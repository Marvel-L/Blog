# engine_stage 统一编排架构

> 更新时间：2026-08-06
> 状态：**已落地，灰度切换中**。核心编排层 `engine_stage` 已完整实现并经过测试，业务入口通过 v2 包以灰度开关方式逐步切换，v1 旧链路保留作为回退。
> 目标：把 check（校验）与 refresh（刷新）的执行链路精简为 engine_stage 层的「统一注册 + 唯一执行入口」，通过**配置化的 Stage 序列**支持 check/refresh 任意穿插，并通过 QuoteBizOpType 支持 SubmitQuote / BizDataCheck / BizDataRefresh 三种场景。

---

## 一、最终目录结构

```
biz/service_basic/
├── engine_common/                     # 通用契约 & 常量（最底层，不依赖任何引擎包）
│   ├── const.go                       # BlockLevel / QuoteBizOpType / QuoteBizDataType / StageKind
│   ├── model.go                       # CheckResult / RefreshResult（结果模型下沉至此）
│   └── func.go                        # HasApplyItem / GetAllItems 等通用工具函数
│
├── engine_stage/                      # 注册 + 执行编排（唯一入口，共 4 个文件）
│   ├── stage.go                       # StageItem / StageResult / IsBlocking / Err / uniqueQuoteContextKeys
│   ├── registry.go                    # Registry：统一注册 rule 桶 / refresher / opType 准入规则+执行序列
│   ├── executor.go                    # Run 唯一执行入口 + ExecOptions / ExecResult / WithSkipBlockRules
│   └── registration.go                # init() 集中装配：全部 bucket / refresher / opType 配置
│
├── check_engine/                      # 只保留具体 Rule 实现 + 接口定义
│   ├── biz_rule.go                    # QuoteBizRule interface（直接返回 engine_common.CheckResult）
│   └── biz_data_rule_*.go / full_quote_rule_*.go / op_access_rule_*.go
│
└── refresh_engine/                    # 只保留具体 Refresher 实现 + 接口定义
    ├── biz_refresher.go               # QuoteBizRefresher interface（直接返回 engine_common.RefreshResult）
    └── biz_data_refresher_*.go        # 共 13 个具体 refresher 实现

biz/service/
├── quote_service_by_engine/           # 业务入口层（v1 旧链路，保留回退）
│   ├── submit_quote.go                # SubmitQuote 入口（v1 旧调度，注入点支持 v2）
│   ├── biz_data_check.go              # BizDataCheck 入口（v1 旧调度，注入点支持 v2）
│   ├── biz_data_refresh.go            # BizDataRefresh 入口（v1 旧调度，注入点支持 v2）
│   └── ...                            # v1 配套实现文件
│
└── quote_service_by_engine_v2/        # 业务入口层（v2 新链路，使用 engine_stage.Run）
    ├── submit_quote.go                # SubmitQuote v2：直接调用 engine_stage.Run
    ├── biz_data_check.go              # BizDataCheck v2：直接调用 engine_stage.Run
    ├── biz_data_refresh.go            # BizDataRefresh v2：直接调用 engine_stage.Run（含 refresherKey 别名兼容）
    └── *_compare_test.go              # v1/v2 结果对比测试，保证灰度切换一致性
```

**灰度切换机制**：三个入口均通过 `shouldUseEngineV2()` 判断，按配置开关支持黑/白名单 + QuoteID 百分比灰度，逐步切流到 v2 新链路。

---

## 二、核心设计决策

| 决策 | 结论 |
|---|---|
| StageItem 数据源 | 每个 OpType 的完整执行序列在 `engine_stage/registration.go` 的 `init()` 中通过链式 DSL 声明，**唯一事实源** |
| StageItem.Kind | 不在 StageItem 中显式声明 Kind；由 `Registry.KindOf(key)` 根据 key 是否落在 QuoteBizDataType 桶或 refresher 集合自动判断，避免写错 |
| 准入校验（Access） | 独立于 stage 序列，通过 `WithAccessRules` 绑定到 opType，固定 FailFast=true 最先执行；不支持白名单降级 |
| BizDataRefresh 动态 keys | 通过 `ExecOptions.OverrideStages` 动态构造 refresher 序列传入，无默认 stages |
| 结果双错误码 | CheckResult 保留 `ErrorCode/ErrorMsg`（老号段，对外兼容）+ 新增 `BizErrorCode/BizErrorMsg`（CCRRNN原子化新号段，内部诊断） |
| Refresh 错误处理 | refresher 系统级失败统一通过 Go error 向上传播；业务阻断通过 RefreshResult.Pass=false+BlockLevel=Error 表达 |
| 循环依赖解法 | `engine_common` 处于最底层（不依赖任何引擎包）；`engine_stage` 依赖 check_engine + refresh_engine 做集中装配；业务包 import engine_stage 触发 init 注册 |
| Needs 预加载 | Run 开始前一次性收集所有 stage + access rule 的 Needs() 去重后统一加载，减少无效 IO |
| Mods 增量重载 | Refresh 步 Changed=true 且 Mods() 非空时，按 mod keys 增量 reload QuoteContext 给后续 stage；QueryOnly=true 时跳过 reload |
| 白名单降级 | WithSkipBlockRules 按 RuleKey 精确命中，仅作用于业务 Check 规则，将 Error 降为 Warn、Pass 改为 true；准入 rule 不支持降级 |

---

## 三、engine_common 层

### 3.1 const.go — 类型与枚举

```go
// BlockLevel 阻塞级别：Error-阻塞流程，Warn-不阻塞仅告警，Info-不阻塞仅记录日志
type BlockLevel string
const (
    BlockLevelError BlockLevel = "Error"
    BlockLevelWarn  BlockLevel = "Warn"
    BlockLevelInfo  BlockLevel = "Info"
)

// QuoteBizOpType 报价业务操作类型
type QuoteBizOpType string
const (
    QuoteBizOpTypeSubmitQuote    QuoteBizOpType = "SubmitQuote"    // 提交报价单
    QuoteBizOpTypeBizDataCheck   QuoteBizOpType = "BizDataCheck"   // 报价单业务数据校验
    QuoteBizOpTypeBizDataRefresh QuoteBizOpType = "BizDataRefresh" // 报价单业务数据刷新
)

// QuoteBizDataType 业务数据类型：Registry 以此为桶维度挂载 rule 集合
type QuoteBizDataType string
const (
    QuoteBizDataTypeQuoteBaseInfo QuoteBizDataType = "QuoteBaseInfo" // 报价单基础信息维度
    QuoteBizDataTypeQuoteItem     QuoteBizDataType = "QuoteItem"     // 报价项维度
    QuoteBizDataTypeGuarantee     QuoteBizDataType = "Guarantee"     // 保底维度
    QuoteBizDataTypeRebate        QuoteBizDataType = "Rebate"        // 返佣维度
    QuoteBizDataTypeCoupon        QuoteBizDataType = "Coupon"        // 代金券申请维度
    QuoteBizDataTypeCredit        QuoteBizDataType = "Credit"        // 信控申请维度
    QuoteBizDataTypeResourcePage  QuoteBizDataType = "ResourcePage"  // 资源页维度
    QuoteBizDataTypeFullQuote     QuoteBizDataType = "FullQuote"     // 整单维度
)

// StageKind 执行项类型
type StageKind string
const (
    StageKindCheck   StageKind = "check"   // 业务数据桶校验
    StageKindRefresh StageKind = "refresh" // 数据刷新
    StageKindAccess  StageKind = "access"  // 准入校验（独立于 stage 序列，固定最先执行）
)
```

### 3.2 model.go — 结果模型

```go
type CheckResult struct {
    Pass         bool
    BlockLevel   BlockLevel
    RuleKey      string
    RuleDesc     string
    ErrorCode    errors.ErrorCodeN   // 老号段，对外兼容，白名单/监控/开放接口按此判定
    ErrorMsg     string
    BizErrorCode errors.ErrorCodeN   // CCRRNN 原子化新号段，用于内部精准诊断
    BizErrorMsg  string
    Detail       interface{}
}

type RefreshResult struct {
    Pass          bool
    BlockLevel    BlockLevel
    RefresherKey  string
    RefresherDesc string
    Detail        interface{}
    Changed       bool                // 本次刷新是否修改了数据，true 时触发 Mods reload
}
```

---

## 四、engine_stage 层

### 4.1 stage.go

**StageItem**：执行项的最小单元，只有 Key 字段，Kind 由 Registry 自动推断：

```go
type StageItem struct {
    Key string
}

// 构造器（推荐使用，避免手写字符串 key）
func CheckBucket(bucket engine_common.QuoteBizDataType) StageItem     // 执行桶下全部 rule
func RunRefresher(ref refresh_engine.QuoteBizRefresher) StageItem     // 执行指定 refresher
```

**StageResult**：单个执行项结果，按 Kind 内嵌具体结果：

```go
type StageResult struct {
    Kind    engine_common.StageKind
    Check   *engine_common.CheckResult    // Kind=check/access 时有效
    Refresh *engine_common.RefreshResult  // Kind=refresh 时有效
}

func (r *StageResult) IsBlocking() (bool, error)  // 未通过且 BlockLevel=Error
func (r *StageResult) Err() error                  // 阻断结果转业务错误（refresh 统一返回 CodeNGetBizRefresherFailed）
```

### 4.2 registry.go — 统一注册表

Registry 通过链式 DSL 注册三类实体：

| 注册方法 | 用途 |
|---|---|
| `RegisterBucket(bucket).WithRules(...)` | 声明业务数据桶并挂载 rule，保持注册顺序 |
| `RegisterRefreshers(...)` | 批量注册全局 refresher（以 refresher.Key() 为唯一 ID），不与桶绑定 |
| `RegisterOpType(opType).WithStages(...).WithAccessRules(...)` | 声明 opType 的执行序列 + 准入 rule |

核心查询方法：
- `KindOf(key)` — 根据 key 自动判断 StageKind（桶→check，refresher→refresh），未注册返回 error
- `StagesByOpType(opType)` — 获取 opType 的默认执行序列
- `RulesByBizDataType(bucket)` — 获取桶下 rule 列表（按注册顺序）
- `RefresherByKey(key)` — 按 key 获取 refresher
- `AccessRulesByOpType(opType)` — 获取 opType 的准入 rule 列表
- `Validate()` / `MustValidateRegistry()` — 注册合法性校验（启动期 panic 兜底）

Validate 覆盖校验项：
1. 桶名非空、无 nil rule、rule.Key() 全局唯一
2. refresher 无 nil、key 非空、全局唯一、不与桶名冲突
3. 所有 opType 的 stage 引用的 key 全部已注册
4. 准入 rule 无 nil、无空 key、key 不与业务 rule 重复（避免白名单误作用）

### 4.3 executor.go — 唯一执行入口

**ExecOptions** 运行时参数：

```go
type ExecOptions struct {
    QueryOnly      bool                // refresher 不写库、不 reload Mods
    FailFast       bool                // Check 步遇 Error 是否短路；Access 固定 FailFast；Refresh Error 始终短路
    ResultOpts     []CheckResultOption // Check 结果后处理（白名单降级等），不作用于 Access
    OverrideStages []StageItem         // 非 nil 时覆盖默认序列；空切片=不跑任何 stage；nil=使用默认序列
}
```

**ExecResult** 执行产物：

```go
type ExecResult struct {
    QuoteCtx *quote_context.QuoteContext
    Stages   []*StageResult
    Blocking *StageResult  // 首个阻断结果
}

func (r *ExecResult) CheckResults() []*engine_common.CheckResult    // 业务校验结果（不含 Access）
func (r *ExecResult) RefreshResults() []*engine_common.RefreshResult // 刷新结果
func (r *ExecResult) BlockingErr() error                             // 首个阻断错误
func (r *ExecResult) SummarizeCheckResults() (pass bool, results []*engine_common.CheckResult)
// pass=true 表示无 Error 级阻断；results 返回需展示给用户的 Warn+Error 项
```

**Run 执行流程**：
1. 校验 quoteCtx / registry 非空
2. 确定 stage 序列（OverrideStages 优先，否则取默认序列）
3. 获取准入 rule 列表
4. 一次性 collectNeeds（合并准入 rule 的 Needs）→ 去重 → Load 全部所需 QuoteContext 数据
5. 执行准入 rule（固定 FailFast，命中 Error 短路返回）
6. 按序执行 stages：
   - Check 步：跑桶内全部 rule → fillCheckResult 兜底 → 应用 ResultOpts → 记录结果 → FailFast 控制短路
   - Refresh 步：refresher.Refresh → 系统错误直接返回 Go error → fillRefreshResult 兜底 → 记录结果 → Error 级阻断始终短路 → Changed=true 且非 QueryOnly 时增量 reload Mods
   - 已有 Blocking 后 break 跳过后续 Refresh 步（避免用过时数据写库）
7. 打印执行汇总日志

**WithSkipBlockRules**：白名单降级 CheckResultOption，命中规则的 BlockLevel 从 Error 降为 Warn、Pass 改为 true。

### 4.4 registration.go — 集中装配

init() 中通过链式 DSL 一次性装配全部内容，MustValidateRegistry 校验后设为默认注册表。

**注册顺序原则**：
1. 桶间顺序：整单基础信息 → 报价项 → 独立业务维度 → 整单聚合校验
2. 桶内顺序：核心枚举合法性 → 简单字段必填/格式/JSON解析 → 数值/有效期逻辑 → 场景化复杂校验+外部数据依赖 → 账号链式校验 → 含Lark RPC的最复杂校验放最后
3. 依赖前置、成本后置：含外部RPC调用的规则放桶内最后，避免基础校验失败时的无效调用
4. refresher 全局注册，不与桶绑定，在 opType stage 序列中精确控制执行时机

**三个 OpType 的执行序列**：

| OpType | Access | Stages 序列 |
|---|---|---|
| **SubmitQuote** | OpAccessQuoteOperationRule | 预刷新(5个: QuoteOppInfo/RebateNotSupportClean/RebateSupportUpdate/ResourcePageCleanExpired/CouponTriggerInfo) → Check 8个桶(QuoteBaseInfo→QuoteItem→Guarantee→Rebate→Coupon→Credit→ResourcePage→FullQuote) → 后置刷新(8个: ItemDiscountHeir/ItemProductInfo/ItemProductTaxRule/ItemCalFactorData/ItemSelectAllExclude/QuoteRelatedResDep/ItemInquiry/ItemTotalDiscount)，共 21 步 |
| **BizDataCheck** | OpAccessQuoteOperationRule | Check 8个桶（顺序同上，无预刷新、无后置刷新），共 8 步 |
| **BizDataRefresh** | OpAccessQuoteOperationRule | 无默认 stages，由外部通过 OverrideStages 传入动态 refresherKeys |

---

## 五、check_engine / refresh_engine 层

两个引擎包都精简为**接口定义 + 具体实现**，不再持有注册表/执行器：

**check_engine/biz_rule.go**：
```go
type QuoteBizRule interface {
    Key() string
    Desc() string
    Needs() []quote_context.QuoteContextKey
    BlockLevel() engine_common.BlockLevel
    Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*engine_common.CheckResult, error)
}
```
- 每个 rule 文件独立实现 QuoteBizRule 接口，直接返回 `*engine_common.CheckResult`
- 使用 `newPassCheckResult(rule)` 快速构造通过结果
- ErrorCode 字段填老号段保持对外兼容，BizErrorCode 字段填 CCRRNN 原子化新号段

**refresh_engine/biz_refresher.go**：
```go
type QuoteBizRefresher interface {
    Key() string
    Desc() string
    Needs() []quote_context.QuoteContextKey
    Mods() []quote_context.QuoteContextKey  // Changed=true 时需要 reload 的 QuoteContextKey
    BlockLevel() engine_common.BlockLevel
    Refresh(ctx context.Context, tx *gorm.DB, quoteCtx *quote_context.QuoteContext, queryOnly bool) (*engine_common.RefreshResult, error)
}
```
- 每个 refresher 文件独立实现 QuoteBizRefresher 接口，直接返回 `*engine_common.RefreshResult`
- 使用 `newPassRefreshResult(refresher)` 快速构造通过结果
- queryOnly=true 时只查询不写库、不触发副作用

---

## 六、业务入口层（v2 新链路）

三个入口统一调用 `engine_stage.Run`，通过 init() 注册到 v1 包的注入点，由灰度开关控制流量：

| 入口文件 | opType | ExecOptions 要点 |
|---|---|---|
| `quote_service_by_engine_v2/submit_quote.go` | SubmitQuote | FailFast=true（快速失败）；WithSkipBlockRules(白名单)；使用默认 stages；事务包裹 |
| `quote_service_by_engine_v2/biz_data_check.go` | BizDataCheck | FailFast=false（收集全部失败）；WithSkipBlockRules(白名单)；使用默认 stages；通过 SummarizeCheckResults() 适配返回 |
| `quote_service_by_engine_v2/biz_data_refresh.go` | BizDataRefresh | FailFast=true；QueryOnly 透传；OverrideStages 由 refresherKeys 动态构造；含 refresherKey 别名兼容（refreshProductTaxRule → 新 key）；事务包裹 |

---

## 七、行为语义清单（回归底线）

| # | 语义 | 实现方式 |
|---|---|---|
| 1 | 执行顺序 | SubmitQuote 21步 / BizDataCheck 8桶 / BizDataRefresh 动态，严格按 registration.go 中声明顺序 |
| 2 | Access FailFast | 准入 rule 固定 FailFast=true，命中 Error 直接短路，不执行后续任何 stage |
| 3 | Check FailFast | 由 ExecOptions.FailFast 控制；SubmitQuote=true（快速失败），BizDataCheck=false（收集全部） |
| 4 | Refresh 短路 | Refresh 步返回 Go error 或 Pass=false+BlockLevel=Error 始终短路（不受 FailFast 控制），避免下游 Rule 读过时数据 |
| 5 | Refresh 副作用保护 | 已有 Blocking 后 break 跳过后续 Refresh 步（避免用过时数据写库） |
| 6 | Mods reload | Refresh Changed=true 且非 QueryOnly 且 Mods() 非空 → 按 mod keys 增量 reload QuoteContext 给后续 stage |
| 7 | Needs 预加载 | Run 开始前一次性 load 全部 stage + access rule 的 Needs()（去重），减少无效加载 |
| 8 | 兜底填充 | Rule/Refresher 返回 nil 或缺字段 → 用 Key/Desc/BlockLevel() 补齐；nil rule 返回 CodeNGetBizCheckerFailed / CodeNCheckDependencyCallFailed |
| 9 | 白名单降级 | WithSkipBlockRules 按 RuleKey 精确命中，将 Error 降为 Warn、Pass 改为 true；准入 rule 不支持降级 |
| 10 | refresherKey 别名 | biz_data_refresh.go v2 维护 refresherKeyAlias 表，入参归一、出参用 canonical key，保持对外兼容 |
| 11 | 日志 | 统一前缀 `[engine_stage]`；按 BlockLevel 分级别打印 access/rule hit；refresh 打印 done/failed + reload 日志 |
| 12 | CheckResult 双号段 | ErrorCode/ErrorMsg 沿用老号段保持对外兼容；BizErrorCode/BizErrorMsg 为 CCRRNN 原子化新号段供内部诊断 |

---

## 八、依赖关系总结

```
engine_common（最底层，零反向依赖）
    ↑
check_engine ──┐
               ├──→ engine_stage（集中装配 + 唯一执行入口）
refresh_engine ┘                      ↑
                                       │
                          quote_service_by_engine_v2（v2 业务入口）
                                       ↑
                                       │（init 注册注入）
                                       ↓
                          quote_service_by_engine（入口分发 + v1 旧链路回退）
```

- `engine_common` 不 import 任何引擎包
- `check_engine` / `refresh_engine` 只 import `engine_common`（用结果类型和常量），互相无依赖
- `engine_stage` import `engine_common` + `check_engine` + `refresh_engine`，负责集中注册与执行
- `quote_service_by_engine_v2` import `engine_stage` + `engine_common`，无需直接 import check_engine/refresh_engine（registration.go 的 init 已完成全部注册）
- `quote_service_by_engine` 作为统一入口，通过开关分发到 v1/v2 实现

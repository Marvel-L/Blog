# 报价系统校验引擎升级迁移进度

> 本文档用于跨任务、跨会话延续上下文。每完成一步必须同步更新本文件。

最后更新：2026-05-25（本轮 7.24.3 续推（第二批）：新增 `TradeProductTypeRule` / `PartnerNameRule` / `CustomerNameRule` 三条原子校验 Rule —— `TradeProductTypeRule` 由 `Quote.GetProductTypeMap` 重算 `containsNoStandard/onlyContainsOnline`，由 `Quote.IsDistributionBizTypeCustom()` 派生 BP 分销-特殊报价分支，仅依赖 `Persisted.Quote`，零 RPC；`PartnerNameRule` / `CustomerNameRule` 通过 `Quote.IsInnerQuote()/IsPrmQuote()` 内联派生 IsInnerQuote/IsPrmQuote，比对 `External.OppInfo.PartnerInfo.AccountName / AccountInfo.AccountName`，复用既有 `loaderOppInfo`，零新增 loader、零副作用。错误码 / 文案与原 `QuoteData.*Check` 完全一致；统一挂在 `checkQuoteBaseInfo` 下，与 `preRunQuoteDataCheckIfNeeded` 共存双跑直到 7.24.4 撤除前置。7.24.3 仍待迁：`PartnerContractNoCheck` / `PriceValidPeriodCheck` / `TradeTypeCheck`（伙伴授权分支）/ `RelatedAccountIDsCheck` / `CustomerDetailCheck`，需新增 `loaderPartnerGrant` / `loaderAccountAndVerifyInfos`，并将 `PartnerContractNoCheck` 的 quote 字段写回剥离到入口前置）

---

## 1. 背景与目标

将 `QuoteBizDataCheck` / `SubmitQuoteV2` 接口的校验逻辑，从原有的 `quote_service` 内嵌 `BizRuleChecker` 体系，迁移到新的 `check_engine` 框架（基于 `quote_context` + `OpChecker` + `RuleRegistry`）。

要求：

- 接入新框架（`quote_context` 加载 + `check_engine` 引擎）
- **保留全部历史代码**（老 checker 不删，仍可被复用）
- 原 `UseNewQuoteCheckEngine` 灰度已下线，`quote_service_by_engine` 已固定使用该校验引擎；后续 V2 演进由独立的 `UseQuoteEngineV2*` 开关控制

## 2. 拆分原则（重要）

校验拆分按 **三层**：

```
OpType（操作维度，如 SubmitQuote）
  └── CheckKey（实体域维度，如 报价单基础信息 / 报价项 / 资源单 / 折扣 / 商务优惠 …）
        └── Rule（原子规则，如 0元报价校验 / 最大数目校验 / 售卖模式合法性…）
```

要点：

- `CheckKey` **按实体域聚合**，不要把单个原子规则做成独立 CheckKey
- 例如 0元报价、比例计费项、报价项有效性、售卖模式合法性，都属于 **报价项实体域**，应统一挂在 `checkQuoteItem` 下
- 同一个 OpType 通过 `WithCheckKeys(...)` 关联若干 CheckKey，间接拿到该域下全部 Rule

## 3. QuoteContext 数据载体

```
QuoteContext
├── Persisted   // 报价单本体相关持久化数据（DB）
├── External    // 外部依赖（商品/配置/价格/商机…）
└── Inputs      // 入参开关
```

External 已注册 loader：

| Key | Loader | 依赖 |
|-----|--------|------|
| QuoteContextKeyProductInfo  | loaderProductInfo  | （已存在） |
| QuoteContextKeyConfigTreeMap | loaderConfigTreeMap | Quote / QuoteItems / DeliveryItems |
| QuoteContextKeyConfigInfoMap | loaderConfigInfoMap | ItemContextMap（仅 IsPublicItem） |
| QuoteContextKeyPriceInfoMap  | loaderPriceInfoMap  | ItemContextMap（仅 IsExactChargeItem） |
| QuoteContextKeyOppInfo       | loaderOppInfo       | Quote |
| QuoteContextKeyOpportunity   | loaderOpportunity   | Quote（CRM `GetOpportunityInfo`，含 JointPrintInfo） |
| QuoteContextKeySpecialRebatePolicy | loaderSpecialRebatePolicy | Opportunity（PRM `GetSpecialRebatePolicy`，仅当 JointPrintInfo 存在时调用） |
| QuoteContextKeyApplyItems    | loaderApplyItems    | （仅依赖 quoteID，调用 apply_checker.FindUsedApplyItem 加载） |
| QuoteContextKeyCombineRulesBySolution | loaderCombineRulesBySolution | QuoteSolutions（取 TemplateSolutionId 调用 dal.CombineRuleDao.FindRulesBySolutions，按 QuoteSolution.Id 反向汇总到 map） |
| QuoteContextKeyDeliveryItemCost | loaderDeliveryItemCost | Quote / DeliveryItems / ItemContextMap（仅 IsConfigList/IsProjectBased 时才发起 RPC；调用 `item_context.QuoteItemFindSingleCost` → `commodity_service.GetTradeProductByArray` + `trade_client.BatchGetChargeItemCostLatest`，写入 `Persisted.DeliveryItemUnitCost` 和 `DeliveryItemCostReqList`） |
| QuoteContextKeyParentItemContextMap | loaderParentItemContextMap | Quote（仅 `IsProjectSupplyAgreement && ParentQuoteID > 0` 时发起；调用 `assistant.Callback`(QuoteItems/DeliveryItems/ItemValues) + `item_context.NewItemContextByCallbackInfo` 构建父报价单的 `map[itemID]*ItemContext`） |
| QuoteContextKeyParentContractTime | loaderParentContractTime | Quote（仅 `IsProjectSupplyAgreement && ParentQuoteID > 0` 时发起；调用 `contract_service.GetContractTimeByQuoteID`，写入 `External.ParentContractInfo`，结构体字段 `ValidBegin / ValidEnd`） |
| QuoteContextKeyResourceItemsFromQuote | loaderResourceItemsFromQuote | Quote（仅 `SupportResourcePage && !IsBytePlus` 时发起；调用 `resource_page_service.GetResourceItemFromQuoteItem`，写入 `Persisted.ResourceItemsFromQuote`） |
| QuoteContextKeyResourceItemRespsFromDB | loaderResourceItemRespsFromDB | Quote（仅 `SupportResourcePage && !IsBytePlus` 时发起；调用 `resource_page_service.GetItemRespListFromDB`，写入 `Persisted.ResourceItemRespsFromDB`） |
| QuoteContextKeyQuoteItemsAllStatus | loaderQuoteItemsAllStatus | （仅依赖 quoteID；`FindQuoteItemsByQuoteID(..., ItemStatusAll, ItemSceneQuoteItem)`；写入 `Persisted.QuoteItemsAllStatus`，对应原 `assistant.CallbackKeyQuoteItemsAllStatus` 含草稿语义） |
| QuoteContextKeyDistributorInfo | loaderDistributorInfo | （依赖 Quote；仅在 `IsDistributionBizTypeCustom() && CustomerDetail != ""` 时调用 `account_service.GetDistributorInfo(ctx, Quote.CustomerDetail)`；写入 `External.DistributorInfo`，供 `DistributorInfoRule` 使用） |

## 4. 关键文件清单

### 新增

- `biz/service/check_engine/check_engine.go`（OpChecker / RuleRegistry 调度核心）
- `biz/service/check_engine/biz_rule.go`（QuoteBizRule 接口）
- `biz/service/check_engine/check_result.go`（CheckResult 结构）
- `biz/service/check_engine/rule_set_registry.go`（注册器）
- `biz/service/check_engine/const.go`（OpType / CheckKey / BlockLevel 常量）
- `biz/service/check_engine/op_access_rule_quote_can_operate.go`（AccessCheckRule 示例）
- `biz/service/check_engine/biz_data_rule_max_item_num.go`（PoC BizDataRule，挂在 checkQuoteBaseInfo）
- `biz/service/check_engine/biz_data_rule_zero_quote.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_item_selling_mode_valid.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_item_effective.go`（**已迁移**，挂在 checkQuoteItem，内联了 ValidateQuoteItems 避免反向依赖）
- `biz/service/check_engine/biz_data_rule_ratio_charge_item.go`（**已迁移**，挂在 checkQuoteItem，依赖 External.PriceInfoMap）
- `biz/service/check_engine/biz_data_rule_item_discount.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_related_charge_item.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_unstandard_delivery_item_cost.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_estimated_income.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_product_customer_scope.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_related_product.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_distribution_discounts.go`（**已迁移**，挂在 checkQuoteItem）
- `biz/service/check_engine/biz_data_rule_guarantee.go`（**已迁移**，挂在 checkGuaranteeItem，依赖 Quote / QuoteItems / GuaranteeItem）
- `biz/service/check_engine/biz_data_rule_rebate.go`（**已迁移**，挂在 checkRebate，副作用 SoftDeleteRebateItem 已剥离到入口层）
- `biz/service/check_engine/biz_data_rule_coupon_apply.go`（**已迁移**，挂在 checkCoupon；仅在存在 BizKey=coupon 时校验 quote.SupportCoupon）
- `biz/service/check_engine/biz_data_rule_credit_apply.go`（**已迁移**，挂在 checkCredit；仅在存在 BizKey=credit 时校验 quote.SupportCredit + 至少一条公有云标品报价项）
- `biz/service/check_engine/biz_data_rule_coupon_param.go`（**已迁移**，挂在 checkCoupon；复用 `Persisted.CouponList` loader，校验类 RPC `couponconfigservice.ValidateCoupon` 在 Rule 内直接调用，开关/拦截逻辑保持与原 ValidateQuoteCouponsWithSwitch 一致）
- `biz/service/check_engine/biz_data_rule_combine_rule.go`（**已迁移**，挂在 checkQuoteBaseInfo；依赖 QuoteItems / QuoteSolutions / CombineRulesBySolution，调用 `rule_check.CheckRelatedProduct`）
- `biz/service/check_engine/biz_data_rule_guarantee_percentage.go`（**已迁移**，挂在 checkGuaranteeItem；复用 `Persisted.ItemContextMap`，`ItemContext.ValidateCalculationFactor` 作为校验类调用直接在 Rule 内执行）
- `biz/service/check_engine/biz_data_rule_config_list.go`（**已迁移**，挂在 checkQuoteItem；依赖 Quote / DeliveryItems / ItemContextMap / DeliveryItemUnitCost；本地按 `req.GetKey()` 分组判断成本价/出厂价类型为阶梯价的交付项是否重复）
- `biz/service/check_engine/biz_data_rule_project_supply.go`（**已迁移**，挂在 checkQuoteBaseInfo；依赖 Quote / QuoteItems / DeliveryItems / ItemContextMap / ParentItemContextMap / ParentContractTime；零 RPC / 零 DB，纯校验）
- `biz/service/check_engine/biz_data_rule_resource_page.go`（**已迁移**，挂在 checkQuoteBaseInfo；依赖 Quote / ResourcePage / ResourceItemsFromQuote / ResourceItemRespsFromDB；写副作用剥离到入口 `preCleanExpiredResourceItemsIfSupport`）
- `biz/service/check_engine/biz_data_rule_quote_base_info_basic.go`（**部分迁移**，挂在 checkQuoteBaseInfo；依赖 Quote / QuoteItemsAllStatus / DeliveryItems；覆盖原 QuoteBaseInfoChecker 中报价项空 / 草稿 / SP / 项目制手工交付项 / 未立项产品线必填 5 个原子校验，**不含** `quoteDataCheck` 和 `validateDistributorInfos` RPC 部分；原 checker 在"不含未立项商品但 UnapprovedProductLines 非空"时回写 quote 的副作用按 §9 已剥离，本 Rule 不做回写）
- `biz/service/check_engine/biz_data_rule_distributor_info.go`（**已迁移**，挂在 checkQuoteBaseInfo；依赖 Quote / DistributorInfo；BP 分销业务下做 FinalCustomer / FirstDistributor / SecondDistributor 三段一致性比对；非分销业务直接 Pass，无写副作用）
- `biz/service/check_engine/biz_data_rule_quote_field_basic.go`（**已迁移**，挂在 checkQuoteBaseInfo；汇集 7.24.2 纯字段类 8 条 Rule：`DistributionBizTypeRule` / `ProjectAttributesRule` / `QuoteNotesRule` / `GiveAwayInfoRule` / `EffectiveInfoRule` / `ChangeInfoRule` / `EstimatedTradingMonthlyIncomeRule` / `PublicCloudEstimateRule`；仅依赖 `Persisted.Quote`，零 helper / 零 RPC / 零 DB；与 `preRunQuoteDataCheckIfNeeded` 共存双跑直到 7.24.4 撤除前置）
- `biz/service/check_engine/biz_data_rule_deduct_discount.go`（**已迁移**，挂在 checkQuoteItem；依赖 Quote / QuoteItems / ItemContextMap；合同价折扣 RPC `price_client.ListContractDiscountRaw` 与 SP 抵扣计费项缓存 `SpDeductChargeItemsCache.GetSpDeductChargeItemInfo` 均在 Rule 内直接执行，无新增 loader）
- `biz/service/check_engine/biz_data_rule_related_business_discount.go`（**已迁移**，挂在 checkRebate；依赖 Quote / QuoteItems / ItemContextMap / RebateItemList / GuaranteeItem；PRM `rebate_item_service.GetPrmRebateRange` 在 Rule 内直接调用，复用 `Persisted.ItemContextMap` 过滤"公有云在线 + 非 SP 抵扣 + ItemSceneQuoteItem"后传入，无新增 loader）
- `biz/service/quote_context/loader_delivery_item_cost.go`
- `biz/service/quote_service/op_check_dispatch.go`（灰度调度 + 适配层 + Rebate 副作用前置清理 `preCleanRebateItemsIfNotSupport`）
- `biz/service/quote_context/loader_config_tree_map.go`
- `biz/service/quote_context/loader_config_info_map.go`
- `biz/service/quote_context/loader_price_info_map.go`
- `biz/service/quote_context/loader_opp_info.go`
- `biz/service/quote_context/loader_apply_items.go`
- `biz/service/quote_context/loader_opportunity.go`
- `biz/service/quote_context/loader_special_rebate_policy.go`
- `biz/service/quote_context/loader_parent_item_context_map.go`
- `biz/service/quote_context/loader_parent_contract_time.go`
- `biz/service/quote_context/loader_resource_items_from_quote.go`
- `biz/service/quote_context/loader_resource_item_resps_from_db.go`
- `biz/service/quote_context/loader_quote_items_all_status.go`

### 修改

- `biz/service/check_engine/const.go`：新增 `checkQuoteBaseInfo`、`checkQuoteItem`、`checkGuaranteeItem`、`checkRebate`、`checkCoupon`、`checkCredit`
- `biz/service/check_engine/check_engine.go`：注册 `&MaxItemNumRule{}`、报价项维度全部 Rule（含 `&DeductDiscountRule{}`）、`&GuaranteeRule{}`、`&GuaranteePercentageRule{}`、`&RebateRule{}`、`&CouponApplyRule{}`、`&CreditApplyRule{}`、`&QuoteCanOperateRule{}`
- `biz/service/quote_context/const.go`：注册 4 个 External loader + `loaderApplyItems`
- `biz/service/quote_context/quote_context.go`：`Persisted` 新增 `ApplyItems []*model.CommonApplyItem`
- `biz/service/quote_service/biz_data_check.go`：QuoteBizDataCheck 接入灰度分支 + 调用 `preCleanRebateItemsIfNotSupport`
- `biz/service/quote_service/submit_quote_v2.go`：SubmitQuoteV2 接入灰度分支

## 5. 灰度调度与阶段控制

`op_check_dispatch.go`：

- `shouldUseNewCheckEngine(ctx, quoteID)`：BlackList > IsOpen > WhiteList > 默认走新
- `runOpCheckByEngine(...)`：按 `opCheckPhase` 控制 `All / Access / BizData`
- `firstBlockingResult(results)`：返回首个阻断级失败（适配 SubmitQuote 主链路）
- `adaptEngineResultsToBizCheckResults(results)`：适配端上响应结构

## 6. 任务列表与状态

> 与 TaskList 同步维护

| # | 状态 | 任务 |
|---|------|------|
| 1 | ✅ completed | 初版校验引擎灰度已完成并已下线，校验引擎作为默认链路保留 |
| 2 | ✅ completed | 新增统一灰度切换 dispatcher 文件（`op_check_dispatch.go`） |
| 3 | ✅ completed | `checkQuoteBizData` 接入灰度分支 |
| 4 | ✅ completed | `submitQuoteV2` 接入灰度分支 |
| 5 | ✅ completed | 补齐 4 个 External loader 实现并注册 |
| 6 | ⏳ pending | 分批迁移存量校验规则到 check_engine（拆分入下方子任务） |
| 7 | ✅ completed | 迁移 `ZeroQuoteChecker` → `ZeroQuoteRule`（挂 `checkQuoteItem`） |
| 7.1 | ✅ completed | 迁移 `ItemSellingModeValidChecker` → `ItemSellingModeValidRule`（挂 `checkQuoteItem`） |
| 7.2 | ✅ completed | 迁移 `ItemEffectiveChecker` → `ItemEffectiveRule`（挂 `checkQuoteItem`，内联 ValidateQuoteItems） |
| 7.3 | ✅ completed | 迁移 `RatioChargeItemChecker` → `RatioChargeItemRule`（挂 `checkQuoteItem`） |
| 7.4 | ✅ completed | 迁移 `ItemDiscountChecker` → `ItemDiscountRule`（挂 `checkQuoteItem`） |
| 7.5 | ✅ completed | 迁移 `RelatedChargeItemChecker` → `RelatedChargeItemRule`（挂 `checkQuoteItem`） |
| 7.6 | ✅ completed | 迁移 `UnStandardDeliveryItemCostChecker` → `UnStandardDeliveryItemCostRule`（挂 `checkQuoteItem`） |
| 7.7 | ✅ completed | 迁移 `EstimatedIncomeChecker` → `EstimatedIncomeRule`（挂 `checkQuoteItem`） |
| 7.8 | ✅ completed | 迁移 `ProductCustomerScopeChecker` → `ProductCustomerScopeRule`（挂 `checkQuoteItem`） |
| 7.9 | ✅ completed | 迁移 `RelatedProductChecker` → `RelatedProductRule`（挂 `checkQuoteItem`） |
| 7.10 | ✅ completed | 迁移 `DistributionDiscountsChecker` → `DistributionDiscountsRule`（挂 `checkQuoteItem`） |
| 7.11 | ✅ completed | 迁移 `GuaranteeChecker` → `GuaranteeRule`（挂 **新建** `checkGuaranteeItem`） |
| 7.12 | ✅ completed | 迁移 `RebateChecker` → `RebateRule`（挂 **新建** `checkRebate`，副作用 `SoftDeleteRebateItem` 剥离到入口 `preCleanRebateItemsIfNotSupport`） |
| 7.13 | ✅ completed | 迁移 `CommonApplyChecker` → `CouponApplyRule`（挂 **新建** `checkCoupon`）+ `CreditApplyRule`（挂 **新建** `checkCredit`，DB count 改为本地 `IsPublicStandardItem` 过滤），新增 `QuoteContextKeyApplyItems` loader |
| 7.14 | ✅ completed | 迁移 `CouponParamChecker` → `CouponParamRule`（挂 `checkCoupon`，复用 `Persisted.CouponList` loader，校验类 RPC 在 Rule 内直接调用） |
| 7.15 | ✅ completed | 迁移 `CombineRuleChecker` → `CombineRuleRule`（挂 `checkQuoteBaseInfo`，新增 `loaderCombineRulesBySolution` 把组合规则按 QuoteSolutionID 汇总到 ctx） |
| 7.16 | ✅ completed | 迁移 `DeductDiscountChecker` → `DeductDiscountRule`（挂 `checkQuoteItem`；合同价折扣 RPC + SP 抵扣计费项缓存均在 Rule 内直接执行，按 §11 不新增 loader） |
| 7.17 | ✅ completed | 迁移 `RelatedQuoteItemBusinessDiscountChecker` → `RelatedBusinessDiscountRule`（挂 `checkRebate`；PRM `GetPrmRebateRange` 作为按需 RPC 在 Rule 内直接调用，按 §11 不新增 loader） |
| 7.18 | ✅ completed | 迁移 `ConfigListChecker` → `ConfigListRule`（挂 `checkQuoteItem`；新增 `loaderDeliveryItemCost` 把 `commodity_service.GetTradeProductByArray` + `trade_client.BatchGetChargeItemCostLatest` 收敛到 loader，loader 内做 `IsConfigList/IsProjectBased` 短路） |
| 7.19 | ✅ completed | 迁移 `GuaranteePercentageChecker` → `GuaranteePercentageRule`（挂 `checkGuaranteeItem`，复用 `Persisted.ItemContextMap`，`ItemContext.ValidateCalculationFactor` 作为校验类调用直接在 Rule 内执行） |
| 7.20 | ✅ completed | 迁移 `JointPrintOrderChecker` → `JointPrintOrderRule`（挂 `checkRebate`；CRM/PRM RPC 改造为 `loaderOpportunity` / `loaderSpecialRebatePolicy` 两个 External loader；写副作用 `BuildSaveRebates + RebateItemDao.Save` 剥离到入口 `preSyncJointOrderRebatesIfSupport`） |
| 7.21 | ✅ completed | 迁移 `ProjectSupplyChecker` → `ProjectSupplyRule`（挂 `checkQuoteBaseInfo`；新增 `loaderParentItemContextMap`（Persisted）+ `loaderParentContractTime`（External），均做 `IsProjectSupplyAgreement && ParentQuoteID > 0` 短路；Rule 内零 RPC / 零 DB，仅做父合同有效期 + 增购行为校验） |
| 7.22 | ✅ completed | 迁移 `ResourcePageChecker` → `ResourcePageRule`（挂 `checkQuoteBaseInfo`；新增 `loaderResourceItemsFromQuote` + `loaderResourceItemRespsFromDB`，均做 `SupportResourcePage && !IsBytePlus` 短路；写副作用 `SoftDeleteResourceItems / SoftDeleteResourcePage` 剥离到入口 `preCleanExpiredResourceItemsIfSupport`） |
| 7.23 | ✅ completed | 拆分 `QuoteBaseInfoChecker` 之"非 RPC 原子检查"为 `QuoteBaseInfoBasicRule`（挂 `checkQuoteBaseInfo`；新增 `loaderQuoteItemsAllStatus` 复用 `CallbackKeyQuoteItemsAllStatus` 含草稿语义；覆盖：报价项空 / 草稿 / SP / 项目制手工交付项 / 未立项产品线必填 5 个原子校验；§9 副作用剥离原则下 `UnapprovedProductLines` 自动清空回写不再保留） |
| 7.24 | ⏳ pending | 迁移 `QuoteBaseInfoChecker` 之 `quoteDataCheck`（含商机 RPC + 签约/配价主体回填）—— 拟拆为 1) 商机/伙伴授权数据 loader 化（CRM/Lark/C360）2) 字段回填副作用入口层化 3) 校验类原子规则若干 |
| 7.24.1 | ✅ completed | 入口层"原貌前置" `quoteDataCheck`：`op_check_dispatch.go` 新增 `preRunQuoteDataCheckIfNeeded`（构造 `genQuoteData(quote)` → `quoteDataCheck` → 显式回写 `CustomerIndustryInfo / PriceEntityIndustryInfo / SalesChannelType / ContractPriceAcc / ParentAccountNumber`）；接入 `submitQuoteV2.useNewEngine` 分支与 `checkQuoteBizDataByEngine`（后者先 `dal.QuoteDao.FindQuoteByID` 取 quote）；保留与老链路 BizError 语义一致的 `CodeNQuoteBaseInfoCheckFailed`；后续 7.24.2/7.24.3 拆 Rule 完成后再撤除本前置 |
| 7.24.2 | ✅ completed | 迁移纯字段类原子校验为 Rule（8 条，挂 `checkQuoteBaseInfo`）：`DistributionBizTypeRule` / `ProjectAttributesRule` / `QuoteNotesRule` / `GiveAwayInfoRule` / `EffectiveInfoRule` / `ChangeInfoRule` / `EstimatedTradingMonthlyIncomeRule` / `PublicCloudEstimateRule`；与 `preRunQuoteDataCheckIfNeeded` 共存双跑（前置 fail-fast 优先），错误码/文案与原方法完全一致，零 helper / 零 RPC / 零 DB |
| 7.24.3 | ⏳ pending | 迁移 helper 依赖类原子校验为 Rule |
| 7.24.4 | ⏳ pending | 清理 `JointPrintOrderCheck` 老入口（与 7.24 子任务收尾绑定） |
| 7.25 | ✅ completed | 迁移 `QuoteBaseInfoChecker` 之 `validateDistributorInfos` → `DistributorInfoRule`：新增 `loaderDistributorInfo` + `External.DistributorInfo`，将 `account_service.GetDistributorInfo` RPC 提取到 QuoteContext External；Rule 仅做本地 `json.Unmarshal(Quote.DistributorInfos)` 与 `External.DistributorInfo` 的字段一致性比对，非分销业务直接 Pass；原 `validateDistributorInfos` 经核对无 quote 字段写入，无需入口层前置改造 |
| 8 | ⏳ pending | 迁移 `QuoteBaseInfoChecker` 收尾：清理老入口（待 7.23 ~ 7.25 全部 ✅ 后） |
| 9 | ⏳ pending | 批量迁移剩余存量 checker 到 check_engine |

## 7. CheckKey 域规划（建议草案，落地前再确认）

| CheckKey 常量 | 实体域 | 拟挂载 Rule（来源 Checker） |
|---|---|---|
| `checkQuoteBaseInfo` | 报价单基础信息 | MaxItemNumRule（已落地）、CombineRuleRule（✅）、QuoteBaseInfoBasicRule（✅，仅含非 RPC 原子检查）、DistributorInfoRule（✅）、7.24.2 字段类 Rule 共 8 条（DistributionBizTypeRule / ProjectAttributesRule / QuoteNotesRule / GiveAwayInfoRule / EffectiveInfoRule / ChangeInfoRule / EstimatedTradingMonthlyIncomeRule / PublicCloudEstimateRule，✅）、QuoteBaseInfoChecker 拆分项剩余（quoteDataCheck 中 helper/RPC 依赖部分待迁）、ProjectSupplyChecker（✅）、ResourcePageChecker（✅） |
| `checkQuoteItem`     | 报价项 | ZeroQuoteRule（✅）、ItemEffectiveRule（✅）、ItemSellingModeValidRule（✅）、RatioChargeItemRule（✅）、ItemDiscountRule（✅）、RelatedChargeItemRule（✅）、UnStandardDeliveryItemCostRule（✅）、EstimatedIncomeRule（✅）、ProductCustomerScopeRule（✅）、RelatedProductRule（✅）、DistributionDiscountsRule（✅）、ConfigListRule（✅） |
| `checkGuaranteeItem` | 保底 | GuaranteeRule（✅）、GuaranteePercentageRule（✅） |
| `checkRebate`        | 返佣 | RebateRule（✅）、RelatedQuoteItemBusinessDiscountChecker（待迁移） |
| `checkCoupon`        | 代金券申请 | CouponApplyRule（✅）、CouponParamRule（✅） |
| `checkCredit`        | 信控申请 | CreditApplyRule（✅） |
| `checkBusinessDiscount`（待加） | 商务优惠 | DeductDiscountChecker |

> 说明：以上仅为划归建议。每条 Rule 实施时需对照原 Checker 的 `Check(ctx, tx, quoteBizData)` 方法体重新审视它真正读了哪些字段，再决定挂哪个 CheckKey、`Needs()` 列哪些 QuoteContextKey。

## 8. 已知坑 / 经验

1. **`AllQuoteItems` ≠ 报价项+交付项**
   - 通过 `caller_quote_items.go:27` 验证：`FindQuoteItemsByQuoteID(..., constants.ItemSceneQuoteItem)` 只查报价项
   - 不要在迁移时把 DeliveryItems 合进来（已踩坑，已修正 ZeroQuoteRule）
2. **过渡期双轨**：refresher 不迁移，校验失败/通过都不影响老的 `ProcessBizDataByBizScene` 更新链路
3. **`opCheckPhase`**：SubmitQuote 主链路只跑 BizData 即可，避免与既有 Access 检查重复
4. **TCC 灰度优先级**：`BlackList`（兜底止损）> `IsOpen` > `WhiteList`（白名单灰度）
5. **`Needs()` 务必显式声明**：OpChecker 会做去重 + 调用 `NewLoaderByQuoteContext(...).WithKeys(...).Load(ctx)`，遗漏会触发空指针
6. **CheckResult 必须字段完备**（约定）：
   - Rule 的 `Check` **不允许返回 nil**；通过/失败都必须返回完整的 `CheckResult`
   - 必填字段：`Pass`、`BlockLevel`、`RuleKey`、`RuleDesc`；失败时再补 `ErrorCode`/`ErrorMsg`/`Detail`
   - `OpChecker.checkRules` 会兜底回填 `RuleKey/RuleDesc/BlockLevel`，但 Rule 自身仍应主动赋值
   - 业务层判断标准：
     - `firstBlockingResult` 仅识别 `Pass=false && BlockLevel=Error` 视为阻断
     - `adaptEngineResultsToBizCheckResults` 跳过 `Pass=true` 与 `BlockLevel=Info`，只把 Error/Warn 透出端上
     - `FailFast` 仅在 `BlockLevel=Error` 时短路
7. **避免对 quote_service 的反向依赖**：`quote_service` 已依赖 `check_engine`，因此 Rule 实现不能 import `quote_service` 包内函数（如 `ValidateQuoteItems`）。需要时把核心逻辑内联进 Rule，或下沉到更底层的包（如 `item_context`）
8. **Rule 只做数据校验，不做数据查询/不依赖 `*gorm.DB`（强约束）**
   - **错误做法**：在 `OpChecker.checkRules` 用 `context.WithValue` 把 `oc.Tx` 注入 ctx，Rule 用 `txFromCtx(ctx)` 取出再喂给下游做 DB/RPC 查询。这把"查询"伪装成"校验"，让 Rule 难以被单测覆盖、也违背 `QuoteContextLoader` 统一加载的初衷。
   - **正确做法**：
     1. **数据先放进 QuoteContext**：所有 Rule 需要的下游数据都加 loader（`Persisted` 或 `External`），由 `Needs()` 显式声明，统一通过 `WithKeys(...).Load(ctx)` 预加载。
     2. **下游函数同步重构**：如果原下游函数内部隐式 `dal.DBProxy.NewRequest(c)` / `commodity_service.GetTradeProductByArray` / `GetConfigTreeMapByCommonItems` 等查询，**必须新增一个无 tx 的"纯计算"重载**（如 `GetRelatedChargeItemsByLoaded`），把上述数据改为入参；老的带 `tx` 的入口可以保留给原调用方，避免影响范围扩散。
     3. **以 itemContext 为聚合中心传参**：报价项相关的下游函数，**优先按 `map[itemID]*XxxBizCtx` 这种"以报价项为中心"的结构传参**，把 itemContext 与该报价项相关的商品信息、配置树、价格信息等绑在一起，而不是把 `productInfoMap`/`configTreeMap` 这类按 `tradeProduct`/`configTreeKey` 索引的散表直接外露。这样：
        - Rule 层负责一次性把 `quoteCtx.External.XxxMap[key]` 取出来塞进 `bizCtx`，下游零散查表逻辑下沉
        - 下游函数签名更内聚，与 itemContext 维度的业务语义一致，便于复用与单测
     4. **不要在 `check_engine` 里偷偷扩展 OpChecker（如塞 `txCtxKey`/`withTx`/`txFromCtx`）**：发现自己要给 Rule 传 tx 时，应回到第 1 步把数据 loader 化，而不是给引擎引入 DB 旁路。
   - **典型案例**：`RelatedChargeItemRule` 第一版用 `txFromCtx(ctx)` 调老 `GetRelatedChargeItems`；第二版改为新增 `GetRelatedChargeItemsByLoaded(ctx, quote, quoteItems, productInfoMap, configTreeMap)`；第三版进一步改为 `GetRelatedChargeItemsByLoaded(ctx, quote, quoteItems, bizCtxMap map[int64]*RelatedChargeItemBizCtx)`，由 Rule 用 `itemContext.TradeProduct` / `itemContext.GetConfigTreeKey()` 聚合好后传入，引擎侧彻底删除 `txCtxKey/withTx/txFromCtx`。
9. **副作用必须剥离到入口层**：原 checker 若在校验失败/某分支里执行写操作（如 `RebateChecker` 内的 `dal.RebateItemDao.SoftDeleteRebateItem`），Rule 一律不能保留这些 DB 写入；统一在 `quote_service` 入口（`checkQuoteBizDataByEngine` 调用前）做前置清理，参考 `op_check_dispatch.go:preCleanRebateItemsIfNotSupport`。
10. **DB count 用本地过滤等价替代**：原 checker 中通过 `CountQuoteItemByConditions` 等 SQL 计数判断的逻辑，Rule 内应改成基于 `QuoteContext.QuoteItems` 的本地过滤（如 `IsPublicStandardItem()`），避免重复查表。前提是 `QuoteItems` loader 的过滤条件覆盖原 SQL 的 `status` / `item_scene` 等约束。参考 `CommonApplyRule` 中的 `canApplyByContext`。
11. **校验类 RPC 允许在 Rule 内直接调用**：与"数据查询型"调用（如查商品/合同/价格）不同，**纯校验类 RPC**（仅消费已有数据，向外部接口请求"这份配置是否合法"）可以直接在 Rule 内调用，不必再绕一层 loader。原则：
    - 数据加载（取代金券/信控/商品/价格…）→ loader
    - 校验类 RPC（外部接口判定参数合法性）→ 可直接在 Rule 内调用
    - 即便 RPC 内部包含开关/拦截逻辑，也优先在 Rule 里展开（开关也是校验语义的一部分），避免在 QuoteContext 上挂"预跑结果"这类语义模糊字段。
    参考 `CouponParamRule`：复用 `Persisted.CouponList` loader 拿数据，开关 + `couponconfigservice.ValidateCoupon` RPC 都在 Rule 内执行。

## 9. 迁移单条 Checker 的标准流程

1. **通读源 Checker**：阅读 `XxxChecker.Check(ctx, tx, quoteBizData *assistant.CallbackInfo)`，列出真正读取的字段
   - **关键陷阱**：弄清 `quoteBizData.AllQuoteItems` / `AllItemValues` 等聚合字段的真实语义（例如 `AllQuoteItems` 仅含报价项，**不**含交付项）
2. **字段映射到 QuoteContext**：把读取的字段映射到 `QuoteContext.Persisted.* / External.*`，缺失 loader 时在 `quote_context` 新增并在 `const.go` 的 `loaderMap` 注册
3. **新建 Rule 文件**：`check_engine/biz_data_rule_xxx.go`（Access 类用 `op_access_rule_xxx.go`），实现 `QuoteBizRule` 接口（`Key / Desc / Needs / Check / BlockLevel`）
   - **`Desc()` 必须完整列出业务规则**：基于 `Check` 的全部分支生成多条业务描述，便于 `GetOpRuleDesc` 给端上展示
   - **`Needs()` 显式声明**：OpChecker 会去重并 `WithKeys(...).Load(ctx)`，遗漏会触发空指针
4. **`Check` 实现规范（CheckResult 必须字段完备）**：
   - **禁止返回 nil**；通过/失败统一返回完整 `CheckResult`
   - 入口必填：`Pass=true / BlockLevel=r.BlockLevel() / RuleKey=r.Key() / RuleDesc=r.Desc()`
   - 失败分支：在已构造的 result 上补 `Pass=false / ErrorCode / ErrorMsg`（必要时 `Detail`）
   - 系统错误才返回 `(nil, error)`；业务校验失败一律走 `CheckResult`
   - 模板：
     ```go
     result := &CheckResult{
         Pass:       true,
         BlockLevel: r.BlockLevel(),
         RuleKey:    r.Key(),
         RuleDesc:   r.Desc(),
     }
     // ... 业务判断 ...
     if /* 失败条件 */ {
         result.Pass = false
         result.ErrorCode = errors.CodeNXxx
         result.ErrorMsg = "..."
     }
     return result, nil
     ```
5. **CheckKey 归属（实体域聚合）**：
   - 报价单基础信息 → `checkQuoteBaseInfo`
   - 报价项相关原子规则（0元/计费项/售卖模式/有效性…） → `checkQuoteItem`
   - 商务优惠（保底/返佣/分销…） → `checkBusinessDiscount`（按需新增）
   - **不要为单个 Rule 独立建 CheckKey**
6. **下游有 DB/RPC 时不要用 tx 旁路（强约束，参见 §8.8）**：
   - Rule 内**禁止**直接持有/取用 `*gorm.DB` 或调用任何会触发 DB/RPC 的下游函数
   - 缺数据 → 在 `quote_context` 加 loader 并在 `Needs()` 声明
   - 下游函数若隐式查询，**新增一个无 tx 的纯计算重载**，并优先以 `map[itemID]*XxxBizCtx` 形式按 itemContext 维度传参（itemContext + 该项对应的商品信息/配置树/价格信息），不要外露 `productInfoMap` / `configTreeMap` 这类全局散表
7. **注册到 RuleRegistry**：在 `check_engine.go` 的 `quoteBizRuleRegistry` 链式调用里 `RegisterCheckKey(xxx).WithRules(&XxxRule{})`；如该 CheckKey 还没绑定到 OpType，需在 `RegisterOpType(...).WithCheckKeys(...)` 中追加
8. **业务层不需改动**：业务层（`op_check_dispatch.go`）已统一基于 `Pass + BlockLevel` 判定：
   - `firstBlockingResult` 仅识别 `Pass=false && BlockLevel=Error` 阻断主链路
   - `adaptEngineResultsToBizCheckResults` 跳过 `Pass=true` 和 `BlockLevel=Info`
   - `FailFast` 仅在 `BlockLevel=Error` 时短路
9. **编译验证**：`go build ./...` 通过 → 更新 TaskList → **更新本 md 文件（任务表 + 已知坑 + 文件清单）**
10. **单测**：保留原 checker 单测不动；新建 rule 单测覆盖 `Pass=true / 各失败分支 / nil quoteCtx` 等核心场景（暂可后置）

## 10. 接力 checklist（重新开 session 时）

- [ ] `git status` 看是否有未提交改动；分支应为 `dev/check_upgrade`
- [ ] 阅读本 md，找到第一个 `pending` 任务
- [ ] 阅读 `biz/service/check_engine/` 全部文件，确认 `quoteBizRuleRegistry` 当前注册情况
- [ ] 阅读 `biz/service/quote_service/biz_data_checker_api_config.go` 了解尚未迁移的老 checker
- [ ] 按 §9 流程推进
- [ ] **每完成一步必须同步更新本 md 的"任务列表"和"已知坑"**

# 报价校验引擎升级测试 Case 设计

> 基于当前分支 `dev/check_upgrade` 与 `master` 的 diff 梳理。覆盖范围：新增 `check_engine`、`quote_context`、`quote_service_by_engine`、灰度入口、刷新副作用，以及 `GetRelatedChargeItemsByLoaded` 预加载上下文链路。
>
> 目标：用于本期需求测试执行与补充自动化/集成测试，重点验证“新引擎与老链路可灰度回退、校验语义等价、副作用刷新符合预期、异常不误放行”。

## 1. 变更范围总览

| 模块 | 变更点 | 关键代码 |
|---|---|---|
| 校验入口 | 初版 `UseNewQuoteCheckEngine` 灰度已下线，`quote_service_by_engine` 固定使用校验引擎；V2 演进使用独立的 `UseQuoteEngineV2*` 开关 | `biz/service/quote_service_by_engine/biz_data_check.go`、`biz/service/quote_service_by_engine/submit_quote.go` |
| 新校验引擎 | 新增 RuleRegistry、OpChecker、CheckResult、FailFast、SkipBlockRules | `biz/service/check_engine/check_engine.go:14`、`biz/service/check_engine/check_engine.go:95`、`biz/service/check_engine/check_engine.go:170`、`biz/service/check_engine/check_engine.go:224` |
| QuoteContext | 新增 `Persisted / External / Inputs` 三层数据载体，支持依赖递归加载、reload、输入注入 | `biz/service/quote_context/quote_context.go:22`、`biz/service/quote_context/quote_context_loader.go:26`、`biz/service/quote_context/quote_context_loader.go:68`、`biz/service/quote_context/quote_context_loader.go:108` |
| by_engine 新链路 | 新增 `QuoteBizDataCheck` / `SubmitQuote` 新实现，统一执行 AccessCheck、前置刷新、BizDataCheck、后置刷新 | `biz/service/quote_service_by_engine/biz_data_check.go:13`、`biz/service/quote_service_by_engine/submit_quote.go:36`、`biz/service/quote_service_by_engine/op_check_dispatch.go:135` |
| 数据刷新 | 新增提交前/后刷新器，剥离原 checker 中的写副作用 | `biz/service/quote_service_by_engine/biz_data_refresher_config.go:3`、`biz/service/quote_service_by_engine/biz_data_refresher_config.go:12`、`biz/service/quote_service_by_engine/biz_data_refresher.go:25` |
| 关联计费项 | 新增基于已加载上下文的关联计费项计算入口，避免 Rule 内重复 DB/RPC 加载 | `biz/service/quote_item_service/get_related_charge_items.go:143`、`biz/service/quote_item_service/get_related_charge_items.go:152` |

## 2. 测试分层建议

1. **单元测试**：Rule、Loader、Result adapter、刷新器分支逻辑。
2. **集成测试**：新旧链路灰度切换、`QuoteBizDataCheck`、`SubmitQuoteV2` 全流程。
3. **回归对账测试**：同一批报价单样本分别跑老链路与新链路，比对阻断结果、错误码、错误文案和关键副作用。
4. **容错测试**：DB/RPC/config/tcc 异常、空数据、nil 数据、非法 JSON、边界日期/金额/数量。

---

## 3. 灰度与入口链路测试

### 3.1 `QuoteBizDataCheck` 引擎链路

| Case ID | 场景 | 输入/Mock | 预期 |
|---|---|---|---|
| BDC-001 | QuoteID 不存在 | `FindQuoteByID` 返回 nil / error | 返回错误，不进入引擎 |
| BDC-002 | Access 阻断 | `QuoteCanOperateRule` 返回 Error 失败 | 返回业务错误，不执行前置刷新和业务校验 |
| BDC-003 | 前置基础信息刷新失败 | `QuoteBaseInfoRefresher` 返回 `CodeNQuoteBaseInfoCheckFailed` | 响应 `CheckPass=false`，不直接抛接口 error |
| BDC-004 | 多条业务规则失败 | `BizFailFast=false` | 收集全部失败规则，`CheckPass=false` |
| BDC-005 | Warn 级结果 | Rule 返回 `Pass=false, BlockLevel=Warn` | 响应包含 warn 结果，但 `CheckPass=true` |
| BDC-006 | Info 级结果 | Rule 返回 `Pass=false, BlockLevel=Info` | 不透出端上，不影响 `CheckPass` |
| BDC-007 | `SwitchQuoteBizDataCheckerPassIgnore` 命中 | skip map 命中失败 RuleKey | 对应结果转 `Pass=true` / `Warn`，不阻断 |
| BDC-008 | 新链路检查接口副作用 | 命中新引擎，数据需要刷新 | 校验接口会执行 pre/post refresh，验证 quote 派生字段、返佣、资源卡、代金券触发条件、综合折扣写库 |
| BDC-009 | 后置刷新失败 | 业务校验通过，`ProcessSubmitQuoteBizDataRefresh` 返回 error | 接口返回 error；不得误报 `CheckPass=true` |

### 3.2 `SubmitQuote` 引擎链路

| Case ID | 场景 | 输入/Mock | 预期 |
|---|---|---|---|
| SUB-001 | 分布式锁失败 | 同 quoteID 重复提交 | 返回 `CodeNCanNotResubmitQuote` |
| SUB-002 | quote 查询失败 | DAO 返回 error | 返回错误，事务回滚 |
| SUB-003 | Access 阻断 | 报价单状态不可操作 | 返回 `CodeNCanNotSubmitQuote`，不执行刷新/提交 |
| SUB-004 | BizData Error 阻断 | 任一 Error 级业务规则失败 | `BizFailFast=true`，命中第一条阻断后返回 `CodeNCanNotSubmitQuote` |
| SUB-005 | BizData Warn 不阻断 | 仅 Warn 级失败 | 继续进入后置刷新和提交状态机 |
| SUB-006 | 后置刷新失败 | 业务校验通过，刷新综合折扣失败 | 返回错误，事务回滚，不推进状态 |
| SUB-007 | 审批中修改分支 | quote `IsInModifyProcess=true` | 更新修改信息、通知超管、写日志、异步 CRM 回调；不走普通提交审批 |
| SUB-008 | 普通异步提交 | `Sync=false` | 更新 creator/salesAccount，执行 `ActionAsyncSubmit`，不提交飞书审批 |
| SUB-009 | 普通同步提交 | `Sync=true` | 执行 `ActionAsyncSubmit`、提交飞书审批、再执行 `ActionSubmitForApproval` |
| SUB-010 | 新老链路字段时序回归 | 老链路状态流转后 `refreshQuoteBaseInfo`，新链路校验前 `QuoteBaseInfoRefresher` | 审批表单读取的客户行业、渠道、父账号、合同配价账号等字段与老链路一致 |

---

## 4. `check_engine` 引擎框架测试

### 4.1 Rule 注册关系

| Case ID | 场景 | 预期 |
|---|---|---|
| ENG-REG-001 | `SubmitQuote` 展开所有 CheckKey | 包含 `checkQuoteBaseInfo/checkQuoteItem/checkGuaranteeItem/checkRebate/checkBizDiscount/checkCoupon/checkCredit` |
| ENG-REG-002 | `SubmitQuote` access rule | 包含 `QuoteCanOperateRule` |
| ENG-REG-003 | 未注册 OpType | 返回 `opType not registered` |
| ENG-REG-004 | OpType 绑定未注册 CheckKey | 返回 `checkKey ruleSet not registered` |
| ENG-REG-005 | 同一 CheckKey 多 Rule 顺序 | 返回顺序与注册顺序一致 |

### 4.2 OpChecker 执行

| Case ID | 场景 | 输入/Mock | 预期 |
|---|---|---|---|
| ENG-RUN-001 | QuoteCtx 为空 | `OpChecker.QuoteCtx=nil` | 返回 `quote context is nil` |
| ENG-RUN-002 | Needs 去重加载 | 多个 Rule 依赖同一个 key | loader 只加载一次 |
| ENG-RUN-003 | loader error | `QuoteContextLoader.Load` 返回 error | 中断并返回 error，不执行 Rule |
| ENG-RUN-004 | Rule 返回 error | `Check` 返回 `(nil, err)` | 中断并返回 error |
| ENG-RUN-005 | Rule 返回 nil result | `Check` 返回 `(nil, nil)` | 引擎兜底生成失败结果，RuleKey/Desc/BlockLevel 完整 |
| ENG-RUN-006 | Rule result 缺元信息 | `RuleKey/RuleDesc/BlockLevel` 为空 | 引擎自动回填 |
| ENG-RUN-007 | FailFast 生效 | 第一条 Error 失败，后面还有规则 | 后续规则不执行 |
| ENG-RUN-008 | FailFast 不影响 Warn | 第一条 Warn 失败 | 继续执行后续规则 |
| ENG-RUN-009 | `WithSkipBlockRules` 命中 | skip map 命中失败 RuleKey | 结果转 `Pass=true`、`BlockLevel=Warn` |
| ENG-RUN-010 | 空 rules | 传空 rule 列表 | 返回空结果，无 error |

---

## 5. `quote_context` 与 Loader 测试

### 5.1 Loader 框架

| Case ID | 场景 | 关键代码 | 预期 |
|---|---|---|---|
| CTX-FW-001 | 默认加载 Quote | `quote_context_loader.go:26` | 不传 `WithKeys` 时默认包含 `QuoteContextKeyQuote` |
| CTX-FW-002 | 依赖递归加载 | `quote_context_loader.go:136` | 请求子 key 时先加载 dependKeys |
| CTX-FW-003 | 已加载短路 | `quote_context_loader.go:121` | 同一 key 重复请求不重复执行 loader |
| CTX-FW-004 | reload 强制刷新 | `quote_context_loader.go:55` | `WithReloadKeys` 会重新加载已加载 key |
| CTX-FW-005 | 循环依赖保护 | `quote_context_loader.go:117` | 返回循环依赖错误，不死循环 |
| CTX-FW-006 | tx 为空自动建 request | `quote_context_loader.go:113` | 使用 `dal.DBProxy.NewRequest(ctx)` |
| CTX-FW-007 | input opts 在加载后执行 | `quote_context_loader.go:101` | loader 完成后再注入 Inputs |

### 5.2 Inputs 与 Callback converter

| Case ID | 场景 | 预期 |
|---|---|---|
| CTX-IN-001 | 注入 CouponList | `Inputs.CouponList` 为空时写入入参 |
| CTX-IN-002 | 注入 CreditList | `Inputs.CreditList` 为空时写入入参 |
| CTX-IN-003 | 不覆盖已有 CouponList | 已存在时保持原值 |
| CTX-IN-004 | 不覆盖已有 CreditList | 已存在时保持原值 |
| CTX-CVT-001 | converter 为 nil / quoteCtx nil | 返回非 nil 空 `assistant.CallbackInfo` |
| CTX-CVT-002 | Persisted 字段映射 | Quote、OriginQuote、QuoteItems、DeliveryItems、ItemValues、Coupon/Credit/Rebate/Guarantee/Resource 等字段正确映射 |
| CTX-CVT-003 | ProductInfoMap 映射 | `External.ProductInfoMap` 映射到 `CallbackInfo.ProductInfos` |
| CTX-CVT-004 | 未加载字段保持零值 | 不 panic，不产生脏数据 |

### 5.3 Loader 明细场景

| Loader 组 | Case ID | 覆盖点 |
|---|---|---|
| DB 基础类：QuoteSolutions/QuoteItems/DeliveryItems/ItemValues/ItemCalMap/Rebate/Apply 等 | CTX-DB-001 ~ CTX-DB-005 | quoteID=0 报错；DAO 成功写入；DAO 空数据；DAO error；nil item 容忍 |
| 可空对象类：OriginQuote/GuaranteeItem/ResourcePage/QuoteContract/ConfigList 等 | CTX-OBJ-001 ~ CTX-OBJ-005 | Quote nil 短路；ID=0 短路；Id<=0 不写入；异常 DB error 返回；非异常空结果不报错 |
| 商品/配置/价格类：ProductInfo/ConfigTree/ConfigInfo/PriceInfo/BizLine | CTX-PROD-001 ~ CTX-PROD-008 | item 去重；空 item 输出空 map；QuoteItemsAllStatus 优先；只处理 public item；只处理 exact charge item；RPC error；nil item；重复 key |
| ItemContext/成本/组合规则/父报价 | CTX-ITEM-001 ~ CTX-ITEM-010 | 正常报价项+交付项建 context；失效项不进入；非配置清单/非项目制成本短路；交付项 context 缺失；组合规则按 solution 汇总；父报价短路/成功/error |
| 商机/PRM/伙伴/账号 | CTX-EXT-001 ~ CTX-EXT-012 | OpportunityID 空短路；商机 RPC 成功/error；JointPrintInfo nil 短路；分销 CustomerDetail 空短路；BytePlus/内部/PRM 短路；伙伴授权聚合；CustomerDetail 逗号/空格/空 token |
| 资源单 | CTX-RES-001 ~ CTX-RES-006 | BytePlus 短路；不支持资源单短路；实时匹配资源卡成功；DB 资源卡成功；ResourcePage Id<=0；DAO/RPC error |

---

## 6. `checkQuoteBaseInfo` 基础信息规则测试

注册位置：`biz/service/check_engine/check_engine.go:14`。

| Rule | Case ID | 必测场景 |
|---|---|---|
| `MaxItemNumRule` | BASE-MAX-001 ~ 004 | 总报价项+交付项小于/等于/大于最大值；只统计 `QuoteItemsAllStatus`；quoteCtx nil |
| `CombineRuleRule` | BASE-COMB-001 ~ 005 | 无 solution 通过；单 solution 通过/失败；多 solution 分别校验；CombineRules 缺失；`CheckRelatedProduct` error |
| `ProjectSupplyRule` | BASE-PS-001 ~ 008 | 非补充项目制跳过；续约+增购开始时间边界；仅增购开始时间边界；默认生成项跳过增购行为校验；数量/周期增加；无增购失败；父合同/context 缺失 |
| `ResourcePageRule` | BASE-RES-001 ~ 007 | BytePlus 跳过；不支持资源单跳过；强制填写但无资源单失败；DB 缺实时资源卡失败；子资源卡匹配；ResourcePage.Id=0；Quote nil |
| `QuoteBaseInfoBasicRule` | BASE-BASIC-001 ~ 009 | 无报价项；存在草稿；SP 不支持；项目制缺手工交付项；未立项产品线必填；disable 开关；新项目制开关关闭；GlobalConf/QuoteApp nil |
| `DistributorInfoRule` | BASE-DIST-001 ~ 006 | 非分销跳过；Final/First/Second 一致；外部信息缺失；三段任一不一致；Second 一边 nil；非法 JSON |
| 字段类 Rule：DistributionBizType/ProjectAttributes/QuoteNotes/GiveAwayInfo/EffectiveInfo/ChangeInfo/EstimatedTradingMonthlyIncome/PublicCloudEstimate | BASE-FIELD-001 ~ 024 | 必填/非法枚举/长度 1000 边界/金额 0、负数、大于销售预估/配置清单分支/Quote nil |
| helper 派生类：LongLifeReason/EstimatedTradingTime/MdInfo/ProgressiveInfo/QuoteEstimateBySales/ProjectQuoteData | BASE-HELP-001 ~ 020 | 超 5 年原因；日期在合同区间内外；BytePlus CRM MdInfo；阶梯信息 JSON；涉及商品时销售预估必填；项目制 SOW/ProjectCode/ProjectName |
| 商机/伙伴授权类：Backdating/SolutionInfo/TradeProductType/PartnerName/CustomerName/TradeType/PriceValidPeriod/RelatedAccountIDs/PartnerContractNo/CustomerDetail/QuoteType/OrderType | BASE-OPP-001 ~ 040 | 倒签合同/原因/合同号；产解账号 Lark；非项目制含非标；伙伴/客户名与商机一致性；客户类型/伙伴授权；有效期固定/自签订/2038/授权覆盖；关联账号矩阵；伙伴合同号；CustomerDetail 账号数量/实名/来源/BP特殊/公私有云限制；报价类型/订单类型合法性 |

重点边界：

- 长度边界：原因/变更说明等 `len == 1000` 应通过，`>1000` 失败。
- 日期边界：开始日等于结束日、等于父合同开始/结束、结束时间超过 2038。
- JSON 边界：`PriceValidPeriod`、`ProgressiveInfo`、`DistributorInfos`、`QuoteRelatedProduct` 非法 JSON。
- 空白字符串：仅空字符串失败还是空白也失败，需要对齐老链路语义。

---

## 7. `checkQuoteItem` 报价项规则测试

注册位置：`biz/service/check_engine/check_engine.go:52`。

| Rule | Case ID | 必测场景 |
|---|---|---|
| `ZeroQuoteRule` | ITEM-ZERO-001 ~ 008 | 无 0 元通过；0 元但同税率/部署方式有非 0 项；赠送场景/原因缺失；非纸质合同；商品信息缺失 error；配置清单赠送类型跳过；多分组错误拼接 |
| `ItemSellingModeValidRule` | ITEM-SM-001 ~ 005 | 无报价项；非公有云跳过；公有云售卖模式合法/非法；ItemContext 缺失；`IsValidSellingMode` error |
| `ItemEffectiveRule` | ITEM-EFF-001 ~ 007 | 报价项/交付项有效；商品/配置/计费项/折扣线/报价方式失效；无 item；itemValues copy 不污染原 map；构造 context error |
| `RatioChargeItemRule` | ITEM-RATIO-001 ~ 005 | 无比例计费项；方案内有关联计费项；方案内无关联计费项；ItemContext 缺失；PriceInfo 为空 |
| `ItemDiscountRule` | ITEM-DISC-001 ~ 010 | 折扣合法；自动生成/交付项跳过；折扣 nil；项目制 UnitPrice=0 且未指派；阶梯折扣失败；SP/抵扣 0 元；SP 非 10 折且有关联抵扣；白名单小于 10 折；ProgressiveInfo JSON error |
| `RelatedChargeItemRule` | ITEM-REL-001 ~ 005 | 开关关闭跳过；无关联返回通过；有关联返回失败；ItemContext 缺失；`GetRelatedChargeItemsByLoaded` error |
| `UnStandardDeliveryItemCostRule` | ITEM-COST-001 ~ 007 | 非配置清单跳过；开关关闭跳过；非手动非标跳过；缺算价；unitCost/factoryPrice nil；非固定金额；金额不一致 |
| `EstimatedIncomeRule` | ITEM-INCOME-001 ~ 009 | 非报价单跳过；预计用量流程金额必填；总销售额 0；公有云预计金额 <=0；公有云合计等于 PublicCloudEstimate；非项目制 TotalSales 等于销售预估；SP 包金额 >= 抵扣和 |
| `ProductCustomerScopeRule` | ITEM-SCOPE-001 ~ 004 | 商品客户范围匹配；不匹配聚合 itemIDs；ProductInfo 缺失跳过；同商品多报价项 |
| `RelatedProductRule` | ITEM-PROD-001 ~ 005 | 报价项类型在声明范围；报价项类型超范围；声明类型缺报价项；交付项跳过；无报价项通过 |
| `DistributionDiscountsRule` | ITEM-BP-001 ~ 005 | 非 BP 特殊跳过；BP 特殊合法；报价项失败；交付项失败；ItemContext 缺失 |
| `ConfigListRule` | ITEM-CFG-001 ~ 006 | 非配置清单/非项目制跳过；无成本数据跳过；同 key 一条阶梯通过；多条阶梯成本价失败；多条阶梯出厂价失败；文案只取前两个 itemID |
| `DeductDiscountRule` | ITEM-DEDUCT-001 ~ 008 | 无抵扣项；抵扣折扣低于参考值；抵扣折扣 >= SP 官网系数；>= 本单按量折扣；>= 合同价最低折扣；关联 SP 包缺失；合同价 RPC error；固定价折扣价格信息缺失 |

---

## 8. 商务优惠、代金券、信控、保底、返佣规则测试

### 8.1 保底 `checkGuaranteeItem`

| Rule | Case ID | 必测场景 |
|---|---|---|
| `GuaranteeRule` | GUA-001 ~ 009 | 无保底；不支持保底；部分保底未绑定；周期保底开始早于合同；结束晚于合同；抵扣项参与保底；采购总席位数非法；月份等于边界；`SupportGuarantee` error |
| `GuaranteePercentageRule` | GUA-PCT-001 ~ 009 | 配置清单跳过；无 itemContext 跳过；多账号保底比例一致；部分有部分无；比例不一致；不支持却填写；支持但未填写；值不在区间；`ValidateCalculationFactor` error |

### 8.2 返佣 `checkRebate`

| Rule | Case ID | 必测场景 |
|---|---|---|
| `RebateRule` | REB-001 ~ 006 | 无返佣；不支持返佣但存在脏返佣项按原语义通过；关联项不存在；关联项非公有云；关联项为抵扣；`SupportRebate` error |
| `RelatedBusinessDiscountRule` | REB-REL-001 ~ 008 | 开关关闭；白名单空；无关联命中；关联项一边有返佣一边无；部分保底不一致；Detail map 正确；PRM 范围 none/all/part；PRM RPC error |
| `JointPrintOrderRule` | REB-JP-001 ~ 014 | 不支持且未填；支持但未填；不支持却填写；JSON 解析失败；OpportunitySrcKey/CustomerOwnerRole 缺失；Support=true 必填项缺失；Collaborator Lark 失败/不存在；商机 JointPrintInfo 不一致；PRM 政策不一致；SpecialRebatePolicy nil 跳过；Opportunity nil；`SupportRebate` error |

### 8.3 商务优惠 `checkBizDiscount`

| Rule | Case ID | 必测场景 |
|---|---|---|
| `FullQuoteModifyDiscountRule` | DISCOUNT-001 ~ 006 | 非审批修改跳过；优惠范围一致；保底/代金券/返佣/信控/赠送任一增减失败；snapshot 空；`GetModifyContext` error；长度相同但内容不同的潜在误判需用测试暴露 |

### 8.4 代金券 `checkCoupon`

| Rule | Case ID | 必测场景 |
|---|---|---|
| `CouponApplyRule` | COUPON-APPLY-001 ~ 004 | 无 coupon apply；有申请且支持；有申请不支持；`SupportCoupon` error / Quote nil |
| `CouponParamRule` | COUPON-PARAM-001 ~ 006 | BatchValidateSwitch=false；CouponList 空；ValidateCoupon 成功；ValidateCoupon 失败但 Intercept=false；ValidateCoupon 失败且 Intercept=true；nil coupon 元素 |
| `FullQuoteCouponFollowContractRule` | COUPON-FOLLOW-001 ~ 004 | 固定日期跳过；自签订+跟随合同通过；自签订+指定月份失败；RuleValidityInfo nil |
| `FullQuoteCouponValidityRangeRule` | COUPON-RANGE-001 ~ 005 | 非指定月份跳过；指定月份在合同内；开始早于合同；结束晚于合同；等于合同开始/结束边界 |
| `FullQuoteCouponTriggerItemRule` | COUPON-TRIGGER-001 ~ 012 | 非按金额跳过；未指定消费商品失败；QuoteItemID 不存在；商品不在消费商品内；抵扣项关联代金券失败；消费商品无报价项；统计报价项/商品非法；计算商品不在统计范围；QuoteItemIDList 空时内存补齐；按金额比例路径 |

### 8.5 信控 `checkCredit`

| Rule | Case ID | 必测场景 |
|---|---|---|
| `CreditApplyRule` | CREDIT-001 ~ 006 | 无 credit apply；有申请且支持且有公有云标品；有申请不支持；无公有云标品；交付项不计入；`SupportCredit` error / Quote nil |

---

## 9. by_engine 刷新器测试

### 9.1 前置刷新器

| Refresher | Case ID | 必测场景 |
|---|---|---|
| `QuoteBaseInfoRefresher` | PRE-QBI-001 ~ 009 | OppInfo 加载成功；内部报价跳过；`SwitchSyncSubmitRefreshOppInfo` 开/关；海外环境跳过行业/合同账号；国内销售渠道部门关键字；BPDistributor 父账号；字段写回成功；派生失败转 `CodeNQuoteBaseInfoCheckFailed` |
| `CleanRebateItemsIfNotSupportRefresher` | PRE-REB-CLEAN-001 ~ 005 | 不支持且有返佣软删；不支持但无返佣；支持返佣不删；查询失败仅日志继续；软删失败返回 error |
| `SyncJointOrderRebatesIfSupportRefresher` | PRE-REB-SYNC-001 ~ 006 | 不支持返佣跳过；支持且 PRM 有数据保存；无报价项；PRM error；BuildSaveRebates error；Save error |
| `CleanExpiredResourceItemsIfSupportRefresher` | PRE-RES-CLEAN-001 ~ 008 | 海外跳过；不支持资源单跳过；无资源单；无过期资源卡；部分过期软删；全部过期软删 resource page；实时/DB 获取失败日志；软删失败 error |
| `FullQuoteCouponTriggerInfoRefresher` | PRE-COUPON-001 ~ 007 | 无代金券；非按金额跳过；旧触发条件自动补齐 QuoteItemIDList；补齐统计商品/报价项；单个 coupon 解析失败日志跳过；无变更不保存；BatchSave 失败 error |

### 9.2 后置刷新器

| Refresher | Case ID | 必测场景 |
|---|---|---|
| `ProcessSubmitQuoteBizDataRefresh` | POST-FLOW-001 ~ 004 | 第一轮 reload keys 正确；beforeTotalDiscount 顺序正确；第二轮 reload keys 正确；综合折扣刷新最后执行 |
| `HeirItemDiscountRefresher` | POST-HEIR-001 ~ 007 | 非项目制补充协议跳过；加载父报价算价；继承报价项价格变化生成固定价折扣；同步自动交付项折扣；父项缺失；Save error |
| `ProductInfoRefresher` | POST-PROD-001 ~ 002 | 调用成功；下游 error 透出 |
| `CalFactorDataRefresher` | POST-CAL-001 ~ 002 | 调用成功；下游 error 透出 |
| `SelectAllExcludeRefresher` | POST-EXCLUDE-001 ~ 003 | 不支持跳过；支持时刷新；刷新 error |
| `RelatedResDepRefresher` | POST-RESDEP-001 ~ 005 | 新项目制开关关闭跳过；白名单命中生成资源方；未命中为空；quote 字段写回；update error |
| `QuoteItemInquiryRefresher` | POST-INQ-001 ~ 002 | 调用成功；下游 error 透出 |
| `QuoteItemTotalDiscountRefresher` | POST-TD-001 ~ 003 | `Write=true`；成功写综合折扣；计算 error 透出 |

---

## 10. `GetRelatedChargeItemsByLoaded` 测试

新增入口见 `biz/service/quote_item_service/get_related_charge_items.go:152`。

| Case ID | 场景 | 预期 |
|---|---|---|
| REL-LOAD-001 | 原 `GetRelatedChargeItems` 行为不变 | 缺上下文时仍自行加载 DB/RPC，结果与 master 兼容 |
| REL-LOAD-002 | `GetRelatedChargeItemsByLoaded` 不额外加载 | 已传入 quote、quoteItems、bizCtxMap，Mock DB/RPC 不应被调用 |
| REL-LOAD-003 | bizCtxMap 缺 ItemCtx | 跳过对应项，不 panic |
| REL-LOAD-004 | 缺 ProductInfo / ConfigTree | 不 panic；无法匹配时返回空 |
| REL-LOAD-005 | 重复 key 已存在 | 不返回重复关联计费项 |
| REL-LOAD-006 | exact charge item 路径 | `IsExactChargeItem=true` 时规则匹配正确 |
| REL-LOAD-007 | 非 exact / 所有选项路径 | `IsExactChargeItem=false` 时规则匹配正确 |
| REL-LOAD-008 | 多字段规则全匹配 | `SrcFormValues` 全匹配才生成 `DstFormValues` |
| REL-LOAD-009 | 规则读取失败 | 返回 error，不吞掉异常 |

---

## 11. 新老链路回归对账用例集

建议准备一批真实/构造报价单，分别在老链路和新链路执行 `QuoteBizDataCheck`、`SubmitQuoteV2`（可在回滚事务内），对账如下字段：

| 样本 | 覆盖目标 | 对账点 |
|---|---|---|
| 普通公有云直销报价 | 基础报价项、有效期、销售预估、CustomerDetail | ErrorCode/ErrorMsg、CheckPass、quote 派生字段 |
| 配置清单报价 | 配置清单特殊分支、代金券指定月份、资源单 | 校验结果、资源卡清理、代金券触发条件修复 |
| 项目制报价 | SOW/项目编码、手工交付项、成本/出厂价、资源方 | 校验结果、RelatedResDepartment、综合折扣 |
| 项目制补充协议 | 父合同时间、父报价项、继承折扣 | 校验结果、继承项折扣写回 |
| BP 分销特殊报价 | 分销业务类型、CustomerDetail、DistributorInfo、TradeProductType | 校验结果、账号/分销商一致性 |
| 生态伙伴报价 | PartnerGrant、PartnerContractNo、RelatedAccountIDs、PriceValidPeriod | 授权覆盖、合同号、账号矩阵 |
| 含保底/返佣报价 | Guarantee、Rebate、JointPrintOrder、RelatedBusinessDiscount | 校验结果、返佣软删/同步 |
| 含代金券/信控报价 | CouponApply/CouponParam/FullQuoteCoupon*、CreditApply | 校验结果、申请项支持性、触发项补齐 |
| 审批中修改报价 | FullQuoteModifyDiscount、SubmitQuote 修改分支 | 商务优惠范围差异、修改记录/CRM 回调 |
| BytePlus/海外报价 | 海外短路分支、资源单短路、MdInfo | 不执行国内专属刷新/校验 |

---

## 12. 风险专项测试

| 风险 | Case ID | 测试点 | 预期 |
|---|---|---|---|
| 校验接口新增写副作用 | RISK-SIDE-001 | `QuoteBizDataCheck` 命中新引擎后是否写 quote、返佣、资源卡、代金券、折扣 | 产品确认允许；测试环境需观察写库差异 |
| SkipBlockRules 误放行 | RISK-SKIP-001 | 白名单只作用于指定 RuleKey | 未命中规则仍阻断 |
| FailFast 结果减少 | RISK-FAST-001 | SubmitQuote 只返回首个 Error，BizDataCheck 返回全部 | 两入口行为差异符合设计 |
| 空指针 | RISK-NIL-001 | quoteCtx nil、Quote nil、External nil、Persisted nil collection | 不 panic；返回明确 error 或按规则短路 |
| 非法 JSON | RISK-JSON-001 | DistributorInfos、PriceValidPeriod、ProgressiveInfo、TriggerInfo 等 | 与老链路一致：应失败或日志跳过，不误通过关键校验 |
| 日期边界 | RISK-DATE-001 | 2038、合同起止月、父合同时间、倒签今日边界 | 边界行为与老链路一致 |
| 金额精度 | RISK-DEC-001 | 销售预估、公有云预估、综合折扣、抵扣折扣 | decimal 精度一致，无 float 误差 |
| 规则注册遗漏 | RISK-REG-001 | SubmitQuote 注册规则数和预期清单一致 | 新增规则不漏挂、不重复挂 |
| 潜在误判：优惠集合比较 | RISK-DISCOUNT-001 | 旧 `[coupon]`、新 `[rebate]` 长度相同内容不同 | 应暴露 `sameFullQuoteDiscounts` 长度相同直接 true 的风险，避免审批修改漏拦截 |

---

## 13. 执行优先级建议

### P0：必须覆盖

1. 灰度回退：`GATE-001 ~ GATE-008`。
2. 提交主链路阻断与事务：`SUB-001 ~ SUB-010`。
3. 整单检查新链路结果适配：`BDC-001 ~ BDC-009`。
4. 引擎框架：`ENG-RUN-001 ~ ENG-RUN-010`。
5. 所有 Error 级 Rule 至少覆盖 1 个成功 + 1 个失败。
6. 前置/后置刷新所有写库副作用成功与失败回滚。

### P1：高优先级

1. Loader 短路和 error 传播。
2. 生态伙伴、BP 分销、项目制补充协议、配置清单、代金券触发条件等复杂业务组合。
3. 新老链路回归对账样本。

### P2：补充覆盖

1. 文案拼接、Detail map、日志跳过分支。
2. nil 元素、空 slice/map、空白字符串、重复数据。
3. 性能/重复加载：Needs 去重、reload 后数据一致性。

---

## 14. 自动化落地建议

1. **Rule 单测命名**：`Test{RuleName}_BitsUT`，每个 Rule 用 `t.Run` 覆盖“通过/失败/边界/error”。
2. **Mock 策略**：外部 RPC、TCC、DAO、状态机、审批服务用 mockey/gomock；纯计算 helper 直接调用。
3. **回归对账**：构造 fixture quoteID 列表，执行校验引擎链路并输出阻断结果、错误码、错误文案和关键副作用差异表。
4. **副作用测试**：所有 refresher 在事务内执行，断言写库字段后回滚。
5. **覆盖率目标**：引擎框架和 adapter 逻辑 90%+；复杂 Rule 至少覆盖每个 `return fail` 分支；loader 至少覆盖成功、短路、error 三类。

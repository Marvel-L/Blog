# 报价校验架构升级一致性分析报告

> 分析对象：当前分支 `dev/check_upgrade` 相对 `master` 的校验链路升级改造。  
> 核心接口：`SubmitQuoteV2`、`QuoteBizDataCheck`。  
> 目标：逐步骤、逐字段对比新引擎链路与历史流程的业务处理一致性，并记录已修复的不一致点与测试覆盖。

## 1. 总体结论

当前修复后，新链路在以下关键业务语义上与历史流程保持一致：

1. `SubmitQuoteV2` 仍通过灰度开关控制是否进入新引擎；未命中开关时完整保留老链路，入口位于 `biz/service/quote_service/submit_quote_v2.go:50`。
2. `SubmitQuoteV2` 新链路保留老链路的分布式锁、事务、报价单查询、准入校验、业务数据刷新、全报价单业务校验、审批中修改、创建人/销售更新、状态机、同步送审等主流程，入口位于 `biz/service/quote_service_by_engine/submit_quote.go:38`。
3. `QuoteBizDataCheck` 仅在“全量校验”场景走新引擎；当请求显式传入 `CheckerKeys` 时继续走老链路，以保留历史“只执行指定 checker”的局部校验语义，修复点位于 `biz/service/quote_service/biz_data_check.go:36`。
4. 新引擎 `BizDataCheck` 使用独立 `OpType=BizDataCheck`，规则集合与历史 `allCheckerKeys` 对齐，并额外隔离“关联报价项商务优惠”规则，避免误进入 `SubmitQuote` 主链路，修复点位于 `biz/service/check_engine/check_engine.go:98` 和 `biz/service/check_engine/check_engine.go:109`。
5. 新引擎返回结果、白名单开关、阻断降级均兼容历史 checker key，不再直接暴露原子规则 key 破坏上层依赖，修复点位于 `biz/service/check_engine/check_engine.go:129`、`biz/service/check_engine/check_engine.go:191`、`biz/service/quote_service_by_engine/op_check_dispatch.go:96`。

## 2. SubmitQuoteV2 逐步骤一致性分析

### 2.1 入口与灰度切换

| 对比项 | 历史链路 | 新链路 | 一致性结论 |
| --- | --- | --- | --- |
| 请求结构 | `SubmitQuoteV2Req` 包含 `QuoteID`、`Sync`、`CustomerID`，定义于 `biz/service/quote_service/submit_quote_v2.go:43` | 新链路入口 `SubmitQuote` 直接接收 `insertReq`、`quoteID`、`sync`、`customerID`，见 `biz/service/quote_service_by_engine/submit_quote.go:38` | 字段承接一致 |
| 灰度入口 | `Handle` 中命中新引擎开关且注入 `EngineSubmitQuote` 时委托新链路，否则继续老链路，见 `biz/service/quote_service/submit_quote_v2.go:50` | `EngineSubmitQuote` 在 `quote_service_by_engine` 包中承接调用 | 一致；老链路可回退 |
| 锁语义 | 老链路使用 `submit_quote_lock_{QuoteID}`，超时 120s，见 `biz/service/quote_service/submit_quote_v2.go:56` | 新链路使用同名锁和相同超时时间，见 `biz/service/quote_service_by_engine/submit_quote.go:39` | 一致 |
| 锁失败错误 | 老链路返回 `CodeNCanNotResubmitQuote` 和“报价单已提交，请稍后重试”，见 `biz/service/quote_service/submit_quote_v2.go:62` | 新链路返回相同错误码和文案，见 `biz/service/quote_service_by_engine/submit_quote.go:44` | 一致 |
| 事务边界 | 老链路在 `dal.DBProxy.NewRequest(ctx).Transaction` 中执行 `submitQuoteV2`，见 `biz/service/quote_service/submit_quote_v2.go:72` | 新链路同样在事务中执行 `submitQuoteV2ByEngine`，见 `biz/service/quote_service_by_engine/submit_quote.go:54` | 一致 |

### 2.2 报价单查询与准入校验

| 对比项 | 历史链路 | 新链路 | 修复/结论 |
| --- | --- | --- | --- |
| 报价单查询 | 按 `QuoteID + CustomerID` 查询，见 `biz/service/quote_service/submit_quote_v2.go:186` | 按 `quoteID + customerID` 查询，见 `biz/service/quote_service_by_engine/submit_quote.go:62` | 一致 |
| 准入校验 | 老链路调用 `processcheck.AllowQuoteOP(OpTypeSubmitQuote)`，见 `biz/service/quote_service/submit_quote_v2.go:192` | 新链路通过 `processSubmitQuoteBizFlow` 先执行 access phase，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:147`；准入规则注册为 `QuoteCanOperateRule`，见 `biz/service/check_engine/check_engine.go:120` | 一致 |
| 准入失败错误包装 | 老链路包装为 `CodeNCanNotSubmitQuote`，见 `biz/service/quote_service/submit_quote_v2.go:192` | 新链路 access 阻断后包装为 `CodeNCanNotSubmitQuote`，见 `biz/service/quote_service_by_engine/submit_quote.go:84` | 一致 |

### 2.3 业务数据加载与预刷新

| 对比项 | 历史链路 | 新链路 | 修复/结论 |
| --- | --- | --- | --- |
| 加载数据范围 | 老链路通过 `assistant.CallbackWithQuote` 加载所有状态报价项、交付项、属性、算价、保底、补充协议、资源单/资源卡、关联合同、解决方案、配置清单、返佣、商品信息，见 `biz/service/quote_service/submit_quote_v2.go:196` | 新链路通过 `newSubmitQuoteBizDataRefreshContext` 构建 `QuoteContext`，并由规则 `Needs()` 和 loader 装配等价数据 | 一致 |
| 查询失败文案 | 老链路 `callbackErr != nil || quoteBizData == nil` 时返回“查询报价单信息失败”，见 `biz/service/quote_service/submit_quote_v2.go:215` | 新链路 context 构建失败返回错误，主流程中断，见 `biz/service/quote_service_by_engine/submit_quote.go:67` | 一致 |
| 提交前业务数据处理 | 老链路调用 `ProcessBizDataByBizScene(...QuoteBizSceneSubmitQuote)`，见 `biz/service/quote_service/submit_quote_v2.go:219` | 新链路拆为 `RefreshBizDataByQuoteContext(...submitQuotePreCheckRefreshers)`，由 `EnablePreRefresh=true` 控制，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:163` 和 `biz/service/quote_service_by_engine/submit_quote.go:78` | 已修复为一致：`SubmitQuote` 必须执行预刷新 |

### 2.4 全报价单业务校验

| 对比项 | 历史链路 | 新链路 | 修复/结论 |
| --- | --- | --- | --- |
| 业务校验入口 | 老链路调用 `processcheck.FullQuoteDataCheck(OpTypeSubmitQuote)`，见 `biz/service/quote_service/submit_quote_v2.go:224` | 新链路调用 `runOpCheckByEngineWithQuoteContext(...opCheckPhaseBizData)`，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:169` | 新引擎承接原 `FullQuoteDataCheck` 语义 |
| 快速失败 | 提交主链路遇阻断即返回错误，见 `biz/service/quote_service/submit_quote_v2.go:224` | 新链路 `BizFailFast=true`，见 `biz/service/quote_service_by_engine/submit_quote.go:76` | 一致 |
| 白名单降级 | 老链路依赖 `SwitchQuoteBizDataCheckerPassIgnore` 的历史 checker key | 新链路通过 `WithSkipBlockRules` 兼容新 `RuleKey` 与历史 checker key，见 `biz/service/check_engine/check_engine.go:198` 和 `biz/service/check_engine/check_engine.go:202` | 已修复为一致 |
| 阻断错误码 | 老链路使用 `CodeNCanNotSubmitQuote` 包装校验失败，见 `biz/service/quote_service/submit_quote_v2.go:225` | 新链路业务阻断同样返回 `CodeNCanNotSubmitQuote`，见 `biz/service/quote_service_by_engine/submit_quote.go:87` | 一致 |

### 2.5 后置刷新与报价单字段

| 字段/处理 | 历史链路 | 新链路 | 一致性结论 |
| --- | --- | --- | --- |
| `customer_industry_info` | 老链路 `refreshQuoteBaseInfo` 写库，见 `biz/service/quote_service/submit_quote_v2.go:301` | 新链路在 `ProcessSubmitQuoteBizDataRefresh` 中执行后置刷新，由 `EnablePostRefresh=true` 控制，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:185` 和 `biz/service/quote_service_by_engine/submit_quote.go:79` | 一致 |
| `price_entity_industry_info` | 老链路写库字段，见 `biz/service/quote_service/submit_quote_v2.go:302` | 新链路后置刷新承接 | 一致 |
| `sales_channel_type` | 老链路写库字段，见 `biz/service/quote_service/submit_quote_v2.go:303` | 新链路后置刷新承接 | 一致 |
| `parent_account_number` | 老链路写库字段，见 `biz/service/quote_service/submit_quote_v2.go:304` | 新链路后置刷新承接 | 一致 |
| `contract_price_acc` | 老链路写库字段，见 `biz/service/quote_service/submit_quote_v2.go:305` | 新链路后置刷新承接 | 一致 |
| 内存态字段同步 | 老链路同步 `quote.CustomerIndustryInfo`、`PriceEntityIndustryInfo`、`SalesChannelType`、`ParentAccountNumber`、`ContractPriceAcc`，见 `biz/service/quote_service/submit_quote_v2.go:310` | 新链路刷新后用 `flowResult.QuoteCtx` 回写最新上下文，见 `biz/service/quote_service_by_engine/submit_quote.go:90` | 一致 |

### 2.6 审批中修改分支

| 对比项 | 历史链路 | 新链路 | 一致性结论 |
| --- | --- | --- | --- |
| 判断条件 | `quote.IsInModifyProcess()`，见 `biz/service/quote_service/submit_quote_v2.go:238` | `quote.IsInModifyProcess()`，见 `biz/service/quote_service_by_engine/submit_quote.go:97` | 一致 |
| 更新修改信息 | `UpdateModifyInfoAfterSubmit`，见 `biz/service/quote_service/submit_quote_v2.go:241` | `quote_service.UpdateModifyInfoAfterSubmit`，见 `biz/service/quote_service_by_engine/submit_quote.go:100` | 一致 |
| 查询 OA 信息 | `oa_service.GetApprovalInfo`，见 `biz/service/quote_service/submit_quote_v2.go:245` | `oa_service.GetApprovalInfo`，见 `biz/service/quote_service_by_engine/submit_quote.go:104` | 一致 |
| 通知超管 | 老链路 `sendNotifyToPromoter`，见 `biz/service/quote_service/submit_quote_v2.go:247` | 新链路 `sendNotifyToPromoter`，见 `biz/service/quote_service_by_engine/submit_quote.go:105` | 一致 |
| 操作日志 | 老链路记录 `ActionModifySubmitQuote`，见 `biz/service/quote_service/submit_quote_v2.go:250` | 新链路记录 `ActionModifySubmitQuote`，见 `biz/service/quote_service_by_engine/submit_quote.go:107` | 一致 |
| CRM 回调 | 老链路异步 `QuoteStatusCallbackWithNotifyV2`，见 `biz/service/quote_service/submit_quote_v2.go:254` | 新链路异步 `QuoteStatusCallbackWithNotifyV2`，见 `biz/service/quote_service_by_engine/submit_quote.go:111` | 一致 |
| 响应 | 返回 `QuoteCommonResp{QuoteID}`，见 `biz/service/quote_service/submit_quote_v2.go:259` | 返回 `QuoteCommonResp{QuoteID}`，见 `biz/service/quote_service_by_engine/submit_quote.go:116` | 一致 |

### 2.7 正常送审分支

| 对比项 | 历史链路 | 新链路 | 一致性结论 |
| --- | --- | --- | --- |
| 获取创建人与销售 | 老链路 `GetCreator`、`GetSalesAccountIDByScene`，见 `biz/service/quote_service/submit_quote_v2.go:233` 和 `biz/service/quote_service/submit_quote_v2.go:264` | 新链路使用传入 `insertReq` 调用同源方法，见 `biz/service/quote_service_by_engine/submit_quote.go:92` 和 `biz/service/quote_service_by_engine/submit_quote.go:121` | 一致 |
| 更新报价单创建人与销售 | 老链路 `UpdateCreatorAccountID`，见 `biz/service/quote_service/submit_quote_v2.go:268` | 新链路同样调用 `UpdateCreatorAccountID`，见 `biz/service/quote_service_by_engine/submit_quote.go:125` | 一致 |
| 状态机：异步提交 | 老链路 `ActionAsyncSubmit`，见 `biz/service/quote_service/submit_quote_v2.go:274` | 新链路 `ActionAsyncSubmit`，见 `biz/service/quote_service_by_engine/submit_quote.go:131` | 一致 |
| 同步送审 | 老链路 `Sync=true` 时调用 `lark_approval_process.Submit`，见 `biz/service/quote_service/submit_quote_v2.go:283` | 新链路 `sync=true` 时调用同一方法，见 `biz/service/quote_service_by_engine/submit_quote.go:136` | 一致 |
| 状态机：提交审批 | 老链路同步送审成功后 `ActionSubmitForApproval`，见 `biz/service/quote_service/submit_quote_v2.go:289` | 新链路同样执行，见 `biz/service/quote_service_by_engine/submit_quote.go:142` | 一致 |
| 响应 | 返回 `QuoteCommonResp{QuoteID}`，见 `biz/service/quote_service/submit_quote_v2.go:294` | 返回 `QuoteCommonResp{QuoteID}`，见 `biz/service/quote_service_by_engine/submit_quote.go:147` | 一致 |

## 3. QuoteBizDataCheck 逐步骤一致性分析

### 3.1 入口与局部校验语义

| 对比项 | 历史链路 | 新链路 | 修复/结论 |
| --- | --- | --- | --- |
| 请求字段 | `QuoteID`、`CheckerKeys`，定义于 `biz/service/quote_service/biz_data_check.go:17` | 新引擎入口当前只接收 `quoteID`，见 `biz/service/quote_service_by_engine/biz_data_check.go:15` | 新引擎仅覆盖全量校验 |
| 局部校验 | 老链路若传入 `CheckerKeys`，只执行指定 checker，见 `biz/service/quote_service/biz_data_check.go:54` | 新链路不支持局部规则子集，因此入口增加 `len(r.CheckerKeys)==0` 限制，见 `biz/service/quote_service/biz_data_check.go:39` | 已修复：指定 checker 场景保持老链路 |
| 全量校验 | 老链路 `fillInCheckerKeys` 在空数组时填充 `allCheckerKeys`，见 `biz/service/quote_service/biz_data_check.go:113` | 新链路空 `CheckerKeys` 时进入 `EngineBizDataCheck`，使用 `QuoteBizOpTypeBizDataCheck` 规则集，见 `biz/service/quote_service_by_engine/biz_data_check.go:30` | 一致 |

### 3.2 数据收集与准入校验

| 对比项 | 历史链路 | 新链路 | 修复/结论 |
| --- | --- | --- | --- |
| 数据收集 | 老链路 `CollectBizData` 加载所有状态报价项、交付项、属性、算价、保底、补充协议、资源、合同、解决方案、配置清单、返佣、商品信息，见 `biz/service/quote_service/biz_data_check.go:86` | 新链路通过 `newSubmitQuoteBizDataRefreshContext` 构建上下文，见 `biz/service/quote_service_by_engine/biz_data_check.go:23` | 一致 |
| 查询失败 | 老链路返回“查询报价单信息失败”，见 `biz/service/quote_service/biz_data_check.go:106` | 新链路 `FindQuoteByID` 失败或为空时返回同文案，见 `biz/service/quote_service_by_engine/biz_data_check.go:18` | 一致 |
| 准入校验 | 老链路调用 `AllowQuoteOP(OpTypeSubmitQuote)`，见 `biz/service/quote_service/biz_data_check.go:51` | 新链路先执行 access phase，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:147`；`BizDataCheck` opType 绑定 `QuoteCanOperateRule`，见 `biz/service/check_engine/check_engine.go:123` | 一致 |
| 准入失败返回 | 老链路直接返回错误 | 新链路 access 阻断返回业务错误，见 `biz/service/quote_service_by_engine/biz_data_check.go:43` | 一致 |

### 3.3 预刷新、业务校验、后置刷新

| 对比项 | 历史链路 | 新链路修复前风险 | 当前修复 |
| --- | --- | --- | --- |
| 预刷新 | 老链路 `CheckBizData` 前已经完成 `CollectBizData`，并在 checker 内依赖历史数据处理顺序；全量校验与提交流程共享部分预处理 | 新链路曾缺少 `BizDataCheck` 预刷新，可能导致代金券触发报价项、返佣/优惠等派生数据使用旧值 | `BizDataCheck` 显式 `EnablePreRefresh=true`，见 `biz/service/quote_service_by_engine/biz_data_check.go:34` |
| 业务校验 | 老链路 `CheckBizData(c, r.CheckerKeys, tx, r.quoteBizData)`，见 `biz/service/quote_service/biz_data_check.go:55` | 新链路若复用 `SubmitQuote` opType，会遗漏/多跑部分历史全量校验规则 | 新增 `QuoteBizOpTypeBizDataCheck`，见 `biz/service/check_engine/const.go:6`；`BizDataCheck` 使用该 opType，见 `biz/service/quote_service_by_engine/biz_data_check.go:31` |
| 快速失败 | 老链路 `CheckBizData` 收集结果返回给端上 | 新链路如使用 failFast 会只返回首个失败 | `BizFailFast=false`，见 `biz/service/quote_service_by_engine/biz_data_check.go:32` |
| 后置刷新 | 老链路业务数据校验接口不执行提交后置刷新，不应改变报价单送审后字段 | 新链路若复用 `SubmitQuote` 流程会误执行提交后置刷新 | `BizDataCheck` 显式 `EnablePostRefresh=false`，见 `biz/service/quote_service_by_engine/biz_data_check.go:35` |

### 3.4 返回结果与白名单字段一致性

| 字段 | 历史链路 | 新链路修复前风险 | 当前修复 |
| --- | --- | --- | --- |
| `CheckPass` | 老链路只要存在非白名单失败结果则为 `false`，见 `biz/service/quote_service/biz_data_check.go:60` | 新链路如果直接按 RuleKey 查白名单，历史 checker key 配置失效 | `ShouldSkipBlockRule` 同时支持 RuleKey 与 legacy checker key，见 `biz/service/check_engine/check_engine.go:198`；`BizDataCheck` 二次判断使用该方法，见 `biz/service/quote_service_by_engine/biz_data_check.go:48` |
| `CheckResults[].CheckKey` | 老链路返回历史 checker key，如 `checkZeroQuote`、`checkCouponParam` | 新链路若返回 `BizDataRuleXxx` 会破坏端上展示/过滤/白名单 | `adaptEngineResultsToBizCheckResults` 使用 `LegacyCheckerKey` 转换，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:108` |
| `ErrorCode` | 老链路透传 checker 错误码 | 新链路原子规则错误码保持透传，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:110` | 一致 |
| `ErrorMsg` | 老链路透传 checker 错误文案 | 新链路原子规则错误文案保持透传，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:111` | 一致 |
| `Detail` | 老链路透传详情 | 新链路透传详情，见 `biz/service/quote_service_by_engine/op_check_dispatch.go:112` | 一致 |

## 4. 规则维度逐项一致性分析

### 4.1 OpType 与 CheckKey 绑定

| 维度 | SubmitQuote 新链路 | BizDataCheck 新链路 | 历史语义 |
| --- | --- | --- | --- |
| 基础信息 | `checkQuoteBaseInfo`，见 `biz/service/check_engine/check_engine.go:98` | `checkQuoteBaseInfo`，见 `biz/service/check_engine/check_engine.go:109` | 两者都需要 |
| 报价项 | `checkQuoteItem`，见 `biz/service/check_engine/check_engine.go:100` | `checkQuoteItem`，见 `biz/service/check_engine/check_engine.go:111` | 两者都需要 |
| 保底 | `checkGuaranteeItem`，见 `biz/service/check_engine/check_engine.go:101` | `checkGuaranteeItem`，见 `biz/service/check_engine/check_engine.go:112` | 两者都需要 |
| 返佣 | `checkRebate`，见 `biz/service/check_engine/check_engine.go:102` | `checkRebate`，见 `biz/service/check_engine/check_engine.go:113` | 两者都需要 |
| 商务优惠 | `checkBizDiscount`，见 `biz/service/check_engine/check_engine.go:103` | `checkBizDiscount`，见 `biz/service/check_engine/check_engine.go:114` | 两者都需要 |
| 代金券 | `checkCoupon`，见 `biz/service/check_engine/check_engine.go:104` | `checkCoupon`，见 `biz/service/check_engine/check_engine.go:115` | 两者都需要 |
| 信控 | `checkCredit`，见 `biz/service/check_engine/check_engine.go:105` | `checkCredit`，见 `biz/service/check_engine/check_engine.go:116` | 两者都需要 |
| 关联报价项商务优惠 | 不包含，见 `biz/service/check_engine/check_engine.go:98` | 包含 `checkRelatedBizDiscount`，见 `biz/service/check_engine/check_engine.go:117` | 历史仅全量业务数据校验执行，SubmitQuote 不执行；已修复 |

### 4.2 legacy checker key 映射

新引擎将历史大 checker 拆成多个原子规则；为了保持白名单、结果展示和上层依赖一致，新增 `legacyCheckerKeyByRuleKey` 映射，见 `biz/service/check_engine/check_engine.go:129`。

关键映射结论：

| 原子规则 | 历史 checker key | 一致性目的 |
| --- | --- | --- |
| `BizDataRuleZeroQuote` | `checkZeroQuote`，见 `biz/service/check_engine/check_engine.go:177` | 兼容 0 元报价白名单与返回结果 |
| `BizDataRuleCouponParam` | `checkCouponParam`，见 `biz/service/check_engine/check_engine.go:172` | 兼容代金券参数校验 |
| `BizDataRuleFullQuoteCouponFollowContract` | `checkCouponParam`，见 `biz/service/check_engine/check_engine.go:186` | 兼容全报价单代金券有效期类历史归属 |
| `BizDataRuleFullQuoteCouponValidityRange` | `checkCouponParam`，见 `biz/service/check_engine/check_engine.go:187` | 同上 |
| `BizDataRuleFullQuoteCouponTriggerItem` | `checkCouponParam`，见 `biz/service/check_engine/check_engine.go:188` | 同上 |
| `BizDataRuleRelatedBusinessDiscount` | `checkRelatedQuoteItemBusinessDiscount`，见 `biz/service/check_engine/check_engine.go:183` | 兼容关联商务优惠全量校验结果 |
| `BizDataRuleFullQuoteModifyDiscount` | `checkRelatedQuoteItemBusinessDiscount`，见 `biz/service/check_engine/check_engine.go:185` | 兼容历史商务优惠相关校验归属 |
| `BizDataRuleCreditApply` | `checkCommonApply`，见 `biz/service/check_engine/check_engine.go:170` | 兼容通用申请类校验 |

## 5. 已发现并修复的不一致问题

| 问题 | 业务风险 | 修复内容 | 代码位置 |
| --- | --- | --- | --- |
| 白名单使用历史 checker key，新引擎使用 RuleKey | 历史已忽略的阻断项在新链路重新阻断，影响送审/校验通过率 | 增加 `LegacyCheckerKey` 与 `ShouldSkipBlockRule`，同时支持新旧 key | `biz/service/check_engine/check_engine.go:191`、`biz/service/check_engine/check_engine.go:198` |
| 返回端上的 `CheckKey` 变成原子 RuleKey | 端上展示、过滤、历史配置无法匹配 | `adaptEngineResultsToBizCheckResults` 返回前转换为 legacy checker key | `biz/service/quote_service_by_engine/op_check_dispatch.go:108` |
| 关联报价项商务优惠规则误进入 SubmitQuote | SubmitQuote 主链路执行历史只在全量校验中执行的规则，可能误阻断送审 | 拆出 `checkRelatedBizDiscount`，仅绑定到 `QuoteBizOpTypeBizDataCheck` | `biz/service/check_engine/check_engine.go:81`、`biz/service/check_engine/check_engine.go:109` |
| `BizDataCheck` 与 `SubmitQuote` 共用同一 opType | 全量业务数据校验规则集与历史 `allCheckerKeys` 不一致 | 新增 `QuoteBizOpTypeBizDataCheck` | `biz/service/check_engine/const.go:6` |
| `BizDataCheck` 缺失预刷新或误执行后置刷新 | 校验使用旧派生数据，或校验接口产生提交副作用 | `processSubmitQuoteBizFlow` 增加 `EnablePreRefresh`/`EnablePostRefresh`，BizDataCheck 配置为前置刷新开启、后置刷新关闭 | `biz/service/quote_service_by_engine/op_check_dispatch.go:118`、`biz/service/quote_service_by_engine/biz_data_check.go:30` |
| 指定 `CheckerKeys` 场景走新引擎 | 历史局部校验变成全量校验，返回非请求指定维度的错误 | 入口限制只有 `len(CheckerKeys)==0` 才走新引擎 | `biz/service/quote_service/biz_data_check.go:39` |

## 6. 单测覆盖

| 测试 | 覆盖内容 | 位置 |
| --- | --- | --- |
| `TestRuleRegistryBizDataRulesBindFullQuoteRulesToRelatedChecks_BitsUT` | 校验 SubmitQuote 包含全报价单代金券/商务优惠规则，但不包含关联商务优惠；BizDataCheck 包含关联商务优惠 | `biz/service/check_engine/check_engine_test.go:55` |
| `TestWithSkipBlockRulesSupportRuleKey_BitsUT` | 校验白名单同时支持新 RuleKey 和历史 checker key | `biz/service/check_engine/check_engine_test.go:104` |
| `TestQuoteBizDataCheckReq_Handle/指定 CheckerKeys 时保持老链路局部校验语义` | 校验传入 `CheckerKeys` 时不调用新引擎 | `biz/service/quote_service/biz_data_check_test.go:241` |

本次验证命令：

```bash
go test -gcflags="all=-N -l" ./biz/service/check_engine
go test -gcflags="all=-N -l" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle'
go test -gcflags="all=-N -l" ./biz/service/quote_service_by_engine
```

验证结果：以上命令均通过。

## 7. 最终风险评估

修复后剩余主要风险集中在“原子规则内部逻辑是否完全等价于历史 checker 内部每个分支”。本次已针对架构升级引入的链路编排、规则归属、白名单语义、返回字段、刷新时机、局部/全量校验边界完成一致性修复；这些属于接口行为层面的关键不一致风险，当前已覆盖并通过单测验证。


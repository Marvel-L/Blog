# 报价系统数据刷新模块 refresh_engine 终态架构

> 更新时间：2026-08-06
> 状态：**已落地完成**。refresh_engine 已完成原子化拆分与架构优化，接入 engine_stage 统一编排，与 check_engine 保持同构设计风格。
> 本文定位：refresh_engine 终态架构说明文档，移除了所有历史升级阶段、过渡方案和待执行计划，以当前代码为准记录最终实现。

---

## 一、模块定位与设计原则

### 1.1 模块定位

`refresh_engine` 位于 `biz/service_basic/refresh_engine/`，是报价系统业务数据刷新的原子化实现层：

- 每个数据派生/回填/清理逻辑独立为一个 `QuoteBizRefresher` 实现
- 所有 refresher 通过 `QuoteBizRefresher` 接口统一抽象
- refresher 不持有注册表与执行器，注册和执行统一由上层 `engine_stage` 编排
- 支持 `queryOnly` 模式：只计算/查询不写库，用于预览刷新结果
- 通过 `Needs()`/`Mods()` 声明数据依赖与影响范围，由 engine_stage 统一预加载和增量重载

### 1.2 核心设计原则

1. **原子化原则**：一个 Refresher 对应一个可独立描述、独立执行、独立观测的刷新目标
   - 多个写库动作如果共享同一批内存计算、必须同事务成对写入，则保持一个 Refresher
   - 不同业务域、不同数据副作用边界必须拆成不同 Refresher
   - Refresher 之间通过注册顺序和 `Mods()` reload 表达依赖，不依赖对方副作用维持正确性

2. **接口同构**：与 `check_engine.QuoteBizRule` 保持一致的接口风格，降低认知负担
   - 相同的 `Key()`/`Desc()`/`Needs()`/`BlockLevel()` 方法签名
   - 新增 `Mods()` 声明刷新后需要重载的上下文 key
   - 返回统一的 `*engine_common.RefreshResult` 结果结构

3. **语义明确**：
   - `queryOnly=true`：只计算、只返回 Detail，禁止写库、软删、保存，`Changed=false`
   - `queryOnly=false`：只有真实写库/软删/保存/Update 成功后才 `Changed=true`
   - 无数据、业务不适用、无差异：`Pass=true`、`Changed=false`
   - 业务可理解失败：`Pass=false`、`error=nil`（结果承载错误信息）
   - 系统/DAO/RPC 异常：直接返回 `error`，由执行器 fail-fast

4. **错误处理**：
   - 框架级错误（获取 refresher 失败、上下文缺失、nil 结果等）统一使用 `errors.CodeNGetBizRefresherFailed`
   - 业务失败结果承载在 RefreshResult 上，不新增专用错误码文件
   - 写库/RPC 异常直接返回 Go error，触发执行器短路

---

## 二、接口定义

文件：`biz/service_basic/refresh_engine/biz_refresher.go`

```go
// QuoteBizRefresher 报价业务数据刷新器接口，供 engine_stage 统一调度。
type QuoteBizRefresher interface {
    // Key 返回刷新器唯一标识，全局唯一，用于 engine_stage 注册与调度
    Key() string
    // Desc 返回刷新器人类可读描述，用于日志与诊断
    Desc() string
    // Needs 返回执行前需要预加载的 QuoteContextKey 列表，由 engine_stage 统一加载
    Needs() []quote_context.QuoteContextKey
    // Mods 返回刷新后数据变更的 QuoteContextKey 列表，Changed=true 时由 engine_stage 增量重载
    Mods() []quote_context.QuoteContextKey
    // BlockLevel 返回阻塞级别：Error-阻塞流程，Warn-不阻塞仅告警，Info-不阻塞仅记录日志
    BlockLevel() engine_common.BlockLevel
    // Refresh 执行刷新逻辑
    // queryOnly=true 时只计算不写库；返回 RefreshResult 承载结果，系统异常返回 error
    Refresh(ctx context.Context, tx *gorm.DB, quoteCtx *quote_context.QuoteContext, queryOnly bool) (*engine_common.RefreshResult, error)
}
```

辅助函数：

```go
// newPassRefreshResult 构造字段完备、默认通过的 RefreshResult，供各 Refresher 复用
func newPassRefreshResult(refresher QuoteBizRefresher) *engine_common.RefreshResult {
    return &engine_common.RefreshResult{
        Pass:          true,
        BlockLevel:    refresher.BlockLevel(),
        RefresherKey:  refresher.Key(),
        RefresherDesc: refresher.Desc(),
    }
}
```

---

## 三、当前 Refresher 列表（共 13 个）

所有 refresher 文件位于 `biz/service_basic/refresh_engine/`，按执行阶段分为**前置刷新**（业务校验前执行，用于数据派生与清理）和**后置刷新**（业务校验通过后执行，用于算价与数据补全）。

### 3.1 前置刷新（5个，SubmitQuote 校验前执行）

| Refresher | Key | 文件 | 职责 | Needs | Mods |
|---|---|---|---|---|---|
| `QuoteOppInfoRefresher` | `refreshQuoteOppInfo` | `biz_data_refresher_quote_opp_info.go` | 基于商机信息（OppInfo）派生并回写报价单基础字段（BP分销商、伙伴合同、生态标记等） | Quote, OppInfo | Quote |
| `RebateNotSupportCleanRefresher` | `rebateNotSupportClean` | `biz_data_refresher_rebate_not_support_clean.go` | 报价单不支持返佣时软删无效返佣项 | Quote, RebateItemList | RebateItemList |
| `RebateSupportUpdateRefresher` | `rebateSupportUpdate` | `biz_data_refresher_rebate_support_update.go` | 报价单支持返佣时同步联合打单返佣配置 | Quote, QuoteItems, RebateItemList | RebateItemList |
| `ResourcePageCleanExpiredRefresher` | `resourcePageCleanExpired` | `biz_data_refresher_resource_page_clean_expired.go` | 资源单/资源卡一致性清理，软删过期项 | Quote, ResourcePage, ResourceItemsFromQuote, ResourceItemRespsFromDB | ResourcePage, QuoteResourceItems, ResourceItemRespsFromDB |
| `CouponTriggerInfoRefresher` | `couponTriggerInfo` | `biz_data_refresher_coupon_trigger_info.go` | 代金券触发条件（触发商品、触发报价项等）回填 | Quote, QuoteItemsAllStatus, DeliveryItems, CouponList | CouponList |

### 3.2 后置刷新（8个，SubmitQuote 校验通过后执行）

| Refresher | Key | 文件 | 职责 | Needs | Mods |
|---|---|---|---|---|---|
| `ItemDiscountHeirRefresher` | `refreshItemDiscountHeir` | `biz_data_refresher_item_discount_heir.go` | 报价项与自动交付项折扣同批更新（Heir派生关系维持） | Quote, QuoteItems, DeliveryItems, ItemValues, ParentItemContextMap | ItemValues, ItemContextMap |
| `ItemProductInfoRefresher` | `refreshItemProductInfo` | `biz_data_refresher_item_product_info.go` | 报价项商品快照与算价字段联动刷新 | Quote, QuoteItems, DeliveryItems, ItemValues, ProductInfo | QuoteItems, DeliveryItems, ItemCalMap, ItemContextMap |
| `ItemProductTaxRuleRefresher` | `refreshItemProductTaxRule` | `biz_data_refresher_item_product_tax_rule.go` | 报价项/交付项/算价税率联动刷新 | QuoteItemsAllStatus, DeliveryItems, ItemCalMap, ProductInfo | QuoteItemsAllStatus, QuoteItems, DeliveryItems, ItemCalMap, ItemContextMap |
| `ItemCalFactorDataRefresher` | `refreshItemCalFactorData` | `biz_data_refresher_item_cal_factor_data.go` | 报价项计算因子关系先删后写，保持原子性 | Quote, QuoteItems, DeliveryItems, ItemValues | ItemValues, ItemContextMap |
| `ItemSelectAllExcludeRefresher` | `refreshItemSelectAllExclude` | `biz_data_refresher_item_select_all_exclude.go` | 报价项所有选项排除字段刷新 | Quote, QuoteItems, DeliveryItems, ItemValues | ItemValues, ItemContextMap |
| `QuoteRelatedResDepRefresher` | `refreshQuoteRelatedResDep` | `biz_data_refresher_quote_related_res_dep.go` | 报价单涉及资源方字段（RelatedResDepartment）刷新 | Quote, DeliveryItems, ItemValues | Quote |
| `ItemInquiryRefresher` | `refreshItemInquiry` | `biz_data_refresher_item_inquiry.go` | 报价项算价结果聚合落库 | Quote, QuoteItems, DeliveryItems | ItemCalMap, Quote |
| `ItemTotalDiscountRefresher` | `refreshItemTotalDiscount` | `biz_data_refresher_item_total_discount.go` | 报价项综合折扣、综合预计金额、代金券配比等聚合刷新 | Quote, QuoteItems, DeliveryItems, ItemValues, ItemCalMap, CouponList, QuoteItemCouponRatioList, RebateItemList, ItemContextMap | CouponList, QuoteItemCouponRatioList, ItemCalMap |

---

## 四、文件组织与命名规范

### 4.1 目录结构

```
biz/service_basic/refresh_engine/
├── biz_refresher.go                           # QuoteBizRefresher 接口定义 + newPassRefreshResult 辅助函数
├── biz_data_refresher_quote_opp_info.go       # 前置：商机信息派生
├── biz_data_refresher_rebate_not_support_clean.go  # 前置：不支持返佣时清理
├── biz_data_refresher_rebate_support_update.go     # 前置：支持返佣时同步
├── biz_data_refresher_resource_page_clean_expired.go # 前置：过期资源项清理
├── biz_data_refresher_coupon_trigger_info.go       # 前置：代金券触发信息回填
├── biz_data_refresher_item_discount_heir.go        # 后置：折扣继承
├── biz_data_refresher_item_product_info.go         # 后置：商品信息刷新
├── biz_data_refresher_item_product_tax_rule.go     # 后置：商品税率刷新
├── biz_data_refresher_item_cal_factor_data.go      # 后置：计算因子刷新
├── biz_data_refresher_item_select_all_exclude.go   # 后置：全选排除刷新
├── biz_data_refresher_quote_related_res_dep.go     # 后置：资源方回填
├── biz_data_refresher_item_inquiry.go              # 后置：算价
└── biz_data_refresher_item_total_discount.go       # 后置：综合折扣聚合
```

### 4.2 命名规范

对齐 check_engine 的命名风格：

- 文件名：`biz_data_refresher_{entity}_{subject}.go`
  - entity：`quote`（整单维度）、`item`（报价项维度）、其他业务域缩写
  - subject：刷新目标的简洁描述
- 结构体名：`{Entity}{Subject}Refresher`（如 `ItemProductInfoRefresher`、`QuoteOppInfoRefresher`）
- Key 格式：`refresh{Entity}{Subject}` 或 `<domain><Action>`（如 `refreshItemProductInfo`、`rebateNotSupportClean`）
- 禁止新增 `pre_`、`post_`、`before_biz_check`、`after_biz_check` 这类流程阶段命名，执行顺序由 engine_stage registration 统一控制

### 4.3 代码风格

每个 refresher 实现遵循统一代码风格：

1. **结构体注释**：按「一句摘要 → 职责 → 触发条件 → 写副作用 → 数据来源 → Mods」顺序
2. **短方法单行**：`Key()`/`Desc()`/`BlockLevel()` 等简单方法使用单行大括号
3. **入口守卫**：上下文缺失直接返回 error，由框架层统一处理
4. **主体分段**：按「入口守卫 → 计算/派生 → 短路（无变更/queryOnly）→ 写库 → Changed=true」自然分段
5. **helper 抽取**：报价项+交付项聚合等重复逻辑抽取为共享 helper
6. **日志收敛**：框架层统一打印执行日志，refresher 内部仅保留必要的业务告警
7. **结果构造**：统一使用 `newPassRefreshResult(r)` 构造通过结果，避免重复代码

---

## 五、与 engine_stage 的集成

refresh_engine 本身不持有注册表和执行器，所有注册和执行调度统一由 `engine_stage` 层完成：

1. **注册**：在 `engine_stage/registration.go` 的 `init()` 中通过 `RegisterRefreshers(...)` 批量注册全部 13 个 refresher
2. **编排**：在各 OpType 的 `WithStages(...)` 中通过 `RunRefresher(&refresh_engine.XxxRefresher{})` 精确控制 refresher 的执行时机和顺序
3. **执行**：`engine_stage.Run()` 统一处理：
   - Needs() 预加载（一次性去重加载所有依赖）
   - queryOnly 参数透传
   - Changed=true 且非 queryOnly 时按 Mods() 增量重载 QuoteContext
   - Error 级阻断短路控制
   - 结果收集与日志打印

当前在 registration.go 中定义的执行顺序：

- **SubmitQuote 链路**：5个前置刷新 → 8个桶校验 → 8个后置刷新
- **BizDataCheck 链路**：仅执行8个桶校验，不执行任何刷新
- **BizDataRefresh 链路**：无默认 stages，由外部通过 OverrideStages 动态指定要执行的 refresher

---

## 六、master 旧刷新器到新 Refresher 映射

从 master 分支旧实现到当前新架构的迁移映射（均为 1:1 迁移）：

| 旧 Refresher (biz/service/quote_service_by_engine/) | 新 Refresher (biz/service_basic/refresh_engine/) | 说明 |
|---|---|---|
| `HeirItemDiscountRefresher` / `refreshHeirItemDiscount` | `ItemDiscountHeirRefresher` / `refreshItemDiscountHeir` | 报价项维度统一加 Item 前缀 |
| `ProductInfoRefresher` / `refreshProductInfo` | `ItemProductInfoRefresher` / `refreshItemProductInfo` | 报价项维度统一加 Item 前缀 |
| `ProductTaxRuleRefresher` / `refreshProductTaxRule` | `ItemProductTaxRuleRefresher` / `refreshItemProductTaxRule` | 报价项维度统一加 Item 前缀 |
| `CalFactorDataRefresher` / `refreshCalFactorData` | `ItemCalFactorDataRefresher` / `refreshItemCalFactorData` | 报价项维度统一加 Item 前缀 |
| `SelectAllExcludeRefresher` / `refreshSelectAllExclude` | `ItemSelectAllExcludeRefresher` / `refreshItemSelectAllExclude` | 报价项维度统一加 Item 前缀 |
| `QuoteItemInquiryRefresher` / `refreshQuoteItemInquiry` | `ItemInquiryRefresher` / `refreshItemInquiry` | 去掉冗余 Quote 前缀，Item 已表达维度 |
| `QuoteItemTotalDiscountRefresher` / `refreshQuoteItemTotalDiscount` | `ItemTotalDiscountRefresher` / `refreshItemTotalDiscount` | 去掉冗余 Quote 前缀 |
| `RelatedResDepRefresher` / `refreshRelatedResDep` | `QuoteRelatedResDepRefresher` / `refreshQuoteRelatedResDep` | 整单维度加 Quote 前缀 |
| `QuoteBaseInfoRefresher` | `QuoteOppInfoRefresher` / `refreshQuoteOppInfo` | 命名精化，突出数据来源为 OppInfo |
| `CleanRebateItemsIfNotSupportRefresher` | `RebateNotSupportCleanRefresher` / `rebateNotSupportClean` | 去掉冗余 IfSupport 后缀 |
| `SyncJointOrderRebatesIfSupportRefresher` | `RebateSupportUpdateRefresher` / `rebateSupportUpdate` | 命名收敛为「返佣支持更新」 |
| `CleanExpiredResourceItemsIfSupportRefresher` | `ResourcePageCleanExpiredRefresher` / `resourcePageCleanExpired` | 去掉冗余 IfSupport 后缀 |
| `FullQuoteCouponTriggerInfoRefresher` | `CouponTriggerInfoRefresher` / `couponTriggerInfo` | 去掉冗余 FullQuote 前缀 |

**兼容性说明**：
- refresher Key 仅在引擎内部使用，未透出到外部接口/白名单，不维护旧 Key 兼容表
- 对外 API 使用的 RefresherKey 常量在业务入口层做适配，不影响 refresh_engine 内部抽象
- 5个前置刷新器是从原 checker 副作用中剥离出来的独立 refresher，后续新增同类逻辑按相同规范扩展即可

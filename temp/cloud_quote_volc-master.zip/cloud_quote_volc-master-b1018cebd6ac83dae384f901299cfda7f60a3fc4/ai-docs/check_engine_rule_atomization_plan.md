# check_engine 规则拆分与注册原则

本文档记录 `biz/service_basic/check_engine` 当前有效的规则拆分原则、注册边界、CCRRNN 错误码约束，以及相对 master 旧规则实现的迁移/拆分映射。中间迭代方案与过渡阶段描述已剔除，本文以当前代码终态为准。

## 1. 拆分边界

1. 一个 Rule 对应一个可独立描述、独立执行、独立 skip 的业务校验目标，不按单个 `if` 机械拆分。
2. 同一业务校验目标内的多个短路失败分支保留在同一个 Rule 中，并按原逻辑优先级顺序返回。
3. 不同用户修复动作、不同业务归属或不同执行时机的校验必须拆成不同 Rule。
4. 拆分前后业务效果必须一致：输入数据范围、短路顺序、FailFast 行为、Rule Key 覆盖范围都要与 master 对应规则对齐。
5. Rule 业务逻辑尽可能闭环，除 `ItemEffectiveRule` 这类下游聚合校验外，不依赖其他复杂业务 Rule 的副作用或失败结果。
6. 只读 `QuoteContext`，禁止在 Rule 内做 DB/RPC 写副作用；原逻辑中的回填/清理类副作用应前移到 Refresher 或 Loader。
7. 能在 Rule 内硬编码清晰表达的逻辑不抽公共方法；公共 helper 仅保留跨多个 Rule 复用且语义稳定的方法。

## 2. 注册与执行原则

所有 Rule 通过 `engine_stage/registration.go` 的链式 DSL 统一注册，不在 check_engine 包内持有注册表或执行器：

1. **桶挂载**：通过 `RegisterBucket(bucket).WithRules(...)` 将 Rule 挂载到对应 `QuoteBizDataType` 桶，注册顺序即桶内执行顺序。
2. **OpType 编排**：通过 `RegisterOpType(opType).WithStages(CheckBucket(bucket), ...).WithAccessRules(...)` 声明每个场景（SubmitQuote / BizDataCheck / BizDataRefresh）的桶执行序列与准入规则。
3. **桶间顺序**（`registration.go`）：整单基础信息(QuoteBaseInfo) → 报价项(QuoteItem) → 独立业务维度(Guarantee/Rebate/Coupon/Credit/ResourcePage) → 整单聚合校验(FullQuote)。
4. **桶内顺序原则**：基础存在性 → 枚举合法性 → 单字段校验 → 跨字段逻辑 → 关联一致性 → RPC 复杂校验（放最后，避免基础校验失败时的无效 RPC 调用）。
5. **准入规则**：通过 `WithAccessRules(...)` 单独挂载到 opType，固定 FailFast 最先执行，不属于任何业务数据桶，不支持白名单降级。
6. **SubmitQuote** 主链路 FailFast=true（遇 Error 即短路）；**BizDataCheck** FailFast=false（收集全部失败返回）；**BizDataRefresh** 默认无 Check 阶段，由外部通过 `OverrideStages` 动态构造。
7. Rule Key 变更不做自动兼容映射；如需改名须与业务侧同步更新白名单 skipRuleMap 中的 Key。

## 3. CCRRNN 错误码体系

所有新增 Rule 的业务错误码使用 6 位 CCRRNN 分层编码（定义于 `pkg/errors/codeN_biz_data.go`），通过 `CheckResult.BizErrorCode` 承载内部诊断；`CheckResult.ErrorCode` 沿用 `pkg/errors/codeN.go` 的 8 位老号段保持前端兼容，两者同时填写。

### 3.1 编码规则

- **CC（2位）**：业务大类，连续分配：
  - `10` → Check 公共系统错误（QuoteContext 缺失、依赖调用失败等）
  - `11` → 操作准入（AccessRules）
  - `12` → 整单基础信息（QuoteBaseInfo 桶）
  - `13` → 报价项（QuoteItem 桶）
  - `14` → 保底（Guarantee 桶）
  - `15` → 返佣（Rebate 桶）
  - `16` → 代金券（Coupon 桶）
  - `17` → 信控（Credit 桶）
  - `18` → 资源单（ResourcePage 桶）
  - `19` → 整单聚合校验（FullQuote 桶）
  - `20`~`29` → Check 预留（后续新增桶/维度在此区间分配）
  - `30`+ → Refresh 维度（参见 `refresh_engine_upgrade_plan.md`）
- **RR（2位）**：大类内规则编号，**每个 Rule 文件独占一个 RR**，严格按文件名字母序从 01 开始递增。
- **NN（2位）**：规则内错误条件序号，01 起递增，每个规则预留 99 个槽位。

### 3.2 使用约束

1. 一个失败分支对应一个唯一 BizErrorCode（CCRRNN），同一个 CodeN 不在多个业务失败分支中复用。
2. 必需上下文缺失返回 `nil, error`，使用 `CodeNCheckQuoteContextMissing(100001)`，不占业务 CodeN。
3. 依赖派生计算/RPC 失败返回 `nil, error`，使用 `CodeNCheckDependencyCallFailed(100002)`；明确属于用户可修复的校验失败才返回业务 `CheckResult`。
4. 所有返回给用户的 `ErrorMsg`/`BizErrorMsg` 必须使用 `i18nfmt.Sprintf(ctx, ...)`。
5. 新增错误码只在对应 CC 号段、对应 RR 文件的最大值后追加，不复用、不改动已存在值。
6. `ErrorCode`（老号段）优先复用 `codeN.go` 已有值；无合适值时先在 `codeN.go` 追加 8 位老码，再在 `codeN_biz_data.go` 追加 6 位新码。

## 4. 命名与文件组织

1. 单项数据校验：`biz_data_rule_{quote|item|guarantee|rebate|coupon|credit}_xxx.go`，结构体 `<Entity><Domain>Rule`，Key `BizDataRule<Entity><Domain>`。
2. 整单聚合校验：`full_quote_rule_xxx.go`，结构体 `FullQuote<Xxx>Rule`，Key `BizDataRuleFullQuote<Xxx>`。
3. 操作准入校验：`op_access_rule_xxx.go`，结构体 `OpAccess<Xxx>Rule`，Key `OpAccessRule<Xxx>`。
4. 文件名、结构体名、Rule Key 语义保持一致；token 已包含实体前缀时不重复叠加。
5. `Desc()` 单行覆盖该 Rule 全部失败语义，用于规则说明文档自动生成。
6. 结构体上方注释固定小节：**职责 / 触发条件 / 失败分支 → CodeN / 数据来源**。

## 5. master 旧 Rule 到当前新 Rule 迁移映射

本节基于 `master` 分支 `biz/service/check_engine/` 下的旧规则实现，对比当前 `biz/service_basic/check_engine/` 的终态实现，记录旧 Rule 改名、移动、合并或拆分后的归属关系。

### 5.1 拆分/合并维度

1. **实体归属维度**：报价单级字段归入 `QuoteXxxRule`，报价项级校验归入 `ItemXxxRule`，保底/返佣/代金券/信控分别归入对应业务域 Rule。
2. **用户修复动作维度**：同一个旧 Rule 中如果包含多个用户需要分别修复的动作，则拆成多个 Rule；例如账号必填、账号数量、账号有效性、账号来源分别拆分。
3. **执行数据范围维度**：单个报价项可独立判断的规则与需要整单跨项聚合判断的规则拆开；整单聚合类使用 `FullQuoteXxxRule`。
4. **支持性与参数合法性维度**：是否允许申请/配置（Support）与具体参数、有效期、触发条件的合法性拆开，便于独立 skip 与错误定位。
5. **业务子域维度**：保底按支持性、关联报价项、有效期、采购总席位数、结转拆分；折扣按完整性、阶梯折扣、0 折、SP 折扣策略拆分。

### 5.2 master 旧 Rule → 新 Rule 映射

每行对应一个 master 旧 Rule；拆成多个新 Rule 时，最后一列用带序号的多段落表达同一老 Rule 拆出的所有新 Rule。旧文件路径位于 `biz/service/check_engine/`，新文件路径位于 `biz/service_basic/check_engine/`，表中省略公共前缀。

| 旧 Rule / 旧 Key | 旧文件 | 旧 Rule 职责 | 拆分/迁移依据 | 新 Rule 清单（新 Rule / 新 Key / 新文件 / 新职责） |
|---|---|---|---|---|
| `MaxItemNumRule` / `BizDataRuleMaxItemNum` | `biz_data_rule_max_item_num.go` | 报价项+交付项数量不超过配置最大值 | 与 QuoteBaseInfoBasicRule 的"报价项存在性"合并为统一数量校验，归入报价项维度 | `ItemCountRule` / `BizDataRuleItemCount` / `biz_data_rule_item_count.go` / 报价项存在性 + 报价项/交付项数量上限 |
| `CombineRuleRule` / `BizDataRuleCombineRule` | `biz_data_rule_combine_rule.go` | 解决方案内报价项商品集合组合规则 | 语义精化为"报价项-解决方案组合规则"，归入报价项维度 | `ItemCombineRule` / `BizDataRuleItemCombine` / `biz_data_rule_item_combine_rule.go` / 解决方案内报价项商品集合组合合法性 |
| `ProjectSupplyRule` / `BizDataRuleProjectSupply` | `biz_data_rule_project_supply.go` | 项目制补充协议续约/增购有效期校验 | 属于报价单项目制基础信息，加 `Quote` 前缀 | `QuoteProjectSupplyRule` / `BizDataRuleQuoteProjectSupply` / `biz_data_rule_quote_project_supply.go` / 项目制补充协议续约/增购有效期约束 |
| `ResourcePageRule` / `BizDataRuleResourcePage` | `biz_data_rule_resource_page.go` | 资源单/资源卡一致性与缺失校验 | 命名精化为 ResourcePageInfoMissing，突出"信息缺失"失败语义 | `ResourcePageInfoMissingRule` / `BizDataRuleResourcePageInfoMissing` / `biz_data_rule_resource_page_info_missing.go` / 资源单/资源卡一致性与缺失校验 |
| `QuoteBaseInfoBasicRule` / `BizDataRuleQuoteBaseInfoBasic` | `biz_data_rule_quote_base_info_basic.go` | 报价单基础信息 6 类校验 | 按用户可修复动作维度拆分；报价项空与 MaxItemNumRule 合并归入 ItemCountRule；SP/提货券两条同类拦截合并到 ItemProductSupportRule；报价单级"未立项产品线缺失"独立为 QuoteUnapprovedProductLineRule | ①`ItemCountRule` / `BizDataRuleItemCount` / `biz_data_rule_item_count.go` / 报价项存在性<br>②`ItemDraftRule` / `BizDataRuleItemDraft` / `biz_data_rule_item_draft.go` / 草稿报价项拦截<br>③`ItemProductSupportRule` / `BizDataRuleItemProductSupport` / `biz_data_rule_item_product_support.go` / SP/提货券商品支持性（合并原 ItemSpSupportRule / ItemPickupVoucherSupportRule）<br>④`ItemDeliveryMissingRule` / `BizDataRuleItemDeliveryMissing` / `biz_data_rule_item_delivery_missing.go` / 项目制手工交付项必填<br>⑤`QuoteUnapprovedProductLineRule` / `BizDataRuleQuoteUnapprovedProductLine` / `biz_data_rule_quote_unapproved_product_line.go` / 含未立项商品时未立项产品线不能为空 |
| `DistributorInfoRule` / `BizDataRuleDistributorInfo` | `biz_data_rule_distributor_info.go` | BP 分销商信息与最新账号关系一致性 | 归入报价单分销信息维度，加 `Quote` 前缀 | `QuoteDistributorInfoRule` / `BizDataRuleQuoteDistributorInfo` / `biz_data_rule_quote_distributor_info.go` / BP 分销商信息一致性与账号关系变更检测 |
| `DistributionBizTypeRule` / `BizDataRuleDistributionBizType` | `biz_data_rule_distribution_biz_type.go` | 分销业务类型枚举与客户类型约束 | 语义精化为"分销业务类型"，加 `Quote` 前缀 | `QuoteDistributionTypeRule` / `BizDataRuleQuoteDistributionType` / `biz_data_rule_quote_distribution_type.go` / 分销业务类型合法性 |
| `ProjectAttributesRule` / `BizDataRuleProjectAttributes` | `biz_data_rule_project_attributes.go` | 报价单项目属性枚举校验 | 归入报价单主体信息维度，加 `Quote` 前缀 | `QuoteProjectAttributeRule` / `BizDataRuleQuoteProjectAttribute` / `biz_data_rule_quote_project_attribute.go` / 报价单项目属性枚举合法性 |
| `QuoteNotesRule` / `BizDataRuleQuoteNotes` | `biz_data_rule_quote_notes.go` | 报价逻辑必填 | 语义闭环，Key 保持不变，仅物理迁移 | `QuoteNotesRule` / `BizDataRuleQuoteNotes` / `biz_data_rule_quote_notes.go` / 报价逻辑必填 |
| `GiveAwayInfoRule` / `BizDataRuleGiveAwayInfo` | `biz_data_rule_give_away_info.go` | 报价单赠送场景、赠送原因字段合法性 | 归入报价单主体信息，加 `Quote` 前缀 | `QuoteGiveawayRule` / `BizDataRuleQuoteGiveaway` / `biz_data_rule_quote_giveaway.go` / 报价单赠送场景/赠送原因字段合法性 |
| `EffectiveInfoRule` / `BizDataRuleEffectiveInfo` | `biz_data_rule_effective_info.go` | 按主体生效时主体名称必填 | 精化为"主体生效对象校验" | `QuoteEffectiveSubjectRule` / `BizDataRuleQuoteEffectiveSubject` / `biz_data_rule_quote_effective_subject.go` / 按主体生效场景下主体信息必填 |
| `ChangeInfoRule` / `BizDataRuleChangeInfo` | `biz_data_rule_change_info.go` | 变更报价才允许填写变更内容，且长度受限 | 加 `Quote` 前缀 | `QuoteChangeInfoRule` / `BizDataRuleQuoteChangeInfo` / `biz_data_rule_quote_change_info.go` / 变更内容填写场景与长度合法性 |
| `EstimatedTradingMonthlyIncomeRule` / `BizDataRuleEstimatedTradingMonthlyIncome` | `biz_data_rule_estimated_trading_monthly_income.go` | 预估上量月收入不超过销售预估金额 | 命名收敛为 QuoteMonthlyIncomeRule | `QuoteMonthlyIncomeRule` / `BizDataRuleQuoteMonthlyIncome` / `biz_data_rule_quote_monthly_income.go` / 上量月收入不超过预估销售金额 |
| `PublicCloudEstimateRule` / `BizDataRulePublicCloudEstimate` | `biz_data_rule_public_cloud_estimate.go` | 公有云标品预估金额约束 | 与 QuoteEstimateBySalesRule 合并为统一预估金额校验 | `QuoteEstimatedIncomeRule` / `BizDataRuleQuoteEstimatedIncome` / `biz_data_rule_quote_estimated_income_required.go` / 涉云预估销售金额必填 + 公有云标品预估金额区间校验 |
| `LongLifeReasonRule` / `BizDataRuleLongLifeReason` | `biz_data_rule_long_life_reason.go` | 长有效期原因必填与长度限制 | 加 `Quote` 前缀 | `QuoteLongLifeReasonRule` / `BizDataRuleQuoteLongLifeReason` / `biz_data_rule_quote_long_life_reason.go` / 长有效期原因必填与长度限制 |
| `EstimatedTradingTimeRule` / `BizDataRuleEstimatedTradingTime` | `biz_data_rule_estimated_trading_time.go` | 预计上量时间落在合同有效期月维度区间内 | 加 `Quote` 前缀 | `QuoteEstimatedTradingTimeRule` / `BizDataRuleQuoteEstimatedTradingTime` / `biz_data_rule_quote_estimated_trading_time.go` / 预计上量时间落在合同有效期月维度区间内 |
| `MdInfoRule` / `BizDataRuleMdInfo` | `biz_data_rule_md_info.go` | BytePlus+CRM 来源场景下 BP 主数据信息解析 | 命名精化为 QuoteBPMdInfoRule | `QuoteBPMdInfoRule` / `BizDataRuleQuoteBPMdInfo` / `biz_data_rule_quote_bp_md_info.go` / BP 主数据信息解析 |
| `ProgressiveInfoRule` / `BizDataRuleProgressiveInfo` | `biz_data_rule_progressive_info.go` | 阶梯信息合法性、单账号独立累计限制 | 加 `Quote` 前缀 | `QuoteProgressiveInfoRule` / `BizDataRuleQuoteProgressiveInfo` / `biz_data_rule_quote_progressive_info.go` / 阶梯信息解析与合法性约束 |
| `QuoteEstimateBySalesRule` / `BizDataRuleQuoteEstimateBySales` | `biz_data_rule_quote_estimate_by_sales.go` | 涉云报价单销售预估金额必填非 0 | 与 PublicCloudEstimateRule 合并为 QuoteEstimatedIncomeRule | （合并入 `QuoteEstimatedIncomeRule`） |
| `ProjectQuoteDataRule` / `BizDataRuleProjectQuoteData` | `biz_data_rule_project_quote_data.go` | 项目制 SOW、项目编码、项目名称等字段完整性 | 命名收敛为 QuoteProjectDataRule | `QuoteProjectDataRule` / `BizDataRuleQuoteProjectData` / `biz_data_rule_quote_project_data.go` / 项目制立项信息完整性 |
| `BackdatingRule` / `BizDataRuleBackdating` | `biz_data_rule_backdating.go` | 倒签场景签约方式/客户类型/项目制/原因/关联合同号校验 | 加 `Quote` 前缀 | `QuoteBackdatingRule` / `BizDataRuleQuoteBackdating` / `biz_data_rule_quote_backdating.go` / 倒签合法性 |
| `SolutionInfoRule` / `BizDataRuleSolutionInfo` | `biz_data_rule_solution_info.go` | 产解/行解账号数量与邮箱有效性 | 语义精化为"产解/行解用户账号"，避免与 Solution 业务对象重名 | `QuoteUserAccountRule` / `BizDataRuleQuoteUserAccount` / `biz_data_rule_quote_user_account.go` / 产解/行解账号合法性 |
| `TradeProductTypeRule` / `BizDataRuleTradeProductType` | `biz_data_rule_trade_product_type.go` | 报价单涉及商品类型整体约束 | 命名收敛为 QuoteProductTypeRule | `QuoteProductTypeRule` / `BizDataRuleQuoteProductType` / `biz_data_rule_quote_product_type.go` / 报价单涉及商品类型整体约束 |
| `PartnerNameRule` / `BizDataRulePartnerName` | `biz_data_rule_partner_name.go` | 伙伴账号名与商机伙伴账号名一致 | 加 `Quote` 前缀 | `QuotePartnerNameRule` / `BizDataRuleQuotePartnerName` / `biz_data_rule_quote_partner_name.go` / 伙伴账号名与商机伙伴账号名一致 |
| `CustomerNameRule` / `BizDataRuleCustomerName` | `biz_data_rule_customer_name.go` | 客户账号名与商机客户账号名一致 | 加 `Quote` 前缀 | `QuoteCustomerNameRule` / `BizDataRuleQuoteCustomerName` / `biz_data_rule_quote_customer_name.go` / 客户账号名与商机客户账号名一致 |
| `TradeTypeRule` / `BizDataRuleTradeType` | `biz_data_rule_trade_type.go` | 客户类型枚举、生态伙伴授权、BP 分销报价类型限制 | 加 `Quote` 前缀 | `QuoteTradeTypeRule` / `BizDataRuleQuoteTradeType` / `biz_data_rule_quote_trade_type.go` / 客户类型枚举与关联业务约束 |
| `PriceValidPeriodRule` / `BizDataRulePriceValidPeriod` | `biz_data_rule_price_valid_period.go` | 预估合同有效期、签约方式、商品类型、伙伴授权时间区间校验 | 加 `Quote` 前缀 | `QuotePriceValidPeriodRule` / `BizDataRuleQuotePriceValidPeriod` / `biz_data_rule_quote_price_valid_period.go` / 预估合同有效期合法性 |
| `RelatedAccountIDsRule` / `BizDataRuleRelatedAccountIDs` | `biz_data_rule_related_account_ids.go` | 签约账号、配价账号、最终客户账号关系与伙伴授权 | 命名收敛为 QuoteRelatedAccountRule | `QuoteRelatedAccountRule` / `BizDataRuleQuoteRelatedAccount` / `biz_data_rule_quote_related_account.go` / 签约/配价/最终客户账号关系与伙伴授权范围 |
| `PartnerContractNoRule` / `BizDataRulePartnerContractNo` | `biz_data_rule_partner_contract_no.go` | 分销协议合同号必填/清空及伙伴授权合同命中 | 命名收敛为 QuotePartnerContractRule | `QuotePartnerContractRule` / `BizDataRuleQuotePartnerContract` / `biz_data_rule_quote_partner_contract.go` / 分销协议合同号约束 |
| `CustomerDetailRule` / `BizDataRuleCustomerDetail` | `biz_data_rule_customer_detail.go` | 客户账号 5 类校验 | 按用户可修复动作维度拆成 5 个原子 Rule | ①`QuoteAccountRequiredRule` / `BizDataRuleQuoteAccountRequired` / `biz_data_rule_quote_account_required.go` / 客户/签约账号必填<br>②`QuoteAccountCountRule` / `BizDataRuleQuoteAccountCount` / `biz_data_rule_quote_account_count.go` / 账号数量与多选场景约束<br>③`QuoteBPFinalCustomerRule` / `BizDataRuleQuoteBPFinalCustomer` / `biz_data_rule_quote_bp_final_customer.go` / BP 最终客户校验<br>④`QuoteAccountEffectiveRule` / `BizDataRuleQuoteAccountEffective` / `biz_data_rule_quote_account_effective.go` / 账号存在/重复/实名/注销校验<br>⑤`QuoteAccountSourceRule` / `BizDataRuleQuoteAccountSource` / `biz_data_rule_quote_account_source.go` / 账号来源与商品类型匹配 |
| `CustomerQuoteQualificationRule` / `BizDataRuleCustomerQuoteQualification` | `biz_data_rule_customer_quote_qualification.go` | 直销账号代销关系与生态客户邀约类型匹配 | 命名收敛为 QuoteAccountCustomerRule | `QuoteAccountCustomerRule` / `BizDataRuleQuoteAccountCustomer` / `biz_data_rule_quote_account_customer.go` / 直销账号代销关系与邀约类型匹配 |
| `QuoteTypeRule` / `BizDataRuleQuoteType` | `biz_data_rule_quote_type.go` | 报价类型合法性 | Key 保持不变，仅物理迁移 | `QuoteTypeRule` / `BizDataRuleQuoteType` / `biz_data_rule_quote_type.go` / 报价类型合法性 |
| `OrderTypeRule` / `BizDataRuleOrderType` | `biz_data_rule_order_type.go` | 签约方式枚举、内部/私有云/分销/阶梯场景限制 | 加 `Quote` 前缀 | `QuoteOrderTypeRule` / `BizDataRuleQuoteOrderType` / `biz_data_rule_quote_order_type.go` / 签约方式合法性 |
| `ZeroQuoteRule` / `BizDataRuleZeroQuote` | `biz_data_rule_zero_quote.go` | 0 元/赠送项 3 类校验 | 赠送项基础字段合并进 QuoteGiveawayRule，剩余拆成 2 个报价项级 Rule | ①赠送场景/原因合并进 `QuoteGiveawayRule`<br>②`ItemZeroSupportRule` / `BizDataRuleItemZeroSupport` / `biz_data_rule_item_zero_support.go` / 0 元类报价项签约方式约束<br>③`ItemZeroRelatedRule` / `BizDataRuleItemZeroRelated` / `biz_data_rule_item_zero_related.go` / 同税率/部署方式分组内非 0 元项关联校验 |
| `ItemSellingModeValidRule` / `BizDataRuleItemSellingModeValid` | `biz_data_rule_item_selling_mode_valid.go` | 公有云报价项售卖模式合法性 | 命名去掉 Valid 冗余后缀 | `ItemSellingModeRule` / `BizDataRuleItemSellingMode` / `biz_data_rule_item_selling_mode.go` / 报价项售卖模式合法性 |
| `ItemEffectiveRule` / `BizDataRuleItemEffective` | `biz_data_rule_item_effective.go` | 商品、配置、计费项、折扣线、报价方式有效性聚合校验 | Key 保持不变，仅物理迁移 | `ItemEffectiveRule` / `BizDataRuleItemEffective` / `biz_data_rule_item_effective.go` / 报价项有效性聚合校验 |
| `RatioChargeItemRule` / `BizDataRuleRatioChargeItem` | `biz_data_rule_ratio_charge_item.go` | 比例计费项所在解决方案需存在比例关联计费项 | 命名收敛为 ItemRatioChargeRule | `ItemRatioChargeRule` / `BizDataRuleItemRatioCharge` / `biz_data_rule_item_ratio_charge.go` / 比例计费项所需关联计费项存在性 |
| `ItemDiscountRule` / `BizDataRuleItemDiscount` | `biz_data_rule_item_discount.go` | 折扣 5 类校验 | 按业务子域拆成 4 个 Rule | ①`ItemDiscountMissingRule` / `BizDataRuleItemDiscountMissing` / `biz_data_rule_item_discount_missing.go` / 折扣信息完整性（含项目制补全）<br>②`ItemDiscountProgressiveRule` / `BizDataRuleItemDiscountProgressive` / `biz_data_rule_item_discount_progressive.go` / 阶梯报价折扣校验<br>③`ItemDiscountZeroRule` / `BizDataRuleItemDiscountZero` / `biz_data_rule_item_discount_zero.go` / SP/抵扣计费项不支持 0 元折扣<br>④`ItemSpDiscountRule` / `BizDataRuleItemSpDiscount` / `biz_data_rule_item_sp_discount.go` / SP 非 10 折策略 |
| `RelatedChargeItemRule` / `BizDataRuleRelatedChargeItem` | `biz_data_rule_related_charge_item.go` | 方舟关联计费项满足配置树定义 | 命名收敛为 ItemChargeRelatedRule | `ItemChargeRelatedRule` / `BizDataRuleItemChargeRelated` / `biz_data_rule_item_charge_related.go` / 方舟关联计费项满足配置树 |
| `UnStandardDeliveryItemCostRule` / `BizDataRuleUnStandardDeliveryItemCost` | `biz_data_rule_unstandard_delivery_item_cost.go` | 手动非标品交付项成本/出厂价 | 命名收敛为 ItemDeliveryCostRule | `ItemDeliveryCostRule` / `BizDataRuleItemDeliveryCost` / `biz_data_rule_item_delivery_cost.go` / 手动非标品交付项成本/出厂价合法性 |
| `EstimatedIncomeRule` / `BizDataRuleEstimatedIncome` | `biz_data_rule_estimated_income.go` | 预计金额 3 类校验 | 综合预计金额校验已下线；剩余按执行数据范围拆成 2 个 Rule | ①`ItemEstimatedIncomeRequiredRule` / `BizDataRuleItemEstimatedIncomeRequired` / `biz_data_rule_item_estimated_income_required.go` / 单项预计金额必填 + 大于 0<br>②`FullQuoteEstimatedIncomeConsistencyRule` / `BizDataRuleFullQuoteEstimatedIncomeConsistency` / `full_quote_rule_estimated_income_consistency.go` / 整单预计金额汇总/跨项一致性 |
| `ProductCustomerScopeRule` / `BizDataRuleProductCustomerScope` | `biz_data_rule_product_customer_scope.go` | 报价项商品售卖客户范围与报价单客户类型匹配 | 加 Item 前缀 | `ItemProductCustomerScopeRule` / `BizDataRuleItemProductCustomerScope` / `biz_data_rule_item_product_customer_scope.go` / 商品售卖客户范围与报价单客户类型匹配 |
| `RelatedProductRule` / `BizDataRuleRelatedProduct` | `biz_data_rule_related_product.go` | 报价项商品类型范围与报价单关联商品范围 | 命名收敛为 ItemProductScopeRule | `ItemProductScopeRule` / `BizDataRuleItemProductScope` / `biz_data_rule_item_product_scope.go` / 报价项商品类型范围与报价单关联商品范围 |
| `DistributionDiscountsRule` / `BizDataRuleDistributionDiscounts` | `biz_data_rule_distribution_discounts.go` | BP 分销折扣力度与一致性 | 命名收敛为 ItemDistributionDiscountRule | `ItemDistributionDiscountRule` / `BizDataRuleItemDistributionDiscount` / `biz_data_rule_item_distribution_discount.go` / BP 分销折扣力度与层级一致性 |
| `ConfigListRule` / `BizDataRuleConfigList` | `biz_data_rule_config_list.go` | 配置清单/项目制交付项阶梯价重复校验 | 命名精化为 ItemProgressivePriceDuplicateRule | `ItemProgressivePriceDuplicateRule` / `BizDataRuleItemProgressivePriceDuplicate` / `biz_data_rule_item_progressive_price_duplicate.go` / 配置清单/项目制交付项阶梯价去重 |
| `DeductDiscountRule` / `BizDataRuleDeductDiscount` | `biz_data_rule_deduct_discount.go` | 抵扣报价项折扣上限 | 属于整单跨项折扣层级约束，归入 FullQuote 前缀 | `FullQuoteDeductDiscountLevelRule` / `BizDataRuleFullQuoteDeductDiscountLevel` / `full_quote_rule_deduct_discount_level.go` / 抵扣报价项折扣上限（整单跨项） |
| `GuaranteeRule` / `BizDataRuleGuarantee` | `biz_data_rule_guarantee.go` | 保底 5 类校验 | 按保底子域拆成 5 个 Rule | ①`GuaranteeSupportRule` / `BizDataRuleGuaranteeSupport` / `biz_data_rule_guarantee_support.go` / 报价单是否支持保底<br>②`GuaranteeItemsRule` / `BizDataRuleGuaranteeItems` / `biz_data_rule_guarantee_items.go` / 保底关联报价项范围<br>③`GuaranteeValidityRule` / `BizDataRuleGuaranteeValidity` / `biz_data_rule_guarantee_validity.go` / 周期保底有效期<br>④`GuaranteeTotalSeatsRule` / `BizDataRuleGuaranteeTotalSeats` / `biz_data_rule_guarantee_total_seats.go` / 保底采购总席位数<br>⑤`GuaranteeCarryForwardRule` / `BizDataRuleGuaranteeCarryForward` / `biz_data_rule_guarantee_carry_forward.go` / 补充协议保底结转 |
| `GuaranteePercentageRule` / `BizDataRuleGuaranteePercentage` | `biz_data_rule_guarantee_percentage.go` | 保底比例校验（多账号一致性/支持性/必填/合法值） | 命名加 Item 前缀，执行位置从 Guarantee 桶迁至 QuoteItem 桶 | `ItemGuaranteePercentageRule` / `BizDataRuleItemGuaranteePercentage` / `biz_data_rule_item_guarantee_percentage.go` / 报价项保底比例合法性 |
| `RebateRule` / `BizDataRuleRebate` | `biz_data_rule_rebate.go` | 返佣信息与关联报价项 | 命名精化为 RebateItemsSupportRule | `RebateItemsSupportRule` / `BizDataRuleRebateItemsSupport` / `biz_data_rule_rebate_items_support.go` / 返佣关联报价项支持性 |
| `JointPrintOrderRule` / `BizDataRuleJointPrintOrder` | `biz_data_rule_joint_print_order.go` | 联合打单信息（商机/PRM 一致性、协作人等） | 加 Quote 前缀；归入 QuoteBaseInfo 桶（返佣前置校验依赖） | `QuoteJointPrintOrderRule` / `BizDataRuleQuoteJointPrintOrder` / `biz_data_rule_quote_joint_print_order.go` / 联合打单信息合法性与商机/PRM 一致性 |
| `FullQuoteModifyDiscountRule` / `BizDataRuleFullQuoteModifyDiscount` | `full_quote_modify_discount_rule.go` | 审批中修改再次送审前后商务优惠范围一致性 | 命名精化为 FullQuoteBusinessDiscountsChangeRule | `FullQuoteBusinessDiscountsChangeRule` / `BizDataRuleFullQuoteBusinessDiscountsChange` / `full_quote_rule_business_discounts_change.go` / 审批中修改再次送审商务优惠范围一致性 |
| `RelatedBusinessDiscountRule` / `BizDataRuleRelatedBusinessDiscount` | `biz_data_rule_related_business_discount.go` | 关联报价项返佣/保底商务优惠成对一致 | 加 FullQuote 前缀（整单跨项） | `FullQuoteBusinessDiscountsRelatedRule` / `BizDataRuleFullQuoteBusinessDiscountsRelated` / `full_quote_rule_business_discounts_related.go` / 关联报价项返佣/保底成对一致 |
| `CouponApplyRule` / `BizDataRuleCouponApply` | `biz_data_rule_coupon_apply.go` | 代金券申请支持性 | 命名精化为 CouponSupportRule | `CouponSupportRule` / `BizDataRuleCouponSupport` / `biz_data_rule_coupon_support.go` / 代金券申请支持性 |
| `CouponParamRule` / `BizDataRuleCouponParam` | `biz_data_rule_coupon_param.go` | 代金券参数合法性 | Key 保持不变，仅物理迁移 | `CouponParamRule` / `BizDataRuleCouponParam` / `biz_data_rule_coupon_param.go` / 代金券参数合法性 |
| `FullQuoteCouponFollowContractRule` / `BizDataRuleFullQuoteCouponFollowContract` | `full_quote_coupon_follow_contract_rule.go` | 自签订之日起代金券须跟随合同 | 与 FullQuoteCouponValidityRangeRule 合并 | （合并入 `CouponValidityRule`） |
| `FullQuoteCouponValidityRangeRule` / `BizDataRuleFullQuoteCouponValidityRange` | `full_quote_coupon_validity_range_rule.go` | 代金券指定月份有效期落在报价单合同有效期内 | 与 FullQuoteCouponFollowContractRule 合并为统一有效期 Rule | `CouponValidityRule` / `BizDataRuleCouponValidity` / `biz_data_rule_coupon_validity.go` / 代金券有效期合法性（跟随合同 + 指定月份区间） |
| `FullQuoteCouponTriggerItemRule` / `BizDataRuleFullQuoteCouponTriggerItem` | `full_quote_coupon_trigger_item_rule.go` | 代金券触发条件报价项归属、消费/统计商品匹配 | 命名收敛为 FullQuoteCouponTriggerRule | `FullQuoteCouponTriggerRule` / `BizDataRuleFullQuoteCouponTrigger` / `full_quote_rule_coupon_trigger.go` / 代金券触发条件报价项归属、消费/统计商品匹配 |
| `CreditApplyRule` / `BizDataRuleCreditApply` | `biz_data_rule_credit_apply.go` | 信控申请支持性（至少包含公有云标品报价项） | 命名精化为 CreditSupportRule | `CreditSupportRule` / `BizDataRuleCreditSupport` / `biz_data_rule_credit_support.go` / 信控申请支持性 |
| `QuoteCanOperateRule` / `OpAccessRuleQuoteCanOperate` | `op_access_rule_quote_can_operate.go` | 操作准入（配置清单上架不可操作、审批中修改状态例外、草稿/驳回前可修改） | 命名收敛为 OpAccessQuoteOperationRule | `OpAccessQuoteOperationRule` / `OpAccessRuleQuoteOperation` / `op_access_rule_quote_operation.go` / 报价单操作准入判定 |

## 6. 当前规则清单（按 QuoteBizDataType 桶组织）

以下清单与 `engine_stage/registration.go` `init()` 中 `RegisterBucket(...).WithRules(...)` 的注册顺序完全一致。

### 6.1 准入规则（AccessRules，挂载在 opType 上，不属于任何桶）

| Rule | 文件 | 职责 |
|---|---|---|
| OpAccessQuoteOperationRule | op_access_rule_quote_operation.go | 报价单操作准入判定（配置清单上架/审批中修改/草稿/驳回状态拦截） |

### 6.2 QuoteBaseInfo 桶（整单基础信息，CC=12）

桶内顺序：核心枚举合法性 → 简单字段必填/格式/JSON解析 → 数值/有效期逻辑 → 场景化复杂校验+外部数据 → 账号链式校验 → Lark RPC 校验

| # | Rule | 文件 | 职责 |
|---|---|---|---|
| 1 | QuoteTypeRule | biz_data_rule_quote_type.go | 报价类型合法性 |
| 2 | QuoteOrderTypeRule | biz_data_rule_quote_order_type.go | 签约方式合法性 |
| 3 | QuoteTradeTypeRule | biz_data_rule_quote_trade_type.go | 客户类型合法性 |
| 4 | QuoteDistributionTypeRule | biz_data_rule_quote_distribution_type.go | 分销业务类型合法性 |
| 5 | QuoteProjectAttributeRule | biz_data_rule_quote_project_attribute.go | 项目属性枚举 |
| 6 | QuoteNotesRule | biz_data_rule_quote_notes.go | 报价逻辑必填 |
| 7 | QuoteEffectiveSubjectRule | biz_data_rule_quote_effective_subject.go | 主体生效信息 |
| 8 | QuoteBPMdInfoRule | biz_data_rule_quote_bp_md_info.go | BP 主数据信息解析 |
| 9 | QuoteProjectDataRule | biz_data_rule_quote_project_data.go | 项目制立项信息完整性 |
| 10 | QuoteGiveawayRule | biz_data_rule_quote_giveaway.go | 赠送场景/原因合法性 |
| 11 | QuoteChangeInfoRule | biz_data_rule_quote_change_info.go | 变更内容合法性 |
| 12 | QuoteProgressiveInfoRule | biz_data_rule_quote_progressive_info.go | 阶梯信息合法性 |
| 13 | QuoteProductTypeRule | biz_data_rule_quote_product_type.go | 报价单涉及商品类型合法性 |
| 14 | QuoteEstimatedIncomeRule | biz_data_rule_quote_estimated_income_required.go | 报价单预估销售金额与公有云标品预估金额范围 |
| 15 | QuoteMonthlyIncomeRule | biz_data_rule_quote_monthly_income.go | 上量月收入不超过预估销售金额 |
| 16 | QuotePriceValidPeriodRule | biz_data_rule_quote_price_valid_period.go | 预估合同有效期合法性 |
| 17 | QuoteLongLifeReasonRule | biz_data_rule_quote_long_life_reason.go | 长有效期原因 |
| 18 | QuoteEstimatedTradingTimeRule | biz_data_rule_quote_estimated_trading_time.go | 预计上量时间 |
| 19 | QuoteUnapprovedProductLineRule | biz_data_rule_quote_unapproved_product_line.go | 未立项商品产品线必填 |
| 20 | QuoteDistributorInfoRule | biz_data_rule_quote_distributor_info.go | BP 分销商信息一致性 |
| 21 | QuotePartnerNameRule | biz_data_rule_quote_partner_name.go | 伙伴账号名与商机一致 |
| 22 | QuoteCustomerNameRule | biz_data_rule_quote_customer_name.go | 客户账号名与商机一致 |
| 23 | QuotePartnerContractRule | biz_data_rule_quote_partner_contract.go | 分销协议合同号 |
| 24 | QuoteProjectSupplyRule | biz_data_rule_quote_project_supply.go | 项目制补充协议续约/增购有效期 |
| 25 | QuoteBackdatingRule | biz_data_rule_quote_backdating.go | 倒签合法性 |
| 26 | QuoteAccountRequiredRule | biz_data_rule_quote_account_required.go | 客户/签约账号必填 |
| 27 | QuoteAccountCountRule | biz_data_rule_quote_account_count.go | 账号数量与多选约束 |
| 28 | QuoteAccountEffectiveRule | biz_data_rule_quote_account_effective.go | 账号有效性（存在/重复/实名/注销） |
| 29 | QuoteBPFinalCustomerRule | biz_data_rule_quote_bp_final_customer.go | BP 最终客户校验 |
| 30 | QuoteAccountSourceRule | biz_data_rule_quote_account_source.go | 账号来源与商品类型匹配 |
| 31 | QuoteAccountCustomerRule | biz_data_rule_quote_account_customer.go | 账号客户关系资质（直销代销/邀约类型） |
| 32 | QuoteRelatedAccountRule | biz_data_rule_quote_related_account.go | 签约/配价/最终客户账号关系与伙伴授权范围 |
| 33 | QuoteUserAccountRule | biz_data_rule_quote_user_account.go | 产解/行解账号合法性（含 Lark RPC） |
| 34 | QuoteJointPrintOrderRule | biz_data_rule_quote_joint_print_order.go | 联合打单信息合法性与商机/PRM 一致性（含 Lark RPC） |

### 6.3 QuoteItem 桶（报价项，CC=13）

桶内顺序：基础存在性/状态闸门 → 商品范围/售卖模式/组合规则 → 0元/赠送项 → 计费项关联 → 折扣链式校验 → 交付项/算价/收入 → Redis 读保底比例

| # | Rule | 文件 | 职责 |
|---|---|---|---|
| 1 | ItemCountRule | biz_data_rule_item_count.go | 报价项存在性与报价项/交付项数量上限 |
| 2 | ItemDraftRule | biz_data_rule_item_draft.go | 草稿报价项拦截 |
| 3 | ItemProductSupportRule | biz_data_rule_item_product_support.go | SP/提货券商品支持性 |
| 4 | ItemDeliveryMissingRule | biz_data_rule_item_delivery_missing.go | 项目制手工交付项必填 |
| 5 | ItemEffectiveRule | biz_data_rule_item_effective.go | 报价项有效性聚合校验 |
| 6 | ItemProductScopeRule | biz_data_rule_item_product_scope.go | 报价项商品类型范围与关联商品范围 |
| 7 | ItemProductCustomerScopeRule | biz_data_rule_item_product_customer_scope.go | 商品售卖客户范围与报价单客户类型匹配 |
| 8 | ItemSellingModeRule | biz_data_rule_item_selling_mode.go | 售卖模式合法性 |
| 9 | ItemCombineRule | biz_data_rule_item_combine_rule.go | 解决方案组合规则 |
| 10 | ItemZeroSupportRule | biz_data_rule_item_zero_support.go | 0 元类/赠送项签约方式约束 |
| 11 | ItemZeroRelatedRule | biz_data_rule_item_zero_related.go | 同税率/部署方式分组内非 0 元项关联校验 |
| 12 | ItemRatioChargeRule | biz_data_rule_item_ratio_charge.go | 比例关联计费项存在性 |
| 13 | ItemChargeRelatedRule | biz_data_rule_item_charge_related.go | 方舟关联计费项满足配置树 |
| 14 | ItemDiscountMissingRule | biz_data_rule_item_discount_missing.go | 折扣信息完整性（含项目制补全） |
| 15 | ItemDiscountProgressiveRule | biz_data_rule_item_discount_progressive.go | 阶梯报价折扣 |
| 16 | ItemDiscountZeroRule | biz_data_rule_item_discount_zero.go | SP/抵扣 0 元折扣限制 |
| 17 | ItemSpDiscountRule | biz_data_rule_item_sp_discount.go | SP 非 10 折策略（白名单 / 无抵扣计费项） |
| 18 | ItemDistributionDiscountRule | biz_data_rule_item_distribution_discount.go | BP 分销折扣合法性 |
| 19 | ItemDeliveryCostRule | biz_data_rule_item_delivery_cost.go | 手动非标品交付项成本/出厂价 |
| 20 | ItemEstimatedIncomeRequiredRule | biz_data_rule_item_estimated_income_required.go | 单项预计金额必填与大于 0 |
| 21 | ItemProgressivePriceDuplicateRule | biz_data_rule_item_progressive_price_duplicate.go | 配置清单/项目制交付项阶梯价去重 |
| 22 | ItemGuaranteePercentageRule | biz_data_rule_item_guarantee_percentage.go | 报价项保底比例合法性（含 Redis 读） |

### 6.4 Guarantee 桶（保底，CC=14）

| Rule | 文件 | 职责 |
|---|---|---|
| GuaranteeSupportRule | biz_data_rule_guarantee_support.go | 报价单是否支持保底 |
| GuaranteeItemsRule | biz_data_rule_guarantee_items.go | 保底关联报价项范围（抵扣计费项不参与） |
| GuaranteeValidityRule | biz_data_rule_guarantee_validity.go | 周期保底有效期 |
| GuaranteeTotalSeatsRule | biz_data_rule_guarantee_total_seats.go | 保底采购总席位数 |
| GuaranteeCarryForwardRule | biz_data_rule_guarantee_carry_forward.go | 补充协议保底结转 |

### 6.5 Rebate 桶（返佣，CC=15）

| Rule | 文件 | 职责 |
|---|---|---|
| RebateItemsSupportRule | biz_data_rule_rebate_items_support.go | 返佣关联报价项支持性 |

### 6.6 Coupon 桶（代金券，CC=16）

| Rule | 文件 | 职责 |
|---|---|---|
| CouponSupportRule | biz_data_rule_coupon_support.go | 代金券申请支持性 |
| CouponParamRule | biz_data_rule_coupon_param.go | 代金券参数合法性 |
| CouponValidityRule | biz_data_rule_coupon_validity.go | 代金券有效期合法性（跟随合同 + 指定月份区间） |

### 6.7 Credit 桶（信控，CC=17）

| Rule | 文件 | 职责 |
|---|---|---|
| CreditSupportRule | biz_data_rule_credit_support.go | 信控申请支持性（至少含公有云标品报价项） |

### 6.8 ResourcePage 桶（资源单，CC=18）

| Rule | 文件 | 职责 |
|---|---|---|
| ResourcePageInfoMissingRule | biz_data_rule_resource_page_info_missing.go | 资源单/资源卡一致性与缺失校验 |

### 6.9 FullQuote 桶（整单聚合校验，CC=19）

| Rule | 文件 | 职责 |
|---|---|---|
| FullQuoteBusinessDiscountsChangeRule | full_quote_rule_business_discounts_change.go | 审批中修改再次送审商务优惠范围一致性 |
| FullQuoteBusinessDiscountsRelatedRule | full_quote_rule_business_discounts_related.go | 关联报价项返佣/保底成对一致 |
| FullQuoteEstimatedIncomeConsistencyRule | full_quote_rule_estimated_income_consistency.go | 整单预计金额汇总/跨项一致性 |
| FullQuoteCouponTriggerRule | full_quote_rule_coupon_trigger.go | 代金券触发条件报价项归属、消费/统计商品匹配 |
| FullQuoteDeductDiscountLevelRule | full_quote_rule_deduct_discount_level.go | 抵扣报价项折扣上限（整单跨项） |

## 7. Review 检查清单

1. 对比 master 旧 Rule，确认输入集合是否一致：例如全状态报价项、正常报价项、交付项、代金券/信控申请项不可混用。
2. 确认拆分后每个 Rule 自身闭环，不通过依赖前置 Rule 的失败结果来维持正确性。
3. 检查相邻 Rule 是否重复校验同一用户修复动作；重复时合并到更贴近业务归属的 Rule。
4. 检查 ErrorMsg/BizErrorMsg 是否全部走 `i18nfmt.Sprintf`，BizErrorCode 是否一分支一唯一 CCRRNN 值。
5. Rule 是否注册到正确的桶，桶内顺序是否遵循"基础→复杂、轻量→重量"的原则。
6. 新增 Rule 后 `MustValidateRegistry` 是否通过（`go test ./biz/service_basic/engine_stage/...`）。
7. 删除解释性迭代注释、临时说明和无意义日志；保留的注释必须直接服务于当前业务规则边界。
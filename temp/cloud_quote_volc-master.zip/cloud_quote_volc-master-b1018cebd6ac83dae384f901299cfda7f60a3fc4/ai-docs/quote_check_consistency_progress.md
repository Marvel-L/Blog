# 报价送审/业务数据校验新老链路一致性进度

更新时间：2026-06-01

## 目标

对 `SubmitQuoteV2` 与 `QuoteBizDataCheck` 两个入口的新老链路进行业务数据校验、业务数据刷新逻辑对齐，并用对比单测固化关键语义，防止重构后行为漂移。

## 老链路梳理

### SubmitQuoteV2

入口：`biz/service/quote_service/submit_quote_v2.go:50`

主流程：

1. 分布式锁：`submit_quote_lock_{quoteID}`。
2. DB 事务内查询报价单：`FindQuoteByIDAndCustomerID`。
3. 准入校验：`processcheck.AllowQuoteOP(OpTypeSubmitQuote)`。
4. 加载业务数据：`assistant.CallbackWithQuote`，包含全状态报价项、交付项、报价项属性、算价信息、保底、补充协议、资源单/卡、合同、解决方案、配置清单、返佣、商品信息。
5. `ProcessBizDataByBizScene(QuoteBizSceneSubmitQuote)` 顺序执行业务 checker/refresher。
6. `processcheck.FullQuoteDataCheck(OpTypeSubmitQuote)` 执行整单校验。
7. 审批中修改分支只更新修改信息、通知、日志、CRM 回调。
8. 正常送审分支更新提交人与销售、状态流转，并刷新报价单基础字段。
9. 同步送审时提交 Lark 审批并再次流转状态。

`QuoteBizSceneSubmitQuote` 中的业务逻辑顺序（按权重排序）：

- Checker：`checkQuoteBaseInfo`、`checkConfigList`、`checkRelatedProduct`、`checkGuarantee`、`checkRebate`、`checkJointOrder`、`checkCommonApply`、`checkProductCustomerScope`、`checkCombineRule`、`checkCouponParam`、`checkProjectSupply`、`checkItemDiscount`、`checkDistributionDiscounts`、`checkEstimatedIncome`、`checkGuaranteedPercentage`、`checkZeroQuote`、`checkRatioChargeItem`、`checkResourcePage`、`checkItemEffective`、`checkItemSellingModeValid`、`checkRelatedChargeItem`、`checkUnStandardDeliveryItemCost`、`checkDeductDiscount`。
- Refresher：`refreshHeirItemDiscount`、`refreshProductInfo`、`refreshCalFactorData`、`refreshSelectAllExclude`、`refreshRelatedResDep`、`refreshQuoteItemInquiry`、`refreshQuoteItemTotalDiscount`。

### QuoteBizDataCheck

入口：`biz/service/quote_service/biz_data_check.go:36`

主流程：

1. 灰度命中新引擎且 `CheckerKeys` 为空才走新链路；指定 `CheckerKeys` 时保持历史局部校验语义。
2. 老链路 `CollectBizData` 使用 `assistant.Callback` 加载全状态报价项、交付项、报价项属性、算价、保底、补充协议、资源单/卡、合同、解决方案、配置清单、返佣、商品信息。
3. 准入校验：`processcheck.AllowQuoteOP(OpTypeSubmitQuote)`。
4. `CheckerKeys` 为空时填充 `allCheckerKeys`，否则只执行传入 checker。
5. `CheckBizData` 收集 checker 结果，不做 fail-fast。
6. 有 checker 结果时按历史 checker key 白名单计算 `CheckPass`。
7. 无 checker 结果时继续执行 `processcheck.FullQuoteDataCheck`，成功后返回 `CheckPass=true`。

`allCheckerKeys` 在 SubmitQuote checker 基础上额外包含 `checkRelatedQuoteItemBusinessDiscount`。

## 新链路梳理

### SubmitQuote

入口：`biz/service/quote_service_by_engine/submit_quote.go:38`

主流程：

1. 分布式锁与事务语义与老链路一致。
2. 查询报价单后构建 `QuoteContext`：`newSubmitQuoteBizDataRefreshContext` 初始只要求报价单存在，后续规则通过 `Needs()` 动态加载。
3. `processSubmitQuoteBizFlow` 执行：准入校验 → 前置刷新 → 业务数据校验 → 后置刷新。
4. SubmitQuote 配置：`BizFailFast=true`、`EnablePostRefresh=true`，并通过 `WithSkipBlockRules` 兼容新 RuleKey 与历史 checker key 白名单。

新链路拆分：

- 准入：`QuoteCanOperateRule`。
- 前置刷新：`QuoteBaseInfoRefresher`、`CleanRebateItemsIfNotSupportRefresher`、`SyncJointOrderRebatesIfSupportRefresher`、`CleanExpiredResourceItemsIfSupportRefresher`、`FullQuoteCouponTriggerInfoRefresher`。
- 业务规则：`QuoteBizOpTypeSubmitQuote` 绑定的 `checkQuoteBaseInfo`、`checkQuoteItem`、`checkGuaranteeItem`、`checkRebate`、`checkBizDiscount`、`checkCoupon`、`checkCredit`。
- 后置刷新：`HeirItemDiscountRefresher`、`ProductInfoRefresher`、`CalFactorDataRefresher`、`SelectAllExcludeRefresher`、`RelatedResDepRefresher`、`QuoteItemInquiryRefresher`、`QuoteItemTotalDiscountRefresher`。

### BizDataCheck

入口：`biz/service/quote_service_by_engine/biz_data_check.go:16`

主流程：

1. 查询报价单并构建 `QuoteContext`。
2. 复用 `processSubmitQuoteBizFlow`，但配置为 `OpType=QuoteBizOpTypeBizDataCheck`、`BizFailFast=false`、`EnablePostRefresh=false`。
3. 准入阻断直接返回错误。
4. 业务规则结果通过 `adaptEngineResultsToBizCheckResults` 转为历史 `CheckResult`，`CheckKey` 使用 `LegacyCheckerKey`。
5. `CheckPass` 通过 `ShouldSkipBlockRule` 同时兼容 RuleKey 与历史 checker key 白名单。

## 对比结论与待固化单测

| 优先级 | 逻辑 | 一致性要求 | 状态 |
|---|---|---|---|
| P0 | BizDataCheck 指定 `CheckerKeys` | 必须走老链路，保留局部校验 | 已有测试覆盖 |
| P0 | BizDataCheck 全量规则集 | 必须包含 `allCheckerKeys` 语义，额外包含关联报价项商务优惠 | 已有部分注册表测试，继续补齐 |
| P0 | BizDataCheck 后置刷新 | 必须关闭 SubmitQuote 后置刷新副作用 | 本轮补充流程测试 |
| P0 | SubmitQuote fail-fast | 业务阻断后不执行后置刷新/审批后续逻辑 | 本轮补充流程测试 |
| P0 | 白名单 | RuleKey 与历史 checker key 均可忽略阻断 | 已有测试覆盖 |
| P0 | 返回 CheckKey | 新链路返回历史 checker key，不暴露原子 RuleKey | 已有测试覆盖 |
| P1 | 前置刷新 | 承接老 checker 内 DB 写副作用，在业务规则前执行 | 本轮补充流程测试 |
| P1 | 后置刷新顺序 | 与老链路 `refresh*` 顺序保持一致，综合折扣前 reload | 待补充更细粒度刷新器测试 |
| P2 | 单个原子规则 | 每个 rule 与 legacy checker 分支输出一致 | 已有局部覆盖，后续按 rule 增量补齐 |

## 第二轮继续梳理结论

本轮继续补齐以下容易在后续改动中漂移的兼容点：

1. **BizDataCheck 入口灰度分流**：
   - `CheckerKeys` 非空：即使灰度开关命中新引擎，也必须保留老链路局部 checker 语义。
   - `CheckerKeys` 为空且注入了 `EngineBizDataCheck`：才允许委托新链路。
   - 命中新引擎但 `EngineBizDataCheck` 为空：必须安全回退老链路，避免 init 注入异常导致空指针。
2. **BizDataCheck 全量规则映射**：
   - `QuoteBizOpTypeBizDataCheck` 注册的所有规则都必须能映射到历史 checker key，否则前端 `CheckKey` 和白名单都会出现兼容问题。
   - 新链路 legacy key 集合必须覆盖老链路 `allCheckerKeys` 语义，尤其是 `checkRelatedQuoteItemBusinessDiscount`。
3. **刷新顺序与错误短路**：
   - SubmitQuote 新链路前置刷新器、后置刷新器顺序需要固定，避免与老链路权重顺序不一致。
   - `RefreshBizDataByQuoteContext` 必须在首个 refresher 报错时停止，保持老链路 `ProcessBizDataByBizScene/RefreshBizData` 的错误短路语义。

## 本轮执行记录

- 已准备单测环境，`BITS_TMP_ROOT=/var/folders/sx/4pgjc59x10v6cjd3xmpmbxl80000gn/T/tmp.RySWtrhnFJ`。
- 已补充流程级对比单测，固定 `processSubmitQuoteBizFlow` 的准入阻断、前置刷新、业务阻断、后置刷新开关语义：
  - 准入阻断时不执行前置刷新、业务校验、后置刷新。
  - BizDataCheck 使用 `QuoteBizOpTypeBizDataCheck`、`BizFailFast=false`，执行前置刷新但不执行 SubmitQuote 后置刷新。
  - SubmitQuote 业务校验通过后执行后置刷新，并回传刷新后的 `QuoteContext`。
  - SubmitQuote 业务校验阻断时不执行后置刷新。

### 本轮单测执行结果

已通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_HandleUsesOldPathWhenCheckerKeysSpecified_BitsUT|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys'
```

备注：测试输出中存在本地环境类日志（如 cgroup/TCC/Kitex 配置提示、`ld_classic` warning），不影响测试通过结论。

### 第二轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys'
```

第二轮新增覆盖：

- `check_engine`：
  - 校验 `QuoteBizOpTypeBizDataCheck` 下所有已注册规则均存在历史 checker key 映射。
  - 校验新链路 BizDataCheck legacy key 集合覆盖老链路全量 checker key 语义。
- `quote_service_by_engine`：
  - 校验 SubmitQuote 前置/后置 refresher 顺序固定，避免偏离老链路 processor 权重顺序。
  - 校验 `RefreshBizDataByQuoteContext` 遇到首个 refresher 错误即短路，不继续执行后续刷新器。
- `quote_service`：
  - 校验 `QuoteBizDataCheckReq.Handle` 在 `CheckerKeys` 为空且命中新引擎时委托 `EngineBizDataCheck`。
  - 校验 `EngineBizDataCheck` 未注入时安全回退老链路。

备注：第二轮测试同样存在本地环境类日志（cgroup/TCC/Kitex 配置提示、`ld_classic` warning、测试环境 configLoader 未初始化日志），测试结果均为 PASS。

### 第三轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第三轮新增覆盖：

- `quote_service_by_engine`：
  - 校验 `adaptEngineResultsToBizCheckResults` 只返回 warn/error 级别失败结果，过滤 pass 与 info 结果，并将新 RuleKey 适配为历史 checker key。
  - 校验 BizDataCheck 计算 `CheckPass` 时兼容历史 checker key 白名单，命中 `checkZeroQuote` 白名单时保持 `CheckPass=true`。
  - 校验 BizDataCheck 存在未白名单 error 阻断时返回 `CheckPass=false`。
  - 校验 BizDataCheck 准入阻断时直接返回错误，不包装成业务校验结果列表，保持老链路接口错误语义。
  - 校验基础信息 API 错误适配为历史业务校验失败响应，返回 `CheckPass=false` 与 `CodeNQuoteBaseInfoCheckFailed`。

备注：第三轮测试输出中仍存在本地环境类日志（cgroup/TCC/Kitex 配置提示、`ld_classic` warning、测试环境 configLoader 未初始化日志），测试结果为 PASS。

### 第四轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第四轮新增覆盖：

- `quote_service_by_engine`：
  - 校验 `ProcessSubmitQuoteBizDataRefresh` 包含两段 reload：后置刷新开始前 reload 全状态报价项/交付项/属性/商品/父项上下文，综合折扣计算前再次 reload 报价项/交付项/属性/算价/优惠/返佣/返券比例。
  - 校验 `QuoteItemTotalDiscountRefresher` 必须在综合折扣前 reload 之后单独执行，固化老链路综合折扣前重新 Callback 读取前序 refresher 落库结果的语义。

备注：第四轮测试输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第五轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys'
```

第五轮新增覆盖：

- `check_engine`：
  - 校验 `QuoteBizOpTypeSubmitQuote` 下所有注册业务规则均存在历史 checker key 映射，避免后续新增 RuleKey 后白名单和端上语义失配。
  - 校验 SubmitQuote 新链路 legacy checker key 集合覆盖老链路送审业务 checker 语义，包括基础信息、关联商品、保底、返佣、联合打单、通用申请、商品客户范围、组合规则、代金券参数、项目补充协议、配置清单、折扣、分销折扣、预计金额、保底比例、零元报价、比例计费项、资源单、报价项有效性/售卖模式、关联计费项、非标交付项成本、抵扣折扣等。
- `quote_service_by_engine`：
  - 校验 `firstBlockingResult` 只把 `Pass=false && BlockLevel=Error` 视为送审阻断，Pass/Warn/Info/nil 结果均不阻断主链路，固化白名单降级为 Warn 后不阻断送审的语义。

备注：第五轮测试输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果均为 PASS。补充过程中曾发现 SubmitQuote 的 `FullQuoteModifyDiscountRule` 会复用历史 `checkRelatedQuoteItemBusinessDiscount` 映射，已按当前注册语义修正测试为“覆盖老送审 checker key 集合”，不再误判为必须完全等于老集合。

### 第六轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys'
```

第六轮新增覆盖：

- `check_engine`：
  - 校验 `OpChecker.checkRules` 在执行规则前会汇总所有规则的 `Needs()`，按顺序去重后统一通过 `QuoteContextLoader.WithKeys(...).Load` 加载，并将加载后的 `QuoteContext` 回写到 checker，避免新链路“初始只加载 Quote”时遗漏规则依赖数据。
  - 校验加载动作发生在具体 rule `Check` 前，固化 “Needs 驱动按需加载 → 执行规则” 的执行顺序。
  - 校验 `FailFast=true` 时如果白名单把首个 error 结果降级为 `Warn/Pass`，后续规则仍会继续执行，确保 SubmitQuote 白名单语义与老链路一致。

备注：第六轮测试输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果均为 PASS。

### 第七轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine ./biz/service/quote_service -run 'TestRuleRegistry|TestShouldSkipBlockRule|TestWithSkipBlockRules|TestOpCheckerFailFast|TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_fillInCheckerKeys'
```

第七轮新增覆盖：

- `check_engine`：
  - 校验 `RuleRegistry` 在未注册 `opType`、`opType` 绑定了未注册 `checkKey` 时返回明确错误，避免新规则注册遗漏导致静默漏检。
  - 校验 `ShouldSkipBlockRule` 同时支持新 RuleKey、历史 checker key、未知 key 自身匹配、未命中与 nil 白名单边界，固化新老白名单 key 兼容语义。
  - 校验 `WithSkipBlockRules` 只改写“失败且命中白名单”的阻断结果，已通过结果、未命中白名单结果和 nil 结果均保持安全行为。
- `quote_service`：
  - 校验 `fillInCheckerKeys` 未指定时填充历史 `allCheckerKeys`，已指定时不覆盖，保持老链路全量/局部校验语义。
  - 校验 `QuoteBizDataCheckReq.Handle` 在 `CheckerKeys` 非空（包括只包含空字符串）时即使命中新引擎开关也回退老链路，避免新引擎全量校验误替代历史局部校验。
  - 校验开关关闭时即使注入 `EngineBizDataCheck` 也回退老链路。

备注：第七轮测试输出中仍存在本地环境类日志、`configLoader` 未初始化日志与 `ld_classic` warning，测试结果均为 PASS。

### 第八轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine -run 'TestAllNormalItems|TestQuoteItemTotalDiscountRefresher|TestRelatedResDepRefresher|TestQuoteBaseInfoRefresher|TestProcessSubmitQuoteBizDataRefreshReloadsBeforeTotalDiscount|TestRefreshBizDataByQuoteContextStopsAtFirstError|TestSubmitQuoteRefresherOrderMatchesLegacyProcessorWeights'
```

第八轮新增覆盖：

- `quote_service_by_engine`：
  - 校验 `allNormalItems` 在存在 `QuoteItemsAllStatus` 时优先使用全状态报价项，并始终追加交付项，固化新后置刷新读取“全状态报价项 + 交付项”的老链路语义。
  - 校验 `QuoteItemTotalDiscountRefresher` 使用当前 `QuoteContext` 的 `QuoteID`，且以 `Write=true`、`reCalculate=false`、`callback=nil` 调用综合折扣计算，确保综合折扣刷新会落库且不复用旧 callback。
  - 校验 `RelatedResDepRefresher.RefreshRelatedResDepartment` 按开关和白名单过滤交付项，忽略自动生成项和非交付项，对资源部门去重排序后写回 `Quote.RelatedResDepartment` 并落库。
  - 校验没有匹配资源部门时写回历史默认值 `multienv.OANone`，保持老链路兜底语义。
  - 校验 `QuoteBaseInfoRefresher` 会加载 `QuoteContextKeyOppInfo`，加载后恢复原始 Quote 指针，派生并只落库历史基础信息刷新涉及的 5 个字段：`customer_industry_info`、`price_entity_industry_info`、`sales_channel_type`、`parent_account_number`、`contract_price_acc`。

备注：第八轮测试输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第九轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine ./biz/service/quote_service_by_engine -run 'TestItemSellingModeValidRule|TestUnStandardDeliveryItemCostRule|TestProductInfoRefresher|TestCalFactorDataRefresher|TestQuoteItemInquiryRefresher'
```

第九轮新增覆盖：

- `check_engine`：
  - 校验 `ItemSellingModeValidRule` 只检查公有云报价项，私有化报价项不参与售卖模式阻断；多个非法报价项按 ID 排序写入 `Detail` 与错误信息，保持历史 checker 返回明细稳定性。
  - 校验 `UnStandardDeliveryItemCostRule` 只读取 `Persisted.DeliveryItems`，不误扫报价项；手动添加非标交付项的单位成本/出厂价必须均为固定金额且金额一致，否则只返回交付项 ID 明细。
- `quote_service_by_engine`：
  - 校验 `ProductInfoRefresher` 透传 `allNormalItems` 结果（全状态报价项 + 交付项）、报价项属性、商品信息列表和 Quote 给 `item_context.RefreshProductInfo`。
  - 校验 `CalFactorDataRefresher` 透传 `allNormalItems` 结果和 Quote 给 `item_context.RefreshCalFactorData`，并原样返回底层错误。
  - 校验 `QuoteItemInquiryRefresher` 调用询价刷新时删除项入参为 nil，新增项入参为 `allNormalItems` 结果，保持老链路“按当前报价项变更刷新询价”的入参语义。

备注：第九轮测试首次执行时 `check_engine` 测试文件缺少 `fmt` import 导致编译失败，已修复后重新执行通过；输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十轮单测执行结果

已新增并通过：

```bash
go test -gcflags="all=-N -l" ./biz/service/check_engine ./biz/service/quote_service_by_engine
```

第十轮新增覆盖：

- `check_engine`：
  - 校验 `RatioChargeItemRule` 只在比例计费项所在同一解决方案内查找比例关联计费项：同方案存在关联计费项时通过，移除同方案关联项后返回 `CodeNRatioChargeItemCheckFailed`。
  - 校验 `RelatedChargeItemRule` 在开关开启时基于已加载 QuoteContext 组装 `GetRelatedChargeItemsReq`，透传 Quote、QuoteItems 与按报价项聚合的 `RelatedChargeItemBizCtx`，并将下游失败明细原样放入 `Detail`。
  - 校验 `DeductDiscountRule` 在存在同口径本单按量报价项时优先使用本单按量折扣，不将该抵扣项加入合同价查询集合；抵扣折扣高于本单按量折扣时返回历史明细字段（抵扣项、关联 SP 包、本单按量报价项、按量折扣）。
- `quote_service_by_engine`：
  - 校验 `HeirItemDiscountRefresher` 仅对项目制补充协议生效，加载父报价项算价结果后刷新继承报价项固定价折扣，并同步自动生成继承交付项折扣，最终批量保存报价项和交付项两个 `QuoteItemValue`。

备注：第十轮首轮执行发现 3 类测试问题并已修复：`PriceInfoMap` 类型应使用 `item_context.ProductPriceInfo`；`mockey.GetMethod(..., "Save")` hook 入参应使用 `interface{}` 接收 data；本地未初始化 Starling 时需 mock `i18nfmt.Sprintf` / `multienv.GetGiveAwayTypeStd` 规避环境依赖。最终相关 package 全量测试通过；输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十一轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第十一轮新增覆盖：

- `quote_context`：
  - 校验 `QuoteContextLoader.WithKeys` 会在默认 Quote key 后按顺序追加业务指定 key，`WithReloadKeys` 多次调用会按顺序追加 reload key，固化流程编排中“默认加载 Quote + 按需追加”的加载语义。
  - 校验 `QuoteContextLoader.Load` 对同一 key 的普通加载会通过 `loadedKeys` 去重，不重复执行 loader；对 reload key 则会重新加载当前 key 及其依赖 key，保证前序刷新落库后重新读取依赖数据。
  - 校验 `Load` 在接入已有 `QuoteContext` 且 `loadedKeys=nil` 时会初始化缓存 map，并在加载结束后执行 `InputOption`，保证 BizDataCheck 入参配置能写入 `Inputs`。
- `quote_service_by_engine`：
  - 补充 `firstBlockingResult` 的 nil/空切片边界：nil 或空结果不阻断，仍仅 `Pass=false && BlockLevel=Error` 阻断送审主链路。
  - 校验 `runOpCheckByEngineWithQuoteContext` 根据 `opCheckPhaseAccess` / `opCheckPhaseBizData` / 默认全量阶段分别调用 `CheckOpAccess` / `CheckOpBizData` / `CheckOperation`，并透传 `OpType`、tx、QuoteContext、FailFast 等字段。
  - 校验 `RefreshBizDataByQuoteContext` 对 nil/空 refreshers 直接成功返回，保持无刷新器场景的幂等边界；已有错误短路用例继续覆盖首个错误透传语义。

备注：第十一轮相关 package 单测均通过；输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十二轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
```

第十二轮新增覆盖：

- `check_engine`：
  - 校验 `RelatedProductRule` 只检查报价项，忽略交付项；当报价项类型超出报价单 `QuoteRelatedProduct` 范围时返回 `CodeNQuoteNotSupportProductType`，当报价单声明的商品类型缺少对应报价项时返回 `CodeNQuoteShortOfProductType`。
  - 校验 `ProductCustomerScopeRule` 按 `TradeProduct` 聚合报价项 ID，基于已加载 `ProductInfoMap` 做客户范围匹配，未加载商品信息的报价项保持老链路语义不误报，失败明细只包含已加载且范围不匹配的报价项 ID。
  - 校验 `DistributionDiscountsRule` 在 BP 分销特殊折扣场景下复用预加载 `ItemContextMap`，同时检查报价项与交付项，并将 `ValidateDistributionDiscounts(ctx, nil)` 失败的 item ID 写入 `Detail`。
  - 校验 `RelatedBusinessDiscountRule` 在关联规则开关开启时，基于预加载报价项与 ItemContext 构造关联报价项映射；返佣均缺失时不报返佣差异，保底只覆盖单侧时返回 `missingBusinessDiscountDetail.MissingGuaranteeItemIDMap`。
- `quote_context`：
  - 追加验证 `loaderProductInfo` 依赖 keys、商品查询入参与错误返回：商品信息加载优先使用全状态报价项，并合并交付项、失效报价项、失效交付项；商品服务失败时返回“查询商品信息失败”业务错误且不写入 `ProductInfoMap`。

备注：第十二轮首次执行时 `ProductCustomerScopeRule` 单测触发本地 Starling 未初始化导致 `TradeType.GetCustomerScope()` panic，已通过 mock `multienv.GetOppNumberPrefixMap` 隔离环境依赖后重跑通过；输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十三轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第十三轮新增覆盖：

- `check_engine`：
  - 校验 `CustomerNameRule` / `PartnerNameRule` 与历史 `QuoteData.CustomerNameCheck` / `PartnerNameCheck` 的字段级语义一致：非内部、非 PRM、非 BytePlus 场景下报价单账号名必须与商机账号名一致，失败时分别返回 `CodeNCustomerNameCheckFailed` / `CodeNPartnerNameCheckFailed` 以及历史文案；BytePlus 场景保持老链路跳过语义。
  - 校验 `DistributionBizTypeRule` 与历史 `DistributionBizTypeCheck` 的三类分支一致：非 BP 分销客户填写分销业务类型返回 `DistributionBizTypeCode error`，BP 分销客户未填写返回 `DistributionBizTypeCode missing`，合法枚举通过。
  - 校验 `EffectiveInfoRule` 与历史 `EffectiveInfoCheck` 一致：按主体生效且缺少 `VerifiedName` 时返回 `CodeNEffectiveInfoCheckFailed` 及“按照主体生效报价单，主体信息缺失”。
  - 校验 `QuoteTypeRule` 与历史 `QuoteTypeCheck` 一致：报价类型枚举错误、PRM 报价不支持非普通报价、内部客户不支持阶梯报价三个分支均返回历史错误码与文案。

备注：第十三轮首次执行时客户/伙伴名称规则因 `Quote.IsInnerQuote()` 间接触发本地 Starling 未初始化 panic，已通过 mock `Quote.IsInnerQuote` / `Quote.IsPrmQuote` 隔离环境依赖后重跑通过；输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十四轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第十四轮新增覆盖：

- `check_engine`：
  - 校验 `TradeTypeRule` 与历史 `QuoteData.TradeTypeCheck` 一致：客户类型枚举错误、非 PRM 客户类型编码错误、国内生态客户类型缺少伙伴授权、BP 分销仅支持普通报价四类分支均返回历史错误码与文案。
  - 校验 `OrderTypeRule` 与历史 `QuoteData.OrderTypeCheck` 一致：签约方式枚举错误、内部报价仅支持官网自助下单、涉及私有云/解决方案/一体机时必须纸质签约、签约方式编码错误均保持历史输出。
  - 校验 `ProjectAttributesRule` 与历史 `QuoteData.ProjectAttributesCheck` 一致：项目属性逐项命中枚举时通过，任一属性未命中时返回 `CodeNProjectAttributesCheckFailed` 与“项目属性错误”。

备注：第十四轮新增用例通过 mock `multienv` 映射、`Quote.IsPrmQuote` / `Quote.IsInnerQuote` 等方法隔离本地 Starling / 多环境依赖；相关 package 单测均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第十五轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
```

第十五轮新增覆盖：

- `check_engine`：
  - 校验 `PriceValidPeriodRule` 与历史 `QuoteData.PriceValidPeriodCheck` 一致：涉及公有云但选择自签订之日起生效时返回固定日期限制；固定日期开始时间不早于结束时间返回历史错误；需要分销协议的客户类型授权有效期缺失返回“客户类型授权有效期信息不完整”；自签订之日起生效时间单位非法返回包含原始 JSON 的历史文案。
  - 校验 `PartnerContractNoRule` 与历史 `QuoteData.PartnerContractNoCheck` 一致：非需分销协议客户类型填写协议号、需协议但授权下无可用协议、协议号未命中授权、协议号命中授权通过四类分支均固化。
  - 校验 `RelatedAccountIDsRule` 与历史 `QuoteData.RelatedAccountIDsCheck` 一致：直销三账号字段一致性、直销账号归属商机客户、生态分销伙伴授权、集成解决方案伙伴 cuid 账号校验均保持历史错误码与文案。
  - 校验 `CustomerDetailRule` 与历史 `QuoteData.CustomerDetailCheckV2` / `CustomerDetailCheckBP` 一致：国内官网自助按账号生效客户 ID 必填、国内账号数量上限、企业实名认证、BytePlus 特殊报价客户 ID 必填与最终客户校验等关键分支均固化。

备注：第十五轮首次执行时 `PriceValidPeriodRule` 非固定日期分支因 `Quote.GetProductTypeMap` 在 `QuoteRelatedProduct` 为空时默认公有云，导致自签订之日起时间单位用例先命中商品类型限制；已改为显式设置私有云商品类型并 mock 官网自助签约方式后重跑通过。输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果为 PASS。

### 第十六轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys|TestSubmitQuoteV2Req'
```

第十六轮新增覆盖：

- `check_engine`：
  - 校验 `QuoteNotesRule` 与历史 `QuoteData.QuoteNotesCheck` 一致：报价逻辑为空时返回 `CodeNQuoteNotesCheckFailed` 与“报价逻辑必填”，非空时通过。
  - 校验 `ChangeInfoRule` 与历史 `QuoteData.ChangeInfoCheck` 一致：非变更场景填写变更内容返回历史错误；变更内容超过 1000 字返回“变更内容长度最大1000”；变更补充协议场景合法内容通过。
  - 校验 `GiveAwayInfoRule` 与历史 `QuoteData.GiveAwayInfoCheck` 一致：赠送场景为空跳过；非法赠送场景、赠送原因缺失、赠送原因超过 1000 字均返回历史错误码与文案。
  - 校验 `LongLifeReasonRule` 与历史 `QuoteData.LongLifeReasonCheck` 一致：固定日期有效期超过 5 年且未填写原因时返回“合同有效期超过5年，请说明原因”；未超过 5 年通过；长有效期原因超过 1000 字返回历史错误。
  - 校验 `EstimatedTradingTimeRule` 与历史 `QuoteData.EstimatedTradingTimeCheck` 一致：预估上量时间为空跳过；固定日期场景晚于结束月份返回 `EstimatedTradingTime is not in PriceValidPeriod `；区间内通过；自签订之日起场景早于本月初返回历史错误。
  - 校验 `TradeProductTypeRule` 与历史 `QuoteData.TradeProductTypeCheck` 一致：非项目制涉及非标品、阶梯报价非纯公有云、BP 分销特殊报价非纯公有云均返回历史错误；只包含公有云时通过。

备注：第十六轮首次执行时测试使用了不存在的 `multienv.SceneNewQuote` 常量，已改为历史新购场景 `multienv.SceneNew` 后重跑通过；`GiveAwayInfoRule`、`TradeProductTypeRule` 用例通过 mock 多环境枚举/分销特殊报价判断隔离环境依赖。输出中仍存在本地环境类日志、`configLoader` 未初始化日志与 `ld_classic` warning，测试结果均为 PASS。

### 第十七轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context
go test -v -gcflags="all=-l -N" ./biz/service/quote_service_by_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_service -run 'TestQuoteBizDataCheckReq_Handle|TestQuoteBizDataCheckReq_checkQuoteBizData|TestQuoteBizDataCheckReq_CollectBizData|TestQuoteBizDataCheckReq_fillInCheckerKeys|TestSubmitQuoteV2Req'
```

第十七轮新增覆盖：

- `check_engine`：
  - 校验 `ProgressiveInfoRule` 与历史 `QuoteData.ProgressiveInfoCheck` 一致：非阶梯报价填写阶梯信息返回历史错误；单账号阶梯报价选择合并累计返回“单账号阶梯报价，阶梯累计类型只允许选择独立累计”；多账号合并累计通过。
  - 校验 `MdInfoRule` 与历史 `QuoteData.MdInfoCheck` 一致：非 BytePlus 场景跳过；BytePlus + CRM 来源下主数据 JSON 解析失败返回 `CodeNMDInfoCheckFailed` 与原解析错误。
  - 校验 `SolutionInfoRule` 与历史 `QuoteData.SolutionInfoCheck` 一致：项目制多产解账号、飞书账号查询失败、单个账号未命中均返回历史错误码与文案。
  - 校验 `QuoteEstimateBySalesRule` 与历史 `QuoteData.QuoteEstimateBySalesCheck` 一致：涉及公有云且预估销售金额为零返回历史错误；仅涉及私有云且金额为零通过。
  - 校验 `ProjectQuoteDataRule` 与历史 `QuoteData.ProjectQuoteDataCheck` 一致：非项目制跳过；项目制立项说明为空、项目编码/名称为空分别返回历史错误。
  - 校验 `BackdatingRule` 与历史 `QuoteData.BackdatingCheck` 一致：非倒签跳过；非纸质签约、原因缺失、需关联合同但合同号为空、合同号不存在均返回历史错误；原因与合同均合法时通过。
  - 校验 `EstimatedTradingMonthlyIncomeRule` 与历史 `QuoteData.EstimatedTradingMonthlyIncomeCheck` 一致：配置清单跳过；非配置清单预估上量月收入大于销售预估金额返回历史错误；小于等于时通过。
  - 校验 `PublicCloudEstimateRule` 与历史 `QuoteData.PublicCloudEstimateCheck` 一致：配置清单公有云标品预估金额大于 0、非配置清单金额小于 0、金额大于总销售预估金额均返回历史错误；合法范围通过。

备注：第十七轮先确认 `QuoteNotesRule` / `ChangeInfoRule` / `GiveAwayInfoRule` / `LongLifeReasonRule` / `EstimatedTradingTimeRule` / `TradeProductTypeRule` 仅存在一份测试，未重复追加；`BackdatingRule` 用例通过 mock `GetContractTypePaperContract`、`GetOppNumberPrefixMap` 与倒签原因/合同查询隔离 Starling 与外部合同 RPC。输出中仍存在本地环境类日志、`configLoader` 未初始化日志与 `ld_classic` warning，测试结果均为 PASS。

### 第十八轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(Rebate|Guarantee|ZeroQuote|ProjectSupply)RuleMirrorsLegacy'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context ./biz/service/quote_service_by_engine ./biz/service/quote_service
```

第十八轮新增覆盖：

- `check_engine`：
  - 校验 `RebateRule` 与历史 `RebateChecker` 一致：无返佣项通过；不支持返佣但仍有返佣脏数据时保持历史软删后通过语义；特殊返佣关联报价项不存在、关联私有云报价项、抵扣计费项设置返佣分别返回历史错误码与文案。
  - 校验 `GuaranteeRule` 与历史 `GuaranteeChecker` 一致：无保底信息通过；报价单不支持保底、部分保底未绑定有效报价项、周期保底开始月份早于报价单生效月份、抵扣计费项参与保底均返回历史错误码与文案。
  - 校验 `ZeroQuoteRule` 与历史 `ZeroQuoteChecker` 一致：普通非零报价项通过；赠送报价项缺少赠送场景/原因且非纸质签约时拼接多条历史错误；0 元刊例价报价项非纸质签约且缺少同组非零项时拼接历史错误；存在同税率同部署方式非零报价项时通过。
  - 校验 `ProjectSupplyRule` 与历史 `ProjectSupplyChecker` 一致：非项目制补充协议跳过；续约增购开始时间未晚于父合同结束时间、仅增购开始时间早于父合同开始时间、无默认生成项且无增购行为均返回历史错误；存在购买数量增购行为时通过。

备注：第十八轮首次执行时 `RebateRule` / `GuaranteeRule` / `ZeroQuoteRule` 的错误文案分支因本地 Starling client 未初始化触发 panic，已在测试内 mock `starling_client.GetTextWithLang` 为 key 原样返回以隔离国际化环境依赖后重跑通过；`ZeroQuoteRule` 同时通过 mock 赠送类型/纸质签约枚举固定历史判断分支。输出中仍存在本地环境类日志与 `ld_classic` warning，测试结果均为 PASS。

### 第十九轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(DistributorInfo|JointPrintOrder|ConfigList|GuaranteePercentage)RuleMirrorsLegacy'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context ./biz/service/quote_service_by_engine ./biz/service/quote_service
```

第十九轮新增覆盖：

- `check_engine`：
  - 校验 `DistributorInfoRule` 与历史 `DistributorInfoChecker` 一致：非 BP 分销特殊报价保持跳过；BP 分销特殊报价缺少最新分销商信息，最终客户、一级分销商、二级分销商信息变化均返回历史错误；分销商信息一致时通过。
  - 校验 `JointPrintOrderRule` 与历史 `JointPrintOrderChecker` 一致：支持返佣但缺少联打信息、不支持返佣但传入联打信息、联打 JSON 非法、协作人账号失效、报价单联打信息与商机不一致、返佣政策与 PRM 不一致均返回历史错误；商机与 PRM 均一致时通过。
  - 校验 `ConfigListRule` 与历史 `ConfigListChecker` 一致：非配置清单且非项目制报价单保持跳过；相同标品配置计费项存在两条阶梯成本价或阶梯出厂价时返回历史错误；非阶梯价格类型时通过。
  - 校验 `GuaranteePercentageRule` 与历史 `GuaranteedPercentageChecker` 一致：配置清单场景跳过；多账号部分缺少保底比例、多账号保底比例不一致、报价项不支持填写保底比例、支持但未配置、保底比例值非法均返回历史错误；保底比例均合法时通过。

备注：第十九轮补充过程中发现联打规则仍读取已移除的冗余 `External.Opportunity` 结构，已同步改为通过 `QuoteContextKeyOppInfo` / `External.OppInfo.JointPrintInfo` 读取商机联打信息，保持与 `QuoteContext` 合并后的上下文结构一致；新增用例继续 mock Starling 文案返回，隔离本地 i18n 环境依赖。相关 package 全量单测均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(EstimatedIncome|ItemDiscount)RuleMirrorsLegacy'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context ./biz/service/quote_service_by_engine ./biz/service/quote_service
```

第二十轮新增覆盖：

- `check_engine`：
  - 校验 `EstimatedIncomeRule` 与历史 `EstimatedIncomeChecker` 一致：配置清单场景跳过；预计用量流程下支持预计金额但未填写、报价项预计金额均为 0 均返回历史错误；预计金额流程下公有云标品折后预计金额小于等于 0、公有云预估金额与公有云报价项折后预计金额之和不一致、SP 包预计金额小于抵扣项预计金额总和均返回历史错误；金额一致且 SP 包可覆盖抵扣项时通过。
  - 校验 `ItemDiscountRule` 与历史 `ItemDiscountChecker` 一致：报价项缺少折扣信息、项目制简单折扣未补全、节省计划商品 0 折扣、抵扣计费项 0 折扣、节省计划商品非 10 折但存在抵扣计费项均返回历史错误；普通报价项合法折扣通过，并固化非法抵扣项明细。

备注：第二十轮新增预计金额流程用例时，部分分支会间接调用赠送类型多语言枚举，已复用 `mockStarlingTextByKeyForRuleTest` 隔离本地 Starling 依赖；SP 包预计金额用例需先保证公有云预估金额与非抵扣公有云报价项金额一致，才能进入 SP 包与抵扣项金额比较分支。相关 package 全量单测均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十一轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(ResourcePage|CouponParam|CombineRuleRule|ItemEffective).*MirrorsLegacy|TestQuoteBaseInfoBasicAndMaxItemNumRulesMirrorLegacy'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -v -gcflags="all=-l -N" ./biz/service/quote_context ./biz/service/quote_service_by_engine ./biz/service/quote_service
```

第二十一轮新增覆盖：

- `check_engine`：
  - 校验 `ResourcePageRule` 与历史 `ResourcePageChecker` 一致：BytePlus 环境跳过；未填写资源单且配置强制填写时报资源单缺失；已填写资源单但 DB 缺失实时匹配资源卡时报资源卡缺失；实时匹配资源卡均存在于 DB 时通过。
  - 校验 `CouponParamRule` 与历史 `CouponParamChecker` 一致：批量校验开关关闭跳过；代金券参数校验失败但拦截开关关闭时通过；拦截开关开启时返回历史错误码与 RPC 错误文案；全部代金券参数合法时通过。
  - 校验 `CombineRuleRule` 与历史 `CombineRuleChecker` 一致：没有解决方案报价项时跳过；组合规则校验失败时返回历史错误码与文案；组合规则校验成功时通过，并固化向 `rule_check.CheckRelatedProduct` 透传的商品集合与规则列表。
  - 校验 `ItemEffectiveRule` 与历史 `ItemEffectiveChecker` 一致：报价项与交付项均为空时通过；报价项有效性校验返回失效文案时转换为历史错误码；无失效文案时通过。
  - 校验 `QuoteBaseInfoBasicRule` / `MaxItemNumRule` 与历史 `QuoteBaseInfoChecker` 基础本地校验一致：无报价项、草稿报价项、不支持 SP 商品、项目制缺少手工交付项、未立项商品缺少产品线、报价项与交付项数超过配置上限均返回历史错误。

备注：第二十一轮资源单规则中 `SupportResourcePage` 会间接访问贸易类型多语言枚举，已在测试辅助构造函数中 mock Starling 文案返回，隔离本地 i18n 环境依赖；`ItemEffectiveRule` 通过 mock 内联 `validateQuoteItems` 聚焦 Rule 对历史错误码/文案转换的兼容语义；本轮相关 package 全量单测均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十二轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(CouponAndCreditApplyRulesMirrorLegacyCommonApplyCheckers|FullQuoteCouponValidityRangeAndTriggerItemRulesMirrorLegacySubmitQuoteChecker|FullQuoteModifyDiscountRuleMirrorsLegacySubmitQuoteChecker)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
go test -gcflags="all=-l -N" ./biz/service/processcheck
go test -gcflags="all=-l -N" ./biz/service/quote_context ./biz/service/quote_service_by_engine ./biz/service/quote_service
```

第二十二轮新增覆盖：

- `check_engine`：
  - 校验 `CouponApplyRule` 与历史 `CouponApplyChecker` 一致：无代金券申请条目时跳过；存在代金券申请但报价单不支持代金券时返回 `CodeNCommonApplyCheckFailed` 与历史文案；报价单支持代金券时通过。
  - 校验 `CreditApplyRule` 与历史 `CreditApplyChecker` 一致：无信控申请条目时跳过；存在信控申请但报价单不支持信控、或缺少公有云标品报价项时返回 `CodeNCommonApplyCheckFailed` 与历史文案；支持信控且存在公有云标品报价项时通过。
  - 校验 `FullQuoteCouponValidityRangeRule` 与历史 `checkerQuoteSubmit.FullQuoteDataCheck` 中代金券有效期范围分支一致：指定月份开始早于报价单合同开始月份、结束晚于报价单合同结束月份时返回历史错误文案；有效期位于合同范围内时通过。
  - 校验 `FullQuoteCouponTriggerItemRule` 与历史整单校验中触发条件报价项分支一致：触发报价项不存在时返回 `CodeNValidateCouponTriggerInfoFailed` 与历史文案；触发报价项与参与账单金额计算商品匹配时通过。
  - 校验 `FullQuoteModifyDiscountRule` 与历史审批中修改整单校验一致：非审批修改流程跳过；审批修改后商务优惠数量不一致时返回 `CodeNCanNotSubmitQuote` 与历史文案；优惠集合一致时通过；并固化历史 `isSame` 的“长度相同即通过”兼容语义，避免重构后意外收紧。

备注：第二十二轮继续通过 `mockStarlingTextByKeyForRuleTest` 隔离商务优惠/申请类型文案的本地 Starling 依赖；相关定向与回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十三轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(DownstreamQuoteItemRulesMirrorLegacyCheckerBoundarySemantics|DeductDiscountRuleMirrorsLegacyDeductDiscountCheckerBoundarySemantics)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十三轮新增覆盖：

- `check_engine`：
  - 校验 `RelatedChargeItemRule` 与历史 `RelatedChargeItemChecker` 一致：关联计费项校验开关关闭时跳过且不调用下游；下游未返回失败明细时通过；下游失败明细透传历史错误码、文案与详情。
  - 校验 `RatioChargeItemRule` 与历史 `RatioChargeItemChecker` 一致：无报价项时通过；比例计费项缺少同解决方案内关联计费项时返回 `CodeNRatioChargeItemCheckFailed`；通过 `GetRatioChargeItemKey()` 匹配到同方案关联计费项时通过。
  - 校验 `UnStandardDeliveryItemCostRule` 与历史 `UnStandardDeliveryItemCostChecker` 一致：校验开关关闭时跳过；配置清单场景跳过；仅检查手工非标交付项，固定成本与固定出厂价一致时通过。
  - 校验 `DeductDiscountRule` 与历史 `DeductDiscountChecker` 一致：无抵扣报价项时通过；抵扣报价项关联 SP 包不存在时返回系统错误；无本单按量折扣时使用合同价折扣兜底并返回历史明细字段；抵扣折扣低于合同价折扣时通过。

备注：第二十三轮继续通过 mock 配置开关、下游关联计费项服务、`DeductDiscountRule.getContractDiscounts` 与 Starling 文案返回隔离外部依赖，聚焦 Rule 与历史 checker 的边界语义一致性；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十四轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(FullQuoteCouponFollowContractRuleMirrorsLegacySubmitQuoteCheckerBoundarySemantics|ItemSellingModeValidRuleMirrorsLegacyCheckerBoundarySemantics)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十四轮新增覆盖：

- `check_engine`：
  - 校验 `FullQuoteCouponFollowContractRule` 与历史 `checkerQuoteSubmit.FullQuoteDataCheck` 中“自签订之日起”代金券规则一致：非自签订之日起生效时不限制代金券规则有效期；自签订之日起且代金券规则有效期为空时保持历史跳过语义；规则有效期跟随合同时通过；规则有效期非跟随合同时返回历史错误文案。
  - 校验 `ItemSellingModeValidRule` 与历史 `ItemSellingModeValidChecker` 一致：无报价项时跳过且不依赖 `ItemContextMap`；私有云报价项不调用售卖模式合法性校验；报价项缺少 `ItemContext` 时返回历史系统错误；`IsValidSellingMode` 依赖返回错误时原样透传。

备注：第二十四轮聚焦前序仅有单点覆盖的整单代金券跟随合同规则与报价项售卖模式规则，补齐历史 checker 边界语义；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十五轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(RuleRegistryAccessRulesBindQuoteCanOperate|QuoteCanOperateRuleMirrorsLegacyAccessCheckerBoundarySemantics)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十五轮新增覆盖：

- `check_engine`：
  - 校验 `RuleRegistry` 对 `SubmitQuote` / `BizDataCheck` 两个 `OpType` 均绑定 `OpAccessRuleQuoteCanOperate`，避免新链路绕过历史操作准入前置校验。
  - 校验 `QuoteCanOperateRule` 与历史 `processcheck` 操作准入公共语义一致：`QuoteContext` 为空时返回不可操作错误；新版配置清单开关开启时配置清单不允许送审；审批中修改允许已提交报价单操作；非审批修改且报价单已提交时返回不可操作错误；审批前状态允许操作。

备注：第二十五轮聚焦新引擎 access rule 层，补齐前序主要覆盖 BizDataRule 后遗漏的操作准入规则注册与边界语义；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十六轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'TestValidateFullQuoteTriggerQuoteItemIDListMirrorsLegacySubmitQuoteCheckerBoundarySemantics_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十六轮新增覆盖：

- `check_engine`：
  - 校验 `ValidateFullQuoteTriggerQuoteItemIDList` 与历史 `processcheck.ValidateTriggerQuoteItemIDList` 边界语义一致：参与消费金额计算商品为空时返回历史错误；触发报价项列表为空时自动按参与商品回填非抵扣报价项并标记 `needUpdate`；参与计算报价项不存在、不在参与商品范围内、或为抵扣计费项时分别返回历史错误码与文案。
  - 校验按消费金额比例返券场景下统计字段兼容逻辑：未传统计商品/统计报价项时兜底使用计算商品/计算报价项并标记 `needUpdate`；计算商品不是统计商品子集、计算报价项不是统计报价项子集时返回历史错误；统计商品与报价项完整匹配时通过。

备注：第二十六轮聚焦 `FullQuoteDataRule` 与 `FullQuoteCouponTriggerItemRule` 共用的触发报价项校验辅助函数，补齐前序仅通过整单规则间接覆盖的直接边界语义；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十七轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(PartnerContractNoRuleMirrorsLegacyPartnerContractNoCheck|ConfigListRuleMirrorsLegacyConfigListChecker)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十七轮新增覆盖：

- `check_engine`：
  - 补齐 `PartnerContractNoRule` 与历史 `QuoteData.PartnerContractNoCheck` 的剩余关键边界：内部报价 / PRM 报价直接跳过；生态解决方案使用当前客户类型口径；需要分销协议且授权下存在可用协议时空 `PartnerContractNo` 通过但 Rule 不写回报价单；多个协议号逗号分隔时逐个 `TrimSpace`、忽略空段并校验授权命中。
  - 补齐 `ConfigListRule` 与历史 `ConfigListChecker` 的配置清单交付项成本边界：未加载 `DeliveryItemUnitCost` 时跳过通过；同为阶梯价但属于不同「标品 + 配置 + 计费项」key 时通过；同 key 下即使只有一个交付项是阶梯成本价、只要该 key 下存在多条交付项也保持历史阻断语义；nil 成本请求 / nil 成本对象安全跳过不误阻断。
  - 顺带对齐 `RuleRegistryBizDataRulesBindFullQuoteRulesToRelatedChecks_BitsUT` 中 SubmitQuote 规则集合断言，适配本轮外部变更将 `checkRelatedBizDiscount` 绑定到 SubmitQuote 后的注册语义。

备注：第二十七轮聚焦前序已有测试但仍存在细粒度边界空缺的分销协议与配置清单规则；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志（cgroup/TCC/Kitex 配置提示）与 `ld_classic` warning。

### 第二十八轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(GuaranteeRuleMirrorsLegacyGuaranteeChecker|JointPrintOrderRuleMirrorsLegacyJointPrintOrderChecker|GuaranteePercentageRuleMirrorsLegacyGuaranteedPercentageChecker)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十八轮新增覆盖：

- `check_engine`：
  - 补齐 `GuaranteeRule` 与历史 `GuaranteeChecker` 的保底总席位数校验失败分支：当 `ValidateGuaranteeTotalSeats` 判定保底报价项包含特定白名单商品但保底采购总席位数为 0 时，返回历史错误码 `CodeNGuaranteeTotalSeatsInvalid`、历史文案，并在 `Detail` 中携带保底明细 ID。
  - 补齐 `JointPrintOrderRule` 与历史 `JointPrintOrderChecker` / `QuoteData.JointPrintOrderCheck` 的协作人边界：`Support=true` 且 Lark 账号查询失败时返回历史协作人获取失败文案；`Support=false` 但填写 `Collaborator` 时返回历史“不支持联合打单，协作人应为空”错误。
  - 补齐 `GuaranteePercentageRule` 与历史 `GuaranteedPercentageChecker` 的报价项过滤语义：仅遍历 `Persisted.QuoteItems` 中存在且能在 `ItemContextMap` 命中的报价项，跳过缺失上下文与额外上下文，避免将交付项/失效项等非报价项上下文纳入保底比例校验。

备注：第二十八轮聚焦保底、联合打单、保底比例三个规则的下游失败/过滤边界，继续通过 mock 配置开关、Lark 查询、保底席位数校验与 Starling 文案返回隔离外部依赖；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

### 第二十九轮单测执行结果

已新增并通过：

```bash
go test -v -gcflags="all=-l -N" ./biz/service/check_engine -run 'Test(RelatedBusinessDiscountRuleMirrorsLegacyRelatedQuoteItemBusinessDiscountCheckerBoundarySemantics|ValidateFullQuoteTriggerQuoteItemIDListMirrorsLegacySubmitQuoteCheckerBoundarySemantics)_BitsUT'
go test -v -gcflags="all=-l -N" ./biz/service/check_engine
```

第二十九轮新增覆盖：

- `check_engine`：
  - 补齐 `RelatedBusinessDiscountRule` 与历史 `RelatedQuoteItemBusinessDiscountChecker` 的关联商务优惠边界：关联规则配置开关关闭时直接跳过；返佣缺失原因只按“公有云在线 + 非 SP 抵扣 + 报价项场景”的上下文查询 PRM；PRM 返回的 `RebateRange` 原样写入缺失原因；PRM 未返回的缺失报价项按历史语义兜底为 `none`；PRM 查询失败时保持错误透传。
  - 继续补齐 `ValidateFullQuoteTriggerQuoteItemIDList` 与历史 `processcheck.ValidateTriggerQuoteItemIDList` / 统计触发信息校验分支：计算报价项不存在、参与商品下无报价项、统计报价项不存在、统计报价项不在统计商品范围、统计抵扣项、统计商品不在当前报价单、统计商品下无报价项、计算报价项不是统计报价项子集等均返回历史错误码与文案。

备注：第二十九轮聚焦全量 BizDataCheck 额外关联商务优惠规则与整单代金券触发信息 helper 的剩余分支；相关定向与 `check_engine` package 全量回归测试均通过，输出中仍存在本地环境类日志与 `ld_classic` warning。

## 后续可接力项

1. 前序预计收尾项已覆盖：`QuoteCanOperateRule`、`RelatedProductRule`、`ProductCustomerScopeRule`、`DistributionDiscountsRule`、`RelatedBusinessDiscountRule`、`loaderProductInfo`，以及基础信息类 `CustomerNameRule`、`PartnerNameRule`、`DistributionBizTypeRule`、`EffectiveInfoRule`、`QuoteTypeRule`、`TradeTypeRule`、`OrderTypeRule`、`ProjectAttributesRule`、`PriceValidPeriodRule`、`PartnerContractNoRule`、`RelatedAccountIDsRule`、`CustomerDetailRule`、`QuoteNotesRule`、`ChangeInfoRule`、`GiveAwayInfoRule`、`LongLifeReasonRule`、`EstimatedTradingTimeRule`、`TradeProductTypeRule`、`ProgressiveInfoRule`、`MdInfoRule`、`SolutionInfoRule`、`QuoteEstimateBySalesRule`、`ProjectQuoteDataRule`、`BackdatingRule`、`EstimatedTradingMonthlyIncomeRule`、`PublicCloudEstimateRule`、`RebateRule`、`GuaranteeRule`、`ZeroQuoteRule`、`ProjectSupplyRule`、`DistributorInfoRule`、`JointPrintOrderRule`、`ConfigListRule`、`GuaranteePercentageRule`、`EstimatedIncomeRule`、`ItemDiscountRule`、`ResourcePageRule`、`CouponParamRule`、`CombineRuleRule`、`ItemEffectiveRule`、`QuoteBaseInfoBasicRule`、`MaxItemNumRule`、`CouponApplyRule`、`CreditApplyRule`、`FullQuoteCouponValidityRangeRule`、`FullQuoteCouponTriggerItemRule`、`FullQuoteModifyDiscountRule`、`FullQuoteCouponFollowContractRule`、`ItemSellingModeValidRule`、`RelatedChargeItemRule`、`RatioChargeItemRule`、`UnStandardDeliveryItemCostRule`、`DeductDiscountRule`、`ValidateFullQuoteTriggerQuoteItemIDList` 均已有核心字段级一致性单测。
2. 若继续深入，可继续针对剩余报价项下游规则组合、外部 RPC/DB 加载路径做历史 checker 字段级对比，尤其关注需要跨服务加载上下文或按需加载缓存的复杂分支。
3. 若后续新规则继续合入，需要同步检查 `LegacyCheckerKey`、BizDataCheck/SubmitQuote OpType 绑定、白名单语义和返回 `CheckKey` 是否保持历史兼容。

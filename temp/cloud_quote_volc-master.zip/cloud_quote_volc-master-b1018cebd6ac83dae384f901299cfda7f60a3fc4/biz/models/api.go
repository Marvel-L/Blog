package models

type RawResult interface {
	Flag()
}

type BaseRawResult struct {
}

func (b BaseRawResult) Flag() {
}

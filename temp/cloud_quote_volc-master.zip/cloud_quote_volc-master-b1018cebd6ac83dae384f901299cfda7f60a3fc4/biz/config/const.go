package config

const (
	EnumsKeySalesDepartment          = "SalesDepartment"          // 销售所属行业
	EnumsKeySolutionDepartment       = "SolutionDepartment"       // 解决方案所属行业
	EnumsKeyRelatedResDepartment     = "RelatedResDepartment"     // 资源方
	EnumsKeyDiscountLineTypeApproval = "DiscountLineTypeApproval" // 折扣线类型审批流
	EnumsKeyQuoteKaniRolesMapping    = "QuoteKaniRolesMapping"    // 报价&Kani角色映射
	EnumsKeyLabelMarketARRMapping    = "LabelMarketARRMapping"    // 市场公有云消耗标签&金额映射
)

const (
	SwitchProductMatchConstraint               = "ProductMatchConstraint"
	SwitchChargeItemMatchConstraint            = "ChargeItemMatchConstraint"
	SwitchCheckConfigIsPublic                  = "CheckConfigIsPublic"
	SwitchApprovalTimeOutAlarmForceExec        = "ApprovalTimeOutAlarmForceExec"
	SwitchApprovalTimeoutAlarmOPForceExec      = "ApprovalTimeoutAlarmOPForceExec"
	SwitchApprovalTimeOutAlarmExec             = "ApprovalTimeOutAlarmExec"
	SwitchApprovalTimeOutSaleOPExec            = "ApprovalTimeOutSaleOPExec"
	SwitchApprovalTimeoutRuleCheck             = "ApprovalTimeoutRuleCheck"
	SwitchApprovalTimeoutRuleBlackRoles        = "ApprovalTimeoutRuleBlackRoles"
	SwitchListConfigChargeItemMaxNum           = "ListConfigChargeItemMaxNum"
	SwitchGetDiscountCategoryV3                = "GetDiscountCategoryV3"
	MockControlResource                        = "MockControlResource"
	SwitchBPStartC360                          = "SwitchBPStartC360"
	SwitchLarkFormOptionAudit                  = "LarkFormOptionAudit"
	SwitchLarkFormOptionAuditDepartment        = "LarkFormOptionAuditDepartment"
	SwitchLarkFormOptionAuditBizLine           = "LarkFormOptionAuditBizLine"
	SwitchUseDefaultProductRate                = "UseDefaultProductRate"
	SwitchRelatedChargeItemChecker             = "RelatedChargeItemChecker"
	SwitchSkipCheckProjectDelivery             = "SkipCheckProjectDelivery"
	SwitchQuantityPriceSkipDepartment          = "QuantityPriceSkipDepartment"
	SwitchExceedThreeSkipBizLine               = "ExceedThreeSkipBizLine"
	SwitchSkipItemValidate                     = "SkipItemValidate"
	SwitchRelatedResDepartmentCode             = "RelatedResDepartmentCode"
	SwitchAmountLengthLimit                    = "AmountLengthLimit"          // 算价结果金额长度限制开关
	SwitchDraftQuoteExpiredAutoCheck           = "DraftQuoteExpiredAutoCheck" // 超长周期草稿报价单自动过期检查开关
	SwitchGetUserRolesWithCache                = "GetUserRolesWithCache"
	SwitchSubmitQuote                          = "SubmitQuote"
	SwitchCheckSpDiscountWhiteList             = "CheckSpDiscountWhiteList"
	SwitchScanSpInfo                           = "ScanSpInfo"
	SwitchRelatedChargeItemConfig              = "RelatedChargeItemConfig" // 关联报价项相关配置校验开关
	SwitchTrustedTopServiceList                = "TrustedTopServiceList"
	SwitchTopServiceCode                       = "TopServiceCodeMapping"
	SwitchApprovalInfoRolePermissions          = "ApprovalInfoRolePermissions"          // 审批自助信息角色权限
	SwitchMetricDeviationSupportDepartment     = "MetricDeviationSupportDepartment"     // 指标偏离支持的产品线
	SwitchBuildApprovalToOneService            = "BuildApprovalToOneService"            // 构建审批调用OneService
	SwitchMatchApprovalRule                    = "MatchApprovalRule"                    // 匹配审批规则开关
	SwitchApprovalRuleHitDetailNewFields       = "ApprovalRuleHitDetailNewFields"       // 审批规则命中详情新字段开关
	SwitchListQuotesReqConfig                  = "ListQuotesReqConfig"                  // 报价单列表请求参数限制
	SwitchCouponRebatePeriodInterval           = "CouponRebatePeriodInterval"           // 代金券返券周期上下限
	SwitchDebugLoadProduct                     = "DebugLoadProduct"                     // 调试开关建设_指定商品加载
	SwitchQuoteBizDataCheckerPassIgnore        = "QuoteBizDataCheckerPassIgnore"        // 报价整单业务校验通过忽略key
	SwitchUseDynamicProductOption              = "UseDynamicProductOption"              // 获取报价项配置选项使用动态选品逻辑
	SwitchUseConfigSkipInquiry                 = "UseConfigSkipInquiry"                 // 使用配置清单是否跳过算价
	SwitchQuantityOpenProductList              = "QuantityOpenProductList"              // 放开预计用量商品名单
	SwitchGuaranteeTotalSeatsProductList       = "GuaranteeTotalSeatsProductList"       // 保底商品数量校验商品白名单
	SwitchGuaranteeProductSeatsOpen            = "GuaranteeProductSeatsOpen"            // 保底商品数量校验开关
	SwitchPublicCustomerTier                   = "PublicCustomerTier"                   // 公有云客户分层
	SwitchMaasCustomerTier                     = "MaasCustomerTier"                     // MAAS客户分层
	SwitchSyncSubmitRefreshOppInfo             = "SyncSubmitRefreshOppInfo"             // 同步送审刷新商机信息
	SwitchFinancialNoApproval                  = "FinancialNoApproval"                  // 财务免审开关
	SwitchTemplateTags                         = "TemplateTags"                         // 报价模板标签
	SwitchForbidSpotQuoteSelection             = "ForbidSpotQuoteSelection"             // 禁止Spot报价选品
	SwitchFinancialNoApprovalThresholdMapping  = "FinancialNoApprovalThresholdMapping"  // 财务免审阈值映射(channel/telemarketing)
	SwitchFinancialNoApprovalOwnerTeamKeywords = "FinancialNoApprovalOwnerTeamKeywords" // 财务免审owner团队关键字
	SwitchUseQuoteEngineV2SubmitQuote          = "UseQuoteEngineV2SubmitQuote"          // 报价引擎V2 - SubmitQuote 灰度开关：IsOpen开启后按 QuoteID%100 < MaxNum 灰度走 v2；WhiteList/BlackList 可按 QuoteID 强制走 V2/老引擎
	SwitchUseQuoteEngineV2BizDataCheck         = "UseQuoteEngineV2BizDataCheck"         // 报价引擎V2 - QuoteBizDataCheck 灰度开关：IsOpen开启后按 QuoteID%100 < MaxNum 灰度走 v2；WhiteList/BlackList 可按 QuoteID 强制走 V2/老引擎
	SwitchUseQuoteEngineV2BizDataRefresh       = "UseQuoteEngineV2BizDataRefresh"       // 报价引擎V2 - QuoteBizDataRefresh 灰度开关：IsOpen开启后按 QuoteID%100 < MaxNum 灰度走 v2；WhiteList/BlackList 可按 QuoteID 强制走 V2/老引擎
	SwitchTaxRuleSupportCombinedSale           = "TaxRuleSupportCombinedSale"           // 财税规则是否支持组合售卖
	SwitchApprovalTaxRateProfitCalculate       = "ApprovalTaxRateProfitCalculate"       // 审批中修改税率后是否触发利润重算
	SwitchGuaranteeRuleThresholdConfig         = "MultiGuaranteeThresholdConfig"        // 多保底阈值配置
	SwitchDiscountLineToPreviewFlow            = "DiscountLineToPreviewFlow"            // 折扣线档位 -> 预览审批流编号（Mapping[折扣线数值] = 审批流编号）
	SwitchPreviewApprovalFlow                  = "PreviewApprovalFlow"                  // 预览审批流配置（Mapping[审批流编号] = ApprovalFlowConf JSON 字符串）
	SwitchDiscountCategorySeverity             = "DiscountCategorySeverity"             // 折扣线档位严重度排序，审批预览取最严档位用（Mapping[折扣线档位数值] = 严重度数值，越大越严；如 "1":"1" "2":"4" "3":"5" "4":"8" "102":"2" "103":"6" "104":"9" "202":"3" "203":"7" "204":"10"）
	SwitchEstimatedIncomeFixedPrice            = "SwitchEstimatedIncomeFixedPrice"      // 固定单价默认报价方式放开
	SwitchApprovalModifyProcessGray            = "ApprovalModifyProcessGray"            // 发起审批中修改灰度：IsOpen为总开关；Mapping[SalesTeamWhiteList]=送审人所属销售团队「部门名称」列表，Mapping[QuoteIDWhiteList]=报价单ID列表，均为逗号分隔；报价单ID灰度优先级高于团队灰度
	SwitchApprovalModifyProgressSync           = "ApprovalModifyProgressSync"           // 审批中修改进度同步：IsOpen控制任务启停
)

const (
	SwitchApprovalRuleOperatorWhitelist            = "ApprovalRuleOperatorWhitelist"            // 审批规则配置免限制操作人邮箱
	SwitchApprovalRuleApplicantDepartmentWhitelist = "ApprovalRuleApplicantDepartmentWhitelist" // 审批规则允许的申请人部门完整路径
	SwitchMonitorRuleOperatorWhitelist             = "MonitorRuleOperatorWhitelist"             // 监控提醒配置免限制操作人邮箱
	SwitchMonitorRuleApprovalRoleWhitelist         = "MonitorRuleApprovalRoleWhitelist"         // 监控提醒允许的飞书审批节点名称
)

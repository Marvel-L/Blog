package config

import (
	"context"

	"code.byted.org/gopkg/logs"
)

// GetAllSwitch 获取所有开关
func GetAllSwitch(ctx context.Context) map[string]*SwitchModel {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetSwitchConfig(ctx)
}

// GetSwitchByName 根据名字获取开关
func GetSwitchByName(ctx context.Context, switchName string) *SwitchModel {
	allSwitchMap := GetAllSwitch(ctx)
	return allSwitchMap[switchName]
}

// GetSwitchIsOpenByName 根据名字获取开关是否打开
func GetSwitchIsOpenByName(ctx context.Context, switchName string) bool {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return false
	}
	return switchModel.IsOpen
}

func GetMaxNumWithDefault(ctx context.Context, switchName string, defaultMaxNum int) int {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return defaultMaxNum
	}
	if switchModel.MaxNum > 0 {
		return switchModel.MaxNum
	}
	return defaultMaxNum
}

func GetSwitchBlackList(ctx context.Context, switchName string) []string {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return nil
	}
	return switchModel.BlackList
}

func GetSwitchWhiteList(ctx context.Context, switchName string) []string {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return nil
	}
	return switchModel.WhiteList
}

func GetSwitchWhiteListMap(ctx context.Context, switchName string) map[string]bool {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return nil
	}
	ret := map[string]bool{}
	for _, key := range switchModel.WhiteList {
		ret[key] = true
	}
	return ret
}

func IsTrustedTopService(ctx context.Context, serviceName string) bool {
	trustedServiceList := GetSwitchWhiteList(ctx, SwitchTrustedTopServiceList)
	for _, trustedService := range trustedServiceList {
		if trustedService == serviceName {
			return true
		}
	}
	return false
}

func GetSwitchMapping(ctx context.Context, switchName string) map[string]string {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return nil
	}
	return switchModel.Mapping
}

func GetMaxNumAndTimeoutWithDefault(ctx context.Context, switchName string, defaultMaxNum int, defaultTimeout int64) *SwitchModel {
	switchModel := GetSwitchByName(ctx, switchName)
	if switchModel == nil {
		return &SwitchModel{
			MaxNum:  defaultMaxNum,
			TimeOut: defaultTimeout,
		}
	}

	return switchModel
}

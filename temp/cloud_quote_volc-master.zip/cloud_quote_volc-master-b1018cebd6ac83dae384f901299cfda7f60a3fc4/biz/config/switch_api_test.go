package config

import (
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func Test_GetMaxNumWithDefault_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_GetMaxNumWithDefault", t, func() {
		mockey.PatchConvey("成功场景 - 开关不存在，返回默认值", func() {
			// 场景描述：
			// 当被测函数依赖的 GetSwitchByName 返回 nil 时，表示开关未找到。
			// 数据构造：
			// - ctx: context.Background()
			// - switchName: 一个不存在的开关名
			// - defaultMaxNum: 一个默认值，例如 100
			// 逻辑链路：
			// 1. Mock GetSwitchByName 函数，使其返回 nil。
			// 2. 调用 GetMaxNumWithDefault。
			// 3. 断言返回值应为传入的 defaultMaxNum。

			// 数据构造
			ctx := context.Background()
			switchName := "non_existent_switch"
			defaultMaxNum := 100

			// Mock
			mockey.Mock(GetSwitchByName).Return(nil).Build()

			// 调用
			result := GetMaxNumWithDefault(ctx, switchName, defaultMaxNum)

			// 断言
			convey.So(result, convey.ShouldEqual, defaultMaxNum)
		})

		mockey.PatchConvey("成功场景 - 开关存在且MaxNum有效，返回配置值", func() {
			// 场景描述：
			// 当被测函数依赖的 GetSwitchByName 返回一个有效的 SwitchModel，且其 MaxNum 字段大于 0 时。
			// 数据构造：
			// - ctx: context.Background()
			// - switchName: 一个存在的开关名
			// - defaultMaxNum: 一个默认值，例如 100
			// - mockSwitch: 一个 SwitchModel 实例，其 MaxNum 设置为大于0的值，例如 50
			// 逻辑链路：
			// 1. Mock GetSwitchByName 函数，使其返回预设的 mockSwitch。
			// 2. 调用 GetMaxNumWithDefault。
			// 3. 断言返回值应为 mockSwitch 中的 MaxNum。

			// 数据构造
			ctx := context.Background()
			switchName := "valid_switch"
			defaultMaxNum := 100
			configMaxNum := 50
			mockSwitch := &SwitchModel{
				MaxNum: configMaxNum,
			}

			// Mock
			mockey.Mock(GetSwitchByName).Return(mockSwitch).Build()

			// 调用
			result := GetMaxNumWithDefault(ctx, switchName, defaultMaxNum)

			// 断言
			convey.So(result, convey.ShouldEqual, configMaxNum)
		})

		mockey.PatchConvey("成功场景 - 开关存在但MaxNum无效，返回默认值", func() {
			// 场景描述：
			// 当被测函数依赖的 GetSwitchByName 返回一个有效的 SwitchModel，但其 MaxNum 字段小于或等于 0 时。
			// 数据构造：
			// - ctx: context.Background()
			// - switchName: 一个存在的开关名
			// - defaultMaxNum: 一个默认值，例如 100
			// - mockSwitch: 一个 SwitchModel 实例，其 MaxNum 设置为 0
			// 逻辑链路：
			// 1. Mock GetSwitchByName 函数，使其返回 MaxNum 为 0 的 mockSwitch。
			// 2. 调用 GetMaxNumWithDefault。
			// 3. 断言返回值应为传入的 defaultMaxNum。

			// 数据构造
			ctx := context.Background()
			switchName := "invalid_max_num_switch"
			defaultMaxNum := 100
			mockSwitch := &SwitchModel{
				MaxNum: 0,
			}

			// Mock
			mockey.Mock(GetSwitchByName).Return(mockSwitch).Build()

			// 调用
			result := GetMaxNumWithDefault(ctx, switchName, defaultMaxNum)

			// 断言
			convey.So(result, convey.ShouldEqual, defaultMaxNum)
		})
	})
}

func TestGetSwitchBlackList_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetSwitchBlackList", t, func() {
		// 公共数据构造
		ctx := context.Background()
		testSwitchName := "test_switch"

		mockey.PatchConvey("成功场景 - 开关存在且黑名单不为空", func() {
			// 场景描述：
			// 当依赖函数GetSwitchByName返回一个包含有效黑名单列表的SwitchModel时，目标函数应正确返回该黑名单。
			// 数据构造：
			// - 构造一个SwitchModel实例，其BlackList字段包含几个字符串元素。
			// 逻辑链路：
			// 1. Mock GetSwitchByName函数，使其在被调用时返回预设的SwitchModel实例。
			// 2. 调用目标函数GetSwitchBlackList。
			// 3. 断言返回的字符串切片与预设的黑名单内容完全一致。

			// 数据构造
			expectedBlackList := []string{"user_a", "user_b", "user_c"}
			mockSwitchModel := &SwitchModel{
				BlackList: expectedBlackList,
			}

			// Mock
			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			// 调用
			result := GetSwitchBlackList(ctx, testSwitchName)

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, expectedBlackList)
		})

		mockey.PatchConvey("成功场景 - 开关存在但黑名单为nil", func() {
			// 场景描述：
			// 当依赖函数GetSwitchByName返回一个SwitchModel，但其BlackList字段为nil时，目标函数应返回nil。
			// 数据构造：
			// - 构造一个SwitchModel实例，其BlackList字段明确设置为nil。
			// 逻辑链路：
			// 1. Mock GetSwitchByName函数，使其返回BlackList为nil的SwitchModel实例。
			// 2. 调用目标函数GetSwitchBlackList。
			// 3. 断言返回值为nil。

			// 数据构造
			mockSwitchModel := &SwitchModel{
				BlackList: nil,
			}

			// Mock
			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			// 调用
			result := GetSwitchBlackList(ctx, testSwitchName)

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景 - 开关存在但黑名单为空列表", func() {
			// 场景描述：
			// 当依赖函数GetSwitchByName返回一个SwitchModel，其BlackList是一个空切片时，目标函数应返回一个空切片。
			// 数据构造：
			// - 构造一个SwitchModel实例，其BlackList字段为一个空的字符串切片 `[]string{}`。
			// 逻辑链路：
			// 1. Mock GetSwitchByName函数，使其返回BlackList为空切片的SwitchModel实例。
			// 2. 调用目标函数GetSwitchBlackList。
			// 3. 断言返回值是一个非nil但长度为0的切片。

			// 数据构造
			mockSwitchModel := &SwitchModel{
				BlackList: []string{},
			}

			// Mock
			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			// 调用
			result := GetSwitchBlackList(ctx, testSwitchName)

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("失败场景 - 开关不存在", func() {
			// 场景描述：
			// 当依赖函数GetSwitchByName返回nil（表示找不到对应的开关配置）时，目标函数应直接返回nil。
			// 数据构造：
			// - 无需构造SwitchModel。
			// 逻辑链路：
			// 1. Mock GetSwitchByName函数，使其返回nil。
			// 2. 调用目标函数GetSwitchBlackList。
			// 3. 断言返回值为nil。

			// Mock
			mockey.Mock(GetSwitchByName).Return(nil).Build()

			// 调用
			result := GetSwitchBlackList(ctx, testSwitchName)

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_GetSwitchWhiteList_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_GetSwitchWhiteList", t, func() {
		mockey.PatchConvey("成功场景 - 开关存在且白名单不为空", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个包含有效白名单列表的 SwitchModel 时。
			// 预期行为:
			// GetSwitchWhiteList 函数应返回该白名单列表。
			ctx := context.Background()
			switchName := "test_switch_with_whitelist"
			expectedWhiteList := []string{"user1", "user2"}

			mockSwitchModel := &SwitchModel{
				WhiteList: expectedWhiteList,
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteList(ctx, switchName)

			convey.So(result, convey.ShouldResemble, expectedWhiteList)
		})

		mockey.PatchConvey("成功场景 - 开关存在但白名单为空", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个 SwitchModel，但其白名单列表为空切片时。
			// 预期行为:
			// GetSwitchWhiteList 函数应返回一个空的字符串切片。
			ctx := context.Background()
			switchName := "test_switch_with_empty_whitelist"
			expectedWhiteList := []string{}

			mockSwitchModel := &SwitchModel{
				WhiteList: expectedWhiteList,
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteList(ctx, switchName)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("成功场景 - 开关存在但白名单为nil", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个 SwitchModel，但其白名单列表为 nil 时。
			// 预期行为:
			// GetSwitchWhiteList 函数应返回 nil。
			ctx := context.Background()
			switchName := "test_switch_with_nil_whitelist"

			mockSwitchModel := &SwitchModel{
				WhiteList: nil,
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteList(ctx, switchName)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景 - 开关不存在", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数因开关不存在而返回 nil 时。
			// 预期行为:
			// GetSwitchWhiteList 函数应返回 nil。
			ctx := context.Background()
			switchName := "non_existent_switch"

			mockey.Mock(GetSwitchByName).Return(nil).Build()

			result := GetSwitchWhiteList(ctx, switchName)

			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func TestGetSwitchWhiteListMap_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetSwitchWhiteListMap", t, func() {
		ctx := context.Background()
		testSwitchName := "test_switch"

		mockey.PatchConvey("成功场景 - 开关存在且白名单不为空", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个包含有效白名单列表的 SwitchModel 时，
			// 预期函数应返回一个 map，其中 key 为白名单项，value 均为 true。
			whiteList := []string{"item1", "item2"}
			mockSwitchModel := &SwitchModel{
				WhiteList: whiteList,
			}
			expectedMap := map[string]bool{
				"item1": true,
				"item2": true,
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteListMap(ctx, testSwitchName)

			convey.So(result, convey.ShouldResemble, expectedMap)
		})

		mockey.PatchConvey("成功场景 - 开关存在但白名单为空列表", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个 SwitchModel，但其白名单列表为空切片时，
			// 预期函数应返回一个空的、非 nil 的 map。
			mockSwitchModel := &SwitchModel{
				WhiteList: []string{},
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteListMap(ctx, testSwitchName)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("成功场景 - 开关存在但白名单为nil", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数返回一个 SwitchModel，但其白名单列表为 nil 时，
			// 预期函数应返回一个空的、非 nil 的 map。
			mockSwitchModel := &SwitchModel{
				WhiteList: nil,
			}

			mockey.Mock(GetSwitchByName).Return(mockSwitchModel).Build()

			result := GetSwitchWhiteListMap(ctx, testSwitchName)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("失败场景 - 开关不存在", func() {
			// 场景描述:
			// 当依赖的 GetSwitchByName 函数因开关不存在而返回 nil 时，
			// 预期函数应直接返回 nil。
			mockey.Mock(GetSwitchByName).Return(nil).Build()

			result := GetSwitchWhiteListMap(ctx, "non_existent_switch")

			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_IsTrustedTopService_BitsUTGen(t *testing.T) {
	// 顶层用例，内层场景分别覆盖true和false两种返回路径，以及nil白名单场景
	mockey.PatchConvey("IsTrustedTopService 用例", t, func() {
		mockey.PatchConvey("可信服务命中白名单返回true", func() {
			// 构造白名单包含目标服务名的场景
			ctx := context.Background()
			mockey.MockUnsafe(GetSwitchWhiteList).Return([]string{"svcA", "svcB"}).Build()

			got := IsTrustedTopService(ctx, "svcB")
			convey.So(got, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("白名单不包含服务返回false", func() {
			// 构造白名单不包含目标服务名的场景
			ctx := context.Background()
			mockey.MockUnsafe(GetSwitchWhiteList).Return([]string{"svcA", "svcC"}).Build()

			got := IsTrustedTopService(ctx, "svcB")
			convey.So(got, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("配置不存在返回nil白名单返回false", func() {
			// 构造GetSwitchWhiteList返回nil的场景，覆盖nil切片遍历分支
			ctx := context.Background()
			mockey.MockUnsafe(GetSwitchWhiteList).Return(nil).Build()

			got := IsTrustedTopService(ctx, "any")
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_GetSwitchMapping_BitsUTGen(t *testing.T) {
	// 顶层场景，内部包含多个子场景，确保每个场景的Mock均自动释放
	mockey.PatchConvey("测试GetSwitchMapping所有分支", t, func() {
		mockey.PatchConvey("GetSwitchMapping_开关不存在返回nil", func() {
			// 场景：GetSwitchByName返回nil，函数应返回nil
			mockey.MockUnsafe(GetSwitchByName).Return((*SwitchModel)(nil)).Build()

			ctx := context.Background()
			res := GetSwitchMapping(ctx, "not_exists")

			convey.So(res, convey.ShouldBeNil)
		})

		mockey.PatchConvey("GetSwitchMapping_开关存在且映射非空返回映射", func() {
			// 场景：GetSwitchByName返回非nil，且Mapping非空，应返回该映射
			mapping := map[string]string{"a": "1", "b": "2"}
			switchModel := &SwitchModel{Mapping: mapping}
			mockey.MockUnsafe(GetSwitchByName).Return(switchModel).Build()

			ctx := context.Background()
			res := GetSwitchMapping(ctx, "exists")

			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res, convey.ShouldResemble, mapping)
			convey.So(res["a"], convey.ShouldEqual, "1")
		})

		mockey.PatchConvey("GetSwitchMapping_开关存在但映射为空返回nil", func() {
			// 场景：GetSwitchByName返回非nil，但Mapping为nil，返回nil
			switchModel := &SwitchModel{Mapping: nil}
			mockey.MockUnsafe(GetSwitchByName).Return(switchModel).Build()

			ctx := context.Background()
			res := GetSwitchMapping(ctx, "exists_but_nil_map")

			convey.So(res, convey.ShouldBeNil)
		})
	})
}

func Test_GetMaxNumAndTimeoutWithDefault_BitsUTGen(t *testing.T) {
	// 公共参数
	ctx := context.Background()
	defaultMaxNum := 50
	defaultTimeout := int64(31)

	mockey.PatchConvey("Test_GetMaxNumAndTimeoutWithDefault", t, func() {
		mockey.PatchConvey("当GetSwitchByName返回nil时使用默认值", func() {
			// 模拟GetSwitchByName返回nil
			mockey.MockUnsafe(GetSwitchByName).Return((*SwitchModel)(nil)).Build()

			res := GetMaxNumAndTimeoutWithDefault(ctx, "missing-switch", defaultMaxNum, defaultTimeout)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res.MaxNum, convey.ShouldEqual, defaultMaxNum)
			convey.So(res.TimeOut, convey.ShouldEqual, defaultTimeout)
		})

		mockey.PatchConvey("当GetSwitchByName返回非空配置时直接返回该配置", func() {
			// 模拟GetSwitchByName返回已有配置
			expected := &SwitchModel{IsOpen: true, UseCache: true, MaxNum: 123, TimeOut: 456}
			mockey.MockUnsafe(GetSwitchByName).Return(expected).Build()

			res := GetMaxNumAndTimeoutWithDefault(ctx, "existing-switch", 999, 888)
			convey.So(res, convey.ShouldEqual, expected)
			convey.So(res.MaxNum, convey.ShouldEqual, 123)
			convey.So(res.TimeOut, convey.ShouldEqual, int64(456))
		})
	})
}

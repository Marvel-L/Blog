package config

import (
	"fmt"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type Conf struct {
	QuoteApp                      *QuoteApp                     `yaml:"QuoteApp"`
	ApprovalControlConf           ApprovalControlConf           `yaml:"ApprovalControlConf"`
	Commodity                     *Commodity                    `yaml:"Commodity"`
	Products                      *Products                     `yaml:"Products"`
	Salesforce                    *Salesforce                   `yaml:"Salesforce"`
	OAApproval                    *OAApproval                   `yaml:"OAApproval"`
	DevSre                        DevSre                        `yaml:"DevSre"`
	Passport                      AppIDAndSecretHost            `yaml:"Passport"`
	InvoiceClient                 *InvoiceClient                `yaml:"InvoiceClient"`
	LarkBot                       *LarkBot                      `yaml:"LarkBot"`
	KMS                           KMS                           `yaml:"KMS"`
	RedisConf                     RedisConf                     `yaml:"RedisConf"`
	CronConf                      *CronConf                     `yaml:"CronConf"`
	VCPClientConf                 *VCPClientConf                `yaml:"VCPClientConf"`
	PriceConf                     *PriceConf                    `yaml:"PriceConf"`
	PriceConsulConf               *HttpClientConf               `yaml:"PriceConsulConf"`
	PermissionConfig              *PermissionConfig             `yaml:"PermissionConfig"`
	PriceServiceConfig            *PriceServiceConfig           `yaml:"PriceServiceConfig"`
	PrmProxyConfig                *RpcConfig                    `yaml:"PrmProxyConfig"`
	PrmContractConfig             *RpcConfig                    `yaml:"PrmContractConfig"`
	WhiteList                     *WhiteList                    `yaml:"WhiteList"`
	CostAnalysisConfig            *RpcConfig                    `yaml:"CostAnalysisConfig"`
	DefaultQuoteItem              *DefaultQuoteItem             `yaml:"DefaultQuoteItem"`
	CreditConf                    *HttpClientConf               `yaml:"CreditConf"`
	SalesOnlineConf               *HttpClientConf               `yaml:"SalesOnlineConf"`
	QuoteConfigListConf           *QuoteConfigListConf          `yaml:"QuoteConfigListConf"`
	C360Config                    *RpcConfig                    `yaml:"C360Config"`
	PrmCommPolicyConf             *RpcConfig                    `yaml:"PrmCommPolicyConf"`
	QuoteApprovalConf             QuoteApprovalConf             `yaml:"QuoteApprovalConf"`
	UploadModelMap                map[string]*FileModel         `yaml:"UploadModelMap"`
	FinanceRelationConfig         *RpcConfig                    `yaml:"FinanceRelationConfig"`
	ExtraConfig                   *ExtraConfig                  `yaml:"ExtraConfig"`
	TradeClientConf               *TradeClientConf              `yaml:"TradeClientConf"`
	ToolConf                      ToolConf                      `yaml:"ToolConf"`
	ModifyConf                    ModifyConf                    `yaml:"ModifyConf"`
	OASubmitEmailMap              map[string]string             `yaml:"OASubmitEmailMap"`
	StarlingClientConf            *StarlingClientConf           `yaml:"StarlingClientConf"`
	StarlingDisplayClientConf     *StarlingDisplayClientConf    `yaml:"StarlingDisplayClientConf"`
	YunShuClientConf              *HttpClientConf               `yaml:"YunShuClientConf"`
	QuoteDataAuditConf            *QuoteDataAuditConf           `yaml:"QuoteDataAuditConf"`
	AccountClientConf             *AccountClientConf            `yaml:"AccountClientConf"`
	LocalCacheTaskMap             map[string]bool               `yaml:"LocalCacheTaskMap"`
	ContractPriceConf             *ContractPriceConf            `yaml:"ContractPriceConf"`
	LarkApprovalStatusAudit       *LarkApprovalStatusAudit      `yaml:"LarkApprovalStatusAudit"`
	DeferRocketMQConf             *DeferRocketMQConf            `yaml:"DeferRocketMQConf"`
	CouponClientConf              *HttpClientConf               `yaml:"CouponClientConf"`
	SwitchCouponConf              *SwitchCouponConf             `yaml:"SwitchCouponConf"`
	ApprovalTimeOutAlarmExecConf  *ApprovalTimeOutAlarmExecConf `yaml:"ApprovalTimeOutAlarmExecConf"`
	HolidayConf                   *HolidayConf                  `yaml:"HolidayConf"`
	DiscountLineToApprovalMap     map[string]string             `yaml:"DiscountLineToApprovalMap"`
	AccountManagementConf         *InnerTopConf                 `yaml:"AccountManagementConf"`
	AccountVerifyConf             *InnerTopConf                 `yaml:"AccountVerifyConf"`
	OneServiceConf                *OneServiceConf               `yaml:"OneServiceConf"`
	KaniConfig                    *KaniConfig                   `yaml:"KaniConfig"`
	LabelClientConfig             *LabelClientConfig            `yaml:"LabelClientConfig"`
	TradeResourceConfig           *RpcConfig                    `yaml:"TradeResourceConfig"`
	TradeActConfig                *RpcConfig                    `yaml:"TradeActConfig"`
	ContractInnerTopConf          *InnerTopConf                 `yaml:"ContractInnerTopConf"`
	ContractInnerTopConfV2        *InnerTopConf                 `yaml:"ContractInnerTopConfV2"`
	CommercializationInnerTopConf *InnerTopConf                 `yaml:"CommercializationInnerTopConf"`
	PartnerInnerTopConf           *InnerTopConf                 `yaml:"PartnerInnerTopConf"`
}

type ToolConf struct {
	EnableRefreshHistoryCoupon bool `yaml:"EnableRefreshHistoryCoupon"`
}

type LarkBot struct {
	AppID                         string `yaml:"AppID"`
	Secret                        string `yaml:"Secret"`
	Domain                        string `yaml:"Domain"`
	QuoteContractGroupID          string `yaml:"QuoteContractGroupID"`
	ContractItemRepeatGroupID     string `yaml:"ContractItemRepeatGroupID"`
	QuoteDutyGroupID              string `yaml:"QuoteDutyGroupID"`
	ApprovalTenantID              string `yaml:"ApprovalTenantID"`
	ApprovalSecretKey             string `yaml:"ApprovalSecretKey"`
	HttpSchema                    string `yaml:"HttpSchema"`
	HttpHost                      string `yaml:"HttpHost"`
	ApprovalHost                  string `yaml:"ApprovalHost"`
	CodeDiscountFunctionRuleApply string `yaml:"CodeDiscountFunctionRuleApply"`
	SearchEmployeeSwitch          bool   `yaml:"SearchEmployeeSwitch"`
	QuoteApprovalSplitSwitch      bool   `yaml:"QuoteApprovalSplitSwitch"`   // 报价单审批流拆分开关，降级使用
	CodeQuoteApply                string `yaml:"CodeQuoteApply"`             // 报价单审批-表单号
	CodeConfigListApply           string `yaml:"CodeConfigListApply"`        // 配置清单审批-表单号
	ChangeResourcePageApply       string `yaml:"ChangeResourcePageApply"`    // 变更资源单
	ChangeDiscountQuoteApply      string `yaml:"ChangeDiscountQuoteApply"`   // 变价报价单
	CodeInnerQuoteApply           string `yaml:"CodeInnerQuoteApply"`        // 内部报价单
	CodeProjectBasedQuoteApply    string `yaml:"CodeProjectBasedQuoteApply"` // 项目制报价单
	CodeDataRefreshApply          string `yaml:"CodeDataRefreshApply"`       // 报价刷数审批
	DesignatedDepartmentId        string `yaml:"DesignatedDepartmentId"`     // 被指定的部门ID，用于获取被指定部门下的所有员工
	DesignatedDepartmentName      string `yaml:"DesignatedDepartmentName"`   // 被指定的部门名称，用于获取被指定部门下的所有员工
	AppIDBackUp                   string `yaml:"AppIDBackUp"`                // bp cn boe stable 配置，生产不配置
	SecretBackUp                  string `yaml:"SecretBackUp"`               // bp cn boe stable 配置，生产不配置
}

type FileModel struct {
	ModelKey  string `yaml:"ModelKey"`
	FileToken string `yaml:"FileToken"`
	FileType  string `yaml:"FileType"`
	BootToken string `yaml:"BootToken"`
}

type QuoteApp struct {
	PSM                            string                       `yaml:"PSM"`
	Env                            string                       `yaml:"Env"`
	PreviewLink                    string                       `yaml:"PreviewLink"`
	ConfigListPreviewLink          string                       `yaml:"ConfigListPreviewLink"`
	ChangeDiscountQuotePreviewLink string                       `yaml:"ChangeDiscountQuotePreviewLink"`
	RefreshTaskPreviewLink         string                       `yaml:"RefreshTaskPreviewLink"`
	DevSreQuoteDetailLink          string                       `yaml:"DevSreQuoteDetailLink"` // 报价平台报价单详情页
	CRMQuoteDetailLink             string                       `yaml:"CRMQuoteDetailLink"`    // CRM报价单详情页
	CRMQuoteDetailLinkV2           string                       `yaml:"CRMQuoteDetailLinkV2"`  // CRM报价单新详情页
	QuoteTaskContractLink          string                       `yaml:"QuoteTaskContractLink"`
	LarkMobileLink                 string                       `yaml:"LarkMobileLink"`
	SourceMap                      map[string]string            `yaml:"SourceMap"`
	ConfigMap                      map[string]map[string]string `yaml:"ConfigMap"`
	MaxItemNum                     int                          `yaml:"MaxItemNum"`
	SubmitNotifyTime               int                          `yaml:"SubmitNotifyTime"`
	ProfitCalculateModifySwitch    bool                         `yaml:"ProfitCalculateModifySwitch"`
	WriteDB                        DBConf                       `yaml:"WriteDB"`
	ReadDB                         []DBConf                     `yaml:"ReadDB"`
	PipelineCmdNum                 int                          `yaml:"PipelineCmdNum"`
	ExFactorySwitchConfig          []string                     `yaml:"ExFactorySwitchConfig"` // 出厂价折扣线启用配置
	ChargeItemKeyReadStr           bool                         `yaml:"ChargeItemKeyReadStr"`
	ChargeItemKeyGroupNum          int                          `yaml:"ChargeItemKeyGroupNum"`
	HealthCheckAllow               bool                         `yaml:"HealthCheckAllow"`
	QAWhiteList                    []string                     `yaml:"QAWhiteList"`
	MaskKeyMap                     map[string]string            `yaml:"MaskKeyMap"`
}

type Commodity struct {
	Host   string `yaml:"Host"`
	AppID  string `yaml:"AppID"`
	Secret string `yaml:"Secret"`
	//Callback string `yaml:"Callback"`
	Feature string `yaml:"Feature"`
	Timeout int    `yaml:"Timeout"`
}

type Products struct {
	Token               string   `yaml:"Token"`
	Host                string   `yaml:"Host"`
	Schema              string   `yaml:"Schema"`
	WhiteList           string   `yaml:"WhiteList"`
	ProductSolutionFlag []string `yaml:"ProductSolutionFlag"` // 产品解决方案 名称标识
}

type Salesforce struct {
	GrantType    string `yaml:"grant_type"`
	ClientID     string `yaml:"client_id"`
	ClientSecret string `yaml:"client_secret"`
	Username     string `yaml:"username"`
	Password     string `yaml:"password"`
	AuthHost     string `yaml:"host"`
	ApiHost      string `yaml:"api_host"`
	Feature      string `yaml:"feature"`
}

type KMS struct {
	Alias string `yaml:"Alias"`
}

type RedisConf struct {
	Cluster      string `yaml:"Cluster"`
	DialTimeout  int    `yaml:"DialTimeout"`  // 秒
	ReadTimeout  int    `yaml:"ReadTimeout"`  // 秒
	WriteTimeout int    `yaml:"WriteTimeout"` // 秒
}

type CronConf struct {
	MasterElectionLockKey string `yaml:"MasterElectionLockKey"` // 定时任务抢主key
	AllowHttpCall         bool   `yaml:"AllowHttpCall"`         // 是否允许http触发
	HttpCallToken         string `yaml:"HttpCallToken"`         // http触发时请求token
}

type VCPClientConf struct {
	Schema  string `yaml:"Schema"`
	Host    string `yaml:"Host"`
	Ak      string `yaml:"Ak"`
	Sk      string `yaml:"Sk"`
	Feature string `yaml:"Feature"`
}

// OAApproval OA审批流程
type OAApproval struct {
	AppID               string `yaml:"AppID"`               //
	Secret              string `yaml:"Secret"`              //
	Host                string `yaml:"Host"`                //
	CodeQuoteApply      string `yaml:"CodeQuoteApply"`      //
	CodeConfigListApply string `yaml:"CodeConfigListApply"` //
}

type PriceConf struct {
	Host    string `yaml:"Host"`    //
	Timeout int    `yaml:"Timeout"` // 毫秒
	AK      string `yaml:"AK"`      //
	SK      string `yaml:"SK"`      //
	Feature string `yaml:"Feature"`
}

type PermissionConfig struct {
	Schema          string `yaml:"Schema"`
	Host            string `yaml:"Host"`
	ServiceKey      string `yaml:"ServiceKey"`
	ServiceSecret   string `yaml:"ServiceSecret"`
	ExpiredDuration int    `yaml:"ExpiredDuration"`
	CheckOpen       bool   `yaml:"CheckOpen"`
	LogOpen         bool   `yaml:"LogOpen"`
}

type HttpClientConf struct {
	Schema  string `yaml:"Schema"`
	Host    string `yaml:"Host"`
	Ak      string `yaml:"Ak"`
	Sk      string `yaml:"Sk"`
	Feature string `yaml:"Feature"`
	Timeout int    `yaml:"Timeout"`
}

type StarlingClientConf struct {
	ProjectName string `yaml:"ProjectName"`
	Namespace   string `yaml:"Namespace"`
}

type StarlingDisplayClientConf struct {
	PublishEnabled bool   `yaml:"PublishEnabled"`
	TestRelease    bool   `yaml:"TestRelease"`
	GrayRelease    bool   `yaml:"GrayRelease"`
	BaseURL        string `yaml:"BaseURL"`
	ProjectID      int64  `yaml:"ProjectID"`
	NamespaceID    int64  `yaml:"NamespaceID"`
	AccessKey      string `yaml:"AccessKey"`
	SecretKey      string `yaml:"SecretKey"`
	TimeoutMillis  int    `yaml:"TimeoutMillis"`
}
type PrmConfig struct {
	Schema      string `yaml:"Schema"`
	Host        string `yaml:"Host"`
	Secret      string `yaml:"Secret"`
	CallerEmail string `yaml:"CallerEmail"`
	Feature     string `yaml:"Feature"`
}

type PriceServiceConfig struct {
	Schema  string `yaml:"Schema"`
	Host    string `yaml:"Host"`
	Secret  string `yaml:"Secret"`
	Feature string `yaml:"Feature"`
	Domain  string `yaml:"Domain"`
}

type RpcConfig struct {
	Psm            string `yaml:"Psm"`
	Feature        string `yaml:"Feature"`
	ConcurrencyNum int    `yaml:"ConcurrencyNum"`
	Cluster        string `yaml:"Cluster"`
	Domain         string `yaml:"Domain"`
}

type AppIDAndSecretHost struct {
	AppID  string `yaml:"AppID"`
	Secret string `yaml:"Secret"`
	Host   string `yaml:"Host"`
}

type InvoiceClient struct {
	Schema string `yaml:"Schema"`
	Host   string `yaml:"Host"`
}

type WhiteList struct {
	Host                   string `yaml:"Host"`
	AppID                  string `yaml:"AppID"`
	Secret                 string `yaml:"Secret"`
	StopSellingProductCode string `yaml:"StopSellingProductCode"`
	Feature                string `yaml:"Feature"`
}

type DefaultQuoteItem struct {
	TradeProduct string                 `yaml:"TradeProduct"`
	FormValues   map[string]interface{} `yaml:"FormValues"`
	ItemScene    int                    `yaml:"ItemScene"`
	ItemBelong   int64                  `yaml:"ItemBelong"`
}

type QuoteConfigListConf struct {
	DefaultNotifiers []string `yaml:"DefaultNotifiers"` // 默认知会人
}

type QuoteApprovalConf struct {
	NeedExtraApprovalBizLine           []string `yaml:"NeedExtraApprovalBizLine"`           // 需要加签的一级业务线
	DefaultExtraApproval               []string `yaml:"DefaultExtraApproval"`               // [产品审核]默认加签人
	DefaultApproval                    []string `yaml:"DefaultApproval"`                    // [产品审核]默认审批人
	DefaultNeedShiftApproval           string   `yaml:"DefaultNeedShiftApproval"`           // [是否需要上升审批]默认值-否
	DefaultShiftApprovalReason         string   `yaml:"DefaultShiftApprovalReason"`         // [上升审批原因]默认值-无
	DefaultDetailedShiftApprovalReason string   `yaml:"DefaultDetailedShiftApprovalReason"` // [上升审批具体原因]默认值-其他
	DefaultApprovalCommittee           []int64  `yaml:"DefaultApprovalCommittee"`           // [审批委员会]默认值，直接填写工号
	DefaultApprovalCommitteeOpen       []string `yaml:"DefaultApprovalCommitteeOpen"`       // [审批委员会]默认值，直接填写open_id
	QuoteSubmitFailCount               int      `yaml:"QuoteSubmitFailCount"`               // 报价单提交失败次数
	DefaultJointPrintCollaborator      []string `yaml:"DefaultJointPrintCollaborator"`      // 默认联合打单协作人
}

type OffPeakHoursBillingConf struct {
	TradeProduct   string            `json:"TradeProduct"`   // 商品
	Configuration  string            `json:"Configuration"`  // 配置
	ChargeItemCode string            `json:"ChargeItemCode"` // 计费项编码
	Periods        []string          `json:"Periods"`        // 可选时段
	DiscountRatios []decimal.Decimal `json:"DiscountRatios"` // 可选折扣比例
}

type SwitchCouponConf struct {
	ValidateSwitch        bool           `yaml:"ValidateSwitch"`        // 校验开关，true=校验，false=不校验
	BatchValidateSwitch   bool           `yaml:"BatchValidateSwitch"`   // 批量校验开关，true=校验，false=不校验
	InterceptSwitch       bool           `yaml:"InterceptSwitch"`       // 异常拦截开关，true=err时拦截，false=err时不拦截
	MockSwitch            bool           `yaml:"MockSwitch"`            // 参数mock开关，true=mock请求参数，false=不mock请求参数
	CouponTypeCodeMapping map[int]string `yaml:"CouponTypeCodeMapping"` // 代金券类型到code的映射
}

func (cfg *OffPeakHoursBillingConf) key() string {
	return buildOffPeakHoursBillingKey(cfg.TradeProduct, cfg.Configuration, cfg.ChargeItemCode)
}

func (cfg *OffPeakHoursBillingConf) IsValidValue(period string, ratio decimal.Decimal) bool {
	if !util.StrIn(period, cfg.Periods) {
		return false
	}
	var containsRatio bool
	for _, v := range cfg.DiscountRatios {
		if v.Equal(ratio) {
			containsRatio = true
			break
		}
	}
	return containsRatio
}

func buildOffPeakHoursBillingKey(product, configuration, chargeItemCode string) string {
	return fmt.Sprintf("%s_%s_%s", product, configuration, chargeItemCode)
}

// ExtraConfig 优惠信息配置相关属性
type ExtraConfig struct {
	MaxCreditLimit int64 `yaml:"MaxCreditLimit"` // 授信额度上限
}

// TradeClientConf 财务账号系统 用于查询当前账号余额等信息
type TradeClientConf struct {
	Schema           string `yaml:"Schema"`
	QueryBalanceHost string `yaml:"QueryBalanceHost"`
	QueryBalanceEnv  string `yaml:"QueryBalanceEnv"`
	Domain           string `yaml:"Domain"`
}

type ModifyConf struct {
	CanNotEditFields                                 []string `yaml:"CanNotEditFields"`                                 // 不能编辑的字段列表
	CommonChangeCanNotEditFields                     []string `yaml:"CommonChangeCanNotEditFields"`                     // 普通报价单，变更场景，不允许变更的字段列表
	CfgListChangeCanEditFields                       []string `yaml:"CfgListChangeCanEditFields"`                       // 配置清单，变更场景，允许变更的字段列表
	SupplyAgreementChangeCanEditFields               []string `yaml:"SupplyAgreementChangeCanEditFields"`               // 公有云补充协议，变更场景，允许变更的字段列表
	SupplyConfigListChangeCanEditFields              []string `yaml:"SupplyConfigListChangeCanEditFields"`              // 补充配置清单，变更场景，允许变更的字段列表
	ProjectSupplyAgreementChangeCanEditFields        []string `yaml:"ProjectSupplyAgreementChangeCanEditFields"`        // 补充项目制报价单，变更场景，允许变更的字段列表
	ProjectSupplyAgreementRenewalChangeCanEditFields []string `yaml:"ProjectSupplyAgreementRenewalChangeCanEditFields"` // 补充项目制报价单-续约，变更场景，允许变更的字段列表
}
type OA struct {
	AppID  string `yaml:"AppID"`
	Secret string `yaml:"Secret"`
	Host   string `yaml:"Host"`
}

type DevSre struct {
	Secret string `yaml:"Secret"`
}

type DBConf struct {
	DBName         string `yaml:"DBName"`
	UserName       string `yaml:"UserName"`
	Password       string `yaml:"Password"`
	PSM            string `yaml:"PSM"`
	ConnectTimeout string `yaml:"ConnectTimeout"`
	ReadTimeout    string `yaml:"ReadTimeout"`
	WriteTimeout   string `yaml:"WriteTimeout"`
	UnUseGdprAuth  bool   `yaml:"UnUseGdprAuth"`
}

type I18nMapper struct {
	Zh   string `yaml:"zh"`
	En   string `yaml:"en"`
	Hint string `yaml:"hint"`
}

type ActionOpenList struct {
	ActionMap map[string]bool `yaml:"ActionMap"`
}

// ApprovalControlConf 审批控制相关配置
type ApprovalControlConf struct {
	EnableLarkApproval                 bool     `yaml:"EnableLarkApproval"`                 // 启用飞书审批，不启用时走敏捷流程逻辑
	CronjobForceExec                   bool     `yaml:"CronjobForceExec"`                   // 定时任务强制执行，忽略IsMaster
	GetApprovalFromCache               bool     `yaml:"GetApprovalFromCache"`               // 从缓存中获取
	DisableCheckUnapprovedProductLines bool     `yaml:"DisableCheckUnapprovedProductLines"` // 跳过校验未立项一级二级产品线字段
	DisableQuoteSubmitOA               bool     `yaml:"DisableQuoteSubmitOA"`               // 禁用送审报价审批，一般只在PPE环境限制该功能
	UnapprovedTradeProducts            []string `yaml:"UnapprovedTradeProducts"`            // 未立项商品code列表
	ConfigListNeedApprovalDepartments  []string `yaml:"ConfigListNeedApprovalDepartments"`  // 配置清单-需要审批对应的一级产品线名称，目前限定为：云基础
	ConfigListNeedNotifyDepartments    []string `yaml:"ConfigListNeedNotifyDepartments"`    // 配置清单-需要抄送一级产品线负责人对应的一级产品线名称
	ConfigListDefSolutionOwner         string   `yaml:"ConfigListDefSolutionOwner"`         // 配置清单-解决方案负责人 默认值
	ConfigListDefSolutionBizLineOwner  string   `yaml:"ConfigListDefSolutionBizLineOwner"`  // 配置清单-解决方案二级产品线负责人 默认值
	ConfigListDefApprovalOwner         string   `yaml:"ConfigListDefApprovalOwner"`         // 配置清单-审批人 默认值
	StandardProductSolutionOwner       string   `yaml:"StandardProductSolutionOwner"`       // 标品解决方案负责人 默认值
}

// DiffConf 差异字段对比配置.
type DiffConf struct {
	FieldDiffConf                 FieldDiffConf                  `yaml:"FieldDiff"`                     // 差异字段对比配置
	QuoteBaseInfoDiffField        map[string][]DiffFieldInfoConf `yaml:"QuoteBaseInfoDiffField"`        // 报价单基础信息对比字段
	QuoteItemContextDiffField     map[string][]DiffFieldInfoConf `yaml:"QuoteItemContextDiffField"`     // 报价单基础信息对比字段
	CouponBaseInfoDiffField       map[string][]DiffFieldInfoConf `yaml:"CouponBaseInfoDiffField"`       // 报价单基础信息对比字段
	GuaranteeBaseInfoDiffField    map[string][]DiffFieldInfoConf `yaml:"GuaranteeBaseInfoDiffField"`    // 保底基础信息对比字段
	RebateDiffField               map[string][]DiffFieldInfoConf `yaml:"RebateDiffField"`               // 返佣对比字段
	JointPrintOrderDiffField      map[string][]DiffFieldInfoConf `yaml:"JointPrintOrderDiffField"`      // 联合打单对比字段
	ProfitDiffDependFields        []string                       `yaml:"ProfitDiffDependFields"`        // 利润diff依赖字段
	StandardPriceDiffIgnoreFields []string                       `yaml:"StandardPriceDiffIgnoreFields"` // 刊例价变更diff忽略字段
	ProfitCalCompareKeys          []string                       `yaml:"ProfitCalCompareKeys"`          // 利润计算对比字段
}

// FieldDiffConf 差异字段对比配置.
type FieldDiffConf struct {
	DiffQuoteBaseInfoFields      []string `yaml:"DiffQuoteBaseInfoFields"`      // 对比字段，报价单基础信息
	DiffCouponDetailFields       []string `yaml:"DiffCouponDetailFields"`       // 对比字段，代金券基础信息
	DiffCouponDetailSortedFields []string `yaml:"DiffCouponDetailSortedFields"` // 对比排序字段，代金券基础信息
	DiffItemContextFields        []string `yaml:"DiffItemContextFields"`        // 对比字段，报价项字段
}

// DiffFieldInfoConf 差异字段详情信息
type DiffFieldInfoConf struct {
	Code          string   `yaml:"Code"`          // 字段code
	Name          string   `yaml:"Name"`          // 字段node
	ValKey        string   `yaml:"ValKey"`        // 字段值在上下文key
	Scene         []string `yaml:"Scene"`         // 字段适用场景（如果不存在，表示全场景共用）
	ValuePath     []string `yaml:"ValuePath"`     // 字段值在原始值中路径（存在，只对比指定字段；不存在，默认整体对比）（只支持一层结构）
	NeedSort      bool     `yaml:"NeedSort"`      // 字段值是否需要排序（默认false，不需要排序）
	SortValueType int      `yaml:"SortValueType"` // 排序值类型（0=逗号分隔（默认），1=int数组json，2=string数组json）
	TrendCalcType string   `yaml:"TrendCalcType"` // 趋势计算类型（decimal=数值型，discount=折扣型，interval=区间型，空=不计算趋势）
}

// QuoteDataAuditConf 报价单数据稽核任务相关配置
type QuoteDataAuditConf struct {
	AuditBeforeDaysQuote int     `yaml:"AuditBeforeDaysQuote"` // 稽核前多少天报价单
	AuditQuoteWhiteList  []int64 `yaml:"AuditQuoteWhiteList"`  // 稽核报价单白名单

	PremiumRuleSwitch  bool   `yaml:"PremiumRuleSwitch"`  // 溢价规则开关
	PremiumRatio       string `yaml:"PremiumRatio"`       // 溢价比例
	DiscountRuleSwitch bool   `yaml:"DiscountRuleSwitch"` // 折价规则开关
	DiscountRatio      string `yaml:"DiscountRatio"`      // 折价比例
}

// AccountClientConf 实名认证client配置
type AccountClientConf struct {
	Schema        string `yaml:"Schema"`
	Host          string `yaml:"Host"`
	Ak            string `yaml:"Ak"`
	Sk            string `yaml:"Sk"`
	Region        string `yaml:"Region"`
	Timeout       int    `yaml:"Timeout"`
	EnableAccount bool   `yaml:"EnableAccount"`
}

// WhiteListConf 白名单配置
type WhiteListConf struct {
	OppAccountIDWhiteList map[string][]string `yaml:"OppAccountIDWhiteList"` // 商机账号白名单列表
}

// ContractPriceConf 合同价配置
type ContractPriceConf struct {
	ContractPriceFailCount int `yaml:"ContractPriceFailCount"` // 合同价创建失败次数
	CreatePriceNumLimit    int `yaml:"CreatePriceNumLimit"`    // 单次创建合同价数量限制
}

// LarkApprovalStatusAudit 飞书审批实例稽核配置
type LarkApprovalStatusAudit struct {
	AuditAllow           bool     `yaml:"AuditAllow"`
	AutoRepairAllow      bool     `yaml:"AutoRepairAllow"` // 是否自动订正审批状态差异，默认关闭
	ApprovalValidityTime int      `yaml:"ApprovalValidityTime"`
	AuditWhite           []string `yaml:"AuditWhite"`
	MinCallTimeInterval  int      `yaml:"MinCallTimeInterval"`
}

type DeferRocketMQConf struct {
	ClusterName string `yaml:"ClusterName"`
	Group       string `yaml:"Group"`
}

type ApprovalTimeOutAlarmExecConf struct {
	LastedDay             int      `yaml:"LastedDay"`             // 最近多少天的报价单
	AlarmBuff             int      `yaml:"AlarmBuff"`             // 提醒缓冲时间
	AlarmSpan             int      `yaml:"AlarmSpan"`             // 固定时间提醒跨度
	MessageToGroupCount   int      `yaml:"MessageToGroupCount"`   // 消息升级为群聊的次数
	MaxSendMessageCount   int      `yaml:"MaxSendMessageCount"`   // 最大发送消息次数
	WorkStartTime         string   `yaml:"WorkStartTime"`         // 工作时间开始
	WorkEndTime           string   `yaml:"WorkEndTime"`           // 工作时间结束
	SendMessageBlackEmail []string `yaml:"SendMessageBlackEmail"` // 发消息黑名单
	SendMessageWhiteEmail []string `yaml:"SendMessageWhiteEmail"` // 发消息白名单
	GroupWhiteEmail       []string `yaml:"GroupWhiteEmail"`       // 拉群白名单
	GroupBlackEmail       []string `yaml:"GroupBlackEmail"`       // 拉群黑名单
	CardTemplateMax       int      `yaml:"CardTemplateMax"`       // 卡片模板最大数量
	CardTemplateSaleOpMax int      `yaml:"CardTemplateSaleOpMax"` // 销运卡片模板最大数量
}

type HolidayConf struct {
	WorkDay []string `yaml:"WorkDay"` // 工作日
	Holiday []string `yaml:"Holiday"` // 节假日
}

type InnerTopConf struct {
	Ak          string `yaml:"Ak"`
	Sk          string `yaml:"Sk"`
	Region      string `yaml:"Region"` // 通过Region区分站点,火山：cn-beijing, BytePlus：ap-southeast-1
	Endpoint    string `yaml:"Endpoint"`
	Feature     string `yaml:"Feature"`
	ServiceCode string `yaml:"ServiceCode"`
}

type OneServiceConf struct {
	ProductIncomeRateQueryID       string `yaml:"ProductIncomeRateQueryID"`
	CustomerARRIncomeQueryID       string `yaml:"CustomerARRIncomeQueryID"`      // 过去12个月的 量价公有云年消耗
	CustomerARRIncomeMonthlyQuery  string `yaml:"CustomerARRIncomeMonthlyQuery"` // 过去12个月的 量价公有云月消耗
	IDC                            string `yaml:"IDC"`
	IDCNew                         string `yaml:"IDCNew"`
	YearConsumptionQueryID         string `yaml:"YearConsumptionQueryID"`         // 公有云、私有云年消耗（主客户维度）
	LargeModelProductQueryID       string `yaml:"LargeModelProductQueryID"`       // 主客户过去12个月，包含大模型商品的消费金额的和
	FirstProductLineProductQueryID string `yaml:"FirstProductLineProductQueryID"` // 主客户过去12个月，不包含大模型，按照一级产品线进行分组的消费金额的和
	OverdueAmountQueryID           string `yaml:"OverdueAmountQueryID"`           // 主客户对应的逾期金额
	PublicCloudGrowthTrendQueryID  string `yaml:"PublicCloudGrowthTrendQueryID"`  // 客户维度过去24个月的公有云、私有云 每月计收金额
	IndicatorDeviationQueryID      string `yaml:"IndicatorDeviationQueryID"`      // 主客户对应的一级、二级产品线、平均折扣和实际折扣
	MaasYearConsumptionQueryID     string `yaml:"MaasYearConsumptionQueryID"`     // MAAS年消耗
}

type KaniConfig struct {
	Host      string `yaml:"Host"`
	Namespace string `yaml:"Namespace"`
	Timeout   int    `yaml:"Timeout"`
}

type LabelClientConfig struct {
	Ak                string `yaml:"Ak"`
	Sk                string `yaml:"Sk"`
	Region            string `yaml:"Region"` // 通过Region区分站点,火山：cn-beijing, BytePlus：ap-southeast-1
	Endpoint          string `yaml:"Endpoint"`
	ServiceCode       string `yaml:"ServiceCode"`
	LabelKeyMarketARR string `yaml:"LabelKeyMarketARR"`
}

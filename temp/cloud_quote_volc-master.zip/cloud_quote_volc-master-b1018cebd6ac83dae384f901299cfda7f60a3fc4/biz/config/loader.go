package config

import "context"

type loader interface {
	GetGlobalConf(ctx context.Context) *Conf
	GetAllEnums(ctx context.Context) map[string]map[string]string
	GetAllOffPeakHoursBillingConf(ctx context.Context) map[string]*OffPeakHoursBillingConf
	GetActionOpenMap(ctx context.Context) map[string]bool
	GetDiffConf(ctx context.Context) *DiffConf
	GetWhiteListConf(ctx context.Context) *WhiteListConf
	GetEventConfig(ctx context.Context) *EventConfig
	GetSwitchConfig(ctx context.Context) map[string]*SwitchModel
	GetConstantsConfig(ctx context.Context) map[string][]*ConstantsModel
	GetLarkApprovalConfig(ctx context.Context) *LarkApprovalConfig
}

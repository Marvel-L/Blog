package config

type ConstantsModel struct {
	Code  string `yaml:"Code"`  // code
	Name  string `yaml:"Name"`  // 名称
	Desc  string `yaml:"Desc"`  // 描述
	Value string `yaml:"Value"` // 值
}

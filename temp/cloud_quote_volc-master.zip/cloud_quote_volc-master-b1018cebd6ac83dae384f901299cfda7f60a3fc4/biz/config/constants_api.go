package config

import (
	"context"

	"code.byted.org/gopkg/logs"
)

// GetConstantsByScene 根据场景获取常量列表
func GetConstantsByScene(ctx context.Context, scene string) []*ConstantsModel {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetConstantsConfig(ctx)[scene]
}

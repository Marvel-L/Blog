package config

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

// All comments and test scenario descriptions must be in english.
func Test_DefinitionFormData_Parse_BitsUTGen(t *testing.T) {
	t.Run("should do nothing if optionValue is already parsed", func(t *testing.T) {
		mockey.PatchConvey("should do nothing if optionValue is already parsed", t, func() {
			d := &DefinitionFormData{
				optionValue: "already parsed",
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			convey.So(d.optionValue, convey.ShouldEqual, "already parsed")
		})
	})

	t.Run("should do nothing if Option field is nil", func(t *testing.T) {
		mockey.PatchConvey("should do nothing if Option field is nil", t, func() {
			d := &DefinitionFormData{
				Option: nil,
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			convey.So(d.optionValue, convey.ShouldBeNil)
		})
	})

	t.Run("should parse amount type successfully", func(t *testing.T) {
		mockey.PatchConvey("should parse amount type successfully", t, func() {
			d := &DefinitionFormData{
				Type: LarkFormTypeAmount,
				Option: map[string]interface{}{
					"isCapital":     true,
					"currencyRange": []string{"USD", "CNY"},
				},
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			val, ok := d.optionValue.(*DefinitionOptionAmount)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(val.IsCapital, convey.ShouldBeTrue)
			convey.So(val.CurrencyRange, convey.ShouldResemble, []string{"USD", "CNY"})
		})
	})

	t.Run("should fail to parse amount type with invalid option data", func(t *testing.T) {
		mockey.PatchConvey("should fail to parse amount type with invalid option data", t, func() {
			d := &DefinitionFormData{
				Type:   LarkFormTypeAmount,
				Option: "invalid data",
			}

			err := d.Parse()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json: cannot unmarshal")
		})
	})

	t.Run("should parse fieldList type successfully", func(t *testing.T) {
		mockey.PatchConvey("should parse fieldList type successfully", t, func() {
			d := &DefinitionFormData{
				Type: LarkFormTypeFieldList,
				Option: map[string]interface{}{
					"input_type": "text",
				},
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			val, ok := d.optionValue.(*DefinitionOptionFieldList)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(val.InputType, convey.ShouldEqual, "text")
		})
	})

	t.Run("should fail to parse fieldList type with invalid option data", func(t *testing.T) {
		mockey.PatchConvey("should fail to parse fieldList type with invalid option data", t, func() {
			d := &DefinitionFormData{
				Type:   LarkFormTypeFieldList,
				Option: 123,
			}

			err := d.Parse()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json: cannot unmarshal")
		})
	})

	t.Run("should parse dateInterval type successfully", func(t *testing.T) {
		mockey.PatchConvey("should parse dateInterval type successfully", t, func() {
			d := &DefinitionFormData{
				Type: LarkFormTypeDateInterval,
				Option: map[string]interface{}{
					"start": "2024-01-01",
					"end":   "2024-12-31",
				},
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			val, ok := d.optionValue.(*DefinitionOptionDateInterval)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(val.Start, convey.ShouldEqual, "2024-01-01")
		})
	})

	t.Run("should fail to parse dateInterval type with invalid option data", func(t *testing.T) {
		mockey.PatchConvey("should fail to parse dateInterval type with invalid option data", t, func() {
			d := &DefinitionFormData{
				Type:   LarkFormTypeDateInterval,
				Option: "invalid data",
			}

			err := d.Parse()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json: cannot unmarshal")
		})
	})

	t.Run("should parse default type successfully", func(t *testing.T) {
		mockey.PatchConvey("should parse default type successfully", t, func() {
			d := &DefinitionFormData{
				Type: "radio", // Any type other than the specific ones
				Option: []map[string]interface{}{
					{"value": "1", "text": "Option 1"},
				},
			}

			err := d.Parse()

			convey.So(err, convey.ShouldBeNil)
			val, ok := d.optionValue.([]*DefinitionOption)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(len(val), convey.ShouldEqual, 1)
			convey.So(val[0].Value, convey.ShouldEqual, "1")
		})
	})

	t.Run("should fail to parse default type with invalid option data", func(t *testing.T) {
		mockey.PatchConvey("should fail to parse default type with invalid option data", t, func() {
			d := &DefinitionFormData{
				Type:   "radio",
				Option: "not an array",
			}

			err := d.Parse()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json: cannot unmarshal")
		})
	})
}

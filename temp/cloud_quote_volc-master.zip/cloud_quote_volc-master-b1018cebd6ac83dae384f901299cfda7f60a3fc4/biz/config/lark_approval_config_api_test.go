package config

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func Test_GetApplyDataRuleConfigs_BitsUTGen(t *testing.T) {
	t.Run("Return nil when approval data rule is nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			mockey.MockUnsafe(GetLarkApprovalDataRule).Return(nil).Build()

			result := GetApplyDataRuleConfigs(ctx, "any-type")
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Return slice when applicationType exists", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			expected := []*DataRuleConfig{
				{Event: "create", TriggerKey: "k1", DataCode: "code1"},
				{Event: "update", TriggerKey: "k2", DataCode: "code2"},
			}
			mockDataRule := &LarkApprovalDataRule{
				BizLine: "biz",
				Events:  []string{"create", "update"},
				DataRuleConfigs: map[string][]*DataRuleConfig{
					"apply-type": expected,
				},
			}

			mockey.MockUnsafe(GetLarkApprovalDataRule).Return(mockDataRule).Build()

			result := GetApplyDataRuleConfigs(ctx, "apply-type")
			convey.So(result, convey.ShouldResemble, expected)
		})
	})

	t.Run("Return nil when applicationType missing", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			mockDataRule := &LarkApprovalDataRule{
				BizLine: "biz",
				Events:  []string{"create"},
				DataRuleConfigs: map[string][]*DataRuleConfig{
					"exist-type": {
						{Event: "create", TriggerKey: "k", DataCode: "c"},
					},
				},
			}

			mockey.MockUnsafe(GetLarkApprovalDataRule).Return(mockDataRule).Build()

			result := GetApplyDataRuleConfigs(ctx, "missing-type")
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_GetLarkApprovalDataRule_BitsUTGen(t *testing.T) {
	t.Run("getLarkApprovalConfig返回nil时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock内部依赖函数，使其返回nil，覆盖目标函数的nil分支
			mockey.MockUnsafe(getLarkApprovalConfig).Return((*LarkApprovalConfig)(nil)).Build()

			ctx := context.Background()
			ret := GetLarkApprovalDataRule(ctx)

			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("getLarkApprovalConfig返回非nil时返回对应规则", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造有效的配置，覆盖目标函数的非nil分支
			expectRule := &LarkApprovalDataRule{
				BizLine:         "biz",
				Events:          []string{"evt1", "evt2"},
				DataRuleConfigs: map[string][]*DataRuleConfig{},
			}
			conf := &LarkApprovalConfig{
				LarkApprovalDataRule: expectRule,
				LarkFormFieldConfigs: map[string][]*LarkFormFieldConfig{},
			}

			// Mock内部依赖函数返回有效配置
			mockey.MockUnsafe(getLarkApprovalConfig).Return(conf).Build()

			ctx := context.Background()
			ret := GetLarkApprovalDataRule(ctx)

			convey.So(ret, convey.ShouldEqual, expectRule)
		})
	})
}

func Test_getLarkApprovalConfig_BitsUTGen(t *testing.T) {
	t.Run("configLoader未初始化时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 避免日志内部依赖影响测试稳定性
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// 将全局变量设置为typed nil，触发分支
			var nilLoader loader
			mockey.MockValue(&configLoader).To(nilLoader)

			ctx := context.Background()
			ret := getLarkApprovalConfig(ctx)

			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("configLoader已初始化时返回配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化并注入全局变量
			mockObj := &Mock_loader_getLarkApprovalConfig{}
			mockey.MockValue(&configLoader).To(mockObj)

			// 预期返回的配置指针
			expected := gptr.Of(LarkApprovalConfig{})

			// 对接口方法进行Mock，确保覆盖返回分支
			mockey.Mock((*Mock_loader_getLarkApprovalConfig).GetLarkApprovalConfig).Return(expected).Build()

			ctx := context.Background()
			ret := getLarkApprovalConfig(ctx)

			convey.So(ret, convey.ShouldEqual, expected)
		})
	})
}

func Test_GetApplyLarkFormFieldConfigs_BitsUTGen(t *testing.T) {
	t.Run("配置加载器返回nil配置，函数返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟内部获取配置方法返回nil，避免触发日志打印导致的空指针
			mockey.MockUnsafe(getLarkApprovalConfig).Return(nil).Build()

			ctx := context.Background()
			res := GetApplyLarkFormFieldConfigs(ctx, "any-type")

			// 断言返回nil分支
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("配置加载器返回包含目标类型的配置，函数返回对应字段配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造包含指定类型字段配置的LarkApprovalConfig
			typeA := "typeA"
			cfg1 := &LarkFormFieldConfig{FieldCode: "code1", FieldType: "text"}
			cfg2 := &LarkFormFieldConfig{FieldCode: "code2", FieldType: "number"}
			conf := &LarkApprovalConfig{
				LarkFormFieldConfigs: map[string][]*LarkFormFieldConfig{
					typeA: {cfg1, cfg2},
				},
			}

			// 模拟内部获取配置方法返回非nil配置
			mockey.MockUnsafe(getLarkApprovalConfig).Return(conf).Build()

			ctx := context.Background()

			// 命中类型，返回非nil切片
			res := GetApplyLarkFormFieldConfigs(ctx, typeA)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 2)
			convey.So(res, convey.ShouldResemble, conf.LarkFormFieldConfigs[typeA])

			// 未命中类型，返回nil（map缺失键时返回nil）
			resNil := GetApplyLarkFormFieldConfigs(ctx, "unknown-type")
			convey.So(resNil, convey.ShouldBeNil)
		})
	})
}

type Mock_loader_getLarkApprovalConfig struct {
	loader
}

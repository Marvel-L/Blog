package config

import "encoding/json"

type DefinitionFormData struct {
	CustomID           string                `json:"custom_id"`
	DefaultValueType   string                `json:"default_value_type"`
	ID                 string                `json:"id"`
	Name               string                `json:"name"`
	Option             interface{}           `json:"option"`
	optionValue        interface{}           `json:"-"` // 解析后的实际option
	Required           bool                  `json:"required"`
	Type               string                `json:"type"`
	WidgetDefaultValue string                `json:"widget_default_value"`
	Children           []*DefinitionFormData `json:"children,omitempty"`
}

type DefinitionOption struct {
	Value  string `json:"value"`
	Text   string `json:"text"`
	TextEn string `json:"text_en"`
}

type DefinitionOptionAmount struct {
	IsCapital     bool     `json:"isCapital"`
	CurrencyRange []string `json:"currencyRange"`
}

type DefinitionOptionFieldList struct {
	InputType        string `json:"input_type"`
	MobileDetailType string `json:"mobile_detail_type"`
	PrintType        string `json:"print_type"`
}

type DefinitionOptionDateInterval struct {
	DateCheckStart      int    `json:"dateCheckStart"`
	DateCheckEnd        int    `json:"dateCheckEnd"`
	DateCheckType       int    `json:"dateCheckType"`
	Start               string `json:"start"`
	End                 string `json:"end"`
	Interval            string `json:"interval"`
	IntervalAllowModify bool   `json:"intervalAllowModify"`
}

func (d *DefinitionFormData) Parse() error {
	if d.optionValue != nil {
		// 已经解析过
		return nil
	}
	if d.Option == nil {
		return nil
	}
	var err error
	body, _ := json.Marshal(d.Option)
	switch d.Type {
	case LarkFormTypeAmount:
		var value DefinitionOptionAmount
		if err = json.Unmarshal(body, &value); err != nil {
			return err
		}
		d.optionValue = &value
	case LarkFormTypeFieldList:
		var value DefinitionOptionFieldList
		if err = json.Unmarshal(body, &value); err != nil {
			return err
		}
		d.optionValue = &value
	case LarkFormTypeDateInterval:
		var value DefinitionOptionDateInterval
		if err = json.Unmarshal(body, &value); err != nil {
			return err
		}
		d.optionValue = &value
	default:
		var value []*DefinitionOption
		if err = json.Unmarshal(body, &value); err != nil {
			return err
		}
		d.optionValue = value
	}
	return nil
}

func (d *DefinitionFormData) GetOptionValue() interface{} {
	_ = d.Parse()
	return d.optionValue
}

const (
	LarkFormTypeAmount       = "amount"       // 金额
	LarkFormTypeFieldList    = "fieldList"    // 明细表
	LarkFormTypeDateInterval = "dateInterval" // 时间区间
)

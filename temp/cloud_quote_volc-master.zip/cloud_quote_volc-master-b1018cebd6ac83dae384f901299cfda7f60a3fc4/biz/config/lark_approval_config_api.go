package config

import (
	"context"

	"code.byted.org/gopkg/logs"
)

func getLarkApprovalConfig(ctx context.Context) *LarkApprovalConfig {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetLarkApprovalConfig(ctx)
}

func GetLarkApprovalDataRule(ctx context.Context) *LarkApprovalDataRule {
	config := getLarkApprovalConfig(ctx)
	if config == nil {
		return nil
	}
	return config.LarkApprovalDataRule
}

func GetApplyDataRuleConfigs(ctx context.Context, applicationType string) []*DataRuleConfig {
	approvalDataRule := GetLarkApprovalDataRule(ctx)
	if approvalDataRule == nil {
		return nil
	}
	return approvalDataRule.DataRuleConfigs[applicationType]
}

func GetApplyLarkFormFieldConfigs(ctx context.Context, applicationType string) []*LarkFormFieldConfig {
	config := getLarkApprovalConfig(ctx)
	if config == nil {
		return nil
	}
	return config.LarkFormFieldConfigs[applicationType]
}

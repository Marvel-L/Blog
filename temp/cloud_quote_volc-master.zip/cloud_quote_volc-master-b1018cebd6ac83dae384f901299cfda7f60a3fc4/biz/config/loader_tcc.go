package config

import (
	"context"
	"encoding/json"
	"time"

	"gopkg.in/yaml.v2"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/tccclient"
)

const (
	_tccConfigKey              = "config"                 //
	_tccEnumsKey               = "enums"                  //
	_tccOffPeakHoursBillingKey = "off_peak_hours_billing" // 闲时计费配置
	_tccI18nKey                = "i18n"                   // i18n配置
	_tccActionOpenListKey      = "action_open_list"       // 接口白名单配置
	_tccDiffConfigKey          = "diff_config"            // diff对比字段配置
	_tccWhiteListConfigKey     = "white_list_config"      // 白名单配置
	_tccEventConfigKey         = "event_config"           // 报价事件配置
	_tccSwitchConfigKey        = "switch_config"          // 报价开关配置
	_tccConstantsConfigKey     = "constants_config"       // 报价常量配置
	_tccLarkApprovalConfigKey  = "lark_approval_config"   // 飞书审批配置
)

type tccLoader struct {
	client *tccclient.ClientV2
}

func newTccLoader(psm string) loader {

	// TCC读取配置
	config := tccclient.NewConfigV2()
	config.FirstGetRetry = 3
	config.FirstGetTimeout = 3 * time.Second
	tccClient, err := tccclient.NewClientV2(psm, config)
	if err != nil {
		logs.Errorf("配置初始化失败, err: %s", err.Error())
		return nil
	}

	if tccClient == nil {
		logs.Errorf("配置初始化失败")
		return nil
	}

	return &tccLoader{
		client: tccClient,
	}
}

func (t *tccLoader) GetGlobalConf(ctx context.Context) *Conf {

	if t.client == nil {
		logs.CtxError(ctx, "GetConfFromTCCFail, client_is_nil")
		return nil
	}

	// 内置缓存
	cfgGetter := t.client.NewGetter(_tccConfigKey, yaml.Unmarshal, &Conf{})
	cfg, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetConfFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := cfg.(*Conf)
	if !ok {
		logs.CtxError(ctx, "GetConfFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetConfFromTCCFail, conf_is_nil")
	}
	return ret
}

func (t *tccLoader) GetAllEnums(ctx context.Context) map[string]map[string]string {
	if t.client == nil {
		logs.CtxError(ctx, "GetAllEnumsFromTCCFail, client_is_nil")
		return nil
	}

	cfgGetter := t.client.NewGetter(_tccEnumsKey, json.Unmarshal, map[string]map[string]string{})
	cfg, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetAllEnumsConfFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := cfg.(map[string]map[string]string)
	if !ok {
		logs.CtxError(ctx, "GetAllEnumsConfFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetAllEnumsFromTCCFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetAllOffPeakHoursBillingConf(ctx context.Context) map[string]*OffPeakHoursBillingConf {

	if t.client == nil {
		logs.CtxError(ctx, "GetAllOffPeakHoursBillingConfFromTCCFail, client_is_nil")
		return nil
	}

	var arr []*OffPeakHoursBillingConf
	cfgGetter := t.client.NewCastGetter(_tccOffPeakHoursBillingKey, json.Unmarshal, arr, offPeakHoursBillingCaster)
	cfg, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetAllOffPeakHoursBillingConfFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := cfg.(map[string]*OffPeakHoursBillingConf)
	if !ok {
		logs.CtxError(ctx, "GetAllOffPeakHoursBillingConfFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetAllOffPeakHoursBillingConfFromTCCFail, conf_is_nil")
	}

	return ret
}

func offPeakHoursBillingCaster(v interface{}) interface{} {

	ret := map[string]*OffPeakHoursBillingConf{}
	if v == nil {
		return ret
	}

	vv, ok := v.([]*OffPeakHoursBillingConf)
	if !ok {
		return ret
	}

	for _, vvv := range vv {
		ret[vvv.key()] = vvv
	}

	return ret
}

func (t *tccLoader) GetActionOpenMap(ctx context.Context) map[string]bool {
	if t.client == nil {
		logs.CtxError(ctx, "GetActionOpenMapFromTCCFail, client_is_nil")
		return nil
	}

	// 内置缓存
	cfgGetter := t.client.NewGetter(_tccActionOpenListKey, yaml.Unmarshal, &ActionOpenList{})
	actionOpenList, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetActionOpenMapFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := actionOpenList.(*ActionOpenList)
	if !ok {
		logs.CtxError(ctx, "GetActionOpenMapFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetActionOpenMapFromTCCFail, conf_is_nil")
		return nil
	}

	return ret.ActionMap
}

func (t *tccLoader) GetDiffConf(ctx context.Context) *DiffConf {
	if t.client == nil {
		logs.CtxError(ctx, "GetDiffConfFromTCCFail, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg DiffConf
	cfgGetter := t.client.NewGetter(_tccDiffConfigKey, yaml.Unmarshal, &cfg)
	diffConf, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetDiffConfFromTCCFailFail, err: %s", err.Error())
		return nil
	}

	ret, ok := diffConf.(*DiffConf)
	if !ok {
		logs.CtxError(ctx, "GetDiffConfFromTCCFailFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetDiffConfFromTCCFailFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetWhiteListConf(ctx context.Context) *WhiteListConf {
	if t.client == nil {
		logs.CtxError(ctx, "GetWhiteListConf, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg WhiteListConf
	cfgGetter := t.client.NewGetter(_tccWhiteListConfigKey, yaml.Unmarshal, &cfg)
	whiteConf, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetWhiteListConfFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := whiteConf.(*WhiteListConf)
	if !ok {
		logs.CtxError(ctx, "GetWhiteListConfFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetWhiteListConfFromTCCFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetEventConfig(ctx context.Context) *EventConfig {
	if t.client == nil {
		logs.CtxError(ctx, "GetEventConfig, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg EventConfig
	cfgGetter := t.client.NewGetter(_tccEventConfigKey, yaml.Unmarshal, &cfg)
	eventConfig, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetEventConfigFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := eventConfig.(*EventConfig)
	if !ok {
		logs.CtxError(ctx, "GetEventConfigFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetEventConfigFromTCCFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetSwitchConfig(ctx context.Context) map[string]*SwitchModel {
	if t.client == nil {
		logs.CtxError(ctx, "GetEventConfig, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg map[string]*SwitchModel
	cfgGetter := t.client.NewGetter(_tccSwitchConfigKey, yaml.Unmarshal, cfg)
	switchConfig, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetSwitchConfigFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := switchConfig.(map[string]*SwitchModel)
	if !ok {
		logs.CtxError(ctx, "GetSwitchConfigFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetSwitchConfigFromTCCFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetConstantsConfig(ctx context.Context) map[string][]*ConstantsModel {
	if t.client == nil {
		logs.CtxError(ctx, "GetConstantsConfig, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg map[string][]*ConstantsModel
	cfgGetter := t.client.NewGetter(_tccConstantsConfigKey, yaml.Unmarshal, cfg)
	constantsConfig, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetConstantsConfigFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := constantsConfig.(map[string][]*ConstantsModel)
	if !ok {
		logs.CtxError(ctx, "GetConstantsConfigFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetConstantsConfigFromTCCFail, conf_is_nil")
	}

	return ret
}

func (t *tccLoader) GetLarkApprovalConfig(ctx context.Context) *LarkApprovalConfig {
	if t.client == nil {
		logs.CtxError(ctx, "GetLarkApprovalConfig, client_is_nil")
		return nil
	}

	// 内置缓存
	var cfg LarkApprovalConfig
	cfgGetter := t.client.NewGetter(_tccLarkApprovalConfigKey, yaml.Unmarshal, &cfg)
	larkApprovalConfig, err := cfgGetter(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetLarkApprovalConfigFromTCCFail, err: %s", err.Error())
		return nil
	}

	ret, ok := larkApprovalConfig.(*LarkApprovalConfig)
	if !ok {
		logs.CtxError(ctx, "GetLarkApprovalConfigFromTCCFail, type_not_match")
		return nil
	}

	if ret == nil {
		logs.CtxError(ctx, "GetLarkApprovalConfigFromTCCFail, conf_is_nil")
	}

	return ret
}

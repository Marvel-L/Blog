package config

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/gopkg/logs"
)

// GetGlobalConf 获取全局配置
func GetGlobalConf(ctx context.Context) *Conf {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetGlobalConf(ctx)
}

func GetLarkConf(ctx context.Context) *LarkBot {
	cfg := GetGlobalConf(ctx)
	if cfg == nil {
		return nil
	}
	return cfg.LarkBot
}

// GetDesignatedDepartmentId 获取指定部门ID
func GetDesignatedDepartmentId(ctx context.Context) string {
	larkConf := GetLarkConf(ctx)
	if larkConf == nil {
		return ""
	}
	return larkConf.DesignatedDepartmentId
}

// GetDesignatedDepartmentName 获取被指定的部门名称
func GetDesignatedDepartmentName(ctx context.Context) string {
	larkConf := GetLarkConf(ctx)
	if larkConf == nil {
		return ""
	}
	return larkConf.DesignatedDepartmentName
}

func GetSourceMap(ctx context.Context) map[string]string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.ConfigMap["SourceMap"]
	}
	return nil
}

func GetEnumConfig(ctx context.Context, enumKey string) map[string]string {
	configMap := constants.DefaultConfigMap
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		configMap = cfg.QuoteApp.ConfigMap
	}
	return configMap[enumKey]
}
func GetAllEnumConfig(ctx context.Context) map[string]map[string]string {
	configMap := constants.DefaultConfigMap
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		configMap = cfg.QuoteApp.ConfigMap
	}
	return configMap
}

func GetMaxItemNum(ctx context.Context) int {
	maxItemNum := constants.QuoteItemsMaxNum
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		maxItemNum = cfg.QuoteApp.MaxItemNum
	}
	return maxItemNum
}

func GetMaxTplItemNum(ctx context.Context) int {
	return GetMaxItemNum(ctx) / 2
}

func GetSubmitNotifyTime(ctx context.Context) int {
	submitNotifyTime := constants.SubmitNotifyTime
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		submitNotifyTime = cfg.QuoteApp.SubmitNotifyTime
	}
	return submitNotifyTime
}

func GetDefaultQuoteItem(ctx context.Context) *DefaultQuoteItem {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.DefaultQuoteItem
	}
	return nil
}

func GetLarkBot(ctx context.Context) *LarkBot {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.LarkBot
	}
	return nil
}

func GetProductSolutionRoleIdentifier(ctx context.Context) []string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil && cfg.Products != nil && len(cfg.Products.ProductSolutionFlag) > 0 {
		return cfg.Products.ProductSolutionFlag
	}
	return []string{"产品解决方案"}
}

func GetDefaultConfigListApprovalNotifier(ctx context.Context) []string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil && cfg.QuoteConfigListConf != nil && len(cfg.QuoteConfigListConf.DefaultNotifiers) > 0 {
		return cfg.QuoteConfigListConf.DefaultNotifiers
	}
	return nil
}

func GetEnums(ctx context.Context, key string) map[string]string {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	allEnums := configLoader.GetAllEnums(ctx)
	return allEnums[key]
}

func GetOffPeakHoursBillingConf(ctx context.Context, product, configuration, chargeItemCode string) *OffPeakHoursBillingConf {
	if product == "" {
		logs.CtxError(ctx, "product不能为空")
		return nil
	}
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}

	conf := configLoader.GetAllOffPeakHoursBillingConf(ctx)

	// 优先精确匹配
	key := buildOffPeakHoursBillingKey(product, configuration, chargeItemCode)
	if conf[key] != nil {
		return conf[key]
	}

	// 匹配不到时，尝试匹配：商品+配置
	key = buildOffPeakHoursBillingKey(product, configuration, "*")
	return conf[key]
}

func GetAllOffPeakHoursBillingConf(ctx context.Context) []*OffPeakHoursBillingConf {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}

	conf := configLoader.GetAllOffPeakHoursBillingConf(ctx)
	var list []*OffPeakHoursBillingConf
	for _, v := range conf {
		list = append(list, v)
	}

	return list
}

func GetUploadModel(ctx context.Context, modelKey string) *FileModel {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.UploadModelMap[modelKey]
	}
	return nil
}

func GetProfitCalculateModifySwitch(ctx context.Context) bool {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.ProfitCalculateModifySwitch

	}
	return false
}

func GetPipelineCmdNum(ctx context.Context) int {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.PipelineCmdNum
	}
	return constants.PipelineCmdNum
}

func GetEmployeeSearchSwitch(ctx context.Context) bool {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.LarkBot.SearchEmployeeSwitch
	}
	return false
}
func GetQuoteApprovalSplitSwitch(ctx context.Context) bool {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.LarkBot.QuoteApprovalSplitSwitch
	}
	return true
}

func GetChargeItemKeyFromStr(ctx context.Context) bool {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		logs.CtxInfo(ctx, "GetChargeItemKeyFromStr %v", cfg.QuoteApp.ChargeItemKeyReadStr)
		return cfg.QuoteApp.ChargeItemKeyReadStr
	}
	return false
}

func GetChargeItemKeyGroupNum(ctx context.Context) int {
	cfg := GetGlobalConf(ctx)
	if cfg == nil || cfg.QuoteApp.ChargeItemKeyGroupNum == 0 {
		return constants.ChargeItemKeyGroupNumDefault
	}
	logs.CtxInfo(ctx, "GetChargeItemKeyGroupNum %v", cfg.QuoteApp.ChargeItemKeyGroupNum)
	return cfg.QuoteApp.ChargeItemKeyGroupNum
}

func GetHealthCheckAllow(ctx context.Context) bool {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.HealthCheckAllow
	}
	return false
}

func GetActionOpenMap(ctx context.Context) map[string]bool {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetActionOpenMap(ctx)
}

func GetOpenApiAppKeyCrm(ctx context.Context) string {
	cfg := GetGlobalConf(ctx)
	if cfg == nil {
		return constants.OpenApiAppKeyCrm
	}
	return cfg.QuoteApp.ConfigMap[constants.OpenApiAppKey][constants.OpenApiAppKeyCrm]
}

// GetDiffConf 获取字段对比配置.
func GetDiffConf(ctx context.Context) *DiffConf {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetDiffConf(ctx)
}

func GetQAWhiteList(ctx context.Context) map[string]bool {
	m := map[string]bool{}
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		for _, qaEmail := range cfg.QuoteApp.QAWhiteList {
			m[qaEmail] = true
		}
	}
	return m
}

func GetMaskKeyMap(ctx context.Context) map[string]string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.MaskKeyMap
	}
	return nil
}

func GetSubmitFailCount(ctx context.Context) int {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApprovalConf.QuoteSubmitFailCount
	}
	return 0
}

// GetWhiteListConf 获取白名单配置
func GetWhiteListConf(ctx context.Context) *WhiteListConf {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetWhiteListConf(ctx)
}

// GetContractPriceFailCount 获取创建合同价失败重试次数
func GetContractPriceFailCount(ctx context.Context) int {
	cfg := GetGlobalConf(ctx)
	if cfg != nil && cfg.ContractPriceConf != nil {
		return cfg.ContractPriceConf.ContractPriceFailCount
	}
	return 0
}

func GetCreatePriceNumLimit(ctx context.Context) int {
	cfg := GetGlobalConf(ctx)
	if cfg != nil && cfg.ContractPriceConf != nil {
		return cfg.ContractPriceConf.CreatePriceNumLimit
	}
	return 0
}

func GetLarkApprovalStatusAudit(ctx context.Context) *LarkApprovalStatusAudit {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.LarkApprovalStatusAudit
	}
	return nil
}

func GetEventConfig(ctx context.Context) *EventConfig {
	if configLoader == nil {
		logs.CtxError(ctx, "configLoader尚未初始化")
		return nil
	}
	return configLoader.GetEventConfig(ctx)
}

func GetSwitchCouponConf(ctx context.Context) *SwitchCouponConf {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.SwitchCouponConf
	}
	return nil
}

func GetApprovalTimeOutAlarmExecConf(ctx context.Context) *ApprovalTimeOutAlarmExecConf {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.ApprovalTimeOutAlarmExecConf
	}
	return nil
}

func GetDevSreQuoteDetailLink(ctx context.Context) string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.DevSreQuoteDetailLink
	}
	return ""
}

func GetHolidayConf(ctx context.Context) *HolidayConf {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.HolidayConf
	}
	return nil
}

func GetDiscountLineToApprovalMap(ctx context.Context) map[string]string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.DiscountLineToApprovalMap
	}
	return nil
}

func GetQuotePreviewLink(ctx context.Context) string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.PreviewLink
	}
	return ""
}

func GetRefreshTaskPreviewLink(ctx context.Context) string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.RefreshTaskPreviewLink
	}
	return ""
}

func GetLarkMobileLink(ctx context.Context) string {
	cfg := GetGlobalConf(ctx)
	if cfg != nil {
		return cfg.QuoteApp.LarkMobileLink
	}
	return ""
}

// IsSpotQuoteTradeProductBlocked 判断某个商品是否命中“禁止 Spot 报价”TCC 黑名单。
// BlackList：仅存 TradeProduct，例如 "ECS".
func IsSpotQuoteTradeProductBlocked(ctx context.Context, tradeProduct string) bool {
	if tradeProduct == "" {
		return false
	}

	sw := GetSwitchByName(ctx, SwitchForbidSpotQuoteSelection)
	if sw == nil || !sw.IsOpen || len(sw.BlackList) == 0 {
		return false
	}

	for _, item := range sw.BlackList {
		if item == tradeProduct {
			return true
		}
	}

	return false
}

package config

import (
	"context"
	"encoding/json"
	"github.com/shopspring/decimal"
	"strings"
	"testing"
)

func backTestParseOffPeakHoursBillingConf(t *testing.T) {
	var data = `
  {
    "TradeProduct": "CDN",
    "Configuration": "cdn_95_bandwidth_avg_monthly",
    "ChargeItemCode": "*",
    "Periods": [
      "0-8",
      "1-9",
      "0-18"
    ],
    "DiscountRatios": [
      "",
      "0.5",
      "0.4"
    ]
  }
`
	var cfg OffPeakHoursBillingConf
	err := json.Unmarshal([]byte(data), &cfg)
	t.Log(err)
	for _, v := range cfg.DiscountRatios {
		t.Log(v.StringFixed(3))
	}
}

func backTestInit(t *testing.T) {
	err := Init("eps.platform.cloud_quote_volc")
	if err != nil {
		panic(err)
	}
	list := GetOffPeakHoursBillingConf(context.Background(), "", "", "")
	t.Log(list)
}

func backTestParseOffPeakConf(t *testing.T) {
	s := `
CDN	cdn_95_bandwidth_avg_monthly	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_95_bandwidth_avg_monthly_1024	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_bandwidth_daily	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_bandwidth_daily_1024	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_peak_bandwidth_avg_monthly	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_peak_bandwidth_avg_monthly_1024	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_bandwidth_monthly	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_bandwidth_monthly_1024	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_peak_bandwidth_fourth_monthly	*	0-8点、1-9点、0-18点	50%，40%
CDN	cdn_peak_bandwidth_fourth_monthly_1024	*	0-8点、1-9点、0-18点	50%，40%
CDN	Byte_Freetime_sum_hourly	*	0-8点、1-9点、0-18点	100%
CDN	Byte_Freetime_sum_hourly_1024	*	0-8点、1-9点、0-18点	100%
CDN	Byte_Freetime_sum_monthly	*	0-8点、1-9点、0-18点	100%
CDN	Byte_Freetime_sum_monthly_1024	*	0-8点、1-9点、0-18点	100%
`
	arr := strings.Split(s, "\n")
	var list []*OffPeakHoursBillingConf
	for _, v := range arr {
		t.Log(v)
		arr2 := strings.Split(v, "\t")
		if len(arr2) != 5 {
			continue
		}

		periods := strings.Split(arr2[3], "、")
		for idx, p := range periods {
			p = strings.ReplaceAll(p, "点", "")
			periods[idx] = p
		}

		ratioStrs := strings.Split(arr2[4], "，")
		var ratios []decimal.Decimal
		for _, ratio := range ratioStrs {
			ratio = strings.ReplaceAll(ratio, "%", "")
			value, _ := decimal.NewFromString(ratio)
			value1 := value.Div(decimal.NewFromFloat(100))
			ratios = append(ratios, value1)
		}

		list = append(list, &OffPeakHoursBillingConf{
			TradeProduct:   arr2[0],
			Configuration:  arr2[1],
			ChargeItemCode: arr2[2],
			Periods:        periods,
			DiscountRatios: ratios,
		})
	}
	body, _ := json.Marshal(list)
	t.Log(string(body))
}

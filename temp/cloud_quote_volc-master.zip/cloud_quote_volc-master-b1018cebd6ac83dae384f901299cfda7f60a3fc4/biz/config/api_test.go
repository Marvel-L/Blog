package config

import (
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestGetSubmitFailCount(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				QuoteApprovalConf: QuoteApprovalConf{
					QuoteSubmitFailCount: 0,
				},
			}).Build()

			// Act
			got := GetSubmitFailCount(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, 0)
		})
	})
}

func TestGetContractPriceFailCount(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				ContractPriceConf: &ContractPriceConf{
					ContractPriceFailCount: 0,
				},
			}).Build()

			// Act
			got := GetContractPriceFailCount(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, 0)
		})
	})
}

func TestGetCreatePriceNumLimit(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				ContractPriceConf: &ContractPriceConf{
					CreatePriceNumLimit: 0,
				},
			}).Build()

			// Act
			got := GetCreatePriceNumLimit(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, 0)
		})
	})
}
func TestGetLarkApprovalStatusAudit(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				LarkApprovalStatusAudit: &LarkApprovalStatusAudit{},
			}).Build()

			// Act
			got := GetLarkApprovalStatusAudit(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

func TestGetSwitchCouponConf(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{SwitchCouponConf: &SwitchCouponConf{}}).Build()

			// Act
			got := GetSwitchCouponConf(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}
func TestGetDiscountLineToApprovalMap(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				DiscountLineToApprovalMap: map[string]string{"": ""},
			}).Build()

			// Act
			got := GetDiscountLineToApprovalMap(context.Background())

			// Assert
			convey.So(got, convey.ShouldResemble, map[string]string{"": ""})
		})
	})
}

func TestGetQuotePreviewLink(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				QuoteApp: &QuoteApp{
					PreviewLink: "",
				},
			}).Build()

			// Act
			got := GetQuotePreviewLink(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "")
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestGetRefreshTaskPreviewLink(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				QuoteApp: &QuoteApp{
					RefreshTaskPreviewLink: "https://quote.example.com/RefreshTask/preview?QuoteID=%d&RefreshApprovalID=%d",
				},
			}).Build()

			// Act
			got := GetRefreshTaskPreviewLink(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "https://quote.example.com/RefreshTask/preview?QuoteID=%d&RefreshApprovalID=%d")
		})
	})
}

func TestGetLarkMobileLink(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetGlobalConf).Return(&Conf{
				QuoteApp: &QuoteApp{
					LarkMobileLink: "",
				},
			}).Build()

			// Act
			got := GetLarkMobileLink(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "")
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestIsSpotQuoteTradeProductBlocked(t *testing.T) {
	t.Run("tradeProduct为空时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			got := IsSpotQuoteTradeProductBlocked(context.Background(), "")

			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("开关不存在时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(GetSwitchByName).Return(nil).Build()

			got := IsSpotQuoteTradeProductBlocked(context.Background(), "ECS")

			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("开关未打开时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(GetSwitchByName).Return(&SwitchModel{
				IsOpen:    false,
				BlackList: []string{"ECS"},
			}).Build()

			got := IsSpotQuoteTradeProductBlocked(context.Background(), "ECS")

			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("黑名单命中时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(GetSwitchByName).Return(&SwitchModel{
				IsOpen:    true,
				BlackList: []string{"ECS", "RDS"},
			}).Build()

			got := IsSpotQuoteTradeProductBlocked(context.Background(), "ECS")

			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("黑名单未命中时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(GetSwitchByName).Return(&SwitchModel{
				IsOpen:    true,
				BlackList: []string{"RDS"},
			}).Build()

			got := IsSpotQuoteTradeProductBlocked(context.Background(), "ECS")

			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_GetDesignatedDepartmentName_BitsUTGen(t *testing.T) {
	t.Run("当LarkConf为空时返回空字符串", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟全局配置为空，保证GetLarkConf返回nil
			mockey.Mock(GetGlobalConf).Return(nil).Build()

			got := GetDesignatedDepartmentName(context.Background())
			convey.So(got, convey.ShouldEqual, "")
		})
	})

	t.Run("当LarkConf存在时返回被指定部门名称", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟LarkBot配置存在，返回指定的部门名称
			mockey.Mock(GetGlobalConf).Return(&Conf{
				LarkBot: &LarkBot{
					DesignatedDepartmentName: "企业合作与解决方案",
				},
			}).Build()

			got := GetDesignatedDepartmentName(context.Background())
			convey.So(got, convey.ShouldEqual, "企业合作与解决方案")
		})
	})
}

func Test_GetDesignatedDepartmentId_BitsUTGen(t *testing.T) {
	t.Run("GetGlobalConf返回nil时返回空字符串", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟配置未初始化
			mockey.Mock(GetGlobalConf).Return(nil).Build()

			// 调用待测函数
			got := GetDesignatedDepartmentId(context.Background())

			// 断言返回空字符串
			convey.So(got, convey.ShouldEqual, "")
		})
	})

	t.Run("GetGlobalConf返回包含LarkBot时返回指定部门ID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟返回包含LarkBot的配置
			mockey.Mock(GetGlobalConf).Return(&Conf{
				LarkBot: &LarkBot{
					DesignatedDepartmentId: "od-123456",
				},
			}).Build()

			// 调用待测函数
			got := GetDesignatedDepartmentId(context.Background())

			// 断言返回指定的部门ID
			convey.So(got, convey.ShouldEqual, "od-123456")
		})
	})
}

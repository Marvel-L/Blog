package config

type EventConfig struct {
	BinlogConfig  *BinlogConfig             `yaml:"BinlogConfig"`  // Binlog消费配置
	EventSwitch   *EventSwitch              `yaml:"EventSwitch"`   // 事件开关
	EventProducer *EventProducer            `yaml:"EventProducer"` // 事件生产配置
	EventTables   map[string]*TableDetail   `yaml:"EventTables"`   // 表详情
	EventDetails  map[string][]*EventDetail `yaml:"EventDetails"`  // 事件详情
}

type BinlogConfig struct {
	DisableBinlog     bool   `yaml:"DisableBinlog"`
	ClientConfigEpoch int64  `yaml:"ClientConfigEpoch"` // ConfigEpoch 配置版本，只能逐步改大，不能改小 https://bytedance.larkoffice.com/docx/doxcnYsxusAtYWzEAGSu8FdMnGd
	ClusterName       string `yaml:"ClusterName"`
	Topic             string `yaml:"Topic"`
	Group             string `yaml:"Group"`
}

type EventSwitch struct {
	OpenLog bool `yaml:"OpenLog"`
}

type EventProducer struct {
	Topic string `yaml:"Topic"`
}

type TableDetail struct {
	TableType string `yaml:"TableType"` // 表类型
}

type EventDetail struct {
	MatchEvent  string        `yaml:"MatchEvent"`  // 匹配事件
	RuleDetails []*RuleDetail `yaml:"RuleDetails"` // 规则详情
}

type RuleDetail struct {
	RuleType     string        `yaml:"RuleType"`     // 规则类型
	IgnoreFields []*FieldValue `yaml:"IgnoreFields"` // 忽略字段列表
	NoticeFields []*FieldValue `yaml:"NoticeFields"` // 关注字段列表
	Fields       []string      `yaml:"Fields"`       // 字段列表
	FieldsValues []*FieldValue `yaml:"FieldsValues"` // 字段值列表
}

type FieldValue struct {
	FieldName        string   `yaml:"FieldName"`        // 字段名称
	FieldBeforeValue []string `yaml:"FieldBeforeValue"` // 字段变更前的值
	FieldAfterValue  []string `yaml:"FieldAfterValue"`  // 字段变更后的值
}

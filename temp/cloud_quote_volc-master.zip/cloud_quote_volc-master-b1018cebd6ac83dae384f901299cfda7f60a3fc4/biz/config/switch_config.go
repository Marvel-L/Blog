package config

type SwitchModel struct {
	IsOpen    bool              `yaml:"IsOpen"`    // 是否打开
	TimeOut   int64             `yaml:"TimeOut"`   // 超时时间毫秒，选用
	UseCache  bool              `yaml:"UseCache"`  // 使用缓存
	MaxNum    int               `yaml:"MaxNum"`    // 最大数量
	MinNum    int               `yaml:"MinNum"`    // 最小数量
	WhiteList []string          `yaml:"WhiteList"` // 白名单
	BlackList []string          `yaml:"BlackList"` // 黑名单
	MockData  string            `yaml:"MockData"`  // mock数据
	Mapping   map[string]string `yaml:"Mapping"`   // 数据映射
}

package config

import (
	"errors"
	"sync"

	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
)

var once sync.Once
var configLoader loader

// Init 初始化配置
func Init(tccPSM string) error {

	once.Do(func() {
		if tccPSM == "" {
			tccPSM = env.PSM()
		}
		logs.Info("init_config_from_tcc tcc: %s", tccPSM)
		configLoader = newTccLoader(tccPSM)
	})

	if configLoader == nil {
		return errors.New("config初始化失败")
	}

	return nil
}

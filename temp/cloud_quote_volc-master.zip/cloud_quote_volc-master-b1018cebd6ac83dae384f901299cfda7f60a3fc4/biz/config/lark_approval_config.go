package config

type LarkApprovalConfig struct {
	LarkApprovalDataRule *LarkApprovalDataRule             `yaml:"LarkApprovalDataRule"` // 飞书审批数据规则
	LarkFormFieldConfigs map[string][]*LarkFormFieldConfig `yaml:"LarkFormFieldConfigs"` // 飞书表单字段配置
}

type LarkApprovalDataRule struct {
	BizLine         string                       `yaml:"BizLine"`         // 业务线
	Events          []string                     `yaml:"Events"`          // 事件（配置中依赖所有事件，初始化时使用）
	DataRuleConfigs map[string][]*DataRuleConfig `yaml:"DataRuleConfigs"` // 数据规则配置
}

type DataRuleConfig struct {
	Event      string `yaml:"Event"`      // 事件
	TriggerKey string `yaml:"TriggerKey"` // 触发键
	DataCode   string `yaml:"DataCode"`   // 数据code
}

type LarkFormFieldConfig struct {
	FieldCode                string                 `yaml:"FieldCode"`                // 字段code
	FieldType                string                 `yaml:"FieldType"`                // 字段类型
	DataPath                 string                 `yaml:"DataPath"`                 // 数据路径
	DefaultValue             interface{}            `yaml:"DefaultValue"`             // 默认值
	StartTimeFormFieldConfig *LarkFormFieldConfig   `yaml:"StartTimeFormFieldConfig"` // 开始时间表单字段配置（仅字段类型为日期区间时存在）
	EndTimeFormFieldConfig   *LarkFormFieldConfig   `yaml:"EndTimeFormFieldConfig"`   // 结束时间表单字段配置（仅字段类型为日期区间时存在）
	SubFormFieldConfigs      []*LarkFormFieldConfig `yaml:"SubFormFieldConfigs"`      // 子表字段配置（仅字段类型为明细子表时存在）
}

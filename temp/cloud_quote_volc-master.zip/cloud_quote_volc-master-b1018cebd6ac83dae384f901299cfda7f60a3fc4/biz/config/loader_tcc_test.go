package config

import (
	"code.byted.org/gopkg/tccclient"
	"context"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func Test_tccLoader_GetSwitchConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return nil, fmt.Errorf("your error")
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(v).Build()

			// Act
			v1 := &tccLoader{
				client: nil,
			}
			got := v1.GetSwitchConfig(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return nil, fmt.Errorf("your error")
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(v).Build()

			// Act
			v1 := &tccLoader{
				client: &tccclient.ClientV2{},
			}
			got := v1.GetSwitchConfig(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return nil, nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(v).Build()

			// Act
			v1 := &tccLoader{
				client: &tccclient.ClientV2{},
			}
			got := v1.GetSwitchConfig(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return map[string]*SwitchModel{"123": &SwitchModel{}}, nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(v).Build()

			// Act
			v1 := &tccLoader{
				client: &tccclient.ClientV2{},
			}
			got := v1.GetSwitchConfig(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})

}

func Test_tccLoader_GetConstantsConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return map[string][]*ConstantsModel{"test": {{Code: "1"}, {Code: "2"}}}, nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(v).Build()

			// Act
			v1 := &tccLoader{
				client: &tccclient.ClientV2{},
			}
			got := v1.GetConstantsConfig(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

func Test_tccLoader_GetLarkApprovalConfig_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	t.Run("client is nil returns nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			loader := &tccLoader{client: nil}
			got := loader.GetLarkApprovalConfig(ctx)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("getter returns error returns nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			getter := tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return nil, fmt.Errorf("mock error")
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(getter).Build()

			loader := &tccLoader{client: &tccclient.ClientV2{}}
			got := loader.GetLarkApprovalConfig(ctx)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("type assert mismatch returns nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			getter := tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return "not-lark-approval-config", nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(getter).Build()

			loader := &tccLoader{client: &tccclient.ClientV2{}}
			got := loader.GetLarkApprovalConfig(ctx)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("typed nil returned config returns nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var cfg *LarkApprovalConfig = nil
			getter := tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return cfg, nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(getter).Build()

			loader := &tccLoader{client: &tccclient.ClientV2{}}
			got := loader.GetLarkApprovalConfig(ctx)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("valid config returned non-nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &LarkApprovalConfig{}
			getter := tccclient.Getter(func(ctx context.Context) (interface{}, error) {
				return cfg, nil
			})
			mockey.Mock((*tccclient.ClientV2).NewGetter).Return(getter).Build()

			loader := &tccLoader{client: &tccclient.ClientV2{}}
			got := loader.GetLarkApprovalConfig(ctx)
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

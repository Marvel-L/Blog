package datacompare

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

func Test_SupplyConfigListDiffHandler_getSupplySceneType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			supplySceneType := diffHandler.getSupplySceneType()

			// Assert
			convey.So(supplySceneType, convey.ShouldNotBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_validateQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			err := diffHandler.validateQuote(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := &SupplyConfigListDiffHandler{
				SrcQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 2,
					},
					ParentQuoteID: 1,
				},
				DestQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 1,
					},
					ParentQuoteID: 0,
				},
				isChildVSParent: true,
			}

			// Act
			err := diffHandler.validateQuote(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_needDiffInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			result1 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteBaseInfo)
			result2 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteItemContext)
			result3 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteCoupon)
			result4 := diffHandler.needDiffInfo(multienv.InfoTypeJointPrintOrder)
			result666 := diffHandler.needDiffInfo(666)

			// Assert
			convey.So(result1, convey.ShouldBeTrue)
			convey.So(result2, convey.ShouldBeTrue)
			convey.So(result3, convey.ShouldBeFalse)
			convey.So(result4, convey.ShouldBeFalse)
			convey.So(result666, convey.ShouldBeFalse)
		})
	})
}

func Test_SupplyConfigListDiffHandler_getDiffFieldConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			fieldConfig := diffHandler.getDiffFieldConfig(nil)

			// Assert
			convey.So(fieldConfig, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_getDiffQuoteBaseInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteBaseInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_getDiffQuoteItemInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteItemInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_getDiffQuoteCouponInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCouponInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_getDiffQuoteGuaranteeInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func Test_SupplyConfigListDiffHandler_getDiffQuoteCreditInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCreditInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func Test_SupplyConfigListDiffHandler_getDiffQuoteRebateInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_SupplyConfigListDiffHandler_diffQuoteItemsResultPostProcessing(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getSupplyConfigListDiffHandler()

			// Act
			diffHandler.diffQuoteItemsResultPostProcessing(nil, nil)

			// Assert
		})
	})
}

func getSupplyConfigListDiffHandler() *SupplyConfigListDiffHandler {
	return &SupplyConfigListDiffHandler{
		SrcQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 1,
			},
			ParentQuoteID: 0,
		},
		DestQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 2,
			},
			ParentQuoteID: 1,
		},
		isChildVSParent: false,
	}
}

package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// ProjectBasedSupplyDiffHandler   补充项目制报价单 Diff处理器
type ProjectBasedSupplyDiffHandler struct {
	SrcQuoteDB      *model.Quote
	DestQuoteDB     *model.Quote
	isChildVSParent bool
}

const (
	Price       = "Price"       // 刊例价单价
	MarketPrice = "MarketPrice" // 市场价单价
)

func (h *ProjectBasedSupplyDiffHandler) getSupplySceneType() string {
	return multienv.ProjectSupplyAgreement
}

func (h *ProjectBasedSupplyDiffHandler) validateQuote(ctx context.Context, tx *gorm.DB) error {
	return nil
}

func (h *ProjectBasedSupplyDiffHandler) needDiffInfo(infoType multienv.QuoteInfoType) bool {
	if infoType == multienv.InfoTypeQuoteBaseInfo {
		return true
	}
	if infoType == multienv.InfoTypeQuoteItemContext {
		return true
	}
	if infoType == multienv.InfoTypeQuoteCoupon {
		return true
	}
	if infoType == multienv.InfoTypeQuoteGuarantee {
		return true
	}
	if infoType == multienv.InfoTypeQuoteRebate {
		return true
	}
	return false
}

func (h *ProjectBasedSupplyDiffHandler) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return getDiffFieldConfigBySceneType(diffFieldMap, h.getSupplySceneType())
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(h.SrcQuoteDB, h.DestQuoteDB, h.isChildVSParent)

	// 子补充项目制报价单，额外查询失效报价项、交付项
	childCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, childQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,           // 报价项
				assistant.CallbackKeyQuoteItemsExpired,    // 失效报价项
				assistant.CallbackKeyDeliveryItems,        // 交付项
				assistant.CallbackKeyDeliveryItemsExpired, // 失效交付项
				assistant.CallbackKeyItemValues,           // 报价项条目
				assistant.CallbackKeyQuote,                // 报价单
				assistant.CallbackKeyItemCalculates,       // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems,     // 代金券信息
				assistant.CallbackKeyItemCouponRatio,      // 报价项返券比例
				assistant.CallbackKeyRebate,               // 返佣记录
			},
		),
	)

	if err != nil || childCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteItemInfo, childCallbackInfo fail, childQuoteID=%d, err=%+v", childQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	// 根据子补充项目制报价单，获取父项目制报价单失效的报价项、交付项
	expiredParentItems := getExpiredParentItems(childCallbackInfo.AllQuoteItemsExpired, childCallbackInfo.AllDeliveryItemsExpired)

	// 父项目制报价单
	parentCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, parentQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,       // 报价项
				assistant.CallbackKeyDeliveryItems,    // 交付项
				assistant.CallbackKeyItemValues,       // 报价项条目
				assistant.CallbackKeyQuote,            // 报价单
				assistant.CallbackKeyItemCalculates,   // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems, // 代金券信息
				assistant.CallbackKeyItemCouponRatio,  // 报价项返券比例
				assistant.CallbackKeyRebate,           // 返佣记录
			},
		),
	)

	if err != nil || parentCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteItemInfo, parentCallbackInfo fail, parentQuoteID=%d, err=%+v", parentQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	// 父项目制报价单，过滤失效报价项、交付项
	parentCallbackInfo.AllQuoteItems = filterExpiredItems(expiredParentItems, parentCallbackInfo.AllQuoteItems)
	parentCallbackInfo.AllDeliveryItems = filterExpiredItems(expiredParentItems, parentCallbackInfo.AllDeliveryItems)

	srcCallbackInfo, destCallbackInfo := getSrcVSDestCallbackInfo(childCallbackInfo, parentCallbackInfo, h.isChildVSParent)
	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteCouponInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteCouponInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)
	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteGuaranteeInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)
	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteGuaranteeInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteRebateInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedSupplyDiffHandler]getDiffQuoteRebateInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedSupplyDiffHandler) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
	var sameList []string

	for itemID, changedDetail := range compareResult.ChangedDetails {
		// 市场价单价、刊例价单价是否存在变化
		_, marketPriceExist := changedDetail[MarketPrice]
		_, priceExist := changedDetail[Price]
		if !marketPriceExist && !priceExist {
			continue
		}

		// 市场价单价、刊例价单价，无需返回变更字段
		delete(changedDetail, MarketPrice)
		delete(changedDetail, Price)

		// 利润依赖字段是否存在变化
		var dependFieldsChange bool
		for _, fieldCode := range processInfo.diffConf.ProfitDiffDependFields {
			if _, exist := changedDetail[fieldCode]; exist {
				dependFieldsChange = true
				break
			}
		}
		if dependFieldsChange {
			// 利润依赖字段存在变化，直接忽略
			continue
		}

		// 利润依赖字段不存在变化，删除忽略变更字段
		for _, fieldCode := range processInfo.diffConf.StandardPriceDiffIgnoreFields {
			delete(changedDetail, fieldCode)
		}

		if len(changedDetail) == 0 {
			// 删除后，如果没有变更字段，则认为未变更
			sameList = append(sameList, itemID)
		}
	}

	// 更新变更报价项信息
	for _, itemID := range sameList {
		delete(compareResult.ChangedDetails, itemID)
		compareResult.ChangedList = util.DeleteSliceValue(compareResult.ChangedList, itemID)
		compareResult.SameList = append(compareResult.SameList, itemID)
	}
}

func (h *ProjectBasedSupplyDiffHandler) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *ProjectBasedSupplyDiffHandler) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *ProjectBasedSupplyDiffHandler) isChangeScene() bool {
	return false
}

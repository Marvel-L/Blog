package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"time"
)

func TestGenCouponConfigCompare(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Act
			couponConfigCompare, err := genCouponConfigCompare(&model.CouponConfigDB{
				BaseDB: framework.BaseDB{
					Id:          991,
					CreatedTime: time.Now(),
					UpdatedTime: time.Now(),
					Status:      0,
				},
				CouponType:              1,
				RebateCouponWay:         3,
				ApplySource:             3,
				CouponUsage:             "CouponUsage",
				OpportunityNumber:       "OpportunityNumber",
				OpportunityName:         "OpportunityName",
				OpportunityCustomerName: "OpportunityCustomerName",
				Applicant:               "Applicant",
				ApplicantDepartment:     "ApplicantDepartment",
				Remark:                  "Remark",
				EnableBalanceAlert:      1,
				DisableInnerExpireAlert: 2,
				BalanceAlertThreshold:   1,
				CouponAlarmMembers:      "CouponAlarmMembers",
				RuleValidityInfo:        "{\"Type\":1,\"BeginMonth\":\"2024-01\",\"EndMonth\":\"2024-12\"}",
				CapInfo:                 "{\"Enabled\":1,\"OnceAmount\":99.5,\"TotalAmount\":199.5}",
				TriggerInfo:             "{\"TotalAmount\":818,\"SingleAmount\":12,\"Remark\":\"说明\",\"ConsumeRebateProductList\":\"GPU_Server,CPU_Server\",\"QuoteItemIDList\":[11,22],\"StatConsumeRebateProductList\":\"B,A\",\"StatQuoteItemIDList\":[33,44],\"Triggers\":[{\"ProgressiveAmount\":66100,\"Amount\":0,\"RebateRatio\":1,\"Quantity\":1,\"CouponOrder\":0,\"DaysAfterArchived\":0,\"ProgressiveGroups\":null}]}",
				OrderTypeLimit:          "OrderTypeLimit",
				ValidTimeType:           1,
				ValidBeginTime:          time.Now(),
				ValidEndTime:            time.Now(),
				ValidDays:               1,
				UsageLimit:              1,
				AmountLimit:             1,
				PayTypeLimit:            "PayTypeLimit",
				Creator:                 "Creator",
				AccountID:               "AccountID",
				AccumulateType:          "AccumulateType",
				CopyFrom:                1234,
				SnapshotFrom:            5678,
				ProductLimits: []*model.CouponConfigProductsLimitDB{
					{
						ID:                  1,
						ConfigID:            2,
						BillingMethod:       "BillingMethod",
						Product:             "Product",
						ZhName:              "ZhName",
						Configuration:       "Configuration",
						ConfigurationName:   "ConfigurationName",
						ChildProductCode:    "ChildProductCode",
						BelongingDepartment: "BelongingDepartment",
						ConfigurationType:   1,
						TimeLimitLower:      1,
						TimeLimitUpper:      1,
						CanPrePay:           1,
						CreatedTime:         time.Now(),
						UpdatedTime:         time.Now(),
						Status:              0,
					},
				},
			})

			// Assert
			convey.So(couponConfigCompare, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(couponConfigCompare.RuleValidityType, convey.ShouldEqual, 1)
			convey.So(couponConfigCompare.RuleValidBeginMonth, convey.ShouldEqual, "2024-01")
			convey.So(couponConfigCompare.RuleValidEndMonth, convey.ShouldEqual, "2024-12")
			convey.So(couponConfigCompare.CapEnabled, convey.ShouldEqual, 1)
			convey.So(couponConfigCompare.CapOnceAmount, convey.ShouldEqual, 99.5)
			convey.So(couponConfigCompare.CapTotalAmount, convey.ShouldEqual, 199.5)
			convey.So(couponConfigCompare.TriggerInfoTotalAmount, convey.ShouldEqual, 818.0)
			convey.So(couponConfigCompare.TriggerInfoSingleAmount, convey.ShouldEqual, 12.0)
			convey.So(couponConfigCompare.TriggerInfoRemark, convey.ShouldEqual, "说明")
			convey.So(couponConfigCompare.TriggerInfoConsumeRebateProductList, convey.ShouldEqual, "CPU_Server,GPU_Server")
			convey.So(couponConfigCompare.TriggerInfoStatConsumeRebateProductList, convey.ShouldEqual, "A,B")
			convey.So(couponConfigCompare.TriggerInfoQuoteItemIDList, convey.ShouldResemble, []int64{11, 22})
			convey.So(couponConfigCompare.TriggerInfoStatQuoteItemIDList, convey.ShouldResemble, []int64{33, 44})
			convey.So(len(couponConfigCompare.TriggerInfoTriggers), convey.ShouldEqual, 1)
			convey.So(couponConfigCompare.SnapshotFrom, convey.ShouldEqual, int64(5678))
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}
func Test_genCouponProductsLimitCompare(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			compare := genCouponProductsLimitCompare([]*model.CouponConfigProductsLimitDB{
				{
					Product: "ECS",
					ZhName:  "ECS1",
				},
				{
					Product: "ECS",
					ZhName:  "ECS2",
				},
				{
					Product: "sms",
					ZhName:  "sms1",
				},
				{
					Product: "sms",
					ZhName:  "sms2",
				},
			})

			// Assert
			convey.So(len(compare), convey.ShouldEqual, 2)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

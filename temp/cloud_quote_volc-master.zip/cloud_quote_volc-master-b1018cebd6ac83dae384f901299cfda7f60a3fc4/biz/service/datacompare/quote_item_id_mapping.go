package datacompare

import (
	"context"
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// buildQuoteItemIDMappings 按业务唯一的 ChargeItemCompareKey 建立新旧报价项双向映射。
// 两侧所有 ID 先写入值为 0 的条目，使调用方能区分“未匹配”和“未返回该报价项”。
func buildQuoteItemIDMappings(ctx context.Context, newItems, oldItems []map[string]interface{}) (map[int64]int64, map[int64]int64, error) {
	newToOld, oldToNew := make(map[int64]int64, len(newItems)), make(map[int64]int64, len(oldItems))
	ids := make(map[string]int64, len(newItems)+len(oldItems))
	idKey := buildKeyBuilder("Id")
	for side, items := range [][]map[string]interface{}{newItems, oldItems} {
		for _, item := range items {
			key := idKey(item)
			id, err := strconv.ParseInt(key, 10, 64)
			if err != nil || id <= 0 {
				return nil, nil, errors.ErrCustomerError.WithArgs("报价项Diff中存在非法ID")
			}
			ids[key] = id
			if side == 0 {
				newToOld[id] = 0
			} else {
				oldToNew[id] = 0
			}
		}
	}
	// 与差异列表复用同一分组函数，保证报价项匹配口径一致。
	newByKey := groupByPK(ctx, buildKeyBuilder("ChargeItemCompareKey"), newItems)
	oldByKey := groupByPK(ctx, buildKeyBuilder("ChargeItemCompareKey"), oldItems)
	for key, newItem := range newByKey {
		if oldItem := oldByKey[key]; oldItem != nil {
			newID, oldID := ids[idKey(newItem)], ids[idKey(oldItem)]
			newToOld[newID] = oldID
			oldToNew[oldID] = newID
		}
	}
	return newToOld, oldToNew, nil
}

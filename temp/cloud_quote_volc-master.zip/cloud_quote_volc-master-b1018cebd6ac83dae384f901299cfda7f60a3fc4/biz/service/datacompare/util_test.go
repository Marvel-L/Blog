package datacompare

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func TestCompareField(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			bizScene := []string{"scene_1", "scene_2"}

			imap := map[string]interface{}{
				"a":   1,
				"b-1": "2",
				"c":   map[string]interface{}{"c1": "c1", "c2": "c2"},
				"d":   "1,2",
				"e":   int64(3),
				"f":   "f1",
				"h":   "h",
			}
			jmap := map[string]interface{}{
				"a":   1,
				"b-1": "21",
				"c":   map[string]interface{}{"c1": "c1-1", "c2": "c2"},
				"d":   "2,1",
				"e":   int64(3),
				"f":   "f2",
				"h":   "h",
			}

			fieldConfig := []config.DiffFieldInfoConf{
				{Code: "a", Scene: []string{"scene_2"}},
				{Code: "b", ValKey: "b-1"},
				{Code: "c", ValuePath: []string{"c2"}},
				{Code: "d", NeedSort: true},
				{Code: "e"},
				{Code: "f"},
				{Code: "g"},
			}

			// Act
			diffFields, changedDetail := CompareField(context.Background(), bizScene, imap, jmap, fieldConfig)

			// Assert
			convey.So(diffFields, convey.ShouldHaveLength, 2)
			convey.So(changedDetail, convey.ShouldHaveLength, 2)
			convey.So(changedDetail, convey.ShouldContainKey, "b")
			convey.So(changedDetail, convey.ShouldContainKey, "f")
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestInterface2Slice(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			var list []*model.Quote

			list = append(list, &model.Quote{ParentQuoteID: 1})
			list = append(list, &model.Quote{ParentQuoteID: 999999})
			list = append(list, &model.Quote{ParentQuoteID: 10000000})

			// Act
			ret := Interface2Slice(list)
			retNil := Interface2Slice(nil)
			retMap := Interface2Slice([]map[string]interface{}{})

			// Assert
			convey.So(len(ret), convey.ShouldEqual, 3)
			convey.So(ret[0]["ParentQuoteID"], convey.ShouldEqual, json.Number("1"))
			convey.So(ret[1]["ParentQuoteID"], convey.ShouldEqual, json.Number("999999"))
			convey.So(ret[2]["ParentQuoteID"], convey.ShouldEqual, json.Number("10000000"))
			convey.So(retNil, convey.ShouldResemble, []map[string]interface{}{})
			convey.So(retMap, convey.ShouldResemble, []map[string]interface{}{})
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestInterface2Map(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			interface2MapNil := Interface2Map(nil)
			interface2MapMap := Interface2Map(map[string]interface{}{})

			// Assert
			convey.So(interface2MapNil, convey.ShouldResemble, map[string]interface{}{})
			convey.So(interface2MapMap, convey.ShouldResemble, map[string]interface{}{})
		})
	})

}

func Test_str2SortedStr(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("type is 1", t, func() {
			// Arrange
			v := "[1,3,2]"

			// Act
			vSort := str2SortedStr(v, 1)

			// Assert
			convey.So(vSort, convey.ShouldEqual, "[1,2,3]")
		})

		mockey.PatchConvey("sortValueType is 2", t, func() {
			// Arrange
			v := "[\"a\",\"c\",\"b\"]"

			// Act
			vSort := str2SortedStr(v, 2)

			// Assert
			convey.So(vSort, convey.ShouldEqual, "[\"a\",\"b\",\"c\"]")
		})

		mockey.PatchConvey("sortValueType is 0", t, func() {
			// Arrange
			v := "1,3,2"

			// Act
			vSort := str2SortedStr(v, 0)

			// Assert
			convey.So(vSort, convey.ShouldEqual, "1,2,3")
		})
	})

}

func (emptyFormatter) Format(state fmt.State, verb rune) {
	// Intentionally write nothing to produce an empty formatted string.
}

func Test_computeDiscountTrend_BitsUTGen(t *testing.T) {
	t.Run("returns TrendNone when either comparable decimal cannot be extracted", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Current value is invalid: empty UnitPrice string; origin is valid
			cur := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       "",
			}
			origin := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       10,
			}

			ret := computeDiscountTrend(cur, origin)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("returns TrendIncrease when current value is greater than origin value", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cur := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       20,
			}
			origin := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       10,
			}

			ret := computeDiscountTrend(cur, origin)
			convey.So(ret, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("returns TrendDecrease when current value is less than origin value", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cur := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       5,
			}
			origin := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       10,
			}

			ret := computeDiscountTrend(cur, origin)
			convey.So(ret, convey.ShouldEqual, TrendDecrease)
		})
	})

	t.Run("returns TrendNone when current value equals origin value", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cur := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       10,
			}
			origin := map[string]interface{}{
				"PricingFunction": "simple_discount",
				"UnitPrice":       10,
			}

			ret := computeDiscountTrend(cur, origin)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})
}

func Test_interfaceToDecimal_BitsUTGen(t *testing.T) {
	t.Run("Nil value should return zero and false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dec, ok := interfaceToDecimal(nil)
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(dec.String(), convey.ShouldEqual, decimal.Zero.String())
		})
	})

	t.Run("Decimal and pointer decimal cases", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// decimal.Decimal value
			d := decimal.NewFromInt(5)
			dec1, ok1 := interfaceToDecimal(d)
			convey.So(ok1, convey.ShouldBeTrue)
			convey.So(dec1.String(), convey.ShouldEqual, d.String())

			// *decimal.Decimal nil pointer
			var pdNil *decimal.Decimal
			dec2, ok2 := interfaceToDecimal(pdNil)
			convey.So(ok2, convey.ShouldBeFalse)
			convey.So(dec2.String(), convey.ShouldEqual, decimal.Zero.String())

			// *decimal.Decimal non-nil pointer
			dp := decimal.NewFromInt(9)
			dec3, ok3 := interfaceToDecimal(&dp)
			convey.So(ok3, convey.ShouldBeTrue)
			convey.So(dec3.String(), convey.ShouldEqual, dp.String())
		})
	})

	t.Run("JSON number parse success and failure", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Success path
			jGood := json.Number("123.45")
			decGood, okGood := interfaceToDecimal(jGood)
			expGood, _ := decimal.NewFromString("123.45")
			convey.So(okGood, convey.ShouldBeTrue)
			convey.So(decGood.String(), convey.ShouldEqual, expGood.String())

			// Failure path
			jBad := json.Number("bad-number")
			_, okBad := interfaceToDecimal(jBad)
			convey.So(okBad, convey.ShouldBeFalse)
		})
	})

	t.Run("Float types conversion", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// float64
			f64 := 1.25
			dec64, ok64 := interfaceToDecimal(f64)
			convey.So(ok64, convey.ShouldBeTrue)
			convey.So(dec64.String(), convey.ShouldEqual, decimal.NewFromFloat(f64).String())

			// float32
			var f32 float32 = 2.5
			dec32, ok32 := interfaceToDecimal(f32)
			convey.So(ok32, convey.ShouldBeTrue)
			convey.So(dec32.String(), convey.ShouldEqual, decimal.NewFromFloat(float64(f32)).String())
		})
	})

	t.Run("Signed integer types conversion", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			i := int(12)
			di, oki := interfaceToDecimal(i)
			convey.So(oki, convey.ShouldBeTrue)
			convey.So(di.String(), convey.ShouldEqual, "12")

			var i8 int8 = -5
			di8, oki8 := interfaceToDecimal(i8)
			convey.So(oki8, convey.ShouldBeTrue)
			convey.So(di8.String(), convey.ShouldEqual, "-5")

			var i16 int16 = 123
			di16, oki16 := interfaceToDecimal(i16)
			convey.So(oki16, convey.ShouldBeTrue)
			convey.So(di16.String(), convey.ShouldEqual, "123")

			var i32 int32 = -123
			di32, oki32 := interfaceToDecimal(i32)
			convey.So(oki32, convey.ShouldBeTrue)
			convey.So(di32.String(), convey.ShouldEqual, "-123")

			var i64 int64 = 999999999
			di64, oki64 := interfaceToDecimal(i64)
			convey.So(oki64, convey.ShouldBeTrue)
			convey.So(di64.String(), convey.ShouldEqual, "999999999")
		})
	})

	t.Run("Unsigned integer types conversion", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var u uint = 42
			du, oku := interfaceToDecimal(u)
			convey.So(oku, convey.ShouldBeTrue)
			convey.So(du.String(), convey.ShouldEqual, "42")

			var u8 uint8 = 200
			du8, oku8 := interfaceToDecimal(u8)
			convey.So(oku8, convey.ShouldBeTrue)
			convey.So(du8.String(), convey.ShouldEqual, "200")

			var u16 uint16 = 65500
			du16, oku16 := interfaceToDecimal(u16)
			convey.So(oku16, convey.ShouldBeTrue)
			convey.So(du16.String(), convey.ShouldEqual, "65500")

			var u32 uint32 = 4000000000 - 1 // 3999999999 within uint32
			du32, oku32 := interfaceToDecimal(u32)
			convey.So(oku32, convey.ShouldBeTrue)
			convey.So(du32.String(), convey.ShouldEqual, "3999999999")
		})
	})

	t.Run("Uint64 upper bound and normal conversion", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Normal conversion within int64 range
			var u64ok uint64 = uint64(math.MaxInt64)
			du64ok, oku64ok := interfaceToDecimal(u64ok)
			convey.So(oku64ok, convey.ShouldBeTrue)
			convey.So(du64ok.String(), convey.ShouldEqual, fmt.Sprintf("%d", int64(u64ok)))

			// Overflow case beyond int64 range
			var u64bad uint64 = math.MaxUint64
			du64bad, oku64bad := interfaceToDecimal(u64bad)
			convey.So(oku64bad, convey.ShouldBeFalse)
			convey.So(du64bad.String(), convey.ShouldEqual, decimal.Zero.String())
		})
	})

	t.Run("String branch with empty, integer, decimal, and invalid inputs", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Empty string after trim
			sEmpty := "   \t\n  "
			decEmpty, okEmpty := interfaceToDecimal(sEmpty)
			convey.So(okEmpty, convey.ShouldBeFalse)
			convey.So(decEmpty.String(), convey.ShouldEqual, decimal.Zero.String())

			// Integer string -> ParseInt path
			sInt := "42"
			decInt, okInt := interfaceToDecimal(sInt)
			convey.So(okInt, convey.ShouldBeTrue)
			convey.So(decInt.String(), convey.ShouldEqual, "42")

			// Decimal string -> NewFromString path
			sDec := "42.5"
			decDec, okDec := interfaceToDecimal(sDec)
			convey.So(okDec, convey.ShouldBeTrue)
			convey.So(decDec.String(), convey.ShouldEqual, "42.5")

			// Invalid string -> error path
			sBad := "abc"
			_, okBad := interfaceToDecimal(sBad)
			convey.So(okBad, convey.ShouldBeFalse)
		})
	})

	t.Run("Default branch with alias type numeric and invalid", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Success: alias type not matching string case, goes to default
			var msNum myString = "77.35"
			decAlias, okAlias := interfaceToDecimal(msNum)
			convey.So(okAlias, convey.ShouldBeTrue)
			convey.So(decAlias.String(), convey.ShouldEqual, "77.35")

			// Failure: invalid numeric from alias type
			var msBad myString = "abc"
			_, okAliasBad := interfaceToDecimal(msBad)
			convey.So(okAliasBad, convey.ShouldBeFalse)
		})
	})

	t.Run("Default branch empty via custom formatter", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Type implements fmt.Formatter and outputs empty string for %+v
			ef := emptyFormatter{}
			decEF, okEF := interfaceToDecimal(ef)
			convey.So(okEF, convey.ShouldBeFalse)
			convey.So(decEF.String(), convey.ShouldEqual, decimal.Zero.String())
		})
	})
}

func Test_computeQuantityPriceIntervalTrend_BitsUTGen(t *testing.T) {
	t.Run("Both intervals empty returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend(nil, nil)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Current interval empty returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend(nil, "10")
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Origin interval empty returns TrendIncrease", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend("10", nil)
			convey.So(ret, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("Origin map interval empty returns TrendIncrease", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend(
				map[string]interface{}{"QuantityPriceInterval": "10,20"},
				map[string]interface{}{},
			)
			convey.So(ret, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("Current map interval empty returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend(
				map[string]interface{}{},
				map[string]interface{}{"QuantityPriceInterval": "10,20"},
			)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Invalid current interval returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend(" , ", "10")
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Invalid origin interval returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend("10", "abc")
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Current left greater returns TrendIncrease", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend("20,30", "10,40")
			convey.So(ret, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("Current left less returns TrendDecrease", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend("5", "10")
			convey.So(ret, convey.ShouldEqual, TrendDecrease)
		})
	})

	t.Run("Equal left boundaries returns TrendNone", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := computeQuantityPriceIntervalTrend("10", "10,20")
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})
}

func Test_computeTrendByType_BitsUTGen(t *testing.T) {
	t.Run("Switch case decimal returns increase", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Decimal: cur > origin -> TrendIncrease
			curVal := 2.5
			originVal := 1.2
			ret := computeTrendByType(TrendCalcTypeDecimal, curVal, originVal)
			convey.So(ret, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("Switch case discount returns decrease", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Discount: simple_discount uses UnitPrice directly, cur < origin -> TrendDecrease
			curVal := map[string]interface{}{
				"PricingFunction": constants.DiscountFunctionSimpleDiscount,
				"UnitPrice":       5.0,
			}
			originVal := map[string]interface{}{
				"PricingFunction": constants.DiscountFunctionSimpleDiscount,
				"UnitPrice":       7.0,
			}
			ret := computeTrendByType(TrendCalcTypeDiscount, curVal, originVal)
			convey.So(ret, convey.ShouldEqual, TrendDecrease)
		})
	})

	t.Run("Switch case interval returns none when both empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Interval: both empty -> TrendNone
			curVal := ""
			originVal := ""
			ret := computeTrendByType(TrendCalcTypeInterval, curVal, originVal)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("Default switch returns none for unknown type", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Default: unknown type -> TrendNone
			curVal := 10
			originVal := 20
			ret := computeTrendByType("unknown", curVal, originVal)
			convey.So(ret, convey.ShouldEqual, TrendNone)
		})
	})
}

func Test_quantityPriceIntervalStr_BitsUTGen(t *testing.T) {
	t.Run("nil input returns empty string", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := quantityPriceIntervalStr(nil)
			convey.So(ret, convey.ShouldEqual, "")
		})
	})

	t.Run("string input returns itself", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ret := quantityPriceIntervalStr("abc")
			convey.So(ret, convey.ShouldEqual, "abc")
		})
	})

	t.Run("map with QuantityPriceInterval key returns formatted value", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{"QuantityPriceInterval": 123}
			ret := quantityPriceIntervalStr(m)
			convey.So(ret, convey.ShouldEqual, "123")
		})
	})

	t.Run("single-key map with string value returns that string", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{"only": "bar"}
			ret := quantityPriceIntervalStr(m)
			convey.So(ret, convey.ShouldEqual, "bar")
		})
	})

	t.Run("single-key map with non-string value returns formatted value", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{"only": 99}
			ret := quantityPriceIntervalStr(m)
			convey.So(ret, convey.ShouldEqual, "99")
		})
	})

	t.Run("map without QuantityPriceInterval and multiple keys returns empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{"a": 1, "b": 2}
			ret := quantityPriceIntervalStr(m)
			convey.So(ret, convey.ShouldEqual, "")
		})
	})
}

func Test_quantityPriceIntervalLeftDecimal_BitsUTGen(t *testing.T) {
	t.Run("Empty interval returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal("   ")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(d.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("All parts empty returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal(" , , ")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(d.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("First non-empty part parsed successfully", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal(" 10 , 20 ")
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(d.Equal(decimal.New(10, 0)), convey.ShouldBeTrue)
		})
	})

	t.Run("First part invalid returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal("abc, 1")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(d.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("Skip empty part then parse valid second", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal(" ,  42 ")
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(d.Equal(decimal.New(42, 0)), convey.ShouldBeTrue)
		})
	})

	t.Run("Skip empty part then invalid second returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d, ok := quantityPriceIntervalLeftDecimal(" , bad ")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(d.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})
}

func Test_discountMapToComparableDecimal_BitsUTGen(t *testing.T) {
	t.Run("pf simple_discount uses UnitPrice with invalid UnitPrice returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction": constants.DiscountFunctionSimpleDiscount,
				"UnitPrice":       nil,
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(ret.Cmp(decimal.NewFromInt(0)), convey.ShouldEqual, 0)
		})
	})

	t.Run("pf fixed_price uses UnitPrice", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   constants.DiscountFunctionFixedPrice,
				"UnitPrice":         "9.5",
				"UnitPriceInterval": "1,2,3",
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ret.Cmp(decimal.NewFromFloat(9.5)), convey.ShouldEqual, 0)
		})
	})

	t.Run("empty UnitPriceInterval falls back to UnitPrice", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "tier_discount",
				"UnitPrice":         "7",
				"UnitPriceInterval": "   ",
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ret.Cmp(decimal.NewFromInt(7)), convey.ShouldEqual, 0)
		})
	})

	t.Run("json UnitPriceInterval unmarshal error falls back to UnitPrice", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         "8",
				"UnitPriceInterval": "{bad}",
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ret.Cmp(decimal.NewFromInt(8)), convey.ShouldEqual, 0)
		})
	})

	t.Run("json UnitPriceInterval smallest decimal extracted", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         "10",
				"UnitPriceInterval": `{"2024-01":"1.2,0.8", "2024-02":"1.0, 2.5, abc"}`,
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			exp, _ := decimal.NewFromString("0.8")
			convey.So(ret.Cmp(exp), convey.ShouldEqual, 0)
		})
	})

	t.Run("json UnitPriceInterval has no valid decimals falls back", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         "5",
				"UnitPriceInterval": `{"a":" ", "b":"abc, def", "c":""}`,
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ret.Cmp(decimal.NewFromInt(5)), convey.ShouldEqual, 0)
		})
	})

	t.Run("string UnitPriceInterval smallest decimal extracted", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         "100",
				"UnitPriceInterval": "3.5, 2.75, abc, 10",
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			exp, _ := decimal.NewFromString("2.75")
			convey.So(ret.Cmp(exp), convey.ShouldEqual, 0)
		})
	})

	t.Run("string UnitPriceInterval has no valid decimals falls back", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         "4",
				"UnitPriceInterval": "abc, , xyz",
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ret.Cmp(decimal.NewFromInt(4)), convey.ShouldEqual, 0)
		})
	})

	t.Run("json UnitPriceInterval no valid decimals and invalid UnitPrice returns false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			m := map[string]interface{}{
				"PricingFunction":   "other",
				"UnitPrice":         nil,
				"UnitPriceInterval": `{"x":" , ", "y":"abc"}`,
			}
			ret, ok := discountMapToComparableDecimal(m)
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(ret.Cmp(decimal.NewFromInt(0)), convey.ShouldEqual, 0)
		})
	})
}

func Test_computeDecimalTrend_BitsUTGen(t *testing.T) {
	t.Run("increase when cur greater than origin and origin is nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// cur is greater than origin, origin is nil -> treated as zero -> increase
			res := computeDecimalTrend(2, nil)
			convey.So(res, convey.ShouldEqual, TrendIncrease)
		})
	})

	t.Run("decrease when cur is nil and origin positive", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// cur is nil -> treated as zero, origin positive -> decrease
			res := computeDecimalTrend(nil, 3)
			convey.So(res, convey.ShouldEqual, TrendDecrease)
		})
	})

	t.Run("none when values are equal across types", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// cur decimal equals origin string -> none
			cur := decimal.NewFromInt(5)
			res := computeDecimalTrend(cur, "5")
			convey.So(res, convey.ShouldEqual, TrendNone)
		})
	})

	t.Run("none when both values are nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// both nil -> both treated as zero -> none
			res := computeDecimalTrend(nil, nil)
			convey.So(res, convey.ShouldEqual, TrendNone)
		})
	})
}

type myString string

type emptyFormatter struct{}

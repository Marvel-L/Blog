package datacompare

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	v2 "code.byted.org/gopkg/gorm/v2"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func TestDiffQuoteService_Diff(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("child VS parent", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(&gorm.DB{}).Build()
			mockey.Mock(isChildVSParent).Return(true).Build()

			quoteDB := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1,
				},
				ParentQuoteID: 1,
				QuoteType:     multienv.QuoteTypeProjectBased,
				QuoteScene:    multienv.SceneSupplyAgreement,
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quoteDB, nil).Build()

			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: quoteDB}, nil).Build()

			itemCtx := map[int64]*item_context.ItemContext{
				0: {FormValues: map[string]string{"": ""}},
			}
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteItemCalculateDao, "QuoteItemCalcMapByQuoteItemIDs")).Return(map[int64]*model.QuoteItemCalculate{}, nil).Build()

			// Act
			v := &DiffQuoteService{}

			ret, err := v.Diff(context.Background(), dal.DBProxy.NewRequest(context.Background()), 1, 2)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("parent VS child", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(&gorm.DB{}).Build()
			mockey.Mock(isChildVSParent).Return(false).Build()

			quoteDB := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1,
				},
				ParentQuoteID: 1,
				QuoteType:     multienv.QuoteTypeProjectBased,
				QuoteScene:    multienv.SceneSupplyAgreement,
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quoteDB, nil).Build()

			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: quoteDB}, nil).Build()

			itemCtx := map[int64]*item_context.ItemContext{
				0: {FormValues: map[string]string{"": ""}},
			}
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteItemCalculateDao, "QuoteItemCalcMapByQuoteItemIDs")).Return(map[int64]*model.QuoteItemCalculate{}, nil).Build()

			// Act
			v := &DiffQuoteService{}

			ret, err := v.Diff(context.Background(), dal.DBProxy.NewRequest(context.Background()), 1, 2)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("PublicChangeQuote", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(&gorm.DB{}).Build()
			mockey.Mock(isChildVSParent).Return(true).Build()

			quoteDB := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1,
				},
				OriginQuoteID: 1,
				QuoteType:     multienv.QuoteTypeNormal,
				QuoteScene:    multienv.SceneChangeQuote,
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quoteDB, nil).Build()
			mockey.Mock((*model.Quote).IsPublicNew).Return(true).Build()
			mockey.Mock((*model.Quote).IsPublicChange).Return(true).Build()

			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: quoteDB}, nil).Build()

			itemCtx := map[int64]*item_context.ItemContext{
				0: {FormValues: map[string]string{"": ""}},
			}
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteItemCalculateDao, "QuoteItemCalcMapByQuoteItemIDs")).Return(map[int64]*model.QuoteItemCalculate{}, nil).Build()

			// Act
			v := &DiffQuoteService{}

			ret, err := v.Diff(context.Background(), dal.DBProxy.NewRequest(context.Background()), 1, 2)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
		})
	})
}

func TestNewDiffQuoteService(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			service := NewDiffQuoteService()

			// Assert
			convey.So(service, convey.ShouldEqual, &DiffQuoteService{})
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestDiffQuoteService_diffProfitCalInfo_BitsUTGen(t *testing.T) {
	s := NewDiffQuoteService()
	ctx := context.Background()
	tx := &gorm.DB{}

	t.Run("should return empty result when needDiffInfo is false", func(t *testing.T) {
		mockey.PatchConvey("should return empty result when needDiffInfo is false", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfo).needDiffInfo).Return(false).Build()

			result, err := s.diffProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, &QuoteDiffProfitCal{})
		})
	})

	t.Run("should return error when first diffProfitCalInfoByType call fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when first diffProfitCalInfoByType call fails", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}
			expectedErr := errors.New("unit cost calculation failed")

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfoByType).Return(nil, expectedErr).Build()

			result, err := s.diffProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should return error when second diffProfitCalInfoByType call fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when second diffProfitCalInfoByType call fails", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}
			expectedErr := errors.New("factory price calculation failed")

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfoByType).
				Return(mockey.Sequence(&QuoteDiffCommonEntity{}, nil).Then(nil, expectedErr)).
				Build()

			result, err := s.diffProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should return error when third diffProfitCalInfoByType call fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when third diffProfitCalInfoByType call fails", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}
			expectedErr := errors.New("latest resource calculation failed")

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfoByType).
				Return(mockey.Sequence(&QuoteDiffCommonEntity{}, nil).Then(&QuoteDiffCommonEntity{}, nil).Then(nil, expectedErr)).
				Build()

			result, err := s.diffProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should return combined diff result on success", func(t *testing.T) {
		mockey.PatchConvey("should return combined diff result on success", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}
			unitCostResult := &QuoteDiffCommonEntity{
				AddedList: []interface{}{"unit_added"},
			}
			factoryPriceResult := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{"factory_deleted"},
			}
			latestResourceResult := &QuoteDiffCommonEntity{
				ChangedList: []interface{}{"latest_resource_changed"},
			}

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfoByType).
				When(func(_ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo, calculateType int) bool {
					return calculateType == constants.CalculateTypeUnitCost
				}).
				Return(unitCostResult, nil).
				When(func(_ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo, calculateType int) bool {
					return calculateType == constants.CalculateTypeExFactoryPrice
				}).
				Return(factoryPriceResult, nil).
				When(func(_ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo, calculateType int) bool {
					return calculateType == constants.CalculateTypeLatestResourcePrice
				}).
				Return(latestResourceResult, nil).
				Build()

			result, err := s.diffProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.UnitCostProfitCal, convey.ShouldEqual, unitCostResult)
			convey.So(result.FactoryPriceProfitCal, convey.ShouldEqual, factoryPriceResult)
			convey.So(result.LatestResourceProfitCal, convey.ShouldEqual, latestResourceResult)
		})
	})
}

func Test_DiffQuoteService_diffProductLineProfitCalInfo_BitsUTGen(t *testing.T) {
	s := NewDiffQuoteService()
	ctx := context.Background()
	tx := &gorm.DB{}

	t.Run("Scenario: diff is not required", func(t *testing.T) {
		mockey.PatchConvey("Scenario: diff is not required because needDiffInfo returns false", t, func() {
			mockHandler := &Mock_DiffHandler_diffProductLineProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}

			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).needDiffInfo).
				When(func(infoType multienv.QuoteInfoType) bool {
					return infoType == multienv.InfoTypeProfitCal
				}).
				Return(false).
				Build()

			result, err := s.diffProductLineProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, &QuoteDiffCommonEntity{})
		})
	})

	t.Run("Scenario: getProductLineProfitCalInfo returns an error", func(t *testing.T) {
		mockey.PatchConvey("Scenario: getProductLineProfitCalInfo returns an error", t, func() {
			mockHandler := &Mock_DiffHandler_diffProductLineProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
			}
			testErr := errors.New("db query failed")
			expectedErr := pkg_errors.ErrCustomerError.WithArgs("报价单利润率测算对比失败")

			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).getProductLineProfitCalInfo).Return(nil, nil, testErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			result, err := s.diffProductLineProfitCalInfo(ctx, tx, processInfo)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, expectedErr)
		})
	})

	t.Run("Scenario: Diff function returns an error", func(t *testing.T) {
		mockey.PatchConvey("Scenario: Diff function returns an error", t, func() {
			mockHandler := &Mock_DiffHandler_diffProductLineProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
				scene:       []string{"test-scene"},
			}
			testErr := errors.New("diff logic failed")
			expectedErr := pkg_errors.ErrCustomerError.WithArgs("报价单利润率测算汇总对比失败")

			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).getProductLineProfitCalInfo).Return(
				[]*profit_calculator.ProductLineCalculateData{},
				[]*profit_calculator.ProductLineCalculateData{},
				nil,
			).Build()
			mockey.Mock(Diff).Return(nil, testErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			result, err := s.diffProductLineProfitCalInfo(ctx, tx, processInfo)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, expectedErr)
		})
	})

	t.Run("Scenario: successful diff with added and changed items", func(t *testing.T) {
		mockey.PatchConvey("Scenario: successful diff with added and changed items", t, func() {
			mockHandler := &Mock_DiffHandler_diffProductLineProfitCalInfo{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
				scene:       []string{"test-scene"},
			}

			srcItems := []*profit_calculator.ProductLineCalculateData{
				{ProductDepartmentName: "PD_Changed", GrossProfitRate: "0.10", LatestResourceGrossProfitRate: "0.20"},
			}
			destItems := []*profit_calculator.ProductLineCalculateData{
				{ProductDepartmentName: "PD_Changed", GrossProfitRate: "0.10", LatestResourceGrossProfitRate: "0.25"},
				{ProductDepartmentName: "PD_Added", GrossProfitRate: "0.30", LatestResourceGrossProfitRate: "0.35"},
			}

			mockDiffResult := &CompareResult{
				AddedList:   []interface{}{"PD_Added"},
				DeletedList: []interface{}{},
				ChangedList: []interface{}{"PD_Changed"},
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"PD_Changed": {
						"LatestResourceGrossProfitRate": {
							Code:        "LatestResourceGrossProfitRate",
							OriginValue: "0.20",
							CurValues:   "0.25",
						},
					},
				},
			}
			expectedResult := &QuoteDiffCommonEntity{
				AddedList:      mockDiffResult.AddedList,
				DeletedList:    mockDiffResult.DeletedList,
				ChangedList:    mockDiffResult.ChangedList,
				ChangedDetails: mockDiffResult.ChangedDetails,
			}

			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).needDiffInfo).Return(true).Build()
			mockey.Mock((*Mock_DiffHandler_diffProductLineProfitCalInfo).getProductLineProfitCalInfo).Return(srcItems, destItems, nil).Build()
			mockey.Mock(Diff).To(func(_ context.Context, diffCtx *Context) (*CompareResult, error) {
				convey.So(diffCtx.Config.CompareFields, convey.ShouldResemble, []config.DiffFieldInfoConf{
					{Code: "GrossProfitRate"},
					{Code: "FactoryPriceGrossProfitRate"},
					{Code: "LatestResourceGrossProfitRate"},
				})
				return mockDiffResult, nil
			}).Build()

			result, err := s.diffProductLineProfitCalInfo(ctx, tx, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})
	})
}

func TestDiffQuoteService_diffProfitCalInfoByType_BitsUTGen(t *testing.T) {
	s := NewDiffQuoteService()
	var tx *gorm.DB

	t.Run("Success scenario with added, deleted, and changed items", func(t *testing.T) {
		mockey.PatchConvey("Success scenario with added, deleted, and changed items", t, func() {
			// Comments must be in english and concise, and only added for code that requires explanation. Do not follow the commenting style of existing tests. Omit unnecessary comments such as // Assert, // Arrange, // Act, // Mock.
			mockHandler := &Mock_DiffHandler_diffProfitCalInfoByType{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
				diffConf:    &config.DiffConf{},
				scene:       []string{"test"},
			}
			srcItems := []*profit_calculator.CommonDataItem{
				{DataKey: "key1", DataValue: decimal.NewFromInt(100)}, // Changed
				{DataKey: "key2", DataValue: decimal.NewFromInt(200)}, // Deleted
			}
			destItems := []*profit_calculator.CommonDataItem{
				{DataKey: "key1", DataValue: decimal.NewFromInt(101)}, // Changed
				{DataKey: "key3", DataValue: decimal.NewFromInt(300)}, // Added
			}

			mockCompareResult := &CompareResult{
				AddedList:   []interface{}{"key3"},
				DeletedList: []interface{}{"key2"},
				ChangedList: []interface{}{"key1"},
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"key1": {
						"DataValue": {Code: "DataValue", OriginValue: "100", CurValues: "101"},
					},
				},
			}

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfoByType).getDiffProfitCalInfo).Return(srcItems, destItems, nil).Build()
			// Mocking the Diff function as its internal logic is complex and tested elsewhere.
			mockey.Mock(Diff).Return(mockCompareResult, nil).Build()

			result, err := s.diffProfitCalInfoByType(context.Background(), tx, processInfo, 0)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.AddedList, convey.ShouldResemble, mockCompareResult.AddedList)
			convey.So(result.DeletedList, convey.ShouldResemble, mockCompareResult.DeletedList)
			convey.So(result.ChangedList, convey.ShouldResemble, mockCompareResult.ChangedList)
			convey.So(result.ChangedDetails, convey.ShouldResemble, mockCompareResult.ChangedDetails)
		})
	})

	t.Run("Failure scenario when getDiffProfitCalInfo returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when getDiffProfitCalInfo returns an error", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfoByType{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
				diffConf:    &config.DiffConf{},
			}
			dbErr := errors.New("database connection failed")

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfoByType).getDiffProfitCalInfo).Return(nil, nil, dbErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			result, err := s.diffProfitCalInfoByType(context.Background(), tx, processInfo, 0)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单利润率测算对比失败")
		})
	})

	t.Run("Failure scenario when the Diff function returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when the Diff function returns an error", t, func() {
			mockHandler := &Mock_DiffHandler_diffProfitCalInfoByType{}
			processInfo := &quoteDiffProcessInfo{
				diffHandler: mockHandler,
				diffConf:    &config.DiffConf{},
			}
			diffErr := errors.New("diff logic error")

			mockey.Mock((*Mock_DiffHandler_diffProfitCalInfoByType).getDiffProfitCalInfo).Return(
				[]*profit_calculator.CommonDataItem{},
				[]*profit_calculator.CommonDataItem{},
				nil,
			).Build()
			mockey.Mock(Diff).Return(nil, diffErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			result, err := s.diffProfitCalInfoByType(context.Background(), tx, processInfo, 0)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单利润率测算汇总对比失败")
		})
	})
}

type Mock_DiffHandler_diffProfitCalInfoByType struct {
	DiffHandler
}

type Mock_DiffHandler_diffProfitCalInfo struct {
	DiffHandler
}

type Mock_DiffHandler_diffProductLineProfitCalInfo struct {
	DiffHandler
}

// Handler that always passes validateQuote.
type MockDiffHandlerOK struct{}

// Handler that returns error in validateQuote.
type MockDiffHandlerErr struct{}

//go:noinline
func (*MockDiffHandlerOK) validateQuote(ctx context.Context, tx *gorm.DB) error { return nil }
func (*MockDiffHandlerErr) validateQuote(ctx context.Context, tx *gorm.DB) error {
	return fmt.Errorf("validate error")
}
func (*MockDiffHandlerOK) needDiffInfo(infoType multienv.QuoteInfoType) bool { return false }

//go:noinline
func (*MockDiffHandlerErr) needDiffInfo(infoType multienv.QuoteInfoType) bool { return false }
func (*MockDiffHandlerOK) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerErr) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, nil
}

//go:noinline
func (*MockDiffHandlerOK) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
}
func (*MockDiffHandlerErr) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
}
func (*MockDiffHandlerOK) isChangeScene() bool { return false }

//go:noinline
func (*MockDiffHandlerErr) isChangeScene() bool { return false }
func Test_DiffQuoteService_Diff_BitsUTGen(t *testing.T) {
	t.Run("error when missing param returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			v := &DiffQuoteService{}
			ctx := context.Background()
			ret, err := v.Diff(ctx, &gorm.DB{}, 0, 123)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err), convey.ShouldContainSubstring, "QuoteID")
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("not related quotes returns empty response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			src := &model.Quote{BaseDB: framework.BaseDB{Id: 101}}
			dest := &model.Quote{BaseDB: framework.BaseDB{Id: 202}}
			mockey.MockUnsafe((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.MockUnsafe(isChildVSParent).Return(false).Build()

			v := &DiffQuoteService{}
			ret, err := v.Diff(ctx, nil, 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(ret.BasicInfo, convey.ShouldNotBeNil)
			convey.So(ret.Items, convey.ShouldNotBeNil)
			convey.So(ret.Coupon, convey.ShouldNotBeNil)
		})
	})

	t.Run("config missing returns internal error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := &model.Quote{BaseDB: framework.BaseDB{Id: 11}, ParentQuoteID: 22}
			dest := &model.Quote{BaseDB: framework.BaseDB{Id: 22}}
			mockey.MockUnsafe((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(config.GetDiffConf).Return((*config.DiffConf)(nil)).Build()

			v := &DiffQuoteService{}
			ret, err := v.Diff(context.Background(), &gorm.DB{}, 1, 2)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err), convey.ShouldContainSubstring, "internal error, get config fail")
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("unsupported quotes returns handler error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := &model.Quote{
				BaseDB:        framework.BaseDB{Id: 1001},
				ParentQuoteID: 2002,
				QuoteType:     multienv.QuoteTypeNormal,
				QuoteScene:    0,
			}
			dest := &model.Quote{
				BaseDB:     framework.BaseDB{Id: 2002},
				QuoteType:  multienv.QuoteTypeNormal,
				QuoteScene: 0,
			}
			mockey.MockUnsafe((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()

			v := &DiffQuoteService{}
			ret, err := v.Diff(context.Background(), &gorm.DB{}, 1, 2)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err), convey.ShouldContainSubstring, "quote is not support to diff")
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("validateQuote returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := &model.Quote{BaseDB: framework.BaseDB{Id: 3001}, ParentQuoteID: 4002}
			dest := &model.Quote{BaseDB: framework.BaseDB{Id: 4002}}
			mockey.MockUnsafe((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()

			mockey.MockUnsafe(getDiffHandler).Return(&MockDiffHandlerErr{}, nil).Build()

			v := &DiffQuoteService{}
			ret, err := v.Diff(context.Background(), &gorm.DB{}, 1, 2)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err), convey.ShouldContainSubstring, "validate error")
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("success path returns diff result", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := &model.Quote{BaseDB: framework.BaseDB{Id: 5001}, ParentQuoteID: 6002}
			dest := &model.Quote{BaseDB: framework.BaseDB{Id: 6002}}
			mockey.MockUnsafe((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.MockUnsafe(getDiffHandler).Return(&MockDiffHandlerOK{}, nil).Build()
			mockey.MockUnsafe((*DiffQuoteService).diff).Return(&QuoteDiffResult{
				BasicInfo:            &QuoteDiffBasicInfo{},
				Items:                &QuoteDiffCommonEntity{},
				Coupon:               &QuoteDiffCoupon{},
				Guarantee:            &QuoteDiffGuarantee{},
				Credit:               &QuoteDiffCommonEntity{},
				Rebate:               &QuoteDiffCommonEntity{},
				ProfitCal:            &QuoteDiffProfitCal{},
				ProductLineProfitCal: &QuoteDiffCommonEntity{},
			}, nil).Build()

			v := &DiffQuoteService{}
			ret, err := v.Diff(context.Background(), &gorm.DB{}, 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(ret.BasicInfo, convey.ShouldNotBeNil)
		})
	})
}

func Test_DiffQuoteService_diffCouponQuoteItemIDList_BitsUTGen(t *testing.T) {
	t.Run("两个列表均为空直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造服务与参数
			svc := NewDiffQuoteService()
			ctx := context.Background()

			srcCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{},
			}
			destCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{},
			}
			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList:  nil,
				itemDestList: nil,
			}

			// 执行方法，两个列表经筛选后均为空，直接返回nil
			res := svc.diffCouponQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("Diff返回错误时记录日志并返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩日志以避免实际调用
			mockey.MockUnsafe(argosnotifylogs.CtxError).Return().Build()
			// 打桩Diff返回错误
			mockey.Mock(Diff).Return(&CompareResult{}, errors.New("diff fail")).Build()

			svc := NewDiffQuoteService()
			ctx := context.Background()

			// 构造非空列表，确保会进入Diff调用
			srcCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{11},
			}
			destCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{22},
			}
			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(11), "ChargeItemCompareKey": "k1"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(22), "ChargeItemCompareKey": "k2"},
				},
			}

			// 执行方法，Diff返回错误则返回nil
			res := svc.diffCouponQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("无新增和删除时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造服务与参数
			svc := NewDiffQuoteService()
			ctx := context.Background()

			// Src与Dest均包含同一个报价项，Diff结果无新增/删除
			srcCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{555},
			}
			destCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{555},
			}
			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(555), "ChargeItemCompareKey": "common"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(555), "ChargeItemCompareKey": "common"},
				},
			}

			// 执行方法，无新增删除则返回nil
			res := svc.diffCouponQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("存在新增或删除时返回对比结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			ctx := context.Background()

			// Src有k1,k3，Dest有k2，产生新增(101,303)与删除(202)
			srcCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{101, 303},
			}
			destCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList: []int64{202},
			}
			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(101), "ChargeItemCompareKey": "k1"},
					{"Id": int64(303), "ChargeItemCompareKey": "k3"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(202), "ChargeItemCompareKey": "k2"},
				},
			}

			// 执行方法，应返回非nil结果，含新增与删除
			res := svc.diffCouponQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res.AddedList, convey.ShouldContain, "101")
			convey.So(res.AddedList, convey.ShouldContain, "303")
			convey.So(res.DeletedList, convey.ShouldContain, "202")
		})
	})
}

func Test_DiffQuoteService_diffCouponStatQuoteItemIDList_BitsUTGen(t *testing.T) {
	t.Run("统计报价项列表按统计字段返回对比结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			ctx := context.Background()

			srcCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList:     []int64{101},
				TriggerInfoStatQuoteItemIDList: []int64{201},
			}
			destCoupon := &CouponConfigCompare{
				TriggerInfoQuoteItemIDList:     []int64{101},
				TriggerInfoStatQuoteItemIDList: []int64{202},
			}
			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(101), "ChargeItemCompareKey": "quote-only"},
					{"Id": int64(201), "ChargeItemCompareKey": "stat-src"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(101), "ChargeItemCompareKey": "quote-only"},
					{"Id": int64(202), "ChargeItemCompareKey": "stat-dest"},
				},
			}

			res := svc.diffCouponStatQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)

			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res.AddedList, convey.ShouldContain, "201")
			convey.So(res.AddedList, convey.ShouldNotContain, "101")
			convey.So(res.DeletedList, convey.ShouldContain, "202")
			convey.So(res.DeletedList, convey.ShouldNotContain, "101")
		})
	})
}

func Test_DiffQuoteService_diffCouponItemIDListCommon_BitsUTGen(t *testing.T) {
	t.Run("仅对命中的报价项ID执行对比", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			ctx := context.Background()

			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(11), "ChargeItemCompareKey": "src-11"},
					{"Id": int64(99), "ChargeItemCompareKey": "src-99"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(22), "ChargeItemCompareKey": "dest-22"},
					{"Id": int64(88), "ChargeItemCompareKey": "dest-88"},
				},
			}

			res := svc.diffCouponItemIDListCommon(ctx, []int64{11}, []int64{22}, diffQuoteItems, "[ut]DiffFail, err=%s")

			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res.AddedList, convey.ShouldContain, "11")
			convey.So(res.AddedList, convey.ShouldNotContain, "99")
			convey.So(res.DeletedList, convey.ShouldContain, "22")
			convey.So(res.DeletedList, convey.ShouldNotContain, "88")
		})
	})

	t.Run("仅有未命中ID时直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			ctx := context.Background()

			diffQuoteItems := &QuoteDiffCommonEntity{
				itemSrcList: []map[string]interface{}{
					{"Id": int64(99), "ChargeItemCompareKey": "src-99"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": int64(88), "ChargeItemCompareKey": "dest-88"},
				},
			}

			res := svc.diffCouponItemIDListCommon(ctx, []int64{11}, []int64{22}, diffQuoteItems, "[ut]DiffFail, err=%s")

			convey.So(res, convey.ShouldBeNil)
		})
	})
}

func Test_DiffQuoteService_checkQuoteCouponChange_BitsUTGen(t *testing.T) {
	t.Run("变更字段非空直接返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 变更字段非空，命中第一个分支
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				ChangeFields: []string{"A"},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("商品范围新增列表非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ProductLimitList存在且AddedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				ProductLimitList: &QuoteDiffCommonEntity{
					AddedList: []interface{}{"p1"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("商品范围删除列表非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ProductLimitList存在且DeletedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				ProductLimitList: &QuoteDiffCommonEntity{
					DeletedList: []interface{}{"p2"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("商品范围变更列表非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ProductLimitList存在且ChangedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				ProductLimitList: &QuoteDiffCommonEntity{
					ChangedList: []interface{}{"p3"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("报价项ID列表新增非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// QuoteItemIDList存在且AddedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				QuoteItemIDList: &QuoteDiffCommonEntity{
					AddedList: []interface{}{"q1"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("报价项ID列表删除非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// QuoteItemIDList存在且DeletedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				QuoteItemIDList: &QuoteDiffCommonEntity{
					DeletedList: []interface{}{"q2"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("报价项ID列表变更非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// QuoteItemIDList存在且ChangedList非空
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				QuoteItemIDList: &QuoteDiffCommonEntity{
					ChangedList: []interface{}{"q3"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("所有列表为nil且无变更返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有字段均为空或nil，最终返回false
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeFalse)
		})
	})

	t.Run("商品范围存在但各列表为空返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ProductLimitList非nil但内部列表都为空，继续判断后返回false
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				ProductLimitList: &QuoteDiffCommonEntity{
					AddedList:   []interface{}{},
					DeletedList: []interface{}{},
					ChangedList: []interface{}{},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeFalse)
		})
	})

	t.Run("报价项ID列表存在但各列表为空返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// QuoteItemIDList非nil但内部列表都为空，最终返回false
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				QuoteItemIDList: &QuoteDiffCommonEntity{
					AddedList:   []interface{}{},
					DeletedList: []interface{}{},
					ChangedList: []interface{}{},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeFalse)
		})
	})

	t.Run("统计报价项ID列表新增非空返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				StatQuoteItemIDList: &QuoteDiffCommonEntity{
					AddedList: []interface{}{"sq1"},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("统计报价项ID列表存在但各列表为空返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			item := &QuoteDiffCouponRawItem{
				StatQuoteItemIDList: &QuoteDiffCommonEntity{
					AddedList:   []interface{}{},
					DeletedList: []interface{}{},
					ChangedList: []interface{}{},
				},
			}
			res := svc.checkQuoteCouponChange(item)
			convey.So(res, convey.ShouldBeFalse)
		})
	})
}

func Test_DiffQuoteService_buildQuoteItemMaps_BitsUTGen(t *testing.T) {
	t.Run("过滤无上下文的报价项", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造一个报价项，但上下文不包含该项
			qi := &model.QuoteItem{}
			qi.Id = 1

			info := &assistant.CallbackInfo{
				Quote:         &model.Quote{},
				AllQuoteItems: []*model.QuoteItem{qi},
				AllItemValues: map[int64][]*model.QuoteItemValue{},
			}

			// mock上下文函数，返回空map，导致subCtx为nil
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(map[int64]*item_context.ItemContext{}, nil).Build()

			svc := NewDiffQuoteService()
			ctx := context.Background()

			result := svc.buildQuoteItemMaps(ctx, info, false, false, quoteDiffRelationUnknown)

			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("报价项计算与返佣字段合并", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造一个非交付项
			qi := &model.QuoteItem{}
			qi.Id = 2
			qi.ItemScene = 0
			qi.InvoiceProject = "tax_project"

			// 构造子上下文，包含表单字段
			subCtx := &item_context.ItemContext{
				TradeProduct:          "TP",
				CanPrePayCode:         "CPP",
				ConfigCategoryCode:    "CAT",
				ConfigurationCode:     "CONF",
				SellingModeCode:       "SELL",
				ChargeItemTag:         "TAG",
				ChargeMethodCode:      "CM",
				RegionCode:            "REG",
				ChargeUnitCode:        "UNIT",
				PriceFactorCode:       "PF",
				ChargeItemCode:        "CIC",
				PrePayRatioCode:       "PRC",
				SpBuyDurationCode:     "SPBD",
				CommitFeeIntervalCode: "CFI",
				FormValues: map[string]string{
					"F1": "V1",
				},
			}
			itemCtx := map[int64]*item_context.ItemContext{
				qi.Id: subCtx,
			}

			// mock上下文返回
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()
			mockey.Mock(trade_client.GetInvoiceItem).Return("增值税专票", nil).Build()

			// 构造算价及返佣
			itemCal := &model.QuoteItemCalculate{
				OriginalPrice:                 decimal.New(100, 0),
				OriginalMarketPrice:           decimal.New(200, 0),
				TotalCost:                     decimal.New(300, 0),
				TotalFactoryPrice:             decimal.New(400, 0),
				FactoryPriceProfitRate:        decimal.New(10, 0),
				TotalLatestResourcePrice:      decimal.New(700, 0),
				LatestResourcePriceProfitRate: decimal.New(30, 0),
				ProfitRate:                    decimal.New(20, 0),
				IncomeNoTax:                   decimal.New(500, 0),
				TotalDiscount:                 decimal.New(5, 0),
				TotalCouponRatio:              decimal.New(6, 0),
				TaxRate:                       decimal.New(13, -2),
			}
			rebate := &model.RebateItem{
				QuoteItemID:     qi.Id,
				RebateLevelType: decimal.New(123, 0),
			}

			info := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllQuoteItems:    []*model.QuoteItem{qi},
				AllDeliveryItems: []*model.QuoteItem{},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
				AllItemCalMap:    map[int64]*model.QuoteItemCalculate{qi.Id: itemCal},
				RebateItemList:   model.RebateItemList{rebate},
			}

			svc := NewDiffQuoteService()
			ctx := context.Background()

			expectedKey := subCtx.GetChargeItemCompareKey()
			result := svc.buildQuoteItemMaps(ctx, info, false, false, quoteDiffRelationUnknown)
			convey.So(len(result), convey.ShouldEqual, 1)

			attr := result[0]
			convey.So(attr["OriginalPrice"], convey.ShouldResemble, itemCal.OriginalPrice)
			convey.So(attr["OriginalMarketPrice"], convey.ShouldResemble, itemCal.OriginalMarketPrice)
			convey.So(attr["TotalCost"], convey.ShouldResemble, itemCal.TotalCost)
			convey.So(attr["TotalFactoryPrice"], convey.ShouldResemble, itemCal.TotalFactoryPrice)
			convey.So(attr["FactoryPriceProfitRate"], convey.ShouldResemble, itemCal.FactoryPriceProfitRate)
			convey.So(attr["TotalLatestResourcePrice"], convey.ShouldResemble, itemCal.TotalLatestResourcePrice)
			convey.So(attr["LatestResourcePriceProfitRate"], convey.ShouldResemble, itemCal.LatestResourcePriceProfitRate)
			convey.So(attr["ProfitRate"], convey.ShouldResemble, itemCal.ProfitRate)
			convey.So(attr["IncomeNoTax"], convey.ShouldResemble, itemCal.IncomeNoTax)
			convey.So(attr["TotalDiscount"], convey.ShouldResemble, itemCal.TotalDiscount)
			convey.So(attr["TotalCouponRatio"], convey.ShouldResemble, itemCal.TotalCouponRatio)
			convey.So(attr["TaxRate"], convey.ShouldResemble, itemCal.TaxRate)
			convey.So(attr["InvoiceItem"], convey.ShouldEqual, "增值税专票")
			convey.So(attr["RebateLevelType"], convey.ShouldResemble, rebate.RebateLevelType)
			convey.So(attr["ChargeItemCompareKey"], convey.ShouldEqual, expectedKey)
			convey.So(attr["F1"], convey.ShouldEqual, "V1")
		})
	})

	t.Run("交付项子场景变更追加ItemCopyFrom", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造所属报价项
			parentQi := &model.QuoteItem{}
			parentQi.Id = 10
			parentQi.ItemCopyFrom = 999

			// 构交付项
			di := &model.QuoteItem{}
			di.Id = 3
			di.ItemScene = constants.ItemSceneDeliveryItem
			di.ItemBelong = parentQi.Id

			// 上下文仅包含交付项
			subCtx := &item_context.ItemContext{
				TradeProduct:          "TP3",
				CanPrePayCode:         "CPP3",
				ConfigCategoryCode:    "CAT3",
				ConfigurationCode:     "CONF3",
				SellingModeCode:       "SELL3",
				ChargeItemTag:         "TAG3",
				ChargeMethodCode:      "CM3",
				RegionCode:            "REG3",
				ChargeUnitCode:        "UNIT3",
				PriceFactorCode:       "PF3",
				ChargeItemCode:        "CIC3",
				PrePayRatioCode:       "PRC3",
				SpBuyDurationCode:     "SPBD3",
				CommitFeeIntervalCode: "CFI3",
			}
			itemCtx := map[int64]*item_context.ItemContext{
				di.Id: subCtx,
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			info := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllQuoteItems:    []*model.QuoteItem{parentQi},
				AllDeliveryItems: []*model.QuoteItem{di},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}

			svc := NewDiffQuoteService()
			ctx := context.Background()

			result := svc.buildQuoteItemMaps(ctx, info, true, true, quoteDiffRelationChange)
			convey.So(len(result), convey.ShouldEqual, 1)

			attr := result[0]
			key := attr["ChargeItemCompareKey"].(string)
			convey.So(strings.HasSuffix(key, constants.Separator+strconv.FormatInt(parentQi.ItemCopyFrom, 10)), convey.ShouldBeTrue)
		})
	})

	t.Run("交付项子场景非变更追加ParentItemID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造所属报价项
			parentQi := &model.QuoteItem{}
			parentQi.Id = 20
			parentQi.ParentItemID = 888

			// 构交付项
			di := &model.QuoteItem{}
			di.Id = 4
			di.ItemScene = constants.ItemSceneDeliveryItem
			di.ItemBelong = parentQi.Id

			// 上下文仅包含交付项
			subCtx := &item_context.ItemContext{
				TradeProduct:          "TP4",
				CanPrePayCode:         "CPP4",
				ConfigCategoryCode:    "CAT4",
				ConfigurationCode:     "CONF4",
				SellingModeCode:       "SELL4",
				ChargeItemTag:         "TAG4",
				ChargeMethodCode:      "CM4",
				RegionCode:            "REG4",
				ChargeUnitCode:        "UNIT4",
				PriceFactorCode:       "PF4",
				ChargeItemCode:        "CIC4",
				PrePayRatioCode:       "PRC4",
				SpBuyDurationCode:     "SPBD4",
				CommitFeeIntervalCode: "CFI4",
			}
			itemCtx := map[int64]*item_context.ItemContext{
				di.Id: subCtx,
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			info := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllQuoteItems:    []*model.QuoteItem{parentQi},
				AllDeliveryItems: []*model.QuoteItem{di},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}

			svc := NewDiffQuoteService()
			ctx := context.Background()

			result := svc.buildQuoteItemMaps(ctx, info, true, false, quoteDiffRelationSupply)
			convey.So(len(result), convey.ShouldEqual, 1)

			attr := result[0]
			key := attr["ChargeItemCompareKey"].(string)
			convey.So(strings.HasSuffix(key, constants.Separator+strconv.FormatInt(parentQi.ParentItemID, 10)), convey.ShouldBeTrue)
		})
	})

	t.Run("交付项父场景追加ItemBelong", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构交付项
			di := &model.QuoteItem{}
			di.Id = 5
			di.ItemScene = constants.ItemSceneDeliveryItem
			di.ItemBelong = 777

			// 上下文仅包含交付项
			subCtx := &item_context.ItemContext{
				TradeProduct:          "TP5",
				CanPrePayCode:         "CPP5",
				ConfigCategoryCode:    "CAT5",
				ConfigurationCode:     "CONF5",
				SellingModeCode:       "SELL5",
				ChargeItemTag:         "TAG5",
				ChargeMethodCode:      "CM5",
				RegionCode:            "REG5",
				ChargeUnitCode:        "UNIT5",
				PriceFactorCode:       "PF5",
				ChargeItemCode:        "CIC5",
				PrePayRatioCode:       "PRC5",
				SpBuyDurationCode:     "SPBD5",
				CommitFeeIntervalCode: "CFI5",
			}
			itemCtx := map[int64]*item_context.ItemContext{
				di.Id: subCtx,
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			info := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllQuoteItems:    []*model.QuoteItem{},
				AllDeliveryItems: []*model.QuoteItem{di},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}

			svc := NewDiffQuoteService()
			ctx := context.Background()

			result := svc.buildQuoteItemMaps(ctx, info, false, false, quoteDiffRelationSupply)
			convey.So(len(result), convey.ShouldEqual, 1)

			attr := result[0]
			key := attr["ChargeItemCompareKey"].(string)
			convey.So(strings.HasSuffix(key, constants.Separator+strconv.FormatInt(di.ItemBelong, 10)), convey.ShouldBeTrue)
		})
	})

	t.Run("交付项子场景找不到所属报价项不追加", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构交付项，所属报价项在quoteItemMap中不存在
			di := &model.QuoteItem{}
			di.Id = 6
			di.ItemScene = constants.ItemSceneDeliveryItem
			di.ItemBelong = 123

			subCtx := &item_context.ItemContext{
				TradeProduct:          "TP6",
				CanPrePayCode:         "CPP6",
				ConfigCategoryCode:    "CAT6",
				ConfigurationCode:     "CONF6",
				SellingModeCode:       "SELL6",
				ChargeItemTag:         "TAG6",
				ChargeMethodCode:      "CM6",
				RegionCode:            "REG6",
				ChargeUnitCode:        "UNIT6",
				PriceFactorCode:       "PF6",
				ChargeItemCode:        "CIC6",
				PrePayRatioCode:       "PRC6",
				SpBuyDurationCode:     "SPBD6",
				CommitFeeIntervalCode: "CFI6",
			}
			itemCtx := map[int64]*item_context.ItemContext{
				di.Id: subCtx,
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(itemCtx, nil).Build()

			info := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllQuoteItems:    []*model.QuoteItem{}, // 不包含所属报价项
				AllDeliveryItems: []*model.QuoteItem{di},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}

			svc := NewDiffQuoteService()
			ctx := context.Background()

			baseKey := subCtx.GetChargeItemCompareKey()
			result := svc.buildQuoteItemMaps(ctx, info, true, true, quoteDiffRelationChange)
			convey.So(len(result), convey.ShouldEqual, 1)

			attr := result[0]
			convey.So(attr["ChargeItemCompareKey"], convey.ShouldEqual, baseKey)
		})
	})

	t.Run("快照版本交付项使用ID和SnapshotFrom匹配", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			currentDeliveryItem := &model.QuoteItem{
				BaseDB:     framework.BaseDB{Id: 31},
				ItemScene:  constants.ItemSceneDeliveryItem,
				ItemBelong: 11,
			}
			snapshotDeliveryItem := &model.QuoteItem{
				BaseDB:       framework.BaseDB{Id: 41},
				ItemScene:    constants.ItemSceneDeliveryItem,
				ItemBelong:   21,
				SnapshotFrom: currentDeliveryItem.Id,
			}
			subCtx := &item_context.ItemContext{
				TradeProduct:      "TP",
				ConfigurationCode: "CONF",
				ChargeItemCode:    "ITEM",
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).
				To(func(
					_ context.Context,
					_ *model.Quote,
					items []*model.QuoteItem,
					_ map[int64][]*model.QuoteItemValue,
				) (map[int64]*item_context.ItemContext, error) {
					return map[int64]*item_context.ItemContext{items[0].Id: subCtx}, nil
				}).
				Build()
			currentInfo := &assistant.CallbackInfo{
				Quote:            &model.Quote{},
				AllDeliveryItems: []*model.QuoteItem{currentDeliveryItem},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}
			snapshotInfo := &assistant.CallbackInfo{
				Quote:            &model.Quote{SnapshotFrom: 101},
				AllDeliveryItems: []*model.QuoteItem{snapshotDeliveryItem},
				AllItemValues:    map[int64][]*model.QuoteItemValue{},
			}

			currentResult := NewDiffQuoteService().buildQuoteItemMaps(
				context.Background(),
				currentInfo,
				true,
				true,
				quoteDiffRelationSnapshot,
			)
			snapshotResult := NewDiffQuoteService().buildQuoteItemMaps(
				context.Background(),
				snapshotInfo,
				false,
				true,
				quoteDiffRelationSnapshot,
			)
			expectedKey := subCtx.GetChargeItemCompareKey() +
				constants.Separator +
				strconv.FormatInt(currentDeliveryItem.Id, 10)
			convey.So(currentResult, convey.ShouldHaveLength, 1)
			convey.So(snapshotResult, convey.ShouldHaveLength, 1)
			convey.So(currentResult[0]["ChargeItemCompareKey"], convey.ShouldEqual, expectedKey)
			convey.So(snapshotResult[0]["ChargeItemCompareKey"], convey.ShouldEqual, expectedKey)
		})
	})
}

func Test_buildChainKeyByID(t *testing.T) {
	t.Run("收集Diff两侧报价项的ID和对比Key", func(t *testing.T) {
		srcList := []map[string]interface{}{
			{"Id": int64(211), "ChargeItemCompareKey": "charge-key-a"},
			{"Id": int64(212), "ChargeItemCompareKey": "charge-key-b"},
		}
		destList := []map[string]interface{}{
			{"Id": int64(111), "ChargeItemCompareKey": "charge-key-a"},
			{"Id": int64(112), "ChargeItemCompareKey": "charge-key-b"},
		}
		compareKeyBuilder := buildKeyBuilder("ChargeItemCompareKey")

		got := buildChainKeyByID(
			srcList,
			destList,
			compareKeyBuilder,
			[]interface{}{int64(211), int64(212)},
			[]interface{}{int64(111), int64(112)},
		)
		want := map[string]string{
			"111": "charge-key-a",
			"112": "charge-key-b",
			"211": "charge-key-a",
			"212": "charge-key-b",
		}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("buildChainKeyByID() = %#v, want %#v", got, want)
		}
	})

	t.Run("忽略缺失ID或对比Key的数据", func(t *testing.T) {
		compareKeyBuilder := buildKeyBuilder("ChargeItemCompareKey")
		got := buildChainKeyByID(
			[]map[string]interface{}{
				{"Id": int64(311), "ChargeItemCompareKey": "charge-key-a"},
				{"Id": int64(312)},
				{"ChargeItemCompareKey": "charge-key-c"},
				nil,
			},
			nil,
			compareKeyBuilder,
			[]interface{}{int64(311), int64(312)},
		)

		want := map[string]string{
			"311": "charge-key-a",
		}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("buildChainKeyByID() = %#v, want %#v", got, want)
		}
	})

	t.Run("无有效数据时返回nil", func(t *testing.T) {
		compareKeyBuilder := buildKeyBuilder("ChargeItemCompareKey")
		got := buildChainKeyByID(nil, []map[string]interface{}{}, compareKeyBuilder, nil)

		if got != nil {
			t.Fatalf("buildChainKeyByID() = %#v, want nil", got)
		}
	})
}

func Test_filterDeletedRelatedQuoteItems_BitsUTGen(t *testing.T) {
	t.Run("空删除列表直接返回原列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// deletedList为空，应该直接返回
			var deletedList []interface{}
			deletedQuoteItemIDs := []interface{}{"x", "y"}

			result := filterDeletedRelatedQuoteItems(deletedList, deletedQuoteItemIDs)

			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("代金券删除的报价项ID列表为空直接返回原列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// deletedQuoteItemIDs为空，应该直接返回原列表
			deletedList := []interface{}{"a", 1, "b"}
			var deletedQuoteItemIDs []interface{}

			result := filterDeletedRelatedQuoteItems(deletedList, deletedQuoteItemIDs)

			convey.So(result, convey.ShouldResemble, deletedList)
		})
	})

	t.Run("过滤逻辑覆盖：包含字符串、非字符串、匹配与不匹配", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// deletedQuoteItemIDs包含字符串和非字符串，deletedList包含字符串和非字符串
			// 其中字符串"a"与"c"在删除ID中应被过滤，"b"与"d"保留，非字符串10保留
			deletedList := []interface{}{"a", "b", 10, "c", "d"}
			deletedQuoteItemIDs := []interface{}{"a", "c", 999}

			result := filterDeletedRelatedQuoteItems(deletedList, deletedQuoteItemIDs)

			convey.So(result, convey.ShouldResemble, []interface{}{"b", 10, "d"})
		})
	})

	t.Run("过滤逻辑：删除ID列表非字符串全部保留", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 删除ID列表全部为非字符串，map为空，结果应完全保留原列表
			deletedList := []interface{}{"e", 99, "f"}
			deletedQuoteItemIDs := []interface{}{123, true}

			result := filterDeletedRelatedQuoteItems(deletedList, deletedQuoteItemIDs)

			convey.So(result, convey.ShouldResemble, deletedList)
		})
	})
}

func Test_DiffQuoteService_diffCouponProductLimit_BitsUTGen(t *testing.T) {
	t.Run("子对父：商品限制非空，返券按金额，报价项删除过滤", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文和服务
			ctx := context.Background()
			s := NewDiffQuoteService()

			// 构造源与目标代金券
			srcCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			srcCoupon.Id = 1001
			destCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			destCoupon.Id = 1001

			srcCouponMap := map[int64]*CouponConfigCompare{1001: srcCoupon}
			destCouponMap := map[int64]*CouponConfigCompare{1001: destCoupon}

			// 基础信息变更详情
			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"1001": {
						"FieldA": {},
					},
				},
			}

			// 报价项对比信息，包含已删除的报价项，用于过滤
			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{"201"},
				itemSrcList: []map[string]interface{}{
					{"Id": "301_current", "ChargeItemCompareKey": "quote-item-301"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": "301", "ChargeItemCompareKey": "quote-item-301"},
				},
			}

			// 商品范围对比返回非nil（子对父不反转）
			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).
				Return(&CompareResult{
					AddedList:   []interface{}{"PLAdd"},
					DeletedList: []interface{}{"PLDel"},
					ChangedList: []interface{}{"PLChange"},
				}).Build()

			// 报价项ID对比返回非nil，包含新增、删除、变更
			mockey.Mock((*DiffQuoteService).diffCouponQuoteItemIDList).
				Return(&CompareResult{
					AddedList:   []interface{}{"101"},
					DeletedList: []interface{}{"201", "301"},
					ChangedList: []interface{}{"401"},
				}).Build()

			// 子对父
			childVSParent := true

			// 执行
			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, childVSParent, baseInfoDiff, diffQuoteItems)

			// 断言结果存在
			convey.So(res, convey.ShouldContainKey, "1001")
			item := res["1001"]
			convey.So(item.ID, convey.ShouldEqual, int64(1001))

			// 断言基础字段变更
			convey.So(len(item.ChangeFields), convey.ShouldEqual, 1)
			convey.So(item.ChangeFields, convey.ShouldContain, "FieldA")

			// 断言商品范围未反转
			convey.So(item.ProductLimitList, convey.ShouldNotBeNil)
			convey.So(item.ProductLimitList.AddedList, convey.ShouldContain, "PLAdd")
			convey.So(item.ProductLimitList.DeletedList, convey.ShouldContain, "PLDel")
			convey.So(item.ProductLimitList.ChangedList, convey.ShouldContain, "PLChange")

			// 断言报价项删除过滤掉已删除的报价项，仅保留仍存在的报价项
			convey.So(item.QuoteItemIDList, convey.ShouldNotBeNil)
			convey.So(item.QuoteItemIDList.AddedList, convey.ShouldContain, "101")
			convey.So(item.QuoteItemIDList.DeletedList, convey.ShouldNotContain, "201")
			convey.So(item.QuoteItemIDList.DeletedList, convey.ShouldContain, "301_current")
			convey.So(item.QuoteItemIDList.ChangedList, convey.ShouldContain, "401")
		})
	})

	t.Run("父对子：商品限制变更需反转，返券按比例，报价项仅变更无删除", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			s := NewDiffQuoteService()

			srcCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmountPercent}
			srcCoupon.Id = 2001
			destCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmountPercent}
			destCoupon.Id = 2001

			srcCouponMap := map[int64]*CouponConfigCompare{2001: srcCoupon}
			destCouponMap := map[int64]*CouponConfigCompare{2001: destCoupon}

			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"2001": {},
				},
			}

			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{},
			}

			// 商品范围对比返回非nil（父对子需要反转）
			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).
				Return(&CompareResult{
					AddedList:   []interface{}{"A"},
					DeletedList: []interface{}{"D"},
					ChangedList: []interface{}{"C"},
				}).Build()

			// 报价项对比仅变更
			mockey.Mock((*DiffQuoteService).diffCouponQuoteItemIDList).
				Return(&CompareResult{
					AddedList:   []interface{}{},
					DeletedList: []interface{}{},
					ChangedList: []interface{}{"X"},
				}).Build()

			childVSParent := false

			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, childVSParent, baseInfoDiff, diffQuoteItems)

			convey.So(res, convey.ShouldContainKey, "2001")
			item := res["2001"]

			// 商品范围反转：新增=原删除，删除=原新增
			convey.So(item.ProductLimitList.AddedList, convey.ShouldContain, "D")
			convey.So(item.ProductLimitList.DeletedList, convey.ShouldContain, "A")
			convey.So(item.ProductLimitList.ChangedList, convey.ShouldContain, "C")

			// 报价项仅变更，无删除过滤
			convey.So(item.QuoteItemIDList.AddedList, convey.ShouldBeEmpty)
			convey.So(item.QuoteItemIDList.DeletedList, convey.ShouldBeEmpty)
			convey.So(item.QuoteItemIDList.ChangedList, convey.ShouldContain, "X")
		})
	})

	t.Run("父对子：目的代金券缺失与无任何变更时不记录", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			s := NewDiffQuoteService()

			// 一个目标缺失，一个无变更
			srcCouponA := &CouponConfigCompare{RebateCouponWay: 0}
			srcCouponA.Id = 3001
			srcCouponB := &CouponConfigCompare{RebateCouponWay: 0}
			srcCouponB.Id = 3002

			srcCouponMap := map[int64]*CouponConfigCompare{
				3001: srcCouponA,
				3002: srcCouponB,
			}
			destCouponMap := map[int64]*CouponConfigCompare{
				// 3001缺失
				3002: {RebateCouponWay: 0},
			}

			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					// 无任何变更详情
				},
			}

			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{},
			}

			// 商品范围返回nil
			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).Return(nil).Build()

			childVSParent := false

			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, childVSParent, baseInfoDiff, diffQuoteItems)

			// 目标缺失被跳过，另一个无任何变更不记录
			convey.So(len(res), convey.ShouldEqual, 0)
		})
	})

	t.Run("子对父：报价项对比返回nil，仅基础信息导致记录", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			s := NewDiffQuoteService()

			srcCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			srcCoupon.Id = 4001
			destCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			destCoupon.Id = 4001

			srcCouponMap := map[int64]*CouponConfigCompare{4001: srcCoupon}
			destCouponMap := map[int64]*CouponConfigCompare{4001: destCoupon}

			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"4001": {"BaseField": {}},
				},
			}

			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{},
			}

			// 商品范围非nil但无变化
			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).
				Return(&CompareResult{
					AddedList:   []interface{}{},
					DeletedList: []interface{}{},
					ChangedList: []interface{}{},
				}).Build()

			// 报价项返回nil
			mockey.Mock((*DiffQuoteService).diffCouponQuoteItemIDList).Return(nil).Build()

			childVSParent := true

			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, childVSParent, baseInfoDiff, diffQuoteItems)

			convey.So(res, convey.ShouldContainKey, "4001")
			item := res["4001"]
			// 基础信息有变更，商品范围为空列表，报价项为空
			convey.So(item.ProductLimitList, convey.ShouldNotBeNil)
			convey.So(item.ProductLimitList.AddedList, convey.ShouldBeEmpty)
			convey.So(item.ProductLimitList.DeletedList, convey.ShouldBeEmpty)
			convey.So(item.ProductLimitList.ChangedList, convey.ShouldBeEmpty)
			convey.So(item.QuoteItemIDList, convey.ShouldBeNil)
			convey.So(item.ChangeFields, convey.ShouldContain, "BaseField")
		})
	})

	t.Run("父对子：报价项新增和删除需要反转且不触发过滤", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			s := NewDiffQuoteService()

			srcCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			srcCoupon.Id = 5001
			destCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmount}
			destCoupon.Id = 5001

			srcCouponMap := map[int64]*CouponConfigCompare{5001: srcCoupon}
			destCouponMap := map[int64]*CouponConfigCompare{5001: destCoupon}

			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"5001": {},
				},
			}

			// 无需过滤
			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{},
				itemSrcList: []map[string]interface{}{
					{"Id": "QA", "ChargeItemCompareKey": "quote-item-qa"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": "QA_current", "ChargeItemCompareKey": "quote-item-qa"},
				},
			}

			// 商品范围为nil
			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).Return(nil).Build()

			// 报价项有新增和删除，父对子需要反转
			mockey.Mock((*DiffQuoteService).diffCouponQuoteItemIDList).
				Return(&CompareResult{
					AddedList:   []interface{}{"QA"},
					DeletedList: []interface{}{"QD"},
					ChangedList: []interface{}{},
				}).Build()

			childVSParent := false

			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, childVSParent, baseInfoDiff, diffQuoteItems)

			convey.So(res, convey.ShouldContainKey, "5001")
			item := res["5001"]

			// 报价项反转校验
			convey.So(item.QuoteItemIDList.AddedList, convey.ShouldContain, "QD")
			convey.So(item.QuoteItemIDList.DeletedList, convey.ShouldContain, "QA_current")
			convey.So(item.QuoteItemIDList.ChangedList, convey.ShouldBeEmpty)
		})
	})

	t.Run("父对子：统计报价项删除过滤并保留字段详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			s := NewDiffQuoteService()

			srcCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmountPercent}
			srcCoupon.Id = 6001
			destCoupon := &CouponConfigCompare{RebateCouponWay: couponconfigconst.RebateCouponWayByAmountPercent}
			destCoupon.Id = 6001

			srcCouponMap := map[int64]*CouponConfigCompare{6001: srcCoupon}
			destCouponMap := map[int64]*CouponConfigCompare{6001: destCoupon}

			baseInfoDiff := &CompareResult{
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"6001": {
						"FieldB": {
							Code:        "FieldB",
							OriginValue: "origin",
							CurValues:   "current",
						},
					},
				},
			}
			expectedChangedDetails := baseInfoDiff.ChangedDetails["6001"]

			diffQuoteItems := &QuoteDiffCommonEntity{
				DeletedList: []interface{}{"700"},
				itemSrcList: []map[string]interface{}{
					{"Id": "800", "ChargeItemCompareKey": "quote-item-800"},
				},
				itemDestList: []map[string]interface{}{
					{"Id": "800_current", "ChargeItemCompareKey": "quote-item-800"},
				},
			}

			mockey.Mock((*DiffQuoteService).diffCouponProductLimitDetail).Return(nil).Build()
			mockey.Mock((*DiffQuoteService).diffCouponQuoteItemIDList).Return(nil).Build()
			mockey.Mock((*DiffQuoteService).diffCouponStatQuoteItemIDList).
				Return(&CompareResult{
					AddedList:   []interface{}{"700", "800"},
					DeletedList: []interface{}{"501"},
					ChangedList: []interface{}{"900"},
				}).Build()

			res := s.diffCouponProductLimit(ctx, srcCouponMap, destCouponMap, false, baseInfoDiff, diffQuoteItems)

			convey.So(res, convey.ShouldContainKey, "6001")
			item := res["6001"]
			convey.So(item.ChangeFields, convey.ShouldContain, "FieldB")
			convey.So(item.ChangedDetails, convey.ShouldResemble, expectedChangedDetails)
			convey.So(item.QuoteItemIDList, convey.ShouldBeNil)
			convey.So(item.StatQuoteItemIDList, convey.ShouldNotBeNil)
			convey.So(item.StatQuoteItemIDList.AddedList, convey.ShouldContain, "501")
			convey.So(item.StatQuoteItemIDList.DeletedList, convey.ShouldNotContain, "700")
			convey.So(item.StatQuoteItemIDList.DeletedList, convey.ShouldContain, "800_current")
			convey.So(item.StatQuoteItemIDList.ChangedList, convey.ShouldContain, "900")
		})
	})
}

func (*StubDiffHandler) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

func (h *StubDiffHandler) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
	if h.quoteItemsPostProcess != nil {
		h.quoteItemsPostProcess(processInfo, compareResult)
	}
}

func (h *StubDiffHandler) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return h.rebateSrcInfo, h.rebateDestInfo, nil
}

func (h *StubDiffHandler) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return h.guaranteeSrcInfo, h.guaranteeDestInfo, nil
}

func (h *StubDiffHandler) isChangeScene() bool { return h.changeScene }

func (*StubDiffHandler) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, nil
}

func (*StubDiffHandler) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return nil, nil, nil
}

func (h *StubDiffHandler) needDiffInfo(infoType multienv.QuoteInfoType) bool {
	return h.needInfo[infoType]
}

func (h *StubDiffHandler) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return h.compareFields
}

func (h *StubDiffHandler) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return h.itemSrcInfo, h.itemDestInfo, nil
}

func (*StubDiffHandler) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, nil
}

func (h *StubDiffHandler) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	return h.couponSrcInfo, h.couponDestInfo, nil
}

func (*StubDiffHandler) validateQuote(ctx context.Context, tx *gorm.DB) error { return nil }

func Test_DiffQuoteService_diff_BitsUTGen(t *testing.T) {
	t.Run("returns joint print order in final response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{}
			jointPrintOrder := &QuoteDiffJointPrintOrder{ChangeFields: []string{"Support"}}

			mockey.Mock((*DiffQuoteService).diffQuoteBaseInfo).Return(&QuoteDiffBasicInfo{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteItems).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteCoupon).Return(&QuoteDiffCoupon{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteGuarantee).Return(&QuoteDiffGuarantee{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteCredit).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteRebate).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfo).Return(&QuoteDiffProfitCal{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffProductLineProfitCalInfo).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteJointPrintOrder).Return(jointPrintOrder, nil).Build()

			ret, err := svc.diff(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(ret.JointPrintOrder, convey.ShouldEqual, jointPrintOrder)
		})
	})

	t.Run("returns initialized empty response when any diff stage returns error", func(t *testing.T) {
		stages := []string{
			"base",
			"items",
			"coupon",
			"guarantee",
			"credit",
			"rebate",
			"profit",
			"product_line",
		}

		for _, stage := range stages {
			t.Run(stage, func(t *testing.T) {
				mockey.PatchConvey("", t, func() {
					svc := NewDiffQuoteService()
					processInfo := &quoteDiffProcessInfo{}
					expectedErr := errors.New(stage + " failed")

					mockey.Mock((*DiffQuoteService).diffQuoteBaseInfo).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffBasicInfo, error) {
						if stage == "base" {
							return nil, expectedErr
						}
						return &QuoteDiffBasicInfo{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteItems).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {
						if stage == "items" {
							return nil, expectedErr
						}
						return &QuoteDiffCommonEntity{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteCoupon).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo, _ *QuoteDiffCommonEntity) (*QuoteDiffCoupon, error) {
						if stage == "coupon" {
							return nil, expectedErr
						}
						return &QuoteDiffCoupon{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteGuarantee).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo, _ *QuoteDiffCommonEntity) (*QuoteDiffGuarantee, error) {
						if stage == "guarantee" {
							return nil, expectedErr
						}
						return &QuoteDiffGuarantee{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteCredit).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {
						if stage == "credit" {
							return nil, expectedErr
						}
						return &QuoteDiffCommonEntity{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteRebate).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {
						if stage == "rebate" {
							return nil, expectedErr
						}
						return &QuoteDiffCommonEntity{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffProfitCalInfo).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffProfitCal, error) {
						if stage == "profit" {
							return nil, expectedErr
						}
						return &QuoteDiffProfitCal{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffProductLineProfitCalInfo).To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {
						if stage == "product_line" {
							return nil, expectedErr
						}
						return &QuoteDiffCommonEntity{}, nil
					}).Build()
					mockey.Mock((*DiffQuoteService).diffQuoteJointPrintOrder).Return(&QuoteDiffJointPrintOrder{}, nil).Build()

					ret, err := svc.diff(context.Background(), &gorm.DB{}, processInfo)

					convey.So(err, convey.ShouldEqual, expectedErr)
					convey.So(ret, convey.ShouldNotBeNil)
					convey.So(ret.BasicInfo, convey.ShouldNotBeNil)
					convey.So(ret.Items, convey.ShouldNotBeNil)
					convey.So(ret.Coupon, convey.ShouldNotBeNil)
					convey.So(ret.JointPrintOrder, convey.ShouldNotBeNil)
				})
			})
		}
	})

	t.Run("returns initialized empty response when joint print order diff fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{}
			expectedErr := errors.New("joint print order failed")

			mockey.Mock((*DiffQuoteService).diffQuoteBaseInfo).Return(&QuoteDiffBasicInfo{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteItems).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteCoupon).Return(&QuoteDiffCoupon{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteGuarantee).Return(&QuoteDiffGuarantee{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteCredit).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteRebate).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffProfitCalInfo).Return(&QuoteDiffProfitCal{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffProductLineProfitCalInfo).Return(&QuoteDiffCommonEntity{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diffQuoteJointPrintOrder).Return(nil, expectedErr).Build()

			ret, err := svc.diff(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(ret.JointPrintOrder, convey.ShouldNotBeNil)
			convey.So(ret.JointPrintOrder.ChangeFields, convey.ShouldResemble, []string{})
		})
	})
}

func Test_DiffQuoteService_diffQuoteCoupon_ChainKeyByID(t *testing.T) {
	parentCoupon := &model.CouponConfigDB{
		BaseDB: framework.BaseDB{Id: 501},
		Remark: "before",
	}
	childCoupon := &model.CouponConfigDB{
		BaseDB:     framework.BaseDB{Id: 601},
		ChangeFrom: 501,
		Remark:     "after",
	}
	processInfo := &quoteDiffProcessInfo{
		diffHandler: &StubDiffHandler{
			needInfo: map[multienv.QuoteInfoType]bool{
				multienv.InfoTypeQuoteCoupon: true,
			},
			compareFields:  []config.DiffFieldInfoConf{{Code: "Remark"}},
			couponSrcInfo:  &assistant.CallbackInfo{CouponList: model.CouponConfigDBList{childCoupon}},
			couponDestInfo: &assistant.CallbackInfo{CouponList: model.CouponConfigDBList{parentCoupon}},
		},
		childVSParent: true,
		relationType:  quoteDiffRelationChange,
		childQuoteDB:  &model.Quote{OriginQuoteID: 100},
		parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 100}},
		diffConf:      &config.DiffConf{},
	}

	got, err := NewDiffQuoteService().diffQuoteCoupon(
		context.Background(),
		&gorm.DB{},
		processInfo,
		&QuoteDiffCommonEntity{},
	)
	if err != nil {
		t.Fatalf("diffQuoteCoupon() error = %v", err)
	}
	want := map[string]string{
		"601": "501",
	}
	if !reflect.DeepEqual(got.ChainKeyByID, want) {
		t.Fatalf("diffQuoteCoupon().ChainKeyByID = %#v, want %#v", got.ChainKeyByID, want)
	}
}

func Test_DiffQuoteService_diffQuoteCoupon_SnapshotFrom(t *testing.T) {
	currentCoupon := &model.CouponConfigDB{
		BaseDB:     framework.BaseDB{Id: 601},
		ChangeFrom: 501,
		Remark:     "after",
	}
	snapshotCoupon := &model.CouponConfigDB{
		BaseDB:       framework.BaseDB{Id: 701},
		SnapshotFrom: currentCoupon.Id,
		ChangeFrom:   currentCoupon.ChangeFrom,
		Remark:       "before",
	}
	processInfo := &quoteDiffProcessInfo{
		diffHandler: &StubDiffHandler{
			needInfo: map[multienv.QuoteInfoType]bool{
				multienv.InfoTypeQuoteCoupon: true,
			},
			compareFields:  []config.DiffFieldInfoConf{{Code: "Remark"}},
			couponSrcInfo:  &assistant.CallbackInfo{CouponList: model.CouponConfigDBList{currentCoupon}},
			couponDestInfo: &assistant.CallbackInfo{CouponList: model.CouponConfigDBList{snapshotCoupon}},
		},
		childVSParent: true,
		relationType:  quoteDiffRelationSnapshot,
		childQuoteDB:  &model.Quote{QuoteScene: multienv.SceneChangeQuote, OriginSnapshotID: 102},
		parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 102}, SnapshotFrom: 101},
		diffConf:      &config.DiffConf{},
	}

	got, err := NewDiffQuoteService().diffQuoteCoupon(
		context.Background(),
		&gorm.DB{},
		processInfo,
		&QuoteDiffCommonEntity{},
	)
	if err != nil {
		t.Fatalf("diffQuoteCoupon() error = %v", err)
	}
	if !reflect.DeepEqual(got.ChangedList, []interface{}{"601"}) {
		t.Fatalf("diffQuoteCoupon().ChangedList = %#v, want [601]", got.ChangedList)
	}
	wantKeyMap := map[string]string{"601": "501"}
	if !reflect.DeepEqual(got.ChainKeyByID, wantKeyMap) {
		t.Fatalf("diffQuoteCoupon().ChainKeyByID = %#v, want %#v", got.ChainKeyByID, wantKeyMap)
	}
	if _, ok := got.RawList["601"]; !ok {
		t.Fatalf("diffQuoteCoupon().RawList missing current coupon 601: %#v", got.RawList)
	}
}

func Test_entityCompareID(t *testing.T) {
	relationInfo := entityRelationInfo{
		id:           601,
		changeFrom:   501,
		copyFrom:     401,
		snapshotFrom: 301,
	}
	tests := []struct {
		name        string
		isChild     bool
		processInfo *quoteDiffProcessInfo
		want        int64
	}{
		{name: "变更子侧", isChild: true, processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationChange}, want: 501},
		{name: "变更父侧", processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationChange}, want: 601},
		{name: "补充协议子侧", isChild: true, processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationSupply}, want: 401},
		{name: "补充协议父侧", processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationSupply}, want: 601},
		{name: "快照子侧", isChild: true, processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationSnapshot}, want: 601},
		{name: "快照父侧", processInfo: &quoteDiffProcessInfo{relationType: quoteDiffRelationSnapshot}, want: 301},
		{name: "上下文为空时子侧兼容补充协议", isChild: true, want: 401},
		{name: "上下文为空时父侧使用自身ID", want: 601},
		{name: "未知关系", processInfo: &quoteDiffProcessInfo{}, want: 0},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := entityCompareID(relationInfo, tt.isChild, tt.processInfo); got != tt.want {
				t.Fatalf("entityCompareID() = %d, want %d", got, tt.want)
			}
		})
	}
}

func Test_DiffQuoteService_buildCouponCompare_CompatibleProcessInfo(t *testing.T) {
	coupon := &model.CouponConfigDB{
		BaseDB:   framework.BaseDB{Id: 601},
		CopyFrom: 501,
	}
	service := NewDiffQuoteService()

	compareMap, compareList, err := service.buildCouponCompare(context.Background(), model.CouponConfigDBList{coupon}, true, nil)
	if err != nil {
		t.Fatalf("buildCouponCompare(nil processInfo) error = %v", err)
	}
	if _, ok := compareMap[501]; !ok {
		t.Fatalf("buildCouponCompare(nil processInfo) compareMap = %#v, want key 501", compareMap)
	}
	if len(compareList) != 1 {
		t.Fatalf("buildCouponCompare(nil processInfo) compareList length = %d, want 1", len(compareList))
	}

	compareMap, compareList, err = service.buildCouponCompare(
		context.Background(),
		model.CouponConfigDBList{coupon},
		true,
		&quoteDiffProcessInfo{relationType: quoteDiffRelationUnknown},
	)
	if err != nil {
		t.Fatalf("buildCouponCompare(unknown relation) error = %v", err)
	}
	if len(compareMap) != 0 {
		t.Fatalf("buildCouponCompare(unknown relation) compareMap = %#v, want empty", compareMap)
	}
	if len(compareList) != 1 {
		t.Fatalf("buildCouponCompare(unknown relation) compareList length = %d, want 1", len(compareList))
	}
}

func Test_entityChainKey(t *testing.T) {
	changeProcess := &quoteDiffProcessInfo{
		relationType: quoteDiffRelationSnapshot,
		childQuoteDB: &model.Quote{QuoteScene: multienv.SceneChangeQuote},
	}
	currentChanged := entityRelationInfo{
		id:         601,
		changeFrom: 501,
	}
	snapshotChanged := entityRelationInfo{
		id:           701,
		changeFrom:   501,
		snapshotFrom: 601,
	}
	if got := entityChainKey(currentChanged, true, changeProcess); got != "501" {
		t.Fatalf("entityChainKey(current changed) = %q, want 501", got)
	}
	if got := entityChainKey(snapshotChanged, false, changeProcess); got != "501" {
		t.Fatalf("entityChainKey(snapshot changed) = %q, want 501", got)
	}

	copyProcess := &quoteDiffProcessInfo{
		relationType: quoteDiffRelationSnapshot,
		childQuoteDB: &model.Quote{QuoteScene: multienv.SceneNew},
	}
	currentCopy := entityRelationInfo{
		id:       602,
		copyFrom: 401,
	}
	snapshotCopy := entityRelationInfo{
		id:           702,
		copyFrom:     401,
		snapshotFrom: 602,
	}
	if got := entityChainKey(currentCopy, true, copyProcess); got != "602" {
		t.Fatalf("entityChainKey(current copy) = %q, want 602", got)
	}
	if got := entityChainKey(snapshotCopy, false, copyProcess); got != "602" {
		t.Fatalf("entityChainKey(snapshot copy) = %q, want 602", got)
	}
}

func Test_buildGuaranteeCompare_BitsUTGen(t *testing.T) {
	t.Run("变更单优先使用ChangeFrom并标准化对比字段", func(t *testing.T) {
		mockey.PatchConvey("变更单优先使用ChangeFrom并标准化对比字段", t, func() {
			total := decimal.NewFromInt(120)
			item := &model.GuaranteeItem{
				BaseDB:                framework.BaseDB{Id: 101},
				ChangeFrom:            2,
				CopyFrom:              8,
				AccountId:             " acc2 ,acc1 ",
				GuaranteeAmount:       decimal.RequireFromString("88.50"),
				GuaranteeTotalAmount:  &total,
				GuaranteeProductSeats: `[{"TradeProduct":" b ","Seats":2},{"TradeProduct":"a","Seats":1}]`,
			}
			processInfo := &quoteDiffProcessInfo{
				relationType:  quoteDiffRelationChange,
				childQuoteDB:  &model.Quote{OriginQuoteID: 100},
				parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 100}},
			}

			itemByCompareKey, compareList, err := buildGuaranteeCompare([]*model.GuaranteeItem{nil, &model.GuaranteeItem{}, item}, true, processInfo)
			convey.So(err, convey.ShouldBeNil)

			convey.So(itemByCompareKey, convey.ShouldContainKey, "2")
			convey.So(itemByCompareKey["2"], convey.ShouldEqual, item)
			convey.So(compareList, convey.ShouldHaveLength, 1)
			convey.So(compareList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "2")
			convey.So(compareList[0]["GuaranteeChainKey"], convey.ShouldEqual, "2")
			convey.So(compareList[0]["AccountId"], convey.ShouldEqual, "acc1,acc2")
			convey.So(compareList[0]["GuaranteeAmount"], convey.ShouldEqual, "88.5")
			convey.So(compareList[0]["GuaranteeTotalAmount"], convey.ShouldEqual, "120")
			convey.So(compareList[0]["GuaranteeProductSeats"], convey.ShouldResemble, []model.GuaranteeProductSeat{
				{TradeProduct: "a", Seats: 1},
				{TradeProduct: "b", Seats: 2},
			})
		})
	})

	t.Run("补充协议使用CopyFrom生成匹配key", func(t *testing.T) {
		mockey.PatchConvey("补充协议使用CopyFrom生成匹配key", t, func() {
			item := &model.GuaranteeItem{
				BaseDB:   framework.BaseDB{Id: 102},
				CopyFrom: 8,
			}
			processInfo := &quoteDiffProcessInfo{
				relationType:  quoteDiffRelationSupply,
				childQuoteDB:  &model.Quote{OriginQuoteID: 200},
				parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 100}},
			}

			itemByCompareKey, compareList, err := buildGuaranteeCompare([]*model.GuaranteeItem{item}, true, processInfo)
			convey.So(err, convey.ShouldBeNil)

			convey.So(itemByCompareKey, convey.ShouldContainKey, "8")
			convey.So(compareList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "8")
			convey.So(compareList[0]["GuaranteeChainKey"], convey.ShouldEqual, "8")
		})
	})

	t.Run("变更单快照使用ID匹配并使用ChangeFrom串联", func(t *testing.T) {
		mockey.PatchConvey("变更单快照使用ID匹配并使用ChangeFrom串联", t, func() {
			currentItem := &model.GuaranteeItem{
				BaseDB:     framework.BaseDB{Id: 102},
				ChangeFrom: 2,
			}
			snapshotItem := &model.GuaranteeItem{
				BaseDB:       framework.BaseDB{Id: 202},
				ChangeFrom:   2,
				SnapshotFrom: currentItem.Id,
			}
			processInfo := &quoteDiffProcessInfo{
				relationType: quoteDiffRelationSnapshot,
				childQuoteDB: &model.Quote{QuoteScene: multienv.SceneChangeQuote},
			}

			currentMap, currentList, err := buildGuaranteeCompare(
				[]*model.GuaranteeItem{currentItem},
				true,
				processInfo,
			)
			convey.So(err, convey.ShouldBeNil)
			snapshotMap, snapshotList, err := buildGuaranteeCompare(
				[]*model.GuaranteeItem{snapshotItem},
				false,
				processInfo,
			)
			convey.So(err, convey.ShouldBeNil)

			convey.So(currentMap, convey.ShouldContainKey, "102")
			convey.So(snapshotMap, convey.ShouldContainKey, "102")
			convey.So(currentList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "102")
			convey.So(snapshotList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "102")
			convey.So(currentList[0]["GuaranteeChainKey"], convey.ShouldEqual, "2")
			convey.So(snapshotList[0]["GuaranteeChainKey"], convey.ShouldEqual, "2")
		})
	})

	t.Run("无业务来源的快照使用当前ID串联", func(t *testing.T) {
		mockey.PatchConvey("无业务来源的快照使用当前ID串联", t, func() {
			currentItem := &model.GuaranteeItem{BaseDB: framework.BaseDB{Id: 103}}
			snapshotItem := &model.GuaranteeItem{
				BaseDB:       framework.BaseDB{Id: 203},
				SnapshotFrom: currentItem.Id,
			}
			processInfo := &quoteDiffProcessInfo{
				relationType: quoteDiffRelationSnapshot,
				childQuoteDB: &model.Quote{QuoteScene: multienv.SceneNew},
			}

			currentMap, currentList, err := buildGuaranteeCompare([]*model.GuaranteeItem{currentItem}, true, processInfo)
			convey.So(err, convey.ShouldBeNil)
			snapshotMap, snapshotList, err := buildGuaranteeCompare([]*model.GuaranteeItem{snapshotItem}, false, processInfo)
			convey.So(err, convey.ShouldBeNil)

			convey.So(currentMap, convey.ShouldContainKey, "103")
			convey.So(snapshotMap, convey.ShouldContainKey, "103")
			convey.So(currentList[0]["GuaranteeChainKey"], convey.ShouldEqual, "103")
			convey.So(snapshotList[0]["GuaranteeChainKey"], convey.ShouldEqual, "103")
		})
	})

	t.Run("子单无来源ID时使用new前缀且父单使用自身ID", func(t *testing.T) {
		mockey.PatchConvey("子单无来源ID时使用new前缀且父单使用自身ID", t, func() {
			childItem := &model.GuaranteeItem{BaseDB: framework.BaseDB{Id: 103}}
			parentItem := &model.GuaranteeItem{BaseDB: framework.BaseDB{Id: 3}}

			childMap, childList, err := buildGuaranteeCompare([]*model.GuaranteeItem{childItem}, true, nil)
			convey.So(err, convey.ShouldBeNil)
			parentMap, parentList, err := buildGuaranteeCompare([]*model.GuaranteeItem{parentItem}, false, nil)
			convey.So(err, convey.ShouldBeNil)

			convey.So(childMap, convey.ShouldContainKey, "new:103")
			convey.So(childList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "new:103")
			convey.So(parentMap, convey.ShouldContainKey, "3")
			convey.So(parentList[0]["GuaranteeCompareKey"], convey.ShouldEqual, "3")
		})
	})
}

func Test_buildGuaranteeCompareMap_BitsUTGen(t *testing.T) {
	t.Run("标准化账号金额与席位信息", func(t *testing.T) {
		mockey.PatchConvey("标准化账号金额与席位信息", t, func() {
			item := &model.GuaranteeItem{
				BaseDB:                framework.BaseDB{Id: 301},
				AccountId:             " acc-b ,acc-a,, acc-c ",
				GuaranteeAmount:       decimal.RequireFromString("10.00"),
				GuaranteeProductSeats: `[{"TradeProduct":" z ","Seats":2},{"TradeProduct":"a","Seats":1}]`,
			}

			ret, err := buildGuaranteeCompareMap(item)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret["AccountId"], convey.ShouldEqual, "acc-a,acc-b,acc-c")
			convey.So(ret["GuaranteeAmount"], convey.ShouldEqual, "10")
			convey.So(ret["GuaranteeTotalAmount"], convey.ShouldEqual, "")
			convey.So(ret["GuaranteeProductSeats"], convey.ShouldResemble, []model.GuaranteeProductSeat{
				{TradeProduct: "a", Seats: 1},
				{TradeProduct: "z", Seats: 2},
			})
			convey.So(ret["GuaranteeAmountLadder"], convey.ShouldResemble, []string{})
		})
	})

	t.Run("非法阶梯金额返回业务错误", func(t *testing.T) {
		mockey.PatchConvey("非法阶梯金额返回业务错误", t, func() {
			rawLadder := `["bad"]`
			item := &model.GuaranteeItem{
				BaseDB:                framework.BaseDB{Id: 302},
				GuaranteeAmountMode:   1,
				GuaranteeAmountLadder: &rawLadder,
			}

			ret, err := buildGuaranteeCompareMap(item)

			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "BizRuleCheckFailed")
		})
	})
}

func Test_DiffQuoteService_diffQuoteItems_BitsUTGen(t *testing.T) {
	t.Run("父子方向反转时交换新增删除并建立稳定映射", func(t *testing.T) {
		mockey.PatchConvey("父子方向反转时交换新增删除并建立稳定映射", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffConf:      &config.DiffConf{},
				childVSParent: false,
				relationType:  quoteDiffRelationSupply,
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeQuoteItemContext: true,
					},
					itemSrcInfo:  &assistant.CallbackInfo{},
					itemDestInfo: &assistant.CallbackInfo{},
					quoteItemsPostProcess: func(_ *quoteDiffProcessInfo, result *CompareResult) {
						result.ChangedDetails = map[string]map[string]ChangedFieldInfo{
							"12": {
								"FieldA": {Code: "FieldA", OriginValue: "old", CurValues: "new"},
							},
						}
					},
				},
			}
			oldItems := []map[string]interface{}{
				{"Id": int64(21), "ChargeItemCompareKey": "same"},
				{"Id": int64(22), "ChargeItemCompareKey": "old-only"},
			}
			newItems := []map[string]interface{}{
				{"Id": int64(12), "ChargeItemCompareKey": "same"},
				{"Id": int64(13), "ChargeItemCompareKey": "new-only"},
			}

			mockey.MockUnsafe((*DiffQuoteService).buildQuoteItemMaps).To(
				func(_ *DiffQuoteService, _ context.Context, _ *assistant.CallbackInfo, isChild bool, _ bool, _ quoteDiffRelationType) []map[string]interface{} {
					if isChild {
						return newItems
					}
					return oldItems
				},
			).Build()
			mockey.Mock(Diff).To(func(_ context.Context, diffCtx *Context) (*CompareResult, error) {
				convey.So(diffCtx.Src, convey.ShouldResemble, oldItems)
				convey.So(diffCtx.Dest, convey.ShouldResemble, newItems)
				return &CompareResult{
					AllList:     []interface{}{int64(21), int64(12)},
					AddedList:   []interface{}{int64(21)},
					DeletedList: []interface{}{int64(12)},
					ChangedList: []interface{}{int64(12)},
				}, nil
			}).Build()

			ret, err := svc.diffQuoteItems(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret.AddedList, convey.ShouldResemble, []interface{}{int64(12)})
			convey.So(ret.DeletedList, convey.ShouldResemble, []interface{}{int64(21)})
			convey.So(ret.NewToOldQuoteItemIDMapping, convey.ShouldResemble, map[int64]int64{12: 21, 13: 0})
			convey.So(ret.OldToNewQuoteItemIDMapping, convey.ShouldResemble, map[int64]int64{21: 12, 22: 0})
			convey.So(ret.ChangedDetails, convey.ShouldContainKey, "12")
			convey.So(ret.ChainKeyByID, convey.ShouldResemble, map[string]string{"12": "same", "21": "same"})
		})
	})

	t.Run("非法报价项ID返回错误", func(t *testing.T) {
		mockey.PatchConvey("非法报价项ID返回错误", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffConf:      &config.DiffConf{},
				childVSParent: true,
				relationType:  quoteDiffRelationSupply,
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeQuoteItemContext: true,
					},
					itemSrcInfo:  &assistant.CallbackInfo{},
					itemDestInfo: &assistant.CallbackInfo{},
				},
			}

			mockey.MockUnsafe((*DiffQuoteService).buildQuoteItemMaps).To(
				func(_ *DiffQuoteService, _ context.Context, _ *assistant.CallbackInfo, isChild bool, _ bool, _ quoteDiffRelationType) []map[string]interface{} {
					if isChild {
						return []map[string]interface{}{{"Id": "bad-id", "ChargeItemCompareKey": "same"}}
					}
					return []map[string]interface{}{{"Id": int64(21), "ChargeItemCompareKey": "same"}}
				},
			).Build()
			mockey.Mock(Diff).Return(&CompareResult{}, nil).Build()

			ret, err := svc.diffQuoteItems(context.Background(), &gorm.DB{}, processInfo)

			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价项Diff中存在非法ID")
		})
	})
}

func Test_DiffQuoteService_diffQuoteGuarantee_BitsUTGen(t *testing.T) {
	t.Run("仅子单有保底时返回新增", func(t *testing.T) {
		mockey.PatchConvey("仅子单有保底时返回新增", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffConf:      &config.DiffConf{},
				childVSParent: true,
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeQuoteGuarantee: true,
					},
					guaranteeSrcInfo: &assistant.CallbackInfo{
						GuaranteeItems: []*model.GuaranteeItem{{BaseDB: framework.BaseDB{Id: 11}}},
					},
					guaranteeDestInfo: &assistant.CallbackInfo{},
				},
			}
			ret, err := svc.diffQuoteGuarantee(context.Background(), &gorm.DB{}, processInfo, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret.ChangeType, convey.ShouldEqual, constants.ChangeTypeAdded)
			convey.So(ret.AllList, convey.ShouldResemble, []interface{}{"11"})
			convey.So(ret.AddedList, convey.ShouldResemble, []interface{}{"11"})
			convey.So(ret.DeletedList, convey.ShouldBeNil)
			convey.So(ret.ChangedList, convey.ShouldResemble, []interface{}{})
			convey.So(ret.SameList, convey.ShouldResemble, []interface{}{})
			convey.So(ret.RawList, convey.ShouldResemble, map[string]*QuoteDiffGuaranteeRawItem{})
		})
	})

	t.Run("排序结果并剔除已细化的same列表", func(t *testing.T) {
		mockey.PatchConvey("排序结果并剔除已细化的same列表", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffConf:      &config.DiffConf{},
				childVSParent: true,
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeQuoteGuarantee: true,
					},
					guaranteeSrcInfo: &assistant.CallbackInfo{
						GuaranteeItems: []*model.GuaranteeItem{{BaseDB: framework.BaseDB{Id: 1}}},
					},
					guaranteeDestInfo: &assistant.CallbackInfo{
						GuaranteeItems: []*model.GuaranteeItem{{BaseDB: framework.BaseDB{Id: 2}}},
					},
					compareFields: []config.DiffFieldInfoConf{{Code: "GuaranteeAmount"}},
				},
			}
			childList := []map[string]interface{}{
				{"Id": int64(5), "GuaranteeChainKey": "child-5"},
				{"Id": int64(3), "GuaranteeChainKey": "child-3"},
			}
			parentList := []map[string]interface{}{
				{"Id": int64(2), "GuaranteeChainKey": "parent-2"},
				{"Id": int64(4), "GuaranteeChainKey": "parent-4"},
			}
			rawList := map[string]*QuoteDiffGuaranteeRawItem{
				"5": {
					ID:           5,
					ChangeType:   constants.ChangeTypeChanged,
					ChangeFields: []string{"GuaranteeAmount"},
				},
			}

			mockey.Mock(buildGuaranteeCompare).To(
				func(_ []*model.GuaranteeItem, isChild bool, _ *quoteDiffProcessInfo) (map[string]*model.GuaranteeItem, []map[string]interface{}, error) {
					if isChild {
						return map[string]*model.GuaranteeItem{"child": {BaseDB: framework.BaseDB{Id: 5}}}, childList, nil
					}
					return map[string]*model.GuaranteeItem{"parent": {BaseDB: framework.BaseDB{Id: 2}}}, parentList, nil
				},
			).Build()
			mockey.Mock(Diff).Return(&CompareResult{
				AllList:     []interface{}{int64(4), int64(1), int64(7), int64(2), int64(3), int64(5)},
				AddedList:   []interface{}{int64(3), int64(1)},
				DeletedList: []interface{}{int64(4), int64(2)},
				SameList:    []interface{}{"5", int64(7)},
			}, nil).Build()
			mockey.MockUnsafe((*DiffQuoteService).diffMatchedGuaranteeRules).Return(rawList, map[string]bool{"5": true}, nil).Build()

			ret, err := svc.diffQuoteGuarantee(context.Background(), &gorm.DB{}, processInfo, &QuoteDiffCommonEntity{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret.AllList, convey.ShouldResemble, []interface{}{int64(1), int64(2), int64(3), int64(4), int64(5), int64(7)})
			convey.So(ret.AddedList, convey.ShouldResemble, []interface{}{int64(1), int64(3)})
			convey.So(ret.DeletedList, convey.ShouldResemble, []interface{}{int64(2), int64(4)})
			convey.So(ret.ChangedList, convey.ShouldResemble, []interface{}{"5"})
			convey.So(ret.SameList, convey.ShouldResemble, []interface{}{int64(7)})
			convey.So(ret.ChangeType, convey.ShouldEqual, constants.ChangeTypeChanged)
			convey.So(ret.RawList, convey.ShouldResemble, rawList)
			convey.So(ret.ChainKeyByID, convey.ShouldResemble, map[string]string{
				"2": "parent-2",
				"3": "child-3",
				"4": "parent-4",
				"5": "child-5",
			})
		})
	})
}

func Test_DiffQuoteService_diffQuoteJointPrintOrder_BitsUTGen(t *testing.T) {
	t.Run("returns empty result when joint print order diff is not required", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{},
				},
			}

			ret, err := svc.diffQuoteJointPrintOrder(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldResemble, &QuoteDiffJointPrintOrder{})
		})
	})

	t.Run("compares parent as source when child vs parent flag is false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeJointPrintOrder: true,
					},
					compareFields: []config.DiffFieldInfoConf{
						{Code: "Support"},
						{Code: "PrintSceneDec"},
					},
				},
				childVSParent: false,
				parentQuoteDB: &model.Quote{
					JointPrintOrder: "{\"Support\":true,\"PrintSceneDec\":\"parent\"}",
				},
				childQuoteDB: &model.Quote{
					JointPrintOrder: "{\"Support\":false,\"PrintSceneDec\":\"child\"}",
				},
				diffConf: &config.DiffConf{},
			}

			ret, err := svc.diffQuoteJointPrintOrder(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret.ChangeFields, convey.ShouldContain, "Support")
			convey.So(ret.ChangeFields, convey.ShouldContain, "PrintSceneDec")
			convey.So(ret.ChangedDetail["Support"].OriginValue, convey.ShouldEqual, false)
			convey.So(ret.ChangedDetail["Support"].CurValues, convey.ShouldEqual, true)
			convey.So(ret.ChangedDetail["PrintSceneDec"].OriginValue, convey.ShouldEqual, "child")
			convey.So(ret.ChangedDetail["PrintSceneDec"].CurValues, convey.ShouldEqual, "parent")
		})
	})

	t.Run("wraps diff errors", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := NewDiffQuoteService()
			processInfo := &quoteDiffProcessInfo{
				diffHandler: &StubDiffHandler{
					needInfo: map[multienv.QuoteInfoType]bool{
						multienv.InfoTypeJointPrintOrder: true,
					},
					compareFields: []config.DiffFieldInfoConf{{Code: "Support"}},
				},
				childVSParent: true,
				parentQuoteDB: &model.Quote{
					JointPrintOrder: "{\"Support\":false}",
				},
				childQuoteDB: &model.Quote{
					JointPrintOrder: "{\"Support\":true}",
				},
				diffConf: &config.DiffConf{},
			}

			mockey.Mock(Diff).Return(nil, errors.New("diff failed")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			ret, err := svc.diffQuoteJointPrintOrder(context.Background(), &gorm.DB{}, processInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单联合打单信息对比失败")
			convey.So(ret, convey.ShouldBeNil)
		})
	})
}

type StubDiffHandler struct {
	needInfo              map[multienv.QuoteInfoType]bool
	compareFields         []config.DiffFieldInfoConf
	changeScene           bool
	couponSrcInfo         *assistant.CallbackInfo
	couponDestInfo        *assistant.CallbackInfo
	itemSrcInfo           *assistant.CallbackInfo
	itemDestInfo          *assistant.CallbackInfo
	rebateSrcInfo         *assistant.CallbackInfo
	rebateDestInfo        *assistant.CallbackInfo
	guaranteeSrcInfo      *assistant.CallbackInfo
	guaranteeDestInfo     *assistant.CallbackInfo
	quoteItemsPostProcess func(processInfo *quoteDiffProcessInfo, compareResult *CompareResult)
}

package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// SupplyConfigListDiffHandler   补充配置清单 Diff处理器
type SupplyConfigListDiffHandler struct {
	SrcQuoteDB      *model.Quote
	DestQuoteDB     *model.Quote
	isChildVSParent bool
}

func (h *SupplyConfigListDiffHandler) getSupplySceneType() string {
	return multienv.ProjectSupplyAgreement
}

func (h *SupplyConfigListDiffHandler) validateQuote(ctx context.Context, tx *gorm.DB) error {
	if !h.isChildVSParent {
		return errors.ErrCustomerError.WithArgs("补充配置清单对比只支持子和父对比")
	}
	return nil
}

func (h *SupplyConfigListDiffHandler) needDiffInfo(infoType multienv.QuoteInfoType) bool {
	if infoType == multienv.InfoTypeQuoteBaseInfo {
		return true
	}
	if infoType == multienv.InfoTypeQuoteItemContext {
		return true
	}
	return false
}

func (h *SupplyConfigListDiffHandler) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return getDiffFieldConfigBySceneType(diffFieldMap, h.getSupplySceneType())
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {
	srcCallbackInfo := &assistant.CallbackInfo{
		Quote: h.SrcQuoteDB,
	}

	parentConfigList, err := dal.QuoteDao.FindQuoteByID(tx, h.DestQuoteDB.QuoteCreateFrom)
	if err != nil {
		argosnotifylogs.CtxError(ctx, "[SupplyConfigListDiffHandler]getDiffQuoteBaseInfo, parentConfigList fail, parentConfigListID=%d, err=%+v", h.DestQuoteDB.QuoteCreateFrom, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价单信息失败")
	}
	destCallbackInfo := &assistant.CallbackInfo{
		Quote: parentConfigList,
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(h.SrcQuoteDB, h.DestQuoteDB, h.isChildVSParent)

	// 子补充配置清单，额外查询失效报价项、交付项
	childCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, childQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,           // 报价项
				assistant.CallbackKeyQuoteItemsExpired,    // 失效报价项
				assistant.CallbackKeyDeliveryItems,        // 交付项
				assistant.CallbackKeyDeliveryItemsExpired, // 失效交付项
				assistant.CallbackKeyItemValues,           // 报价项条目
			},
		),
	)

	if err != nil || childCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[SupplyConfigListDiffHandler]getDiffQuoteItemInfo, childCallbackInfo fail, childQuoteID=%d, err=%+v", childQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	// 根据子补充配置清单，获取父项目制报价单失效的报价项、交付项
	expiredParentItems := getExpiredParentItems(childCallbackInfo.AllQuoteItemsExpired, childCallbackInfo.AllDeliveryItemsExpired)

	// 父项目制报价单
	parentCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, parentQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyDeliveryItems, // 交付项
				assistant.CallbackKeyItemValues,    // 报价项条目
			},
		),
	)

	if err != nil || parentCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[SupplyConfigListDiffHandler]getDiffQuoteItemInfo, parentCallbackInfo fail, parentQuoteID=%d, err=%+v", parentQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	// 父项目制报价单，过滤失效报价项、交付项
	parentCallbackInfo.AllQuoteItems = filterExpiredItems(expiredParentItems, parentCallbackInfo.AllQuoteItems)
	parentCallbackInfo.AllDeliveryItems = filterExpiredItems(expiredParentItems, parentCallbackInfo.AllDeliveryItems)

	srcCallbackInfo, destCallbackInfo := getSrcVSDestCallbackInfo(childCallbackInfo, parentCallbackInfo, h.isChildVSParent)
	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *SupplyConfigListDiffHandler) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
}

func (h *SupplyConfigListDiffHandler) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *SupplyConfigListDiffHandler) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *SupplyConfigListDiffHandler) isChangeScene() bool {
	return false
}

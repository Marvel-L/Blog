package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func Test_PublicSupplyDiffHandler_getSupplySceneType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			supplySceneType := diffHandler.getSupplySceneType()

			// Assert
			convey.So(supplySceneType, convey.ShouldNotBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_validateQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			err := diffHandler.validateQuote(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_needDiffInfo(t *testing.T) {
	t.Run("始终包含保底与联合打单对比", func(t *testing.T) {
		mockey.PatchConvey("始终包含保底与联合打单对比", t, func() {
			diffHandler := getPublicSupplyDiffHandler()

			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteBaseInfo), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteItemContext), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteCoupon), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteRebate), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeJointPrintOrder), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteGuarantee), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(666), convey.ShouldBeFalse)
		})
	})
}

func Test_PublicSupplyDiffHandler_getDiffFieldConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			fieldConfig := diffHandler.getDiffFieldConfig(nil)

			// Assert
			convey.So(fieldConfig, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_getDiffQuoteBaseInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteBaseInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_getDiffQuoteItemInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteItemInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_getDiffQuoteCouponInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCouponInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_getDiffQuoteGuaranteeInfo(t *testing.T) {
	t.Run("成功返回保底回调信息", func(t *testing.T) {
		mockey.PatchConvey("成功返回保底回调信息", t, func() {
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).To(func(_ context.Context, _ *gorm.DB, quote *model.Quote, opts ...assistant.CallbackOption) (*assistant.CallbackInfo, pkg_errors.APIError) {
				callbackCtx := &assistant.CallbackContext{}
				for _, opt := range opts {
					opt.F(callbackCtx)
				}
				convey.So(callbackCtx.CallbackInfoKeys, convey.ShouldContain, assistant.CallbackKeyGuaranteeItem)
				return &assistant.CallbackInfo{Quote: quote, GuaranteeItems: []*model.GuaranteeItem{{}}}, nil
			}).Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcCallbackInfo.Quote, convey.ShouldEqual, diffHandler.SrcQuoteDB)
			convey.So(destCallbackInfo.Quote, convey.ShouldEqual, diffHandler.DestQuoteDB)
			convey.So(srcCallbackInfo.GuaranteeItems, convey.ShouldNotBeEmpty)
			convey.So(destCallbackInfo.GuaranteeItems, convey.ShouldNotBeEmpty)
		})
	})

	t.Run("源报价单查询失败时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("源报价单查询失败时返回统一错误", t, func() {
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})

	t.Run("目标报价单查询失败时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("目标报价单查询失败时返回统一错误", t, func() {
			diffHandler := getPublicSupplyDiffHandler()
			srcInfo := &assistant.CallbackInfo{Quote: diffHandler.SrcQuoteDB, GuaranteeItems: []*model.GuaranteeItem{{}}}
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).
					Then(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})
}
func Test_PublicSupplyDiffHandler_getDiffQuoteCreditInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCreditInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func Test_PublicSupplyDiffHandler_getDiffQuoteRebateInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("source callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getPublicSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})

	t.Run("destination callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getPublicSupplyDiffHandler()
			srcInfo := &assistant.CallbackInfo{Quote: diffHandler.SrcQuoteDB}
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).
					Then(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})
}

func Test_PublicSupplyDiffHandler_diffQuoteItemsResultPostProcessing(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicSupplyDiffHandler()

			// Act
			diffHandler.diffQuoteItemsResultPostProcessing(nil, nil)

			// Assert
		})
	})
}

func getPublicSupplyDiffHandler() *PublicSupplyDiffHandler {
	return &PublicSupplyDiffHandler{
		SrcQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 1,
			},
			ParentQuoteID: 0,
		},
		DestQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 2,
			},
			ParentQuoteID: 1,
		},
		isChildVSParent: false,
	}
}

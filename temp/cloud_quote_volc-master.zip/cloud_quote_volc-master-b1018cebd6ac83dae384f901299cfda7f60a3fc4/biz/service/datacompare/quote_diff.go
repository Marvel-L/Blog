package datacompare

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

type DiffQuoteService struct {
}

func NewDiffQuoteService() *DiffQuoteService {
	return &DiffQuoteService{}
}

type quoteDiffProcessInfo struct {
	diffConf      *config.DiffConf
	childVSParent bool
	relationType  quoteDiffRelationType
	scene         []string
	childQuoteDB  *model.Quote
	parentQuoteDB *model.Quote
	diffHandler   DiffHandler
}

type QuoteDiffResult struct {
	BasicInfo            *QuoteDiffBasicInfo       `json:"BasicInfo,omitempty"`
	Items                *QuoteDiffCommonEntity    `json:"Items,omitempty"`
	Coupon               *QuoteDiffCoupon          `json:"Coupon,omitempty"`
	Guarantee            *QuoteDiffGuarantee       `json:"Guarantee,omitempty"`
	Credit               *QuoteDiffCommonEntity    `json:"Credit,omitempty"`
	Rebate               *QuoteDiffCommonEntity    `json:"Rebate,omitempty"`
	ProfitCal            *QuoteDiffProfitCal       `json:"ProfitCal,omitempty"`
	ProductLineProfitCal *QuoteDiffCommonEntity    `json:"ProductLineProfitCal,omitempty"`
	JointPrintOrder      *QuoteDiffJointPrintOrder `json:"JointPrintOrder,omitempty"`
}

// QuoteDiffJointPrintOrder 联合打单信息对比
type QuoteDiffJointPrintOrder struct {
	ChangeFields  []string                    `json:"ChangeFields,omitempty"`  // 变更字段
	ChangedDetail map[string]ChangedFieldInfo `json:"ChangedDetail,omitempty"` // 变更详情
}

// QuoteDiffBasicInfo 基础信息
type QuoteDiffBasicInfo struct {
	ChangeFields  []string                    `json:"ChangeFields,omitempty"`  // 变更字段
	ChangedDetail map[string]ChangedFieldInfo `json:"ChangedDetail,omitempty"` // 变更详情
}

type QuoteDiffCommonEntity struct {
	AllList                    []interface{}                          `json:"AllList,omitempty"`                    // 全部
	AddedList                  []interface{}                          `json:"AddedList,omitempty"`                  // 新增的ID
	DeletedList                []interface{}                          `json:"DeletedList,omitempty"`                // 删除的ID
	ChangedList                []interface{}                          `json:"ChangedList,omitempty"`                // 变更的ID
	SameList                   []interface{}                          `json:"SameList,omitempty"`                   // 未变更的ID
	ChangedDetails             map[string]map[string]ChangedFieldInfo `json:"ChangedDetails,omitempty"`             // 变更详情
	ChainKeyByID               map[string]string                      `json:"ChainKeyByID,omitempty"`               // 实体ID对应的跨Diff链路Key
	NewToOldQuoteItemIDMapping map[int64]int64                        `json:"NewToOldQuoteItemIDMapping,omitempty"` // 新单报价项 ID 到旧单报价项 ID，未匹配时值为 0
	OldToNewQuoteItemIDMapping map[int64]int64                        `json:"OldToNewQuoteItemIDMapping,omitempty"` // 旧单报价项 ID 到新单报价项 ID，未匹配时值为 0
	itemSrcList                []map[string]interface{}
	itemDestList               []map[string]interface{}
}

type QuoteDiffProfitCal struct {
	UnitCostProfitCal       *QuoteDiffCommonEntity // 目标成本
	FactoryPriceProfitCal   *QuoteDiffCommonEntity // 出厂价
	LatestResourceProfitCal *QuoteDiffCommonEntity // 最新资源价
}

// QuoteDiffCoupon 代金券配置
type QuoteDiffCoupon struct {
	QuoteDiffCommonEntity
	RawList map[string]*QuoteDiffCouponRawItem `json:"RawList,omitempty"` // 代金券配置变更详情
}

type QuoteDiffCouponRawItem struct {
	ID                  int64                       `json:"ID,omitempty"`                  // 变更ID
	ChangeFields        []string                    `json:"ChangeFields,omitempty"`        // 变更字段
	ChangedDetails      map[string]ChangedFieldInfo `json:"ChangedDetails,omitempty"`      // 变更字段详情（含前后值）
	ProductLimitList    *QuoteDiffCommonEntity      `json:"ProductLimitList,omitempty"`    // 适用商品范围
	QuoteItemIDList     *QuoteDiffCommonEntity      `json:"QuoteItemIDList,omitempty"`     // QuoteItemIDList变更（仅按账单金额/比例返券）
	StatQuoteItemIDList *QuoteDiffCommonEntity      `json:"StatQuoteItemIDList,omitempty"` // StatQuoteItemIDList变更（仅按账单金额比例返券）
}

type QuoteDiffGuarantee struct {
	QuoteDiffCommonEntity
	ChangeType int                                   `json:"ChangeType,omitempty"` // 兼容旧单保底字段；多保底以 AddedList/DeletedList/ChangedList 为准
	RawList    map[string]*QuoteDiffGuaranteeRawItem `json:"RawList,omitempty"`    // 保底规则变更详情
}

type QuoteDiffGuaranteeRawItem struct {
	ID              int64                       `json:"ID,omitempty"`
	ChangeType      int                         `json:"ChangeType,omitempty"`
	ChangeFields    []string                    `json:"ChangeFields,omitempty"`
	ChangedDetails  map[string]ChangedFieldInfo `json:"ChangedDetails,omitempty"`
	QuoteItemIDList *QuoteDiffCommonEntity      `json:"QuoteItemIDList,omitempty"`
}

func (s *DiffQuoteService) Diff(ctx context.Context, tx *gorm.DB, quoteID int64, compareWith int64) (*QuoteDiffResult, error) {
	if tx == nil {
		tx = dal.DBProxy.NewRequest(ctx)
	}
	if snapshot, found := s.getDiffSnapshotByQuoteIDs(ctx, tx, quoteID, compareWith); found {
		logs.CtxInfo(ctx, "[DiffQuoteService] diff snapshot found, quoteID=%d, compareWith=%d", quoteID, compareWith)
		return snapshot, nil
	}
	return s.diffQuote(ctx, tx, quoteID, compareWith)
}

// diffQuote 实时计算报价差异，不读取已保存的 Diff 快照。
func (s *DiffQuoteService) diffQuote(ctx context.Context, tx *gorm.DB, quoteID int64, compareWith int64) (*QuoteDiffResult, error) {
	var (
		processInfo = &quoteDiffProcessInfo{}
		err         error
	)
	if tx == nil {
		tx = dal.DBProxy.NewRequest(ctx)
	}

	// 入参校验
	srcQuoteDB, destQuoteDB, err := s.validateParam(tx, quoteID, compareWith)
	if err != nil {
		return nil, err
	}

	// 两个报价单是否可以对比
	if need := s.isRelatedQuote(srcQuoteDB, destQuoteDB); !need {
		logs.CtxInfo(ctx, "[DiffQuoteService]Diff, isRelated=false")
		return s.newEmptyResp(), nil
	}
	processInfo.childVSParent = isChildVSParent(srcQuoteDB, destQuoteDB)

	// 获取对比特殊场景，以子报价单为准
	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(srcQuoteDB, destQuoteDB, processInfo.childVSParent)
	processInfo.childQuoteDB = childQuoteDB
	processInfo.parentQuoteDB = parentQuoteDB
	processInfo.relationType = getQuoteDiffRelationType(childQuoteDB, parentQuoteDB)
	processInfo.scene = getDiffFieldBizScene(processInfo.childQuoteDB)

	// 获取diff配置
	diffConf := config.GetDiffConf(ctx)
	if diffConf == nil {
		return nil, errors.ErrCustomerError.WithArgs("internal error, get config fail")
	}
	processInfo.diffConf = diffConf

	// 获取diff逻辑处理器
	diffHandler, err := getDiffHandler(srcQuoteDB, destQuoteDB, processInfo.childVSParent, processInfo.relationType)
	if err != nil {
		return nil, err
	}
	processInfo.diffHandler = diffHandler

	// 校验报价单信息
	if err := diffHandler.validateQuote(ctx, tx); err != nil {
		return nil, err
	}

	return s.diff(ctx, tx, processInfo)
}

func (s *DiffQuoteService) diff(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffResult, error) {

	// 对比报价单基础信息
	diffBaseInfo, err := s.diffQuoteBaseInfo(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比报价项
	diffQuoteItems, err := s.diffQuoteItems(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比代金券配置
	diffCoupon, err := s.diffQuoteCoupon(ctx, tx, processInfo, diffQuoteItems)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比保底配置
	diffGuarantee, err := s.diffQuoteGuarantee(ctx, tx, processInfo, diffQuoteItems)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比信控配置
	diffCredit, err := s.diffQuoteCredit(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比返佣配置
	diffRebate, err := s.diffQuoteRebate(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比利润率测算汇总
	diffProfitCal, err := s.diffProfitCalInfo(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}
	//
	// 对比产品线利润率测算汇总
	productLineProfitCal, err := s.diffProductLineProfitCalInfo(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	// 对比联合打单信息
	diffJointPrintOrder, err := s.diffQuoteJointPrintOrder(ctx, tx, processInfo)
	if err != nil {
		return s.newEmptyResp(), err
	}

	return &QuoteDiffResult{
		BasicInfo:            diffBaseInfo,
		Items:                diffQuoteItems,
		Coupon:               diffCoupon,
		Guarantee:            diffGuarantee,
		Credit:               diffCredit,
		Rebate:               diffRebate,
		ProfitCal:            diffProfitCal,
		ProductLineProfitCal: productLineProfitCal,
		JointPrintOrder:      diffJointPrintOrder,
	}, nil
}

func (s *DiffQuoteService) validateParam(tx *gorm.DB, quoteID int64, compareWith int64) (*model.Quote, *model.Quote, error) {
	if quoteID == 0 {
		return nil, nil, errors.ErrorMissingParam.WithArgs("QuoteID")
	}
	if compareWith == 0 {
		return nil, nil, errors.ErrorMissingParam.WithArgs("CompareWith")
	}

	srcQuoteDB, err := dal.QuoteDao.FindQuoteByID(tx, quoteID)
	if err != nil {
		return nil, nil, errors.ErrCustomerError.WithArgs("原报价单不存在")
	}
	destQuoteDB, err := dal.QuoteDao.FindQuoteByID(tx, compareWith)
	if err != nil {
		return nil, nil, errors.ErrCustomerError.WithArgs("对比报价单不存在")
	}

	return srcQuoteDB, destQuoteDB, nil
}

// 两个报价单是否有关系
func (s *DiffQuoteService) isRelatedQuote(srcQuote, destQuote *model.Quote) bool {
	if isChildVSParent(srcQuote, destQuote) {
		return true
	}
	if isChildVSParent(destQuote, srcQuote) {
		return true
	}
	return false
}

func (s *DiffQuoteService) diffQuoteBaseInfo(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffBasicInfo, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteBaseInfo) {
		return &QuoteDiffBasicInfo{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteBaseInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.QuoteBaseInfoDiffField)
	srcMap := Interface2Map(srcQuoteInfo.Quote)
	destMap := Interface2Map(destQuoteInfo.Quote)

	result, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields: compareFields,
		},
		Src:   srcMap,
		Dest:  destMap,
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteBaseInfoFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单基础信息对比失败")
	}

	return &QuoteDiffBasicInfo{
		ChangeFields:  result.DiffFields,
		ChangedDetail: result.ChangedDetail,
	}, nil
}

func (s *DiffQuoteService) diffQuoteItems(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteItemContext) {
		return &QuoteDiffCommonEntity{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteItemInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.QuoteItemContextDiffField)
	srcList := s.buildQuoteItemMaps(
		ctx,
		srcQuoteInfo,
		processInfo.childVSParent,
		processInfo.diffHandler.isChangeScene(),
		processInfo.relationType,
	)
	destList := s.buildQuoteItemMaps(
		ctx,
		destQuoteInfo,
		!processInfo.childVSParent,
		processInfo.diffHandler.isChangeScene(),
		processInfo.relationType,
	)
	compareKeyBuilder := buildKeyBuilder("ChargeItemCompareKey")

	diffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields:               compareFields,
			ListCompareSrcKeyBuilder:    compareKeyBuilder,
			ListCompareDestKeyBuilder:   compareKeyBuilder,
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
		},
		Src:   srcList,
		Dest:  destList,
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteItemsFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单报价项信息对比失败")
	}

	// diff结果特殊处理
	processInfo.diffHandler.diffQuoteItemsResultPostProcessing(processInfo, diffResult)

	if !processInfo.childVSParent {
		tmp := diffResult.AddedList
		diffResult.AddedList = diffResult.DeletedList
		diffResult.DeletedList = tmp
	}

	// 差异计算的源端和目标端跟随内部处理方向，但对外映射固定表达业务新单与旧单；
	// 当前源端为父单时交换两侧，避免映射方向随内部调用顺序变化。
	newItems, oldItems := srcList, destList
	if !processInfo.childVSParent {
		newItems, oldItems = destList, srcList
	}
	newToOld, oldToNew, err := buildQuoteItemIDMappings(ctx, newItems, oldItems)
	if err != nil {
		return nil, err
	}
	return &QuoteDiffCommonEntity{
		NewToOldQuoteItemIDMapping: newToOld,
		OldToNewQuoteItemIDMapping: oldToNew,
		AddedList:                  diffResult.AddedList,
		DeletedList:                diffResult.DeletedList,
		ChangedList:                diffResult.ChangedList,
		ChangedDetails:             diffResult.ChangedDetails,
		ChainKeyByID: buildChainKeyByID(
			srcList,
			destList,
			compareKeyBuilder,
			diffResult.AllList,
			diffResult.DeletedList,
		),
		itemSrcList:  srcList,
		itemDestList: destList,
	}, nil
}

// buildChainKeyByID 构建本次 Diff 结果中“实体 ID -> 跨多次 Diff 链路 Key”的映射。
func buildChainKeyByID(
	srcList, destList []map[string]interface{},
	chainKeyBuilder KeyBuilder,
	resultIDLists ...[]interface{},
) map[string]string {
	// resultIDLists 通常包含新增、删除和变更列表；未发生变化的实体无需返回链路 Key。
	resultIDs := make(map[string]struct{})
	for _, resultIDList := range resultIDLists {
		for _, resultID := range resultIDList {
			id := fmt.Sprintf("%+v", resultID)
			if id == "" || id == "<nil>" {
				continue
			}
			resultIDs[id] = struct{}{}
		}
	}
	if len(resultIDs) == 0 {
		return nil
	}

	chainKeyByID := make(map[string]string)
	idKeyBuilder := buildKeyBuilder("Id")
	// 从指定一侧筛选本次 Diff 涉及的实体，并生成链路 Key。
	appendChainKeys := func(itemList []map[string]interface{}) {
		if chainKeyBuilder == nil {
			return
		}
		for _, item := range itemList {
			id := idKeyBuilder(item)
			if _, ok := resultIDs[id]; !ok {
				continue
			}
			chainKey := chainKeyBuilder(item)
			if id == "" || chainKey == "" {
				continue
			}
			chainKeyByID[id] = chainKey
		}
	}
	// 同时扫描两侧，确保新增项可从 src 获取，删除项可从 dest 获取。
	appendChainKeys(srcList)
	appendChainKeys(destList)
	if len(chainKeyByID) == 0 {
		return nil
	}
	return chainKeyByID
}

func (s *DiffQuoteService) buildQuoteItemMaps(
	ctx context.Context,
	info *assistant.CallbackInfo,
	isChild bool,
	isChangeScene bool,
	relationType quoteDiffRelationType,
) []map[string]interface{} {

	var (
		items        = append(info.AllQuoteItems, info.AllDeliveryItems...)
		itemValues   = info.AllItemValues
		quoteItemMap = map[int64]*model.QuoteItem{}
	)
	for _, quoteItem := range info.AllQuoteItems {
		quoteItemMap[quoteItem.Id] = quoteItem
	}

	itemCtx, _ := item_context.NewItemContextByQuoteItemValues(ctx, info.Quote, items, itemValues)

	// AllItemCalMap已通过CallbackKeyItemCalculates加载，并可能被applyQuoteItemTotalDiscount更新
	itemCals := info.AllItemCalMap

	// 获取返佣项映射
	rebateItemMap := info.GetRebateItemMap()

	var result []map[string]interface{}

	for _, item := range items {

		attrMap := Interface2Map(item)

		invoiceItem, _ := trade_client.GetInvoiceItem(item.InvoiceProject)
		attrMap["InvoiceItem"] = invoiceItem

		subCtx := itemCtx[item.Id]
		if subCtx == nil {
			// 过滤不存在报价项上下文信息
			continue
		}

		for k, v := range subCtx.FormValues {
			attrMap[k] = v
		}

		itemCal := itemCals[item.Id]
		if itemCal != nil {
			attrMap["OriginalPrice"] = itemCal.OriginalPrice
			attrMap["OriginalMarketPrice"] = itemCal.OriginalMarketPrice
			attrMap["TotalCost"] = itemCal.TotalCost
			attrMap["TotalFactoryPrice"] = itemCal.TotalFactoryPrice
			attrMap["FactoryPriceProfitRate"] = itemCal.FactoryPriceProfitRate
			attrMap["TotalLatestResourcePrice"] = itemCal.TotalLatestResourcePrice
			attrMap["LatestResourcePriceProfitRate"] = itemCal.LatestResourcePriceProfitRate
			attrMap["ProfitRate"] = itemCal.ProfitRate
			attrMap["IncomeNoTax"] = itemCal.IncomeNoTax
			// 综合折扣、综合返券比例等字段（从CalQuoteItemTotalDiscount返回值中获取）
			attrMap["TotalDiscount"] = itemCal.TotalDiscount
			attrMap["TotalCouponRatio"] = itemCal.TotalCouponRatio
			attrMap["TaxRate"] = itemCal.TaxRate
		}

		// 添加返佣比例字段
		rebateItem := rebateItemMap[item.Id]
		if rebateItem != nil {
			attrMap["RebateLevelType"] = rebateItem.RebateLevelType
		}

		// ChargeItemCompareKey同时用于本次Diff匹配及跨多次Diff串联。
		chargeItemCompareKey := subCtx.GetChargeItemCompareKey()
		// SP抵扣报价项：追加所属SP包报价项的对比key，限定对比范围为相同SP包下的抵扣报价项
		if subCtx.IsSpDeductItem() {
			chargeItemCompareKey = chargeItemCompareKey + constants.Separator + itemCtx[subCtx.RelatedItemID].GetChargeItemCompareKey()
		}
		if item.ItemScene == constants.ItemSceneDeliveryItem {
			if relationType == quoteDiffRelationSnapshot {
				snapshotSourceID := item.Id
				if !isChild {
					snapshotSourceID = item.SnapshotFrom
				}
				chargeItemCompareKey += constants.Separator + strconv.FormatInt(snapshotSourceID, 10)
			} else {
				// 普通业务Diff沿用所属报价项ID匹配，避免同一报价单内重复交付项串行。
				if isChild {
					quoteItem, ok := quoteItemMap[item.ItemBelong]
					if ok {
						if isChangeScene {
							// 变更后拆解的交付项ItemCopyFrom会和原交付项ItemCopyFrom保持一致
							chargeItemCompareKey += constants.Separator + strconv.FormatInt(quoteItem.ItemCopyFrom, 10)
						} else {
							chargeItemCompareKey += constants.Separator + strconv.FormatInt(quoteItem.ParentItemID, 10)
						}
					}
				} else {
					chargeItemCompareKey += constants.Separator + strconv.FormatInt(item.ItemBelong, 10)
				}
			}
		}
		attrMap["ChargeItemCompareKey"] = chargeItemCompareKey

		result = append(result, attrMap)
	}

	return result

}

func (s *DiffQuoteService) diffQuoteCoupon(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo, diffQuoteItems *QuoteDiffCommonEntity) (*QuoteDiffCoupon, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteCoupon) {
		return &QuoteDiffCoupon{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteCouponInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	srcMap, srcList, err := s.buildCouponCompare(ctx, srcQuoteInfo.CouponList, processInfo.childVSParent, processInfo)
	if err != nil {
		return nil, err
	}

	destMap, destList, err := s.buildCouponCompare(ctx, destQuoteInfo.CouponList, !processInfo.childVSParent, processInfo)
	if err != nil {
		return nil, err
	}

	srcKeyBuilder, destKeyBuilder := getCouponKeyBuilder(processInfo)
	chainKeyBuilder := buildKeyBuilder("CouponChainKey")

	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.CouponBaseInfoDiffField)

	baseInfoDiffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields:               compareFields,
			ListCompareSrcKeyBuilder:    srcKeyBuilder,
			ListCompareDestKeyBuilder:   destKeyBuilder,
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
		},
		Src:   srcList,
		Dest:  destList,
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteCouponFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单代金券信息对比失败")
	}

	if !processInfo.childVSParent {
		tmp := baseInfoDiffResult.AddedList
		baseInfoDiffResult.AddedList = baseInfoDiffResult.DeletedList
		baseInfoDiffResult.DeletedList = tmp
	}

	// 代金券适用商品对比
	detailDiffResult := s.diffCouponProductLimit(ctx, srcMap, destMap, processInfo.childVSParent, baseInfoDiffResult, diffQuoteItems)

	var (
		changedMap  = map[string]bool{}
		changedList []interface{}
		sameList    []interface{}
	)

	for changeID := range detailDiffResult {
		changedList = append(changedList, changeID)
		changedMap[changeID] = true
	}

	for _, sameID := range baseInfoDiffResult.SameList {
		if sameIDStr, ok := sameID.(string); ok {
			if _, changeOk := changedMap[sameIDStr]; !changeOk {
				sameList = append(sameList, sameIDStr)
			}
		}
	}

	return &QuoteDiffCoupon{
		QuoteDiffCommonEntity: QuoteDiffCommonEntity{
			AllList:     baseInfoDiffResult.AllList,
			AddedList:   baseInfoDiffResult.AddedList,
			DeletedList: baseInfoDiffResult.DeletedList,
			ChangedList: changedList,
			SameList:    sameList,
			ChainKeyByID: buildChainKeyByID(
				srcList,
				destList,
				chainKeyBuilder,
				baseInfoDiffResult.AllList,
				baseInfoDiffResult.DeletedList,
			),
		},
		RawList: detailDiffResult,
	}, nil
}

func (s *DiffQuoteService) buildCouponCompare(ctx context.Context, couponList model.CouponConfigDBList, isChild bool, processInfo *quoteDiffProcessInfo) (map[int64]*CouponConfigCompare, []map[string]interface{}, error) {
	compareMap := make(map[int64]*CouponConfigCompare, len(couponList))
	compareList := make([]map[string]interface{}, 0, len(couponList))

	for _, coupon := range couponList {
		compare, err := genCouponConfigCompare(coupon)
		if err != nil {
			argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]genCouponConfigCompareFail, couponID=%d, err=%s", coupon.Id, err.Error())
			return nil, nil, errors.ErrCustomerError.WithArgs("代金券配置对比对象转换失败")
		}

		relationInfo := entityRelationInfo{
			id:           coupon.Id,
			changeFrom:   coupon.ChangeFrom,
			copyFrom:     coupon.CopyFrom,
			snapshotFrom: coupon.SnapshotFrom,
		}
		compareKey := entityCompareID(relationInfo, isChild, processInfo)
		// 来源ID为0表示新增项，不需要用于变更详情匹配。
		if compareKey > 0 {
			compareMap[compareKey] = compare
		}
		compareData := Interface2Map(compare)
		compareData["CouponChainKey"] = entityChainKey(relationInfo, isChild, processInfo)
		compareList = append(compareList, compareData)
	}

	return compareMap, compareList, nil
}

type entityRelationInfo struct {
	id           int64
	changeFrom   int64
	copyFrom     int64
	snapshotFrom int64
}

// entityCompareID 根据对比关系选择当前实体的匹配 ID。
func entityCompareID(relationInfo entityRelationInfo, isChild bool, processInfo *quoteDiffProcessInfo) int64 {
	if processInfo == nil {
		if isChild {
			return relationInfo.copyFrom
		}
		return relationInfo.id
	}

	switch processInfo.relationType {
	case quoteDiffRelationSnapshot:
		if isChild {
			return relationInfo.id
		}
		return relationInfo.snapshotFrom
	case quoteDiffRelationChange:
		if isChild {
			return relationInfo.changeFrom
		}
		return relationInfo.id
	case quoteDiffRelationSupply:
		if isChild {
			return relationInfo.copyFrom
		}
		return relationInfo.id
	default:
		return 0
	}
}

// entityChainKey 生成跨业务 Diff 和快照 Diff 稳定的实体链路 key。
func entityChainKey(relationInfo entityRelationInfo, isChild bool, processInfo *quoteDiffProcessInfo) string {
	if relationInfo.id == 0 || processInfo == nil {
		return ""
	}

	var chainID int64
	switch processInfo.relationType {
	case quoteDiffRelationChange:
		chainID = relationInfo.id
		if isChild && relationInfo.changeFrom > 0 {
			chainID = relationInfo.changeFrom
		}
	case quoteDiffRelationSupply:
		chainID = relationInfo.id
		if isChild && relationInfo.copyFrom > 0 {
			chainID = relationInfo.copyFrom
		}
	case quoteDiffRelationSnapshot:
		if processInfo.childQuoteDB != nil && processInfo.childQuoteDB.IsChangeQuoteCommon() {
			chainID = relationInfo.changeFrom
		} else if processInfo.childQuoteDB != nil && processInfo.childQuoteDB.IsSupplyAgreement() {
			chainID = relationInfo.copyFrom
		}
		if chainID <= 0 {
			if isChild {
				chainID = relationInfo.id
			} else {
				chainID = relationInfo.snapshotFrom
			}
		}
	default:
		return ""
	}

	if chainID <= 0 {
		return ""
	}
	return strconv.FormatInt(chainID, 10)
}

func (s *DiffQuoteService) diffCouponProductLimit(ctx context.Context, srcCouponMap, destCouponMap map[int64]*CouponConfigCompare, childVSParent bool, baseInfoDiffResult *CompareResult, diffQuoteItems *QuoteDiffCommonEntity) map[string]*QuoteDiffCouponRawItem {

	detailResult := map[string]*QuoteDiffCouponRawItem{}

	// 代金券基础信息对比，仅对比两个报价单中都包含的数据
	for key, srcCoupon := range srcCouponMap {

		destCoupon := destCouponMap[key]
		if destCoupon == nil {
			continue
		}

		var productLimitDiffResult *QuoteDiffCommonEntity

		// 适用商品范围
		productLimitResult := s.diffCouponProductLimitDetail(ctx, srcCoupon.ProductLimits, destCoupon.ProductLimits)

		if productLimitResult != nil {
			if !childVSParent {
				tmp := productLimitResult.AddedList
				productLimitResult.AddedList = productLimitResult.DeletedList
				productLimitResult.DeletedList = tmp
			}
			productLimitDiffResult = &QuoteDiffCommonEntity{
				AddedList:   productLimitResult.AddedList,
				DeletedList: productLimitResult.DeletedList,
				ChangedList: productLimitResult.ChangedList,
			}
		}

		resultKey := fmt.Sprintf("%d", srcCoupon.Id)

		var changeFields []string
		for k := range baseInfoDiffResult.ChangedDetails[resultKey] {
			changeFields = append(changeFields, k)
		}

		var quoteItemIDListDiffResult *QuoteDiffCommonEntity
		var statQuoteItemIDListDiffResult *QuoteDiffCommonEntity

		// QuoteItemIDList对比：仅对按账单金额/按账单金额比例返券进行对比
		// 其他/分期返券类型代金券不对比QuoteItemIDList
		if srcCoupon.RebateCouponWay == couponconfigconst.RebateCouponWayByAmount ||
			srcCoupon.RebateCouponWay == couponconfigconst.RebateCouponWayByAmountPercent {
			quoteItemIDListResult := s.diffCouponQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			if quoteItemIDListResult != nil {
				if !childVSParent {
					tmp := quoteItemIDListResult.AddedList
					quoteItemIDListResult.AddedList = quoteItemIDListResult.DeletedList
					quoteItemIDListResult.DeletedList = tmp
				}
				quoteItemIDListDiffResult = &QuoteDiffCommonEntity{
					AddedList:   quoteItemIDListResult.AddedList,
					DeletedList: quoteItemIDListResult.DeletedList,
					ChangedList: quoteItemIDListResult.ChangedList,
				}
				// 仅保留“代金券删除了，但报价项本身仍存在”的QuoteItemID。
				if len(quoteItemIDListDiffResult.DeletedList) > 0 {
					quoteItemIDListDiffResult.DeletedList = filterDeletedRelatedQuoteItems(quoteItemIDListDiffResult.DeletedList, diffQuoteItems.DeletedList)
					quoteItemIDListDiffResult.DeletedList = buildCurrentQuoteItemIDListByOriginIDs(quoteItemIDListDiffResult.DeletedList, diffQuoteItems, childVSParent)
				}
			}
		}

		// StatQuoteItemIDList对比：仅对按账单金额比例返券进行对比
		if srcCoupon.RebateCouponWay == couponconfigconst.RebateCouponWayByAmountPercent {
			statQuoteItemIDListResult := s.diffCouponStatQuoteItemIDList(ctx, srcCoupon, destCoupon, diffQuoteItems)
			if statQuoteItemIDListResult != nil {
				if !childVSParent {
					tmp := statQuoteItemIDListResult.AddedList
					statQuoteItemIDListResult.AddedList = statQuoteItemIDListResult.DeletedList
					statQuoteItemIDListResult.DeletedList = tmp
				}
				statQuoteItemIDListDiffResult = &QuoteDiffCommonEntity{
					AddedList:   statQuoteItemIDListResult.AddedList,
					DeletedList: statQuoteItemIDListResult.DeletedList,
					ChangedList: statQuoteItemIDListResult.ChangedList,
				}
				// 先过滤报价项本身已删除的统计项，再将删除结果映射为当前单报价项ID。
				if len(statQuoteItemIDListDiffResult.DeletedList) > 0 {
					statQuoteItemIDListDiffResult.DeletedList = filterDeletedRelatedQuoteItems(statQuoteItemIDListDiffResult.DeletedList, diffQuoteItems.DeletedList)
					statQuoteItemIDListDiffResult.DeletedList = buildCurrentQuoteItemIDListByOriginIDs(statQuoteItemIDListDiffResult.DeletedList, diffQuoteItems, childVSParent)
				}
			}
		}

		couponRawItem := &QuoteDiffCouponRawItem{
			ID:                  srcCoupon.Id,
			ChangeFields:        changeFields,
			ChangedDetails:      baseInfoDiffResult.ChangedDetails[resultKey],
			ProductLimitList:    productLimitDiffResult,
			QuoteItemIDList:     quoteItemIDListDiffResult,
			StatQuoteItemIDList: statQuoteItemIDListDiffResult,
		}

		if s.checkQuoteCouponChange(couponRawItem) {
			// 只有变更记录
			detailResult[resultKey] = couponRawItem
		}
	}

	return detailResult
}

func (s *DiffQuoteService) diffCouponProductLimitDetail(
	ctx context.Context,
	srcProducts, destProducts []*model.CouponConfigProductsLimitDB,
) *CompareResult {

	diffCtx := &Context{
		Config: &Config{
			ListCompareSrcKeyBuilder:    buildKeyBuilder("Product"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("Product"),
			ListCompareResultKeyBuilder: buildKeyBuilder("Product"),
			CompareFields:               []config.DiffFieldInfoConf{{Code: "ValueKeys"}},
		},
		Src:  Interface2Slice(genCouponProductsLimitCompare(srcProducts)),
		Dest: Interface2Slice(genCouponProductsLimitCompare(destProducts)),
	}
	result, err := Diff(ctx, diffCtx)
	if err != nil {
		// 仅记录错误信息
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffCouponProductLimitDetailFail, err=%s", err.Error())
	}
	return result
}

// diffCouponQuoteItemIDList 对比代金券的QuoteItemIDList
// 按账单金额/按账单金额比例返券中，QuoteItemIDList新增或删除需要标记
func (s *DiffQuoteService) diffCouponQuoteItemIDList(ctx context.Context, srcCoupon, destCoupon *CouponConfigCompare, diffQuoteItems *QuoteDiffCommonEntity) *CompareResult {
	return s.diffCouponItemIDListCommon(
		ctx,
		srcCoupon.TriggerInfoQuoteItemIDList,
		destCoupon.TriggerInfoQuoteItemIDList,
		diffQuoteItems,
		"[diffCouponQuoteItemIDList]DiffFail, err=%s",
	)
}

// diffCouponStatQuoteItemIDList 对比代金券的StatQuoteItemIDList
// 按账单金额比例返券中，StatQuoteItemIDList新增或删除需要标记
func (s *DiffQuoteService) diffCouponStatQuoteItemIDList(ctx context.Context, srcCoupon, destCoupon *CouponConfigCompare, diffQuoteItems *QuoteDiffCommonEntity) *CompareResult {
	return s.diffCouponItemIDListCommon(
		ctx,
		srcCoupon.TriggerInfoStatQuoteItemIDList,
		destCoupon.TriggerInfoStatQuoteItemIDList,
		diffQuoteItems,
		"[diffCouponStatQuoteItemIDList]DiffFail, err=%s",
	)
}

// diffCouponItemIDListCommon 对比代金券的ItemIDList（公共逻辑）
func (s *DiffQuoteService) diffCouponItemIDListCommon(
	ctx context.Context,
	srcItemIDs, destItemIDs []int64,
	diffQuoteItems *QuoteDiffCommonEntity,
	errorLogFormat string,
) *CompareResult {

	var (
		srcItemIDMap  = map[string]bool{}
		destItemIDMap = map[string]bool{}
		itemSrcList   = diffQuoteItems.itemSrcList
		itemDestList  = diffQuoteItems.itemDestList
	)
	for _, itemID := range srcItemIDs {
		srcItemIDMap[strconv.FormatInt(itemID, 10)] = true
	}
	for _, itemID := range destItemIDs {
		destItemIDMap[strconv.FormatInt(itemID, 10)] = true
	}

	// 构建对比数据
	var srcList []map[string]interface{}
	var destList []map[string]interface{}
	for _, itemSrcDataMap := range itemSrcList {
		idStr := fmt.Sprintf("%+v", itemSrcDataMap["Id"])
		if _, ok := srcItemIDMap[idStr]; ok {
			srcList = append(srcList, itemSrcDataMap)
		}
	}
	for _, itemDescDataMap := range itemDestList {
		idStr := fmt.Sprintf("%+v", itemDescDataMap["Id"])
		if _, ok := destItemIDMap[idStr]; ok {
			destList = append(destList, itemDescDataMap)
		}
	}

	// 如果两个列表都为空，无需对比
	if len(srcList) == 0 && len(destList) == 0 {
		return nil
	}

	diffCtx := &Context{
		Config: &Config{
			ListCompareSrcKeyBuilder:    buildKeyBuilder("ChargeItemCompareKey"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("ChargeItemCompareKey"),
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
			CompareFields:               []config.DiffFieldInfoConf{},
		},
		Src:  srcList,
		Dest: destList,
	}

	result, err := Diff(ctx, diffCtx)
	if err != nil {
		argosnotifylogs.CtxError(ctx, errorLogFormat, err.Error())
		return nil
	}

	// 如果没有变化，返回nil
	if len(result.AddedList) == 0 && len(result.DeletedList) == 0 {
		return nil
	}

	return result
}

// filterDeletedRelatedQuoteItems 过滤关联报价项的删除结果。
// 保留规则：
// - 保留：代金券/保底删除了该QuoteItemID，但报价项本身未删除 => 需要标记“删”
// - 过滤：代金券/保底删除了该QuoteItemID，且报价项本身也删除了 => 无需标记“删”
func filterDeletedRelatedQuoteItems(deletedList []interface{}, deletedQuoteItemIDs []interface{}) []interface{} {
	if len(deletedList) == 0 || len(deletedQuoteItemIDs) == 0 {
		return deletedList
	}
	delQuoteItemMap := map[string]bool{}
	for _, deletedQuoteItemID := range deletedQuoteItemIDs {
		deletedID, ok := deletedQuoteItemID.(string)
		if ok {
			delQuoteItemMap[deletedID] = true
		}
	}
	filtered := make([]interface{}, 0, len(deletedList))
	for _, deleted := range deletedList {
		deletedID, ok := deleted.(string)
		if !ok {
			filtered = append(filtered, deleted)
			continue
		}
		if delQuoteItemMap[deletedID] {
			continue
		}
		filtered = append(filtered, deleted)
	}
	return filtered
}

func buildCurrentQuoteItemIDListByOriginIDs(deletedList []interface{}, diffQuoteItems *QuoteDiffCommonEntity, childVSParent bool) []interface{} {
	if len(deletedList) == 0 || diffQuoteItems == nil {
		return deletedList
	}

	currentItemList := diffQuoteItems.itemSrcList
	originItemList := diffQuoteItems.itemDestList
	if !childVSParent {
		currentItemList = diffQuoteItems.itemDestList
		originItemList = diffQuoteItems.itemSrcList
	}

	currentIDByCompareKey := make(map[string]string, len(currentItemList))
	for _, itemMap := range currentItemList {
		compareKey := fmt.Sprintf("%+v", itemMap["ChargeItemCompareKey"])
		id := fmt.Sprintf("%+v", itemMap["Id"])
		if compareKey == "" || compareKey == "<nil>" || id == "" || id == "<nil>" {
			continue
		}
		currentIDByCompareKey[compareKey] = id
	}

	originCompareKeyByID := make(map[string]string, len(originItemList))
	for _, itemMap := range originItemList {
		id := fmt.Sprintf("%+v", itemMap["Id"])
		compareKey := fmt.Sprintf("%+v", itemMap["ChargeItemCompareKey"])
		if compareKey == "" || compareKey == "<nil>" || id == "" || id == "<nil>" {
			continue
		}
		originCompareKeyByID[id] = compareKey
	}

	ret := make([]interface{}, 0, len(deletedList))
	exists := make(map[string]bool, len(deletedList))
	for _, deleted := range deletedList {
		deletedID := fmt.Sprintf("%+v", deleted)
		compareKey := originCompareKeyByID[deletedID]
		if compareKey == "" {
			continue
		}
		currentID := currentIDByCompareKey[compareKey]
		if currentID == "" || exists[currentID] {
			continue
		}
		exists[currentID] = true
		ret = append(ret, currentID)
	}
	return ret
}

func (s *DiffQuoteService) diffQuoteGuarantee(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo, diffQuoteItems *QuoteDiffCommonEntity) (*QuoteDiffGuarantee, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteGuarantee) {
		return &QuoteDiffGuarantee{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteGuaranteeInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	childQuoteInfo := getChildQuoteInfo(srcQuoteInfo, destQuoteInfo, processInfo.childVSParent)
	parentQuoteInfo := destQuoteInfo
	if !processInfo.childVSParent {
		parentQuoteInfo = srcQuoteInfo
	}
	childGuaranteeItems := getCallbackGuaranteeItems(childQuoteInfo)
	parentGuaranteeItems := getCallbackGuaranteeItems(parentQuoteInfo)
	if len(childGuaranteeItems) == 0 && len(parentGuaranteeItems) == 0 {
		return &QuoteDiffGuarantee{}, nil
	}

	childMap, childList, err := buildGuaranteeCompare(childGuaranteeItems, true, processInfo)
	if err != nil {
		return nil, err
	}
	parentMap, parentList, err := buildGuaranteeCompare(parentGuaranteeItems, false, processInfo)
	if err != nil {
		return nil, err
	}
	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.GuaranteeBaseInfoDiffField)
	compareFields = normalizeGuaranteeBaseInfoDiffFields(compareFields)
	chainKeyBuilder := buildKeyBuilder("GuaranteeChainKey")

	baseInfoDiffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields:               compareFields,
			ListCompareSrcKeyBuilder:    buildKeyBuilder("GuaranteeCompareKey"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("GuaranteeCompareKey"),
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
		},
		Src:   childList,
		Dest:  parentList,
		Scene: processInfo.scene,
	})
	if err != nil {
		logs.CtxError(ctx, "[diffQuoteGuarantee]DiffFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单保底规则信息对比失败")
	}

	rawList, changedMap, err := s.diffMatchedGuaranteeRules(ctx, tx, childMap, parentMap, baseInfoDiffResult, processInfo, diffQuoteItems)
	if err != nil {
		return nil, err
	}

	changedList := make([]interface{}, 0, len(changedMap))
	for changedID := range changedMap {
		changedList = append(changedList, changedID)
	}
	sameList := make([]interface{}, 0, len(baseInfoDiffResult.SameList))
	for _, sameID := range baseInfoDiffResult.SameList {
		sameIDStr := fmt.Sprintf("%+v", sameID)
		if !changedMap[sameIDStr] {
			sameList = append(sameList, sameID)
		}
	}
	sortInterfaceList(baseInfoDiffResult.AllList)
	sortInterfaceList(baseInfoDiffResult.AddedList)
	sortInterfaceList(baseInfoDiffResult.DeletedList)
	sortInterfaceList(changedList)
	sortInterfaceList(sameList)

	ret := &QuoteDiffGuarantee{
		QuoteDiffCommonEntity: QuoteDiffCommonEntity{
			AllList:     baseInfoDiffResult.AllList,
			AddedList:   baseInfoDiffResult.AddedList,
			DeletedList: baseInfoDiffResult.DeletedList,
			ChangedList: changedList,
			SameList:    sameList,
			ChainKeyByID: buildChainKeyByID(
				childList,
				parentList,
				chainKeyBuilder,
				baseInfoDiffResult.AllList,
				baseInfoDiffResult.DeletedList,
			),
		},
		RawList: rawList,
	}
	fillGuaranteeChangeType(ret)
	return ret, nil
}

// getCallbackGuaranteeItems 从 callback 信息中读取多保底规则列表。
func getCallbackGuaranteeItems(info *assistant.CallbackInfo) []*model.GuaranteeItem {
	if info == nil {
		return nil
	}
	return info.GuaranteeItems
}

// buildGuaranteeCompare 构建保底差异对比的稳定键映射和基础字段列表。
func buildGuaranteeCompare(items []*model.GuaranteeItem, isChild bool, processInfo *quoteDiffProcessInfo) (map[string]*model.GuaranteeItem, []map[string]interface{}, error) {
	itemByCompareKey := map[string]*model.GuaranteeItem{}
	compareList := make([]map[string]interface{}, 0, len(items))
	targets := make(map[int64]*model.GuaranteeItem, len(items))
	for _, item := range items {
		if item != nil {
			targets[item.Id] = item
		}
	}
	for _, item := range items {
		if item == nil || item.Id == 0 {
			continue
		}
		relationInfo := entityRelationInfo{
			id:           item.Id,
			changeFrom:   item.ChangeFrom,
			copyFrom:     item.CopyFrom,
			snapshotFrom: item.SnapshotFrom,
		}
		compareKey := guaranteeCompareKey(relationInfo, isChild, processInfo)
		if compareKey == "" {
			continue
		}
		itemByCompareKey[compareKey] = item
		compareMap, err := buildGuaranteeCompareMap(item)
		if err != nil {
			return nil, nil, err
		}
		if item.CrossGroupCarryForwardID != 0 {
			target := targets[item.CrossGroupCarryForwardID]
			if target == nil || target.QuoteID != item.QuoteID || target.ParentGuaranteeID != 0 {
				return nil, nil, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底规则%d跨组结转目标不存在或无效").WithArgs(item.Id)
			}
			// 新旧单中的跨组目标物理 ID 不同，转换为目标规则的稳定比较键后再参与差异对比。
			targetRelationInfo := entityRelationInfo{
				id:           target.Id,
				changeFrom:   target.ChangeFrom,
				copyFrom:     target.CopyFrom,
				snapshotFrom: target.SnapshotFrom,
			}
			compareMap["CrossGroupCarryForwardID"] = guaranteeCompareKey(targetRelationInfo, isChild, processInfo)
		} else {
			// 无目标统一使用字符串 0，保证该比较字段在两侧类型一致。
			compareMap["CrossGroupCarryForwardID"] = "0"
		}
		compareMap["GuaranteeCompareKey"] = compareKey
		compareMap["GuaranteeChainKey"] = entityChainKey(relationInfo, isChild, processInfo)
		compareList = append(compareList, compareMap)
	}
	return itemByCompareKey, compareList, nil
}

// guaranteeCompareKey 生成保底规则 diff 匹配 key，优先使用来源规则 ID。
func guaranteeCompareKey(relationInfo entityRelationInfo, isChild bool, processInfo *quoteDiffProcessInfo) string {
	if relationInfo.id == 0 {
		return ""
	}
	compareID := entityCompareID(relationInfo, isChild, processInfo)
	if compareID > 0 {
		return strconv.FormatInt(compareID, 10)
	}
	return fmt.Sprintf("new:%d", relationInfo.id)
}

// diffMatchedGuaranteeRules 对已匹配的保底规则计算字段变更和关联报价项变更。
func (s *DiffQuoteService) diffMatchedGuaranteeRules(
	ctx context.Context,
	tx *gorm.DB,
	childMap map[string]*model.GuaranteeItem,
	parentMap map[string]*model.GuaranteeItem,
	baseInfoDiffResult *CompareResult,
	processInfo *quoteDiffProcessInfo,
	diffQuoteItems *QuoteDiffCommonEntity,
) (map[string]*QuoteDiffGuaranteeRawItem, map[string]bool, error) {
	rawList := map[string]*QuoteDiffGuaranteeRawItem{}
	changedMap := map[string]bool{}
	for compareKey, childItem := range childMap {
		parentItem := parentMap[compareKey]
		if parentItem == nil {
			continue
		}
		resultKey := strconv.FormatInt(childItem.Id, 10)
		changedDetails := baseInfoDiffResult.ChangedDetails[resultKey]
		rawItem := &QuoteDiffGuaranteeRawItem{
			ID:             childItem.Id,
			ChangeFields:   sortedChangedFieldCodes(changedDetails),
			ChangedDetails: changedDetails,
		}
		srcItem, destItem := childItem, parentItem
		if !processInfo.childVSParent {
			srcItem, destItem = parentItem, childItem
		}
		quoteItemIDList, err := s.diffGuaranteeQuoteItemIDList(ctx, tx, srcItem, destItem, processInfo, diffQuoteItems)
		if err != nil {
			return nil, nil, err
		}
		rawItem.QuoteItemIDList = quoteItemIDList
		if len(rawItem.ChangeFields) == 0 && !hasCommonEntityDiff(rawItem.QuoteItemIDList) {
			continue
		}
		rawItem.ChangeType = constants.ChangeTypeChanged
		rawList[resultKey] = rawItem
		changedMap[resultKey] = true
	}
	return rawList, changedMap, nil
}

// sortedChangedFieldCodes 对变更字段 code 排序，保证 diff 结果稳定。
func sortedChangedFieldCodes(details map[string]ChangedFieldInfo) []string {
	if len(details) == 0 {
		return nil
	}
	ret := make([]string, 0, len(details))
	for code := range details {
		ret = append(ret, code)
	}
	sort.Strings(ret)
	return ret
}

// sortInterfaceList 使用格式化后的字符串排序接口列表，保证响应顺序稳定。
func sortInterfaceList(list []interface{}) {
	sort.Slice(list, func(i, j int) bool {
		return fmt.Sprintf("%+v", list[i]) < fmt.Sprintf("%+v", list[j])
	})
}

// fillGuaranteeChangeType 汇总保底新增、删除、变更列表并设置整体变更类型。
func fillGuaranteeChangeType(ret *QuoteDiffGuarantee) {
	if ret == nil {
		return
	}
	// 顶层 ChangeType 仅保留单保底兼容语义；多保底明细以 AddedList/DeletedList/ChangedList/RawList 为准。
	hasAdded := len(ret.AddedList) > 0
	hasDeleted := len(ret.DeletedList) > 0
	hasChanged := len(ret.ChangedList) > 0
	switch {
	case !hasAdded && !hasDeleted && !hasChanged:
		return
	case hasAdded && !hasDeleted && !hasChanged:
		ret.ChangeType = constants.ChangeTypeAdded
	case hasDeleted && !hasAdded && !hasChanged:
		ret.ChangeType = constants.ChangeTypeDeleted
	default:
		ret.ChangeType = constants.ChangeTypeChanged
	}
}

func normalizeGuaranteeBaseInfoDiffFields(fields []config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	ret := make([]config.DiffFieldInfoConf, 0, len(fields))
	exists := map[string]bool{}
	for _, field := range fields {
		if field.Code == "TotalSeats" {
			field.Code = "GuaranteeProductSeats"
			field.Name = "保底商品采购席位数"
			field.TrendCalcType = TrendCalcTypeNone
			field.ValuePath = nil
		}
		// 父子关系只影响树结构展示，不作为规则自身业务字段 diff。
		switch field.Code {
		case "RootGuaranteeID", "ParentGuaranteeID":
			continue
		}
		if exists[field.Code] {
			continue
		}
		exists[field.Code] = true
		ret = append(ret, field)
	}
	return ret
}

func buildGuaranteeCompareMap(guaranteeItem *model.GuaranteeItem) (map[string]interface{}, error) {
	if guaranteeItem == nil {
		return nil, nil
	}
	resp, err := guaranteeItem.GenResp()
	if err != nil {
		return nil, err
	}
	// 金额阶梯保持周期顺序，只规范化十进制文本，消除 1、1.0 等格式造成的伪差异。
	ladder := make([]string, 0, len(resp.GuaranteeAmountLadder))
	for _, value := range resp.GuaranteeAmountLadder {
		amount, err := model.ParseGuaranteeAmount(value)
		if err != nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底规则%d金额阶梯格式不合法").WithArgs(guaranteeItem.Id)
		}
		ladder = append(ladder, amount.String())
	}
	ret := Interface2Map(guaranteeItem)
	ret["AccountId"] = normalizeGuaranteeAccountID(guaranteeItem.AccountId)
	ret["GuaranteeAmount"] = guaranteeItem.GuaranteeAmount.String()
	ret["GuaranteeTotalAmount"] = guaranteeTotalAmountString(guaranteeItem.GuaranteeTotalAmount)
	ret["GuaranteeProductSeats"] = normalizeGuaranteeProductSeats(guaranteeItem.GetGuaranteeProductSeats())
	ret["GuaranteeAmountLadder"] = ladder
	return ret, nil
}

func guaranteeTotalAmountString(total *decimal.Decimal) string {
	if total == nil {
		return ""
	}
	return total.String()
}

func normalizeGuaranteeProductSeats(seats []model.GuaranteeProductSeat) []model.GuaranteeProductSeat {
	ret := make([]model.GuaranteeProductSeat, 0, len(seats))
	for _, seat := range seats {
		seat.TradeProduct = strings.TrimSpace(seat.TradeProduct)
		ret = append(ret, seat)
	}
	sort.Slice(ret, func(i, j int) bool {
		if ret[i].TradeProduct == ret[j].TradeProduct {
			return ret[i].Seats < ret[j].Seats
		}
		return ret[i].TradeProduct < ret[j].TradeProduct
	})
	return ret
}

func normalizeGuaranteeAccountID(accountID string) string {
	ids := strings.Split(accountID, ",")
	ret := make([]string, 0, len(ids))
	for _, id := range ids {
		id = strings.TrimSpace(id)
		if id != "" {
			ret = append(ret, id)
		}
	}
	sort.Strings(ret)
	return strings.Join(ret, ",")
}

func (s *DiffQuoteService) diffGuaranteeQuoteItemIDList(ctx context.Context, tx *gorm.DB, src, dest *model.GuaranteeItem, processInfo *quoteDiffProcessInfo, diffQuoteItems *QuoteDiffCommonEntity) (*QuoteDiffCommonEntity, error) {
	if diffQuoteItems == nil {
		return nil, nil
	}

	srcIDs := buildGuaranteeQuoteItemIDSet(src, diffQuoteItems.itemSrcList)
	destIDs := buildGuaranteeQuoteItemIDSet(dest, diffQuoteItems.itemDestList)
	srcList := filterQuoteItemMapsByID(diffQuoteItems.itemSrcList, srcIDs)
	destList := filterQuoteItemMapsByID(diffQuoteItems.itemDestList, destIDs)
	if len(srcList) == 0 && len(destList) == 0 {
		return nil, nil
	}

	result, err := Diff(ctx, &Context{
		Config: &Config{
			ListCompareSrcKeyBuilder:    buildKeyBuilder("ChargeItemCompareKey"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("ChargeItemCompareKey"),
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
			CompareFields:               []config.DiffFieldInfoConf{},
		},
		Src:  srcList,
		Dest: destList,
	})
	if err != nil {
		logs.CtxError(ctx, "[diffGuaranteeQuoteItemIDList]DiffFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单保底报价项信息对比失败")
	}
	if !processInfo.childVSParent {
		tmp := result.AddedList
		result.AddedList = result.DeletedList
		result.DeletedList = tmp
	}
	if len(result.AddedList) == 0 && len(result.DeletedList) == 0 {
		return nil, nil
	}
	if len(result.DeletedList) > 0 {
		result.DeletedList = filterDeletedRelatedQuoteItems(result.DeletedList, diffQuoteItems.DeletedList)
		result.DeletedList = buildCurrentQuoteItemIDListByOriginIDs(result.DeletedList, diffQuoteItems, processInfo.childVSParent)
	}
	if len(result.AddedList) == 0 && len(result.DeletedList) == 0 {
		return nil, nil
	}
	return &QuoteDiffCommonEntity{
		AddedList:   result.AddedList,
		DeletedList: result.DeletedList,
		SameList:    result.SameList,
	}, nil
}

func filterQuoteItemMapsByID(itemMaps []map[string]interface{}, quoteItemIDs []int64) []map[string]interface{} {
	quoteItemIDMap := map[string]bool{}
	for _, quoteItemID := range quoteItemIDs {
		quoteItemIDMap[strconv.FormatInt(quoteItemID, 10)] = true
	}
	ret := make([]map[string]interface{}, 0, len(quoteItemIDs))
	for _, itemMap := range itemMaps {
		idStr := fmt.Sprintf("%+v", itemMap["Id"])
		if quoteItemIDMap[idStr] {
			ret = append(ret, itemMap)
		}
	}
	return ret
}

func buildGuaranteeQuoteItemIDSet(guaranteeItem *model.GuaranteeItem, itemMaps []map[string]interface{}) []int64 {
	if guaranteeItem == nil || guaranteeItem.Id == 0 {
		return nil
	}
	guaranteeQuoteItemIDMap := map[int64]bool{}
	for _, quoteItemID := range guaranteeItem.GetRelatedQuoteItemId() {
		guaranteeQuoteItemIDMap[quoteItemID] = true
	}
	ids := make([]int64, 0, len(itemMaps))
	switch guaranteeItem.GuaranteeType {
	case multienv.GuaranteeTypePartial:
		for _, itemMap := range itemMaps {
			quoteItemID, ok := getInt64FromMap(itemMap, "Id")
			if ok && guaranteeQuoteItemIDMap[quoteItemID] && canJoinGuaranteeItemMap(itemMap) {
				ids = append(ids, quoteItemID)
			}
		}
	case multienv.GuaranteeTypeAll:
		for _, itemMap := range itemMaps {
			quoteItemID, ok := getInt64FromMap(itemMap, "Id")
			if ok && canJoinGuaranteeItemMap(itemMap) {
				ids = append(ids, quoteItemID)
			}
		}
	default:
		return nil
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	return ids
}

func canJoinGuaranteeItemMap(itemMap map[string]interface{}) bool {
	quoteSolutionID, ok := getInt64FromMap(itemMap, "QuoteSolutionID")
	if !ok || quoteSolutionID != 0 {
		return false
	}
	itemBusinessRole, ok := getInt64FromMap(itemMap, "ItemBusinessRole")
	if ok && itemBusinessRole == constants.QuoteItemBusinessRoleDeduct {
		return false
	}
	itemScene, ok := getInt64FromMap(itemMap, "ItemScene")
	if !ok || itemScene != constants.ItemSceneQuoteItem {
		return false
	}
	itemType, ok := getInt64FromMap(itemMap, "ItemType")
	return ok && itemType == int64(multienv.TradeProductTypeOnline)
}

func getInt64FromMap(itemMap map[string]interface{}, key string) (int64, bool) {
	if itemMap == nil {
		return 0, false
	}
	v, ok := itemMap[key]
	if !ok || v == nil {
		return 0, false
	}
	switch val := v.(type) {
	case int:
		return int64(val), true
	case int8:
		return int64(val), true
	case int16:
		return int64(val), true
	case int32:
		return int64(val), true
	case int64:
		return val, true
	case uint:
		return int64(val), true
	case uint8:
		return int64(val), true
	case uint16:
		return int64(val), true
	case uint32:
		return int64(val), true
	case uint64:
		if val > uint64(^uint64(0)>>1) {
			return 0, false
		}
		return int64(val), true
	case float64:
		return int64(val), true
	case string:
		parsed, err := strconv.ParseInt(val, 10, 64)
		return parsed, err == nil
	default:
		parsed, err := strconv.ParseInt(fmt.Sprintf("%+v", v), 10, 64)
		return parsed, err == nil
	}
}

func hasCommonEntityDiff(entity *QuoteDiffCommonEntity) bool {
	if entity == nil {
		return false
	}
	return len(entity.AddedList) > 0 || len(entity.DeletedList) > 0 || len(entity.ChangedList) > 0
}

func (s *DiffQuoteService) diffQuoteCredit(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteCredit) {
		return &QuoteDiffCommonEntity{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteCreditInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	diffResult, err := Diff(ctx, &Context{
		Config: &Config{
			ListCompareSrcKeyBuilder:    buildKeyBuilder("AccountID"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("AccountID"),
			ListCompareResultKeyBuilder: buildKeyBuilder("AccountID"),
		},
		Src:   Interface2Slice(srcQuoteInfo.CreditList),
		Dest:  Interface2Slice(destQuoteInfo.CreditList),
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteCreditFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单信控信息对比失败")
	}

	if !processInfo.childVSParent {
		tmp := diffResult.AddedList
		diffResult.AddedList = diffResult.DeletedList
		diffResult.DeletedList = tmp
	}

	return &QuoteDiffCommonEntity{
		AddedList:   diffResult.AddedList,
		DeletedList: diffResult.DeletedList,
	}, nil
}

func (s *DiffQuoteService) diffQuoteRebate(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {

	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeQuoteRebate) {
		return &QuoteDiffCommonEntity{}, nil
	}

	srcQuoteInfo, destQuoteInfo, err := processInfo.diffHandler.getDiffQuoteRebateInfo(ctx, tx)
	if err != nil {
		return nil, err
	}

	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.RebateDiffField)
	srcList := s.buildQuoteRebateMaps(ctx, srcQuoteInfo)
	destList := s.buildQuoteRebateMaps(ctx, destQuoteInfo)
	compareKeyBuilder := buildKeyBuilder("ChargeRebateCompareKey")

	diffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields:               compareFields,
			ListCompareSrcKeyBuilder:    compareKeyBuilder,
			ListCompareDestKeyBuilder:   compareKeyBuilder,
			ListCompareResultKeyBuilder: buildKeyBuilder("Id"),
		},
		Src:   srcList,
		Dest:  destList,
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteRebate, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单返佣信息对比失败")
	}

	if !processInfo.childVSParent {
		tmp := diffResult.AddedList
		diffResult.AddedList = diffResult.DeletedList
		diffResult.DeletedList = tmp
	}
	childQuoteInfo := getChildQuoteInfo(srcQuoteInfo, destQuoteInfo, processInfo.childVSParent)
	childList := s.buildQuoteRebateMaps(ctx, childQuoteInfo)
	diffResult.AddedList = filterUnwrittenAddedRebate(diffResult.AddedList, childList)

	return &QuoteDiffCommonEntity{
		AddedList:      diffResult.AddedList,
		DeletedList:    diffResult.DeletedList,
		ChangedList:    diffResult.ChangedList,
		ChangedDetails: diffResult.ChangedDetails,
		ChainKeyByID: buildChainKeyByID(
			srcList,
			destList,
			compareKeyBuilder,
			diffResult.AllList,
			diffResult.DeletedList,
		),
	}, nil
}

func (s *DiffQuoteService) diffQuoteJointPrintOrder(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffJointPrintOrder, error) {
	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeJointPrintOrder) {
		return &QuoteDiffJointPrintOrder{}, nil
	}

	// 根据 childVSParent 判断源和目标
	var srcQuote *model.Quote
	var destQuote *model.Quote
	if processInfo.childVSParent {
		srcQuote = processInfo.childQuoteDB
		destQuote = processInfo.parentQuoteDB
	} else {
		srcQuote = processInfo.parentQuoteDB
		destQuote = processInfo.childQuoteDB
	}

	// 解析源报价单和目标报价单的联合打单信息
	srcJointPrintOrder := srcQuote.ParseJointPrintOrder()
	destJointPrintOrder := destQuote.ParseJointPrintOrder()

	// 转换为 map 进行对比
	srcMap := Interface2Map(srcJointPrintOrder)
	destMap := Interface2Map(destJointPrintOrder)

	compareFields := processInfo.diffHandler.getDiffFieldConfig(processInfo.diffConf.JointPrintOrderDiffField)

	// 调用 Diff 进行对比
	result, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields: compareFields,
		},
		Src:   srcMap,
		Dest:  destMap,
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffQuoteJointPrintOrderFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单联合打单信息对比失败")
	}

	return &QuoteDiffJointPrintOrder{
		ChangeFields:  result.DiffFields,
		ChangedDetail: result.ChangedDetail,
	}, nil
}

func (s *DiffQuoteService) diffProfitCalInfo(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffProfitCal, error) {
	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeProfitCal) {
		return &QuoteDiffProfitCal{}, nil
	}
	// 单位目标成本利润率测算对比
	unitCostProfitCal, err := s.diffProfitCalInfoByType(ctx, tx, processInfo, constants.CalculateTypeUnitCost)
	if err != nil {
		return nil, err
	}
	// 出厂价利润率测算对比
	factoryPriceProfitCal, err := s.diffProfitCalInfoByType(ctx, tx, processInfo, constants.CalculateTypeExFactoryPrice)
	if err != nil {
		return nil, err
	}
	// 最新资源价利润率测算对比
	latestResourceProfitCal, err := s.diffProfitCalInfoByType(ctx, tx, processInfo, constants.CalculateTypeLatestResourcePrice)
	if err != nil {
		return nil, err
	}
	return &QuoteDiffProfitCal{
		UnitCostProfitCal:       unitCostProfitCal,
		FactoryPriceProfitCal:   factoryPriceProfitCal,
		LatestResourceProfitCal: latestResourceProfitCal,
	}, nil
}

func (s *DiffQuoteService) diffProfitCalInfoByType(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo, calculateType int) (*QuoteDiffCommonEntity, error) {

	srcItems, destItems, err := processInfo.diffHandler.getDiffProfitCalInfo(ctx, tx, calculateType, processInfo.diffConf.ProfitCalCompareKeys)
	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffProfitCalInfoByTypeFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单利润率测算对比失败")
	}
	diffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields:               []config.DiffFieldInfoConf{{Code: "DataValue"}},
			ListCompareSrcKeyBuilder:    buildKeyBuilder("DataKey"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("DataKey"),
			ListCompareResultKeyBuilder: buildKeyBuilder("DataKey"),
		},
		Src:   Interface2Slice(srcItems),
		Dest:  Interface2Slice(destItems),
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffProfitCalInfoByTypeFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单利润率测算汇总对比失败")
	}

	return &QuoteDiffCommonEntity{
		AddedList:      diffResult.AddedList,
		DeletedList:    diffResult.DeletedList,
		ChangedList:    diffResult.ChangedList,
		ChangedDetails: diffResult.ChangedDetails,
	}, nil
}

func (s *DiffQuoteService) diffProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB, processInfo *quoteDiffProcessInfo) (*QuoteDiffCommonEntity, error) {
	if !processInfo.diffHandler.needDiffInfo(multienv.InfoTypeProfitCal) {
		return &QuoteDiffCommonEntity{}, nil
	}
	srcItems, destItems, err := processInfo.diffHandler.getProductLineProfitCalInfo(ctx, tx)
	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffProfitCalInfoByTypeFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单利润率测算对比失败")
	}
	diffResult, err := Diff(ctx, &Context{
		Config: &Config{
			CompareFields: []config.DiffFieldInfoConf{
				{Code: "GrossProfitRate"},
				{Code: "FactoryPriceGrossProfitRate"},
				// 项目制变更展示需要覆盖资源价口径，避免仅最新资源价毛利率变化时 Diff 漏报。
				{Code: "LatestResourceGrossProfitRate"},
			},
			ListCompareSrcKeyBuilder:    buildKeyBuilder("ProductDepartmentName"),
			ListCompareDestKeyBuilder:   buildKeyBuilder("ProductDepartmentName"),
			ListCompareResultKeyBuilder: buildKeyBuilder("ProductDepartmentName"),
		},
		Src:   Interface2Slice(srcItems),
		Dest:  Interface2Slice(destItems),
		Scene: processInfo.scene,
	})

	if err != nil {
		argosnotifylogs.CtxError(ctx, "[GetQuoteDiffReq]diffProfitCalInfoByTypeFail, err=%s", err.Error())
		return nil, errors.ErrCustomerError.WithArgs("报价单利润率测算汇总对比失败")
	}

	return &QuoteDiffCommonEntity{
		AddedList:      diffResult.AddedList,
		DeletedList:    diffResult.DeletedList,
		ChangedList:    diffResult.ChangedList,
		ChangedDetails: diffResult.ChangedDetails,
	}, nil
}

func (s *DiffQuoteService) buildQuoteRebateMaps(ctx context.Context, info *assistant.CallbackInfo) []map[string]interface{} {

	itemCtx, _ := item_context.NewItemContextByQuoteItemValues(ctx, info.Quote, info.AllQuoteItems, info.AllItemValues)

	var result []map[string]interface{}

	for _, rebate := range info.RebateItemList {

		attrMap := Interface2Map(rebate)

		subCtx := itemCtx[rebate.QuoteItemID]
		if subCtx == nil {
			// 过滤不存在报价项上下文信息
			continue
		}

		attrMap["ChargeRebateCompareKey"] = subCtx.GetChargeItemCompareKey()

		result = append(result, attrMap)
	}

	return result
}

func filterUnwrittenAddedRebate(addedList []interface{}, childList []map[string]interface{}) []interface{} {
	if len(addedList) == 0 || len(childList) == 0 {
		return addedList
	}

	writtenByID := make(map[string]bool, len(childList))
	for _, rebate := range childList {
		id := fmt.Sprintf("%+v", rebate["Id"])
		if id == "" {
			continue
		}
		writtenByID[id] = isRebateWritten(rebate["IsRebateWritten"])
	}

	filtered := make([]interface{}, 0, len(addedList))
	for _, addedID := range addedList {
		if writtenByID[fmt.Sprintf("%+v", addedID)] {
			filtered = append(filtered, addedID)
		}
	}
	return filtered
}

func isRebateWritten(v interface{}) bool {
	dec, ok := interfaceToDecimal(v)
	return ok && dec.Equal(decimal.NewFromInt(1))
}

func (s *DiffQuoteService) checkQuoteCouponChange(couponItem *QuoteDiffCouponRawItem) bool {
	if len(couponItem.ChangeFields) > 0 {
		return true
	}
	if couponItem.ProductLimitList != nil {
		if len(couponItem.ProductLimitList.AddedList) > 0 {
			return true
		}
		if len(couponItem.ProductLimitList.DeletedList) > 0 {
			return true
		}
		if len(couponItem.ProductLimitList.ChangedList) > 0 {
			return true
		}
	}
	if couponItem.QuoteItemIDList != nil {
		if len(couponItem.QuoteItemIDList.AddedList) > 0 {
			return true
		}
		if len(couponItem.QuoteItemIDList.DeletedList) > 0 {
			return true
		}
		if len(couponItem.QuoteItemIDList.ChangedList) > 0 {
			return true
		}
	}
	if couponItem.StatQuoteItemIDList != nil {
		if len(couponItem.StatQuoteItemIDList.AddedList) > 0 {
			return true
		}
		if len(couponItem.StatQuoteItemIDList.DeletedList) > 0 {
			return true
		}
		if len(couponItem.StatQuoteItemIDList.ChangedList) > 0 {
			return true
		}
	}
	return false
}

func (s *DiffQuoteService) newEmptyResp() *QuoteDiffResult {
	return &QuoteDiffResult{
		BasicInfo: &QuoteDiffBasicInfo{
			ChangeFields:  []string{},
			ChangedDetail: map[string]ChangedFieldInfo{},
		},
		Items: &QuoteDiffCommonEntity{
			AddedList:      []interface{}{},
			DeletedList:    []interface{}{},
			ChangedList:    []interface{}{},
			ChangedDetails: map[string]map[string]ChangedFieldInfo{},
		},
		Coupon: &QuoteDiffCoupon{
			QuoteDiffCommonEntity: QuoteDiffCommonEntity{
				AddedList:   []interface{}{},
				DeletedList: []interface{}{},
				ChangedList: []interface{}{},
			},
			RawList: map[string]*QuoteDiffCouponRawItem{},
		},
		JointPrintOrder: &QuoteDiffJointPrintOrder{
			ChangeFields:  []string{},
			ChangedDetail: map[string]ChangedFieldInfo{},
		},
	}
}

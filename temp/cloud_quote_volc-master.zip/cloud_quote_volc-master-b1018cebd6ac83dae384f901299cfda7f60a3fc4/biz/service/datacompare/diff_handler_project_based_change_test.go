package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

// All comments and test scenario descriptions must be in english.
func Test_getQuoteProductLineProfitCompareItems_BitsUTGen(t *testing.T) {
	t.Run("Failure Scenario - GetProductLineProfitCalculate returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - GetProductLineProfitCalculate returns an error", t, func() {
			ctx := context.Background()
			var tx *gorm.DB
			quote := &model.Quote{}
			mockErr := errors.New("mock db error")

			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).Return(nil, mockErr).Build()

			items, err := getQuoteProductLineProfitCompareItems(ctx, tx, quote)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock db error")
			convey.So(items, convey.ShouldBeNil)
		})
	})

	t.Run("Success Scenario - ProfitCalculateData is nil", func(t *testing.T) {
		mockey.PatchConvey("Success Scenario - ProfitCalculateData is nil", t, func() {
			ctx := context.Background()
			var tx *gorm.DB
			quote := &model.Quote{}

			mockResult := &profit_calculator.ProductLineProfit{
				ProfitCalculateData: nil,
			}
			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).Return(mockResult, nil).Build()

			items, err := getQuoteProductLineProfitCompareItems(ctx, tx, quote)

			convey.So(err, convey.ShouldBeNil)
			// A nil slice is a valid representation of an empty slice.
			// The original `ShouldNotBeNil` assertion was incorrect for this case.
			convey.So(len(items), convey.ShouldEqual, 0)
		})
	})

	t.Run("Success Scenario - Full data structure", func(t *testing.T) {
		mockey.PatchConvey("Success Scenario - Full data structure", t, func() {
			ctx := context.Background()
			var tx *gorm.DB
			quote := &model.Quote{BaseDB: framework.BaseDB{Id: 1}}

			mockData := &profit_calculator.ProductLineProfit{
				QuoteID: 1,
				ProfitCalculateData: &profit_calculator.ProductLineCalculateData{
					ProductDepartmentName:         "Total",
					GrossProfitRate:               "10%",
					FactoryPriceGrossProfitRate:   "11%",
					LatestResourceGrossProfitRate: "12%",
					SubCalculateData: []*profit_calculator.ProductLineCalculateData{
						{
							ProductDepartmentName:         "DeptA",
							GrossProfitRate:               "20%",
							FactoryPriceGrossProfitRate:   "21%",
							LatestResourceGrossProfitRate: "22%",
							SubCalculateData: []*profit_calculator.ProductLineCalculateData{
								{
									ProductDepartmentName:         "SubDeptA1",
									GrossProfitRate:               "30%",
									FactoryPriceGrossProfitRate:   "31%",
									LatestResourceGrossProfitRate: "32%",
								},
							},
						},
						{
							ProductDepartmentName:         "DeptB",
							GrossProfitRate:               "40%",
							FactoryPriceGrossProfitRate:   "41%",
							LatestResourceGrossProfitRate: "42%",
							SubCalculateData:              nil, // Test case where inner sub-data is nil
						},
					},
				},
			}

			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).
				Return(mockData, nil).Build()

			items, err := getQuoteProductLineProfitCompareItems(ctx, tx, quote)

			convey.So(err, convey.ShouldBeNil)
			convey.So(items, convey.ShouldNotBeNil)
			convey.So(len(items), convey.ShouldEqual, 4)

			// Check the order and content
			convey.So(items[0].ProductDepartmentName, convey.ShouldEqual, "Total")
			convey.So(items[0].GrossProfitRate, convey.ShouldEqual, "10%")
			convey.So(items[0].LatestResourceGrossProfitRate, convey.ShouldEqual, "12%")

			convey.So(items[1].ProductDepartmentName, convey.ShouldEqual, "SubDeptA1")
			convey.So(items[1].GrossProfitRate, convey.ShouldEqual, "30%")
			convey.So(items[1].LatestResourceGrossProfitRate, convey.ShouldEqual, "32%")

			convey.So(items[2].ProductDepartmentName, convey.ShouldEqual, "DeptA")
			convey.So(items[2].GrossProfitRate, convey.ShouldEqual, "20%")
			convey.So(items[2].LatestResourceGrossProfitRate, convey.ShouldEqual, "22%")

			convey.So(items[3].ProductDepartmentName, convey.ShouldEqual, "DeptB")
			convey.So(items[3].GrossProfitRate, convey.ShouldEqual, "40%")
			convey.So(items[3].LatestResourceGrossProfitRate, convey.ShouldEqual, "42%")
		})
	})

	t.Run("Success Scenario - No sub-data", func(t *testing.T) {
		mockey.PatchConvey("Success Scenario - No sub-data", t, func() {
			ctx := context.Background()
			var tx *gorm.DB
			quote := &model.Quote{BaseDB: framework.BaseDB{Id: 2}}

			mockData := &profit_calculator.ProductLineProfit{
				QuoteID: 2,
				ProfitCalculateData: &profit_calculator.ProductLineCalculateData{
					ProductDepartmentName:         "Total Only",
					GrossProfitRate:               "5%",
					FactoryPriceGrossProfitRate:   "6%",
					LatestResourceGrossProfitRate: "7%",
					SubCalculateData:              []*profit_calculator.ProductLineCalculateData{},
				},
			}

			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).
				Return(mockData, nil).Build()

			items, err := getQuoteProductLineProfitCompareItems(ctx, tx, quote)

			convey.So(err, convey.ShouldBeNil)
			convey.So(items, convey.ShouldNotBeNil)
			convey.So(len(items), convey.ShouldEqual, 1)
			convey.So(items[0].ProductDepartmentName, convey.ShouldEqual, "Total Only")
			convey.So(items[0].GrossProfitRate, convey.ShouldEqual, "5%")
			convey.So(items[0].FactoryPriceGrossProfitRate, convey.ShouldEqual, "6%")
			convey.So(items[0].LatestResourceGrossProfitRate, convey.ShouldEqual, "7%")
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_ProjectBasedChangeDiffHandler_needDiffInfo_BitsUTGen(t *testing.T) {
	h := &ProjectBasedChangeDiffHandler{}

	t.Run("Successful Scenario - Should return true for required info types", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - Should return true for required info types", t, func() {
			requiredTypes := []multienv.QuoteInfoType{
				multienv.InfoTypeQuoteBaseInfo,
				multienv.InfoTypeQuoteItemContext,
				multienv.InfoTypeQuoteCoupon,
				multienv.InfoTypeQuoteGuarantee,
				multienv.InfoTypeQuoteCredit,
				multienv.InfoTypeQuoteRebate,
				multienv.InfoTypeProfitCal,
				multienv.InfoTypeJointPrintOrder,
			}

			for _, infoType := range requiredTypes {
				result := h.needDiffInfo(infoType)
				convey.So(result, convey.ShouldBeTrue)
			}
		})
	})

	t.Run("Failure Scenario - Should return false for an unrequired info type", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Should return false for an unrequired info type", t, func() {
			unrequiredType := multienv.QuoteInfoType(999)

			result := h.needDiffInfo(unrequiredType)

			convey.So(result, convey.ShouldBeFalse)
		})
	})

	t.Run("Failure Scenario - Should return false for zero value info type", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Should return false for zero value info type", t, func() {
			zeroType := multienv.QuoteInfoType(0)

			result := h.needDiffInfo(zeroType)

			convey.So(result, convey.ShouldBeFalse)
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_ProjectBasedChangeDiffHandler_getDiffQuoteCouponInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	handler := &ProjectBasedChangeDiffHandler{
		SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
		DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
	}
	srcCallbackInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}
	destCallbackInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}}}
	testAPIError := pkg_errors.ErrCustomerError.WithArgs("mocked error")

	t.Run("Successful scenario where both callbacks succeed", func(t *testing.T) {
		mockey.PatchConvey("Successful scenario where both callbacks succeed", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcCallbackInfo, nil).
					Then(destCallbackInfo, nil),
			).Build()

			gotSrcInfo, gotDestInfo, err := handler.getDiffQuoteCouponInfo(ctx, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(gotSrcInfo, convey.ShouldEqual, srcCallbackInfo)
			convey.So(gotDestInfo, convey.ShouldEqual, destCallbackInfo)
		})
	})

	t.Run("Failure Scenario - source callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - source callback returns an error", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, testAPIError).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			gotSrcInfo, gotDestInfo, err := handler.getDiffQuoteCouponInfo(ctx, nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询代金券信息失败")
			convey.So(gotSrcInfo, convey.ShouldBeNil)
			convey.So(gotDestInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - source callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - source callback returns nil info", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, nil).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			gotSrcInfo, gotDestInfo, err := handler.getDiffQuoteCouponInfo(ctx, nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询代金券信息失败")
			convey.So(gotSrcInfo, convey.ShouldBeNil)
			convey.So(gotDestInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - destination callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - destination callback returns an error", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcCallbackInfo, nil).
					Then(nil, testAPIError),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			gotSrcInfo, gotDestInfo, err := handler.getDiffQuoteCouponInfo(ctx, nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询代金券信息失败")
			convey.So(gotSrcInfo, convey.ShouldBeNil)
			convey.So(gotDestInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - destination callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - destination callback returns nil info", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcCallbackInfo, nil).
					Then(nil, nil),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			gotSrcInfo, gotDestInfo, err := handler.getDiffQuoteCouponInfo(ctx, (*gorm.DB)(nil))

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询代金券信息失败")
			convey.So(gotSrcInfo, convey.ShouldBeNil)
			convey.So(gotDestInfo, convey.ShouldBeNil)
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_getQuoteProfitCompareItems_BitsUTGen(t *testing.T) {
	t.Run("Success case - items found in header and footer", func(t *testing.T) {
		mockey.PatchConvey("Success case - items found in header and footer", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			quote := &model.Quote{}
			calculateType := constants.CalculateTypeUnitCost
			compareKeys := []string{"key1", "key3"}

			mockProfitData := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{
						{DataKey: "key1", ShowName: "Header Key 1"},
						{DataKey: "key2", ShowName: "Header Key 2"},
					},
					Footer: []*profit_calculator.CommonDataItem{
						{DataKey: "key3", ShowName: "Footer Key 3"},
						{DataKey: "key4", ShowName: "Footer Key 4"},
					},
				},
			}

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(mockProfitData, nil).Build()

			items, err := getQuoteProfitCompareItems(ctx, tx, quote, calculateType, compareKeys)

			convey.So(err, convey.ShouldBeNil)
			convey.So(items, convey.ShouldNotBeNil)
			convey.So(len(items), convey.ShouldEqual, 2)
			convey.So(items[0].DataKey, convey.ShouldEqual, "key1")
			convey.So(items[1].DataKey, convey.ShouldEqual, "key3")
		})
	})

	t.Run("Failure case - GetProfitCalculate returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure case - GetProfitCalculate returns an error", t, func() {
			ctx := context.Background()
			mockErr := errors.New("get profit calculate failed")

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(nil, mockErr).Build()

			items, err := getQuoteProfitCompareItems(ctx, &gorm.DB{}, &model.Quote{}, 0, []string{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
			convey.So(items, convey.ShouldBeNil)
		})
	})

	t.Run("Failure case - GetProfitCalculate returns incorrect data type", func(t *testing.T) {
		mockey.PatchConvey("Failure case - GetProfitCalculate returns incorrect data type", t, func() {
			ctx := context.Background()
			// Return a different type to cause the type assertion to fail.
			mockey.Mock(profit_calculator.GetProfitCalculate).Return(&struct{}{}, nil).Build()

			expectedErr := pkg_errors.ErrInternalError.WithArgs("利润率汇算数据错误")

			items, err := getQuoteProfitCompareItems(ctx, &gorm.DB{}, &model.Quote{}, 0, []string{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			convey.So(items, convey.ShouldBeNil)
		})
	})

	t.Run("Edge case - no matching keys", func(t *testing.T) {
		mockey.PatchConvey("Edge case - no matching keys", t, func() {
			ctx := context.Background()
			compareKeys := []string{"non_existent_key1", "non_existent_key2"}

			mockProfitData := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{
						{DataKey: "key1"},
					},
					Footer: []*profit_calculator.CommonDataItem{
						{DataKey: "key3"},
					},
				},
			}

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(mockProfitData, nil).Build()

			items, err := getQuoteProfitCompareItems(ctx, &gorm.DB{}, &model.Quote{}, 0, compareKeys)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(items), convey.ShouldEqual, 0)
		})
	})

	t.Run("Edge case - empty compareKeys", func(t *testing.T) {
		mockey.PatchConvey("Edge case - empty compareKeys", t, func() {
			ctx := context.Background()
			var compareKeys []string // empty slice

			mockProfitData := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{
						{DataKey: "key1"},
					},
					Footer: []*profit_calculator.CommonDataItem{
						{DataKey: "key3"},
					},
				},
			}

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(mockProfitData, nil).Build()

			items, err := getQuoteProfitCompareItems(ctx, &gorm.DB{}, &model.Quote{}, 0, compareKeys)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(items), convey.ShouldEqual, 0)
		})
	})

	t.Run("Edge case - empty profit data header and footer", func(t *testing.T) {
		mockey.PatchConvey("Edge case - empty profit data header and footer", t, func() {
			ctx := context.Background()
			compareKeys := []string{"key1", "key3"}

			mockProfitData := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{}, // Empty header
					Footer: nil,                                   // Nil footer
				},
			}

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(mockProfitData, nil).Build()

			items, err := getQuoteProfitCompareItems(ctx, &gorm.DB{}, &model.Quote{}, 0, compareKeys)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(items), convey.ShouldEqual, 0)
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_ProjectBasedChangeDiffHandler_getProductLineProfitCalInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	var tx *gorm.DB

	t.Run("should return profit info when all calls succeed", func(t *testing.T) {
		mockey.PatchConvey("should return profit info when all calls succeed", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}

			srcProfit := &profit_calculator.ProductLineProfit{
				ProfitCalculateData: &profit_calculator.ProductLineCalculateData{
					ProductDepartmentName:       "TotalSrc",
					GrossProfitRate:             "10%",
					FactoryPriceGrossProfitRate: "12%",
					SubCalculateData: []*profit_calculator.ProductLineCalculateData{
						{
							ProductDepartmentName:       "SubSrc1",
							GrossProfitRate:             "11%",
							FactoryPriceGrossProfitRate: "13%",
							SubCalculateData: []*profit_calculator.ProductLineCalculateData{
								{
									ProductDepartmentName:       "SubSubSrc1",
									GrossProfitRate:             "11.1%",
									FactoryPriceGrossProfitRate: "13.1%",
								},
							},
						},
					},
				},
			}
			destProfit := &profit_calculator.ProductLineProfit{
				ProfitCalculateData: &profit_calculator.ProductLineCalculateData{
					ProductDepartmentName:       "TotalDest",
					GrossProfitRate:             "20%",
					FactoryPriceGrossProfitRate: "22%",
				},
			}

			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ int) bool {
					return q.Id == 1
				}).Return(srcProfit, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ int) bool {
					return q.Id == 2
				}).Return(destProfit, nil).
				Build()

			srcItems, destItems, err := h.getProductLineProfitCalInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(srcItems), convey.ShouldEqual, 3)
			convey.So(srcItems[0].ProductDepartmentName, convey.ShouldEqual, "TotalSrc")
			convey.So(srcItems[1].ProductDepartmentName, convey.ShouldEqual, "SubSubSrc1")
			convey.So(srcItems[2].ProductDepartmentName, convey.ShouldEqual, "SubSrc1")
			convey.So(len(destItems), convey.ShouldEqual, 1)
			convey.So(destItems[0].ProductDepartmentName, convey.ShouldEqual, "TotalDest")
		})
	})

	t.Run("should return error when getDiffQuoteBaseInfo fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when getDiffQuoteBaseInfo fails", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			expectedErr := errors.New("getDiffQuoteBaseInfo error")
			mockey.Mock((*ProjectBasedChangeDiffHandler).getDiffQuoteBaseInfo).Return(nil, nil, expectedErr).Build()

			srcItems, destItems, err := h.getProductLineProfitCalInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			convey.So(srcItems, convey.ShouldBeNil)
			convey.So(destItems, convey.ShouldBeNil)
		})
	})

	t.Run("should return error when getting src profit info fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when getting src profit info fails", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			expectedErr := errors.New("src profit calculation error")
			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ int) bool {
					return q.Id == 1
				}).Return(nil, expectedErr).
				Build()

			srcItems, destItems, err := h.getProductLineProfitCalInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			convey.So(srcItems, convey.ShouldBeNil)
			convey.So(destItems, convey.ShouldBeNil)
		})
	})

	t.Run("should return error when getting dest profit info fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when getting dest profit info fails", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			srcProfit := &profit_calculator.ProductLineProfit{
				ProfitCalculateData: &profit_calculator.ProductLineCalculateData{
					ProductDepartmentName: "TotalSrc",
				},
			}
			expectedErr := errors.New("dest profit calculation error")
			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ int) bool {
					return q.Id == 1
				}).Return(srcProfit, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ int) bool {
					return q.Id == 2
				}).Return(nil, expectedErr).
				Build()

			srcItems, destItems, err := h.getProductLineProfitCalInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			convey.So(srcItems, convey.ShouldBeNil)
			convey.So(destItems, convey.ShouldBeNil)
		})
	})

	t.Run("should return empty slices when profit data is nil", func(t *testing.T) {
		mockey.PatchConvey("should return empty slices when profit data is nil", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}

			// Mock GetProductLineProfitCalculate to return a profit object with nil data field
			mockey.Mock(profit_calculator.GetProductLineProfitCalculate).Return(&profit_calculator.ProductLineProfit{
				ProfitCalculateData: nil,
			}, nil).Build()

			srcItems, destItems, err := h.getProductLineProfitCalInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcItems, convey.ShouldBeEmpty)
			convey.So(destItems, convey.ShouldBeEmpty)
		})
	})
}

// Test_ProjectBasedChangeDiffHandler_getDiffProfitCalInfo tests the getDiffProfitCalInfo method.
func Test_ProjectBasedChangeDiffHandler_getDiffProfitCalInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	tx := &gorm.DB{}
	calculateType := constants.CalculateTypeUnitCost
	compareKeys := []string{"key1", "key3"}
	h := &ProjectBasedChangeDiffHandler{
		SrcQuoteDB:  &model.Quote{ProjectBased: 1},
		DestQuoteDB: &model.Quote{ProjectBased: 1},
	}

	t.Run("Successful scenario - retrieve profit info for both quotes", func(t *testing.T) {
		mockey.PatchConvey("Successful scenario - retrieve profit info for both quotes", t, func() {
			mockSrcProfit := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{
						{DataKey: "key1", ShowName: "Key 1"},
						{DataKey: "key2", ShowName: "Key 2"},
					},
					Footer: []*profit_calculator.CommonDataItem{
						{DataKey: "key3", ShowName: "Key 3"},
					},
				},
			}
			mockDestProfit := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{
					Header: []*profit_calculator.CommonDataItem{
						{DataKey: "keyA", ShowName: "Key A"},
						{DataKey: "key1", ShowName: "Key 1"},
					},
					Footer: []*profit_calculator.CommonDataItem{
						{DataKey: "keyB", ShowName: "Key B"},
					},
				},
			}

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(
				mockey.Sequence(mockSrcProfit, nil).Then(mockDestProfit, nil),
			).Build()

			srcDataItems, descDataItems, err := h.getDiffProfitCalInfo(ctx, tx, calculateType, compareKeys)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcDataItems, convey.ShouldNotBeNil)
			convey.So(descDataItems, convey.ShouldNotBeNil)
			convey.So(len(srcDataItems), convey.ShouldEqual, 2)
			convey.So(srcDataItems[0].DataKey, convey.ShouldEqual, "key1")
			convey.So(srcDataItems[1].DataKey, convey.ShouldEqual, "key3")
			convey.So(len(descDataItems), convey.ShouldEqual, 1)
			convey.So(descDataItems[0].DataKey, convey.ShouldEqual, "key1")
		})
	})

	t.Run("Failure scenario - getDiffQuoteBaseInfo fails", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - getDiffQuoteBaseInfo fails", t, func() {
			expectedErr := errors.New("get base info error")
			mockey.Mock((*ProjectBasedChangeDiffHandler).getDiffQuoteBaseInfo).Return(nil, nil, expectedErr).Build()

			srcDataItems, descDataItems, err := h.getDiffProfitCalInfo(ctx, tx, calculateType, compareKeys)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(srcDataItems, convey.ShouldBeNil)
			convey.So(descDataItems, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - GetProfitCalculate for source quote fails", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - GetProfitCalculate for source quote fails", t, func() {
			expectedErr := errors.New("profit calculation error")
			mockey.Mock(profit_calculator.GetProfitCalculate).Return(nil, expectedErr).Build()

			srcDataItems, descDataItems, err := h.getDiffProfitCalInfo(ctx, tx, calculateType, compareKeys)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "profit calculation error")
			convey.So(srcDataItems, convey.ShouldBeNil)
			convey.So(descDataItems, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - GetProfitCalculate for destination quote fails", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - GetProfitCalculate for destination quote fails", t, func() {
			mockSrcProfit := &profit_calculator.ProjectBasedProfit{
				ProfitCalculateData: &profit_calculator.ProjectBasedProfitData{},
			}
			expectedErr := errors.New("dest profit error")

			mockey.Mock(profit_calculator.GetProfitCalculate).Return(
				mockey.Sequence(mockSrcProfit, nil).Then(nil, expectedErr),
			).Build()

			srcDataItems, descDataItems, err := h.getDiffProfitCalInfo(ctx, tx, calculateType, compareKeys)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "dest profit error")
			convey.So(srcDataItems, convey.ShouldBeNil)
			convey.So(descDataItems, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - Type assertion for profit data fails", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - Type assertion for profit data fails", t, func() {
			mockey.Mock(profit_calculator.GetProfitCalculate).Return(new(struct{}), nil).Build()

			srcDataItems, descDataItems, err := h.getDiffProfitCalInfo(ctx, tx, calculateType, compareKeys)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldHaveSameTypeAs, pkg_errors.ErrInternalError)
			convey.So(err.Error(), convey.ShouldContainSubstring, "利润率汇算数据错误")
			convey.So(srcDataItems, convey.ShouldBeNil)
			convey.So(descDataItems, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedChangeDiffHandler_getDiffQuoteGuaranteeInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	var tx *gorm.DB

	handler := &ProjectBasedChangeDiffHandler{
		SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
		DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
	}
	mockSrcInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}
	mockDestInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}}}
	mockAPIErr := pkg_errors.ErrInternalError.WithArgs(errors.New("mock api error"))

	t.Run("Successful scenario when both callbacks return valid info", func(t *testing.T) {
		mockey.PatchConvey("Successful scenario when both callbacks return valid info", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.SrcQuoteDB.Id
				}).
				Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.DestQuoteDB.Id
				}).
				Return(mockDestInfo, nil).
				Build()

			srcInfo, destInfo, err := handler.getDiffQuoteGuaranteeInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcInfo, convey.ShouldEqual, mockSrcInfo)
			convey.So(destInfo, convey.ShouldEqual, mockDestInfo)
		})
	})

	t.Run("Failure scenario when source callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when source callback returns an error", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.SrcQuoteDB.Id
				}).
				Return(nil, mockAPIErr).
				Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := handler.getDiffQuoteGuaranteeInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when source callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when source callback returns nil info", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.SrcQuoteDB.Id
				}).
				Return(nil, nil).
				Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := handler.getDiffQuoteGuaranteeInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when destination callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when destination callback returns an error", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.SrcQuoteDB.Id
				}).
				Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.DestQuoteDB.Id
				}).
				Return(nil, mockAPIErr).
				Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := handler.getDiffQuoteGuaranteeInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when destination callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when destination callback returns nil info", t, func() {
			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.SrcQuoteDB.Id
				}).
				Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == handler.DestQuoteDB.Id
				}).
				Return(nil, nil).
				Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := handler.getDiffQuoteGuaranteeInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedChangeDiffHandler_getDiffQuoteItemInfo_BitsUTGen(t *testing.T) {
	t.Run("Success scenario with isChildVSParent as true", func(t *testing.T) {
		mockey.PatchConvey("Success scenario with isChildVSParent as true", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				isChildVSParent: true,
			}
			ctx := context.Background()
			var tx *gorm.DB

			childInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}
			parentInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}}}

			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == 1
				}).Return(childInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == 2
				}).Return(parentInfo, nil).
				Build()

			srcCallbackInfo, destCallbackInfo, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcCallbackInfo, convey.ShouldEqual, childInfo)
			convey.So(destCallbackInfo, convey.ShouldEqual, parentInfo)
		})
	})

	t.Run("Success scenario with isChildVSParent as false", func(t *testing.T) {
		mockey.PatchConvey("Success scenario with isChildVSParent as false", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}}, // Parent
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}}, // Child
				isChildVSParent: false,
			}
			ctx := context.Background()
			var tx *gorm.DB

			childInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}}}
			parentInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}

			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == 2 // Child is called first
				}).Return(childInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == 1 // Parent is called second
				}).Return(parentInfo, nil).
				Build()

			srcCallbackInfo, destCallbackInfo, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcCallbackInfo, convey.ShouldEqual, parentInfo)
			convey.So(destCallbackInfo, convey.ShouldEqual, childInfo)
		})
	})

	t.Run("Failure scenario when child info callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when child info callback returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				isChildVSParent: true,
			}
			ctx := context.Background()
			var tx *gorm.DB
			mockErr := pkg_errors.ErrInternalError.WithArgs(errors.New("db error"))

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, mockErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			src, dest, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价项信息失败")
			convey.So(src, convey.ShouldBeNil)
			convey.So(dest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when child info callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when child info callback returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				isChildVSParent: true,
			}
			ctx := context.Background()
			var tx *gorm.DB

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, nil).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			src, dest, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价项信息失败")
			convey.So(src, convey.ShouldBeNil)
			convey.So(dest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when parent info callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when parent info callback returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				isChildVSParent: true,
			}
			ctx := context.Background()
			var tx *gorm.DB
			childInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}
			mockErr := pkg_errors.ErrInternalError.WithArgs(errors.New("db error"))

			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(childInfo, nil).
					Then(nil, mockErr),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			src, dest, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价项信息失败")
			convey.So(src, convey.ShouldBeNil)
			convey.So(dest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario when parent info callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario when parent info callback returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:      &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB:     &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				isChildVSParent: true,
			}
			ctx := context.Background()
			var tx *gorm.DB
			childInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 1}}}

			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(childInfo, nil).
					Then(nil, nil),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			src, dest, err := h.getDiffQuoteItemInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价项信息失败")
			convey.So(src, convey.ShouldBeNil)
			convey.So(dest, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedChangeDiffHandler_getDiffQuoteRebateInfo_BitsUTGen(t *testing.T) {
	t.Run("Success scenario - both callbacks return valid info", func(t *testing.T) {
		mockey.PatchConvey("Success scenario - both callbacks return valid info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			ctx := context.Background()
			var tx *gorm.DB

			mockSrcInfo := &assistant.CallbackInfo{Quote: h.SrcQuoteDB}
			mockDestInfo := &assistant.CallbackInfo{Quote: h.DestQuoteDB}

			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.SrcQuoteDB.Id
				}).Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.DestQuoteDB.Id
				}).Return(mockDestInfo, nil).Build()

			srcInfo, destInfo, err := h.getDiffQuoteRebateInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcInfo, convey.ShouldEqual, mockSrcInfo)
			convey.So(destInfo, convey.ShouldEqual, mockDestInfo)
		})
	})

	t.Run("Failure scenario - callback for src quote returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - callback for src quote returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			ctx := context.Background()
			var tx *gorm.DB
			mockApiErr := pkg_errors.ErrInternalError.WithArgs("mock src error")

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, mockApiErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := h.getDiffQuoteRebateInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - callback for src quote returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - callback for src quote returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			ctx := context.Background()
			var tx *gorm.DB

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, nil).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := h.getDiffQuoteRebateInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - callback for dest quote returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - callback for dest quote returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			ctx := context.Background()
			var tx *gorm.DB
			mockSrcInfo := &assistant.CallbackInfo{Quote: h.SrcQuoteDB}
			mockApiErr := pkg_errors.ErrInternalError.WithArgs("mock dest error")

			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.SrcQuoteDB.Id
				}).Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.DestQuoteDB.Id
				}).Return(nil, mockApiErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := h.getDiffQuoteRebateInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})

	t.Run("Failure scenario - callback for dest quote returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - callback for dest quote returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			ctx := context.Background()
			var tx *gorm.DB
			mockSrcInfo := &assistant.CallbackInfo{Quote: h.SrcQuoteDB}

			mockey.Mock(assistant.CallbackWithQuote).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.SrcQuoteDB.Id
				}).Return(mockSrcInfo, nil).
				When(func(_ context.Context, _ *gorm.DB, q *model.Quote, _ ...assistant.CallbackOption) bool {
					return q.Id == h.DestQuoteDB.Id
				}).Return(nil, nil).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcInfo, destInfo, err := h.getDiffQuoteRebateInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcInfo, convey.ShouldBeNil)
			convey.So(destInfo, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedChangeDiffHandler_getDiffQuoteCreditInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	var tx *gorm.DB

	t.Run("Successful Scenario - Both callbacks return valid info", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - Both callbacks return valid info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			srcInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 101}}}
			destInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 102}}}

			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).Then(destInfo, nil),
			).Build()

			resultSrc, resultDest, err := h.getDiffQuoteCreditInfo(ctx, tx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resultSrc, convey.ShouldEqual, srcInfo)
			convey.So(resultDest, convey.ShouldEqual, destInfo)
		})
	})

	t.Run("Failure Scenario - Source quote callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Source quote callback returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			mockErr := pkg_errors.ErrInternalError.WithArgs("mock assistant error")

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, mockErr).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			resultSrc, resultDest, err := h.getDiffQuoteCreditInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询信控信息失败")
			convey.So(resultSrc, convey.ShouldBeNil)
			convey.So(resultDest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - Source quote callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Source quote callback returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}

			mockey.Mock(assistant.CallbackWithQuote).Return(nil, nil).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			resultSrc, resultDest, err := h.getDiffQuoteCreditInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询信控信息失败")
			convey.So(resultSrc, convey.ShouldBeNil)
			convey.So(resultDest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - Destination quote callback returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Destination quote callback returns an error", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			srcInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 101}}}
			mockErr := pkg_errors.ErrInternalError.WithArgs("mock assistant error")

			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).Then(nil, mockErr),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			resultSrc, resultDest, err := h.getDiffQuoteCreditInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询信控信息失败")
			convey.So(resultSrc, convey.ShouldBeNil)
			convey.So(resultDest, convey.ShouldBeNil)
		})
	})

	t.Run("Failure Scenario - Destination quote callback returns nil info", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Destination quote callback returns nil info", t, func() {
			h := &ProjectBasedChangeDiffHandler{
				SrcQuoteDB:  &model.Quote{BaseDB: framework.BaseDB{Id: 1}},
				DestQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
			}
			srcInfo := &assistant.CallbackInfo{Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 101}}}

			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).Then(nil, nil),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			resultSrc, resultDest, err := h.getDiffQuoteCreditInfo(ctx, tx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询信控信息失败")
			convey.So(resultSrc, convey.ShouldBeNil)
			convey.So(resultDest, convey.ShouldBeNil)
		})
	})
}

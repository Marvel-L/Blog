package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// PublicSupplyDiffHandler   公有云补充协议 Diff处理器
type PublicSupplyDiffHandler struct {
	SrcQuoteDB      *model.Quote
	DestQuoteDB     *model.Quote
	isChildVSParent bool
}

func (h *PublicSupplyDiffHandler) getSupplySceneType() string {
	return multienv.PublicSupplyAgreement
}

func (h *PublicSupplyDiffHandler) validateQuote(ctx context.Context, tx *gorm.DB) error {
	return nil
}

func (h *PublicSupplyDiffHandler) needDiffInfo(infoType multienv.QuoteInfoType) bool {
	if infoType == multienv.InfoTypeQuoteBaseInfo {
		return true
	}
	if infoType == multienv.InfoTypeQuoteItemContext {
		return true
	}
	if infoType == multienv.InfoTypeQuoteCoupon {
		return true
	}
	if infoType == multienv.InfoTypeQuoteRebate {
		return true
	}
	if infoType == multienv.InfoTypeJointPrintOrder {
		return true
	}
	if infoType == multienv.InfoTypeQuoteGuarantee {
		return true
	}
	return false
}

func (h *PublicSupplyDiffHandler) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return getDiffFieldConfigBySceneType(diffFieldMap, h.getSupplySceneType())
}

func (h *PublicSupplyDiffHandler) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,       // 报价项
				assistant.CallbackKeyDeliveryItems,    // 交付项
				assistant.CallbackKeyItemValues,       // 报价项条目
				assistant.CallbackKeyQuote,            // 报价单
				assistant.CallbackKeyItemCalculates,   // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems, // 代金券信息
				assistant.CallbackKeyItemCouponRatio,  // 报价项返券比例
				assistant.CallbackKeyRebate,           // 返佣记录
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteItemInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,       // 报价项
				assistant.CallbackKeyDeliveryItems,    // 交付项
				assistant.CallbackKeyItemValues,       // 报价项条目
				assistant.CallbackKeyQuote,            // 报价单
				assistant.CallbackKeyItemCalculates,   // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems, // 代金券信息
				assistant.CallbackKeyItemCouponRatio,  // 报价项返券比例
				assistant.CallbackKeyRebate,           // 返佣记录
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteItemInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteCouponInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteCouponInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)
	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteGuaranteeInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)
	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteGuaranteeInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteRebateInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[PublicSupplyDiffHandler]getDiffQuoteRebateInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *PublicSupplyDiffHandler) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
}
func (h *PublicSupplyDiffHandler) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *PublicSupplyDiffHandler) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	return nil, nil, errors.ErrCustomerError.WithArgs("not support")
}

func (h *PublicSupplyDiffHandler) isChangeScene() bool {
	return false
}

package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func Test_PublicChangeQuoteDiffHandler_getSupplySceneType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			supplySceneType := diffHandler.getSupplySceneType()

			// Assert
			convey.So(supplySceneType, convey.ShouldNotBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_validateQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			err := diffHandler.validateQuote(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_needDiffInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			result1 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteBaseInfo)
			result2 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteItemContext)
			result3 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteCoupon)
			result4 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteGuarantee)
			result5 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteCredit)
			result6 := diffHandler.needDiffInfo(multienv.InfoTypeQuoteRebate)
			result7 := diffHandler.needDiffInfo(multienv.InfoTypeJointPrintOrder)
			result666 := diffHandler.needDiffInfo(666)

			// Assert
			convey.So(result1, convey.ShouldBeTrue)
			convey.So(result2, convey.ShouldBeTrue)
			convey.So(result3, convey.ShouldBeTrue)
			convey.So(result4, convey.ShouldBeTrue)
			convey.So(result5, convey.ShouldBeTrue)
			convey.So(result6, convey.ShouldBeTrue)
			convey.So(result7, convey.ShouldBeTrue)
			convey.So(result666, convey.ShouldBeFalse)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_getDiffFieldConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			fieldConfig := diffHandler.getDiffFieldConfig(nil)

			// Assert
			convey.So(fieldConfig, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_getDiffQuoteBaseInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteBaseInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_getDiffQuoteItemInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteItemInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_getDiffQuoteCouponInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCouponInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_getDiffQuoteGuaranteeInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func Test_PublicChangeQuoteDiffHandler_getDiffQuoteCreditInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCreditInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func Test_PublicChangeQuoteDiffHandler_getDiffQuoteRebateInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("source callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getPublicChangeQuoteDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})

	t.Run("destination callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getPublicChangeQuoteDiffHandler()
			srcInfo := &assistant.CallbackInfo{Quote: diffHandler.SrcQuoteDB}
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).
					Then(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})
}

func Test_PublicChangeQuoteDiffHandler_diffQuoteItemsResultPostProcessing(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getPublicChangeQuoteDiffHandler()

			// Act
			diffHandler.diffQuoteItemsResultPostProcessing(nil, nil)

			// Assert
		})
	})
}

func getPublicChangeQuoteDiffHandler() *PublicChangeQuoteDiffHandler {
	return &PublicChangeQuoteDiffHandler{
		SrcQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 1,
			},
			OriginQuoteID: 0,
		},
		DestQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 2,
			},
			OriginQuoteID: 1,
		},
		isChildVSParent: false,
	}
}

package datacompare

import (
	"context"
	"encoding/json"
	"strconv"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/process_data/data_parse"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/gopkg/logs"
)

// getDiffSnapshotByQuoteIDs 根据报价单 ID 归一化父子关系后读取快照。
func (s *DiffQuoteService) getDiffSnapshotByQuoteIDs(ctx context.Context, tx *gorm.DB, quoteID int64, compareWith int64) (*QuoteDiffResult, bool) {
	if tx == nil {
		tx = dal.DBProxy.NewRequest(ctx)
	}
	srcQuoteDB, destQuoteDB, err := s.validateParam(tx, quoteID, compareWith)
	if err != nil {
		logs.CtxError(ctx, "[DiffQuoteService.getDiffSnapshotByQuoteIDs] validate param fail, quoteID=%d, compareWith=%d, err=%s",
			quoteID, compareWith, err.Error())
		return nil, false
	}
	if !s.isRelatedQuote(srcQuoteDB, destQuoteDB) {
		return nil, false
	}
	childVSParent := isChildVSParent(srcQuoteDB, destQuoteDB)
	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(srcQuoteDB, destQuoteDB, childVSParent)
	return s.getDiffSnapshot(ctx, tx, childQuoteDB, parentQuoteDB)
}

// SaveApprovalPassedDiffSnapshots 在审批通过事务内计算并保存全部最终差异。
func SaveApprovalPassedDiffSnapshots(ctx context.Context, tx *gorm.DB, quote *model.Quote) error {
	if quote == nil || quote.Id <= 0 {
		logs.CtxError(ctx, "[SaveApprovalPassedDiffSnapshots] invalid quote")
		return errors.NewBizErrWithMsg(errors.HistoryInternalErrCode, "保存审批通过 Diff 快照失败：报价单为空或 ID 非法")
	}

	// 关联报价单字段非零时分别固化 Diff，不依赖报价场景组合关系。
	service := NewDiffQuoteService()
	// 变更场景Diff 快照
	if quote.OriginQuoteID != 0 {
		if err := service.saveDiffSnapshot(ctx, tx, quote.Id, quote.OriginQuoteID); err != nil {
			return err
		}
	}
	// 补充场景Diff 快照
	if quote.ParentQuoteID != 0 {
		if err := service.saveDiffSnapshot(ctx, tx, quote.Id, quote.ParentQuoteID); err != nil {
			return err
		}
	}
	if quote.OriginSnapshotID != 0 {
		// 审批中修改Diff 快照
		if err := service.saveDiffSnapshot(ctx, tx, quote.Id, quote.OriginSnapshotID); err != nil {
			return err
		}
		// 审批中修改需补充修改前快照到业务基线的 Diff，形成完整三段对比。
		if quote.OriginQuoteID != 0 {
			if err := service.saveDiffSnapshot(ctx, tx, quote.OriginSnapshotID, quote.OriginQuoteID); err != nil {
				return err
			}
		}
		if quote.ParentQuoteID != 0 {
			if err := service.saveDiffSnapshot(ctx, tx, quote.OriginSnapshotID, quote.ParentQuoteID); err != nil {
				return err
			}
		}
	}
	return nil
}

// saveDiffSnapshot 强制实时计算 Diff 并持久化，避免审批通过时读取已有快照。
func (s *DiffQuoteService) saveDiffSnapshot(ctx context.Context, tx *gorm.DB, quoteID int64, compareQuoteID int64) error {
	diff, diffErr := s.diffQuote(ctx, tx, quoteID, compareQuoteID)
	if diffErr != nil {
		logs.CtxError(ctx, "[DiffQuoteService.saveDiffSnapshot] calculate snapshot fail, quoteID=%d, compareQuoteID=%d, err=%s",
			quoteID, compareQuoteID, diffErr.Error())
		return diffErr
	}
	detail, marshalErr := json.Marshal(diff)
	if marshalErr != nil {
		logs.CtxError(ctx, "[DiffQuoteService.saveDiffSnapshot] marshal snapshot fail, quoteID=%d, compareQuoteID=%d, err=%s",
			quoteID, compareQuoteID, marshalErr.Error())
		return marshalErr
	}
	processData := &model.QuoteProcessData{
		QuoteID:         quoteID,
		BizScene:        data_parse.BizSceneQuoteDiffSnapshot,
		BizCode:         strconv.FormatInt(compareQuoteID, 10),
		CalculateDetail: string(detail),
	}
	if saveErr := dal.QuoteProcessDataDao.Save(tx, processData, &model.QuoteProcessData{}); saveErr != nil {
		logs.CtxError(ctx, "[DiffQuoteService.saveDiffSnapshot] save snapshot fail, quoteID=%d, compareQuoteID=%d, err=%s",
			quoteID, compareQuoteID, saveErr.Error())
		return saveErr
	}
	logs.CtxInfo(ctx, "[DiffQuoteService.saveDiffSnapshot] save snapshot success, quoteID=%d, compareQuoteID=%d",
		quoteID, compareQuoteID)
	return nil
}

// getDiffSnapshot 使用归一化后的子报价单和父报价单查询快照；读取异常按未命中处理，由调用方实时计算。
func (s *DiffQuoteService) getDiffSnapshot(ctx context.Context, tx *gorm.DB, childQuoteDB *model.Quote,
	parentQuoteDB *model.Quote) (*QuoteDiffResult, bool) {
	if childQuoteDB == nil || parentQuoteDB == nil {
		return nil, false
	}
	if _, ok := constants.CanReadDiffSnapshotStatusMap[childQuoteDB.QuoteStatus]; !ok {
		return nil, false
	}
	quoteID, compareWith := childQuoteDB.Id, parentQuoteDB.Id
	processData, err := dal.QuoteProcessDataDao.FindLastByCondition(tx, framework.Condition{
		"quote_id":  quoteID,
		"biz_scene": data_parse.BizSceneQuoteDiffSnapshot,
		"biz_code":  strconv.FormatInt(compareWith, 10),
	})
	if err != nil {
		logs.CtxError(ctx, "[DiffQuoteService.getDiffSnapshot] query snapshot fail, quoteID=%d, compareWith=%d, err=%s",
			quoteID, compareWith, err.Error())
		return nil, false
	}
	if processData == nil || processData.Id == 0 {
		return nil, false
	}
	if processData.CalculateDetail == "" {
		logs.CtxError(ctx, "[DiffQuoteService.getDiffSnapshot] snapshot content is empty, quoteID=%d, compareWith=%d",
			quoteID, compareWith)
		return nil, false
	}
	result := &QuoteDiffResult{}
	if err = json.Unmarshal([]byte(processData.CalculateDetail), result); err != nil {
		logs.CtxError(ctx, "[DiffQuoteService.getDiffSnapshot] unmarshal snapshot fail, quoteID=%d, compareWith=%d, err=%s",
			quoteID, compareWith, err.Error())
		return nil, false
	}
	logs.CtxInfo(ctx, "[DiffQuoteService.getDiffSnapshot] snapshot hit, quoteID=%d, compareWith=%d", quoteID, compareWith)
	return result, true
}

package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/process_data/data_parse"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	std_errors "errors"
	"github.com/bytedance/mockey"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"strconv"
	"testing"
)

func TestGetDiffSnapshot(t *testing.T) {
	childQuoteDB := &model.Quote{
		BaseDB:      framework.BaseDB{Id: 101},
		QuoteStatus: constants.StatusPass,
	}
	parentQuoteDB := &model.Quote{BaseDB: framework.BaseDB{Id: 201}}

	t.Run("returns stored snapshot", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(&model.QuoteProcessData{
					BaseDB:          framework.BaseDB{Id: 1},
					CalculateDetail: `{"QuoteDiff":{}}`,
				}, nil).Build()

			result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
				childQuoteDB, parentQuoteDB)

			require.True(t, found)
			require.NotNil(t, result)
		})
	})

	t.Run("returns not found when snapshot does not exist", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(&model.QuoteProcessData{}, nil).Build()

			result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
				childQuoteDB, parentQuoteDB)

			require.False(t, found)
			require.Nil(t, result)
		})
	})

	t.Run("returns not found on query error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(nil, std_errors.New("query failed")).Build()

			result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
				childQuoteDB, parentQuoteDB)

			require.False(t, found)
			require.Nil(t, result)
		})
	})

	t.Run("returns not found on empty snapshot", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(&model.QuoteProcessData{BaseDB: framework.BaseDB{Id: 1}}, nil).Build()

			result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
				childQuoteDB, parentQuoteDB)

			require.False(t, found)
			require.Nil(t, result)
		})
	})

	t.Run("returns not found on invalid json", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(&model.QuoteProcessData{
					BaseDB:          framework.BaseDB{Id: 1},
					CalculateDetail: `{`,
				}, nil).Build()

			result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
				childQuoteDB, parentQuoteDB)

			require.False(t, found)
			require.Nil(t, result)
		})
	})

	t.Run("does not query snapshot for disallowed status", func(t *testing.T) {
		disallowedChildQuoteDB := *childQuoteDB
		disallowedChildQuoteDB.QuoteStatus = constants.StatusSubmit
		result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
			&disallowedChildQuoteDB, parentQuoteDB)

		require.False(t, found)
		require.Nil(t, result)
	})

	t.Run("returns not found for nil quote", func(t *testing.T) {
		tests := []struct {
			name   string
			child  *model.Quote
			parent *model.Quote
		}{
			{name: "nil child", parent: parentQuoteDB},
			{name: "nil parent", child: childQuoteDB},
		}
		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				result, found := NewDiffQuoteService().getDiffSnapshot(context.Background(), &gorm.DB{},
					tt.child, tt.parent)

				require.False(t, found)
				require.Nil(t, result)
			})
		}
	})
}

func TestDiffPrefersSnapshotForFinalizedChildStatus(t *testing.T) {
	t.Run("returns snapshot for allowed child status", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
				constants.ApprovalModifyStatusNone)
			src.QuoteStatus = constants.StatusPass
			dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
				constants.ApprovalModifyStatusNone)
			mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				To(func(_ *gorm.DB, actual framework.Condition) (*model.QuoteProcessData, error) {
					require.Equal(t, int64(101), actual["quote_id"])
					require.Equal(t, data_parse.BizSceneQuoteDiffSnapshot, actual["biz_scene"])
					require.Equal(t, "201", actual["biz_code"])
					return &model.QuoteProcessData{
						BaseDB:          framework.BaseDB{Id: 1},
						CalculateDetail: "{\"BasicInfo\":{\"ChangeFields\":[\"CustomerName\"]}}",
					}, nil
				}).Build()

			result, err := NewDiffQuoteService().Diff(context.Background(), &gorm.DB{}, 101, 201)

			require.NoError(t, err)
			require.Equal(t, []string{"CustomerName"}, result.BasicInfo.ChangeFields)
		})
	})

	t.Run("uses normalized child and parent ids for reverse request", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			parent := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
				constants.ApprovalModifyStatusNone)
			child := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
				constants.ApprovalModifyStatusNone)
			child.QuoteStatus = constants.StatusPass
			mockey.Mock((*DiffQuoteService).validateParam).Return(parent, child, nil).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				To(func(_ *gorm.DB, actual framework.Condition) (*model.QuoteProcessData, error) {
					require.Equal(t, int64(101), actual["quote_id"])
					require.Equal(t, "201", actual["biz_code"])
					return &model.QuoteProcessData{
						BaseDB:          framework.BaseDB{Id: 1},
						CalculateDetail: `{"BasicInfo":{"ChangeFields":["CustomerName"]}}`,
					}, nil
				}).Build()

			result, err := NewDiffQuoteService().Diff(context.Background(), &gorm.DB{}, 201, 101)

			require.NoError(t, err)
			require.Equal(t, []string{"CustomerName"}, result.BasicInfo.ChangeFields)
		})
	})

	t.Run("falls back to realtime diff when snapshot is absent", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
				constants.ApprovalModifyStatusNone)
			src.QuoteStatus = constants.StatusPass
			dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
				constants.ApprovalModifyStatusNone)
			want := &QuoteDiffResult{BasicInfo: &QuoteDiffBasicInfo{ChangeFields: []string{"Realtime"}}}
			mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(&model.QuoteProcessData{}, nil).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(getDiffHandler).Return(&MockDiffHandlerOK{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diff).Return(want, nil).Build()

			result, err := NewDiffQuoteService().Diff(context.Background(), &gorm.DB{}, 101, 201)

			require.NoError(t, err)
			require.Same(t, want, result)
		})
	})

	t.Run("falls back to realtime diff when snapshot query fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
				constants.ApprovalModifyStatusNone)
			src.QuoteStatus = constants.StatusPass
			dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
				constants.ApprovalModifyStatusNone)
			want := &QuoteDiffResult{BasicInfo: &QuoteDiffBasicInfo{ChangeFields: []string{"Realtime"}}}
			mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
				Return(nil, std_errors.New("query failed")).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(getDiffHandler).Return(&MockDiffHandlerOK{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diff).Return(want, nil).Build()

			result, err := NewDiffQuoteService().Diff(context.Background(), &gorm.DB{}, 101, 201)

			require.NoError(t, err)
			require.Same(t, want, result)
		})
	})

	t.Run("does not query snapshot for disallowed child status", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			src := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
				constants.ApprovalModifyStatusNone)
			src.QuoteStatus = constants.StatusSubmit
			dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
				constants.ApprovalModifyStatusNone)
			want := &QuoteDiffResult{BasicInfo: &QuoteDiffBasicInfo{ChangeFields: []string{"Realtime"}}}
			mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
			mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
			mockey.Mock(getDiffHandler).Return(&MockDiffHandlerOK{}, nil).Build()
			mockey.Mock((*DiffQuoteService).diff).Return(want, nil).Build()

			result, err := NewDiffQuoteService().Diff(context.Background(), &gorm.DB{}, 101, 201)

			require.NoError(t, err)
			require.Same(t, want, result)
		})
	})
}

func TestDiffQuoteAlwaysCalculatesRealtime(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		src := newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 201, 0,
			constants.ApprovalModifyStatusNone)
		src.QuoteStatus = constants.StatusPass
		dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0,
			constants.ApprovalModifyStatusNone)
		want := &QuoteDiffResult{BasicInfo: &QuoteDiffBasicInfo{ChangeFields: []string{"Realtime"}}}
		mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()
		snapshotQueryCalls := 0
		mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "FindLastByCondition")).
			To(func(_ *gorm.DB, _ framework.Condition) (*model.QuoteProcessData, error) {
				snapshotQueryCalls++
				return &model.QuoteProcessData{
					BaseDB:          framework.BaseDB{Id: 1},
					CalculateDetail: `{"BasicInfo":{"ChangeFields":["Snapshot"]}}`,
				}, nil
			}).Build()
		mockey.Mock(config.GetDiffConf).Return(&config.DiffConf{}).Build()
		mockey.Mock(getDiffHandler).Return(&MockDiffHandlerOK{}, nil).Build()
		mockey.Mock((*DiffQuoteService).diff).Return(want, nil).Build()

		result, err := NewDiffQuoteService().diffQuote(context.Background(), &gorm.DB{}, 101, 201)

		require.NoError(t, err)
		require.Same(t, want, result)
		require.Zero(t, snapshotQueryCalls)
	})
}

func TestGetDiffSnapshotByQuoteIDsReturnsNotFoundWhenValidationFails(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		mockey.Mock((*DiffQuoteService).validateParam).
			Return(nil, nil, std_errors.New("validate failed")).Build()

		result, found := NewDiffQuoteService().getDiffSnapshotByQuoteIDs(context.Background(), &gorm.DB{}, 101, 201)

		require.False(t, found)
		require.Nil(t, result)
	})
}

func TestGetDiffSnapshotByQuoteIDsReturnsNotFoundForUnrelatedQuotes(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		src := newDiffSnapshotTestQuote(101, multienv.SceneNew, 0, 0, 0, constants.ApprovalModifyStatusNone)
		dest := newDiffSnapshotTestQuote(201, multienv.SceneNew, 0, 0, 0, constants.ApprovalModifyStatusNone)
		mockey.Mock((*DiffQuoteService).validateParam).Return(src, dest, nil).Build()

		result, found := NewDiffQuoteService().getDiffSnapshotByQuoteIDs(context.Background(), &gorm.DB{}, 101, 201)

		require.False(t, found)
		require.Nil(t, result)
	})
}

func TestSaveApprovalPassedDiffSnapshots(t *testing.T) {
	tests := []struct {
		name      string
		quote     *model.Quote
		wantPairs [][2]int64
	}{
		{
			name:  "change quote saves current quote against origin quote",
			quote: newDiffSnapshotTestQuote(101, multienv.SceneChangeQuote, 201, 0, 0, constants.ApprovalModifyStatusNone),
			wantPairs: [][2]int64{
				{101, 201},
			},
		},
		{
			name:  "supply agreement saves current quote against parent quote",
			quote: newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 202, 0, constants.ApprovalModifyStatusNone),
			wantPairs: [][2]int64{
				{101, 202},
			},
		},
		{
			name:  "new quote approval modification saves current quote against origin snapshot",
			quote: newDiffSnapshotTestQuote(101, multienv.SceneNew, 0, 0, 203, constants.ApprovalModifyStatusNone),
			wantPairs: [][2]int64{
				{101, 203},
			},
		},
		{
			name:  "change quote approval modification saves three snapshots",
			quote: newDiffSnapshotTestQuote(101, multienv.SceneChangeQuote, 201, 0, 203, constants.ApprovalModifyStatusNone),
			wantPairs: [][2]int64{
				{101, 201},
				{101, 203},
				{203, 201},
			},
		},
		{
			name:  "supply agreement approval modification saves three snapshots",
			quote: newDiffSnapshotTestQuote(101, multienv.SceneSupplyAgreement, 0, 202, 203, constants.ApprovalModifyStatusNone),
			wantPairs: [][2]int64{
				{101, 202},
				{101, 203},
				{203, 202},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				want := &QuoteDiffResult{BasicInfo: &QuoteDiffBasicInfo{ChangeFields: []string{"CustomerName"}}}
				var comparedQuoteIDs [][2]int64
				mockey.Mock((*DiffQuoteService).diffQuote).
					To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, quoteID int64, compareQuoteID int64) (*QuoteDiffResult, error) {
						comparedQuoteIDs = append(comparedQuoteIDs, [2]int64{quoteID, compareQuoteID})
						return want, nil
					}).Build()

				var saved []*model.QuoteProcessData
				mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "Save")).
					To(func(_ *gorm.DB, data interface{}, _ schema.Tabler) error {
						saved = append(saved, data.(*model.QuoteProcessData))
						return nil
					}).Build()

				err := SaveApprovalPassedDiffSnapshots(context.Background(), &gorm.DB{}, tt.quote)

				require.NoError(t, err)
				require.Equal(t, tt.wantPairs, comparedQuoteIDs)
				require.Len(t, saved, len(tt.wantPairs))
				for i, processData := range saved {
					require.Equal(t, tt.wantPairs[i][0], processData.QuoteID)
					require.Equal(t, "quote_diff_snapshot", processData.BizScene)
					require.Equal(t, strconv.FormatInt(tt.wantPairs[i][1], 10), processData.BizCode)
					require.JSONEq(t, `{"BasicInfo":{"ChangeFields":["CustomerName"]}}`, processData.CalculateDetail)
				}
			})
		})
	}
}

func TestSaveApprovalPassedDiffSnapshotsSkipsZeroIDs(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		quote := newDiffSnapshotTestQuote(101, multienv.SceneNew, 0, 0, 0,
			constants.ApprovalModifyStatusNone)
		diffCalls := 0
		mockey.Mock((*DiffQuoteService).diffQuote).
			To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, _ int64, _ int64) (*QuoteDiffResult, error) {
				diffCalls++
				return &QuoteDiffResult{}, nil
			}).Build()

		err := SaveApprovalPassedDiffSnapshots(context.Background(), &gorm.DB{}, quote)

		require.NoError(t, err)
		require.Zero(t, diffCalls)
	})
}

func TestSaveApprovalPassedDiffSnapshotsStopsAfterSaveFailure(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		quote := newDiffSnapshotTestQuote(101, multienv.SceneChangeQuote, 201, 202, 203,
			constants.ApprovalModifyStatusNone)
		wantErr := std_errors.New("save failed")
		var comparedQuoteIDs [][2]int64
		mockey.Mock((*DiffQuoteService).saveDiffSnapshot).
			To(func(_ *DiffQuoteService, _ context.Context, _ *gorm.DB, quoteID int64, compareQuoteID int64) error {
				comparedQuoteIDs = append(comparedQuoteIDs, [2]int64{quoteID, compareQuoteID})
				return wantErr
			}).Build()

		err := SaveApprovalPassedDiffSnapshots(context.Background(), &gorm.DB{}, quote)

		require.ErrorIs(t, err, wantErr)
		require.Equal(t, [][2]int64{{101, 201}}, comparedQuoteIDs)
	})
}

func TestSaveDiffSnapshotReturnsOriginalError(t *testing.T) {
	t.Run("calculate diff fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			wantErr := std_errors.New("calculate failed")
			mockey.Mock((*DiffQuoteService).diffQuote).Return(nil, wantErr).Build()

			err := NewDiffQuoteService().saveDiffSnapshot(context.Background(), &gorm.DB{}, 101, 201)

			require.ErrorIs(t, err, wantErr)
		})
	})

	t.Run("marshal diff fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diff := &QuoteDiffResult{
				Items: &QuoteDiffCommonEntity{AllList: []interface{}{func() {}}},
			}
			mockey.Mock((*DiffQuoteService).diffQuote).Return(diff, nil).Build()

			err := NewDiffQuoteService().saveDiffSnapshot(context.Background(), &gorm.DB{}, 101, 201)

			require.Error(t, err)
			require.Contains(t, err.Error(), "unsupported type")
		})
	})

	t.Run("save process data fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			wantErr := std_errors.New("save failed")
			mockey.Mock((*DiffQuoteService).diffQuote).Return(&QuoteDiffResult{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteProcessDataDao, "Save")).Return(wantErr).Build()

			err := NewDiffQuoteService().saveDiffSnapshot(context.Background(), &gorm.DB{}, 101, 201)

			require.ErrorIs(t, err, wantErr)
		})
	})
}

func TestSaveApprovalPassedDiffSnapshotsRejectsNilQuote(t *testing.T) {
	err := SaveApprovalPassedDiffSnapshots(context.Background(), &gorm.DB{}, nil)

	assertDiffSnapshotBizError(t, err, "报价单为空或 ID 非法")
}

func newDiffSnapshotTestQuote(
	id int64,
	scene multienv.QuoteScene,
	originQuoteID int64,
	parentQuoteID int64,
	originSnapshotID int64,
	modifyStatus int,
) *model.Quote {
	return &model.Quote{
		BaseDB:           framework.BaseDB{Id: id},
		QuoteScene:       scene,
		OriginQuoteID:    originQuoteID,
		ParentQuoteID:    parentQuoteID,
		OriginSnapshotID: originSnapshotID,
		ModifyStatus:     modifyStatus,
	}
}

func assertDiffSnapshotBizError(t *testing.T, err error, message string) {
	t.Helper()
	require.Error(t, err)
	require.ErrorContains(t, err, message)
	apiErr, ok := err.(interface {
		GetCodeInt() int
		GetCode() string
	})
	require.True(t, ok)
	require.Equal(t, int(pkg_errors.HistoryInternalErrCode), apiErr.GetCodeInt())
	require.Equal(t, pkg_errors.ErrorCodeBizRuleCheckFailed, apiErr.GetCode())
}

func TestSaveApprovalPassedDiffSnapshotsRejectsNonPositiveQuoteID(t *testing.T) {
	tests := []struct {
		name string
		id   int64
	}{
		{name: "zero id", id: 0},
		{name: "negative id", id: -1},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			quote := newDiffSnapshotTestQuote(tt.id, multienv.SceneNew, 0, 0, 0, constants.ApprovalModifyStatusNone)

			err := SaveApprovalPassedDiffSnapshots(context.Background(), &gorm.DB{}, quote)

			assertDiffSnapshotBizError(t, err, "报价单为空或 ID 非法")
		})
	}
}

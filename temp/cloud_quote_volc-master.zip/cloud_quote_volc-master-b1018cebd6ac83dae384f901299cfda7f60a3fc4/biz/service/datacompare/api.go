package datacompare

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/gopkg/logs"
)

type quoteDiffRelationType int

const (
	quoteDiffRelationUnknown quoteDiffRelationType = iota
	quoteDiffRelationChange
	quoteDiffRelationSupply
	quoteDiffRelationSnapshot
)

func Diff(ctx context.Context, dc *Context) (*CompareResult, error) {

	if dc == nil || dc.Src == nil || dc.Dest == nil {
		return &CompareResult{}, nil
	}

	reflectValue := reflect.Indirect(reflect.ValueOf(dc.Src))
	switch reflectValue.Kind() {
	case reflect.Map:
		return diffMap(ctx, dc)
	case reflect.Slice:
		return diffList(ctx, dc)
	default:
		return nil, errors.New("unsupported compare type")
	}

}

func diffMap(ctx context.Context, dc *Context) (*CompareResult, error) {
	if dc.Config == nil {
		return nil, errors.New("compare config is nil")
	}
	srcMap, ok := dc.Src.(map[string]interface{})
	if !ok {
		return nil, errors.New("invalid input")
	}
	destMap, ok := dc.Dest.(map[string]interface{})
	if !ok {
		return nil, errors.New("invalid input")
	}

	diffFields, changedDetail := CompareField(ctx, dc.Scene, srcMap, destMap, dc.Config.CompareFields)
	return &CompareResult{DiffFields: diffFields, ChangedDetail: changedDetail}, nil
}

/**
 * 1. 对比新增、减少的条目
 * 2. 对比变更的条目
 */
func diffList(ctx context.Context, dc *Context) (*CompareResult, error) {

	if dc.Config == nil ||
		dc.Config.ListCompareSrcKeyBuilder == nil ||
		dc.Config.ListCompareDestKeyBuilder == nil ||
		dc.Config.ListCompareResultKeyBuilder == nil {
		return nil, errors.New("compare config is nil")
	}

	srcList, ok := dc.Src.([]map[string]interface{})
	if !ok {
		return nil, errors.New("invalid input")
	}
	destList, ok := dc.Dest.([]map[string]interface{})
	if !ok {
		return nil, errors.New("invalid input")
	}

	var (
		allList        []interface{}                              // 全量key
		addedList      []interface{}                              // 新增的key
		deletedList    []interface{}                              // 删除的key
		changedList    []interface{}                              // 变更的key
		sameList       []interface{}                              // 未变更的key
		changedDetails = map[string]map[string]ChangedFieldInfo{} // 变更的key的变更详情
	)

	srcGroupMap := groupByPK(ctx, dc.Config.ListCompareSrcKeyBuilder, srcList)
	destGroupMap := groupByPK(ctx, dc.Config.ListCompareDestKeyBuilder, destList)

	for key, src := range srcGroupMap {
		resultKey := dc.Config.ListCompareResultKeyBuilder(src)
		allList = append(allList, resultKey)

		dest := destGroupMap[key]
		if dest == nil {
			// 当前列表中有，原列表中无 => 新增
			addedList = append(addedList, resultKey)
			continue
		}

		// 当前列表中有，原列表中有 => 对比是否变更
		diffFields, changedDetail := CompareField(ctx, dc.Scene, src, dest, dc.Config.CompareFields)
		if len(diffFields) > 0 {
			changedList = append(changedList, resultKey)
			changedDetails[resultKey] = changedDetail
		} else {
			sameList = append(sameList, resultKey)
		}
	}

	for key, dest := range destGroupMap {
		src := srcGroupMap[key]
		if src == nil {
			// 当前列表中无，原列表中有 => 删除
			deletedList = append(deletedList, dc.Config.ListCompareResultKeyBuilder(dest))
		}
	}

	return &CompareResult{
		AllList:        allList,
		AddedList:      addedList,
		DeletedList:    deletedList,
		ChangedList:    changedList,
		SameList:       sameList,
		ChangedDetails: changedDetails,
	}, nil
}

func groupByPK(ctx context.Context, keyBuilder KeyBuilder, list []map[string]interface{}) map[string]map[string]interface{} {
	groupMap := map[string]map[string]interface{}{}
	for i, entity := range list {
		key := keyBuilder(entity)
		if key == "" {
			continue
		}
		if groupMap[key] != nil {
			logs.CtxWarn(ctx, "[datacompare]groupByPK_duplicated_key => %s", key)
			key = fmt.Sprintf("%s::%d", key, i)
		}
		groupMap[key] = entity
	}
	return groupMap
}

func buildKey(pkFields []string, entity map[string]interface{}) string {
	var values []string
	for _, field := range pkFields {
		v := entity[field]
		if v == nil {
			continue
		}
		vs := fmt.Sprintf("%+v", v)
		values = append(values, vs)
	}
	return strings.Join(values, constants.Separator)
}

func buildKeyBuilder(fields ...string) KeyBuilder {
	return func(values map[string]interface{}) string {
		return buildKey(fields, values)
	}
}

// getDiffFieldBizScene 获取diff特殊业务场景
func getDiffFieldBizScene(quote *model.Quote) []string {
	var bizScene []string

	if quote.IsSupplyConfigList() {
		// 补充配置清单
		bizScene = append(bizScene, "supply_agreement_config_list")
	}
	if quote.IsProjectSupplyAgreement() {
		// 补充项目制报价单
		bizScene = append(bizScene, "supply_agreement_project_quote")
	}
	if multienv.IsContainsSupplyScene(quote.SupplyScene, multienv.SupplySceneContractRenewal) {
		// 项目制补充协议-增购+续约
		bizScene = append(bizScene, "supply_scene_contract_renewal")
	}
	if quote.QuoteStatus.IsInApproveStatus() || quote.QuoteStatus.AfterInApproveStatus() {
		// 报价单状态在送审后
		bizScene = append(bizScene, "quote_status_after_submit")
	}

	return bizScene
}

func isChildVSParent(srcQuote, destQuote *model.Quote) bool {
	return srcQuote.ParentQuoteID == destQuote.Id ||
		srcQuote.OriginQuoteID == destQuote.Id ||
		srcQuote.ParentSnapshotID == destQuote.Id ||
		srcQuote.OriginSnapshotID == destQuote.Id
}

func getQuoteDiffRelationType(childQuote, parentQuote *model.Quote) quoteDiffRelationType {
	if childQuote == nil || parentQuote == nil {
		return quoteDiffRelationUnknown
	}
	// 首次快照通过 origin_snapshot_id 关联；多轮审批中修改通过 parent_snapshot_id 关联最近版本。
	if childQuote.OriginSnapshotID == parentQuote.Id || childQuote.ParentSnapshotID == parentQuote.Id {
		return quoteDiffRelationSnapshot
	}
	if childQuote.OriginQuoteID == parentQuote.Id {
		return quoteDiffRelationChange
	}
	if childQuote.ParentQuoteID == parentQuote.Id {
		return quoteDiffRelationSupply
	}
	return quoteDiffRelationUnknown
}

func getChildQuote(srcQuote, destQuote *model.Quote, isChildVSParent bool) *model.Quote {
	if isChildVSParent {
		return srcQuote
	}
	return destQuote
}

func getChildQuoteInfo(srcQuoteInfo, destQuoteInfo *assistant.CallbackInfo, isChildVSParent bool) *assistant.CallbackInfo {
	if isChildVSParent {
		return srcQuoteInfo
	}
	return destQuoteInfo
}

func getCouponKeyBuilder(processInfo *quoteDiffProcessInfo) (KeyBuilder, KeyBuilder) {
	childKeyBuilder, parentKeyBuilder := getCouponChildParentKeyBuilder(processInfo.relationType)
	if processInfo.childVSParent {
		return childKeyBuilder, parentKeyBuilder
	}
	return parentKeyBuilder, childKeyBuilder
}

func getCouponChildParentKeyBuilder(relationType quoteDiffRelationType) (KeyBuilder, KeyBuilder) {
	switch relationType {
	case quoteDiffRelationSnapshot:
		return buildKeyBuilder("Id"), buildKeyBuilder("SnapshotFrom")
	case quoteDiffRelationChange:
		return buildKeyBuilder("ChangeFrom"), buildKeyBuilder("Id")
	case quoteDiffRelationSupply:
		return buildKeyBuilder("CopyFrom"), buildKeyBuilder("Id")
	default:
		return nil, nil
	}
}

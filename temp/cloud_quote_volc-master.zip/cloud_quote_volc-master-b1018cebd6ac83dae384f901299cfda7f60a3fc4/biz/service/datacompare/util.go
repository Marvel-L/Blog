package datacompare

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

const (
	// TrendNone 趋势：无变化（默认值，不输出）
	TrendNone = 0
	// TrendIncrease 趋势：变大
	TrendIncrease = 1
	// TrendDecrease 趋势：变小
	TrendDecrease = 2
)

const (
	// TrendCalcTypeNone 不计算趋势
	TrendCalcTypeNone = ""
	// TrendCalcTypeDecimal 数值型（直接比较 decimal）
	TrendCalcTypeDecimal = "decimal"
	// TrendCalcTypeDiscount 折扣型（需要解析折扣结构）
	TrendCalcTypeDiscount = "discount"
	// TrendCalcTypeInterval 区间型（取左边界比较）
	TrendCalcTypeInterval = "interval"
)

const (
	DiffFieldDiscount              = "discount"
	DiffFieldTotalDiscount         = "TotalDiscount"
	DiffFieldQuantityPriceInterval = "QuantityPriceInterval"
	DiffFieldTaxRate               = "TaxRate"
)

// CompareField 对数据字段值是否一致
// @param bizScene 业务场景
// @param curMap 当前数据
// @param originMap 原始数据
// @param fields 对比字段
// @return []string 变更字段code
// @return map[string]ChangedFieldInfo 变更字段变更详情
func CompareField(ctx context.Context, bizScene []string, curMap, originMap map[string]interface{}, fields []config.DiffFieldInfoConf) ([]string, map[string]ChangedFieldInfo) {
	logs.CtxInfo(ctx, "CompareField start, bizScene:%v, curMap:%s, originMap:%s", bizScene, util.GetJsonStr(curMap), util.GetJsonStr(originMap))

	var (
		diffFields    []string
		changedDetail = map[string]ChangedFieldInfo{}
	)

	for _, field := range fields {
		logs.CtxInfo(ctx, "CompareField field start, field:%s", util.GetJsonStr(field))
		if len(field.Scene) > 0 && !util.StrSliceIn(field.Scene, bizScene) {
			// 业务场景与字段适用场景不匹配，直接跳过
			continue
		}

		// 获取真实key
		valKey := field.Code
		if field.ValKey != "" {
			valKey = field.ValKey
		}

		// 记录真实值，返回前后值使用
		curValRel := curMap[valKey]
		originValRel := originMap[valKey]

		curValRelStr := interface2Str(curValRel)
		originValRelStr := interface2Str(originValRel)
		logs.CtxInfo(ctx, "CompareField field value before, curVal:%s, originVal:%s", curValRelStr, originValRelStr)

		if len(field.ValuePath) > 0 {
			// 指定路径，只对比具体路径下的值
			curValRelMap := Interface2Map(curValRel)
			originValRelMap := Interface2Map(originValRel)

			var (
				curCompareValMap    = map[string]interface{}{}
				originCompareValMap = map[string]interface{}{}
				curCompareVals      []string
				originCompareVals   []string
			)

			for _, path := range field.ValuePath {
				curCompareVal := curValRelMap[path]
				originCompareVal := originValRelMap[path]

				curCompareValMap[path] = curCompareVal
				originCompareValMap[path] = originCompareVal
				curCompareVals = append(curCompareVals, interface2Str(curCompareVal))
				originCompareVals = append(originCompareVals, interface2Str(originCompareVal))
			}

			curValRel = curCompareValMap
			originValRel = originCompareValMap
			curValRelStr = strings.Join(curCompareVals, constants.Separator)
			originValRelStr = strings.Join(originCompareVals, constants.Separator)
		}

		if field.NeedSort {
			// 需要排序，按指定字符分割后重新排序然后合并
			curValRelStr = str2SortedStr(curValRelStr, field.SortValueType)
			originValRelStr = str2SortedStr(originValRelStr, field.SortValueType)
		}

		logs.CtxInfo(ctx, "CompareField field value after, curVal:%s, originVal:%s", curValRelStr, originValRelStr)
		if curValRelStr != originValRelStr {
			// 不相等，记录变更字段
			diffFields = append(diffFields, field.Code)
			changedDetail[field.Code] = ChangedFieldInfo{Code: field.Code, Name: field.Name, OriginValue: originValRel, CurValues: curValRel, Trend: computeTrendByType(field.TrendCalcType, curValRel, originValRel)}
		}
	}

	logs.CtxInfo(ctx, "CompareField end, diffFields:%v, changedDetail:%s", diffFields, util.GetJsonStr(changedDetail))
	return diffFields, changedDetail
}

func Interface2Map(v interface{}) map[string]interface{} {
	if v == nil {
		return map[string]interface{}{}
	}
	vv, ok := v.(map[string]interface{})
	if ok {
		return vv
	}

	var body []byte
	if vStr, ok := v.(string); ok {
		// 字符串不用再次json序列化
		body = []byte(vStr)
	} else {
		body, _ = json.Marshal(v)
	}

	var ret = map[string]interface{}{}
	decoder := json.NewDecoder(bytes.NewBuffer(body))
	decoder.UseNumber()
	_ = decoder.Decode(&ret)
	return ret
}

func Interface2Slice(v interface{}) []map[string]interface{} {
	if v == nil {
		return []map[string]interface{}{}
	}
	vv, ok := v.([]map[string]interface{})
	if ok {
		return vv
	}

	var body []byte
	if vStr, ok := v.(string); ok {
		// 字符串不用再次json序列化
		body = []byte(vStr)
	} else {
		body, _ = json.Marshal(v)
	}

	var ret []map[string]interface{}
	decoder := json.NewDecoder(bytes.NewBuffer(body))
	decoder.UseNumber()
	_ = decoder.Decode(&ret)
	return ret
}

func str2SortedStr(v string, sortValueType int) string {
	if sortValueType == 1 {
		// int数组json
		var list []int
		_ = json.Unmarshal([]byte(v), &list)
		sort.Ints(list)
		return util.GetJsonStr(list)
	}

	if sortValueType == 2 {
		// string数组json
		var list []string
		_ = json.Unmarshal([]byte(v), &list)
		sort.Strings(list)
		return util.GetJsonStr(list)
	}

	// 逗号分隔（默认）
	arr := strings.Split(v, ",")
	sort.Strings(arr)
	return strings.Join(arr, ",")
}

func interface2Str(v interface{}) string {
	if v == nil {
		return ""
	}
	return fmt.Sprintf("%+v", v)
}

// computeTrendByType 根据配置的 TrendCalcType 计算字段趋势：
// - TrendNone：默认值（不输出）
// - TrendIncrease：变大
// - TrendDecrease：变小
func computeTrendByType(trendCalcType string, curVal, originVal interface{}) int {
	switch trendCalcType {
	case TrendCalcTypeDecimal:
		// 数值型字段：综合折扣、综合返券比例、返佣比例等
		return computeDecimalTrend(curVal, originVal)
	case TrendCalcTypeDiscount:
		// 折扣型字段：discount、discountSecond、discountFinal等
		return computeDiscountTrend(curVal, originVal)
	case TrendCalcTypeInterval:
		// 区间型字段：QuantityPriceInterval等
		return computeQuantityPriceIntervalTrend(curVal, originVal)
	default:
		// 空或未配置，不计算趋势
		return TrendNone
	}
}

// computeDecimalTrend 用于可以直接转为 decimal 的数值字段趋势计算。
func computeDecimalTrend(curVal, originVal interface{}) int {
	// 当前值为 null 时，视为 0 进行比较
	curDec, ok1 := interfaceToDecimal(curVal)
	if !ok1 {
		curDec = decimal.Zero
	}

	// 当原始值为 null 时，视为 0 进行比较
	originDec, ok2 := interfaceToDecimal(originVal)
	if !ok2 {
		originDec = decimal.Zero
	}

	if curDec.GreaterThan(originDec) {
		return TrendIncrease
	}
	if curDec.LessThan(originDec) {
		return TrendDecrease
	}
	return TrendNone
}

// computeDiscountTrend 折扣字段趋势计算。
func computeDiscountTrend(curVal, originVal interface{}) int {
	// 步骤1：将值转换为 map 格式
	curMap := Interface2Map(curVal)
	originMap := Interface2Map(originVal)

	// 步骤2：从 map 中提取可比较的数值
	curDec, ok1 := discountMapToComparableDecimal(curMap)
	originDec, ok2 := discountMapToComparableDecimal(originMap)

	if !ok1 || !ok2 {
		return TrendNone
	}

	// 步骤3：比较数值大小
	if curDec.GreaterThan(originDec) {
		return TrendIncrease
	}
	if curDec.LessThan(originDec) {
		return TrendDecrease
	}

	return TrendNone
}

// computeQuantityPriceIntervalTrend 量价区间趋势计算。
// 量价区间是字符串（例如 "10,20" 或 "20"），趋势按区间左边界的数值比较：
// - 左边界变大 => TrendIncrease
// - 左边界变小 => TrendDecrease
// - 原本无量价区间，现在有=> TrendIncrease，前端展示「增」
// - 原本有量价区间，现在无=> TrendNone，前端不展示标签
func computeQuantityPriceIntervalTrend(curVal, originVal interface{}) int {
	curInterval := quantityPriceIntervalStr(curVal)
	originInterval := quantityPriceIntervalStr(originVal)

	// 两者都为空，无变化
	if curInterval == "" && originInterval == "" {
		return TrendNone
	}

	// 从有到无
	if curInterval == "" {
		return TrendNone
	}

	// 从无到有
	if originInterval == "" {
		return TrendIncrease
	}

	// 正常情况：两者都有量价区间，比较左边界数值
	curLeft, ok1 := quantityPriceIntervalLeftDecimal(curInterval)
	if !ok1 {
		return TrendNone
	}

	originLeft, ok2 := quantityPriceIntervalLeftDecimal(originInterval)
	if !ok2 {
		return TrendNone
	}

	if curLeft.GreaterThan(originLeft) {
		return TrendIncrease
	}
	if curLeft.LessThan(originLeft) {
		return TrendDecrease
	}
	return TrendNone
}

// quantityPriceIntervalStr 兼容 CompareField 截取后的形态：
// - 字符串：直接返回
// - map：优先取 "QuantityPriceInterval" 字段；否则在单字段 map 场景取唯一值
func quantityPriceIntervalStr(v interface{}) string {
	if v == nil {
		return ""
	}
	if s, ok := v.(string); ok {
		return s
	}
	if m, ok := v.(map[string]interface{}); ok {
		if vv, exist := m["QuantityPriceInterval"]; exist {
			return interface2Str(vv)
		}
		if len(m) == 1 {
			for _, vv := range m {
				if s, ok := vv.(string); ok {
					return s
				}
				return interface2Str(vv)
			}
		}
	}
	return ""
}

// quantityPriceIntervalLeftDecimal 取量价区间的左边界数值。
// interval 示例："10,20" / "20"
func quantityPriceIntervalLeftDecimal(interval string) (decimal.Decimal, bool) {
	interval = strings.TrimSpace(interval)
	if interval == "" {
		return decimal.Zero, false
	}
	parts := strings.Split(interval, ",")
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		d, err := decimal.NewFromString(p)
		if err != nil {
			return decimal.Zero, false
		}
		return d, true
	}
	return decimal.Zero, false
}

// discountMapToComparableDecimal 将折扣结构提取成可比较的 decimal 值。
// 折扣结构可能有多种形式，这个函数会根据不同的定价函数类型选择合适的比较值：
// - simple_discount（简单折扣）/ fixed_price（固定价）：直接使用 UnitPrice
// - 其他（如阶梯折扣、时间满折等）：从 UnitPriceInterval 中取最小折扣值作为比较基准
func discountMapToComparableDecimal(m map[string]interface{}) (decimal.Decimal, bool) {
	// 步骤1：提取定价函数类型和单价
	pf := interface2Str(m["PricingFunction"])
	unitPrice, unitOK := interfaceToDecimal(m["UnitPrice"])

	// 步骤2：如果是简单折扣或固定价，直接使用 UnitPrice
	if pf == constants.DiscountFunctionSimpleDiscount || pf == constants.DiscountFunctionFixedPrice {
		return unitPrice, unitOK
	}

	// 步骤3：尝试从 UnitPriceInterval 中提取最小值
	unitPriceInterval := strings.TrimSpace(interface2Str(m["UnitPriceInterval"]))
	if unitPriceInterval == "" {
		return unitPrice, unitOK
	}

	// 情况A：UnitPriceInterval 是 JSON 格式（如时间折扣）
	if strings.HasPrefix(unitPriceInterval, "{") {
		var mp map[string]string
		if err := json.Unmarshal([]byte(unitPriceInterval), &mp); err != nil {
			return unitPrice, unitOK
		}

		var min decimal.Decimal
		found := false

		// 遍历 JSON 中的所有值
		for _, v := range mp {
			// 每个值可能是逗号分隔的多个价格
			for _, part := range strings.Split(v, ",") {
				part = strings.TrimSpace(part)
				if part == "" {
					continue
				}

				// 尝试转换为 decimal
				d, err := decimal.NewFromString(part)
				if err != nil {
					continue
				}

				// 更新最小值
				if !found || d.LessThan(min) {
					min = d
					found = true
				}
			}
		}

		if found {
			return min, true
		}
		return unitPrice, unitOK
	}

	// 情况B：UnitPriceInterval 是逗号分隔的字符串（如阶梯折扣）
	var min decimal.Decimal
	found := false

	for _, part := range strings.Split(unitPriceInterval, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}

		// 尝试转换为 decimal
		d, err := decimal.NewFromString(part)
		if err != nil {
			continue
		}

		// 更新最小值
		if !found || d.LessThan(min) {
			min = d
			found = true
		}
	}

	if found {
		return min, true
	}

	// 步骤4：所有方式都失败，回退到使用 UnitPrice
	return unitPrice, unitOK
}

// interfaceToDecimal 将 interface{} 尽量转换为 decimal.Decimal：
// - 支持 decimal.Decimal/json.Number/数值类型/string 等
// - 转换失败返回 (0,false)
func interfaceToDecimal(v interface{}) (decimal.Decimal, bool) {
	if v == nil {
		return decimal.Zero, false
	}
	switch vv := v.(type) {
	case decimal.Decimal:
		return vv, true
	case *decimal.Decimal:
		if vv == nil {
			return decimal.Zero, false
		}
		return *vv, true
	case json.Number:
		d, err := decimal.NewFromString(vv.String())
		return d, err == nil
	case float64:
		return decimal.NewFromFloat(vv), true
	case float32:
		return decimal.NewFromFloat(float64(vv)), true
	case int:
		return decimal.NewFromInt(int64(vv)), true
	case int8:
		return decimal.NewFromInt(int64(vv)), true
	case int16:
		return decimal.NewFromInt(int64(vv)), true
	case int32:
		return decimal.NewFromInt(int64(vv)), true
	case int64:
		return decimal.NewFromInt(vv), true
	case uint:
		return decimal.NewFromInt(int64(vv)), true
	case uint8:
		return decimal.NewFromInt(int64(vv)), true
	case uint16:
		return decimal.NewFromInt(int64(vv)), true
	case uint32:
		return decimal.NewFromInt(int64(vv)), true
	case uint64:
		if vv > uint64(^uint64(0)>>1) {
			return decimal.Zero, false
		}
		return decimal.NewFromInt(int64(vv)), true
	case string:
		s := strings.TrimSpace(vv)
		if s == "" {
			return decimal.Zero, false
		}
		if i, err := strconv.ParseInt(s, 10, 64); err == nil {
			return decimal.NewFromInt(i), true
		}
		d, err := decimal.NewFromString(s)
		return d, err == nil
	default:
		s := strings.TrimSpace(interface2Str(v))
		if s == "" {
			return decimal.Zero, false
		}
		d, err := decimal.NewFromString(s)
		return d, err == nil
	}
}

package datacompare

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

func Test_diffList(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			ret, err := diffList(context.Background(), &Context{
				Config: &Config{
					CompareFields:               []config.DiffFieldInfoConf{{Code: "a"}},
					ListCompareSrcKeyBuilder:    buildKeyBuilder("id"),
					ListCompareDestKeyBuilder:   buildKeyBuilder("id"),
					ListCompareResultKeyBuilder: buildKeyBuilder("id"),
				},
				Src: []map[string]interface{}{
					{
						"id": 1,
						"a":  1,
					},
					{
						"id": 2,
						"a":  2,
					},
					{
						"id": 3,
						"a":  3,
					},
				},
				Dest: []map[string]interface{}{
					{
						"id": 1,
						"a":  1,
					},
					{
						"id": 2,
						"a":  21,
					},
					{
						"id": 4,
						"a":  4,
					},
				},
			})

			t.Log(ret)
			t.Log(err)

			// Assert
			convey.So(err, convey.ShouldBeEmpty)
		})
	})
}

func Test_diffMap(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			ret, err := diffMap(context.Background(), &Context{
				Config: &Config{
					CompareFields: []config.DiffFieldInfoConf{
						{
							Code:          "a",
							Name:          "a",
							Scene:         nil,
							ValuePath:     nil,
							NeedSort:      false,
							SortValueType: 0,
						},
					},
					ListCompareSrcKeyBuilder:    buildKeyBuilder("id"),
					ListCompareDestKeyBuilder:   buildKeyBuilder("id"),
					ListCompareResultKeyBuilder: buildKeyBuilder("id"),
				},
				Src: map[string]interface{}{
					"id": 100,
					"a":  1,
					"b":  "2",
					"c":  nil,
				},
				Dest: map[string]interface{}{
					"id": 100,
					"a":  1,
					"b":  "3",
					"c":  nil,
				},
			})

			t.Log(ret)
			t.Log(err)

			// Assert
			convey.So(err, convey.ShouldBeEmpty)
		})
	})
}

func Test_Diff(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			ret, err := Diff(context.Background(), &Context{
				Config: &Config{
					CompareFields: []config.DiffFieldInfoConf{
						{
							Code:          "a",
							Name:          "a",
							Scene:         nil,
							ValuePath:     nil,
							NeedSort:      false,
							SortValueType: 0,
						},
					},
				},
				Src: map[string]interface{}{
					"id": 100,
					"a":  1,
					"b":  "2",
					"c":  nil,
				},
				Dest: map[string]interface{}{
					"id": 100,
					"a":  1,
					"b":  "3",
					"c":  nil,
				},
			})

			t.Log(ret)
			t.Log(err)

			// Assert
			convey.So(err, convey.ShouldBeEmpty)
		})
	})
}

func Test_getDiffFieldBizScene(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			quote := &model.Quote{
				QuoteScene:  multienv.SceneSupplyConfigurationList,
				SupplyScene: "4,5",
				QuoteStatus: constants.StatusSubmitting,
			}

			// Act
			bizScene := getDiffFieldBizScene(quote)

			// Assert
			convey.So(bizScene, convey.ShouldHaveLength, 3)
		})

		mockey.PatchConvey("", t, func() {
			// Arrange
			quote := &model.Quote{
				QuoteType:   multienv.QuoteTypeProjectBased,
				QuoteScene:  multienv.SceneSupplyAgreement,
				SupplyScene: "4",
				QuoteStatus: constants.StatusPass,
			}

			// Act
			bizScene := getDiffFieldBizScene(quote)

			// Assert
			convey.So(bizScene, convey.ShouldHaveLength, 2)
		})
	})
}

func Test_getChildQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			srcQuote := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1,
				},
				ParentQuoteID: 0,
			}
			destQuote := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 2,
				},
				ParentQuoteID: 1,
			}

			// Act
			childQuote1 := getChildQuote(srcQuote, destQuote, false)
			childQuote2 := getChildQuote(srcQuote, destQuote, true)

			// Assert
			convey.So(childQuote1, convey.ShouldEqual, destQuote)
			convey.So(childQuote2, convey.ShouldEqual, srcQuote)
		})
	})
}

func Test_getChildQuoteInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			srcQuoteInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 1,
					},
					ParentQuoteID: 0,
				},
			}
			destQuoteInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 2,
					},
					ParentQuoteID: 1,
				},
			}

			// Act
			childQuoteInfo1 := getChildQuoteInfo(srcQuoteInfo, destQuoteInfo, false)
			childQuoteInfo2 := getChildQuoteInfo(srcQuoteInfo, destQuoteInfo, true)

			// Assert
			convey.So(childQuoteInfo1, convey.ShouldEqual, destQuoteInfo)
			convey.So(childQuoteInfo2, convey.ShouldEqual, srcQuoteInfo)
		})
	})
}

func Test_getCouponKeyBuilder(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			srcKeyBuilder1, destKeyBuilder1 := getCouponKeyBuilder(&quoteDiffProcessInfo{
				diffConf:      nil,
				childVSParent: false,
				relationType:  quoteDiffRelationSupply,
				scene:         nil,
				childQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 1,
					},
					ParentQuoteID: 111,
				},
				parentQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 111,
					},
					ParentQuoteID: 1,
				},
				diffHandler: nil,
			})
			srcKeyBuilder2, destKeyBuilder2 := getCouponKeyBuilder(&quoteDiffProcessInfo{
				diffConf:      nil,
				childVSParent: false,
				relationType:  quoteDiffRelationChange,
				scene:         nil,
				childQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 1,
					},
					OriginQuoteID: 111,
				},
				parentQuoteDB: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 111,
					},
					ParentQuoteID: 1,
				},
				diffHandler: nil,
			})

			// Assert
			convey.So(srcKeyBuilder1, convey.ShouldNotBeNil)
			convey.So(destKeyBuilder1, convey.ShouldNotBeNil)
			convey.So(srcKeyBuilder2, convey.ShouldNotBeNil)
			convey.So(destKeyBuilder2, convey.ShouldNotBeNil)
			convey.So(srcKeyBuilder1(map[string]interface{}{"Id": 111}), convey.ShouldEqual, "111")
			convey.So(destKeyBuilder1(map[string]interface{}{"CopyFrom": 111}), convey.ShouldEqual, "111")
			convey.So(srcKeyBuilder2(map[string]interface{}{"Id": 111}), convey.ShouldEqual, "111")
			convey.So(destKeyBuilder2(map[string]interface{}{"ChangeFrom": 111}), convey.ShouldEqual, "111")
		})
	})

	t.Run("快照版本使用当前ID匹配快照来源ID", func(t *testing.T) {
		processInfo := &quoteDiffProcessInfo{
			childVSParent: true,
			relationType:  quoteDiffRelationSnapshot,
			childQuoteDB: &model.Quote{
				QuoteScene: multienv.SceneChangeQuote,
			},
			parentQuoteDB: &model.Quote{},
		}

		srcKeyBuilder, destKeyBuilder := getCouponKeyBuilder(processInfo)

		convey.Convey("current to snapshot", t, func() {
			convey.So(srcKeyBuilder(map[string]interface{}{"Id": 601}), convey.ShouldEqual, "601")
			convey.So(destKeyBuilder(map[string]interface{}{"SnapshotFrom": 601}), convey.ShouldEqual, "601")
		})
	})

	t.Run("反向快照版本交换当前和快照KeyBuilder", func(t *testing.T) {
		processInfo := &quoteDiffProcessInfo{
			childVSParent: false,
			relationType:  quoteDiffRelationSnapshot,
			childQuoteDB:  &model.Quote{},
			parentQuoteDB: &model.Quote{},
		}

		srcKeyBuilder, destKeyBuilder := getCouponKeyBuilder(processInfo)

		convey.Convey("snapshot to current", t, func() {
			convey.So(srcKeyBuilder(map[string]interface{}{"SnapshotFrom": 601}), convey.ShouldEqual, "601")
			convey.So(destKeyBuilder(map[string]interface{}{"Id": 601}), convey.ShouldEqual, "601")
		})
	})
}

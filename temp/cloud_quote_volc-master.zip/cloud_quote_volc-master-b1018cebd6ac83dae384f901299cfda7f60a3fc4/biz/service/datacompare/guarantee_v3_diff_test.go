package datacompare

import (
	"context"
	"reflect"
	"strconv"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

func TestGuaranteeV3QuoteItemMappings(t *testing.T) {
	newItems := []map[string]interface{}{
		{"Id": int64(11), "ChargeItemCompareKey": "a"},
		{"Id": int64(12), "ChargeItemCompareKey": "new"},
		{"Id": int64(13), "ChargeItemCompareKey": "a"},
	}
	oldItems := []map[string]interface{}{
		{"Id": int64(21), "ChargeItemCompareKey": "a"},
		{"Id": int64(22), "ChargeItemCompareKey": "deleted"},
		{"Id": int64(23), "ChargeItemCompareKey": "a"},
	}
	newToOld, oldToNew, err := buildQuoteItemIDMappings(context.Background(), newItems, oldItems)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(newToOld, map[int64]int64{11: 21, 12: 0, 13: 23}) ||
		!reflect.DeepEqual(oldToNew, map[int64]int64{21: 11, 22: 0, 23: 13}) {
		t.Fatalf("unexpected mappings: %+v %+v", newToOld, oldToNew)
	}
	reverse, forward, err := buildQuoteItemIDMappings(context.Background(), oldItems, newItems)
	if err != nil || !reflect.DeepEqual(reverse, oldToNew) || !reflect.DeepEqual(forward, newToOld) {
		t.Fatalf("mapping reverse is inconsistent: %v", err)
	}
	_, _, err = buildQuoteItemIDMappings(context.Background(), []map[string]interface{}{{"Id": "bad"}}, nil)
	if err == nil {
		t.Fatal("invalid ID accepted")
	}
}

func TestGuaranteeV3DiffNormalization(t *testing.T) {
	for _, relation := range []quoteDiffRelationType{quoteDiffRelationSupply, quoteDiffRelationChange, quoteDiffRelationSnapshot} {
		t.Run(strconv.Itoa(int(relation)), func(t *testing.T) {
			currentRaw, oldRaw := `["1","2.0"]`, `["1.0000000000","2"]`
			current := &model.GuaranteeItem{
				BaseDB: framework.BaseDB{Id: 11}, QuoteID: 1,
				GuaranteeAmountMode: 1, GuaranteeAmountLadder: &currentRaw, CrossGroupCarryForwardID: 12,
				CopyFrom: 21, ChangeFrom: 21,
			}
			currentTarget := &model.GuaranteeItem{BaseDB: framework.BaseDB{Id: 12}, QuoteID: 1, CopyFrom: 22, ChangeFrom: 22}
			old := &model.GuaranteeItem{
				BaseDB: framework.BaseDB{Id: 21}, QuoteID: 2,
				GuaranteeAmountMode: 1, GuaranteeAmountLadder: &oldRaw, CrossGroupCarryForwardID: 22, SnapshotFrom: 11,
			}
			oldTarget := &model.GuaranteeItem{BaseDB: framework.BaseDB{Id: 22}, QuoteID: 2, SnapshotFrom: 12}
			process := &quoteDiffProcessInfo{relationType: relation}
			_, currentList, err := buildGuaranteeCompare([]*model.GuaranteeItem{current, currentTarget}, true, process)
			if err != nil {
				t.Fatal(err)
			}
			_, oldList, err := buildGuaranteeCompare([]*model.GuaranteeItem{old, oldTarget}, false, process)
			if err != nil {
				t.Fatal(err)
			}
			for _, key := range []string{"GuaranteeAmountMode", "GuaranteeAmountLadder", "SameRuleCarryForward", "CrossGroupCarryForwardID"} {
				if !reflect.DeepEqual(currentList[0][key], oldList[0][key]) {
					t.Fatalf("%s differs after ID/decimal normalization: %v != %v", key, currentList[0][key], oldList[0][key])
				}
			}
			currentRaw = `["2","1"]`
			_, reordered, err := buildGuaranteeCompare([]*model.GuaranteeItem{current, currentTarget}, true, process)
			if err != nil || reflect.DeepEqual(reordered[0]["GuaranteeAmountLadder"], oldList[0]["GuaranteeAmountLadder"]) {
				t.Fatal("ladder order change was hidden")
			}
			currentRaw = `invalid`
			if _, _, err := buildGuaranteeCompare([]*model.GuaranteeItem{current, currentTarget}, true, process); err == nil {
				t.Fatal("malformed ladder accepted")
			}
		})
	}
}

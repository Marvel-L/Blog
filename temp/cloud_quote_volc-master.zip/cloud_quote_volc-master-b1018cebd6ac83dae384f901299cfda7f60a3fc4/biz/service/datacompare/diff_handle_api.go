package datacompare

import (
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
)

type DiffHandler interface {
	validateQuote(ctx context.Context, tx *gorm.DB) error
	needDiffInfo(infoType multienv.QuoteInfoType) bool
	getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf
	getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error)
	getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error)
	getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error)
	diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult)
	isChangeScene() bool
}

func getDiffHandler(
	srcQuoteDB, destQuoteDB *model.Quote,
	isChildVSParent bool,
	relationType quoteDiffRelationType,
) (DiffHandler, error) {
	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(srcQuoteDB, destQuoteDB, isChildVSParent)

	// 后续下线
	if childQuoteDB.IsSupplyConfigList() && parentQuoteDB.IsProjectBased() {
		// 子=补充配置清单，父=项目制报价单
		return &SupplyConfigListDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	}

	switch {
	// 变更场景与其审批中修改快照，沿用对应的变更处理器。
	case childQuoteDB.IsProjectBasedChange() &&
		(relationType == quoteDiffRelationChange || relationType == quoteDiffRelationSnapshot):
		return &ProjectBasedChangeDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	case childQuoteDB.IsPublicChange() &&
		(relationType == quoteDiffRelationChange || relationType == quoteDiffRelationSnapshot):
		return &PublicChangeQuoteDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	// 补充场景与其审批中修改快照，沿用对应的补充处理器。
	case childQuoteDB.IsProjectSupplyAgreement() &&
		(relationType == quoteDiffRelationSupply || relationType == quoteDiffRelationSnapshot):
		return &ProjectBasedSupplyDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	case childQuoteDB.IsPublicSupplyAgreement() &&
		(relationType == quoteDiffRelationSupply || relationType == quoteDiffRelationSnapshot):
		return &PublicSupplyDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	// 新签报价单只有快照版本关系，复用对应的变更处理器。
	case relationType == quoteDiffRelationSnapshot &&
		childQuoteDB.QuoteScene == multienv.SceneNew &&
		childQuoteDB.IsProjectBased():
		return &ProjectBasedChangeDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	case relationType == quoteDiffRelationSnapshot && childQuoteDB.IsPublicNew():
		return &PublicChangeQuoteDiffHandler{SrcQuoteDB: srcQuoteDB, DestQuoteDB: destQuoteDB, isChildVSParent: isChildVSParent}, nil
	}

	return nil, fmt.Errorf(
		"quote is not support to diff, srcQuoteID:%d, destQuoteDB:%d, relationType:%d",
		srcQuoteDB.Id,
		destQuoteDB.Id,
		relationType,
	)
}

func getChildVSParentQuoteDB(srcQuoteDB, destQuoteDB *model.Quote, isChildVSParent bool) (*model.Quote, *model.Quote) {
	if isChildVSParent {
		return srcQuoteDB, destQuoteDB
	}
	return destQuoteDB, srcQuoteDB
}

func getSrcVSDestCallbackInfo(childCallbackInfo, parentCallbackInfo *assistant.CallbackInfo, isChildVSParent bool) (*assistant.CallbackInfo, *assistant.CallbackInfo) {
	if isChildVSParent {
		return childCallbackInfo, parentCallbackInfo
	}
	return parentCallbackInfo, childCallbackInfo
}

func getDiffFieldConfigBySceneType(diffFieldMap map[string][]config.DiffFieldInfoConf, supplySceneType string) []config.DiffFieldInfoConf {
	if len(diffFieldMap) == 0 {
		return nil
	}
	return diffFieldMap[supplySceneType]
}

func getExpiredParentItems(expiredQuoteItems ...[]*model.QuoteItem) map[int64]bool {
	expiredItems := map[int64]bool{}
	for _, expiredQuoteItem := range expiredQuoteItems {
		for _, item := range expiredQuoteItem {
			expiredItems[item.ParentItemID] = true
		}
	}
	return expiredItems
}

func filterExpiredItems(expiredItems map[int64]bool, allQuoteItems []*model.QuoteItem) []*model.QuoteItem {
	var resultQuoteItems []*model.QuoteItem
	for _, item := range allQuoteItems {
		if _, exist := expiredItems[item.Id]; exist {
			continue
		}
		resultQuoteItems = append(resultQuoteItems, item)
	}
	return resultQuoteItems
}

func buildDefaultCallbackInfo(srcQuoteDB, destQuoteDB *model.Quote) (*assistant.CallbackInfo, *assistant.CallbackInfo) {
	srcCallbackInfo := &assistant.CallbackInfo{
		Quote: srcQuoteDB,
	}

	destCallbackInfo := &assistant.CallbackInfo{
		Quote: destQuoteDB,
	}
	return srcCallbackInfo, destCallbackInfo
}

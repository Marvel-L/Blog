package datacompare

import (
	"encoding/json"
	"sort"
	"strings"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"github.com/jinzhu/copier"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type Context struct {
	Config *Config     // 对比配置
	Src    interface{} // 源数据 map[string]interface | []map[string]interface
	Dest   interface{} // 目标数据 map[string]interface | []map[string]interface
	Scene  []string    // 业务场景
}

type Config struct {
	CompareFields               []config.DiffFieldInfoConf // 对比的字段
	ListCompareSrcKeyBuilder    KeyBuilder                 // 列表对比时 原实体对比键
	ListCompareDestKeyBuilder   KeyBuilder                 // 列表对比时 目标实体对比键
	ListCompareResultKeyBuilder KeyBuilder                 // 结果对比时 目标实体对比键
}

type CompareResult struct {
	DiffFields     []string                               // 有差异的字段列表
	ChangedDetail  map[string]ChangedFieldInfo            // 变更详情（Map类型）
	AllList        []interface{}                          // 全部
	AddedList      []interface{}                          // 新增的ID
	DeletedList    []interface{}                          // 删除的ID
	ChangedList    []interface{}                          // 变更的ID
	SameList       []interface{}                          // 未变更的ID
	ChangedDetails map[string]map[string]ChangedFieldInfo // 变更详情（Slice类型）
}

type ChangedFieldInfo struct {
	Code        string      // 字段code
	Name        string      // 字段name
	OriginValue interface{} // 字段原始值
	CurValues   interface{} // 字段当前值
	Trend       int         `json:"Trend,omitempty"` // 字段趋势：0=无/不展示，1=变大，2=变小
}

type KeyBuilder func(values map[string]interface{}) string

type CouponConfigCompare struct {
	framework.BaseDB
	CouponType              int
	RebateCouponWay         int
	ApplySource             int
	CouponUsage             string
	OpportunityNumber       string
	OpportunityName         string
	OpportunityCustomerName string
	Applicant               string
	ApplicantDepartment     string
	Remark                  string
	EnableBalanceAlert      int
	DisableInnerExpireAlert int
	BalanceAlertThreshold   float64
	CouponAlarmMembers      string
	TriggerInfo             string
	OrderTypeLimit          string
	ValidTimeType           int
	ValidBeginTime          time.Time
	ValidEndTime            time.Time
	ValidDays               int
	UsageLimit              int
	AmountLimit             float64
	PayTypeLimit            string
	Creator                 string
	AccountID               string
	AccumulateType          string
	CopyFrom                int64
	ChangeFrom              int64
	SnapshotFrom            int64
	BillCaliber             int
	RebatePeriod            int
	RebateThresholdType     int
	RuleValidityType        int
	RuleValidBeginMonth     string
	RuleValidEndMonth       string
	CapEnabled              int
	CapOnceAmount           float64
	CapTotalAmount          float64
	RuleValidityInfo        string
	CapInfo                 string
	ProductLimits           []*model.CouponConfigProductsLimitDB

	TriggerInfoTotalAmount                  float64
	TriggerInfoSingleAmount                 float64
	TriggerInfoRemark                       string
	TriggerInfoConsumeRebateProductList     string
	TriggerInfoStatConsumeRebateProductList string
	TriggerInfoStatQuoteItemIDList          []int64
	TriggerInfoTriggers                     []*model.Trigger
	TriggerInfoQuoteItemIDList              []int64
}

// genCouponConfigCompare 代金券数据库对象生成对比对象
func genCouponConfigCompare(couponDB *model.CouponConfigDB) (*CouponConfigCompare, error) {
	couponCompareData := &CouponConfigCompare{}
	err := copier.Copy(couponCompareData, couponDB)
	if err != nil {
		return nil, err
	}

	// 解析 RuleValidityInfo JSON
	var ruleInfo model.RuleValidityInfo
	_ = json.Unmarshal([]byte(couponDB.RuleValidityInfo), &ruleInfo)
	couponCompareData.RuleValidityType = ruleInfo.Type
	couponCompareData.RuleValidBeginMonth = ruleInfo.BeginMonth
	couponCompareData.RuleValidEndMonth = ruleInfo.EndMonth

	// 解析 CapInfo JSON
	var capInfo model.CapInfo
	_ = json.Unmarshal([]byte(couponDB.CapInfo), &capInfo)
	couponCompareData.CapEnabled = capInfo.Enabled
	couponCompareData.CapOnceAmount = capInfo.OnceAmount
	couponCompareData.CapTotalAmount = capInfo.TotalAmount

	var info model.TriggerInfo
	_ = json.Unmarshal([]byte(couponDB.TriggerInfo), &info)
	couponCompareData.TriggerInfoTotalAmount = info.TotalAmount
	couponCompareData.TriggerInfoSingleAmount = info.SingleAmount
	couponCompareData.TriggerInfoRemark = info.Remark
	couponCompareData.TriggerInfoConsumeRebateProductList = util.SortSliceStr(info.ConsumeRebateProductList)
	couponCompareData.TriggerInfoStatConsumeRebateProductList = util.SortSliceStr(info.StatConsumeRebateProductList)
	couponCompareData.TriggerInfoStatQuoteItemIDList = info.StatQuoteItemIDList
	couponCompareData.TriggerInfoTriggers = info.Triggers
	// QuoteItemIDList对比：将int64数组转为排序后的字符串用于对比
	couponCompareData.TriggerInfoQuoteItemIDList = info.QuoteItemIDList
	return couponCompareData, err
}

type CouponProductsLimitCompare struct {
	Product   string
	ValueKeys []string
}

// genCouponProductsLimitCompare 生成代金券适用商品对比象
func genCouponProductsLimitCompare(limitProducts []*model.CouponConfigProductsLimitDB) []*CouponProductsLimitCompare {
	productCompareMap := map[string][]string{}
	for _, limitProduct := range limitProducts {
		productCompareMap[limitProduct.Product] = append(productCompareMap[limitProduct.Product], limitProduct.ValueKey())
	}
	var compareProducts []*CouponProductsLimitCompare
	for product, valueKeys := range productCompareMap {
		sort.Slice(valueKeys, func(i, j int) bool {
			return strings.Compare(valueKeys[i], valueKeys[j]) > 0
		})
		compareProducts = append(compareProducts, &CouponProductsLimitCompare{
			Product:   product,
			ValueKeys: valueKeys,
		})
	}
	return compareProducts
}

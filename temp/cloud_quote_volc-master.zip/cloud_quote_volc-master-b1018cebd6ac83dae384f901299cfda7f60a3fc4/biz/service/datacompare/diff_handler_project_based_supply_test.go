package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func Test_ProjectBasedSupplyDiffHandler_getSupplySceneType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			// Act
			supplySceneType := diffHandler.getSupplySceneType()

			// Assert
			convey.So(supplySceneType, convey.ShouldNotBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_validateQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			// Act
			err := diffHandler.validateQuote(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_needDiffInfo(t *testing.T) {
	t.Run("始终包含保底对比分支", func(t *testing.T) {
		mockey.PatchConvey("始终包含保底对比分支", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()

			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteBaseInfo), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteItemContext), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteCoupon), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteRebate), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(multienv.InfoTypeQuoteGuarantee), convey.ShouldBeTrue)
			convey.So(diffHandler.needDiffInfo(666), convey.ShouldBeFalse)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_getDiffFieldConfig(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			// Act
			fieldConfig := diffHandler.getDiffFieldConfig(nil)

			// Assert
			convey.So(fieldConfig, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteBaseInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteBaseInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteItemInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteItemInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteCouponInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCouponInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteGuaranteeInfo(t *testing.T) {
	t.Run("成功返回保底回调信息", func(t *testing.T) {
		mockey.PatchConvey("成功返回保底回调信息", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).To(func(_ context.Context, _ *gorm.DB, quote *model.Quote, opts ...assistant.CallbackOption) (*assistant.CallbackInfo, pkg_errors.APIError) {
				callbackCtx := &assistant.CallbackContext{}
				for _, opt := range opts {
					opt.F(callbackCtx)
				}
				convey.So(callbackCtx.CallbackInfoKeys, convey.ShouldContain, assistant.CallbackKeyGuaranteeItem)
				return &assistant.CallbackInfo{Quote: quote, GuaranteeItems: []*model.GuaranteeItem{{}}}, nil
			}).Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(srcCallbackInfo.Quote, convey.ShouldEqual, diffHandler.SrcQuoteDB)
			convey.So(destCallbackInfo.Quote, convey.ShouldEqual, diffHandler.DestQuoteDB)
			convey.So(srcCallbackInfo.GuaranteeItems, convey.ShouldNotBeEmpty)
			convey.So(destCallbackInfo.GuaranteeItems, convey.ShouldNotBeEmpty)
		})
	})

	t.Run("源报价单查询失败时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("源报价单查询失败时返回统一错误", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})

	t.Run("目标报价单查询失败时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("目标报价单查询失败时返回统一错误", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()
			srcInfo := &assistant.CallbackInfo{Quote: diffHandler.SrcQuoteDB, GuaranteeItems: []*model.GuaranteeItem{{}}}
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).
					Then(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteGuaranteeInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})
}
func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteCreditInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteCreditInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectBasedSupplyDiffHandler_diffQuoteItemsResultPostProcessing(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()

			processInfo := &quoteDiffProcessInfo{
				diffConf: &config.DiffConf{
					ProfitDiffDependFields:        []string{"a"},
					StandardPriceDiffIgnoreFields: []string{"b"},
				},
			}

			compareResult := &CompareResult{
				ChangedList: []interface{}{"1", "2", "3", "4"},
				SameList:    []interface{}{"5"},
				ChangedDetails: map[string]map[string]ChangedFieldInfo{
					"1": {
						"a": ChangedFieldInfo{},
						"b": ChangedFieldInfo{},
					},
					"2": {
						Price: ChangedFieldInfo{},
						"b":   ChangedFieldInfo{},
					},
					"3": {
						Price: ChangedFieldInfo{},
						"a":   ChangedFieldInfo{},
						"b":   ChangedFieldInfo{},
					},
					"4": {
						Price: ChangedFieldInfo{},
						"a":   ChangedFieldInfo{},
						"b":   ChangedFieldInfo{},
						"c":   ChangedFieldInfo{},
					},
				},
			}

			// Act
			diffHandler.diffQuoteItemsResultPostProcessing(processInfo, compareResult)

			// Assert
			convey.So(compareResult.ChangedList, convey.ShouldHaveLength, 3)
			convey.So(compareResult.SameList, convey.ShouldHaveLength, 2)

			convey.So(compareResult.ChangedList, convey.ShouldContain, "1")
			convey.So(compareResult.ChangedList, convey.ShouldContain, "3")
			convey.So(compareResult.ChangedList, convey.ShouldContain, "4")
			convey.So(compareResult.SameList, convey.ShouldContain, "2")
			convey.So(compareResult.SameList, convey.ShouldContain, "5")
		})
	})
}

func getProjectBasedSupplyDiffHandler() *ProjectBasedSupplyDiffHandler {
	return &ProjectBasedSupplyDiffHandler{
		SrcQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 1,
			},
			ParentQuoteID: 0,
		},
		DestQuoteDB: &model.Quote{
			BaseDB: framework.BaseDB{
				Id: 2,
			},
			ParentQuoteID: 1,
		},
		isChildVSParent: false,
	}
}

func Test_ProjectBasedSupplyDiffHandler_getDiffQuoteRebateInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).To(func(_ context.Context, _ *gorm.DB, quote *model.Quote, opts ...assistant.CallbackOption) (*assistant.CallbackInfo, pkg_errors.APIError) {
				callbackCtx := &assistant.CallbackContext{}
				for _, opt := range opts {
					opt.F(callbackCtx)
				}
				convey.So(callbackCtx.CallbackInfoKeys, convey.ShouldContain, assistant.CallbackKeyAllRebateData)
				return &assistant.CallbackInfo{Quote: quote}, nil
			}).Build()

			// Act
			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("source callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()
			mockey.Mock(assistant.CallbackWithQuote).Return(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})

	t.Run("destination callback returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			diffHandler := getProjectBasedSupplyDiffHandler()
			srcInfo := &assistant.CallbackInfo{Quote: diffHandler.SrcQuoteDB}
			mockey.Mock(assistant.CallbackWithQuote).Return(
				mockey.Sequence(srcInfo, nil).
					Then(nil, pkg_errors.ErrCustomerError.WithArgs("mocked error")),
			).Build()
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			srcCallbackInfo, destCallbackInfo, err := diffHandler.getDiffQuoteRebateInfo(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返佣信息失败")
			convey.So(srcCallbackInfo, convey.ShouldBeNil)
			convey.So(destCallbackInfo, convey.ShouldBeNil)
		})
	})
}

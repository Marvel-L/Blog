package datacompare

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service/profit_calculator"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// ProjectBasedChangeDiffHandler   补充项目制报价单 Diff处理器
type ProjectBasedChangeDiffHandler struct {
	SrcQuoteDB      *model.Quote
	DestQuoteDB     *model.Quote
	isChildVSParent bool
}

func (h *ProjectBasedChangeDiffHandler) getSupplySceneType() string {
	return "ProjectBasedChange"
}

func (h *ProjectBasedChangeDiffHandler) validateQuote(ctx context.Context, tx *gorm.DB) error {
	return nil
}

func (h *ProjectBasedChangeDiffHandler) needDiffInfo(infoType multienv.QuoteInfoType) bool {
	if infoType == multienv.InfoTypeQuoteBaseInfo {
		return true
	}
	if infoType == multienv.InfoTypeQuoteItemContext {
		return true
	}
	if infoType == multienv.InfoTypeQuoteCoupon {
		return true
	}
	if infoType == multienv.InfoTypeQuoteGuarantee {
		return true
	}
	if infoType == multienv.InfoTypeQuoteCredit {
		return true
	}
	if infoType == multienv.InfoTypeQuoteRebate {
		return true
	}
	if infoType == multienv.InfoTypeProfitCal {
		return true
	}
	if infoType == multienv.InfoTypeJointPrintOrder {
		return true
	}
	return false
}

func (h *ProjectBasedChangeDiffHandler) getDiffFieldConfig(diffFieldMap map[string][]config.DiffFieldInfoConf) []config.DiffFieldInfoConf {
	return getDiffFieldConfigBySceneType(diffFieldMap, h.getSupplySceneType())
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteBaseInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(h.SrcQuoteDB, h.DestQuoteDB)

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteItemInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	childQuoteDB, parentQuoteDB := getChildVSParentQuoteDB(h.SrcQuoteDB, h.DestQuoteDB, h.isChildVSParent)

	// 子补充项目制报价单，额外查询失效报价项、交付项
	childCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, childQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuote,            // 报价单
				assistant.CallbackKeyQuoteItems,       // 报价项
				assistant.CallbackKeyDeliveryItems,    // 交付项
				assistant.CallbackKeyItemValues,       // 报价项值
				assistant.CallbackKeyItemCalculates,   // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems, // 代金券信息
				assistant.CallbackKeyItemCouponRatio,  // 报价项返券比例
				assistant.CallbackKeyRebate,           // 返佣记录
			},
		),
	)

	if err != nil || childCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteItemInfo, childCallbackInfo fail, childQuoteID=%d, err=%+v", childQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	// 父项目制报价单
	parentCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, parentQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuote,            // 报价单
				assistant.CallbackKeyQuoteItems,       // 报价项
				assistant.CallbackKeyDeliveryItems,    // 交付项
				assistant.CallbackKeyItemValues,       // 报价项值
				assistant.CallbackKeyItemCalculates,   // 报价项试算信息
				assistant.CallbackKeyApplyCouponItems, // 代金券信息
				assistant.CallbackKeyItemCouponRatio,  // 报价项返券比例
				assistant.CallbackKeyRebate,           // 返佣记录
			},
		),
	)

	if err != nil || parentCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteItemInfo, parentCallbackInfo fail, parentQuoteID=%d, err=%+v", parentQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	srcCallbackInfo, destCallbackInfo := getSrcVSDestCallbackInfo(childCallbackInfo, parentCallbackInfo, h.isChildVSParent)
	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteCouponInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteCouponInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCouponItems, // 代金券
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteCouponInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询代金券信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteGuaranteeInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteGuaranteeInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyGuaranteeItem, // 保底
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteGuaranteeInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteCreditInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCreditItems, // 信控
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteCreditInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询信控信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyApplyCreditItems, // 信控
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteCreditInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询信控信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) getDiffQuoteRebateInfo(ctx context.Context, tx *gorm.DB) (*assistant.CallbackInfo, *assistant.CallbackInfo, error) {

	srcCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.SrcQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || srcCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteRebateInfo, srcCallbackInfo fail, srcQuoteID=%d, err=%+v", h.SrcQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	destCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, h.DestQuoteDB,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteItems,    // 报价项
				assistant.CallbackKeyItemValues,    // 报价项条目
				assistant.CallbackKeyAllRebateData, // 返佣
			},
		),
	)

	if err != nil || destCallbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "[ProjectBasedChangeDiffHandler]getDiffQuoteRebateInfo, destCallbackInfo fail, destQuoteID=%d, err=%+v", h.DestQuoteDB.Id, err)
		return nil, nil, errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	return srcCallbackInfo, destCallbackInfo, nil
}

func (h *ProjectBasedChangeDiffHandler) diffQuoteItemsResultPostProcessing(processInfo *quoteDiffProcessInfo, compareResult *CompareResult) {
}

func (h *ProjectBasedChangeDiffHandler) getDiffProfitCalInfo(ctx context.Context, tx *gorm.DB, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, []*profit_calculator.CommonDataItem, error) {
	srcQuoteInfo, destQuoteInfo, err := h.getDiffQuoteBaseInfo(ctx, tx)
	if err != nil {
		return nil, nil, err
	}
	srcDataItems, err := getQuoteProfitCompareItems(ctx, tx, srcQuoteInfo.Quote, calculateType, compareKeys)
	if err != nil {
		return nil, nil, err
	}
	destDataItems, err := getQuoteProfitCompareItems(ctx, tx, destQuoteInfo.Quote, calculateType, compareKeys)
	if err != nil {
		return nil, nil, err
	}
	return srcDataItems, destDataItems, nil
}

func getQuoteProfitCompareItems(ctx context.Context, tx *gorm.DB, quote *model.Quote, calculateType int, compareKeys []string) ([]*profit_calculator.CommonDataItem, error) {
	profitDB, err := profit_calculator.GetProfitCalculate(ctx, tx, quote, calculateType, constants.ProfitDataScopeAll)
	if err != nil {
		return nil, err
	}
	profitCal, ok := profitDB.(*profit_calculator.ProjectBasedProfit)
	if !ok {
		return nil, errors.ErrInternalError.WithArgs("利润率汇算数据错误")
	}
	var itemList []*profit_calculator.CommonDataItem
	compareKeyMap := util.StrSliceToMap(compareKeys)
	for _, item := range profitCal.ProfitCalculateData.Header {
		if _, ok := compareKeyMap[item.DataKey]; ok {
			itemList = append(itemList, item)
		}
	}
	for _, item := range profitCal.ProfitCalculateData.Footer {
		if _, ok := compareKeyMap[item.DataKey]; ok {
			itemList = append(itemList, item)
		}
	}
	return itemList, nil
}

func (h *ProjectBasedChangeDiffHandler) getProductLineProfitCalInfo(ctx context.Context, tx *gorm.DB) ([]*profit_calculator.ProductLineCalculateData, []*profit_calculator.ProductLineCalculateData, error) {
	srcQuoteInfo, destQuoteInfo, err := h.getDiffQuoteBaseInfo(ctx, tx)
	if err != nil {
		return nil, nil, err
	}
	srcDataItems, err := getQuoteProductLineProfitCompareItems(ctx, tx, srcQuoteInfo.Quote)
	if err != nil {
		return nil, nil, err
	}
	destDataItems, err := getQuoteProductLineProfitCompareItems(ctx, tx, destQuoteInfo.Quote)
	if err != nil {
		return nil, nil, err
	}
	return srcDataItems, destDataItems, nil
}

func getQuoteProductLineProfitCompareItems(ctx context.Context, tx *gorm.DB, quote *model.Quote) ([]*profit_calculator.ProductLineCalculateData, error) {
	lineProfitCalculate, err := profit_calculator.GetProductLineProfitCalculate(ctx, tx, quote, constants.ProfitDataScopeAll)
	if err != nil {
		return nil, err
	}
	var itemList []*profit_calculator.ProductLineCalculateData
	data := lineProfitCalculate.ProfitCalculateData
	if data == nil {
		return itemList, nil
	}
	itemList = append(itemList, &profit_calculator.ProductLineCalculateData{
		ProductDepartmentName:         data.ProductDepartmentName,
		GrossProfitRate:               data.GrossProfitRate,
		FactoryPriceGrossProfitRate:   data.FactoryPriceGrossProfitRate,
		LatestResourceGrossProfitRate: data.LatestResourceGrossProfitRate,
	})
	for _, subCalculateData := range data.SubCalculateData {
		for _, ssData := range subCalculateData.SubCalculateData {
			itemList = append(itemList, &profit_calculator.ProductLineCalculateData{
				ProductDepartmentName:         ssData.ProductDepartmentName,
				GrossProfitRate:               ssData.GrossProfitRate,
				FactoryPriceGrossProfitRate:   ssData.FactoryPriceGrossProfitRate,
				LatestResourceGrossProfitRate: ssData.LatestResourceGrossProfitRate,
			})
		}
		itemList = append(itemList, &profit_calculator.ProductLineCalculateData{
			ProductDepartmentName:         subCalculateData.ProductDepartmentName,
			GrossProfitRate:               subCalculateData.GrossProfitRate,
			FactoryPriceGrossProfitRate:   subCalculateData.FactoryPriceGrossProfitRate,
			LatestResourceGrossProfitRate: subCalculateData.LatestResourceGrossProfitRate,
		})
	}
	return itemList, nil
}

func (h *ProjectBasedChangeDiffHandler) isChangeScene() bool {
	return true
}

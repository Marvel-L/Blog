package datacompare

import (
	"testing"

	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// 链式变更中，OriginQuoteID 表示直接前序单；RootQuoteID 仅表示整条变更链根单。
func TestChainChange_DirectPredecessorRelation(t *testing.T) {
	child := &model.Quote{
		BaseDB:        framework.BaseDB{Id: 300},
		OriginQuoteID: 200,
		RootQuoteID:   100,
	}

	convey.Convey("二次变更相对上一版是直接关系", t, func() {
		parent := &model.Quote{BaseDB: framework.BaseDB{Id: 200}}
		convey.So(isChildVSParent(child, parent), convey.ShouldBeTrue)
	})

	convey.Convey("二次变更相对链根不是直接关系", t, func() {
		root := &model.Quote{BaseDB: framework.BaseDB{Id: 100}}
		convey.So(isChildVSParent(child, root), convey.ShouldBeFalse)
	})
}

func TestChainChange_CouponKeyBuilderUsesDirectRelation(t *testing.T) {
	child := &model.Quote{
		BaseDB:        framework.BaseDB{Id: 300},
		OriginQuoteID: 200,
		RootQuoteID:   100,
	}

	convey.Convey("二次变更相对直接前序单使用 ChangeFrom", t, func() {
		childKey, _ := getCouponKeyBuilder(&quoteDiffProcessInfo{
			childVSParent: true,
			relationType:  quoteDiffRelationChange,
			childQuoteDB:  child,
			parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 200}},
		})
		convey.So(childKey(map[string]interface{}{"ChangeFrom": int64(11), "CopyFrom": int64(22)}), convey.ShouldEqual, "11")
	})

	convey.Convey("变更补协相对补协链根使用 CopyFrom", t, func() {
		childKey, _ := getCouponKeyBuilder(&quoteDiffProcessInfo{
			childVSParent: true,
			relationType:  quoteDiffRelationSupply,
			childQuoteDB:  child,
			parentQuoteDB: &model.Quote{BaseDB: framework.BaseDB{Id: 100}},
		})
		convey.So(childKey(map[string]interface{}{"ChangeFrom": int64(11), "CopyFrom": int64(22)}), convey.ShouldEqual, "22")
	})
}

package datacompare

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

func Test_getDiffHandler_NewQuoteModify(t *testing.T) {
	parentQuote := &model.Quote{BaseDB: framework.BaseDB{Id: 1}}

	t.Run("新签项目制修改使用项目制变更处理器", func(t *testing.T) {
		childQuote := &model.Quote{
			BaseDB:           framework.BaseDB{Id: 2},
			QuoteScene:       multienv.SceneNew,
			QuoteType:        multienv.QuoteTypeProjectBased,
			ParentSnapshotID: parentQuote.Id,
		}

		handler, err := getDiffHandler(childQuote, parentQuote, true, quoteDiffRelationSnapshot)

		if err != nil {
			t.Fatalf("getDiffHandler() error = %v", err)
		}
		if _, ok := handler.(*ProjectBasedChangeDiffHandler); !ok {
			t.Fatalf("getDiffHandler() type = %T, want *ProjectBasedChangeDiffHandler", handler)
		}
	})

	t.Run("新签公有云修改使用公有云变更处理器", func(t *testing.T) {
		childQuote := &model.Quote{
			BaseDB:           framework.BaseDB{Id: 2},
			QuoteScene:       multienv.SceneNew,
			QuoteType:        multienv.QuoteTypeNormal,
			ParentSnapshotID: parentQuote.Id,
		}

		handler, err := getDiffHandler(parentQuote, childQuote, false, quoteDiffRelationSnapshot)

		if err != nil {
			t.Fatalf("getDiffHandler() error = %v", err)
		}
		if _, ok := handler.(*PublicChangeQuoteDiffHandler); !ok {
			t.Fatalf("getDiffHandler() type = %T, want *PublicChangeQuoteDiffHandler", handler)
		}
	})

	t.Run("OriginSnapshotID关联的新签公有云修改使用公有云变更处理器", func(t *testing.T) {
		childQuote := &model.Quote{
			BaseDB:           framework.BaseDB{Id: 2},
			QuoteScene:       multienv.SceneNew,
			QuoteType:        multienv.QuoteTypeNormal,
			OriginSnapshotID: parentQuote.Id,
		}

		handler, err := getDiffHandler(childQuote, parentQuote, true, quoteDiffRelationSnapshot)

		if err != nil {
			t.Fatalf("getDiffHandler() error = %v", err)
		}
		if _, ok := handler.(*PublicChangeQuoteDiffHandler); !ok {
			t.Fatalf("getDiffHandler() type = %T, want *PublicChangeQuoteDiffHandler", handler)
		}
	})
}

func Test_getDiffHandler_ChangeQuoteSnapshot(t *testing.T) {
	originQuote := &model.Quote{
		BaseDB:     framework.BaseDB{Id: 100},
		QuoteScene: multienv.SceneNew,
		QuoteType:  multienv.QuoteTypeNormal,
	}
	currentQuote := &model.Quote{
		BaseDB:           framework.BaseDB{Id: 101},
		QuoteScene:       multienv.SceneChangeQuote,
		QuoteType:        multienv.QuoteTypeNormal,
		OriginQuoteID:    originQuote.Id,
		OriginSnapshotID: 102,
		ParentSnapshotID: 102,
	}
	snapshotQuote := &model.Quote{
		BaseDB:        framework.BaseDB{Id: 102},
		QuoteScene:    multienv.SceneChangeQuote,
		QuoteType:     multienv.QuoteTypeNormal,
		OriginQuoteID: originQuote.Id,
		SnapshotFrom:  currentQuote.Id,
	}

	businessRelation := getQuoteDiffRelationType(snapshotQuote, originQuote)
	if businessRelation != quoteDiffRelationChange {
		t.Fatalf("getQuoteDiffRelationType(102, 100) = %d, want change", businessRelation)
	}
	businessHandler, err := getDiffHandler(snapshotQuote, originQuote, true, businessRelation)
	if err != nil {
		t.Fatalf("getDiffHandler(102, 100) error = %v", err)
	}
	if _, ok := businessHandler.(*PublicChangeQuoteDiffHandler); !ok {
		t.Fatalf("getDiffHandler(102, 100) type = %T, want *PublicChangeQuoteDiffHandler", businessHandler)
	}

	snapshotRelation := getQuoteDiffRelationType(currentQuote, snapshotQuote)
	if snapshotRelation != quoteDiffRelationSnapshot {
		t.Fatalf("getQuoteDiffRelationType(101, 102) = %d, want snapshot", snapshotRelation)
	}
	snapshotHandler, err := getDiffHandler(currentQuote, snapshotQuote, true, snapshotRelation)
	if err != nil {
		t.Fatalf("getDiffHandler(101, 102) error = %v", err)
	}
	if _, ok := snapshotHandler.(*PublicChangeQuoteDiffHandler); !ok {
		t.Fatalf("getDiffHandler(101, 102) type = %T, want *PublicChangeQuoteDiffHandler", snapshotHandler)
	}
}

func Test_getChildVSParentQuoteDB(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			srcQuote := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1,
				},
				ParentQuoteID: 0,
			}
			destQuote := &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 2,
				},
				ParentQuoteID: 1,
			}

			// Act
			childQuoteDB1, parentQuoteDB1 := getChildVSParentQuoteDB(srcQuote, destQuote, false)
			childQuoteDB2, parentQuoteDB2 := getChildVSParentQuoteDB(srcQuote, destQuote, true)

			// Assert
			convey.So(childQuoteDB1, convey.ShouldEqual, destQuote)
			convey.So(parentQuoteDB1, convey.ShouldEqual, srcQuote)
			convey.So(childQuoteDB2, convey.ShouldEqual, srcQuote)
			convey.So(parentQuoteDB2, convey.ShouldEqual, destQuote)
		})
	})
}

func Test_getSrcVSDestCallbackInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			childQuoteInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 1,
					},
					ParentQuoteID: 0,
				},
			}
			parentQuoteInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB: framework.BaseDB{
						Id: 2,
					},
					ParentQuoteID: 1,
				},
			}

			// Act
			srcQuoteInfo1, destQuoteInfo1 := getSrcVSDestCallbackInfo(childQuoteInfo, parentQuoteInfo, false)
			srcQuoteInfo2, destQuoteInfo2 := getSrcVSDestCallbackInfo(childQuoteInfo, parentQuoteInfo, true)

			// Assert
			convey.So(srcQuoteInfo1, convey.ShouldEqual, parentQuoteInfo)
			convey.So(destQuoteInfo1, convey.ShouldEqual, childQuoteInfo)
			convey.So(srcQuoteInfo2, convey.ShouldEqual, childQuoteInfo)
			convey.So(destQuoteInfo2, convey.ShouldEqual, parentQuoteInfo)
		})
	})
}

func Test_getDiffFieldConfigBySceneType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("nil", t, func() {
			// Arrange

			// Act
			fieldConf := getDiffFieldConfigBySceneType(nil, "")

			// Assert
			convey.So(fieldConf, convey.ShouldBeNil)
		})

		mockey.PatchConvey("nil", t, func() {
			// Arrange
			diffFieldMap := map[string][]config.DiffFieldInfoConf{
				"a": []config.DiffFieldInfoConf{},
			}

			// Act
			fieldConf1 := getDiffFieldConfigBySceneType(nil, "")
			fieldConf2 := getDiffFieldConfigBySceneType(diffFieldMap, "a")
			fieldConf3 := getDiffFieldConfigBySceneType(diffFieldMap, "b")

			// Assert
			convey.So(fieldConf1, convey.ShouldBeNil)
			convey.So(fieldConf2, convey.ShouldNotBeNil)
			convey.So(fieldConf3, convey.ShouldBeNil)
		})
	})
}

func Test_getExpiredParentItems(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			expiredQuoteItem := []*model.QuoteItem{{ParentItemID: 1}}

			// Act
			expiredParentItems := getExpiredParentItems(expiredQuoteItem)

			// Assert
			convey.So(expiredParentItems, convey.ShouldHaveLength, 1)
			convey.So(expiredParentItems, convey.ShouldContainKey, int64(1))
		})
	})
}

func Test_filterExpiredItems(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			expiredParentItems := map[int64]bool{1: true}
			allQuoteItems := []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 1}}, {BaseDB: framework.BaseDB{Id: 2}}}

			// Act
			resultQuoteItems := filterExpiredItems(expiredParentItems, allQuoteItems)

			// Assert
			convey.So(resultQuoteItems, convey.ShouldHaveLength, 1)
			convey.So(resultQuoteItems[0].Id, convey.ShouldEqual, int64(2))
		})
	})
}

func Test_buildDefaultCallbackInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			srcCallbackInfo, destCallbackInfo := buildDefaultCallbackInfo(&model.Quote{}, &model.Quote{})

			// Assert
			convey.So(srcCallbackInfo, convey.ShouldNotBeNil)
			convey.So(destCallbackInfo, convey.ShouldNotBeNil)
		})
	})
}

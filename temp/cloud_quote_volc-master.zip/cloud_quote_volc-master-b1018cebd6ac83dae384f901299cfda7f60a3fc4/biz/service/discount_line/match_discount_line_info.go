package discount_line

//
//import (
//	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
//	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
//	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
//	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
//	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
//	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
//	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
//	"context"
//)
//
//type MatchDiscountLineReq struct {
//	TradeProduct string
//	QuoteID      int64
//	CfgNodeList  []*product_config_parser.ConfigNode `json:"CfgNodeList,required"`
//	Token        string
//}
//
//func (r *MatchDiscountLineReq) Handle(ctx context.Context) (interface{}, error) {
//
//	conf := config.GetGlobalConf(ctx)
//	if conf == nil {
//		return nil, errors.ErrInternalError.WithArgs("get conf error")
//	}
//
//	if conf.CronConf.AllowHttpCall && conf.CronConf.HttpCallToken == r.Token {
//		tx := dal.DBProxy.NewRequest(ctx)
//
//		quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
//		if err != nil {
//			return nil, err
//		}
//		productInfo, err := commodity_service.GetProductInfoFromCache(ctx, r.TradeProduct)
//		if err != nil {
//			return nil, err
//		}
//		productType := constants.ProductType(productInfo.ProductType)
//
//		// 获取当前商品配置树
//		container, err := product_config_load.GetConfigContainer(ctx, productType, productInfo.StandardProduct)
//		if err != nil {
//			return nil, err
//		}
//		configTree, err := container.GetProductConfigTree(ctx, productInfo, true, quote.GetConstraintAccountIDs(), quote.TradeType.GetCustomerScope())
//		if err != nil {
//			return nil, err
//		}
//
//		getDiscountLine := GetDiscountLine{
//			TradeProduct: r.TradeProduct,
//			QuoteID:      r.QuoteID,
//			CfgNodeList:  r.CfgNodeList,
//		}
//
//		discountLines, chargeItemKeyMap, allDiscountLineMap, allExFactoryDiscountLineMap, err := getDiscountLine.GetSelectAllDiscountLines(ctx, quote, configTree)
//		if err != nil {
//			return nil, err
//		}
//		return map[string]interface{}{
//			"discountLines":               discountLines,
//			"chargeItemKeyMap":            chargeItemKeyMap,
//			"allDiscountLineMap":          allDiscountLineMap,
//			"allExFactoryDiscountLineMap": allExFactoryDiscountLineMap,
//		}, nil
//	} else {
//		return nil, errors.ErrInvalidParam.WithArgs("token", r.Token)
//	}
//}

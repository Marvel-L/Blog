package discount_line

import (
	"context"
	"strings"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_effective"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
)

type GetDiscountLine struct {
	TradeProduct string
	QuoteID      int64
	CfgNodeList  []*product_config_parser.ConfigNode `json:"CfgNodeList,required"`

	ProductInfo *trade_client.TradeProductVersionInfo
}

func (r *GetDiscountLine) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)
	return r.getDiscountLines(ctx, tx)
}
func (r *GetDiscountLine) getDiscountLines(ctx context.Context, tx *gorm.DB) (interface{}, error) {
	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		return nil, err
	}
	productInfo, err := commodity_service.GetProductInfoFromCache(ctx, r.TradeProduct)
	if err != nil {
		return nil, err
	}
	r.ProductInfo = productInfo
	config_option_service.AppendExcludeDetail(ctx, quote, productInfo, r.CfgNodeList, false)
	// 获取当前商品配置树
	container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(r.ProductInfo.ProductType), r.ProductInfo.StandardProduct)
	if err != nil {
		return nil, err
	}
	filter := &product_config_parser.ConfigNodesFilter{
		ProductInfo:             productInfo,
		ConstraintAccountList:   quote.GetConstraintAccountIDs(),
		ConstraintAccountNumber: quote.ContractPriceAcc,
		QuoteCustomerScope:      quote.TradeType.GetCustomerScope(),
		CheckConfigIsPublic:     quote.IsQuote() && productInfo.ConfigPublicDisplay == multienv.ConfigPublicDisplayFalse,
		CheckAllPrePayWhiteList: quote.IsQuote(),
	}
	configTree, err := container.GetConfigFromCache(ctx, r.TradeProduct, filter)
	if err != nil {
		return nil, err
	}
	discountLineMap, err := r.GetSelectAllDiscountLines(ctx, quote, configTree)
	discountLines := r.filterDiscountLine(ctx, quote, discountLineMap)
	return discountLines, err
}

func (r *GetDiscountLine) GetSelectAllDiscountLines(ctx context.Context, quote *model.Quote, configTree *product_config_parser.StandardConfigTree) (map[string]*product_config_load.DiscountLine, error) {
	if configTree.Root == nil {
		return nil, nil
	}
	leafNodes, err := product_config_parser.FindLeafNodes(r.CfgNodeList, []*product_config_parser.TrieNode{configTree.Root})
	if err != nil {
		return nil, err
	}
	discountLineMap := map[string]*product_config_load.DiscountLine{}
	tradeCustomerDiscountLineMap := multienv.GetDiscountLineMap(quote.TradeType, false)
	for _, leafNode := range leafNodes {
		priceInfo := product_config_load.TransOtherInfoToPriceInfo(leafNode.OtherInfo)
		if item_effective.ShortOfDiscountLine(&priceInfo, tradeCustomerDiscountLineMap) ||
			priceInfo.ShortOfNonZeroChargeItem() {
			continue
		}
		chargeItemInfo := buildChargeItemInfo(leafNode.ConfigNodeList)
		// 过滤掉非当前客户范围的计费项
		if match := product_config_parser.CustomerScopeMatch(
			quote.TradeType.GetCustomerScope(),
			priceInfo.SellingCustomerScope,
		); !match {
			continue
		}

		discountLineList := priceInfo.DiscountLineList
		for _, discountLine := range discountLineList {
			discountLine.ChargeItemInfo = chargeItemInfo
			line, ok := discountLineMap[discountLine.Key]
			if !ok {
				discountLineMap[discountLine.Key] = discountLine
			} else {
				discountLineValue, _ := discountLine.Parse()
				lineValue, _ := line.Parse()
				if discountLine.Absent || discountLineValue.GreaterThan(lineValue) {
					discountLineMap[discountLine.Key] = discountLine
				}
			}
		}
	}
	return discountLineMap, err
}

func (r *GetDiscountLine) filterDiscountLine(ctx context.Context, quote *model.Quote, discountLineMap map[string]*product_config_load.DiscountLine) []*product_config_load.DiscountLine {
	var discountLines []*product_config_load.DiscountLine
	discountLineKeys := multienv.GetSellingModeDiscountLineList(quote.TradeType, true)
	for _, discountLineKey := range discountLineKeys {
		discountLine, ok := discountLineMap[discountLineKey]
		if !ok {
			continue
		}
		if !discountLine.NeedDecrypy && !multienv.NotDisplayDiscountLineKeyMap[discountLine.Key] {
			discountLines = append(discountLines, discountLine)
		}
	}
	return discountLines
}

func buildChargeItemInfo(configNodes []*product_config_parser.ConfigNode) *product_config_load.ChargeItemInfo {
	chargeItemInfo := &product_config_load.ChargeItemInfo{}

	for _, configNode := range configNodes {
		if configNode.NodeType == constants.SchemaChargeUnit {
			chargeItemInfo.ChargeUnit = configNode.NodeName
		} else if configNode.NodeType == constants.SchemaChargeMethod {
			chargeItemInfo.ChargeMethod = configNode.NodeName
		} else if configNode.NodeType == constants.SchemaRegion {
			chargeItemInfo.Region = configNode.NodeName
		} else if configNode.NodeType == constants.SchemaPriceFactor {
			chargeItemInfo.PriceFactor = configNode.NodeName
		} else if configNode.NodeType == constants.SchemaPriceType {
			arr := strings.Split(configNode.NodeKey, "::")
			chargeItemInfo.ChargeItemCode = arr[1]
		}
	}

	return chargeItemInfo
}

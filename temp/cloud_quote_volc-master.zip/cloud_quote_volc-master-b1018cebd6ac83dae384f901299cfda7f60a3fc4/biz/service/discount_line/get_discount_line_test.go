package discount_line

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func TestBuildChargeItemInfo(t *testing.T) {
	mockey.PatchConvey("TestBuildChargeItemInfo", t, func() {
		mockey.PatchConvey("success", func() {
			configNodes := []*product_config_parser.ConfigNode{
				{
					NodeType: constants.SchemaChargeUnit,
					NodeName: "小时",
				},
				{
					NodeType: constants.SchemaChargeMethod,
					NodeName: "后付费",
				},
				{
					NodeType: constants.SchemaRegion,
					NodeName: "中国大陆",
				},
				{
					NodeType: constants.SchemaPriceFactor,
					NodeName: "1",
				},
				{
					NodeType: constants.SchemaPriceType,
					NodeKey:  "priceType::test",
				},
			}
			chargeItemInfo := buildChargeItemInfo(configNodes)
			So(chargeItemInfo, ShouldResemble, &product_config_load.ChargeItemInfo{
				ChargeUnit:     "小时",
				ChargeMethod:   "后付费",
				Region:         "中国大陆",
				PriceFactor:    "1",
				ChargeItemCode: "test",
			})
		})
	})
}

func TestGetDiscountLineGetSelectAllDiscountLines(t *testing.T) {
	newLeafNode := func(priceInfo product_config_load.PriceInfo, chargeItemCode, chargeUnit string) *product_config_parser.TrieNode {
		return &product_config_parser.TrieNode{
			OtherInfo: priceInfo,
			ConfigNodeList: []*product_config_parser.ConfigNode{
				{
					NodeType: constants.SchemaChargeUnit,
					NodeName: chargeUnit,
				},
				{
					NodeType: constants.SchemaChargeMethod,
					NodeName: "后付费",
				},
				{
					NodeType: constants.SchemaRegion,
					NodeName: "华北",
				},
				{
					NodeType: constants.SchemaPriceFactor,
					NodeName: "标准",
				},
				{
					NodeType: constants.SchemaPriceType,
					NodeKey:  "priceType::" + chargeItemCode,
				},
			},
		}
	}

	t.Run("配置树为空时直接返回", func(t *testing.T) {
		mockey.PatchConvey("配置树为空时直接返回", t, func() {
			r := &GetDiscountLine{}

			result, err := r.GetSelectAllDiscountLines(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{})

			So(err, ShouldBeNil)
			So(result, ShouldBeNil)
		})
	})

	t.Run("查找叶子节点失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("查找叶子节点失败时返回错误", t, func() {
			r := &GetDiscountLine{}
			expectedErr := errors.New("find leaf nodes error")

			mockey.Mock(product_config_parser.FindLeafNodes).Return(nil, expectedErr).Build()

			result, err := r.GetSelectAllDiscountLines(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{NodeKey: "root"},
			})

			So(err, ShouldEqual, expectedErr)
			So(result, ShouldBeNil)
		})
	})

	t.Run("过滤无效叶子并保留更优折扣线", func(t *testing.T) {
		mockey.PatchConvey("过滤无效叶子并保留更优折扣线", t, func() {
			r := &GetDiscountLine{}
			quote := &model.Quote{TradeType: multienv.TradeType("test_trade_type")}

			leafNodes := []*product_config_parser.TrieNode{
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             multienv.GeneralDiscountLine,
							DiscountLineVal: "0.50",
							Type:            constants.DiscountLineTypeCommon,
							Absent:          true,
						},
					},
				}, "skip-missing", "小时"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                0,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             multienv.GeneralDiscountLine,
							DiscountLineVal: "0.60",
							Type:            constants.DiscountLineTypeCommon,
						},
					},
				}, "skip-zero", "天"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             multienv.GeneralDiscountLine,
							DiscountLineVal: "0.65",
							Type:            constants.DiscountLineTypeCommon,
						},
					},
				}, "skip-scope", "月"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             multienv.GeneralDiscountLine,
							DiscountLineVal: "0.70",
							Type:            constants.DiscountLineTypeCommon,
						},
					},
				}, "general-low", "小时"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             multienv.GeneralDiscountLine,
							DiscountLineVal: "0.90",
							Type:            constants.DiscountLineTypeCommon,
						},
					},
				}, "general-high", "天"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             "custom_line",
							DiscountLineVal: "0.10",
							Type:            constants.DiscountLineTypeCommon,
						},
					},
				}, "custom-low", "小时"),
				newLeafNode(product_config_load.PriceInfo{
					PricingFunction:      constants.PricingFunctionFixedPrice,
					Price:                100,
					SellingCustomerScope: multienv.CustomerScopeInternalAndExternal,
					DiscountLineList: []*product_config_load.DiscountLine{
						{
							Key:             "custom_line",
							DiscountLineVal: "0.20",
							Type:            constants.DiscountLineTypeCommon,
							Absent:          true,
						},
					},
				}, "custom-absent", "月"),
			}

			mockey.Mock(product_config_parser.FindLeafNodes).Return(leafNodes, nil).Build()
			mockey.Mock(multienv.GetDiscountLineMap).Return(map[string]interface{}{
				multienv.GeneralDiscountLine: struct{}{},
			}).Build()
			mockey.Mock(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()

			result, err := r.GetSelectAllDiscountLines(context.Background(), quote, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{NodeKey: "root"},
			})

			So(err, ShouldBeNil)
			So(result, ShouldNotBeNil)
			So(len(result), ShouldEqual, 2)
			So(result[multienv.GeneralDiscountLine].DiscountLineVal, ShouldEqual, "0.90")
			So(result[multienv.GeneralDiscountLine].ChargeItemInfo, ShouldResemble, &product_config_load.ChargeItemInfo{
				ChargeItemCode: "general-high",
				ChargeUnit:     "天",
				ChargeMethod:   "后付费",
				Region:         "华北",
				PriceFactor:    "标准",
			})
			So(result["custom_line"].DiscountLineVal, ShouldEqual, "0.20")
			So(result["custom_line"].Absent, ShouldBeTrue)
			So(result["custom_line"].ChargeItemInfo, ShouldResemble, &product_config_load.ChargeItemInfo{
				ChargeItemCode: "custom-absent",
				ChargeUnit:     "月",
				ChargeMethod:   "后付费",
				Region:         "华北",
				PriceFactor:    "标准",
			})
		})
	})
}

func Test_GetDiscountLine_filterDiscountLine_BitsUTGen(t *testing.T) {
	// 构造测试目标方法的接收者实例
	r := &GetDiscountLine{}
	ctx := context.Background()

	mockey.PatchConvey("Test_GetDiscountLine_filterDiscountLine", t, func() {
		mockey.PatchConvey("成功场景 - 正常过滤折扣线", func() {
			// 场景描述：
			// 模拟 GetSellingModeDiscountLineList 返回一组折扣线key。
			// discountLineMap 中包含部分key，其中一些需要解密，一些在不展示列表中。
			// 期望函数能正确过滤出符合条件的折扣线。
			// 数据构造：
			// - quote.TradeType: "Direct"
			// - discountLineMap: 包含4个折扣线
			//   - GeneralDiscountLine: 正常，应被保留
			//   - AuditFreeDiscountLine: NeedDecrypy=true, 应被过滤
			//   - DirectExceededS: 在 NotDisplayDiscountLineKeyMap 中，应被过滤
			//   - ExceededDiscountLine: 正常，应被保留
			// 逻辑链路：
			// 1. Mock multienv.GetSellingModeDiscountLineList 返回 ["GeneralDiscountLine", "AuditFreeDiscountLine", "DirectExceededS", "ExceededDiscountLine", "NonExistentKey"]。
			// 2. 函数遍历key列表。
			// 3. "GeneralDiscountLine" 和 "ExceededDiscountLine" 通过所有检查，被添加到结果中。
			// 4. "AuditFreeDiscountLine" 因 NeedDecrypy=true 被跳过。
			// 5. "DirectExceededS" 因存在于 multienv.NotDisplayDiscountLineKeyMap 被跳过。
			// 6. "NonExistentKey" 因在 discountLineMap 中不存在而被跳过。
			// 7. 验证返回的切片包含2个正确的折扣线。

			// 数据构造
			quote := &model.Quote{
				TradeType: "Direct",
			}
			discountLineMap := map[string]*product_config_load.DiscountLine{
				multienv.GeneralDiscountLine: {
					Key:         multienv.GeneralDiscountLine,
					NeedDecrypy: false,
				},
				multienv.AuditFreeDiscountLine: {
					Key:         multienv.AuditFreeDiscountLine,
					NeedDecrypy: true, // 应被过滤
				},
				multienv.DirectExceededS: {
					Key:         multienv.DirectExceededS,
					NeedDecrypy: false, // 应被过滤 (在 NotDisplayDiscountLineKeyMap 中)
				},
				multienv.ExceededDiscountLine: {
					Key:         multienv.ExceededDiscountLine,
					NeedDecrypy: false,
				},
			}

			// Mock
			mockey.Mock(multienv.GetSellingModeDiscountLineList).Return([]string{
				multienv.GeneralDiscountLine,
				multienv.AuditFreeDiscountLine,
				multienv.DirectExceededS,
				multienv.ExceededDiscountLine,
				"NonExistentKey",
			}).Build()

			// 调用
			result := r.filterDiscountLine(ctx, quote, discountLineMap)

			// 断言
			So(result, ShouldNotBeNil)
			So(len(result), ShouldEqual, 2)
			So(result[0].Key, ShouldEqual, multienv.GeneralDiscountLine)
			So(result[1].Key, ShouldEqual, multienv.ExceededDiscountLine)
		})

		mockey.PatchConvey("成功场景 - 所有折扣线都被过滤", func() {
			// 场景描述：
			// GetSellingModeDiscountLineList 返回的 key 对应的折扣线均不满足条件（需要解密或在不展示列表）。
			// 期望返回一个空切片。
			// 数据构造：
			// - quote.TradeType: "Direct"
			// - discountLineMap:
			//   - GeneralDiscountLine: NeedDecrypy=true, 应被过滤
			//   - DirectExceededS: 在 NotDisplayDiscountLineKeyMap 中，应被过滤
			// 逻辑链路：
			// 1. Mock multienv.GetSellingModeDiscountLineList 返回 ["GeneralDiscountLine", "DirectExceededS"]。
			// 2. "GeneralDiscountLine" 因 NeedDecrypy=true 被跳过。
			// 3. "DirectExceededS" 因存在于 multienv.NotDisplayDiscountLineKeyMap 被跳过。
			// 4. 验证返回的切片为空。

			// 数据构造
			quote := &model.Quote{
				TradeType: "Direct",
			}
			discountLineMap := map[string]*product_config_load.DiscountLine{
				multienv.GeneralDiscountLine: {
					Key:         multienv.GeneralDiscountLine,
					NeedDecrypy: true,
				},
				multienv.DirectExceededS: {
					Key:         multienv.DirectExceededS,
					NeedDecrypy: false,
				},
			}

			// Mock
			mockey.Mock(multienv.GetSellingModeDiscountLineList).Return([]string{
				multienv.GeneralDiscountLine,
				multienv.DirectExceededS,
			}).Build()

			// 调用
			result := r.filterDiscountLine(ctx, quote, discountLineMap)

			// 断言
			So(result, ShouldBeEmpty)
		})

		mockey.PatchConvey("边界场景 - GetSellingModeDiscountLineList返回空", func() {
			// 场景描述：
			// 依赖的 multienv.GetSellingModeDiscountLineList 函数返回一个空切片。
			// 期望函数直接返回一个空切片，不进行任何处理。
			// 数据构造：
			// - quote.TradeType: "Direct"
			// - discountLineMap: 包含一些数据，但不应被使用
			// 逻辑链路：
			// 1. Mock multienv.GetSellingModeDiscountLineList 返回 []string{}。
			// 2. 函数的 for 循环不会执行。
			// 3. 验证返回的切片为空。

			// 数据构造
			quote := &model.Quote{
				TradeType: "Direct",
			}
			discountLineMap := map[string]*product_config_load.DiscountLine{
				multienv.GeneralDiscountLine: {
					Key:         multienv.GeneralDiscountLine,
					NeedDecrypy: false,
				},
			}

			// Mock
			mockey.Mock(multienv.GetSellingModeDiscountLineList).Return([]string{}).Build()

			// 调用
			result := r.filterDiscountLine(ctx, quote, discountLineMap)

			// 断言
			So(result, ShouldBeEmpty)
		})

		mockey.PatchConvey("边界场景 - discountLineMap为空", func() {
			// 场景描述：
			// 传入的 discountLineMap 为空。
			// 期望函数直接返回一个空切片，因为所有 key 在 map 中都找不到。
			// 数据构造：
			// - quote.TradeType: "Direct"
			// - discountLineMap: 空 map
			// 逻辑链路：
			// 1. Mock multienv.GetSellingModeDiscountLineList 返回一些 key。
			// 2. 函数遍历 key 列表，但在 discountLineMap 中查找时总是失败 (ok=false)。
			// 3. 验证返回的切片为空。

			// 数据构造
			quote := &model.Quote{
				TradeType: "Direct",
			}
			discountLineMap := make(map[string]*product_config_load.DiscountLine)

			// Mock
			mockey.Mock(multienv.GetSellingModeDiscountLineList).Return([]string{
				multienv.GeneralDiscountLine,
				multienv.ExceededDiscountLine,
			}).Build()

			// 调用
			result := r.filterDiscountLine(ctx, quote, discountLineMap)

			// 断言
			So(result, ShouldBeEmpty)
		})

		mockey.PatchConvey("成功场景 - 所有折扣线都符合条件", func() {
			// 场景描述：
			// GetSellingModeDiscountLineList 返回的 key 对应的折扣线都满足条件。
			// 期望返回所有这些折扣线。
			// 数据构造：
			// - quote.TradeType: "Direct"
			// - discountLineMap:
			//   - GeneralDiscountLine: 正常
			//   - ExceededDiscountLine: 正常
			// 逻辑链路：
			// 1. Mock multienv.GetSellingModeDiscountLineList 返回 ["GeneralDiscountLine", "ExceededDiscountLine"]。
			// 2. "GeneralDiscountLine" 通过检查，被添加。
			// 3. "ExceededDiscountLine" 通过检查，被添加。
			// 4. 验证返回的切片包含2个折扣线。

			// 数据构造
			quote := &model.Quote{
				TradeType: "Direct",
			}
			discountLineMap := map[string]*product_config_load.DiscountLine{
				multienv.GeneralDiscountLine: {
					Key:         multienv.GeneralDiscountLine,
					NeedDecrypy: false,
				},
				multienv.ExceededDiscountLine: {
					Key:         multienv.ExceededDiscountLine,
					NeedDecrypy: false,
				},
			}
			// Mock
			mockey.Mock(multienv.GetSellingModeDiscountLineList).Return([]string{
				multienv.GeneralDiscountLine,
				multienv.ExceededDiscountLine,
			}).Build()

			// 调用
			result := r.filterDiscountLine(ctx, quote, discountLineMap)

			// 断言
			So(result, ShouldNotBeNil)
			So(len(result), ShouldEqual, 2)
			So(result[0].Key, ShouldEqual, multienv.GeneralDiscountLine)
			So(result[1].Key, ShouldEqual, multienv.ExceededDiscountLine)
		})
	})
}

func Test_GetDiscountLine_getDiscountLines_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_GetDiscountLine_getDiscountLines", t, func() {
		ctx := context.Background()
		// 使用一个空的 gorm.DB 实例，因为所有数据库操作都将被 mock
		mockTx := &gorm.DB{}
		r := &GetDiscountLine{
			TradeProduct: "test_product",
			QuoteID:      1,
			CfgNodeList:  []*product_config_parser.ConfigNode{},
		}

		mockey.PatchConvey("成功场景", func() {
			// 准备模拟数据
			mockQuote := &model.Quote{
				TradeType:        multienv.TradeType("some_type"),
				ContractPriceAcc: "acc123",
			}
			mockProductInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     int(multienv.TradeProductTypeOnline),
				StandardProduct: 1,
			}
			mockContainer := &product_config_load.ConfigContainer{}
			mockConfigTree := &product_config_parser.StandardConfigTree{}
			mockDiscountLineMap := map[string]*product_config_load.DiscountLine{
				"key1": {Key: "key1"},
			}
			mockFilteredLines := []*product_config_load.DiscountLine{
				{Key: "key1_filtered"},
			}

			// 设定模拟行为
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(mockQuote, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(mockProductInfo, nil).Build()
			mockey.Mock(config_option_service.AppendExcludeDetail).Return().Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock((*model.Quote).GetConstraintAccountIDs).Return([]int64{1001}).Build()
			mockey.Mock(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeInternal).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).Return(mockConfigTree, nil).Build()
			// 假设 GetSelectAllDiscountLines 和 filterDiscountLine 被正确测试，这里将其作为黑盒 mock
			mockey.Mock((*GetDiscountLine).GetSelectAllDiscountLines).Return(mockDiscountLineMap, nil).Build()
			mockey.Mock((*GetDiscountLine).filterDiscountLine).Return(mockFilteredLines).Build()

			// 执行被测函数
			result, err := r.getDiscountLines(ctx, mockTx)

			// 断言结果
			So(err, ShouldBeNil)
			So(result, ShouldResemble, mockFilteredLines)
		})

		mockey.PatchConvey("失败场景 - dal.QuoteDao.FindQuoteByID 返回错误", func() {
			expectedErr := errors.New("database query error")
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(nil, expectedErr).Build()

			result, err := r.getDiscountLines(ctx, mockTx)

			So(result, ShouldBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("失败场景 - commodity_service.GetProductInfoFromCache 返回错误", func() {
			mockQuote := &model.Quote{}
			expectedErr := errors.New("get product info error")
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(mockQuote, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(nil, expectedErr).Build()

			result, err := r.getDiscountLines(ctx, mockTx)

			So(result, ShouldBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("失败场景 - product_config_load.GetConfigContainer 返回错误", func() {
			mockQuote := &model.Quote{}
			mockProductInfo := &trade_client.TradeProductVersionInfo{}
			expectedErr := errors.New("get config container error")
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(mockQuote, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(mockProductInfo, nil).Build()
			mockey.Mock(config_option_service.AppendExcludeDetail).Return().Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(nil, expectedErr).Build()

			result, err := r.getDiscountLines(ctx, mockTx)

			So(result, ShouldBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("失败场景 - container.GetConfigFromCache 返回错误", func() {
			mockQuote := &model.Quote{TradeType: multienv.TradeType("some_type")}
			mockProductInfo := &trade_client.TradeProductVersionInfo{}
			mockContainer := &product_config_load.ConfigContainer{}
			expectedErr := errors.New("get config from cache error")

			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(mockQuote, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(mockProductInfo, nil).Build()
			mockey.Mock(config_option_service.AppendExcludeDetail).Return().Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock((*model.Quote).GetConstraintAccountIDs).Return(nil).Build()
			mockey.Mock(multienv.TradeType.GetCustomerScope).Return("").Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).Return(nil, expectedErr).Build()

			result, err := r.getDiscountLines(ctx, mockTx)

			So(result, ShouldBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("失败场景 - r.GetSelectAllDiscountLines 返回错误", func() {
			mockQuote := &model.Quote{TradeType: multienv.TradeType("some_type")}
			mockProductInfo := &trade_client.TradeProductVersionInfo{}
			mockContainer := &product_config_load.ConfigContainer{}
			mockConfigTree := &product_config_parser.StandardConfigTree{}
			expectedErr := errors.New("get select all discount lines error")
			// 即使有错误，filterDiscountLine 仍然会被调用，这里模拟它返回一个空切片
			mockFilteredLines := []*product_config_load.DiscountLine{}

			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(mockQuote, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(mockProductInfo, nil).Build()
			mockey.Mock(config_option_service.AppendExcludeDetail).Return().Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock((*model.Quote).GetConstraintAccountIDs).Return(nil).Build()
			mockey.Mock(multienv.TradeType.GetCustomerScope).Return("").Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).Return(mockConfigTree, nil).Build()
			mockey.Mock((*GetDiscountLine).GetSelectAllDiscountLines).Return(nil, expectedErr).Build()
			mockey.Mock((*GetDiscountLine).filterDiscountLine).Return(mockFilteredLines).Build()

			result, err := r.getDiscountLines(ctx, mockTx)

			// 验证错误是否被正确传递
			So(err, ShouldEqual, expectedErr)
			// 验证即使在错误情况下，返回值也是 filterDiscountLine 的结果
			So(result, ShouldResemble, mockFilteredLines)
		})
	})
}

package config_option_service

import (
	"encoding/json"
	"fmt"
)

type MdInfoModel struct {
	OtherPartyMdmCode string
	PaymentType       string
	BankAccount       string
	BankName          string
	Name              string
	CountryName       string
	CountryCode       string
}

func (mi *MdInfoModel) GetInfo() string {
	return fmt.Sprintf("%s(%s) %s", mi.Name, mi.OtherPartyMdmCode, mi.CountryName)
}

func GenMdInfoList(mdInfoStr string) ([]*MdInfoModel, error) {
	var mdInfoModelArr []*MdInfoModel
	if mdInfoStr == "" {
		return mdInfoModelArr, nil
	}
	if err := json.Unmarshal([]byte(mdInfoStr), &mdInfoModelArr); err != nil {
		return nil, err
	}
	return mdInfoModelArr, nil
}

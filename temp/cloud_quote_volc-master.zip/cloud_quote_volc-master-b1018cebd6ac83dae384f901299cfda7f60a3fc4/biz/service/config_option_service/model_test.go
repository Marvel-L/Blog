package config_option_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"encoding/json"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"github.com/stretchr/testify/assert"
	"regexp"
	"testing"
)

func backTestDiscount_CalcGiveAwayType(t *testing.T) {

	var cases = []struct {
		Info string
		Ret  string
	}{
		{
			Info: `{
			"PricingFunction": "time_discount",
			"UnitPriceInterval": "{\"BM000101\":\"0.95,0.85,0.75\",\"BM000030\":\"0.95,0.85,0.75\",\"BM000037\":\"0.95,0.85,0.75\"}",
			"MeasureInterval": "{\"BM000101\":\"9,8,7\",\"BM000030\":\"9,8,7\",\"BM000037\":\"9,8,7\"}",
			"UnitPrice": null
		}`,
			Ret: multienv.GiveAwayTypeDefault,
		},
		{
			Info: `{
			"PricingFunction": "time_discount",
			"UnitPriceInterval": "{\"BM000101\":\"0,0.85,0.75\",\"BM000030\":\"0.95,0.85,0.75\",\"BM000037\":\"0.95,0.85,0.75\"}",
			"MeasureInterval": "{\"BM000101\":\"9,8,7\",\"BM000030\":\"9,8,7\",\"BM000037\":\"9,8,7\"}",
			"UnitPrice": null
		}`,
			Ret: multienv.GetGiveAwayTypeRange(),
		},
	}

	for _, c := range cases {
		var discount Discount
		_ = json.Unmarshal([]byte(c.Info), &discount)
		awayType := discount.CalcGiveAwayType()
		assert.True(t, awayType == c.Ret)
		//t.Log(awayType)
	}

}

func backTestValidateItemDiscount(t *testing.T) {

	discnt := &Discount{
		PricingFunction:   "",
		UnitPriceInterval: "0,0,0",
		MeasureInterval:   "0,100000,200000",
		UnitPrice:         decimal.Zero,
	}

	err := discnt.ValidateProgressiveDiscount()
	t.Log(err)

}

func backTestPattern(t *testing.T) {

	list := []string{
		"0,0.1",
		"0,0,0",
		"1,0.8,,,,",
	}

	for _, v := range list {
		match, err := regexp.MatchString(unitPriceIntervalPattern, v)
		//assert.Nil(t, err)
		//assert.True(t, match)
		t.Log(err)
		t.Log(match)
	}
}

func Test_Discount_GetQuotePriceDiscount_BitsUTGen(t *testing.T) {
	t.Run("场景一: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 合法, 成功找到最小折扣", func(t *testing.T) {
		mockey.PatchConvey("场景一: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 合法, 成功找到最小折扣", t, func() {
			// 场景描述:
			// 构造数据: Discount 的 PricingFunction 为 DiscountFunctionTotalOverAmountDiscount, UnitPriceInterval 为 "0.9,0.8,0.95"。
			// 逻辑链路:
			// 1. 函数进入 PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount 的 if 分支。
			// 2. strings.Split 将 "0.9,0.8,0.95" 分割为字符串切片。
			// 3. 循环遍历切片, Mock decimal.NewFromString 分别为 "0.9", "0.8", "0.95" 返回对应的 decimal 对象和 nil error。
			// 4. Mock decimal.Decimal.LessThan 方法来模拟比较过程，最终确定最小折扣为 0.8。
			// 5. Mock 最小折扣 decimal 对象的 String() 方法返回 "0.8"。
			// 6. 函数返回一个 BillingFunction 为 simple_discount 且 UnitPrice 为 "0.8" 的 ContractDiscount 对象。
			d := &Discount{
				PricingFunction:   constants.DiscountFunctionTotalOverAmountDiscount,
				UnitPriceInterval: "0.9,0.8,0.95",
			}

			dec9, _ := decimal.NewFromString("0.9")
			dec8, _ := decimal.NewFromString("0.8")
			dec95, _ := decimal.NewFromString("0.95")

			mockey.Mock(decimal.NewFromString).To(func(s string) (decimal.Decimal, error) {
				switch s {
				case "0.9":
					return dec9, nil
				case "0.8":
					return dec8, nil
				case "0.95":
					return dec95, nil
				}
				return decimal.Zero, errors.New("unexpected input")
			}).Build()

			// 逻辑: minDiscount 初始为 1
			// 1. 0.9 < 1 ? -> true. minDiscount = 0.9
			// 2. 0.8 < 0.9 ? -> true. minDiscount = 0.8
			// 3. 0.95 < 0.8 ? -> false. minDiscount = 0.8
			mockey.Mock(decimal.Decimal.LessThan).Return(mockey.Sequence(true).Then(true).Then(false)).Build()

			mockey.Mock(decimal.Decimal.String).When(func(dec decimal.Decimal) bool {
				return dec.Equals(dec8) // 最终的 minDiscount 是 dec8
			}).Return("0.8").Build()

			result, err := d.GetQuotePriceDiscount()

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.BillingFunction, convey.ShouldEqual, constants.DiscountFunctionSimpleDiscount)
			convey.So(result.UnitPrice, convey.ShouldEqual, "0.8")
		})
	})

	t.Run("场景二: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 包含非法字符, 返回错误", func(t *testing.T) {
		mockey.PatchConvey("场景二: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 包含非法字符, 返回错误", t, func() {
			// 场景描述:
			// 构造数据: Discount 的 PricingFunction 为 DiscountFunctionTotalOverAmountDiscount, UnitPriceInterval 包含非法数值 "invalid"。
			// 逻辑链路:
			// 1. 函数进入 PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount 的 if 分支。
			// 2. 当循环到 "invalid" 时, Mock decimal.NewFromString 返回一个错误。
			// 3. 函数应立即捕获并返回该错误。
			d := &Discount{
				PricingFunction:   constants.DiscountFunctionTotalOverAmountDiscount,
				UnitPriceInterval: "0.9,invalid",
			}

			dec9, _ := decimal.NewFromString("0.9")
			mockErr := errors.New("invalid number")

			mockey.Mock(decimal.NewFromString).To(func(s string) (decimal.Decimal, error) {
				if s == "0.9" {
					return dec9, nil
				}
				if s == "invalid" {
					return decimal.Decimal{}, mockErr
				}
				return decimal.Zero, nil
			}).Build()

			result, err := d.GetQuotePriceDiscount()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "invalid")
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("场景三: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 包含空字符串", func(t *testing.T) {
		mockey.PatchConvey("场景三: PricingFunction 为 total_over_amount_discount, UnitPriceInterval 包含空字符串", t, func() {
			// 场景描述:
			// 构造数据: Discount 的 PricingFunction 为 DiscountFunctionTotalOverAmountDiscount, UnitPriceInterval 包含一个空字符串 ",,"。
			// 逻辑链路:
			// 1. 函数进入 PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount 的 if 分支。
			// 2. strings.Split 结果包含一个空字符串。
			// 3. 循环时, if price == "" 条件为 true, continue, 跳过空字符串的处理。
			// 4. 函数应正常处理其他有效值并返回最小折扣。
			d := &Discount{
				PricingFunction:   constants.DiscountFunctionTotalOverAmountDiscount,
				UnitPriceInterval: "0.9,,0.8",
			}

			dec9, _ := decimal.NewFromString("0.9")
			dec8, _ := decimal.NewFromString("0.8")

			mockey.Mock(decimal.NewFromString).To(func(s string) (decimal.Decimal, error) {
				if s == "0.9" {
					return dec9, nil
				}
				if s == "0.8" {
					return dec8, nil
				}
				return decimal.Zero, nil
			}).Build()

			mockey.Mock(decimal.Decimal.LessThan).Return(mockey.Sequence(true).Then(true)).Build()
			mockey.Mock(decimal.Decimal.String).When(func(dec decimal.Decimal) bool {
				return dec.Equals(dec8)
			}).Return("0.8").Build()

			result, err := d.GetQuotePriceDiscount()

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.UnitPrice, convey.ShouldEqual, "0.8")
		})
	})

	t.Run("场景四: PricingFunction 为 time_discount, 成功解析并更新 Interval", func(t *testing.T) {
		mockey.PatchConvey("场景四: PricingFunction 为 time_discount, 成功解析并更新 Interval", t, func() {
			// 场景描述:
			// 构造数据: Discount 的 PricingFunction 为 DiscountFunctionTimeDiscount, UnitPriceInterval 和 MeasureInterval 为合法的 JSON 字符串。
			// 逻辑链路:
			// 1. 函数进入 PricingFunction == constants.DiscountFunctionTimeDiscount 的 if 分支。
			// 2. json.Unmarshal 成功解析 interval 字符串到 map。
			// 3. for 循环遍历 map (只有一个元素), 提取 value 更新 d 的 MeasureInterval 和 UnitPriceInterval 字段。
			// 4. Mock d.UnitPrice 的 String() 方法。
			// 5. 函数返回一个包含更新后 interval 的 ContractDiscount 对象。
			d := &Discount{
				PricingFunction:   constants.DiscountFunctionTimeDiscount,
				UnitPriceInterval: `{"TIME_01":"0.85"}`,
				MeasureInterval:   `{"TIME_01":"1000"}`,
				UnitPrice:         decimal.NewFromInt(1),
			}

			mockey.Mock(decimal.Decimal.String).When(func(dec decimal.Decimal) bool {
				return dec.Equals(d.UnitPrice)
			}).Return("1").Build()

			result, err := d.GetQuotePriceDiscount()

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.BillingFunction, convey.ShouldEqual, constants.DiscountFunctionTimeDiscount)
			convey.So(result.UnitPrice, convey.ShouldEqual, "1")
			convey.So(result.MeasureInterval, convey.ShouldEqual, "1000")
			convey.So(result.UnitPriceInterval, convey.ShouldEqual, "0.85")
		})
	})

	t.Run("场景五: PricingFunction 为其他类型 (simple_discount), 直接返回原始值", func(t *testing.T) {
		mockey.PatchConvey("场景五: PricingFunction 为其他类型 (simple_discount), 直接返回原始值", t, func() {
			// 场景描述:
			// 构造数据: Discount 的 PricingFunction 为 DiscountFunctionSimpleDiscount。
			// 逻辑链路:
			// 1. 函数不进入任何特定的 if 分支。
			// 2. Mock d.UnitPrice 的 String() 方法。
			// 3. 函数直接使用 d 的原始字段构建并返回 ContractDiscount 对象。
			unitPrice, _ := decimal.NewFromString("0.99")
			d := &Discount{
				PricingFunction:   constants.DiscountFunctionSimpleDiscount,
				UnitPriceInterval: "interval_val",
				MeasureInterval:   "measure_val",
				UnitPrice:         unitPrice,
			}

			mockey.Mock(decimal.Decimal.String).When(func(dec decimal.Decimal) bool {
				return dec.Equals(unitPrice)
			}).Return("0.99").Build()

			result, err := d.GetQuotePriceDiscount()

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.BillingFunction, convey.ShouldEqual, constants.DiscountFunctionSimpleDiscount)
			convey.So(result.UnitPrice, convey.ShouldEqual, "0.99")
			convey.So(result.MeasureInterval, convey.ShouldEqual, "measure_val")
			convey.So(result.UnitPriceInterval, convey.ShouldEqual, "interval_val")
		})
	})
}

func Test_CommonItem_GetConfigTreeKey_BitsUTGen(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("验证CommonItem.GetConfigTreeKey", t, func() {
			mockey.PatchConvey("抵扣报价项返回商品与SP包组合键", func() {
				item := &CommonItem{
					TradeProduct:     "ecs",
					ItemBusinessRole: constants.QuoteItemBusinessRoleDeduct,
					SpPkgInfo: &model.SpPkgInfo{
						ProductCode:           "prod",
						ConfigurationCode:     "conf",
						SpBuyDurationCode:     "dur",
						CommitFeeIntervalCode: "fee",
					},
				}

				got := item.GetConfigTreeKey()

				assert.Equal(t, "ecs::prod::conf::dur::fee", got)
			})

			mockey.PatchConvey("非抵扣报价项仅返回商品编码", func() {
				item := &CommonItem{
					TradeProduct:     "vpc",
					ItemBusinessRole: 0,
					SpPkgInfo: &model.SpPkgInfo{
						ProductCode:           "ignoredProd",
						ConfigurationCode:     "ignoredConf",
						SpBuyDurationCode:     "ignoredDur",
						CommitFeeIntervalCode: "ignoredFee",
					},
				}

				got := item.GetConfigTreeKey()

				assert.Equal(t, "vpc", got)
			})
		})
	})
}

func Test_Discount_NoDiscount_BitsUTGen(t *testing.T) {
	t.Run("验证无折扣判断", func(t *testing.T) {
		mockey.PatchConvey("验证无折扣判断方法", t, func() {
			mockey.PatchConvey("定价函数为简单折扣且单价等于一时返回真", func() {
				discount := &Discount{
					PricingFunction: constants.DiscountFunctionSimpleDiscount,
					UnitPrice:       decimal.NewFromInt(1),
				}

				result := discount.NoDiscount()

				assert.True(t, result)
			})

			mockey.PatchConvey("定价函数不是简单折扣时返回假", func() {
				discount := &Discount{
					PricingFunction: "other_discount",
					UnitPrice:       decimal.NewFromInt(1),
				}

				result := discount.NoDiscount()

				assert.False(t, result)
			})

			mockey.PatchConvey("定价函数为简单折扣但单价不等于一时返回假", func() {
				discount := &Discount{
					PricingFunction: constants.DiscountFunctionSimpleDiscount,
					UnitPrice:       decimal.NewFromInt(2),
				}

				result := discount.NoDiscount()

				assert.False(t, result)
			})
		})
	})
}

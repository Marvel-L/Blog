package config_option_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type TplItemValuesGenerator struct {
	FormValues        map[string]interface{}
	ConfigNodes       []*product_config_parser.ConfigNode
	TemplateItem      *model.TemplateItem
	CurrentUser       string
	ProductInfo       *trade_client.TradeProductVersionInfo
	OptionEnumDescMap map[string]map[string]string
}

func (g *TplItemValuesGenerator) ConfigNodesToTemplateItemValues() ([]*model.TemplateItemValue, error) {

	var (
		formValues        = g.FormValues
		configNodes       = g.ConfigNodes
		templateItem      = g.TemplateItem
		currentUser       = g.CurrentUser
		productInfo       = g.ProductInfo
		optionEnumDescMap = g.OptionEnumDescMap
	)

	cfgNodeMap := map[string]*product_config_parser.ConfigNode{}

	for _, cfgNode := range configNodes {
		cfgNodeMap[cfgNode.NodeType] = cfgNode
	}

	schemaMap := dal.FormSchemaMap[util.GetMapKey(constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)]
	var tplItemValues []*model.TemplateItemValue

	for schemaKey, formSchema := range schemaMap {
		formValue, ok := formValues[schemaKey]
		configNode, nodeOk := cfgNodeMap[schemaKey]
		if ok || nodeOk {
			var templateItemValue *model.TemplateItemValue
			if nodeOk {
				templateItemValue = &model.TemplateItemValue{
					TemplateID:            templateItem.TemplateID,
					TemplateItemID:        templateItem.Id,
					TemplateItemValue:     configNode.NodeKey,
					FormSchemaID:          formSchema.Id,
					FormSchemaKey:         formSchema.AttrKey,
					CreatorAccountID:      currentUser,
					FormSchemaDisplay:     formSchema.DisplayName,
					FormSchemaAttrType:    formSchema.AttrType,
					OptionEnumDescription: configNode.NodeName,
				}
			} else {
				val := fmt.Sprintf("%v", formValue)
				if f, typeOk := formValue.(float64); typeOk {
					val = fmt.Sprintf("%.2f", f)
				}
				desc := val
				if s, descOk := optionEnumDescMap[schemaKey][val]; descOk {
					desc = s
				}
				templateItemValue = &model.TemplateItemValue{
					TemplateID:            templateItem.TemplateID,
					TemplateItemID:        templateItem.Id,
					TemplateItemValue:     val,
					FormSchemaID:          formSchema.Id,
					FormSchemaKey:         formSchema.AttrKey,
					CreatorAccountID:      currentUser,
					FormSchemaDisplay:     formSchema.DisplayName,
					FormSchemaAttrType:    formSchema.AttrType,
					OptionEnumDescription: desc,
				}
			}
			tplItemValues = append(tplItemValues, templateItemValue)

		} else {
			if formSchema.AttrRequired == constants.FormSchemaAttrRequired {
				return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(context.Background(), "formValues动态字段数据不全，字段：%s", schemaKey))
			}
		}

	}
	return tplItemValues, nil
}

func TemplateItemToCommon(templateItem *model.TemplateItem) *CommonItem {
	return &CommonItem{
		PricingVersion:   templateItem.PricingVersion,
		ItemSource:       constants.ItemSourceTemplate,
		ItemID:           templateItem.Id,
		BelongToID:       templateItem.TemplateID,
		TradeProduct:     templateItem.TradeProduct,
		TradeProductName: templateItem.TradeProductName,
		ItemType:         templateItem.ItemType,
		StandardProduct:  templateItem.StandardProduct,
		ItemScene:        constants.ItemSceneQuoteItem,
		SolutionID:       templateItem.TemplateSolutionID,
		ItemStatus:       templateItem.ItemStatus,
		GiveAwayType:     templateItem.GiveAwayType,
		GenerateType:     constants.GenerateTypeDefault,
		IsZeroPrice:      templateItem.IsZeroPrice,
		SalesMode:        templateItem.SalesMode,
	}
}

func TemplateItemArrToCommon(templateItems []*model.TemplateItem) []*CommonItem {
	var commonItemArr []*CommonItem
	for _, templateItem := range templateItems {
		commonItemArr = append(commonItemArr, TemplateItemToCommon(templateItem))
	}
	return commonItemArr
}

func TemplateItemValueArrToCommon(templateItemValues []*model.TemplateItemValue) []*CommonItemValue {
	var commonItemValueArr []*CommonItemValue
	for _, templateItemValue := range templateItemValues {
		commonItemValueArr = append(commonItemValueArr, &CommonItemValue{
			ItemID:                templateItemValue.TemplateItemID,
			BelongToID:            templateItemValue.TemplateID,
			FormSchemaKey:         templateItemValue.FormSchemaKey,
			ItemValue:             templateItemValue.TemplateItemValue,
			OptionEnumDescription: templateItemValue.OptionEnumDescription,
		})
	}
	return commonItemValueArr
}

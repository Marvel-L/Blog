package config_option_service

type OptionHandler interface {
	RemoveConfigRelated() error
}

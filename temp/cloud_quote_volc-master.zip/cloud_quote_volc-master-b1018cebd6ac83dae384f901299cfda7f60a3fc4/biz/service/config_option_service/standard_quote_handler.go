package config_option_service

import (
	"context"
	"encoding/json"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

type QuoteItemValuesGenerator struct {
	FormValues        map[string]interface{}
	ConfigNodes       []*product_config_parser.ConfigNode
	QuoteItem         *model.QuoteItem
	CurrentUser       string
	ProductInfo       *trade_client.TradeProductVersionInfo
	OptionEnumDescMap map[string]map[string]string
}

func (g *QuoteItemValuesGenerator) ConfigNodesToQuoteItemValues(
	ctx context.Context) ([]*model.QuoteItemValue, error) {
	var (
		formValues        = g.FormValues
		configNodes       = g.ConfigNodes
		quoteItem         = g.QuoteItem
		currentUser       = g.CurrentUser
		productInfo       = g.ProductInfo
		optionEnumDescMap = g.OptionEnumDescMap
	)
	cfgNodeMap := map[string]*product_config_parser.ConfigNode{}

	for _, cfgNode := range configNodes {
		cfgNodeMap[cfgNode.NodeType] = cfgNode
	}

	schemaMap := dal.FormSchemaMap[util.GetMapKey(constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)]
	var quoteItemValues []*model.QuoteItemValue

	for schemaKey, formSchema := range schemaMap {
		formValue, ok := formValues[schemaKey]
		if ok {
			var quoteItemValue *model.QuoteItemValue
			configNode, nodeOk := cfgNodeMap[schemaKey]
			if nodeOk {
				quoteItemValue = &model.QuoteItemValue{
					QuoteID:               quoteItem.QuoteID,
					QuoteItemID:           quoteItem.Id,
					QuoteItemValue:        configNode.NodeKey,
					FormSchemaID:          formSchema.Id,
					FormSchemaKey:         formSchema.AttrKey,
					CreatorAccountID:      currentUser,
					FormSchemaDisplay:     formSchema.DisplayName,
					FormSchemaAttrType:    formSchema.AttrType,
					OptionEnumDescription: configNode.NodeName,
					ExcludeDetail:         configNode.ExcludeDetailStr,
				}
			} else {
				val := fmt.Sprintf("%v", formValue)
				if f, typeOk := formValue.(float64); typeOk {
					val = fmt.Sprintf("%.2f", f)
				}
				desc := val
				if s, descOk := optionEnumDescMap[schemaKey][val]; descOk {
					desc = s
				}
				quoteItemValue = &model.QuoteItemValue{
					QuoteID:               quoteItem.QuoteID,
					QuoteItemID:           quoteItem.Id,
					QuoteItemValue:        val,
					FormSchemaID:          formSchema.Id,
					FormSchemaKey:         formSchema.AttrKey,
					CreatorAccountID:      currentUser,
					FormSchemaDisplay:     formSchema.DisplayName,
					FormSchemaAttrType:    formSchema.AttrType,
					OptionEnumDescription: desc,
				}
			}
			if schemaKey == constants.SchemaDiscount {
				quoteItemValue.QuoteItemValue = assignDiscount(ctx, quoteItemValue.QuoteItemValue)
				quoteItemValue.OptionEnumDescription = quoteItemValue.QuoteItemValue
			}
			quoteItemValues = append(quoteItemValues, quoteItemValue)
		} else {
			if formSchema.AttrRequired == constants.FormSchemaAttrRequired {
				return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "formValues动态字段数据不全，字段：%s", schemaKey))
			}
		}
	}
	return quoteItemValues, nil
}

func ConfigNodesToCommonValues(
	ctx context.Context,
	formValues map[string]interface{},
	configNodes []*product_config_parser.ConfigNode,
	commonItem *CommonItem,
	currentUser string,
	productType constants.ProductType,
	standardProduct int,
) ([]*CommonItemValue, error) {

	cfgNodeMap := map[string]*product_config_parser.ConfigNode{}

	for _, cfgNode := range configNodes {
		cfgNodeMap[cfgNode.NodeType] = cfgNode
	}

	schemaMap := dal.FormSchemaMap[util.GetMapKey(productType, standardProduct)]
	var commonItemValues []*CommonItemValue

	for schemaKey, formSchema := range schemaMap {
		formValue, ok := formValues[schemaKey]
		if ok {
			var commonItemValue *CommonItemValue
			configNode, nodeOk := cfgNodeMap[schemaKey]
			if nodeOk {
				commonItemValue = &CommonItemValue{
					ItemID:                commonItem.ItemID,
					BelongToID:            commonItem.BelongToID,
					FormSchemaKey:         formSchema.AttrKey,
					ItemValue:             configNode.NodeKey,
					OptionEnumDescription: configNode.NodeName,
				}
			} else {
				val := fmt.Sprintf("%v", formValue)
				if f, typeOk := formValue.(float64); typeOk {
					val = fmt.Sprintf("%.2f", f)
				}
				commonItemValue = &CommonItemValue{
					ItemID:                commonItem.ItemID,
					BelongToID:            commonItem.BelongToID,
					FormSchemaKey:         formSchema.AttrKey,
					ItemValue:             val,
					OptionEnumDescription: val,
				}
			}
			if schemaKey == constants.SchemaDiscount {
				commonItemValue.ItemValue = assignDiscount(ctx, commonItemValue.ItemValue)
				commonItemValue.OptionEnumDescription = commonItemValue.ItemValue
			}
			commonItemValues = append(commonItemValues, commonItemValue)
		}
	}
	return commonItemValues, nil
}

func assignDiscount(ctx context.Context, s string) string {
	var discount DiscountV2
	err := json.Unmarshal([]byte(s), &discount)
	if err != nil {
		logs.CtxError(ctx, "discountUnmarshalFail, s=%s, err=%s", s, err.Error())
		return s
	}
	discount.Assigned = true
	body, _ := json.Marshal(discount)
	return string(body)
}

func QuoteItemToCommon(quoteItem *model.QuoteItem) *CommonItem {
	return &CommonItem{
		PricingVersion:      quoteItem.PricingVersion,
		ItemSource:          constants.ItemSourceQuote,
		ItemID:              quoteItem.Id,
		BelongToID:          quoteItem.QuoteID,
		TradeProduct:        quoteItem.TradeProduct,
		TradeProductName:    quoteItem.TradeProductName,
		ItemType:            quoteItem.ItemType,
		StandardProduct:     quoteItem.StandardProduct,
		ItemScene:           quoteItem.ItemScene,
		AutoGenerate:        quoteItem.AutoGenerate,
		SolutionID:          quoteItem.QuoteSolutionID,
		ItemStatus:          quoteItem.ItemStatus,
		GiveAwayType:        quoteItem.GiveAwayType,
		GenerateType:        quoteItem.GenerateType,
		EstimatedIncome:     quoteItem.EstimatedIncome,
		IsZeroPrice:         quoteItem.IsZeroPrice,
		SalesMode:           quoteItem.SalesMode,
		ConfigPublicDisplay: quoteItem.ConfigPublicDisplay,
		ItemBusinessRole:    quoteItem.ItemBusinessRole,
		RelatedItemID:       quoteItem.RelatedItemID,
		SpPkgInfo:           quoteItem.GetSpPkgInfo(),
		ItemBelong:          quoteItem.ItemBelong,
	}
}

func QuoteItemArrToCommon(quoteItems []*model.QuoteItem) []*CommonItem {
	var commonItemArr []*CommonItem
	for _, quoteItem := range quoteItems {
		commonItemArr = append(commonItemArr, QuoteItemToCommon(quoteItem))
	}
	return commonItemArr
}

func QuoteItemValueArrToCommon(quoteItemValues []*model.QuoteItemValue) []*CommonItemValue {
	var commonItemValueArr []*CommonItemValue
	for _, quoteItemValue := range quoteItemValues {
		commonItemValueArr = append(commonItemValueArr, &CommonItemValue{
			ItemID:                quoteItemValue.QuoteItemID,
			BelongToID:            quoteItemValue.QuoteID,
			FormSchemaKey:         quoteItemValue.FormSchemaKey,
			ItemValue:             quoteItemValue.QuoteItemValue,
			OptionEnumDescription: quoteItemValue.OptionEnumDescription,
			QuoteItemValue:        quoteItemValue,
			ExcludeDetail:         quoteItemValue.ExcludeDetail,
		})
	}
	return commonItemValueArr
}

package config_option_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"
	"encoding/json"
	"regexp"
)

type ProgressiveInfoModel struct {
	ProgressiveType string
	MeasureInterval string
	AccumulateType  string `json:"AccumulateType" default:"single"`
}

func (p *ProgressiveInfoModel) IsSame(v *ProgressiveInfoModel) bool {
	if v == nil {
		return false
	}
	return p.ProgressiveType == v.ProgressiveType && p.AccumulateType == v.AccumulateType && p.MeasureInterval == v.MeasureInterval
}

const measureIntervalPattern = "^\\d+(\\.\\d{1,2})?(,\\d+(\\.\\d{1,2})?){0,9}$"
const unitPriceIntervalPattern = "^(0|1|0\\.\\d{1,10})(,(|0|1|0\\.\\d{1,10})){0,9}$"

func GenProgressiveInfo(progressiveInfoStr string) (*ProgressiveInfoModel, error) {
	progressiveInfo := &ProgressiveInfoModel{}
	if err := json.Unmarshal([]byte(progressiveInfoStr), progressiveInfo); err != nil {
		return nil, err
	}
	if _, ok := constants.ProgressiveTypeMapping[progressiveInfo.ProgressiveType]; !ok {
		return nil, i18nfmt.NewError(context.Background(), "报价单阶梯信息，累计维度类型枚举错误")
	}
	match, err := regexp.MatchString(measureIntervalPattern, progressiveInfo.MeasureInterval)
	if err != nil {
		return nil, err
	}
	if !match {
		return nil, i18nfmt.NewError(context.Background(), "报价单阶梯信息，累计阶梯错误")
	}
	if progressiveInfo.AccumulateType == "" {
		progressiveInfo.AccumulateType = constants.AccumulateTypeSingle
	}

	if _, ok := constants.AccumulateType[progressiveInfo.AccumulateType]; !ok {
		return nil, i18nfmt.NewError(context.Background(), "报价单阶梯信息，阶梯累计类型错误")
	}

	return progressiveInfo, nil
}

package config_option_service

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/gopkg/logs"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

func AutoSelectAll(cfgNodeList []*product_config_parser.ConfigNode, productInfo *trade_client.TradeProductVersionInfo) (bool, string) {

	if constants.ProductType(productInfo.ProductType) == multienv.TradeProductTypeOffline || len(cfgNodeList) == 0 {
		return false, ""
	}

	formSchemaKeyMap, ok := constants.FormSchemaKeySonMapping[productInfo.ActivationType]
	if !ok {
		return false, ""
	}
	formSchemaKey := formSchemaKeyMap[cfgNodeList[len(cfgNodeList)-1].NodeType]
	_, ok = constants.AutoSelectAllKeyMapping[formSchemaKey]
	selectAll := false
	if ok {
		selectAll = cfgNodeList[len(cfgNodeList)-1].NodeKey == constants.SelectAll
	}

	if formSchemaKey == constants.SchemaChargeUnit { //`计费方式`选【所有选项】`计费单元`自动刷成【所有选项】
		for _, cfgNode := range cfgNodeList {
			if cfgNode.NodeType == constants.SchemaChargeMethod && cfgNode.NodeKey == constants.SelectAll {
				selectAll = true
			}
		}
	}

	return selectAll, formSchemaKey
}

func GetSelectAllOption(formSchemaKey string, mapKeysArr [][]string, otherInfo interface{}) *Option {
	parentKeys := []string{mapKeysArr[0][0]}
	for i := 1; i < len(mapKeysArr); i++ {
		parentKeys = append(parentKeys, constants.SelectAll)
	}

	selectAllOption := &Option{
		AttrKey:         constants.SelectAll,
		EnumDescription: multienv.GetSelectAllDesc(),
		FormSchemaKey:   formSchemaKey,
		ParentKeys:      parentKeys,
		OtherInfo:       otherInfo,
	}
	return selectAllOption
}

func GetMapKeysArr(rootKey string, cfgNodeList []*product_config_parser.ConfigNode) [][]string {
	mapKeysArr := [][]string{{rootKey}}
	for _, configNode := range cfgNodeList {
		if len(configNode.NodeKeys) > 0 {
			mapKeysArr = append(mapKeysArr, configNode.NodeKeys)
		} else {
			mapKeysArr = append(mapKeysArr, []string{configNode.NodeKey})
		}
	}
	return mapKeysArr
}

func ParseConfigNodeToOptions(trieNodes []*product_config_parser.TrieNode, rootKey string, cfgNodeList []*product_config_parser.ConfigNode, productInfo *trade_client.TradeProductVersionInfo) ([]*Option, *Option) {

	mapKeysArr := GetMapKeysArr(rootKey, cfgNodeList)
	var options []*Option
	var selectAllOption *Option
	if len(trieNodes) == 0 {
		return options, selectAllOption
	}
	sonNodeType := ""
	sonMap := map[string]*product_config_parser.TrieNode{}

	for _, trieNode := range trieNodes {
		if trieNode != nil {
			sonNodeType = trieNode.SonNodeType
			for _, sonNode := range trieNode.SonMap {
				sonMap[sonNode.GetMappedFullKey(mapKeysArr)] = sonNode
			}
		}
	}
	var selectAllOtherInfo *product_config_load.ConfigurationInfo
	canPrePayTypeMap := map[string]*product_config_load.CommonOption{}
	if sonNodeType == constants.SchemaConfig {
		selectAllOtherInfo = &product_config_load.ConfigurationInfo{}
	}

	for _, sonNode := range sonMap {
		if sonNodeType == constants.SchemaConfig {
			sonNodeOtherInfo := product_config_load.TransOtherInfoToConfigurationInfo(sonNode.OtherInfo)
			selectAllOtherInfo.SupportSellingModeAll = false
			selectAllOtherInfo.SupportCalculateCostInstance = selectAllOtherInfo.SupportCalculateCostInstance || sonNodeOtherInfo.SupportCalculateCostInstance
			selectAllOtherInfo.SupportSpotInstance = selectAllOtherInfo.SupportSpotInstance || sonNodeOtherInfo.SupportSpotInstance
			selectAllOtherInfo.SupportESIInstance = selectAllOtherInfo.SupportESIInstance || sonNodeOtherInfo.SupportESIInstance
			selectAllOtherInfo.SupportESISegInstance = selectAllOtherInfo.SupportESISegInstance || sonNodeOtherInfo.SupportESISegInstance
			sonNodeOtherInfo.SupportSellingModeAll = false // 不再支持端上售卖模式所有选项的渲染
			sonNode.OtherInfo = sonNodeOtherInfo
			if len(sonNodeOtherInfo.CanPrePayTypes) > 0 {
				canPrePayTypeMap[sonNodeOtherInfo.CanPrePayTypes[0].AttrKey] = sonNodeOtherInfo.CanPrePayTypes[0]
			}
		}
		options = append(options, &Option{
			AttrKey:         sonNode.NodeKey,
			EnumDescription: sonNode.NodeName,
			OtherInfo:       sonNode.OtherInfo,
			CalculateData:   sonNode.CalculateData,
			FormSchemaKey:   sonNode.NodeType,
			ParentKeys:      sonNode.GetMappedParentKeys(mapKeysArr),
			NodeData:        sonNode.NodeData,
		})
	}

	if len(canPrePayTypeMap) > 0 {
		var canPrePayTypes []*product_config_load.CommonOption
		for _, canPrePayType := range canPrePayTypeMap {
			canPrePayTypes = append(canPrePayTypes, canPrePayType)
		}
		canPrePayTypes = append(canPrePayTypes, &product_config_load.CommonOption{
			AttrKey:         constants.SelectAll,
			EnumDescription: multienv.GetSelectAllDesc(),
			FormSchemaKey:   constants.SchemaCanPrePay,
		})
		sort.Slice(canPrePayTypes, func(i, j int) bool {
			if canPrePayTypes[i].AttrKey == constants.SelectAll && canPrePayTypes[j].AttrKey != constants.SelectAll {
				return true
			}
			if canPrePayTypes[i].AttrKey != constants.SelectAll && canPrePayTypes[j].AttrKey == constants.SelectAll {
				return false
			}
			return strings.Compare(options[j].EnumDescription, options[i].EnumDescription) > 0
		})
		selectAllOtherInfo.CanPrePayTypes = canPrePayTypes
	}
	autoSelectAll, _ := AutoSelectAll(cfgNodeList, productInfo)
	if autoSelectAll || appendSelectAllOption(productInfo, sonNodeType, options) {
		selectAllOption = GetSelectAllOption(sonNodeType, mapKeysArr, selectAllOtherInfo)
	}
	fieldSupportSelectAllMap := productInfo.GetSelectionRuleHasAllMap()
	if selectAllOption != nil &&
		fieldSupportSelectAllMap[selectAllOption.FormSchemaKey] == multienv.FiledSupportSelectAllFalse {
		selectAllOption = nil
	}
	return options, selectAllOption
}

func appendSelectAllOption(productInfo *trade_client.TradeProductVersionInfo, sonNodeType string, options []*Option) bool {
	_, ok := constants.ActivationNoSelectAllKeyMapping[sonNodeType]
	if productInfo.IsActivationProduct() && ok {
		return false
	}
	return constants.ProductType(productInfo.ProductType) == multienv.TradeProductTypeOnline && sonNodeType != constants.SchemaPriceType && len(options) > 0
}

func GetCommonOptions(
	ctx context.Context,
	quote *model.Quote,
	configTree *product_config_parser.StandardConfigTree,
	cfgNodeList []*product_config_parser.ConfigNode,
	productInfo *trade_client.TradeProductVersionInfo,
	isDeduct bool,
) ([]*Option, error) {

	for _, cfgNode := range cfgNodeList {
		if cfgNode.NodeType != constants.SchemaPriceType {
			cfgNode.NodeKey = util.GetCode(cfgNode.NodeKey)
		}
	}
	AppendExcludeDetail(ctx, quote, productInfo, cfgNodeList, isDeduct)
	trieNodes, err := configTree.Find(cfgNodeList, productInfo.TradeProduct)
	if err != nil {
		return nil, err
	}
	if len(trieNodes) == 0 {
		logs.CtxInfo(ctx, "There are no options , cfgNodeList:%s", util.GetJsonStr(cfgNodeList))
		return nil, errors.NewBizErrWithMsg(errors.CommodityNoOption, "There are no options , please check if this config is already added or excluded .")
	}
	options, selectAllOption := ParseConfigNodeToOptions(trieNodes, configTree.Root.NodeKey, cfgNodeList, productInfo)
	options = ExcludeSelectAllOptions(ctx, quote, options, selectAllOption, productInfo, isDeduct)
	options = FilterSelectAllOptions(options, cfgNodeList, productInfo)
	if len(options) == 0 {
		logs.CtxInfo(ctx, "FilterSelectAllOptions no options after exclusion, cfgNodeList:%s", util.GetJsonStr(cfgNodeList))
		return nil, errors.NewBizErrWithMsg(errors.CodeNNoOptionsAfterExclusion, "There are no options after exclusion.")
	}
	sort.Slice(options, func(i, j int) bool {
		if options[i].AttrKey == constants.SelectAll && options[j].AttrKey != constants.SelectAll {
			return true
		}
		if options[i].AttrKey != constants.SelectAll && options[j].AttrKey == constants.SelectAll {
			return false
		}
		return strings.Compare(options[j].EnumDescription, options[i].EnumDescription) > 0
	})
	return options, nil
}

func ExcludeSelectAllOptions(
	ctx context.Context,
	quote *model.Quote,
	options []*Option,
	selectAllOption *Option,
	productInfo *trade_client.TradeProductVersionInfo,
	isDeduct bool,
) []*Option {
	if selectAllOption == nil {
		return options
	}
	if !quote.SupportExclude() {
		options = append(options, selectAllOption)
		return options
	}
	excludeDetailMap := productInfo.GetExcludeDetailMap()
	excludeDetail := excludeDetailMap[selectAllOption.FormSchemaKey]
	if excludeDetail == nil {
		options = append(options, selectAllOption)
		return options
	}
	excludeKeyMap := excludeDetail.GetExcludeKeyMap()

	var excludeOptions []*Option
	allOptionKeyMap := map[string]bool{}
	for _, option := range options {
		allOptionKeyMap[option.AttrKey] = true
		if _, ok := excludeKeyMap[option.AttrKey]; ok {
			excludeOptions = append(excludeOptions, option)
		}
	}

	if excludeDetail.Codes != "" {
		// 需要保证和原始顺序一致
		var excludeCodes []string
		for _, code := range strings.Split(excludeDetail.Codes, ",") {
			if allOptionKeyMap[code] {
				excludeCodes = append(excludeCodes, code)
			}
		}
		selectAllOption.ExcludeCodes = excludeCodes
	}

	if len(excludeOptions) == len(options) {
		return options
	}
	options = append(options, selectAllOption)
	return options
}

func FilterSelectAllOptions(options []*Option, cfgNodeList []*product_config_parser.ConfigNode, productInfo *trade_client.TradeProductVersionInfo) []*Option {
	if selectAll, _ := AutoSelectAll(cfgNodeList, productInfo); selectAll {
		var selectAllOption *Option
		for _, option := range options {
			if option.AttrKey == constants.SelectAll {
				selectAllOption = option
				break
			}
		}
		if selectAllOption != nil {
			return []*Option{selectAllOption}
		} else {
			return nil
		}
	}
	return options
}

func FormValuesToConfigNode(
	ctx context.Context,
	quote *model.Quote,
	productInfo *trade_client.TradeProductVersionInfo,
	formValues map[string]interface{},
	isDeduct bool,
) ([]*product_config_parser.ConfigNode, error) {

	schemaMap, formSchemaOk := dal.FormSchemaMap[util.GetMapKey(constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)]
	if !formSchemaOk {
		return nil, errors.ErrInternalError.WithArgs("报价项动态属性配置获取失败")
	}
	var configNodes []*product_config_parser.ConfigNode
	for attrKey, formSchema := range schemaMap {
		if formSchema.AttrType == model.FormAttrType_Select {
			quoteItemValue, ok := formValues[attrKey]
			if !ok {
				return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(context.Background(), "提交报价项属性值有缺失：%s", attrKey))
			}
			quoteItemValueStr, valOk := quoteItemValue.(string)
			if !valOk {
				return nil, errors.ErrInternalError.WithArgs("提交报价项属性值有误")
			}
			configNodes = append(configNodes, &product_config_parser.ConfigNode{
				NodeType: attrKey,
				NodeKey:  quoteItemValueStr,
				NodeSort: formSchema.Sort,
			})
		}
	}
	if productInfo.IsActivationProduct() {
		formSchema, ok := schemaMap[constants.SchemaChargeItemTag]
		if !ok {
			return nil, errors.ErrInternalError.WithArgs("计费项分类 formSchema 配置有误")
		}
		quoteItemValue, valOk := formValues[constants.SchemaChargeItemTag]
		if !valOk {
			return nil, errors.ErrInternalError.WithArgs("提交报价项属性值,计费项分类有误")
		}
		quoteItemValueStr, valOk := quoteItemValue.(string)
		if !valOk {
			return nil, errors.ErrInternalError.WithArgs("提交报价项属性值有误")
		}
		configNodes = append(configNodes, &product_config_parser.ConfigNode{
			NodeType: formSchema.AttrKey,
			NodeKey:  quoteItemValueStr,
			NodeSort: formSchema.Sort,
		})
	} else {
		_, ok := formValues[constants.SchemaChargeItemTag]
		if ok {
			return nil, errors.ErrInternalError.WithArgs("only ActivationProduct support chargeItemTag")
		}
	}

	sort.Slice(configNodes, func(i, j int) bool {
		return configNodes[i].NodeSort > configNodes[j].NodeSort
	})
	AppendExcludeDetail(ctx, quote, productInfo, configNodes, isDeduct)
	return configNodes, nil
}

func AppendExcludeDetail(
	ctx context.Context,
	quote *model.Quote,
	productInfo *trade_client.TradeProductVersionInfo,
	configNodes []*product_config_parser.ConfigNode,
	isDeduct bool,
) {
	if !quote.SupportExclude() {
		for _, configNode := range configNodes {
			configNode.ExcludeKeyMap = nil
			configNode.ExcludeDetailStr = ""
		}
		return
	}
	excludeDetailMap := productInfo.GetExcludeDetailMap()
	for _, configNode := range configNodes {
		if configNode.NodeKey == constants.SelectAll {
			excludeDetail, ok := excludeDetailMap[configNode.NodeType]
			if ok {
				configNode.ExcludeKeyMap = excludeDetail.GetExcludeKeyMap()
				configNode.ExcludeDetailStr = util.GetJsonStr(excludeDetail)
				continue
			}
		}
		configNode.ExcludeKeyMap = nil
		configNode.ExcludeDetailStr = ""
	}
}

func SortConfigNodeList(productType constants.ProductType, standardProduct int, cfgNodeList []*product_config_parser.ConfigNode) ([]*product_config_parser.ConfigNode, error) {
	schemaMap, formSchemaOk := dal.FormSchemaMap[util.GetMapKey(productType, standardProduct)]
	if !formSchemaOk {
		return nil, errors.ErrInternalError.WithArgs("报价项动态属性配置获取失败")
	}
	for _, configNode := range cfgNodeList {
		formSchema, ok := schemaMap[configNode.NodeType]
		if !ok {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(context.Background(), "configNode.NodeType 属性值不存在：%s", configNode.NodeType))
		}
		configNode.NodeSort = formSchema.Sort
	}
	sort.Slice(cfgNodeList, func(i, j int) bool {
		return cfgNodeList[i].NodeSort > cfgNodeList[j].NodeSort
	})
	return cfgNodeList, nil
}

func GetRealCfgNodesList(configTree *product_config_parser.StandardConfigTree, configNodesList [][]*product_config_parser.ConfigNode, tradeProduct string) ([][]*product_config_parser.ConfigNode, error) {
	var configNodesListReal [][]*product_config_parser.ConfigNode

	for _, configNodesExist := range configNodesList {
		cfgNodesList, err := configTree.FindCfgByCfg(configNodesExist, tradeProduct)
		if err != nil {
			return nil, err
		}
		configNodesListReal = append(configNodesListReal, cfgNodesList...)
	}

	return configNodesListReal, nil

}

// QuoteItemValuesEncode 切新数据模型兼容旧数据结构 临时使用，完全切换新数据模型后下线
func QuoteItemValuesEncode(quoteItemValues []*model.QuoteItemValue, tradeProduct string) {

	var (
		canPrePay      string
		configCategory string
		config         string
		chargeMethod   string
		region         string
		chargeUnit     string
		priceFactor    string
	)

	for _, quoteItemValue := range quoteItemValues {
		if quoteItemValue.FormSchemaKey == constants.SchemaCanPrePay {
			canPrePay = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaConfigCategory {
			configCategory = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaConfig {
			config = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaChargeMethod {
			chargeMethod = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaRegion {
			region = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaChargeUnit {
			chargeUnit = util.GetCode(quoteItemValue.QuoteItemValue)
		} else if quoteItemValue.FormSchemaKey == constants.SchemaPriceFactor {
			priceFactor = util.GetCode(quoteItemValue.QuoteItemValue)
		}
	}

	for _, quoteItemValue := range quoteItemValues {
		if quoteItemValue.FormSchemaKey == constants.SchemaCanPrePay {
			if canPrePay == constants.SelectAll {
				quoteItemValue.QuoteItemValue = canPrePay
			} else {
				quoteItemValue.QuoteItemValue = GetKey(canPrePay, tradeProduct)
			}
		} else if quoteItemValue.FormSchemaKey == constants.SchemaConfigCategory {
			if configCategory == constants.SelectAll {
				quoteItemValue.QuoteItemValue = configCategory
			} else {
				quoteItemValue.QuoteItemValue = GetKey(configCategory, tradeProduct, canPrePay)
			}

		} else if quoteItemValue.FormSchemaKey == constants.SchemaConfig {
			if config == constants.SelectAll {
				quoteItemValue.QuoteItemValue = config
			} else {
				quoteItemValue.QuoteItemValue = GetKey(config, configCategory)
			}

		} else if quoteItemValue.FormSchemaKey == constants.SchemaChargeMethod {
			if chargeMethod == constants.SelectAll {
				quoteItemValue.QuoteItemValue = chargeMethod
			} else {
				quoteItemValue.QuoteItemValue = GetKey(chargeMethod, config, configCategory)
			}

		} else if quoteItemValue.FormSchemaKey == constants.SchemaRegion {
			if region == constants.SelectAll {
				quoteItemValue.QuoteItemValue = region
			} else {
				quoteItemValue.QuoteItemValue = GetKey(region, chargeMethod, config, configCategory)
			}

		} else if quoteItemValue.FormSchemaKey == constants.SchemaChargeUnit {
			if chargeUnit == constants.SelectAll {
				quoteItemValue.QuoteItemValue = chargeUnit
			} else {
				quoteItemValue.QuoteItemValue = GetKey(chargeUnit, region, chargeMethod, config, configCategory)
			}

		} else if quoteItemValue.FormSchemaKey == constants.SchemaPriceFactor {
			if priceFactor == constants.SelectAll {
				quoteItemValue.QuoteItemValue = priceFactor
			} else {
				quoteItemValue.QuoteItemValue = GetKey(priceFactor, chargeUnit, region, chargeMethod, config, configCategory)
			}
		}
	}
}

func GetKey(key string, parentKeys ...string) string {
	if len(parentKeys) > 0 {
		return strings.Join(append(parentKeys, key), constants.Separator)
	}
	return key
}

func ParseDiscount(discountStr string) string {
	discount := &Discount{}
	_ = json.Unmarshal([]byte(discountStr), discount)
	switch discount.PricingFunction {
	case constants.DiscountFunctionFixedPrice:
		return i18nfmt.Sprintf(context.Background(), "固定单价 %s %v", multienv.GetMoneySymbol(), discount.UnitPrice)
	case constants.DiscountFunctionSimpleDiscount:
		return i18nfmt.Sprintf(context.Background(), "单一折扣 %s", multienv.GetDiscount(discount.UnitPrice))
	case constants.DiscountFunctionOverProgressive,
		constants.DiscountFunctionFullProgressive,
		constants.DiscountFunctionFullProgressiveTotal:
		measures := strings.Split(discount.MeasureInterval, ",")
		units := strings.Split(discount.UnitPriceInterval, ",")
		var prices []string
		previous := "0"
		bracket := "["
		for i := 1; i < len(measures); i++ {
			current := measures[i]
			price := units[i-1]
			if i > 1 {
				bracket = "("
			}
			interval := fmt.Sprintf("%s%v, %v], %s%v ", bracket, previous, current, multienv.GetMoneySymbol(), price)
			prices = append(prices, interval)
			previous = current
		}
		prices = append(prices, fmt.Sprintf("(%v, +∞), %s%v", previous, multienv.GetMoneySymbol(), units[len(units)-1]))
		return strings.Join(prices, ";\n")
	case constants.DiscountFunctionTotalOverAmountDiscount:
		measures := strings.Split(discount.MeasureInterval, ",")
		unitPrices := strings.Split(discount.UnitPriceInterval, ",")
		var prices []string
		for i, measure := range measures {
			discountVal, _ := decimal.NewFromString(unitPrices[i])
			//discountVal = discountVal.Mul(decimal.NewFromInt(10))
			prices = append(prices, i18nfmt.Sprintf(context.Background(), "阶梯%d：满%s%s，%s", i+1, multienv.GetMoneySymbol(), measure, multienv.GetDiscount(discountVal)))
		}
		return strings.Join(prices, "\n")
	case constants.DiscountFunctionTimeDiscount:
		var prices []string
		unitPriceInterval := discount.UnitPriceInterval
		measureInterval := discount.MeasureInterval
		unitPriceMap := map[string]string{}
		measureMap := map[string]string{}
		_ = json.Unmarshal([]byte(unitPriceInterval), &unitPriceMap)
		_ = json.Unmarshal([]byte(measureInterval), &measureMap)

		for timeDiscountCode, measureValue := range measureMap {
			priceValue := unitPriceMap[timeDiscountCode]
			measures := strings.Split(measureValue, ",")
			unitPrices := strings.Split(priceValue, ",")
			unit := multienv.GetTimeDiscountUnitMapping()[timeDiscountCode]
			var priceItems string
			for i := 0; i < len(measures); i++ {
				measure := measures[i]
				unitPrice := unitPrices[i]
				priceDiscount, _ := decimal.NewFromString(unitPrice)
				//priceDiscount = priceDiscount.Mul(decimal.NewFromInt(10))
				space := ""
				if i > 0 {
					space = "    "
				}
				priceItems = i18nfmt.Sprintf(context.Background(), "%s%s满%s%s%s", priceItems, space, measure, unit, multienv.GetDiscount(priceDiscount))
			}
			discountItemName := multienv.GetTimeDiscountNameMapping()[timeDiscountCode]
			price := discountItemName + ":" + priceItems
			prices = append(prices, price)
		}
		return strings.Join(prices, "")
	default:
		return i18nfmt.Sprintf(context.Background(), "暂时没有支持的折扣类型：%v", discount.PricingFunction)
	}
}

func ConfigNodesFiltered(configNodes []*product_config_parser.ConfigNode) (string, string, string, string) {

	var chargeMethod string
	var region string
	var canPrePay string
	var configCategory string
	for _, configNode := range configNodes {
		if configNode.NodeType == constants.SchemaChargeMethod {
			chargeMethod = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaRegion {
			region = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaCanPrePay {
			canPrePay = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaConfigCategory {
			configCategory = configNode.NodeKey
		}
	}

	return chargeMethod, region, canPrePay, configCategory
}

func getItemValueCode(formSchemaKey, value string) string {
	if formSchemaKey == constants.SchemaPriceType {
		return value
	} else {
		return util.GetCode(value)
	}
}

func getExcludeKeyMap(excludeDetailStr string) map[string]string {
	if excludeDetailStr == "" {
		return nil
	}
	excludeDetail := &trade_client.ExcludeDetail{}
	_ = json.Unmarshal([]byte(excludeDetailStr), excludeDetail)
	return excludeDetail.GetExcludeKeyMap()
}

func TransferToChargeItem(nodes []*product_config_parser.ConfigNode) *ProductChargeItemInfo {
	chargeItem := &ProductChargeItemInfo{}
	for _, configNode := range nodes {
		if configNode.NodeType == constants.SchemaChargeMethod {
			chargeItem.ChargeMethod = configNode.NodeName
			chargeItem.ChargeMethodCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaChargeUnit {
			chargeItem.ChargeUnit = configNode.NodeName
			chargeItem.ChargeUnitCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceFactor {
			chargeItem.PriceFactor = configNode.NodeName
			chargeItem.PriceFactorCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceType {
			chargeItem.PriceType = configNode.NodeName
			chargeItem.PriceTypeCode = configNode.NodeKey
			chargeItem.PriceInfo = configNode.OtherInfo
			chargeItem.ChargeItemCode = util.GetChargeItemCode(configNode.NodeKey)
		}
	}
	return chargeItem
}

func TransferToConfigChargeItem(nodes []*product_config_parser.ConfigNode, productInfo *trade_client.TradeProductVersionInfo, conditionsMap map[string]map[string]bool) *ConfigChargeItemInfo {
	if len(nodes) == 0 {
		return nil
	}
	chargeItem := &ConfigChargeItemInfo{
		TradeProductCode: productInfo.TradeProduct,
	}
	if productInfo.ProductType == int(multienv.TradeProductDeploymentTypePublic) {
		chargeItem.ConfigChargeItemData = &ConfigChargeItemData{}
	}
	otherInfo := nodes[len(nodes)-1].OtherInfo
	priceInfo := product_config_load.TransOtherInfoToPriceInfo(otherInfo)
	sellingModeKey := multienv.SellingModeNo
	if priceInfo.SupportCalculateCostInstance {
		sellingModeKey = multienv.SellingModeCalculateCostInstance
	} else if priceInfo.SupportSpotInstance {
		sellingModeKey = multienv.SellingModeSpotInstance
	} else if priceInfo.SupportESIInstance {
		sellingModeKey = multienv.SellingModeESIInstance
	} else if priceInfo.SupportESISegInstance {
		sellingModeKey = multienv.SellingModeESISegInstance
	}
	chargeItem.SellingModeCode = sellingModeKey
	sellingModeCondition := conditionsMap[constants.SchemaSellingMode]
	if len(sellingModeCondition) > 0 {
		if len(nodes) == 0 {
			return nil
		}
		if _, ok := sellingModeCondition[sellingModeKey]; !ok {
			return nil
		}
	}
	for _, configNode := range nodes {
		condition := conditionsMap[configNode.NodeType]
		if len(condition) > 0 {
			if _, ok := condition[configNode.NodeKey]; !ok {
				return nil
			}
		}
		if configNode.NodeType == constants.SchemaChargeMethod {
			chargeItem.ChargeMethod = configNode.NodeName
			chargeItem.ChargeMethodCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaChargeUnit {
			chargeItem.ChargeUnit = configNode.NodeName
			chargeItem.ChargeUnitCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceFactor {
			chargeItem.PriceFactor = configNode.NodeName
			chargeItem.PriceFactorCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceType {
			chargeItem.PriceType = configNode.NodeName
			chargeItem.PriceTypeCode = configNode.NodeKey
			chargeItem.PriceInfo = configNode.OtherInfo
			chargeItem.ChargeItemCode = util.GetChargeItemCode(configNode.NodeKey)
		} else if chargeItem.ConfigChargeItemData != nil {
			if configNode.NodeType == constants.SchemaCanPrePay {
				chargeItem.ConfigChargeItemData.CanPrePay = configNode.NodeName
				chargeItem.ConfigChargeItemData.CanPrePayCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaConfigCategory {
				chargeItem.ConfigChargeItemData.ConfigCategory = configNode.NodeName
				chargeItem.ConfigChargeItemData.ConfigCategoryCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaConfig {
				chargeItem.ConfigChargeItemData.Config = configNode.NodeName
				chargeItem.ConfigChargeItemData.ConfigCode = configNode.NodeKey
				chargeItem.ConfigChargeItemData.ConfigurationInfo = configNode.OtherInfo
				chargeItem.ConfigChargeItemData.ConfigurationCalculateData = configNode.CalculateData
			} else if configNode.NodeType == constants.SchemaChargeItemTag {
				chargeItem.ConfigChargeItemData.ChargeItemTag = configNode.NodeName
				chargeItem.ConfigChargeItemData.ChargeItemTagCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaRegion {
				chargeItem.ConfigChargeItemData.Region = configNode.NodeName
				chargeItem.ConfigChargeItemData.RegionCode = configNode.NodeKey
			}
		}
	}
	return chargeItem
}

// TransferToConfigChargeItemSelectAll 专用于“所有选项”场景的计费项转换
// 与 TransferToConfigChargeItem 的差异：
// - 支持 SchemaPriceType 节点为通配符（SelectAll），避免解析具体 ChargeItemCode
// - 不执行条件过滤（conditionsMap），仅做节点信息的收集
func TransferToConfigChargeItemSelectAll(nodes []*product_config_parser.ConfigNode, productInfo *trade_client.TradeProductVersionInfo) *ConfigChargeItemInfo {
	if len(nodes) == 0 {
		return nil
	}
	chargeItem := &ConfigChargeItemInfo{
		TradeProductCode: productInfo.TradeProduct,
	}
	if productInfo.ProductType == int(multienv.TradeProductDeploymentTypePublic) {
		chargeItem.ConfigChargeItemData = &ConfigChargeItemData{}
	}

	for _, configNode := range nodes {
		if configNode == nil {
			continue
		}
		if configNode.NodeType == constants.SchemaChargeMethod {
			chargeItem.ChargeMethod = configNode.NodeName
			chargeItem.ChargeMethodCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaChargeUnit {
			chargeItem.ChargeUnit = configNode.NodeName
			chargeItem.ChargeUnitCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceFactor {
			chargeItem.PriceFactor = configNode.NodeName
			chargeItem.PriceFactorCode = configNode.NodeKey
		} else if configNode.NodeType == constants.SchemaPriceType {
			chargeItem.PriceType = configNode.NodeName
			chargeItem.PriceTypeCode = configNode.NodeKey
			chargeItem.PriceInfo = configNode.OtherInfo
		} else if chargeItem.ConfigChargeItemData != nil {
			if configNode.NodeType == constants.SchemaCanPrePay {
				chargeItem.ConfigChargeItemData.CanPrePay = configNode.NodeName
				chargeItem.ConfigChargeItemData.CanPrePayCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaConfigCategory {
				chargeItem.ConfigChargeItemData.ConfigCategory = configNode.NodeName
				chargeItem.ConfigChargeItemData.ConfigCategoryCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaConfig {
				chargeItem.ConfigChargeItemData.Config = configNode.NodeName
				chargeItem.ConfigChargeItemData.ConfigCode = configNode.NodeKey
				chargeItem.ConfigChargeItemData.ConfigurationInfo = configNode.OtherInfo
			} else if configNode.NodeType == constants.SchemaChargeItemTag {
				chargeItem.ConfigChargeItemData.ChargeItemTag = configNode.NodeName
				chargeItem.ConfigChargeItemData.ChargeItemTagCode = configNode.NodeKey
			} else if configNode.NodeType == constants.SchemaRegion {
				chargeItem.ConfigChargeItemData.Region = configNode.NodeName
				chargeItem.ConfigChargeItemData.RegionCode = configNode.NodeKey
			}
		}
	}
	return chargeItem
}

// CommonItemsToConfigNode 构建 付费方式、配置分类、配置、计费方式、地域、计费单元、价格影响因子、价格类型 数组
func CommonItemsToConfigNode(commonItemValuesLookup map[int64][]*CommonItemValue, productType constants.ProductType, standardProduct int) ([][]*product_config_parser.ConfigNode, error) {
	var configNodesList [][]*product_config_parser.ConfigNode
	for _, values := range commonItemValuesLookup {
		configNodes, err := CommonItemValuesToConfigNode(values, productType, standardProduct)
		if err != nil {
			return nil, err
		}
		configNodesList = append(configNodesList, configNodes)
	}

	return configNodesList, nil
}

func CommonItemValuesToConfigNode(values []*CommonItemValue, productType constants.ProductType, standardProduct int) ([]*product_config_parser.ConfigNode, error) {

	var itemID int64
	valueMap := map[string]*CommonItemValue{}
	for _, itemValue := range values {
		valueMap[itemValue.FormSchemaKey] = itemValue
		if itemID == 0 {
			itemID = itemValue.ItemID
		}
	}
	schemaMap := dal.FormSchemaMap[util.GetMapKey(productType, standardProduct)]

	var configNodes []*product_config_parser.ConfigNode

	for attrKey, formSchema := range schemaMap {
		if formSchema.AttrType == model.FormAttrType_Select {
			commonItemValue, ok := valueMap[attrKey]
			if !ok {
				return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(context.Background(), "模板项或模板项属性值有缺失：%s，报价项id或模板项id %d", attrKey, itemID))
			}
			configNodes = append(configNodes, &product_config_parser.ConfigNode{
				NodeType:         commonItemValue.FormSchemaKey,
				NodeSort:         formSchema.Sort,
				NodeKey:          getItemValueCode(commonItemValue.FormSchemaKey, commonItemValue.ItemValue),
				ExcludeDetailStr: commonItemValue.ExcludeDetail,
				ExcludeKeyMap:    getExcludeKeyMap(commonItemValue.ExcludeDetail),
			})
		}
		if attrKey == constants.SchemaChargeItemTag {
			commonItemValue, ok := valueMap[attrKey]
			if ok {
				configNodes = append(configNodes, &product_config_parser.ConfigNode{
					NodeType:         commonItemValue.FormSchemaKey,
					NodeSort:         formSchema.Sort,
					NodeKey:          getItemValueCode(commonItemValue.FormSchemaKey, commonItemValue.ItemValue),
					ExcludeDetailStr: commonItemValue.ExcludeDetail,
					ExcludeKeyMap:    getExcludeKeyMap(commonItemValue.ExcludeDetail),
				})
			}
		}
	}
	sort.Slice(configNodes, func(i, j int) bool {
		return configNodes[i].NodeSort > configNodes[j].NodeSort
	})
	return configNodes, nil
}

// GetConfigTreeMapByCommonItems 返回配置树map
func GetConfigTreeMapByCommonItems(c context.Context, commonItems []*CommonItem, quote *model.Quote, fullTreeNodes bool) (map[string]*product_config_parser.StandardConfigTree, error) {
	configTreeMap := map[string]*product_config_parser.StandardConfigTree{}
	var tradeProducts []string
	for _, commonItem := range commonItems {
		tradeProducts = append(tradeProducts, commonItem.TradeProduct)
	}
	productInfoMap, err := commodity_service.GetTradeProductByArray(c, tradeProducts, true)
	if err != nil {
		return nil, err
	}

	for _, commonItem := range commonItems {
		configTreeKey := commonItem.GetConfigTreeKey()
		if _, ok := configTreeMap[configTreeKey]; !ok {
			productInfo, productOk := productInfoMap[commonItem.TradeProduct]
			if !productOk {
				configTreeMap[configTreeKey] = &product_config_parser.StandardConfigTree{}
				continue
			}
			container, err := product_config_load.GetConfigContainer(c, commonItem.ItemType, commonItem.StandardProduct)
			if err != nil {
				return nil, err
			}
			filter := &product_config_parser.ConfigNodesFilter{
				ProductInfo:             productInfo,
				QuoteCustomerScope:      multienv.QuoteCustomerScopeAll,
				CheckConfigIsPublic:     false,
				CheckAllPrePayWhiteList: false,
				FullTreeNodes:           fullTreeNodes,
			}
			if quote != nil {
				filter.QuoteCustomerScope = quote.TradeType.GetCustomerScope()
				filter.ConstraintAccountList = quote.GetConstraintAccountIDs()
				filter.ConstraintAccountNumber = quote.ContractPriceAcc
				filter.CheckConfigIsPublic = quote.IsQuote() && productInfo.ConfigPublicDisplay == multienv.ConfigPublicDisplayFalse
				filter.CheckAllPrePayWhiteList = quote.IsQuote()
				filter.SpPkgInfo = commonItem.SpPkgInfo
			}
			configTree, err := container.GetConfigFromCache(c, commonItem.TradeProduct, filter)
			if err != nil {
				return nil, err
			}
			configTreeMap[configTreeKey] = configTree
		}
	}
	return configTreeMap, nil
}

func ShortOfDiscountLine(priceInfo *product_config_load.PriceInfo) bool {
	if len(priceInfo.DiscountLineList) == 0 {
		return true
	}
	discountList := priceInfo.DiscountLineList
	for _, discountLine := range discountList {
		_, checkMiss := multienv.CheckMissDiscountLineKeyMap[discountLine.Key]
		if checkMiss && discountLine.Absent {
			return true
		}
	}
	return false
}

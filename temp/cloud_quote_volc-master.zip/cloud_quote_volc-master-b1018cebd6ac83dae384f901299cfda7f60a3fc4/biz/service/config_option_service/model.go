package config_option_service

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"sort"
	"strings"

	priceCalculatorModel "code.byted.org/eps-platform/cloud_quote_volc/kitex_gen/eps/trade/price_calculator/model"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type Option struct {
	AttrKey         string
	EnumDescription string
	FormSchemaKey   string
	OtherInfo       interface{} `json:"OtherInfo,omitempty" `
	CalculateData   interface{} `json:"CalculateData,omitempty" ` // 当前节点计算数据
	ParentKeys      []string
	NodeData        map[string]string `json:"NodeData,omitempty" ` //选配信息
	ExcludeCodes    []string          `json:"ExcludeCodes,omitempty" `
}

func (o *Option) GetFullKey() string {
	return strings.Join(o.ParentKeys, constants.SeparatorV2)
}

type BatchOption struct {
	AttrKey         string
	EnumDescription string
	FormSchemaKey   string
	TradeProducts   []*BatchOptionProduct
}

type BatchOptionProduct struct {
	TradeProduct       string
	ProductRelatedData interface{}
	ParentKeys         []string
}

type Discount struct {
	PricingFunction   string
	UnitPriceInterval string
	MeasureInterval   string
	UnitPrice         decimal.Decimal
	Assigned          bool // 是否已设置折扣信息
}

func (d *Discount) GetQuotePriceDiscount() (*priceCalculatorModel.ContractDiscount, error) {
	if d.PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount { //整单超额累进使用单一折扣+最低折扣算价
		prices := strings.Split(d.UnitPriceInterval, ",")
		minDiscount := decimal.NewFromInt(1)
		for _, price := range prices {
			if price == "" {
				continue
			}
			priceDecimal, err := decimal.NewFromString(price)
			if err != nil {
				return nil, err
			}
			if priceDecimal.LessThan(minDiscount) {
				minDiscount = priceDecimal
			}
		}

		return &priceCalculatorModel.ContractDiscount{
			BillingFunction: constants.DiscountFunctionSimpleDiscount,
			UnitPrice:       minDiscount.String(),
		}, nil
	}

	if d.PricingFunction == constants.DiscountFunctionTimeDiscount {
		unitPriceInterval := d.UnitPriceInterval
		measureInterval := d.MeasureInterval
		unitPriceMap := map[string]string{}
		measureMap := map[string]string{}
		_ = json.Unmarshal([]byte(unitPriceInterval), &unitPriceMap)
		_ = json.Unmarshal([]byte(measureInterval), &measureMap)
		var measureValueStr string
		var priceValueStr string
		for timeDiscountCode, measureValue := range measureMap {
			priceValue := unitPriceMap[timeDiscountCode]
			measureValueStr = measureValue
			priceValueStr = priceValue
		}

		d.MeasureInterval = measureValueStr
		d.UnitPriceInterval = priceValueStr
	}
	return &priceCalculatorModel.ContractDiscount{
		BillingFunction:   d.PricingFunction,
		UnitPrice:         d.UnitPrice.String(),
		MeasureInterval:   d.MeasureInterval,
		UnitPriceInterval: d.UnitPriceInterval,
	}, nil
}

func (d *Discount) TransferPrice() (decimal.Decimal, decimal.Decimal) {
	if d.PricingFunction == constants.DiscountFunctionSimpleDiscount {
		return decimal.NewFromInt(1), d.UnitPrice
	} else if d.PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount {
		simpleDiscountStr := strings.Split(d.UnitPriceInterval, ",")
		minSimpleDiscount := decimal.NewFromInt(1)
		for _, s := range simpleDiscountStr {
			simpleDiscount, _ := decimal.NewFromString(s)
			if simpleDiscount.LessThan(minSimpleDiscount) {
				minSimpleDiscount = simpleDiscount
			}
		}
		return decimal.NewFromInt(1), minSimpleDiscount
	} else if d.PricingFunction == constants.DiscountFunctionTimeDiscount {
		unitPriceMap := map[string]string{}
		_ = json.Unmarshal([]byte(d.UnitPriceInterval), &unitPriceMap)
		unitPrice := decimal.NewFromInt(1)
		for _, priceArrStr := range unitPriceMap {
			priceArr := strings.Split(priceArrStr, ",")
			for _, price := range priceArr {
				priceDecimal, _ := decimal.NewFromString(price)
				if unitPrice.GreaterThan(priceDecimal) {
					unitPrice = priceDecimal
				}
			}
		}

		return decimal.NewFromInt(1), unitPrice
	}
	return decimal.NewFromInt(1), decimal.NewFromInt(1)
}

func (d *Discount) ZeroSimpleDiscount() bool {
	return d.PricingFunction == constants.DiscountFunctionSimpleDiscount && d.UnitPrice.IsZero()
}

func (d *Discount) ZeroFixedPrice() bool {
	return d.PricingFunction == constants.DiscountFunctionFixedPrice && d.UnitPrice.IsZero()
}

// NoDiscount 无折扣（十折）
func (d *Discount) NoDiscount() bool {
	return d.PricingFunction == constants.DiscountFunctionSimpleDiscount && d.UnitPrice.Equal(decimal.NewFromInt(1))
}

func (d *Discount) ContainsZeroDiscount() bool {

	// 单一折扣 {"PricingFunction":"simple_discount","UnitPrice":0.1}
	if d.ZeroSimpleDiscount() {
		return true
	}

	switch d.PricingFunction {
	case constants.DiscountFunctionFixedPrice: // 固定单价
		// {"PricingFunction":"fixed_price","UnitPriceInterval":"","MeasureInterval":"","UnitPrice":0}
		return d.UnitPrice.IsZero()
	case constants.DiscountFunctionTimeDiscount: // 时间满折
		/*
			{"PricingFunction":"time_discount","UnitPriceInterval":"{\"BM000030\":\"0.95,0.85,0.75\"}","MeasureInterval":"{\"BM000030\":\"9,8,7\"}","UnitPrice":0}
		*/
		unitPriceInterval := map[string]string{}
		_ = json.Unmarshal([]byte(d.UnitPriceInterval), &unitPriceInterval)
		for k, v := range unitPriceInterval {
			if !multienv.IsValidChargeMethodTimeCode(k) {
				continue
			}
			arr := strings.Split(v, ",")
			for _, v := range arr {
				step, _ := decimal.NewFromString(v)
				if step.IsZero() {
					return true
				}
			}
		}
	case constants.DiscountFunctionOverProgressive,
		constants.DiscountFunctionFullProgressiveTotal,
		constants.DiscountFunctionFullProgressive,
		constants.DiscountFunctionTotalOverAmountDiscount:
		// 超额累进单价 {"PricingFunction":"over_progressive","UnitPriceInterval":"11,22","MeasureInterval":"0,10"}
		// 全额累进单价 {"PricingFunction":"full_progressive","UnitPriceInterval":"0,1","MeasureInterval":"0,6"}
		// 搬站阶梯 {"PricingFunction":"total_over_amount_discount","UnitPriceInterval":"0.7,0.6,0.5","MeasureInterval":"0,100000,200000","ProgressiveType":"monthly"}
		arr := strings.Split(d.UnitPriceInterval, ",")
		for _, v := range arr {
			step, _ := decimal.NewFromString(v)
			if step.IsZero() {
				return true
			}
		}
	}
	return false
}

// IsProgressive 属于阶梯报价
func (d *Discount) IsProgressive() bool {
	return d.PricingFunction == constants.DiscountFunctionOverProgressive ||
		d.PricingFunction == constants.DiscountFunctionFullProgressive ||
		d.PricingFunction == constants.DiscountFunctionFullProgressiveTotal ||
		d.PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount
}

func (d *Discount) ValidateProgressiveQuote(progressiveInfoModel *ProgressiveInfoModel) error {
	if err := d.ValidateProgressiveDiscount(); err != nil {
		return err
	}
	if progressiveInfoModel != nil && d.MeasureInterval != progressiveInfoModel.MeasureInterval {
		return errors.ErrBadRequestError.WithArgs("阶梯报价折扣信息错误")
	}
	priceArr := strings.Split(d.UnitPriceInterval, ",")
	for _, priceStr := range priceArr {
		if priceStr == "" {
			return errors.ErrBadRequestError.WithArgs("阶梯报价折扣信息错误")
		}
	}

	return nil
}

func (d *Discount) ValidateProgressiveDiscount() error {
	if d.PricingFunction != constants.DiscountFunctionTotalOverAmountDiscount ||
		len(strings.Split(d.UnitPriceInterval, ",")) != len(strings.Split(d.MeasureInterval, ",")) {
		return errors.ErrBadRequestError.WithArgs("报价项阶梯报价折扣信息错误")
	}
	match, err := regexp.MatchString(unitPriceIntervalPattern, d.UnitPriceInterval)
	if err != nil {
		return err
	}
	if !match {
		return errors.ErrBadRequestError.WithArgs("报价项阶梯报价折扣信息错误")
	}
	return nil
}

func (d *Discount) ValidateDiscount() error {
	invalid := false
	if d.PricingFunction == constants.DiscountFunctionSimpleDiscount { //单一折扣 折扣值[0，1]
		if d.UnitPrice.GreaterThan(decimal.NewFromInt(1)) ||
			d.UnitPrice.LessThan(decimal.NewFromInt(0)) {
			invalid = true
		}
	} else if d.PricingFunction == constants.DiscountFunctionFixedPrice { //固定单价 折扣值[0，+∞]
		if d.UnitPrice.LessThan(decimal.NewFromInt(0)) {
			invalid = true
		}
	} else if d.PricingFunction == constants.DiscountFunctionTimeDiscount {
		unitPriceInterval := d.UnitPriceInterval
		measureInterval := d.MeasureInterval
		unitPriceMap := map[string]string{}
		measureMap := map[string]string{}
		_ = json.Unmarshal([]byte(unitPriceInterval), &unitPriceMap)
		_ = json.Unmarshal([]byte(measureInterval), &measureMap)

		if len(unitPriceMap) != len(measureMap) || len(unitPriceMap) == 0 {
			invalid = true
		} else {
			for timeDiscountCode, measureValue := range measureMap {
				priceValue, unitPriceOk := unitPriceMap[timeDiscountCode]
				if !unitPriceOk {
					invalid = true
				} else {
					measures := strings.Split(measureValue, ",")
					unitPrices := strings.Split(priceValue, ",")
					if len(measures) != len(unitPrices) {
						invalid = true
					}
					for _, unitPrice := range unitPrices {
						priceDiscount, _ := decimal.NewFromString(unitPrice)
						if priceDiscount.GreaterThan(decimal.NewFromInt(1)) ||
							priceDiscount.LessThan(decimal.NewFromInt(0)) {
							invalid = true
						}
					}
				}
			}
		}
	} else if d.PricingFunction == constants.DiscountFunctionTotalOverAmountDiscount {
		if err := d.ValidateProgressiveDiscount(); err != nil {
			return err
		}
	} else if d.PricingFunction == constants.DiscountFunctionOverProgressive ||
		d.PricingFunction == constants.DiscountFunctionFullProgressive ||
		d.PricingFunction == constants.DiscountFunctionFullProgressiveTotal {
		// todo 增加折扣值校验
	} else {
		invalid = true
	}
	if invalid {
		return errors.ErrBadRequestError.WithArgs(i18nfmt.Sprintf(context.Background(), "折扣数填写错误: %s", util.GetJsonStr(d)))
	}
	return nil
}

// CalcGiveAwayType 计算赠送类型
func (d *Discount) CalcGiveAwayType() string {

	// 阶梯报价: 当前discount字段中，PricingFunction对应的是报价方式
	hasProgressiveIsZero, allProgressiveIsZero := false, true
	if d.IsProgressive() {
		arr := strings.Split(d.UnitPriceInterval, ",")
		for _, v := range arr {
			step, _ := decimal.NewFromString(v)
			if step.IsZero() {
				hasProgressiveIsZero = true
			} else {
				allProgressiveIsZero = false
			}
		}

		if allProgressiveIsZero {
			return multienv.GetGiveAwayTypeStd()
		}
		if hasProgressiveIsZero {
			return multienv.GetGiveAwayTypeRange()
		}
	} else if d.PricingFunction == constants.DiscountFunctionTimeDiscount { // 时间满折解析方式与上述有差异
		/* 示例  BM000101 => 计费方案编码-包年
		{
			"PricingFunction": "time_discount",
			"UnitPriceInterval": "{\"BM000101\":\"0.95,0.85,0.75\",\"BM000030\":\"0.95,0.85,0.75\",\"BM000037\":\"0.95,0.85,0.75\"}",
			"MeasureInterval": "{\"BM000101\":\"9,8,7\",\"BM000030\":\"9,8,7\",\"BM000037\":\"9,8,7\"}",
			"UnitPrice": null,
		}
		*/
		unitPriceInterval := map[string]string{}
		_ = json.Unmarshal([]byte(d.UnitPriceInterval), &unitPriceInterval)
		for k, v := range unitPriceInterval {
			if !multienv.IsValidChargeMethodTimeCode(k) {
				continue
			}
			arr := strings.Split(v, ",")
			for _, v := range arr {
				step, _ := decimal.NewFromString(v)
				if step.IsZero() {
					hasProgressiveIsZero = true
				} else {
					allProgressiveIsZero = false
				}
			}
		}

		if allProgressiveIsZero {
			return multienv.GetGiveAwayTypeStd()
		}
		if hasProgressiveIsZero {
			return multienv.GetGiveAwayTypeRange()
		}

	} else if d.PricingFunction == constants.DiscountFunctionSimpleDiscount {
		// 通用场景 单一折扣、固定单价中UnitPrice为0
		if d.UnitPrice.IsZero() {
			return multienv.GetGiveAwayTypeStd()
		}
	} else if d.PricingFunction == constants.DiscountFunctionFixedPrice {
		// 通用场景 单一折扣、固定单价中UnitPrice为0
		if d.UnitPrice.IsZero() {
			return multienv.GetGiveAwayTypeStd()
		}
	}

	return multienv.GiveAwayTypeDefault
}

func (d *Discount) RecalculateQuantity() bool {
	return d.PricingFunction == constants.DiscountFunctionOverProgressive ||
		d.PricingFunction == constants.DiscountFunctionFullProgressive
}

type DiscountV2 struct {
	PricingFunction   string
	UnitPriceInterval string
	MeasureInterval   string
	UnitPrice         float64
	Assigned          bool // 是否已设置折扣信息
}

type DiscountValidateOption struct {
	Quote     *model.Quote
	QuoteItem *model.QuoteItem
}

func GetSimpleDiscountV2Zero() *DiscountV2 {
	return &DiscountV2{
		PricingFunction:   constants.DiscountFunctionSimpleDiscount,
		UnitPriceInterval: "",
		MeasureInterval:   "",
		UnitPrice:         0,
		Assigned:          false,
	}
}

func FormatDiscountStr(discountStr string) (string, error) {
	discount := &Discount{}
	err := json.Unmarshal(([]byte)(discountStr), &discount)
	if err != nil {
		return "", errors.ErrBadRequestError.WithArgs(i18nfmt.Sprintf(context.Background(), "错误的折扣信息: %s", discountStr))
	}
	discount.Assigned = true
	discountStrFormat := util.GetJsonStr(discount)

	return discountStrFormat, nil
}

type ProductChargeItemInfo struct {
	ChargeItemCode   string      `json:"ChargeItemCode"`
	ChargeMethod     string      `json:"ChargeMethod"`
	ChargeMethodCode string      `json:"ChargeMethodCode"`
	ChargeUnit       string      `json:"ChargeUnit"`
	ChargeUnitCode   string      `json:"ChargeUnitCode"`
	PriceFactor      string      `json:"PriceFactor"`
	PriceFactorCode  string      `json:"PriceFactorCode"`
	PriceType        string      `json:"PriceType"`
	PriceTypeCode    string      `json:"PriceTypeCode"`
	PriceInfo        interface{} `json:"PriceInfo"`
}
type ConfigChargeItemData struct {
	CanPrePay                  string      `json:"CanPrePay"`
	CanPrePayCode              string      `json:"CanPrePayCode"`
	ConfigCategory             string      `json:"ConfigCategory"`
	ConfigCategoryCode         string      `json:"ConfigCategoryCode"`
	Config                     string      `json:"Config"`
	ConfigCode                 string      `json:"ConfigCode"`
	Region                     string      `json:"Region"`
	RegionCode                 string      `json:"RegionCode"`
	ChargeItemTag              string      `json:"ChargeItemTag"`
	ChargeItemTagCode          string      `json:"ChargeItemTagCode"`
	ConfigurationInfo          interface{} `json:"ConfigurationInfo"`
	ConfigurationCalculateData interface{} `json:"ConfigurationCalculateData"`
}

type ConfigChargeItemInfo struct {
	ConfigChargeItemData  *ConfigChargeItemData
	TradeProductCode      string      `json:"TradeProductCode"`
	ChargeItemCode        string      `json:"ChargeItemCode"`
	ChargeMethod          string      `json:"ChargeMethod"`
	ChargeMethodCode      string      `json:"ChargeMethodCode"`
	ChargeUnit            string      `json:"ChargeUnit"`
	ChargeUnitCode        string      `json:"ChargeUnitCode"`
	PriceFactor           string      `json:"PriceFactor"`
	PriceFactorCode       string      `json:"PriceFactorCode"`
	PriceType             string      `json:"PriceType"`
	PriceTypeCode         string      `json:"PriceTypeCode"`
	PriceInfo             interface{} `json:"PriceInfo"`
	PrePayRatio           string      `json:"PrePayRatio"`
	PrePayRatioCode       string      `json:"PrePayRatioCode"`
	SpBuyDuration         string      `json:"SpBuyDuration"`
	SpBuyDurationCode     string      `json:"SpBuyDurationCode"`
	CommitFeeInterval     string      `json:"CommitFeeInterval"`
	CommitFeeIntervalCode string      `json:"CommitFeeIntervalCode"`
	SellingModeCode       string      `json:"SellingModeCode"`
}

func (i *ConfigChargeItemInfo) Clone() *ConfigChargeItemInfo {
	clone := *i
	return &clone
}

func (i *ConfigChargeItemInfo) GetChargeItemRepeatKey() string {
	var configCode string
	if i.ConfigChargeItemData != nil {
		configCode = i.ConfigChargeItemData.ConfigCode
	}
	return fmt.Sprintf("%s::%s::%s::%s::%s::%s::%s", i.TradeProductCode, configCode, i.ChargeItemCode, i.SellingModeCode, i.PrePayRatioCode, i.SpBuyDurationCode, i.CommitFeeIntervalCode)
}

type CommonItem struct {
	PricingVersion      string // 价格版本
	ItemSource          string
	ItemID              int64
	BelongToID          int64 //报价单id或者模板id
	TradeProduct        string
	TradeProductName    string
	ItemType            constants.ProductType
	StandardProduct     int
	ItemScene           int
	AutoGenerate        int
	SolutionID          int64
	ItemStatus          int
	GiveAwayType        string
	GenerateType        int
	CommonItemValues    []*CommonItemValue
	OtherInfo           map[string]interface{}
	EstimatedIncome     string
	IsZeroPrice         int // 是否0元刊例价：0-否，1-是
	SalesMode           string
	ConfigPublicDisplay int
	ItemBusinessRole    int   // 报价项业务角色：0-标准报价项，1-抵扣报价项
	RelatedItemID       int64 // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	SpPkgInfo           *model.SpPkgInfo
	ItemBelong          int64
}

func (i *CommonItem) AllSame(commonItem *CommonItem) bool {
	if i.TradeProduct != commonItem.TradeProduct {
		return false
	}
	iValueMap := map[string]string{}
	for _, commonItemValue := range i.CommonItemValues {
		if _, ok := constants.AllSameFieldMap[commonItemValue.FormSchemaKey]; ok {
			iValueMap[commonItemValue.FormSchemaKey] = commonItemValue.ItemValue
		}
	}
	oValueMap := map[string]string{}
	for _, commonItemValue := range commonItem.CommonItemValues {
		if _, ok := constants.AllSameFieldMap[commonItemValue.FormSchemaKey]; ok {
			oValueMap[commonItemValue.FormSchemaKey] = commonItemValue.ItemValue
		}
	}
	if len(iValueMap) != len(oValueMap) {
		return false
	}

	for formSchemaKey, itemValue := range iValueMap {
		if oValueMap[formSchemaKey] != itemValue {
			return false
		}
	}
	return true
}

func (i *CommonItem) GetCheckGroupKey() string {
	if i.ItemType == multienv.TradeProductTypeOnline { //线上标品，整单判重
		return i.TradeProduct
	} else {
		return fmt.Sprintf("%d%s%s", i.SolutionID, constants.Separator, i.TradeProduct) //线下标品，解决方案维度判重
	}
}

func (i *CommonItem) GetAllSameKey() string {
	sort.Slice(i.CommonItemValues, func(o, k int) bool {
		return strings.Compare(i.CommonItemValues[k].FormSchemaKey, i.CommonItemValues[o].FormSchemaKey) > 0
	})
	var valArr []string
	for _, commonItemValue := range i.CommonItemValues {
		if _, ok := constants.AllSameFieldMap[commonItemValue.FormSchemaKey]; ok {
			valArr = append(valArr, commonItemValue.ItemValue)
		}
	}
	return strings.Join(valArr, constants.Separator)
}

func (i *CommonItem) GetConfigTreeKey() string {
	if i.ItemBusinessRole == constants.QuoteItemBusinessRoleDeduct {
		return fmt.Sprintf("%s::%s", i.TradeProduct, i.SpPkgInfo.GetSpPkgKey())
	}
	return i.TradeProduct
}

type CommonItemValue struct {
	ItemID                int64
	BelongToID            int64
	FormSchemaKey         string
	ItemValue             string
	OptionEnumDescription string
	QuoteItemValue        *model.QuoteItemValue
	ExcludeDetail         string // 排除明细
}

// OffPeakHoursBilling 闲时计费
type OffPeakHoursBilling struct {
	Enabled       bool            `json:"Enabled"`       // 是否启用
	Period        string          `json:"Period"`        // 时段
	DiscountRatio decimal.Decimal `json:"DiscountRatio"` // 折扣比例
}

package config_option_service

const (
	OptionSceneStandardQuote    = 1
	OptionSceneStandardTemplate = 2
)

package config_option_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"sort"
	"testing"
)

func TestParseConfigNodeToOptions(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetMapKeysArr).Return([][]string{[]string{""}}).Build()
			mockey.Mock((*product_config_parser.TrieNode).GetMappedFullKey).Return("").Build()
			mockey.Mock((*product_config_parser.TrieNode).GetMappedParentKeys).Return([]string{""}).Build()
			mockey.Mock(product_config_load.TransOtherInfoToConfigurationInfo).Return(&product_config_load.ConfigurationInfo{
				CanPrePay:                    "1",
				SupportSellingModeAll:        false,
				SupportCalculateCostInstance: false,
				SupportSpotInstance:          false,
				SupportESIInstance:           false,
				SupportESISegInstance:        false,
			}).Build()
			mockey.Mock(multienv.GetCanPrePayMapping).Return(map[int]string{0: ""}).Build()
			mockey.Mock(util.StrToInt).Return(0).Build()
			mockey.Mock(multienv.GetSelectAllDesc).Return("").Build()
			mockey.Mock(GetSelectAllOption).Return(&Option{}).Build()
			mockey.Mock(AutoSelectAll).Return(false, "").Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).IsActivationProduct).Return(false).Build()

			// Act
			got, _ := ParseConfigNodeToOptions([]*product_config_parser.TrieNode{&product_config_parser.TrieNode{
				SonMap:      map[string]*product_config_parser.TrieNode{"": &product_config_parser.TrieNode{}},
				SonNodeType: constants.SchemaConfig,
			}}, "", []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{}}, &trade_client.TradeProductVersionInfo{
				ProductType: 0,
			})

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}
func TestGetCommonOptions(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(util.GetCode).Return("").Build()
			mockey.Mock(AppendExcludeDetail).Return().Build()
			mockey.Mock((*product_config_parser.StandardConfigTree).Find).Return([]*product_config_parser.TrieNode{&product_config_parser.TrieNode{}}, fmt.Errorf("your error")).Build()
			mockey.Mock(ParseConfigNodeToOptions).Return([]*Option{&Option{}}, &Option{}).Build()
			mockey.Mock(ExcludeSelectAllOptions).Return([]*Option{&Option{}}).Build()
			mockey.Mock(FilterSelectAllOptions).Return([]*Option{&Option{}}).Build()

			// Act
			got, err := GetCommonOptions(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{
					NodeKey: "",
				},
			}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "",
			}}, &trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}, false)

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(util.GetCode).Return("").Build()
			mockey.Mock(AppendExcludeDetail).Return().Build()
			mockey.Mock((*product_config_parser.StandardConfigTree).Find).Return(nil, nil).Build()
			mockey.Mock(ParseConfigNodeToOptions).Return([]*Option{&Option{}}, &Option{}).Build()
			mockey.Mock(ExcludeSelectAllOptions).Return([]*Option{&Option{}}).Build()
			mockey.Mock(FilterSelectAllOptions).Return([]*Option{&Option{}}).Build()

			// Act
			got, err := GetCommonOptions(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{
					NodeKey: "",
				},
			}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "",
			}}, &trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}, false)

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(util.GetCode).Return("").Build()
			mockey.Mock(AppendExcludeDetail).Return().Build()
			mockey.Mock((*product_config_parser.StandardConfigTree).Find).Return([]*product_config_parser.TrieNode{&product_config_parser.TrieNode{}}, nil).Build()
			mockey.Mock(ParseConfigNodeToOptions).Return([]*Option{&Option{}}, &Option{}).Build()
			mockey.Mock(ExcludeSelectAllOptions).Return([]*Option{&Option{}}).Build()
			mockey.Mock(FilterSelectAllOptions).Return(nil).Build()

			// Act
			got, err := GetCommonOptions(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{
					NodeKey: "",
				},
			}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "",
			}}, &trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}, false)

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(util.GetCode).Return("").Build()
			mockey.Mock(AppendExcludeDetail).Return().Build()
			mockey.Mock((*product_config_parser.StandardConfigTree).Find).Return([]*product_config_parser.TrieNode{&product_config_parser.TrieNode{}}, nil).Build()
			mockey.Mock(ParseConfigNodeToOptions).Return([]*Option{&Option{}}, &Option{}).Build()
			mockey.Mock(ExcludeSelectAllOptions).Return([]*Option{&Option{}}).Build()
			mockey.Mock(FilterSelectAllOptions).Return([]*Option{&Option{}}).Build()

			// Act
			got, err := GetCommonOptions(context.Background(), &model.Quote{}, &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{
					NodeKey: "",
				},
			}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "",
			}}, &trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func TestExcludeSelectAllOptions(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(false).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"": ""}).Build()

			// Act
			got := ExcludeSelectAllOptions(context.Background(), &model.Quote{}, []*Option{&Option{
				AttrKey: "",
			}}, nil, &trade_client.TradeProductVersionInfo{}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(false).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"": ""}).Build()

			// Act
			got := ExcludeSelectAllOptions(context.Background(), &model.Quote{}, []*Option{&Option{
				AttrKey: "",
			}}, &Option{
				FormSchemaKey: "",
			}, &trade_client.TradeProductVersionInfo{}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(true).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"1": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"": ""}).Build()

			// Act
			got := ExcludeSelectAllOptions(context.Background(), &model.Quote{}, []*Option{&Option{
				AttrKey: "",
			}}, &Option{
				FormSchemaKey: "",
			}, &trade_client.TradeProductVersionInfo{}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(true).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"1": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"1": "1"}).Build()

			// Act
			got := ExcludeSelectAllOptions(context.Background(), &model.Quote{}, []*Option{&Option{
				AttrKey: "1",
			}}, &Option{
				FormSchemaKey: "1",
			}, &trade_client.TradeProductVersionInfo{}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(true).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"1": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"1": "1"}).Build()

			// Act
			got := ExcludeSelectAllOptions(context.Background(), &model.Quote{}, []*Option{&Option{
				AttrKey: "2",
			}}, &Option{
				FormSchemaKey: "1",
			}, &trade_client.TradeProductVersionInfo{}, false)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})

}
func TestFilterSelectAllOptions(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(AutoSelectAll).Return(true, "").Build()

			// Act
			got := FilterSelectAllOptions([]*Option{&Option{
				AttrKey: "*",
			}}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{}}, &trade_client.TradeProductVersionInfo{})

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(AutoSelectAll).Return(true, "").Build()

			// Act
			got := FilterSelectAllOptions([]*Option{&Option{
				AttrKey: "",
			}}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{}}, &trade_client.TradeProductVersionInfo{})

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(AutoSelectAll).Return(false, "").Build()

			// Act
			got := FilterSelectAllOptions([]*Option{&Option{
				AttrKey: "",
			}}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{}}, &trade_client.TradeProductVersionInfo{})

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})

}
func TestAppendExcludeDetail(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(false).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"": ""}).Build()

			// Act
			AppendExcludeDetail(context.Background(), &model.Quote{}, &trade_client.TradeProductVersionInfo{}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "",
			}}, false)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*model.Quote).SupportExclude).Return(true).Build()
			mockey.Mock((*trade_client.TradeProductVersionInfo).GetExcludeDetailMap).Return(map[string]*trade_client.ExcludeDetail{"": &trade_client.ExcludeDetail{}}).Build()
			mockey.Mock((*trade_client.ExcludeDetail).GetExcludeKeyMap).Return(map[string]string{"": ""}).Build()

			// Act
			AppendExcludeDetail(context.Background(), &model.Quote{}, &trade_client.TradeProductVersionInfo{}, []*product_config_parser.ConfigNode{&product_config_parser.ConfigNode{
				NodeType: "",
				NodeKey:  "*",
			}}, false)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
}

func TestGetConfigTreeMapByCommonItems_BitsUTGen(t *testing.T) {
	t.Run("Success case with no quote and one item", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
			}
			productInfoMap := map[string]*trade_client.TradeProductVersionInfo{
				"prod-1": {TradeProduct: "prod-1"},
			}
			mockContainer := &product_config_load.ConfigContainer{}
			expectedTree := &product_config_parser.StandardConfigTree{}

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(productInfoMap, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).Return(expectedTree, nil).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, nil, true)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result["prod-1"], convey.ShouldEqual, expectedTree)
		})
	})

	t.Run("Success case with quote and duplicate items", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
			}
			quote := &model.Quote{
				TradeType:        multienv.TradeType("some-type"),
				ContractPriceAcc: "acc-123",
			}
			productInfoMap := map[string]*trade_client.TradeProductVersionInfo{
				"prod-1": {
					TradeProduct:        "prod-1",
					ConfigPublicDisplay: multienv.ConfigPublicDisplayFalse,
				},
			}
			mockContainer := &product_config_load.ConfigContainer{}
			expectedTree := &product_config_parser.StandardConfigTree{}

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(productInfoMap, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock((*model.Quote).GetConstraintAccountIDs).Return([]int64{456, 123}).Build()
			mockey.MockUnsafe((*model.Quote).IsQuote).Return(true).Build()

			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).
				When(func(_ context.Context, product string, filter *product_config_parser.ConfigNodesFilter) bool {
					convey.So(product, convey.ShouldEqual, "prod-1")
					convey.So(filter.QuoteCustomerScope, convey.ShouldEqual, multienv.QuoteCustomerScopeExternal)
					convey.So(filter.ConstraintAccountList, convey.ShouldResemble, []int64{456, 123})
					convey.So(filter.ConstraintAccountNumber, convey.ShouldEqual, "acc-123")
					convey.So(filter.CheckConfigIsPublic, convey.ShouldBeTrue)
					convey.So(filter.CheckAllPrePayWhiteList, convey.ShouldBeTrue)
					convey.So(filter.FullTreeNodes, convey.ShouldBeFalse)
					return true
				}).
				Return(expectedTree, nil).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, quote, false)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result["prod-1"], convey.ShouldEqual, expectedTree)
		})
	})

	t.Run("Error from commodity_service.GetTradeProductByArray", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{{TradeProduct: "prod-1"}}
			expectedErr := errors.New("db error")

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(nil, expectedErr).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, nil, false)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Product not found in product info map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
			}
			productInfoMap := map[string]*trade_client.TradeProductVersionInfo{}

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(productInfoMap, nil).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, nil, true)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result["prod-1"], convey.ShouldResemble, &product_config_parser.StandardConfigTree{})
		})
	})

	t.Run("Error from product_config_load.GetConfigContainer", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
			}
			productInfoMap := map[string]*trade_client.TradeProductVersionInfo{
				"prod-1": {TradeProduct: "prod-1"},
			}
			expectedErr := errors.New("container error")

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(productInfoMap, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(nil, expectedErr).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, nil, false)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Error from container.GetConfigFromCache", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			commonItems := []*CommonItem{
				{TradeProduct: "prod-1", ItemType: constants.ProductType(1), StandardProduct: 1},
			}
			productInfoMap := map[string]*trade_client.TradeProductVersionInfo{
				"prod-1": {TradeProduct: "prod-1"},
			}
			mockContainer := &product_config_load.ConfigContainer{}
			expectedErr := errors.New("cache error")

			mockey.Mock(commodity_service.GetTradeProductByArray).Return(productInfoMap, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(mockContainer, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigFromCache).Return(nil, expectedErr).Build()

			result, err := GetConfigTreeMapByCommonItems(ctx, commonItems, nil, false)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func TestTransferToConfigChargeItem_BitsUTGen(t *testing.T) {
	productInfoPublic := &trade_client.TradeProductVersionInfo{
		TradeProduct: "TestPublicProduct",
		ProductType:  int(multienv.TradeProductDeploymentTypePublic),
	}
	productInfoPrivate := &trade_client.TradeProductVersionInfo{
		TradeProduct: "TestPrivateProduct",
		ProductType:  int(multienv.TradeProductDeploymentTypePublic) + 1, // Any non-public type
	}

	t.Run("should return nil when nodes slice is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var nodes []*product_config_parser.ConfigNode
			conditionsMap := make(map[string]map[string]bool)

			result := TransferToConfigChargeItem(nodes, productInfoPublic, conditionsMap)

			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should return nil when selling mode condition is not met", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			nodes := []*product_config_parser.ConfigNode{
				{OtherInfo: "some info"},
			}
			conditionsMap := map[string]map[string]bool{
				constants.SchemaSellingMode: {multienv.SellingModeCalculateCostInstance: true},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(product_config_load.PriceInfo{
				SupportSpotInstance: true, // This will generate a key that is not in the conditionsMap
			}).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, conditionsMap)

			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should return nil when a generic node condition is not met", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaRegion, NodeKey: "cn-beijing"},
				{OtherInfo: "some info"},
			}
			conditionsMap := map[string]map[string]bool{
				constants.SchemaRegion: {"cn-shanghai": true},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(product_config_load.PriceInfo{}).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, conditionsMap)

			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("should successfully convert for a public product with all node types", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{SupportESIInstance: true}
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaChargeMethod, NodeName: "PostPaid", NodeKey: "PostPaid_Key"},
				{NodeType: constants.SchemaChargeUnit, NodeName: "Hour", NodeKey: "Hour_Key"},
				{NodeType: constants.SchemaPriceFactor, NodeName: "Factor", NodeKey: "Factor_Key"},
				{NodeType: constants.SchemaCanPrePay, NodeName: "Yes", NodeKey: "Yes_Key"},
				{NodeType: constants.SchemaConfigCategory, NodeName: "Category", NodeKey: "Category_Key"},
				{NodeType: constants.SchemaConfig, NodeName: "ConfigName", NodeKey: "Config_Key", OtherInfo: "ConfigInfo"},
				{NodeType: constants.SchemaChargeItemTag, NodeName: "Tag", NodeKey: "Tag_Key"},
				{NodeType: constants.SchemaRegion, NodeName: "RegionName", NodeKey: "Region_Key"},
				{NodeType: constants.SchemaPriceType, NodeName: "PriceTypeName", NodeKey: "PriceType_Key::ItemCode", OtherInfo: priceInfo},
			}
			conditionsMap := make(map[string]map[string]bool)
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, conditionsMap)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.TradeProductCode, convey.ShouldEqual, productInfoPublic.TradeProduct)
			convey.So(result.SellingModeCode, convey.ShouldEqual, multienv.SellingModeESIInstance)
			convey.So(result.ChargeMethod, convey.ShouldEqual, "PostPaid")
			convey.So(result.ChargeMethodCode, convey.ShouldEqual, "PostPaid_Key")
			convey.So(result.ChargeUnit, convey.ShouldEqual, "Hour")
			convey.So(result.ChargeUnitCode, convey.ShouldEqual, "Hour_Key")
			convey.So(result.PriceFactor, convey.ShouldEqual, "Factor")
			convey.So(result.PriceFactorCode, convey.ShouldEqual, "Factor_Key")
			convey.So(result.PriceType, convey.ShouldEqual, "PriceTypeName")
			convey.So(result.PriceTypeCode, convey.ShouldEqual, "PriceType_Key::ItemCode")
			convey.So(result.ChargeItemCode, convey.ShouldEqual, "ItemCode")
			convey.So(result.PriceInfo, convey.ShouldResemble, priceInfo)
			convey.So(result.ConfigChargeItemData, convey.ShouldNotBeNil)
			convey.So(result.ConfigChargeItemData.CanPrePay, convey.ShouldEqual, "Yes")
			convey.So(result.ConfigChargeItemData.CanPrePayCode, convey.ShouldEqual, "Yes_Key")
			convey.So(result.ConfigChargeItemData.ConfigCategory, convey.ShouldEqual, "Category")
			convey.So(result.ConfigChargeItemData.ConfigCategoryCode, convey.ShouldEqual, "Category_Key")
			convey.So(result.ConfigChargeItemData.Config, convey.ShouldEqual, "ConfigName")
			convey.So(result.ConfigChargeItemData.ConfigCode, convey.ShouldEqual, "Config_Key")
			convey.So(result.ConfigChargeItemData.ConfigurationInfo, convey.ShouldEqual, "ConfigInfo")
			convey.So(result.ConfigChargeItemData.ChargeItemTag, convey.ShouldEqual, "Tag")
			convey.So(result.ConfigChargeItemData.ChargeItemTagCode, convey.ShouldEqual, "Tag_Key")
			convey.So(result.ConfigChargeItemData.Region, convey.ShouldEqual, "RegionName")
			convey.So(result.ConfigChargeItemData.RegionCode, convey.ShouldEqual, "Region_Key")
		})
	})

	t.Run("should successfully convert for a non-public product", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{}
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaChargeMethod, NodeName: "PostPaid", NodeKey: "PostPaid_Key"},
				// This node should be ignored as ConfigChargeItemData is nil for non-public products
				{NodeType: constants.SchemaCanPrePay, NodeName: "Yes", NodeKey: "Yes_Key"},
				{NodeType: constants.SchemaPriceType, NodeName: "PriceTypeName", NodeKey: "PriceType_Key::ItemCode", OtherInfo: priceInfo},
			}
			conditionsMap := make(map[string]map[string]bool)
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPrivate, conditionsMap)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.TradeProductCode, convey.ShouldEqual, productInfoPrivate.TradeProduct)
			convey.So(result.ChargeMethod, convey.ShouldEqual, "PostPaid")
			convey.So(result.ConfigChargeItemData, convey.ShouldBeNil)
		})
	})

	t.Run("should correctly determine SellingModeCalculateCostInstance", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{SupportCalculateCostInstance: true}
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaPriceType, NodeKey: "k::c", OtherInfo: priceInfo},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, make(map[string]map[string]bool))

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.SellingModeCode, convey.ShouldEqual, multienv.SellingModeCalculateCostInstance)
		})
	})

	t.Run("should correctly determine SellingModeSpotInstance", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{SupportSpotInstance: true}
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaPriceType, NodeKey: "k::c", OtherInfo: priceInfo},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, make(map[string]map[string]bool))

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.SellingModeCode, convey.ShouldEqual, multienv.SellingModeSpotInstance)
		})
	})

	t.Run("should correctly determine SellingModeESISegInstance", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{SupportESISegInstance: true}
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaPriceType, NodeKey: "k::c", OtherInfo: priceInfo},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, make(map[string]map[string]bool))

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.SellingModeCode, convey.ShouldEqual, multienv.SellingModeESISegInstance)
		})
	})

	t.Run("should correctly determine SellingModeNo when no specific mode is supported", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			priceInfo := product_config_load.PriceInfo{} // All support flags are false
			nodes := []*product_config_parser.ConfigNode{
				{NodeType: constants.SchemaPriceType, NodeKey: "k::c", OtherInfo: priceInfo},
			}
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(priceInfo).Build()

			result := TransferToConfigChargeItem(nodes, productInfoPublic, make(map[string]map[string]bool))

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.SellingModeCode, convey.ShouldEqual, multienv.SellingModeNo)
		})
	})
}

func Test_TransferToConfigChargeItemSelectAll_BitsUTGen(t *testing.T) {
	t.Run("SelectAll returns nil when nodes is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var nodes []*product_config_parser.ConfigNode
			productInfo := &trade_client.TradeProductVersionInfo{
				TradeProduct: "EmptyNodesProduct",
				ProductType:  int(multienv.TradeProductDeploymentTypePublic),
			}

			result := TransferToConfigChargeItemSelectAll(nodes, productInfo)

			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("SelectAll collects basic fields for non-public product and ignores config data nodes", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Non-public product type means ConfigChargeItemData should remain nil.
			productInfo := &trade_client.TradeProductVersionInfo{
				TradeProduct: "PrivateProd",
				ProductType:  int(multienv.TradeProductDeploymentTypePublic) + 1,
			}
			priceInfo := map[string]string{"pi": "m"}
			nodes := []*product_config_parser.ConfigNode{
				nil, // ensure nil node is skipped
				{NodeType: "unknown", NodeName: "Unknown", NodeKey: "Unknown_Key"},
				{NodeType: constants.SchemaChargeMethod, NodeName: "PostPaid", NodeKey: "PostPaid_Key"},
				{NodeType: constants.SchemaChargeUnit, NodeName: "Hour", NodeKey: "Hour_Key"},
				{NodeType: constants.SchemaPriceFactor, NodeName: "Factor", NodeKey: "Factor_Key"},
				{NodeType: constants.SchemaPriceType, NodeName: "PriceType", NodeKey: "PriceType_Key::ItemCodePrivate", OtherInfo: priceInfo},
				// These should be ignored because ConfigChargeItemData is nil for non-public products.
				{NodeType: constants.SchemaConfig, NodeName: "ShouldIgnore", NodeKey: "ConfKey", OtherInfo: "ConfInfo"},
				{NodeType: constants.SchemaCanPrePay, NodeName: "Yes", NodeKey: "YesKey"},
			}

			result := TransferToConfigChargeItemSelectAll(nodes, productInfo)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.TradeProductCode, convey.ShouldEqual, "PrivateProd")
			convey.So(result.ConfigChargeItemData, convey.ShouldBeNil)

			convey.So(result.ChargeMethod, convey.ShouldEqual, "PostPaid")
			convey.So(result.ChargeMethodCode, convey.ShouldEqual, "PostPaid_Key")
			convey.So(result.ChargeUnit, convey.ShouldEqual, "Hour")
			convey.So(result.ChargeUnitCode, convey.ShouldEqual, "Hour_Key")
			convey.So(result.PriceFactor, convey.ShouldEqual, "Factor")
			convey.So(result.PriceFactorCode, convey.ShouldEqual, "Factor_Key")
			convey.So(result.PriceType, convey.ShouldEqual, "PriceType")
			convey.So(result.PriceTypeCode, convey.ShouldEqual, "PriceType_Key::ItemCodePrivate")
			convey.So(result.PriceInfo, convey.ShouldResemble, priceInfo)

			// Ensure that ChargeItemCode is not parsed/filled in this SelectAll function.
			convey.So(result.ChargeItemCode, convey.ShouldEqual, "")
		})
	})

	t.Run("SelectAll collects all fields for public product including ConfigChargeItemData", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			productInfo := &trade_client.TradeProductVersionInfo{
				TradeProduct: "PublicProd",
				ProductType:  int(multienv.TradeProductDeploymentTypePublic),
			}
			priceInfo := map[string]string{"k": "v"}
			nodes := []*product_config_parser.ConfigNode{
				nil, // ensure nil node is skipped
				{NodeType: "unknown", NodeName: "Unknown", NodeKey: "Unknown_Key"},
				{NodeType: constants.SchemaChargeMethod, NodeName: "Method", NodeKey: "MethodKey"},
				{NodeType: constants.SchemaChargeUnit, NodeName: "Unit", NodeKey: "UnitKey"},
				{NodeType: constants.SchemaPriceFactor, NodeName: "Factor", NodeKey: "FactorKey"},
				{NodeType: constants.SchemaPriceType, NodeName: "PTName", NodeKey: "PTKey", OtherInfo: priceInfo},
				{NodeType: constants.SchemaCanPrePay, NodeName: "Yes", NodeKey: "YesKey"},
				{NodeType: constants.SchemaConfigCategory, NodeName: "Category", NodeKey: "CategoryKey"},
				{NodeType: constants.SchemaConfig, NodeName: "ConfigName", NodeKey: "ConfigKey", OtherInfo: "CfgInfo"},
				{NodeType: constants.SchemaChargeItemTag, NodeName: "TagName", NodeKey: "TagKey"},
				{NodeType: constants.SchemaRegion, NodeName: "RegionName", NodeKey: "RegionKey"},
			}

			result := TransferToConfigChargeItemSelectAll(nodes, productInfo)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.TradeProductCode, convey.ShouldEqual, "PublicProd")

			// Top-level fields
			convey.So(result.ChargeMethod, convey.ShouldEqual, "Method")
			convey.So(result.ChargeMethodCode, convey.ShouldEqual, "MethodKey")
			convey.So(result.ChargeUnit, convey.ShouldEqual, "Unit")
			convey.So(result.ChargeUnitCode, convey.ShouldEqual, "UnitKey")
			convey.So(result.PriceFactor, convey.ShouldEqual, "Factor")
			convey.So(result.PriceFactorCode, convey.ShouldEqual, "FactorKey")
			convey.So(result.PriceType, convey.ShouldEqual, "PTName")
			convey.So(result.PriceTypeCode, convey.ShouldEqual, "PTKey")
			convey.So(result.PriceInfo, convey.ShouldResemble, priceInfo)
			convey.So(result.ChargeItemCode, convey.ShouldEqual, "")

			// ConfigChargeItemData fields
			convey.So(result.ConfigChargeItemData, convey.ShouldNotBeNil)
			convey.So(result.ConfigChargeItemData.CanPrePay, convey.ShouldEqual, "Yes")
			convey.So(result.ConfigChargeItemData.CanPrePayCode, convey.ShouldEqual, "YesKey")
			convey.So(result.ConfigChargeItemData.ConfigCategory, convey.ShouldEqual, "Category")
			convey.So(result.ConfigChargeItemData.ConfigCategoryCode, convey.ShouldEqual, "CategoryKey")
			convey.So(result.ConfigChargeItemData.Config, convey.ShouldEqual, "ConfigName")
			convey.So(result.ConfigChargeItemData.ConfigCode, convey.ShouldEqual, "ConfigKey")
			convey.So(result.ConfigChargeItemData.ConfigurationInfo, convey.ShouldEqual, "CfgInfo")
			convey.So(result.ConfigChargeItemData.ChargeItemTag, convey.ShouldEqual, "TagName")
			convey.So(result.ConfigChargeItemData.ChargeItemTagCode, convey.ShouldEqual, "TagKey")
			convey.So(result.ConfigChargeItemData.Region, convey.ShouldEqual, "RegionName")
			convey.So(result.ConfigChargeItemData.RegionCode, convey.ShouldEqual, "RegionKey")
		})
	})
}

func Test_AppendExcludeDetail_BitsUTGen(t *testing.T) {
	t.Run("AppendExcludeDetail", func(t *testing.T) {
		mockey.PatchConvey("测试AppendExcludeDetail", t, func() {
			mockey.PatchConvey("不支持排除时清空所有排除信息", func() {
				// 准备
				ctx := context.Background()
				nodes := []*product_config_parser.ConfigNode{
					{
						NodeType:         "region",
						NodeKey:          constants.SelectAll,
						ExcludeKeyMap:    map[string]string{"old": "旧值"},
						ExcludeDetailStr: "old_detail",
					},
					{
						NodeType:         "zone",
						NodeKey:          "cn-beijing",
						ExcludeKeyMap:    map[string]string{"old2": "旧值2"},
						ExcludeDetailStr: "old_detail_2",
					},
				}

				// 执行
				AppendExcludeDetail(ctx, nil, nil, nodes, false)

				// 校验
				assert.Nil(t, nodes[0].ExcludeKeyMap)
				assert.Equal(t, "", nodes[0].ExcludeDetailStr)
				assert.Nil(t, nodes[1].ExcludeKeyMap)
				assert.Equal(t, "", nodes[1].ExcludeDetailStr)
			})

			mockey.PatchConvey("扣减场景命中排除详情并处理未命中节点", func() {
				// 准备
				ctx := context.Background()
				quote := &model.Quote{}
				excludeDetail := &trade_client.ExcludeDetail{
					Codes: "code1,code2",
					Names: "名称1,名称2",
				}
				productInfo := &trade_client.TradeProductVersionInfo{
					SelectionRuleDetails: []*trade_client.SelectionRuleDetail{
						{
							FormSchemaKey: "region",
							ExcludeDetail: excludeDetail,
						},
						{
							FormSchemaKey: "",
							ExcludeDetail: &trade_client.ExcludeDetail{
								Codes: "ignored",
								Names: "ignored",
							},
						},
						{
							FormSchemaKey: "zone",
							ExcludeDetail: nil,
						},
					},
				}
				hitNode := &product_config_parser.ConfigNode{
					NodeType:         "region",
					NodeKey:          constants.SelectAll,
					ExcludeKeyMap:    map[string]string{"old": "旧值"},
					ExcludeDetailStr: "old_detail",
				}
				missNode := &product_config_parser.ConfigNode{
					NodeType:         "zone",
					NodeKey:          constants.SelectAll,
					ExcludeKeyMap:    map[string]string{"old2": "旧值2"},
					ExcludeDetailStr: "old_detail_2",
				}
				normalNode := &product_config_parser.ConfigNode{
					NodeType:         "region",
					NodeKey:          "cn-guangzhou",
					ExcludeKeyMap:    map[string]string{"old3": "旧值3"},
					ExcludeDetailStr: "old_detail_3",
				}
				nodes := []*product_config_parser.ConfigNode{hitNode, missNode, normalNode}

				// 执行
				AppendExcludeDetail(ctx, quote, productInfo, nodes, true)

				// 校验
				assert.Equal(t, excludeDetail.GetExcludeKeyMap(), hitNode.ExcludeKeyMap)
				assert.Equal(t, util.GetJsonStr(excludeDetail), hitNode.ExcludeDetailStr)
				assert.Nil(t, missNode.ExcludeKeyMap)
				assert.Equal(t, "", missNode.ExcludeDetailStr)
				assert.Nil(t, normalNode.ExcludeKeyMap)
				assert.Equal(t, "", normalNode.ExcludeDetailStr)
			})

			mockey.PatchConvey("非扣减场景直接按排除详情处理", func() {
				// 准备
				ctx := context.Background()
				quote := &model.Quote{}
				excludeDetail := &trade_client.ExcludeDetail{
					Codes: "onlyCode",
					Names: "唯一名称",
				}
				productInfo := &trade_client.TradeProductVersionInfo{
					SelectionRuleDetails: []*trade_client.SelectionRuleDetail{
						{
							FormSchemaKey: "region",
							ExcludeDetail: excludeDetail,
						},
					},
				}
				nodes := []*product_config_parser.ConfigNode{
					{
						NodeType: "region",
						NodeKey:  constants.SelectAll,
					},
				}

				// 执行
				AppendExcludeDetail(ctx, quote, productInfo, nodes, false)

				// 校验
				assert.Equal(t, excludeDetail.GetExcludeKeyMap(), nodes[0].ExcludeKeyMap)
				assert.Equal(t, util.GetJsonStr(excludeDetail), nodes[0].ExcludeDetailStr)
			})
		})
	})
}

//go:noinline
func newTradeProductInfoForExclude(formSchemaKey, codes, names string) *trade_client.TradeProductVersionInfo {
	return &trade_client.TradeProductVersionInfo{
		SelectionRuleDetails: []*trade_client.SelectionRuleDetail{
			{
				FormSchemaKey: formSchemaKey,
				ExcludeDetail: &trade_client.ExcludeDetail{
					Codes: codes,
					Names: names,
				},
			},
		},
	}
}
func Test_ExcludeSelectAllOptions_BitsUTGen(t *testing.T) {
	t.Run("分支覆盖", func(t *testing.T) {
		mockey.PatchConvey("ExcludeSelectAllOptions分支覆盖", t, func() {
			mockey.PatchConvey("返回原始选项_当全选选项为空", func() {
				ctx := context.Background()
				options := []*Option{
					{AttrKey: "a"},
				}

				got := ExcludeSelectAllOptions(ctx, &model.Quote{}, options, nil, &trade_client.TradeProductVersionInfo{}, false)

				if assert.Len(t, got, 1) {
					assert.True(t, got[0] == options[0])
				}
			})

			mockey.PatchConvey("追加全选选项_当报价单不支持排除", func() {
				ctx := context.Background()
				options := []*Option{
					{AttrKey: "a"},
				}
				selectAllOption := &Option{
					AttrKey:       "all",
					FormSchemaKey: "form1",
				}

				got := ExcludeSelectAllOptions(ctx, nil, options, selectAllOption, &trade_client.TradeProductVersionInfo{}, false)

				if assert.Len(t, got, 2) {
					assert.True(t, got[1] == selectAllOption)
				}
			})

			mockey.PatchConvey("追加全选选项_当未找到排除详情", func() {
				ctx := context.Background()

				options := []*Option{
					{AttrKey: "a"},
				}
				selectAllOption := &Option{
					AttrKey:       "all",
					FormSchemaKey: "form1",
				}

				got := ExcludeSelectAllOptions(ctx, &model.Quote{}, options, selectAllOption, &trade_client.TradeProductVersionInfo{}, true)

				if assert.Len(t, got, 2) {
					assert.True(t, got[1] == selectAllOption)
				}
			})

			mockey.PatchConvey("保留原选项_当全部选项都在排除列表中", func() {
				ctx := context.Background()
				options := []*Option{
					{AttrKey: "a"},
					{AttrKey: "b"},
				}
				selectAllOption := &Option{
					AttrKey:       "all",
					FormSchemaKey: "form1",
				}
				productInfo := newTradeProductInfoForExclude("form1", "b,a", "B,A")

				got := ExcludeSelectAllOptions(ctx, &model.Quote{}, options, selectAllOption, productInfo, false)

				if assert.Len(t, got, 2) {
					assert.True(t, got[0] == options[0])
					assert.True(t, got[1] == options[1])
				}
				assert.Equal(t, []string{"b", "a"}, selectAllOption.ExcludeCodes)
			})

			mockey.PatchConvey("追加全选选项并过滤排除编码_当仅部分选项命中排除列表", func() {
				ctx := context.Background()
				options := []*Option{
					{AttrKey: "a"},
					{AttrKey: "d"},
				}
				selectAllOption := &Option{
					AttrKey:       "all",
					FormSchemaKey: "form1",
				}
				productInfo := newTradeProductInfoForExclude("form1", "c,a,b", "C,A,B")

				got := ExcludeSelectAllOptions(ctx, &model.Quote{}, options, selectAllOption, productInfo, false)

				if assert.Len(t, got, 3) {
					assert.True(t, got[2] == selectAllOption)
				}
				assert.Equal(t, []string{"a"}, selectAllOption.ExcludeCodes)
			})

			mockey.PatchConvey("追加全选选项_当排除详情没有编码", func() {
				ctx := context.Background()
				options := []*Option{
					{AttrKey: "a"},
				}
				selectAllOption := &Option{
					AttrKey:       "all",
					FormSchemaKey: "form1",
				}
				productInfo := newTradeProductInfoForExclude("form1", "", "")

				got := ExcludeSelectAllOptions(ctx, &model.Quote{}, options, selectAllOption, productInfo, false)

				if assert.Len(t, got, 2) {
					assert.True(t, got[1] == selectAllOption)
				}
				assert.Nil(t, selectAllOption.ExcludeCodes)
			})
		})
	})
}

func Test_ParseConfigNodeToOptions_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("ParseConfigNodeToOptions", t, func() {
		mockey.PatchConvey("空trieNodes直接返回空结果", func() {
			// 调用目标函数
			opts, sel := ParseConfigNodeToOptions(nil, "root", nil, &trade_client.TradeProductVersionInfo{})

			// 断言
			assert.Equal(t, 0, len(opts))
			assert.Nil(t, sel)
		})

		mockey.PatchConvey("子节点为config时汇总预付类型并添加全选但被规则屏蔽", func() {
			// 构造cfgNodeList与根key
			rootKey := "root"
			cfgNodeList := []*product_config_parser.ConfigNode{
				{NodeType: "parentType", NodeKey: "p1"},
			}

			// 构造两个子节点，均在config类型下，且有相同的CanPrePayTypes，保证map聚合后只有一个元素
			otherInfo1 := map[string]interface{}{
				"SupportCalculateCostInstance": true,
				"SupportSpotInstance":          false,
				"SupportESIInstance":           true,
				"SupportESISegInstance":        false,
				"CanPrePayTypes": []interface{}{
					map[string]interface{}{
						"AttrKey":         "pre1",
						"EnumDescription": "预付1",
						"FormSchemaKey":   constants.SchemaCanPrePay,
					},
				},
			}
			otherInfo2 := map[string]interface{}{
				"SupportCalculateCostInstance": false,
				"SupportSpotInstance":          true,
				"SupportESIInstance":           false,
				"SupportESISegInstance":        true,
				"CanPrePayTypes": []interface{}{
					map[string]interface{}{
						"AttrKey":         "pre1",
						"EnumDescription": "预付1",
						"FormSchemaKey":   constants.SchemaCanPrePay,
					},
				},
			}
			son1 := &product_config_parser.TrieNode{
				NodeType:   constants.SchemaConfig,
				NodeName:   "desc1",
				NodeKey:    "k1",
				ParentKeys: []string{"p1"},
				OtherInfo:  otherInfo1,
			}
			son2 := &product_config_parser.TrieNode{
				NodeType:   constants.SchemaConfig,
				NodeName:   "desc2",
				NodeKey:    "k2",
				ParentKeys: []string{"p1"},
				OtherInfo:  otherInfo2,
			}
			trie := &product_config_parser.TrieNode{
				SonNodeType: constants.SchemaConfig,
				SonMap: map[string]*product_config_parser.TrieNode{
					"a": son1,
					"b": son2,
				},
			}
			trieNodes := []*product_config_parser.TrieNode{nil, trie}

			// 商品信息，规则指定该字段禁止“所有选项”
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:    int(multienv.TradeProductTypeOnline),
				ActivationType: constants.ActivationTypeOther,
				SelectionRuleDetails: []*trade_client.SelectionRuleDetail{
					{FormSchemaKey: constants.SchemaConfig, HasAll: multienv.FiledSupportSelectAllFalse},
				},
			}

			// 打桩：自动全选关闭
			mockey.Mock(AutoSelectAll).Return(false, "").Build()
			// 打桩：国际化文案
			mockey.MockUnsafe(multienv.GetSelectAllDesc).Return("所有选项").Build()
			// 打桩：排序调用less，多次调用覆盖分支
			mockey.Mock(sort.Slice).To(func(slice interface{}, less func(i, j int) bool) {
				// 触发 i=1, j=0 分支（i为selectAll，j非selectAll）
				_ = less(1, 0)
				// 触发 i=0, j=1 分支（i非selectAll，j为selectAll）
				_ = less(0, 1)
				// 触发默认比较分支
				_ = less(0, 0)
			}).Build()

			// 调用目标函数
			opts, sel := ParseConfigNodeToOptions(trieNodes, rootKey, cfgNodeList, productInfo)

			// 断言：生成了选项，但全选被过滤
			assert.Equal(t, 2, len(opts))
			assert.Nil(t, sel)
			// 断言：子项OtherInfo已转换为ConfigurationInfo
			for _, o := range opts {
				_, ok := o.OtherInfo.(*product_config_load.ConfigurationInfo)
				assert.True(t, ok)
			}
		})

		mockey.PatchConvey("非config类型依赖自动全选生成", func() {
			// 构造cfgNodeList与根key
			rootKey := "root"
			cfgNodeList := []*product_config_parser.ConfigNode{
				{NodeType: "parentType", NodeKey: "p1"},
			}

			// 子节点类型非config
			son := &product_config_parser.TrieNode{
				NodeType:   constants.SchemaRegion,
				NodeName:   "区域1",
				NodeKey:    "r1",
				ParentKeys: []string{"p1"},
				OtherInfo:  nil,
			}
			trie := &product_config_parser.TrieNode{
				SonNodeType: constants.SchemaRegion,
				SonMap: map[string]*product_config_parser.TrieNode{
					"a": son,
				},
			}
			trieNodes := []*product_config_parser.TrieNode{trie}

			// 商品信息，无限制
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:    int(multienv.TradeProductTypeOnline),
				ActivationType: constants.ActivationTypeOther,
			}

			// 打桩：自动全选开启
			mockey.Mock(AutoSelectAll).Return(true, constants.SchemaRegion).Build()
			// 打桩：国际化文案
			mockey.MockUnsafe(multienv.GetSelectAllDesc).Return("所有选项").Build()

			// 调用
			opts, sel := ParseConfigNodeToOptions(trieNodes, rootKey, cfgNodeList, productInfo)

			// 断言
			assert.GreaterOrEqual(t, len(opts), 1)
			assert.NotNil(t, sel)
			assert.Equal(t, constants.SchemaRegion, sel.FormSchemaKey)
		})

		mockey.PatchConvey("激活商品阻止追加全选", func() {
			// 构造cfgNodeList与根key
			rootKey := "root"
			cfgNodeList := []*product_config_parser.ConfigNode{
				{NodeType: "parentType", NodeKey: "p1"},
			}

			// 子节点类型为config，且无预付类型，避免进入排序分支
			son := &product_config_parser.TrieNode{
				NodeType:   constants.SchemaConfig,
				NodeName:   "配置1",
				NodeKey:    "c1",
				ParentKeys: []string{"p1"},
				OtherInfo: map[string]interface{}{
					"SupportCalculateCostInstance": true,
				},
			}
			trie := &product_config_parser.TrieNode{
				SonNodeType: constants.SchemaConfig,
				SonMap: map[string]*product_config_parser.TrieNode{
					"a": son,
				},
			}
			trieNodes := []*product_config_parser.TrieNode{trie}

			// 商品信息为激活型，appendSelectAllOption将被阻止
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:    int(multienv.TradeProductTypeOnline),
				ActivationType: constants.ActivationTypeActivation,
			}

			// 打桩：自动全选关闭
			mockey.Mock(AutoSelectAll).Return(false, "").Build()

			// 调用
			opts, sel := ParseConfigNodeToOptions(trieNodes, rootKey, cfgNodeList, productInfo)

			// 断言
			assert.GreaterOrEqual(t, len(opts), 1)
			assert.Nil(t, sel)
		})
	})
}

func testBuildProductInfo(activation bool) *trade_client.TradeProductVersionInfo {
	productInfo := &trade_client.TradeProductVersionInfo{
		ProductType:     11,
		StandardProduct: 22,
	}
	if activation {
		productInfo.ActivationType = constants.ActivationTypeActivation
	}
	return productInfo
}
func testBuildSelectSchema(attrKey string, sortNo int64) *model.FormSchema {
	return &model.FormSchema{
		AttrKey:  attrKey,
		AttrType: model.FormAttrType_Select,
		Sort:     sortNo,
	}
}
func testBuildOtherSchema(attrKey string, sortNo int64) *model.FormSchema {
	return &model.FormSchema{
		AttrKey:  attrKey,
		AttrType: "input",
		Sort:     sortNo,
	}
}
func testBuildFormSchemaRegistry(productInfo *trade_client.TradeProductVersionInfo, schemaMap map[string]*model.FormSchema) map[string]map[string]*model.FormSchema {
	return map[string]map[string]*model.FormSchema{
		util.GetMapKey(constants.ProductType(productInfo.ProductType), productInfo.StandardProduct): schemaMap,
	}
}
func Test_FormValuesToConfigNode_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	t.Run("覆盖全部分支", func(t *testing.T) {
		mockey.PatchConvey("FormValuesToConfigNode", t, func() {
			mockey.PatchConvey("缺少表单配置时返回内部错误", func() {
				productInfo := testBuildProductInfo(false)
				mockey.MockValue(&dal.FormSchemaMap).To(map[string]map[string]*model.FormSchema{})

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "报价项动态属性配置获取失败")
			})

			mockey.PatchConvey("下拉属性缺失时返回错误", func() {
				productInfo := testBuildProductInfo(false)
				schemaMap := map[string]*model.FormSchema{
					"region": testBuildSelectSchema("region", 10),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))
				mockey.MockUnsafe(i18nfmt.Sprintf).Return("缺少属性region").Build()

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "缺少属性region")
			})

			mockey.PatchConvey("下拉属性值不是字符串时返回错误", func() {
				productInfo := testBuildProductInfo(false)
				schemaMap := map[string]*model.FormSchema{
					"region": testBuildSelectSchema("region", 10),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"region": 123,
				}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "提交报价项属性值有误")
			})

			mockey.PatchConvey("激活商品缺少计费项分类配置时返回错误", func() {
				productInfo := testBuildProductInfo(true)
				schemaMap := map[string]*model.FormSchema{
					"region": testBuildSelectSchema("region", 10),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"region": "cn-north",
				}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "计费项分类 formSchema 配置有误")
			})

			mockey.PatchConvey("激活商品缺少计费项分类值时返回错误", func() {
				productInfo := testBuildProductInfo(true)
				schemaMap := map[string]*model.FormSchema{
					"region":                      testBuildSelectSchema("region", 10),
					constants.SchemaChargeItemTag: testBuildOtherSchema(constants.SchemaChargeItemTag, 20),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"region": "cn-north",
				}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "提交报价项属性值,计费项分类有误")
			})

			mockey.PatchConvey("激活商品计费项分类值不是字符串时返回错误", func() {
				productInfo := testBuildProductInfo(true)
				schemaMap := map[string]*model.FormSchema{
					"region":                      testBuildSelectSchema("region", 10),
					constants.SchemaChargeItemTag: testBuildOtherSchema(constants.SchemaChargeItemTag, 20),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"region":                      "cn-north",
					constants.SchemaChargeItemTag: 1,
				}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "提交报价项属性值有误")
			})

			mockey.PatchConvey("非激活商品传入计费项分类时返回错误", func() {
				productInfo := testBuildProductInfo(false)
				schemaMap := map[string]*model.FormSchema{
					"region": testBuildSelectSchema("region", 10),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"region":                      "cn-north",
					constants.SchemaChargeItemTag: "charge-tag",
				}, false)

				require.Error(t, err)
				assert.Nil(t, nodes)
				assert.Contains(t, err.Error(), "only ActivationProduct support chargeItemTag")
			})

			mockey.PatchConvey("激活商品转换成功并按排序返回节点", func() {
				productInfo := testBuildProductInfo(true)
				schemaMap := map[string]*model.FormSchema{
					"zone":                        testBuildSelectSchema("zone", 10),
					"spec":                        testBuildSelectSchema("spec", 30),
					"remark":                      testBuildOtherSchema("remark", 40),
					constants.SchemaChargeItemTag: testBuildOtherSchema(constants.SchemaChargeItemTag, 20),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"zone":                        "zone-a",
					"spec":                        "spec-a",
					constants.SchemaChargeItemTag: "charge-tag-a",
				}, false)

				require.NoError(t, err)
				require.Len(t, nodes, 3)
				assert.Equal(t, "spec", nodes[0].NodeType)
				assert.Equal(t, "spec-a", nodes[0].NodeKey)
				assert.Equal(t, int64(30), nodes[0].NodeSort)
				assert.Equal(t, constants.SchemaChargeItemTag, nodes[1].NodeType)
				assert.Equal(t, "charge-tag-a", nodes[1].NodeKey)
				assert.Equal(t, int64(20), nodes[1].NodeSort)
				assert.Equal(t, "zone", nodes[2].NodeType)
				assert.Equal(t, "zone-a", nodes[2].NodeKey)
				assert.Equal(t, int64(10), nodes[2].NodeSort)
				for _, node := range nodes {
					assert.Nil(t, node.ExcludeKeyMap)
					assert.Empty(t, node.ExcludeDetailStr)
				}
			})

			mockey.PatchConvey("非激活商品转换成功且忽略非下拉属性", func() {
				productInfo := testBuildProductInfo(false)
				schemaMap := map[string]*model.FormSchema{
					"zone":   testBuildSelectSchema("zone", 10),
					"spec":   testBuildSelectSchema("spec", 30),
					"remark": testBuildOtherSchema("remark", 20),
				}
				mockey.MockValue(&dal.FormSchemaMap).To(testBuildFormSchemaRegistry(productInfo, schemaMap))

				nodes, err := FormValuesToConfigNode(ctx, nil, productInfo, map[string]interface{}{
					"zone": "zone-b",
					"spec": "spec-b",
				}, false)

				require.NoError(t, err)
				require.Len(t, nodes, 2)
				assert.Equal(t, "spec", nodes[0].NodeType)
				assert.Equal(t, "spec-b", nodes[0].NodeKey)
				assert.Equal(t, "zone", nodes[1].NodeType)
				assert.Equal(t, "zone-b", nodes[1].NodeKey)
				for _, node := range nodes {
					assert.Nil(t, node.ExcludeKeyMap)
					assert.Empty(t, node.ExcludeDetailStr)
				}
			})
		})
	})
}

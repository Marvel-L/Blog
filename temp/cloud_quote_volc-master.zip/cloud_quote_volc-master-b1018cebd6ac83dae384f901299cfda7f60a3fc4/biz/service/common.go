package service

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
)

type InsertReq struct {
	CreatorAccountID string //给三方调用使用，创建人账号
	SalesAccountID   string //给报价平台传参使用+crm销售账号
}

func (r InsertReq) GetCreator(c context.Context, tx *gorm.DB) (*model.Account, error) {

	if util.RequestFromOpen(c) {
		//openApi来的 CreatorAccountID是创建人
		account, err := quote_account_service.FindKaniUserWithCache(c, r.CreatorAccountID)
		if err != nil {
			return nil, errors.NewUserNotFoundErr(err.Error())
		}
		if account == nil {
			return nil, errors.NewUserNotFoundErr("创建人没有填，请传入CreatorAccountID")
		}
		return account, nil
	} else { //报价平台来的，当前用户是创建人
		currentUser, err := dal.AccountDao.CurrentUser(c)
		if err != nil {
			return nil, err
		}
		return currentUser, nil
	}
}

func (r InsertReq) GetSalesAccountID(c context.Context, tx *gorm.DB) (string, error) {

	if util.RequestFromOpen(c) {
		//openApi来的 CreatorAccountID是销售账号
		account, err := quote_account_service.FindKaniUserWithCache(c, r.CreatorAccountID)
		if err != nil {
			return "", errors.NewUserNotFoundErr(err.Error())
		}
		if account == nil {
			return "", errors.NewUserNotFoundErr("创建人没有填，请传入CreatorAccountID")
		}
		return account.AccountID, nil
	} else {
		//报价平台来的
		//1.如果当前用户是销售，当前用户为销售账号
		//2.如果当前用户不是销售，使用参数中的销售账号
		currentUser, err := dal.AccountDao.CurrentUser(c)
		if err != nil {
			return "", err
		}
		if currentUser.AccountType.Contains(constants.AccountTypeUser) {
			return currentUser.AccountID, nil
		}
		account, peopleErr := lark_client.GetEmployeeDetailByEmail(c, r.SalesAccountID)
		if peopleErr != nil {
			return "", errors.NewUserNotFoundErr(peopleErr.Error())
		}
		if account == nil {
			return "", errors.NewUserNotFoundErr("销售没有填，请传入SalesAccountID, 使用字节的邮箱")
		}
		return account.Email, nil
	}
}

func (r InsertReq) GetSalesAccountIDByScene(c context.Context, tx *gorm.DB, quoteScene multienv.QuoteScene, quoteType int) (string, error) {
	if util.RequestFromOpen(c) &&
		r.SalesAccountID != "" &&
		(quoteScene.GeneralizedConfigListScene() || quoteType == multienv.QuoteTypeProjectBased) {
		account, err := quote_account_service.FindKaniUserWithCache(c, r.SalesAccountID)
		if err != nil {
			return "", errors.NewUserNotFoundErr(err.Error())
		}
		return account.AccountID, nil
	} else {
		return r.GetSalesAccountID(c, tx)
	}
}

package config_list

import (
	"context"
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/inquery_service"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

type UseConfigListReq struct {
	ConfigListID            int64 `json:"ConfigListID"`
	QuoteID                 int64 `json:"QuoteID"`
	IgnoreConfigListItemIDs []int64
	IgnoreQuoteItemIDs      []int64

	quoteCallbackInfo      *assistant.CallbackInfo
	configListCallbackInfo *assistant.CallbackInfo

	quoteItems              []*model.QuoteItem
	quoteDeliveryItems      []*model.QuoteItem
	allQuoteItems           []*model.QuoteItem
	configListItems         []*model.QuoteItem
	configListDeliveryItems []*model.QuoteItem
	allConfigListItems      []*model.QuoteItem
	deleteQuoteItemIDs      []int64
	configListSolutions     []*model.QuoteSolution
}

type UseConfigListResp struct {
	QuoteID      int64   `json:"QuoteID"`
	QuoteItemIDs []int64 `json:"QuoteItemIDs"`
}

func (r *UseConfigListReq) Handle(ctx context.Context) (interface{}, error) {
	var resp interface{}
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.useConfigList(ctx, tx)
		return err
	})
	return resp, err
}

func (r *UseConfigListReq) useConfigList(ctx context.Context, tx *gorm.DB) (*UseConfigListResp, error) {
	var err error

	quoteCallbackInfo, err := assistant.Callback(ctx, tx, r.QuoteID,
		assistant.WithCallbackInfoKeys([]assistant.CallbackKey{
			assistant.CallbackKeyQuoteItemsAllStatus,
			assistant.CallbackKeyDeliveryItems,
			assistant.CallbackKeyItemValues,
			assistant.CallbackKeyQuoteSolutions,
		}),
	)
	if err != nil {
		return nil, err
	}
	r.quoteCallbackInfo = quoteCallbackInfo

	configListCallbackInfo, err := assistant.Callback(ctx, tx, r.ConfigListID,
		assistant.WithCallbackInfoKeys([]assistant.CallbackKey{
			assistant.CallbackKeyQuoteItemsAllStatus,
			assistant.CallbackKeyDeliveryItems,
			assistant.CallbackKeyItemValues,
			assistant.CallbackKeyQuoteSolutions,
			assistant.CallbackKeyProductInfo,
		}),
	)
	if err != nil {
		return nil, err
	}
	r.configListCallbackInfo = configListCallbackInfo

	if err = processcheck.AllowQuoteOP(ctx, tx,
		processcheck.OpTypeConfigListUse,
		quoteCallbackInfo.Quote,
		processcheck.WithAllowOPSetCallbackInfo(&assistant.CallbackInfo{ConfigList: configListCallbackInfo.Quote}),
	); err != nil {
		return nil, err
	}

	if _, err = processcheck.FullQuoteDataCheck(ctx, tx,
		processcheck.OpTypeConfigListUse,
		processcheck.WithQuoteDataCheckSetAllQuoteItems(quoteCallbackInfo.GetAllItems()),
	); err != nil {
		return nil, err
	}

	r.useItemInfoInit()
	if err = r.itemNumCheck(ctx); err != nil {
		return nil, err
	}
	if err = r.validateConfigListItems(ctx); err != nil {
		return nil, err
	}
	if err = r.solutionRepeatCheck(ctx); err != nil {
		return nil, err
	}
	if err = r.itemRepeatCheck(ctx); err != nil {
		return nil, err
	}

	solutionIDMapping, err := r.saveSolutions(ctx, tx)
	if err != nil {
		return nil, err
	}
	quoteItemIDs, err := r.saveItems(ctx, tx, solutionIDMapping)
	if err != nil {
		return nil, err
	}
	if err = r.updateQuote(ctx, tx); err != nil {
		return nil, err
	}

	if !config.GetSwitchIsOpenByName(ctx, config.SwitchUseConfigSkipInquiry) {
		if err = inquery_service.GetInquiryService().UpdateInquiryOnQuoteItemChange(ctx, tx, quoteCallbackInfo.Quote, nil, r.allConfigListItems); err != nil {
			return nil, err
		}
	}

	return &UseConfigListResp{
		QuoteID:      r.QuoteID,
		QuoteItemIDs: quoteItemIDs,
	}, nil
}

func (r *UseConfigListReq) useItemInfoInit() {
	var (
		ignoreQuoteItemIDMap      = util.SliceToMap[int64](r.IgnoreQuoteItemIDs)
		ignoreConfigListItemIDMap = util.SliceToMap[int64](r.IgnoreConfigListItemIDs)

		quoteItems              []*model.QuoteItem
		quoteDeliveryItems      []*model.QuoteItem
		allQuoteItems           []*model.QuoteItem
		configListItems         []*model.QuoteItem
		configListDeliveryItems []*model.QuoteItem
		allConfigListItems      []*model.QuoteItem
		deleteQuoteItemIDs      []int64

		effectiveConfigListSolutionIDs = map[int64]bool{}
		configListSolutions            []*model.QuoteSolution
	)

	for _, quoteItem := range r.quoteCallbackInfo.AllQuoteItems {
		if !ignoreQuoteItemIDMap[quoteItem.Id] {
			quoteItems = append(quoteItems, quoteItem)
			allQuoteItems = append(allQuoteItems, quoteItem)
		} else {
			deleteQuoteItemIDs = append(deleteQuoteItemIDs, quoteItem.Id)
		}
	}
	for _, deliveryItem := range r.quoteCallbackInfo.AllDeliveryItems {
		if !ignoreQuoteItemIDMap[deliveryItem.ItemBelong] {
			quoteDeliveryItems = append(quoteDeliveryItems, deliveryItem)
			allQuoteItems = append(allQuoteItems, deliveryItem)
		}
	}
	for _, quoteItem := range r.configListCallbackInfo.AllQuoteItems {
		if !ignoreConfigListItemIDMap[quoteItem.Id] {
			configListItems = append(configListItems, quoteItem)
			allConfigListItems = append(allConfigListItems, quoteItem)
			if quoteItem.QuoteSolutionID > 0 {
				effectiveConfigListSolutionIDs[quoteItem.QuoteSolutionID] = true
			}
		}
	}
	for _, deliveryItem := range r.configListCallbackInfo.AllDeliveryItems {
		if !ignoreConfigListItemIDMap[deliveryItem.ItemBelong] {
			configListDeliveryItems = append(configListDeliveryItems, deliveryItem)
			allConfigListItems = append(allConfigListItems, deliveryItem)
			if deliveryItem.QuoteSolutionID > 0 {
				effectiveConfigListSolutionIDs[deliveryItem.QuoteSolutionID] = true
			}
		}
	}
	for _, solution := range r.configListCallbackInfo.AllQuoteSolutions {
		if _, ok := effectiveConfigListSolutionIDs[solution.Id]; ok {
			configListSolutions = append(configListSolutions, solution)
		}
	}

	r.quoteItems = quoteItems
	r.quoteDeliveryItems = quoteDeliveryItems
	r.allQuoteItems = allQuoteItems
	r.configListItems = configListItems
	r.configListDeliveryItems = configListDeliveryItems
	r.allConfigListItems = allConfigListItems
	r.deleteQuoteItemIDs = deleteQuoteItemIDs
	r.configListSolutions = configListSolutions
}

func (r *UseConfigListReq) itemNumCheck(ctx context.Context) error {
	if len(r.allConfigListItems) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNNoQuoteItem, "配置清单报价项列表为空不支持被引用")
	}
	maxItemNum := config.GetMaxItemNum(ctx)
	if len(r.allQuoteItems)+len(r.allConfigListItems) > maxItemNum {
		return errors.NewBizErrWithMsg(errors.CodeNItemNumExceedMaxNum, "所引用配置清单下报价项与该报价单已选报价项总和超过%d条，为保证流程正常，禁止添加！").WithArgs(maxItemNum)
	}
	return nil
}

func (r *UseConfigListReq) validateConfigListItems(ctx context.Context) error {
	for _, quoteItem := range r.allConfigListItems {
		itemValues, ok := r.configListCallbackInfo.AllItemValues[quoteItem.Id]
		if !ok {
			continue
		}
		for _, itemValue := range itemValues {
			if itemValue.FormSchemaKey != constants.SchemaDiscount {
				continue
			}
			if quoteItem.IsZeroPrice == multienv.IsZeroPriceYes {
				// 0元刊例价：单一折扣0折
				itemValue.QuoteItemValue = constants.ConfigZeroPriceDefaultDiscount
				itemValue.OptionEnumDescription = constants.ConfigZeroPriceDefaultDiscount
			} else if (quoteItem.IsQuoteItem() || quoteItem.IsAutoGeneratedDeliveryItem()) &&
				quoteItem.StandardProduct == multienv.TradeProductStandardNo {
				// 报价项&自动生成交付项 非标品：固定单价0元（包括非标品赠送）
				itemValue.QuoteItemValue = constants.ConfigUnStandardProductDefaultDiscount
				itemValue.OptionEnumDescription = constants.ConfigUnStandardProductDefaultDiscount
			} else if quoteItem.IsGiveAway() {
				// 赠送：单一折扣0折
				itemValue.QuoteItemValue = constants.ConfigZeroPriceDefaultDiscount
				itemValue.OptionEnumDescription = constants.ConfigZeroPriceDefaultDiscount
			} else if quoteItem.IsQuoteItem() || quoteItem.IsAutoGeneratedDeliveryItem() {
				// 报价项&自动生成交付项：单一折扣10折
				itemValue.QuoteItemValue = constants.ConfigQuoteItemMaxDiscount
				itemValue.OptionEnumDescription = constants.ConfigQuoteItemMaxDiscount
			} else {
				// 手动拆解交付项：单一折扣0折
				itemValue.QuoteItemValue = constants.ConfigQuoteItemDefaultDiscount
				itemValue.OptionEnumDescription = constants.ConfigQuoteItemDefaultDiscount
			}
		}
	}
	return nil
}

func (r *UseConfigListReq) solutionRepeatCheck(ctx context.Context) error {
	configListSolutionKeys := map[string]bool{}
	for _, solution := range r.configListSolutions {
		configListSolutionKeys[solution.TradeSolution+constants.Separator+solution.TradeSolutionVersion] = true
	}
	if len(r.configListSolutions) != len(configListSolutionKeys) {
		return errors.NewBizErrWithMsg(errors.CodeNQuoteSolutionRepeat, "所引用配置清单下存在重复解决方案或套餐，请重新选择配置清单！")
	}
	for _, solution := range r.quoteCallbackInfo.AllQuoteSolutions {
		solutionKey := solution.TradeSolution + constants.Separator + solution.TradeSolutionVersion
		if _, ok := configListSolutionKeys[solutionKey]; ok {
			logs.CtxWarn(ctx, "[UseConfigListReq]solutionRepeatCheck error, solutionKey: %s", solutionKey)
			return errors.NewBizErrWithMsg(errors.CodeNQuoteSolutionRepeat, "所引用配置清单与当前项目制报价单内解决方案或套餐重复，请重新选择配置清单！重复解决方案或套餐名称：%s").WithArgs(solution.TradeSolutionName)
		}
	}
	return nil
}

func (r *UseConfigListReq) itemRepeatCheck(ctx context.Context) error {
	quoteItemContexts, err := item_context.NewItemContextByQuoteItemValues(ctx, r.quoteCallbackInfo.Quote, r.quoteItems, r.quoteCallbackInfo.AllItemValues)
	if err != nil {
		return err
	}
	configListItemContexts, err := item_context.NewItemContextByQuoteItemValues(ctx, r.configListCallbackInfo.Quote, r.configListItems, r.configListCallbackInfo.AllItemValues)
	if err != nil {
		return err
	}
	repeatQuoteItemIDs := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)
	if len(repeatQuoteItemIDs) > 0 {
		logs.CtxWarn(ctx, "[UseConfigListReq]itemRepeatCheck error, repeatQuoteItemIDs: %s", util.GetJsonStr(repeatQuoteItemIDs))
		return errors.NewBizErrWithMsg(errors.CodeNQuoteItemRepeat, "项目制报价单中部分报价项与配置清单中报价项重复，不支持引用配置清单")
	}
	return nil
}

func (r *UseConfigListReq) saveSolutions(ctx context.Context, tx *gorm.DB) (map[int64]int64, error) {
	if len(r.configListSolutions) == 0 {
		return nil, nil
	}
	for _, solution := range r.configListSolutions {
		solution.SolutionCopyFrom = solution.Id
		solution.Id = 0
		solution.QuoteId = r.QuoteID
		solution.CreatedTime = time.Now()
		solution.CreatorAccountId = r.quoteCallbackInfo.Quote.CreatorAccountID
	}
	if err := dal.QuoteSolutionDao.Save(tx, r.configListSolutions, &model.QuoteSolution{}); err != nil {
		return nil, err
	}
	solutionIDMapping := map[int64]int64{}
	for _, solution := range r.configListSolutions {
		solutionIDMapping[solution.SolutionCopyFrom] = solution.Id
	}
	return solutionIDMapping, nil
}

func (r *UseConfigListReq) saveItems(ctx context.Context, tx *gorm.DB, solutionIDMapping map[int64]int64) ([]int64, error) {
	if len(r.deleteQuoteItemIDs) > 0 {
		if _, err := quote_item_service.DeleteQuoteItems(tx, r.QuoteID, r.deleteQuoteItemIDs); err != nil {
			return nil, err
		}
	}

	itemContexts, err := item_context.NewItemContextByQuoteItemValues(ctx, r.configListCallbackInfo.Quote, r.allConfigListItems, r.configListCallbackInfo.AllItemValues)
	if err != nil {
		return nil, err
	}

	var (
		productInfos    = r.configListCallbackInfo.ProductInfos
		quoteItemIDs    []int64
		allQuoteItemMap = map[int64]*model.QuoteItem{}
	)
	for _, quoteItem := range r.configListItems {
		itemContext := itemContexts[quoteItem.Id]
		productInfo := productInfos[quoteItem.TradeProduct]
		configurationInfo, _ := itemContext.GetDisplayConfigurationInfo(ctx)
		quoteItem.ItemCreateFrom = quoteItem.Id
		quoteItem.QuoteID = r.QuoteID
		quoteItem.Id = 0
		quoteItem.QuoteTemplateID = 0
		quoteItem.TemplateItemID = 0
		quoteItem.CreatorAccountID = r.quoteCallbackInfo.Quote.CreatorAccountID
		quoteItem.QuoteSolutionID = solutionIDMapping[quoteItem.QuoteSolutionID]
		quoteItem.Approvers = ""
		quoteItem.Notifiers = ""
		quoteItem.ExtraApprovals = ""
		quoteItem.ConfigIsPublic = multienv.ConfigIsPublicDefault
		quoteItem.ConfigPublicDisplay = multienv.ConfigPublicDisplayDefault
		if configurationInfo != nil {
			quoteItem.IncomeType = configurationInfo.IncomeType
			quoteItem.ConfigIsPublic = configurationInfo.ConfigIsPublic
		}
		if productInfo != nil {
			quoteItem.InvoiceProject = productInfo.InvoiceProject
			quoteItem.IncomeCode = productInfo.IncomeCode
			quoteItem.TaxRuleType = multienv.TaxRuleTypeSingleSale
			quoteItem.SalesMode = productInfo.SalesMode
			quoteItem.ConfigPublicDisplay = productInfo.ConfigPublicDisplay
		}
	}
	if err = dal.QuoteItemDao.SaveWithOption(tx, r.configListItems, &model.QuoteItem{}, dal.WithQuoteItemSaveOptionSetModifyTime()); err != nil {
		return nil, err
	}
	for _, quoteItem := range r.configListItems {
		quoteItemIDs = append(quoteItemIDs, quoteItem.Id)
		allQuoteItemMap[quoteItem.ItemCreateFrom] = quoteItem
	}

	for _, quoteItem := range r.configListDeliveryItems {
		itemContext := itemContexts[quoteItem.Id]
		productInfo := productInfos[quoteItem.TradeProduct]
		configurationInfo, _ := itemContext.GetDisplayConfigurationInfo(ctx)
		quoteItem.ItemCreateFrom = quoteItem.Id
		quoteItem.QuoteID = r.QuoteID
		quoteItem.Id = 0
		quoteItem.QuoteTemplateID = 0
		quoteItem.TemplateItemID = 0
		quoteItem.CreatorAccountID = r.quoteCallbackInfo.Quote.CreatorAccountID
		quoteItem.QuoteSolutionID = solutionIDMapping[quoteItem.QuoteSolutionID]
		quoteItem.Approvers = ""
		quoteItem.Notifiers = ""
		quoteItem.ExtraApprovals = ""
		quoteItem.ConfigIsPublic = multienv.ConfigIsPublicDefault
		quoteItem.ConfigPublicDisplay = multienv.ConfigPublicDisplayDefault
		if configurationInfo != nil {
			quoteItem.IncomeType = configurationInfo.IncomeType
			quoteItem.ConfigIsPublic = configurationInfo.ConfigIsPublic
		}
		if productInfo != nil {
			quoteItem.InvoiceProject = productInfo.InvoiceProject
			quoteItem.IncomeCode = productInfo.IncomeCode
			quoteItem.TaxRuleType = multienv.TaxRuleTypeSingleSale
			quoteItem.SalesMode = productInfo.SalesMode
			quoteItem.ConfigPublicDisplay = productInfo.ConfigPublicDisplay
		}

		quoteItemNew, ok := allQuoteItemMap[quoteItem.ItemBelong]
		if !ok {
			return nil, errors.NewBizErrWithMsg(errors.CodeNDeliveryItemBelongNotFound, "配置清单中部分交付项所属报价项缺失")
		}
		quoteItem.ItemBelong = quoteItemNew.Id
	}
	if err = dal.QuoteItemDao.SaveWithOption(tx, r.configListDeliveryItems, &model.QuoteItem{}, dal.WithQuoteItemSaveOptionSetModifyTime()); err != nil {
		return nil, err
	}
	for _, deliveryItem := range r.configListDeliveryItems {
		allQuoteItemMap[deliveryItem.ItemCreateFrom] = deliveryItem
	}

	var quoteItemValues []*model.QuoteItemValue
	for oldItemID, itemValues := range r.configListCallbackInfo.AllItemValues {
		newQuoteItem, ok := allQuoteItemMap[oldItemID]
		if !ok {
			continue
		}
		for _, itemValue := range itemValues {
			itemValue.Id = 0
			itemValue.QuoteID = r.QuoteID
			itemValue.CreatorAccountID = r.quoteCallbackInfo.Quote.CreatorAccountID
			itemValue.QuoteItemID = newQuoteItem.Id

			quoteItemValues = append(quoteItemValues, itemValue)
		}
	}
	if err = dal.QuoteItemValueDao.BatchSave(tx, quoteItemValues, &model.QuoteItemValue{}, constants.MaxSaveNum); err != nil {
		return nil, err
	}

	return quoteItemIDs, nil
}

func (r *UseConfigListReq) updateQuote(ctx context.Context, tx *gorm.DB) error {
	if err := dal.QuoteDao.UpdateByCondition(tx, dal.Condition{"id": r.QuoteID}, &model.Quote{},
		map[string]interface{}{"quote_create_from": r.ConfigListID},
	); err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

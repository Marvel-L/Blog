package config_list

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service_by_engine"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type PutOnConfigListReq struct {
	QuoteID int64 `json:"QuoteID"`
}

type PutOnConfigListResp struct {
	QuoteID int64 `json:"QuoteID"`
}

func (r *PutOnConfigListReq) Handle(ctx context.Context) (interface{}, error) {
	var err error
	tx := dal.DBProxy.NewRequest(ctx)

	quoteCtx, err := quote_context.NewQuoteContextLoader(r.QuoteID, tx).
		WithKeys(
			quote_context.QuoteContextKeyQuoteItemsAllStatus,
			quote_context.QuoteContextKeyDeliveryItems,
			quote_context.QuoteContextKeyItemValues,
		).Load(ctx)
	if err != nil {
		return nil, err
	}

	if err = processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeConfigListPullOn, quoteCtx.Persisted.Quote); err != nil {
		return nil, err
	}

	if _, err = processcheck.FullQuoteDataCheck(ctx, tx,
		processcheck.OpTypeConfigListPullOn,
		processcheck.WithQuoteDataCheckSetQuoteDBBefore(quoteCtx.Persisted.Quote),
		processcheck.WithQuoteDataCheckSetAllQuoteItems(quoteCtx.Persisted.QuoteItemsAllStatus),
	); err != nil {
		return nil, err
	}

	refresher := &quote_service_by_engine.RelatedResDepRefresher{}
	if _, err = refresher.Refresh(ctx, tx, quoteCtx, false); err != nil {
		return nil, err
	}

	if err = dal.QuoteDao.UpdateByCondition(tx,
		dal.Condition{"id": r.QuoteID, "quote_status": quoteCtx.Persisted.Quote.QuoteStatus},
		&model.Quote{},
		map[string]interface{}{"quote_status": constants.StatusConfigListPutOn},
	); err != nil {
		return nil, errors.NewInternalDBError(err)
	}

	return &PutOnConfigListResp{
		QuoteID: r.QuoteID,
	}, nil
}

package config_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/inquery_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"reflect"
	"testing"
)

// validateGuarantee is not present in production code for UseConfigListReq.
// Provide a minimal test-only implementation to satisfy existing tests.
func (r *UseConfigListReq) validateGuarantee(ctx context.Context, tx *gorm.DB) error {
	guaranteeItem, err := dal.GuaranteeItemDao.FindByQuoteID(tx, r.QuoteID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil
		}
		return err
	}
	if guaranteeItem == nil || guaranteeItem.GuaranteeType == multienv.GuaranteeTypeOther {
		return nil
	}
	if guaranteeItem.GuaranteeType == multienv.GuaranteeTypeAll {
		for _, it := range r.configListItems {
			if it != nil && it.SalesMode == multienv.SalesModeSavingsPlans {
				return pkg_errors.NewBizErrWithMsg(pkg_errors.CodeNSPNotSupportGuarantee, "配置清单存在节省计划商品，报价单保底类型不支持选择所有报价项参与保底，不支持被引用")
			}
		}
	}
	return nil
}

func Test_UseConfigListReq_useItemInfoInit_BitsUTGen(t *testing.T) {
	t.Run("正常场景-部分item被忽略且包含有效解决方案", func(t *testing.T) {
		mockey.PatchConvey("正常场景-部分item被忽略且包含有效解决方案", t, func() {
			// 准备将被忽略和保留的报价项/交付项/解决方案
			quoteItem101 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 101}} // to be ignored
			quoteItem102 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 102}} // to be kept
			deliveryItemFor101 := &model.QuoteItem{ItemBelong: 101}             // to be ignored
			deliveryItemFor103 := &model.QuoteItem{ItemBelong: 103}             // to be kept

			configItem201 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 201}}                       // to be ignored
			configItem202 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 202}, QuoteSolutionID: 301} // to be kept
			configDeliveryFor201 := &model.QuoteItem{ItemBelong: 201}                                  // to be ignored
			configDeliveryFor203 := &model.QuoteItem{ItemBelong: 203, QuoteSolutionID: 302}            // to be kept

			solution301 := &model.QuoteSolution{BaseDB: framework.BaseDB{Id: 301}} // to be kept
			solution302 := &model.QuoteSolution{BaseDB: framework.BaseDB{Id: 302}} // to be kept
			solution303 := &model.QuoteSolution{BaseDB: framework.BaseDB{Id: 303}} // to be discarded

			r := &UseConfigListReq{
				IgnoreQuoteItemIDs:      []int64{101},
				IgnoreConfigListItemIDs: []int64{201},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:    []*model.QuoteItem{quoteItem101, quoteItem102},
					AllDeliveryItems: []*model.QuoteItem{deliveryItemFor101, deliveryItemFor103},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:     []*model.QuoteItem{configItem201, configItem202},
					AllDeliveryItems:  []*model.QuoteItem{configDeliveryFor201, configDeliveryFor203},
					AllQuoteSolutions: []*model.QuoteSolution{solution301, solution302, solution303},
				},
			}

			// Mock泛型函数util.SliceToMap，按顺序返回不同的忽略ID map
			mockey.MockGeneric(util.SliceToMap[int64]).Return(
				mockey.Sequence(map[int64]bool{101: true}).
					Then(map[int64]bool{201: true}),
			).Build()

			r.useItemInfoInit()

			// 断言各项是否被正确过滤和分类
			convey.So(r.quoteItems, convey.ShouldResemble, []*model.QuoteItem{quoteItem102})
			convey.So(r.quoteDeliveryItems, convey.ShouldResemble, []*model.QuoteItem{deliveryItemFor103})
			convey.So(r.allQuoteItems, convey.ShouldResemble, []*model.QuoteItem{quoteItem102, deliveryItemFor103})
			convey.So(r.deleteQuoteItemIDs, convey.ShouldResemble, []int64{101})
			convey.So(r.configListItems, convey.ShouldResemble, []*model.QuoteItem{configItem202})
			convey.So(r.configListDeliveryItems, convey.ShouldResemble, []*model.QuoteItem{configDeliveryFor203})
			convey.So(r.allConfigListItems, convey.ShouldResemble, []*model.QuoteItem{configItem202, configDeliveryFor203})
			convey.So(r.configListSolutions, convey.ShouldResemble, []*model.QuoteSolution{solution301, solution302})
		})
	})

	t.Run("边缘场景-忽略列表为空", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-忽略列表为空", t, func() {
			// 准备数据，此时不应有任何item被忽略
			quoteItem101 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 101}}
			deliveryItemFor103 := &model.QuoteItem{ItemBelong: 103}
			configItem202 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 202}}

			r := &UseConfigListReq{
				IgnoreQuoteItemIDs:      []int64{},
				IgnoreConfigListItemIDs: []int64{},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:    []*model.QuoteItem{quoteItem101},
					AllDeliveryItems: []*model.QuoteItem{deliveryItemFor103},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:    []*model.QuoteItem{configItem202},
					AllDeliveryItems: []*model.QuoteItem{},
				},
			}

			// Mock util.SliceToMap，两次调用都返回空map
			mockey.MockGeneric(util.SliceToMap[int64]).Return(
				mockey.Sequence(map[int64]bool{}).
					Then(map[int64]bool{}),
			).Build()

			r.useItemInfoInit()

			// 断言所有item都应被保留
			convey.So(r.quoteItems, convey.ShouldResemble, []*model.QuoteItem{quoteItem101})
			convey.So(r.quoteDeliveryItems, convey.ShouldResemble, []*model.QuoteItem{deliveryItemFor103})
			convey.So(r.allQuoteItems, convey.ShouldResemble, []*model.QuoteItem{quoteItem101, deliveryItemFor103})
			convey.So(r.configListItems, convey.ShouldResemble, []*model.QuoteItem{configItem202})
			convey.So(r.deleteQuoteItemIDs, convey.ShouldBeEmpty)
			convey.So(r.configListSolutions, convey.ShouldBeEmpty)
		})
	})

	t.Run("边缘场景-所有item均被忽略", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-所有item均被忽略", t, func() {
			// 准备数据，所有item的ID都在忽略列表中
			quoteItem101 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 101}}
			deliveryItemFor101 := &model.QuoteItem{ItemBelong: 101}
			configItem201 := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 201}, QuoteSolutionID: 301}
			solution301 := &model.QuoteSolution{BaseDB: framework.BaseDB{Id: 301}}

			r := &UseConfigListReq{
				IgnoreQuoteItemIDs:      []int64{101},
				IgnoreConfigListItemIDs: []int64{201},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:    []*model.QuoteItem{quoteItem101},
					AllDeliveryItems: []*model.QuoteItem{deliveryItemFor101},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:     []*model.QuoteItem{configItem201},
					AllQuoteSolutions: []*model.QuoteSolution{solution301},
				},
			}

			// Mock util.SliceToMap使其返回包含所有item ID的map
			mockey.MockGeneric(util.SliceToMap[int64]).Return(
				mockey.Sequence(map[int64]bool{101: true}).
					Then(map[int64]bool{201: true}),
			).Build()

			r.useItemInfoInit()

			// 断言所有结果列表都为空
			convey.So(r.quoteItems, convey.ShouldBeEmpty)
			convey.So(r.quoteDeliveryItems, convey.ShouldBeEmpty)
			convey.So(r.allQuoteItems, convey.ShouldBeEmpty)
			convey.So(r.configListItems, convey.ShouldBeEmpty)
			convey.So(r.configListDeliveryItems, convey.ShouldBeEmpty)
			convey.So(r.allConfigListItems, convey.ShouldBeEmpty)
			convey.So(r.configListSolutions, convey.ShouldBeEmpty)
			convey.So(r.deleteQuoteItemIDs, convey.ShouldResemble, []int64{101})
		})
	})

	t.Run("边缘场景-输入item列表为空", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-输入item列表为空", t, func() {
			// 准备数据，所有item列表都为空
			r := &UseConfigListReq{
				IgnoreQuoteItemIDs:      []int64{101},
				IgnoreConfigListItemIDs: []int64{201},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:    []*model.QuoteItem{},
					AllDeliveryItems: []*model.QuoteItem{},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:     []*model.QuoteItem{},
					AllDeliveryItems:  []*model.QuoteItem{},
					AllQuoteSolutions: []*model.QuoteSolution{},
				},
			}

			// Mock util.SliceToMap，即使输入为空，函数依然会被调用
			mockey.MockGeneric(util.SliceToMap[int64]).Return(
				mockey.Sequence(map[int64]bool{101: true}).
					Then(map[int64]bool{201: true}),
			).Build()

			r.useItemInfoInit()

			// 断言所有结果列表都应为空
			convey.So(r.quoteItems, convey.ShouldBeEmpty)
			convey.So(r.quoteDeliveryItems, convey.ShouldBeEmpty)
			convey.So(r.allQuoteItems, convey.ShouldBeEmpty)
			convey.So(r.configListItems, convey.ShouldBeEmpty)
			convey.So(r.configListDeliveryItems, convey.ShouldBeEmpty)
			convey.So(r.allConfigListItems, convey.ShouldBeEmpty)
			convey.So(r.configListSolutions, convey.ShouldBeEmpty)
			convey.So(r.deleteQuoteItemIDs, convey.ShouldBeEmpty)
		})
	})

	t.Run("特殊场景-配置项的解决方案ID无效", func(t *testing.T) {
		mockey.PatchConvey("特殊场景-配置项的解决方案ID无效", t, func() {
			// 准备数据，配置项的QuoteSolutionID为0或负数
			configItemWithZeroID := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 202}, QuoteSolutionID: 0}
			configItemWithNegativeID := &model.QuoteItem{BaseDB: framework.BaseDB{Id: 203}, QuoteSolutionID: -1}
			solution301 := &model.QuoteSolution{BaseDB: framework.BaseDB{Id: 301}}

			r := &UseConfigListReq{
				IgnoreConfigListItemIDs: []int64{},
				quoteCallbackInfo:       &assistant.CallbackInfo{},
				configListCallbackInfo: &assistant.CallbackInfo{
					AllQuoteItems:     []*model.QuoteItem{configItemWithZeroID, configItemWithNegativeID},
					AllQuoteSolutions: []*model.QuoteSolution{solution301},
				},
			}

			mockey.MockGeneric(util.SliceToMap[int64]).Return(
				mockey.Sequence(map[int64]bool{}).
					Then(map[int64]bool{}),
			).Build()

			r.useItemInfoInit()

			// 断言配置项被保留，但解决方案列表为空
			convey.So(r.configListItems, convey.ShouldResemble, []*model.QuoteItem{configItemWithZeroID, configItemWithNegativeID})
			convey.So(r.configListSolutions, convey.ShouldBeEmpty)
		})
	})
}

func Test_UseConfigListReq_itemRepeatCheck_BitsUTGen(t *testing.T) {
	// 场景1：成功场景，报价项和配置清单项没有重复
	t.Run("成功场景-无重复项", func(t *testing.T) {
		mockey.PatchConvey("当报价项和配置清单项没有重复时,应返回nil", t, func() {
			// 准备上下文和请求结构体
			ctx := context.Background()
			req := &UseConfigListReq{
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{1: {}},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{101: {}},
				},
				quoteItems:      []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 1}}},
				configListItems: []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 101}}},
			}

			// 构造模拟的上下文map
			quoteContexts := map[int64]*item_context.ItemContext{1: {ItemID: 1}}
			configListContexts := map[int64]*item_context.ItemContext{101: {ItemID: 101}}

			// Mock依赖函数，第一次调用返回报价项上下文，第二次返回配置清单上下文
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(quoteContexts, nil).Then(configListContexts, nil)).
				Build()

			// Mock ItemContext的方法，使其返回不同的key，以确保不重复
			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(ic *item_context.ItemContext) bool { return ic.ItemID == 1 }).Return([]string{"unique_key_1"}).
				When(func(ic *item_context.ItemContext) bool { return ic.ItemID == 101 }).Return([]string{"unique_key_2"}).
				Build()

			// 执行目标函数
			err := req.itemRepeatCheck(ctx)

			// 断言结果为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	// 场景2：失败场景，报价项和配置清单项存在重复
	t.Run("失败场景-存在重复项", func(t *testing.T) {
		mockey.PatchConvey("当报价项和配置清单项存在重复时,应返回重复错误", t, func() {
			// 准备上下文和请求结构体
			ctx := context.Background()
			req := &UseConfigListReq{
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{1: {}},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{101: {}},
				},
				quoteItems:      []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 1}}},
				configListItems: []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 101}}},
			}

			// 构造模拟的上下文map
			quoteContexts := map[int64]*item_context.ItemContext{1: {ItemID: 1}}
			configListContexts := map[int64]*item_context.ItemContext{101: {ItemID: 101}}

			// Mock依赖函数，使其成功返回
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(quoteContexts, nil).Then(configListContexts, nil)).
				Build()

			// Mock ItemContext的方法，使其返回相同的key，模拟重复情况
			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).Return([]string{"repeat_key"}).Build()

			// 执行目标函数
			err := req.itemRepeatCheck(ctx)

			// 断言返回了业务错误，且错误码和错误信息符合预期
			convey.So(err, convey.ShouldNotBeNil)
			bizErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(bizErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNQuoteItemRepeat))
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制报价单中部分报价项与配置清单中报价项重复，不支持引用配置清单")
		})
	})

	// 场景3：失败场景，创建报价项上下文时发生错误
	t.Run("失败场景-创建报价项上下文失败", func(t *testing.T) {
		mockey.PatchConvey("当创建报价项上下文失败时,应直接返回错误", t, func() {
			// 准备上下文和请求结构体
			ctx := context.Background()
			req := &UseConfigListReq{
				quoteCallbackInfo:      &assistant.CallbackInfo{},
				configListCallbackInfo: &assistant.CallbackInfo{},
			}
			mockErr := errors.New("mock: failed to create quote context")

			// Mock依赖函数，使其第一次调用就返回错误
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(nil, mockErr).Build()

			// 执行目标函数
			err := req.itemRepeatCheck(ctx)

			// 断言返回的错误就是mock的错误
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})

	// 场景4：失败场景，创建配置清单项上下文时发生错误
	t.Run("失败场景-创建配置清单上下文失败", func(t *testing.T) {
		mockey.PatchConvey("当创建配置清单上下文失败时,应直接返回错误", t, func() {
			// 准备上下文和请求结构体
			ctx := context.Background()
			req := &UseConfigListReq{
				quoteCallbackInfo:      &assistant.CallbackInfo{},
				configListCallbackInfo: &assistant.CallbackInfo{},
			}
			mockErr := errors.New("mock: failed to create config list context")

			// Mock依赖函数，第一次调用成功，第二次调用返回错误
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(make(map[int64]*item_context.ItemContext), nil).Then(nil, mockErr)).
				Build()

			// 执行目标函数
			err := req.itemRepeatCheck(ctx)

			// 断言返回的错误就是mock的错误
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})
}

func Test_UseConfigListReq_itemNumCheck_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	t.Run("失败-配置清单报价项列表为空", func(t *testing.T) {
		mockey.PatchConvey("当allConfigListItems为空时，应返回错误", t, func() {
			req := &UseConfigListReq{
				allConfigListItems: []*model.QuoteItem{}, // 空的配置清单项
			}

			err := req.itemNumCheck(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNNoQuoteItem))
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置清单报价项列表为空不支持被引用")
		})
	})

	t.Run("失败-总报价项数超过最大限制", func(t *testing.T) {
		mockey.PatchConvey("当总报价项数超过GetMaxItemNum返回的值时，应返回错误", t, func() {
			maxItemNum := 100
			// Mock GetMaxItemNum返回一个较小的值
			mockey.Mock(config.GetMaxItemNum).Return(maxItemNum).Build()

			req := &UseConfigListReq{
				allConfigListItems: make([]*model.QuoteItem, 50),
				allQuoteItems:      make([]*model.QuoteItem, 51), // 50 + 51 = 101 > 100
			}

			err := req.itemNumCheck(ctx)

			expectedMsg := fmt.Sprintf("所引用配置清单下报价项与该报价单已选报价项总和超过%d条，为保证流程正常，禁止添加！", maxItemNum)
			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNItemNumExceedMaxNum))
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedMsg)
		})
	})

	t.Run("成功-总报价项数等于最大限制", func(t *testing.T) {
		mockey.PatchConvey("当总报价项数等于GetMaxItemNum返回的值时，应校验通过", t, func() {
			maxItemNum := 100
			mockey.Mock(config.GetMaxItemNum).Return(maxItemNum).Build()

			req := &UseConfigListReq{
				allConfigListItems: make([]*model.QuoteItem, 50),
				allQuoteItems:      make([]*model.QuoteItem, 50), // 50 + 50 = 100
			}

			err := req.itemNumCheck(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("成功-总报价项数小于最大限制", func(t *testing.T) {
		mockey.PatchConvey("当总报价项数小于GetMaxItemNum返回的值时，应校验通过", t, func() {
			maxItemNum := 100
			mockey.Mock(config.GetMaxItemNum).Return(maxItemNum).Build()

			req := &UseConfigListReq{
				allConfigListItems: make([]*model.QuoteItem, 40),
				allQuoteItems:      make([]*model.QuoteItem, 50), // 40 + 50 = 90 < 100
			}

			err := req.itemNumCheck(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UseConfigListReq_updateQuote_BitsUTGen(t *testing.T) {
	t.Run("成功-数据库更新成功", func(t *testing.T) {
		mockey.PatchConvey("当数据库更新操作成功时，函数应返回nil", t, func() {
			// 准备测试数据
			req := &UseConfigListReq{
				QuoteID:      123,
				ConfigListID: 456,
			}
			// 准备一个gorm.DB的空实例，仅用于参数传递
			mockTx := &gorm.DB{}

			// Mock dao层更新方法使其返回成功
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "UpdateByCondition")).Return(nil).Build()

			// 执行被测函数
			err := req.updateQuote(context.Background(), mockTx)

			// 断言错误为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("失败-数据库更新失败", func(t *testing.T) {
		mockey.PatchConvey("当数据库更新操作失败时，函数应返回数据库内部错误", t, func() {
			// 准备测试数据
			req := &UseConfigListReq{
				QuoteID:      123,
				ConfigListID: 456,
			}
			mockTx := &gorm.DB{}
			dbErr := errors.New("mocked database update error")

			// Mock dao层更新方法使其返回错误
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "UpdateByCondition")).Return(dbErr).Build()

			// 执行被测函数
			err := req.updateQuote(context.Background(), mockTx)

			// 断言返回了错误
			convey.So(err, convey.ShouldNotBeNil)
			// 断言错误信息包含原始的数据库错误信息
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())

			// 断言错误类型为预期的APIError
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCodeInternalDBError)
		})
	})
}

func Test_UseConfigListReq_Handle_BitsUTGen(t *testing.T) {
	// 初始化上下文
	ctx := context.Background()

	t.Run("成功场景-事务和useConfigList均成功", func(t *testing.T) {
		mockey.PatchConvey("成功场景-事务和useConfigList均成功", t, func() {
			// 准备请求和预期响应
			req := &UseConfigListReq{
				ConfigListID: 1,
				QuoteID:      2,
			}
			expectedResp := &UseConfigListResp{
				QuoteID:      2,
				QuoteItemIDs: []int64{101, 102},
			}

			// 初始化并Mock数据库代理
			dal.DBProxy = &v2.DBProxy{}
			mockDB := &gorm.DB{}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// Mock事务，并执行传入的函数来模拟真实事务行为
			mockey.Mock((*gorm.DB).Transaction).To(func(db *gorm.DB, fc func(tx *gorm.DB) error, opts ...*sql.TxOptions) error {
				return fc(db)
			}).Build()

			// Mock核心业务逻辑useConfigList以返回成功结果
			mockey.Mock((*UseConfigListReq).useConfigList).Return(expectedResp, nil).Build()

			// 执行目标方法
			resp, err := req.Handle(ctx)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldResemble, expectedResp)
		})
	})

	t.Run("失败场景-useConfigList在事务内返回错误", func(t *testing.T) {
		mockey.PatchConvey("失败场景-useConfigList在事务内返回错误", t, func() {
			// 准备请求和预期错误
			req := &UseConfigListReq{}
			expectedErr := errors.New("useConfigList failed inside transaction")

			// 初始化并Mock数据库代理
			dal.DBProxy = &v2.DBProxy{}
			mockDB := &gorm.DB{}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// Mock事务，并执行传入的函数
			mockey.Mock((*gorm.DB).Transaction).To(func(db *gorm.DB, fc func(tx *gorm.DB) error, opts ...*sql.TxOptions) error {
				return fc(db)
			}).Build()

			// Mock核心业务逻辑useConfigList以返回错误
			mockey.Mock((*UseConfigListReq).useConfigList).Return(nil, expectedErr).Build()

			// 执行目标方法
			resp, err := req.Handle(ctx)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "useConfigList failed inside transaction")
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-数据库事务本身失败", func(t *testing.T) {
		mockey.PatchConvey("失败场景-数据库事务本身失败", t, func() {
			// 准备请求和预期错误
			req := &UseConfigListReq{}
			txErr := errors.New("transaction failed")

			// 初始化并Mock数据库代理
			dal.DBProxy = &v2.DBProxy{}
			mockDB := &gorm.DB{}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// Mock事务直接返回错误，此时useConfigList不会被调用
			mockey.Mock((*gorm.DB).Transaction).Return(txErr).Build()

			// 执行目标方法
			resp, err := req.Handle(ctx)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "transaction failed")
			convey.So(resp, convey.ShouldBeNil)
		})
	})
}

func Test_UseConfigListReq_saveSolutions_BitsUTGen(t *testing.T) {
	t.Run("场景：解决方案列表为空", func(t *testing.T) {
		mockey.PatchConvey("当configListSolutions为空时，应直接返回nil, nil", t, func() {
			// 准备一个请求，其解决方案列表为空
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{},
			}

			// 执行目标方法
			resultMap, err := r.saveSolutions(context.Background(), &gorm.DB{})

			// 断言错误和返回的map均为空
			convey.So(err, convey.ShouldBeNil)
			convey.So(resultMap, convey.ShouldBeNil)
		})
	})

	t.Run("场景：保存解决方案成功", func(t *testing.T) {
		mockey.PatchConvey("当DAL保存成功时，应返回新旧ID映射并更新原对象", t, func() {
			// 准备包含多个解决方案的请求数据
			r := &UseConfigListReq{
				QuoteID: 99,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{
						CreatorAccountID: "test-creator-id",
					},
				},
				configListSolutions: []*model.QuoteSolution{
					{BaseDB: framework.BaseDB{Id: 1}},
					{BaseDB: framework.BaseDB{Id: 2}},
				},
			}

			// Mock DAL的Save方法，模拟GORM保存后回填ID的行为
			mockey.Mock(mockey.GetMethod(dal.QuoteSolutionDao, "Save")).To(func(tx *gorm.DB, data interface{}, tb schema.Tabler) error {
				solutions, ok := data.([]*model.QuoteSolution)
				convey.So(ok, convey.ShouldBeTrue)
				solutions[0].Id = 101 // 模拟新生成的ID
				solutions[1].Id = 102 // 模拟新生成的ID
				return nil
			}).Build()

			// 执行目标方法
			resultMap, err := r.saveSolutions(context.Background(), &gorm.DB{})

			// 断言无错误，且返回的ID映射符合预期
			convey.So(err, convey.ShouldBeNil)
			expectedMap := map[int64]int64{
				1: 101,
				2: 102,
			}
			convey.So(resultMap, convey.ShouldResemble, expectedMap)
			// 同时验证传入的solution对象字段是否被正确修改
			convey.So(r.configListSolutions[0].QuoteId, convey.ShouldEqual, int64(99))
			convey.So(r.configListSolutions[0].CreatorAccountId, convey.ShouldEqual, "test-creator-id")
			convey.So(r.configListSolutions[0].SolutionCopyFrom, convey.ShouldEqual, int64(1))
		})
	})

	t.Run("场景：保存解决方案失败", func(t *testing.T) {
		mockey.PatchConvey("当DAL保存失败时，应向上层透传错误", t, func() {
			// 准备请求数据和预设的数据库错误
			dbErr := errors.New("database save error")
			r := &UseConfigListReq{
				QuoteID: 99,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{
						CreatorAccountID: "test-creator-id",
					},
				},
				configListSolutions: []*model.QuoteSolution{
					{BaseDB: framework.BaseDB{Id: 1}},
				},
			}

			// Mock DAL的Save方法，使其返回错误
			mockey.Mock(mockey.GetMethod(dal.QuoteSolutionDao, "Save")).Return(dbErr).Build()

			// 执行目标方法
			resultMap, err := r.saveSolutions(context.Background(), &gorm.DB{})

			// 断言返回的错误符合预期，且map为nil
			convey.So(err, convey.ShouldEqual, dbErr)
			convey.So(resultMap, convey.ShouldBeNil)
		})
	})
}

func Test_UseConfigListReq_solutionRepeatCheck_BitsUTGen(t *testing.T) {
	t.Run("正常场景-无重复解决方案", func(t *testing.T) {
		mockey.PatchConvey("正常场景-无重复解决方案", t, func() {
			// 准备测试数据，配置清单和报价单中均无重复的解决方案
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{
					{TradeSolution: "sol-A", TradeSolutionVersion: "v1"},
					{TradeSolution: "sol-B", TradeSolutionVersion: "v1"},
				},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{
						{TradeSolution: "sol-C", TradeSolutionVersion: "v1"},
						{TradeSolution: "sol-D", TradeSolutionVersion: "v1"},
					},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期不返回错误
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-配置清单内存在重复解决方案", func(t *testing.T) {
		mockey.PatchConvey("失败场景-配置清单内存在重复解决方案", t, func() {
			// 准备测试数据，配置清单内存在重复的解决方案
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{
					{TradeSolution: "sol-A", TradeSolutionVersion: "v1"},
					{TradeSolution: "sol-A", TradeSolutionVersion: "v1"}, // 重复项
				},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期返回错误，并检查错误信息
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "所引用配置清单下存在重复解决方案或套餐，请重新选择配置清单！")
		})
	})

	t.Run("失败场景-配置清单与报价单存在重复解决方案", func(t *testing.T) {
		mockey.PatchConvey("失败场景-配置清单与报价单存在重复解决方案", t, func() {
			// 准备测试数据，配置清单的解决方案与当前报价单的解决方案存在重复
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{
					{TradeSolution: "sol-A", TradeSolutionVersion: "v1"},
					{TradeSolution: "sol-B", TradeSolutionVersion: "v1"},
				},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{
						{TradeSolution: "sol-C", TradeSolutionVersion: "v1"},
						{TradeSolution: "sol-A", TradeSolutionVersion: "v1", TradeSolutionName: "重复方案A"}, // 重复项
					},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期返回错误，并检查错误信息
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "所引用配置清单与当前项目制报价单内解决方案或套餐重复，请重新选择配置清单！重复解决方案或套餐名称：重复方案A")
		})
	})

	t.Run("边缘场景-配置清单和报价单解决方案均为空", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-配置清单和报价单解决方案均为空", t, func() {
			// 准备测试数据，两个解决方案列表都为空
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期不返回错误
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("边缘场景-报价单解决方案为空", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-报价单解决方案为空", t, func() {
			// 准备测试数据，仅当前报价单的解决方案列表为空
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{
					{TradeSolution: "sol-A", TradeSolutionVersion: "v1"},
				},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期不返回错误
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("边缘场景-配置清单解决方案为空", func(t *testing.T) {
		mockey.PatchConvey("边缘场景-配置清单解决方案为空", t, func() {
			// 准备测试数据，仅配置清单的解决方案列表为空
			r := &UseConfigListReq{
				configListSolutions: []*model.QuoteSolution{},
				quoteCallbackInfo: &assistant.CallbackInfo{
					AllQuoteSolutions: []*model.QuoteSolution{
						{TradeSolution: "sol-A", TradeSolutionVersion: "v1"},
					},
				},
			}

			// 执行被测函数
			err := r.solutionRepeatCheck(context.Background())

			// 断言结果，预期不返回错误
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UseConfigListReq_validateGuarantee_BitsUTGen(t *testing.T) {
	t.Run("异常场景-查询保底项发生异常", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟DAO返回异常错误，满足IsExceptionError为true
			dbErr := errors.New("mock db error")
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindByQuoteID")).Return(nil, dbErr).Build()

			r := &UseConfigListReq{QuoteID: 100}
			err := r.validateGuarantee(context.Background(), &gorm.DB{})

			// 应直接返回底层错误
			convey.So(err, convey.ShouldEqual, dbErr)
		})
	})

	t.Run("成功场景-无保底记录返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟未查询到记录：返回nil对象和ErrRecordNotFound
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindByQuoteID")).Return(nil, gorm.ErrRecordNotFound).Build()

			r := &UseConfigListReq{QuoteID: 101}
			err := r.validateGuarantee(context.Background(), &gorm.DB{})

			// 无保底记录应返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("成功场景-保底类型为其他返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟查询到保底项，类型为Other
			item := &model.GuaranteeItem{GuaranteeType: multienv.GuaranteeTypeOther}
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindByQuoteID")).Return(item, nil).Build()

			r := &UseConfigListReq{QuoteID: 102}
			err := r.validateGuarantee(context.Background(), &gorm.DB{})

			// 保底类型为其他，应返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-存在节省计划商品且保底类型为所有", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟查询到保底项，类型为All
			item := &model.GuaranteeItem{GuaranteeType: multienv.GuaranteeTypeAll}
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindByQuoteID")).Return(item, nil).Build()

			// 构造配置清单中含有节省计划商品
			spItem := &model.QuoteItem{SalesMode: multienv.SalesModeSavingsPlans}
			r := &UseConfigListReq{
				QuoteID:         103,
				configListItems: []*model.QuoteItem{spItem},
			}

			err := r.validateGuarantee(context.Background(), &gorm.DB{})

			// 应返回业务错误，错误码为NSP不支持保底
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置清单存在节省计划商品，报价单保底类型不支持选择所有报价项参与保底，不支持被引用")
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNSPNotSupportGuarantee))
		})
	})

	t.Run("成功场景-存在节省计划商品但保底类型非所有", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟查询到保底项，类型为非All非Other（例如2）
			item := &model.GuaranteeItem{GuaranteeType: 2}
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindByQuoteID")).Return(item, nil).Build()

			// 配置清单中包含节省计划商品，但由于保底类型不是All，应最终返回nil
			spItem := &model.QuoteItem{SalesMode: multienv.SalesModeSavingsPlans}
			normalItem := &model.QuoteItem{SalesMode: "Others"}
			r := &UseConfigListReq{
				QuoteID:         104,
				configListItems: []*model.QuoteItem{spItem, normalItem},
			}

			err := r.validateGuarantee(context.Background(), &gorm.DB{})

			// 应走到循环结束后的最终返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

//go:noinline
func newCallbackInfo() *assistant.CallbackInfo {
	return &assistant.CallbackInfo{
		Quote:            &model.Quote{CreatorAccountID: "creator"},
		AllQuoteItems:    []*model.QuoteItem{},
		AllDeliveryItems: []*model.QuoteItem{},
		AllItemValues:    map[int64][]*model.QuoteItemValue{},
	}
}

//go:noinline
func mockSuccessCallbacks(req *UseConfigListReq, quoteInfo, configInfo *assistant.CallbackInfo) {
	mockey.Mock(assistant.Callback).
		When(func(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...assistant.CallbackOption) bool {
			return quoteID == req.QuoteID
		}).
		Return(quoteInfo, nil).
		When(func(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...assistant.CallbackOption) bool {
			return quoteID == req.ConfigListID
		}).
		Return(configInfo, nil).
		Build()
}

func Test_UseConfigListReq_saveItems_BitsUTGen(t *testing.T) {
	t.Run("删除报价项失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(quote_item_service.DeleteQuoteItems).Return(nil, errors.New("delete failed")).Build()

			req := &UseConfigListReq{
				QuoteID:            100,
				deleteQuoteItemIDs: []int64{1, 2},
			}
			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "delete failed")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("初始化ItemContext失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(nil, errors.New("context init failed")).Build()

			req := &UseConfigListReq{
				QuoteID: 200,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{},
				},
				allConfigListItems: []*model.QuoteItem{&model.QuoteItem{}},
			}
			// 设置Id在结构体创建之后
			req.allConfigListItems[0].Id = 1

			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "context init failed")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("保存报价项失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockValue(&dal.QuoteItemDao).To(dal.QuoteItemDao)

			icMap := map[int64]*item_context.ItemContext{
				10: {ItemID: 10},
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(icMap, nil).Build()
			mockey.Mock((*item_context.ItemContext).GetDisplayConfigurationInfo).Return(&product_config_load.ConfigurationInfo{IncomeType: "once", ConfigIsPublic: 1}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "SaveWithOption")).Return(errors.New("save items failed")).Build()

			item := &model.QuoteItem{TradeProduct: "tp1", QuoteSolutionID: 1}
			item.Id = 10

			allItem := &model.QuoteItem{}
			allItem.Id = 10

			req := &UseConfigListReq{
				QuoteID: 300,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{},
					ProductInfos:  map[string]*trade_client.TradeProductVersionInfo{},
				},
				configListItems:    []*model.QuoteItem{item},
				allConfigListItems: []*model.QuoteItem{allItem},
			}
			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{1: 1001})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "save items failed")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("交付项所属报价项缺失返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockValue(&dal.QuoteItemDao).To(dal.QuoteItemDao)

			icMap := map[int64]*item_context.ItemContext{
				10: {ItemID: 10},
				30: {ItemID: 30},
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(icMap, nil).Build()
			mockey.Mock((*item_context.ItemContext).GetDisplayConfigurationInfo).Return(nil, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "SaveWithOption")).Return(nil).Build()

			item := &model.QuoteItem{TradeProduct: "tp1", QuoteSolutionID: 1}
			item.Id = 10
			dItem := &model.QuoteItem{TradeProduct: "tpd1", ItemBelong: 9999, QuoteSolutionID: 1}
			dItem.Id = 30

			allItem1 := &model.QuoteItem{}
			allItem1.Id = 10
			allItem2 := &model.QuoteItem{}
			allItem2.Id = 30

			req := &UseConfigListReq{
				QuoteID: 400,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{},
					ProductInfos:  map[string]*trade_client.TradeProductVersionInfo{},
				},
				configListItems:         []*model.QuoteItem{item},
				configListDeliveryItems: []*model.QuoteItem{dItem},
				allConfigListItems:      []*model.QuoteItem{allItem1, allItem2},
			}
			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{1: 1001})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置清单中部分交付项所属报价项缺失")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("保存交付项失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockValue(&dal.QuoteItemDao).To(dal.QuoteItemDao)

			icMap := map[int64]*item_context.ItemContext{
				10: {ItemID: 10},
				15: {ItemID: 15},
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(icMap, nil).Build()
			mockey.Mock((*item_context.ItemContext).GetDisplayConfigurationInfo).Return(nil, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "SaveWithOption")).
				Return(mockey.Sequence(nil).Then(errors.New("save delivery failed"))).Build()

			item := &model.QuoteItem{TradeProduct: "tp1", QuoteSolutionID: 1}
			item.Id = 10
			dItem := &model.QuoteItem{TradeProduct: "tpd1", ItemBelong: 10, QuoteSolutionID: 1}
			dItem.Id = 15

			allItem1 := &model.QuoteItem{}
			allItem1.Id = 10
			allItem2 := &model.QuoteItem{}
			allItem2.Id = 15

			req := &UseConfigListReq{
				QuoteID: 500,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote:         &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{},
					ProductInfos:  map[string]*trade_client.TradeProductVersionInfo{},
				},
				configListItems:         []*model.QuoteItem{item},
				configListDeliveryItems: []*model.QuoteItem{dItem},
				allConfigListItems:      []*model.QuoteItem{allItem1, allItem2},
			}
			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{1: 1001})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "save delivery failed")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("保存属性失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockValue(&dal.QuoteItemDao).To(dal.QuoteItemDao)
			mockey.MockValue(&dal.QuoteItemValueDao).To(dal.QuoteItemValueDao)

			icMap := map[int64]*item_context.ItemContext{
				10: {ItemID: 10},
				20: {ItemID: 20},
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(icMap, nil).Build()
			mockey.Mock((*item_context.ItemContext).GetDisplayConfigurationInfo).Return(nil, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "SaveWithOption")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemValueDao, "BatchSave")).Return(errors.New("batch save failed")).Build()

			item := &model.QuoteItem{TradeProduct: "tp1", QuoteSolutionID: 1}
			item.Id = 10
			dItem := &model.QuoteItem{TradeProduct: "tp2", ItemBelong: 10, QuoteSolutionID: 1}
			dItem.Id = 20

			allItem1 := &model.QuoteItem{}
			allItem1.Id = 10
			allItem2 := &model.QuoteItem{}
			allItem2.Id = 20

			v10_1 := &model.QuoteItemValue{}
			v10_1.Id = 1001
			v10_2 := &model.QuoteItemValue{}
			v10_2.Id = 1002
			v20_1 := &model.QuoteItemValue{}
			v20_1.Id = 2001

			req := &UseConfigListReq{
				QuoteID: 600,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{
						10: {v10_1, v10_2},
						20: {v20_1},
					},
					ProductInfos: map[string]*trade_client.TradeProductVersionInfo{
						"tp1":  {InvoiceProject: "inv1", SalesMode: "SM1", ConfigPublicDisplay: 1},
						"tp2":  {InvoiceProject: "inv2", SalesMode: "SM2", ConfigPublicDisplay: 2},
						"tpd1": {InvoiceProject: "invd1", SalesMode: "SMD1", ConfigPublicDisplay: 1},
					},
				},
				configListItems:         []*model.QuoteItem{item},
				configListDeliveryItems: []*model.QuoteItem{dItem},
				allConfigListItems:      []*model.QuoteItem{allItem1, allItem2},
			}

			tx := &gorm.DB{}
			ctx := context.Background()

			ids, err := req.saveItems(ctx, tx, map[int64]int64{1: 1001})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "batch save failed")
			convey.So(ids, convey.ShouldBeNil)
		})
	})

	t.Run("全部成功返回新报价项ID列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockValue(&dal.QuoteItemDao).To(dal.QuoteItemDao)
			mockey.MockValue(&dal.QuoteItemValueDao).To(dal.QuoteItemValueDao)

			icMap := map[int64]*item_context.ItemContext{
				10: {ItemID: 10, TradeProduct: "tp1"},
				20: {ItemID: 20, TradeProduct: "tp2"},
				30: {ItemID: 30, TradeProduct: "tpd1"},
			}
			mockey.MockUnsafe(item_context.NewItemContextByQuoteItemValues).Return(icMap, nil).Build()

			mockey.Mock((*item_context.ItemContext).GetDisplayConfigurationInfo).
				To(func(ic *item_context.ItemContext, ctx context.Context) (*product_config_load.ConfigurationInfo, error) {
					if ic.ItemID == 10 || ic.ItemID == 30 {
						return &product_config_load.ConfigurationInfo{IncomeType: "once", ConfigIsPublic: 1}, nil
					}
					return nil, nil
				}).Build()

			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "SaveWithOption")).
				To(func(tx *gorm.DB, items []*model.QuoteItem, tb schema.Tabler, opts ...dal.QuoteItemSaveOption) error {
					if len(items) == 2 {
						for i := range items {
							items[i].Id = 101 + int64(i)
						}
					} else {
						for i := range items {
							items[i].Id = 201 + int64(i)
						}
					}
					return nil
				}).Build()

			var capturedValues []*model.QuoteItemValue
			mockey.Mock(mockey.GetMethod(dal.QuoteItemValueDao, "BatchSave")).
				To(func(tx *gorm.DB, data interface{}, tb schema.Tabler, batchSize int) error {
					if vs, ok := data.([]*model.QuoteItemValue); ok {
						capturedValues = vs
					}
					return nil
				}).Build()

			item1 := &model.QuoteItem{TradeProduct: "tp1", QuoteSolutionID: 1}
			item1.Id = 10
			item2 := &model.QuoteItem{TradeProduct: "tp2", QuoteSolutionID: 1}
			item2.Id = 20
			dItem := &model.QuoteItem{TradeProduct: "tpd1", ItemBelong: 10, QuoteSolutionID: 1}
			dItem.Id = 30

			allItem1 := &model.QuoteItem{}
			allItem1.Id = 10
			allItem2 := &model.QuoteItem{}
			allItem2.Id = 20
			allItem3 := &model.QuoteItem{}
			allItem3.Id = 30

			v10_1 := &model.QuoteItemValue{}
			v10_1.Id = 1001
			v10_2 := &model.QuoteItemValue{}
			v10_2.Id = 1002
			v30_1 := &model.QuoteItemValue{}
			v30_1.Id = 3001

			req := &UseConfigListReq{
				QuoteID: 700,
				quoteCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{CreatorAccountID: "creator@x.com"},
				},
				configListCallbackInfo: &assistant.CallbackInfo{
					Quote: &model.Quote{},
					AllItemValues: map[int64][]*model.QuoteItemValue{
						10: {v10_1, v10_2},
						30: {v30_1},
					},
						ProductInfos: map[string]*trade_client.TradeProductVersionInfo{
							"tp1":  {InvoiceProject: "inv1", IncomeCode: "income-1", SalesMode: "SM1", ConfigPublicDisplay: 1},
							"tpd1": {InvoiceProject: "invd1", IncomeCode: "income-d1", SalesMode: "SMD1", ConfigPublicDisplay: 2},
						},
				},
				configListItems:         []*model.QuoteItem{item1, item2},
				configListDeliveryItems: []*model.QuoteItem{dItem},
				allConfigListItems:      []*model.QuoteItem{allItem1, allItem2, allItem3},
			}
			tx := &gorm.DB{}
			ctx := context.Background()
			solutionIDMapping := map[int64]int64{1: 1001}

			ids, err := req.saveItems(ctx, tx, solutionIDMapping)
			convey.So(err, convey.ShouldBeNil)
			convey.So(ids, convey.ShouldResemble, []int64{101, 102})

			convey.So(req.configListDeliveryItems[0].ItemBelong, convey.ShouldEqual, int64(101))
			convey.So(req.configListItems[0].IncomeCode, convey.ShouldEqual, "income-1")
			convey.So(req.configListItems[0].TaxRuleType, convey.ShouldEqual, multienv.TaxRuleTypeSingleSale)
			convey.So(req.configListDeliveryItems[0].IncomeCode, convey.ShouldEqual, "income-d1")
			convey.So(req.configListDeliveryItems[0].TaxRuleType, convey.ShouldEqual, multienv.TaxRuleTypeSingleSale)

			var has101, has201 bool
			for _, v := range capturedValues {
				if v.QuoteItemID == 101 {
					has101 = true
				}
				if v.QuoteItemID == 201 {
					has201 = true
				}
				convey.So(v.Id, convey.ShouldEqual, 0)
				convey.So(v.QuoteID, convey.ShouldEqual, int64(700))
				convey.So(v.CreatorAccountID, convey.ShouldEqual, "creator@x.com")
			}
			convey.So(has101, convey.ShouldBeTrue)
			convey.So(has201, convey.ShouldBeTrue)
		})
	})
}

//go:noinline
func newUseConfigListCallbackInfo() *assistant.CallbackInfo {
	return &assistant.CallbackInfo{
		Quote:             &model.Quote{CreatorAccountID: "creator"},
		AllQuoteItems:     []*model.QuoteItem{},
		AllDeliveryItems:  []*model.QuoteItem{},
		AllItemValues:     map[int64][]*model.QuoteItemValue{},
		AllQuoteSolutions: []*model.QuoteSolution{},
	}
}

//go:noinline
func mockUseConfigListCallbacks(req *UseConfigListReq, quoteInfo *assistant.CallbackInfo, quoteErr pkg_errors.APIError, configInfo *assistant.CallbackInfo, configErr pkg_errors.APIError) {
	mockey.Mock(assistant.Callback).To(func(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...assistant.CallbackOption) (*assistant.CallbackInfo, pkg_errors.APIError) {
		if quoteID == req.QuoteID {
			return quoteInfo, quoteErr
		}
		if quoteID == req.ConfigListID {
			return configInfo, configErr
		}
		return (*assistant.CallbackInfo)(nil), (pkg_errors.APIError)(nil)
	}).Build()
}

//go:noinline
func mockUseConfigListCallbacksSuccess(req *UseConfigListReq, quoteInfo, configInfo *assistant.CallbackInfo) {
	mockUseConfigListCallbacks(req, quoteInfo, (pkg_errors.APIError)(nil), configInfo, (pkg_errors.APIError)(nil))
}

//go:noinline
func mockUseConfigListProcessChecksSuccess() {
	mockey.Mock(processcheck.AllowQuoteOP).Return((pkg_errors.APIError)(nil)).Build()
	mockey.Mock(processcheck.FullQuoteDataCheck).Return(processcheck.FullQuoteDataCheckResp{Success: true}, (pkg_errors.APIError)(nil)).Build()
}

//go:noinline
func mockUseConfigListReqChecksSuccess() {
	mockey.Mock((*UseConfigListReq).itemNumCheck).Return((error)(nil)).Build()
	mockey.Mock((*UseConfigListReq).validateConfigListItems).Return((error)(nil)).Build()
	mockey.Mock((*UseConfigListReq).solutionRepeatCheck).Return((error)(nil)).Build()
	mockey.Mock((*UseConfigListReq).itemRepeatCheck).Return((error)(nil)).Build()
}

//go:noinline
func mockUseConfigListPersistenceSuccess(quoteItemIDs []int64) {
	mockey.Mock((*UseConfigListReq).saveSolutions).Return(map[int64]int64{1: 101}, (error)(nil)).Build()
	mockey.Mock((*UseConfigListReq).saveItems).Return(quoteItemIDs, (error)(nil)).Build()
	mockey.Mock((*UseConfigListReq).updateQuote).Return((error)(nil)).Build()
}
func TestUseConfigListReq_useConfigList_BitsUTGen(t *testing.T) {
	t.Run("首次回调返回错误时直接失败", func(t *testing.T) {
		mockey.PatchConvey("首次回调返回错误时直接失败", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 1, ConfigListID: 2}

			apiErr := pkg_errors.NewBizErrWithMsg(pkg_errors.HistoryInternalErrCode, "quote callback error")
			var expectedErr error = apiErr
			mockUseConfigListCallbacks(req, nil, apiErr, nil, nil)

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("配置清单回调返回错误时直接失败", func(t *testing.T) {
		mockey.PatchConvey("配置清单回调返回错误时直接失败", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 3, ConfigListID: 4}
			quoteInfo := newUseConfigListCallbackInfo()

			apiErr := pkg_errors.NewBizErrWithMsg(pkg_errors.HistoryInternalErrCode, "config list callback error")
			var expectedErr error = apiErr
			mockUseConfigListCallbacks(req, quoteInfo, nil, nil, apiErr)

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
			if req.quoteCallbackInfo != quoteInfo {
				t.Fatalf("quoteCallbackInfo should be assigned before second callback failure")
			}
		})
	})

	t.Run("操作权限校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("操作权限校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 5, ConfigListID: 6}

			apiErr := pkg_errors.NewBizErrWithMsg(pkg_errors.HistoryInternalErrCode, "allow quote op error")
			var expectedErr error = apiErr
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockey.Mock(processcheck.AllowQuoteOP).Return(apiErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("全量数据校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("全量数据校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 7, ConfigListID: 8}

			apiErr := pkg_errors.NewBizErrWithMsg(pkg_errors.HistoryInternalErrCode, "full quote data check error")
			var expectedErr error = apiErr
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockey.Mock(processcheck.AllowQuoteOP).Return((pkg_errors.APIError)(nil)).Build()
			mockey.Mock(processcheck.FullQuoteDataCheck).Return(processcheck.FullQuoteDataCheckResp{}, apiErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("报价项数量校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("报价项数量校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 9, ConfigListID: 10}

			expectedErr := errors.New("item num check error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockey.Mock((*UseConfigListReq).itemNumCheck).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("配置清单项校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("配置清单项校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 11, ConfigListID: 12}

			expectedErr := errors.New("validate config list items error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockey.Mock((*UseConfigListReq).itemNumCheck).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).validateConfigListItems).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("解决方案重复校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("解决方案重复校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 13, ConfigListID: 14}

			expectedErr := errors.New("solution repeat check error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockey.Mock((*UseConfigListReq).itemNumCheck).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).validateConfigListItems).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).solutionRepeatCheck).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("报价项重复校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("报价项重复校验失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 15, ConfigListID: 16}

			expectedErr := errors.New("item repeat check error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockey.Mock((*UseConfigListReq).itemNumCheck).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).validateConfigListItems).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).solutionRepeatCheck).Return((error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).itemRepeatCheck).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("保存解决方案失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("保存解决方案失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 17, ConfigListID: 18}

			expectedErr := errors.New("save solutions error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockey.Mock((*UseConfigListReq).saveSolutions).Return(map[int64]int64(nil), expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("保存报价项失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("保存报价项失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 19, ConfigListID: 20}

			expectedErr := errors.New("save items error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockey.Mock((*UseConfigListReq).saveSolutions).Return(map[int64]int64{1: 101}, (error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).saveItems).Return([]int64(nil), expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("更新报价单失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("更新报价单失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 21, ConfigListID: 22}

			expectedErr := errors.New("update quote error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockey.Mock((*UseConfigListReq).saveSolutions).Return(map[int64]int64{1: 101}, (error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).saveItems).Return([]int64{1001, 1002}, (error)(nil)).Build()
			mockey.Mock((*UseConfigListReq).updateQuote).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("询价开关关闭且更新询价失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("询价开关关闭且更新询价失败时返回错误", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 23, ConfigListID: 24}

			expectedErr := errors.New("inquiry update error")
			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockUseConfigListPersistenceSuccess([]int64{2001, 2002})
			mockey.MockUnsafe(config.GetSwitchIsOpenByName).Return(false).Build()
			mockey.Mock((*inquery_service.InquiryService).UpdateInquiryOnQuoteItemChange).Return(expectedErr).Build()

			resp, err := req.useConfigList(ctx, tx)
			if resp != nil {
				t.Fatalf("resp should be nil, got %+v", resp)
			}
			if err != expectedErr {
				t.Fatalf("err mismatch, got %v want %v", err, expectedErr)
			}
		})
	})

	t.Run("询价开关开启时跳过询价并成功返回结果", func(t *testing.T) {
		mockey.PatchConvey("询价开关开启时跳过询价并成功返回结果", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 25, ConfigListID: 26}
			quoteInfo := newUseConfigListCallbackInfo()
			configInfo := newUseConfigListCallbackInfo()
			wantItemIDs := []int64{3001, 3002}

			mockUseConfigListCallbacksSuccess(req, quoteInfo, configInfo)
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockUseConfigListPersistenceSuccess(wantItemIDs)
			mockey.MockUnsafe(config.GetSwitchIsOpenByName).Return(true).Build()
			mockey.Mock((*inquery_service.InquiryService).UpdateInquiryOnQuoteItemChange).Return(errors.New("should not be called")).Build()

			resp, err := req.useConfigList(ctx, tx)
			if err != nil {
				t.Fatalf("unexpected err: %v", err)
			}
			if resp == nil {
				t.Fatalf("resp should not be nil")
			}
			if resp.QuoteID != req.QuoteID {
				t.Fatalf("QuoteID mismatch, got %d want %d", resp.QuoteID, req.QuoteID)
			}
			if !reflect.DeepEqual(resp.QuoteItemIDs, wantItemIDs) {
				t.Fatalf("QuoteItemIDs mismatch, got %+v want %+v", resp.QuoteItemIDs, wantItemIDs)
			}
			if req.quoteCallbackInfo != quoteInfo {
				t.Fatalf("quoteCallbackInfo not assigned")
			}
			if req.configListCallbackInfo != configInfo {
				t.Fatalf("configListCallbackInfo not assigned")
			}
		})
	})

	t.Run("询价开关关闭且更新询价成功时返回结果", func(t *testing.T) {
		mockey.PatchConvey("询价开关关闭且更新询价成功时返回结果", t, func() {
			ctx := context.Background()
			tx := &gorm.DB{}
			req := &UseConfigListReq{QuoteID: 27, ConfigListID: 28}
			wantItemIDs := []int64{4001, 4002}

			mockUseConfigListCallbacksSuccess(req, newUseConfigListCallbackInfo(), newUseConfigListCallbackInfo())
			mockUseConfigListProcessChecksSuccess()
			mockUseConfigListReqChecksSuccess()
			mockUseConfigListPersistenceSuccess(wantItemIDs)
			mockey.MockUnsafe(config.GetSwitchIsOpenByName).Return(false).Build()
			mockey.Mock((*inquery_service.InquiryService).UpdateInquiryOnQuoteItemChange).Return((error)(nil)).Build()

			resp, err := req.useConfigList(ctx, tx)
			if err != nil {
				t.Fatalf("unexpected err: %v", err)
			}
			if resp == nil {
				t.Fatalf("resp should not be nil")
			}
			if resp.QuoteID != req.QuoteID {
				t.Fatalf("QuoteID mismatch, got %d want %d", resp.QuoteID, req.QuoteID)
			}
			if !reflect.DeepEqual(resp.QuoteItemIDs, wantItemIDs) {
				t.Fatalf("QuoteItemIDs mismatch, got %+v want %+v", resp.QuoteItemIDs, wantItemIDs)
			}
		})
	})
}

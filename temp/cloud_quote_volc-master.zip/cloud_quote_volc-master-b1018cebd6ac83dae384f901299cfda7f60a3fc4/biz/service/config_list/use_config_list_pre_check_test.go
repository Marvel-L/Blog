package config_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func Test_UseConfigListPreCheckReq_Handle_BitsUTGen(t *testing.T) {
	// 初始化共享的mock数据
	ctx := context.Background()
	mockErr := errors.New("mock error")
	mockApiErr := pkg_errors.ErrInternalError.WithArgs("mock api error")
	mockDB := &gorm.DB{}

	t.Run("成功场景-无缺失无重复", func(t *testing.T) {
		mockey.PatchConvey("成功场景-所有检查通过", t, func() {
			// Mock DB
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			// Mock assistant.Callback
			quoteCallbackInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB:              framework.BaseDB{Id: 1},
					QuoteRelatedProduct: `[0, 1]`, // 包含公有云和私有云
				},
			}
			configListCallbackInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				AllQuoteItems: []*model.QuoteItem{
					{BaseDB: framework.BaseDB{Id: 101}, ItemType: 0},
				},
			}
			mockey.Mock(assistant.Callback).
				When(func(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...assistant.CallbackOption) bool {
					return quoteID == 1
				}).Return(quoteCallbackInfo, nil).
				When(func(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...assistant.CallbackOption) bool {
					return quoteID == 2
				}).Return(configListCallbackInfo, nil).Build()

			// Mock processcheck.AllowQuoteOP
			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()

			// Mock item_context.NewItemContextByQuoteItemValues
			quoteItemContexts := map[int64]*item_context.ItemContext{
				1: {ItemID: 1},
			}
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
			}
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(quoteItemContexts, nil).
					Then(configListItemContexts, nil)).
				Build()

			// Mock item_context.GetRepeatCheckKey
			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(r *item_context.ItemContext) bool {
					return r.ItemID == 1
				}).Return([]string{"key_quote"}).
				When(func(r *item_context.ItemContext) bool {
					return r.ItemID == 101
				}).Return([]string{"key_config_list"}).Build()

			req := &UseConfigListPreCheckReq{
				ConfigListID: 2,
				QuoteID:      1,
			}
			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			checkResp, ok := resp.(*UseConfigListPreCheckResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(checkResp.RelatedProductMiss, convey.ShouldBeFalse)
			convey.So(checkResp.QuoteItemRepeat, convey.ShouldBeFalse)
			convey.So(len(checkResp.MissProductTypes), convey.ShouldEqual, 0)
			convey.So(len(checkResp.RepeatQuoteItemIDMap), convey.ShouldEqual, 0)
		})
	})

	t.Run("失败场景-assistant_Callback获取报价单失败", func(t *testing.T) {
		mockey.PatchConvey("当第一个assistant.Callback调用返回错误时，函数应立即返回该错误", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()
			mockey.Mock(assistant.Callback).Return(nil, mockApiErr).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock api error")
		})
	})

	t.Run("失败场景-assistant_Callback获取配置清单失败", func(t *testing.T) {
		mockey.PatchConvey("当第二个assistant.Callback调用返回错误时，函数应立即返回该错误", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()
			mockey.Mock(assistant.Callback).
				Return(mockey.Sequence(&assistant.CallbackInfo{}, nil).
					Then(nil, mockApiErr)).
				Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock api error")
		})
	})

	t.Run("失败场景-processcheck_AllowQuoteOP权限检查失败", func(t *testing.T) {
		mockey.PatchConvey("当processcheck.AllowQuoteOP返回错误时，函数应立即返回该错误", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			mockey.Mock(assistant.Callback).Return(&assistant.CallbackInfo{Quote: &model.Quote{}}, nil).Build()
			mockey.Mock(processcheck.AllowQuoteOP).Return(mockApiErr).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock api error")
		})
	})

	t.Run("检查场景-存在缺失的商品类型", func(t *testing.T) {
		mockey.PatchConvey("当配置清单包含报价单所没有的商品类型时，应正确识别", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			quoteCallbackInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{
					BaseDB:              framework.BaseDB{Id: 1},
					QuoteRelatedProduct: `[0]`, // 只包含公有云
				},
			}
			configListCallbackInfo := &assistant.CallbackInfo{
				Quote: &model.Quote{BaseDB: framework.BaseDB{Id: 2}},
				AllQuoteItems: []*model.QuoteItem{
					{BaseDB: framework.BaseDB{Id: 101}, ItemType: 1, StandardProduct: 1}, // 私有云标品
				},
			}
			mockey.Mock(assistant.Callback).
				Return(mockey.Sequence(quoteCallbackInfo, nil).Then(configListCallbackInfo, nil)).
				Build()

			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(map[int64]*item_context.ItemContext{}, nil).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			checkResp, ok := resp.(*UseConfigListPreCheckResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(checkResp.RelatedProductMiss, convey.ShouldBeTrue)
			convey.So(checkResp.MissProductTypes, convey.ShouldResemble, []int{1})
		})
	})

	t.Run("检查场景-存在重复的报价项", func(t *testing.T) {
		mockey.PatchConvey("当报价项和配置清单项存在重复时，应正确识别", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			quoteCBInfo := &assistant.CallbackInfo{
				Quote:         &model.Quote{QuoteRelatedProduct: `[0]`},
				AllQuoteItems: []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 1}}},
				AllItemValues: map[int64][]*model.QuoteItemValue{1: {}},
			}
			configListCBInfo := &assistant.CallbackInfo{
				Quote:         &model.Quote{},
				AllQuoteItems: []*model.QuoteItem{{BaseDB: framework.BaseDB{Id: 101}, ItemType: 0}},
				AllItemValues: map[int64][]*model.QuoteItemValue{101: {}},
			}
			mockey.Mock(assistant.Callback).
				Return(mockey.Sequence(quoteCBInfo, nil).Then(configListCBInfo, nil)).
				Build()

			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()

			quoteItemContexts := map[int64]*item_context.ItemContext{
				1: {ItemID: 1},
			}
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
			}
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(quoteItemContexts, nil).Then(configListItemContexts, nil)).Build()

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(r *item_context.ItemContext) bool {
					return r.ItemID == 1
				}).Return([]string{"repeat_key"}).
				When(func(r *item_context.ItemContext) bool {
					return r.ItemID == 101
				}).Return([]string{"repeat_key"}).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			checkResp, ok := resp.(*UseConfigListPreCheckResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(checkResp.QuoteItemRepeat, convey.ShouldBeTrue)
			convey.So(checkResp.RepeatQuoteItemIDMap, convey.ShouldResemble, map[int64]int64{1: 101})
		})
	})

	t.Run("失败场景-创建报价单ItemContext失败", func(t *testing.T) {
		mockey.PatchConvey("当第一个NewItemContextByQuoteItemValues调用失败时，应返回错误", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			quoteCBInfo := &assistant.CallbackInfo{Quote: &model.Quote{QuoteRelatedProduct: ""}}
			configListCBInfo := &assistant.CallbackInfo{Quote: &model.Quote{}}
			mockey.Mock(assistant.Callback).
				Return(mockey.Sequence(quoteCBInfo, nil).Then(configListCBInfo, nil)).
				Build()

			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).Return(nil, mockErr).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})

	t.Run("失败场景-创建配置清单ItemContext失败", func(t *testing.T) {
		mockey.PatchConvey("当第二个NewItemContextByQuoteItemValues调用失败时，应返回错误", t, func() {
			mockDBProxy := &v2.DBProxy{}
			mockey.MockValue(&dal.DBProxy).To(mockDBProxy)
			mockey.Mock(mockey.GetMethod(mockDBProxy, "NewRequest")).Return(mockDB).Build()

			quoteCBInfo := &assistant.CallbackInfo{Quote: &model.Quote{QuoteRelatedProduct: ""}}
			configListCBInfo := &assistant.CallbackInfo{Quote: &model.Quote{}}
			mockey.Mock(assistant.Callback).
				Return(mockey.Sequence(quoteCBInfo, nil).Then(configListCBInfo, nil)).
				Build()

			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()
			mockey.Mock(item_context.NewItemContextByQuoteItemValues).
				Return(mockey.Sequence(map[int64]*item_context.ItemContext{}, nil).Then(nil, mockErr)).Build()

			req := &UseConfigListPreCheckReq{QuoteID: 1, ConfigListID: 2}
			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})
}

func Test_getRepeatQuoteItemIDs_BitsUTGen(t *testing.T) {
	t.Run("场景1: 报价项与配置清单项无重复", func(t *testing.T) {
		mockey.PatchConvey("当报价项和配置清单项的重复检查键不重叠时,应返回空map", t, func() {
			// 准备测试数据
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
			}

			// Mock依赖方法
			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 101 }).
				Return([]string{"config_key_1"}).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 201 }).
				Return([]string{"quote_key_1"}).
				Build()

			// 执行目标函数
			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			// 断言结果
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("场景2: 存在一个重复项", func(t *testing.T) {
		mockey.PatchConvey("当一个报价项和一个配置清单项的检查键相同时,应返回该重复项的ID映射", t, func() {
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
			}

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				Return([]string{"common_key"}).Build()

			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			expected := map[int64]int64{201: 101}
			convey.So(result, convey.ShouldResemble, expected)
		})
	})

	t.Run("场景3: 存在多个重复项", func(t *testing.T) {
		mockey.PatchConvey("当多个报价项和配置清单项的检查键匹配时,应返回所有重复项的ID映射", t, func() {
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
				102: {ItemID: 102},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
				202: {ItemID: 202},
			}

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 101 || ctx.ItemID == 201 }).
				Return([]string{"key_A"}).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 102 || ctx.ItemID == 202 }).
				Return([]string{"key_B"}).
				Build()

			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			expected := map[int64]int64{201: 101, 202: 102}
			convey.So(result, convey.ShouldResemble, expected)
		})
	})

	t.Run("场景4: 报价项有多个键,其中一个键重复", func(t *testing.T) {
		mockey.PatchConvey("当一个报价项有多个检查键,且其中一个匹配时,应被识别为重复", t, func() {
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
			}

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 101 }).
				Return([]string{"key_A"}).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 201 }).
				Return([]string{"key_B", "key_A", "key_C"}).
				Build()

			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			expected := map[int64]int64{201: 101}
			convey.So(result, convey.ShouldResemble, expected)
		})
	})

	t.Run("场景5: 报价项的多个键匹配不同的配置项(覆盖逻辑)", func(t *testing.T) {
		mockey.PatchConvey("当一个报价项的多个键匹配不同配置项时,结果应为最后匹配的配置项ID", t, func() {
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
				102: {ItemID: 102},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
			}

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 101 }).
				Return([]string{"key_A"}).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 102 }).
				Return([]string{"key_B"}).
				When(func(ctx *item_context.ItemContext) bool { return ctx.ItemID == 201 }).
				Return([]string{"key_A", "key_B"}).
				Build()

			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			// 由于 "key_B" 在 "key_A" 之后被检查,它将覆盖结果
			expected := map[int64]int64{201: 102}
			convey.So(result, convey.ShouldResemble, expected)
		})
	})

	t.Run("场景6: 多个配置清单项产生相同的键(覆盖逻辑)", func(t *testing.T) {
		mockey.PatchConvey("当多个配置清单项产生相同的键时,报价项应与最后处理的那个配置项匹配", t, func() {
			// 注意: map的迭代顺序不确定,这个测试验证的是覆盖行为本身,而不是哪个ID一定获胜
			configListItemContexts := map[int64]*item_context.ItemContext{
				101: {ItemID: 101},
				102: {ItemID: 102},
			}
			quoteItemContexts := map[int64]*item_context.ItemContext{
				201: {ItemID: 201},
			}

			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).
				Return([]string{"common_key"}).Build()

			result := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)

			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result[201], convey.ShouldBeIn, []int64{101, 102})
		})
	})

	t.Run("场景7: 输入为空或nil", func(t *testing.T) {
		mockey.PatchConvey("当任一输入map为空或nil时,应返回空map", t, func() {
			// 修复：添加对GetRepeatCheckKey的mock，防止在不完整的ItemContext上调用真实方法导致空指针
			mockey.Mock((*item_context.ItemContext).GetRepeatCheckKey).Return([]string{}).Build()

			// Case 1: quoteItemContexts is nil
			result1 := getRepeatQuoteItemIDs(nil, map[int64]*item_context.ItemContext{101: {ItemID: 101}})
			convey.So(len(result1), convey.ShouldEqual, 0)

			// Case 2: configListItemContexts is nil
			result2 := getRepeatQuoteItemIDs(map[int64]*item_context.ItemContext{201: {ItemID: 201}}, nil)
			convey.So(len(result2), convey.ShouldEqual, 0)

			// Case 3: Both are empty maps
			result3 := getRepeatQuoteItemIDs(map[int64]*item_context.ItemContext{}, map[int64]*item_context.ItemContext{})
			convey.So(len(result3), convey.ShouldEqual, 0)
		})
	})
}

func Test_getMissRelatedProducts_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	quote := &model.Quote{}

	t.Run("场景一：所有配置项产品类型均在报价单中", func(t *testing.T) {
		mockey.PatchConvey("场景一：所有配置项产品类型均在报价单中，应返回空切片", t, func() {
			// 构造报价单中已包含的产品类型
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline:  struct{}{}, // 0
				multienv.TradeProductTypeOffline: struct{}{}, // 1
			}, nil).Build()

			// 构造配置项列表，其产品类型均已包含在报价单中
			configListItems := []*model.QuoteItem{
				{ItemType: multienv.TradeProductDeploymentTypePublic},                                                     // 返回 0 (公有云)
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardYes}, // 返回 1 (私有云标品)
			}

			result := getMissRelatedProducts(ctx, quote, configListItems)

			convey.So(result, convey.ShouldBeEmpty)
		})
	})

	t.Run("场景二：部分配置项产品类型不在报价单中", func(t *testing.T) {
		mockey.PatchConvey("场景二：部分配置项产品类型不在报价单中，应返回缺失的产品类型切片", t, func() {
			// 构造报价单中仅包含公有云产品类型
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{}, // 0
			}, nil).Build()

			// 构造配置项列表，其中包含报价单中没有的产品类型
			configListItems := []*model.QuoteItem{
				{ItemType: multienv.TradeProductDeploymentTypePublic},                                                     // 已存在, 返回 0
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardYes}, // 缺失, 返回 1 (私有云)
				{QuoteSolutionType: constants.QuoteSolutionTypeDefaultSolution},                                           // 缺失, 返回 2 (解决方案)
			}

			result := getMissRelatedProducts(ctx, quote, configListItems)

			// 期望返回经过排序和去重的缺失产品类型
			convey.So(result, convey.ShouldResemble, []int{1, 2})
		})
	})

	t.Run("场景三：所有配置项产品类型都不在报价单中", func(t *testing.T) {
		mockey.PatchConvey("场景三：所有配置项产品类型都不在报价单中，应返回所有相关的产品类型", t, func() {
			// 构造报价单中不包含任何产品类型
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{}, nil).Build()

			configListItems := []*model.QuoteItem{
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardNo}, // 缺失, 返回 5 (非标品)
				{QuoteSolutionType: constants.QuoteSolutionTypeIntegratedMachine},                                        // 缺失, 返回 4 (一体机)
			}

			result := getMissRelatedProducts(ctx, quote, configListItems)

			convey.So(result, convey.ShouldResemble, []int{4, 5})
		})
	})

	t.Run("场景四：配置项列表为空", func(t *testing.T) {
		mockey.PatchConvey("场景四：配置项列表为空，应返回空切片", t, func() {
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()

			var configListItems []*model.QuoteItem // 空列表

			result := getMissRelatedProducts(ctx, quote, configListItems)

			convey.So(result, convey.ShouldBeEmpty)
		})
	})

	t.Run("场景五：存在重复的缺失产品类型", func(t *testing.T) {
		mockey.PatchConvey("场景五：存在重复的缺失产品类型，应返回去重并排序的切片", t, func() {
			// 构造报价单中不包含任何产品类型
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{}, nil).Build()

			configListItems := []*model.QuoteItem{
				{QuoteSolutionType: constants.QuoteSolutionTypeDefaultSolution},                                           // 缺失, 返回 2
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardYes}, // 缺失, 返回 1
				{QuoteSolutionType: constants.QuoteSolutionTypeDefaultSolution},                                           // 重复缺失, 返回 2
			}

			result := getMissRelatedProducts(ctx, quote, configListItems)

			// 期望返回经过排序和去重的缺失产品类型
			convey.So(result, convey.ShouldResemble, []int{1, 2})
		})
	})

	t.Run("场景六：测试GetRelatedProductType所有分支的返回", func(t *testing.T) {
		mockey.PatchConvey("场景六：测试GetRelatedProductType所有分支的返回，应返回所有缺失类型", t, func() {
			// 构造报价单中不包含任何产品类型
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{}, nil).Build()

			configListItems := []*model.QuoteItem{
				{QuoteSolutionType: constants.QuoteSolutionTypeDefaultSolution},                                           // 返回 2
				{QuoteSolutionType: constants.QuoteSolutionTypeIntegratedMachine},                                         // 返回 4
				{ItemType: multienv.TradeProductDeploymentTypePublic},                                                     // 返回 0
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardYes}, // 返回 1
				{ItemType: multienv.TradeProductDeploymentTypePrivate, StandardProduct: multienv.TradeProductStandardNo},  // 返回 5
				{ItemType: multienv.TradeProductTypeAll},                                                                  // 默认情况, 返回ItemType本身, 即 3
			}

			result := getMissRelatedProducts(ctx, quote, configListItems)

			convey.So(result, convey.ShouldResemble, []int{0, 1, 2, 3, 4, 5})
		})
	})
}

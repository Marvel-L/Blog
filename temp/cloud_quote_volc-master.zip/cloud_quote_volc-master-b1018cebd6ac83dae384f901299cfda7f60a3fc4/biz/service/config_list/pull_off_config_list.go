package config_list

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type PullOffConfigListReq struct {
	QuoteID int64 `json:"QuoteID"`
}

type PullOffConfigListResp struct {
	QuoteID int64 `json:"QuoteID"`
}

func (r *PullOffConfigListReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)

	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		if errors.IsRecordNotFound(err) {
			return nil, errors.NewRecordNotFoundErr("配置清单%d不存在").WithArgs(r.QuoteID)
		}
		return nil, errors.NewInternalDBError(err)
	}

	if err = processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeConfigListPullOff, quote); err != nil {
		return nil, err
	}

	if err = dal.QuoteDao.UpdateByCondition(tx,
		dal.Condition{"id": r.QuoteID, "quote_status": constants.StatusConfigListPutOn},
		&model.Quote{},
		map[string]interface{}{"quote_status": constants.StatusConfigListPullOff},
	); err != nil {
		return nil, errors.NewInternalDBError(err)
	}

	return &PullOffConfigListResp{
		QuoteID: r.QuoteID,
	}, nil
}

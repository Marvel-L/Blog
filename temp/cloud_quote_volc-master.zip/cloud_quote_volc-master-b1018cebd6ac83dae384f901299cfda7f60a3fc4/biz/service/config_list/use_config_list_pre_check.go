package config_list

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type UseConfigListPreCheckReq struct {
	ConfigListID int64 `json:"ConfigListID"`
	QuoteID      int64 `json:"QuoteID"`
}

type UseConfigListPreCheckResp struct {
	RelatedProductMiss   bool            `json:"RelatedProductMiss"`   // 报价单涉及商品类型是否缺失
	MissProductTypes     []int           `json:"MissRelatedProducts"`  // 缺失报价单涉及商品类型
	QuoteItemRepeat      bool            `json:"QuoteItemRepeat"`      // 报价项是否重复
	RepeatQuoteItemIDMap map[int64]int64 `json:"RepeatQuoteItemIDMap"` // 重复报价项ID（k=报价项ID，v=配置清单项ID）
}

func (r *UseConfigListPreCheckReq) Handle(ctx context.Context) (interface{}, error) {
	var err error
	tx := dal.DBProxy.NewRequest(ctx)

	quoteCallbackInfo, err := assistant.Callback(ctx, tx, r.QuoteID,
		assistant.WithCallbackInfoKeys([]assistant.CallbackKey{
			assistant.CallbackKeyQuoteItemsAllStatus,
			assistant.CallbackKeyItemValues,
		}),
	)
	if err != nil {
		return nil, err
	}

	configListCallbackInfo, err := assistant.Callback(ctx, tx, r.ConfigListID,
		assistant.WithCallbackInfoKeys([]assistant.CallbackKey{
			assistant.CallbackKeyQuoteItemsAllStatus,
			assistant.CallbackKeyItemValues,
		}),
	)
	if err != nil {
		return nil, err
	}

	if err = processcheck.AllowQuoteOP(ctx, tx,
		processcheck.OpTypeConfigListUse,
		quoteCallbackInfo.Quote,
		processcheck.WithAllowOPSetCallbackInfo(&assistant.CallbackInfo{ConfigList: configListCallbackInfo.Quote}),
	); err != nil {
		return nil, err
	}

	checkResp := &UseConfigListPreCheckResp{}

	missProductTypes := getMissRelatedProducts(ctx, quoteCallbackInfo.Quote, configListCallbackInfo.AllQuoteItems)
	checkResp.RelatedProductMiss = len(missProductTypes) > 0
	checkResp.MissProductTypes = missProductTypes

	quoteItemContexts, err := item_context.NewItemContextByQuoteItemValues(ctx,
		quoteCallbackInfo.Quote, quoteCallbackInfo.AllQuoteItems, quoteCallbackInfo.AllItemValues)
	if err != nil {
		return nil, err
	}
	configListItemContexts, err := item_context.NewItemContextByQuoteItemValues(ctx,
		configListCallbackInfo.Quote, configListCallbackInfo.AllQuoteItems, configListCallbackInfo.AllItemValues)
	if err != nil {
		return nil, err
	}

	repeatQuoteItemIDs := getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts)
	checkResp.QuoteItemRepeat = len(repeatQuoteItemIDs) > 0
	checkResp.RepeatQuoteItemIDMap = repeatQuoteItemIDs

	return checkResp, nil
}

func getMissRelatedProducts(ctx context.Context, quote *model.Quote, configListItems []*model.QuoteItem) []int {
	var missRelatedProducts []int
	quoteProductTypes, _ := quote.GetProductTypeMap(ctx)
	for _, quoteItem := range configListItems {
		itemProductType := quoteItem.GetRelatedProductType()
		if _, ok := quoteProductTypes[itemProductType]; !ok {
			missRelatedProducts = append(missRelatedProducts, int(itemProductType))
		}
	}
	return util.SortSlice(util.GetUniqKeyInt(missRelatedProducts), util.SortFuncIntAsc)
}

func getRepeatQuoteItemIDs(quoteItemContexts, configListItemContexts map[int64]*item_context.ItemContext) map[int64]int64 {
	configListRepeatCheckKeys := map[string]int64{}
	for _, itemContext := range configListItemContexts {
		for _, key := range itemContext.GetRepeatCheckKey() {
			configListRepeatCheckKeys[key] = itemContext.ItemID
		}
	}

	repeatQuoteItemIDs := map[int64]int64{}
	for _, itemContext := range quoteItemContexts {
		for _, key := range itemContext.GetRepeatCheckKey() {
			if configListItemID, ok := configListRepeatCheckKeys[key]; ok {
				repeatQuoteItemIDs[itemContext.ItemID] = configListItemID
			}
		}
	}
	return repeatQuoteItemIDs
}

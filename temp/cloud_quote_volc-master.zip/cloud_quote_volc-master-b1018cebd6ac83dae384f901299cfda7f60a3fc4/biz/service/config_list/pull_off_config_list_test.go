package config_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	gorm "gorm.io/gorm"
	"testing"
)

func Test_PullOffConfigListReq_Handle_BitsUTGen(t *testing.T) {
	// 初始化通用参数
	ctx := context.Background()
	mockDB := &gorm.DB{}

	t.Run("成功下架配置清单", func(t *testing.T) {
		mockey.PatchConvey("成功下架配置清单", t, func() {
			req := &PullOffConfigListReq{QuoteID: 123}

			mockey.MockValue(&dal.DBProxy).To(new(v2.DBProxy))
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 模拟成功找到配置清单
			expectedQuote := &model.Quote{
				BaseDB:      framework.BaseDB{Id: 123},
				QuoteStatus: constants.StatusConfigListPutOn,
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(expectedQuote, nil).Build()

			// 模拟权限校验通过
			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()

			// 模拟成功更新状态
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "UpdateByCondition")).Return(nil).Build()

			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldResemble, &PullOffConfigListResp{QuoteID: 123})
		})
	})

	t.Run("失败-配置清单不存在", func(t *testing.T) {
		mockey.PatchConvey("失败-配置清单不存在", t, func() {
			req := &PullOffConfigListReq{QuoteID: 404}

			mockey.MockValue(&dal.DBProxy).To(new(v2.DBProxy))
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 模拟找不到记录
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(nil, gorm.ErrRecordNotFound).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCodeRecordNotFound)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置清单404不存在")
		})
	})

	t.Run("失败-查询配置清单时发生数据库错误", func(t *testing.T) {
		mockey.PatchConvey("失败-查询配置清单时发生数据库错误", t, func() {
			req := &PullOffConfigListReq{QuoteID: 500}
			dbErr := errors.New("database connection failed")

			mockey.MockValue(&dal.DBProxy).To(new(v2.DBProxy))
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 模拟查询时数据库出错
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(nil, dbErr).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCodeInternalDBError)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})
	})

	t.Run("失败-权限校验不通过", func(t *testing.T) {
		mockey.PatchConvey("失败-权限校验不通过", t, func() {
			req := &PullOffConfigListReq{QuoteID: 123}
			checkErr := pkg_errors.ErrCustomerError.WithArgs("状态不合法，不允许下架")

			mockey.MockValue(&dal.DBProxy).To(new(v2.DBProxy))
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			expectedQuote := &model.Quote{
				BaseDB:      framework.BaseDB{Id: 123},
				QuoteStatus: constants.StatusConfigListInitialed, // 假设一个不允许下架的状态
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(expectedQuote, nil).Build()

			// 模拟权限校验失败
			mockey.Mock(processcheck.AllowQuoteOP).Return(checkErr).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, checkErr)
			convey.So(err.Error(), convey.ShouldContainSubstring, "状态不合法，不允许下架")
		})
	})

	t.Run("失败-更新状态时发生数据库错误", func(t *testing.T) {
		mockey.PatchConvey("失败-更新状态时发生数据库错误", t, func() {
			req := &PullOffConfigListReq{QuoteID: 123}
			updateErr := errors.New("update failed due to lock")

			mockey.MockValue(&dal.DBProxy).To(new(v2.DBProxy))
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			expectedQuote := &model.Quote{
				BaseDB:      framework.BaseDB{Id: 123},
				QuoteStatus: constants.StatusConfigListPutOn,
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(expectedQuote, nil).Build()

			mockey.Mock(processcheck.AllowQuoteOP).Return(nil).Build()

			// 模拟更新时数据库出错
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "UpdateByCondition")).Return(updateErr).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCodeInternalDBError)
			convey.So(err.Error(), convey.ShouldContainSubstring, updateErr.Error())
		})
	})
}

package coupon_validation

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// ValidateOriginalBillCouponAIProducts 校验原价口径的金额返券仅使用 AI 商品。
func ValidateOriginalBillCouponAIProducts(
	rebateCouponWay int,
	billCaliber int,
	triggerInfo *model.TriggerInfo,
	productInfos map[string]*trade_client.TradeProductVersionInfo,
) errors.APIError {
	if billCaliber != couponconfigconst.BillCaliberOriginal ||
		(rebateCouponWay != couponconfigconst.RebateCouponWayByAmount &&
			rebateCouponWay != couponconfigconst.RebateCouponWayByAmountPercent) {
		return nil
	}
	if triggerInfo == nil {
		return errors.ErrCustomerError.WithArgs("代金券触发条件缺失")
	}

	products := util.StrSplitToMap(triggerInfo.ConsumeRebateProductList, ",")
	if rebateCouponWay == couponconfigconst.RebateCouponWayByAmountPercent {
		for product := range util.StrSplitToMap(triggerInfo.StatConsumeRebateProductList, ",") {
			products[product] = struct{}{}
		}
	}

	for product := range products {
		productInfo := productInfos[product]
		if productInfo == nil {
			return errors.ErrCustomerError.WithArgs("查询商品信息失败")
		}
		if productInfo.IsAIProduct != multienv.IsAIProductTrue {
			return errors.ErrCustomerError.WithArgs("账单原价金额口径仅支持选择AI大模型商品")
		}
	}
	return nil
}

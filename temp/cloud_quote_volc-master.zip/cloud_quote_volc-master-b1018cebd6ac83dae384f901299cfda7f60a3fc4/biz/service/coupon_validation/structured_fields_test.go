package coupon_validation

import (
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

func TestParseRuleValidityInfo(t *testing.T) {
	tests := []struct {
		name    string
		raw     string
		wantErr bool
	}{
		{name: "follow contract", raw: `{"Type":0}`, wantErr: false},
		{name: "specified month", raw: `{"Type":1,"BeginMonth":"2026-01","EndMonth":"2026-12"}`, wantErr: false},
		{name: "empty", raw: "", wantErr: true},
		{name: "json null", raw: "null", wantErr: true},
		{name: "invalid json", raw: "invalid-json", wantErr: true},
		{name: "invalid type", raw: `{"Type":2}`, wantErr: true},
		{name: "missing month", raw: `{"Type":1,"BeginMonth":"","EndMonth":"2026-12"}`, wantErr: true},
		{name: "invalid month", raw: `{"Type":1,"BeginMonth":"2026-13","EndMonth":"2026-12"}`, wantErr: true},
		{name: "reversed month", raw: `{"Type":1,"BeginMonth":"2026-12","EndMonth":"2026-01"}`, wantErr: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := ParseRuleValidityInfo(&model.CouponConfigDB{RuleValidityInfo: tt.raw})
			if (err != nil) != tt.wantErr {
				t.Fatalf("ParseRuleValidityInfo() error = %v, wantErr %v", err, tt.wantErr)
			}
			if tt.wantErr {
				if _, ok := err.(pkg_errors.APIError); !ok {
					t.Fatalf("ParseRuleValidityInfo() error type = %T, want errors.APIError", err)
				}
			}
		})
	}
}

func TestParseCapInfo(t *testing.T) {
	tests := []struct {
		name            string
		raw             string
		rebateCouponWay int
		wantErr         bool
	}{
		{name: "disabled", raw: `{"Enabled":0,"OnceAmount":0,"TotalAmount":0}`},
		{name: "enabled once", raw: `{"Enabled":1,"OnceAmount":10,"TotalAmount":0}`},
		{name: "enabled total", raw: `{"Enabled":1,"OnceAmount":0,"TotalAmount":20}`},
		{name: "empty", raw: "", wantErr: true},
		{name: "json null", raw: "null", wantErr: true},
		{name: "invalid json", raw: "invalid-json", wantErr: true},
		{name: "invalid enabled", raw: `{"Enabled":2}`, wantErr: true},
		{name: "disabled with amount", raw: `{"Enabled":0,"OnceAmount":1}`, wantErr: true},
		{name: "enabled without amount", raw: `{"Enabled":1}`, wantErr: true},
		{name: "negative amount", raw: `{"Enabled":1,"OnceAmount":-1}`, wantErr: true},
		{name: "once greater than total", raw: `{"Enabled":1,"OnceAmount":20,"TotalAmount":10}`, wantErr: true},
		{name: "time coupon must disable cap", raw: `{"Enabled":1,"TotalAmount":10}`, rebateCouponWay: couponconfigconst.RebateCouponWayByTime, wantErr: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := ParseCapInfo(&model.CouponConfigDB{CapInfo: tt.raw, RebateCouponWay: tt.rebateCouponWay})
			if (err != nil) != tt.wantErr {
				t.Fatalf("ParseCapInfo() error = %v, wantErr %v", err, tt.wantErr)
			}
			if tt.wantErr {
				if _, ok := err.(pkg_errors.APIError); !ok {
					t.Fatalf("ParseCapInfo() error type = %T, want errors.APIError", err)
				}
			}
		})
	}
}

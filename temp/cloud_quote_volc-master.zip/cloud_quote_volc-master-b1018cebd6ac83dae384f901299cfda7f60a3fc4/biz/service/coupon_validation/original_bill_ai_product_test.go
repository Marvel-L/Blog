package coupon_validation

import (
	"testing"

	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
)

func TestValidateOriginalBillCouponAIProducts(t *testing.T) {
	tests := []struct {
		name            string
		rebateCouponWay int
		billCaliber     int
		triggerInfo     *model.TriggerInfo
		productInfos    map[string]*trade_client.TradeProductVersionInfo
		wantErr         string
	}{
		{
			name:            "非原价口径跳过校验",
			rebateCouponWay: couponconfigconst.RebateCouponWayByAmount,
			billCaliber:     couponconfigconst.BillCaliberPayable,
			triggerInfo:     &model.TriggerInfo{ConsumeRebateProductList: "non-ai"},
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"non-ai": {IsAIProduct: multienv.IsAIProductFalse},
			},
		},
		{
			name:            "原价按金额返券AI商品通过",
			rebateCouponWay: couponconfigconst.RebateCouponWayByAmount,
			billCaliber:     couponconfigconst.BillCaliberOriginal,
			triggerInfo:     &model.TriggerInfo{ConsumeRebateProductList: "ai"},
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"ai": {IsAIProduct: multienv.IsAIProductTrue},
			},
		},
		{
			name:            "原价按金额返券非AI商品失败",
			rebateCouponWay: couponconfigconst.RebateCouponWayByAmount,
			billCaliber:     couponconfigconst.BillCaliberOriginal,
			triggerInfo:     &model.TriggerInfo{ConsumeRebateProductList: "non-ai"},
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"non-ai": {IsAIProduct: multienv.IsAIProductFalse},
			},
			wantErr: "账单原价金额口径仅支持选择AI大模型商品",
		},
		{
			name:            "原价比例返券统计商品非AI失败",
			rebateCouponWay: couponconfigconst.RebateCouponWayByAmountPercent,
			billCaliber:     couponconfigconst.BillCaliberOriginal,
			triggerInfo: &model.TriggerInfo{
				ConsumeRebateProductList:     "ai",
				StatConsumeRebateProductList: "non-ai",
			},
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"ai":     {IsAIProduct: multienv.IsAIProductTrue},
				"non-ai": {IsAIProduct: multienv.IsAIProductFalse},
			},
			wantErr: "账单原价金额口径仅支持选择AI大模型商品",
		},
		{
			name:            "原价商品信息缺失失败",
			rebateCouponWay: couponconfigconst.RebateCouponWayByAmount,
			billCaliber:     couponconfigconst.BillCaliberOriginal,
			triggerInfo:     &model.TriggerInfo{ConsumeRebateProductList: "missing"},
			productInfos:    map[string]*trade_client.TradeProductVersionInfo{},
			wantErr:         "查询商品信息失败",
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			convey.Convey(tt.name, t, func() {
				err := ValidateOriginalBillCouponAIProducts(
					tt.rebateCouponWay,
					tt.billCaliber,
					tt.triggerInfo,
					tt.productInfos,
				)
				if tt.wantErr == "" {
					convey.So(err, convey.ShouldBeNil)
					return
				}
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, tt.wantErr)
			})
		})
	}
}

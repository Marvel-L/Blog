package coupon_validation

import (
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// ParseRuleValidityInfo 严格解析并校验代金券规则有效期配置。
func ParseRuleValidityInfo(coupon *model.CouponConfigDB) (*model.RuleValidityInfo, error) {
	if coupon == nil {
		return nil, errors.ErrCustomerError.WithArgs("coupon is nil")
	}
	info, err := coupon.GetRuleValidityInfo()
	if err != nil {
		return nil, errors.ErrCustomerError.WithArgs(fmt.Sprintf("parse rule_validity_info failed: %s", err.Error()))
	}
	if info == nil {
		return nil, errors.ErrCustomerError.WithArgs("rule_validity_info is empty")
	}
	if !couponconfigconst.IsValidRuleValidityType(info.Type) {
		return nil, errors.ErrCustomerError.WithArgs(fmt.Sprintf("rule_validity_info type is invalid: %d", info.Type))
	}
	if info.Type == couponconfigconst.RuleValidityTypeSpecifiedMonth {
		if info.BeginMonth == "" || info.EndMonth == "" {
			return nil, errors.ErrCustomerError.WithArgs("rule_validity_info month range is empty")
		}
		if !util.CheckTimeWithFormat(info.BeginMonth, util.DateFormatMonth) ||
			!util.CheckTimeWithFormat(info.EndMonth, util.DateFormatMonth) {
			return nil, errors.ErrCustomerError.WithArgs("rule_validity_info month format is invalid")
		}
		if info.BeginMonth > info.EndMonth {
			return nil, errors.ErrCustomerError.WithArgs("rule_validity_info begin month is after end month")
		}
	}
	return info, nil
}

// ParseCapInfo 严格解析并校验代金券封顶配置。
func ParseCapInfo(coupon *model.CouponConfigDB) (*model.CapInfo, error) {
	if coupon == nil {
		return nil, errors.ErrCustomerError.WithArgs("coupon is nil")
	}
	info, err := coupon.GetCapInfo()
	if err != nil {
		return nil, errors.ErrCustomerError.WithArgs(fmt.Sprintf("parse cap_info failed: %s", err.Error()))
	}
	if info == nil {
		return nil, errors.ErrCustomerError.WithArgs("cap_info is empty")
	}
	if !couponconfigconst.IsValidCapEnabled(info.Enabled) {
		return nil, errors.ErrCustomerError.WithArgs(fmt.Sprintf("cap_info enabled is invalid: %d", info.Enabled))
	}
	if info.OnceAmount < 0 || info.TotalAmount < 0 {
		return nil, errors.ErrCustomerError.WithArgs("cap_info amount cannot be negative")
	}
	if info.Enabled == couponconfigconst.CapEnabledNo {
		if info.OnceAmount != 0 || info.TotalAmount != 0 {
			return nil, errors.ErrCustomerError.WithArgs("cap_info amount must be zero when cap is disabled")
		}
	} else {
		if info.OnceAmount == 0 && info.TotalAmount == 0 {
			return nil, errors.ErrCustomerError.WithArgs("cap_info requires at least one positive limit when cap is enabled")
		}
		if info.OnceAmount > 0 && info.TotalAmount > 0 && info.OnceAmount > info.TotalAmount {
			return nil, errors.ErrCustomerError.WithArgs("cap_info once amount cannot exceed total amount")
		}
	}
	if coupon.RebateCouponWay == couponconfigconst.RebateCouponWayByTime &&
		(info.Enabled != couponconfigconst.CapEnabledNo || info.OnceAmount != 0 || info.TotalAmount != 0) {
		return nil, errors.ErrCustomerError.WithArgs("cap_info must be disabled for time-based coupon")
	}
	return info, nil
}

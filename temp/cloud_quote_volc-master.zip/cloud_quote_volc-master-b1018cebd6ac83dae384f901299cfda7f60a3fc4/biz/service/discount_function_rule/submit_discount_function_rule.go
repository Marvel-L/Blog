package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/lark_approval_process"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"context"
	"gorm.io/gorm"
	"strconv"
	"time"
)

const submitDiscountFunctionRuleLockKey = "submit_discount_function_rule_lock_"

type SubmitDiscountFunctionRuleReq struct {
	DiscountFunctionPermission
	Id        int64  `json:"Id"`
	ApplyType string `json:"ApplyType"`
}

func (r *SubmitDiscountFunctionRuleReq) Handle(ctx context.Context) (interface{}, error) {
	var resp interface{}
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.submitRule(ctx, tx)
		return err
	})
	return resp, err
}

func (r *SubmitDiscountFunctionRuleReq) submitRule(ctx context.Context, tx *gorm.DB) (interface{}, error) {
	lock := redis_client.RedisLock{
		LockKey: submitDiscountFunctionRuleLockKey + strconv.FormatInt(r.Id, 10),
		Value:   logid.GenLogID(),
		Timeout: 60 * time.Second,
	}
	// 抢占分布式锁
	if err := lock.Lock(); err != nil {
		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
		return nil, i18nfmt.NewError(ctx, "报价方式规则正在提交，请稍后重试")
	}
	defer lock.Unlock()

	discountFunctionRule, err := dal.DiscountFunctionRuleDao.FindByID(tx, r.Id)
	if err != nil {
		return nil, err
	}
	currentAccount, err := r.permissionCheck(ctx, discountFunctionRule)
	if err != nil {
		return nil, err
	}

	applicationType, ok := constants.DiscountFunctionRuleApplyMap[discountFunctionRule.RuleStatus]
	if !ok {
		return nil, i18nfmt.NewError(ctx, "当前报价方式规则状态不允许提交送审")
	}
	if r.ApplyType != applicationType {
		return nil, i18nfmt.Errorf(ctx, "当前报价方式规则状态不允许提交类型为%s送审", r.ApplyType)
	}

	larkApprovalInstance, err := lark_approval_process.Submit(ctx, tx, &lark_approval_process.DiscountFunctionRuleApplyParam{
		Tx:                   tx,
		DiscountFunctionRule: discountFunctionRule,
	}, constants.DiscountFunctionRuleApply, currentAccount)
	if err != nil {
		return nil, err
	}
	ruleStatus := constants.DiscountFunctionRuleApplyRuleStatusMap[r.ApplyType]
	discountFunctionRule.RuleStatus = ruleStatus
	discountFunctionRule.CurrentApprovalInstanceId = larkApprovalInstance.ApprovalInstanceId
	if err = dal.DiscountFunctionRuleDao.Save(tx, []*model.DiscountFunctionRule{discountFunctionRule}, &model.DiscountFunctionRule{}); err != nil {
		return nil, err
	}

	return discountFunctionRule, nil
}

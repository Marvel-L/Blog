package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"time"
)

type ListDiscountFunctionRulesReq struct {
	DiscountFunctionPermission
	framework.Pagination
	BelongingDepartment []string `json:"BelongingDepartment"`
	RelatedProduct      []string `json:"RelatedProduct"`
	DiscountFunction    []string `json:"DiscountFunction"`
	CreatedTimeStartStr string   `json:"CreatedTimeStart"`
	CreatedTimeEndStr   string   `json:"CreatedTimeEnd"`
	CreatorAccountId    string   `json:"CreatorAccountId"`
}

type ListDiscountFunctionRulesResp struct {
	framework.Pagination
	List []*model.DiscountFunctionRule
}

func (r *ListDiscountFunctionRulesReq) Handle(ctx context.Context) (interface{}, error) {
	currentUser, err := r.permissionCheck(ctx, nil)
	if err != nil {
		return nil, err
	}
	condition, err := r.getCondition(currentUser)
	if err != nil {
		return nil, err
	}
	tx := dal.DBProxy.NewRequest(ctx)
	discountFunctionRules, total, err := dal.DiscountFunctionRuleDao.FindByConditions(ctx, tx, condition, r.Limit, r.Offset)
	if err != nil {
		return nil, errors.ErrInternalError.WithArgs(err)
	}
	return &ListDiscountFunctionRulesResp{
		Pagination: framework.Pagination{
			Limit:  r.Limit,
			Offset: r.Offset,
			Total:  total,
		},
		List: discountFunctionRules,
	}, nil

}
func (r *ListDiscountFunctionRulesReq) getCondition(currentUser *model.Account) (framework.Condition, error) {
	condition := framework.Condition{}
	if len(r.BelongingDepartment) > 0 {
		for _, belongingDepartment := range r.BelongingDepartment {
			condition["belonging_department like"] = dal.MakeFuzzQuery(belongingDepartment)
		}
	}
	if len(r.RelatedProduct) > 0 {
		for _, relatedProduct := range r.RelatedProduct {
			condition["related_product like"] = dal.MakeFuzzQuery(relatedProduct)
		}
	}

	if len(r.DiscountFunction) > 0 {
		for _, discountFunction := range r.DiscountFunction {
			condition["discount_function like"] = dal.MakeFuzzQuery(discountFunction)

		}
	}

	if r.CreatedTimeStartStr != "" {
		var start time.Time
		var err error
		if start, err = util.CheckTimeWithZone(r.CreatedTimeStartStr); err != nil {
			return nil, errors.ErrInvalidParam.WithArgs("Time", r.CreatedTimeStartStr)
		}
		condition["created_time>="] = util.ToBeginningOfDay(start)
	}
	if r.CreatedTimeEndStr != "" {
		var end time.Time
		var err error
		if end, err = util.CheckTimeWithZone(r.CreatedTimeEndStr); err != nil {
			return nil, errors.ErrInvalidParam.WithArgs("Time", r.CreatedTimeEndStr)
		}
		condition["created_time<"] = util.ToEndOfDay(end)
	}

	if r.CreatorAccountId != "" {
		condition["creator_account_id"] = r.CreatorAccountId
	}
	if !currentUser.AccountType.Contains(constants.AccountTypeAdmin) {
		condition["creator_account_id"] = currentUser.AccountID

	}
	return condition, nil
}

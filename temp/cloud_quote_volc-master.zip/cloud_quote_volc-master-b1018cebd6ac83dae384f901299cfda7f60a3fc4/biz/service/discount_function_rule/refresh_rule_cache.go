package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/discount_function_rule_cache"
	"context"
)

type UpdateDiscountFunctionRuleCacheReq struct {
	RuleIDs []int64 `json:"RuleIDs"`
}

func (r *UpdateDiscountFunctionRuleCacheReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)
	discountFunctionRules, err := dal.DiscountFunctionRuleDao.FindByIDs(tx, r.RuleIDs)
	if err != nil {
		return nil, err
	}
	for _, discountFunctionRule := range discountFunctionRules {
		cacheHandel := &discount_function_rule_cache.RuleCacheHandel{DiscountFunctionRule: discountFunctionRule}
		if err = cacheHandel.UpdateRuleCache(ctx); err != nil {
			return nil, err
		}
	}
	return nil, nil
}

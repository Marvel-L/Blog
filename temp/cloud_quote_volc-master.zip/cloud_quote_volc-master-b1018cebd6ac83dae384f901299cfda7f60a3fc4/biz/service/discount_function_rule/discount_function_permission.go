package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"
)

type DiscountFunctionPermission struct {
}

func (p DiscountFunctionPermission) permissionCheck(ctx context.Context, discountFunctionRule *model.DiscountFunctionRule) (*model.Account, error) {
	currentUser, apiErr := dal.AccountDao.CurrentUser(ctx)
	if apiErr != nil {
		return currentUser, apiErr
	}
	if !currentUser.AccountType.CanUseDiscountFunction() {
		return currentUser, i18nfmt.NewError(ctx, "当前账号权限不允许操作报价方式规则")
	}
	if discountFunctionRule != nil {
		if discountFunctionRule.CreatorAccountId != currentUser.AccountID &&
			!currentUser.AccountType.Contains(constants.AccountTypeAdmin) {
			return currentUser, i18nfmt.NewError(ctx, "当前账号权限不允许操作此报价方式规则")
		}
	}
	return currentUser, nil
}

package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"context"
)

type GetRuleApprovalInstanceInfoReq struct {
	DiscountFunctionPermission
	Id int64 `json:"Id"`
}

func (r *GetRuleApprovalInstanceInfoReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)
	discountFunctionRule, err := dal.DiscountFunctionRuleDao.FindByID(tx, r.Id)
	if err != nil {
		return nil, err
	}
	_, err = r.permissionCheck(ctx, discountFunctionRule)
	if err != nil {
		return nil, err
	}
	return dal.LarkApprovalInstanceDao.FindByInstanceAndEntityID(tx, discountFunctionRule.Id, discountFunctionRule.CurrentApprovalInstanceId)
}

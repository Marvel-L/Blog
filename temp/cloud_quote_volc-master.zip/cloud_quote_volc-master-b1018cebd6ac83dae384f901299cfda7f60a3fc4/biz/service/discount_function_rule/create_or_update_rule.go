package discount_function_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"strings"
)

type CreateOrUpdateRuleReq struct {
	DiscountFunctionPermission
	Id                    int64                 `json:"Id"`
	DeploymentType        constants.ProductType `json:"DeploymentType"`
	RelatedProduct        string                `json:"RelatedProduct"`
	PrePayType            string                `json:"PrePayType"`
	DiscountFunction      string                `json:"DiscountFunction"`
	ApplyReason           string                `json:"ApplyReason"`
	RelatedProductNames   []string
	BelongingDepartments  []string
	BizLineNames          []string
	PrePayTypeNames       []string
	DiscountFunctionNames []string
}

func (r *CreateOrUpdateRuleReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)
	var discountFunctionRule *model.DiscountFunctionRule
	var err error
	if r.Id > 0 {
		discountFunctionRule, err = dal.DiscountFunctionRuleDao.FindByID(tx, r.Id)
		if err != nil {
			return nil, err
		}
		if !discountFunctionRule.CanEdit() {
			return nil, i18nfmt.NewError(ctx, "当前报价方式规则状态不允许编辑")
		}
	}
	currentUser, err := r.permissionCheck(ctx, discountFunctionRule)
	if err != nil {
		return nil, err
	}
	if err = r.paramCheck(ctx); err != nil {
		return nil, err
	}
	if discountFunctionRule == nil {
		discountFunctionRule = &model.DiscountFunctionRule{}
	}
	discountFunctionRule.Id = r.Id
	discountFunctionRule.DeploymentType = int(r.DeploymentType)
	discountFunctionRule.RelatedProduct = r.RelatedProduct
	discountFunctionRule.RelatedProductName = strings.Join(r.RelatedProductNames, ",")
	discountFunctionRule.PrePayType = r.PrePayType
	discountFunctionRule.PrePayTypeName = strings.Join(r.PrePayTypeNames, ",")
	discountFunctionRule.BelongingDepartment = strings.Join(r.BelongingDepartments, ",")
	discountFunctionRule.BizLineName = strings.Join(r.BizLineNames, ",")
	discountFunctionRule.DiscountFunction = r.DiscountFunction
	discountFunctionRule.DiscountFunctionName = strings.Join(r.DiscountFunctionNames, ",")
	discountFunctionRule.ApplyReason = r.ApplyReason
	discountFunctionRule.RuleStatus = constants.RuleStatusInitialed
	discountFunctionRule.CreatorAccountId = currentUser.AccountID
	if err = dal.DiscountFunctionRuleDao.Save(tx, []*model.DiscountFunctionRule{discountFunctionRule}, &model.DiscountFunctionRule{}); err != nil {
		return nil, err
	}
	return discountFunctionRule, nil
}

func (r *CreateOrUpdateRuleReq) paramCheck(ctx context.Context) error {
	if r.DeploymentType == multienv.TradeProductDeploymentTypePrivate && r.PrePayType != "" ||
		r.DeploymentType == multienv.TradeProductDeploymentTypePublic && r.PrePayType == "" {
		return i18nfmt.NewError(ctx, "公有云必填付费方式，私有云不可填付费方式")
	}
	if r.PrePayType != "" {
		var prePayTypeNames []string
		prePayTypes := strings.Split(r.PrePayType, ",")
		r.PrePayType = strings.Join(prePayTypes, ",")
		for _, prePayType := range prePayTypes {
			prePayTypeName, ok := multienv.GetCanPrePayValueMapping()[prePayType]
			if !ok {
				return i18nfmt.NewError(ctx, "付费方式枚举填写错误")
			}
			prePayTypeNames = append(prePayTypeNames, prePayTypeName)
		}
		r.PrePayTypeNames = prePayTypeNames
	}

	tradeProducts := strings.Split(r.RelatedProduct, ",")
	if len(tradeProducts) > constants.DiscountFunctionRulesProductMaxNum || len(tradeProducts) == 0 {
		return i18nfmt.Errorf(ctx, "报价方式规则必须绑定商品，最多支持%d个商品", constants.DiscountFunctionRulesProductMaxNum)
	}
	relatedProductMap, err := commodity_service.GetTradeProductByArray(ctx, tradeProducts, false)
	if err != nil {
		return err
	}
	if len(relatedProductMap) != len(tradeProducts) {
		return i18nfmt.NewError(ctx, "部分商品数据不存在或有重复")
	}
	var relatedProductNames []string
	var belongingDepartments []string
	var bizLineNames []string
	for _, tradeProduct := range tradeProducts {
		productVersionInfo, ok := relatedProductMap[tradeProduct]
		if !ok {
			return i18nfmt.Errorf(ctx, "商品%s数据不存在，请确认", tradeProduct)
		}
		if r.DeploymentType != constants.ProductType(productVersionInfo.ProductType) {
			return i18nfmt.Errorf(ctx, "商品%s商品类型与入参不符，请确认", tradeProduct)
		}
		relatedProductNames = append(relatedProductNames, productVersionInfo.TradeProductName)
		belongingDepartments = append(belongingDepartments, productVersionInfo.BelongingDepartment)
		bizLineNames = append(bizLineNames, productVersionInfo.BizLineName)

	}
	r.RelatedProductNames = util.GetUniqKeys(relatedProductNames)
	r.BelongingDepartments = util.GetUniqKeys(belongingDepartments)
	r.BizLineNames = util.GetUniqKeys(bizLineNames)
	discountFunctionMap := multienv.GetPrePayTypeDiscountFunctionMap()[r.PrePayType]
	discountFunctions := strings.Split(r.DiscountFunction, ",")
	uniqKeys := util.GetUniqKeys(discountFunctions)
	if len(discountFunctions) != len(uniqKeys) {
		return i18nfmt.NewError(ctx, "授权报价方式有重复，请确认")
	}

	var discountFunctionNames []string
	for _, discountFunction := range discountFunctions {
		discountFunctionName, ok := discountFunctionMap[discountFunction]
		if !ok {
			return i18nfmt.Errorf(ctx, "授权报价方式%s 错误，请确认", discountFunction)
		}
		discountFunctionNames = append(discountFunctionNames, discountFunctionName)
	}
	r.DiscountFunctionNames = discountFunctionNames
	if len([]rune(r.ApplyReason)) > 500 || len([]rune(r.ApplyReason)) == 0 {
		return i18nfmt.NewError(ctx, "申请原因：必填，长文本字段，最大限制500字")
	}
	return nil
}

package account_service

// FinancialRole 财务云角色
const (
	FinancialRoleFirstDistributor  = "FirstDistributor"  // 1级分销商
	FinancialRoleSecondDistributor = "SecondDistributor" // 2级分销商
	FinancialRoleFinalCustomer     = "FinalCustomer"     // 最终客户
)

// 0 无任何财务角色，11 托管主，12 托管子，21 代销伙伴，22代销客户，31 代售伙伴，32 代售客户，41 财务管理主，42 财务管理子，51 代理伙伴，52 代理客户
const (
	FinancialBizRoleFirstDistributor  = 21  // 1级分销商
	FinancialBizRoleSecondDistributor = 212 // 2级分销商
	FinancialBizRoleFinalCustomer     = 22  // 最终客户
)

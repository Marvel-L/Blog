package account_service

import (
	"context"
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_corp_finance_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/overpass/eps_platform_trade_corp_finance/kitex_gen/eps/platform/trade_corp_finance"
)

type ListAccountFinancialRoleReq struct {
	AccountIDs []string `json:"AccountIDs,required"` // 账号ID列表
}

type ListAccountFinancialRoleResp struct {
	AccountID         string
	RoleList          []string
	FinancialRoleList []int32
}

func (r *ListAccountFinancialRoleReq) Handle(c context.Context) (interface{}, error) {

	if len(r.AccountIDs) == 0 {
		return []*ListAccountFinancialRoleResp{}, nil
	}

	// 获取财务云原始角色
	financialRoleInfoList := make([]*trade_corp_finance.FinancialRoleInfo, 0, len(r.AccountIDs))
	for _, accountID := range r.AccountIDs {
		accountIDInt, err := strconv.ParseInt(accountID, 10, 64)
		if err != nil {
			return nil, err
		}

		financialRoleInfo := &trade_corp_finance.FinancialRoleInfo{
			AccountID: accountIDInt,
			SubjectNo: multienv.GetSubjectNo(),
		}
		financialRoleInfoList = append(financialRoleInfoList, financialRoleInfo)
	}
	financialRoleReq := &trade_corp_finance.BatchListAccountFinancialRoleRequest{
		FinancialRoleInfoList: financialRoleInfoList,
	}

	financialRoleResp, err := trade_corp_finance_client.BatchListAccountFinancialRole(c, financialRoleReq)
	if err != nil {
		return nil, err
	}

	financialRoleInfoMap := make(map[string]*trade_corp_finance.FinancialRoleInfo, len(financialRoleResp.FinancialRoleInfoList))
	for _, financialRoleInfo := range financialRoleResp.FinancialRoleInfoList {
		financialRoleInfoMap[strconv.FormatInt(financialRoleInfo.AccountID, 10)] = financialRoleInfo
	}

	// 财务云角色组装
	respList := make([]*ListAccountFinancialRoleResp, 0, len(r.AccountIDs))
	for _, accountID := range r.AccountIDs {

		resp := &ListAccountFinancialRoleResp{
			AccountID: accountID,
		}

		financialRoleInfo, exist := financialRoleInfoMap[accountID]
		if !exist {
			respList = append(respList, resp)
			continue
		}
		resp.FinancialRoleList = financialRoleInfo.FinancialRoleList

		var roleList []string

		// 最终客户角色判断
		if isFinalCustomer, err := r.checkFinalCustomer(c, financialRoleInfo); err != nil {
			return nil, err
		} else if isFinalCustomer {
			roleList = append(roleList, FinancialRoleFinalCustomer)
		}

		resp.RoleList = roleList
		respList = append(respList, resp)
	}

	return respList, nil
}

// checkFinalCustomer 校验是否为最终客户
func (r *ListAccountFinancialRoleReq) checkFinalCustomer(c context.Context, roleInfo *trade_corp_finance.FinancialRoleInfo) (bool, error) {

	if len(roleInfo.FinancialRoleList) == 0 || !util.Int32In(FinancialBizRoleFinalCustomer, roleInfo.FinancialRoleList) {
		return false, nil
	}

	isFinalCustomer, _, err := CheckFinalCustomer(c, strconv.FormatInt(roleInfo.AccountID, 10))
	return isFinalCustomer, err
}

package account_service

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

type GetAccountDistributorInfoReq struct {
	AccountID string `json:"AccountID,required"` // 账号ID
}

type GetAccountDistributorInfoResp struct {
	AccountID string
	*model.DistributorInfo
}

func (r *GetAccountDistributorInfoReq) Handle(c context.Context) (interface{}, error) {

	distributorInfo, err := GetDistributorInfo(c, r.AccountID)
	if err != nil {
		return nil, err
	}

	return &GetAccountDistributorInfoResp{
		AccountID:       r.AccountID,
		DistributorInfo: distributorInfo,
	}, nil
}

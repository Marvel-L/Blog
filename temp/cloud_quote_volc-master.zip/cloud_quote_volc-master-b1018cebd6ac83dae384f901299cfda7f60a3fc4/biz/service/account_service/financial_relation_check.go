package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/financial_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"context"
	"strconv"
)

type FinancialRelationCheckResp struct {
	AccountRelatedType int
	RelatedAccountID   string
}

type FinancialRelationCheckReq struct {
	AccountID string `query:"AccountID,required"`
}

func (r *FinancialRelationCheckReq) Handle(c context.Context) (interface{}, error) {

	accountID, err := strconv.ParseInt(r.AccountID, 10, 64)
	if err != nil {
		return nil, err
	}

	financialRelations, err := financial_service.GetAccountFinancialRelation(c, []int64{accountID})
	if err != nil {
		return nil, err
	}

	resp := &FinancialRelationCheckResp{
		AccountRelatedType: multienv.RelatedTypeNot,
	}

	for _, relation := range financialRelations {
		if relation.Relation != multienv.RelationTypeEntrust {
			continue
		}
		if relation.Status == multienv.RelationStatusBuild {
			if relation.MajorAccountID == accountID {
				resp.AccountRelatedType = multienv.RelatedTypeMajor
				break
			} else if relation.SubAccountID == accountID {
				resp.AccountRelatedType = multienv.RelatedTypeSub
				resp.RelatedAccountID = strconv.FormatInt(relation.MajorAccountID, 10)
				break
			}
		}
	}

	return resp, nil
}

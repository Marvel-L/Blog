package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_corp_finance_client"
	"code.byted.org/overpass/eps_platform_trade_corp_finance/kitex_gen/eps/platform/trade_corp_finance"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestListAccountFinancialRoleReq_Handle(t *testing.T) {
	testCases := []struct {
		name              string
		accountIDs        []string
		financialRoleResp *trade_corp_finance.BatchListAccountFinancialRoleResponse
		isFinalCustomer   bool
		expectedResp      []*ListAccountFinancialRoleResp
	}{
		{
			name:       "返回财务角色和最终客户角色",
			accountIDs: []string{"1"},
			financialRoleResp: &trade_corp_finance.BatchListAccountFinancialRoleResponse{
				FinancialRoleInfoList: []*trade_corp_finance.FinancialRoleInfo{
					{
						AccountID:         1,
						FinancialRoleList: []int32{FinancialBizRoleFinalCustomer, 99},
					},
				},
			},
			isFinalCustomer: true,
			expectedResp: []*ListAccountFinancialRoleResp{
				{
					AccountID:         "1",
					RoleList:          []string{FinancialRoleFinalCustomer},
					FinancialRoleList: []int32{FinancialBizRoleFinalCustomer, 99},
				},
			},
		},
		{
			name:       "账号未命中财务角色信息时返回空角色",
			accountIDs: []string{"1", "2"},
			financialRoleResp: &trade_corp_finance.BatchListAccountFinancialRoleResponse{
				FinancialRoleInfoList: []*trade_corp_finance.FinancialRoleInfo{
					{
						AccountID:         1,
						FinancialRoleList: []int32{FinancialBizRoleFinalCustomer},
					},
				},
			},
			expectedResp: []*ListAccountFinancialRoleResp{
				{
					AccountID:         "1",
					FinancialRoleList: []int32{FinancialBizRoleFinalCustomer},
				},
				{
					AccountID: "2",
				},
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				mockey.Mock(trade_corp_finance_client.BatchListAccountFinancialRole).Return(tc.financialRoleResp, nil).Build()
				mockey.Mock((*ListAccountFinancialRoleReq).checkFinalCustomer).Return(tc.isFinalCustomer, nil).Build()

				req := &ListAccountFinancialRoleReq{
					AccountIDs: tc.accountIDs,
				}
				resp, err := req.Handle(context.Background())

				convey.So(err, convey.ShouldBeNil)
				convey.So(resp, convey.ShouldResemble, tc.expectedResp)
			})
		})
	}
}

func TestListAccountFinancialRoleReq_checkFinalCustomer(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(CheckFinalCustomer).Return(true, &trade_corp_finance.AccountNode{}, nil).Build()

			// Act
			roleInfo := &trade_corp_finance.FinancialRoleInfo{
				AccountID:         1,
				FinancialRoleList: []int32{FinancialBizRoleFinalCustomer},
			}

			req := &ListAccountFinancialRoleReq{}
			isFinalCustomer, err := req.checkFinalCustomer(context.Background(), roleInfo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeTrue)
		})
	})
}

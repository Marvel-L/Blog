package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/verify_info"
	"context"
	"strconv"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_corp_finance_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/eps_platform_trade_corp_finance/kitex_gen/eps/platform/trade_corp_finance"
)

func CheckFinalCustomer(ctx context.Context, accountID string) (bool, *trade_corp_finance.AccountNode, error) {

	accountIDInt, err := strconv.ParseInt(accountID, 10, 64)
	if err != nil {
		return false, nil, err
	}

	// 获取账号业务关系树
	nowTime := util.FormatTime(time.Now())
	bizRelTreeReq := &trade_corp_finance.ListAccountBizRelTreeOnPageRequest{
		AccountID:    accountIDInt,
		SubjectNo:    multienv.GetSubjectNo(),
		BizTime:      nowTime,
		BizTimeBegin: nowTime,
		SearchMode:   3,
	}
	bizRelTreeResp, err := trade_corp_finance_client.ListAccountBizRelTreeOnPage(ctx, bizRelTreeReq)
	if err != nil {
		return false, nil, err
	}
	if bizRelTreeResp == nil || bizRelTreeResp.BizRelTree == nil {
		return false, nil, i18nfmt.Errorf(ctx, "account [%s] not exist", accountID)
	}

	// 获取账号节点信息
	accountNode, err := trade_corp_finance_client.GetNode(ctx, accountIDInt, multienv.GetSubjectNo(), bizRelTreeResp.BizRelTree)
	if err != nil {
		logs.CtxError(ctx, "[CheckFinalCustomer] GetNode failed, AccountID:%s, err=%s", accountID, err.Error())
		return false, nil, err
	}

	// 判断是否为最终客户：
	// 1、当前节点为最终客户
	// 2、叶子结点
	// 3、存在上级分销商（1级、2级+1级）
	if !util.Int64In(FinancialBizRoleFinalCustomer, accountNode.BizRoleList) {
		return false, nil, nil
	}
	if len(accountNode.Children) != 0 {
		return false, nil, nil
	}
	if accountNode.Parent == nil {
		return false, nil, nil
	}
	if util.Int64In(FinancialBizRoleFirstDistributor, accountNode.Parent.BizRoleList) {
		// 上级分销商层级关系为 1级
		return true, accountNode, nil
	}
	// 上级分销商层级关系为 2级+1级
	if !util.Int64In(FinancialBizRoleSecondDistributor, accountNode.Parent.BizRoleList) {
		return false, nil, nil
	}
	if accountNode.Parent.Parent == nil || !util.Int64In(FinancialBizRoleFirstDistributor, accountNode.Parent.Parent.BizRoleList) {
		return false, nil, nil
	}

	return true, accountNode, nil
}

func GetDistributorInfo(ctx context.Context, accountID string) (*model.DistributorInfo, error) {

	// 最终客户判断
	isFinalCustomer, finalNode, err := CheckFinalCustomer(ctx, accountID)
	if err != nil {
		return nil, err
	}
	if !isFinalCustomer {
		return nil, i18nfmt.Errorf(ctx, "account [%s] not final customer", accountID)
	}

	// 最终客户
	finalCustomer, err := buildCustomerInfo(ctx, FinancialRoleFinalCustomer, finalNode.AccountID, "*")
	if err != nil {
		return nil, err
	}

	if util.Int64In(FinancialBizRoleFirstDistributor, finalNode.Parent.BizRoleList) {
		// 1级分销商
		firstNode := finalNode.Parent
		firstDistributor, err := buildCustomerInfo(ctx, FinancialRoleFirstDistributor, firstNode.AccountID, finalCustomer.AccountID)
		if err != nil {
			return nil, err
		}

		return &model.DistributorInfo{
			FirstDistributor: firstDistributor,
			FinalCustomer:    finalCustomer,
		}, nil
	}

	// 2级分销商
	secondNode := finalNode.Parent
	secondDistributor, err := buildCustomerInfo(ctx, FinancialRoleSecondDistributor, secondNode.AccountID, finalCustomer.AccountID)
	if err != nil {
		return nil, err
	}

	// 1级分销商
	firstNode := secondNode.Parent
	firstDistributor, err := buildCustomerInfo(ctx, FinancialRoleFirstDistributor, firstNode.AccountID, finalCustomer.AccountID)
	if err != nil {
		return nil, err
	}

	return &model.DistributorInfo{
		FirstDistributor:  firstDistributor,
		SecondDistributor: secondDistributor,
		FinalCustomer:     finalCustomer,
	}, nil
}

func buildCustomerInfo(ctx context.Context, customerType string, accountID int64, ownerID string) (*model.CustomerInfo, error) {
	orgName, err := verify_info.GetVerifiedName(ctx, accountID)
	if err != nil {
		return nil, err
	}

	return &model.CustomerInfo{
		CustomerType: customerType,
		AccountID:    strconv.FormatInt(accountID, 10),
		OwnerID:      ownerID,
		CustomerName: orgName,
	}, nil
}

package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"context"
)

const kvPrefix = "quote_common_kv:"

type SetKVReq struct {
	Type                     string
	V                        string
	AccountIDJustForInnerUse string
}

type SetKVResp struct {
	AccountID string
	Type      string
}

func (r *SetKVReq) Handle(c context.Context) (interface{}, error) {
	currentUser, err := dal.AccountDao.CurrentUser(c)
	if err != nil {
		return nil, err
	}
	redisClient := redis_client.NewRedisClient()

	if r.AccountIDJustForInnerUse != "" {
		_, err = redisClient.HSet(kvPrefix+r.Type, r.AccountIDJustForInnerUse, r.V).Result()
	} else {
		_, err = redisClient.HSet(kvPrefix+r.Type, currentUser.AccountID, r.V).Result()
	}

	if err != nil {
		return nil, err
	}

	return &SetKVResp{
		AccountID: currentUser.AccountID,
		Type:      r.Type,
	}, nil
}

package account_service

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

func TestGetAccountDistributorInfoReq_Handle(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetDistributorInfo).Return(&model.DistributorInfo{}, nil).Build()

			// Act
			req := &GetAccountDistributorInfoReq{
				AccountID: "1",
			}
			resp, err := req.Handle(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
		})
	})
}

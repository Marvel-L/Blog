package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/verify_info"
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_corp_finance_client"
	"code.byted.org/overpass/eps_platform_trade_corp_finance/kitex_gen/eps/platform/trade_corp_finance"
)

func TestCheckFinalCustomer(t *testing.T) {
	t.Run("case #1: N", func(t *testing.T) {
		mockey.PatchConvey("no Final", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFirstDistributor},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeFalse)
			convey.So(accountNode, convey.ShouldBeNil)
		})
		mockey.PatchConvey("has Children", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Children:    []*trade_corp_finance.AccountNode{{}},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeFalse)
			convey.So(accountNode, convey.ShouldBeNil)
		})
		mockey.PatchConvey("no Parent", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeFalse)
			convey.So(accountNode, convey.ShouldBeNil)
		})
		mockey.PatchConvey("no Second&First", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					BizRoleList: []int64{777},
				},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeFalse)
			convey.So(accountNode, convey.ShouldBeNil)
		})
		mockey.PatchConvey("no First", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					BizRoleList: []int64{FinancialBizRoleSecondDistributor},
					Parent: &trade_corp_finance.AccountNode{
						BizRoleList: []int64{777},
					},
				},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeFalse)
			convey.So(accountNode, convey.ShouldBeNil)
		})
	})
	t.Run("case #2: Y", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					BizRoleList: []int64{FinancialBizRoleFirstDistributor},
				},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeTrue)
			convey.So(accountNode, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("", t, func() {
			// Arrange
			bizRelTreeResp := &trade_corp_finance.ListAccountBizRelTreeOnPageResponse{
				BizRelTree: []*trade_corp_finance.SerializableTreeNodeOnPage{},
			}
			mockey.Mock(trade_corp_finance_client.ListAccountBizRelTreeOnPage).Return(bizRelTreeResp, nil).Build()

			accountNode := &trade_corp_finance.AccountNode{
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					BizRoleList: []int64{FinancialBizRoleSecondDistributor},
					Parent: &trade_corp_finance.AccountNode{
						BizRoleList: []int64{FinancialBizRoleFirstDistributor},
					},
				},
			}
			mockey.Mock(trade_corp_finance_client.GetNode).Return(accountNode, nil).Build()

			// Act
			isFinalCustomer, accountNode, err := CheckFinalCustomer(context.Background(), "1")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isFinalCustomer, convey.ShouldBeTrue)
			convey.So(accountNode, convey.ShouldNotBeNil)
		})
	})
}

func TestGetDistributorInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			accountNode := &trade_corp_finance.AccountNode{
				AccountID:   1,
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					AccountID:   2,
					BizRoleList: []int64{FinancialBizRoleFirstDistributor},
				},
			}
			mockey.Mock(CheckFinalCustomer).Return(true, accountNode, nil).Build()

			mockey.Mock(verify_info.GetVerifiedName).Return("aaa", nil).Build()

			// Act
			distributorInfo, err := GetDistributorInfo(context.Background(), "")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(distributorInfo, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("", t, func() {
			// Arrange
			accountNode := &trade_corp_finance.AccountNode{
				AccountID:   1,
				BizRoleList: []int64{FinancialBizRoleFinalCustomer},
				Parent: &trade_corp_finance.AccountNode{
					AccountID:   2,
					BizRoleList: []int64{FinancialBizRoleSecondDistributor},
					Parent: &trade_corp_finance.AccountNode{
						AccountID:   3,
						BizRoleList: []int64{FinancialBizRoleFirstDistributor},
					},
				},
			}
			mockey.Mock(CheckFinalCustomer).Return(true, accountNode, nil).Build()

			mockey.Mock(verify_info.GetVerifiedName).Return("aaa", nil).Build()

			// Act
			distributorInfo, err := GetDistributorInfo(context.Background(), "")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(distributorInfo, convey.ShouldNotBeNil)
		})
	})
}

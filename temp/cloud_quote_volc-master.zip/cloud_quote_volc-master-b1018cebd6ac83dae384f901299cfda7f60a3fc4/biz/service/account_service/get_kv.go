package account_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/kv/redis-v6/pkg"
	"context"
)

type GetKVReq struct {
	Type string
	V    string
}

func (r *GetKVReq) Handle(c context.Context) (interface{}, error) {
	currentUser, err := dal.AccountDao.CurrentUser(c)
	if err != nil {
		return nil, err
	}

	redisClient := redis_client.NewRedisClient()
	result, err := redisClient.HGet(kvPrefix+r.Type, currentUser.AccountID).Result()
	if err == pkg.Nil {
		return "", nil
	}
	if err != nil {
		return "", err
	}

	return result, nil
}

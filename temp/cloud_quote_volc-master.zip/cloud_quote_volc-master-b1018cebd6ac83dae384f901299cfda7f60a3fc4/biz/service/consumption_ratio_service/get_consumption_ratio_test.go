package consumption_ratio_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/gorm/v2"
	"context"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	gorm1 "gorm.io/gorm"
	"testing"
)

func TestGetConsumptionRatioReq_Handle(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{
				ConsumptionRatio: "",
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(errors.IsRecordNotFound).Return(false).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v := &GetConsumptionRatioReq{
				QuoteID: 0,
			}
			got, err := v.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{
				ConsumptionRatio: "",
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(errors.IsRecordNotFound).Return(true).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v := &GetConsumptionRatioReq{
				QuoteID: 0,
			}
			got, err := v.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
}

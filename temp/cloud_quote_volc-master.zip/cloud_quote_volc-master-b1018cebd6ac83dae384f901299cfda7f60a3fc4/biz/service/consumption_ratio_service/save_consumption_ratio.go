package consumption_ratio_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"errors"
	"fmt"
	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
)

type SaveConsumptionRatioReq struct {
	QuoteID           int64               `json:"QuoteID"`
	ConsumptionRatios []*ConsumptionRatio `json:"ConsumptionRatios"`
}

func (r *SaveConsumptionRatioReq) Handle(ctx context.Context) (interface{}, error) {
	var resp interface{}
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.saveConsumptionRatio(ctx, tx)
		return err
	})
	return resp, err
}

func (r *SaveConsumptionRatioReq) saveConsumptionRatio(ctx context.Context, tx *gorm.DB) (interface{}, error) {

	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		return nil, err
	}
	if err := processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeAddQuoteItem, quote); err != nil { //允许修改消费结构条件同增加报价项
		return nil, err
	}
	if err = CheckConsumptionRatio(ctx, tx, r.QuoteID, r.ConsumptionRatios); err != nil {
		return nil, err
	}
	if err = dal.QuoteDao.UpdateConsumptionRatio(tx, r.QuoteID, util.GetJsonStr(r.ConsumptionRatios)); err != nil {
		return nil, err
	}
	return r.QuoteID, nil
}

func CheckConsumptionRatio(ctx context.Context, tx *gorm.DB, quoteID int64, consumptionRatios []*ConsumptionRatio) error {
	ratioCurrentMap, err := getCurrentRatios(ctx, tx, quoteID)
	if err != nil {
		return err
	}
	if len(consumptionRatios) != len(ratioCurrentMap) {
		return errors.New("ConsumptionRatio is not right")
	}
	sum := decimal.Zero
	for _, ratio := range consumptionRatios {
		consumptionRatio, ok := ratioCurrentMap[ratio.GetKey()]
		if !ok {
			return errors.New(fmt.Sprintf(" %s can not be add to ConsumptionRatio", util.GetJsonStr(ratio)))
		}
		if !consumptionRatio.CanBeZero && ratio.Ratio.Equal(decimal.Zero) {
			return errors.New(fmt.Sprintf(" %s consumptionRatio can not be 0", ratio.GetKey()))
		}

		sum = sum.Add(ratio.Ratio)
	}
	if !sum.Equal(decimal.NewFromInt(1)) {
		return errors.New("ConsumptionRatio sum is not 1")
	}
	return nil
}

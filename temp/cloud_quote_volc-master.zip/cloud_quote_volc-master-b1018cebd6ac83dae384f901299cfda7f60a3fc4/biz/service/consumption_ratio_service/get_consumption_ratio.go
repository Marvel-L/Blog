package consumption_ratio_service

import (
	"context"
	"encoding/json"
	"sort"
	"strings"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
)

type GetConsumptionRatioReq struct {
	QuoteID int64
}

func (r *GetConsumptionRatioReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)
	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		if errors.IsRecordNotFound(err) {
			return nil, errors.NewRecordNotFoundErr("报价单号%d不存在").WithArgs(r.QuoteID)
		}
		return nil, errors.NewInternalDBError(err)
	}
	var ratiosSaved []*ConsumptionRatio
	ratioSavedMap := map[string]*ConsumptionRatio{}
	consumptionRatio := quote.ConsumptionRatio
	if consumptionRatio != "" {
		if unmarshalErr := json.Unmarshal([]byte(consumptionRatio), &ratiosSaved); unmarshalErr != nil {
			return nil, unmarshalErr
		}
		for _, ratio := range ratiosSaved {
			ratioSavedMap[ratio.GetKey()] = ratio
		}
	}
	ratioCurrentMap, err := getCurrentRatios(ctx, tx, r.QuoteID)
	if err != nil {
		return nil, err
	}
	var ratiosCurrent []*ConsumptionRatio
	for ratioKey, currentRatio := range ratioCurrentMap {
		ratioSaved, ok := ratioSavedMap[ratioKey]
		if ok {
			currentRatio.Ratio = ratioSaved.Ratio
		}
		ratiosCurrent = append(ratiosCurrent, currentRatio)
	}

	sort.Slice(ratiosCurrent, func(i, j int) bool {
		if ratiosCurrent[j].PrimaryProductLine != ratiosCurrent[i].PrimaryProductLine {
			return strings.Compare(ratiosCurrent[j].PrimaryProductLine, ratiosCurrent[i].PrimaryProductLine) > 0
		}
		return strings.Compare(ratiosCurrent[j].SecondaryProductLine, ratiosCurrent[i].SecondaryProductLine) > 0
	})

	return ratiosCurrent, nil
}

func getCurrentRatios(ctx context.Context, tx *gorm.DB, quoteID int64) (map[string]*ConsumptionRatio, error) {
	quoteItems, err := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, quoteID, constants.ItemStatusAll, multienv.TradeProductTypeAll, constants.ItemSceneQuoteItem)
	if err != nil {
		return nil, err
	}
	ratioCurrentMap := map[string]*ConsumptionRatio{}
	for _, quoteItem := range quoteItems {
		ratio := &ConsumptionRatio{
			PrimaryProductLine:   quoteItem.ProductDepartmentName,
			SecondaryProductLine: quoteItem.SecondaryProductLine,
			CanBeZero:            true,
		}
		consumptionRatio, ok := ratioCurrentMap[ratio.GetKey()]
		if !ok {
			ratioCurrentMap[ratio.GetKey()] = ratio
			consumptionRatio = ratio
		}
		if !quoteItem.IsZeroQuote() {
			consumptionRatio.CanBeZero = false
		}
	}
	return ratioCurrentMap, nil
}

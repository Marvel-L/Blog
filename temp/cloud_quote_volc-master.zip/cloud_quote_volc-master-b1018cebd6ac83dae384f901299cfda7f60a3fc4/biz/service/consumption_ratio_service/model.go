package consumption_ratio_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"fmt"
	"github.com/shopspring/decimal"
)

type ConsumptionRatio struct {
	PrimaryProductLine   string          `json:"PrimaryProductLine"`
	SecondaryProductLine string          `json:"SecondaryProductLine"`
	Ratio                decimal.Decimal `json:"Ratio"`
	CanBeZero            bool            `json:"CanBeZero"`
}

func (r *ConsumptionRatio) GetKey() string {
	return fmt.Sprintf("%s%s%s", r.PrimaryProductLine, constants.Separator, r.SecondaryProductLine)
}

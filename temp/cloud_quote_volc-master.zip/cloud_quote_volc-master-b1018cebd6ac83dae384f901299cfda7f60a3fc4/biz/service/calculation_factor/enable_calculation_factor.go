package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"gorm.io/gorm"
)

type EnableCalculationFactorReq struct {
	CalculationFactorPermission
	FactorIDs []int64 `json:"FactorIDs"`

	factorIDsToBeUsable []int64
	factorsToBeUsable   []*model.CalculationFactor
}

type EnableCalculationFactorResp struct {
	FactorIDs []int64
}

func (r *EnableCalculationFactorReq) Handle(ctx context.Context) (interface{}, error) {

	_, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}
	var resp interface{}
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.enableFactors(ctx, tx)
		return err
	})

	return resp, err
}
func (r *EnableCalculationFactorReq) enableFactors(ctx context.Context, tx *gorm.DB) (interface{}, error) {
	if err := r.factorsStatusCheck(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.updateFactorsToUsable(ctx, tx); err != nil {
		return nil, err
	}

	return &EnableCalculationFactorResp{
		FactorIDs: r.factorIDsToBeUsable,
	}, nil
}

func (r *EnableCalculationFactorReq) factorsStatusCheck(ctx context.Context, tx *gorm.DB) error {
	if len(r.FactorIDs) == 0 {
		return nil
	}
	condition := framework.Condition{}
	condition["id"] = r.FactorIDs
	factors, err := dal.CalculationFactorDao.FindFactorsByConditions(ctx, tx, condition)
	if err != nil {
		return err
	}
	if len(factors) != len(r.FactorIDs) {
		return i18nfmt.NewError(ctx, "部分启用因子查询失败")
	}
	var factorIDsToBeUsable []int64
	var factorIDsAbandoned []int64
	var factorsToBeUsable []*model.CalculationFactor
	for _, calculationFactor := range factors {
		if calculationFactor.FactorStatus == multienv.FactorStatusUsable {
			continue
		} else if calculationFactor.FactorStatus == multienv.FactorStatusAbandoned {
			factorIDsAbandoned = append(factorIDsAbandoned, calculationFactor.Id)
		} else if calculationFactor.FactorStatus == multienv.FactorStatusDraft {
			factorIDsToBeUsable = append(factorIDsToBeUsable, calculationFactor.Id)
			calculationFactor.FactorStatus = multienv.FactorStatusUsable
			factorsToBeUsable = append(factorsToBeUsable, calculationFactor)
		}

	}
	if len(factorIDsAbandoned) > 0 {
		return i18nfmt.Errorf(ctx, "选项中包含作废的计算因子 id : %s，作废的计算因子不可再启用！", util.GetJsonStr(factorIDsAbandoned))
	}
	r.factorIDsToBeUsable = factorIDsToBeUsable
	r.factorsToBeUsable = factorsToBeUsable
	return err
}

func (r *EnableCalculationFactorReq) updateFactorsToUsable(ctx context.Context, tx *gorm.DB) error {
	if len(r.factorIDsToBeUsable) == 0 {
		return nil
	}
	if err := addFactorsToCache(r.factorsToBeUsable); err != nil {
		return err
	}
	return dal.CalculationFactorDao.UpdateFactorStatusByIDs(tx, r.factorIDsToBeUsable, multienv.FactorStatusUsable)
}

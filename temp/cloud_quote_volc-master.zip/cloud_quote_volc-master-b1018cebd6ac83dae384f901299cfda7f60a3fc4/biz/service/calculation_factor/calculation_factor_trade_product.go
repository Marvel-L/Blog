package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"context"
)

type CalculationFactorTradeProduct struct {
	TradeProduct string `json:"TradeProduct"`
}

func (p CalculationFactorTradeProduct) tradeProductCheck(ctx context.Context) (*trade_client.TradeProductVersionInfo, error) {
	productInfo, err := commodity_service.GetProductInfoFromCache(ctx, p.TradeProduct)
	if err != nil {
		return nil, err
	}
	if constants.ProductType(productInfo.ProductType) != multienv.TradeProductDeploymentTypePublic {
		return nil, i18nfmt.NewError(ctx, "私有云商品不允许配置计算因子")
	}
	return productInfo, nil
}

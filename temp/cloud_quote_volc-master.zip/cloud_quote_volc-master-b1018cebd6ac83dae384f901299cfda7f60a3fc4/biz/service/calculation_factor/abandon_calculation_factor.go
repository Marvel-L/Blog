package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
	"gorm.io/gorm"
)

type AbandonCalculationFactorReq struct {
	CalculationFactorPermission
	FactorIDs []int64 `json:"FactorIDs"`

	factorIDsToAbandon []int64
	factorsToAbandon   []*model.CalculationFactor
}

type AbandonCalculationFactorResp struct {
	FactorIDs []int64
}

func (r *AbandonCalculationFactorReq) Handle(ctx context.Context) (interface{}, error) {

	_, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}
	var resp interface{}
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.abandonFactors(ctx, tx)
		return err
	})

	return resp, err
}
func (r *AbandonCalculationFactorReq) abandonFactors(ctx context.Context, tx *gorm.DB) (interface{}, error) {
	if err := r.factorsStatusCheck(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.factorsInUseCheck(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.updateFactorsToAbandoned(ctx, tx); err != nil {
		return nil, err
	}

	return &EnableCalculationFactorResp{
		FactorIDs: r.factorIDsToAbandon,
	}, nil
}

func (r *AbandonCalculationFactorReq) factorsStatusCheck(ctx context.Context, tx *gorm.DB) error {
	if len(r.FactorIDs) == 0 {
		return nil
	}
	condition := framework.Condition{}
	condition["id"] = r.FactorIDs
	factors, err := dal.CalculationFactorDao.FindFactorsByConditions(ctx, tx, condition)
	if err != nil {
		return err
	}
	if len(factors) != len(r.FactorIDs) {
		return i18nfmt.NewError(ctx, "部分启用因子查询失败")
	}
	var factorIDsToAbandon []int64
	var factorIDsDraft []int64
	for _, calculationFactor := range factors {
		if calculationFactor.FactorStatus == multienv.FactorStatusAbandoned {
			continue
		} else if calculationFactor.FactorStatus == multienv.FactorStatusDraft {
			factorIDsDraft = append(factorIDsDraft, calculationFactor.Id)
		} else if calculationFactor.FactorStatus == multienv.FactorStatusUsable {
			factorIDsToAbandon = append(factorIDsToAbandon, calculationFactor.Id)
		}
	}
	if len(factorIDsDraft) > 0 {
		return i18nfmt.Errorf(ctx, "选项中包含草稿计算因子 id : %s，草稿计算因子不可作废！", util.GetJsonStr(factorIDsDraft))
	}
	r.factorIDsToAbandon = factorIDsToAbandon
	r.factorsToAbandon = factors
	return err
}

func (r *AbandonCalculationFactorReq) factorsInUseCheck(ctx context.Context, tx *gorm.DB) error {
	relations, err := dal.CommonQuoteRelation.FindRelationByConditions(ctx, tx, framework.Condition{
		"entity_id":      r.factorIDsToAbandon,
		"relation_scene": constants.RelationSceneCalculationFactor,
	})
	if err != nil {
		return err
	}
	if len(relations) == 0 {
		return nil
	}
	var quoteIDs []int64
	for _, relation := range relations {
		quoteIDs = append(quoteIDs, relation.QuoteId)
	}
	quotes, err := dal.QuoteDao.FindQuotesByIDs(tx, quoteIDs)
	if err != nil {
		return err
	}

	var factorUsedQuoteIDs []int64
	for _, quote := range quotes {
		if _, ok := constants.FactorUsedQuoteStatusMapping[quote.QuoteStatus]; ok {
			factorUsedQuoteIDs = append(factorUsedQuoteIDs, quote.Id)
		}
	}
	if len(factorUsedQuoteIDs) > 0 {
		return i18nfmt.NewError(ctx, "要作废的计算因子存在使用场景，不能作废！")
	}
	return nil
}

func (r *AbandonCalculationFactorReq) updateFactorsToAbandoned(ctx context.Context, tx *gorm.DB) error {
	if len(r.factorIDsToAbandon) == 0 {
		return nil
	}

	if err := delFactorsFromCache(r.factorsToAbandon); err != nil {
		return err
	}
	return dal.CalculationFactorDao.UpdateFactorStatusByIDs(tx, r.factorIDsToAbandon, multienv.FactorStatusAbandoned)
}

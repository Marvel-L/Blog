package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"time"
)

type ListCalculationFactorReq struct {
	CalculationFactorPermission
	framework.Pagination
	FactorType        string `json:"FactorType"`
	TradeProduct      string `json:"TradeProduct"`
	ChargeItemCode    string `json:"ChargeItemCode"`
	CustomerAccountID string `json:"CustomerAccountID"`
	CreatorAccountID  string `json:"CreatorAccountID"`
	CreatedTimeStart  int64  `json:"CreatedTimeStart"`
	CreatedTimeEnd    int64  `json:"CreatedTimeEnd"`
	FactorStatus      string `json:"FactorStatus"`
}

type ListCalculationFactorResp struct {
	framework.Pagination
	List []*model.CalculationFactor
}

func (r *ListCalculationFactorReq) Handle(ctx context.Context) (interface{}, error) {

	_, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}
	tx := dal.DBProxy.NewRequest(ctx)
	condition := r.getCondition()
	factors, total, err := dal.CalculationFactorDao.FindPageFactorsByConditions(ctx, tx, condition, r.Limit, r.Offset)
	if err != nil {
		return nil, err
	}

	return &ListCalculationFactorResp{
		Pagination: framework.Pagination{
			Limit:  r.Limit,
			Offset: r.Offset,
			Total:  total,
		},
		List: factors,
	}, err
}

func (r *ListCalculationFactorReq) getCondition() framework.Condition {
	condition := framework.Condition{}
	if r.FactorType != "" {
		condition["factor_type"] = r.FactorType
	}

	if r.TradeProduct != "" {
		condition["trade_product"] = r.TradeProduct
	}
	if r.ChargeItemCode != "" {
		condition["charge_item_code"] = r.ChargeItemCode
	}
	if r.CustomerAccountID != "" {
		condition["customer_account_id"] = r.CustomerAccountID
	}
	if r.CreatorAccountID != "" {
		condition["creator_account_id"] = r.CreatorAccountID
	}
	if r.CreatedTimeStart > 0 {
		condition["created_time >= "] = time.Unix(r.CreatedTimeStart, 0)
	}
	if r.CreatedTimeEnd > 0 {
		condition["created_time  <= "] = time.Unix(r.CreatedTimeEnd, 0)
	}
	if r.FactorStatus != "" {
		condition["factor_status"] = r.FactorStatus
	}
	return condition
}

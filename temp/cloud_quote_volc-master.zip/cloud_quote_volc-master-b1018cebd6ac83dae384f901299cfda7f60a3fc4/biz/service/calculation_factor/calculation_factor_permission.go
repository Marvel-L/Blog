package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"context"
)

type CalculationFactorPermission struct {
}

func (p CalculationFactorPermission) permissionCheck(ctx context.Context) (*model.Account, error) {
	currentUser, apiErr := dal.AccountDao.CurrentUser(ctx)
	if apiErr != nil {
		return currentUser, apiErr
	}
	if !currentUser.AccountType.CanManageCalculationFactor() {
		return currentUser, i18nfmt.NewError(ctx, "当前账号权限不允许操作计算因子")
	}
	return currentUser, nil
}

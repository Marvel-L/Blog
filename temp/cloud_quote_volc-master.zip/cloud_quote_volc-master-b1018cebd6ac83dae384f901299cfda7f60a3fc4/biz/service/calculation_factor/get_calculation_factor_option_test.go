package calculation_factor

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_GetCalculationFactorOptionReq_getOptions_BitsUTGen(t *testing.T) {
	t.Run("Successful Scenario", func(t *testing.T) {
		mockey.PatchConvey("should return options successfully, filtering out the 'SelectAll' option", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{
					TradeProduct: "test-product",
				},
				CfgNodeList: []*product_config_parser.ConfigNode{},
			}

			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountType: constants.AccountTypeAdmin,
			}, nil).Build()

			productInfo := &trade_client.TradeProductVersionInfo{
				TradeProduct:    "test-product",
				ProductType:     int(multienv.TradeProductDeploymentTypePublic),
				StandardProduct: multienv.TradeProductStandardYes,
			}
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()

			container := &product_config_load.ConfigContainer{}
			mockey.Mock(product_config_load.GetConfigContainer).Return(container, nil).Build()

			configTree := &product_config_parser.StandardConfigTree{
				Root: &product_config_parser.TrieNode{},
			}
			mockey.Mock(mockey.GetMethod(container, "GetProductConfigTree")).Return(configTree, nil).Build()

			options := []*config_option_service.Option{
				{AttrKey: "option1", EnumDescription: "Option 1"},
				{AttrKey: constants.SelectAll, EnumDescription: "Select All"},
				{AttrKey: "option2", EnumDescription: "Option 2"},
			}
			mockey.Mock(config_option_service.GetCommonOptions).Return(options, nil).Build()

			result, err := req.getOptions(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result[0].AttrKey, convey.ShouldEqual, "option1")
			convey.So(result[1].AttrKey, convey.ShouldEqual, "option2")
		})
	})

	t.Run("Failure Scenario - Permission Check Fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when permission check fails", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{}
			expectedErr := errors.New("permission denied")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(nil, expectedErr).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("Failure Scenario - Trade Product Check Fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when trade product check fails", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{TradeProduct: "test-product"},
			}
			expectedErr := errors.New("product not found")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{AccountType: constants.AccountTypeAdmin}, nil).Build()
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(nil, expectedErr).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("Failure Scenario - GetConfigContainer Fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when GetConfigContainer fails", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{TradeProduct: "test-product"},
			}
			expectedErr := errors.New("container not found")

			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{AccountType: constants.AccountTypeAdmin}, nil).Build()
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(nil, expectedErr).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("Failure Scenario - GetProductConfigTree Fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when GetProductConfigTree fails", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{TradeProduct: "test-product"},
			}
			container := &product_config_load.ConfigContainer{}
			expectedErr := errors.New("tree creation failed")

			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{AccountType: constants.AccountTypeAdmin}, nil).Build()
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.Mock(mockey.GetMethod(container, "GetProductConfigTree")).Return(nil, expectedErr).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("Failure Scenario - ConfigTree Root is Nil", func(t *testing.T) {
		mockey.PatchConvey("should return biz error when config tree root is nil", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{TradeProduct: "test-product"},
			}
			container := &product_config_load.ConfigContainer{}
			configTree := &product_config_parser.StandardConfigTree{Root: nil}

			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{AccountType: constants.AccountTypeAdmin}, nil).Build()
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.Mock(mockey.GetMethod(container, "GetProductConfigTree")).Return(configTree, nil).Build()
			// Mocking i18nfmt because it is used inside NewBizErrWithMsg to format the message.
			mockey.Mock(multienv.I18nFormat).Return("当前商品不存在可报价配置").Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CommodityNoOption))
		})
	})

	t.Run("Failure Scenario - GetCommonOptions Fails", func(t *testing.T) {
		mockey.PatchConvey("should return error when GetCommonOptions fails", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{TradeProduct: "test-product"},
			}
			container := &product_config_load.ConfigContainer{}
			configTree := &product_config_parser.StandardConfigTree{Root: &product_config_parser.TrieNode{}}
			expectedErr := errors.New("failed to get options")

			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{AccountType: constants.AccountTypeAdmin}, nil).Build()
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.Mock(mockey.GetMethod(container, "GetProductConfigTree")).Return(configTree, nil).Build()
			mockey.Mock(config_option_service.GetCommonOptions).Return(nil, expectedErr).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("Failure Scenario - Insufficient Permissions", func(t *testing.T) {
		mockey.PatchConvey("should return error for account with insufficient permissions", t, func() {
			ctx := context.Background()
			req := &GetCalculationFactorOptionReq{}
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountType: constants.AccountTypeUser, // This will cause CanManageCalculationFactor to be false
			}, nil).Build()
			mockey.Mock(i18nfmt.NewError).Return(errors.New("当前账号权限不允许操作计算因子")).Build()

			result, err := req.getOptions(ctx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前账号权限不允许操作计算因子")
		})
	})
}

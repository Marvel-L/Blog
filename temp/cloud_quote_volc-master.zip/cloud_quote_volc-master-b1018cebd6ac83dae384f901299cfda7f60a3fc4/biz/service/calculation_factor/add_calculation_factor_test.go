package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/account_info"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"context"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func TestAddCalculationFactorReq_paramCheck(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(commodity_service.GetProductInfoFromCache).Return(&trade_client.TradeProductVersionInfo{
				ProductType: 0,
			}, nil).Build()
			mockey.Mock(i18nfmt.NewError).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(mockey.GetMethod(dal.CalculationFactorDao, "FindFactorByID")).Return(&model.CalculationFactor{
				FactorStatus: multienv.FactorStatusDraft,
			}, nil).Build()
			mockey.Mock(account_info.ListAccountByIds).Return([]*account_info.AccountInfo{&account_info.AccountInfo{}}, nil).Build()
			mockey.Mock((*item_context.FactorData).DataCheck).Return(nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigNodeList).Return([]*product_config_parser.ConfigNode{
				{
					NodeType:  constants.SchemaCanPrePay,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaConfigCategory,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaConfig,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaChargeMethod,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaRegion,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaChargeUnit,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
				{
					NodeType:  constants.SchemaPriceFactor,
					NodeName:  "",
					NodeKey:   "",
					OtherInfo: nil,
				},
			}).Build()
			mockey.Mock(product_config_load.TransOtherInfoToPriceInfo).Return(product_config_load.PriceInfo{}).Build()
			mockey.Mock(item_context.GetProductPriceInfo).Return(&item_context.ProductPriceInfo{}).Build()
			mockey.Mock((*item_context.ProductPriceInfo).GetSupportSellingModeMap).Return(map[string]bool{"1": true}).Build()
			mockey.Mock(multienv.GetSellingModeMapping).Return(map[string]string{"1": ""}).Build()

			// Act
			v := &AddCalculationFactorReq{
				CalculationFactorPermission: CalculationFactorPermission{},
				CalculationFactorTradeProduct: CalculationFactorTradeProduct{
					TradeProduct: "",
				},
				FactorID:           1,
				FactorType:         multienv.FactorTypeRadix,
				ConfigCode:         "1",
				SellingModeCode:    "1",
				ChargeItemCode:     "1",
				FactorDefaultValue: decimal.Decimal{},
				CustomerAccountIDs: []string{"1234"},
				PercentageValue:    "",
				currentUser: &model.Account{
					AccountID: "",
				},
			}
			err := v.paramCheck(context.Background(), &gorm.DB{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

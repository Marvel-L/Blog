package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"context"
)

func addFactorsToCache(factorsToBeUsable []*model.CalculationFactor) error {
	if len(factorsToBeUsable) == 0 {
		return nil
	}
	pipelineClient := redis_client.NewRedisClient().Pipeline()
	for _, factorToBeUsable := range factorsToBeUsable {
		pipelineClient.HSet(factorToBeUsable.GetCacheKey(), factorToBeUsable.GetKey(), util.GetJsonStr(factorToBeUsable))
	}

	if _, err := pipelineClient.Exec(); err != nil {
		return i18nfmt.Errorf(context.Background(), "启用计算因子，加入缓存失败%s", err.Error())
	}
	return nil
}

func delFactorsFromCache(factorsToAbandon []*model.CalculationFactor) error {
	if len(factorsToAbandon) == 0 {
		return nil
	}
	pipelineClient := redis_client.NewRedisClient().Pipeline()
	for _, factorToAbandon := range factorsToAbandon {
		pipelineClient.HDel(factorToAbandon.GetCacheKey(), factorToAbandon.GetKey())
	}

	if _, err := pipelineClient.Exec(); err != nil {
		return i18nfmt.Errorf(context.Background(), "废弃计算因子，删除缓存失败%s", err.Error())
	}
	return nil
}

type CalculationFactorCacheRefreshReq struct {
	CalculationFactorPermission
	FactorIDs []int64 `json:"FactorIDs"`
}

func (r *CalculationFactorCacheRefreshReq) Handle(ctx context.Context) (interface{}, error) {

	_, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}
	tx := dal.DBProxy.NewRequest(ctx)
	condition := framework.Condition{}
	condition["id"] = r.FactorIDs
	factors, err := dal.CalculationFactorDao.FindFactorsByConditions(ctx, tx, condition)
	if err != nil {
		return nil, err
	}
	var addCacheFactors []*model.CalculationFactor
	var delCacheFactors []*model.CalculationFactor
	for _, factor := range factors {
		if factor.FactorStatus == multienv.FactorStatusUsable {
			addCacheFactors = append(addCacheFactors, factor)
		} else {
			delCacheFactors = append(delCacheFactors, factor)
		}
	}
	if err = addFactorsToCache(addCacheFactors); err != nil {
		return nil, err
	}

	if err = delFactorsFromCache(delCacheFactors); err != nil {
		return nil, err
	}

	return r, err
}

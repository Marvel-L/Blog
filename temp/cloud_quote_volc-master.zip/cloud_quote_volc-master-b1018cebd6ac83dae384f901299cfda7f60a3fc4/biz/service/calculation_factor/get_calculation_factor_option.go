package calculation_factor

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type GetCalculationFactorOptionReq struct {
	CalculationFactorPermission
	CalculationFactorTradeProduct
	CfgNodeList []*product_config_parser.ConfigNode `json:"CfgNodeList,required"`
}

func (r *GetCalculationFactorOptionReq) Handle(ctx context.Context) (interface{}, error) {
	return r.getOptions(ctx)
}
func (r *GetCalculationFactorOptionReq) getOptions(ctx context.Context) ([]*config_option_service.Option, error) {

	_, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}

	productInfo, err := r.tradeProductCheck(ctx)
	if err != nil {
		return nil, err
	}

	container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)
	if err != nil {
		return nil, err
	}
	filter := &product_config_parser.ConfigNodesFilter{
		ProductInfo:             productInfo,
		QuoteCustomerScope:      multienv.QuoteCustomerScopeAll,
		CheckConfigIsPublic:     false,
		CheckAllPrePayWhiteList: false,
	}
	configTree, err := container.GetProductConfigTree(ctx, productInfo, true, filter)
	if err != nil {
		return nil, err
	}
	if configTree.Root == nil {
		return nil, errors.NewBizErrWithMsg(errors.CommodityNoOption, "当前商品不存在可报价配置")
	}
	// 拼装选项
	options, err := config_option_service.GetCommonOptions(ctx, nil, configTree, r.CfgNodeList, productInfo, false)
	var useOptions []*config_option_service.Option
	for _, option := range options {
		if option.AttrKey != constants.SelectAll {
			useOptions = append(useOptions, option)
		}
	}
	return useOptions, err
}

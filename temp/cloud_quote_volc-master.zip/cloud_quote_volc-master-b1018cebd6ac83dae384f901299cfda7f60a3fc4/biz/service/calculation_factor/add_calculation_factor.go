package calculation_factor

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/account_info"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"github.com/shopspring/decimal"
	"gorm.io/gorm"
	"time"
)

const calculationFactorQuoteLockKey = "calculation_factor_quote_lock_"

type AddCalculationFactorReq struct {
	CalculationFactorPermission
	CalculationFactorTradeProduct
	FactorID           int64           `json:"FactorID"`
	FactorType         string          `json:"FactorType,required"`
	ConfigCode         string          `json:"ConfigCode"`
	SellingModeCode    string          `json:"SellingModeCode"`
	ChargeItemCode     string          `json:"ChargeItemCode"`
	FactorDefaultValue decimal.Decimal `json:"FactorDefaultValue"`
	CustomerAccountIDs []string        `json:"CustomerAccountIDs,required"`
	PercentageValue    string          `json:"PercentageValue"`

	productInfo  *trade_client.TradeProductVersionInfo
	currentUser  *model.Account
	oldFactor    *model.CalculationFactor
	factorsToAdd []*model.CalculationFactor
	factorModel  *model.CalculationFactor
}

type AddCalculationFactorResp struct {
	FactorIDs []int64
}

func (r *AddCalculationFactorReq) Handle(ctx context.Context) (interface{}, error) {

	currentUser, err := r.permissionCheck(ctx)
	if err != nil {
		return nil, err
	}
	r.currentUser = currentUser
	lock := redis_client.RedisLock{
		LockKey: calculationFactorQuoteLockKey + r.getLockKey(),
		Value:   logid.GenLogID(),
		Timeout: 60 * time.Second,
	}
	// 抢占分布式锁
	if err := lock.Lock(); err != nil {
		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
		return nil, i18nfmt.NewError(ctx, "当前配置计费项计算因子正在提交，请稍后重试")
	}
	defer lock.Unlock()

	var resp interface{}
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.addFactor(ctx, tx)
		return err
	})

	return resp, err
}
func (r *AddCalculationFactorReq) addFactor(ctx context.Context, tx *gorm.DB) (interface{}, error) {
	if err := r.paramCheck(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.repeatCheck(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.transferToFactors(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.saveFactors(ctx, tx); err != nil {
		return nil, err
	}
	var factorIDs []int64
	for _, calculationFactor := range r.factorsToAdd {
		factorIDs = append(factorIDs, calculationFactor.Id)
	}

	return &AddCalculationFactorResp{
		FactorIDs: factorIDs,
	}, nil
}

func (r *AddCalculationFactorReq) paramCheck(ctx context.Context, tx *gorm.DB) error {

	if r.FactorID > 0 {
		oldFactor, err := dal.CalculationFactorDao.FindFactorByID(tx, r.FactorID)
		if err != nil {
			return err
		}
		if oldFactor.FactorStatus != multienv.FactorStatusDraft {
			return i18nfmt.NewError(ctx, "当前计算因子非草稿状态，不允许编辑")
		}
		r.oldFactor = oldFactor
	}
	r.CustomerAccountIDs = util.GetUniqKeys(r.CustomerAccountIDs)
	accountInfos, err := account_info.ListAccountByIds(ctx, r.CustomerAccountIDs)
	if err != nil {
		return err
	}
	if len(accountInfos) != len(r.CustomerAccountIDs) {
		return i18nfmt.NewError(ctx, "输入账号信息查询失败，请确认")
	}

	factorData := &item_context.FactorData{
		FactorType:      r.FactorType,
		FactorValue:     r.FactorDefaultValue,
		PercentageValue: r.PercentageValue,
	}

	if err = factorData.DataCheck(ctx); err != nil {
		return err
	}
	factorModel := &model.CalculationFactor{
		FactorType:       r.FactorType,
		CreatorAccountId: r.currentUser.AccountID,
		FactorStatus:     multienv.FactorStatusDraft,
		PercentageValue:  r.PercentageValue,
	}

	if _, ok := multienv.NormalFactorMapping[r.FactorType]; ok {
		productInfo, err := r.tradeProductCheck(ctx)
		if err != nil {
			return err
		}
		r.productInfo = productInfo
		container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)
		if err != nil {
			return err
		}
		filter := &product_config_parser.ConfigNodesFilter{
			ProductInfo:             productInfo,
			QuoteCustomerScope:      multienv.QuoteCustomerScopeAll,
			CheckConfigIsPublic:     false,
			CheckAllPrePayWhiteList: false,
		}
		configNodes := container.GetConfigNodeList(ctx, filter, r.getChargeItemKey())
		if configNodes == nil {
			return i18nfmt.NewError(ctx, "输入的商品配置计费项信息不存在，请确认")
		}
		priceInfo := product_config_load.TransOtherInfoToPriceInfo(configNodes[len(configNodes)-1].OtherInfo)
		productPriceInfo := item_context.GetProductPriceInfo(&priceInfo)
		if r.SellingModeCode != "" {
			sellingModeMap := productPriceInfo.GetSupportSellingModeMap()
			if _, ok := sellingModeMap[r.SellingModeCode]; !ok {
				return i18nfmt.NewError(ctx, "售卖模式设置错误，当前配置计费项不支持该售卖模式")
			}
		}

		factorModel.TradeProduct = r.TradeProduct
		factorModel.TradeProductName = productInfo.TradeProductName
		factorModel.ChargeItemCode = r.ChargeItemCode
		factorModel.FactorDefaultValue = r.FactorDefaultValue
		for _, configNode := range configNodes {
			if configNode.NodeType == constants.SchemaCanPrePay {
				factorModel.CanPrePayCode = configNode.NodeKey
				factorModel.CanPrePayName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaConfigCategory {
				factorModel.ConfigCategoryCode = configNode.NodeKey
				factorModel.ConfigCategoryName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaConfig {
				factorModel.ConfigCode = configNode.NodeKey
				factorModel.ConfigName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaChargeMethod {
				factorModel.ChargeMethodCode = configNode.NodeKey
				factorModel.ChargeMethodName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaRegion {
				factorModel.RegionCode = configNode.NodeKey
				factorModel.RegionName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaChargeUnit {
				factorModel.ChargeUnitCode = configNode.NodeKey
				factorModel.ChargeUnitName = configNode.NodeName
			} else if configNode.NodeType == constants.SchemaPriceFactor {
				factorModel.PriceFactorCode = configNode.NodeKey
				factorModel.PriceFactorName = configNode.NodeName
			}
		}
		factorModel.SellingModeCode = r.SellingModeCode
		factorModel.SellingModeName = multienv.GetSellingModeMapping()[r.SellingModeCode]
	}
	r.factorModel = factorModel
	return nil
}

func (r *AddCalculationFactorReq) repeatCheck(ctx context.Context, tx *gorm.DB) error {
	condition := framework.Condition{}
	condition["trade_product"] = r.TradeProduct
	condition["config_code"] = r.ConfigCode
	condition["selling_mode_code"] = r.SellingModeCode
	condition["charge_item_code"] = r.ChargeItemCode
	condition["factor_type"] = r.FactorType
	condition["id != "] = r.FactorID
	condition["factor_status"] = []string{multienv.FactorStatusDraft, multienv.FactorStatusUsable}
	factors, err := dal.CalculationFactorDao.FindFactorsByConditions(ctx, tx, condition)
	if err != nil {
		return err
	}
	customerAccountIDMap := util.StrSliceToMap(r.CustomerAccountIDs)
	var repeatFactorIDs []int64
	for _, calculationFactor := range factors {
		if _, ok := customerAccountIDMap[calculationFactor.CustomerAccountId]; ok {
			repeatFactorIDs = append(repeatFactorIDs, calculationFactor.Id)
		}
	}
	if len(repeatFactorIDs) > 0 {
		return i18nfmt.Errorf(ctx, "当前计算因子已存在重复的计算因子，ID: %s ，请确认！", util.GetJsonStr(repeatFactorIDs))
	}
	return err
}

func (r *AddCalculationFactorReq) transferToFactors(ctx context.Context, tx *gorm.DB) error {

	var factorsToAdd []*model.CalculationFactor
	var findSameFactor bool
	for _, customerAccountID := range r.CustomerAccountIDs {
		newFactorToAdd := *r.factorModel
		newFactorToAdd.CustomerAccountId = customerAccountID
		if r.oldFactor != nil && r.oldFactor.CustomerAccountId == customerAccountID {
			newFactorToAdd.Id = r.oldFactor.Id
			findSameFactor = true
		}
		factorsToAdd = append(factorsToAdd, &newFactorToAdd)
	}
	if r.oldFactor != nil && !findSameFactor {
		factorsToAdd[0].Id = r.oldFactor.Id
	}
	r.factorsToAdd = factorsToAdd
	return nil
}

func (r *AddCalculationFactorReq) saveFactors(ctx context.Context, tx *gorm.DB) error {
	return dal.CalculationFactorDao.Save(tx, r.factorsToAdd, &model.CalculationFactor{})
}

func (r *AddCalculationFactorReq) getLockKey() string {
	return fmt.Sprintf("%s::%s::%s::%s::%s", r.FactorType, r.TradeProduct, r.ConfigCode, r.SellingModeCode, r.ChargeItemCode)
}

func (r *AddCalculationFactorReq) getChargeItemKey() string {
	return fmt.Sprintf("%s::%s::%s", r.TradeProduct, r.ConfigCode, r.ChargeItemCode)
}

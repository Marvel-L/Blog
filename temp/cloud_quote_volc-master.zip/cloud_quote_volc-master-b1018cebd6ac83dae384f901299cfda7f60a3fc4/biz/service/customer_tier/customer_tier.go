package customer_tier

import (
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/crmclient"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
)

const CustomerTierNone = "暂无客户等级"

type Source struct {
	AccountTierCN       string
	AccountParentTierCN string
	PartnerTierCN       string
}

func BuildSourceFromSimpleInfo(opp *crm_service.OpportunitySimpleInfo) Source {
	source := Source{}
	if opp == nil {
		return source
	}
	if opp.AccountInfo != nil {
		source.AccountTierCN = opp.AccountInfo.AccountTierCN
	}
	if opp.ParentAccountInfo != nil {
		source.AccountParentTierCN = opp.ParentAccountInfo.AccountTierCN
	}
	if opp.PartnerInfo != nil {
		source.PartnerTierCN = opp.PartnerInfo.AccountTierCN
	}
	return source
}

func BuildSourceFromOpportunityInfo(opp *opportunity.SearchOpportunityRelatedInfoForQuote) Source {
	source := Source{}
	if opp == nil {
		return source
	}
	if opp.GetAccountInfo() != nil {
		source.AccountTierCN = opp.GetAccountInfo().GetAccountTierCN()
	}
	if opp.GetParentAccountInfo() != nil {
		source.AccountParentTierCN = opp.GetParentAccountInfo().GetAccountTierCN()
	}
	if opp.GetPartnerInfo() != nil {
		source.PartnerTierCN = opp.GetPartnerInfo().GetAccountTierCN()
	}
	return source
}

func ResolveByTradeTypeCode(tradeTypeCode int, source Source) *crmclient.CustomerTierInfo {
	result := &crmclient.CustomerTierInfo{
		CustomerTierCN:             NormalizeTier(source.AccountTierCN),
		CustomerParentTierCN:       NormalizeTier(source.AccountParentTierCN),
		ContractEntityTierCN:       CustomerTierNone,
		ContractEntityParentTierCN: CustomerTierNone,
	}
	if IsContractEntityPartner(tradeTypeCode) {
		result.ContractEntityTierCN = NormalizeTier(source.PartnerTierCN)
		return result
	}
	result.ContractEntityTierCN = result.CustomerTierCN
	result.ContractEntityParentTierCN = result.CustomerParentTierCN
	return result
}

func NormalizeTier(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return CustomerTierNone
	}
	return raw
}

func IsContractEntityPartner(tradeTypeCode int) bool {
	switch tradeTypeCode {
	case multienv.CustomerTypeCodeEcoDist,
		multienv.CustomerTypeCodeEcoSalesByProxy,
		multienv.CustomerTypeCodeEcoSolution,
		multienv.CustomerTypeCodeEcoSell:
		return true
	default:
		return false
	}
}

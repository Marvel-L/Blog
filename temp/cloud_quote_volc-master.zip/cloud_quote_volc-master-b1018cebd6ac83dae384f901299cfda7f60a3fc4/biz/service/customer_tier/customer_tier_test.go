package customer_tier

import (
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestBuildSourceFromSimpleInfo(t *testing.T) {
	t.Run("空商机返回空来源", func(t *testing.T) {
		mockey.PatchConvey("空商机返回空来源", t, func() {
			got := BuildSourceFromSimpleInfo(nil)

			convey.So(got, convey.ShouldResemble, Source{})
		})
	})

	t.Run("提取客户伙伴和主客户等级", func(t *testing.T) {
		mockey.PatchConvey("提取客户伙伴和主客户等级", t, func() {
			opp := &crm_service.OpportunitySimpleInfo{
				AccountInfo:       &crm_service.AccountInfo{AccountTierCN: "KA"},
				ParentAccountInfo: &crm_service.AccountInfo{AccountTierCN: "母客户"},
				PartnerInfo:       &crm_service.AccountInfo{AccountTierCN: "伙伴"},
			}

			got := BuildSourceFromSimpleInfo(opp)

			convey.So(got, convey.ShouldResemble, Source{
				AccountTierCN:       "KA",
				AccountParentTierCN: "母客户",
				PartnerTierCN:       "伙伴",
			})
		})
	})
}

func TestBuildSourceFromOpportunityInfo(t *testing.T) {
	t.Run("空商机返回空来源", func(t *testing.T) {
		mockey.PatchConvey("空商机返回空来源", t, func() {
			got := BuildSourceFromOpportunityInfo(nil)

			convey.So(got, convey.ShouldResemble, Source{})
		})
	})

	t.Run("提取kitex商机中的客户等级", func(t *testing.T) {
		mockey.PatchConvey("提取kitex商机中的客户等级", t, func() {
			opp := &opportunity.SearchOpportunityRelatedInfoForQuote{
				AccountInfo:       &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{AccountTierCN: stringPtr("A类")},
				ParentAccountInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{AccountTierCN: stringPtr("父级")},
				PartnerInfo:       &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{AccountTierCN: stringPtr("伙伴级别")},
			}

			got := BuildSourceFromOpportunityInfo(opp)

			convey.So(got, convey.ShouldResemble, Source{
				AccountTierCN:       "A类",
				AccountParentTierCN: "父级",
				PartnerTierCN:       "伙伴级别",
			})
		})
	})
}

func TestResolveByTradeTypeCode(t *testing.T) {
	t.Run("伙伴签约主体使用伙伴等级", func(t *testing.T) {
		mockey.PatchConvey("伙伴签约主体使用伙伴等级", t, func() {
			source := Source{
				AccountTierCN:       " 客户等级 ",
				AccountParentTierCN: " ",
				PartnerTierCN:       " 伙伴等级 ",
			}

			got := ResolveByTradeTypeCode(multienv.CustomerTypeCodeEcoDist, source)

			convey.So(got.CustomerTierCN, convey.ShouldEqual, "客户等级")
			convey.So(got.CustomerParentTierCN, convey.ShouldEqual, CustomerTierNone)
			convey.So(got.ContractEntityTierCN, convey.ShouldEqual, "伙伴等级")
			convey.So(got.ContractEntityParentTierCN, convey.ShouldEqual, CustomerTierNone)
		})
	})

	t.Run("非伙伴签约主体沿用客户等级", func(t *testing.T) {
		mockey.PatchConvey("非伙伴签约主体沿用客户等级", t, func() {
			source := Source{
				AccountTierCN:       "",
				AccountParentTierCN: " 主客户 ",
				PartnerTierCN:       "伙伴等级",
			}

			got := ResolveByTradeTypeCode(multienv.CustomerTypeCodeDirectSell, source)

			convey.So(got.CustomerTierCN, convey.ShouldEqual, CustomerTierNone)
			convey.So(got.CustomerParentTierCN, convey.ShouldEqual, "主客户")
			convey.So(got.ContractEntityTierCN, convey.ShouldEqual, CustomerTierNone)
			convey.So(got.ContractEntityParentTierCN, convey.ShouldEqual, "主客户")
		})
	})
}

func stringPtr(v string) *string {
	return &v
}

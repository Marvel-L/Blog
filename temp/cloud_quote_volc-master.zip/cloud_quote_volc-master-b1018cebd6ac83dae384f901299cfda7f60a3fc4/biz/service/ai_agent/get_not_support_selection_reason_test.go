package ai_agent

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_effective"
	"context"
	"errors"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/constraint_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
)

func Test_GetNotSupportSelectionReasonReq_validateWithConstraint_BitsUTGen(t *testing.T) {
	t.Run("约束数据自身支持报价直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求对象，约束数据完全支持报价
			constraintData := &constraint_service.ConstraintData{
				ChargeItemKey:    "prod::cfg::item",
				ConfigStatus:     multienv.TradeConfigStatusOn,
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue,
			}
			r := &GetNotSupportSelectionReasonReq{
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
				ChargeItemCode:    "item",
				quote:             &model.Quote{},
				selectionRule:     &trade_client.SelectionRuleData{ConfigPublicDisplay: multienv.ConfigPublicDisplayFalse},
				configNodes:       []*product_config_parser.ConfigNode{{ConstraintField: constraintData}},
				notSupportReason:  map[string]map[string]interface{}{},
			}

			// 报价单场景为报价，确保checkConfigIsPublic为true
			mockey.MockUnsafe((*model.Quote).IsQuote).Return(true).Build()
			// 避免Match前置校验不通过
			mockey.MockUnsafe((*model.Quote).GetConstraintAccountIDs).Return([]int64{1}).Build()
			// 即使不会执行到Match，也给一个默认返回避免潜在调用
			mockey.Mock((*constraint_service.MatchConstraintChargeItemReq).Match).Return(map[string]*constraint_service.ConstraintData{}).Build()

			// 调用待测方法
			r.validateWithConstraint(context.Background(), (*gorm.DB)(nil))

			// 断言：直接返回，不填充不支持原因
			convey.So(len(r.notSupportReason), convey.ShouldEqual, 0)
		})
	})

	t.Run("匹配到约束数据且支持报价直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求对象，初始约束数据不支持报价，但Match后返回支持的约束数据
			constraintData := &constraint_service.ConstraintData{
				ChargeItemKey:    "prod::cfg::item",
				ConfigStatus:     0, // 使首次SupportQuote返回false
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue,
			}
			r := &GetNotSupportSelectionReasonReq{
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
				ChargeItemCode:    "item",
				quote:             &model.Quote{},
				selectionRule:     &trade_client.SelectionRuleData{ConfigPublicDisplay: multienv.ConfigPublicDisplayFalse},
				configNodes:       []*product_config_parser.ConfigNode{{ConstraintField: constraintData}},
				notSupportReason:  map[string]map[string]interface{}{},
			}

			// 报价单场景为报价，确保checkConfigIsPublic为true
			mockey.MockUnsafe((*model.Quote).IsQuote).Return(true).Build()
			// 保证Match的前置校验通过
			mockey.MockUnsafe((*model.Quote).GetConstraintAccountIDs).Return([]int64{1, 2}).Build()
			// 返回匹配到支持报价的约束数据
			matchOK := &constraint_service.ConstraintData{
				ChargeItemKey:    constraintData.ChargeItemKey,
				ConfigStatus:     multienv.TradeConfigStatusOn,
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue,
			}
			mockey.Mock((*constraint_service.MatchConstraintChargeItemReq).Match).Return(map[string]*constraint_service.ConstraintData{
				constraintData.ChargeItemKey: matchOK,
			}).Build()

			// 调用待测方法
			r.validateWithConstraint(context.Background(), (*gorm.DB)(nil))

			// 断言：匹配到支持的约束数据后直接返回，不填充不支持原因
			convey.So(len(r.notSupportReason), convey.ShouldEqual, 0)
		})
	})

	t.Run("不支持场景填充所有原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求对象，约束数据各项不支持
			constraintData := &constraint_service.ConstraintData{
				ChargeItemKey:    "prod::cfg::item",
				ConfigStatus:     0,
				ChargeItemStatus: 0,
				ConfigIsPublic:   0,
			}
			r := &GetNotSupportSelectionReasonReq{
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
				ChargeItemCode:    "item",
				quote:             &model.Quote{},
				selectionRule:     &trade_client.SelectionRuleData{ConfigPublicDisplay: multienv.ConfigPublicDisplayFalse},
				configNodes:       []*product_config_parser.ConfigNode{{ConstraintField: constraintData}},
				notSupportReason:  map[string]map[string]interface{}{},
			}

			// 报价单场景为报价，确保checkConfigIsPublic为true
			mockey.MockUnsafe((*model.Quote).IsQuote).Return(true).Build()
			// 保证Match的前置校验通过
			mockey.MockUnsafe((*model.Quote).GetConstraintAccountIDs).Return([]int64{3}).Build()
			// 返回nil，保证不会触发第二个return分支
			mockey.Mock((*constraint_service.MatchConstraintChargeItemReq).Match).Return(nil).Build()

			// 调用待测方法
			r.validateWithConstraint(context.Background(), (*gorm.DB)(nil))

			// 断言：应填充三个不支持原因
			convey.So(len(r.notSupportReason), convey.ShouldEqual, 3)
			convey.So(r.notSupportReason, convey.ShouldContainKey, "configuration_status_not_support_with_constraint")
			convey.So(r.notSupportReason, convey.ShouldContainKey, "charge_item_status_not_support_with_constraint")
			convey.So(r.notSupportReason, convey.ShouldContainKey, "configuration_is_public_not_support_with_constraint")
		})
	})

	t.Run("匹配结果为空映射时继续使用原始约束值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			constraintData := &constraint_service.ConstraintData{
				ChargeItemKey:    "prod::cfg::item",
				ConfigStatus:     0,
				ChargeItemStatus: 0,
				ConfigIsPublic:   0,
			}
			r := &GetNotSupportSelectionReasonReq{
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
				ChargeItemCode:    "item",
				quote:             &model.Quote{},
				selectionRule:     &trade_client.SelectionRuleData{ConfigPublicDisplay: multienv.ConfigPublicDisplayFalse},
				configNodes:       []*product_config_parser.ConfigNode{{ConstraintField: constraintData}},
				notSupportReason:  map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*model.Quote).IsQuote).Return(true).Build()
			mockey.MockUnsafe((*model.Quote).GetConstraintAccountIDs).Return([]int64{9}).Build()
			mockey.Mock((*constraint_service.MatchConstraintChargeItemReq).Match).Return(map[string]*constraint_service.ConstraintData{}).Build()

			r.validateWithConstraint(context.Background(), (*gorm.DB)(nil))

			convey.So(r.notSupportReason["configuration_status_not_support_with_constraint"], convey.ShouldNotBeNil)
			convey.So(r.notSupportReason["charge_item_status_not_support_with_constraint"], convey.ShouldNotBeNil)
			convey.So(r.notSupportReason["configuration_is_public_not_support_with_constraint"], convey.ShouldNotBeNil)
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_validateOriginProduct_BitsUTGen(t *testing.T) {

	t.Run("修改流程成功且业务线不匹配，选品不可见且约束后下架", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        2002,
				ProductCode:    "prod-2",
				IsSolution:     true,
				IsDeliveryItem: false,
				quote: &model.Quote{
					ModifyStatus:  constants.ApprovalModifyStatusStart,
					QuoteStatus:   constants.StatusSubmit,
					QuoteType:     0,
					QuoteScene:    multienv.QuoteScene(0),
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: 0,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-2",
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline-tag",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "C",
				},
				selectionRule:    &trade_client.SelectionRuleData{Display: 2},
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{
				BizLineNameList: []string{"A", "B"},
			}, nil).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(map[string]int{
				"prod-2": 0,
			}).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			convey.So(r.notSupportReason["product_biz_line_not_support_in_modify_process"], convey.ShouldNotBeNil)
			convey.So(r.notSupportReason["product_selection_rule_not_display"], convey.ShouldNotBeNil)
			convey.So(r.notSupportReason["product_status_not_support"], convey.ShouldNotBeNil)
			reason := r.notSupportReason["product_status_not_support"]
			convey.So(reason["product_status_has_constraint"], convey.ShouldEqual, true)
			convey.So(reason["product_status_constraint_after"], convey.ShouldEqual, 0)
		})
	})

	t.Run("无约束但商品状态下架", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        3003,
				ProductCode:    "prod-3",
				IsSolution:     true,
				IsDeliveryItem: true,
				quote: &model.Quote{
					ModifyStatus:  0,
					QuoteStatus:   "",
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: 0,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-3",
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      0,
					BizLineName: "D",
				},
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			convey.So(r.notSupportReason["product_status_not_support"], convey.ShouldNotBeNil)
			reason := r.notSupportReason["product_status_not_support"]
			convey.So(reason["product_status_has_constraint"], convey.ShouldEqual, false)
			convey.So(reason["support_product_status"], convey.ShouldEqual, multienv.TradeProductStatusOn)
		})
	})

	t.Run("节省计划商品在报价单不支持时写入原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        3600,
				ProductCode:    "prod-sp",
				IsSolution:     true,
				IsDeliveryItem: true,
				quote: &model.Quote{
					QuoteType:     11,
					QuoteScene:    multienv.QuoteScene(12),
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: 13,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-sp",
					SalesMode:    multienv.SalesModeSavingsPlans,
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "line",
				},
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()
			mockey.Mock((*model.Quote).SupportSpProduct).Return(false).Build()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			reason := r.notSupportReason["quote_not_support_sp_product"]
			convey.So(reason, convey.ShouldNotBeNil)
			convey.So(reason["is_byte_plus"], convey.ShouldEqual, false)
			convey.So(reason["quote_type"], convey.ShouldEqual, r.quote.QuoteType)
			convey.So(reason["quote_scene"], convey.ShouldEqual, r.quote.QuoteScene)
			convey.So(reason["quote_trade_type"], convey.ShouldEqual, r.quote.TradeTypeCode)
		})
	})

	t.Run("节省计划商品在报价单支持时不写入原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        3700,
				ProductCode:    "prod-sp-ok",
				IsSolution:     true,
				IsDeliveryItem: true,
				quote: &model.Quote{
					TradeType: multienv.TradeType("any"),
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-sp-ok",
					SalesMode:    multienv.SalesModeSavingsPlans,
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "line",
				},
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()
			mockey.Mock((*model.Quote).SupportSpProduct).Return(true).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(r.notSupportReason["quote_not_support_sp_product"], convey.ShouldBeNil)
		})
	})

	t.Run("提货券商品在报价单不支持时写入原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        3800,
				ProductCode:    "prod-pv",
				IsSolution:     true,
				IsDeliveryItem: true,
				quote: &model.Quote{
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: multienv.CustomerTypeCodeEcoDist,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-pv",
					SalesMode:    multienv.SalesModePickupVoucher,
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "line",
				},
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()
			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			reason := r.notSupportReason["quote_not_support_pickup_voucher_product"]
			convey.So(reason, convey.ShouldNotBeNil)
			convey.So(reason["quote_trade_type"], convey.ShouldEqual, r.quote.TradeTypeCode)
		})
	})

	t.Run("全部规则不触发", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        4004,
				ProductCode:    "prod-4",
				IsSolution:     true,
				IsDeliveryItem: true,
				quote: &model.Quote{
					ModifyStatus:  0,
					QuoteStatus:   "",
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: 0,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-4",
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "X",
				},
				selectionRule:    nil,
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeInternal).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(r.notSupportReason), convey.ShouldEqual, 0)
		})
	})

	t.Run("修改流程成功且业务线匹配不添加原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()

			r := &GetNotSupportSelectionReasonReq{
				QuoteID:        5005,
				ProductCode:    "prod-5",
				IsSolution:     true,
				IsDeliveryItem: false,
				quote: &model.Quote{
					ModifyStatus:  constants.ApprovalModifyStatusStart,
					QuoteStatus:   constants.StatusSubmit,
					TradeType:     multienv.TradeType("any"),
					TradeTypeCode: 0,
				},
				product: &trade_client.ProductInfo{
					Product:      "prod-5",
					SalesStatus:  multienv.SalesStatusOfficialSale,
					SalesChannel: "官网",
					CatalogueCodeMap: map[string]string{
						multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
						multienv.StandardProductKey: multienv.StandardProductYes,
					},
					SingleSale:  1,
					ProductTag:  "no-offline",
					Status:      multienv.TradeProductStatusOn,
					BizLineName: "B",
				},
				selectionRule:    nil,
				notSupportReason: map[string]map[string]interface{}{},
			}

			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(false).Build()
			mockey.MockUnsafe(multienv.TradeType.GetCustomerScope).Return(multienv.QuoteCustomerScopeExternal).Build()
			mockey.Mock(assistant.CallbackWithQuote).Return(&assistant.CallbackInfo{
				BizLineNameList: []string{"A", "B"},
			}, nil).Build()
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(nil).Build()

			err := r.validateOriginProduct(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(r.notSupportReason["product_biz_line_not_support_in_modify_process"], convey.ShouldBeNil)
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_validateCacheConfigNodes_BitsUTGen(t *testing.T) {
	t.Run("配置节点为空直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()

			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				notSupportReason: map[string]map[string]interface{}{},
			}

			err := req.validateCacheConfigNodes(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(req.notSupportReason), convey.ShouldEqual, 0)
		})
	})

	t.Run("公有云计费项触发多种校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()

			ctx := context.Background()
			priceInfo := product_config_load.PriceInfo{
				PricingFunction: constants.PricingFunctionFixedPrice,
				Price:           0,
				BuyNumUnit:      "num",
				BuyDurationUnit: "duration",
			}
			req := &GetNotSupportSelectionReasonReq{
				configNodes: []*product_config_parser.ConfigNode{
					{
						CustomerScope: multienv.CustomerScopeInternal,
						OtherInfo:     priceInfo,
					},
				},
				quote: &model.Quote{
					TradeType:     multienv.TradeType("outer_trade_type"),
					TradeTypeCode: 101,
					QuoteType:     3,
					QuoteScene:    multienv.QuoteScene(4),
				},
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePublic),
					StandardProduct: multienv.TradeProductStandardYes,
				},
				SellingModeCode:  "modeA",
				configuration:    &commercialization_api.Configuration{},
				notSupportReason: map[string]map[string]interface{}{},
			}

			// 避免GetCustomerScope内部的I18n调用引发空指针
			mockey.Mock(multienv.GetOppNumberPrefixMap).Return(map[multienv.TradeType]string{}).Build()

			mockey.Mock((*GetNotSupportSelectionReasonReq).validateWithConstraint).Return().Build()
			mockey.MockUnsafe((*GetNotSupportSelectionReasonReq).isPublicQuote).Return(true).Build()
			mockey.Mock(multienv.GetDiscountLineMap).Return(map[string]interface{}{"dl": struct{}{}}).Build()
			mockey.Mock(item_effective.ShortOfMultiDiscountLine).Return(true).Build()
			mockey.Mock((*model.Quote).SupportQuantityPrice).Return(true).Build()
			mockey.Mock(item_context.AllowedZeroChargeItem).Return(false).Build()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			err := req.validateCacheConfigNodes(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			customerScopeReason := req.notSupportReason["charge_item_customer_scope_not_support"]
			convey.So(customerScopeReason, convey.ShouldNotBeNil)
			convey.So(customerScopeReason["quote_customer_scope"], convey.ShouldEqual, multienv.QuoteCustomerScopeExternal)
			convey.So(customerScopeReason["charge_item_customer_scope"], convey.ShouldEqual, multienv.CustomerScopeInternal)

			sellingReason := req.notSupportReason["charge_item_selling_mode_not_support"]
			convey.So(sellingReason, convey.ShouldNotBeNil)
			convey.So(sellingReason["charge_item_selling_mode"], convey.ShouldEqual, "modeA")
			supportModes, ok := sellingReason["support_charge_item_selling_mode"].([]string)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(supportModes, convey.ShouldResemble, []string{})

			discountReason := req.notSupportReason["charge_item_discount_line_not_support"]
			convey.So(discountReason, convey.ShouldNotBeNil)
			convey.So(discountReason["charge_item_selling_mode"], convey.ShouldEqual, "modeA")
			convey.So(discountReason["charge_item_support_quantity_price"], convey.ShouldBeFalse)
			needLines, ok := discountReason["charge_item_need_discount_line"].([]string)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(needLines, convey.ShouldContain, "dl")

			zeroPriceReason := req.notSupportReason["charge_item_standard_price_zero_not_support"]
			convey.So(zeroPriceReason, convey.ShouldNotBeNil)
			convey.So(zeroPriceReason["is_byte_plus"], convey.ShouldBeFalse)
			convey.So(zeroPriceReason["quote_type"], convey.ShouldEqual, 3)
			convey.So(zeroPriceReason["quote_scene"], convey.ShouldEqual, multienv.QuoteScene(4))
			convey.So(zeroPriceReason["product_type"], convey.ShouldEqual, constants.ProductType(multienv.TradeProductDeploymentTypePublic))
			convey.So(zeroPriceReason["standard_product"], convey.ShouldEqual, multienv.TradeProductStandardYes)
		})
	})

	t.Run("私有云线下商品缺少购买单位", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()

			ctx := context.Background()
			priceInfo := product_config_load.PriceInfo{
				PricingFunction: constants.PricingFunctionFixedPrice,
				Price:           10,
				BuyNumUnit:      "",
				BuyDurationUnit: "",
			}
			req := &GetNotSupportSelectionReasonReq{
				configNodes: []*product_config_parser.ConfigNode{
					{
						CustomerScope: multienv.CustomerScopeInternalAndExternal,
						OtherInfo:     priceInfo,
					},
				},
				quote: &model.Quote{
					TradeType:     multienv.TradeType("outer_trade_type"),
					TradeTypeCode: 202,
				},
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePrivate),
					StandardProduct: multienv.TradeProductStandardYes,
				},
				notSupportReason: map[string]map[string]interface{}{},
			}

			// 避免GetCustomerScope内部的I18n调用引发空指针
			mockey.Mock(multienv.GetOppNumberPrefixMap).Return(map[multienv.TradeType]string{}).Build()

			mockey.Mock((*GetNotSupportSelectionReasonReq).validateWithConstraint).Return().Build()

			err := req.validateCacheConfigNodes(ctx, nil)
			convey.So(err, convey.ShouldBeNil)

			buyNumReason := req.notSupportReason["charge_item_buy_num_unit_short"]
			convey.So(buyNumReason, convey.ShouldNotBeNil)
			convey.So(len(buyNumReason), convey.ShouldEqual, 0)

			buyDurationReason := req.notSupportReason["charge_item_buy_duration_unit_short"]
			convey.So(buyDurationReason, convey.ShouldNotBeNil)
			convey.So(len(buyDurationReason), convey.ShouldEqual, 0)
		})
	})
}

//go:noinline
func newPublicProduct(code string) *trade_client.ProductInfo {
	return &trade_client.ProductInfo{
		ProductCode:     code,
		ProductType:     int(multienv.TradeProductDeploymentTypePublic),
		StandardProduct: multienv.TradeProductStandardYes,
	}
}

//go:noinline
func newNonPublicProduct(code string) *trade_client.ProductInfo {
	return &trade_client.ProductInfo{
		ProductCode:     code,
		ProductType:     int(multienv.TradeProductDeploymentTypePublic) + 1,
		StandardProduct: 0,
	}
}
func Test_GetNotSupportSelectionReasonReq_initValidateInfo_BitsUTGen(t *testing.T) {
	t.Run("报价单ID校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 0, ProductCode: "prod"}
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单id不能为空")
		})
	})

	t.Run("商品编码校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 1}
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品code不能为空")
		})
	})

	t.Run("报价单查询失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 1, ProductCode: "prod"}
			queryErr := errors.New("db error")
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return((*model.Quote)(nil), queryErr).Build()
			mockey.MockUnsafe(quoteerrors.IsRecordNotFound).Return(false).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单不存在")
		})
	})

	t.Run("商品查询接口异常", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 1, ProductCode: "prod"}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			cacheErr := errors.New("cache error")
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return(([]*trade_client.ProductInfo)(nil), cacheErr).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品查询失败")
		})
	})

	t.Run("商品不存在", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 1, ProductCode: "prod"}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品不存在")
		})
	})

	t.Run("选品规则查询失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{QuoteID: 1, ProductCode: "prod"}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			ruleErr := errors.New("rule error")
			mockey.Mock(commodity_service.GetProductSelectRule).Return((*trade_client.SelectionRuleData)(nil), ruleErr).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "选品规则查询失败")
		})
	})

	t.Run("公有云缺少配置编码", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:        1,
				ProductCode:    "prod",
				ChargeItemCode: "charge",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置code不能为空")
		})
	})

	t.Run("非公有云配置编码不允许", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:           1,
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newNonPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "非公有云商品不支持配置code")
		})
	})

	t.Run("配置查询接口异常", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:           1,
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			cfgErr := errors.New("config error")
			mockey.Mock(trade_client.ListConfiguration).Return((*commercialization_api.ListConfigurationResult)(nil), cfgErr).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置计费项查询失败")
		})
	})

	t.Run("配置列表为空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:           1,
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			mockey.Mock(trade_client.ListConfiguration).Return(&commercialization_api.ListConfigurationResult{List: []*commercialization_api.Configuration{}}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配置计费项不存在")
		})
	})

	t.Run("计费项编码为空直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:     1,
				ProductCode: "prod",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(req.product, convey.ShouldNotBeNil)
			convey.So(req.selectionRule, convey.ShouldNotBeNil)
		})
	})

	t.Run("计费项查询接口异常", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:        1,
				ProductCode:    "prod",
				ChargeItemCode: "charge",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newNonPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			chargeErr := errors.New("charge error")
			mockey.Mock(trade_client.ListOriginChargeItem).Return(([]*commercialization_api.ChargeItemModel)(nil), chargeErr).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "计费项查询失败")
		})
	})

	t.Run("计费项列表为空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:        1,
				ProductCode:    "prod",
				ChargeItemCode: "charge",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newNonPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			mockey.Mock(trade_client.ListOriginChargeItem).Return([]*commercialization_api.ChargeItemModel{}, nil).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "计费项不存在")
		})
	})

	t.Run("配置容器获取失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:        1,
				ProductCode:    "prod",
				ChargeItemCode: "charge",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newNonPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			mockey.Mock(trade_client.ListOriginChargeItem).Return([]*commercialization_api.ChargeItemModel{{ChargeItemCode: "charge"}}, nil).Build()
			containerErr := errors.New("container error")
			mockey.Mock(product_config_load.GetConfigContainer).Return((*product_config_load.ConfigContainer)(nil), containerErr).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品类型不支持报价")
		})
	})

	t.Run("初始化信息成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetNotSupportSelectionReasonReq{
				QuoteID:           1,
				ProductCode:       "prod",
				ConfigurationCode: "cfg",
				ChargeItemCode:    "charge",
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{}, nil).Build()
			mockey.Mock((*commodity_service.ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{newPublicProduct("prod")}, nil).Build()
			mockey.Mock(commodity_service.GetProductSelectRule).Return(&trade_client.SelectionRuleData{}, nil).Build()
			mockey.Mock(trade_client.ListConfiguration).Return(&commercialization_api.ListConfigurationResult{
				List: []*commercialization_api.Configuration{{ConfigurationCode: "cfg"}},
			}, nil).Build()
			mockey.Mock(trade_client.ListOriginChargeItem).Return([]*commercialization_api.ChargeItemModel{{ChargeItemCode: "charge"}}, nil).Build()
			container := &product_config_load.ConfigContainer{}
			mockey.Mock(product_config_load.GetConfigContainer).Return(container, nil).Build()
			configNodes := []*product_config_parser.ConfigNode{{NodeName: "node"}}
			mockey.Mock((*product_config_load.ConfigContainer).GetConfigNodeListWithoutFilter).Return(configNodes).Build()
			err := req.initValidateInfo(ctx, nil)
			convey.So(err, convey.ShouldBeNil)
			convey.So(req.quote, convey.ShouldNotBeNil)
			convey.So(req.product, convey.ShouldNotBeNil)
			convey.So(req.configuration, convey.ShouldNotBeNil)
			convey.So(req.chargeItem, convey.ShouldNotBeNil)
			convey.So(len(req.configNodes), convey.ShouldEqual, 1)
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_validateOriginConfiguration_BitsUTGen(t *testing.T) {
	t.Run("配置为空时直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求，配置为空
			req := &GetNotSupportSelectionReasonReq{
				configuration:    nil,
				notSupportReason: nil,
			}
			ctx := context.Background()

			// 调用方法
			err := req.validateOriginConfiguration(ctx, nil)

			// 断言返回为空，不应修改原因
			convey.So(err, convey.ShouldBeNil)
			convey.So(req.notSupportReason, convey.ShouldBeNil)
		})
	})

	t.Run("配置状态/售卖状态/渠道均不支持时写入原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置状态不支持，售卖状态不在映射中，渠道为不生效渠道
			cfg := &commercialization_api.Configuration{
				Status:       int8(0),
				SalesStatus:  int8(1),
				SalesChannel: multienv.ConfigUnEffectiveSalesChannel,
			}
			req := &GetNotSupportSelectionReasonReq{
				configuration:    cfg,
				notSupportReason: make(map[string]map[string]interface{}),
			}
			ctx := context.Background()

			// 调用方法
			err := req.validateOriginConfiguration(ctx, nil)

			// 断言错误为空
			convey.So(err, convey.ShouldBeNil)

			// 断言状态不支持原因写入
			statusReason := req.notSupportReason["configuration_status_not_support"]
			convey.So(statusReason, convey.ShouldNotBeNil)
			convey.So(statusReason["configuration_status"], convey.ShouldEqual, cfg.Status)
			convey.So(statusReason["support_configuration_status"], convey.ShouldResemble,
				[]int8{multienv.TradeConfigStatusOn, multienv.TradeConfigStatusToOff})

			// 断言售卖状态不支持原因写入
			salesStatusReason := req.notSupportReason["configuration_sales_status_not_support"]
			convey.So(salesStatusReason, convey.ShouldNotBeNil)
			convey.So(salesStatusReason["configuration_sales_status"], convey.ShouldEqual, cfg.SalesStatus)
			// 验证支持的售卖状态集合包含预期项（映射的键为2、3、4）
			supportedAny, ok := salesStatusReason["support_configuration_sales_status"].([]int)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(supportedAny, convey.ShouldContain, 2)
			convey.So(supportedAny, convey.ShouldContain, 3)
			convey.So(supportedAny, convey.ShouldContain, 4)
			// 同时和MapKeysToSlice的结果进行弱校验（不比较顺序，只校验包含）
			expectedKeys := util.MapKeysToSlice(multienv.TradeProductSalesStatusCheckMapping)
			for _, k := range expectedKeys {
				convey.So(supportedAny, convey.ShouldContain, k)
			}

			// 断言渠道不支持原因写入
			channelReason := req.notSupportReason["configuration_sales_channel_not_support"]
			convey.So(channelReason, convey.ShouldNotBeNil)
			convey.So(channelReason["not_support_configuration_sales_channel"], convey.ShouldEqual, multienv.ConfigUnEffectiveSalesChannel)
			chList, ok := channelReason["configuration_sales_channel"].([]string)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(len(chList), convey.ShouldEqual, 1)
			convey.So(chList[0], convey.ShouldEqual, multienv.ConfigUnEffectiveSalesChannel)
		})
	})

	t.Run("配置状态/售卖状态/渠道均支持时不写入原因", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置状态、售卖状态、渠道均为支持场景
			cfg := &commercialization_api.Configuration{
				Status:       multienv.TradeConfigStatusOn,
				SalesStatus:  int8(multienv.SalesStatusOfficialSale),
				SalesChannel: "其他渠道",
			}
			req := &GetNotSupportSelectionReasonReq{
				configuration:    cfg,
				notSupportReason: make(map[string]map[string]interface{}),
			}
			ctx := context.Background()

			// 调用方法
			err := req.validateOriginConfiguration(ctx, nil)

			// 断言错误为空，原因集合应为空
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(req.notSupportReason), convey.ShouldEqual, 0)

			// 进一步确认不存在任何不支持原因键
			convey.So(req.notSupportReason["configuration_status_not_support"], convey.ShouldBeNil)
			convey.So(req.notSupportReason["configuration_sales_status_not_support"], convey.ShouldBeNil)
			convey.So(req.notSupportReason["configuration_sales_channel_not_support"], convey.ShouldBeNil)
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_isOfflineStandard_BitsUTGen(t *testing.T) {
	t.Run("私有部署标准商品返回真", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.PatchConvey("当商品满足条件时返回真", func() {
				req := &GetNotSupportSelectionReasonReq{
					product: &trade_client.ProductInfo{
						ProductType:     int(multienv.TradeProductDeploymentTypePrivate),
						StandardProduct: multienv.TradeProductStandardYes,
					},
				}
				result := req.isOfflineStandard()
				convey.So(result, convey.ShouldBeTrue)
			})
		})
	})
	t.Run("非私有部署或非标准返回假", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.PatchConvey("当商品不满足任一条件时返回假", func() {
				req := &GetNotSupportSelectionReasonReq{
					product: &trade_client.ProductInfo{
						ProductType:     2,
						StandardProduct: multienv.TradeProductStandardYes,
					},
				}
				result := req.isOfflineStandard()
				convey.So(result, convey.ShouldBeFalse)
			})
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_isPublicStandard_BitsUTGen(t *testing.T) {
	t.Run("返回true当产品是公有云标准品时", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备一个符合公有云标准品条件的请求
			req := &GetNotSupportSelectionReasonReq{
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePublic),
					StandardProduct: multienv.TradeProductStandardYes,
				},
			}

			// 执行并断言
			result := req.isPublicStandard()
			convey.So(result, convey.ShouldBeTrue)
		})
	})

	t.Run("返回false当产品类型不是公有云时", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备一个产品类型不符合条件的请求
			req := &GetNotSupportSelectionReasonReq{
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePublic) + 1, // 非公有云类型
					StandardProduct: multienv.TradeProductStandardYes,
				},
			}

			// 执行并断言
			result := req.isPublicStandard()
			convey.So(result, convey.ShouldBeFalse)
		})
	})

	t.Run("返回false当产品不是标准品时", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备一个非标准品的请求
			req := &GetNotSupportSelectionReasonReq{
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePublic),
					StandardProduct: multienv.TradeProductStandardYes - 1, // 非标准品
				},
			}

			// 执行并断言
			result := req.isPublicStandard()
			convey.So(result, convey.ShouldBeFalse)
		})
	})

	t.Run("返回false当产品既不是公有云也不是标准品时", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备一个两个条件都不符合的请求
			req := &GetNotSupportSelectionReasonReq{
				product: &trade_client.ProductInfo{
					ProductType:     int(multienv.TradeProductDeploymentTypePublic) + 1, // 非公有云类型
					StandardProduct: multienv.TradeProductStandardYes - 1,               // 非标准品
				},
			}

			// 执行并断言
			result := req.isPublicStandard()
			convey.So(result, convey.ShouldBeFalse)
		})
	})
}

func Test_GetNotSupportSelectionReasonReq_isPublicQuote_BitsUTGen(t *testing.T) {
	t.Run("报价单且不是项目制时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &GetNotSupportSelectionReasonReq{
				quote: &model.Quote{
					QuoteScene: multienv.SceneNew,
					QuoteType:  multienv.QuoteTypeNormal,
				},
			}

			convey.So(req.isPublicQuote(), convey.ShouldBeTrue)
		})
	})

	t.Run("项目制报价单返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &GetNotSupportSelectionReasonReq{
				quote: &model.Quote{
					QuoteScene: multienv.SceneNew,
					QuoteType:  multienv.QuoteTypeProjectBased,
				},
			}

			convey.So(req.isPublicQuote(), convey.ShouldBeFalse)
		})
	})

	t.Run("配置清单场景返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &GetNotSupportSelectionReasonReq{
				quote: &model.Quote{
					QuoteScene: multienv.SceneConfigurationList,
					QuoteType:  multienv.QuoteTypeNormal,
				},
			}

			convey.So(req.isPublicQuote(), convey.ShouldBeFalse)
		})
	})
}

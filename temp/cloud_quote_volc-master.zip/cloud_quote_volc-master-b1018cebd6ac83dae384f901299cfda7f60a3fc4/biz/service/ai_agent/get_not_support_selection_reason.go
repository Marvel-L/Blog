package ai_agent

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/constraint_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_effective"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/gopkg/logs"
)

type GetNotSupportSelectionReasonReq struct {
	QuoteID           int64  `json:"QuoteID,required"`     // 报价单id
	ProductCode       string `json:"ProductCode,required"` // 商品code
	ConfigurationCode string `json:"ConfigurationCode"`    // 配置code
	ChargeItemCode    string `json:"ChargeItemCode"`       // 计费项code
	SellingModeCode   string `json:"SellingModeCode"`      // 售卖模式code
	IsSolution        bool   `json:"IsSolution"`           // 是否解决方案
	IsDeliveryItem    bool   `json:"IsDeliveryItem"`       // 是否交付项

	quote         *model.Quote
	product       *trade_client.ProductInfo
	selectionRule *trade_client.SelectionRuleData
	configuration *commercialization_api.Configuration
	chargeItem    *commercialization_api.ChargeItemModel
	configNodes   []*product_config_parser.ConfigNode

	notSupportReason map[string]map[string]interface{} // 不支持选品原因
}

type GetNotSupportSelectionReasonResp struct {
	NotSupportReason map[string]map[string]interface{} // 不支持选品原因
}

func (r *GetNotSupportSelectionReasonReq) Handle(ctx context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(ctx)

	if err := r.initValidateInfo(ctx, tx); err != nil {
		return nil, err
	}

	r.notSupportReason = map[string]map[string]interface{}{}

	if err := r.validateOriginProduct(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.validateOriginConfiguration(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.validateOriginChargeItem(ctx, tx); err != nil {
		return nil, err
	}
	if err := r.validateCacheConfigNodes(ctx, tx); err != nil {
		return nil, err
	}

	return &GetNotSupportSelectionReasonResp{
		NotSupportReason: r.notSupportReason,
	}, nil
}

func (r *GetNotSupportSelectionReasonReq) initValidateInfo(ctx context.Context, tx *gorm.DB) error {
	if r.QuoteID <= 0 {
		return errors.New("报价单id不能为空")
	}
	if r.ProductCode == "" {
		return errors.New("商品code不能为空")
	}

	// 报价单信息
	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		if !quoteerrors.IsRecordNotFound(err) {
			logs.CtxError(ctx, "[GetNotSupportSelectionReason]报价单查询失败, QuoteID: %d, err: %v", r.QuoteID, err)
		}
		return fmt.Errorf("报价单不存在, 报价单id: %d", r.QuoteID)
	}
	r.quote = quote

	// 商品信息
	listProductReq := &commodity_service.ListTradeProductInfoReq{
		TradeProductList: []string{r.ProductCode},
	}
	productInfoList, err := listProductReq.ListTradeProductFromCache()
	if err != nil {
		logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]商品查询失败, ProductCode: %s, err: %v", r.ProductCode, err)
		return fmt.Errorf("商品查询失败, 商品code: %s", r.ProductCode)
	}
	if len(productInfoList) == 0 {
		return fmt.Errorf("商品不存在, 商品code: %s", r.ProductCode)
	}
	r.product = productInfoList[0]

	// 商品选品规则信息
	selectionRule, err := commodity_service.GetProductSelectRule(r.ProductCode)
	if err != nil {
		logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]选品规则查询失败, ProductCode: %s, err: %v", r.ProductCode, err)
		return fmt.Errorf("选品规则查询失败, 商品code: %s", r.ProductCode)
	}
	r.selectionRule = selectionRule

	if r.isPublicStandard() {
		if r.ChargeItemCode != "" && r.ConfigurationCode == "" {
			return errors.New("配置code不能为空")
		}
	} else {
		if r.ConfigurationCode != "" {
			return errors.New("非公有云商品不支持配置code")
		}
	}

	if r.ConfigurationCode != "" {
		// 配置信息（公有云）
		listConfigurationReq := &commercialization_api.ListConfigurationReq{
			Product:           r.ProductCode,
			ConfigurationCode: r.ConfigurationCode,
			WithAbilityAttrs:  1,
		}
		configurationList, err := trade_client.ListConfiguration(ctx, listConfigurationReq)
		if err != nil {
			logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]配置计费项查询失败, listConfigurationReq: %s, err: %v", util.GetJsonStr(listConfigurationReq), err)
			return fmt.Errorf("配置计费项查询失败, 商品code: %s, 配置code: %s", r.ProductCode, r.ConfigurationCode)
		}
		if configurationList == nil || len(configurationList.List) == 0 {
			return fmt.Errorf("配置计费项不存在, 商品code: %s, 配置code: %s", r.ProductCode, r.ConfigurationCode)
		}
		r.configuration = configurationList.List[0]
	}

	if r.ChargeItemCode == "" {
		return nil
	}

	// 计费项信息
	listChargeItemReq := &commercialization_api.ListChargeItemReq{
		Product:        r.ProductCode,
		ChargeItemCode: r.ChargeItemCode,
	}
	chargeItemList, err := trade_client.ListOriginChargeItem(ctx, listChargeItemReq)
	if err != nil {
		logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]计费项查询失败, listChargeItemReq: %s, err: %v", util.GetJsonStr(listChargeItemReq), err)
		return fmt.Errorf("计费项查询失败, 商品code: %s, 计费项code: %s", r.ProductCode, r.ChargeItemCode)
	}
	if len(chargeItemList) == 0 {
		return fmt.Errorf("计费项不存在, 商品code: %s, 计费项code: %s", r.ProductCode, r.ChargeItemCode)
	}
	r.chargeItem = chargeItemList[0]

	// 报价配置节点信息
	container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(r.product.ProductType), r.product.StandardProduct)
	if err != nil {
		logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]获取商品配置处理器失败, productType: %d, standardProduct: %d, err: %v", r.product.ProductType, r.product.StandardProduct, err)
		return fmt.Errorf("商品类型不支持报价, 商品code: %s", r.ProductCode)
	}
	chargeItemKey := fmt.Sprintf("%s::%s::%s", r.ProductCode, r.ConfigurationCode, r.ChargeItemCode)
	r.configNodes = container.GetConfigNodeListWithoutFilter(ctx, chargeItemKey)

	return nil
}

func (r *GetNotSupportSelectionReasonReq) validateOriginProduct(ctx context.Context, tx *gorm.DB) error {

	if _, ok := multienv.TradeProductSalesStatusCheckMapping[r.product.SalesStatus]; !ok {
		r.notSupportReason["product_sales_status_not_support"] = map[string]interface{}{
			"support_product_sales_status": util.MapKeysToSlice(multienv.TradeProductSalesStatusCheckMapping),
			"product_sales_status":         r.product.SalesStatus,
		}
	}

	salesChannels := strings.Split(r.product.SalesChannel, multienv.SalesChannelSeparator)
	if util.SliceAllInMap(salesChannels, multienv.ProductUnEffectiveSalesChannelMapping) {
		r.notSupportReason["product_sales_channel_not_support"] = map[string]interface{}{
			"not_support_product_sales_channel": util.MapKeysToSlice(multienv.ProductUnEffectiveSalesChannelMapping),
			"product_sales_channel":             salesChannels,
		}
	}

	quoteCustomerScope := r.quote.TradeType.GetCustomerScope()
	productCustomerScope := r.product.CatalogueCodeMap[multienv.CustomerScopeKey]
	if !product_config_parser.CustomerScopeMatch(quoteCustomerScope, productCustomerScope) {
		r.notSupportReason["product_customer_scope_not_support"] = map[string]interface{}{
			"quote_trade_type":       r.quote.TradeTypeCode,
			"quote_customer_scope":   quoteCustomerScope,
			"product_customer_scope": productCustomerScope,
		}
	}

	if !r.IsSolution && r.product.SingleSale == multienv.CanNotSingleSale {
		r.notSupportReason["product_single_sale_not_support_in_non_solution"] = map[string]interface{}{}
	}

	if !r.IsDeliveryItem && strings.Contains(r.product.ProductTag, multienv.ProductTagOfflineBOMGeneralProduct) {
		r.notSupportReason["product_offline_bom_general_not_support_in_quote_item"] = map[string]interface{}{}
	}

	standardProduct := r.product.CatalogueCodeMap[multienv.StandardProductKey]
	if r.isPublicQuote() && standardProduct != multienv.StandardProductYes {
		r.notSupportReason["product_non_standard_not_support_in_public_quote"] = map[string]interface{}{
			"quote_type":  r.quote.QuoteType,
			"quote_scene": r.quote.QuoteScene,
		}
	}

	// 仅老版审批中修改把商品限制在报价单已有二级产品线内（前端置灰不可选新产品线）；
	// 新版允许新增产品线（非三锁定字段），不做此限制。
	if r.quote.IsInModifyProcess() && !r.quote.IsNewModifyProcessData() && !r.IsDeliveryItem {
		quoteCallbackInfo, err := assistant.CallbackWithQuote(ctx, tx, r.quote,
			assistant.WithCallbackInfoKeys([]assistant.CallbackKey{assistant.CallbackKeyBizLine}),
		)
		if err != nil {
			logs.CtxWarn(ctx, "[GetNotSupportSelectionReason]报价单涉及二级产品线查询失败, QuoteID: %d, err: %v", r.QuoteID, err)
			return fmt.Errorf("报价单涉及二级产品线查询失败, 报价单id: %d", r.QuoteID)
		}
		if !util.StrIn(r.product.BizLineName, quoteCallbackInfo.BizLineNameList) {
			r.notSupportReason["product_biz_line_not_support_in_modify_process"] = map[string]interface{}{
				"quote_all_biz_line": quoteCallbackInfo.BizLineNameList,
				"product_biz_line":   r.product.BizLineName,
			}
		}
	}

	if r.selectionRule != nil && r.selectionRule.Display != 1 {
		r.notSupportReason["product_selection_rule_not_display"] = map[string]interface{}{}
	}

	productStatus := r.product.Status
	productMatchReq := &constraint_service.MatchConstraintProductReq{
		AccountIDList:    r.quote.GetConstraintAccountIDs(),
		CustomerID:       r.quote.ContractPriceAcc,
		ProductModelList: []*commercialization_api.ProductConstraintModel{{Product: r.product.Product, Status: int8(productStatus)}},
	}
	constraintProductStatusMap := productMatchReq.Match(ctx)
	constraintProductStatus, productStatusHasConstraint := constraintProductStatusMap[r.product.Product]
	if productStatusHasConstraint {
		productStatus = constraintProductStatus
	}
	if productStatus != multienv.TradeProductStatusOn {
		reasonDetail := map[string]interface{}{
			"support_product_status":        multienv.TradeProductStatusOn,
			"product_status":                r.product.Status,
			"product_status_has_constraint": productStatusHasConstraint,
		}
		if productStatusHasConstraint {
			reasonDetail["product_status_constraint_after"] = constraintProductStatus
		}
		r.notSupportReason["product_status_not_support"] = reasonDetail
	}

	if r.product.SalesMode == multienv.SalesModeSavingsPlans && !r.quote.SupportSpProduct() {
		r.notSupportReason["quote_not_support_sp_product"] = map[string]interface{}{
			"is_byte_plus":     multienv.IsBytePlus(),
			"quote_type":       r.quote.QuoteType,
			"quote_scene":      r.quote.QuoteScene,
			"quote_trade_type": r.quote.TradeTypeCode,
		}
	}

	if r.product.SalesMode == multienv.SalesModePickupVoucher && !r.quote.SupportPickupVoucherProduct() {
		r.notSupportReason["quote_not_support_pickup_voucher_product"] = map[string]interface{}{
			"quote_trade_type": r.quote.TradeTypeCode,
		}
	}

	return nil
}

func (r *GetNotSupportSelectionReasonReq) validateOriginConfiguration(ctx context.Context, tx *gorm.DB) error {
	if r.configuration == nil {
		return nil
	}

	if r.configuration.Status != multienv.TradeConfigStatusOn && r.configuration.Status != multienv.TradeConfigStatusToOff {
		r.notSupportReason["configuration_status_not_support"] = map[string]interface{}{
			"support_configuration_status": []int8{multienv.TradeConfigStatusOn, multienv.TradeConfigStatusToOff},
			"configuration_status":         r.configuration.Status,
		}
	}

	if _, ok := multienv.TradeProductSalesStatusCheckMapping[int(r.configuration.SalesStatus)]; !ok {
		r.notSupportReason["configuration_sales_status_not_support"] = map[string]interface{}{
			"support_configuration_sales_status": util.MapKeysToSlice(multienv.TradeProductSalesStatusCheckMapping),
			"configuration_sales_status":         r.configuration.SalesStatus,
		}
	}

	salesChannels := strings.Split(r.configuration.SalesChannel, multienv.SalesChannelSeparator)
	if len(salesChannels) == 1 && salesChannels[0] == multienv.ConfigUnEffectiveSalesChannel {
		r.notSupportReason["configuration_sales_channel_not_support"] = map[string]interface{}{
			"not_support_configuration_sales_channel": multienv.ConfigUnEffectiveSalesChannel,
			"configuration_sales_channel":             salesChannels,
		}
	}

	return nil
}

func (r *GetNotSupportSelectionReasonReq) validateOriginChargeItem(ctx context.Context, tx *gorm.DB) error {
	if r.chargeItem == nil {
		return nil
	}

	if r.chargeItem.Status != multienv.ChargeItemStatusOn && r.chargeItem.Status != multienv.ChargeItemStatusToOff {
		r.notSupportReason["charge_item_status_not_support"] = map[string]interface{}{
			"support_charge_item_status": []int8{multienv.ChargeItemStatusOn, multienv.ChargeItemStatusToOff},
			"charge_item_status":         r.chargeItem.Status,
		}
	}

	return nil
}

func (r *GetNotSupportSelectionReasonReq) validateCacheConfigNodes(ctx context.Context, tx *gorm.DB) error {
	if len(r.configNodes) == 0 {
		return nil
	}

	r.validateWithConstraint(ctx, tx)

	quoteCustomerScope := r.quote.TradeType.GetCustomerScope()
	chargeItemCustomerScope := r.configNodes[len(r.configNodes)-1].CustomerScope
	if !product_config_parser.CustomerScopeMatch(quoteCustomerScope, chargeItemCustomerScope) {
		r.notSupportReason["charge_item_customer_scope_not_support"] = map[string]interface{}{
			"quote_trade_type":           r.quote.TradeTypeCode,
			"quote_customer_scope":       quoteCustomerScope,
			"charge_item_customer_scope": chargeItemCustomerScope,
		}
	}

	var (
		otherInfo        = r.configNodes[len(r.configNodes)-1].OtherInfo
		priceInfo        = product_config_load.TransOtherInfoToPriceInfo(otherInfo)
		priceInfoPointer = &priceInfo
		productPriceInfo = item_context.GetProductPriceInfo(priceInfoPointer)

		productType = constants.ProductType(r.product.ProductType)
	)

	if r.SellingModeCode != "" && r.configuration != nil {
		supportSellingMode := productPriceInfo.GetSupportSellingModeMap()
		if !supportSellingMode[r.SellingModeCode] {
			r.notSupportReason["charge_item_selling_mode_not_support"] = map[string]interface{}{
				"support_charge_item_selling_mode": util.MapKeysToSlice(supportSellingMode),
				"charge_item_selling_mode":         r.SellingModeCode,
			}
		}
	}

	if !r.IsDeliveryItem && r.isPublicQuote() && r.isPublicStandard() {
		sellingModeCode := r.SellingModeCode
		if sellingModeCode == "" {
			sellingModeCode = multienv.SellingModeCalculateCostInstance
		}
		discountLineMap := multienv.GetDiscountLineMap(r.quote.TradeType, false)
		if item_effective.ShortOfMultiDiscountLine(priceInfoPointer, discountLineMap, r.quote, productType, sellingModeCode) {
			r.notSupportReason["charge_item_discount_line_not_support"] = map[string]interface{}{
				"quote_trade_type":                   r.quote.TradeTypeCode,
				"charge_item_selling_mode":           sellingModeCode,
				"charge_item_support_quantity_price": r.quote.SupportQuantityPrice() && r.isPublicStandard() && productPriceInfo.IsFollowQuantityPrice(r.SellingModeCode),
				"charge_item_need_discount_line":     util.MapKeysToSlice(discountLineMap),
			}
		}
	}

	if !r.IsDeliveryItem && r.isOfflineStandard() {
		if priceInfoPointer.BuyNumUnit == "" {
			r.notSupportReason["charge_item_buy_num_unit_short"] = map[string]interface{}{}
		}
		if priceInfoPointer.BuyDurationUnit == "" {
			r.notSupportReason["charge_item_buy_duration_unit_short"] = map[string]interface{}{}
		}
	}

	if priceInfoPointer.ShortOfNonZeroChargeItem() && !item_context.AllowedZeroChargeItem(r.quote, productType) {
		r.notSupportReason["charge_item_standard_price_zero_not_support"] = map[string]interface{}{
			"is_byte_plus":     multienv.IsBytePlus(),
			"quote_type":       r.quote.QuoteType,
			"quote_scene":      r.quote.QuoteScene,
			"product_type":     productType,
			"standard_product": r.product.StandardProduct,
		}
	}

	return nil
}

func (r *GetNotSupportSelectionReasonReq) validateWithConstraint(ctx context.Context, tx *gorm.DB) {
	constraintData := r.configNodes[len(r.configNodes)-1].ConstraintField

	checkConfigIsPublic := r.quote.IsQuote() && r.selectionRule.ConfigPublicDisplay == multienv.ConfigPublicDisplayFalse
	if supportQuote, _ := constraintData.SupportQuote(checkConfigIsPublic); supportQuote {
		return
	}

	matchConstraintChargeItemReq := &constraint_service.MatchConstraintChargeItemReq{
		AccountIDList: r.quote.GetConstraintAccountIDs(),
		CustomerID:    r.quote.ContractPriceAcc,
		Product:       r.ProductCode,
		ConfigurationList: []*commercialization_api.ConfigConstraintModel{{
			ConfigurationCode: r.ConfigurationCode,
			Status:            int8(constraintData.ConfigStatus),
			IsPublic:          int8(constraintData.ConfigIsPublic),
			ChargeItemConstraintModelList: []*commercialization_api.ChargeItemConstraintModel{{
				ChargeItemCode: r.ChargeItemCode,
				Status:         int8(constraintData.ChargeItemStatus),
			}},
		}},
	}
	matchResult := matchConstraintChargeItemReq.Match(ctx, false)
	matchConstraintData := matchResult[constraintData.ChargeItemKey]
	matchSupportQuote, _ := matchConstraintData.SupportQuote(checkConfigIsPublic)
	if matchConstraintData != nil && matchSupportQuote {
		return
	}

	retConstraintData := constraintData
	if matchConstraintData != nil {
		retConstraintData = matchConstraintData
	}

	if retConstraintData.ConfigStatus != multienv.TradeConfigStatusOn {
		r.notSupportReason["configuration_status_not_support_with_constraint"] = map[string]interface{}{
			"support_configuration_status": multienv.TradeConfigStatusOn,
			"configuration_status":         constraintData.ConfigStatus,
		}
	}
	if retConstraintData.ChargeItemStatus != multienv.ChargeItemStatusOn {
		r.notSupportReason["charge_item_status_not_support_with_constraint"] = map[string]interface{}{
			"support_charge_item_status": multienv.ChargeItemStatusOn,
			"charge_item_status":         constraintData.ChargeItemStatus,
		}
	}
	if checkConfigIsPublic && retConstraintData.ConfigIsPublic != multienv.ConfigIsPublicTrue {
		r.notSupportReason["configuration_is_public_not_support_with_constraint"] = map[string]interface{}{
			"quote_scene":                          r.quote.QuoteScene,
			"selection_rule_config_public_display": r.selectionRule.ConfigPublicDisplay,
			"support_configuration_is_public":      multienv.ConfigIsPublicTrue,
			"configuration_is_public":              constraintData.ConfigIsPublic,
		}
	}
}

func (r *GetNotSupportSelectionReasonReq) isPublicQuote() bool {
	return r.quote.IsQuote() && !r.quote.IsProjectBased()
}

func (r *GetNotSupportSelectionReasonReq) isPublicStandard() bool {
	return r.product.ProductType == int(multienv.TradeProductDeploymentTypePublic) &&
		r.product.StandardProduct == multienv.TradeProductStandardYes
}

func (r *GetNotSupportSelectionReasonReq) isOfflineStandard() bool {
	return r.product.ProductType == int(multienv.TradeProductDeploymentTypePrivate) &&
		r.product.StandardProduct == multienv.TradeProductStandardYes
}

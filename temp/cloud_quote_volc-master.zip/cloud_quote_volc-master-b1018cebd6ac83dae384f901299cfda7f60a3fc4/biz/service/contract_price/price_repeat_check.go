package contract_price

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
)

type PriceCheckErr struct {
	ErrMsg    string
	SubTaskID int64
}

func AllQuoteItemsPriceRepeatCheck(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote, req *quote_client.CreateBizContractReq) ([]int64, []string, []*price_client.ContractDiscount, error) {

	// [开始日早于提单日] 不做合同价判重
	if quoteDB.IsBackdating() {
		logs.CtxInfo(ctx, "AllQuoteItemsPriceRepeatCheck, IsBackdating, Skip price repeat check")
		return nil, nil, nil, nil
	}

	if (quoteDB.CustomerDetail == "" && quoteDB.EffectiveType == constants.EffectiveTypeAccount) ||
		quoteDB.PriceValidPeriod != "" { //自签订之日起以及合同价按客户生效且无客户id不进行合同价判重
		return nil, nil, nil, nil
	}
	//req, err := quote_contract_service.GenContractCreateReq(ctx, tx, quoteDB, constants.ItemStatusAll, multienv.TradeProductTypeOnline, constants.ItemSceneQuoteItem)
	//if err != nil {
	//	logs.CtxError(ctx, "QuotePriceRepeatCheck gen contract create req  err ", err)
	//	return nil, nil, nil, errors.ErrInternalError.WithArgs(err.Error())
	//}

	contractNoList, err := GenContractNoList(ctx, tx, quoteDB)
	if err != nil {
		logs.CtxError(ctx, "QuotePriceRepeatCheck GenContractNoList  err :%s ", err.Error())
		return nil, nil, nil, errors.ErrInternalError.WithArgs(err.Error())
	}

	checkReqs, err := GenPriceCheckReq(ctx, req, contractNoList, quoteDB)
	if err != nil {
		logs.CtxError(ctx, "QuotePriceRepeatCheck GenPriceCheckReq  err  :%s", err.Error())
		return nil, nil, nil, errors.ErrInternalError.WithArgs(err.Error())
	}

	if len(checkReqs) == 0 {
		return nil, nil, nil, nil
	}
	results, err := price_client.BatchCheckContractDiscount(ctx, checkReqs)
	if err != nil {
		logs.CtxError(ctx, "QuotePriceRepeatCheck price_client.CheckContractDiscount  err  :%s", err.Error())
		return nil, nil, nil, errors.ErrInternalError.WithArgs(err.Error())
	}
	var itemIDs []int64
	var relatedContractNoSet = map[string]bool{}
	var relatedContractNos []string
	var contractDiscountList []*price_client.ContractDiscount

	for _, result := range results {
		if result == nil {
			continue
		}
		for _, contractDiscount := range result.DuplicatedContractDiscount {
			itemID, _ := strconv.ParseInt(contractDiscount.ExternalID, 10, 64)
			itemIDs = append(itemIDs, itemID)
			relatedContractNoSet[contractDiscount.ContractNo] = true
		}
		contractDiscountList = append(contractDiscountList, result.DuplicatedContractDiscount...)
	}

	for contractNo := range relatedContractNoSet {
		relatedContractNos = append(relatedContractNos, contractNo)
	}

	for _, contractDiscount := range contractDiscountList {
		if err = fillDiscountOfContractDiscount(contractDiscount); err != nil {
			return nil, nil, nil, errors.ErrInternalError.WithArgs(err)
		}
		for _, deductDiscount := range contractDiscount.DeductList {
			if err = fillDiscountOfContractDiscount(deductDiscount); err != nil {
				return nil, nil, nil, errors.ErrInternalError.WithArgs(err)
			}
			deductDiscount.BeginTime = contractDiscount.BeginTime
			deductDiscount.EndTime = contractDiscount.EndTime
			deductDiscount.ContractNo = contractDiscount.ContractNo
		}
		if contractDiscount.Extra != nil && contractDiscount.Extra.SavingPlan != nil {
			contractDiscount.SavingPlanDetail = price_client.SavingPlanDetail{
				PrePayRatio:           contractDiscount.Extra.SavingPlan.PrepayRatioDisplay,
				PrePayRatioCode:       contractDiscount.Extra.SavingPlan.PrepayRatio,
				SpBuyDuration:         contractDiscount.Extra.SavingPlan.BuyDurationDisplay,
				SpBuyDurationCode:     contractDiscount.Extra.SavingPlan.BuyDuration,
				CommitFeeInterval:     contractDiscount.Extra.SavingPlan.CommitFeeIntervalDisplay,
				CommitFeeIntervalCode: contractDiscount.Extra.SavingPlan.CommitFeeInterval,
			}
		}
	}
	return itemIDs, relatedContractNos, contractDiscountList, nil

}

// AllChangeItemsPriceCheck 预校验所有的变价计费项合同价是否符合格式
func AllChangeItemsPriceCheck(ctx context.Context, quoteSubTasks []*model.QuoteSubTask, quoteTaskChargeItems []*model.QuoteTaskChargeItem) []*PriceCheckErr {
	var priceCheckErrList []*PriceCheckErr
	limit := config.GetCreatePriceNumLimit(ctx)
	if limit <= 0 {
		logs.CtxError(ctx, "TCC获取创建合同价数量限制失败")
		priceCheckErrList = append(priceCheckErrList, &PriceCheckErr{
			ErrMsg:    "TCC获取创建合同价数量限制失败",
			SubTaskID: 0,
		})
		return priceCheckErrList
	}
	splitChargeItems := splitQuoteTaskChargeItems(quoteTaskChargeItems, limit)
	for _, quoteSubTask := range quoteSubTasks {
		for _, chargeItems := range splitChargeItems {
			checkReq, err := GenChangePriceCheckReq(ctx, quoteSubTask, chargeItems)
			if err != nil {
				logs.CtxError(ctx, "AllChangeItemsPriceRepeatCheck GenChangePriceCheckReq  err ", err)
				priceCheckErrList = append(priceCheckErrList, &PriceCheckErr{
					ErrMsg:    err.Error(),
					SubTaskID: quoteSubTask.Id,
				})
				continue
			}
			checkResp, err := price_client.CreateContractDiscountForQuote(ctx, checkReq)
			if err != nil {
				logs.CtxError(ctx, "AllChangeItemsPriceRepeatCheck price_client.CreateContractDiscountForQuote  err ", err)
				priceCheckErrList = append(priceCheckErrList, &PriceCheckErr{
					ErrMsg:    err.Error(),
					SubTaskID: quoteSubTask.Id,
				})
				continue
			}
			if checkResp.Result.Msg != "" {
				priceCheckErrList = append(priceCheckErrList, &PriceCheckErr{
					ErrMsg:    checkResp.Result.Msg,
					SubTaskID: quoteSubTask.Id,
				})
			}
		}
	}
	return priceCheckErrList
}

// GenChangePriceCheckReq 生成短信变价合同价校验请求
func GenChangePriceCheckReq(ctx context.Context, quoteSubTask *model.QuoteSubTask, quoteTaskChargeItems []*model.QuoteTaskChargeItem) (*price_client.CreateContractDiscountForQuoteReq, error) {
	var (
		startTime string
		endTime   string
	)
	if quoteSubTask.PriceValidPeriodStartTime.IsZero() {
		startTime = util.FormatDateTimeWithZone(time.Now())
	} else {
		startTime = util.FormatDateTimeWithZone(quoteSubTask.PriceValidPeriodStartTime)
	}
	endTime = util.FormatDateTimeWithZone(quoteSubTask.PriceValidPeriodEndTime)
	effectiveValue := quoteSubTask.CustomerAccountID
	var quoteDiscounts []*price_client.QuoteDiscount
	for _, value := range quoteTaskChargeItems {
		discount := price_client.Discount{}
		err := json.Unmarshal([]byte(value.Discount), &discount)
		if err != nil {
			return nil, err
		}
		var payType string
		payTypeIn, ok := multienv.ContractPriceCanPrePayMapping[value.PrePayTypeCode]
		if ok {
			payType = payTypeIn
		}

		quoteDiscount := &price_client.QuoteDiscount{
			Product:            value.TradeProduct,
			Configuration:      value.ConfigCode,
			ChargeItemCode:     value.ChargeItemCode,
			PriceVersion:       value.PriceVersion,
			BeginTime:          startTime,
			EndTime:            endTime,
			BizBillingFunction: discount.PricingFunction,
			UnitPrice:          fmt.Sprintf("%g", discount.UnitPrice),
			UnitPriceInterval:  discount.UnitPriceInterval,
			MeasureInterval:    discount.MeasureInterval,

			ConfigurationCategory: value.ConfigCategory,
			BillingMethodCode:     value.ChargeMethodCode,
			BillingName:           value.ChargeMethodName,
			RegionCode:            value.RegionCode,
			ChargeElementCode:     value.ChargeUnitCode,
			PriceFactor:           value.PriceFactorCode,
			PayType:               payType,
			ExternalID:            strconv.FormatInt(value.Id, 10),
			SellingMode:           value.SellingMode,
			DeploymentType:        1,                           // 变价默认都是公有云
			ProductCatalogue:      multienv.StandardProductYes, // 默认标品
			ReferenceID:           strconv.FormatInt(value.Id, 10),
			IsProject:             "0", // 默认不是项目制
			ChargeItemTag:         value.ChargeItemTag,
			GuaranteedPercentage:  "",
		}
		quoteDiscounts = append(quoteDiscounts, quoteDiscount)
	}
	checkContractReq := &price_client.CreateContractDiscountForQuoteReq{
		ContractNo:     quoteSubTask.ContractCode,
		DiscountList:   quoteDiscounts,
		QuoteScene:     int(multienv.SceneNew),
		QuoteNo:        strconv.FormatInt(quoteSubTask.Id, 10),
		BeginTime:      startTime,
		EndTime:        endTime,
		EffectiveType:  constants.EffectiveTypeAccount, // 默认按照账号生效
		EffectiveValue: effectiveValue,
		SubjectNo:      multienv.GetSubjectNo(),
		Operator:       quoteSubTask.CreatorAccountID, // 默认操作人是创建人
		RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "短信变价报价单校验", true), quoteSubTask.Id),
		PriceSource:    constants.PriceSourceCustomerPriceModify,
		DryRun:         true,
		IdemKey:        fmt.Sprintf("%s-%d-%s", "QuoteTask", quoteSubTask.Id, effectiveValue),
	}
	return checkContractReq, nil
}

// splitQuoteTaskChargeItems 拆分报价任务计费项
func splitQuoteTaskChargeItems(quoteTaskChargeItems []*model.QuoteTaskChargeItem, batchSize int) [][]*model.QuoteTaskChargeItem {
	// 计算需要多少组
	totalLen := len(quoteTaskChargeItems)
	batchCount := (totalLen + batchSize - 1) / batchSize

	// 创建二维切片
	batchItems := make([][]*model.QuoteTaskChargeItem, 0, batchCount)

	// 按批次分组
	for i := 0; i < totalLen; i += batchSize {
		end := i + batchSize
		if end > totalLen {
			end = totalLen
		}
		batchItems = append(batchItems, quoteTaskChargeItems[i:end])
	}

	return batchItems
}

func fillDiscountOfContractDiscount(contractDiscount *price_client.ContractDiscount) error {
	var unitPrice float64
	var err error
	if contractDiscount.UnitPrice != "" {
		unitPrice, err = strconv.ParseFloat(contractDiscount.UnitPrice, 64)
		if err != nil {
			return err
		}
	}

	discount := &config_option_service.DiscountV2{
		PricingFunction:   contractDiscount.BillingFunction,
		UnitPriceInterval: contractDiscount.UnitPriceInterval,
		MeasureInterval:   contractDiscount.MeasureInterval,
		UnitPrice:         unitPrice,
	}

	//合同价存储的时间满折数据可能存在格式问题，兼容一下
	if contractDiscount.BillingFunction == constants.DiscountFunctionTimeDiscount {
		fixTimeDiscount(contractDiscount.BillingMethodCode, discount)
	}

	discountStr, err := json.Marshal(discount)
	if err != nil {
		return err
	}
	contractDiscount.Discount = string(discountStr)
	contractDiscount.CreatedTime = util.FormatDateTimeStrWithoutZone(contractDiscount.CreatedTime) //兼容合同价返回时间字符串，带时区和不带时区
	contractDiscount.UpdatedTime = contractDiscount.UpdatedTime.In(time.Local)
	return nil
}

func fixTimeDiscount(billingMethodCode string, discount *config_option_service.DiscountV2) {
	unitPriceMap := map[string]string{}
	measureMap := map[string]string{}
	if err := json.Unmarshal([]byte(discount.UnitPriceInterval), &unitPriceMap); err != nil {
		unitPriceMap[billingMethodCode] = discount.UnitPriceInterval
		discount.UnitPriceInterval = util.GetJsonStr(unitPriceMap)
	}
	if err := json.Unmarshal([]byte(discount.MeasureInterval), &measureMap); err != nil {
		measureMap[billingMethodCode] = discount.MeasureInterval
		discount.MeasureInterval = util.GetJsonStr(measureMap)
	}
}

func GenContractNoList(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote) ([]string, error) {
	var contractNoList []string
	if !quoteDB.IsSupplyAgreement() {
		return contractNoList, nil
	}
	// 补充协议验重时，仅需额外判断原报价单
	supplyQuotes, err := dal.QuoteDao.FindRelatedQuoteByMainID(tx, quoteDB.MainQuoteID)
	if err != nil {
		return nil, err
	}
	if len(supplyQuotes) == 0 {
		return contractNoList, nil
	}

	var supplyQuoteIDs []int64
	for _, supplyQuote := range supplyQuotes {
		supplyQuoteIDs = append(supplyQuoteIDs, supplyQuote.Id)
	}
	//if parentQuote == nil {
	//	// 理论上 补充协议必定有ParentQuoteID
	//	argosnotifylogs.CtxError(ctx, "[GenContractNoList]补充协议查询原报价单失败, quoteID=%s, parentQuoteID=%d", quoteDB.Id, quoteDB.ParentQuoteID)
	//	return nil, errors.ErrCustomerError.WithArgs("原报价单不存在")
	//}

	var quoteContracts []*model.QuoteContract
	err = dal.QuoteContractDao.SelectByCondition(tx, dal.Condition{
		"quote_id": supplyQuoteIDs,
	}, &model.QuoteContract{}, &quoteContracts)
	if err != nil {
		return nil, err
	}
	for _, quoteContract := range quoteContracts {
		if quoteContract.ContractCode != "" {
			contractNoList = append(contractNoList, quoteContract.ContractCode)
		}
	}
	return contractNoList, nil
}

func GenPriceCheckReq(ctx context.Context, req *quote_client.CreateBizContractReq, contractNoList []string, quoteDB *model.Quote) ([]*price_client.CheckContractReq, error) {
	quoteBizInfo := transferBizInfo(req.BizInfo)
	startTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodStartTime)
	endTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodEndTime)
	quoteDiscounts, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)
	if err != nil {
		logs.CtxError(ctx, "GenPriceCheckReq GenQuoteDiscountList err：%s ", err.Error())
		return nil, err
	}

	if len(quoteDiscounts) == 0 {
		return nil, nil
	}

	effectiveType := quoteDB.EffectiveType
	var checkContractReqs []*price_client.CheckContractReq
	if quoteDB.EffectiveType == constants.EffectiveTypeSubject {
		checkContractReqs = []*price_client.CheckContractReq{
			{
				EffectiveType:      effectiveType,
				EffectiveValue:     quoteDB.VerifiedName,
				DiscountList:       quoteDiscounts,
				SkipContractNoList: contractNoList,
			},
		}
	} else if quoteDB.IsDistributionBizTypeCustom() {

		distributorInfos := &model.DistributorInfo{}
		_ = json.Unmarshal([]byte(quoteDB.DistributorInfos), distributorInfos)

		checkContractReqs = []*price_client.CheckContractReq{
			{
				EffectiveType:      effectiveType,
				EffectiveValue:     distributorInfos.FirstDistributor.AccountID,
				OwnerID:            distributorInfos.FinalCustomer.AccountID,
				DiscountList:       quoteDiscounts,
				SkipContractNoList: contractNoList,
			},
		}
	} else {
		effectiveValues := strings.Split(quoteDB.CustomerDetail, ",")
		for _, effectiveValue := range effectiveValues {
			checkContractReqs = append(checkContractReqs, &price_client.CheckContractReq{
				EffectiveType:      effectiveType,
				EffectiveValue:     effectiveValue,
				DiscountList:       quoteDiscounts,
				SkipContractNoList: contractNoList,
			})
		}
	}

	return checkContractReqs, nil

}

func transferBizInfo(bizInfo map[string]interface{}) *price_client.QuoteBizInfo {

	quoteItems := bizInfo["QuoteItems"]
	deductQuoteItems := bizInfo["DeductQuoteItems"]
	items := quoteItems.([]map[string]string)
	deductItems := deductQuoteItems.([]map[string]string)
	items = append(items, deductItems...)

	projectBased := bizInfo["ProjectBased"]
	quoteProjectBased := strconv.Itoa(projectBased.(int))

	var priceItems []*price_client.QuoteItem
	for _, quoteItem := range items {
		priceItem := price_client.QuoteItem{
			Config:                    quoteItem["config"],
			ConfigCode:                quoteItem["configCode"],
			ChargeItemCode:            quoteItem["chargeItemCode"],
			PricingVersion:            quoteItem["PricingVersion"],
			PriceType:                 quoteItem["priceType"],
			Discount:                  quoteItem["discount"],
			ChildProductName:          quoteItem["ChildProductName"],
			ChildProductCode:          quoteItem["ChildProductCode"],
			Quantity:                  quoteItem["quantity"],
			StandardProductCode:       quoteItem["standardProductCode"],
			Product:                   quoteItem["Product"],
			ProductName:               quoteItem["ProductName"],
			QuoteItemID:               quoteItem["QuoteItemID"],
			ItemBusinessRole:          quoteItem["ItemBusinessRole"],
			RelatedItemID:             quoteItem["RelatedItemID"],
			ConfigCategory:            quoteItem["configCategory"],
			ConfigCategoryCode:        quoteItem["configCategoryCode"],
			ChargeMethod:              quoteItem["chargeMethod"],
			ChargeMethodCode:          quoteItem["chargeMethodCode"],
			Region:                    quoteItem["region"],
			RegionCode:                quoteItem["regionCode"],
			ChargeUnit:                quoteItem["chargeUnit"],
			ChargeUnitCode:            quoteItem["chargeUnitCode"],
			PriceFactor:               quoteItem["priceFactor"],
			PriceFactorCode:           quoteItem["priceFactorCode"],
			CanPrePay:                 quoteItem["canPrePay"],
			CanPrePayCode:             quoteItem["canPrePayCode"],
			ItemType:                  quoteItem["ItemType"],
			SellingMode:               quoteItem["sellingMode"],
			TradeSolution:             quoteItem["TradeSolution"],
			TradeSolutionVersion:      quoteItem["TradeSolutionVersion"],
			IsProject:                 quoteProjectBased,
			StandardProduct:           quoteItem["StandardProduct"],
			ChargeItemTag:             quoteItem["chargeItemTag"],
			GuaranteedPercentage:      quoteItem["guaranteedPercentage"],
			ChargeUnitCodeExclude:     quoteItem["chargeUnitCodeExclude"],
			ChargeUnitNameExclude:     quoteItem["chargeUnitNameExclude"],
			ConfigCodeExclude:         quoteItem["configCodeExclude"],
			ConfigNameExclude:         quoteItem["configNameExclude"],
			RegionCodeExclude:         quoteItem["regionCodeExclude"],
			RegionNameExclude:         quoteItem["regionNameExclude"],
			ChargeItemTagCodeExclude:  quoteItem["chargeItemTagCodeExclude"],
			ChargeItemTagNameExclude:  quoteItem["chargeItemTagNameExclude"],
			ConfigCategoryCodeExclude: quoteItem["configCategoryCodeExclude"],
			ConfigCategoryNameExclude: quoteItem["configCategoryNameExclude"],
			PrePayRatioCode:           quoteItem["prePayRatioCode"],
			SpBuyDurationCode:         quoteItem["spBuyDurationCode"],
			CommitFeeIntervalCode:     quoteItem["commitFeeIntervalCode"],
			PrePayRatio:               quoteItem["prePayRatio"],
			SpBuyDuration:             quoteItem["spBuyDuration"],
			CommitFeeInterval:         quoteItem["commitFeeInterval"],
			SalesMode:                 quoteItem["SalesMode"],
		}
		if priceItem.SellingMode == "" {
			priceItem.SellingMode = multienv.SellingModeCalculateCostInstance
		}
		priceItems = append(priceItems, &priceItem)
	}

	quoteBizInfo := &price_client.QuoteBizInfo{
		QuoteItems: priceItems,
	}

	return quoteBizInfo

}

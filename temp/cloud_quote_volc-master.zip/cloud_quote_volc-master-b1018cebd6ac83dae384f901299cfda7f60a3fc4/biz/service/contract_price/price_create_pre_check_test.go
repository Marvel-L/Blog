package contract_price

import (
	"context"
	"fmt"
	"strconv"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
)

func TestPriceCreatePreCheck(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{&price_client.CreateContractDiscountForQuoteReq{}}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, fmt.Errorf("your error")).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{&price_client.CreateContractDiscountForQuoteReq{}}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, fmt.Errorf("your error")).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{&price_client.CreateContractDiscountForQuoteReq{}}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, fmt.Errorf("your error")).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "123",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, fmt.Errorf("your error")).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "123",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{&price_client.CreateContractDiscountForQuoteReq{}}, nil).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, fmt.Errorf("your error")).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "123",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #6", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GenPriceCreateCheckReqs).Return([]*price_client.CreateContractDiscountForQuoteReq{&price_client.CreateContractDiscountForQuoteReq{}}, nil).Build()
			mockey.Mock(price_client.BatchCreateContractDiscount).Return([]*price_client.Result{&price_client.Result{}}, nil).Build()

			// Act
			err := PriceCreatePreCheck(context.Background(), &model.Quote{
				CustomerDetail: "123",
				EffectiveType:  0,
			}, &quote_client.CreateBizContractReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_GenPriceCreateCheckReqs_BitsUTGen(t *testing.T) {
	// 构造有效折扣JSON
	validDiscount := `{"PricingFunction":"F","UnitPriceInterval":"U","MeasureInterval":"M","UnitPrice":9.9}`

	type testCase struct {
		name   string
		setup  func()
		req    *quote_client.CreateBizContractReq
		quote  *model.Quote
		assert func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error)
	}

	tests := []testCase{
		{
			name: "折扣生成失败返回错误",
			setup: func() {
				mockey.Mock(multienv.I18nFormat).Return("报价单").Build()
				mockey.Mock(multienv.GetSubjectNo).Return("SUBNO").Build()
			},
			req: &quote_client.CreateBizContractReq{
				Identifier: "ERR001",
				BizInfo: map[string]interface{}{
					"QuoteItems":       []map[string]string{{"discount": ""}}, // 空字符串解析失败
					"DeductQuoteItems": []map[string]string{},
					"ProjectBased":     0,
				},
			},
			quote: &model.Quote{
				EffectiveType:             0,
				PriceValidPeriodStartTime: time.Time{},
				PriceValidPeriodEndTime:   time.Time{},
				DistributionBizTypeCode:   0,
				CustomerDetail:            "",
				VerifiedName:              "",
				SalesAccountID:            "SA",
				DistributorInfos:          "",
			},
			assert: func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error) {
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "InternalError")
				convey.So(reqs, convey.ShouldBeNil)
			},
		},
		{
			name: "仅抵扣项导致空折扣列表返回空",
			setup: func() {
				mockey.Mock(multienv.I18nFormat).Return("报价单").Build()
				mockey.Mock(multienv.GetSubjectNo).Return("SUBNO").Build()
			},
			req: &quote_client.CreateBizContractReq{
				Identifier: "EMPTY001",
				BizInfo: map[string]interface{}{
					"QuoteItems": []map[string]string{},
					"DeductQuoteItems": []map[string]string{
						{
							"discount":         validDiscount,
							"ItemBusinessRole": strconv.Itoa(constants.QuoteItemBusinessRoleDeduct),
							"QuoteItemID":      "ded1",
							"RelatedItemID":    "parentX",
						},
					},
					"ProjectBased": 0,
				},
			},
			quote: &model.Quote{
				EffectiveType:             0,
				PriceValidPeriodStartTime: time.Time{},
				PriceValidPeriodEndTime:   time.Time{},
				DistributionBizTypeCode:   0,
				CustomerDetail:            "",
				SalesAccountID:            "SA",
			},
			assert: func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(reqs, convey.ShouldBeNil)
			},
		},
		{
			name: "签约主体生效生成单条请求",
			setup: func() {
				mockey.Mock(multienv.I18nFormat).Return("报价单").Build()
				mockey.Mock(multienv.GetSubjectNo).Return("SUBNO").Build()
			},
			req: &quote_client.CreateBizContractReq{
				Identifier: "SUBJ001",
				BizInfo: map[string]interface{}{
					"QuoteItems": []map[string]string{
						{
							"discount":         validDiscount,
							"ItemBusinessRole": "0",
							"QuoteItemID":      "n1",
						},
					},
					"DeductQuoteItems": []map[string]string{},
					"ProjectBased":     0,
				},
			},
			quote: &model.Quote{
				EffectiveType:             constants.EffectiveTypeSubject,
				VerifiedName:              "主体A",
				SalesAccountID:            "SA",
				PriceValidPeriodStartTime: time.Now(),
				PriceValidPeriodEndTime:   time.Now().Add(2 * time.Hour),
				DistributionBizTypeCode:   0,
				CustomerDetail:            "",
			},
			assert: func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(reqs, convey.ShouldNotBeNil)
				convey.So(len(reqs), convey.ShouldEqual, 1)
				convey.So(reqs[0].EffectiveType, convey.ShouldEqual, constants.EffectiveTypeSubject)
				convey.So(reqs[0].EffectiveValue, convey.ShouldEqual, "主体A")
				convey.So(reqs[0].BeginTime, convey.ShouldNotEqual, "")
				convey.So(reqs[0].EndTime, convey.ShouldNotEqual, "")
				convey.So(reqs[0].PriceSource, convey.ShouldEqual, int8(constants.PriceSourceQuoteContract))
				convey.So(reqs[0].DryRun, convey.ShouldBeTrue)
				convey.So(reqs[0].QuoteScene, convey.ShouldEqual, int(multienv.SceneNew))
			},
		},
		{
			name: "分销类型自定义生成单条请求",
			setup: func() {
				mockey.Mock(multienv.I18nFormat).Return("报价单").Build()
				mockey.Mock(multienv.GetSubjectNo).Return("SUBNO").Build()
			},
			req: &quote_client.CreateBizContractReq{
				Identifier: "DIST001",
				BizInfo: map[string]interface{}{
					"QuoteItems": []map[string]string{
						{
							"discount":         validDiscount,
							"ItemBusinessRole": "0",
							"QuoteItemID":      "n2",
						},
					},
					"DeductQuoteItems": []map[string]string{},
					"ProjectBased":     0,
				},
			},
			quote: &model.Quote{
				EffectiveType:             0,
				SalesAccountID:            "SA",
				PriceValidPeriodStartTime: time.Time{}, // 触发时间回填
				PriceValidPeriodEndTime:   time.Time{},
				DistributionBizTypeCode:   multienv.DistributionBizTypeCodeCustom,
				DistributorInfos:          `{"FirstDistributor":{"CustomerType":"FirstDistributor","AccountID":"acc1","OwnerID":"owner1","CustomerName":"name"},"SecondDistributor":null,"FinalCustomer":null}`,
			},
			assert: func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(reqs, convey.ShouldNotBeNil)
				convey.So(len(reqs), convey.ShouldEqual, 1)
				convey.So(reqs[0].EffectiveValue, convey.ShouldEqual, "acc1")
				convey.So(reqs[0].BeginTime, convey.ShouldNotEqual, "")
				convey.So(reqs[0].EndTime, convey.ShouldNotEqual, "")
				convey.So(reqs[0].PriceSource, convey.ShouldEqual, int8(constants.PriceSourceQuoteContract))
				convey.So(reqs[0].DryRun, convey.ShouldBeTrue)
			},
		},
		{
			name: "客户ID列表生成多条请求带幂等键",
			setup: func() {
				mockey.Mock(multienv.I18nFormat).Return("报价单").Build()
				mockey.Mock(multienv.GetSubjectNo).Return("SUBNO").Build()
			},
			req: &quote_client.CreateBizContractReq{
				Identifier: "CUST001",
				BizInfo: map[string]interface{}{
					"QuoteItems": []map[string]string{
						{
							"discount":         validDiscount,
							"ItemBusinessRole": "0",
							"QuoteItemID":      "n3",
						},
					},
					"DeductQuoteItems": []map[string]string{},
					"ProjectBased":     0,
				},
			},
			quote: &model.Quote{
				CustomerDetail:            "c1,c2",
				EffectiveType:             0,
				SalesAccountID:            "SA",
				PriceValidPeriodStartTime: time.Now(),
				PriceValidPeriodEndTime:   time.Now().Add(3 * time.Hour),
				DistributionBizTypeCode:   0,
			},
			assert: func(reqs []*price_client.CreateContractDiscountForQuoteReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(reqs, convey.ShouldNotBeNil)
				convey.So(len(reqs), convey.ShouldEqual, 2)
				convey.So(reqs[0].EffectiveValue, convey.ShouldEqual, "c1")
				convey.So(reqs[1].EffectiveValue, convey.ShouldEqual, "c2")
				convey.So(reqs[0].IdemKey, convey.ShouldContainSubstring, "Quote-0-c1")
				convey.So(reqs[1].IdemKey, convey.ShouldContainSubstring, "Quote-0-c2")
				convey.So(reqs[0].PriceSource, convey.ShouldEqual, int8(constants.PriceSourceQuoteContract))
				convey.So(reqs[1].PriceSource, convey.ShouldEqual, int8(constants.PriceSourceQuoteContract))
			},
		},
	}

	for _, tc := range tests {
		mockey.PatchConvey(tc.name, t, func() {
			if tc.setup != nil {
				tc.setup()
			}
			gotReqs, err := GenPriceCreateCheckReqs(context.Background(), tc.req, tc.quote)
			tc.assert(gotReqs, err)
		})
	}
}

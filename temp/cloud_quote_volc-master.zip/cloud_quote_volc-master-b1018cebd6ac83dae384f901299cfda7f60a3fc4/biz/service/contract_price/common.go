package contract_price

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"context"
	"strconv"
)

func GenQuoteDiscountList(ctx context.Context, startTime, endTime string, quoteBizInfo *price_client.QuoteBizInfo) ([]*price_client.QuoteDiscount, error) {
	discountMap := make(map[string]*price_client.QuoteDiscount)
	deductDiscountMap := make(map[string]*price_client.QuoteDiscount)
	for _, value := range quoteBizInfo.QuoteItems {
		discount := value.GenQuoteDiscount(startTime, endTime)
		if discount == nil {
			logs.CtxError(ctx, "GenPriceCreateCheckReqs, Json解析失败。value:%v", value)
			return nil, errors.ErrInternalError.WithArgs("GenPriceCreateCheckReqs, Json解析失败。")
		}
		if value.ItemBusinessRole == strconv.Itoa(constants.QuoteItemBusinessRoleDeduct) {
			deductDiscountMap[value.QuoteItemID] = discount
		} else {
			discountMap[value.QuoteItemID] = discount
		}
	}
	// 抵扣报价项，挂到对应父discount的DeductList下
	for _, value := range quoteBizInfo.QuoteItems {
		// 只处理抵扣项
		if value.ItemBusinessRole != strconv.Itoa(constants.QuoteItemBusinessRoleDeduct) {
			continue
		}
		// 找到对应的父discount
		if parentDiscount, ok := discountMap[value.RelatedItemID]; ok {
			parentDiscount.DeductList = append(parentDiscount.DeductList, deductDiscountMap[value.QuoteItemID])
		}
	}

	return util.MapValuesToSlice(discountMap), nil
}

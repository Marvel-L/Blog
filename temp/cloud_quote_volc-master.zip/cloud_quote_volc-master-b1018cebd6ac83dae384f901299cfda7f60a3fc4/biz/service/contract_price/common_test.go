package contract_price

import (
	"context"
	"encoding/json"
	"strconv"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

//go:noinline
func newDiscountJSON(pricingFunction string, unitPrice float64) string {
	raw, err := json.Marshal(price_client.Discount{
		PricingFunction:   pricingFunction,
		UnitPriceInterval: "hour",
		MeasureInterval:   "month",
		UnitPrice:         unitPrice,
	})
	if err != nil {
		panic(err)
	}
	return string(raw)
}

//go:noinline
func newQuoteItem(id, role, relatedID, discountJSON string) *price_client.QuoteItem {
	return &price_client.QuoteItem{
		Product:               "product-" + id,
		ChildProductCode:      "child-" + id,
		ConfigCode:            "config-" + id,
		ChargeItemCode:        "charge-" + id,
		PricingVersion:        "v1",
		Discount:              discountJSON,
		QuoteItemID:           id,
		ItemBusinessRole:      role,
		RelatedItemID:         relatedID,
		ConfigCategoryCode:    "category-" + id,
		ChargeMethodCode:      "billing-code-" + id,
		ChargeMethod:          "计费方式-" + id,
		RegionCode:            "region-" + id,
		ChargeUnitCode:        "unit-" + id,
		PriceFactorCode:       "factor-" + id,
		CanPrePayCode:         "1",
		ItemType:              "0",
		SellingMode:           "normal",
		TradeSolution:         "solution-" + id,
		TradeSolutionVersion:  "solution-version-" + id,
		IsProject:             "0",
		StandardProduct:       "1",
		ChargeItemTag:         "tag-" + id,
		GuaranteedPercentage:  "10",
		ChargeUnitCodeExclude: "exclude-unit-" + id,
		ConfigCodeExclude:     "exclude-config-" + id,
		RegionCodeExclude:     "exclude-region-" + id,
	}
}

//go:noinline
func findDiscountByExternalID(discounts []*price_client.QuoteDiscount, externalID string) *price_client.QuoteDiscount {
	for _, discount := range discounts {
		if discount != nil && discount.ExternalID == externalID {
			return discount
		}
	}
	return nil
}

func Test_GenQuoteDiscountList_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	startTime := "2024-01-01 00:00:00"
	endTime := "2024-12-31 23:59:59"

	mockey.PatchConvey("测试GenQuoteDiscountList", t, func() {
		mockey.PatchConvey("折扣字段无法解析时返回内部错误", func() {
			quoteBizInfo := &price_client.QuoteBizInfo{
				QuoteItems: []*price_client.QuoteItem{
					newQuoteItem("invalid-item", "0", "", "{invalid-json"),
				},
			}

			got, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)

			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "GenPriceCreateCheckReqs, Json解析失败")
		})

		mockey.PatchConvey("普通项与抵扣项混合时正确组装抵扣列表", func() {
			parentItem := newQuoteItem("parent-1", "0", "", newDiscountJSON("pf-parent", 12.5))
			childItem := newQuoteItem("child-1", strconv.Itoa(constants.QuoteItemBusinessRoleDeduct), "parent-1", newDiscountJSON("pf-child", 3.5))
			orphanDeductItem := newQuoteItem("child-orphan", strconv.Itoa(constants.QuoteItemBusinessRoleDeduct), "missing-parent", newDiscountJSON("pf-orphan", 1.2))
			anotherParentItem := newQuoteItem("parent-2", "0", "", newDiscountJSON("pf-parent-2", 8))

			quoteBizInfo := &price_client.QuoteBizInfo{
				QuoteItems: []*price_client.QuoteItem{parentItem, childItem, orphanDeductItem, anotherParentItem},
			}

			got, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(got), convey.ShouldEqual, 2)

			parentDiscount := findDiscountByExternalID(got, "parent-1")
			convey.So(parentDiscount, convey.ShouldNotBeNil)
			if parentDiscount != nil {
				convey.So(parentDiscount.BeginTime, convey.ShouldEqual, startTime)
				convey.So(parentDiscount.EndTime, convey.ShouldEqual, endTime)
				convey.So(parentDiscount.BizBillingFunction, convey.ShouldEqual, "pf-parent")
				convey.So(parentDiscount.UnitPrice, convey.ShouldEqual, "12.5")
				convey.So(len(parentDiscount.DeductList), convey.ShouldEqual, 1)
				if len(parentDiscount.DeductList) == 1 && parentDiscount.DeductList[0] != nil {
					convey.So(parentDiscount.DeductList[0].ExternalID, convey.ShouldEqual, "child-1")
					convey.So(parentDiscount.DeductList[0].BizBillingFunction, convey.ShouldEqual, "pf-child")
					convey.So(parentDiscount.DeductList[0].UnitPrice, convey.ShouldEqual, "3.5")
				}
			}

			anotherParentDiscount := findDiscountByExternalID(got, "parent-2")
			convey.So(anotherParentDiscount, convey.ShouldNotBeNil)
			if anotherParentDiscount != nil {
				convey.So(len(anotherParentDiscount.DeductList), convey.ShouldEqual, 0)
			}

			convey.So(findDiscountByExternalID(got, "child-1"), convey.ShouldBeNil)
			convey.So(findDiscountByExternalID(got, "child-orphan"), convey.ShouldBeNil)
		})

		mockey.PatchConvey("空报价项返回空列表", func() {
			quoteBizInfo := &price_client.QuoteBizInfo{}

			got, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(len(got), convey.ShouldEqual, 0)
		})
	})
}

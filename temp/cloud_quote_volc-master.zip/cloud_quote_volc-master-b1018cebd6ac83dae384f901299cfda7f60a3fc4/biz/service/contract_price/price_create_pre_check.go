package contract_price

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
)

func PriceCreatePreCheck(ctx context.Context, quoteDB *model.Quote, req *quote_client.CreateBizContractReq) error {
	if quoteDB.CustomerDetail == "" && quoteDB.EffectiveType == constants.EffectiveTypeAccount {
		return nil
	}
	checkReqs, err := GenPriceCreateCheckReqs(ctx, req, quoteDB)
	if err != nil {
		logs.CtxError(ctx, "PriceCreatePreCheck GenPriceCreateCheckReqs  err ：%s ", err.Error())
		return err
	}
	if len(checkReqs) == 0 {
		return nil
	}
	_, err = price_client.BatchCreateContractDiscount(ctx, checkReqs)
	if err != nil {
		logs.CtxError(ctx, "PriceCreatePreCheck price_client.BatchCreateContractDiscount err：%s ", err.Error())
		return err
	}
	return nil
}

func GenPriceCreateCheckReqs(ctx context.Context, req *quote_client.CreateBizContractReq, quoteDB *model.Quote) ([]*price_client.CreateContractDiscountForQuoteReq, error) {
	quoteBizInfo := transferBizInfo(req.BizInfo)
	startTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodStartTime)
	endTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodEndTime)
	if startTime == "" && endTime == "" { // 预估合同有效期自签订之日起的，mock 一个开始时间和结束时间
		startTime = util.FormatDateTimeWithZone(util.ToBeginningOfDay(time.Now().Add(24 * time.Hour)))
		endTime = util.FormatDateTimeWithZone(util.ToEndOfDay(time.Now().Add(24 * time.Hour)))
	}
	quoteDiscounts, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)
	if err != nil {
		logs.CtxError(ctx, "PriceCreatePreCheck GenQuoteDiscountList err：%s ", err.Error())
		return nil, err
	}
	if len(quoteDiscounts) == 0 {
		return nil, nil
	}
	var createContractReqs []*price_client.CreateContractDiscountForQuoteReq
	if quoteDB.EffectiveType == constants.EffectiveTypeSubject {
		createContractReqs = append(createContractReqs, &price_client.CreateContractDiscountForQuoteReq{
			DiscountList:   quoteDiscounts,
			QuoteScene:     int(multienv.SceneNew),
			QuoteNo:        req.Identifier,
			BeginTime:      startTime,
			EndTime:        endTime,
			EffectiveType:  quoteDB.EffectiveType,
			EffectiveValue: quoteDB.VerifiedName,
			SubjectNo:      multienv.GetSubjectNo(),
			Operator:       quoteDB.SalesAccountID,
			RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "报价单", true), quoteDB.Id),
			PriceSource:    constants.PriceSourceQuoteContract,
			DryRun:         true,
			IdemKey:        fmt.Sprintf("%s-%d-%s", "Quote", quoteDB.Id, quoteDB.VerifiedName),
		})
	} else if quoteDB.IsDistributionBizTypeCustom() {
		distributorInfos := &model.DistributorInfo{}
		_ = json.Unmarshal([]byte(quoteDB.DistributorInfos), distributorInfos)
		createContractReqs = append(createContractReqs, &price_client.CreateContractDiscountForQuoteReq{
			DiscountList:   quoteDiscounts, // BP分销场景，DiscountList中AccountID、OwnerID字段没有赋值，仅作为校验使用
			QuoteScene:     int(multienv.SceneNew),
			QuoteNo:        req.Identifier,
			BeginTime:      startTime,
			EndTime:        endTime,
			EffectiveType:  quoteDB.EffectiveType,
			EffectiveValue: distributorInfos.FirstDistributor.AccountID,
			SubjectNo:      multienv.GetSubjectNo(),
			Operator:       quoteDB.SalesAccountID,
			RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "报价单", true), quoteDB.Id),
			PriceSource:    constants.PriceSourceQuoteContract,
			DryRun:         true,
			IdemKey:        fmt.Sprintf("%s-%d-%s", "Quote", quoteDB.Id, distributorInfos.FirstDistributor.AccountID),
		})
	} else {
		effectiveValues := strings.Split(quoteDB.CustomerDetail, ",")
		for _, effectiveValue := range effectiveValues {
			createContractReqs = append(createContractReqs, &price_client.CreateContractDiscountForQuoteReq{
				DiscountList:   quoteDiscounts,
				QuoteScene:     int(multienv.SceneNew),
				QuoteNo:        req.Identifier,
				BeginTime:      startTime,
				EndTime:        endTime,
				EffectiveType:  quoteDB.EffectiveType,
				EffectiveValue: effectiveValue,
				SubjectNo:      multienv.GetSubjectNo(),
				Operator:       quoteDB.SalesAccountID,
				RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "报价单", true), quoteDB.Id),
				PriceSource:    constants.PriceSourceQuoteContract,
				DryRun:         true,
				IdemKey:        fmt.Sprintf("%s-%d-%s", "Quote", quoteDB.Id, effectiveValue),
			})
		}
	}
	return createContractReqs, nil
}

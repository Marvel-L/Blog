package contract_price

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_contract_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
)

func CreateContractPrice(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote) (string, error) {

	req, err := quote_contract_service.GenContractCreateReq(ctx, tx, quoteDB, constants.ItemStatusAll, multienv.TradeProductTypeOnline, constants.ItemSceneQuoteItem)
	if err != nil {
		logs.CtxError(ctx, "CreateContractPrice gen contract create req  err %s ", err.Error())
		return "", err
	}

	createReq, err := GenPriceCreateReq(ctx, req, quoteDB)
	if err != nil {
		logs.CtxError(ctx, "QuotePriceRepeatCheck GenPriceCheckReq  err %s", err.Error())
		return "", err
	}

	if len(createReq.DiscountList) == 0 {
		virtualContractNo, genErr := GenVirtualContractNo()
		if genErr != nil {
			return "", genErr
		}

		return virtualContractNo, nil
	}
	createResp, err := price_client.CreateContractDiscountForQuote(ctx, createReq)
	if err != nil {
		logs.CtxError(ctx, "CreateContractDiscountForQuote price_client.CreateContractDiscountForQuote  err %s", err.Error())
		return "", err
	}

	return createResp.Result.ContractNo, nil

}

func GenPriceCreateReq(ctx context.Context, req *quote_client.CreateBizContractReq, quoteDB *model.Quote) (*price_client.CreateContractDiscountForQuoteReq, error) {
	quoteBizInfo := transferBizInfo(req.BizInfo)
	startTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodStartTime)
	endTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodEndTime)

	// 报价直接创建合同价只有内部报价单，内部报价单不支持抵扣计费项，这里为了统一样式，兼容处理一下
	quoteDiscounts, err := GenQuoteDiscountList(ctx, startTime, endTime, quoteBizInfo)
	if err != nil {
		logs.CtxError(ctx, "CreateContractPrice GenQuoteDiscountList err：%s ", err.Error())
		return nil, err
	}
	effectiveType := quoteDB.EffectiveType
	effectiveValue := strconv.FormatInt(req.AccountID, 10)
	if quoteDB.EffectiveType == constants.EffectiveTypeSubject {
		effectiveValue = quoteDB.VerifiedName
	}

	checkContractReq := &price_client.CreateContractDiscountForQuoteReq{
		DiscountList:   quoteDiscounts,
		QuoteScene:     int(multienv.SceneNew),
		QuoteNo:        req.Identifier,
		BeginTime:      startTime,
		EndTime:        endTime,
		EffectiveType:  effectiveType,
		EffectiveValue: effectiveValue,
		SubjectNo:      multienv.GetSubjectNo(),
		Operator:       quoteDB.SalesAccountID,
		RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "内部客户报价", true), quoteDB.Id),
		PriceSource:    constants.PriceSourceInnerQuote,
	}

	return checkContractReq, nil

}

func GenVirtualContractNo() (string, error) {
	ContractNo, err := redis_client.Incr(constants.VirtualContractNoRedisKey)
	if err != nil {
		return "", err
	}
	virtualContractNo := fmt.Sprintf("%s%010d", constants.VirtualContractNoPrefix, ContractNo)
	return virtualContractNo, nil
}

func CreateChangeContractPrice(ctx context.Context, tx *gorm.DB, contractPriceTask *model.ContractPriceTask, quoteDB *model.Quote) (string, error) {
	// 变价报价项id
	batchQuoteItemIDs := strings.Split(contractPriceTask.BatchQuoteItemID, ",")
	var changeDiscountItemIDs []int64
	for _, batchItemID := range batchQuoteItemIDs {
		num, err := strconv.ParseInt(batchItemID, 10, 64)
		if err != nil {
			return "", err
		}
		changeDiscountItemIDs = append(changeDiscountItemIDs, num)
	}
	changeDiscountItems, err := dal.ChangeDiscountQuoteItemDao.FindChangeDiscountQuoteItemByID(tx, changeDiscountItemIDs)
	if err != nil {
		return "", err
	}
	// 创建合同价请求
	createReq, err := GenChangePriceCreateReq(ctx, tx, quoteDB, changeDiscountItems)
	if err != nil {
		logs.CtxError(ctx, "CreateChangeContractPrice GenChangePriceCreateReq  err %s", err.Error())
		return "", err
	}
	createResp, err := price_client.CreateContractDiscountForQuote(ctx, createReq)
	if err != nil {
		logs.CtxError(ctx, "CreateChangeContractPrice price_client.CreateContractDiscountForQuote  err %s", err.Error())
		return "", err
	}

	return createResp.Result.ContractNo, nil
}

func GenChangePriceCreateReq(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote, changeDiscountItems []*model.ChangeDiscountQuoteItem) (*price_client.CreateContractDiscountForQuoteReq, error) {
	startTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodStartTime)
	endTime := util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodEndTime)
	effectiveType := quoteDB.EffectiveType
	effectiveValue := quoteDB.CustomerDetail
	// 查询合同号
	subTask, err := dal.QuoteSubTaskDao.FindSubTasksByID(tx, quoteDB.SubTaskID)
	if err != nil {
		return nil, err
	}
	var quoteDiscounts []*price_client.QuoteDiscount
	for _, value := range changeDiscountItems {
		discount := price_client.Discount{}
		err := json.Unmarshal([]byte(value.Discount), &discount)
		if err != nil {
			return nil, err
		}
		var payType string
		payTypeIn, ok := multienv.ContractPriceCanPrePayMapping[value.PrePayTypeCode]
		if ok {
			payType = payTypeIn
		}

		quoteDiscount := &price_client.QuoteDiscount{
			Product:            value.TradeProduct,
			Configuration:      value.ConfigCode,
			ChargeItemCode:     value.ChargeItemCode,
			PriceVersion:       value.PriceVersion,
			BeginTime:          startTime,
			EndTime:            endTime,
			BizBillingFunction: discount.PricingFunction,
			UnitPrice:          fmt.Sprintf("%g", discount.UnitPrice),
			UnitPriceInterval:  discount.UnitPriceInterval,
			MeasureInterval:    discount.MeasureInterval,

			ConfigurationCategory: value.ConfigCategory,
			BillingMethodCode:     value.ChargeMethodCode,
			BillingName:           value.ChargeMethodName,
			RegionCode:            value.RegionCode,
			ChargeElementCode:     value.ChargeUnitCode,
			PriceFactor:           value.PriceFactorCode,
			PayType:               payType,
			ExternalID:            strconv.FormatInt(value.Id, 10),
			SellingMode:           value.SellingMode,
			DeploymentType:        1,                           // 变价默认都是公有云
			ProductCatalogue:      multienv.StandardProductYes, // 默认标品
			ReferenceID:           strconv.FormatInt(value.Id, 10),
			IsProject:             "0", // 默认不是项目制
			ChargeItemTag:         value.ChargeItemTag,
			GuaranteedPercentage:  "",
		}
		quoteDiscounts = append(quoteDiscounts, quoteDiscount)
	}
	createContractReq := &price_client.CreateContractDiscountForQuoteReq{
		ContractNo:     subTask.ContractCode,
		DiscountList:   quoteDiscounts,
		QuoteScene:     int(multienv.SceneNew),
		QuoteNo:        strconv.FormatInt(quoteDB.Id, 10),
		BeginTime:      startTime,
		EndTime:        endTime,
		EffectiveType:  effectiveType,
		EffectiveValue: effectiveValue,
		SubjectNo:      multienv.GetSubjectNo(),
		Operator:       quoteDB.SalesAccountID,
		RuleName:       fmt.Sprintf("%s-%d", multienv.I18nFormat(ctx, "创建短信变价报价单合同价", true), quoteDB.Id),
		PriceSource:    constants.PriceSourceCustomerPriceModify,
		DryRun:         false,
	}
	return createContractReq, nil
}

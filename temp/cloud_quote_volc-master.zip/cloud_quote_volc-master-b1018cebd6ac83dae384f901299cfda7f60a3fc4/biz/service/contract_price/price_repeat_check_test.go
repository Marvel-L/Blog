package contract_price

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"context"
	"fmt"
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
	"encoding/json"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"strconv"
)

func TestAllChangeItemsPriceCheck(t *testing.T) {

	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetCreatePriceNumLimit).Return(10).Build()
			mockey.Mock(GenChangePriceCheckReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					Msg: "",
				},
			}, fmt.Errorf("your error")).Build()

			// Act
			got := AllChangeItemsPriceCheck(context.Background(), []*model.QuoteSubTask{&model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
			}}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}})

			// Assert
			convey.So(len(got), convey.ShouldEqual, 1)
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetCreatePriceNumLimit).Return(10).Build()
			mockey.Mock(GenChangePriceCheckReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					Msg: "",
				},
			}, fmt.Errorf("your error")).Build()

			// Act
			got := AllChangeItemsPriceCheck(context.Background(), []*model.QuoteSubTask{&model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
			}}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}})

			// Assert
			convey.So(len(got), convey.ShouldEqual, 1)
		})
	})

	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetCreatePriceNumLimit).Return(10).Build()
			mockey.Mock(GenChangePriceCheckReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					Msg: "111",
				},
			}, nil).Build()

			// Act
			got := AllChangeItemsPriceCheck(context.Background(), []*model.QuoteSubTask{&model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
			}}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}})

			// Assert
			convey.So(len(got), convey.ShouldEqual, 1)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetCreatePriceNumLimit).Return(10).Build()
			mockey.Mock(GenChangePriceCheckReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					Msg: "",
				},
			}, nil).Build()

			// Act
			got := AllChangeItemsPriceCheck(context.Background(), []*model.QuoteSubTask{&model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
			}}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}})

			// Assert
			convey.So(len(got), convey.ShouldEqual, 0)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetCreatePriceNumLimit).Return(0).Build()
			mockey.Mock(GenChangePriceCheckReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					Msg: "",
				},
			}, nil).Build()

			// Act
			got := AllChangeItemsPriceCheck(context.Background(), []*model.QuoteSubTask{&model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
			}}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}})

			// Assert
			convey.So(got[0].ErrMsg, convey.ShouldEqual, "TCC获取创建合同价数量限制失败")
		})
	})
}

func Test_splitQuoteTaskChargeItems(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			got := splitQuoteTaskChargeItems([]*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{}}, 1)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

func TestGenChangePriceCheckReq(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(multienv.GetSubjectNo).Return("").Build()
			mockey.Mock(multienv.I18nFormat).Return("").Build()

			// Act
			v, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			got, err := GenChangePriceCheckReq(context.Background(), &model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				CreatorAccountID:          "",
				CustomerAccountID:         "",
				ContractCode:              "",
				PriceValidPeriodStartTime: v,
				PriceValidPeriodEndTime:   v1,
			}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				TradeProduct:     "",
				PrePayTypeCode:   "0",
				ConfigCategory:   "",
				ConfigCode:       "",
				SellingMode:      "",
				ChargeItemTag:    "",
				ChargeMethodCode: "",
				ChargeMethodName: "",
				RegionCode:       "",
				ChargeUnitCode:   "",
				PriceFactorCode:  "",
				ChargeItemCode:   "",
				Discount:         "",
				PriceVersion:     "",
			}})

			// Assert
			convey.So(got, convey.ShouldResemble, (*price_client.CreateContractDiscountForQuoteReq)(nil))
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})

	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(multienv.GetSubjectNo).Return("").Build()
			mockey.Mock(multienv.I18nFormat).Return("").Build()

			// Act
			v, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			got, err := GenChangePriceCheckReq(context.Background(), &model.QuoteSubTask{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				CreatorAccountID:          "",
				CustomerAccountID:         "",
				ContractCode:              "",
				PriceValidPeriodStartTime: v,
				PriceValidPeriodEndTime:   v1,
			}, []*model.QuoteTaskChargeItem{&model.QuoteTaskChargeItem{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				TradeProduct:     "",
				PrePayTypeCode:   "0",
				ConfigCategory:   "",
				ConfigCode:       "",
				SellingMode:      "",
				ChargeItemTag:    "",
				ChargeMethodCode: "",
				ChargeMethodName: "",
				RegionCode:       "",
				ChargeUnitCode:   "",
				PriceFactorCode:  "",
				ChargeItemCode:   "",
				Discount:         "{\"PricingFunction\":\"Linear\",\"UnitPriceInterval\":\"Hour\",\"MeasureInterval\":\"Hour\",\"UnitPrice\":1.5}",
				PriceVersion:     "",
			}})

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
}

// TestGenChangePriceCheckReq tests the GenChangePriceCheckReq function.
func TestGenChangePriceCheckReq_BitsUTGen(t *testing.T) {
	// Common setup for test data
	ctx := context.Background()
	now := time.Now()
	validStartTime := now.Add(-24 * time.Hour)
	validEndTime := now.Add(24 * time.Hour)
	formattedValidStartTime := util.FormatDateTimeWithZone(validStartTime)
	formattedEndTime := util.FormatDateTimeWithZone(validEndTime)

	// t.Run for "Successful Scenario - StartTime is provided"
	t.Run("Successful Scenario - StartTime is provided", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - StartTime is provided", t, func() {
			// This case covers the `else` branch of the `IsZero()` check.
			quoteSubTask := &model.QuoteSubTask{
				BaseDB:                    framework.BaseDB{Id: 101},
				CustomerAccountID:         "customer-123",
				CreatorAccountID:          "operator-456",
				ContractCode:              "contract-789",
				PriceValidPeriodStartTime: validStartTime,
				PriceValidPeriodEndTime:   validEndTime,
			}
			discountJSON := `{"PricingFunction":"fixed_price","UnitPrice":1.23,"UnitPriceInterval":"Hour","MeasureInterval":"Hour"}`
			quoteTaskChargeItems := []*model.QuoteTaskChargeItem{
				{
					BaseDB:           framework.BaseDB{Id: 201},
					TradeProduct:     "test_product",
					ConfigCode:       "test_config",
					ChargeItemCode:   "test_item_code",
					PriceVersion:     "v1.0",
					Discount:         discountJSON,
					PrePayTypeCode:   "0", // Corresponds to "post" in ContractPriceCanPrePayMapping
					ConfigCategory:   "category_A",
					ChargeMethodCode: "method_B",
					ChargeMethodName: "Method B",
					RegionCode:       "cn-beijing",
					ChargeUnitCode:   "unit_C",
					PriceFactorCode:  "factor_D",
					SellingMode:      "mode_E",
					ChargeItemTag:    "tag_F",
				},
			}

			mockey.Mock(multienv.GetSubjectNo).Return("1065").Build()
			mockey.Mock(multienv.I18nFormat).Return("SMS Price Change Check").Build()

			req, err := GenChangePriceCheckReq(ctx, quoteSubTask, quoteTaskChargeItems)

			convey.So(err, convey.ShouldBeNil)
			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.ContractNo, convey.ShouldEqual, quoteSubTask.ContractCode)
			convey.So(req.QuoteNo, convey.ShouldEqual, strconv.FormatInt(quoteSubTask.Id, 10))
			convey.So(req.BeginTime, convey.ShouldEqual, formattedValidStartTime)
			convey.So(req.EndTime, convey.ShouldEqual, formattedEndTime)
			convey.So(req.EffectiveValue, convey.ShouldEqual, quoteSubTask.CustomerAccountID)
			convey.So(req.Operator, convey.ShouldEqual, quoteSubTask.CreatorAccountID)
			convey.So(req.RuleName, convey.ShouldEqual, fmt.Sprintf("SMS Price Change Check-%d", quoteSubTask.Id))
			convey.So(len(req.DiscountList), convey.ShouldEqual, 1)

			discountItem := req.DiscountList[0]
			convey.So(discountItem.BeginTime, convey.ShouldEqual, formattedValidStartTime)
			convey.So(discountItem.EndTime, convey.ShouldEqual, formattedEndTime)
			convey.So(discountItem.UnitPrice, convey.ShouldEqual, "1.23")
			convey.So(discountItem.PayType, convey.ShouldEqual, "post")
		})
	})

	// t.Run for "Successful Scenario - StartTime is zero"
	t.Run("Successful Scenario - StartTime is zero", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - StartTime is zero", t, func() {
			// This case covers the `if` branch of the `IsZero()` check, which is the core change.
			quoteSubTask := &model.QuoteSubTask{
				BaseDB:                    framework.BaseDB{Id: 102},
				CustomerAccountID:         "customer-456",
				CreatorAccountID:          "operator-789",
				ContractCode:              "contract-123",
				PriceValidPeriodStartTime: time.Time{}, // Zero time
				PriceValidPeriodEndTime:   validEndTime,
			}
			discountJSON := `{"PricingFunction":"linear","UnitPrice":99.9}`
			quoteTaskChargeItems := []*model.QuoteTaskChargeItem{
				{
					BaseDB:         framework.BaseDB{Id: 202},
					Discount:       discountJSON,
					PrePayTypeCode: "1", // Corresponds to "pre"
				},
			}

			mockey.Mock(multienv.GetSubjectNo).Return("3423").Build()
			mockey.Mock(multienv.I18nFormat).Return("SMS Price Change Check").Build()

			req, err := GenChangePriceCheckReq(ctx, quoteSubTask, quoteTaskChargeItems)

			convey.So(err, convey.ShouldBeNil)
			convey.So(req, convey.ShouldNotBeNil)
			// Since time.Now() is used, we cannot assert an exact value,
			// but we can verify it's a valid, non-empty, formatted timestamp.
			convey.So(req.BeginTime, convey.ShouldNotBeEmpty)
			convey.So(req.BeginTime, convey.ShouldContainSubstring, "T")
			convey.So(req.BeginTime, convey.ShouldContainSubstring, "+")
			convey.So(len(req.DiscountList), convey.ShouldEqual, 1)
			convey.So(req.DiscountList[0].BeginTime, convey.ShouldEqual, req.BeginTime)
			convey.So(req.DiscountList[0].PayType, convey.ShouldEqual, "pre")
		})
	})

	// t.Run for "Failure Scenario - Invalid Discount JSON"
	t.Run("Failure Scenario - Invalid Discount JSON", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid Discount JSON", t, func() {
			quoteSubTask := &model.QuoteSubTask{}
			quoteTaskChargeItems := []*model.QuoteTaskChargeItem{
				{
					Discount: `{"invalid_json`,
				},
			}

			req, err := GenChangePriceCheckReq(ctx, quoteSubTask, quoteTaskChargeItems)

			convey.So(req, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeError)
			convey.So(err.Error(), convey.ShouldContainSubstring, "unexpected end of JSON input")
		})
	})

	// t.Run for "Edge case - Empty Charge Items"
	t.Run("Edge case - Empty Charge Items", func(t *testing.T) {
		mockey.PatchConvey("Edge case - Empty Charge Items", t, func() {
			quoteSubTask := &model.QuoteSubTask{
				BaseDB:                    framework.BaseDB{Id: 103},
				PriceValidPeriodStartTime: validStartTime,
				PriceValidPeriodEndTime:   validEndTime,
			}
			var quoteTaskChargeItems []*model.QuoteTaskChargeItem

			mockey.Mock(multienv.GetSubjectNo).Return("1065").Build()
			mockey.Mock(multienv.I18nFormat).Return("SMS Price Change Check").Build()

			req, err := GenChangePriceCheckReq(ctx, quoteSubTask, quoteTaskChargeItems)

			convey.So(err, convey.ShouldBeNil)
			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.DiscountList, convey.ShouldBeEmpty)
			convey.So(req.BeginTime, convey.ShouldEqual, formattedValidStartTime)
		})
	})
}

//go:noinline
func newTestCreateBizContractReq(quoteItems, deductQuoteItems []map[string]string) *quote_client.CreateBizContractReq {
	return &quote_client.CreateBizContractReq{
		BizInfo: map[string]interface{}{
			"QuoteItems":       quoteItems,
			"DeductQuoteItems": deductQuoteItems,
			"ProjectBased":     0,
		},
	}
}

//go:noinline
func newTestValidQuoteItem(itemID string) map[string]string {
	return map[string]string{
		"config":           "cfg-name",
		"configCode":       "cfg-code",
		"chargeItemCode":   "charge-code",
		"PricingVersion":   "v1",
		"discount":         `{"PricingFunction":"step","UnitPriceInterval":"[0,1]","MeasureInterval":"month","UnitPrice":12.3}`,
		"ChildProductCode": "child-product-code",
		"Product":          "product-a",
		"QuoteItemID":      itemID,
		"ItemBusinessRole": "0",
		"sellingMode":      "",
	}
}

//go:noinline
func mustMarshalDistributorInfo(info *model.DistributorInfo) string {
	data, err := json.Marshal(info)
	if err != nil {
		panic(err)
	}
	return string(data)
}
func Test_GenPriceCheckReq_BitsUTGen(t *testing.T) {
	tests := []struct {
		name           string
		setup          func()
		req            *quote_client.CreateBizContractReq
		contractNoList []string
		quoteDB        *model.Quote
		check          func(got []*price_client.CheckContractReq, err error)
	}{
		{
			name: "生成折扣列表报错时返回错误",
			setup: func() {
				mockey.Mock(GenQuoteDiscountList).Return(([]*price_client.QuoteDiscount)(nil), errors.New("gen discount failed")).Build()
			},
			req:            newTestCreateBizContractReq([]map[string]string{newTestValidQuoteItem("item-error")}, []map[string]string{}),
			contractNoList: []string{"contract-1"},
			quoteDB: &model.Quote{
				EffectiveType: constants.EffectiveTypeSubject,
				VerifiedName:  "subject-a",
			},
			check: func(got []*price_client.CheckContractReq, err error) {
				convey.So(got, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "gen discount failed")
			},
		},
		{
			name:           "折扣列表为空时返回空结果",
			req:            newTestCreateBizContractReq([]map[string]string{}, []map[string]string{}),
			contractNoList: []string{"contract-2"},
			quoteDB: &model.Quote{
				EffectiveType: constants.EffectiveTypeSubject,
				VerifiedName:  "subject-b",
			},
			check: func(got []*price_client.CheckContractReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(got, convey.ShouldBeNil)
			},
		},
		{
			name:           "按主体生效时返回主体判重请求",
			req:            newTestCreateBizContractReq([]map[string]string{newTestValidQuoteItem("item-subject")}, []map[string]string{}),
			contractNoList: []string{"contract-3", "contract-4"},
			quoteDB: &model.Quote{
				EffectiveType: constants.EffectiveTypeSubject,
				VerifiedName:  "verified-subject",
			},
			check: func(got []*price_client.CheckContractReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(got, convey.ShouldNotBeNil)
				convey.So(len(got), convey.ShouldEqual, 1)
				convey.So(got[0].EffectiveType, convey.ShouldEqual, constants.EffectiveTypeSubject)
				convey.So(got[0].EffectiveValue, convey.ShouldEqual, "verified-subject")
				convey.So(got[0].OwnerID, convey.ShouldEqual, "")
				convey.So(got[0].SkipContractNoList, convey.ShouldResemble, []string{"contract-3", "contract-4"})
				convey.So(len(got[0].DiscountList), convey.ShouldEqual, 1)
				convey.So(got[0].DiscountList[0].ExternalID, convey.ShouldEqual, "item-subject")
				convey.So(got[0].DiscountList[0].SellingMode, convey.ShouldEqual, multienv.SellingModeCalculateCostInstance)
			},
		},
		{
			name:           "自定义分销业务返回分销商判重请求",
			req:            newTestCreateBizContractReq([]map[string]string{newTestValidQuoteItem("item-distribution")}, []map[string]string{}),
			contractNoList: []string{"contract-5"},
			quoteDB: &model.Quote{
				EffectiveType:           2,
				DistributionBizTypeCode: multienv.DistributionBizTypeCodeCustom,
				DistributorInfos: mustMarshalDistributorInfo(&model.DistributorInfo{
					FirstDistributor: &model.CustomerInfo{
						AccountID: "first-distributor-id",
					},
					FinalCustomer: &model.CustomerInfo{
						AccountID: "final-customer-id",
					},
				}),
			},
			check: func(got []*price_client.CheckContractReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(got, convey.ShouldNotBeNil)
				convey.So(len(got), convey.ShouldEqual, 1)
				convey.So(got[0].EffectiveType, convey.ShouldEqual, 2)
				convey.So(got[0].EffectiveValue, convey.ShouldEqual, "first-distributor-id")
				convey.So(got[0].OwnerID, convey.ShouldEqual, "final-customer-id")
				convey.So(got[0].SkipContractNoList, convey.ShouldResemble, []string{"contract-5"})
				convey.So(len(got[0].DiscountList), convey.ShouldEqual, 1)
				convey.So(got[0].DiscountList[0].ExternalID, convey.ShouldEqual, "item-distribution")
			},
		},
		{
			name:           "按客户生效时拆分多个客户判重请求",
			req:            newTestCreateBizContractReq([]map[string]string{newTestValidQuoteItem("item-customer")}, []map[string]string{}),
			contractNoList: []string{"contract-6"},
			quoteDB: &model.Quote{
				EffectiveType:  2,
				CustomerDetail: "customer-1,customer-2",
			},
			check: func(got []*price_client.CheckContractReq, err error) {
				convey.So(err, convey.ShouldBeNil)
				convey.So(got, convey.ShouldNotBeNil)
				convey.So(len(got), convey.ShouldEqual, 2)

				convey.So(got[0].EffectiveType, convey.ShouldEqual, 2)
				convey.So(got[0].EffectiveValue, convey.ShouldEqual, "customer-1")
				convey.So(got[0].OwnerID, convey.ShouldEqual, "")
				convey.So(got[0].SkipContractNoList, convey.ShouldResemble, []string{"contract-6"})
				convey.So(len(got[0].DiscountList), convey.ShouldEqual, 1)
				convey.So(got[0].DiscountList[0].ExternalID, convey.ShouldEqual, "item-customer")

				convey.So(got[1].EffectiveType, convey.ShouldEqual, 2)
				convey.So(got[1].EffectiveValue, convey.ShouldEqual, "customer-2")
				convey.So(got[1].OwnerID, convey.ShouldEqual, "")
				convey.So(got[1].SkipContractNoList, convey.ShouldResemble, []string{"contract-6"})
				convey.So(len(got[1].DiscountList), convey.ShouldEqual, 1)
				convey.So(got[1].DiscountList[0].ExternalID, convey.ShouldEqual, "item-customer")
			},
		},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				if tc.setup != nil {
					tc.setup()
				}
				got, err := GenPriceCheckReq(context.Background(), tc.req, tc.contractNoList, tc.quoteDB)
				tc.check(got, err)
			})
		})
	}
}

func Test_AllQuoteItemsPriceRepeatCheck_BitsUTGen(t *testing.T) {
	type testCase struct {
		name string
		run  func()
	}

	cases := []testCase{
		{
			name: "场景: 回溯报价单，直接跳过合同价判重",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{BackdatingReason: "retro-reason"}

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 客户生效但客户ID为空，跳过合同价判重",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "",
					EffectiveType:  constants.EffectiveTypeAccount,
				}

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 报价单价格有效期非空，跳过合同价判重",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail:   "cust",
					EffectiveType:    constants.EffectiveTypeSubject,
					PriceValidPeriod: "自签订之日起",
				}

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 生成合同号列表出错，返回内部错误",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return(nil, errors.New("mock contract list error")).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "mock contract list error")
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 生成价格判重请求出错，返回内部错误",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"CN1"}, nil).Build()
				mockey.Mock(GenPriceCheckReq).Return(nil, errors.New("mock check req error")).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "mock check req error")
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 判重请求为空，直接返回",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{}, nil).Build()
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{}, nil).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 批量价格接口报错，返回内部错误",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"CN1"}, nil).Build()
				checkReq := &price_client.CheckContractReq{}
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{checkReq}, nil).Build()
				mockey.Mock(price_client.BatchCheckContractDiscount).Return(nil, errors.New("mock batch error")).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "mock batch error")
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 填充主合同折扣失败，返回内部错误",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"CN1"}, nil).Build()
				checkReq := &price_client.CheckContractReq{}
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{checkReq}, nil).Build()
				dupDiscount := &price_client.ContractDiscount{
					ExternalID:        "789",
					ContractNo:        "CN_ERR",
					UnitPrice:         "1",
					CreatedTime:       "2024-01-01T00:00:00Z",
					UpdatedTime:       time.Now(),
					Extra:             &price_client.Extra{},
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}
				mockey.Mock(price_client.BatchCheckContractDiscount).Return([]*price_client.Result{
					{DuplicatedContractDiscount: []*price_client.ContractDiscount{dupDiscount}},
				}, nil).Build()
				mockey.Mock(fillDiscountOfContractDiscount).Return(errors.New("fill error")).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "fill error")
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 填充抵扣折扣失败，返回内部错误",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"CNX"}, nil).Build()
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{{}}, nil).Build()

				main := &price_client.ContractDiscount{
					ExternalID:        "100",
					ContractNo:        "C-DEDUCT",
					UnitPrice:         "2.5",
					CreatedTime:       "2024-02-02T00:00:00Z",
					UpdatedTime:       time.Now(),
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}
				deduct := &price_client.ContractDiscount{
					ExternalID:        "101",
					UnitPrice:         "3.5",
					CreatedTime:       "2024-02-02T00:00:00Z",
					UpdatedTime:       time.Now(),
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}
				main.DeductList = []*price_client.ContractDiscount{deduct}

				mockey.Mock(price_client.BatchCheckContractDiscount).Return([]*price_client.Result{
					{DuplicatedContractDiscount: []*price_client.ContractDiscount{main}},
				}, nil).Build()

				mockey.Mock(fillDiscountOfContractDiscount).Return(
					mockey.Sequence(nil).Then(errors.New("deduct fill error")),
				).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "deduct fill error")
				convey.So(itemIDs, convey.ShouldBeNil)
				convey.So(contractNos, convey.ShouldBeNil)
				convey.So(discounts, convey.ShouldBeNil)
			},
		},
		{
			name: "场景: 成功返回且包含节省计划，同时存在nil结果被跳过",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"CN_SKIP"}, nil).Build()
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{{}}, nil).Build()

				dupDiscount := &price_client.ContractDiscount{
					ExternalID:  "456",
					ContractNo:  "CN_SUCCESS",
					UnitPrice:   "1.50",
					CreatedTime: "2024-01-02T15:04:05Z",
					UpdatedTime: time.Now(),
					Extra: &price_client.Extra{
						SavingPlan: &price_client.SavingPlan{
							PrepayRatio:              "code_ratio",
							BuyDuration:              "code_duration",
							CommitFeeInterval:        "code_interval",
							PrepayRatioDisplay:       "display ratio",
							BuyDurationDisplay:       "display duration",
							CommitFeeIntervalDisplay: "display interval",
						},
					},
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}
				mockey.Mock(price_client.BatchCheckContractDiscount).Return([]*price_client.Result{
					nil,
					{DuplicatedContractDiscount: []*price_client.ContractDiscount{dupDiscount}},
				}, nil).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(len(itemIDs), convey.ShouldEqual, 1)
				convey.So(itemIDs[0], convey.ShouldEqual, int64(456))
				convey.So(len(contractNos), convey.ShouldEqual, 1)
				convey.So(contractNos[0], convey.ShouldEqual, dupDiscount.ContractNo)
				convey.So(len(discounts), convey.ShouldEqual, 1)
				convey.So(discounts[0], convey.ShouldEqual, dupDiscount)
				convey.So(discounts[0].SavingPlanDetail.PrePayRatio, convey.ShouldEqual, "display ratio")
				convey.So(discounts[0].SavingPlanDetail.PrePayRatioCode, convey.ShouldEqual, "code_ratio")
				convey.So(discounts[0].SavingPlanDetail.SpBuyDuration, convey.ShouldEqual, "display duration")
				convey.So(discounts[0].SavingPlanDetail.SpBuyDurationCode, convey.ShouldEqual, "code_duration")
				convey.So(discounts[0].SavingPlanDetail.CommitFeeInterval, convey.ShouldEqual, "display interval")
				convey.So(discounts[0].SavingPlanDetail.CommitFeeIntervalCode, convey.ShouldEqual, "code_interval")
			},
		},
		{
			name: "场景: 成功返回且无节省计划，抵扣项时间和合同号被补齐",
			run: func() {
				ctx := context.Background()
				quote := &model.Quote{
					CustomerDetail: "cust",
					EffectiveType:  constants.EffectiveTypeAccount,
				}
				mockey.Mock(GenContractNoList).Return([]string{"C1"}, nil).Build()
				mockey.Mock(GenPriceCheckReq).Return([]*price_client.CheckContractReq{{}}, nil).Build()

				main := &price_client.ContractDiscount{
					ExternalID:        "900",
					ContractNo:        "C123",
					UnitPrice:         "2.00",
					CreatedTime:       "2024-03-01T00:00:00Z",
					UpdatedTime:       time.Now(),
					UnitPriceInterval: "",
					MeasureInterval:   "",
					BeginTime:         100,
					EndTime:           200,
					Extra:             nil,
				}
				deduct := &price_client.ContractDiscount{
					ExternalID:        "901",
					UnitPrice:         "3.00",
					CreatedTime:       "2024-03-01T00:00:00Z",
					UpdatedTime:       time.Now(),
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}
				main.DeductList = []*price_client.ContractDiscount{deduct}

				another := &price_client.ContractDiscount{
					ExternalID:        "902",
					ContractNo:        "C456",
					UnitPrice:         "4.00",
					CreatedTime:       "2024-03-02T00:00:00Z",
					UpdatedTime:       time.Now(),
					UnitPriceInterval: "",
					MeasureInterval:   "",
				}

				mockey.Mock(price_client.BatchCheckContractDiscount).Return([]*price_client.Result{
					{DuplicatedContractDiscount: []*price_client.ContractDiscount{main, another}},
				}, nil).Build()

				itemIDs, contractNos, discounts, err := AllQuoteItemsPriceRepeatCheck(ctx, nil, quote, &quote_client.CreateBizContractReq{})

				convey.So(err, convey.ShouldBeNil)
				convey.So(len(itemIDs), convey.ShouldEqual, 2)
				convey.So(len(contractNos) >= 2, convey.ShouldBeTrue)
				convey.So(len(discounts), convey.ShouldEqual, 2)
				convey.So(main.DeductList[0].BeginTime, convey.ShouldEqual, main.BeginTime)
				convey.So(main.DeductList[0].EndTime, convey.ShouldEqual, main.EndTime)
				convey.So(main.DeductList[0].ContractNo, convey.ShouldEqual, main.ContractNo)
				convey.So(discounts[0].SavingPlanDetail.PrePayRatio, convey.ShouldEqual, "") // 无节省计划不填充
			},
		},
	}

	for _, tc := range cases {
		mockey.PatchConvey(tc.name, t, func() {
			tc.run()
		})
	}
}

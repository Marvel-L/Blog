package contract_price

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"fmt"
	"github.com/smartystreets/assertions/should"
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"strconv"
)

func TestCreateChangeContractPrice(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.ChangeDiscountQuoteItemDao, "FindChangeDiscountQuoteItemByID")).Return([]*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{}}, fmt.Errorf("your error")).Build()
			mockey.Mock(GenChangePriceCreateReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					ContractNo: "",
				},
			}, fmt.Errorf("your error")).Build()

			// Act
			got, err := CreateChangeContractPrice(context.Background(), &gorm.DB{}, &model.ContractPriceTask{
				BatchQuoteItemID: "123,456,789",
			}, &model.Quote{})

			// Assert
			convey.So(got, convey.ShouldEqual, "")
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.ChangeDiscountQuoteItemDao, "FindChangeDiscountQuoteItemByID")).Return([]*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{}}, nil).Build()
			mockey.Mock(GenChangePriceCreateReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, fmt.Errorf("your error")).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					ContractNo: "",
				},
			}, fmt.Errorf("your error")).Build()

			// Act
			got, err := CreateChangeContractPrice(context.Background(), &gorm.DB{}, &model.ContractPriceTask{
				BatchQuoteItemID: "123,456,789",
			}, &model.Quote{})

			// Assert
			convey.So(got, convey.ShouldEqual, "")
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.ChangeDiscountQuoteItemDao, "FindChangeDiscountQuoteItemByID")).Return([]*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{}}, nil).Build()
			mockey.Mock(GenChangePriceCreateReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					ContractNo: "",
				},
			}, fmt.Errorf("your error")).Build()

			// Act
			got, err := CreateChangeContractPrice(context.Background(), &gorm.DB{}, &model.ContractPriceTask{
				BatchQuoteItemID: "123,456,789",
			}, &model.Quote{})

			// Assert
			convey.So(got, convey.ShouldEqual, "")
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})

	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.ChangeDiscountQuoteItemDao, "FindChangeDiscountQuoteItemByID")).Return([]*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{}}, nil).Build()
			mockey.Mock(GenChangePriceCreateReq).Return(&price_client.CreateContractDiscountForQuoteReq{}, nil).Build()
			mockey.Mock(price_client.CreateContractDiscountForQuote).Return(&price_client.PriceResp{
				Result: &price_client.Result{
					ContractNo: "xxx",
				},
			}, nil).Build()

			// Act
			got, err := CreateChangeContractPrice(context.Background(), &gorm.DB{}, &model.ContractPriceTask{
				BatchQuoteItemID: "123,456,789",
			}, &model.Quote{})

			// Assert
			convey.So(got, convey.ShouldEqual, "xxx")
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
}

func TestGenChangePriceCreateReq(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.QuoteSubTaskDao, "FindSubTasksByID")).Return(&model.QuoteSubTask{
				ContractCode: "",
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(multienv.GetSubjectNo).Return("").Build()
			mockey.Mock(multienv.I18nFormat).Return("").Build()

			// Act
			v, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			got, err := GenChangePriceCreateReq(context.Background(), &gorm.DB{}, &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				CustomerDetail:            "",
				SalesAccountID:            "",
				PriceValidPeriodStartTime: v,
				PriceValidPeriodEndTime:   v1,
				EffectiveType:             0,
				SubTaskID:                 0,
			}, []*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				TradeProduct:     "",
				PrePayTypeCode:   "",
				ConfigCategory:   "",
				ConfigCode:       "",
				SellingMode:      "",
				ChargeItemTag:    "",
				ChargeMethodCode: "",
				ChargeMethodName: "",
				RegionCode:       "",
				ChargeUnitCode:   "",
				PriceFactorCode:  "",
				ChargeItemCode:   "",
				Discount:         "",
				PriceVersion:     "",
			}})

			// Assert
			convey.So(got, convey.ShouldResemble, (*price_client.CreateContractDiscountForQuoteReq)(nil))
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.QuoteSubTaskDao, "FindSubTasksByID")).Return(&model.QuoteSubTask{
				ContractCode: "",
			}, nil).Build()
			mockey.Mock(multienv.GetSubjectNo).Return("").Build()
			mockey.Mock(multienv.I18nFormat).Return("").Build()

			// Act
			v, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			got, err := GenChangePriceCreateReq(context.Background(), &gorm.DB{}, &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				CustomerDetail:            "",
				SalesAccountID:            "",
				PriceValidPeriodStartTime: v,
				PriceValidPeriodEndTime:   v1,
				EffectiveType:             0,
				SubTaskID:                 0,
			}, []*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				TradeProduct:     "",
				PrePayTypeCode:   "0",
				ConfigCategory:   "",
				ConfigCode:       "",
				SellingMode:      "",
				ChargeItemTag:    "",
				ChargeMethodCode: "",
				ChargeMethodName: "",
				RegionCode:       "",
				ChargeUnitCode:   "",
				PriceFactorCode:  "",
				ChargeItemCode:   "",
				Discount:         "",
				PriceVersion:     "",
			}})

			// Assert
			convey.So(got, convey.ShouldResemble, (*price_client.CreateContractDiscountForQuoteReq)(nil))
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(mockey.GetMethod(dal.QuoteSubTaskDao, "FindSubTasksByID")).Return(&model.QuoteSubTask{
				ContractCode: "",
			}, nil).Build()
			mockey.Mock(multienv.GetSubjectNo).Return("").Build()
			mockey.Mock(multienv.I18nFormat).Return("").Build()

			// Act
			v, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			got, err := GenChangePriceCreateReq(context.Background(), &gorm.DB{}, &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				CustomerDetail:            "",
				SalesAccountID:            "",
				PriceValidPeriodStartTime: v,
				PriceValidPeriodEndTime:   v1,
				EffectiveType:             0,
				SubTaskID:                 0,
			}, []*model.ChangeDiscountQuoteItem{&model.ChangeDiscountQuoteItem{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				TradeProduct:     "",
				PrePayTypeCode:   "0",
				ConfigCategory:   "",
				ConfigCode:       "",
				SellingMode:      "",
				ChargeItemTag:    "",
				ChargeMethodCode: "",
				ChargeMethodName: "",
				RegionCode:       "",
				ChargeUnitCode:   "",
				PriceFactorCode:  "",
				ChargeItemCode:   "",
				Discount:         "{\"PricingFunction\":\"Linear\",\"UnitPriceInterval\":\"Hour\",\"MeasureInterval\":\"Hour\",\"UnitPrice\":1.5}",
				PriceVersion:     "",
			}})

			// Assert
			convey.So(got, should.NotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

//go:noinline
func buildGenPriceCreateReqBizInfo(items, deductItems []map[string]string, projectBased int) map[string]interface{} {
	return map[string]interface{}{
		"QuoteItems":       items,
		"DeductQuoteItems": deductItems,
		"ProjectBased":     projectBased,
	}
}

//go:noinline
func buildGenPriceCreateReqItem(id, role, relatedID, discount, sellingMode string) map[string]string {
	return map[string]string{
		"config":               "配置名称-" + id,
		"configCode":           "config-code-" + id,
		"chargeItemCode":       "charge-item-" + id,
		"PricingVersion":       "v1",
		"priceType":            "discount",
		"discount":             discount,
		"ChildProductName":     "子产品-" + id,
		"ChildProductCode":     "child-product-code-" + id,
		"quantity":             "1",
		"standardProductCode":  "standard-product-code-" + id,
		"Product":              "产品-" + id,
		"ProductName":          "产品名称-" + id,
		"QuoteItemID":          id,
		"ItemBusinessRole":     role,
		"RelatedItemID":        relatedID,
		"configCategory":       "配置分类",
		"configCategoryCode":   "config-category-code",
		"chargeMethod":         "按量",
		"chargeMethodCode":     "charge-method-code",
		"region":               "华北",
		"regionCode":           "cn-north-1",
		"chargeUnit":           "核时",
		"chargeUnitCode":       "charge-unit-code",
		"priceFactor":          "规格",
		"priceFactorCode":      "price-factor-code",
		"canPrePay":            "",
		"canPrePayCode":        "",
		"ItemType":             "",
		"sellingMode":          sellingMode,
		"TradeSolution":        "solution",
		"TradeSolutionVersion": "solution-v1",
		"StandardProduct":      "",
		"ChargeItemTag":        "tag",
		"GuaranteedPercentage": "0",
		"SalesMode":            "",
	}
}
func Test_GenPriceCreateReq_BitsUTGen(t *testing.T) {
	type want struct {
		errContains string
		check       func(got *price_client.CreateContractDiscountForQuoteReq, req *quote_client.CreateBizContractReq, quoteDB *model.Quote)
	}

	startTime := time.Date(2024, 1, 2, 3, 4, 5, 0, time.Local)
	endTime := time.Date(2024, 2, 3, 4, 5, 6, 0, time.Local)

	tests := []struct {
		name    string
		req     *quote_client.CreateBizContractReq
		quoteDB *model.Quote
		want    want
	}{
		{
			name: "抵扣列表生成失败时返回错误",
			req: &quote_client.CreateBizContractReq{
				Identifier: "quote-error",
				AccountID:  12345,
				BizInfo: buildGenPriceCreateReqBizInfo(
					[]map[string]string{
						buildGenPriceCreateReqItem("item-error", "0", "", "not-json", ""),
					},
					[]map[string]string{},
					1,
				),
			},
			quoteDB: &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1001,
				},
				PriceValidPeriodStartTime: startTime,
				PriceValidPeriodEndTime:   endTime,
				EffectiveType:             0,
				VerifiedName:              "不应使用",
				SalesAccountID:            "sales-error",
			},
			want: want{
				errContains: "Json解析失败",
			},
		},
		{
			name: "非主体生效类型时使用账号ID生成请求",
			req: &quote_client.CreateBizContractReq{
				Identifier: "quote-normal",
				AccountID:  99887766,
				BizInfo: buildGenPriceCreateReqBizInfo(
					[]map[string]string{
						buildGenPriceCreateReqItem("item-normal", "0", "", `{"PricingFunction":"Linear","UnitPriceInterval":"Hour","MeasureInterval":"Hour","UnitPrice":1.5}`, ""),
					},
					[]map[string]string{},
					1,
				),
			},
			quoteDB: &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1002,
				},
				PriceValidPeriodStartTime: startTime,
				PriceValidPeriodEndTime:   endTime,
				EffectiveType:             0,
				VerifiedName:              "不应使用的实名",
				SalesAccountID:            "sales-normal",
			},
			want: want{
				check: func(got *price_client.CreateContractDiscountForQuoteReq, req *quote_client.CreateBizContractReq, quoteDB *model.Quote) {
					convey.So(got, convey.ShouldNotBeNil)
					convey.So(got.QuoteNo, convey.ShouldEqual, req.Identifier)
					convey.So(got.BeginTime, convey.ShouldEqual, util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodStartTime))
					convey.So(got.EndTime, convey.ShouldEqual, util.FormatDateTimeWithZone(quoteDB.PriceValidPeriodEndTime))
					convey.So(got.EffectiveType, convey.ShouldEqual, quoteDB.EffectiveType)
					convey.So(got.EffectiveValue, convey.ShouldEqual, strconv.FormatInt(req.AccountID, 10))
					convey.So(got.SubjectNo, convey.ShouldEqual, "mock-subject-no")
					convey.So(got.Operator, convey.ShouldEqual, quoteDB.SalesAccountID)
					convey.So(got.RuleName, convey.ShouldEqual, "mock-rule-name-1002")
					convey.So(got.PriceSource, convey.ShouldEqual, constants.PriceSourceInnerQuote)
					convey.So(got.QuoteScene, convey.ShouldEqual, int(multienv.SceneNew))
					convey.So(len(got.DiscountList), convey.ShouldEqual, 1)
					convey.So(got.DiscountList[0].ExternalID, convey.ShouldEqual, "item-normal")
					convey.So(got.DiscountList[0].SellingMode, convey.ShouldEqual, multienv.SellingModeCalculateCostInstance)
					convey.So(len(got.DiscountList[0].DeductList), convey.ShouldEqual, 0)
				},
			},
		},
		{
			name: "主体生效类型时使用实名并挂载抵扣项",
			req: &quote_client.CreateBizContractReq{
				Identifier: "quote-subject",
				AccountID:  11223344,
				BizInfo: buildGenPriceCreateReqBizInfo(
					[]map[string]string{
						buildGenPriceCreateReqItem("item-parent", "0", "", `{"PricingFunction":"Linear","UnitPriceInterval":"Hour","MeasureInterval":"Hour","UnitPrice":3.2}`, ""),
					},
					[]map[string]string{
						buildGenPriceCreateReqItem("item-deduct", strconv.Itoa(constants.QuoteItemBusinessRoleDeduct), "item-parent", `{"PricingFunction":"Linear","UnitPriceInterval":"Hour","MeasureInterval":"Hour","UnitPrice":0.8}`, ""),
					},
					1,
				),
			},
			quoteDB: &model.Quote{
				BaseDB: framework.BaseDB{
					Id: 1003,
				},
				PriceValidPeriodStartTime: startTime,
				PriceValidPeriodEndTime:   endTime,
				EffectiveType:             constants.EffectiveTypeSubject,
				VerifiedName:              "实名主体A",
				SalesAccountID:            "sales-subject",
			},
			want: want{
				check: func(got *price_client.CreateContractDiscountForQuoteReq, req *quote_client.CreateBizContractReq, quoteDB *model.Quote) {
					convey.So(got, convey.ShouldNotBeNil)
					convey.So(got.EffectiveType, convey.ShouldEqual, constants.EffectiveTypeSubject)
					convey.So(got.EffectiveValue, convey.ShouldEqual, quoteDB.VerifiedName)
					convey.So(got.SubjectNo, convey.ShouldEqual, "mock-subject-no")
					convey.So(got.RuleName, convey.ShouldEqual, "mock-rule-name-1003")
					convey.So(len(got.DiscountList), convey.ShouldEqual, 1)
					convey.So(got.DiscountList[0].ExternalID, convey.ShouldEqual, "item-parent")
					convey.So(len(got.DiscountList[0].DeductList), convey.ShouldEqual, 1)
					convey.So(got.DiscountList[0].DeductList[0].ExternalID, convey.ShouldEqual, "item-deduct")
					convey.So(got.DiscountList[0].DeductList[0].ReferenceID, convey.ShouldEqual, "item-deduct")
				},
			},
		},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				mockey.MockUnsafe(multienv.GetSubjectNo).Return("mock-subject-no").Build()
				mockey.MockUnsafe(multienv.I18nFormat).Return("mock-rule-name").Build()

				got, err := GenPriceCreateReq(context.Background(), tc.req, tc.quoteDB)

				if tc.want.errContains != "" {
					convey.So(got, convey.ShouldBeNil)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, tc.want.errContains)
					return
				}

				convey.So(err, convey.ShouldBeNil)
				tc.want.check(got, tc.req, tc.quoteDB)
			})
		})
	}
}

package discount_function_rule_cache

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kv/redis-v6/pkg"
	"context"
	"github.com/bytedance/sonic"
	"strconv"
	"strings"
)

const discountFunctionRulePrefix = "discount_function_rule_prefix_"

type RuleCacheHandel struct {
	DiscountFunctionRule *model.DiscountFunctionRule
}

func (c *RuleCacheHandel) UpdateRuleCache(ctx context.Context) error {
	if c.DiscountFunctionRule.RuleStatus == constants.RuleStatusEffective {
		logs.CtxInfo(ctx, "报价方式当前状态需要写入缓存%s", c.DiscountFunctionRule.RuleStatus)
		return c.putRuleInCache(ctx)
	} else if c.DiscountFunctionRule.RuleStatus == constants.RuleStatusUnEffective {
		logs.CtxInfo(ctx, "报价方式当前状态需要移除缓存%s", c.DiscountFunctionRule.RuleStatus)
		return c.removeRuleFromCache(ctx)
	} else {
		logs.CtxInfo(ctx, "报价方式当前状态不需要更新缓存%s", c.DiscountFunctionRule.RuleStatus)
	}
	return nil
}

func (c *RuleCacheHandel) putRuleInCache(ctx context.Context) error {
	tradeProducts := strings.Split(c.DiscountFunctionRule.RelatedProduct, ",")
	discountFunctionStr := util.GetJsonStr(RuleCacheData{
		PrePayType:       c.DiscountFunctionRule.PrePayType,
		DiscountFunction: c.DiscountFunctionRule.DiscountFunction,
	})

	pipelineClient := redis_client.NewRedisClient().Pipeline()

	for _, tradeProduct := range tradeProducts {
		pipelineClient.HSet(discountFunctionRulePrefix+tradeProduct, strconv.FormatInt(c.DiscountFunctionRule.Id, 10), discountFunctionStr)
	}
	_, err := pipelineClient.Exec()
	if err != nil {
		logs.CtxError(ctx, "putRuleInCache error :%s", err.Error())
		return err
	}
	return nil
}

func (c *RuleCacheHandel) removeRuleFromCache(ctx context.Context) error {
	tradeProducts := strings.Split(c.DiscountFunctionRule.RelatedProduct, ",")
	pipelineClient := redis_client.NewRedisClient().Pipeline()
	for _, tradeProduct := range tradeProducts {
		pipelineClient.HDel(discountFunctionRulePrefix+tradeProduct, strconv.FormatInt(c.DiscountFunctionRule.Id, 10))
	}
	_, err := pipelineClient.Exec()
	if err != nil {
		logs.CtxError(ctx, "removeRuleFromCache error :%s", err.Error())
		return err
	}
	return nil
}

func (c *RuleCacheHandel) GetRulesFromCache(ctx context.Context, tradeProduct string) ([]*RuleCacheData, error) {

	var ret []*RuleCacheData
	redisClient := redis_client.NewRedisClient()
	ruleCacheDataMap, err := redisClient.HGetAll(discountFunctionRulePrefix + tradeProduct).Result()
	if err == pkg.Nil {
		return ret, nil
	}
	if err != nil {
		return nil, err
	}
	for _, ruleCacheDataStr := range ruleCacheDataMap {
		ruleCacheData := &RuleCacheData{}
		err = sonic.Unmarshal([]byte(ruleCacheDataStr), ruleCacheData)
		if err != nil {
			return nil, err
		}
		ret = append(ret, ruleCacheData)
	}
	return ret, nil
}

type RuleCacheData struct {
	PrePayType       string
	DiscountFunction string
}

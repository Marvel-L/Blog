package control_resource_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"fmt"
)

// ControlResource 受控资源卡信息
type ControlResource struct {
	ResourceCardName     string
	TradeProduct         string
	ConfigCode           string
	BillingElementZhName string
	ResourceNumLimit     int
	DefaultNumLimit      int
}

// GetKey 获取资源卡匹配key
func (r *ControlResource) GetKey() string {
	return fmt.Sprintf(
		"%s%s%s%s%s",
		r.TradeProduct,
		constants.Separator,
		r.ConfigCode,
		constants.Separator,
		r.BillingElementZhName,
	)
}

// ControlInfo 受控信息
type ControlInfo struct {
	TradeProductMap    map[string]bool
	ControlResourceMap map[string]*ControlResource
}

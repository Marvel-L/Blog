package control_resource_service

import "context"

// RefreshControlCardInfoReq 刷新受控卡信息
type RefreshControlCardInfoReq struct {
}

// Handle 处理
func (r *RefreshControlCardInfoReq) Handle(ctx context.Context) (interface{}, error) {
	return SyncControlResourceMap(ctx)
}

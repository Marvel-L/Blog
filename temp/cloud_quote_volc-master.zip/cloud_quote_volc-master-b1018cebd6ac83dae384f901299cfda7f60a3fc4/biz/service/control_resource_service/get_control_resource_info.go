package control_resource_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/yunshu_client"
	"code.byted.org/gopkg/logs"
	"context"
	"encoding/json"
)

const controlResourceMapKey = "control_resource_map_h"

// getControlResourceMapFromServer 从云枢获取受控卡信息
func getControlResourceMapFromServer(ctx context.Context) (map[string]*ControlResource, error) {
	allControlCardInfos, err := yunshu_client.ListAllControlCardInfo(ctx)
	if err != nil {
		return nil, err
	}

	var resourceArr []*ControlResource
	for _, controlCardInfo := range allControlCardInfos {
		resourceArr = append(resourceArr,
			&ControlResource{
				ResourceCardName:     controlCardInfo.CardName,
				TradeProduct:         controlCardInfo.Trade,
				ConfigCode:           controlCardInfo.ConfigurationCode,
				BillingElementZhName: controlCardInfo.BillingElementZhName,
				ResourceNumLimit:     controlCardInfo.CardNum,
				DefaultNumLimit:      controlCardInfo.DefaultCardNum,
			},
		)
	}

	ret := map[string]*ControlResource{}
	for _, resource := range resourceArr {
		ret[resource.GetKey()] = resource
	}
	return ret, nil
}

// SyncControlResourceMap 同步受控卡信息缓存
func SyncControlResourceMap(ctx context.Context) (map[string]*ControlResource, error) {
	resourceMapFromServer, err := getControlResourceMapFromServer(ctx)
	if err != nil {
		return nil, err
	}

	redisClient := redis_client.NewRedisClient()
	cachedResourceMap, err := redisClient.HGetAll(controlResourceMapKey).Result()
	if err != nil {
		logs.CtxError(ctx, "redisClient.HGetAll(controlResourceMapKey) err: %s", err.Error())
		return nil, err
	}
	var invalidCachedResourceKeys []string
	for cachedResourceKey := range cachedResourceMap {
		if _, ok := resourceMapFromServer[cachedResourceKey]; !ok {
			invalidCachedResourceKeys = append(invalidCachedResourceKeys, cachedResourceKey)
		}
	}
	if len(invalidCachedResourceKeys) > 0 {
		_, err = redisClient.HDel(controlResourceMapKey, invalidCachedResourceKeys...).Result()
		if err != nil {
			logs.CtxError(ctx, "redisClient.HDel(controlResourceMapKey, invalidCachedResourceKeys...) err: %s", err.Error())
			return nil, err
		}
	}
	updateResourceMap := map[string]interface{}{}
	for resourceKey, resourceData := range resourceMapFromServer {
		updateResourceMap[resourceKey] = util.GetJsonStr(resourceData)
	}
	_, err = redisClient.HMSet(controlResourceMapKey, updateResourceMap).Result()
	if err != nil {
		logs.CtxError(ctx, "redisClient.HMSet(controlResourceMapKey, updateResourceMap) err: %s", err.Error())
		return nil, err
	}

	return resourceMapFromServer, nil
}

// GetControlResourceMapFromCache 缓存中获取受控卡信息
func GetControlResourceMapFromCache(ctx context.Context) (*ControlInfo, error) {
	switchModel := config.GetSwitchByName(ctx, config.MockControlResource)
	if switchModel != nil && switchModel.IsOpen {
		logs.CtxInfo(ctx, "GetControlResourceMapFromCache use mock data：%s", switchModel.MockData)
		var mockControlInfo *ControlInfo
		err := json.Unmarshal([]byte(switchModel.MockData), &mockControlInfo)
		return mockControlInfo, err
	}

	redisClient := redis_client.NewRedisClient()
	cachedResourceMap, err := redisClient.HGetAll(controlResourceMapKey).Result()
	if err != nil {
		logs.CtxError(ctx, "redisClient.HGetAll(controlResourceMapKey) err: %s", err.Error())
		return nil, err
	}
	controlResourceMap := map[string]*ControlResource{}
	tradeProductMap := map[string]bool{}

	for resourceKey, resourceDataStr := range cachedResourceMap {
		resourceData := &ControlResource{}
		err = json.Unmarshal([]byte(resourceDataStr), resourceData)
		if err != nil {
			logs.CtxError(
				ctx,
				"json.Unmarshal([]byte(resourceDataStr), resourceData) resourceDataStr: %s  err: %s",
				resourceDataStr,
				err.Error(),
			)
			return nil, err
		}
		controlResourceMap[resourceKey] = resourceData
		tradeProductMap[resourceData.TradeProduct] = true
	}
	return &ControlInfo{
		TradeProductMap:    tradeProductMap,
		ControlResourceMap: controlResourceMap,
	}, nil
}

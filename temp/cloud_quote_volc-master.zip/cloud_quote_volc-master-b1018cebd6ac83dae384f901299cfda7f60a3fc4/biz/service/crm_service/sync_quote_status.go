package crm_service

import (
	"context"
	"fmt"
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"code.byted.org/eps-platform/salesforce_sdk"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/recovery"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/crmclient"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"

	"code.byted.org/gopkg/logs"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type SyncQuoteStatusReq struct {
	QuoteId int64
}

type SyncQuoteStatusResp struct {
	*model.Quote
}

var QuoteStatusMapper = map[constants.QuoteStatus]string{
	constants.StatusInitialed:     constants.CrmApplicationStatusDraft,
	constants.StatusSubmit:        constants.CrmApplicationStatusInApproval,
	constants.StatusPass:          constants.CrmApplicationStatusApproved,
	constants.StatusReject:        constants.CrmApplicationStatusRejected,
	constants.StatusToBeEffective: constants.CrmApplicationStatusToBeEffective,
	constants.StatusEffective:     constants.CrmApplicationStatusEffective,
	constants.StatusExpired:       constants.CrmApplicationStatusExpired,
	constants.StatusAbandoned:     constants.CrmApplicationStatusAbandoned,
	constants.StatusChanging:      constants.CrmApplicationStatusChanging,
	constants.StatusChanged:       constants.CrmApplicationStatusChanged,
	constants.StatusSubmitting:    constants.CrmApplicationStatusSubmitting,
	constants.StatusSubmitFail:    constants.CrmApplicationStatusSubmitting,
	constants.StatusDraftExpired:  constants.CrmApplicationStatusDraftExpired,
}

var QuoteEditStatusMapper = map[int]string{
	constants.ApprovalModifyStatusNone:      constants.CrmApplicationEditStatusUnableModify,
	constants.ApprovalModifyStatusStart:     constants.CrmApplicationEditStatusModify,
	constants.ApprovalModifyStatusSubmitted: constants.CrmApplicationEditStatusModifySubmit,
}

func (r *SyncQuoteStatusReq) Handle(c context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(c)
	quoteDB, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteId)

	if err != nil {
		logs.CtxError(c, "find oa application by quotID error", err)
		return nil, errors.ErrInternalError.WithArgs(err)
	}
	statusStr := QuoteStatusMapper[quoteDB.QuoteStatus]
	editStatusStr := QuoteEditStatusMapper[quoteDB.ModifyStatus]
	err = QuoteStatusCallbackV2(c, quoteDB.Id, salesforce_sdk.QuoteStatusCallbackReq{
		Status:     &statusStr,
		EditStatus: &editStatusStr,
	})
	if err != nil {
		logs.CtxError(c, "manual quote status crm callback error", err)
		return nil, errors.ErrInternalError.WithArgs(err)
	}
	logs.CtxInfo(c, "manual quote status crm callback success")
	resp := SyncQuoteStatusResp{
		Quote: quoteDB,
	}

	return resp, nil
}

func QuoteStatusCallbackV2(ctx context.Context, quoteID int64, req salesforce_sdk.QuoteStatusCallbackReq) error {
	tx := dal.DBProxy.NewRequest(ctx)

	quoteDB, err := dal.QuoteDao.FindQuoteByID(tx, quoteID)
	if err != nil {
		return err
	}

	if quoteDB.AppAccountID == constants.CrmAccount ||
		quoteDB.AppAccountID == constants.PrmAccount ||
		quoteDB.AppAccountID == constants.OpenApiAppKeyPrm ||
		quoteDB.AppAccountID == config.GetOpenApiAppKeyCrm(ctx) {

		if quoteDB.IsQuote() {
			return crmclient.QuoteStatusCallbackV2(ctx, quoteID, req)
		}
	}
	logs.CtxInfo(ctx, "do not need quote status crm sync quoteId: %d AppAccountID : %s", quoteDB.Id, quoteDB.AppAccountID)
	return nil
}

func QuoteStatusCallbackWithNotifyV2(ctx context.Context, quoteID int64, req salesforce_sdk.QuoteStatusCallbackReq) {
	defer recovery.DefaultRecovery(ctx, "QuoteStatusCallbackWithNotify")()
	logs.CtxInfo(ctx, "QuoteStatusCallbackWithNotifyV2 quoteID : %d req: %s ", quoteID, util.GetJsonStr(req))
	err := QuoteStatusCallbackV2(ctx, quoteID, req)
	if err != nil {
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf("【ERR】crm报价单状态同步失败 （@邹野） quoteId : %d , error: [%s] ", quoteID, err.Error()))
		logs.CtxError(ctx, "oa callback quote status crm callback error: %s ", err.Error())
	} else {
		logs.CtxInfo(ctx, "QuoteStatusCallbackWithNotifyV2Success")
	}
}

func QuoteNumberCallback(ctx context.Context, quoteID int64, quoteNumber string) {
	defer recovery.DefaultRecovery(ctx, "QuoteNumberCallback")()
	logs.CtxInfo(ctx, "QuoteNumberCallback quoteID : %d quoteNumber: %s ", quoteID, quoteNumber)
	err := crmclient.QuoteNumberCallback(ctx, quoteID, quoteNumber)
	if err != nil {
		logs.CtxError(ctx, "crmclient.QuoteNumberCallback error: %s ", err.Error())
	}
	logs.CtxInfo(ctx, "QuoteNumberCallbackSuccess")
}

func CreateCrmQuote(ctx context.Context, quoteDB *model.Quote) {
	if quoteDB.AppAccountID != constants.PrmAccount && quoteDB.AppAccountID != constants.OpenApiAppKeyPrm {
		return
	}
	//只有伙伴渠道创建的才会进行同步

	relatedProduct, err := quoteDB.GetProductType(ctx)
	if err != nil {
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf("【ERR】prm报价单创建到crm失败 （@邹野） quote_id : %d , error: [%s] ", quoteDB.Id, err.Error()))
		logs.CtxError(ctx, "prm报价单创建到crm失败 error: %s ", err.Error())
		return
	}

	err = crmclient.CreateCrmQuote(ctx, salesforce_sdk.QuoteModel{
		PartnerID:      quoteDB.CustomerDetail,
		OppNumber:      string(quoteDB.OpportunityID),
		RelatedProduct: relatedProduct,
		SolutionEmail:  quoteDB.SolutionConsultantID,
		QuoteID:        strconv.FormatInt(quoteDB.Id, 10),
		QuoteStatus:    constants.CrmApplicationStatusDraft,
		QuoteSource:    constants.QuoteSourcePrm,
	})

	if err != nil {
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf("【ERR】prm报价单创建到crm失败 （@邹野） quote_id : %d , error: [%s] ", quoteDB.Id, err.Error()))
		logs.CtxError(ctx, "prm报价单创建到crm失败 error: %s ", err.Error())
		return
	}

	logs.CtxInfo(ctx, "prm报价单创建到crm : %s", util.GetJsonStr(quoteDB))
}

package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"context"
	"strconv"
)

type GetCrmQuoteNumMapReq struct {
	QuoteIDList []int64
}

type GetCrmQuoteNumMapResp struct {
	QuoteNumMap map[int64]string
}

func (r *GetCrmQuoteNumMapReq) Handle(c context.Context) (interface{}, error) {
	quoteNumMap := make(map[int64]string)
	if len(r.QuoteIDList) == 0 {
		return &GetCrmQuoteNumMapResp{QuoteNumMap: quoteNumMap}, nil
	}
	if len(r.QuoteIDList) > 1000 {
		return nil, errors.NewBizErrWithMsg(0, "quote id list size must be less than 1000")
	}
	quoteIDStrList := make([]string, 0)
	for _, id := range r.QuoteIDList {
		quoteIDStrList = append(quoteIDStrList, strconv.FormatInt(id, 10))
	}

	sfSearchQuoteResp, err := c360service_client.SfSearchQuote(c, quoteIDStrList)
	if err != nil {
		logs.CtxError(c, "SfSearchQuote err: %v", err)
		return nil, err
	}
	if sfSearchQuoteResp == nil {
		logs.CtxWarn(c, "sfSearchQuoteResp is nil")
		return nil, nil
	}
	for _, record := range sfSearchQuoteResp.Records {
		if record == nil {
			continue
		}
		if record.QuoteCenterID == nil || record.SfID == nil {
			logs.CtxWarn(c, "sfSearchQuoteResp record: %v", util.GetJsonStr(record))
			continue
		}
		if *record.QuoteCenterID == "" {
			logs.CtxWarn(c, "sfSearchQuoteResp record QuoteCenterID is empty string, record: %v", util.GetJsonStr(record))
			continue
		}
		quoteNumMap[util.StrToInt64(*record.QuoteCenterID)] = *record.SfID
	}

	return &GetCrmQuoteNumMapResp{QuoteNumMap: quoteNumMap}, nil
}

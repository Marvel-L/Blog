package crm_service

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
)

func (r *GetOpportunityInfoReq) GetOpportunitySimpleInfo(c context.Context) (*OpportunitySimpleInfo, error) {
	oppInfo, err := c360service_client.GetOpportunityInfo(c, r.GetOppoNumber(c), r.GetOppoName(c), "")
	if err != nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNQueryOpportunityInfoError, err.Error())
	}
	if oppInfo == nil {
		return nil, nil
	}
	respOpp := &OpportunitySimpleInfo{
		OppNumber:                 oppInfo.GetOppNumber(),
		OppName:                   oppInfo.GetOppName(),
		PartnerVolcanoMap:         map[string]bool{},
		CustomerVolcanoMap:        map[string]bool{},
		PartnerCustomerVolcanoMap: map[string]bool{},
		JointPrintInfo:            &JointPrintInfo{},
	}
	accountInfo := oppInfo.GetAccountInfo()
	if accountInfo != nil {
		respOpp.AccountInfo = convertAccountInfo(accountInfo)
	}
	partnerInfo := oppInfo.GetPartnerInfo()
	if partnerInfo != nil {
		respOpp.PartnerInfo = convertAccountInfo(partnerInfo)
	}
	parentAccountInfo := oppInfo.GetParentAccountInfo()
	if parentAccountInfo != nil {
		respOpp.ParentAccountInfo = convertAccountInfo(parentAccountInfo)
	}

	for _, partner := range oppInfo.PartnerVolcanoList {
		respOpp.PartnerVolcanoMap[partner.GetVolcanoId()] = true
	}
	for _, customerInfo := range oppInfo.CustomerVolcanoList {
		respOpp.CustomerVolcanoMap[customerInfo.GetVolcanoId()] = true
	}
	for _, customerInfo := range oppInfo.PartnerCustomerVolcanoList {
		respOpp.PartnerCustomerVolcanoMap[customerInfo.GetVolcanoId()] = true
	}
	respOpp.GetJointPrintInfo(oppInfo)
	return respOpp, nil
}

func (r *OpportunitySimpleInfo) GetJointPrintInfo(oppInfo *opportunity.SearchOpportunityRelatedInfoForQuote) {
	if oppInfo.OwnerInfo != nil && oppInfo.OwnerInfo.ShortRoleName != nil {
		r.JointPrintInfo.PrintSceneOppRole = *oppInfo.OwnerInfo.ShortRoleName
	}
	if oppInfo.JointOppUserInfo != nil {
		if oppInfo.JointOppUserInfo.ShortRoleName != nil {
			r.JointPrintInfo.PrintSceneJointRole = *oppInfo.JointOppUserInfo.ShortRoleName
		}
		if oppInfo.JointOppUserInfo.Email != nil {
			r.JointPrintInfo.Collaborator = *oppInfo.JointOppUserInfo.Email
		}
	}
	if oppInfo.AccountInfo != nil && oppInfo.AccountInfo.OwnerInfo != nil && oppInfo.AccountInfo.OwnerInfo.ShortRoleName != nil {
		r.JointPrintInfo.CustomerOwnerRole = *oppInfo.AccountInfo.OwnerInfo.ShortRoleName
	}
	if oppInfo.JointOppActiveInfo != nil && oppInfo.JointOppActiveInfo.JointOppScenesDec != nil {
		r.JointPrintInfo.PrintSceneDec = *oppInfo.JointOppActiveInfo.JointOppScenesDec
	}
	if oppInfo.OpportunitySourceKey != nil {
		r.JointPrintInfo.OpportunitySrcKey = *oppInfo.OpportunitySourceKey
	}
	if oppInfo.JointOppIsActive != nil {
		r.JointPrintInfo.Support = *oppInfo.JointOppIsActive
	}
}

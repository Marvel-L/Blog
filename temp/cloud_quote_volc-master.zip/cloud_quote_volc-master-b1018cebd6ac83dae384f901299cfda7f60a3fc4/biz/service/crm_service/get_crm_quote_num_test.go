package crm_service

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/quote"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

// All comments and test scenario descriptions must be in english.
func Test_GetCrmQuoteNumMapReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("Successful Scenario - Empty QuoteIDList", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - Empty QuoteIDList", t, func() {
			req := &GetCrmQuoteNumMapReq{
				QuoteIDList: []int64{},
			}

			resp, err := req.Handle(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			result, ok := resp.(*GetCrmQuoteNumMapResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(len(result.QuoteNumMap), convey.ShouldEqual, 0)
		})
	})

	t.Run("Failure Scenario - QuoteIDList exceeds size limit", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - QuoteIDList exceeds size limit", t, func() {
			req := &GetCrmQuoteNumMapReq{
				QuoteIDList: make([]int64, 1001),
			}

			resp, err := req.Handle(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			bizErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(bizErr.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCodeBizRuleCheckFailed)
			convey.So(bizErr.Error(), convey.ShouldContainSubstring, "quote id list size must be less than 1000")
		})
	})

	t.Run("Failure Scenario - SfSearchQuote returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - SfSearchQuote returns an error", t, func() {
			req := &GetCrmQuoteNumMapReq{
				QuoteIDList: []int64{123},
			}
			mockErr := errors.New("rpc call failed")
			mockey.Mock(c360service_client.SfSearchQuote).Return(nil, mockErr).Build()

			resp, err := req.Handle(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})

	t.Run("Successful Scenario - SfSearchQuote returns valid and invalid records", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - SfSearchQuote returns valid and invalid records", t, func() {
			req := &GetCrmQuoteNumMapReq{
				QuoteIDList: []int64{1, 2, 3, 4, 5, 6},
			}
			mockResp := &quote.SfSearchQuoteResp{
				Records: []*quote.Quote{
					{ // Valid record
						QuoteCenterID: gptr.Of("1"),
						SfID:          gptr.Of("SF-001"),
					},
					{ // Record with nil SfID
						QuoteCenterID: gptr.Of("2"),
						SfID:          nil,
					},
					{ // Record with nil QuoteCenterID
						QuoteCenterID: nil,
						SfID:          gptr.Of("SF-003"),
					},
					{ // Record with empty string QuoteCenterID
						QuoteCenterID: gptr.Of(""),
						SfID:          gptr.Of("SF-004"),
					},
					nil, // Nil record in the list
					{ // Another valid record
						QuoteCenterID: gptr.Of("6"),
						SfID:          gptr.Of("SF-006"),
					},
				},
			}
			mockey.Mock(c360service_client.SfSearchQuote).Return(mockResp, nil).Build()

			resp, err := req.Handle(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			result, ok := resp.(*GetCrmQuoteNumMapResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(len(result.QuoteNumMap), convey.ShouldEqual, 2)
			convey.So(result.QuoteNumMap[1], convey.ShouldEqual, "SF-001")
			convey.So(result.QuoteNumMap[6], convey.ShouldEqual, "SF-006")
		})
	})

	t.Run("Successful Scenario - SfSearchQuote returns no matching records", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - SfSearchQuote returns no matching records", t, func() {
			req := &GetCrmQuoteNumMapReq{
				QuoteIDList: []int64{123},
			}
			mockResp := &quote.SfSearchQuoteResp{
				Records: []*quote.Quote{},
			}
			mockey.Mock(c360service_client.SfSearchQuote).Return(mockResp, nil).Build()

			resp, err := req.Handle(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			result, ok := resp.(*GetCrmQuoteNumMapResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(len(result.QuoteNumMap), convey.ShouldEqual, 0)
		})
	})
}

package crm_service

import (
	"context"
	"strconv"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/passport_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type SearchOpportunityInfoReq struct {
	OppName   string `query:"OppName"`
	OppNumber string `query:"OppNumber"`
}

type SearchOpportunityInfoResp struct {
	List []*OpportunityInfo `json:"List"`
}

func (r *SearchOpportunityInfoReq) Handle(c context.Context) (interface{}, error) {

	if r.OppName == "" && r.OppNumber == "" {
		return nil, errors.ErrInvalidParam.WithArgs("OppName&OppNumber", "empty string")
	}

	currentUser, apiErr := dal.AccountDao.CurrentUser(c)
	if apiErr != nil {
		return nil, errors.ErrInternalError.WithArgs(apiErr)
	}

	oppUser := ""
	if currentUser.AccountType.Contains(constants.AccountTypeUser) {
		oppUser = currentUser.AccountID
	}
	oppList, err := c360service_client.SearchOpportunityInfo(c, r.OppName, r.OppNumber, oppUser)
	if err != nil {
		return nil, errors.ErrInternalError.WithArgs(err.Error())
	}

	accountSimpleInfoMap, err := r.getAccountInfo(c, oppList)
	if err != nil {
		return nil, err
	}
	var respList []*OpportunityInfo
	for _, oppInfo := range oppList {
		respOpp := &OpportunityInfo{
			ProjectServiceList:  []*ProjectInfo{},
			PartnerVolcanoList:  []*DomainInfo{},
			CustomerVolcanoList: []*DomainInfo{},
			OppNumber:           oppInfo.GetOppNumber(),
			OppName:             oppInfo.GetOppName(),
			AccountInfo:         &AccountInfo{},
		}

		var partnerInfoList []*DomainInfo
		for _, partnerInfo := range oppInfo.PartnerVolcanoList {
			partnerAccount, ok := accountSimpleInfoMap[partnerInfo.GetVolcanoId()]
			if ok && partnerAccount.IsEnterpriseIdentity {
				partnerInfoList = append(partnerInfoList, &DomainInfo{
					VolcanoName:           partnerInfo.GetVolcanoName(),
					VolcanoId:             partnerInfo.GetVolcanoId(),
					CreateSource:          partnerAccount.CreateSource,
					FinancialEntrustLabel: partnerAccount.FinancialManageLabel,
					FinancialManageLabel:  partnerAccount.FinancialEntrustLabel,
				})
			}
		}
		respOpp.PartnerVolcanoList = partnerInfoList
		var customerInfoList []*DomainInfo
		for _, customerInfo := range oppInfo.CustomerVolcanoList {
			customerAccount, ok := accountSimpleInfoMap[customerInfo.GetVolcanoId()]
			if ok && customerAccount.IsEnterpriseIdentity {

				customerInfoList = append(customerInfoList, &DomainInfo{
					VolcanoName:           customerInfo.GetVolcanoName(),
					VolcanoId:             customerInfo.GetVolcanoId(),
					CreateSource:          customerAccount.CreateSource,
					FinancialEntrustLabel: customerAccount.FinancialManageLabel,
					FinancialManageLabel:  customerAccount.FinancialEntrustLabel,
				})

			}
		}
		respOpp.CustomerVolcanoList = customerInfoList
		accountInfo := oppInfo.GetAccountInfo()
		if accountInfo != nil {
			respOpp.AccountInfo = &AccountInfo{
				CollectionAccount: accountInfo.GetCollectionAccount(),
				AccountTierCN:     accountInfo.GetAccountTierCN(),
				AccountTier:       accountInfo.GetAccountTier(),
				AccountName:       accountInfo.GetAccountName(),
			}
		}

		respList = append(respList, respOpp)
	}

	resp := SearchOpportunityInfoResp{List: respList}
	return resp, nil
}

func (r *SearchOpportunityInfoReq) getAccountInfo(c context.Context, oppList []*opportunity.SearchOpportunityRelatedInfoForQuote) (map[string]*passport_service.AccountSimpleInfo, error) {
	var accountList []string
	accountIDMap := map[string]bool{}
	whiteListConf := config.GetWhiteListConf(c)
	for _, oppInfo := range oppList {
		// 商机白名单判断
		if oppInfo.OppNumber != nil && len(whiteListConf.OppAccountIDWhiteList) != 0 {
			oppNumber := *oppInfo.OppNumber
			if accountIDWhiteList, exist := whiteListConf.OppAccountIDWhiteList[oppNumber]; exist && len(accountIDWhiteList) != 0 {
				logs.CtxInfo(c, "[SearchOpportunityInfo]getAccountInfo hit OppAccountIDWhiteList, OppNumber:%s, OppAccountIDWhiteList:%v", oppNumber, accountIDWhiteList)
				accountList = append(accountList, accountIDWhiteList...)
				continue
			}
		}

		for _, partnerInfo := range oppInfo.PartnerVolcanoList {
			accountIDMap[partnerInfo.GetVolcanoId()] = true
		}
		for _, customerInfo := range oppInfo.CustomerVolcanoList {
			accountIDMap[customerInfo.GetVolcanoId()] = true
		}
	}
	for accountID, _ := range accountIDMap {
		accountList = append(accountList, accountID)
	}
	accountInfoReq := &passport_service.ListAccountInfoReq{
		AccountID: strings.Join(accountList, ","),
	}
	accountSimpleInfoList, err := accountInfoReq.ListAccountSimpleInfo(c)
	if err != nil {
		return nil, err
	}

	accountSimpleInfoMap := map[string]*passport_service.AccountSimpleInfo{}
	for _, accountSimpleInfo := range accountSimpleInfoList {
		accountSimpleInfoMap[strconv.FormatUint(accountSimpleInfo.AccountID, 10)] = accountSimpleInfo
	}
	return accountSimpleInfoMap, nil
}

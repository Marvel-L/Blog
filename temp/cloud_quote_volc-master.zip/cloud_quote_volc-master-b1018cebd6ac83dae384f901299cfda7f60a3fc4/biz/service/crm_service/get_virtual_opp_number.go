package crm_service

import (
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
)

type GetVirtualOppNumberReq struct {
	TradeType     multienv.TradeType `query:"TradeType"`
	TradeTypeCode int                `query:"TradeTypeCode"`
}

type GetVirtualOppNumberResp struct {
	OppNumber multienv.OppNumber
}

func (r *GetVirtualOppNumberReq) Handle(c context.Context) (interface{}, error) {
	if r.TradeTypeCode > 0 {
		r.TradeType = multienv.GetTradeCodeTypeMapping()[r.TradeTypeCode]
	}
	oppNumberPrefix, ok := multienv.GetOppNumberPrefixMap()[r.TradeType]
	if !ok {
		return nil, errors.ErrInternalError.WithArgs("内部客户类型错误，无法获取相应虚拟商机编号")
	}
	strVal := redis_client.GetStrVal(oppNumberPrefix)
	if strVal == "" {
		incr, err := GetMaxOppIDFromDB(c, oppNumberPrefix)
		if err != nil {
			logs.CtxError(c, "获取虚拟商机编号失败 error : %s", err.Error())
			return nil, errors.ErrInternalError.WithArgs("获取虚拟商机编号失败")
		}
		if _, err = redis_client.NewRedisClient().Set(oppNumberPrefix, strconv.FormatInt(incr, 10), 0).Result(); err != nil {
			return nil, err
		}
		strVal = redis_client.GetStrVal(oppNumberPrefix)
	}

	oppNumber := fmt.Sprintf("%s%08s", oppNumberPrefix, strVal)

	return &GetVirtualOppNumberResp{OppNumber: multienv.OppNumber(oppNumber)}, nil
}

func OppNumberWriteOff(oppNumber multienv.OppNumber, tradeType multienv.TradeType) (bool, error) {
	oppNumberPrefix, ok := multienv.GetOppNumberPrefixMap()[tradeType]
	if !ok {
		return false, errors.ErrInternalError.WithArgs("内部客户类型错误，虚拟商机校验失败")
	}

	countStr := strings.TrimPrefix(string(oppNumber), oppNumberPrefix)
	countIntValStr := strings.TrimLeft(countStr, "0")

	incr, err := redis_client.MatchAndIncr(oppNumberPrefix, countIntValStr)
	if err != nil {
		return false, err
	}
	if incr == 0 {
		return false, nil
	}
	return true, nil
}

func GetMaxOppIDFromDB(c context.Context, oppNumberPrefix string) (int64, error) {
	tx := dal.DBProxy.NewRequest(c)
	maxOppID, err := dal.QuoteDao.FindMaxOpportunityIDByPrefix(tx, oppNumberPrefix)
	if err != nil {
		return 0, err
	}
	if maxOppID == "" {
		return 0, errors.ErrInternalError.WithArgs("数据库中无虚拟商机记录")
	}
	countStr := strings.TrimPrefix(maxOppID, oppNumberPrefix)
	count, err := strconv.ParseInt(countStr, 10, 64)
	if err != nil {
		return 0, err
	}
	return count + 1, nil
}

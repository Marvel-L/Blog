package crm_service

import "code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"

type OpportunityInfo struct {
	ProjectServiceList         []*ProjectInfo `json:"ProjectServiceList"`
	PartnerVolcanoList         []*DomainInfo  `json:"PartnerVolcanoList"`
	OppNumber                  string         `json:"OppNumber"`
	OppName                    string         `json:"OppName"`
	CustomerVolcanoList        []*DomainInfo  `json:"CustomerVolcanoList"`
	AccountInfo                *AccountInfo
	PartnerInfo                *AccountInfo
	JointPrintInfo             *JointPrintInfo `json:"JointPrintInfo"`
	PartnerCustomerVolcanoList []*DomainInfo   `json:"PartnerCustomerVolcanoList"` // 伙伴客户账号列表
}

type OpportunitySimpleInfo struct {
	PartnerVolcanoMap         map[string]bool
	CustomerVolcanoMap        map[string]bool
	PartnerCustomerVolcanoMap map[string]bool // 伙伴cuidMap
	OppNumber                 string
	OppName                   string
	AccountInfo               *AccountInfo
	PartnerInfo               *AccountInfo
	JointPrintInfo            *JointPrintInfo
	ParentAccountInfo         *AccountInfo
}

type ProjectInfo struct {
	ProjectName string `json:"ExternalProjectNumber"`
	ProjectCode string `json:"ProjectName"`
}

type DomainInfo struct {
	VolcanoName           string `json:"VolcanoName"`
	VolcanoId             string `json:"VolcanoId"`
	CreateSource          int    `json:"CreateSource"`
	FinancialEntrustLabel string `json:"FinancialEntrustLabel"`
	FinancialManageLabel  string `json:"FinancialManageLabel"`
}

type AccountInfo struct {
	CollectionAccount   bool      `json:"CollectionAccount"`
	AccountTierCN       string    `json:"AccountTierCN"`
	AccountTier         string    `json:"AccountTier"`
	AccountName         string    `json:"AccountName"`
	IndustryKey         string    `json:"IndustryKey"`
	IndustryDec         string    `json:"IndustryDec"`
	SubIndustryKey      string    `json:"SubIndustryKey"`
	SubIndustryDec      string    `json:"SubIndustryDec"`
	AccountNumber       string    `json:"AccountNumber"`
	ParentAccountNumber string    `json:"ParentAccountNumber"`
	OwnerInfo           OwnerInfo `json:"OwnerInfo"`
	PartnerCode         string    `json:"PartnerCode"`
}

type OwnerInfo struct {
	Id            string `json:"Id"`
	Name          string `json:"Name"`
	Email         string `json:"Email"`
	ShortRoleName string `json:"ShortRoleName"`
}

type JointPrintInfo struct {
	OpportunitySrcKey   string `json:"OpportunitySrcKey"`
	Support             bool   `json:"Support"`
	PrintSceneDec       string `json:"PrintSceneDec"`
	PrintSceneOppRole   string `json:"PrintSceneOppRole"`
	PrintSceneJointRole string `json:"PrintSceneJointRole"`
	CustomerOwnerRole   string `json:"CustomerOwnerRole"`
	Collaborator        string `json:"Collaborator"`
}

func (r *JointPrintInfo) Equal(jointData *model.JointPrintOrder) bool {
	return r.Support == jointData.Support &&
		r.PrintSceneDec == jointData.PrintSceneDec &&
		r.PrintSceneOppRole == jointData.PrintSceneOppRole &&
		r.PrintSceneJointRole == jointData.PrintSceneJointRole &&
		r.OpportunitySrcKey == jointData.OpportunitySrcKey &&
		r.CustomerOwnerRole == jointData.CustomerOwnerRole &&
		r.Collaborator == jointData.Collaborator
}

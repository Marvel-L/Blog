package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"context"
)

type VirtualOppNumberCheckReq struct {
	TradeType        multienv.TradeType `query:"TradeType"`
	VirtualOppNumber multienv.OppNumber `query:"VirtualOppNumber"`
}

type VirtualOppNumberCheckResp struct {
	CheckResult bool
}

func (r *VirtualOppNumberCheckReq) Handle(c context.Context) (interface{}, error) {
	checkResult, err := OppNumberWriteOff(r.VirtualOppNumber, r.TradeType)
	if err != nil {
		return nil, err
	}

	return &VirtualOppNumberCheckResp{CheckResult: checkResult}, nil
}

package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/passport_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"strconv"
	"testing"
)

func TestGetOpportunityInfoReq_Handle(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetOpportunityInfoReq).GetOpportunityInfo).Return(&OpportunityInfo{}, fmt.Errorf("your error")).Build()

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "",
			}
			got, err := v.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetOpportunityInfoReq).GetOpportunityInfo).Return(&OpportunityInfo{}, nil).Build()

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "1234",
			}
			got, err := v.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

}
func TestGetOpportunityInfoReq_GetOpportunityInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.AccountType("")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "",
				AccountType: v,
			}, fmt.Errorf("your error")).Build()
			mockey.Mock((constants.AccountType).Contains).Return(false).Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				ProjectServiceList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{&opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService).GetProjectName).Return("").Build()
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"": []string{""}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v1 := &GetOpportunityInfoReq{}
			_, err := v1.GetOpportunityInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.AccountType("")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "",
				AccountType: v,
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(true).Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				ProjectServiceList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{&opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService).GetProjectName).Return("").Build()
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"": []string{""}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v1 := &GetOpportunityInfoReq{}
			_, err := v1.GetOpportunityInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.AccountType("")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "",
				AccountType: v,
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(true).Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(nil, nil).Build()
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return(map[string]*passport_service.AccountSimpleInfo{"": &passport_service.AccountSimpleInfo{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService).GetProjectName).Return("").Build()
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"": []string{""}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v1 := &GetOpportunityInfoReq{}
			_, err := v1.GetOpportunityInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.AccountType("")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "",
				AccountType: v,
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(true).Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				ProjectServiceList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{&opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{}},
			}, nil).Build()
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return(map[string]*passport_service.AccountSimpleInfo{"": &passport_service.AccountSimpleInfo{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService).GetProjectName).Return("").Build()
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"": []string{""}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v1 := &GetOpportunityInfoReq{}
			_, err := v1.GetOpportunityInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.AccountType("")
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "",
				AccountType: v,
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(true).Build()
			var a = "1"
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				OppName:   &a,
				OppNumber: &a,
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
					{
						VolcanoName: &a,
						VolcanoId:   &a,
					},
				},
				PartnerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
					{
						VolcanoName: &a,
						VolcanoId:   &a,
					},
				},
				ProjectServiceList: []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{{
					ProjectName:           &a,
					ExternalProjectNumber: &a,
				}},
				AccountInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
					AccountName:   &a,
					AccountTier:   &a,
					AccountTierCN: &a,
				},
				PartnerInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
					AccountName:   &a,
					AccountTier:   &a,
					AccountTierCN: &a,
				},
			}, nil).Build()
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return(map[string]*passport_service.AccountSimpleInfo{"1": &passport_service.AccountSimpleInfo{
				AccountID:             1,
				CreateSource:          0,
				FinancialEntrustLabel: "",
				FinancialManageLabel:  "",
			}}, nil).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService).GetProjectName).Return("").Build()
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"": []string{""}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v1 := &GetOpportunityInfoReq{}
			_, err := v1.GetOpportunityInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func TestGetOpportunityInfoReq_getAccountInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"123": []string{"123"}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, fmt.Errorf("your error")).Build()

			// Act
			v := &GetOpportunityInfoReq{}
			var v1 string = "123"
			_, err := v.getAccountInfo(context.Background(), &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber:           &v1,
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
			})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{"123": []string{"123"}},
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, nil).Build()

			// Act
			v := &GetOpportunityInfoReq{}
			var v1 string = "123"
			_, err := v.getAccountInfo(context.Background(), &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber:           &v1,
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: nil,
			}).Build()
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{&passport_service.AccountSimpleInfo{
				AccountID: 0,
			}}, nil).Build()

			// Act
			v := &GetOpportunityInfoReq{}
			var v1 string = "123"
			_, err := v.getAccountInfo(context.Background(), &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber:           &v1,
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func TestGetOpportunityInfoReq_GetOppoName(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "OPP-123",
			}
			got := v.GetOppoName(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "")
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "123",
			}
			got := v.GetOppoName(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "123")
		})
	})
}

func TestGetOpportunityInfoReq_GetOppoNumber(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "OPP-123",
			}
			got := v.GetOppoNumber(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "OPP-123")
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &GetOpportunityInfoReq{
				OppKey: "123",
			}
			got := v.GetOppoNumber(context.Background())

			// Assert
			convey.So(got, convey.ShouldEqual, "")
		})
	})
}

func TestOpportunityInfo_GetJointPrintInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &OpportunityInfo{
				JointPrintInfo: &JointPrintInfo{},
			}
			var v1 string = ""
			var v2 string = ""
			var v3 bool = false
			var v4 string = ""
			var v5 string = ""
			var v6 string = ""
			var v7 string = ""
			v.GetJointPrintInfo(&opportunity.SearchOpportunityRelatedInfoForQuote{
				AccountInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
					OwnerInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
						ShortRoleName: &v1,
					},
				},
				OpportunitySourceKey: &v2,
				JointOppIsActive:     &v3,
				JointOppActiveInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteJointActiveInfo{
					JointOppScenesDec: &v4,
				},
				JointOppUserInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
					Email:         &v5,
					ShortRoleName: &v6,
				},
				OwnerInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
					ShortRoleName: &v7,
				},
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
}

func Test_convertAccountInfo_BitsUTGen(t *testing.T) {

	mockey.PatchConvey("Test_convertAccountInfo", t, func() {
		mockey.PatchConvey("成功场景 - 输入为非nil的完整结构体", func() {
			// 场景描述：
			// 当输入一个完整的opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo结构体时，验证目标函数能正确转换为AccountInfo结构体。
			// 数据构造：
			// - info: 一个完整的、所有字段都已赋值的opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo结构体实例。
			// 逻辑链路：
			// 1. 构造一个包含所有字段数据的info对象。
			// 2. 调用convertAccountInfo函数。
			// 3. 验证返回的AccountInfo对象的每个字段都与输入对象的相应字段值匹配。

			// 数据构造
			info := &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
				AccountName:       gptr.Of("Test Account"),
				AccountTier:       gptr.Of("Tier 1"),
				AccountTierCN:     gptr.Of("一级客户"),
				CollectionAccount: gptr.Of(true),
				OwnerInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
					Id:            gptr.Of("owner-123"),
					Name:          gptr.Of("John Doe"),
					Email:         gptr.Of("john.doe@example.com"),
					ShortRoleName: gptr.Of("AM"),
				},
				AccountNumber:       gptr.Of("ACC-001"),
				IndustryKey:         gptr.Of("tech"),
				IndustryDec:         gptr.Of("科技"),
				SubIndustryKey:      gptr.Of("cloud"),
				SubIndustryDec:      gptr.Of("云计算"),
				ParentAccountNumber: gptr.Of("PARENT-ACC-001"),
			}
			expected := &AccountInfo{
				CollectionAccount:   true,
				AccountTierCN:       "一级客户",
				AccountTier:         "Tier 1",
				AccountName:         "Test Account",
				IndustryKey:         "tech",
				IndustryDec:         "科技",
				SubIndustryKey:      "cloud",
				SubIndustryDec:      "云计算",
				AccountNumber:       "ACC-001",
				ParentAccountNumber: "PARENT-ACC-001",
				OwnerInfo: OwnerInfo{
					Id:            "owner-123",
					Name:          "John Doe",
					Email:         "john.doe@example.com",
					ShortRoleName: "AM",
				},
			}

			// 调用
			result := convertAccountInfo(info)

			// 断言
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景 - 输入为nil", func() {
			// 场景描述：
			// 当输入的info参数为nil时，验证目标函数能正确处理边界情况。
			// 数据构造：
			// - info: nil
			// 逻辑链路：
			// 1. 调用convertAccountInfo函数并传入nil。
			// 2. 验证返回值是否为nil。

			// 数据构造
			var info *opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo = nil

			// 调用
			result := convertAccountInfo(info)

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界场景 - 输入结构体部分字段为nil", func() {
			// 场景描述：
			// 当输入的info结构体中部分字段（包括嵌套的OwnerInfo）为nil时，验证目标函数能正确处理并返回相应字段的零值。
			// 数据构造：
			// - info: 一个部分字段为nil的opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo实例。
			// 逻辑链路：
			// 1. 构造一个部分字段为nil的info对象。
			// 2. 调用convertAccountInfo函数。
			// 3. 验证返回的AccountInfo对象中，对应nil字段的字段值是否为Go的零值。

			// 数据构造
			info := &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
				AccountName:       gptr.Of("Partial Account"),
				AccountNumber:     gptr.Of("ACC-002"),
				CollectionAccount: nil, // bool 零值为 false
				AccountTier:       nil, // string 零值为 ""
				OwnerInfo:         nil, // struct 零值
			}
			expected := &AccountInfo{
				CollectionAccount:   false,
				AccountTierCN:       "",
				AccountTier:         "",
				AccountName:         "Partial Account",
				IndustryKey:         "",
				IndustryDec:         "",
				SubIndustryKey:      "",
				SubIndustryDec:      "",
				AccountNumber:       "ACC-002",
				ParentAccountNumber: "",
				OwnerInfo: OwnerInfo{
					Id:            "",
					Name:          "",
					Email:         "",
					ShortRoleName: "",
				},
			}

			// 调用
			result := convertAccountInfo(info)

			// 断言
			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_GetOpportunityInfoReq_GetOpportunityInfo_BitsUTGen(t *testing.T) {
	t.Run("error when current user missing and IgnoreUser is false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock current user returns error
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return((*model.Account)(nil), errors.New("no user")).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: false}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("success path when current user type is not user", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock current user and Contains returning false
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "someone@example.com",
				AccountType: constants.AccountType("other"),
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(false).Build()

			// Mock c360 returns minimal oppInfo (account/partner info nil to cover those branches)
			opp := &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber: gptr.Of("OPP12345"),
				OppName:   gptr.Of("OppName-X"),
				// Empty lists to keep it simple
				CustomerVolcanoList:        []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{},
				PartnerVolcanoList:         []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{},
				PartnerCustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{},
				ProjectServiceList: []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{
					{ProjectName: gptr.Of("P1"), ExternalProjectNumber: gptr.Of("E1")},
				},
				AccountInfo: nil,
				PartnerInfo: nil,
			}
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, nil).Build()

			// Mock getAccountInfo returns empty map
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return(map[string]*passport_service.AccountSimpleInfo{}, nil).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: false}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.OppNumber, convey.ShouldEqual, "OPP12345")
			convey.So(resp.OppName, convey.ShouldEqual, "OppName-X")
			convey.So(len(resp.ProjectServiceList), convey.ShouldEqual, 1)
			convey.So(resp.AccountInfo, convey.ShouldNotBeNil) // stays as default initialized
			convey.So(resp.PartnerInfo, convey.ShouldBeNil)    // since partnerInfo was nil, not set
		})
	})

	t.Run("error when c360 service returns an error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock current user and Contains true
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(&model.Account{
				AccountID:   "user@example.com",
				AccountType: constants.AccountType("user"),
			}, nil).Build()
			mockey.Mock((constants.AccountType).Contains).Return(true).Build()

			// Mock c360 returns error
			mockey.Mock(c360service_client.GetOpportunityInfo).Return((*opportunity.SearchOpportunityRelatedInfoForQuote)(nil), errors.New("rpc error")).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: false, OppKey: "OPP-9988"}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("nil opportunity info returns nil result and nil error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Ignore user to skip user branch
			// Mock c360 returns nil, nil
			mockey.Mock(c360service_client.GetOpportunityInfo).Return((*opportunity.SearchOpportunityRelatedInfoForQuote)(nil), nil).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: true}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("error when getAccountInfo returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock c360 returns an oppInfo
			opp := &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber: gptr.Of("OPP-ERR"),
				OppName:   gptr.Of("ERR-Name"),
			}
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, nil).Build()

			// Mock getAccountInfo to return error
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return((map[string]*passport_service.AccountSimpleInfo)(nil), errors.New("fetch account error")).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: true}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("successful assembly with partner, customer, partner-customer lists and project/account/partner info", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Build complex oppInfo with lists and account/partner info populated
			oppOwnerRole := "OwnerRole"
			jointRole := "JointRole"
			email := "collab@test.com"
			sceneDec := "SceneDec"
			srcKey := "SRC_KEY"

			partnerDetails := []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
				{VolcanoId: gptr.Of("100"), VolcanoName: gptr.Of("pn100")},
				{VolcanoId: gptr.Of("200"), VolcanoName: gptr.Of("pn200")},
				{VolcanoId: gptr.Of("300"), VolcanoName: gptr.Of("pn300")},
			}
			customerDetails := []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
				{VolcanoId: gptr.Of("400"), VolcanoName: gptr.Of("cn400")},
				{VolcanoId: gptr.Of("500"), VolcanoName: gptr.Of("cn500")},
			}
			partnerCustomerDetails := []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
				{VolcanoId: gptr.Of("600"), VolcanoName: gptr.Of("pc600")},
				{VolcanoId: gptr.Of("700"), VolcanoName: gptr.Of("pc700")},
			}

			accOwner := &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
				Id:            gptr.Of("oid"),
				Name:          gptr.Of("oname"),
				Email:         gptr.Of("oemail"),
				ShortRoleName: gptr.Of("CustomerOwnerRole"),
			}
			accountInfo := &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
				AccountName:         gptr.Of("AccName"),
				AccountTier:         gptr.Of("TierA"),
				AccountTierCN:       gptr.Of("TierCN-A"),
				CollectionAccount:   gptr.Of(true),
				OwnerInfo:           accOwner,
				AccountNumber:       gptr.Of("AN-1"),
				IndustryKey:         gptr.Of("IK"),
				IndustryDec:         gptr.Of("ID"),
				SubIndustryKey:      gptr.Of("SIK"),
				SubIndustryDec:      gptr.Of("SID"),
				ParentAccountNumber: gptr.Of("PAN-1"),
				PartnerCode:         gptr.Of("PC-1"),
			}
			partnerInfo := &opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{
				AccountName:   gptr.Of("PartnerAcc"),
				AccountTier:   gptr.Of("PTier"),
				AccountTierCN: gptr.Of("PTierCN"),
				OwnerInfo: &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{
					Id:            gptr.Of("pid"),
					Name:          gptr.Of("pname"),
					Email:         gptr.Of("pemail"),
					ShortRoleName: gptr.Of("pShort"),
				},
			}

			opp := &opportunity.SearchOpportunityRelatedInfoForQuote{
				OppNumber:                  gptr.Of("OPP-SUCCESS"),
				OppName:                    gptr.Of("SuccessOpp"),
				PartnerVolcanoList:         partnerDetails,
				CustomerVolcanoList:        customerDetails,
				PartnerCustomerVolcanoList: partnerCustomerDetails,
				ProjectServiceList: []*opportunity.SearchOpportunityRelatedInfoForQuoteProjectService{
					{ProjectName: gptr.Of("Proj1"), ExternalProjectNumber: gptr.Of("Code1")},
					{ProjectName: gptr.Of("Proj2"), ExternalProjectNumber: gptr.Of("Code2")},
				},
				AccountInfo:          accountInfo,
				PartnerInfo:          partnerInfo,
				OwnerInfo:            &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{ShortRoleName: gptr.Of(oppOwnerRole)},
				JointOppUserInfo:     &opportunity.SearchOpportunityRelatedInfoForQuoteUserInfo{ShortRoleName: gptr.Of(jointRole), Email: gptr.Of(email)},
				JointOppActiveInfo:   &opportunity.SearchOpportunityRelatedInfoForQuoteJointActiveInfo{JointOppScenesDec: gptr.Of(sceneDec)},
				OpportunitySourceKey: gptr.Of(srcKey),
				JointOppIsActive:     gptr.Of(true),
			}

			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, nil).Build()

			// Account map: include true/false/missing cases to cover branches in loops
			accountMap := map[string]*passport_service.AccountSimpleInfo{
				"100": {AccountID: 100, CreateSource: 1, FinancialEntrustLabel: "E1", FinancialManageLabel: "M1", IsEnterpriseIdentity: true},
				"200": {AccountID: 200, CreateSource: 2, FinancialEntrustLabel: "E2", FinancialManageLabel: "M2", IsEnterpriseIdentity: false}, // should not append
				// "300" missing -> ok=false branch
				"400": {AccountID: 400, CreateSource: 3, FinancialEntrustLabel: "E3", FinancialManageLabel: "M3", IsEnterpriseIdentity: true},
				// "500" missing -> ok=false branch
				"600": {AccountID: 600, CreateSource: 4, FinancialEntrustLabel: "E4", FinancialManageLabel: "M4", IsEnterpriseIdentity: true},
				// "700" missing or false could be another no-append case
			}
			mockey.Mock((*GetOpportunityInfoReq).getAccountInfo).Return(accountMap, nil).Build()

			req := &GetOpportunityInfoReq{IgnoreUser: true}
			resp, err := req.GetOpportunityInfo(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			// Partner list: only "100" should be appended
			convey.So(len(resp.PartnerVolcanoList), convey.ShouldEqual, 1)
			convey.So(resp.PartnerVolcanoList[0].VolcanoId, convey.ShouldEqual, "100")
			convey.So(resp.PartnerVolcanoList[0].VolcanoName, convey.ShouldEqual, "pn100")
			convey.So(resp.PartnerVolcanoList[0].CreateSource, convey.ShouldEqual, 1)

			// Customer list: only "400" should be appended
			convey.So(len(resp.CustomerVolcanoList), convey.ShouldEqual, 1)
			convey.So(resp.CustomerVolcanoList[0].VolcanoId, convey.ShouldEqual, "400")
			convey.So(resp.CustomerVolcanoList[0].VolcanoName, convey.ShouldEqual, "cn400")

			// Partner-customer list: only "600" should be appended
			convey.So(len(resp.PartnerCustomerVolcanoList), convey.ShouldEqual, 1)
			convey.So(resp.PartnerCustomerVolcanoList[0].VolcanoId, convey.ShouldEqual, "600")
			convey.So(resp.PartnerCustomerVolcanoList[0].VolcanoName, convey.ShouldEqual, "pc600")

			// Account and partner info converted
			convey.So(resp.AccountInfo, convey.ShouldNotBeNil)
			convey.So(resp.AccountInfo.AccountName, convey.ShouldEqual, "AccName")
			convey.So(resp.PartnerInfo, convey.ShouldNotBeNil)
			convey.So(resp.PartnerInfo.AccountName, convey.ShouldEqual, "PartnerAcc")

			// Project service list
			convey.So(len(resp.ProjectServiceList), convey.ShouldEqual, 2)
			convey.So(resp.ProjectServiceList[0].ProjectName, convey.ShouldEqual, "Proj1")
			convey.So(resp.ProjectServiceList[0].ProjectCode, convey.ShouldEqual, "Code1")

			// Joint print info should be populated
			convey.So(resp.JointPrintInfo.Collaborator, convey.ShouldEqual, email)
			convey.So(resp.JointPrintInfo.PrintSceneOppRole, convey.ShouldEqual, oppOwnerRole)
			convey.So(resp.JointPrintInfo.PrintSceneJointRole, convey.ShouldEqual, jointRole)
			convey.So(resp.JointPrintInfo.PrintSceneDec, convey.ShouldEqual, sceneDec)
			convey.So(resp.JointPrintInfo.OpportunitySrcKey, convey.ShouldEqual, srcKey)
			convey.So(resp.JointPrintInfo.Support, convey.ShouldEqual, true)
			convey.So(resp.JointPrintInfo.CustomerOwnerRole, convey.ShouldEqual, "CustomerOwnerRole")
		})
	})
}

//go:noinline
func makeVolcanoDetail(id string) *opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail {
	d := opportunity.NewSearchOpportunityRelatedInfoForQuoteVolcanoDetail()
	d.VolcanoId = gptr.Of(id)
	return d
}

func Test_GetOpportunityInfoReq_getAccountInfo_BitsUTGen(t *testing.T) {
	t.Run("Whitelist matched returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock whitelist to hit whitelist branch
			mockey.MockUnsafe(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{
					"OPP_OK": {"101", "202"},
				},
			}).Build()
			// Mock passport service to return error
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return(nil, errors.New("mock error")).Build()

			req := &GetOpportunityInfoReq{}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP_OK")

			res, err := req.getAccountInfo(context.Background(), opp)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock error")
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("Whitelist matched returns success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock whitelist to hit whitelist branch
			mockey.MockUnsafe(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: map[string][]string{
					"OPP_OK": {"101", "202"},
				},
			}).Build()
			// Mock passport service to return valid list
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{
				{AccountID: uint64(101)},
				{AccountID: uint64(202)},
			}, nil).Build()

			req := &GetOpportunityInfoReq{}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP_OK")

			res, err := req.getAccountInfo(context.Background(), opp)
			convey.So(err, convey.ShouldBeNil)
			convey.So(res["101"], convey.ShouldNotBeNil)
			convey.So(res["202"], convey.ShouldNotBeNil)
			convey.So(res["101"].AccountID, convey.ShouldEqual, uint64(101))
			convey.So(res["202"].AccountID, convey.ShouldEqual, uint64(202))
		})
	})

	t.Run("Else branch with over maxAccountNum and success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock whitelist to non-match (else branch)
			mockey.MockUnsafe(config.GetWhiteListConf).Return(&config.WhiteListConf{
				OppAccountIDWhiteList: nil,
			}).Build()
			// Mock passport service to return valid list
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return([]*passport_service.AccountSimpleInfo{
				{AccountID: uint64(100)},
				{AccountID: uint64(200)},
			}, nil).Build()

			req := &GetOpportunityInfoReq{}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP_ELSE")

			// Build partner list with length > maxAccountNum to trigger break
			var partnerList []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail
			for i := 0; i < maxAccountNum+1; i++ {
				id := "acc-" + strconv.Itoa(i)
				partnerList = append(partnerList, &opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{
					VolcanoId: gptr.Of(id),
				})
			}
			opp.PartnerVolcanoList = partnerList

			res, err := req.getAccountInfo(context.Background(), opp)
			convey.So(err, convey.ShouldBeNil)
			convey.So(res["100"], convey.ShouldNotBeNil)
			convey.So(res["200"], convey.ShouldNotBeNil)
		})
	})

	t.Run("Else branch with empty lists returns empty map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock whitelist to nil to ensure else branch with empty accountList
			mockey.MockUnsafe(config.GetWhiteListConf).Return(nil).Build()
			// When AccountID is empty, passport service returns nil, nil
			mockey.Mock((*passport_service.ListAccountInfoReq).ListAccountSimpleInfo).Return(nil, nil).Build()

			req := &GetOpportunityInfoReq{}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP_EMPTY")

			res, err := req.getAccountInfo(context.Background(), opp)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})
	})
}

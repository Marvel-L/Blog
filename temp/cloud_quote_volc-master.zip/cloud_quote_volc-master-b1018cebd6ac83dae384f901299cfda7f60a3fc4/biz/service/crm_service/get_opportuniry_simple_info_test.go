package crm_service

import (
	"context"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetOpportunityInfoReq_GetOpportunitySimpleInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetAccountInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{}).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetCollectionAccount).Return(false).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail).GetVolcanoId).Return("").Build()

			// Act
			v := &GetOpportunityInfoReq{}
			_, err := v.GetOpportunitySimpleInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetOpportunityInfoReq).GetOppoNumber).Return("").Build()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuote{
				CustomerVolcanoList: []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
				PartnerVolcanoList:  []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{&opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{}},
			}, nil).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetOppNumber).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetAccountInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{}).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuote).GetPartnerInfo).Return(&opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo{}).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetCollectionAccount).Return(false).Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo).GetAccountTierCN).Return("").Build()
			mockey.Mock((*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail).GetVolcanoId).Return("").Build()

			// Act
			v := &GetOpportunityInfoReq{}
			_, err := v.GetOpportunitySimpleInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_GetOpportunityInfoReq_GetOpportunitySimpleInfo_BitsUTGen(t *testing.T) {
	t.Run("error when c360service_client.GetOpportunityInfo returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock RPC to return an error
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, errors.New("rpc failure")).Build()

			req := &GetOpportunityInfoReq{OppKey: "OPP-ERR-001"}
			resp, err := req.GetOpportunitySimpleInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("oppInfo is nil and function returns (nil, nil)", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock RPC to return nil info and nil error
			mockey.Mock(c360service_client.GetOpportunityInfo).Return((*opportunity.SearchOpportunityRelatedInfoForQuote)(nil), nil).Build()

			req := &GetOpportunityInfoReq{OppKey: "OPP-NIL-001"}
			resp, err := req.GetOpportunitySimpleInfo(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("success path: fills maps and converts account and partner info", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Build a full opportunity with account/partner info and volcano lists
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP-001")
			opp.OppName = gptr.Of("Opportunity Alpha")

			acc := opportunity.NewSearchOpportunityRelatedInfoForQuoteAccountInfo()
			acc.AccountNumber = gptr.Of("ACC-001")
			acc.AccountName = gptr.Of("Account One")
			acc.AccountTier = gptr.Of("Gold")
			acc.AccountTierCN = gptr.Of("黄金")
			acc.CollectionAccount = gptr.Of(true)
			acc.IndustryKey = gptr.Of("IK")
			acc.IndustryDec = gptr.Of("Industry Dec")
			acc.SubIndustryKey = gptr.Of("SIK")
			acc.SubIndustryDec = gptr.Of("SubIndustry Dec")
			acc.ParentAccountNumber = gptr.Of("PARENT-ACC-001")
			acc.PartnerCode = gptr.Of("PCODE-01")
			owner := opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			owner.Id = gptr.Of("USR-1")
			owner.Name = gptr.Of("Alice")
			owner.Email = gptr.Of("alice@example.com")
			owner.ShortRoleName = gptr.Of("Mgr")
			acc.OwnerInfo = owner
			opp.AccountInfo = acc

			pacc := opportunity.NewSearchOpportunityRelatedInfoForQuoteAccountInfo()
			pacc.AccountNumber = gptr.Of("P-ACC-001")
			pacc.AccountName = gptr.Of("Partner One")
			pacc.AccountTier = gptr.Of("Silver")
			pacc.AccountTierCN = gptr.Of("白银")
			pacc.CollectionAccount = gptr.Of(false)
			pacc.IndustryKey = gptr.Of("PIK")
			powner := opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			powner.Id = gptr.Of("USR-2")
			powner.Name = gptr.Of("Bob")
			pacc.OwnerInfo = powner
			opp.PartnerInfo = pacc

			parentAcc := opportunity.NewSearchOpportunityRelatedInfoForQuoteAccountInfo()
			parentAcc.AccountNumber = gptr.Of("PARENT-ACC-001")
			parentAcc.AccountName = gptr.Of("Parent Account")
			parentAcc.AccountTier = gptr.Of("Platinum")
			parentAcc.AccountTierCN = gptr.Of("铂金")
			parentAcc.CollectionAccount = gptr.Of(true)
			parentOwner := opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			parentOwner.Id = gptr.Of("USR-3")
			parentOwner.Name = gptr.Of("Carol")
			parentAcc.OwnerInfo = parentOwner
			opp.ParentAccountInfo = parentAcc

			vp1 := opportunity.NewSearchOpportunityRelatedInfoForQuoteVolcanoDetail()
			vp1.VolcanoId = gptr.Of("VP1")
			vp2 := opportunity.NewSearchOpportunityRelatedInfoForQuoteVolcanoDetail()
			vp2.VolcanoId = gptr.Of("VP2")
			vc1 := opportunity.NewSearchOpportunityRelatedInfoForQuoteVolcanoDetail()
			vc1.VolcanoId = gptr.Of("VC1")
			vpc1 := opportunity.NewSearchOpportunityRelatedInfoForQuoteVolcanoDetail()
			vpc1.VolcanoId = gptr.Of("VPC1")
			opp.PartnerVolcanoList = []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{vp1, vp2}
			opp.CustomerVolcanoList = []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{vc1}
			opp.PartnerCustomerVolcanoList = []*opportunity.SearchOpportunityRelatedInfoForQuoteVolcanoDetail{vpc1}

			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, nil).Build()

			req := &GetOpportunityInfoReq{OppKey: "OPP-001"}
			resp, err := req.GetOpportunitySimpleInfo(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.OppNumber, convey.ShouldEqual, "OPP-001")
			convey.So(resp.OppName, convey.ShouldEqual, "Opportunity Alpha")

			// AccountInfo assertions
			convey.So(resp.AccountInfo, convey.ShouldNotBeNil)
			convey.So(resp.AccountInfo.AccountNumber, convey.ShouldEqual, "ACC-001")
			convey.So(resp.AccountInfo.AccountName, convey.ShouldEqual, "Account One")
			convey.So(resp.AccountInfo.AccountTier, convey.ShouldEqual, "Gold")
			convey.So(resp.AccountInfo.AccountTierCN, convey.ShouldEqual, "黄金")
			convey.So(resp.AccountInfo.CollectionAccount, convey.ShouldEqual, true)
			convey.So(resp.AccountInfo.OwnerInfo.Id, convey.ShouldEqual, "USR-1")
			convey.So(resp.AccountInfo.OwnerInfo.Name, convey.ShouldEqual, "Alice")

			// PartnerInfo assertions
			convey.So(resp.PartnerInfo, convey.ShouldNotBeNil)
			convey.So(resp.PartnerInfo.AccountNumber, convey.ShouldEqual, "P-ACC-001")
			convey.So(resp.PartnerInfo.AccountName, convey.ShouldEqual, "Partner One")

			// ParentAccountInfo assertions
			convey.So(resp.ParentAccountInfo, convey.ShouldNotBeNil)
			convey.So(resp.ParentAccountInfo.AccountNumber, convey.ShouldEqual, "PARENT-ACC-001")
			convey.So(resp.ParentAccountInfo.AccountName, convey.ShouldEqual, "Parent Account")
			convey.So(resp.ParentAccountInfo.AccountTier, convey.ShouldEqual, "Platinum")
			convey.So(resp.ParentAccountInfo.AccountTierCN, convey.ShouldEqual, "铂金")
			convey.So(resp.ParentAccountInfo.CollectionAccount, convey.ShouldEqual, true)
			convey.So(resp.ParentAccountInfo.OwnerInfo.Id, convey.ShouldEqual, "USR-3")
			convey.So(resp.ParentAccountInfo.OwnerInfo.Name, convey.ShouldEqual, "Carol")

			// Volcano maps assertions
			convey.So(resp.PartnerVolcanoMap["VP1"], convey.ShouldBeTrue)
			convey.So(resp.PartnerVolcanoMap["VP2"], convey.ShouldBeTrue)
			convey.So(resp.CustomerVolcanoMap["VC1"], convey.ShouldBeTrue)
			convey.So(resp.PartnerCustomerVolcanoMap["VPC1"], convey.ShouldBeTrue)
		})
	})

	t.Run("success path: no account/partner info (both nil)", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OppNumber = gptr.Of("OPP-EMPTY")
			opp.OppName = gptr.Of("Empty Info")
			opp.AccountInfo = nil
			opp.PartnerInfo = nil
			// No volcano entries
			opp.PartnerVolcanoList = nil
			opp.CustomerVolcanoList = nil
			opp.PartnerCustomerVolcanoList = nil

			mockey.Mock(c360service_client.GetOpportunityInfo).Return(opp, nil).Build()

			req := &GetOpportunityInfoReq{OppKey: "OPP-EMPTY"}
			resp, err := req.GetOpportunitySimpleInfo(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.AccountInfo, convey.ShouldBeNil)
			convey.So(resp.PartnerInfo, convey.ShouldBeNil)
			convey.So(len(resp.PartnerVolcanoMap), convey.ShouldEqual, 0)
			convey.So(len(resp.CustomerVolcanoMap), convey.ShouldEqual, 0)
			convey.So(len(resp.PartnerCustomerVolcanoMap), convey.ShouldEqual, 0)
		})
	})
}

func TestOpportunitySimpleInfo_GetJointPrintInfo(t *testing.T) {
	t.Run("字段完整时写入联合打印信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &OpportunitySimpleInfo{
				JointPrintInfo: &JointPrintInfo{},
			}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OpportunitySourceKey = gptr.Of("source-key")
			opp.JointOppIsActive = gptr.Of(true)

			opp.OwnerInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.OwnerInfo.ShortRoleName = gptr.Of("主协同")

			opp.JointOppUserInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.JointOppUserInfo.ShortRoleName = gptr.Of("联合角色")
			opp.JointOppUserInfo.Email = gptr.Of("joint@example.com")

			opp.AccountInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteAccountInfo()
			opp.AccountInfo.OwnerInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.AccountInfo.OwnerInfo.ShortRoleName = gptr.Of("客户负责人")

			opp.JointOppActiveInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteJointActiveInfo()
			opp.JointOppActiveInfo.JointOppScenesDec = gptr.Of("联合场景")

			resp.GetJointPrintInfo(opp)

			convey.So(resp.JointPrintInfo.PrintSceneOppRole, convey.ShouldEqual, "主协同")
			convey.So(resp.JointPrintInfo.PrintSceneJointRole, convey.ShouldEqual, "联合角色")
			convey.So(resp.JointPrintInfo.Collaborator, convey.ShouldEqual, "joint@example.com")
			convey.So(resp.JointPrintInfo.CustomerOwnerRole, convey.ShouldEqual, "客户负责人")
			convey.So(resp.JointPrintInfo.PrintSceneDec, convey.ShouldEqual, "联合场景")
			convey.So(resp.JointPrintInfo.OpportunitySrcKey, convey.ShouldEqual, "source-key")
			convey.So(resp.JointPrintInfo.Support, convey.ShouldBeTrue)
		})
	})

	t.Run("字段缺失时保留默认值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &OpportunitySimpleInfo{
				JointPrintInfo: &JointPrintInfo{
					OpportunitySrcKey:   "keep-source",
					Support:             true,
					PrintSceneDec:       "keep-scene",
					PrintSceneOppRole:   "keep-opp-role",
					PrintSceneJointRole: "keep-joint-role",
					CustomerOwnerRole:   "keep-customer-role",
					Collaborator:        "keep-collaborator",
				},
			}
			opp := opportunity.NewSearchOpportunityRelatedInfoForQuote()
			opp.OwnerInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.JointOppUserInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.AccountInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteAccountInfo()
			opp.AccountInfo.OwnerInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteUserInfo()
			opp.JointOppActiveInfo = opportunity.NewSearchOpportunityRelatedInfoForQuoteJointActiveInfo()

			resp.GetJointPrintInfo(opp)

			convey.So(resp.JointPrintInfo.OpportunitySrcKey, convey.ShouldEqual, "keep-source")
			convey.So(resp.JointPrintInfo.Support, convey.ShouldBeTrue)
			convey.So(resp.JointPrintInfo.PrintSceneDec, convey.ShouldEqual, "keep-scene")
			convey.So(resp.JointPrintInfo.PrintSceneOppRole, convey.ShouldEqual, "keep-opp-role")
			convey.So(resp.JointPrintInfo.PrintSceneJointRole, convey.ShouldEqual, "keep-joint-role")
			convey.So(resp.JointPrintInfo.CustomerOwnerRole, convey.ShouldEqual, "keep-customer-role")
			convey.So(resp.JointPrintInfo.Collaborator, convey.ShouldEqual, "keep-collaborator")
		})
	})
}

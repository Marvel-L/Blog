package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/prmcontract_client"
	"context"
)

type ListPartnerContractReq struct {
	PartnerAccountID string `query:"PartnerAccountID"`
	PartnerName      string `query:"PartnerName"`
	Limit            int    `query:"Limit"`
	Offset           int    `query:"Offset"`
}

func (r *ListPartnerContractReq) Handle(c context.Context) (interface{}, error) {
	//req := &prmclient.GetContractListReq{
	//	AccountID:      r.PartnerAccountID,
	//	PartnerName:    r.PartnerName,
	//	Limit:          r.Limit,
	//	Offset:         r.Offset,
	//	ContractType:   1, //1 分销合同
	//	ContractStatus: 2, // 2 已归档
	//}
	//
	//listResult, err := prm_client.GetContractList(c, req)
	//if err != nil {
	//	return nil, err
	//}
	listResult, err := prmcontract_client.GetContractList(c, r.PartnerAccountID, r.PartnerName, r.Limit, r.Offset)
	if err != nil {
		return nil, err
	}
	return listResult, nil
}

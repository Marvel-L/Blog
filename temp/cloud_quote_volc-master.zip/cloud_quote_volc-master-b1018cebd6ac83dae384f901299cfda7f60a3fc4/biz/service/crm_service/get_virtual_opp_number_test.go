package crm_service

import (
	dal "code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	errors "errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	gorm "gorm.io/gorm"
	"testing"
)

func Test_GetMaxOppIDFromDB_BitsUTGen(t *testing.T) {
	t.Run("DAO returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Initialize global DBProxy and mock NewRequest to return a dummy *gorm.DB
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			dummyDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(dummyDB).Build()

			// Mock DAO method to return an error
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindMaxOpportunityIDByPrefix")).Return("", errors.New("db failed")).Build()

			ctx := context.Background()
			res, err := GetMaxOppIDFromDB(ctx, "V")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db failed")
			convey.So(res, convey.ShouldEqual, int64(0))
		})
	})

	t.Run("No max opp ID in DB returns internal API error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Initialize global DBProxy and mock NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			dummyDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(dummyDB).Build()

			// Mock DAO method to return empty string without error
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindMaxOpportunityIDByPrefix")).Return("", nil).Build()

			ctx := context.Background()
			res, err := GetMaxOppIDFromDB(ctx, "V")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "数据库中无虚拟商机记录")
			convey.So(res, convey.ShouldEqual, int64(0))
		})
	})

	t.Run("ParseInt error when maxOppID suffix is not numeric", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Initialize global DBProxy and mock NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			dummyDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(dummyDB).Build()

			// Mock DAO method to return a non-numeric suffix
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindMaxOpportunityIDByPrefix")).Return("Vbad", nil).Build()

			ctx := context.Background()
			res, err := GetMaxOppIDFromDB(ctx, "V")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "invalid syntax")
			convey.So(res, convey.ShouldEqual, int64(0))
		})
	})

	t.Run("Success: returns next incremental count", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Initialize global DBProxy and mock NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			dummyDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(dummyDB).Build()

			// Mock DAO method to return a valid numeric suffix
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindMaxOpportunityIDByPrefix")).Return("V00000008", nil).Build()

			ctx := context.Background()
			res, err := GetMaxOppIDFromDB(ctx, "V")
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldEqual, int64(9))
		})
	})
}

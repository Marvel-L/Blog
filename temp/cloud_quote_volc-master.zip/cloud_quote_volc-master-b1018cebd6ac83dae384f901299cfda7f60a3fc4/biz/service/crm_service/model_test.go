package crm_service

import (
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestJointPrintInfo_Equal(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &JointPrintInfo{
				OpportunitySrcKey:   "",
				Support:             false,
				PrintSceneDec:       "",
				PrintSceneOppRole:   "",
				PrintSceneJointRole: "",
				CustomerOwnerRole:   "",
				Collaborator:        "",
			}
			got := v.Equal(&model.JointPrintOrder{
				OpportunitySrcKey:   "",
				Support:             false,
				PrintSceneDec:       "",
				PrintSceneOppRole:   "",
				PrintSceneJointRole: "",
				CustomerOwnerRole:   "",
				Collaborator:        "",
			})

			// Assert
			convey.So(got, convey.ShouldEqual, true)
		})
	})
}

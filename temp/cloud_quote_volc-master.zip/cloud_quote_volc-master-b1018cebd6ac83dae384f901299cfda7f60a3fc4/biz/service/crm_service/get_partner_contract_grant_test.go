package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/prmcontract_client"
	"code.byted.org/overpass/eps_platform_eco_prm_contract/kitex_gen/eps/platform/eco_prm_contract"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestGetPartnerGrantReq_Handle(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetPartnerGrantReq).GetPartnerGrant).Return(map[int32]*PartnerGrant{0: &PartnerGrant{}}, fmt.Errorf("your error")).Build()

			// Act
			v := &GetPartnerGrantReq{
				PartnerName: "",
			}
			_, err := v.Handle(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetPartnerGrantReq).GetPartnerGrant).Return(map[int32]*PartnerGrant{0: &PartnerGrant{}}, fmt.Errorf("your error")).Build()

			// Act
			v := &GetPartnerGrantReq{
				PartnerName: "123",
			}
			_, err := v.Handle(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*GetPartnerGrantReq).GetPartnerGrant).Return(map[int32]*PartnerGrant{0: &PartnerGrant{}}, nil).Build()

			// Act
			v := &GetPartnerGrantReq{
				PartnerName: "123",
			}
			_, err := v.Handle(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}
func TestGetPartnerGrantReq_GetPartnerGrant(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(prmcontract_client.ListContractGrant).Return(&eco_prm_contract.ListContractGrantResponse{
				Grants: []*eco_prm_contract.ContractGrantListResp{&eco_prm_contract.ContractGrantListResp{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "",
						PartnerCode: "",
						PartnerName: "",
					},
					ContractNo:          "",
					PartnerContractType: "",
					GrantType:           "",
					ValidatedTime:       0,
					InvalidatedTime:     0,
					GrantStatus:         "",
					GrantTypeEnum:       0,
				}},
			}, fmt.Errorf("your error")).Build()

			// Act
			v := &GetPartnerGrantReq{
				PartnerName: "",
			}
			_, err := v.GetPartnerGrant(context.Background())

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(prmcontract_client.ListContractGrant).Return(&eco_prm_contract.ListContractGrantResponse{
				Grants: []*eco_prm_contract.ContractGrantListResp{&eco_prm_contract.ContractGrantListResp{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "",
						PartnerCode: "",
						PartnerName: "",
					},
					ContractNo:          "",
					PartnerContractType: "",
					GrantType:           "",
					ValidatedTime:       0,
					InvalidatedTime:     0,
					GrantStatus:         "",
					GrantTypeEnum:       0,
				}},
			}, nil).Build()

			// Act
			v := &GetPartnerGrantReq{
				PartnerName: "",
			}
			_, err := v.GetPartnerGrant(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_GetPartnerGrantReq_GetPartnerGrant_BitsUTGen(t *testing.T) {
	t.Run("RPC error returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock RPC to return error to cover early return path
			mockey.Mock(prmcontract_client.ListContractGrant).Return(&eco_prm_contract.ListContractGrantResponse{
				Grants: []*eco_prm_contract.ContractGrantListResp{},
			}, errors.New("rpc failed")).Build()

			req := &GetPartnerGrantReq{PartnerCode: "CODE-ERROR"}
			_, err := req.GetPartnerGrant(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("Successful aggregation with multiple branches, duplicates and zero-time contracts", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Prepare grants to hit:
			// - new grant type creation
			// - partner present and nil partner
			// - new partner and existing partner (partnerOk true/false)
			// - new contract and duplicate contract (contractOk true/false)
			// - min/max time calculation including zero-time contract to trigger continue path
			grants := []*eco_prm_contract.ContractGrantListResp{
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P1",
						PartnerCode: "PC1",
						PartnerName: "PN1",
					},
					ContractNo:          "C1",
					PartnerContractType: "CT1",
					GrantType:           "TypeA",
					ValidatedTime:       5,
					InvalidatedTime:     10,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(100),
				},
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P1",
						PartnerCode: "PC1",
						PartnerName: "PN1",
					},
					ContractNo:          "C2",
					PartnerContractType: "CT2",
					GrantType:           "TypeA",
					ValidatedTime:       3,
					InvalidatedTime:     12,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(100),
				},
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P1",
						PartnerCode: "PC1",
						PartnerName: "PN1",
					},
					ContractNo:          "C2", // duplicate contract to hit contractOk true path
					PartnerContractType: "CT2",
					GrantType:           "TypeA",
					ValidatedTime:       3,
					InvalidatedTime:     12,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(100),
				},
				{
					Partner:             nil, // nil partner branch
					ContractNo:          "C-NIL",
					PartnerContractType: "CT-NIL",
					GrantType:           "TypeB",
					ValidatedTime:       20,
					InvalidatedTime:     30,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(200),
				},
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P1",
						PartnerCode: "PC1",
						PartnerName: "PN1",
					},
					ContractNo:          "C3", // zero times to hit logs and continue
					PartnerContractType: "CT3",
					GrantType:           "TypeA",
					ValidatedTime:       0,
					InvalidatedTime:     0,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(100),
				},
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P1",
						PartnerCode: "PC1",
						PartnerName: "PN1",
					},
					ContractNo:          "C4", // larger than min, smaller than max to hit false branches
					PartnerContractType: "CT4",
					GrantType:           "TypeA",
					ValidatedTime:       7,
					InvalidatedTime:     8,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(100),
				},
			}

			mockey.Mock(prmcontract_client.ListContractGrant).Return(&eco_prm_contract.ListContractGrantResponse{
				Grants: grants,
			}, nil).Build()

			req := &GetPartnerGrantReq{PartnerCode: "CODE-SUCCESS"}
			grantMap, err := req.GetPartnerGrant(context.Background())
			convey.So(err, convey.ShouldBeNil)

			// Validate grant type 100 aggregation
			g100, ok100 := grantMap[int32(100)]
			convey.So(ok100, convey.ShouldBeTrue)
			convey.So(g100.GrantType, convey.ShouldEqual, "TypeA")
			convey.So(len(g100.PartnerList), convey.ShouldEqual, 1)
			// C1, C2, C3 (zero-time but added), C4 should be present; duplicate C2 should be skipped
			convey.So(len(g100.PartnerList[0].PartnerContractList), convey.ShouldEqual, 4)
			convey.So(g100.ValidatedTime, convey.ShouldEqual, int64(3))    // min of 5,3,7
			convey.So(g100.InvalidatedTime, convey.ShouldEqual, int64(12)) // max of 10,12,8

			// Validate grant type 200 with nil partner
			g200, ok200 := grantMap[int32(200)]
			convey.So(ok200, convey.ShouldBeTrue)
			convey.So(g200.GrantType, convey.ShouldEqual, "TypeB")
			convey.So(len(g200.PartnerList), convey.ShouldEqual, 0)       // nil partner results in no PartnerList entries
			convey.So(g200.ValidatedTime, convey.ShouldEqual, int64(0))   // no contracts processed
			convey.So(g200.InvalidatedTime, convey.ShouldEqual, int64(0)) // no contracts processed
		})
	})

	t.Run("Uses PartnerName when code is empty and computes times", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Simple successful case to cover the PartnerName branch
			grants := []*eco_prm_contract.ContractGrantListResp{
				{
					Partner: &eco_prm_contract.Partner{
						PassportID:  "P2",
						PartnerCode: "PC2",
						PartnerName: "Partner-Name-Only",
					},
					ContractNo:          "CA",
					PartnerContractType: "CTA",
					GrantType:           "TypeC",
					ValidatedTime:       2,
					InvalidatedTime:     9,
					GrantStatus:         "Active",
					GrantTypeEnum:       int32(300),
				},
			}
			mockey.Mock(prmcontract_client.ListContractGrant).Return(&eco_prm_contract.ListContractGrantResponse{
				Grants: grants,
			}, nil).Build()

			req := &GetPartnerGrantReq{PartnerName: "Partner-Name-Only"}
			grantMap, err := req.GetPartnerGrant(context.Background())
			convey.So(err, convey.ShouldBeNil)

			g300, ok := grantMap[int32(300)]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(g300.GrantType, convey.ShouldEqual, "TypeC")
			convey.So(g300.ValidatedTime, convey.ShouldEqual, int64(2))
			convey.So(g300.InvalidatedTime, convey.ShouldEqual, int64(9))
		})
	})
}

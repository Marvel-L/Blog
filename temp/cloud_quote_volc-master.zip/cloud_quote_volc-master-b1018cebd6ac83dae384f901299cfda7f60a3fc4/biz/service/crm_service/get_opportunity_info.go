package crm_service

import (
	"context"
	"strconv"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/passport_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

const maxAccountNum = 50

type GetOpportunityInfoReq struct {
	OppKey     string `query:"OppKey"`
	IgnoreUser bool
}

func (r *GetOpportunityInfoReq) Handle(c context.Context) (interface{}, error) {
	if r.OppKey == "" {
		return nil, nil
	}
	return r.GetOpportunityInfo(c)
}

func (r *GetOpportunityInfoReq) GetOpportunityInfo(c context.Context) (*OpportunityInfo, error) {
	oppUser := ""
	if !r.IgnoreUser {
		currentUser, apiErr := dal.AccountDao.CurrentUser(c)
		if apiErr != nil {
			return nil, errors.ErrInternalError.WithArgs(apiErr)
		}
		if currentUser.AccountType.Contains(constants.AccountTypeUser) {
			oppUser = currentUser.AccountID
		}
	}
	oppInfo, err := c360service_client.GetOpportunityInfo(c, r.GetOppoNumber(c), r.GetOppoName(c), oppUser)
	if err != nil {
		return nil, errors.ErrInternalError.WithArgs(err.Error())
	}
	if oppInfo == nil {
		return nil, nil
	}
	accountSimpleInfoMap, err := r.getAccountInfo(c, oppInfo)
	if err != nil {
		return nil, err
	}
	respOpp := &OpportunityInfo{
		OppNumber:      oppInfo.GetOppNumber(),
		OppName:        oppInfo.GetOppName(),
		AccountInfo:    &AccountInfo{},
		JointPrintInfo: &JointPrintInfo{},
	}

	var partnerInfoList []*DomainInfo
	for _, partnerInfo := range oppInfo.PartnerVolcanoList {
		partnerAccount, ok := accountSimpleInfoMap[partnerInfo.GetVolcanoId()]
		if ok && partnerAccount.IsEnterpriseIdentity {
			partnerInfoList = append(partnerInfoList, &DomainInfo{
				VolcanoName:           partnerInfo.GetVolcanoName(),
				VolcanoId:             partnerInfo.GetVolcanoId(),
				CreateSource:          partnerAccount.CreateSource,
				FinancialEntrustLabel: partnerAccount.FinancialEntrustLabel,
				FinancialManageLabel:  partnerAccount.FinancialManageLabel,
			})
		}
	}
	respOpp.PartnerVolcanoList = partnerInfoList
	var customerInfoList []*DomainInfo
	for _, customerInfo := range oppInfo.CustomerVolcanoList {
		customerAccount, ok := accountSimpleInfoMap[customerInfo.GetVolcanoId()]
		if ok && customerAccount.IsEnterpriseIdentity {
			customerInfoList = append(customerInfoList, &DomainInfo{
				VolcanoName:           customerInfo.GetVolcanoName(),
				VolcanoId:             customerInfo.GetVolcanoId(),
				CreateSource:          customerAccount.CreateSource,
				FinancialEntrustLabel: customerAccount.FinancialEntrustLabel,
				FinancialManageLabel:  customerAccount.FinancialManageLabel,
			})

		}
	}
	respOpp.CustomerVolcanoList = customerInfoList
	var partnerCustomerInfoList []*DomainInfo
	for _, partnerCustomerInfo := range oppInfo.PartnerCustomerVolcanoList {
		partnerCustomerAccount, ok := accountSimpleInfoMap[partnerCustomerInfo.GetVolcanoId()]
		if ok && partnerCustomerAccount.IsEnterpriseIdentity {
			partnerCustomerInfoList = append(partnerCustomerInfoList, &DomainInfo{
				VolcanoName:           partnerCustomerInfo.GetVolcanoName(),
				VolcanoId:             partnerCustomerInfo.GetVolcanoId(),
				CreateSource:          partnerCustomerAccount.CreateSource,
				FinancialEntrustLabel: partnerCustomerAccount.FinancialEntrustLabel,
				FinancialManageLabel:  partnerCustomerAccount.FinancialManageLabel,
			})
		}
	}
	respOpp.PartnerCustomerVolcanoList = partnerCustomerInfoList
	accountInfo := oppInfo.GetAccountInfo()
	if accountInfo != nil {
		respOpp.AccountInfo = convertAccountInfo(accountInfo)
	}
	partnerInfo := oppInfo.GetPartnerInfo()
	if partnerInfo != nil {
		respOpp.PartnerInfo = convertAccountInfo(partnerInfo)
	}

	var projectServiceList []*ProjectInfo
	for _, projectInfo := range oppInfo.ProjectServiceList {
		projectServiceList = append(projectServiceList, &ProjectInfo{
			ProjectName: projectInfo.GetProjectName(),
			ProjectCode: projectInfo.GetExternalProjectNumber(),
		})
	}
	respOpp.ProjectServiceList = projectServiceList

	respOpp.GetJointPrintInfo(oppInfo)
	return respOpp, nil
}

func (r *GetOpportunityInfoReq) getAccountInfo(c context.Context, oppInfo *opportunity.SearchOpportunityRelatedInfoForQuote) (map[string]*passport_service.AccountSimpleInfo, error) {

	var (
		accountList        []string
		accountIDMap       = map[string]bool{}
		matchWhiteList     = false
		accountIDWhiteList []string
	)
	whiteListConf := config.GetWhiteListConf(c)
	// 商机白名单判断
	oppNumber := oppInfo.GetOppNumber()
	if whiteListConf != nil {
		accountIDWhiteList, matchWhiteList = whiteListConf.OppAccountIDWhiteList[oppNumber]
	}
	if matchWhiteList && len(accountIDWhiteList) != 0 {
		logs.CtxInfo(c, "[SearchOpportunityInfo]getAccountInfo hit OppAccountIDWhiteList, OppNumber:%s, OppAccountIDWhiteList:%v", oppNumber, accountIDWhiteList)
		accountList = append(accountList, accountIDWhiteList...)
	} else {
		for i, partnerInfo := range oppInfo.PartnerVolcanoList {
			// 性能问题，最多只返回maxAccountNum 账号信息
			if i == maxAccountNum {
				break
			}
			accountIDMap[partnerInfo.GetVolcanoId()] = true
		}
		for i, customerInfo := range oppInfo.CustomerVolcanoList {
			// 性能问题，最多只返回maxAccountNum 账号信息
			if i == maxAccountNum {
				break
			}
			accountIDMap[customerInfo.GetVolcanoId()] = true
		}
		for i, partnerCustomerInfo := range oppInfo.PartnerCustomerVolcanoList {
			// 性能问题，最多只返回maxAccountNum 账号信息
			if i == maxAccountNum {
				break
			}
			accountIDMap[partnerCustomerInfo.GetVolcanoId()] = true
		}
		for accountID, _ := range accountIDMap {
			accountList = append(accountList, accountID)
		}
	}
	accountInfoReq := &passport_service.ListAccountInfoReq{
		AccountID: strings.Join(accountList, ","),
	}
	accountSimpleInfoList, err := accountInfoReq.ListAccountSimpleInfo(c)
	if err != nil {
		return nil, err
	}

	accountSimpleInfoMap := map[string]*passport_service.AccountSimpleInfo{}
	for _, accountSimpleInfo := range accountSimpleInfoList {
		accountSimpleInfoMap[strconv.FormatUint(accountSimpleInfo.AccountID, 10)] = accountSimpleInfo
	}
	return accountSimpleInfoMap, nil
}

func (r *GetOpportunityInfoReq) GetOppoName(c context.Context) string {
	if strings.HasPrefix(r.OppKey, multienv.OppNumberPrefix) {
		return ""
	} else {
		return r.OppKey
	}
}

func (r *GetOpportunityInfoReq) GetOppoNumber(c context.Context) string {
	if strings.HasPrefix(r.OppKey, multienv.OppNumberPrefix) {
		return r.OppKey
	} else {
		return ""
	}
}

func (r *OpportunityInfo) GetJointPrintInfo(oppInfo *opportunity.SearchOpportunityRelatedInfoForQuote) {
	if oppInfo.OwnerInfo != nil && oppInfo.OwnerInfo.ShortRoleName != nil {
		r.JointPrintInfo.PrintSceneOppRole = *oppInfo.OwnerInfo.ShortRoleName
	}
	if oppInfo.JointOppUserInfo != nil {
		if oppInfo.JointOppUserInfo.ShortRoleName != nil {
			r.JointPrintInfo.PrintSceneJointRole = *oppInfo.JointOppUserInfo.ShortRoleName
		}
		if oppInfo.JointOppUserInfo.Email != nil {
			r.JointPrintInfo.Collaborator = *oppInfo.JointOppUserInfo.Email
		}
	}
	if oppInfo.AccountInfo != nil && oppInfo.AccountInfo.OwnerInfo != nil && oppInfo.AccountInfo.OwnerInfo.ShortRoleName != nil {
		r.JointPrintInfo.CustomerOwnerRole = *oppInfo.AccountInfo.OwnerInfo.ShortRoleName
	}
	if oppInfo.JointOppActiveInfo != nil && oppInfo.JointOppActiveInfo.JointOppScenesDec != nil {
		r.JointPrintInfo.PrintSceneDec = *oppInfo.JointOppActiveInfo.JointOppScenesDec
	}
	if oppInfo.OpportunitySourceKey != nil {
		r.JointPrintInfo.OpportunitySrcKey = *oppInfo.OpportunitySourceKey
	}
	if oppInfo.JointOppIsActive != nil {
		r.JointPrintInfo.Support = *oppInfo.JointOppIsActive
	}

}

func convertAccountInfo(info *opportunity.SearchOpportunityRelatedInfoForQuoteAccountInfo) *AccountInfo {
	if info == nil {
		return nil
	}
	return &AccountInfo{
		CollectionAccount:   info.GetCollectionAccount(),
		AccountTierCN:       info.GetAccountTierCN(),
		AccountTier:         info.GetAccountTier(),
		AccountName:         info.GetAccountName(),
		IndustryKey:         info.GetIndustryKey(),
		IndustryDec:         info.GetIndustryDec(),
		SubIndustryKey:      info.GetSubIndustryKey(),
		SubIndustryDec:      info.GetSubIndustryDec(),
		AccountNumber:       info.GetAccountNumber(),
		ParentAccountNumber: info.GetParentAccountNumber(),
		OwnerInfo: OwnerInfo{
			Id:            info.GetOwnerInfo().GetId(),
			Name:          info.GetOwnerInfo().GetName(),
			Email:         info.GetOwnerInfo().GetEmail(),
			ShortRoleName: info.GetOwnerInfo().GetShortRoleName(),
		},
		PartnerCode: info.GetPartnerCode(),
	}
}

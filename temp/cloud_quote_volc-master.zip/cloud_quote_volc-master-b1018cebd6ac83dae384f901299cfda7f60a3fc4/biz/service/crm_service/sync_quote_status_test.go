package crm_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/crmclient"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/salesforce_sdk"
	gorm "code.byted.org/gopkg/gorm/v2"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	gorm1 "gorm.io/gorm"
	"testing"
)

func TestQuoteStatusCallbackV2(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				AppAccountID: "",
			}, nil).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return("").Build()
			mockey.Mock((*model.Quote).IsConfigList).Return(false).Build()
			mockey.Mock(crmclient.ConfigListStatusCallbackV2).Return(nil).Build()
			mockey.Mock(crmclient.QuoteStatusCallbackV2).Return(nil).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			err := QuoteStatusCallbackV2(context.Background(), 0, salesforce_sdk.QuoteStatusCallbackReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{
				BaseDB: framework.BaseDB{
					Id: 0,
				},
				AppAccountID: "",
			}, nil).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return("").Build()
			mockey.Mock((*model.Quote).IsConfigList).Return(true).Build()
			mockey.Mock(crmclient.ConfigListStatusCallbackV2).Return(nil).Build()
			mockey.Mock(crmclient.QuoteStatusCallbackV2).Return(nil).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			err := QuoteStatusCallbackV2(context.Background(), 0, salesforce_sdk.QuoteStatusCallbackReq{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_CreateCrmQuote_BitsUTGen(t *testing.T) {
	t.Run("non partner account returns immediately", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				BaseDB:       framework.BaseDB{Id: 10},
				AppAccountID: "other_account",
			}

			getCalled := false
			mockey.Mock((*model.Quote).GetProductType).To(func(q *model.Quote, c context.Context) ([]int, error) {
				getCalled = true
				return []int{1}, nil
			}).Build()

			createCalled := false
			mockey.Mock(crmclient.CreateCrmQuote).To(func(c context.Context, m salesforce_sdk.QuoteModel) error {
				createCalled = true
				return nil
			}).Build()

			sendCalled := false
			mockey.Mock(lark_client.SendLogMessage).To(func(c context.Context, msg string) error {
				sendCalled = true
				return nil
			}).Build()

			CreateCrmQuote(ctx, quote)

			convey.So(getCalled, convey.ShouldBeFalse)
			convey.So(createCalled, convey.ShouldBeFalse)
			convey.So(sendCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("get product type fails triggers error handling", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				BaseDB:       framework.BaseDB{Id: 123},
				AppAccountID: constants.PrmAccount,
			}

			mockey.Mock((*model.Quote).GetProductType).To(func(q *model.Quote, c context.Context) ([]int, error) {
				return nil, errors.New("mock get product type error")
			}).Build()

			var loggedMessage string
			sendCalled := false
			mockey.Mock(lark_client.SendLogMessage).To(func(c context.Context, msg string) error {
				sendCalled = true
				loggedMessage = msg
				return nil
			}).Build()

			createCalled := false
			mockey.Mock(crmclient.CreateCrmQuote).To(func(c context.Context, m salesforce_sdk.QuoteModel) error {
				createCalled = true
				return nil
			}).Build()

			CreateCrmQuote(ctx, quote)

			convey.So(sendCalled, convey.ShouldBeTrue)
			convey.So(loggedMessage, convey.ShouldContainSubstring, "quote_id : 123")
			convey.So(loggedMessage, convey.ShouldContainSubstring, "mock get product type error")
			convey.So(createCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("crm creation failure triggers error handling", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				BaseDB:               framework.BaseDB{Id: 456},
				AppAccountID:         constants.OpenApiAppKeyPrm,
				CustomerDetail:       "partner-001",
				OpportunityID:        multienv.OppNumber("OPP-001"),
				SolutionConsultantID: "sc@example.com",
				QuoteRelatedProduct:  "",
			}

			mockey.Mock((*model.Quote).GetProductType).To(func(q *model.Quote, c context.Context) ([]int, error) {
				return []int{7}, nil
			}).Build()

			createCalled := false
			mockey.Mock(crmclient.CreateCrmQuote).To(func(c context.Context, m salesforce_sdk.QuoteModel) error {
				createCalled = true
				return errors.New("mock crm creation error")
			}).Build()

			var loggedMessage string
			sendCalled := false
			mockey.Mock(lark_client.SendLogMessage).To(func(c context.Context, msg string) error {
				sendCalled = true
				loggedMessage = msg
				return nil
			}).Build()

			CreateCrmQuote(ctx, quote)

			convey.So(createCalled, convey.ShouldBeTrue)
			convey.So(sendCalled, convey.ShouldBeTrue)
			convey.So(loggedMessage, convey.ShouldContainSubstring, "quote_id : 456")
			convey.So(loggedMessage, convey.ShouldContainSubstring, "mock crm creation error")
		})
	})

	t.Run("successful crm quote creation logs info", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				BaseDB:               framework.BaseDB{Id: 789},
				AppAccountID:         constants.PrmAccount,
				CustomerDetail:       "partner-002",
				OpportunityID:        multienv.OppNumber("OPP-002"),
				SolutionConsultantID: "solution@example.com",
			}

			mockey.Mock((*model.Quote).GetProductType).To(func(q *model.Quote, c context.Context) ([]int, error) {
				return []int{2, 3}, nil
			}).Build()

			var capturedModel salesforce_sdk.QuoteModel
			mockey.Mock(crmclient.CreateCrmQuote).To(func(c context.Context, m salesforce_sdk.QuoteModel) error {
				capturedModel = m
				return nil
			}).Build()

			sendCalled := false
			mockey.Mock(lark_client.SendLogMessage).To(func(c context.Context, msg string) error {
				sendCalled = true
				return nil
			}).Build()

			CreateCrmQuote(ctx, quote)

			convey.So(sendCalled, convey.ShouldBeFalse)
			convey.So(capturedModel.PartnerID, convey.ShouldEqual, quote.CustomerDetail)
			convey.So(capturedModel.OppNumber, convey.ShouldEqual, string(quote.OpportunityID))
			convey.So(capturedModel.RelatedProduct, convey.ShouldResemble, []int{2, 3})
			convey.So(capturedModel.SolutionEmail, convey.ShouldEqual, quote.SolutionConsultantID)
			convey.So(capturedModel.QuoteID, convey.ShouldEqual, "789")
			convey.So(capturedModel.QuoteStatus, convey.ShouldEqual, constants.CrmApplicationStatusDraft)
			convey.So(capturedModel.QuoteSource, convey.ShouldEqual, constants.QuoteSourcePrm)
		})
	})
}

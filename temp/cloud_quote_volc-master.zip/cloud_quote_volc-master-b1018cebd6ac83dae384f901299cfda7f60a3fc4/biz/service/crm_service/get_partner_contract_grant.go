package crm_service

import (
	"context"
	"sort"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/prmcontract_client"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/eps_platform_eco_prm_contract/kitex_gen/eps/platform/eco_prm_contract"
)

type GetPartnerGrantReq struct {
	PartnerName string `query:"PartnerName"` // 伙伴名称
	PartnerCode string `query:"PartnerCode"` // 伙伴Code
}

type PartnerGrant struct {
	GrantType       string
	GrantStatus     string
	GrantTypeEnum   int32
	PartnerList     []*PartnerInfo
	PartnerMap      map[string]*PartnerInfo `json:"-"`
	ValidatedTime   int64                   // 该授权生效时间
	InvalidatedTime int64                   // 该授权失效时间
}
type PartnerInfo struct {
	PassportID             string
	PartnerCode            string
	PartnerName            string
	PartnerContractList    []*PartnerContract
	PartnerContractListMap map[string]*PartnerContract `json:"-"`
}

type PartnerContract struct {
	ContractNo          string
	PartnerContractType string
	ValidatedTime       int64
	InvalidatedTime     int64
}

func (r *GetPartnerGrantReq) Handle(ctx context.Context) (interface{}, error) {
	if r.PartnerName == "" && r.PartnerCode == "" {
		return nil, nil
	}
	var partnerGrantList []*PartnerGrant
	grantMap, err := r.GetPartnerGrant(ctx)
	if err != nil {
		return nil, err
	}
	for _, partnerGrant := range grantMap {
		partnerGrantList = append(partnerGrantList, partnerGrant)
	}
	sort.Slice(partnerGrantList, func(i, j int) bool {
		return partnerGrantList[i].GrantTypeEnum < partnerGrantList[j].GrantTypeEnum
	})
	return partnerGrantList, nil
}

func (r *GetPartnerGrantReq) GetPartnerGrant(ctx context.Context) (map[int32]*PartnerGrant, error) {
	partner := &eco_prm_contract.Partner{}
	if r.PartnerCode != "" {
		partner.PartnerCode = r.PartnerCode
	} else if r.PartnerName != "" {
		partner.PartnerName = r.PartnerName
	}

	req := &eco_prm_contract.ListContractGrantRequest{
		Partner: partner,
		ProcessStatusList: []int8{
			8, //8-走完流程
		},
		ContractStatusList: []int8{
			1, 2, 3, //1-未生效 2-已生效 3-临期
		},
		Limit:  1000,
		Offset: 1,
	}
	contractGrantList, err := prmcontract_client.ListContractGrant(ctx, req)
	if err != nil {
		return nil, err
	}
	grantMap := map[int32]*PartnerGrant{}
	for _, grant := range contractGrantList.Grants {
		partnerGrant, ok := grantMap[grant.GrantTypeEnum]
		if !ok {
			partnerGrant = &PartnerGrant{
				GrantType:     grant.GrantType,
				GrantStatus:   grant.GrantStatus,
				GrantTypeEnum: grant.GrantTypeEnum,
				PartnerList:   nil,
				PartnerMap:    map[string]*PartnerInfo{},
			}
			grantMap[grant.GrantTypeEnum] = partnerGrant
		}
		if grant.Partner != nil {
			partnerInfo, partnerOk := partnerGrant.PartnerMap[grant.Partner.PassportID]
			if !partnerOk {
				partnerInfo = &PartnerInfo{
					PassportID:             grant.Partner.PassportID,
					PartnerCode:            grant.Partner.PartnerCode,
					PartnerName:            grant.Partner.PartnerName,
					PartnerContractListMap: map[string]*PartnerContract{},
				}
				partnerGrant.PartnerMap[grant.Partner.PassportID] = partnerInfo
				partnerGrant.PartnerList = append(partnerGrant.PartnerList, partnerInfo)
			}
			_, contractOk := partnerInfo.PartnerContractListMap[grant.ContractNo]
			if !contractOk {
				partnerContract := &PartnerContract{
					ContractNo:          grant.ContractNo,
					PartnerContractType: grant.PartnerContractType,
					ValidatedTime:       grant.ValidatedTime,
					InvalidatedTime:     grant.InvalidatedTime,
				}
				partnerInfo.PartnerContractListMap[grant.ContractNo] = partnerContract
				partnerInfo.PartnerContractList = append(partnerInfo.PartnerContractList, partnerContract)
			}
		}
	}

	// 按照授权类型计算每个授权的最小生效时间和最大失效时间
	for _, partnerGrant := range grantMap {
		var minValidatedTime int64
		var maxInvalidatedTime int64
		for _, partnerInfo := range partnerGrant.PartnerList {
			for _, contract := range partnerInfo.PartnerContractList {
				if contract.ValidatedTime == 0 || contract.InvalidatedTime == 0 {
					logs.CtxError(ctx, "伙伴合同生效时间或失效时间为0")
					continue
				}
				// 计算最早的生效时间
				if minValidatedTime == 0 || contract.ValidatedTime < minValidatedTime {
					minValidatedTime = contract.ValidatedTime
				}
				// 计算最晚的失效时间
				if contract.InvalidatedTime > maxInvalidatedTime {
					maxInvalidatedTime = contract.InvalidatedTime
				}
			}
		}
		partnerGrant.ValidatedTime = minValidatedTime
		partnerGrant.InvalidatedTime = maxInvalidatedTime
	}

	return grantMap, nil
}

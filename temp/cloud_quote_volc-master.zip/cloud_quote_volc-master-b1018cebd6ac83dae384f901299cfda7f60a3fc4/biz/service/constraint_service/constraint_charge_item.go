package constraint_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kv/redis-v6/pkg"
	"context"
	"encoding/json"
	"fmt"
	"time"
)

const constraintChargeItemKey = "constraint_charge_item_list"

type MatchConstraintChargeItemReq struct {
	AccountIDList     []int64
	CustomerID        string
	Product           string
	ConfigurationList []*commercialization_api.ConfigConstraintModel
}

type ConstraintData struct {
	ChargeItemKey    string // 商品code::配置code::计费项code
	ConfigStatus     int
	ConfigIsPublic   int
	ChargeItemStatus int
	CustomerScope    string
	PrePayRatio      string // 预付费比例
}

func (r *MatchConstraintChargeItemReq) GetConfigConstraintFilterRequest() *commercialization_api.ConfigConstraintFilterRequest {
	req := &commercialization_api.ConfigConstraintFilterRequest{
		Product:                   r.Product,
		ConfigConstraintModelList: r.ConfigurationList,
	}
	if len(r.AccountIDList) > 0 {
		req.AccountIDList = r.AccountIDList
	} else if r.CustomerID != "" {
		req.CustomerID = &r.CustomerID
	}
	return req
}

func (r *MatchConstraintChargeItemReq) getCacheKey() string {
	return fmt.Sprintf("%s_%s_%s_%s", constraintChargeItemKey, r.Product, r.CustomerID, util.Int64Join(r.AccountIDList, "_"))
}

func (d *ConstraintData) SupportQuote(checkConfigIsPublic bool) (bool, errors.ErrorCodeN) {
	if d == nil {
		return true, errors.CodeNNoError
	}
	switch d.ConfigStatus {
	case multienv.TradeConfigStatusOn:
	case multienv.TradeConfigStatusToOff:
		return false, errors.CodeNConfigStatusToOffNotSupportQuote
	case multienv.TradeConfigStatusOff: // 从商品获取配置的时候已经过滤掉下架的配置，所以这种情况目前不会出现
		return false, errors.CodeNConfigStatusOffNotSupportQuote
	default:
		return false, errors.CodeNConfigStatusNotSupportQuote
	}
	switch d.ChargeItemStatus {
	case multienv.ChargeItemStatusOn:
	case multienv.ChargeItemStatusToOff:
		return false, errors.CodeNChargeItemStatusToOffNotSupportQuote
	case multienv.ChargeItemStatusOff: // 从商品获取计费项的时候已经过滤掉下架的计费项，所以这种情况目前不会出现
		return false, errors.CodeNChargeItemStatusOffNotSupportQuote
	default:
		return false, errors.CodeNChargeItemStatusNotSupportQuote
	}
	if checkConfigIsPublic && d.ConfigIsPublic != multienv.ConfigIsPublicTrue {
		return false, errors.CodeNConfigIsPublicNotSupportQuote
	}
	return true, errors.CodeNNoError
}

func (r *MatchConstraintChargeItemReq) Match(ctx context.Context, saveToCache bool) map[string]*ConstraintData {
	if (len(r.AccountIDList) == 0 && r.CustomerID == "") ||
		len(r.ConfigurationList) == 0 {
		return nil
	}
	switchModel := config.GetSwitchByName(ctx, config.SwitchChargeItemMatchConstraint)
	if switchModel == nil {
		logs.CtxInfo(ctx, "MatchConstraintChargeItem switchModel is nil, skip match")
		return nil
	}
	if !switchModel.IsOpen {
		logs.CtxInfo(ctx, "MatchConstraintChargeItem switchModel is not open, skip match")
		return nil
	}
	if switchModel.UseCache {
		constraintChargeItemMap, err := r.getMatchResultFromCache(ctx)
		if err != nil {
			logs.CtxError(ctx, "MatchConstraintChargeItem getMatchResultFromCache error %s", err.Error())
			_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
				"【WARN】配置计费项约束匹配查询缓存失败 error %s,请考虑关闭开关【%s】进行降级, requestID : %s",
				err.Error(),
				config.SwitchChargeItemMatchConstraint,
				util.GetRequestID(ctx),
			))
		}
		if constraintChargeItemMap != nil {
			return constraintChargeItemMap
		}
	}

	constraintChargeItemMap := r.getMatchResultFromServer(ctx, switchModel)

	if saveToCache {
		if err := r.saveMatchResultToCache(ctx, constraintChargeItemMap); err != nil {
			logs.CtxError(ctx, "MatchConstraintChargeItem saveMatchResultToCache error %s", err.Error())
			_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
				"【WARN】配置计费项约束匹配保存缓存失败 error %s,请考虑关闭开关【%s】进行降级, requestID : %s",
				err.Error(),
				config.SwitchChargeItemMatchConstraint,
				util.GetRequestID(ctx),
			))
		}
	}

	return constraintChargeItemMap
}

func (r *MatchConstraintChargeItemReq) getMatchResultFromServer(ctx context.Context, switchModel *config.SwitchModel) map[string]*ConstraintData {
	matchStartTime := time.Now()
	configConstraintFilterResult, err := trade_client.MatchConstraintChargeItem(ctx, r.GetConfigConstraintFilterRequest())
	if err != nil {
		logs.CtxError(ctx, "MatchConstraintChargeItem error %s", err.Error())
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
			"【WARN】配置计费项约束匹配失败 error %s,请考虑关闭开关【%s】进行降级, requestID : %s",
			err.Error(),
			config.SwitchChargeItemMatchConstraint,
			util.GetRequestID(ctx),
		))
		return nil
	}
	matchEndTime := time.Now()
	timeUsed := matchEndTime.Sub(matchStartTime).Milliseconds()
	if timeUsed > switchModel.TimeOut {
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
			"【WARN】配置计费项约束匹配失败【%d】毫秒,请考虑关闭开关【%s】进行降级, requestID : %s",
			timeUsed,
			config.SwitchChargeItemMatchConstraint,
			util.GetRequestID(ctx),
		))
	}
	if configConstraintFilterResult == nil {
		return nil
	}
	constraintChargeItemMap := map[string]*ConstraintData{}
	for _, configuration := range configConstraintFilterResult.ConfigConstraintModelList {
		for _, chargeItem := range configuration.ChargeItemConstraintModelList {
			chargeItemKey := util.GetChargeItemUniqKey(configConstraintFilterResult.Product, configuration.ConfigurationCode, chargeItem.ChargeItemCode)
			constraintChargeItemMap[chargeItemKey] = &ConstraintData{
				ChargeItemKey:    chargeItemKey,
				ConfigStatus:     int(configuration.Status),
				ConfigIsPublic:   int(configuration.IsPublic),
				ChargeItemStatus: int(chargeItem.Status),
			}
		}
	}
	return constraintChargeItemMap
}

func (r *MatchConstraintChargeItemReq) getMatchResultFromCache(ctx context.Context) (map[string]*ConstraintData, error) {
	redisClient := redis_client.NewRedisClient()
	constraintDataListStr, err := redisClient.Get(r.getCacheKey()).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var constraintDataList []*ConstraintData
	if err = json.Unmarshal([]byte(constraintDataListStr), &constraintDataList); err != nil {
		return nil, err
	}
	m := map[string]*ConstraintData{}
	for _, constraintData := range constraintDataList {
		m[constraintData.ChargeItemKey] = constraintData
	}
	return m, nil
}

func (r *MatchConstraintChargeItemReq) saveMatchResultToCache(ctx context.Context, constraintDataMap map[string]*ConstraintData) error {
	constraintDataList := make([]*ConstraintData, 0, len(constraintDataMap))
	for _, constraintData := range constraintDataMap {
		constraintDataList = append(constraintDataList, constraintData)
	}
	redisClient := redis_client.NewRedisClient()
	_, err := redisClient.Set(r.getCacheKey(), util.GetJsonStr(constraintDataList), 10*time.Minute).Result()
	return err
}

package constraint_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"time"
)

type MatchConstraintProductReq struct {
	AccountIDList    []int64
	ProductModelList []*commercialization_api.ProductConstraintModel
	CustomerID       string
}

func (r *MatchConstraintProductReq) GetProductConstraintFilterRequest() *commercialization_api.ProductConstraintFilterRequest {
	req := &commercialization_api.ProductConstraintFilterRequest{
		ProductConstraintModelList: r.ProductModelList,
	}
	if len(r.AccountIDList) > 0 {
		req.AccountIDList = r.AccountIDList
	} else if r.CustomerID != "" {
		req.CustomerID = &r.CustomerID
	}
	return req
}

func (r *MatchConstraintProductReq) Match(ctx context.Context) map[string]int {
	if (len(r.AccountIDList) == 0 && r.CustomerID == "") ||
		len(r.ProductModelList) == 0 {
		return nil
	}
	switchModel := config.GetSwitchByName(ctx, config.SwitchProductMatchConstraint)
	if switchModel == nil {
		logs.CtxInfo(ctx, "MatchConstraintProduct switchModel is nil, skip match")
		return nil
	}
	if !switchModel.IsOpen {
		logs.CtxInfo(ctx, "MatchConstraintProduct switchModel is not open, skip match")
		return nil
	}
	matchStartTime := time.Now()
	productConstraintFilterResult, err := trade_client.MatchConstraintProduct(ctx, r.GetProductConstraintFilterRequest())
	if err != nil {
		logs.CtxError(ctx, "MatchConstraintProduct error %s", err.Error())
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
			"【WARN】商品约束匹配失败 error %s,请考虑关闭开关【%s】进行降级, requestID : %s",
			err.Error(),
			config.SwitchProductMatchConstraint,
			util.GetRequestID(ctx),
		))
		return nil
	}
	matchEndTime := time.Now()
	timeUsed := matchEndTime.Sub(matchStartTime).Milliseconds()
	if timeUsed > switchModel.TimeOut {
		_ = lark_client.SendLogMessage(ctx, fmt.Sprintf(
			"【WARN】商品约束匹配耗时【%d】毫秒,请考虑关闭开关【%s】进行降级, requestID : %s",
			timeUsed,
			config.SwitchProductMatchConstraint,
			util.GetRequestID(ctx),
		))
	}
	constraintProductStatusMap := map[string]int{}
	if productConstraintFilterResult == nil {
		return constraintProductStatusMap
	}
	for _, productMode := range productConstraintFilterResult.ProductConstraintModelList {
		constraintProductStatusMap[productMode.Product] = int(productMode.Status)
	}
	return constraintProductStatusMap
}

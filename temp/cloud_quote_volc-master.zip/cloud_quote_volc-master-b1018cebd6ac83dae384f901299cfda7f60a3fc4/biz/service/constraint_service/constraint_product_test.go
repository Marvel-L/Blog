package constraint_service

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
)

func TestMatchConstraintProductReq_GetProductConstraintFilterRequest(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &MatchConstraintProductReq{
				AccountIDList:    []int64{0},
				ProductModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{}},
			}
			got := v.GetProductConstraintFilterRequest()

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})

}
func TestMatchConstraintProductReq_Match(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:  false,
				TimeOut: 0,
			}).Build()
			mockey.Mock((*MatchConstraintProductReq).GetProductConstraintFilterRequest).Return(&commercialization_api.ProductConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintProduct).Return(&commercialization_api.ProductConstraintFilterResult{
				ProductConstraintModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{
					Product: "",
					Status:  0,
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v1 := &MatchConstraintProductReq{
				AccountIDList: []int64{},
			}
			got := v1.Match(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(nil).Build()
			mockey.Mock((*MatchConstraintProductReq).GetProductConstraintFilterRequest).Return(&commercialization_api.ProductConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintProduct).Return(&commercialization_api.ProductConstraintFilterResult{
				ProductConstraintModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{
					Product: "",
					Status:  0,
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v1 := &MatchConstraintProductReq{
				AccountIDList: []int64{123},
			}
			got := v1.Match(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("124", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:  false,
				TimeOut: 0,
			}).Build()
			mockey.Mock((*MatchConstraintProductReq).GetProductConstraintFilterRequest).Return(&commercialization_api.ProductConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintProduct).Return(&commercialization_api.ProductConstraintFilterResult{
				ProductConstraintModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{
					Product: "",
					Status:  0,
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v1 := &MatchConstraintProductReq{
				AccountIDList: []int64{},
			}
			got := v1.Match(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:  true,
				TimeOut: 0,
			}).Build()
			mockey.Mock((*MatchConstraintProductReq).GetProductConstraintFilterRequest).Return(&commercialization_api.ProductConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintProduct).Return(&commercialization_api.ProductConstraintFilterResult{
				ProductConstraintModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{
					Product: "",
					Status:  0,
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v1 := &MatchConstraintProductReq{
				AccountIDList: []int64{123},
			}
			got := v1.Match(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:  true,
				TimeOut: 0,
			}).Build()
			mockey.Mock((*MatchConstraintProductReq).GetProductConstraintFilterRequest).Return(&commercialization_api.ProductConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintProduct).Return(&commercialization_api.ProductConstraintFilterResult{
				ProductConstraintModelList: []*commercialization_api.ProductConstraintModel{&commercialization_api.ProductConstraintModel{
					Product: "",
					Status:  0,
				}},
			}, nil).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(nil).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v1 := &MatchConstraintProductReq{
				AccountIDList: []int64{123},
			}
			got := v1.Match(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
}

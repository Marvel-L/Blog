package constraint_service

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/kv/goredis"
	"code.byted.org/kv/redis-v6"
	"code.byted.org/kv/redis-v6/pkg"
)

func TestMatchConstraintChargeItemReq_GetConfigConstraintFilterRequest(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &MatchConstraintChargeItemReq{
				AccountIDList:     []int64{0},
				Product:           "",
				ConfigurationList: []*commercialization_api.ConfigConstraintModel{&commercialization_api.ConfigConstraintModel{}},
			}
			got := v.GetConfigConstraintFilterRequest()

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

func TestMatchConstraintChargeItemReq_Match(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:   false,
				UseCache: false,
			}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(map[string]*ConstraintData{"": &ConstraintData{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(nil).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(map[string]*ConstraintData{"": &ConstraintData{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{1234},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:   false,
				UseCache: false,
			}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(map[string]*ConstraintData{"": &ConstraintData{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{1234},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:   true,
				UseCache: true,
			}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(nil, fmt.Errorf("your error")).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{1234},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:   true,
				UseCache: true,
			}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(map[string]*ConstraintData{"": &ConstraintData{}}, nil).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{1234},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #6", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:   true,
				UseCache: true,
			}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromCache).Return(nil, nil).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).getMatchResultFromServer).Return(map[string]*ConstraintData{"": &ConstraintData{}}).Build()
			mockey.Mock((*MatchConstraintChargeItemReq).saveMatchResultToCache).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(nil).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()

			// Act
			v5 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{1234},
				Product:       "",
			}
			got := v5.Match(context.Background(), true)

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})

}
func TestMatchConstraintChargeItemReq_getMatchResultFromServer(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*MatchConstraintChargeItemReq).GetConfigConstraintFilterRequest).Return(&commercialization_api.ConfigConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintChargeItem).Return(&commercialization_api.ConfigConstraintFilterResult{
				Product: "",
				ConfigConstraintModelList: []*commercialization_api.ConfigConstraintModel{&commercialization_api.ConfigConstraintModel{
					ConfigurationCode: "",
					Status:            0,
					IsPublic:          0,
					ChargeItemConstraintModelList: []*commercialization_api.ChargeItemConstraintModel{&commercialization_api.ChargeItemConstraintModel{
						ChargeItemCode: "",
						Status:         0,
					}},
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()
			mockey.Mock(util.GetChargeItemUniqKey).Return("").Build()

			// Act
			v1 := &MatchConstraintChargeItemReq{}
			got := v1.getMatchResultFromServer(context.Background(), &config.SwitchModel{
				TimeOut: 0,
			})

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*MatchConstraintChargeItemReq).GetConfigConstraintFilterRequest).Return(&commercialization_api.ConfigConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintChargeItem).Return(nil, nil).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(nil).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()
			mockey.Mock(util.GetChargeItemUniqKey).Return("").Build()

			// Act
			v1 := &MatchConstraintChargeItemReq{}
			got := v1.getMatchResultFromServer(context.Background(), &config.SwitchModel{
				TimeOut: 0,
			})

			// Assert
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*MatchConstraintChargeItemReq).GetConfigConstraintFilterRequest).Return(&commercialization_api.ConfigConstraintFilterRequest{}).Build()
			mockey.Mock(trade_client.MatchConstraintChargeItem).Return(&commercialization_api.ConfigConstraintFilterResult{
				Product: "",
				ConfigConstraintModelList: []*commercialization_api.ConfigConstraintModel{&commercialization_api.ConfigConstraintModel{
					ConfigurationCode: "",
					Status:            0,
					IsPublic:          0,
					ChargeItemConstraintModelList: []*commercialization_api.ChargeItemConstraintModel{&commercialization_api.ChargeItemConstraintModel{
						ChargeItemCode: "",
						Status:         0,
					}},
				}},
			}, nil).Build()
			mockey.Mock(lark_client.SendLogMessage).Return(nil).Build()
			mockey.Mock(util.GetRequestID).Return("").Build()
			mockey.Mock(util.GetChargeItemUniqKey).Return("").Build()

			// Act
			v1 := &MatchConstraintChargeItemReq{}
			got := v1.getMatchResultFromServer(context.Background(), &config.SwitchModel{
				TimeOut: 0,
			})

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}
func TestMatchConstraintChargeItemReq_getMatchResultFromCache(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "Get")).To(func(key string) *redis.StringCmd {
				v1 := &redis.StringCmd{}
				v1.SetVal("")
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("", pkg.Nil).Build()

			// Act
			v2 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{0},
				Product:       "",
			}
			got, err := v2.getMatchResultFromCache(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "Get")).To(func(key string) *redis.StringCmd {
				v1 := &redis.StringCmd{}
				v1.SetVal("")
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("", fmt.Errorf("your error")).Build()

			// Act
			v2 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{0},
				Product:       "",
			}
			got, err := v2.getMatchResultFromCache(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "Get")).To(func(key string) *redis.StringCmd {
				v1 := &redis.StringCmd{}
				v1.SetVal("")
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("", nil).Build()

			// Act
			v2 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{0},
				Product:       "",
			}
			got, err := v2.getMatchResultFromCache(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "Get")).To(func(key string) *redis.StringCmd {
				v1 := &redis.StringCmd{}
				v1.SetVal("")
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("[]", nil).Build()

			// Act
			v2 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{0},
				Product:       "",
			}
			got, err := v2.getMatchResultFromCache(context.Background())

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func TestMatchConstraintChargeItemReq_saveMatchResultToCache(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "Set")).To(func(key string, value interface{}, expiration time.Duration) *redis.StatusCmd {
				v1 := &redis.StatusCmd{}
				v1.SetVal("")
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()
			mockey.Mock((*redis.StatusCmd).Result).Return("", nil).Build()

			// Act
			v2 := &MatchConstraintChargeItemReq{
				AccountIDList: []int64{0},
				Product:       "",
			}
			err := v2.saveMatchResultToCache(context.Background(), map[string]*ConstraintData{"": &ConstraintData{}})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_ConstraintData_SupportQuote_BitsUTGen(t *testing.T) {
	t.Run("should return true when ConstraintData is nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var d *ConstraintData = nil
			supported, errCode := d.SupportQuote(false)
			convey.So(supported, convey.ShouldBeTrue)
			convey.So(errCode, convey.ShouldEqual, pkg_errors.CodeNNoError)
		})
	})

	statusTests := []struct {
		name             string
		configStatus     int
		chargeItemStatus int
		code             pkg_errors.ErrorCodeN
	}{
		{"config status to off", multienv.TradeConfigStatusToOff, multienv.ChargeItemStatusOn, pkg_errors.CodeNConfigStatusToOffNotSupportQuote},
		{"config status off", multienv.TradeConfigStatusOff, multienv.ChargeItemStatusOn, pkg_errors.CodeNConfigStatusOffNotSupportQuote},
		{"config status draft", multienv.TradeConfigStatusDraft, multienv.ChargeItemStatusOn, pkg_errors.CodeNConfigStatusNotSupportQuote},
		{"config status unknown", -1, multienv.ChargeItemStatusOn, pkg_errors.CodeNConfigStatusNotSupportQuote},
		{"charge item status to off", multienv.TradeConfigStatusOn, multienv.ChargeItemStatusToOff, pkg_errors.CodeNChargeItemStatusToOffNotSupportQuote},
		{"charge item status off", multienv.TradeConfigStatusOn, multienv.ChargeItemStatusOff, pkg_errors.CodeNChargeItemStatusOffNotSupportQuote},
		{"charge item status draft", multienv.TradeConfigStatusOn, multienv.ChargeItemStatusDraft, pkg_errors.CodeNChargeItemStatusNotSupportQuote},
		{"charge item status unknown", multienv.TradeConfigStatusOn, -1, pkg_errors.CodeNChargeItemStatusNotSupportQuote},
		{"config status takes precedence", multienv.TradeConfigStatusOff, multienv.ChargeItemStatusToOff, pkg_errors.CodeNConfigStatusOffNotSupportQuote},
	}
	for _, tt := range statusTests {
		t.Run(tt.name, func(t *testing.T) {
			data := &ConstraintData{
				ConfigStatus:     tt.configStatus,
				ChargeItemStatus: tt.chargeItemStatus,
			}
			supported, errCode := data.SupportQuote(false)
			if supported {
				t.Fatal("expected quote to be unsupported")
			}
			if errCode != tt.code {
				t.Fatalf("unexpected error code: got %d, want %d", errCode, tt.code)
			}
		})
	}

	t.Run("should return false when checkConfigIsPublic is true and ConfigIsPublic is not True", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d := &ConstraintData{
				ConfigStatus:     multienv.TradeConfigStatusOn,
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue + 1,
			}
			supported, errCode := d.SupportQuote(true)
			convey.So(supported, convey.ShouldBeFalse)
			convey.So(errCode, convey.ShouldEqual, pkg_errors.CodeNConfigIsPublicNotSupportQuote)
		})
	})

	t.Run("should return true when all conditions met and checkConfigIsPublic is false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d := &ConstraintData{
				ConfigStatus:     multienv.TradeConfigStatusOn,
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue + 1, // This should be ignored
			}
			supported, errCode := d.SupportQuote(false)
			convey.So(supported, convey.ShouldBeTrue)
			convey.So(errCode, convey.ShouldEqual, pkg_errors.CodeNNoError)
		})
	})

	t.Run("should return true when all conditions met and checkConfigIsPublic is true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			d := &ConstraintData{
				ConfigStatus:     multienv.TradeConfigStatusOn,
				ChargeItemStatus: multienv.ChargeItemStatusOn,
				ConfigIsPublic:   multienv.ConfigIsPublicTrue,
			}
			supported, errCode := d.SupportQuote(true)
			convey.So(supported, convey.ShouldBeTrue)
			convey.So(errCode, convey.ShouldEqual, pkg_errors.CodeNNoError)
		})
	})
}

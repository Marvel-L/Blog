package error_detail

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"context"
	"fmt"
	v2 "github.com/larksuite/oapi-sdk-go/service/sheets/v2"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	gorm "code.byted.org/gopkg/gorm/v2"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	gorm1 "gorm.io/gorm"
)

func TestGetErrorDetailsReq_Handle(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "FindByErrorCodes")).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, fmt.Errorf("your error")).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v2 := &GetErrorDetailsReq{
				ErrorCodes: []string{""},
			}
			got, err := v2.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "FindByErrorCodes")).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, fmt.Errorf("your error")).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v2 := &GetErrorDetailsReq{
				ErrorCodes: []string{},
			}
			got, err := v2.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "FindByErrorCodes")).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, nil).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v2 := &GetErrorDetailsReq{
				ErrorCodes: []string{},
			}
			got, err := v2.Handle(context.Background())

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
}

func Test_ParseLarkSheet(t *testing.T) {
	ctx := context.Background()
	req := &UpdateErrorDetailsReq{}

	t.Run("Test empty rows", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rows := [][]string{}
			res, err := req.ParseLarkSheet(ctx, rows)
			convey.So(res, convey.ShouldBeEmpty)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Test invalid header format", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rows := [][]string{
				{"invalidHeader1", "invalidHeader2", "invalidHeader3", "invalidHeader4", "invalidHeader5"}, {"invalidHeader1", "invalidHeader2", "invalidHeader3", "invalidHeader4", "invalidHeader5"},
			}
			res, err := req.ParseLarkSheet(ctx, rows)
			convey.So(res, convey.ShouldBeEmpty)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "error_detail format error")
		})
	})

	t.Run("Test valid header but empty data rows", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rows := [][]string{
				{"errorCode", "errorMsg", "errorCause", "solution", "link"},
			}
			res, err := req.ParseLarkSheet(ctx, rows)
			convey.So(res, convey.ShouldBeEmpty)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Test valid header and data rows", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rows := [][]string{
				{"errorCode", "errorMsg", "errorCause", "solution", "link"},
				{"ERR001", "Error Message 1", "Error Cause 1", "Solution 1", "Link 1"},
				{"ERR002", "Error Message 2", "Error Cause 2", "Solution 2", "Link 2"},
			}
			res, err := req.ParseLarkSheet(ctx, rows)
			convey.So(res, convey.ShouldHaveLength, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(res[0].ErrorCode, convey.ShouldEqual, "ERR001")
			convey.So(res[0].ErrorMsg, convey.ShouldEqual, "Error Message 1")
			convey.So(res[0].ErrorCause, convey.ShouldEqual, "Error Cause 1")
			convey.So(res[0].Solution, convey.ShouldEqual, "Solution 1")
			convey.So(res[0].Link, convey.ShouldEqual, "Link 1")
			convey.So(res[1].ErrorCode, convey.ShouldEqual, "ERR002")
			convey.So(res[1].ErrorMsg, convey.ShouldEqual, "Error Message 2")
			convey.So(res[1].ErrorCause, convey.ShouldEqual, "Error Cause 2")
			convey.So(res[1].Solution, convey.ShouldEqual, "Solution 2")
			convey.So(res[1].Link, convey.ShouldEqual, "Link 2")
		})
	})

	t.Run("Test valid header and data rows with empty error code", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rows := [][]string{
				{"errorCode", "errorMsg", "errorCause", "solution", "link"},
				{"", "Error Message 1", "Error Cause 1", "Solution 1", "Link 1"},
				{"ERR002", "Error Message 2", "Error Cause 2", "Solution 2", "Link 2"},
			}
			res, err := req.ParseLarkSheet(ctx, rows)
			convey.So(res, convey.ShouldHaveLength, 1)
			convey.So(err, convey.ShouldBeNil)
			convey.So(res[0].ErrorCode, convey.ShouldEqual, "ERR002")
			convey.So(res[0].ErrorMsg, convey.ShouldEqual, "Error Message 2")
			convey.So(res[0].ErrorCause, convey.ShouldEqual, "Error Cause 2")
			convey.So(res[0].Solution, convey.ShouldEqual, "Solution 2")
			convey.So(res[0].Link, convey.ShouldEqual, "Link 2")
		})
	})
}

func TestUpdateErrorDetailsReq_UpdateErrorDetails(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(lark_client.GetSheetContent).Return(&v2.SpreadsheetsMetainfoResult{}, [][]string{[]string{""}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*UpdateErrorDetailsReq).ParseLarkSheet).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*UpdateErrorDetailsReq).FilterErrorDetails).Return([]*model.ErrorDetail{&model.ErrorDetail{}}).Build()
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "BatchSave")).Return(fmt.Errorf("your error")).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v1 := &UpdateErrorDetailsReq{
				Link: "",
			}
			err := v1.UpdateErrorDetails(context.Background())

			// Assert
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(lark_client.GetSheetContent).Return(&v2.SpreadsheetsMetainfoResult{}, [][]string{[]string{""}}, nil).Build()
			mockey.Mock((*UpdateErrorDetailsReq).ParseLarkSheet).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, fmt.Errorf("your error")).Build()
			mockey.Mock((*UpdateErrorDetailsReq).FilterErrorDetails).Return([]*model.ErrorDetail{&model.ErrorDetail{}}).Build()
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "BatchSave")).Return(fmt.Errorf("your error")).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v1 := &UpdateErrorDetailsReq{
				Link: "",
			}
			err := v1.UpdateErrorDetails(context.Background())

			// Assert
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})

	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(lark_client.GetSheetContent).Return(&v2.SpreadsheetsMetainfoResult{}, [][]string{[]string{""}}, nil).Build()
			mockey.Mock((*UpdateErrorDetailsReq).ParseLarkSheet).Return([]*model.ErrorDetail{&model.ErrorDetail{}}, nil).Build()
			mockey.Mock((*UpdateErrorDetailsReq).FilterErrorDetails).Return([]*model.ErrorDetail{&model.ErrorDetail{}}).Build()
			mockey.Mock((*gorm.DBProxy).NewRequest).Return(&gorm1.DB{}).Build()
			mockey.Mock(mockey.GetMethod(dal.ErrorDetailDao, "BatchSave")).Return(fmt.Errorf("your error")).Build()

			// Act
			dal.DBProxy = &gorm.DBProxy{}
			v1 := &UpdateErrorDetailsReq{
				Link: "",
			}
			err := v1.UpdateErrorDetails(context.Background())

			// Assert
			convey.So(err != nil, convey.ShouldEqual, true)
		})
	})
}

package approval_modify

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/gopkg/logs"
)

// sendApprovalModifyFlowChangeNotification 向发起审批中修改的用户发送审批流变化卡片。
func sendApprovalModifyFlowChangeNotification(
	ctx context.Context,
	quote *model.Quote,
	currentInstance *model.LarkApprovalInstance,
	reason string,
) error {
	if quote == nil || currentInstance == nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批流变化通知缺少报价单或审批实例")
	}
	modifyContext, err := quote.GetModifyContext()
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "解析审批中修改上下文失败: %s").WithArgs(err.Error())
	}
	receiver := strings.TrimSpace(modifyContext.Promoter)
	if receiver == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "发起审批中修改的用户为空")
	}

	quotePreviewTemplate := config.GetQuotePreviewLink(ctx)
	if quotePreviewTemplate == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单预览链接配置为空")
	}
	quotePreviewLink := fmt.Sprintf(quotePreviewTemplate, quote.Id)

	approvalPCLink := strings.TrimSpace(currentInstance.ApprovalLink)
	approvalMobilePrefix := config.GetLarkMobileLink(ctx)
	approvalInstanceID := strings.TrimSpace(currentInstance.ApprovalInstanceId)
	if approvalPCLink == "" || approvalMobilePrefix == "" || approvalInstanceID == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "飞书审批链接信息不完整")
	}
	approvalMobileLink := approvalMobilePrefix + approvalInstanceID

	contractEntity := strings.TrimSpace(quote.ContractEntity)
	if contractEntity == "" {
		contractEntity = "-"
	}
	salesDisplay := approvalModifySalesDisplay(ctx, quote.SalesAccountID)
	if strings.TrimSpace(reason) == "" {
		reason = "-"
	}

	// 复用销运调整资源卡模板，变量名称必须与模板 AAq4EyagMYEl3 保持一致。
	cardTemplateData := &lark_client.CardTemplateData{
		TemplateID: lark_client.TemplateApprovalModifyFlowChange,
		TemplateVariable: map[string]interface{}{
			"title": lark_client.FullRegionMessage(ctx, "报价单审批中修改 - 审批流变化通知"),
			"text_content": i18nfmt.Sprintf(ctx,
				"报价单%d审批流已变更，需重新审阅。\n签约主体：%s\n销售：%s\n变更原因：%s",
				quote.Id, contractEntity, salesDisplay, reason,
			),
			"lark_link": lark_client.CardTemplateLink{
				PCUrl:      approvalPCLink,
				AndroidUrl: approvalMobileLink,
				IosUrl:     approvalMobileLink,
			},
			"quote_preview_link": lark_client.CardTemplateLink{
				Url: quotePreviewLink,
			},
		},
	}
	lark_client.SendCardTemplate(ctx, receiver, cardTemplateData)
	return nil
}

func approvalModifySalesDisplay(ctx context.Context, salesAccountID string) string {
	salesAccountID = strings.TrimSpace(salesAccountID)
	if salesAccountID == "" {
		return "-"
	}
	userIDs, err := lark_client.GetUserIDsByEmails(ctx, []string{salesAccountID})
	if err != nil {
		// 人员信息查询失败不应阻断通知，退化为展示销售邮箱。
		logs.CtxWarn(ctx, "%s get sales user ID failed, sales=%s, err=%s", LogPrefix, salesAccountID, err.Error())
		return salesAccountID
	}
	if userID := strings.TrimSpace(userIDs[salesAccountID]); userID != "" {
		return fmt.Sprintf(lark_client.UserCard, userID)
	}
	return salesAccountID
}

package approval_modify

import (
	"context"
	"encoding/json"
	"sort"
	"strconv"
	"strings"

	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

type approvalTaskCommentContent struct {
	Text  string                     `json:"text,omitempty"`
	Files []*approvalTaskCommentFile `json:"files,omitempty"`
}

type approvalTaskCommentFile struct {
	URL      *string `json:"url,omitempty"`
	FileSize *int    `json:"fileSize,omitempty"`
	Title    *string `json:"title,omitempty"`
	Type     *string `json:"type,omitempty"`
}

// syncApprovalTaskAttachmentsAsComment 将历史审批同意时的附件转换为当前实例的全局评论。
func (s *approvalModifySyncState) syncApprovalTaskAttachmentsAsComment(
	ctx context.Context,
	task *larkapproval.InstanceTask,
	files []*larkapproval.File,
) error {
	if task == nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批任务为空")
	}
	content := approvalTaskCommentContent{}
	for _, file := range files {
		if file == nil {
			continue
		}
		content.Files = append(content.Files, &approvalTaskCommentFile{
			URL:      file.Url,
			FileSize: file.FileSize,
			Title:    file.Title,
			Type:     file.Type,
		})
	}
	if len(content.Files) == 0 {
		return nil
	}
	commentator := util.TrimStringValue(task.UserId)
	if commentator == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批任务审批人为空")
	}
	content.Text = i18nfmt.Sprintf(ctx, "审批通过时附带的文件")
	if nodeName := util.TrimStringValue(task.NodeName); nodeName != "" {
		content.Text = "【" + nodeName + "】" + content.Text
	}
	data, err := json.Marshal(content)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "构造历史审批附件评论失败: %s").WithArgs(err.Error())
	}
	attachmentComment := string(data)
	semanticKey := approvalCommentKey(commentator, attachmentComment, nil)
	_, err = createApprovalCommentWithCheck(
		ctx,
		s.currentInstance.ApprovalInstanceId,
		s.currentUserID,
		commentator,
		attachmentComment,
		nil,
		"",
		semanticKey,
	)
	return err
}

func (s *approvalModifySyncState) syncApprovalInstanceComments(ctx context.Context) (int, error) {
	// 必须使用评论列表接口获取完整父评论和回复，实例详情中的简化评论列表不够完整。
	previousComments, err := lark_client.ListApprovalInstanceComments(
		ctx,
		s.previousInstance.ApprovalInstanceId,
		s.previousUserID,
	)
	if err != nil {
		return 0, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "上一审批实例评论查询失败: %s").WithArgs(err.Error())
	}
	currentComments, err := lark_client.ListApprovalInstanceComments(
		ctx,
		s.currentInstance.ApprovalInstanceId,
		s.currentUserID,
	)
	if err != nil {
		return 0, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "当前审批实例评论查询失败: %s").WithArgs(err.Error())
	}

	// 父评论先按创建时间同步，确保后续回复可以绑定到正确的新父评论。
	sort.SliceStable(previousComments, func(i, j int) bool {
		return commentCreateTime(previousComments[i]) < commentCreateTime(previousComments[j])
	})
	existingParents := make(map[string]string)
	existingReplies := make(map[string]struct{})
	commentatorNameCache := make(map[string]string)
	// 先为目标实例建立语义索引，使任务重试时可以跳过已经复制成功的内容。
	for _, comment := range currentComments {
		if isDeletedComment(comment) {
			continue
		}
		content, atInfo, normalizeErr := normalizeCommentContent(comment.Content, comment.AtInfoList)
		if normalizeErr != nil {
			return 0, normalizeErr
		}
		key := approvalCommentKey(util.TrimStringValue(comment.Commentator), content, atInfo)
		existingParents[key] = util.TrimStringValue(comment.Id)
		for _, reply := range comment.Replies {
			if isDeletedReply(reply) {
				continue
			}
			replyContent, replyAtInfo, normalizeErr := normalizeCommentContent(reply.Content, reply.AtInfoList)
			if normalizeErr != nil {
				return 0, normalizeErr
			}
			existingReplies[approvalReplyKey(key, util.TrimStringValue(reply.Commentator), replyContent, replyAtInfo)] = struct{}{}
		}
	}

	created := 0
	for _, comment := range previousComments {
		if isDeletedComment(comment) {
			continue
		}
		content, atInfo, err := normalizeCommentContent(comment.Content, comment.AtInfoList)
		if err != nil {
			return created, err
		}
		sourceCommentator := util.TrimStringValue(comment.Commentator)
		if sourceCommentator == "" {
			return created, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论创建人为空")
		}
		commentator, content, atInfo, err := prepareApprovalCommentForCreate(
			ctx,
			sourceCommentator,
			s.currentUserID,
			content,
			atInfo,
			s.commentAuthorizedUserIDs,
			commentatorNameCache,
		)
		if err != nil {
			return created, err
		}
		parentKey := approvalCommentKey(commentator, content, atInfo)
		parentID := existingParents[parentKey]
		if parentID == "" {
			// 新流程参与人使用原身份；缺席用户由新实例发起人代发。写后统一由发起人复查。
			parentID, err = createApprovalCommentWithCheck(
				ctx,
				s.currentInstance.ApprovalInstanceId,
				s.currentUserID,
				commentator,
				content,
				atInfo,
				"",
				parentKey,
			)
			if err != nil {
				return created, err
			}
			existingParents[parentKey] = parentID
			created++
		}

		// 回复必须在父评论确定后按时间顺序创建，并绑定新实例中的父评论 ID。
		sort.SliceStable(comment.Replies, func(i, j int) bool {
			return replyCreateTime(comment.Replies[i]) < replyCreateTime(comment.Replies[j])
		})
		for _, reply := range comment.Replies {
			if isDeletedReply(reply) {
				continue
			}
			replyContent, replyAtInfo, normalizeErr := normalizeCommentContent(reply.Content, reply.AtInfoList)
			if normalizeErr != nil {
				return created, normalizeErr
			}
			sourceReplyCommentator := util.TrimStringValue(reply.Commentator)
			if sourceReplyCommentator == "" {
				return created, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批回复创建人为空")
			}
			replyCommentator, replyContent, replyAtInfo, normalizeErr := prepareApprovalCommentForCreate(
				ctx,
				sourceReplyCommentator,
				s.currentUserID,
				replyContent,
				replyAtInfo,
				s.commentAuthorizedUserIDs,
				commentatorNameCache,
			)
			if normalizeErr != nil {
				return created, normalizeErr
			}
			replyKey := approvalReplyKey(parentKey, replyCommentator, replyContent, replyAtInfo)
			if _, exists := existingReplies[replyKey]; exists {
				continue
			}
			if _, createErr := createApprovalCommentWithCheck(
				ctx,
				s.currentInstance.ApprovalInstanceId,
				s.currentUserID,
				replyCommentator,
				replyContent,
				replyAtInfo,
				parentID,
				replyKey,
			); createErr != nil {
				return created, createErr
			}
			existingReplies[replyKey] = struct{}{}
			created++
		}
	}
	return created, nil
}

func prepareApprovalCommentForCreate(
	ctx context.Context,
	sourceCommentator string,
	currentUserID string,
	content string,
	atInfo []*larkapproval.CommentAtInfo,
	commentAuthorizedUserIDs map[string]struct{},
	commentatorNameCache map[string]string,
) (string, string, []*larkapproval.CommentAtInfo, error) {
	if sourceCommentator == currentUserID {
		return sourceCommentator, content, atInfo, nil
	}
	if _, exists := commentAuthorizedUserIDs[sourceCommentator]; exists {
		return sourceCommentator, content, atInfo, nil
	}

	commentatorName, exists := commentatorNameCache[sourceCommentator]
	if !exists {
		queriedName, err := lark_client.GetUserNameByUserID(ctx, sourceCommentator)
		commentatorName = strings.TrimSpace(queriedName)
		if err != nil || commentatorName == "" {
			// user_id 才是 @ 人的真实标识；姓名不可查时使用 ID 兜底，避免评论同步永久阻塞。
			logs.CtxWarn(ctx, "%s get source commentator name failed, userID=%s, err=%v", LogPrefix, sourceCommentator, err)
			commentatorName = sourceCommentator
		}
		commentatorNameCache[sourceCommentator] = commentatorName
	}

	copiedContent, copiedAtInfo, err := prependCopiedApprovalCommentAttribution(
		ctx,
		content,
		atInfo,
		sourceCommentator,
		commentatorName,
	)
	if err != nil {
		return "", "", nil, err
	}
	return currentUserID, copiedContent, copiedAtInfo, nil
}

func prependCopiedApprovalCommentAttribution(
	ctx context.Context,
	content string,
	atInfo []*larkapproval.CommentAtInfo,
	sourceCommentator string,
	sourceCommentatorName string,
) (string, []*larkapproval.CommentAtInfo, error) {
	var raw map[string]interface{}
	if err := json.Unmarshal([]byte(content), &raw); err != nil {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "解析审批评论内容失败: %s").WithArgs(err.Error())
	}
	text, _ := raw["text"].(string)
	prefixText := i18nfmt.Sprintf(ctx, "评论来自%s：", "@us")
	mentionByteOffset := strings.Index(prefixText, "@us")
	if mentionByteOffset < 0 {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论来源文案缺少@占位符")
	}
	mentionOffset := len([]rune(prefixText[:mentionByteOffset]))
	raw["text"] = prefixText + text

	copiedAtInfo := make([]*larkapproval.CommentAtInfo, 0, len(atInfo)+1)
	copiedAtInfo = append(copiedAtInfo, larkapproval.NewCommentAtInfoBuilder().
		UserId(sourceCommentator).
		Name(sourceCommentatorName).
		Offset(strconv.Itoa(mentionOffset)).
		Build())
	offsetShift := len([]rune(prefixText))
	for _, info := range atInfo {
		if info == nil || info.UserId == nil || info.Name == nil || info.Offset == nil {
			return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@信息不完整")
		}
		offset, err := strconv.Atoi(*info.Offset)
		if err != nil || offset < 0 {
			return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@偏移量非法")
		}
		copiedAtInfo = append(copiedAtInfo, larkapproval.NewCommentAtInfoBuilder().
			UserId(*info.UserId).
			Name(*info.Name).
			Offset(strconv.Itoa(offset+offsetShift)).
			Build())
	}

	copiedContent, err := json.Marshal(raw)
	if err != nil {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "构造审批评论内容失败: %s").WithArgs(err.Error())
	}
	return string(copiedContent), copiedAtInfo, nil
}

func createApprovalCommentWithCheck(
	ctx context.Context,
	instanceID string,
	queryUserID string,
	commentator string,
	content string,
	atInfo []*larkapproval.CommentAtInfo,
	parentID string,
	semanticKey string,
) (string, error) {
	builder := larkapproval.NewCommentRequestBuilder().Content(content).AtInfoList(atInfo).DisableBot(true)
	if parentID != "" {
		builder.ParentCommentId(parentID)
	}
	var lastErr error
	for attempt := 0; attempt < 2; attempt++ {
		commentID, err := lark_client.CreateApprovalInstanceComment(ctx, instanceID, commentator, builder.Build())
		if err == nil {
			return commentID, nil
		}
		lastErr = err

		// 网络超时不能直接重试写请求：先查询目标实例并按语义键确认是否已经成功创建。
		comments, queryErr := lark_client.ListApprovalInstanceComments(ctx, instanceID, queryUserID)
		if queryErr != nil {
			return "", errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "创建审批评论失败且复查失败: %s; %s").WithArgs(err, queryErr)
		}
		for _, comment := range comments {
			if isDeletedComment(comment) {
				continue
			}
			normalized, normalizedAtInfo, normalizeErr := normalizeCommentContent(comment.Content, comment.AtInfoList)
			if normalizeErr != nil {
				return "", normalizeErr
			}
			parentKey := approvalCommentKey(util.TrimStringValue(comment.Commentator), normalized, normalizedAtInfo)
			if parentID == "" && parentKey == semanticKey {
				return util.TrimStringValue(comment.Id), nil
			}
			for _, reply := range comment.Replies {
				if isDeletedReply(reply) {
					continue
				}
				replyContent, replyAtInfo, normalizeErr := normalizeCommentContent(reply.Content, reply.AtInfoList)
				if normalizeErr != nil {
					return "", normalizeErr
				}
				if approvalReplyKey(parentKey, util.TrimStringValue(reply.Commentator), replyContent, replyAtInfo) == semanticKey {
					return util.TrimStringValue(reply.Id), nil
				}
			}
		}
	}
	return "", errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "创建审批评论失败: %s").WithArgs(lastErr.Error())
}

func normalizeCommentContent(content *string, sourceAtInfo []*larkapproval.CommentAtInfo) (string, []*larkapproval.CommentAtInfo, error) {
	if content == nil || *content == "" {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论内容为空")
	}
	var raw map[string]interface{}
	if err := json.Unmarshal([]byte(*content), &raw); err != nil {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "解析审批评论内容失败: %s").WithArgs(err.Error())
	}
	text, _ := raw["text"].(string)
	files, hasFiles := raw["files"].([]interface{})
	if text == "" && (!hasFiles || len(files) == 0) {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论正文和附件均为空")
	}
	// 评论附件位于 content.files 中，创建评论时原样透传，父评论和回复使用同一套处理逻辑。

	type atPosition struct {
		info   *larkapproval.CommentAtInfo
		offset int
	}
	positions := make([]atPosition, 0, len(sourceAtInfo))
	for _, info := range sourceAtInfo {
		if info == nil || info.UserId == nil || info.Name == nil || info.Offset == nil {
			return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@信息不完整")
		}
		offset, err := strconv.Atoi(*info.Offset)
		if err != nil || offset < 0 {
			return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@偏移量非法")
		}
		positions = append(positions, atPosition{info: info, offset: offset})
	}
	sort.SliceStable(positions, func(i, j int) bool { return positions[i].offset < positions[j].offset })

	// 飞书 offset 按字符计算，使用 rune 而不是字节索引，避免中文字符导致偏移错误。
	runes := []rune(text)
	result := make([]rune, 0, len(runes))
	rebuiltAtInfo := make([]*larkapproval.CommentAtInfo, 0, len(positions))
	cursor := 0
	for _, position := range positions {
		if position.offset < cursor || position.offset >= len(runes) {
			return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@偏移量越界")
		}
		nameRunes := []rune(*position.info.Name)
		mentionEnd := position.offset + 1 + len(nameRunes)
		if mentionEnd > len(runes) || runes[position.offset] != '@' || string(runes[position.offset+1:mentionEnd]) != *position.info.Name {
			// 目标实例中的文本可能已经是 @us，占位符仍需参与幂等归一化。
			mentionEnd = position.offset + len([]rune("@us"))
			if mentionEnd > len(runes) || string(runes[position.offset:mentionEnd]) != "@us" {
				return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "审批评论@文本与偏移量不一致")
			}
		}
		result = append(result, runes[cursor:position.offset]...)
		targetOffset := len(result)
		// 创建接口要求正文使用 @us 占位符，同时 at_info_list 保留真实用户信息。
		result = append(result, []rune("@us")...)
		rebuiltAtInfo = append(rebuiltAtInfo, larkapproval.NewCommentAtInfoBuilder().
			UserId(*position.info.UserId).
			Name(*position.info.Name).
			Offset(strconv.Itoa(targetOffset)).
			Build())
		cursor = mentionEnd
	}
	result = append(result, runes[cursor:]...)
	raw["text"] = string(result)
	normalized, err := json.Marshal(raw)
	if err != nil {
		return "", nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "构造审批评论内容失败: %s").WithArgs(err.Error())
	}
	return string(normalized), rebuiltAtInfo, nil
}

func approvalCommentKey(commentator, content string, atInfo []*larkapproval.CommentAtInfo) string {
	return commentator + "\x00" + content + approvalCommentAtInfoKey(atInfo)
}

func approvalReplyKey(parentKey, commentator, content string, atInfo []*larkapproval.CommentAtInfo) string {
	return parentKey + "\x00" + approvalCommentKey(commentator, content, atInfo)
}

func approvalCommentAtInfoKey(atInfo []*larkapproval.CommentAtInfo) string {
	var key strings.Builder
	for _, info := range atInfo {
		if info == nil {
			continue
		}
		key.WriteString("\x00")
		key.WriteString(util.TrimStringValue(info.UserId))
		key.WriteString("\x00")
		key.WriteString(util.TrimStringValue(info.Offset))
	}
	return key.String()
}

func commentCreateTime(comment *larkapproval.Comment) int64 {
	if comment == nil {
		return 0
	}
	value, _ := strconv.ParseInt(util.TrimStringValue(comment.CreateTime), 10, 64)
	return value
}

func replyCreateTime(reply *larkapproval.CommentReply) int64 {
	if reply == nil {
		return 0
	}
	value, _ := strconv.ParseInt(util.TrimStringValue(reply.CreateTime), 10, 64)
	return value
}

func isDeletedComment(comment *larkapproval.Comment) bool {
	return comment == nil || (comment.IsDelete != nil && *comment.IsDelete != 0)
}

func isDeletedReply(reply *larkapproval.CommentReply) bool {
	return reply == nil || (reply.IsDelete != nil && *reply.IsDelete != 0)
}

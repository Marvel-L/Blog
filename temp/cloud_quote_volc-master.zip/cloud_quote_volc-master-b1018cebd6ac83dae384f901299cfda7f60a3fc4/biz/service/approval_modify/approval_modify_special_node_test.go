package approval_modify

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
)

func TestEvaluateApprovalModifySpecialNodeReasonUsesI18n(t *testing.T) {
	editCustomNodeID := "编辑｜1"
	tests := []struct {
		name       string
		quote      *model.Quote
		task       *larkapproval.InstanceTask
		source     string
		translated string
		mockRule   func()
	}{
		{
			name:       "财务BP节点",
			quote:      &model.Quote{QuoteType: multienv.QuoteTypeProjectBased},
			task:       newApprovalTask("task", "node", "user", constants.ApprovalTaskStatusPending, "100"),
			source:     "财务BP节点需重新审批",
			translated: "Financial BP node requires re-approval",
			mockRule: func() {
				mockey.MockUnsafe(approvalModifyQuoteItemsChanged).Return(true, nil).Build()
			},
		},
		{
			name:       "产品线负责人节点",
			task:       newApprovalTask("task", "node", "user", constants.ApprovalTaskStatusPending, "100"),
			source:     "产品线负责人节点需重新审批",
			translated: "Product line owner node requires re-approval",
			mockRule: func() {
				mockey.MockUnsafe(approvalModifyProductLineNeedsReview).Return(true, nil).Build()
			},
		},
		{
			name:       "编辑权限节点",
			task:       newApprovalTask("task", "node", "user", constants.ApprovalTaskStatusPending, "100"),
			source:     "编辑权限节点需重新审批",
			translated: "Edit permission node requires re-approval",
			mockRule: func() {
				mockey.MockUnsafe(approvalModifyEditNodeCanPass).Return(false, nil).Build()
			},
		},
	}
	tests[0].task.NodeName = stringPointer(constants.ApprovalNodeNameFinancialBP)
	tests[1].task.NodeName = stringPointer(constants.ApprovalNodeNameFirstProductLineOwner)
	tests[2].task.CustomNodeId = &editCustomNodeID

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				tt.mockRule()
				mockey.MockUnsafe(i18nfmt.Sprintf).
					To(func(_ context.Context, format string, args ...interface{}) string {
						if format != tt.source || len(args) != 0 {
							t.Fatalf("i18nfmt.Sprintf() = (%q, %v)", format, args)
						}
						return tt.translated
					}).Build()

				quote := tt.quote
				if quote == nil {
					quote = &model.Quote{}
				}
				canPass, reason, err := evaluateApprovalModifySpecialNode(
					context.Background(),
					&gorm.DB{},
					quote,
					nil,
					nil,
					tt.task,
				)
				if err != nil {
					t.Fatalf("evaluateApprovalModifySpecialNode() error = %v", err)
				}
				if canPass || reason != tt.translated {
					t.Fatalf("evaluateApprovalModifySpecialNode() = (%t, %q), want (false, %q)", canPass, reason, tt.translated)
				}
			})
		})
	}
}

func TestApprovalModifyEditNodeCanPassOnlyChecksNextNonEditNode(t *testing.T) {
	tests := []struct {
		name           string
		previousStatus string
		want           bool
	}{
		{name: "下一节点已通过", previousStatus: constants.ApprovalTaskStatusApproved, want: true},
		{name: "下一节点已结束", previousStatus: constants.ApprovalTaskStatusDone, want: true},
		{name: "下一节点未通过", previousStatus: constants.ApprovalTaskStatusPending, want: false},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				currentTask := newApprovalTask("edit-task", "edit-node", "editor", constants.ApprovalTaskStatusPending, "100")
				currentDetail := &larkapproval.GetInstanceRespData{
					ApprovalCode: stringPointer("approval-code"),
					InstanceCode: stringPointer("instance-code"),
				}
				previousDetail := &larkapproval.GetInstanceRespData{
					TaskList: []*larkapproval.InstanceTask{
						newApprovalTask("previous-next", "finance-node", "finance-user", tt.previousStatus, "200"),
					},
				}
				nextEditCustomNodeID := "编辑｜2"
				mockey.Mock(lark_client.PreviewApprovalInstance).Return(&larkapproval.PreviewInstanceRespData{
					PreviewNodes: []*larkapproval.PreviewNode{
						{
							NodeId:       stringPointer("edit-node-2"),
							CustomNodeId: &nextEditCustomNodeID,
							UserIdList:   []string{"other-editor"},
						},
						{
							NodeId:     stringPointer("finance-node"),
							NodeName:   stringPointer("普通审批"),
							UserIdList: []string{"finance-user"},
						},
						{
							NodeId:     stringPointer("later-node"),
							UserIdList: []string{"unmatched-later-user"},
						},
					},
				}, nil).Build()

				got, err := approvalModifyEditNodeCanPass(
					context.Background(),
					&gorm.DB{},
					&model.Quote{},
					currentDetail,
					previousDetail,
					currentTask,
				)
				if err != nil {
					t.Fatalf("approvalModifyEditNodeCanPass() error = %v", err)
				}
				if got != tt.want {
					t.Fatalf("approvalModifyEditNodeCanPass() = %t, want %t", got, tt.want)
				}
			})
		})
	}
}

func TestApprovalModifyEditNodeCanPassChecksNextSpecialNode(t *testing.T) {
	tests := []struct {
		name            string
		nextNodeName    string
		nextCustomID    string
		want            bool
		mockSpecialRule func()
	}{
		{
			name:         "财务BP无报价项变化",
			nextNodeName: constants.ApprovalNodeNameFinancialBP,
			want:         true,
			mockSpecialRule: func() {
				mockey.MockUnsafe(approvalModifyQuoteItemsChanged).Return(false, nil).Build()
			},
		},
		{
			name:         "财务BP有报价项变化",
			nextNodeName: constants.ApprovalNodeNameFinancialBP,
			want:         false,
			mockSpecialRule: func() {
				mockey.MockUnsafe(approvalModifyQuoteItemsChanged).Return(true, nil).Build()
			},
		},
		{
			name:         "产品线综合折扣未降低",
			nextNodeName: constants.ApprovalNodeNameFirstProductLineOwner,
			nextCustomID: "飞连｜1",
			want:         true,
			mockSpecialRule: func() {
				mockey.MockUnsafe(approvalModifyProductLineNeedsReview).Return(false, nil).Build()
			},
		},
		{
			name:         "产品线综合折扣降低",
			nextNodeName: constants.ApprovalNodeNameSecondProductLineOwner,
			nextCustomID: "飞连｜1",
			want:         false,
			mockSpecialRule: func() {
				mockey.MockUnsafe(approvalModifyProductLineNeedsReview).Return(true, nil).Build()
			},
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				tt.mockSpecialRule()
				mockey.MockUnsafe(i18nfmt.Sprintf).
					To(func(_ context.Context, format string, _ ...interface{}) string {
						return format
					}).Build()
				currentTask := newApprovalTask("edit-task", "edit-node", "editor", constants.ApprovalTaskStatusPending, "100")
				currentDetail := &larkapproval.GetInstanceRespData{
					ApprovalCode: stringPointer("approval-code"),
					InstanceCode: stringPointer("instance-code"),
				}
				previousDetail := &larkapproval.GetInstanceRespData{
					TaskList: []*larkapproval.InstanceTask{
						newApprovalTask("previous-next", "next-node", "next-user", constants.ApprovalTaskStatusApproved, "200"),
					},
				}
				nextNode := &larkapproval.PreviewNode{
					NodeId:     stringPointer("next-node"),
					NodeName:   stringPointer(tt.nextNodeName),
					UserIdList: []string{"next-user"},
				}
				if tt.nextCustomID != "" {
					nextNode.CustomNodeId = stringPointer(tt.nextCustomID)
				}
				mockey.Mock(lark_client.PreviewApprovalInstance).Return(&larkapproval.PreviewInstanceRespData{
					PreviewNodes: []*larkapproval.PreviewNode{nextNode},
				}, nil).Build()

				got, err := approvalModifyEditNodeCanPass(
					context.Background(),
					&gorm.DB{},
					&model.Quote{},
					currentDetail,
					previousDetail,
					currentTask,
				)
				if err != nil {
					t.Fatalf("approvalModifyEditNodeCanPass() error = %v", err)
				}
				if got != tt.want {
					t.Fatalf("approvalModifyEditNodeCanPass() = %t, want %t", got, tt.want)
				}
			})
		})
	}
}

func TestQuoteItemMatchesProductLines(t *testing.T) {
	productLines := map[string]struct{}{
		"云基础": {},
		"飞连":  {},
	}
	tests := []struct {
		name string
		item *model.QuoteItem
		want bool
	}{
		{name: "一级产品线命中", item: &model.QuoteItem{ProductDepartmentName: "云基础"}, want: true},
		{name: "二级产品线命中", item: &model.QuoteItem{SecondaryProductLine: "飞连"}, want: true},
		{name: "一二级产品线均未命中", item: &model.QuoteItem{ProductDepartmentName: "计算", SecondaryProductLine: "对象存储"}, want: false},
		{name: "产品线为空", item: &model.QuoteItem{}, want: false},
		{name: "报价项为空", item: nil, want: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := quoteItemMatchesProductLines(tt.item, productLines); got != tt.want {
				t.Fatalf("quoteItemMatchesProductLines() = %t, want %t", got, tt.want)
			}
		})
	}
}

func TestParseApprovalNodeProductLines(t *testing.T) {
	tests := []struct {
		name     string
		customID string
		want     []string
		ok       bool
	}{
		{name: "只有编辑标记", customID: "编辑", want: []string{}, ok: true},
		{name: "编辑标记和全角序号", customID: "编辑｜2", want: []string{}, ok: true},
		{name: "单个产品线", customID: "云基础", want: []string{"云基础"}, ok: true},
		{name: "单个产品线和全角序号", customID: "云基础｜1", want: []string{"云基础"}, ok: true},
		{name: "多个产品线", customID: "云基础、存储、飞连", want: []string{"云基础", "存储", "飞连"}, ok: true},
		{name: "多个产品线和全角序号", customID: "云基础、存储、飞连｜2", want: []string{"云基础", "存储", "飞连"}, ok: true},
		{name: "产品线和编辑标记", customID: "云基础、编辑", want: []string{"云基础"}, ok: true},
		{name: "产品线编辑标记和全角序号", customID: "云基础、编辑｜3", want: []string{"云基础"}, ok: true},
		{name: "半角序号", customID: "飞连、计算|2", want: []string{"飞连", "计算"}, ok: true},
		{name: "分隔符后内容不参与解析", customID: "飞连、计算|invalid", want: []string{"飞连", "计算"}, ok: true},
		{name: "分隔符后为空", customID: "飞连、计算|", want: []string{"飞连", "计算"}, ok: true},
		{name: "分隔符前为空", customID: "｜1", ok: false},
		{name: "空值", customID: "", ok: false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, ok := parseApprovalNodeProductLines(tt.customID)
			if ok != tt.ok {
				t.Fatalf("ok = %v, want %v", ok, tt.ok)
			}
			if len(got) != len(tt.want) {
				t.Fatalf("lines = %v, want %v", got, tt.want)
			}
			for _, line := range tt.want {
				if _, exists := got[line]; !exists {
					t.Fatalf("lines = %v, missing %q", got, line)
				}
			}
		})
	}
}

func TestIsApprovalEditNode(t *testing.T) {
	withEdit := "飞连、编辑｜1"
	withoutEdit := "飞连、计算｜1"
	if !isApprovalEditNode(&withEdit) {
		t.Fatal("isApprovalEditNode() = false, want true")
	}
	if isApprovalEditNode(&withoutEdit) {
		t.Fatal("isApprovalEditNode() = true, want false")
	}
	if isApprovalEditNode(nil) {
		t.Fatal("isApprovalEditNode(nil) = true, want false")
	}
}

package approval_modify

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/datacompare"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/oa_service/quotediff"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

const maxApprovalPreviewNodes = 100

func evaluateApprovalModifySpecialNode(
	ctx context.Context,
	tx *gorm.DB,
	quote *model.Quote,
	currentDetail *larkapproval.GetInstanceRespData,
	previousDetail *larkapproval.GetInstanceRespData,
	currentTask *larkapproval.InstanceTask,
) (bool, string, error) {
	// 策略按财务 BP、产品线负责人、编辑权限顺序执行；任一规则要求重审即停止回放。
	nodeName := util.TrimStringValue(currentTask.NodeName)
	if nodeName == constants.ApprovalNodeNameFinancialBP {
		// 公有云由审批流中的“是否财务审批”字段决定能否到达本节点；
		// 项目制不再使用该字段。两类报价单到达本节点后，都按上一版本的报价项增删改决定是否重审。
		changed, err := approvalModifyQuoteItemsChanged(ctx, tx, quote)
		if err != nil {
			return false, "", err
		}
		if changed {
			return false, i18nfmt.Sprintf(ctx, "财务BP节点需重新审批"), nil
		}
	}

	if strings.Contains(nodeName, constants.ApprovalNodeNameFirstProductLineOwner) ||
		strings.Contains(nodeName, constants.ApprovalNodeNameSecondProductLineOwner) {
		// 仅当当前节点负责的产品线发生新增或折扣下降时，才需要重新人工审批。
		needReview, err := approvalModifyProductLineNeedsReview(ctx, tx, quote, currentTask)
		if err != nil {
			return false, "", err
		}
		if needReview {
			return false, i18nfmt.Sprintf(ctx, "产品线负责人节点需重新审批"), nil
		}
	}

	if isApprovalEditNode(currentTask.CustomNodeId) {
		// 编辑权限节点可能改变后续分支，只验证下一个非编辑审批节点的审批人仍可复用。
		canPass, err := approvalModifyEditNodeCanPass(ctx, tx, quote, currentDetail, previousDetail, currentTask)
		if err != nil {
			return false, "", err
		}
		if !canPass {
			return false, i18nfmt.Sprintf(ctx, "编辑权限节点需重新审批"), nil
		}
	}
	return true, "", nil
}

func approvalModifyQuoteItemsChanged(ctx context.Context, tx *gorm.DB, quote *model.Quote) (bool, error) {
	// 财务 BP 对报价项的任意新增、删除或修改都敏感，必须与最近一次快照比较。
	if quote.ParentSnapshotID == 0 {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]上一版本快照为空").WithArgs(quote.Id)
	}
	result, err := datacompare.NewDiffQuoteService().Diff(ctx, tx, quote.Id, quote.ParentSnapshotID)
	if err != nil {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]报价项Diff查询失败: %s").WithArgs(quote.Id, err.Error())
	}
	if result == nil || result.Items == nil {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]报价项Diff结果为空").WithArgs(quote.Id)
	}
	return len(result.Items.AddedList) > 0 || len(result.Items.DeletedList) > 0 || len(result.Items.ChangedList) > 0, nil
}

func approvalModifyProductLineNeedsReview(ctx context.Context, tx *gorm.DB, quote *model.Quote, task *larkapproval.InstanceTask) (bool, error) {
	// 自定义节点 ID 是产品线归属的唯一可靠来源；格式异常时失败关闭并交还人工审批。
	productLines, ok := parseApprovalNodeProductLines(util.TrimStringValue(task.CustomNodeId))
	if !ok {
		return true, nil
	}
	if quote.ParentSnapshotID == 0 {
		return true, nil
	}
	result, err := datacompare.NewDiffQuoteService().Diff(ctx, tx, quote.Id, quote.ParentSnapshotID)
	if err != nil {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]报价项Diff查询失败: %s").WithArgs(quote.Id, err.Error())
	}
	if result == nil || result.Items == nil {
		return true, nil
	}
	items, err := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, quote.Id, constants.ItemStatusAll, multienv.TradeProductTypeAll, constants.ItemSceneAll)
	if err != nil {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]报价项查询失败: %s").WithArgs(quote.Id, err.Error())
	}
	itemMap := make(map[int64]*model.QuoteItem, len(items))
	for _, item := range items {
		if item != nil {
			itemMap[item.Id] = item
		}
	}
	for _, rawID := range result.Items.AddedList {
		// 新增报价项直接触发其所属产品线重审；ID 或产品线无法解析时同样失败关闭。
		itemID, valid := interfaceToInt64(rawID)
		item := itemMap[itemID]
		if !valid || item == nil {
			return true, nil
		}
		if quoteItemMatchesProductLines(item, productLines) {
			return true, nil
		}
	}
	for itemID, details := range result.Items.ChangedDetails {
		parsedItemID, valid := interfaceToInt64(itemID)
		item := itemMap[parsedItemID]
		if !valid || item == nil {
			return true, nil
		}
		// 公有云读取综合折扣、私有云读取折扣字段，复用现有趋势判断避免口径分叉。
		if quotediff.GetTotalDiscountTrend(item, details) == datacompare.TrendDecrease &&
			quoteItemMatchesProductLines(item, productLines) {
			return true, nil
		}
	}
	return false, nil
}

// quoteItemMatchesProductLines 判断报价项的一、二级产品线是否命中节点配置的产品线集合。
func quoteItemMatchesProductLines(item *model.QuoteItem, productLines map[string]struct{}) bool {
	if item == nil {
		return false
	}
	_, firstProductLineExists := productLines[item.ProductDepartmentName]
	_, secondProductLineExists := productLines[item.SecondaryProductLine]
	return firstProductLineExists || secondProductLineExists
}

func approvalModifyEditNodeCanPass(
	ctx context.Context,
	tx *gorm.DB,
	quote *model.Quote,
	currentDetail *larkapproval.GetInstanceRespData,
	previousDetail *larkapproval.GetInstanceRespData,
	currentTask *larkapproval.InstanceTask,
) (bool, error) {
	if currentDetail == nil || currentDetail.ApprovalCode == nil || currentDetail.InstanceCode == nil ||
		currentTask == nil || currentTask.Id == nil || currentTask.UserId == nil {
		return false, nil
	}
	req := larkapproval.NewPreviewInstanceReqBuilder().
		UserIdType("user_id").
		Body(larkapproval.NewPreviewInstanceReqBodyBuilder().
			UserId(*currentTask.UserId).
			ApprovalCode(*currentDetail.ApprovalCode).
			InstanceCode(*currentDetail.InstanceCode).
			TaskId(*currentTask.Id).
			Build()).
		Build()
	preview, err := lark_client.PreviewApprovalInstance(ctx, req)
	if err != nil {
		return false, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]审批实例预览失败: %s").WithArgs(quote.Id, err.Error())
	}
	// 预览结果缺失或节点数异常时不自动审批，防止流程配置异常造成误通过。
	if preview == nil || len(preview.PreviewNodes) > maxApprovalPreviewNodes {
		return false, nil
	}
	for _, node := range preview.PreviewNodes {
		if node == nil || util.TrimStringValue(node.NodeId) == util.TrimStringValue(currentTask.NodeId) {
			continue
		}
		// 连续编辑节点不参与历史审批状态判断，继续查找下一个实际审批节点。
		if isApprovalEditNode(node.CustomNodeId) {
			continue
		}
		if node.NodeId == nil {
			return false, nil
		}
		if len(node.UserIdList) == 0 {
			continue
		}
		previewTask := &larkapproval.InstanceTask{
			NodeId:       node.NodeId,
			NodeName:     node.NodeName,
			CustomNodeId: node.CustomNodeId,
			UserId:       &node.UserIdList[0],
		}
		for userIndex := range node.UserIdList {
			// 预览节点没有 task_id，以 node_id + user_id 在旧实例中验证是否已经通过。
			previousTask := findAnyPreviousTask(previousDetail.TaskList, &larkapproval.InstanceTask{
				NodeId:       node.NodeId,
				NodeName:     node.NodeName,
				CustomNodeId: node.CustomNodeId,
				UserId:       &node.UserIdList[userIndex],
			})
			if !approvalTaskPassed(previousTask) {
				return false, nil
			}
		}
		canPass, _, evaluateErr := evaluateApprovalModifySpecialNode(ctx, tx, quote, currentDetail, previousDetail, previewTask)
		if evaluateErr != nil || !canPass {
			return false, evaluateErr
		}
		// 编辑节点只校验下一个非编辑审批节点；更远节点在流程实际到达时再独立判断。
		return true, nil
	}
	return true, nil
}

func findAnyPreviousTask(previousTasks []*larkapproval.InstanceTask, target *larkapproval.InstanceTask) *larkapproval.InstanceTask {
	targetKey, ok := newApprovalTaskKey(target)
	if !ok {
		return nil
	}
	for _, task := range previousTasks {
		key, valid := newApprovalTaskKey(task)
		if valid && key == targetKey && approvalTaskPassed(task) {
			return task
		}
	}
	return nil
}

func parseApprovalNodeProductLines(customNodeID string) (map[string]struct{}, bool) {
	customNodeID = strings.TrimSpace(customNodeID)
	if customNodeID == "" {
		return nil, false
	}
	// 统一全角、半角分隔符。分隔符后的节点序号不参与产品线解析，
	// 因此只保留第一个分隔符前的产品线和“编辑”标记。
	customNodeID = strings.ReplaceAll(customNodeID, constants.ApprovalNodeCustomIDSequenceSeparatorCN, constants.ApprovalNodeCustomIDSequenceSeparator)
	if index := strings.Index(customNodeID, constants.ApprovalNodeCustomIDSequenceSeparator); index >= 0 {
		customNodeID = customNodeID[:index]
	}
	customNodeID = strings.TrimSpace(customNodeID)
	if customNodeID == "" {
		return nil, false
	}

	result := make(map[string]struct{})
	hasValidPart := false
	for _, part := range strings.Split(customNodeID, "、") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		hasValidPart = true
		if part == constants.ApprovalNodeCustomIDEditMarker {
			continue
		}
		result[part] = struct{}{}
	}
	// 纯“编辑”节点没有产品线，但格式本身合法，交由编辑节点策略继续处理。
	return result, hasValidPart
}

func isApprovalEditNode(customNodeID *string) bool {
	if customNodeID == nil {
		return false
	}
	normalized := strings.ReplaceAll(*customNodeID, constants.ApprovalNodeCustomIDSequenceSeparatorCN, constants.ApprovalNodeCustomIDSequenceSeparator)
	if index := strings.LastIndex(normalized, constants.ApprovalNodeCustomIDSequenceSeparator); index >= 0 {
		normalized = normalized[:index]
	}
	// “编辑”必须是独立标记，避免产品线名称中包含相同文字时误判。
	for _, part := range strings.Split(normalized, "、") {
		if strings.TrimSpace(part) == constants.ApprovalNodeCustomIDEditMarker {
			return true
		}
	}
	return false
}

func interfaceToInt64(value interface{}) (int64, bool) {
	var (
		result int64
		err    error
	)
	switch typed := value.(type) {
	case string:
		result, err = strconv.ParseInt(typed, 10, 64)
	case int64:
		result = typed
	case int:
		result = int64(typed)
	case json.Number:
		result, err = strconv.ParseInt(string(typed), 10, 64)
	default:
		result, err = strconv.ParseInt(fmt.Sprint(value), 10, 64)
	}
	return result, err == nil && result > 0
}

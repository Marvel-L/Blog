package approval_modify

import (
	"testing"

	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

func TestMatchPreviousApprovalTask(t *testing.T) {
	t.Run("按节点和审批人匹配", func(t *testing.T) {
		current := newApprovalTask("current", "node", "user", "PENDING", "200")
		previousTasks := []*larkapproval.InstanceTask{
			newApprovalTask("other-user", "node", "other", "APPROVED", "100"),
			newApprovalTask("previous", "node", "user", "APPROVED", "200"),
		}

		got := matchPreviousApprovalTask(previousTasks, current)
		if got == nil || util.TrimStringValue(got.Id) != "previous" {
			t.Fatalf("matchPreviousApprovalTask() = %v, want previous", util.TrimStringValue(got.Id))
		}
	})

	t.Run("节点或审批人不同不匹配", func(t *testing.T) {
		current := newApprovalTask("current", "node-a", "user-a", "PENDING", "100")
		got := matchPreviousApprovalTask(
			[]*larkapproval.InstanceTask{newApprovalTask("previous", "node-a", "user-b", "APPROVED", "100")},
			current,
		)
		if got != nil {
			t.Fatalf("matchPreviousApprovalTask() = %v, want nil", util.TrimStringValue(got.Id))
		}
	})
}

func TestApprovalTaskPassed(t *testing.T) {
	if !approvalTaskPassed(newApprovalTask("approved", "node", "user", constants.ApprovalTaskStatusApproved, "100")) {
		t.Fatal("approvalTaskPassed(APPROVED) = false, want true")
	}
	if !approvalTaskPassed(newApprovalTask("done", "node", "user", constants.ApprovalTaskStatusDone, "100")) {
		t.Fatal("approvalTaskPassed(DONE) = false, want true")
	}
}

func newApprovalTask(id, nodeID, userID, status, startTime string) *larkapproval.InstanceTask {
	task := &larkapproval.InstanceTask{
		Id:     stringPointer(id),
		NodeId: stringPointer(nodeID),
		UserId: stringPointer(userID),
		Status: stringPointer(status),
	}
	if startTime != "" {
		task.StartTime = stringPointer(startTime)
	}
	return task
}

func stringPointer(value string) *string {
	return &value
}

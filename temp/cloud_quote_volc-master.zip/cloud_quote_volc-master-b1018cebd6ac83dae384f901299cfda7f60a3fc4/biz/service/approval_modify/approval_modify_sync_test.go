package approval_modify

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"github.com/bytedance/mockey"
	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

func TestSyncQuote(t *testing.T) {
	t.Run("非待同步状态直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(&model.Quote{
				BaseDB:      framework.BaseDB{Id: 1},
				QuoteStatus: constants.StatusInitialed,
			}, nil).Build()

			if err := SyncQuote(context.Background(), 1); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
		})
	})

	t.Run("审批实例未就绪返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(2)
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{{ApprovalInstanceId: "current"}}, nil).Build()

			if err := SyncQuote(context.Background(), quote.Id); err == nil {
				t.Fatal("SyncQuote() error = nil, want non-nil")
			}
		})
	})

	t.Run("无可回放待审批任务返回审批进度同步业务错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(20)
			previousDetail := approvalInstanceDetail("previous", "applicant", nil)
			currentDetail := approvalInstanceDetail("current", "applicant", nil)

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil)).Build()

			err := SyncQuote(context.Background(), quote.Id)
			apiErr, ok := err.(*pkg_errors.APIErrorStruct)
			if !ok {
				t.Fatalf("SyncQuote() error type = %T, want *errors.APIErrorStruct", err)
			}
			if apiErr.GetCodeInt() != int(pkg_errors.CodeNApprovalModifyProgressSyncFailed) {
				t.Fatalf("SyncQuote() codeN = %d, want %d", apiErr.GetCodeInt(), pkg_errors.CodeNApprovalModifyProgressSyncFailed)
			}
			if !strings.Contains(err.Error(), "报价单[20]当前审批实例无可回放待审批任务") {
				t.Fatalf("SyncQuote() error = %q, want no replayable task context", err.Error())
			}
		})
	})

	t.Run("上一版本无对应节点时完成同步并通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(3)
			previousDetail := approvalInstanceDetail("previous", "applicant", nil)
			currentTask := newApprovalTask("current-task", "new-node", "approver", constants.ApprovalTaskStatusPending, "100")
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{currentTask})

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil)).Build()
			commentsSynced := false
			mockey.Mock(lark_client.ListApprovalInstanceComments).
				To(func(context.Context, string, string) ([]*larkapproval.Comment, error) {
					commentsSynced = true
					return []*larkapproval.Comment{}, nil
				}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FinishApprovalModifySync")).Return(true, nil).Build()
			notifyCount := 0
			mockey.Mock(sendApprovalModifyFlowChangeNotification).
				To(func(context.Context, *model.Quote, *model.LarkApprovalInstance, string) error {
					if !commentsSynced {
						t.Fatal("global comments were not synced before sales operations notification")
					}
					notifyCount++
					return errors.New("send failed")
				}).Build()

			if err := SyncQuote(context.Background(), quote.Id); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
			if notifyCount != 1 {
				t.Fatalf("notification count = %d, want 1", notifyCount)
			}
		})
	})

	t.Run("上一版本任务拒绝时完成同步并通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(30)
			previousTask := newApprovalTask("previous-task", "node", "approver", constants.ApprovalTaskStatusRejected, "100")
			currentTask := newApprovalTask("current-task", "node", "approver", constants.ApprovalTaskStatusPending, "100")
			previousDetail := approvalInstanceDetail("previous", "applicant", []*larkapproval.InstanceTask{previousTask})
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{currentTask})

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil)).Build()
			mockey.Mock(lark_client.ListApprovalInstanceComments).Return([]*larkapproval.Comment{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FinishApprovalModifySync")).Return(true, nil).Build()

			notifyCount := 0
			mockey.Mock(sendApprovalModifyFlowChangeNotification).
				To(func(_ context.Context, _ *model.Quote, _ *model.LarkApprovalInstance, reason string) error {
					notifyCount++
					if reason != "到达发起审批中修改节点" {
						t.Fatalf("notification reason = %q", reason)
					}
					return nil
				}).Build()

			if err := SyncQuote(context.Background(), quote.Id); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
			if notifyCount != 1 {
				t.Fatalf("notification count = %d, want 1", notifyCount)
			}
		})
	})

	t.Run("会签节点跳过历史DONE审批人并由历史APPROVED审批人推进", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(4)
			previousTaskA := newApprovalTask("previous-task-a", "node", "approver-a", constants.ApprovalTaskStatusDone, "100")
			previousTaskB := newApprovalTask("previous-task-b", "node", "approver-b", constants.ApprovalTaskStatusApproved, "100")
			currentTaskA := newApprovalTask("current-task-a", "node", "approver-a", constants.ApprovalTaskStatusPending, "100")
			currentTaskB := newApprovalTask("current-task-b", "node", "approver-b", constants.ApprovalTaskStatusPending, "100")
			previousDetail := approvalInstanceDetail("previous", "applicant", []*larkapproval.InstanceTask{previousTaskA, previousTaskB})
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{currentTaskA, currentTaskB})
			completedDetail := approvalInstanceDetail("current", "applicant", nil)
			completedDetail.Status = stringPointer(constants.ApprovalTaskStatusApproved)

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil).
					Then(completedDetail, nil)).Build()
			mockey.Mock(lark_client.ListApprovalInstanceComments).Return([]*larkapproval.Comment{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FinishApprovalModifySync")).Return(true, nil).Build()
			approveCount := 0
			var approvedTaskID, approvedUserID string
			mockey.Mock(lark_client.ApproveApprovalTask).
				To(func(_ context.Context, param *larkapproval.TaskApprove) error {
					approveCount++
					approvedTaskID = util.TrimStringValue(param.TaskId)
					approvedUserID = util.TrimStringValue(param.UserId)
					return nil
				}).Build()

			if err := SyncQuote(context.Background(), quote.Id); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
			if approveCount != 1 {
				t.Fatalf("ApproveApprovalTask() calls = %d, want 1", approveCount)
			}
			if approvedTaskID != "current-task-b" || approvedUserID != "approver-b" {
				t.Fatalf("ApproveApprovalTask() task = %s, user = %s, want current-task-b/approver-b", approvedTaskID, approvedUserID)
			}
		})
	})

	t.Run("审批成功后任务状态未推进时停止重复审批", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(40)
			previousTask := newApprovalTask("previous-task", "node", "approver", constants.ApprovalTaskStatusApproved, "100")
			currentTask := newApprovalTask("current-task", "node", "approver", constants.ApprovalTaskStatusPending, "100")
			previousDetail := approvalInstanceDetail("previous", "applicant", []*larkapproval.InstanceTask{previousTask})
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{currentTask})

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil)).Build()
			approveCount := 0
			mockey.Mock(lark_client.ApproveApprovalTask).
				To(func(context.Context, *larkapproval.TaskApprove) error {
					approveCount++
					return nil
				}).Build()

			err := SyncQuote(context.Background(), quote.Id)
			if err == nil || !strings.Contains(err.Error(), "状态未推进") {
				t.Fatalf("SyncQuote() error = %v, want task not progressed error", err)
			}
			if approveCount != 1 {
				t.Fatalf("ApproveApprovalTask() calls = %d, want 1", approveCount)
			}
		})
	})

	t.Run("审批通过时附件作为当前审批人的全局评论", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Sprintf).Return("审批通过时附带的文件").Build()
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(5)
			previousTask := newApprovalTask("previous-task", "node", "approver", constants.ApprovalTaskStatusApproved, "100")
			currentTask := newApprovalTask("current-task", "node", "approver", constants.ApprovalTaskStatusPending, "100")
			currentTask.NodeName = stringPointer("销售负责人")
			previousDetail := approvalInstanceDetail("previous", "applicant", []*larkapproval.InstanceTask{previousTask})
			previousDetail.Timeline = []*larkapproval.InstanceTimeline{{
				TaskId:  stringPointer("previous-task"),
				Comment: stringPointer("审批通过，请查收附件"),
				Files: []*larkapproval.File{
					larkapproval.NewFileBuilder().
						Url("https://example.com/screenshot.png").
						FileSize(1024).
						Title("screenshot.png").
						Type("image").
						Build(),
					larkapproval.NewFileBuilder().
						Url("https://example.com/document.pdf").
						FileSize(2048).
						Title("document.pdf").
						Type("attachment").
						Build(),
				},
			}}
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{currentTask})
			completedDetail := approvalInstanceDetail("current", "applicant", nil)
			completedDetail.Status = stringPointer(constants.ApprovalTaskStatusApproved)

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil).
					Then(completedDetail, nil)).Build()
			mockey.Mock(lark_client.ListApprovalInstanceComments).Return([]*larkapproval.Comment{}, nil).Build()

			createdCommentCount := 0
			var createdCommentUserID string
			var createdComment *larkapproval.CommentRequest
			mockey.Mock(lark_client.CreateApprovalInstanceComment).
				To(func(_ context.Context, instanceID, userID string, req *larkapproval.CommentRequest) (string, error) {
					if instanceID != "current" {
						t.Fatalf("CreateApprovalInstanceComment() instanceID = %s, want current", instanceID)
					}
					createdCommentCount++
					createdCommentUserID = userID
					createdComment = req
					return "comment-id", nil
				}).Build()
			var approveParam *larkapproval.TaskApprove
			mockey.Mock(lark_client.ApproveApprovalTask).
				To(func(_ context.Context, param *larkapproval.TaskApprove) error {
					if createdCommentCount == 0 {
						t.Fatal("ApproveApprovalTask() called before attachment comment was created")
					}
					approveParam = param
					return nil
				}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FinishApprovalModifySync")).Return(true, nil).Build()

			if err := SyncQuote(context.Background(), quote.Id); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
			if approveParam == nil || util.TrimStringValue(approveParam.Comment) != "审批通过，请查收附件" {
				t.Fatalf("ApproveApprovalTask() comment = %v, want source text", approveParam)
			}
			if createdCommentCount != 1 || createdCommentUserID != "approver" ||
				createdComment == nil || createdComment.Content == nil {
				t.Fatalf("attachment comment = (%d, %s, %+v)", createdCommentCount, createdCommentUserID, createdComment)
			}
			var comment struct {
				Text  string `json:"text"`
				Files []struct {
					URL      string `json:"url"`
					FileSize int    `json:"fileSize"`
					Title    string `json:"title"`
					Type     string `json:"type"`
				} `json:"files"`
			}
			if err := json.Unmarshal([]byte(*createdComment.Content), &comment); err != nil {
				t.Fatalf("attachment comment is invalid json: %v", err)
			}
			if comment.Text != "【销售负责人】审批通过时附带的文件" || len(comment.Files) != 2 {
				t.Fatalf("attachment comment = %+v, want node text and two attachments", comment)
			}
			if comment.Files[0].URL != "https://example.com/screenshot.png" ||
				comment.Files[0].FileSize != 1024 ||
				comment.Files[0].Title != "screenshot.png" ||
				comment.Files[0].Type != "image" {
				t.Fatalf("attachment comment image = %+v, want source image", comment.Files[0])
			}
			if comment.Files[1].URL != "https://example.com/document.pdf" ||
				comment.Files[1].FileSize != 2048 ||
				comment.Files[1].Title != "document.pdf" ||
				comment.Files[1].Type != "attachment" {
				t.Fatalf("attachment comment file = %+v, want source attachment", comment.Files[1])
			}
		})
	})

	t.Run("先推进审批再按最终详情权限复制全局评论", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Sprintf).Return("评论来自@us：").Build()
			tx := &gorm.DB{}
			quote := targetApprovalModifyQuote(6)
			previousTask := newApprovalTask("previous-task", "node", "approver", constants.ApprovalTaskStatusApproved, "100")
			currentTask := newApprovalTask("current-task", "node", "approver", constants.ApprovalTaskStatusPending, "100")
			doneTask := newApprovalTask("done-task", "other-node", "done-user", constants.ApprovalTaskStatusDone, "90")
			previousDetail := approvalInstanceDetail("previous", "applicant", []*larkapproval.InstanceTask{previousTask})
			currentDetail := approvalInstanceDetail("current", "applicant", []*larkapproval.InstanceTask{doneTask, currentTask})
			completedDetail := approvalInstanceDetail("current", "applicant", nil)
			completedDetail.Status = stringPointer(constants.ApprovalTaskStatusApproved)
			sourceContent := `{"text":"原评论内容"}`
			sourceComments := []*larkapproval.Comment{
				larkapproval.NewCommentBuilder().
					Id("approver-comment").
					Content(`{"text":"审批人评论"}`).
					Commentator("approver").
					Build(),
				larkapproval.NewCommentBuilder().
					Id("source-comment").
					Content(sourceContent).
					Commentator("done-user").
					Build(),
			}

			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(quote, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.LarkApprovalInstanceDao, "ListLatestByEntityAndTypes")).
				Return([]*model.LarkApprovalInstance{
					{ApprovalInstanceId: "current"},
					{ApprovalInstanceId: "previous"},
				}, nil).Build()
			mockey.Mock(lark_client.QueryApprovalInstanceDetailDirect).
				Return(mockey.Sequence(previousDetail, nil).
					Then(currentDetail, nil).
					Then(currentDetail, nil).
					Then(completedDetail, nil)).Build()

			approvalProgressed := false
			mockey.Mock(lark_client.ApproveApprovalTask).
				To(func(context.Context, *larkapproval.TaskApprove) error {
					approvalProgressed = true
					return nil
				}).Build()
			mockey.Mock(lark_client.ListApprovalInstanceComments).
				To(func(_ context.Context, instanceID, _ string) ([]*larkapproval.Comment, error) {
					if !approvalProgressed {
						t.Fatal("global comments were queried before approval progress replay")
					}
					if instanceID == "previous" {
						return sourceComments, nil
					}
					return []*larkapproval.Comment{}, nil
				}).Build()
			mockey.Mock(lark_client.GetUserNameByUserID).
				To(func(_ context.Context, userID string) (string, error) {
					switch userID {
					case "approver":
						return "审批人", nil
					case "done-user":
						return "原评论人", nil
					default:
						t.Fatalf("GetUserNameByUserID() userID = %s, want approver or done-user", userID)
						return "", nil
					}
				}).Build()

			var createdUserIDs []string
			var createdComments []*larkapproval.CommentRequest
			mockey.Mock(lark_client.CreateApprovalInstanceComment).
				To(func(_ context.Context, instanceID, userID string, req *larkapproval.CommentRequest) (string, error) {
					if instanceID != "current" {
						t.Fatalf("CreateApprovalInstanceComment() instanceID = %s, want current", instanceID)
					}
					createdUserIDs = append(createdUserIDs, userID)
					createdComments = append(createdComments, req)
					return "copied-comment", nil
				}).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FinishApprovalModifySync")).Return(true, nil).Build()

			if err := SyncQuote(context.Background(), quote.Id); err != nil {
				t.Fatalf("SyncQuote() error = %v", err)
			}
			if len(createdUserIDs) != 2 || createdUserIDs[0] != "applicant" || createdUserIDs[1] != "applicant" {
				t.Fatalf("created comment userIDs = %v, want [applicant applicant]", createdUserIDs)
			}
			var approverContent struct {
				Text string `json:"text"`
			}
			if err := json.Unmarshal([]byte(util.TrimStringValue(createdComments[0].Content)), &approverContent); err != nil {
				t.Fatalf("approver comment content is invalid json: %v", err)
			}
			if approverContent.Text != "评论来自@us：审批人评论" ||
				len(createdComments[0].AtInfoList) != 1 ||
				util.TrimStringValue(createdComments[0].AtInfoList[0].UserId) != "approver" {
				t.Fatalf("copied approver comment = %+v, want source attribution", createdComments[0])
			}
			createdComment := createdComments[1]
			if createdComment == nil || createdComment.Content == nil || len(createdComment.AtInfoList) != 1 {
				t.Fatalf("copied comment request = %+v, want content and source attribution", createdComment)
			}
			var copiedContent struct {
				Text string `json:"text"`
			}
			if err := json.Unmarshal([]byte(*createdComment.Content), &copiedContent); err != nil {
				t.Fatalf("copied comment content is invalid json: %v", err)
			}
			if copiedContent.Text != "评论来自@us：原评论内容" {
				t.Fatalf("copied comment text = %q", copiedContent.Text)
			}
			if util.TrimStringValue(createdComment.AtInfoList[0].UserId) != "done-user" {
				t.Fatalf("copied comment mentioned user = %s, want done-user", util.TrimStringValue(createdComment.AtInfoList[0].UserId))
			}
		})
	})

	t.Run("报价单查询错误转换为审批进度同步业务错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tx := &gorm.DB{}
			wantErr := errors.New("query failed")
			mockey.Mock(mockey.GetMethod(dal.DBProxy, "NewRequest")).Return(tx).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return((*model.Quote)(nil), wantErr).Build()

			err := SyncQuote(context.Background(), 7)
			apiErr, ok := err.(*pkg_errors.APIErrorStruct)
			if !ok {
				t.Fatalf("SyncQuote() error type = %T, want *errors.APIErrorStruct", err)
			}
			if apiErr.GetCodeInt() != int(pkg_errors.CodeNApprovalModifyProgressSyncFailed) {
				t.Fatalf("SyncQuote() codeN = %d, want %d", apiErr.GetCodeInt(), pkg_errors.CodeNApprovalModifyProgressSyncFailed)
			}
			if !strings.Contains(err.Error(), "报价单[7]查询失败: query failed") {
				t.Fatalf("SyncQuote() error = %q, want quote query context", err.Error())
			}
		})
	})
}

func TestSyncApprovalTaskAttachmentsAsCommentUsesI18n(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		mockey.MockUnsafe(i18nfmt.Sprintf).
			To(func(_ context.Context, format string, args ...interface{}) string {
				if format != "审批通过时附带的文件" || len(args) != 0 {
					t.Fatalf("i18nfmt.Sprintf() = (%q, %v)", format, args)
				}
				return "Files attached upon approval"
			}).Build()
		state := &approvalModifySyncState{
			currentInstance: &model.LarkApprovalInstance{ApprovalInstanceId: "current"},
			currentUserID:   "applicant",
		}
		task := newApprovalTask("task", "node", "approver", constants.ApprovalTaskStatusPending, "100")
		task.NodeName = stringPointer("Sales Manager")
		createdCommentCount := 0
		var createdComment *larkapproval.CommentRequest
		mockey.Mock(lark_client.CreateApprovalInstanceComment).
			To(func(_ context.Context, instanceID, userID string, req *larkapproval.CommentRequest) (string, error) {
				if instanceID != "current" || userID != "approver" {
					t.Fatalf("CreateApprovalInstanceComment() = (%q, %q), want (current, approver)", instanceID, userID)
				}
				createdCommentCount++
				createdComment = req
				return "comment-id", nil
			}).Build()

		files := []*larkapproval.File{
			larkapproval.NewFileBuilder().
				Url("https://example.com/document.pdf").
				FileSize(2048).
				Title("document.pdf").
				Type("attachment").
				Build(),
		}
		err := state.syncApprovalTaskAttachmentsAsComment(context.Background(), task, files)
		if err != nil {
			t.Fatalf("syncApprovalTaskAttachmentsAsComment() error = %v", err)
		}
		var parsed struct {
			Text string `json:"text"`
		}
		if createdComment == nil || createdComment.Content == nil {
			t.Fatalf("created comment = %+v, want content", createdComment)
		}
		if err := json.Unmarshal([]byte(*createdComment.Content), &parsed); err != nil {
			t.Fatalf("attachment comment is invalid json: %v", err)
		}
		if parsed.Text != "【Sales Manager】Files attached upon approval" {
			t.Fatalf("attachment comment text = %q", parsed.Text)
		}

		if err := state.syncApprovalTaskAttachmentsAsComment(context.Background(), task, []*larkapproval.File{nil}); err != nil {
			t.Fatalf("syncApprovalTaskAttachmentsAsComment() with empty files error = %v", err)
		}
		if createdCommentCount != 1 {
			t.Fatalf("created comment count = %d, want 1", createdCommentCount)
		}

		if err := state.syncApprovalTaskAttachmentsAsComment(context.Background(), nil, files); err == nil {
			t.Fatal("syncApprovalTaskAttachmentsAsComment() with nil task error = nil, want non-nil")
		}
	})
}

func targetApprovalModifyQuote(id int64) *model.Quote {
	return &model.Quote{
		BaseDB:           framework.BaseDB{Id: id},
		QuoteStatus:      constants.StatusSubmit,
		ModifyStatus:     constants.ApprovalModifyStatusSubmitted,
		OriginSnapshotID: 1,
	}
}

func approvalInstanceDetail(instanceID, userID string, tasks []*larkapproval.InstanceTask) *larkapproval.GetInstanceRespData {
	status := constants.ApprovalTaskStatusPending
	approvalCode := "approval-code"
	return &larkapproval.GetInstanceRespData{
		InstanceCode: &instanceID,
		ApprovalCode: &approvalCode,
		UserId:       &userID,
		Status:       &status,
		TaskList:     tasks,
	}
}

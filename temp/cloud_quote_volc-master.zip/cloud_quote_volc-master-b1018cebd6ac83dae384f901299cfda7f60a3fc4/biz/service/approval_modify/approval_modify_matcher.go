package approval_modify

import (
	"sort"
	"strconv"

	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type approvalTaskKey struct {
	NodeID string
	UserID string
}

// newApprovalTaskKey 同时使用节点和审批人定位任务，避免会签节点内不同审批人互相匹配。
func newApprovalTaskKey(task *larkapproval.InstanceTask) (approvalTaskKey, bool) {
	if task == nil || task.NodeId == nil || task.UserId == nil || *task.NodeId == "" || *task.UserId == "" {
		return approvalTaskKey{}, false
	}
	return approvalTaskKey{NodeID: *task.NodeId, UserID: *task.UserId}, true
}

// pendingApprovalTasks 只返回当前可操作的 PENDING 任务，已通过或被或签结束的任务不参与选择。
func pendingApprovalTasks(tasks []*larkapproval.InstanceTask) []*larkapproval.InstanceTask {
	var pending []*larkapproval.InstanceTask
	for _, task := range tasks {
		if task != nil && task.Status != nil && *task.Status == constants.ApprovalTaskStatusPending {
			pending = append(pending, task)
		}
	}
	return sortApprovalTasksByStartTime(pending)
}

// firstReplayableApprovalTask 跳过历史状态为 DONE 的审批人。或签场景应由历史实际
// 审批通过的人推进当前节点，飞书会自动把同节点其他待审批任务置为 DONE。
func firstReplayableApprovalTask(
	previousTasks []*larkapproval.InstanceTask,
	currentTasks []*larkapproval.InstanceTask,
) (*larkapproval.InstanceTask, *larkapproval.InstanceTask) {
	for _, currentTask := range pendingApprovalTasks(currentTasks) {
		previousTask := matchPreviousApprovalTask(previousTasks, currentTask)
		if previousTask != nil && util.TrimStringValue(previousTask.Status) == constants.ApprovalTaskStatusDone {
			continue
		}
		return currentTask, previousTask
	}
	return nil, nil
}

func approvalTaskStartTime(task *larkapproval.InstanceTask) (int64, bool) {
	if task == nil || task.StartTime == nil || *task.StartTime == "" {
		return 0, false
	}
	value, err := strconv.ParseInt(*task.StartTime, 10, 64)
	return value, err == nil
}

// sortApprovalTasksByStartTime 返回按开始时间稳定排序的副本。任一任务缺失合法时间时，
// 整体保持飞书接口返回顺序，避免把未知时间错误地当作最早时间。
func sortApprovalTasksByStartTime(tasks []*larkapproval.InstanceTask) []*larkapproval.InstanceTask {
	result := append([]*larkapproval.InstanceTask(nil), tasks...)
	for _, task := range result {
		_, ok := approvalTaskStartTime(task)
		if !ok {
			return result
		}
	}
	sort.SliceStable(result, func(i, j int) bool {
		left, _ := approvalTaskStartTime(result[i])
		right, _ := approvalTaskStartTime(result[j])
		return left < right
	})
	return result
}

// matchPreviousApprovalTask 使用审批实例内唯一的 node_id + user_id 匹配上一版本任务。
func matchPreviousApprovalTask(
	previousTasks []*larkapproval.InstanceTask,
	currentTask *larkapproval.InstanceTask,
) *larkapproval.InstanceTask {
	key, ok := newApprovalTaskKey(currentTask)
	if !ok {
		return nil
	}

	for _, task := range previousTasks {
		taskKey, valid := newApprovalTaskKey(task)
		if valid && taskKey == key {
			return task
		}
	}
	return nil
}

func approvalTaskPassed(task *larkapproval.InstanceTask) bool {
	// DONE 可用于编辑节点预览的历史完成性校验；直接回放时由选择器跳过该审批人。
	return task != nil && task.Status != nil &&
		(*task.Status == constants.ApprovalTaskStatusApproved || *task.Status == constants.ApprovalTaskStatusDone)
}

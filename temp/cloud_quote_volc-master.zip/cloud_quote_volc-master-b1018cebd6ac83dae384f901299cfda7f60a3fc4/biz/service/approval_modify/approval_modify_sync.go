package approval_modify

import (
	"context"

	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

const (
	// LogPrefix is shared by the scheduled job and operational logs.
	LogPrefix                    = "ApprovalModifyProgressSync"
	maxApprovalModifyReplaySteps = 1000
)

type approvalModifySyncState struct {
	quote                    *model.Quote                      // 报价单
	previousInstance         *model.LarkApprovalInstance       // 上一审批实例
	previousDetail           *larkapproval.GetInstanceRespData // 上一审批实例详情
	previousUserID           string                            // 上一审批实例处理人
	currentInstance          *model.LarkApprovalInstance       // 当前审批实例
	currentDetail            *larkapproval.GetInstanceRespData // 当前审批实例详情
	currentUserID            string                            // 当前审批实例处理人
	previousTaskOpinions     map[string]approvalTaskOpinion    // 上一审批实例任务意见
	approvedTaskIDs          map[string]struct{}               // 已审批任务ID
	commentAuthorizedUserIDs map[string]struct{}               // 已授权评论用户ID
}

func SyncQuote(ctx context.Context, quoteID int64) (err error) {
	tx := dal.DBProxy.NewRequest(ctx)
	syncState, err := newApprovalModifySyncState(ctx, tx, quoteID)
	if err != nil || syncState == nil {
		return err
	}

	for step := 0; step < maxApprovalModifyReplaySteps; step++ {
		// 每次只处理一个任务并重新查询实例。或签会把同节点其他任务置为 DONE，
		// 编辑节点也可能改变后续流程，复用旧任务列表会产生重复审批或误匹配。
		syncState.currentDetail, err = lark_client.QueryApprovalInstanceDetailDirect(ctx, syncState.currentInstance.ApprovalInstanceId)
		if err != nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]当前审批实例详情查询失败: %s").WithArgs(quoteID, err.Error())
		}
		if util.TrimStringValue(syncState.currentDetail.Status) != constants.ApprovalTaskStatusPending {
			// 报价最终状态由既有审批回调维护；这里仅结束“审批进度同步”阶段。
			return syncState.finish(ctx, tx, false, "当前审批实例已结束")
		}
		currentTask, previousTask := firstReplayableApprovalTask(syncState.previousDetail.TaskList, syncState.currentDetail.TaskList)
		if currentTask == nil {
			// 实例仍为审批中但暂时没有可回放任务，可能处于飞书状态切换窗口，
			// 或当前待审批人都对应历史 DONE。保持 modify_status=2，等待后续重试。
			return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]当前审批实例无可回放待审批任务").WithArgs(quoteID)
		}
		// node_id + user_id 在单个审批实例内唯一，用于匹配上一版本任务。
		if previousTask == nil {
			return syncState.finish(ctx, tx, true, "审批流发生变化：上一版本无对应节点")
		}

		switch util.TrimStringValue(previousTask.Status) {
		case constants.ApprovalTaskStatusRejected:
			// 历史拒绝节点是本次修改的人工起点，新实例停在当前节点，不模拟拒绝。
			return syncState.finish(ctx, tx, true, "到达发起审批中修改节点")
		case constants.ApprovalTaskStatusApproved:
			canPass, reason, evaluateErr := evaluateApprovalModifySpecialNode(ctx, tx, syncState.quote, syncState.currentDetail, syncState.previousDetail, currentTask)
			if evaluateErr != nil {
				return evaluateErr
			}
			if !canPass {
				return syncState.finish(ctx, tx, true, reason)
			}
		default:
			// 上一版本未完成的节点交还人工处理，不进行猜测性自动通过。
			return syncState.finish(ctx, tx, false, "到达需要人工审批的节点")
		}

		// 关键标识缺失时失败关闭，避免向错误实例或错误审批人发送写请求。
		if syncState.currentDetail.ApprovalCode == nil || syncState.currentDetail.InstanceCode == nil || currentTask.UserId == nil || currentTask.Id == nil {
			return syncState.finish(ctx, tx, true, "当前审批任务关键字段缺失")
		}
		currentTaskID := *currentTask.Id
		if _, exists := syncState.approvedTaskIDs[currentTaskID]; exists {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]审批任务[%s]状态未推进，等待下次重试").WithArgs(quoteID, currentTaskID)
		}
		previousTaskID := util.TrimStringValue(previousTask.Id)
		previousTaskOpinion := syncState.previousTaskOpinions[previousTaskID]
		if len(previousTaskOpinion.Files) > 0 {
			if syncErr := syncState.syncApprovalTaskAttachmentsAsComment(ctx, currentTask, previousTaskOpinion.Files); syncErr != nil {
				return syncErr
			}
		}
		// 审批同意
		param := larkapproval.NewTaskApproveBuilder().
			ApprovalCode(*syncState.currentDetail.ApprovalCode).
			InstanceCode(*syncState.currentDetail.InstanceCode).
			UserId(*currentTask.UserId).
			TaskId(*currentTask.Id).
			Comment(previousTaskOpinion.Comment).
			Build()
		if err = lark_client.ApproveApprovalTask(ctx, param); err != nil {
			// 写请求可能已在飞书侧成功但客户端超时。失败后先复查任务状态，
			// 只有任务仍为 PENDING 时才返回错误并等待下轮重试。
			latestDetail, queryErr := lark_client.QueryApprovalInstanceDetailDirect(ctx, syncState.currentInstance.ApprovalInstanceId)
			if queryErr != nil || lark_client.ApprovalTaskStillPending(latestDetail, util.TrimStringValue(currentTask.Id)) {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]审批任务[%s]自动通过失败: %s").WithArgs(quoteID, currentTaskID, err.Error())
			}
		}
		syncState.approvedTaskIDs[currentTaskID] = struct{}{}
		logs.CtxInfo(ctx, "%s task approved, quoteID=%d, taskID=%s, nodeID=%s, userID=%s, step=%d",
			LogPrefix, quoteID, util.TrimStringValue(currentTask.Id), util.TrimStringValue(currentTask.NodeId), util.TrimStringValue(currentTask.UserId), step)
	}
	return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]审批进度回放超过最大节点数%d").WithArgs(quoteID, maxApprovalModifyReplaySteps)
}

func newApprovalModifySyncState(ctx context.Context, tx *gorm.DB, quoteID int64) (*approvalModifySyncState, error) {
	quote, err := dal.QuoteDao.FindQuoteByID(tx, quoteID)
	if err != nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]查询失败: %s").WithArgs(quoteID, err.Error())
	}
	// 定时扫描结果可能因审批回调或人工操作而过期；进入服务后必须再次校验，
	// 不满足待同步条件时按幂等成功处理，避免重复操作审批任务。
	if quote.QuoteStatus != constants.StatusSubmit || quote.ModifyStatus != constants.ApprovalModifyStatusSubmitted || quote.OriginSnapshotID == 0 {
		return nil, nil
	}

	// 数据库只保存审批实例索引，节点和任务状态始终以飞书实时详情为准。
	currentInstance, previousInstance, err := loadApprovalModifyInstances(tx, quote)
	if err != nil {
		return nil, err
	}
	previousDetail, err := lark_client.QueryApprovalInstanceDetailDirect(ctx, previousInstance.ApprovalInstanceId)
	if err != nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]上一审批实例详情查询失败: %s").WithArgs(quoteID, err.Error())
	}
	currentDetail, err := lark_client.QueryApprovalInstanceDetailDirect(ctx, currentInstance.ApprovalInstanceId)
	if err != nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]当前审批实例详情查询失败: %s").WithArgs(quoteID, err.Error())
	}
	previousUserID := util.TrimStringValue(previousDetail.UserId)
	currentUserID := util.TrimStringValue(currentDetail.UserId)
	if previousUserID == "" || currentUserID == "" {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]审批实例发起人为空").WithArgs(quoteID)
	}
	return &approvalModifySyncState{
		quote:                    quote,
		previousInstance:         previousInstance,
		previousDetail:           previousDetail,
		previousUserID:           previousUserID,
		currentInstance:          currentInstance,
		currentDetail:            currentDetail,
		currentUserID:            currentUserID,
		previousTaskOpinions:     collectApprovalTaskOpinions(previousDetail.Timeline),
		approvedTaskIDs:          make(map[string]struct{}),
		commentAuthorizedUserIDs: make(map[string]struct{}),
	}, nil
}

func (s *approvalModifySyncState) addCommentAuthorizedUserIDs(detail *larkapproval.GetInstanceRespData) {
	if detail == nil {
		return
	}
	if userID := util.TrimStringValue(detail.UserId); userID != "" {
		s.commentAuthorizedUserIDs[userID] = struct{}{}
	}
	for _, task := range detail.TaskList {
		if task == nil {
			continue
		}
		switch util.TrimStringValue(task.Status) {
		case constants.ApprovalTaskStatusPending,
			constants.ApprovalTaskStatusApproved,
			constants.ApprovalTaskStatusRejected,
			constants.ApprovalTaskStatusDone:
		default:
			// DONE 表示审批人未实际操作，不作为评论授权依据。
			continue
		}
		if userID := util.TrimStringValue(task.UserId); userID != "" {
			s.commentAuthorizedUserIDs[userID] = struct{}{}
		}
	}
}

func loadApprovalModifyInstances(tx *gorm.DB, quote *model.Quote) (*model.LarkApprovalInstance, *model.LarkApprovalInstance, error) {
	// 公有云和项目制使用不同申请类型，禁止跨类型串联审批版本。
	applicationType := constants.QuoteApply
	if quote.IsProjectBased() {
		applicationType = constants.ProjectBasedQuoteApply
	}
	instances, err := dal.LarkApprovalInstanceDao.ListLatestByEntityAndTypes(tx, quote.Id, []constants.ApplicationType{applicationType}, 2)
	if err != nil {
		return nil, nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]新旧审批实例查询失败: %s").WithArgs(quote.Id, err.Error())
	}
	if len(instances) < 2 || instances[0] == nil || instances[1] == nil ||
		instances[0].ApprovalInstanceId == "" || instances[1].ApprovalInstanceId == "" ||
		instances[0].ApprovalInstanceId == instances[1].ApprovalInstanceId {
		return nil, nil, errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]新旧审批实例数据未就绪").WithArgs(quote.Id)
	}
	return instances[0], instances[1], nil
}

func (s *approvalModifySyncState) finish(
	ctx context.Context,
	tx *gorm.DB,
	notify bool,
	reason string,
) error {
	quoteID := s.quote.Id
	// 统计拥有全局评论权限的人员
	s.addCommentAuthorizedUserIDs(s.currentDetail)
	// 全局评论
	commentCount, err := s.syncApprovalInstanceComments(ctx)
	if err != nil {
		return err
	}
	logs.CtxInfo(ctx, "%s comments synced, quoteID=%d, count=%d", LogPrefix, quoteID, commentCount)

	// CAS 保证并发定时任务或审批回调只有一个执行方能完成状态迁移并发送通知。
	updated, err := dal.QuoteDao.FinishApprovalModifySync(tx, quoteID)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalModifyProgressSyncFailed, "报价单[%d]完成审批进度同步状态失败: %s").WithArgs(quoteID, err.Error())
	}
	if !updated {
		return nil
	}
	logs.CtxInfo(ctx, "%s finished, quoteID=%d, notify=%t, reason=%s", LogPrefix, quoteID, notify, reason)
	if notify {
		// 状态已完成后再发送卡片；通知失败只记录日志，避免回滚后被定时任务重复通知。
		if notifyErr := sendApprovalModifyFlowChangeNotification(ctx, s.quote, s.currentInstance, reason); notifyErr != nil {
			logs.CtxError(ctx, "%s send flow change notification failed, quoteID=%d, err=%s", LogPrefix, quoteID, notifyErr.Error())
		}
	}
	return nil
}

package approval_modify

import (
	"context"
	"fmt"
	"strings"
	"testing"

	"github.com/bytedance/mockey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
)

func TestSendApprovalModifyFlowChangeNotification(t *testing.T) {
	t.Run("发送给发起审批中修改的用户", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			quote := &model.Quote{
				BaseDB:         framework.BaseDB{Id: 100},
				ModifyContext:  `{"Promoter":"promoter@test.com"}`,
				ContractEntity: "测试签约主体",
				SalesAccountID: "sales@test.com",
			}
			instance := &model.LarkApprovalInstance{
				ApprovalInstanceId: "instance-id",
				ApprovalLink:       "https://approval.example.com/instance-id",
			}
			mockey.Mock(config.GetQuotePreviewLink).Return("https://quote.example.com/%d").Build()
			mockey.Mock(config.GetLarkMobileLink).Return("https://mobile.example.com/").Build()
			mockey.Mock(lark_client.GetUserIDsByEmails).
				Return(map[string]string{"sales@test.com": "sales-user-id"}, nil).Build()
			// 单测只验证卡片变量组装，隔离未初始化的多语言客户端。
			mockey.Mock(lark_client.FullRegionMessage).
				To(func(_ context.Context, message string) string { return message }).Build()
			mockey.Mock(i18nfmt.Sprintf).
				To(func(_ context.Context, format string, args ...interface{}) string {
					return fmt.Sprintf(format, args...)
				}).Build()

			var (
				receiver string
				cardData *lark_client.CardTemplateData
			)
			mockey.Mock(lark_client.SendCardTemplate).
				To(func(_ context.Context, email string, data *lark_client.CardTemplateData) {
					receiver = email
					cardData = data
				}).Build()

			err := sendApprovalModifyFlowChangeNotification(context.Background(), quote, instance, "产品线负责人需重新审批")
			if err != nil {
				t.Fatalf("sendApprovalModifyFlowChangeNotification() error = %v", err)
			}
			if receiver != "promoter@test.com" {
				t.Fatalf("receiver = %q, want promoter@test.com", receiver)
			}
			if cardData == nil || cardData.TemplateID != lark_client.TemplateApprovalModifyFlowChange {
				t.Fatalf("card template = %#v", cardData)
			}
			textContent, _ := cardData.TemplateVariable["text_content"].(string)
			for _, expected := range []string{"100", "测试签约主体", "sales-user-id", "产品线负责人需重新审批"} {
				if !strings.Contains(textContent, expected) {
					t.Fatalf("text_content = %q, want contain %q", textContent, expected)
				}
			}
			larkLink, ok := cardData.TemplateVariable["lark_link"].(lark_client.CardTemplateLink)
			if !ok || larkLink.PCUrl != instance.ApprovalLink || larkLink.AndroidUrl != "https://mobile.example.com/instance-id" {
				t.Fatalf("lark_link = %#v", cardData.TemplateVariable["lark_link"])
			}
			previewLink, ok := cardData.TemplateVariable["quote_preview_link"].(lark_client.CardTemplateLink)
			if !ok || previewLink.Url != "https://quote.example.com/100" {
				t.Fatalf("quote_preview_link = %#v", cardData.TemplateVariable["quote_preview_link"])
			}
		})
	})

	t.Run("发起人为空时不发送", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			sendCount := 0
			mockey.Mock(lark_client.SendCardTemplate).
				To(func(context.Context, string, *lark_client.CardTemplateData) { sendCount++ }).Build()
			err := sendApprovalModifyFlowChangeNotification(context.Background(), &model.Quote{
				BaseDB:        framework.BaseDB{Id: 101},
				ModifyContext: `{}`,
			}, &model.LarkApprovalInstance{}, "审批流变化")
			if err == nil {
				t.Fatal("sendApprovalModifyFlowChangeNotification() error = nil, want non-nil")
			}
			if sendCount != 0 {
				t.Fatalf("send count = %d, want 0", sendCount)
			}
		})
	})
}

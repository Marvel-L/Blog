package approval_modify

import larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"

type approvalTaskOpinion struct {
	Comment string
	Files   []*larkapproval.File
}

// collectApprovalTaskOpinions 从 timeline 收集节点审批意见，不使用全局评论替代。
func collectApprovalTaskOpinions(timeline []*larkapproval.InstanceTimeline) map[string]approvalTaskOpinion {
	result := make(map[string]approvalTaskOpinion)
	for _, item := range timeline {
		if item == nil || item.TaskId == nil || *item.TaskId == "" {
			continue
		}
		opinion := result[*item.TaskId]
		if item.Comment != nil {
			opinion.Comment = *item.Comment
		}
		if len(item.Files) > 0 {
			opinion.Files = item.Files
		}
		result[*item.TaskId] = opinion
	}
	return result
}

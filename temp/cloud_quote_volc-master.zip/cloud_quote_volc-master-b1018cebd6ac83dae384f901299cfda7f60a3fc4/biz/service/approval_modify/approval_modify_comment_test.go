package approval_modify

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"github.com/bytedance/mockey"
	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

func TestNormalizeCommentContent(t *testing.T) {
	t.Run("重建多个@占位符并保留附件", func(t *testing.T) {
		content := `{"text":"你好@张三，请联系@李四","files":[{"url":"https://example.com/file.png","fileSize":155149,"title":"file.png","type":"image"}]}`
		atInfo := []*larkapproval.CommentAtInfo{
			larkapproval.NewCommentAtInfoBuilder().UserId("u1").Name("张三").Offset("2").Build(),
			larkapproval.NewCommentAtInfoBuilder().UserId("u2").Name("李四").Offset("9").Build(),
		}

		got, rebuilt, err := normalizeCommentContent(&content, atInfo)
		if err != nil {
			t.Fatalf("normalizeCommentContent() error = %v", err)
		}
		var parsed map[string]interface{}
		if err := json.Unmarshal([]byte(got), &parsed); err != nil {
			t.Fatalf("normalized content is invalid json: %v", err)
		}
		if parsed["text"] != "你好@us，请联系@us" {
			t.Fatalf("text = %v, want 你好@us，请联系@us", parsed["text"])
		}
		files, ok := parsed["files"].([]interface{})
		if !ok || len(files) != 1 {
			t.Fatalf("files = %v, want one attachment", parsed["files"])
		}
		file, ok := files[0].(map[string]interface{})
		if !ok || file["url"] != "https://example.com/file.png" || file["title"] != "file.png" || file["type"] != "image" {
			t.Fatalf("attachment = %v, want source attachment preserved", files[0])
		}
		if len(rebuilt) != 2 || util.TrimStringValue(rebuilt[0].Offset) != "2" || util.TrimStringValue(rebuilt[1].Offset) != "9" {
			t.Fatalf("rebuilt offsets = [%s,%s], want [2,9]", util.TrimStringValue(rebuilt[0].Offset), util.TrimStringValue(rebuilt[1].Offset))
		}
	})

	t.Run("仅附件评论允许同步", func(t *testing.T) {
		content := `{"text":"","files":[{"url":"https://example.com/document.pdf","fileSize":1024,"title":"document.pdf","type":"file"}]}`

		got, rebuilt, err := normalizeCommentContent(&content, nil)
		if err != nil {
			t.Fatalf("normalizeCommentContent() error = %v", err)
		}
		if len(rebuilt) != 0 {
			t.Fatalf("rebuilt at info = %v, want empty", rebuilt)
		}
		var parsed map[string]interface{}
		if err := json.Unmarshal([]byte(got), &parsed); err != nil {
			t.Fatalf("normalized content is invalid json: %v", err)
		}
		files, ok := parsed["files"].([]interface{})
		if !ok || len(files) != 1 {
			t.Fatalf("files = %v, want one attachment", parsed["files"])
		}
	})

	t.Run("已是@us格式时保持幂等", func(t *testing.T) {
		content := `{"text":"@us 已处理"}`
		atInfo := []*larkapproval.CommentAtInfo{
			larkapproval.NewCommentAtInfoBuilder().UserId("u1").Name("张三").Offset("0").Build(),
		}

		got, rebuilt, err := normalizeCommentContent(&content, atInfo)
		if err != nil {
			t.Fatalf("normalizeCommentContent() error = %v", err)
		}
		if got != `{"text":"@us 已处理"}` || len(rebuilt) != 1 || util.TrimStringValue(rebuilt[0].Offset) != "0" {
			t.Fatalf("normalizeCommentContent() = %s, %+v", got, rebuilt)
		}
	})

	t.Run("偏移量与文本不一致返回错误", func(t *testing.T) {
		content := `{"text":"你好张三"}`
		_, _, err := normalizeCommentContent(&content, []*larkapproval.CommentAtInfo{
			larkapproval.NewCommentAtInfoBuilder().UserId("u1").Name("张三").Offset("2").Build(),
		})
		if err == nil {
			t.Fatal("normalizeCommentContent() error = nil, want non-nil")
		}
	})
}

func TestPrependCopiedApprovalCommentAttribution(t *testing.T) {
	tests := []struct {
		name                string
		translatedPrefix    string
		wantText            string
		wantSourceOffset    string
		wantMentionedOffset string
	}{
		{
			name:                "国内环境使用中文前缀",
			translatedPrefix:    "评论来自@us：",
			wantText:            "评论来自@us：请看@us",
			wantSourceOffset:    "4",
			wantMentionedOffset: "10",
		},
		{
			name:                "BytePlus环境使用英文前缀",
			translatedPrefix:    "Comment from @us: ",
			wantText:            "Comment from @us: 请看@us",
			wantSourceOffset:    "13",
			wantMentionedOffset: "20",
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				mockey.MockUnsafe(i18nfmt.Sprintf).
					To(func(_ context.Context, format string, args ...interface{}) string {
						if format != "评论来自%s：" || len(args) != 1 || args[0] != "@us" {
							t.Fatalf("i18nfmt.Sprintf() = (%q, %v)", format, args)
						}
						return tt.translatedPrefix
					}).Build()
				content := `{"text":"请看@us","files":[{"url":"https://example.com/file.png","title":"file.png","type":"image"}]}`
				atInfo := []*larkapproval.CommentAtInfo{
					larkapproval.NewCommentAtInfoBuilder().UserId("mentioned-user").Name("李四").Offset("2").Build(),
				}

				got, rebuilt, err := prependCopiedApprovalCommentAttribution(
					context.Background(),
					content,
					atInfo,
					"source-user",
					"张三",
				)
				if err != nil {
					t.Fatalf("prependCopiedApprovalCommentAttribution() error = %v", err)
				}
				var parsed map[string]interface{}
				if err := json.Unmarshal([]byte(got), &parsed); err != nil {
					t.Fatalf("copied content is invalid json: %v", err)
				}
				if parsed["text"] != tt.wantText {
					t.Fatalf("text = %v, want %s", parsed["text"], tt.wantText)
				}
				files, ok := parsed["files"].([]interface{})
				if !ok || len(files) != 1 {
					t.Fatalf("files = %v, want source attachment preserved", parsed["files"])
				}
				if len(rebuilt) != 2 {
					t.Fatalf("rebuilt at info count = %d, want 2", len(rebuilt))
				}
				if util.TrimStringValue(rebuilt[0].UserId) != "source-user" ||
					util.TrimStringValue(rebuilt[0].Name) != "张三" ||
					util.TrimStringValue(rebuilt[0].Offset) != tt.wantSourceOffset {
					t.Fatalf("source attribution = %+v, want offset %s", rebuilt[0], tt.wantSourceOffset)
				}
				if util.TrimStringValue(rebuilt[1].UserId) != "mentioned-user" ||
					util.TrimStringValue(rebuilt[1].Offset) != tt.wantMentionedOffset {
					t.Fatalf("source mention = %+v, want shifted offset %s", rebuilt[1], tt.wantMentionedOffset)
				}
			})
		})
	}
}

func TestApprovalCommentKeyIncludesMentionedUser(t *testing.T) {
	content := `{"text":"评论来自@us：相同内容"}`
	left := approvalCommentKey("applicant", content, []*larkapproval.CommentAtInfo{
		larkapproval.NewCommentAtInfoBuilder().UserId("source-a").Name("张三").Offset("4").Build(),
	})
	right := approvalCommentKey("applicant", content, []*larkapproval.CommentAtInfo{
		larkapproval.NewCommentAtInfoBuilder().UserId("source-b").Name("李四").Offset("4").Build(),
	})
	if left == right {
		t.Fatal("approvalCommentKey() should distinguish different mentioned users")
	}
}

func TestPrepareApprovalCommentForCreateFallsBackToUserID(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		mockey.MockUnsafe(i18nfmt.Sprintf).Return("评论来自@us：").Build()
		mockey.Mock(lark_client.GetUserNameByUserID).Return("", errors.New("user not found")).Build()

		commentator, content, atInfo, err := prepareApprovalCommentForCreate(
			context.Background(),
			"missing-user",
			"applicant",
			`{"text":"原评论内容"}`,
			nil,
			map[string]struct{}{"applicant": {}},
			make(map[string]string),
		)
		if err != nil {
			t.Fatalf("prepareApprovalCommentForCreate() error = %v", err)
		}
		if commentator != "applicant" {
			t.Fatalf("commentator = %s, want applicant", commentator)
		}
		if len(atInfo) != 1 ||
			util.TrimStringValue(atInfo[0].UserId) != "missing-user" ||
			util.TrimStringValue(atInfo[0].Name) != "missing-user" {
			t.Fatalf("atInfo = %+v, want missing-user fallback attribution", atInfo)
		}
		var parsed map[string]interface{}
		if err := json.Unmarshal([]byte(content), &parsed); err != nil {
			t.Fatalf("copied content is invalid json: %v", err)
		}
		if parsed["text"] != "评论来自@us：原评论内容" {
			t.Fatalf("text = %v, want copied attribution", parsed["text"])
		}
	})
}

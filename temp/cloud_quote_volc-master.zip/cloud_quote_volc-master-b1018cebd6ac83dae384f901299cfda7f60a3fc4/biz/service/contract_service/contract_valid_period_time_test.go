package contract_service

import (
	"context"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/vcp_clients/contractmetahttpclient"
)

func Test_GetContractTimeByQuoteID(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			timeValue, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")

			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue,
				PriceValidPeriodEndTime:   timeValue,
			}
			mockey.Mock(assistant.Callback).Return(&assistant.CallbackInfo{Quote: quoteDB}, nil).Build()

			// Act
			startTime, endTime, err := GetContractTimeByQuoteID(context.Background(), 1)

			// Assert
			convey.So(startTime, convey.ShouldEqual, timeValue)
			convey.So(endTime, convey.ShouldEqual, timeValue)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_GetContractTimeByQuoteDB(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("empty", t, func() {
			// Arrange
			timeValue, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")

			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue,
				PriceValidPeriodEndTime:   timeValue,
			}

			// Act
			startTime1, endTime1, err1 := GetContractTimeByQuoteDB(context.Background(), quoteDB, nil)
			startTime2, endTime2, err2 := GetContractTimeByQuoteDB(context.Background(), quoteDB, &model.QuoteContract{})

			// Assert
			convey.So(startTime1, convey.ShouldEqual, timeValue)
			convey.So(endTime1, convey.ShouldEqual, timeValue)
			convey.So(err1, convey.ShouldBeNil)
			convey.So(startTime2, convey.ShouldEqual, timeValue)
			convey.So(endTime2, convey.ShouldEqual, timeValue)
			convey.So(err2, convey.ShouldBeNil)
		})

		mockey.PatchConvey("contract nil", t, func() {
			// Arrange
			timeValue, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue,
				PriceValidPeriodEndTime:   timeValue,
			}

			mockey.Mock(contract_client.GetMetaDetail).Return(nil, nil).Build()

			// Act
			startTime, endTime, err := GetContractTimeByQuoteDB(context.Background(), quoteDB, &model.QuoteContract{ContractCode: "111"})

			// Assert
			convey.So(startTime, convey.ShouldEqual, time.Time{})
			convey.So(endTime, convey.ShouldEqual, time.Time{})
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("contract not nil", t, func() {
			// Arrange
			timeValue1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue1,
				PriceValidPeriodEndTime:   timeValue1,
			}

			timeValue2, _ := time.Parse("2006-01-02 15:04:05", "2023-08-01 00:00:00")
			contract := &contractmetahttpclient.ContractMetaInfo{
				ValidityBegin: timeValue2,
				ValidityEnd:   timeValue2,
			}
			mockey.Mock(contract_client.GetMetaDetail).Return(contract, nil).Build()

			// Act
			startTime, endTime, err := GetContractTimeByQuoteDB(context.Background(), quoteDB, &model.QuoteContract{ContractCode: "111"})

			// Assert
			convey.So(startTime, convey.ShouldEqual, timeValue2)
			convey.So(endTime, convey.ShouldEqual, timeValue2)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ProjectSupplyParentValidPeriodTimeCheck(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("SupplyScene=4,5 err", t, func() {
			// Arrange
			timeValue1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue1,
				PriceValidPeriodEndTime:   timeValue1,
				SupplyScene:               "4,5",
			}

			timeValue2, _ := time.Parse("2006-01-02 15:04:05", "2023-08-01 00:00:00")
			mockey.Mock(GetContractTimeByQuoteID).Return(timeValue2, timeValue2, nil).Build()

			// Act
			err := ProjectSupplyParentValidPeriodTimeCheck(context.Background(), quoteDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("SupplyScene=4,5 success", t, func() {
			// Arrange
			timeValue1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue1,
				PriceValidPeriodEndTime:   timeValue1,
				SupplyScene:               "4,5",
			}

			timeValue2, _ := time.Parse("2006-01-02 15:04:05", "2023-06-01 00:00:00")
			mockey.Mock(GetContractTimeByQuoteID).Return(timeValue2, timeValue2, nil).Build()

			// Act
			err := ProjectSupplyParentValidPeriodTimeCheck(context.Background(), quoteDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("SupplyScene=4 err", t, func() {
			// Arrange
			timeValue1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue1,
				PriceValidPeriodEndTime:   timeValue1,
				SupplyScene:               "4",
			}

			timeValue2, _ := time.Parse("2006-01-02 15:04:05", "2023-08-01 00:00:00")
			mockey.Mock(GetContractTimeByQuoteID).Return(timeValue2, timeValue2, nil).Build()

			// Act
			err := ProjectSupplyParentValidPeriodTimeCheck(context.Background(), quoteDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("SupplyScene=4 success", t, func() {
			// Arrange
			timeValue1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			quoteDB := &model.Quote{
				PriceValidPeriodStartTime: timeValue1,
				PriceValidPeriodEndTime:   timeValue1,
				SupplyScene:               "4",
			}

			timeValue2, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(GetContractTimeByQuoteID).Return(timeValue2, timeValue2, nil).Build()

			// Act
			err := ProjectSupplyParentValidPeriodTimeCheck(context.Background(), quoteDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

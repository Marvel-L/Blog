package contract_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/vcp_clients/contractmetahttpclient"
	"context"
	"strings"
)

func ContractItemRepeatRepeatCheck(ctx context.Context, quoteDB *model.Quote, checkQuoteItems []*model.QuoteItem) (bool, []*contractmetahttpclient.RepeatContractExportData, error) {

	needCheck, err := quoteDB.NeedContractRepeatCheck(ctx)
	if err != nil {
		return false, nil, err
	}
	if !needCheck {
		return false, nil, nil
	}

	req := &contractmetahttpclient.QueryLadderQuotationContractReq{
		CurrentOperator: quoteDB.SalesAccountID,
		ValidityBegin:   quoteDB.PriceValidPeriodStartTime,
		ValidityEnd:     quoteDB.PriceValidPeriodEndTime,
	}
	var productList []string
	for _, quoteItem := range checkQuoteItems {
		productList = append(productList, quoteItem.TradeProduct)
	}
	req.ProductList = strings.Join(util.GetUniqKeys(productList), ",")
	if quoteDB.CustomerDetail != "" {
		req.AccountIds = quoteDB.CustomerDetail
	} else {
		contractNos, err := c360service_client.GetContractsByOppNumber(ctx, string(quoteDB.OpportunityID))
		if err != nil {
			return false, nil, err
		}
		req.ContractNoList = strings.Join(contractNos, ",")
	}
	if req.ContractNoList == "" && req.AccountIds == "" {
		return false, nil, nil
	}
	contractData, err := contract_client.QueryLadderQuotationContract(ctx, req)
	if err != nil {
		return false, nil, err
	}

	return contractData.IsRepeat, contractData.RepeatList, nil

}

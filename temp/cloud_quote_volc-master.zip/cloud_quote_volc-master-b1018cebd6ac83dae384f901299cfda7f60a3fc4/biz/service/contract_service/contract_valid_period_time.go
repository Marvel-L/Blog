package contract_service

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

func GetContractTimeByQuoteID(ctx context.Context, quoteID int64) (time.Time, time.Time, errors.APIError) {

	callbackInfo, err := assistant.Callback(ctx, nil, quoteID,
		assistant.WithCallbackInfoKeys(
			[]assistant.CallbackKey{
				assistant.CallbackKeyQuoteContract, // 报价单关联合同号
			},
		),
	)

	if err != nil || callbackInfo == nil {
		argosnotifylogs.CtxError(ctx, "GetContractValidPeriodTimeByQuoteID fail, quoteID=%d, err=%+v", quoteID, err)
		return time.Time{}, time.Time{}, errors.ErrCustomerError.WithArgs("查询报价项信息失败")
	}

	return GetContractTimeByQuoteDB(ctx, callbackInfo.Quote, callbackInfo.QuoteContract)
}

func GetContractTimeByQuoteDB(ctx context.Context, quoteDB *model.Quote, quoteContract *model.QuoteContract) (time.Time, time.Time, errors.APIError) {
	if quoteContract == nil || quoteContract.ContractCode == "" {
		return quoteDB.PriceValidPeriodStartTime, quoteDB.PriceValidPeriodEndTime, nil
	}

	contract, err := contract_client.GetMetaDetail(ctx, quoteContract.ContractCode)
	if err != nil {
		argosnotifylogs.CtxError(ctx, "GetContractValidPeriodTimeByQuoteDB fail, contractNo=%s, err=%s", quoteContract.ContractCode, err.Error())
		return time.Time{}, time.Time{}, errors.ErrCustomerError.WithArgs("查询关联合同有效期失败")
	}
	if contract == nil {
		return time.Time{}, time.Time{}, errors.ErrCustomerError.WithArgs("关联合同不存在")
	}

	return contract.ValidityBegin, contract.ValidityEnd, nil
}

func ProjectSupplyParentValidPeriodTimeCheck(c context.Context, quoteDB *model.Quote) errors.APIError {

	parentStartTime, parentEndTime, err := GetContractTimeByQuoteID(c, quoteDB.ParentQuoteID)
	if err != nil {
		return err
	}

	if multienv.IsContainsSupplyScene(quoteDB.SupplyScene, multienv.SupplySceneContractRenewal) {
		// 增购+续约

		if !quoteDB.PriceValidPeriodStartTime.After(parentEndTime) {
			return errors.ErrCustomerError.WithArgs("补充项目制报价单-增购&续约，变更场景下，预估合同有效期-开始时间必须晚于原结束时间")
		}

		return nil
	}

	// 增购
	if quoteDB.PriceValidPeriodStartTime.Before(parentStartTime) {
		return errors.ErrCustomerError.WithArgs("补充项目制报价单-增购，变更场景下，预估合同有效期-开始时间必须晚于或等于原开始时间")
	}

	return nil
}

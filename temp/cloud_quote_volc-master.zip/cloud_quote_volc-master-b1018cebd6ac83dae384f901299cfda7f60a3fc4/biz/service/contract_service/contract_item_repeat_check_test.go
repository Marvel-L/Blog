package contract_service

import (
	"context"
	"sort"
	"strings"
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/c360service_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/vcp_clients/contractmetahttpclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestContractItemRepeatRepeatCheck(t *testing.T) {
	t.Run("skip repeat check", func(t *testing.T) {
		mockey.PatchConvey("skip repeat check", t, func() {
			// Arrange
			quoteDB := &model.Quote{}
			mockey.Mock((*model.Quote).NeedContractRepeatCheck).Return(false, nil).Build()

			// Act
			isRepeat, repeatList, err := ContractItemRepeatRepeatCheck(context.Background(), quoteDB, []*model.QuoteItem{
				{TradeProduct: "ecs"},
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isRepeat, convey.ShouldBeFalse)
			convey.So(repeatList, convey.ShouldBeNil)
		})
	})

	t.Run("query by account ids", func(t *testing.T) {
		mockey.PatchConvey("query by account ids", t, func() {
			// Arrange
			timeValue, _ := time.Parse("2006-01-02 15:04:05", "2024-01-02 03:04:05")
			quoteDB := &model.Quote{
				SalesAccountID:            "sale-1",
				CustomerDetail:            "account-1",
				PriceValidPeriodStartTime: timeValue,
				PriceValidPeriodEndTime:   timeValue,
			}
			expectedRepeatList := []*contractmetahttpclient.RepeatContractExportData{{AccountId: 1}}
			mockey.Mock((*model.Quote).NeedContractRepeatCheck).Return(true, nil).Build()
			mockey.Mock(contract_client.QueryLadderQuotationContract).To(
				func(_ context.Context, req *contractmetahttpclient.QueryLadderQuotationContractReq) (*contractmetahttpclient.QueryLadderQuotationContractData, error) {
					productList := strings.Split(req.ProductList, ",")
					sort.Strings(productList)

					convey.So(req.CurrentOperator, convey.ShouldEqual, "sale-1")
					convey.So(req.AccountIds, convey.ShouldEqual, "account-1")
					convey.So(req.ContractNoList, convey.ShouldEqual, "")
					convey.So(productList, convey.ShouldResemble, []string{"ecs", "vpc"})
					convey.So(req.ValidityBegin, convey.ShouldEqual, timeValue)
					convey.So(req.ValidityEnd, convey.ShouldEqual, timeValue)

					return &contractmetahttpclient.QueryLadderQuotationContractData{
						IsRepeat:   true,
						RepeatList: expectedRepeatList,
					}, nil
				},
			).Build()

			// Act
			isRepeat, repeatList, err := ContractItemRepeatRepeatCheck(context.Background(), quoteDB, []*model.QuoteItem{
				{TradeProduct: "ecs"},
				{TradeProduct: "vpc"},
				{TradeProduct: "ecs"},
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isRepeat, convey.ShouldBeTrue)
			convey.So(repeatList, convey.ShouldResemble, expectedRepeatList)
		})
	})

	t.Run("query by contract numbers", func(t *testing.T) {
		mockey.PatchConvey("query by contract numbers", t, func() {
			// Arrange
			timeValue, _ := time.Parse("2006-01-02 15:04:05", "2024-01-02 03:04:05")
			quoteDB := &model.Quote{
				SalesAccountID:            "sale-2",
				OpportunityID:             multienv.OppNumber("opp-1"),
				PriceValidPeriodStartTime: timeValue,
				PriceValidPeriodEndTime:   timeValue,
			}
			mockey.Mock((*model.Quote).NeedContractRepeatCheck).Return(true, nil).Build()
			mockey.Mock(c360service_client.GetContractsByOppNumber).To(func(_ context.Context, opportunityNumber string) ([]string, error) {
				convey.So(opportunityNumber, convey.ShouldEqual, "opp-1")
				return []string{"contract-1", "contract-2"}, nil
			}).Build()
			mockey.Mock(contract_client.QueryLadderQuotationContract).To(
				func(_ context.Context, req *contractmetahttpclient.QueryLadderQuotationContractReq) (*contractmetahttpclient.QueryLadderQuotationContractData, error) {
					convey.So(req.CurrentOperator, convey.ShouldEqual, "sale-2")
					convey.So(req.AccountIds, convey.ShouldEqual, "")
					convey.So(req.ContractNoList, convey.ShouldEqual, "contract-1,contract-2")
					convey.So(req.ProductList, convey.ShouldEqual, "tos")

					return &contractmetahttpclient.QueryLadderQuotationContractData{
						IsRepeat: false,
					}, nil
				},
			).Build()

			// Act
			isRepeat, repeatList, err := ContractItemRepeatRepeatCheck(context.Background(), quoteDB, []*model.QuoteItem{
				{TradeProduct: "tos"},
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(isRepeat, convey.ShouldBeFalse)
			convey.So(repeatList, convey.ShouldBeNil)
		})
	})
}

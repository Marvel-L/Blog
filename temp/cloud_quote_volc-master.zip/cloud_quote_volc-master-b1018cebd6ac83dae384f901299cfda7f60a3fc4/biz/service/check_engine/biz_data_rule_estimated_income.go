package check_engine

import (
	"context"
	"fmt"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// EstimatedIncomeRule 预计金额校验。
//
// 与原 EstimatedIncomeChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / ItemValues / ItemContextMap / ItemCalMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 仅做数据校验，不做任何 DB / RPC 查询。
//
// 注意：原 checker 使用 quoteBizData.AllQuoteItems（仅含报价项，不含交付项），
// 此处对齐使用 Persisted.QuoteItems。
type EstimatedIncomeRule struct{}

// SpPackageIDWithDeductionSum SP 包预计金额与抵扣金额聚合结果。
type SpPackageIDWithDeductionSum struct {
	SpPackageID  int64
	DeductionSum decimal.Decimal
}

func (r *EstimatedIncomeRule) Key() string {
	return "BizDataRuleEstimatedIncome"
}

func (r *EstimatedIncomeRule) Desc() string {
	return "预计金额校验：" +
		"1) 预计用量流程下，支持预计金额的报价项必须填写预计金额，且总销售额不能为 0；" +
		"2) 预计金额流程下，公有云标品报价项预计金额必须大于 0，公有云预估金额需与所有公有云报价项预计金额（折后）之和一致；" +
		"3) 非项目制报价单的预估销售金额需与系统预估销售金额一致；" +
		"4) SP 包预计金额需大于等于其对应抵扣项预计金额之和。"
}

func (r *EstimatedIncomeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyItemCalMap,
	}
}

func (r *EstimatedIncomeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedIncomeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	if !quote.IsQuote() {
		return result, nil
	}

	if quote.SupportPublicCloudEstimate() {
		return r.estimatedProcessCheck(ctx, quoteCtx, result)
	}
	return r.quantityProcessCheck(ctx, quoteCtx, result)
}

// quantityProcessCheck 预计用量流程校验预计金额
func (r *EstimatedIncomeRule) quantityProcessCheck(ctx context.Context, quoteCtx *quote_context.QuoteContext, result *CheckResult) (*CheckResult, error) {
	if multienv.IsBytePlus() {
		return result, nil
	}
	quoteItems := quoteCtx.Persisted.QuoteItems
	if len(quoteItems) == 0 {
		return result, nil
	}
	itemContextMap := quoteCtx.Persisted.ItemContextMap

	var invalidItemIDs []int64
	for _, quoteItem := range quoteItems {
		itemContext, ok := itemContextMap[quoteItem.Id]
		if !ok || itemContext == nil {
			continue
		}
		if itemContext.SupportEstimatedIncome() && itemContext.EstimatedIncome == "" {
			invalidItemIDs = append(invalidItemIDs, quoteItem.Id)
		}
	}
	if len(invalidItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedIncomeCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx,
			"报价项: %s,需要补充预计金额",
			util.GetJsonStr(invalidItemIDs))
		return result, nil
	}
	if quoteCtx.Persisted.Quote.TotalSales.Equal(decimal.Zero) {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedIncomeCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "报价项预计金额不能均为0")
		return result, nil
	}
	return result, nil
}

// estimatedProcessCheck 预计金额流程校验预计金额
func (r *EstimatedIncomeRule) estimatedProcessCheck(ctx context.Context, quoteCtx *quote_context.QuoteContext, result *CheckResult) (*CheckResult, error) {
	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems
	calMap := quoteCtx.Persisted.ItemCalMap
	if len(quoteItems) == 0 {
		return result, nil
	}

	publicTotalSales := decimal.Zero
	for _, quoteItem := range quoteItems {
		if quoteItem.IsGiveAway() {
			continue
		}
		if !quoteItem.IsPublicStandardItem() {
			continue
		}
		itemCalculate, ok := calMap[quoteItem.Id]
		if !ok {
			continue
		}
		if itemCalculate.IncomeNoTax.LessThanOrEqual(decimal.Zero) {
			result.Pass = false
			result.ErrorCode = errors.CodeNEstimatedIncomeNeedBigThanZero
			result.ErrorMsg = fmt.Sprintf(
				"quoteItem %d,estimated income less than or equal zero",
				quoteItem.Id,
			)
			return result, nil
		}
		if quoteItem.IsSpDeductItem() {
			continue
		}
		publicTotalSales = publicTotalSales.Add(itemCalculate.IncomeNoTax)
	}
	if !publicTotalSales.Equal(quote.PublicCloudEstimate) {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedIncomeCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx,
			"「公有云预估金额 %s」与「所有公有云报价项 预计金额（折后）之和 %s 」不一致，请返回修改。",
			quote.PublicCloudEstimate.String(),
			publicTotalSales.String(),
		)
		return result, nil
	}

	if !quote.IsProjectBased() && !quote.TotalSales.Equal(quote.QuoteEstimateBySales) {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedIncomeCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx,
			"【预估销售金额】:%s 与【系统预估销售金额】: %s 不一致,请重新进行预计金额分摊",
			quote.QuoteEstimateBySales.String(),
			quote.TotalSales.String(),
		)
		return result, nil
	}

	// SP包预计金额校验：SP包预计金额需大于等于其对应抵扣项预计金额之和
	spDeductionSumMap := make(map[int64]decimal.Decimal)
	for _, quoteItem := range quoteItems {
		if quoteItem.IsSpDeductItem() && quoteItem.RelatedItemID > 0 {
			itemCalculate, ok := calMap[quoteItem.Id]
			if ok {
				spDeductionSumMap[quoteItem.RelatedItemID] = spDeductionSumMap[quoteItem.RelatedItemID].Add(itemCalculate.IncomeNoTax)
			}
		}
	}
	spPackageIDWithDeductionSumList := make([]SpPackageIDWithDeductionSum, 0)
	for spPackageID, deductionSum := range spDeductionSumMap {
		itemCalculate, ok := calMap[spPackageID]
		if !ok {
			continue
		}
		if itemCalculate.IncomeNoTax.LessThan(deductionSum) {
			spPackageIDWithDeductionSumList = append(spPackageIDWithDeductionSumList, SpPackageIDWithDeductionSum{
				SpPackageID:  spPackageID,
				DeductionSum: deductionSum,
			})
		}
	}
	if len(spPackageIDWithDeductionSumList) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNSpPackEstimatedLessDeduct
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "SP包预计金额小于其对应抵扣项预计金额总和")
		result.Detail = spPackageIDWithDeductionSumList
		return result, nil
	}
	return result, nil
}

func (r *EstimatedIncomeRule) BlockLevel() string {
	return BlockLevelError
}

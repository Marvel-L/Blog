package check_engine

type QuoteBizOpType string

const (
	QuoteBizOpTypeSubmitQuote  QuoteBizOpType = "SubmitQuote"  // 提交报价单
	QuoteBizOpTypeBizDataCheck QuoteBizOpType = "BizDataCheck" // 报价单业务数据校验

)

const (
	checkQuoteBaseInfo        = "checkQuoteBaseInfo"                    // 报价单基础信息维度
	checkQuoteItem            = "checkQuoteItem"                        // 报价项维度（0元报价、计费项、售卖模式等原子规则归此）
	checkTotalEstimatedIncome = "checkTotalEstimatedIncome"             // 综合预计金额维度
	checkGuaranteeItem        = "checkGuaranteeItem"                    // 保底维度
	checkRebate               = "checkRebate"                           // 返佣维度
	checkBizDiscount          = "checkBizDiscount"                      // 商务优惠维度
	checkRelatedBizDiscount   = "checkRelatedQuoteItemBusinessDiscount" // 关联报价项商务优惠维度
	checkCoupon               = "checkCoupon"                           // 代金券申请维度
	checkCredit               = "checkCredit"                           // 信控申请维度
)

const (
	BlockLevelError = "Error"
	BlockLevelWarn  = "Warn"
	BlockLevelInfo  = "Info"
)

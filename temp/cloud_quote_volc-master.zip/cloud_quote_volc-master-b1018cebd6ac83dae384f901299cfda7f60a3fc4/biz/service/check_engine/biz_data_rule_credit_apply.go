package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// CreditApplyRule 信控申请条目校验。
//
// 来源：原 CommonApplyChecker → apply_checker.CreditApplyChecker。
// 仅当报价单存在 BizKey=credit 的申请条目时校验：要求
//  1. quote.SupportCredit=true；
//  2. 报价单至少存在一条公有云标品报价项（等价替换原
//     CountQuoteItemByConditions 的 SQL 计数）。
//
// 不再依赖 *gorm.DB；ApplyItems 与 QuoteItems 由 QuoteContextLoader 预加载。
type CreditApplyRule struct{}

func (r *CreditApplyRule) Key() string {
	return "BizDataRuleCreditApply"
}

func (r *CreditApplyRule) Desc() string {
	return "信控申请校验：当前报价单需支持信控申请，且至少包含一条公有云标品报价项。"
}

func (r *CreditApplyRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyApplyItems,
	}
}

func (r *CreditApplyRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCommonApplyCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if !hasApplyItem(quoteCtx.Persisted.ApplyItems, multienv.ApplyBizKeyCredit) {
		return result, nil
	}
	supportCredit, err := quoteCtx.Persisted.Quote.SupportCredit(ctx)
	if err != nil {
		return nil, err
	}
	if !supportCredit || !hasPublicStandardItem(quoteCtx.Persisted.QuoteItems) {
		applyBizDesc := multienv.GetApplyBizDesc(multienv.ApplyBizKeyCredit)
		result.Pass = false
		result.ErrorCode = errors.CodeNCommonApplyCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单不支持%s申请，请先删除%s申请信息", applyBizDesc, applyBizDesc)
		return result, nil
	}
	return result, nil
}

func (r *CreditApplyRule) BlockLevel() string {
	return BlockLevelError
}

// hasApplyItem 判断 applyItems 中是否存在指定 bizKey 的申请条目。
func hasApplyItem(applyItems []*model.CommonApplyItem, bizKey string) bool {
	for _, item := range applyItems {
		if item != nil && item.BizKey == bizKey {
			return true
		}
	}
	return false
}

// hasPublicStandardItem 等价于：
// count(quote_id, status=0, standard_product=Yes, item_type=Public, item_scene=QuoteItem) > 0
// QuoteContext.QuoteItems 已按 status=Normal、scene=QuoteItem 加载。
func hasPublicStandardItem(quoteItems []*model.QuoteItem) bool {
	for _, item := range quoteItems {
		if item != nil && item.IsPublicStandardItem() {
			return true
		}
	}
	return false
}

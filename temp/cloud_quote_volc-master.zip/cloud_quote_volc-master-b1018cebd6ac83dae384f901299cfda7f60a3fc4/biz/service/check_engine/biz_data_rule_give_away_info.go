package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// GiveAwayInfoRule —— 赠送信息校验。
//
// 与原 QuoteData.GiveAwayInfoCheck 保持错误码与文案完全一致：
//   - 填写赠送场景时必须命中合法枚举；
//   - 填写赠送场景时必须指定赠送原因；
//   - 赠送原因长度不超过 1000。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type GiveAwayInfoRule struct{}

func (r *GiveAwayInfoRule) Key() string { return "BizDataRuleGiveAwayInfo" }
func (r *GiveAwayInfoRule) Desc() string {
	return "赠送信息校验：填写赠送场景时必须命中合法枚举且赠送原因非空、长度不超过 1000"
}
func (r *GiveAwayInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *GiveAwayInfoRule) BlockLevel() string { return BlockLevelError }

func (r *GiveAwayInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNGiveAwayInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.GiveAwayScene == "" {
		return result, nil
	}
	if !multienv.IsValidGiveAwayScene(quote.GiveAwayScene) {
		result.Pass = false
		result.ErrorCode = errors.CodeNGiveAwayInfoCheckFailed
		result.ErrorMsg = "赠送场景错误"
		return result, nil
	}
	if quote.GiveAwayReason == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNGiveAwayInfoCheckFailed
		result.ErrorMsg = "赠送场景不为空时，必须指定赠送原因"
		return result, nil
	}
	if len([]rune(quote.GiveAwayReason)) > 1000 {
		result.Pass = false
		result.ErrorCode = errors.CodeNGiveAwayInfoCheckFailed
		result.ErrorMsg = "赠送原因最大长度1000"
		return result, nil
	}
	return result, nil
}

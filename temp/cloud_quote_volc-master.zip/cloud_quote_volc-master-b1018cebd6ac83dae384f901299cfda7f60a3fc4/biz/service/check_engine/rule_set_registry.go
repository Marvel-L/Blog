package check_engine

import (
	"fmt"
)

// RuleRegistry provides opType -> checkKey -> rules mapping.
// It is a lightweight in-code DSL to declare validation rule sets.

type opTypeRuleData struct {
	opType           QuoteBizOpType
	accessCheckRules []QuoteBizRule
	bizDataChecks    []string
}

type RuleRegistry struct {
	checkKeyRules map[string][]QuoteBizRule          //checkKey -> ruleset
	opTypeRule    map[QuoteBizOpType]*opTypeRuleData // opType->*opTypeRuleData
}

func NewRuleRegistry() *RuleRegistry {
	return &RuleRegistry{
		checkKeyRules: make(map[string][]QuoteBizRule),
		opTypeRule:    make(map[QuoteBizOpType]*opTypeRuleData),
	}
}

type RuleSetBuilder struct {
	r        *RuleRegistry
	checkKey string
	opType   QuoteBizOpType
}

func (r *RuleRegistry) RegisterCheckKey(checkKey string) *RuleSetBuilder {
	return &RuleSetBuilder{r: r, checkKey: checkKey}
}

// WithRules sets the rules for the current (checkKey, opTypes) binding.
func (b *RuleSetBuilder) WithRules(rules ...QuoteBizRule) *RuleRegistry {
	b.r.checkKeyRules[b.checkKey] = append(b.r.checkKeyRules[b.checkKey], rules...)
	return b.r
}

func (r *RuleRegistry) RegisterOpType(opType QuoteBizOpType) *RuleSetBuilder {
	return &RuleSetBuilder{r: r, opType: opType}
}

func (b *RuleSetBuilder) WithCheckKeys(checkKeys ...string) *RuleRegistry {
	ruleData, ok := b.r.opTypeRule[b.opType]
	if !ok {
		ruleData = &opTypeRuleData{
			opType:           b.opType,
			accessCheckRules: make([]QuoteBizRule, 0),
			bizDataChecks:    make([]string, 0),
		}
		b.r.opTypeRule[b.opType] = ruleData
	}
	ruleData.bizDataChecks = append(ruleData.bizDataChecks, checkKeys...)
	return b.r
}
func (b *RuleSetBuilder) WithAccessCheckRules(accessCheckRules ...QuoteBizRule) *RuleRegistry {
	ruleData, ok := b.r.opTypeRule[b.opType]
	if !ok {
		ruleData = &opTypeRuleData{
			opType:           b.opType,
			accessCheckRules: make([]QuoteBizRule, 0),
			bizDataChecks:    make([]string, 0),
		}
		b.r.opTypeRule[b.opType] = ruleData
	}
	ruleData.accessCheckRules = append(ruleData.accessCheckRules, accessCheckRules...)
	return b.r
}

func (r *RuleRegistry) validate() error {
	if r == nil {
		return fmt.Errorf("rule registry is nil")
	}
	for opType, ruleData := range r.opTypeRule {
		if ruleData == nil {
			return fmt.Errorf("opType [%s] rule data is nil", opType)
		}
		for _, checkKey := range ruleData.bizDataChecks {
			if _, ok := r.checkKeyRules[checkKey]; !ok {
				return fmt.Errorf("opType [%s] references unregistered checkKey [%s]", opType, checkKey)
			}
		}
	}

	ruleKeyCheckKey := make(map[string]string)
	for checkKey, rules := range r.checkKeyRules {
		for _, rule := range rules {
			if rule == nil {
				return fmt.Errorf("checkKey [%s] contains nil rule", checkKey)
			}
			ruleKey := rule.Key()
			if ruleKey == "" {
				return fmt.Errorf("checkKey [%s] contains empty rule key", checkKey)
			}
			if existingCheckKey, ok := ruleKeyCheckKey[ruleKey]; ok {
				return fmt.Errorf("rule key [%s] duplicated in checkKey [%s] and checkKey [%s]", ruleKey, existingCheckKey, checkKey)
			}
			ruleKeyCheckKey[ruleKey] = checkKey
		}
	}
	return nil
}

func mustValidateRuleRegistry(r *RuleRegistry) {
	if err := r.validate(); err != nil {
		panic(fmt.Sprintf("invalid quote biz rule registry: %s", err.Error()))
	}
}

func (r *RuleRegistry) getBizDataCheckRules(opType QuoteBizOpType) ([]QuoteBizRule, error) {
	ruleData, ok := r.opTypeRule[opType]
	if !ok {
		return nil, fmt.Errorf("opType [%s] not registered", opType)
	}
	var rules []QuoteBizRule
	for _, checkKey := range ruleData.bizDataChecks {
		if ruleSet, ok := r.checkKeyRules[checkKey]; ok {
			rules = append(rules, ruleSet...)
		} else {
			return nil, fmt.Errorf("checkKey [%s] ruleSet not registered", checkKey)
		}
	}
	return rules, nil
}
func (r *RuleRegistry) getAccessCheckRules(opType QuoteBizOpType) ([]QuoteBizRule, error) {
	ruleData, ok := r.opTypeRule[opType]
	if !ok {
		return nil, fmt.Errorf("opType [%s] not registered", opType)
	}
	return ruleData.accessCheckRules, nil
}

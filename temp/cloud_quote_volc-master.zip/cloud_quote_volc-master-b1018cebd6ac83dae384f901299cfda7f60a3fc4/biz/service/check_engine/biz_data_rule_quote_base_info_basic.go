package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// QuoteBaseInfoBasicRule 报价单基础信息校验中"非 RPC、纯本地数据"部分。
//
// 与原 QuoteBaseInfoChecker 的差异：
//   - 不承担 quoteDataCheck（含 RPC 商机查询、签约/配价主体回填等）和 validateDistributorInfos（RPC + 写入）
//     这两块作为后续子任务单独迁移；
//   - 仅保留以下 5 个原子校验，全部基于 QuoteContext 完成：
//     1) 报价单中无报价项 -> CodeNNoQuoteItem
//     2) 存在草稿状态报价项 -> CodeNExistDraftQuoteItem
//     3) 不支持 SP 但报价项含 SP 商品 -> CodeNQuoteNotSupportSP
//     4) 不支持提货券但报价项含提货券商品 -> CodeNQuoteNotSupportPickupVoucher
//     5) 项目制送审需至少 1 条非系统自动生成的交付项 -> CodeNNotAutoDeliveryItemMiss
//     6) 包含未立项商品但 UnapprovedProductLines 为空 -> CodeNUnapprovedProductLinesMiss
//
// 注意：原 checker 用 `quoteBizData.AllQuoteItems`（含草稿）做 1)/2)，
// 用 `quoteBizData.AllDeliveryItems` 做 4)，因此本 Rule 显式声明
// QuoteContextKeyQuoteItemsAllStatus 和 QuoteContextKeyDeliveryItems。
type QuoteBaseInfoBasicRule struct{}

func (r *QuoteBaseInfoBasicRule) Key() string {
	return "BizDataRuleQuoteBaseInfoBasic"
}

func (r *QuoteBaseInfoBasicRule) Desc() string {
	return "报价单基础信息基本校验：" +
		"1) 报价单中需至少包含 1 条报价项；" +
		"2) 报价项不可处于草稿状态；" +
		"3) 报价项含节省计划商品时，报价单必须支持节省计划；" +
		"4) 报价项含提货券商品时，报价单必须支持提货券；" +
		"5) 项目制报价单需至少包含 1 条非系统自动生成的交付项；" +
		"6) 报价单包含未立项商品时，未立项产品线不能为空。"
}

func (r *QuoteBaseInfoBasicRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItemsAllStatus,
		quote_context.QuoteContextKeyDeliveryItems,
	}
}

func (r *QuoteBaseInfoBasicRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteBaseInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	allQuoteItems := quoteCtx.Persisted.QuoteItemsAllStatus
	allDeliveryItems := quoteCtx.Persisted.DeliveryItems

	// 1) 报价项空判定
	if len(allQuoteItems) == 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNNoQuoteItem
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单中无报价项，不允许提交")
		return result, nil
	}

	// 2)/3)/4) 草稿状态、SP 商品兼容性、提货券商品兼容性
	for _, quoteItem := range allQuoteItems {
		if quoteItem.ItemStatus == constants.ItemStatusDraft {
			result.Pass = false
			result.ErrorCode = errors.CodeNExistDraftQuoteItem
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单中包含草稿报价项，不允许直接提交")
			return result, nil
		}
		if quoteItem.IsSpProduct() && !quote.SupportSpProduct() {
			result.Pass = false
			result.ErrorCode = errors.CodeNQuoteNotSupportSP
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单不支持添加节省计划商品，但包含节省计划商品【%s】，不允许直接提交", quoteItem.TradeProduct)
			return result, nil
		}
		if quoteItem.IsPickupVoucherProduct() && !quote.SupportPickupVoucherProduct() {
			result.Pass = false
			result.ErrorCode = errors.CodeNQuoteNotSupportPickupVoucher
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单不支持添加提货券商品，但包含提货券商品【%s】，不允许直接提交", quoteItem.TradeProduct)
			return result, nil
		}
	}

	// 5)/6) 仅在项目制场景下生效
	if !isProjectBased(quote) {
		return result, nil
	}

	// 4) 项目制送审需要至少 1 条非系统自动生成的交付项
	if e := r.checkDeliveryItems(ctx, quote, allDeliveryItems); e != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNNotAutoDeliveryItemMiss
		result.ErrorMsg = e.Error()
		return result, nil
	}
	// 5) 包含未立项商品时，未立项产品线不能为空
	if e := r.checkUnapprovedProductLines(ctx, quote, allQuoteItems, allDeliveryItems); e != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNUnapprovedProductLinesMiss
		result.ErrorMsg = e.Error()
		return result, nil
	}
	return result, nil
}

func (r *QuoteBaseInfoBasicRule) BlockLevel() string {
	return BlockLevelError
}

// isProjectBased 与 quote_service.QuoteData.IsProjectBased 等价：
// 用 model.Quote.QuoteType 直接判定，避免对 quote_service 的反向依赖。
func isProjectBased(quote *model.Quote) bool {
	if quote == nil {
		return false
	}
	return quote.QuoteType == multienv.QuoteTypeProjectBased
}

// checkDeliveryItems 内联自 QuoteBaseInfoChecker.checkDeliveryItems：项目制必含 1 条手工交付项。
func (r *QuoteBaseInfoBasicRule) checkDeliveryItems(ctx context.Context, quote *model.Quote, allDeliveryItems []*model.QuoteItem) error {
	logs.CtxInfo(ctx, "[QuoteBaseInfoBasicRule]_checkDeliveryItems, quote_id=%d", quote.Id)
	for _, item := range allDeliveryItems {
		if item.ItemScene == constants.ItemSceneDeliveryItem && item.AutoGenerate == constants.ItemAutoGenerateFalse {
			return nil
		}
	}
	return i18nfmt.Errorf(ctx, "项目制报价单，需要至少包含1条非系统自动生成的交付项，请手动添加交付项后送审")
}

// checkUnapprovedProductLines 内联自 QuoteBaseInfoChecker.checkUnapprovedProductLines：
// 配置开启 + 报价单含未立项商品 -> 必须填写未立项产品线。
//
// 与原逻辑差异：原 checker 在"不含未立项商品但 UnapprovedProductLines 非空"时会清空 quote.UnapprovedProductLines，
// 该写副作用按 §9 不应在 Rule 内执行；此处仅做校验，不做回填。
func (r *QuoteBaseInfoBasicRule) checkUnapprovedProductLines(ctx context.Context, quote *model.Quote, quoteItems, deliveryItems []*model.QuoteItem) error {
	logs.CtxInfo(ctx, "[QuoteBaseInfoBasicRule]_checkUnapprovedProductLines, quote_id=%d", quote.Id)
	conf := config.GetGlobalConf(ctx)
	if conf == nil || conf.QuoteApp == nil {
		return i18nfmt.Errorf(ctx, "config is missing")
	}
	if conf.ApprovalControlConf.DisableCheckUnapprovedProductLines {
		logs.CtxInfo(ctx, "[QuoteBaseInfoBasicRule]_checkUnapprovedProductLines, quote_id=%d, skip check UnapprovedProductLines, DisableCheckUnapprovedProductLines=true", quote.Id)
		return nil
	}
	unapprovedTradeProducts := conf.ApprovalControlConf.UnapprovedTradeProducts
	if len(unapprovedTradeProducts) == 0 {
		logs.CtxInfo(ctx, "[QuoteBaseInfoBasicRule]_checkUnapprovedProductLines, quote_id=%d, skip check UnapprovedProductLines, UnapprovedTradeProducts is nil", quote.Id)
		return nil
	}
	allItems := append([]*model.QuoteItem{}, quoteItems...)
	allItems = append(allItems, deliveryItems...)
	hasUnapprovedTradeProducts := false
	for _, item := range allItems {
		if util.StrIn(item.TradeProduct, unapprovedTradeProducts) {
			logs.CtxInfo(ctx, "[QuoteBaseInfoBasicRule]_checkUnapprovedProductLines, hasUnapprovedTradeProducts=true, quote_id=%d, item[%d], trade_product=%s, unapprovedTradeProducts=%v", quote.Id, item.Id, item.TradeProduct, unapprovedTradeProducts)
			hasUnapprovedTradeProducts = true
			break
		}
	}
	if hasUnapprovedTradeProducts && quote.UnapprovedProductLines == "" {
		logs.CtxWarn(ctx, "[QuoteBaseInfoBasicRule]_checkUnapprovedProductLines，quote[%d] hasUnapprovedTradeProducts, but UnapprovedProductLines is empty", quote.Id)
		return i18nfmt.Errorf(ctx, "报价单包含未立项商品，未立项产品线不能为空")
	}
	return nil
}

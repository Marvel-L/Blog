package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// RelatedProductRule 报价单关联商品类型校验。
//
// 与原 RelatedProductChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 仅做数据校验，不做任何 DB / RPC 查询。
//
// 注意：原 checker 用 quoteBizData.AllQuoteItems（仅含报价项），此处对齐使用
// Persisted.QuoteItems。
type RelatedProductRule struct{}

func (r *RelatedProductRule) Key() string {
	return "BizDataRuleRelatedProduct"
}

func (r *RelatedProductRule) Desc() string {
	return "报价单关联商品类型校验：" +
		"1) 报价项关联商品类型必须落在报价单 QuoteRelatedProduct 范围内；" +
		"2) 报价单 QuoteRelatedProduct 中的每种类型，至少需要存在一个对应类型的报价项。"
}

func (r *RelatedProductRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
	}
}

func (r *RelatedProductRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteNotSupportProductType
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems
	if len(quoteItems) == 0 {
		return result, nil
	}

	typeMap, err := quote.GetProductTypeMap(ctx)
	if err != nil {
		return nil, err
	}
	itemProductTypeMap := map[constants.ProductType]interface{}{}

	// 判断报价项中类型范围是否有超出相关商品
	for _, quoteItem := range quoteItems {
		if quoteItem.ItemScene == constants.ItemSceneDeliveryItem { // 交付项不受报价单关联商品范围影响
			continue
		}
		productType := quoteItem.GetRelatedProductType()
		if _, ok := typeMap[productType]; !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNQuoteNotSupportProductType
			result.ErrorMsg = i18nfmt.Sprintf(ctx,
				"当前报价单不支持类型为 %s 的报价项，不可提交",
				multienv.GetTradeProductTypeNameMapping()[productType],
			)
			return result, nil
		}
		itemProductTypeMap[productType] = struct{}{}
	}

	for productType := range typeMap {
		if _, ok := itemProductTypeMap[productType]; !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNQuoteShortOfProductType
			result.ErrorMsg = i18nfmt.Sprintf(ctx,
				"当前报价单缺少类型为 %s 的报价项，不可提交",
				multienv.GetTradeProductTypeNameMapping()[productType],
			)
			return result, nil
		}
	}
	return result, nil
}

func (r *RelatedProductRule) BlockLevel() string {
	return BlockLevelError
}

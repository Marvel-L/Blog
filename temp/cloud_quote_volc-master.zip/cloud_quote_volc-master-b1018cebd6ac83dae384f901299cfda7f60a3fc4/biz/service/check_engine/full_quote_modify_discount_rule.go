package check_engine

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

// FullQuoteModifyDiscountRule 审批中修改时，再次送审前后商务优惠范围需保持一致。
type FullQuoteModifyDiscountRule struct{}

func (r *FullQuoteModifyDiscountRule) Key() string { return "BizDataRuleFullQuoteModifyDiscount" }

func (r *FullQuoteModifyDiscountRule) Desc() string {
	return "审批中修改整单校验：再次送审前后商务优惠范围需保持一致。"
}

func (r *FullQuoteModifyDiscountRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyGuaranteeItems,
		quote_context.QuoteContextKeyApplyItems,
		quote_context.QuoteContextKeyRebateItemList,
		quote_context.QuoteContextKeyQuoteItemsAllStatus,
	}
}

func (r *FullQuoteModifyDiscountRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		logs.CtxError(ctx, "[FullQuoteModifyDiscountRule]_context_param_is_invalid, hasQuote=%v", quoteCtx != nil && quoteCtx.Persisted.Quote != nil)
		return result, nil
	}
	quoteDB := quoteCtx.Persisted.Quote
	// 仅老版审批中修改校验「送审前后商务优惠范围一致」；新版审批中修改允许调整商务优惠范围，故跳过。
	if !quoteDB.IsInModifyProcess() || quoteDB.IsNewModifyProcessData() {
		return result, nil
	}
	currentDiscounts := fullQuoteBusinessDiscounts(quoteCtx)
	mctx, _ := quoteDB.GetModifyContext()
	oldDiscounts := strings.Split(mctx.DiscountSnapshot, ",")
	if sameFullQuoteDiscounts(ctx, currentDiscounts, oldDiscounts) {
		return result, nil
	}
	logs.CtxInfo(ctx, "[FullQuoteModifyDiscountRule]_送审前后商务优惠有差异，currentDiscounts=%v, oldDiscounts=%v", currentDiscounts, oldDiscounts)
	result.Pass = false
	result.ErrorCode = errors.CodeNCanNotSubmitQuote
	result.ErrorMsg = "审批修改后，商务优惠范围有差异"
	return result, nil
}

func (r *FullQuoteModifyDiscountRule) BlockLevel() string { return BlockLevelError }

func fullQuoteBusinessDiscounts(quoteCtx *quote_context.QuoteContext) []string {
	if quoteCtx == nil {
		return nil
	}
	businessDiscounts := make([]string, 0)
	if len(quoteCtx.Persisted.GuaranteeItems) > 0 {
		businessDiscounts = append(businessDiscounts, multienv.GetBusinessDiscountGuarantee())
	}
	if hasApplyItem(quoteCtx.Persisted.ApplyItems, multienv.ApplyBizKeyCoupon) {
		businessDiscounts = append(businessDiscounts, multienv.GetBusinessDiscountCoupon())
	}
	if len(quoteCtx.Persisted.RebateItemList) > 0 {
		businessDiscounts = append(businessDiscounts, multienv.GetBusinessDiscountRebate())
	}
	if hasApplyItem(quoteCtx.Persisted.ApplyItems, multienv.ApplyBizKeyCredit) {
		businessDiscounts = append(businessDiscounts, multienv.GetBusinessDiscountCredit())
	}
	for _, item := range quoteCtx.Persisted.QuoteItemsAllStatus {
		if item != nil && multienv.IsGiveAwayType(item.GiveAwayType) {
			businessDiscounts = append(businessDiscounts, multienv.GetBusinessDiscountGiveAway())
			break
		}
	}
	return businessDiscounts
}

package check_engine

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

type CheckResult struct {
	Pass       bool
	BlockLevel string // 阻塞级别(规则粒度)，error-阻塞流程，warning-不阻塞流程，仅告警，info-不阻塞流程，仅记录日志
	RuleKey    string
	RuleDesc   string
	ErrorCode  errors.ErrorCodeN
	ErrorMsg   string
	Detail     interface{}
}

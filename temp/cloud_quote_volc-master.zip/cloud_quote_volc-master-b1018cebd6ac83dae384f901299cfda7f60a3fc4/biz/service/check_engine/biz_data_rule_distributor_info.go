package check_engine

import (
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// DistributorInfoRule BP 分销商信息一致性校验。
//
// 与原 quote_service.validateDistributorInfos 的差异：
//   - RPC 调用 account_service.GetDistributorInfo 提取到 loaderDistributorInfo（QuoteContext External 维度）；
//   - Rule 内仅做：本地 Quote.DistributorInfos 反序列化 + 与 External.DistributorInfo 字段比对，零写入；
//   - 仅在分销业务（IsDistributionBizTypeCustom）场景生效；非分销 Quote 直接 Pass。
//
// 注意：原 validateDistributorInfos 无任何写副作用（不会回填 quote 字段），
// 因此本 Rule 不需要在入口层做任何前置写操作。
type DistributorInfoRule struct{}

func (r *DistributorInfoRule) Key() string {
	return "BizDataRuleDistributorInfo"
}

func (r *DistributorInfoRule) Desc() string {
	return "BP 分销商信息校验：分销业务报价单的 DistributorInfos 中 FinalCustomer / FirstDistributor / SecondDistributor 须与最新账号关系保持一致。"
}

func (r *DistributorInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyDistributorInfo,
	}
}

func (r *DistributorInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if !quote.IsDistributionBizTypeCustom() {
		return result, nil
	}

	src := &model.DistributorInfo{}
	_ = json.Unmarshal([]byte(quote.DistributorInfos), src)

	dest := quoteCtx.External.DistributorInfo
	if dest == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "DistributorInfos missing")
		return result, nil
	}

	if !src.FinalCustomer.DeepEqual(dest.FinalCustomer) {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "DistributorInfos FinalCustomer changed")
		return result, nil
	}
	if !src.FirstDistributor.DeepEqual(dest.FirstDistributor) {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "DistributorInfos FirstDistributor changed")
		return result, nil
	}
	if (src.SecondDistributor != nil && dest.SecondDistributor == nil) ||
		(src.SecondDistributor == nil && dest.SecondDistributor != nil) {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "DistributorInfos SecondDistributor changed")
		return result, nil
	}
	if src.SecondDistributor != nil && !src.SecondDistributor.DeepEqual(dest.SecondDistributor) {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributorInfoCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "DistributorInfos SecondDistributor changed")
		return result, nil
	}
	return result, nil
}

func (r *DistributorInfoRule) BlockLevel() string {
	return BlockLevelError
}

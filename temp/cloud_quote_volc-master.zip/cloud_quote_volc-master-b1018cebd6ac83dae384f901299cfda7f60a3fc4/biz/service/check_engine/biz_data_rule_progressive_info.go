package check_engine

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ProgressiveInfoRule —— 阶梯信息校验。
//
// 与原 QuoteData.ProgressiveInfoCheck 保持错误码与文案完全一致：
//   - 阶梯报价：ProgressiveInfo 必须能被合法解析；当配价账号数 ≤ 1 时，累计类型只允许 Single；
//   - 非阶梯报价：不允许填写 ProgressiveInfo。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - AccountIDs ⇔ Quote.CustomerDetail 按 "," split。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type ProgressiveInfoRule struct{}

func (r *ProgressiveInfoRule) Key() string { return "BizDataRuleProgressiveInfo" }
func (r *ProgressiveInfoRule) Desc() string {
	return "阶梯信息校验：阶梯报价时 ProgressiveInfo 必须合法且单账号场景下仅允许独立累计；非阶梯报价不可填写 ProgressiveInfo"
}
func (r *ProgressiveInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *ProgressiveInfoRule) BlockLevel() string { return BlockLevelError }

func (r *ProgressiveInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNProgressiveInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.QuoteType == multienv.QuoteTypeProgressive {
		progressiveInfo, err := config_option_service.GenProgressiveInfo(quote.ProgressiveInfo)
		if err != nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNProgressiveInfoCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
		// AccountIDs: Quote.CustomerDetail 按 "," split（与 QuoteDataCheckHelper 派生口径一致）
		var accountIDs []string
		if quote.CustomerDetail != "" {
			accountIDs = strings.Split(quote.CustomerDetail, ",")
		}
		if len(accountIDs) <= 1 && progressiveInfo.AccumulateType != constants.AccumulateTypeSingle {
			result.Pass = false
			result.ErrorCode = errors.CodeNProgressiveInfoCheckFailed
			result.ErrorMsg = "单账号阶梯报价，阶梯累计类型只允许选择独立累计"
			return result, nil
		}
		return result, nil
	}
	if quote.ProgressiveInfo != "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNProgressiveInfoCheckFailed
		result.ErrorMsg = "报价类型非阶梯报价，不支持填写阶梯信息"
		return result, nil
	}
	return result, nil
}

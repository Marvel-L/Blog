package check_engine

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/gopkg/logs"
)

// SolutionInfoRule —— 解决方案账号校验。
//
// 与原 QuoteData.SolutionInfoCheck 保持错误码与文案完全一致：
//   - 项目制报价单不支持多产解账号；
//   - SolutionConsultantID 中的每个邮箱必须能通过 Lark RPC 解析为有效用户。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsProjectBased ⇔ Quote.QuoteType == multienv.QuoteTypeProjectBased。
//
// 属于校验类 RPC（lark_client.GetUserIDsByEmails 仅做账号有效性判定），按 §8.11 允许在 Rule 内调用。
// 仅依赖 Persisted.Quote。
type SolutionInfoRule struct{}

func (r *SolutionInfoRule) Key() string { return "BizDataRuleSolutionInfo" }
func (r *SolutionInfoRule) Desc() string {
	return "解决方案账号校验：项目制不支持多产解账号；SolutionConsultantID 中的每个邮箱必须有效"
}
func (r *SolutionInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *SolutionInfoRule) BlockLevel() string { return BlockLevelError }

func (r *SolutionInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNSolutionInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	consultantIdList := strings.Split(quote.SolutionConsultantID, ",")
	if quote.QuoteType == multienv.QuoteTypeProjectBased && len(consultantIdList) > 1 {
		logs.CtxError(ctx, "checkSolutionConsultantIDInfo, 项目制报价单不支持多产解账号")
		result.Pass = false
		result.ErrorCode = errors.CodeNSolutionInfoCheckFailed
		result.ErrorMsg = "项目制报价单不支持多产解账号"
		return result, nil
	}
	employeeMap, peopleErr := lark_client.GetUserIDsByEmails(ctx, consultantIdList)
	if peopleErr != nil {
		logs.CtxError(ctx, "checkSolutionConsultantIDInfo err=%v", peopleErr)
		result.Pass = false
		result.ErrorCode = errors.CodeNSolutionInfoCheckFailed
		result.ErrorMsg = "解决方案账号失效：" + quote.SolutionConsultantID
		return result, nil
	}
	for _, v := range consultantIdList {
		if _, exist := employeeMap[v]; !exist {
			logs.CtxInfo(ctx, "checkSolutionConsultantIDInfo, 账号[%s]不存在", v)
			result.Pass = false
			result.ErrorCode = errors.CodeNSolutionInfoCheckFailed
			result.ErrorMsg = "解决方案账号失效：" + v
			return result, nil
		}
	}
	return result, nil
}

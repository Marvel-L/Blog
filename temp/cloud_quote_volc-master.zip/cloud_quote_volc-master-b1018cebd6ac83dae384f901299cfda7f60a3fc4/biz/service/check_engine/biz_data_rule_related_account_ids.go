package check_engine

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// RelatedAccountIDsRule —— 签约账号、配价账号、最终客户账号校验。
//
// 与原 QuoteData.RelatedAccountIDsCheck（quote_data_field_check.go:173-278）保持错误码与文案完全一致：
//   - 直销/SLV/标准伙伴/生态代理/EPS内部/字节内部：ContractAccount=CustomerDetail=CustomerAccount，
//     且 CustomerDetail 拆分出的每个账号必须在商机客户账号集合中；
//   - 生态分销/代销：ContractAccount=CustomerDetail，必须为商机伙伴账号且有伙伴授权；
//     最终客户账号根据 NeedCustomerAccountTradeTypeCodeMap 判定是否允许，且若必填须在商机客户账号集合中；
//   - AI生态/集成解决方案：ContractAccount=CustomerDetail，签约账号须为商机伙伴 cuid 账号；
//     最终客户账号若填写须为商机客户账号；
//   - 生态转售：CustomerDetail=CustomerAccount 为客户账号；ContractAccount 为商机伙伴账号且有伙伴授权。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsPrmQuote                 ⇔ Quote.IsPrmQuote()；
//   - IsInnerQuote               ⇔ Quote.IsInnerQuote()；
//   - AccountIDs                 ⇔ strings.Split(Quote.CustomerDetail, ",")（CustomerDetail 非空时）；
//   - customerAccountMap         ⇔ External.OppInfo.CustomerVolcanoMap；
//   - partnerAccountMap          ⇔ External.OppInfo.PartnerVolcanoMap；
//   - partnerCustomerAccountMap  ⇔ External.OppInfo.PartnerCustomerVolcanoMap；
//   - partnerGrant               ⇔ External.TradeTypeGrantMap[TradeTypeCode]。
//
// 副作用剥离（§9）：原 helper.partnerInfo = partnerInfo 写回不在 Rule 内进行，
// 后续依赖伙伴授权时间区间的校验已直接消费 External.TradeTypeGrantMap（见 PriceValidPeriodRule）。
//
// 仅依赖 Persisted.Quote + External.OppInfo + External.TradeTypeGrantMap，不发起任何 RPC / DB 查询。
type RelatedAccountIDsRule struct{}

func (r *RelatedAccountIDsRule) Key() string { return "BizDataRuleRelatedAccountIDs" }
func (r *RelatedAccountIDsRule) Desc() string {
	return "签约账号、配价账号、最终客户账号校验：按客户类型校验账号一致性、商机归属与伙伴授权"
}
func (r *RelatedAccountIDsRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyOppInfo,
		quote_context.QuoteContextKeyPartnerGrant,
	}
}
func (r *RelatedAccountIDsRule) BlockLevel() string { return BlockLevelError }

func (r *RelatedAccountIDsRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNAccountIDCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote

	if quote.IsInnerQuote() || quote.IsPrmQuote() || multienv.IsBytePlus() {
		return result, nil
	}

	var customerAccountMap, partnerAccountMap, partnerCustomerAccountMap map[string]bool
	if quoteCtx.External.OppInfo != nil {
		customerAccountMap = quoteCtx.External.OppInfo.CustomerVolcanoMap
		partnerAccountMap = quoteCtx.External.OppInfo.PartnerVolcanoMap
		partnerCustomerAccountMap = quoteCtx.External.OppInfo.PartnerCustomerVolcanoMap
	}

	switch quote.TradeTypeCode {
	case multienv.CustomerTypeCodeDirectSell,
		multienv.CustomerTypeCodeSLV,
		multienv.CustomerTypeCodePartnerStandard,
		multienv.CustomerTypeCodeEcoAgent,
		multienv.CustomerTypeCodeEPSInner,
		multienv.CustomerTypeCodeByteInner:
		// 1. 签约账号、配价账号、最终客户账号相同
		// 2. 是商机客户账号（直销客户可能多账号）
		// 3. 账号数量可能 0~10
		if quote.CustomerDetail == "" {
			return result, nil
		}
		if !util.SameKeys(quote.ContractAccount, quote.CustomerDetail, quote.CustomerAccount) {
			result.Pass = false
			result.ErrorCode = errors.CodeNAccountRelationInconsistent
			result.ErrorMsg = fmt.Sprintf("签约账号、配价账号、最终客户账号需保持一致，请检查账号填写。签约账号%s、配价账号%s、最终客户账号%s", quote.ContractAccount, quote.CustomerDetail, quote.CustomerAccount)
			return result, nil
		}
		var invalidAccountIDs []string
		for _, accountID := range splitAccountIDs(quote.CustomerDetail) {
			if _, ok := customerAccountMap[accountID]; !ok {
				invalidAccountIDs = append(invalidAccountIDs, accountID)
			}
		}
		if len(invalidAccountIDs) > 0 {
			result.Pass = false
			result.ErrorCode = errors.CodeNCustomerAccountNotOpportunityCustomer
			result.ErrorMsg = fmt.Sprintf("客户账号%s已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。", strings.Join(invalidAccountIDs, ","))
			return result, nil
		}

	case multienv.CustomerTypeCodeEcoDist,
		multienv.CustomerTypeCodeEcoSalesByProxy:
		// 签约账号、配价账号账号相同
		// 签约账号、配价账号是商机伙伴账号
		// 签约账号、配价账号有伙伴授权
		// 分销、集成解决方案最终客户账号为空
		// 代销最终客户账号ID不为空，为客户账号
		// 生态客户类型，账号数量 0~1
		if !util.SameKeys(quote.ContractAccount, quote.CustomerDetail) {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceAccountInconsistent
			result.ErrorMsg = fmt.Sprintf("签约账号和配价账号需保持一致，请检查账号填写。签约账号%s、配价账号%s", quote.ContractAccount, quote.CustomerDetail)
			return result, nil
		}
		if quote.CustomerDetail != "" {
			if _, ok := partnerAccountMap[quote.CustomerDetail]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNPriceAccountNotOpportunityPartner
				result.ErrorMsg = fmt.Sprintf("配价账号%s已换绑至其他伙伴客户，当前商机关联的伙伴无法使用该账号报价，你可前往商机页面更改商机关联伙伴后重试或者新建商机关联新的伙伴后发起报价。", quote.CustomerDetail)
				return result, nil
			}
			partnerGrant := quoteCtx.External.TradeTypeGrantMap[quote.TradeTypeCode]
			if partnerGrant == nil {
				result.Pass = false
				result.ErrorCode = errors.CodeNPartnerAccountNoGrant
				result.ErrorMsg = fmt.Sprintf("伙伴账号%s无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T", quote.CustomerDetail)
				return result, nil
			}
			if _, ok := partnerGrant.PartnerMap[quote.CustomerDetail]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNPartnerAccountNoGrant
				result.ErrorMsg = fmt.Sprintf("伙伴账号%s无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T", quote.CustomerDetail)
				return result, nil
			}
		}
		if _, need := multienv.NeedCustomerAccountTradeTypeCodeMap[quote.TradeTypeCode]; need {
			if _, ok := customerAccountMap[quote.CustomerAccount]; quote.CustomerAccount != "" && !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNFinalAccountNotOpportunityCustomer
				result.ErrorMsg = fmt.Sprintf("最终客户账号%s已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。", quote.CustomerAccount)
				return result, nil
			}
		} else if quote.CustomerAccount != "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNCustomerAccountShouldBeEmpty
			result.ErrorMsg = fmt.Sprintf("当前客户类型不允许填写最终客户账号，请清空后重试。客户类型%s(%d)、最终客户账号%s", quote.TradeType, quote.TradeTypeCode, quote.CustomerAccount)
			return result, nil
		}

	case multienv.CustomerTypeCodeEcoSolution:
		// 1. 客户类型为 AI生态/集成解决方案，签约账号是伙伴 cuid 账号、配价账号等于签约账号，此处不校验账号是否必填
		// 2. 客户类型为 AI生态/集成解决方案，最终客户账号是商机客户账号，此处不校验账号是否必填
		if !util.SameKeys(quote.ContractAccount, quote.CustomerDetail) {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceAccountInconsistent
			result.ErrorMsg = fmt.Sprintf("签约账号和配价账号需保持一致，请检查账号填写。签约账号%s、配价账号%s", quote.ContractAccount, quote.CustomerDetail)
			return result, nil
		}
		// 如果填写了签约账号/配价账号，校验是否为伙伴 cuid 账号
		if quote.CustomerDetail != "" {
			if _, ok := partnerCustomerAccountMap[quote.CustomerDetail]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNOpportunityPartnerAccountIDCheckFailed
				result.ErrorMsg = "invalid r.CustomerDetail : " + quote.CustomerDetail + " is not opportunity partner cuid accountID"
				return result, nil
			}
		}
		// 如果填写了最终客户账号，校验是否为商机客户账号
		if quote.CustomerAccount != "" {
			if _, ok := customerAccountMap[quote.CustomerAccount]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNFinalAccountNotOpportunityCustomer
				result.ErrorMsg = fmt.Sprintf("最终客户账号%s已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。", quote.CustomerAccount)
				return result, nil
			}
		}

	case multienv.CustomerTypeCodeEcoSell:
		// 配价账号和最终客户账号相同是客户账号
		// 签约账号是商机伙伴账号有伙伴授权
		if !util.SameKeys(quote.CustomerDetail, quote.CustomerAccount) {
			result.Pass = false
			result.ErrorCode = errors.CodeNPriceFinalCustomerAccountInconsistent
			result.ErrorMsg = fmt.Sprintf("配价账号和最终客户账号需保持一致，请检查账号填写。配价账号%s、最终客户账号%s", quote.CustomerDetail, quote.CustomerAccount)
			return result, nil
		}
		if _, ok := customerAccountMap[quote.CustomerAccount]; quote.CustomerAccount != "" && !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNFinalAccountNotOpportunityCustomer
			result.ErrorMsg = fmt.Sprintf("最终客户账号%s已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。", quote.CustomerAccount)
			return result, nil
		}
		if _, ok := partnerAccountMap[quote.ContractAccount]; quote.ContractAccount != "" && !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractAccountNotOpportunityPartner
			result.ErrorMsg = fmt.Sprintf("签约账号%s已换绑至其他伙伴客户，当前商机关联的伙伴无法使用该账号报价，你可前往商机页面更改商机关联伙伴后重试或者新建商机关联新的伙伴后发起报价。", quote.ContractAccount)
			return result, nil
		}
		if quote.ContractAccount != "" {
			partnerGrant := quoteCtx.External.TradeTypeGrantMap[quote.TradeTypeCode]
			if partnerGrant == nil {
				result.Pass = false
				result.ErrorCode = errors.CodeNPartnerAccountNoGrant
				result.ErrorMsg = fmt.Sprintf("伙伴账号%s无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T", quote.ContractAccount)
				return result, nil
			}
			if _, ok := partnerGrant.PartnerMap[quote.ContractAccount]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNPartnerAccountNoGrant
				result.ErrorMsg = fmt.Sprintf("伙伴账号%s无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T", quote.ContractAccount)
				return result, nil
			}
		}

	default:
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeAccountCheckUnsupported
		result.ErrorMsg = fmt.Sprintf("当前客户类型%s(%d)不支持账号校验，请检查客户类型", quote.TradeType, quote.TradeTypeCode)
		return result, nil
	}

	return result, nil
}

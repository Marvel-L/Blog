package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// CouponApplyRule 代金券申请条目校验。
//
// 来源：原 CommonApplyChecker → apply_checker.CouponApplyChecker。
// 仅当报价单存在 BizKey=coupon 的申请条目时校验：要求 quote.SupportCoupon=true。
// 不再依赖 *gorm.DB；ApplyItems 由 QuoteContextLoader 预加载。
type CouponApplyRule struct{}

func (r *CouponApplyRule) Key() string {
	return "BizDataRuleCouponApply"
}

func (r *CouponApplyRule) Desc() string {
	return "代金券申请校验：当前报价单需支持代金券申请（不支持时不应残留代金券申请条目）。"
}

func (r *CouponApplyRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyApplyItems,
	}
}

func (r *CouponApplyRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCommonApplyCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if !hasApplyItem(quoteCtx.Persisted.ApplyItems, multienv.ApplyBizKeyCoupon) {
		return result, nil
	}
	supportCoupon, err := quoteCtx.Persisted.Quote.SupportCoupon(ctx)
	if err != nil {
		return nil, err
	}
	if !supportCoupon {
		applyBizDesc := multienv.GetApplyBizDesc(multienv.ApplyBizKeyCoupon)
		result.Pass = false
		result.ErrorCode = errors.CodeNCommonApplyCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单不支持%s申请，请先删除%s申请信息", applyBizDesc, applyBizDesc)
		return result, nil
	}
	return result, nil
}

func (r *CouponApplyRule) BlockLevel() string {
	return BlockLevelError
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// QuoteEstimateBySalesRule —— 销售预估金额校验。
//
// 与原 QuoteData.QuoteEstimateBySalesCheck 保持错误码与文案完全一致：
// 当报价单涉及商品包含公有云 / 解决方案 / 一体机时，QuoteEstimateBySales 必须 > 0。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - ProductTypeMap ⇔ Quote.GetProductTypeMap（基于 Quote.QuoteRelatedProduct JSON 解析）。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type QuoteEstimateBySalesRule struct{}

func (r *QuoteEstimateBySalesRule) Key() string { return "BizDataRuleQuoteEstimateBySales" }
func (r *QuoteEstimateBySalesRule) Desc() string {
	return "销售预估金额校验：涉及公有云 / 解决方案 / 一体机的报价单，QuoteEstimateBySales 必填且不可为 0"
}
func (r *QuoteEstimateBySalesRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *QuoteEstimateBySalesRule) BlockLevel() string { return BlockLevelError }

func (r *QuoteEstimateBySalesRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimateBySalesCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	productTypeMap, err := quote.GetProductTypeMap(ctx)
	if err != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimateBySalesCheckFailed
		result.ErrorMsg = err.Error()
		return result, nil
	}
	_, containsOnline := productTypeMap[multienv.TradeProductTypeOnline]
	_, containsSolution := productTypeMap[multienv.TradeProductTypeSolution]
	_, containsIntegratedMachine := productTypeMap[multienv.TradeProductTypeIntegratedMachine]
	if (containsOnline || containsSolution || containsIntegratedMachine) && quote.QuoteEstimateBySales.IsZero() {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimateBySalesCheckFailed
		result.ErrorMsg = "涉及公有云或者解决方案或者一体机的报价单，需要填写预估销售金额"
		return result, nil
	}
	return result, nil
}

package check_engine

import (
	"context"
	stderrors "errors"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/guarantee_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/starling_client"
)

func TestGuaranteeRuleDesc(t *testing.T) {
	t.Run("返回规则说明", func(t *testing.T) {
		mockey.PatchConvey("返回规则说明", t, func() {
			rule := &GuaranteeRule{}

			convey.So(rule.Desc(), convey.ShouldContainSubstring, "补充协议结转需关联有效父单根规则")
		})
	})
}

func TestGuaranteeRuleNeeds(t *testing.T) {
	t.Run("返回依赖键", func(t *testing.T) {
		mockey.PatchConvey("返回依赖键", t, func() {
			rule := &GuaranteeRule{}

			convey.So(rule.Needs(), convey.ShouldResemble, []quote_context.QuoteContextKey{
				quote_context.QuoteContextKeyQuote,
				quote_context.QuoteContextKeyQuoteItems,
				quote_context.QuoteContextKeyItemValues,
				quote_context.QuoteContextKeyGuaranteeItems,
			})
		})
	})
}

func TestGuaranteeRuleCheck(t *testing.T) {
	rule := &GuaranteeRule{}

	t.Run("缺少报价上下文时返回失败", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), &quote_context.QuoteContext{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNNotSupportGuarantee)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "quote context is missing")
		})
	})

	t.Run("不支持保底时返回失败并带详情", func(t *testing.T) {
		mockey.PatchConvey("不支持保底", t, func() {
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(nil).Build()
			quote := &model.Quote{}
			quote.Id = 1001
			guaranteeItem := &model.GuaranteeItem{}
			guaranteeItem.Id = 2001
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
				},
			}
			mockey.Mock((*model.Quote).SupportGuarantee).Return(false, nil).Build()
			mockey.Mock(starling_client.GetTextWithLang).To(func(textKey string, _ string) string {
				return textKey
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNNotSupportGuarantee)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "当前报价单不支持保底，请删除保底信息")
			convey.So(result.Detail, convey.ShouldResemble, []int64{guaranteeItem.Id})
		})
	})

	t.Run("结转校验透传父单数据", func(t *testing.T) {
		mockey.PatchConvey("结转校验透传父单数据", t, func() {
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(nil).Build()
			quote := &model.Quote{ParentQuoteID: 1002}
			quote.Id = 1001
			parentQuote := &model.Quote{}
			parentQuote.Id = 1002
			currentQuoteItem := &model.QuoteItem{}
			currentQuoteItem.Id = 3001
			parentQuoteItem := &model.QuoteItem{}
			parentQuoteItem.Id = 3002
			quoteItems := []*model.QuoteItem{currentQuoteItem}
			parentQuoteItems := []*model.QuoteItem{parentQuoteItem}
			itemValues := map[int64][]*model.QuoteItemValue{3001: {}}
			parentItemValues := map[int64][]*model.QuoteItemValue{3002: {}}
			guaranteeItem := &model.GuaranteeItem{CarryForward: model.CarryForwardYes}
			guaranteeItem.Id = 2001
			parentGuaranteeItem := &model.GuaranteeItem{}
			parentGuaranteeItem.Id = 2002
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					QuoteItems:     quoteItems,
					ItemValues:     itemValues,
					GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
				},
			}
			mockey.Mock((*model.Quote).SupportGuarantee).Return(true, nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeTotalSeats).Return(nil).Build()
			mockey.Mock(loadParentQuoteContextForGuaranteeCarryForward).To(
				func(_ context.Context, quoteDB *model.Quote) (*quote_context.QuoteContext, error) {
					convey.So(quoteDB, convey.ShouldEqual, quote)
					return &quote_context.QuoteContext{
						Persisted: quote_context.QuoteContextPersisted{
							Quote:          parentQuote,
							GuaranteeItems: []*model.GuaranteeItem{parentGuaranteeItem},
							QuoteItems:     parentQuoteItems,
							ItemValues:     parentItemValues,
						},
					}, nil
				},
			).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeCarryForward).To(
				func(_ context.Context, tx *gorm.DB, quoteDB *model.Quote, item *model.GuaranteeItem, opts ...guarantee_item_service.ValidateGuaranteeCarryForwardOpt) error {
					convey.So(tx, convey.ShouldBeNil)
					convey.So(quoteDB, convey.ShouldEqual, quote)
					convey.So(item, convey.ShouldEqual, guaranteeItem)

					opt := &guarantee_item_service.ValidateGuaranteeCarryForwardOption{}
					for _, fn := range opts {
						fn(opt)
					}

					convey.So(opt.QuoteData[quote.Id].Quote, convey.ShouldEqual, quote)
					convey.So(opt.QuoteData[quote.Id].GuaranteeItems, convey.ShouldResemble, []*model.GuaranteeItem{guaranteeItem})
					convey.So(opt.QuoteData[quote.Id].QuoteItems, convey.ShouldResemble, quoteItems)
					convey.So(opt.QuoteData[quote.Id].ItemValues, convey.ShouldResemble, itemValues)
					convey.So(opt.QuoteData[parentQuote.Id].Quote, convey.ShouldEqual, parentQuote)
					convey.So(opt.QuoteData[parentQuote.Id].GuaranteeItems, convey.ShouldResemble, []*model.GuaranteeItem{parentGuaranteeItem})
					convey.So(opt.QuoteData[parentQuote.Id].QuoteItems, convey.ShouldResemble, parentQuoteItems)
					convey.So(opt.QuoteData[parentQuote.Id].ItemValues, convey.ShouldResemble, parentItemValues)
					return nil
				},
			).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
		})
	})

	t.Run("结转校验返回业务错误时转为失败结果", func(t *testing.T) {
		mockey.PatchConvey("结转校验返回业务错误", t, func() {
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(nil).Build()
			quote := &model.Quote{}
			quote.Id = 1001
			guaranteeItem := &model.GuaranteeItem{}
			guaranteeItem.Id = 2001
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
				},
			}
			apiErr := quoteerrors.NewBizErrWithMsg(
				quoteerrors.CodeNGuaranteeCarryForwardInvalid,
				"当前保底规则未完整包含原报价单保底报价项，不允许选择结转",
			)
			mockey.Mock((*model.Quote).SupportGuarantee).Return(true, nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeTotalSeats).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeCarryForward).Return(apiErr).Build()
			mockey.Mock(starling_client.GetTextWithLang).To(func(textKey string, _ string) string {
				return textKey
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNGuaranteeCarryForwardInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, apiErr.Error())
			convey.So(result.Detail, convey.ShouldResemble, []int64{guaranteeItem.Id})
		})
	})

	t.Run("结转校验返回普通错误时直接返回", func(t *testing.T) {
		mockey.PatchConvey("结转校验返回普通错误", t, func() {
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(nil).Build()
			quote := &model.Quote{}
			quote.Id = 1001
			guaranteeItem := &model.GuaranteeItem{}
			guaranteeItem.Id = 2001
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
				},
			}
			expectErr := stderrors.New("carry forward failed")
			mockey.Mock((*model.Quote).SupportGuarantee).Return(true, nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeTotalSeats).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeCarryForward).Return(expectErr).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, expectErr)
		})
	})

	t.Run("规则树送审校验失败时返回失败结果", func(t *testing.T) {
		mockey.PatchConvey("规则树送审校验失败", t, func() {
			quote := &model.Quote{}
			quote.Id = 1001
			root := &model.GuaranteeItem{}
			root.Id = 2001
			child := &model.GuaranteeItem{ParentGuaranteeID: 2001, RootGuaranteeID: 2001}
			child.Id = 2002
			quoteItems := []*model.QuoteItem{{}}
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					QuoteItems:     quoteItems,
					GuaranteeItems: []*model.GuaranteeItem{root, child},
				},
			}
			apiErr := &guarantee_item_service.GuaranteeRuleTreeError{
				Err: quoteerrors.NewBizErrWithMsg(
					quoteerrors.CodeNGuaranteeRuleTreeInvalid,
					"父子保底规则三元组不能完全一致",
				),
				Reason:           guarantee_item_service.GuaranteeRuleTreeErrorReasonParentChildTupleEqual,
				GuaranteeItemIDs: []int64{child.Id},
			}
			mockey.Mock((*model.Quote).SupportGuarantee).Return(true, nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeTotalSeats).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeCarryForward).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).To(
				func(_ context.Context, inputQuote *model.Quote, items []*model.GuaranteeItem, inputQuoteItems []*model.QuoteItem) error {
					convey.So(inputQuote.Id, convey.ShouldEqual, quote.Id)
					convey.So(items, convey.ShouldResemble, []*model.GuaranteeItem{root, child})
					convey.So(inputQuoteItems, convey.ShouldResemble, quoteItems)
					return apiErr
				},
			).Build()
			mockey.Mock(starling_client.GetTextWithLang).To(func(textKey string, _ string) string {
				return textKey
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNGuaranteeRuleTreeInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "父子保底规则三元组不能完全一致")
			convey.So(result.Detail, convey.ShouldResemble, &guarantee_item_service.GuaranteeRuleTreeErrorDetail{
				Reason:           string(guarantee_item_service.GuaranteeRuleTreeErrorReasonParentChildTupleEqual),
				GuaranteeItemIDs: []int64{child.Id},
			})
		})
	})

	t.Run("规则树送审返回普通错误时兜底详情", func(t *testing.T) {
		mockey.PatchConvey("规则树送审普通错误", t, func() {
			quote := &model.Quote{}
			quote.Id = 1001
			guaranteeItems := []*model.GuaranteeItem{
				{},
				{},
				{},
			}
			guaranteeItems[0].Id = 2001
			guaranteeItems[1].Id = 2002
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          quote,
					QuoteItems:     []*model.QuoteItem{{}},
					GuaranteeItems: guaranteeItems,
				},
			}
			quoteCtx.Persisted.QuoteItems[0].Id = 3001
			expectErr := stderrors.New("rule tree check failed")
			mockey.Mock((*model.Quote).SupportGuarantee).Return(true, nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeTotalSeats).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeCarryForward).Return(nil).Build()
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(expectErr).Build()
			mockey.Mock(starling_client.GetTextWithLang).To(func(textKey string, _ string) string {
				return textKey
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNGuaranteeRuleTreeInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, expectErr.Error())
			convey.So(result.Detail, convey.ShouldResemble, &guarantee_item_service.GuaranteeRuleTreeErrorDetail{
				Reason:           string(guarantee_item_service.GuaranteeRuleTreeErrorReasonCheckFailed),
				GuaranteeItemIDs: []int64{2001, 2002},
			})
		})
	})
}

func TestGuaranteeRuleCheckRuleTreeForSubmit(t *testing.T) {
	rule := &GuaranteeRule{}
	quote := &model.Quote{}
	quote.Id = 1001
	root := &model.GuaranteeItem{}
	root.Id = 2001
	child := &model.GuaranteeItem{ParentGuaranteeID: 2001, RootGuaranteeID: 2001}
	child.Id = 2002
	quoteItems := []*model.QuoteItem{{}}
	quoteItems[0].Id = 3001
	quoteCtx := &quote_context.QuoteContext{
		Persisted: quote_context.QuoteContextPersisted{
			Quote:          quote,
			QuoteItems:     quoteItems,
			GuaranteeItems: []*model.GuaranteeItem{root, child},
		},
	}

	t.Run("校验通过时保持结果不变", func(t *testing.T) {
		mockey.PatchConvey("规则树校验通过", t, func() {
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).To(
				func(_ context.Context, inputQuote *model.Quote, items []*model.GuaranteeItem, inputQuoteItems []*model.QuoteItem) error {
					convey.So(inputQuote, convey.ShouldEqual, quote)
					convey.So(items, convey.ShouldResemble, []*model.GuaranteeItem{root, child})
					convey.So(inputQuoteItems, convey.ShouldResemble, quoteItems)
					return nil
				},
			).Build()
			result := &CheckResult{Pass: true}

			err := rule.checkRuleTreeForSubmit(context.Background(), result, quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
			convey.So(result.Detail, convey.ShouldBeNil)
		})
	})

	t.Run("tcc配置缺失时直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("规则树校验返回tcc配置缺失", t, func() {
			expectErr := quoteerrors.NewBizErrWithMsg(
				quoteerrors.CodeNTccConfigNotFound,
				"guarantee rule tree config not found",
			)
			mockey.Mock(guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit).Return(expectErr).Build()
			result := &CheckResult{Pass: true}

			err := rule.checkRuleTreeForSubmit(context.Background(), result, quoteCtx)

			convey.So(err, convey.ShouldEqual, expectErr)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
			convey.So(result.Detail, convey.ShouldBeNil)
		})
	})
}

func TestGuaranteeRuleLoadParentCarryForwardQuoteData(t *testing.T) {
	rule := &GuaranteeRule{}

	t.Run("未显式选择结转时不加载父单", func(t *testing.T) {
		mockey.PatchConvey("未显式选择结转", t, func() {
			data, err := rule.loadParentCarryForwardQuoteData(
				context.Background(),
				&model.Quote{ParentQuoteID: 1002},
				[]*model.GuaranteeItem{{CarryForward: model.CarryForwardNone}},
			)

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldBeNil)
		})
	})

	t.Run("命中结转时组装父单数据", func(t *testing.T) {
		mockey.PatchConvey("命中结转", t, func() {
			parentQuote := &model.Quote{}
			parentQuote.Id = 1002
			parentQuoteItem := &model.QuoteItem{}
			parentQuoteItem.Id = 3002
			parentGuaranteeItem := &model.GuaranteeItem{}
			parentGuaranteeItem.Id = 2002
			parentItemValues := map[int64][]*model.QuoteItemValue{3002: {}}
			mockey.Mock(loadParentQuoteContextForGuaranteeCarryForward).Return(&quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:          parentQuote,
					QuoteItems:     []*model.QuoteItem{parentQuoteItem},
					GuaranteeItems: []*model.GuaranteeItem{parentGuaranteeItem},
					ItemValues:     parentItemValues,
				},
			}, nil).Build()

			data, err := rule.loadParentCarryForwardQuoteData(
				context.Background(),
				&model.Quote{ParentQuoteID: 1002},
				[]*model.GuaranteeItem{{CarryForward: model.CarryForwardYes}},
			)

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldNotBeNil)
			convey.So(data.Quote, convey.ShouldEqual, parentQuote)
			convey.So(data.QuoteItems, convey.ShouldResemble, []*model.QuoteItem{parentQuoteItem})
			convey.So(data.GuaranteeItems, convey.ShouldResemble, []*model.GuaranteeItem{parentGuaranteeItem})
			convey.So(data.ItemValues, convey.ShouldResemble, parentItemValues)
		})
	})
}

func TestLoadParentQuoteContextForGuaranteeCarryForward(t *testing.T) {
	t.Run("非补充协议直接返回空", func(t *testing.T) {
		mockey.PatchConvey("非补充协议", t, func() {
			data, err := loadParentQuoteContextForGuaranteeCarryForward(context.Background(), &model.Quote{ParentQuoteID: 1002})

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldBeNil)
		})
	})

	t.Run("补充协议时加载父单上下文", func(t *testing.T) {
		mockey.PatchConvey("补充协议加载父单", t, func() {
			parentQuoteCtx := &quote_context.QuoteContext{QuoteID: 1002}
			mockey.Mock((*quote_context.QuoteContextLoader).Load).To(
				func(loader *quote_context.QuoteContextLoader, _ context.Context) (*quote_context.QuoteContext, error) {
					return parentQuoteCtx, nil
				},
			).Build()

			data, err := loadParentQuoteContextForGuaranteeCarryForward(context.Background(), &model.Quote{
				ParentQuoteID: 1002,
				QuoteScene:    multienv.SceneSupplyAgreement,
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldEqual, parentQuoteCtx)
		})
	})
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/log_utils"
)

// CouponParamRule 代金券参数校验。
//
// 来源：原 CouponParamChecker，调用 couponconfigservice.ValidateQuoteCouponsWithSwitch。
// 该函数内部包含：开关判断 / DB 查询代金券申请条目 / RPC 校验代金券参数 / 拦截策略。
//
// 迁移到 check_engine 后：
//   - DB 查询统一收敛到 loaderCouponList（已通过 BizKey=coupon 过滤），
//     Rule 仅复用 `Persisted.CouponList` 做 RPC 校验；
//   - 校验类 RPC 允许在 Rule 内直接调用，逻辑与原 ValidateQuoteCouponsWithSwitch 一致：
//     1) BatchValidateSwitch=false -> 跳过；
//     2) ValidateCoupon RPC 失败时按 InterceptSwitch 决定是否拦截。
type CouponParamRule struct{}

func (r *CouponParamRule) Key() string {
	return "BizDataRuleCouponParam"
}

func (r *CouponParamRule) Desc() string {
	return "代金券参数校验：依据代金券配置开关，校验当前报价单关联的代金券申请参数是否合法。"
}

func (r *CouponParamRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyCouponList,
	}
}

func (r *CouponParamRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCouponParamCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	logCtx := log_utils.Build(ctx).WithEvent("CouponParamRule")
	conf := config.GetSwitchCouponConf(ctx)
	if conf == nil || !conf.BatchValidateSwitch {
		logCtx.WithMsg("skip validate").Info(ctx)
		return result, nil
	}
	for _, couponConfig := range quoteCtx.Persisted.CouponList {
		if couponConfig == nil {
			continue
		}
		if err := couponconfigservice.ValidateCoupon(ctx, couponConfig, quoteCtx.Persisted.Quote); err != nil {
			logCtx.WithMsg("ValidateCoupon failed").WithErr(err).Warn(ctx)
			if !conf.InterceptSwitch {
				logCtx.WithMsg("skip intercept").Warn(ctx)
				continue
			}
			result.Pass = false
			result.ErrorCode = errors.CodeNCouponParamCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
	}
	return result, nil
}

func (r *CouponParamRule) BlockLevel() string {
	return BlockLevelError
}

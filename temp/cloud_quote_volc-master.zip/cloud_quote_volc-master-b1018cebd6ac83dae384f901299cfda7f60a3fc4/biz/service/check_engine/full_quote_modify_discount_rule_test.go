package check_engine

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/starling_client"
)

func TestFullQuoteModifyDiscountRuleNeeds(t *testing.T) {
	t.Run("返回依赖键", func(t *testing.T) {
		mockey.PatchConvey("返回依赖键", t, func() {
			rule := &FullQuoteModifyDiscountRule{}

			convey.So(rule.Needs(), convey.ShouldResemble, []quote_context.QuoteContextKey{
				quote_context.QuoteContextKeyQuote,
				quote_context.QuoteContextKeyGuaranteeItems,
				quote_context.QuoteContextKeyApplyItems,
				quote_context.QuoteContextKeyRebateItemList,
				quote_context.QuoteContextKeyQuoteItemsAllStatus,
			})
		})
	})
}

func TestFullQuoteBusinessDiscounts(t *testing.T) {
	t.Run("汇总整单商务优惠范围", func(t *testing.T) {
		mockey.PatchConvey("汇总整单商务优惠范围", t, func() {
			mockey.Mock(starling_client.GetTextWithLang).To(func(textKey string, _ string) string {
				return textKey
			}).Build()
			guaranteeItem := &model.GuaranteeItem{}
			guaranteeItem.Id = 1
			giveAwayItem := &model.QuoteItem{GiveAwayType: multienv.GetGiveAwayTypeStd()}
			giveAwayItem.Id = 21
			normalItem := &model.QuoteItem{}
			normalItem.Id = 22
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
					ApplyItems: []*model.CommonApplyItem{
						{BizKey: multienv.ApplyBizKeyCoupon},
						{BizKey: multienv.ApplyBizKeyCredit},
					},
					RebateItemList: model.RebateItemList{&model.RebateItem{QuoteItemID: 11}},
					QuoteItemsAllStatus: []*model.QuoteItem{
						giveAwayItem,
						normalItem,
					},
				},
			}

			convey.So(fullQuoteBusinessDiscounts(quoteCtx), convey.ShouldResemble, []string{
				multienv.BusinessDiscountGuarantee,
				multienv.BusinessDiscountCoupon,
				multienv.BusinessDiscountRebate,
				multienv.BusinessDiscountCredit,
				multienv.BusinessDiscountGiveAway,
			})
		})
	})

	t.Run("空上下文返回空", func(t *testing.T) {
		mockey.PatchConvey("空上下文", t, func() {
			convey.So(fullQuoteBusinessDiscounts(nil), convey.ShouldBeNil)
		})
	})
}

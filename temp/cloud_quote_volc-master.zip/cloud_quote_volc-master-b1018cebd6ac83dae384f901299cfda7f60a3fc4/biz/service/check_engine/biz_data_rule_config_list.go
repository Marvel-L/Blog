package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ConfigListRule 配置清单 / 项目制交付项校验。
//
// 来源：原 ConfigListChecker。
// 校验目标：在配置清单 / 项目制场景下，**同一个**「标品 + 配置 + 计费项」组合
// 不能同时出现 2 条及以上「成本价 / 出厂价类型为阶梯价」的交付项。
//
// 与原 checker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / DeliveryItems / ItemContextMap / DeliveryItemUnitCost；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - `commodity_service.GetTradeProductByArray` + `trade_client.BatchGetChargeItemCostLatest`
//     封装到 loaderDeliveryItemCost，Rule 仅做本地分组判断。
type ConfigListRule struct{}

func (r *ConfigListRule) Key() string {
	return "BizDataRuleConfigList"
}

func (r *ConfigListRule) Desc() string {
	return "配置清单/项目制交付项校验：" +
		"1) 同一标品+配置+计费项不允许出现两条及以上「成本价类型为阶梯价」的交付项；" +
		"2) 同一标品+配置+计费项不允许出现两条及以上「出厂价类型为阶梯价」的交付项。"
}

func (r *ConfigListRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyDeliveryItemCost,
	}
}

func (r *ConfigListRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNConfigListCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if !quote.IsConfigList() && !quote.IsProjectBased() {
		return result, nil
	}

	unitCostFactoryPrice := quoteCtx.Persisted.DeliveryItemUnitCost
	if unitCostFactoryPrice == nil {
		return result, nil
	}

	chargeItemKeyIDsMap := map[string][]int64{}
	chargeItemIDKeyMap := map[int64]string{}
	for _, req := range quoteCtx.Persisted.DeliveryItemCostReqList {
		if req == nil {
			continue
		}
		chargeItemKeyIDsMap[req.GetKey()] = append(chargeItemKeyIDsMap[req.GetKey()], req.QuoteItemID)
		chargeItemIDKeyMap[req.QuoteItemID] = req.GetKey()
	}

	for itemID, unitCostObj := range unitCostFactoryPrice.UnitCostMap {
		if unitCostObj == nil {
			continue
		}
		if _, ok := constants.CostProgressiveFunctionMap[unitCostObj.TotalCostFunction]; !ok {
			continue
		}
		itemKey := chargeItemIDKeyMap[itemID]
		itemIDs := chargeItemKeyIDsMap[itemKey]
		if len(itemIDs) > 1 {
			result.Pass = false
			result.ErrorCode = errors.CodeNConfigListCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "已有相同的成本价类型为阶梯价的标品+（配置）+计费项，交付项ID{$%d,%d}，成本价类型为阶梯价的相同的标品+（配置）+计费项不能出现两条及以上", itemIDs[0], itemIDs[1])
			return result, nil
		}
	}

	for itemID, factoryPriceObj := range unitCostFactoryPrice.FactoryPriceMap {
		if factoryPriceObj == nil {
			continue
		}
		if _, ok := constants.CostProgressiveFunctionMap[factoryPriceObj.ExFactoryPriceFunction]; !ok {
			continue
		}
		itemKey := chargeItemIDKeyMap[itemID]
		itemIDs := chargeItemKeyIDsMap[itemKey]
		if len(itemIDs) > 1 {
			result.Pass = false
			result.ErrorCode = errors.CodeNConfigListCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "已有相同的出厂价类型为阶梯价的标品+（配置）+计费项，交付项ID{$%d,%d}，出厂价类型为阶梯价的相同的标品+（配置）+计费项不能出现两条及以上", itemIDs[0], itemIDs[1])
			return result, nil
		}
	}
	return result, nil
}

func (r *ConfigListRule) BlockLevel() string {
	return BlockLevelError
}

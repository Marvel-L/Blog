package check_engine

import (
	"context"
	stderrors "errors"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/account_info"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/partner_inner"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/verify_info"
)

func TestCustomerDetailRuleCheckV2(t *testing.T) {
	rule := &CustomerDetailRule{}

	t.Run("官网自助按账号生效缺少客户账号时返回必填错误", func(t *testing.T) {
		mockey.PatchConvey("客户账号必填", t, func() {
			quote := &model.Quote{OrderType: "official", EffectiveType: constants.EffectiveTypeAccount}
			mockey.Mock(multienv.GetContractTypeOfficialWebAuto).Return("official").Build()

			result, err := rule.checkV2(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNCustomerAccountRequired)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "签约方式为【官网自助下单】时，客户 ID 必填")
		})
	})

	t.Run("客户账号超过十个时返回数量限制", func(t *testing.T) {
		mockey.PatchConvey("客户账号数量超限", t, func() {
			quote := &model.Quote{CustomerDetail: "1,2,3,4,5,6,7,8,9,10,11"}

			result, err := rule.checkV2(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountCountExceedLimit)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "客户账号不支持超10个报价，请删除多余账号后按需分批进行报价。当前账号数量11，账号列表1,2,3,4,5,6,7,8,9,10,11")
		})
	})

	t.Run("线下代客创建账号多选时返回账号列表 JSON", func(t *testing.T) {
		mockey.PatchConvey("线下代客账号多选", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceSales, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
				{AccountID: 102, CreateSource: account_info.CreateSourceSales, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{
				CustomerDetail:  "101,102",
				ContractAccount: "101",
				TradeTypeCode:   multienv.CustomerTypeCodeDirectSell,
				OrderTypeCode:   multienv.ContractTypeCodeOfficialWebAuto,
				QuoteType:       multienv.QuoteTypeNormal,
			}

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNSalesCreateAccountCountExceedLimit)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "线下代客创建的账号不允许多选。请删除多余账号后按需分批进行报价。当前账号数量2，账号列表[\"101\",\"102\"]")
		})
	})

	t.Run("多账号且场景不支持时返回多账号限制", func(t *testing.T) {
		mockey.PatchConvey("多账号不支持", t, func() {
			quote := &model.Quote{CustomerDetail: "101,102"}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNMultiAccountUnsupported)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "仅公有云（标品）且直签场景下允许客户账号多选。请删除多余账号后按需分批进行报价。当前账号数量2，账号列表101,102")
		})
	})

	t.Run("仅公有云商品包含线下代客账号时返回来源限制", func(t *testing.T) {
		mockey.PatchConvey("公有云账号来源限制", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceSales, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPublicCloudAccountCreateSourceInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "涉及商品类型仅包含公有云商品时，只允许选择客户自注册账号（[\"101\"]账号为线下代客创建类型，请移除账号或者修改涉及商品类型）")
		})
	})

	t.Run("仅公有云商品且账号来源合规时通过", func(t *testing.T) {
		mockey.PatchConvey("公有云账号校验通过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})

	t.Run("官网自助按账号生效缺少签约账号时返回必填错误", func(t *testing.T) {
		mockey.PatchConvey("签约账号必填", t, func() {
			quote := &model.Quote{
				CustomerDetail: "101",
				OrderType:      "official",
				EffectiveType:  constants.EffectiveTypeAccount,
			}
			mockey.Mock(multienv.GetContractTypeOfficialWebAuto).Return("official").Build()

			result, err := rule.checkV2(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNContractAccountRequired)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "签约方式为【官网自助下单】时，签约火山账号 ID 必填")
		})
	})

	t.Run("客户账号不是企业实名认证时返回实名错误", func(t *testing.T) {
		mockey.PatchConvey("客户账号非企业认证", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypePersonal},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountIDCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "用户账号非企业实名认证账号：101")
		})
	})

	t.Run("仅私有云商品包含官网账号时返回来源限制", func(t *testing.T) {
		mockey.PatchConvey("私有云账号来源限制", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOffline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPrivateCloudAccountCreateSourceInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "涉及商品类型仅包含私有云商品时，只允许选择线下代客创建账号（[\"101\"]账号为客户自注册创建类型，请移除账号或者修改涉及商品类型或者联系销运创建线下账号）")
		})
	})

	t.Run("客户账号来源不支持时返回来源限制", func(t *testing.T) {
		mockey.PatchConvey("客户账号来源非法", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: 2, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountCreateSourceInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "该客户账号101来源不支持绑定报价单，请使用官网注册或销售代客创建账号")
		})
	})

	t.Run("客户账号已注销时返回注销错误", func(t *testing.T) {
		mockey.PatchConvey("客户账号已注销", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, Status: account_info.AccountStatusDeleted, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "101", ContractAccount: "101"}

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountClosed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "当前账号101已注销，不支持报价")
		})
	})

	t.Run("客户账号不存在时返回账号不存在错误", func(t *testing.T) {
		mockey.PatchConvey("客户账号不存在", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{
				CustomerDetail:  "101,102",
				ContractAccount: "101",
				TradeTypeCode:   multienv.CustomerTypeCodeDirectSell,
				OrderTypeCode:   multienv.ContractTypeCodeOfficialWebAuto,
				QuoteType:       multienv.QuoteTypeNormal,
			}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountNotFound)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "用户账号102不存在，请检查账号 ID 是否正确")
		})
	})

	t.Run("客户账号重复时返回重复账号错误", func(t *testing.T) {
		mockey.PatchConvey("客户账号重复", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 101, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{
				CustomerDetail:  "101,101",
				ContractAccount: "101",
				TradeTypeCode:   multienv.CustomerTypeCodeDirectSell,
				OrderTypeCode:   multienv.ContractTypeCodeOfficialWebAuto,
				QuoteType:       multienv.QuoteTypeNormal,
			}
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: nil,
			}, nil).Build()

			result, err := rule.checkV2(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNDuplicateAccountID)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "输入账号有重复，请删除重复账号后重试。账号列表101,101")
		})
	})
}

func TestTotalEstimatedIncomeRuleCheck(t *testing.T) {
	rule := &TotalEstimatedIncomeRule{}

	t.Run("缺少报价上下文时返回通过并回填规则元数据", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.RuleKey, convey.ShouldEqual, rule.Key())
			convey.So(result.RuleDesc, convey.ShouldEqual, rule.Desc())
			convey.So(result.BlockLevel, convey.ShouldEqual, rule.BlockLevel())
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "")
			convey.So(result.Detail, convey.ShouldBeNil)
		})
	})

	t.Run("存在报价上下文时仍直接返回通过结果", func(t *testing.T) {
		mockey.PatchConvey("存在报价上下文", t, func() {
			result, err := rule.Check(context.Background(), &quote_context.QuoteContext{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.RuleKey, convey.ShouldEqual, rule.Key())
			convey.So(result.RuleDesc, convey.ShouldEqual, rule.Desc())
			convey.So(result.BlockLevel, convey.ShouldEqual, rule.BlockLevel())
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "")
			convey.So(result.Detail, convey.ShouldBeNil)
		})
	})
}

func TestCustomerQuoteQualificationRule(t *testing.T) {
	rule := &CustomerQuoteQualificationRule{}

	t.Run("缺少报价上下文时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNTradeTypeCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "quote context is missing")
		})
	})

	t.Run("直销配价账号无代销关系时通过并回填规则元数据", func(t *testing.T) {
		mockey.PatchConvey("直销账号校验通过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:  multienv.CustomerTypeCodeDirectSell,
				CustomerDetail: "1001",
			}
			quoteCtx.External.AccountFinancialRoleList = []*account_service.ListAccountFinancialRoleResp{
				{AccountID: "1001", FinancialRoleList: []int32{account_service.FinancialBizRoleSecondDistributor}},
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.RuleKey, convey.ShouldEqual, rule.Key())
			convey.So(result.RuleDesc, convey.ShouldEqual, rule.Desc())
			convey.So(result.BlockLevel, convey.ShouldEqual, rule.BlockLevel())
		})
	})

	t.Run("直销配价账号存在代销关系时禁止报价", func(t *testing.T) {
		mockey.PatchConvey("直销账号存在代销关系", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:  multienv.CustomerTypeCodeDirectSell,
				CustomerDetail: "1001,1002",
			}
			quoteCtx.External.AccountFinancialRoleList = []*account_service.ListAccountFinancialRoleResp{
				{AccountID: "1001", FinancialRoleList: []int32{account_service.FinancialBizRoleSecondDistributor}},
				{AccountID: "1002", FinancialRoleList: []int32{account_service.FinancialBizRoleFinalCustomer}},
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountExistsDistributionRelation)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "该账号1002存在代销关系，不支持直销报价。如需直销报价，请在伙伴管理平台解除代销关系。若有疑问，可联系生态运营/ 渠道运营同学")
		})
	})

	t.Run("生态客户邀约类型匹配时允许报价", func(t *testing.T) {
		mockey.PatchConvey("生态邀约类型匹配", t, func() {
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoAgent,
				TradeType:       multienv.CustomerTypeEcoAgent,
				CustomerDetail:  "1001",
				JointPrintOrder: `{"Support":false}`,
			}
			quoteCtx.External.CustomerGrantTypeMap = map[string]*partner_inner.CustomerGrantTypeInfo{
				"1001": {CustomerPassportID: "1001", GrantType: 101},
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})

	t.Run("生态客户未查询到邀约类型时禁止报价", func(t *testing.T) {
		mockey.PatchConvey("生态邀约类型缺失", t, func() {
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoAgent,
				TradeType:       multienv.CustomerTypeEcoAgent,
				CustomerDetail:  "1001",
				JointPrintOrder: `{"Support":false}`,
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNTradeTypeCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "未查询到配价账号1001的客户邀约类型")
		})
	})

	t.Run("生态客户邀约类型不匹配时禁止报价", func(t *testing.T) {
		mockey.PatchConvey("生态邀约类型不匹配", t, func() {
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoAgent,
				TradeType:       multienv.CustomerTypeEcoAgent,
				CustomerDetail:  "1001",
				JointPrintOrder: `{"Support":false}`,
			}
			quoteCtx.External.CustomerGrantTypeMap = map[string]*partner_inner.CustomerGrantTypeInfo{
				"1001": {CustomerPassportID: "1001", GrantType: 104},
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPartnerInviteTypeMismatch)
			convey.So(result.ErrorMsg, convey.ShouldContainSubstring, "该账号1001的业务类型为")
		})
	})

	t.Run("联合打单支持时跳过生态客户邀约类型校验", func(t *testing.T) {
		mockey.PatchConvey("联合打单支持", t, func() {
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoAgent,
				TradeType:       multienv.CustomerTypeEcoAgent,
				CustomerDetail:  "1001",
				JointPrintOrder: `{"Support":true}`,
			}

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})
}

func TestCustomerQuoteQualificationRuleNeeds(t *testing.T) {
	rule := &CustomerQuoteQualificationRule{}

	t.Run("返回报价资格校验依赖键", func(t *testing.T) {
		mockey.PatchConvey("返回依赖键", t, func() {
			convey.So(rule.Needs(), convey.ShouldResemble, []quote_context.QuoteContextKey{
				quote_context.QuoteContextKeyQuote,
				quote_context.QuoteContextKeyAccountFinancialRole,
				quote_context.QuoteContextKeyCustomerGrantType,
			})
		})
	})
}

func TestCustomerDetailRuleCheckBP(t *testing.T) {
	rule := &CustomerDetailRule{}

	t.Run("特殊报价缺少客户账号时返回必填错误", func(t *testing.T) {
		mockey.PatchConvey("特殊报价客户账号必填", t, func() {
			quote := &model.Quote{DistributionBizTypeCode: multienv.DistributionBizTypeCodeCustom}
			mockey.Mock(multienv.GetContractTypeOfficialWebAuto).Return("official").Build()

			result, err := rule.checkBP(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPSpecialCustomerAccountRequired)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "Partner Special Discount quotation requires end customer console user ID linked to Distributor Console User Layer. Please check your selected quotation model and End Customer Console User ID, or guide partners to invite and register an end customer console user ID account.")
		})
	})

	t.Run("特殊报价客户账号不是最终客户时返回最终客户错误", func(t *testing.T) {
		mockey.PatchConvey("特殊报价最终客户校验", t, func() {
			quote := &model.Quote{CustomerDetail: "123", DistributionBizTypeCode: multienv.DistributionBizTypeCodeCustom}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock(account_service.CheckFinalCustomer).Return(false, nil, nil).Build()

			result, err := rule.checkBP(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPSpecialCustomerNotFinalCustomer)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "Under the Partner Special Discount quotation, the quoted end customer console user ID 123 must belong to the customer associated with the opportunity. Navigate to the opportunity-bound account page to Console User or switch to another existing account under this customer.")
		})
	})

	t.Run("客户账号来源不是官网注册时返回来源限制", func(t *testing.T) {
		mockey.PatchConvey("客户账号来源非法", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 123, CreateSource: account_info.CreateSourceSales, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "123"}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.checkBP(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPAccountCreateSourceInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "该客户账号123来源不支持绑定报价单，请使用官网注册账号")
		})
	})

	t.Run("内部报价客户账号多选时返回数量限制", func(t *testing.T) {
		mockey.PatchConvey("内部报价多账号", t, func() {
			quote := &model.Quote{CustomerDetail: "123,456"}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(true).Build()

			result, err := rule.checkBP(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPInnerMultiAccountUnsupported)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "内部客户账号不允许多选。请删除多余账号后按需分批进行报价。当前账号数量2，账号列表123,456")
		})
	})

	t.Run("特殊报价最终客户校验失败时返回统一提示", func(t *testing.T) {
		mockey.PatchConvey("特殊报价最终客户校验失败", t, func() {
			quote := &model.Quote{CustomerDetail: "123", DistributionBizTypeCode: multienv.DistributionBizTypeCodeCustom}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock(account_service.CheckFinalCustomer).Return(false, nil, stderrors.New("rpc failed")).Build()

			result, err := rule.checkBP(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNFinalCustomerCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "最终客户校验失败，请检查客户 ID 或稍后重试。客户 ID 123")
		})
	})

	t.Run("官网注册企业账号时通过", func(t *testing.T) {
		mockey.PatchConvey("账号校验通过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 123, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "123"}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.checkBP(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})

	t.Run("特殊报价多账号时返回数量限制", func(t *testing.T) {
		mockey.PatchConvey("特殊报价多账号", t, func() {
			quote := &model.Quote{CustomerDetail: "123,456", DistributionBizTypeCode: multienv.DistributionBizTypeCodeCustom}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.checkBP(context.Background(), &quote_context.QuoteContext{}, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPSpecialAccountCountInvalid)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "Partner Special Discount quotation does not support multi-select accounts. Delete redundant accounts and quote batch by batch. Current account count is 2, account list is 123,456.")
		})
	})

	t.Run("账号未完成企业认证时返回认证错误", func(t *testing.T) {
		mockey.PatchConvey("企业认证不完整", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 123, CreateSource: account_info.CreateSourceOfficialWebsite, IsVerified: false, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "123"}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.checkBP(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNBPAccountNotEnterpriseVerified)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "Partner Special Discount quotation is not allowed because enterprise authentication for Account 123 is incomplete. Please advise the customer to complete authentication before retrying.")
		})
	})

	t.Run("账号已注销时返回注销错误", func(t *testing.T) {
		mockey.PatchConvey("账号已注销", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.External.AccountAndVerifyInfos = []*account_info.AccountAndVerifyInfo{
				{AccountID: 123, CreateSource: account_info.CreateSourceOfficialWebsite, Status: account_info.AccountStatusDeleted, IsVerified: true, IdentityType: verify_info.IdentityTypeEnterprise},
			}
			quote := &model.Quote{CustomerDetail: "123"}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.checkBP(context.Background(), quoteCtx, quote, &CheckResult{Pass: true})

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountClosed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "当前账号123已注销，不支持报价")
		})
	})
}

func TestRelatedAccountIDsRuleCheck(t *testing.T) {
	rule := &RelatedAccountIDsRule{}

	t.Run("缺少报价上下文时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountIDCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "quote context is missing")
		})
	})

	t.Run("BytePlus 环境时跳过账号关系校验", func(t *testing.T) {
		mockey.PatchConvey("BytePlus 跳过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{TradeTypeCode: multienv.CustomerTypeCodeDirectSell}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})

	t.Run("直销未填写配价账号时通过", func(t *testing.T) {
		mockey.PatchConvey("直销账号为空", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{TradeTypeCode: multienv.CustomerTypeCodeDirectSell}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})

	t.Run("直销账号三字段不一致时返回账号关系错误", func(t *testing.T) {
		mockey.PatchConvey("直销账号不一致", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeDirectSell,
				ContractAccount: "c1",
				CustomerDetail:  "c2",
				CustomerAccount: "c1",
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNAccountRelationInconsistent)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "签约账号、配价账号、最终客户账号需保持一致，请检查账号填写。签约账号c1、配价账号c2、最终客户账号c1")
		})
	})

	t.Run("生态分销账号缺少伙伴授权时返回无授权错误", func(t *testing.T) {
		mockey.PatchConvey("生态分销账号无授权", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoDist,
				ContractAccount: "p1",
				CustomerDetail:  "p1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{PartnerVolcanoMap: map[string]bool{"p1": true}}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPartnerAccountNoGrant)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "伙伴账号p1无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T")
		})
	})

	t.Run("生态分销授权列表不包含配价账号时返回无授权错误", func(t *testing.T) {
		mockey.PatchConvey("生态分销伙伴授权账号缺失", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoDist,
				ContractAccount: "p1",
				CustomerDetail:  "p1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{PartnerVolcanoMap: map[string]bool{"p1": true}}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{
				multienv.CustomerTypeCodeEcoDist: {
					PartnerMap: map[string]*crm_service.PartnerInfo{"p2": {}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPartnerAccountNoGrant)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "伙伴账号p1无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T")
		})
	})

	t.Run("不支持的客户类型返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("不支持的客户类型", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{TradeType: "未知客户", TradeTypeCode: 999}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNTradeTypeAccountCheckUnsupported)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "当前客户类型未知客户(999)不支持账号校验，请检查客户类型")
		})
	})

	t.Run("直销客户账号不属于商机客户时返回错误", func(t *testing.T) {
		mockey.PatchConvey("直销客户账号已换绑", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeDirectSell,
				ContractAccount: "c1,c2",
				CustomerDetail:  "c1,c2",
				CustomerAccount: "c1,c2",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap: map[string]bool{"c1": true},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNCustomerAccountNotOpportunityCustomer)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "客户账号c2已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。")
		})
	})

	t.Run("生态分销填写最终客户账号时返回清空提示", func(t *testing.T) {
		mockey.PatchConvey("生态分销最终客户账号需清空", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeType:       "生态-分销",
				TradeTypeCode:   multienv.CustomerTypeCodeEcoDist,
				ContractAccount: "p1",
				CustomerDetail:  "p1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				PartnerVolcanoMap: map[string]bool{"p1": true},
			}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{
				multienv.CustomerTypeCodeEcoDist: {
					PartnerMap: map[string]*crm_service.PartnerInfo{"p1": {}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNCustomerAccountShouldBeEmpty)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "当前客户类型不允许填写最终客户账号，请清空后重试。客户类型生态-分销(4)、最终客户账号c1")
		})
	})

	t.Run("生态分销配价账号不是商机伙伴时返回错误", func(t *testing.T) {
		mockey.PatchConvey("生态分销伙伴账号换绑", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoDist,
				ContractAccount: "p1",
				CustomerDetail:  "p1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				PartnerVolcanoMap: map[string]bool{},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPriceAccountNotOpportunityPartner)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "配价账号p1已换绑至其他伙伴客户，当前商机关联的伙伴无法使用该账号报价，你可前往商机页面更改商机关联伙伴后重试或者新建商机关联新的伙伴后发起报价。")
		})
	})

	t.Run("生态代销最终客户账号不是商机客户时返回错误", func(t *testing.T) {
		mockey.PatchConvey("生态代销最终客户换绑", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSalesByProxy,
				ContractAccount: "p1",
				CustomerDetail:  "p1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap: map[string]bool{},
				PartnerVolcanoMap:  map[string]bool{"p1": true},
			}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{
				multienv.CustomerTypeCodeEcoSalesByProxy: {
					PartnerMap: map[string]*crm_service.PartnerInfo{"p1": {}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNFinalAccountNotOpportunityCustomer)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "最终客户账号c1已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。")
		})
	})

	t.Run("集成解决方案签约账号不是伙伴 cuid 时返回错误", func(t *testing.T) {
		mockey.PatchConvey("集成解决方案伙伴 cuid 校验", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSolution,
				ContractAccount: "pc1",
				CustomerDetail:  "pc1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				PartnerCustomerVolcanoMap: map[string]bool{},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNOpportunityPartnerAccountIDCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "invalid r.CustomerDetail : pc1 is not opportunity partner cuid accountID")
		})
	})

	t.Run("集成解决方案签约账号和配价账号不一致时返回错误", func(t *testing.T) {
		mockey.PatchConvey("集成解决方案账号不一致", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSolution,
				ContractAccount: "pc1",
				CustomerDetail:  "pc2",
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNContractPriceAccountInconsistent)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "签约账号和配价账号需保持一致，请检查账号填写。签约账号pc1、配价账号pc2")
		})
	})

	t.Run("集成解决方案最终客户账号不是商机客户时返回错误", func(t *testing.T) {
		mockey.PatchConvey("集成解决方案最终客户换绑", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSolution,
				ContractAccount: "pc1",
				CustomerDetail:  "pc1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap:        map[string]bool{},
				PartnerCustomerVolcanoMap: map[string]bool{"pc1": true},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNFinalAccountNotOpportunityCustomer)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "最终客户账号c1已换绑至其他客户，当前客户无法使用该账号报价，你可前往账号新绑定的客户下满足条件的商机页面发起报价。")
		})
	})

	t.Run("生态代售签约账号不是商机伙伴时返回错误", func(t *testing.T) {
		mockey.PatchConvey("生态代售伙伴账号校验", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSell,
				ContractAccount: "p1",
				CustomerDetail:  "c1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap: map[string]bool{"c1": true},
				PartnerVolcanoMap:  map[string]bool{},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNContractAccountNotOpportunityPartner)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "签约账号p1已换绑至其他伙伴客户，当前商机关联的伙伴无法使用该账号报价，你可前往商机页面更改商机关联伙伴后重试或者新建商机关联新的伙伴后发起报价。")
		})
	})

	t.Run("生态代售配价账号和最终客户账号不一致时返回错误", func(t *testing.T) {
		mockey.PatchConvey("生态代售账号不一致", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSell,
				ContractAccount: "p1",
				CustomerDetail:  "c1",
				CustomerAccount: "c2",
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPriceFinalCustomerAccountInconsistent)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "配价账号和最终客户账号需保持一致，请检查账号填写。配价账号c1、最终客户账号c2")
		})
	})

	t.Run("生态代售伙伴账号缺少授权时返回错误", func(t *testing.T) {
		mockey.PatchConvey("生态代售伙伴账号无授权", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSell,
				ContractAccount: "p1",
				CustomerDetail:  "c1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap: map[string]bool{"c1": true},
				PartnerVolcanoMap:  map[string]bool{"p1": true},
			}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNPartnerAccountNoGrant)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "伙伴账号p1无授权类型，请确保伙伴已完成伙伴协议签署并归档，如有疑问可进线伙伴值班号咨询：https://applink.larkoffice.com/T96VjZsKul9T")
		})
	})

	t.Run("生态代售账号关系合法时通过", func(t *testing.T) {
		mockey.PatchConvey("生态代售账号校验通过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				TradeTypeCode:   multienv.CustomerTypeCodeEcoSell,
				ContractAccount: "p1",
				CustomerDetail:  "c1",
				CustomerAccount: "c1",
			}
			quoteCtx.External.OppInfo = &crm_service.OpportunitySimpleInfo{
				CustomerVolcanoMap: map[string]bool{"c1": true},
				PartnerVolcanoMap:  map[string]bool{"p1": true},
			}
			quoteCtx.External.TradeTypeGrantMap = map[int]*crm_service.PartnerGrant{
				multienv.CustomerTypeCodeEcoSell: {
					PartnerMap: map[string]*crm_service.PartnerInfo{"p1": {}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).IsPrmQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})
}

func TestShouldSkipBlockRule(t *testing.T) {
	t.Run("命中新引擎规则键时返回true", func(t *testing.T) {
		mockey.PatchConvey("命中新引擎规则键时返回true", t, func() {
			skipRuleMap := map[string]bool{
				"BizDataRuleCustomerDetail": true,
			}

			convey.So(ShouldSkipBlockRule(skipRuleMap, "BizDataRuleCustomerDetail"), convey.ShouldBeTrue)
		})
	})

	t.Run("未配置规则键时返回false", func(t *testing.T) {
		mockey.PatchConvey("未配置规则键时返回false", t, func() {
			convey.So(ShouldSkipBlockRule(map[string]bool{}, "BizDataRuleOrderType"), convey.ShouldBeFalse)
		})
	})
}

func TestOrderTypeRuleCheck(t *testing.T) {
	rule := &OrderTypeRule{}

	t.Run("缺少报价上下文时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNOrderTypeCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "quote context is missing")
		})
	})

	t.Run("生态分销非纸质签约时返回限制", func(t *testing.T) {
		mockey.PatchConvey("生态分销签约方式受限", t, func() {
			mockey.Mock(multienv.GetContractTypeOfficialWebAuto).Return("official").Build()
			mockey.Mock(multienv.GetContractTypePaperContract).Return("paper").Build()
			mockey.Mock(multienv.GetContractTypeMapping).Return(map[string]interface{}{
				"official": struct{}{},
				"paper":    struct{}{},
			}).Build()
			mockey.Mock(multienv.GetContractTypeCodeToTypeMapping).Return(map[int]string{
				multienv.ContractTypeCodeOfficialWebAuto: "official",
				multienv.ContractTypeCodePaperContract:   "paper",
			}).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				OrderType:     "official",
				OrderTypeCode: multienv.ContractTypeCodeOfficialWebAuto,
				TradeTypeCode: multienv.CustomerTypeCodeEcoDist,
			}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()
			mockey.Mock((*model.Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{}, nil).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNOrderTypeCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "客户类型为生态-分销，签约方式只能选【产品和服务协议（合同纸质签约）】")
		})
	})

	t.Run("纸质签约且编码合法时通过", func(t *testing.T) {
		mockey.PatchConvey("纸质签约通过", t, func() {
			mockey.Mock(multienv.GetContractTypeOfficialWebAuto).Return("official").Build()
			mockey.Mock(multienv.GetContractTypePaperContract).Return("paper").Build()
			mockey.Mock(multienv.GetContractTypeMapping).Return(map[string]interface{}{
				"official": struct{}{},
				"paper":    struct{}{},
			}).Build()
			mockey.Mock(multienv.GetContractTypeCodeToTypeMapping).Return(map[int]string{
				multienv.ContractTypeCodeOfficialWebAuto: "official",
				multienv.ContractTypeCodePaperContract:   "paper",
			}).Build()
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{
				OrderType:     "paper",
				OrderTypeCode: multienv.ContractTypeCodePaperContract,
			}
			mockey.Mock((*model.Quote).IsInnerQuote).Return(false).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.RuleKey, convey.ShouldEqual, rule.Key())
			convey.So(result.RuleDesc, convey.ShouldEqual, rule.Desc())
			convey.So(result.BlockLevel, convey.ShouldEqual, rule.BlockLevel())
		})
	})
}

func TestUnStandardDeliveryItemCostRuleCheck(t *testing.T) {
	rule := &UnStandardDeliveryItemCostRule{}

	t.Run("非标交付项成本不合法时按报价项聚合返回明细", func(t *testing.T) {
		mockey.PatchConvey("非标交付项成本不合法", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{}
			quoteCtx.Persisted.DeliveryItems = []*model.QuoteItem{{
				BaseDB:          framework.BaseDB{Id: 1001},
				ItemBelong:      5001,
				ItemScene:       constants.ItemSceneDeliveryItem,
				AutoGenerate:    constants.ItemAutoGenerateFalse,
				StandardProduct: multienv.TradeProductStandardNo,
			}}
			quoteCtx.Persisted.QuoteItems = []*model.QuoteItem{{
				BaseDB:          framework.BaseDB{Id: 2001},
				ItemBelong:      5002,
				ItemScene:       constants.ItemSceneQuoteItem,
				AutoGenerate:    constants.ItemAutoGenerateFalse,
				StandardProduct: multienv.TradeProductStandardNo,
			}}
			quoteCtx.Persisted.ItemCalMap = map[int64]*model.QuoteItemCalculate{
				1001: {
					UnitCost: (&model.UnitCostObj{
						TotalCostFunction: constants.TotalCostFunctionFixedPrice,
						TotalCost:         "10",
					}).String(),
					FactoryPrice: (&model.FactoryPriceObj{
						ExFactoryPriceFunction: constants.TotalCostFunctionFixedPrice,
						ExFactoryPrice:         "9",
					}).String(),
				},
			}
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, args ...interface{}) string {
				return fmt.Sprintf(format, args...)
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNUnStandardDeliveryItemCostCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "手动添加非标品交付项成本&出厂价校验失败，报价项ID：[5001]")
			convey.So(result.Detail, convey.ShouldResemble, map[int64][]int64{5001: {1001}})
		})
	})

	t.Run("缺少报价上下文时返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("缺少报价上下文", t, func() {
			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNUnStandardDeliveryItemCostCheckFailed)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "quote context is missing")
		})
	})

	t.Run("合法的手动非标交付项时通过", func(t *testing.T) {
		mockey.PatchConvey("非标交付项校验通过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{}
			quoteCtx.Persisted.DeliveryItems = []*model.QuoteItem{
				{
					BaseDB:          framework.BaseDB{Id: 1001},
					ItemBelong:      5001,
					ItemScene:       constants.ItemSceneDeliveryItem,
					AutoGenerate:    constants.ItemAutoGenerateFalse,
					StandardProduct: multienv.TradeProductStandardNo,
				},
				{
					BaseDB:          framework.BaseDB{Id: 1002},
					ItemBelong:      5002,
					ItemScene:       constants.ItemSceneQuoteItem,
					AutoGenerate:    constants.ItemAutoGenerateFalse,
					StandardProduct: multienv.TradeProductStandardNo,
				},
			}
			quoteCtx.Persisted.ItemCalMap = map[int64]*model.QuoteItemCalculate{
				1001: {
					UnitCost: (&model.UnitCostObj{
						TotalCostFunction: constants.TotalCostFunctionFixedPrice,
						TotalCost:         "10",
					}).String(),
					FactoryPrice: (&model.FactoryPriceObj{
						ExFactoryPriceFunction: constants.TotalCostFunctionFixedPrice,
						ExFactoryPrice:         "10",
					}).String(),
				},
			}
			mockey.MockUnsafe(config.GetSwitchIsOpenByName).Return(true).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.Detail, convey.ShouldBeNil)
		})
	})

	t.Run("配置清单报价单时跳过校验", func(t *testing.T) {
		mockey.PatchConvey("配置清单跳过", t, func() {
			quoteCtx := &quote_context.QuoteContext{}
			quoteCtx.Persisted.Quote = &model.Quote{}
			mockey.Mock((*model.Quote).IsConfigList).Return(true).Build()
			mockey.MockUnsafe(config.GetSwitchIsOpenByName).To(func(ctx context.Context, name string) bool {
				t.Fatalf("unexpected switch check when quote should skip")
				return false
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
		})
	})
}

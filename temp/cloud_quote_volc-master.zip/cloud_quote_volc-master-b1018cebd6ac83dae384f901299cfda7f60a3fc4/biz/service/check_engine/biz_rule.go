package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
)

type QuoteBizRule interface {
	Key() string
	Desc() string
	Needs() []quote_context.QuoteContextKey
	Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error)
	BlockLevel() string
}

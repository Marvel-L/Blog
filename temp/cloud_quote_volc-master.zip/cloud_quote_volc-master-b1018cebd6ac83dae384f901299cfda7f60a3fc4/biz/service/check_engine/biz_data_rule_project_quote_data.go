package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ProjectQuoteDataRule —— 项目制报价单字段校验。
//
// 与原 QuoteData.ProjectQuoteDataCheck 保持错误码与文案完全一致：
//   - 项目制报价单 StatementOfWork 必填；
//   - 项目制报价单需 ProjectCode / ProjectName 同时非空。
//
// 关于 CheckProjectCode：原入参字段在 QuoteData 上，model.Quote 不持久化该字段。
// 进入 Rule 阶段的入口（quote_data_quote_gen.go:35）默认 CheckProjectCode=true，
// 与原方法在主链路下的语义等价；Rule 阶段一律按 true 处理。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type ProjectQuoteDataRule struct{}

func (r *ProjectQuoteDataRule) Key() string { return "BizDataRuleProjectQuoteData" }
func (r *ProjectQuoteDataRule) Desc() string {
	return "项目制报价单字段校验：StatementOfWork 必填，ProjectCode / ProjectName 必填"
}
func (r *ProjectQuoteDataRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *ProjectQuoteDataRule) BlockLevel() string { return BlockLevelError }

func (r *ProjectQuoteDataRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNProjectDataCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.QuoteType != multienv.QuoteTypeProjectBased {
		return result, nil
	}
	if quote.StatementOfWork == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNProjectDataCheckFailed
		result.ErrorMsg = "项目制报价单立项说明不可为空"
		return result, nil
	}
	if quote.ProjectCode == "" || quote.ProjectName == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNProjectDataCheckFailed
		result.ErrorMsg = "项目制报价项目信息不可为空"
		return result, nil
	}
	return result, nil
}

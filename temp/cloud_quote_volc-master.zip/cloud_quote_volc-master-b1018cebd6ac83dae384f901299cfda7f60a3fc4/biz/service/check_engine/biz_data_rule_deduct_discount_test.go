package check_engine

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// buildDeductDiscountQuoteCtx 构造一个含 1 个本单按量报价项 + 1 个抵扣报价项的上下文。
// 抵扣项走「本单按量折扣」参考路径（避开 SP 缓存与合同价 RPC），
// deductUnitPrice / normalUnitPrice 分别为抵扣项与本单按量项折扣，用于覆盖「等于」边界。
func buildDeductDiscountQuoteCtx(deductUnitPrice, normalUnitPrice decimal.Decimal) *quote_context.QuoteContext {
	normalItem := &model.QuoteItem{ItemBusinessRole: constants.QuoteItemBusinessRoleNormal}
	normalItem.Id = 1
	deductItem := &model.QuoteItem{ItemBusinessRole: constants.QuoteItemBusinessRoleDeduct}
	deductItem.Id = 2

	normalCtx := &item_context.ItemContext{
		ItemID: 1,
		Discount: &config_option_service.Discount{
			PricingFunction: constants.DiscountFunctionSimpleDiscount,
			UnitPrice:       normalUnitPrice,
		},
	}
	deductCtx := &item_context.ItemContext{
		ItemID:        2,
		RelatedItemID: 1,
		Discount: &config_option_service.Discount{
			PricingFunction: constants.DiscountFunctionSimpleDiscount,
			UnitPrice:       deductUnitPrice,
		},
	}

	return &quote_context.QuoteContext{
		Persisted: quote_context.QuoteContextPersisted{
			Quote:      &model.Quote{},
			QuoteItems: []*model.QuoteItem{normalItem, deductItem},
			ItemContextMap: map[int64]*item_context.ItemContext{
				1: normalCtx,
				2: deductCtx,
			},
		},
	}
}

func TestDeductDiscountRuleCheck_EqualBoundary(t *testing.T) {
	rule := &DeductDiscountRule{}

	// 通用 mock：两个 ItemContext 命中同一 RepeatCheckKey，抵扣项走本单按量参考路径；
	// 非精确计费项以跳过 SP 缓存分支。
	mockAll := func() {
		mockey.Mock((*item_context.ItemContext).GetRepeatCheckKeyWithoutSpDeduct).Return([]string{"repeat_key_1"}).Build()
		mockey.Mock((*item_context.ItemContext).IsExactChargeItem).Return(false).Build()
		// i18nfmt 依赖 starling 客户端，单测环境未初始化，mock 掉避免拉取远端翻译。
		mockey.Mock(i18nfmt.Sprintf).Return("抵扣报价项折扣异常").Build()
	}

	t.Run("抵扣系数等于本单按量折扣：放开等于，判定正常放行", func(t *testing.T) {
		mockey.PatchConvey("等于边界", t, func() {
			mockAll()

			quoteCtx := buildDeductDiscountQuoteCtx(decimal.NewFromFloat(0.8), decimal.NewFromFloat(0.8))
			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.ErrorCodeN(0))
		})
	})

	t.Run("抵扣系数大于本单按量折扣：判定异常并拦截", func(t *testing.T) {
		mockey.PatchConvey("大于即异常", t, func() {
			mockAll()

			quoteCtx := buildDeductDiscountQuoteCtx(decimal.NewFromFloat(0.9), decimal.NewFromFloat(0.8))
			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNDeductDiscountIllegal)
			convey.So(result.Detail, convey.ShouldNotBeNil)
		})
	})
}

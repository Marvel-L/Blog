package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// GuaranteePercentageRule 保底比例校验。
//
// 来源：原 GuaranteePercentageChecker。
// 与原 checker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - `ItemContext.ValidateCalculationFactor` 内部走 Redis 缓存读，属于纯校验类调用，
//     遵循 §11 校验类调用允许在 Rule 内直接执行的约定，不再绕一层 loader。
//
// 注意：原 checker 用 `quoteBizData.AllQuoteItems`（仅含报价项）构造 itemContextMap；
// 此处复用 `Persisted.ItemContextMap`（包含报价项 + 交付项 + 失效项），需按
// `Persisted.QuoteItems` 的 ID 过滤，对齐原行为。
type GuaranteePercentageRule struct{}

func (r *GuaranteePercentageRule) Key() string {
	return "BizDataRuleGuaranteePercentage"
}

func (r *GuaranteePercentageRule) Desc() string {
	return "保底比例校验：" +
		"1) 多账号下保底比例必须可合并（不能存在部分账号配置/部分账号未配置）；" +
		"2) 多账号下保底比例必须一致（固定比例相同 / 区间存在交集）；" +
		"3) 报价项不支持保底比例时不能填写；" +
		"4) 报价项支持保底比例但未填写时拦截；" +
		"5) 报价项保底比例值必须落在可用区间内。"
}

func (r *GuaranteePercentageRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *GuaranteePercentageRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.IsConfigList() {
		return result, nil
	}

	itemContextMap := quoteCtx.Persisted.ItemContextMap
	if len(itemContextMap) == 0 || len(quoteCtx.Persisted.QuoteItems) == 0 {
		return result, nil
	}

	var notSupportFactorQuoteItemIDs []int64
	var shotOfFactorQuoteItemIDs []int64
	var valueNotRightQuoteItemIDs []int64
	for _, quoteItem := range quoteCtx.Persisted.QuoteItems {
		itemContext, ok := itemContextMap[quoteItem.Id]
		if !ok || itemContext == nil {
			continue
		}
		guaranteedPercentageMergeType, guaranteeErr := itemContext.ValidateCalculationFactor(ctx, multienv.FactorTypeGuaranteedPercentage, true)
		if guaranteeErr != nil {
			logs.CtxInfo(ctx, "[GuaranteePercentageRule] ValidateCalculationFactor error: %s", guaranteeErr.Error())
		}
		if guaranteedPercentageMergeType == multienv.FactorInvalidTypeMultiAccountShortOfFactor {
			result.Pass = false
			result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单中多个帐号中，存在部分帐号有保底比例，部分帐号无保底比例，因此整单不支持配置保底比例，这样会对需要保底的帐号产生「资损」影响，因此需先将无保底比例的帐号配置上保底比例：1）均为固定比例，固定比例必须相同；2）均为保底区间，保底区间需存在交集。若不修改，建议多个帐号ID分开报价！")
			return result, nil
		}
		if guaranteedPercentageMergeType == multienv.FactorInvalidTypeMultiAccountFactorNotSame {
			result.Pass = false
			result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单中多个帐号均存在保底白名单，但保底比例不一致，会导致无法送审，若需要送审，需先修改保底比例：1）均为固定比例，固定比例必须相同；2）均为保底区间，保底区间需存在交集。若不修改，建议多个帐号ID分开报价！")
			return result, nil
		}
		if guaranteedPercentageMergeType == multienv.FactorInvalidTypeNotSupportFactor {
			notSupportFactorQuoteItemIDs = append(notSupportFactorQuoteItemIDs, quoteItem.Id)
		}
		if guaranteedPercentageMergeType == multienv.FactorInvalidTypeItemShortOfFactor {
			shotOfFactorQuoteItemIDs = append(shotOfFactorQuoteItemIDs, quoteItem.Id)
		}
		if guaranteedPercentageMergeType == multienv.FactorInvalidTypeFactorValueNotRight {
			valueNotRightQuoteItemIDs = append(valueNotRightQuoteItemIDs, quoteItem.Id)
		}
	}
	if len(notSupportFactorQuoteItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单存在报价项不支持填写保底比例，报价项为%s", util.Int64Join(notSupportFactorQuoteItemIDs, ","))
		return result, nil
	}
	if len(shotOfFactorQuoteItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单存在报价项未配置保底比例，报价项为%s", util.Int64Join(shotOfFactorQuoteItemIDs, ","))
		return result, nil
	}
	if len(valueNotRightQuoteItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNGuaranteedPercentageCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单存在报价项保底比例不正确，报价项为%s", util.Int64Join(valueNotRightQuoteItemIDs, ","))
		return result, nil
	}
	return result, nil
}

func (r *GuaranteePercentageRule) BlockLevel() string {
	return BlockLevelError
}

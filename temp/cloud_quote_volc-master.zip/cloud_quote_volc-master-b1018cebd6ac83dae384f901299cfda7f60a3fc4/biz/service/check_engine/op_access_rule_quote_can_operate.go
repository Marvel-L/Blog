package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type QuoteCanOperateRule struct{}

func (r *QuoteCanOperateRule) Key() string {
	return "OpAccessRuleQuoteCanOperate"
}

func (r *QuoteCanOperateRule) Desc() string {
	return "配置清单已上架，不可操作；报价单审批中修改，不限制状态允许修改；报价单审批之前的状态（草稿、审批驳回），才允许修改"
}

func (r *QuoteCanOperateRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
	}
}

func (r *QuoteCanOperateRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteNotSupportToOperate
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	var quoteDB = quoteCtx.Persisted.Quote
	if quoteDB.IsConfigList() {
		result.Pass = false
		result.ErrorCode = 0
		result.ErrorMsg = "配置清单不再允许送审"
		return result, nil
	}
	if quoteDB.IsNewConfigList(ctx) {
		if !quoteDB.QuoteStatus.IsBeforeConfigListPutOn() {
			result.Pass = false
			result.ErrorCode = errors.CodeNQuoteNotSupportToOperate
			result.ErrorMsg = "当前报价单已经提交，不可修改"
			return result, nil
		}
		return result, nil
	}
	// 审批中修改，不限制状态允许变更
	if quoteDB.IsInModifyProcess() {
		return result, nil
	}
	// 审批之前的状态（草稿、审批驳回），才允许变更
	if !quoteDB.QuoteStatus.IsBeforeApproveStatus() {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteNotSupportToOperate
		result.ErrorMsg = "当前报价单已经提交，不可修改"
		return result, nil
	}
	return result, nil
}

func (r *QuoteCanOperateRule) BlockLevel() string {
	return BlockLevelError
}

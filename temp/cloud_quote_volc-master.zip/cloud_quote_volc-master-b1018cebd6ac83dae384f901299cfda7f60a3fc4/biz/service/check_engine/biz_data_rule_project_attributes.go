package check_engine

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ProjectAttributesRule —— 项目属性枚举校验。
//
// 与原 QuoteData.ProjectAttributesCheck 保持错误码与文案完全一致：
// ProjectAttributes 字段每个值必须命中枚举字典 EnumKeyProjectAttribute。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type ProjectAttributesRule struct{}

func (r *ProjectAttributesRule) Key() string { return "BizDataRuleProjectAttributes" }
func (r *ProjectAttributesRule) Desc() string {
	return "项目属性校验：报价单 ProjectAttributes 字段每个值必须命中枚举字典 EnumKeyProjectAttribute"
}
func (r *ProjectAttributesRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *ProjectAttributesRule) BlockLevel() string { return BlockLevelError }

func (r *ProjectAttributesRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNProjectAttributesCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	projectAttributeMap := config.GetEnumConfig(ctx, constants.EnumKeyProjectAttribute)
	for _, projectAttribute := range strings.Split(quote.ProjectAttributes, ",") {
		if _, ok := projectAttributeMap[projectAttribute]; !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNProjectAttributesCheckFailed
			result.ErrorMsg = "项目属性错误"
			return result, nil
		}
	}
	return result, nil
}

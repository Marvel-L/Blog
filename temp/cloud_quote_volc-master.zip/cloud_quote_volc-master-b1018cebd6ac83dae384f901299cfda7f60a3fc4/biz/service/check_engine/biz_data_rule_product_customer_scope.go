package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ProductCustomerScopeRule 报价项商品售卖客户范围校验。
//
// 与原 ProductCustomerScopeChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / External.ProductInfoMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 不再调用 quote_service.GetCustomerScopeErrData（避免反向依赖），
//     直接基于预加载的 ProductInfoMap 复刻 customer scope 判定逻辑。
//
// 注意：原 checker 用 quoteBizData.AllQuoteItems（仅含报价项），此处对齐使用
// Persisted.QuoteItems。
type ProductCustomerScopeRule struct{}

func (r *ProductCustomerScopeRule) Key() string {
	return "BizDataRuleProductCustomerScope"
}

func (r *ProductCustomerScopeRule) Desc() string {
	return "报价项商品售卖客户范围校验：报价项关联商品的客户范围必须与报价单贸易类型对应的客户范围匹配。"
}

func (r *ProductCustomerScopeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyProductInfo,
	}
}

func (r *ProductCustomerScopeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCustomerScopeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems
	productInfoMap := quoteCtx.External.ProductInfoMap
	quoteCustomerScope := quote.TradeType.GetCustomerScope()

	// 1、按 tradeProduct 聚合报价项 ID
	productItemIDs := map[string][]int64{}
	for _, quoteItem := range quoteItems {
		productItemIDs[quoteItem.TradeProduct] = append(productItemIDs[quoteItem.TradeProduct], quoteItem.Id)
	}

	// 2、按商品客户范围筛选超范围商品
	var errItemIDs []int64
	for tradeProduct, itemIDs := range productItemIDs {
		productInfo, ok := productInfoMap[tradeProduct]
		if !ok || productInfo == nil {
			continue
		}
		productCustomerScope := productInfo.CatalogueCodeMap[multienv.CustomerScopeKey]
		if !product_config_parser.CustomerScopeMatch(quoteCustomerScope, productCustomerScope) {
			errItemIDs = append(errItemIDs, itemIDs...)
		}
	}

	if len(errItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNCustomerScopeCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx,
			"存在报价项商品售卖客户范围与报价单不符，请修改后重新提交，报价项id :%v",
			errItemIDs,
		)
		result.Detail = errItemIDs
		return result, nil
	}
	return result, nil
}

func (r *ProductCustomerScopeRule) BlockLevel() string {
	return BlockLevelError
}

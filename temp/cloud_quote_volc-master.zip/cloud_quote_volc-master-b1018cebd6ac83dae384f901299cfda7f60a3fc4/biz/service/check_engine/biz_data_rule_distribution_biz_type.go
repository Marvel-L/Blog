package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// DistributionBizTypeRule —— 分销业务类型校验。
//
// 与原 QuoteData.DistributionBizTypeCheck 保持错误码与文案完全一致：
//   - 仅 BP 分销客户类型可填写分销业务类型；
//   - BP 分销客户类型必须填写分销业务类型，且必须命中合法枚举。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type DistributionBizTypeRule struct{}

func (r *DistributionBizTypeRule) Key() string { return "BizDataRuleDistributionBizType" }
func (r *DistributionBizTypeRule) Desc() string {
	return "分销业务类型校验：仅 BP 分销客户类型可填写分销业务类型，且必须为合法枚举"
}
func (r *DistributionBizTypeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *DistributionBizTypeRule) BlockLevel() string { return BlockLevelError }

func (r *DistributionBizTypeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributionBizTypeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.TradeTypeCode != multienv.CustomerTypeCodeBPDistributor {
		if quote.DistributionBizTypeCode != 0 {
			result.Pass = false
			result.ErrorCode = errors.CodeNDistributionBizTypeCheckFailed
			result.ErrorMsg = "DistributionBizTypeCode error"
			return result, nil
		}
		return result, nil
	}
	if quote.DistributionBizTypeCode == 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributionBizTypeCheckFailed
		result.ErrorMsg = "DistributionBizTypeCode missing"
		return result, nil
	}
	if _, exist := multienv.GetDistributionBizTypeCodeMapping()[quote.DistributionBizTypeCode]; !exist {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributionBizTypeCheckFailed
		result.ErrorMsg = "DistributionBizTypeCode error"
		return result, nil
	}
	return result, nil
}

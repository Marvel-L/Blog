package check_engine

import (
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// JointPrintOrderRule 联合打单信息校验。
//
// 来源：原 JointPrintOrderChecker + 老 QuoteData.JointPrintOrderCheck（字段必填/JSON 解析/Collaborator Lark）。
// 校验目标：
//  1. supportRebate 与 JointPrintOrder 是否填写一致：
//     - supportRebate=true 必须填 JointPrintOrder；
//     - supportRebate=false 不允许填 JointPrintOrder；
//  2. JointPrintOrder JSON 解析有效性 + 必填字段（OpportunitySrcKey / CustomerOwnerRole；
//     Support=true 时还要 PrintSceneDec / PrintSceneOppRole / PrintSceneJointRole / Collaborator）；
//  3. Support=true 时 Collaborator 通过 Lark RPC 解析为有效用户；Support=false 时 Collaborator 必须为空；
//  4. 报价单 JointPrintOrder 与商机 JointPrintInfo 一致（仅 supportRebate）；
//  5. 报价单 JointPrintOrder 中 PolicyName / PolicyLink 与 PRM 当前政策一致（仅 supportRebate）。
//
// 与原 checker 的差异：
//   - 原 checker 在校验后还会执行 `BuildSaveRebates + RebateItemDao.Save` 写副作用，
//     按 §9 已剥离到入口层（`op_check_dispatch.preSyncJointOrderRebatesIfSupport`），
//     Rule 仅做"是否一致"的纯校验；
//   - CRM `GetOpportunityInfo` 与 PRM `GetSpecialRebatePolicy` 均改造为 QuoteContext
//     的 External loader（`QuoteContextKeyOppInfo` / `QuoteContextKeySpecialRebatePolicy`），
//     Rule 内不再发起 RPC，仅读取 QuoteContext；
//   - Collaborator Lark 校验属于校验类 RPC（仅做账号有效性判定），按 §8.11 允许在 Rule 内调用。
type JointPrintOrderRule struct{}

func (r *JointPrintOrderRule) Key() string {
	return "BizDataRuleJointPrintOrder"
}

func (r *JointPrintOrderRule) Desc() string {
	return "联合打单信息校验：" +
		"1) supportRebate 与 JointPrintOrder 是否填写一致；" +
		"2) JointPrintOrder JSON 解析与必填字段校验；" +
		"3) Collaborator Lark 账号有效性校验；" +
		"4) 报价单 JointPrintOrder 与商机最新 JointPrintInfo 必须一致；" +
		"5) 报价单 JointPrintOrder 中政策名称/链接必须与 PRM 当前返佣政策一致。"
}

func (r *JointPrintOrderRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyOppInfo,
		quote_context.QuoteContextKeySpecialRebatePolicy,
	}
}

func (r *JointPrintOrderRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	supportRebate, err := quote.SupportRebate(ctx)
	if err != nil {
		return nil, err
	}
	// 1) supportRebate 与 JointPrintOrder 必填一致性
	if supportRebate && quote.JointPrintOrder == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "该报价单支持返佣，请传入字段JointPrintOrder")
		return result, nil
	}
	if !supportRebate && quote.JointPrintOrder != "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "该报价单不支持返佣，不允许传入字段JointPrintOrder")
		return result, nil
	}
	if quote.JointPrintOrder == "" {
		return result, nil
	}

	// 2) JSON 解析 + 必填字段
	jointPrintOrderInfo := &model.JointPrintOrder{}
	if err := json.Unmarshal([]byte(quote.JointPrintOrder), jointPrintOrderInfo); err != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder parse JointPrintOrder => %s,err= %s", quote.JointPrintOrder, err.Error())
		return result, nil
	}
	if jointPrintOrderInfo.OpportunitySrcKey == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段OpportunitySrcKey为空")
		return result, nil
	}
	if jointPrintOrderInfo.CustomerOwnerRole == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段CustomerOwnerRole为空")
		return result, nil
	}
	// 3) Support 分支必填字段 + Collaborator Lark 校验
	if jointPrintOrderInfo.Support {
		if jointPrintOrderInfo.PrintSceneDec == "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段PrintSceneDec为空")
			return result, nil
		}
		if jointPrintOrderInfo.PrintSceneOppRole == "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段PrintSceneOppRole为空")
			return result, nil
		}
		if jointPrintOrderInfo.PrintSceneJointRole == "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段PrintSceneJointRole为空")
			return result, nil
		}
		if jointPrintOrderInfo.Collaborator == "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段Collaborator为空")
			return result, nil
		}
		employeeMap, peopleErr := lark_client.GetUserIDsByEmails(ctx, []string{jointPrintOrderInfo.Collaborator})
		if peopleErr != nil {
			logs.CtxError(ctx, "JointPrintOrder必填字段Collaborator[%s]获取账号信息失败, err=%s", jointPrintOrderInfo.Collaborator, peopleErr.Error())
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段Collaborator[%s]获取账号信息失败", jointPrintOrderInfo.Collaborator)
			return result, nil
		}
		if _, exist := employeeMap[jointPrintOrderInfo.Collaborator]; !exist {
			logs.CtxError(ctx, "JointPrintOrder必填字段Collaborator[%s]账号失效", jointPrintOrderInfo.Collaborator)
			result.Pass = false
			result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "JointPrintOrder必填字段Collaborator[%s]账号失效", jointPrintOrderInfo.Collaborator)
			return result, nil
		}
	} else if jointPrintOrderInfo.Collaborator != "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintOrderCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "不支持联合打单，联合打单协作人Collaborator应为空")
		return result, nil
	}

	// 商机一致性校验 / PRM 政策一致性校验仅在 supportRebate 时进行（与原 JointPrintOrderChecker 一致）。
	if !supportRebate {
		return result, nil
	}

	// 4) 商机一致性校验
	opportunityInfo := quoteCtx.External.OppInfo
	if opportunityInfo == nil || opportunityInfo.JointPrintInfo == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNNoOpportunityInfo
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "商机信息为空")
		return result, nil
	}
	infoFromOpp := opportunityInfo.JointPrintInfo
	if !infoFromOpp.Equal(jointPrintOrderInfo) {
		logs.CtxInfo(ctx, "[JointPrintOrderRule] joint print order 与商机不一致 infoFromOpp: %s, JointPrintOrder: %s",
			util.GetJsonStr(infoFromOpp), util.GetJsonStr(jointPrintOrderInfo))
		result.Pass = false
		result.ErrorCode = errors.CodeNJointPrintInfoDiff
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单jointPrintOrder信息与最新商机信息不一致，请更新报价单信息")
		return result, nil
	}

	// 5) PRM 政策一致性校验
	policyFromPrm := quoteCtx.External.SpecialRebatePolicy
	if policyFromPrm == nil {
		return result, nil
	}
	if policyFromPrm.PolicyName != jointPrintOrderInfo.PolicyName ||
		policyFromPrm.PolicyLink != jointPrintOrderInfo.PolicyLink {
		logs.CtxInfo(ctx, "[JointPrintOrderRule] joint print policy 与 PRM 不一致")
		result.Pass = false
		result.ErrorCode = errors.CodeNRebatePolicyDiff
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单返佣政策与最新PRM信息不一致，请更新报价单信息")
		return result, nil
	}
	return result, nil
}

func (r *JointPrintOrderRule) BlockLevel() string {
	return BlockLevelError
}

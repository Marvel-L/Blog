package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// EffectiveInfoRule —— 主体生效信息校验。
//
// 与原 QuoteData.EffectiveInfoCheck 保持错误码与文案完全一致：
// 按主体生效时 VerifiedName 必填。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type EffectiveInfoRule struct{}

func (r *EffectiveInfoRule) Key() string  { return "BizDataRuleEffectiveInfo" }
func (r *EffectiveInfoRule) Desc() string { return "主体生效信息校验：按主体生效时 VerifiedName 必填" }
func (r *EffectiveInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *EffectiveInfoRule) BlockLevel() string { return BlockLevelError }

func (r *EffectiveInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNEffectiveInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.EffectiveType == constants.EffectiveTypeSubject && quote.VerifiedName == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNEffectiveInfoCheckFailed
		result.ErrorMsg = "按照主体生效报价单，主体信息缺失"
		return result, nil
	}
	return result, nil
}

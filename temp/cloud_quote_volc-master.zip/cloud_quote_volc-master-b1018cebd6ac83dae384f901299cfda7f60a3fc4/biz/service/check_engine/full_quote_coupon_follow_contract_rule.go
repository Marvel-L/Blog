package check_engine

import (
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/coupon_validation"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// FullQuoteCouponFollowContractRule 报价单预估合同有效期选择「自签订之日起」时，代金券规则有效期只能跟随合同。
type FullQuoteCouponFollowContractRule struct{}

func (r *FullQuoteCouponFollowContractRule) Key() string {
	return "BizDataRuleFullQuoteCouponFollowContract"
}

func (r *FullQuoteCouponFollowContractRule) Desc() string {
	return "报价单预估合同有效期选择自签订之日起时，代金券规则有效期只能选择跟随合同。"
}

func (r *FullQuoteCouponFollowContractRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote, quote_context.QuoteContextKeyCouponList}
}

func (r *FullQuoteCouponFollowContractRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil || quoteCtx.Persisted.Quote.PriceValidPeriod == "" {
		return result, nil
	}
	for _, coupon := range quoteCtx.Persisted.CouponList {
		if coupon == nil {
			continue
		}
		ruleInfo, err := coupon_validation.ParseRuleValidityInfo(coupon)
		if err != nil {
			return failCheckResult(result, errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券(id=%d)规则有效期数据异常", coupon.Id))), nil
		}
		if ruleInfo.Type != couponconfigconst.RuleValidityTypeFollowContract {
			return failCheckResult(result, errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券(id=%d)报价单预估合同有效期选择了自签订之日起，代金券规则有效期只能选择跟随合同", coupon.Id))), nil
		}
	}
	return result, nil
}

func (r *FullQuoteCouponFollowContractRule) BlockLevel() string { return BlockLevelError }

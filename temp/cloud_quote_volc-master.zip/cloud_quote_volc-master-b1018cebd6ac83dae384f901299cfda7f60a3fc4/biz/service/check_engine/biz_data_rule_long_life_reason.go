package check_engine

import (
	"context"
	"encoding/json"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// LongLifeReasonRule —— 长有效期原因校验。
//
// 与原 QuoteData.LongLifeReasonCheck 保持错误码与文案完全一致：
//   - 当合同有效期超过 5 年时，必须填写 LongLifeReason；
//   - LongLifeReason 长度不能超过 1000。
//
// IsLongLifeQuote 在 Rule 内基于 Persisted.Quote 字段直接重算，
// 与 QuoteDataCheckHelper 的派生口径完全一致：
//   - 固定时间生效（PriceValidPeriod 为空）：以 ToBeginningOfDay(EndTime - StartTime) > 5*365 天判定；
//   - 自签订之日起生效：JSON 解析 PriceValidPeriod 后调用 (*PriceValidPeriod).Over5Years()。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type LongLifeReasonRule struct{}

func (r *LongLifeReasonRule) Key() string { return "BizDataRuleLongLifeReason" }
func (r *LongLifeReasonRule) Desc() string {
	return "长有效期原因校验：合同有效期超过 5 年时 LongLifeReason 必填，且长度不超过 1000"
}
func (r *LongLifeReasonRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *LongLifeReasonRule) BlockLevel() string { return BlockLevelError }

func (r *LongLifeReasonRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNLongLifeReasonCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	isLongLife, err := isLongLifeQuoteFromPersisted(quote)
	if err != nil {
		// 与原逻辑一致：解析失败保留原报错链路（CodeNEffectFromSignTimeError 在 Helper 初始化阶段已抛过；
		// Rule 阶段降级为 LongLifeReason 校验失败，避免重复触发）。
		result.Pass = false
		result.ErrorCode = errors.CodeNLongLifeReasonCheckFailed
		result.ErrorMsg = err.Error()
		return result, nil
	}
	if isLongLife && quote.LongLifeReason == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNLongLifeReasonCheckFailed
		result.ErrorMsg = "合同有效期超过5年，请说明原因"
		return result, nil
	}
	if len([]rune(quote.LongLifeReason)) > 1000 {
		result.Pass = false
		result.ErrorCode = errors.CodeNLongLifeReasonCheckFailed
		result.ErrorMsg = "长有效期原因不可超过1000字"
		return result, nil
	}
	return result, nil
}

// isLongLifeQuoteFromPersisted 与 QuoteDataCheckHelper.IsLongLifeQuote 的派生口径完全一致。
func isLongLifeQuoteFromPersisted(quote *model.Quote) (bool, error) {
	if quote.PriceValidPeriod == "" { // 固定日期生效
		duration := util.ToBeginningOfDay(quote.PriceValidPeriodEndTime).Sub(util.ToBeginningOfDay(quote.PriceValidPeriodStartTime))
		return duration > constants.LongLifYearNum*365*24*time.Hour, nil
	}
	period := &model.PriceValidPeriod{}
	if err := json.Unmarshal([]byte(quote.PriceValidPeriod), period); err != nil {
		return false, err
	}
	return period.Over5Years(), nil
}

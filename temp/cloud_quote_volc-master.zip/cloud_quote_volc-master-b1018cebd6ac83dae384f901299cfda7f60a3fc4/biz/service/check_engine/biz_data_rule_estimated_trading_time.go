package check_engine

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// EstimatedTradingTimeRule —— 报价单预估上量时间校验。
//
// 与原 QuoteData.EstimatedTradingTimeCheck 保持错误码与文案完全一致：
//   - 固定日期生效（PriceValidPeriod 为空）：EstimatedTradingTime 必须落在
//     [ToBeginningOfMonth(PriceValidPeriodStartTime), ToBeginningOfMonth(PriceValidPeriodEndTime)] 月维度区间内；
//   - 自签订之日起生效：EstimatedTradingTime 不可早于本月初。
//
// 与 QuoteDataCheckHelper 的派生口径一致：
//   - IsFixedTimeEffective ⇔ Quote.PriceValidPeriod == ""；
//   - PriceStartTime/PriceEndTime 即 Quote.PriceValidPeriodStartTime/EndTime（持久态字段）。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type EstimatedTradingTimeRule struct{}

func (r *EstimatedTradingTimeRule) Key() string { return "BizDataRuleEstimatedTradingTime" }
func (r *EstimatedTradingTimeRule) Desc() string {
	return "预估上量时间校验：EstimatedTradingTime 必须落在合同有效期对应的月维度区间内（自签订之日起场景下不早于本月初）"
}
func (r *EstimatedTradingTimeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *EstimatedTradingTimeRule) BlockLevel() string { return BlockLevelError }

func (r *EstimatedTradingTimeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNEstimatedTradingTimeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	tradingTime := quote.EstimatedTradingTime
	if tradingTime.IsZero() {
		return result, nil
	}
	isFixedTimeEffective := quote.PriceValidPeriod == ""
	if isFixedTimeEffective {
		if tradingTime.After(util.ToBeginningOfMonth(quote.PriceValidPeriodEndTime)) ||
			tradingTime.Before(util.ToBeginningOfMonth(quote.PriceValidPeriodStartTime)) {
			result.Pass = false
			result.ErrorCode = errors.CodeNEstimatedTradingTimeCheckFailed
			result.ErrorMsg = "EstimatedTradingTime is not in PriceValidPeriod "
			return result, nil
		}
	} else {
		if tradingTime.Before(util.ToBeginningOfMonth(time.Now())) {
			result.Pass = false
			result.ErrorCode = errors.CodeNEstimatedTradingTimeCheckFailed
			result.ErrorMsg = "EstimatedTradingTime is not in PriceValidPeriod "
			return result, nil
		}
	}
	return result, nil
}

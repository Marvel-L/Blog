package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// RebateRule 返佣信息校验。
//
// 与原 RebateChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / RebateItemList；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 仅做数据校验，不做任何 DB / RPC 查询。
//     原 checker 在 !supportRebate 时会 SoftDeleteRebateItem 写 DB，本 Rule 不再
//     承担该副作用，由调用入口在引擎执行前完成清理。
type RebateRule struct{}

func (r *RebateRule) Key() string {
	return "BizDataRuleRebate"
}

func (r *RebateRule) Desc() string {
	return "返佣信息校验：" +
		"1) 当前报价单需支持返佣（不支持时返佣项应被前置清理）；" +
		"2) 特殊返佣关联的报价项必须存在；" +
		"3) 特殊返佣关联的报价项不能为私有云；" +
		"4) 抵扣计费项不允许设置特殊返佣。"
}

func (r *RebateRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyRebateItemList,
	}
}

func (r *RebateRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNNoRebateQuoteItem
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	rebateItems := quoteCtx.Persisted.RebateItemList
	if len(rebateItems) == 0 {
		return result, nil
	}

	supportRebate, err := quoteCtx.Persisted.Quote.SupportRebate(ctx)
	if err != nil {
		return nil, err
	}
	if !supportRebate {
		// 不支持返佣的脏数据由入口层前置清理；这里若仍存在则视为通过，
		// 等价于原 checker 在 !supportRebate 分支返回 nil 的语义。
		return result, nil
	}

	quoteItemMap := make(map[int64]bool, len(quoteCtx.Persisted.QuoteItems))
	itemTypeMap := make(map[int64]constants.ProductType, len(quoteCtx.Persisted.QuoteItems))
	itemSpDeductMap := make(map[int64]bool, len(quoteCtx.Persisted.QuoteItems))
	for _, item := range quoteCtx.Persisted.QuoteItems {
		quoteItemMap[item.Id] = true
		itemTypeMap[item.Id] = item.ItemType
		itemSpDeductMap[item.Id] = item.IsSpDeductItem()
	}

	for _, rebate := range rebateItems {
		if !quoteItemMap[rebate.QuoteItemID] {
			result.Pass = false
			result.ErrorCode = errors.CodeNNoRebateQuoteItem
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "特殊返佣关联的报价项不存在，请联系后台删除关联的返佣配置")
			return result, nil
		}
		if itemTypeMap[rebate.QuoteItemID] != multienv.TradeProductTypeOnline {
			result.Pass = false
			result.ErrorCode = errors.CodeNRebateQuoteItemPrivate
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "特殊返佣关联的报价项为私有云，请删除id为%v对应的返佣配置", rebate.QuoteItemID)
			return result, nil
		}
		if itemSpDeductMap[rebate.QuoteItemID] {
			result.Pass = false
			result.ErrorCode = errors.CodeNDeductNotSupportRebate
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "抵扣计费项【%d】不支持设置特殊返佣，请删除对应的返佣配置", rebate.QuoteItemID)
			return result, nil
		}
	}
	return result, nil
}

func (r *RebateRule) BlockLevel() string {
	return BlockLevelError
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// TradeTypeRule —— 客户类型校验。
//
// 与原 QuoteData.TradeTypeCheck 保持错误码与文案完全一致：
//   - TradeType 必须是有效客户类型；
//   - 非 PRM 报价单：TradeTypeCode 必须在 GetTradeCodeTypeMapping 中；
//   - 非 BytePlus + 生态客户类型：必须有伙伴授权（TradeTypeGrantMap[TradeTypeCode] 命中）；
//   - BP 分销客户类型仅支持 QuoteTypeNormal。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsPrmQuote ⇔ Quote.IsPrmQuote()
//
// 依赖 Persisted.Quote + External.TradeTypeGrantMap。
type TradeTypeRule struct{}

func (r *TradeTypeRule) Key() string { return "BizDataRuleTradeType" }
func (r *TradeTypeRule) Desc() string {
	return "客户类型校验：包含基本枚举校验、生态客户类型伙伴授权校验、BP 分销报价类型限制"
}
func (r *TradeTypeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyPartnerGrant,
	}
}
func (r *TradeTypeRule) BlockLevel() string { return BlockLevelError }

func (r *TradeTypeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if !quote.TradeType.EffectiveCustomer() {
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeCheckFailed
		result.ErrorMsg = "客户类型错误"
		return result, nil
	}

	if quote.IsPrmQuote() {
		return result, nil
	}

	if _, ok := multienv.GetTradeCodeTypeMapping()[quote.TradeTypeCode]; !ok {
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeCheckFailed
		result.ErrorMsg = "TradeTypeCode error"
		return result, nil
	}

	if !multienv.IsBytePlus() {
		if _, ok := multienv.EcoTradeTypeCodeMap[quote.TradeTypeCode]; ok {
			if _, grantOk := quoteCtx.External.TradeTypeGrantMap[quote.TradeTypeCode]; !grantOk {
				result.Pass = false
				result.ErrorCode = errors.CodeNTradeTypeCheckFailed
				result.ErrorMsg = "tradeType is invalid, no partner grant"
				return result, nil
			}
		}
	}

	if quote.TradeTypeCode == multienv.CustomerTypeCodeBPDistributor && quote.QuoteType != multienv.QuoteTypeNormal {
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeCheckFailed
		result.ErrorMsg = "【生态—BP分销】只支持报价类型【普通报价】"
		return result, nil
	}
	return result, nil
}

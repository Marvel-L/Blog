package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// MdInfoRule —— 主数据信息校验。
//
// 与原 QuoteData.MdInfoCheck 保持错误码与文案完全一致：
//   - 仅在 BytePlus 环境且来源 CRM 时校验；
//   - 通过 config_option_service.GenMdInfoList 解析 MdInfo，解析失败即报 CodeNMDInfoCheckFailed。
//
// 仅依赖 Persisted.Quote 的 MdInfo 字段与 ctx 上的 OpenApiAppKey（非 helper），不发起任何 RPC / DB 查询。
type MdInfoRule struct{}

func (r *MdInfoRule) Key() string  { return "BizDataRuleMdInfo" }
func (r *MdInfoRule) Desc() string { return "主数据信息校验：BytePlus + CRM 来源场景下 MdInfo 必须能被合法解析" }
func (r *MdInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *MdInfoRule) BlockLevel() string { return BlockLevelError }

func (r *MdInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNMDInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if !multienv.IsBytePlus() {
		return result, nil
	}
	if util.GetOpenApiAppKey(ctx) != config.GetOpenApiAppKeyCrm(ctx) {
		return result, nil
	}
	if _, err := config_option_service.GenMdInfoList(quoteCtx.Persisted.Quote.MdInfo); err != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNMDInfoCheckFailed
		result.ErrorMsg = err.Error()
		return result, nil
	}
	return result, nil
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// MaxItemNumRule is a PoC rule for the "rule needs" driven validation engine.
// It checks whether total quote items + delivery items exceeds config max.
//
// NOTE: This rule is only wired into QuoteBizDataCheckReq via checker key `CheckerKeyDemoMaxItemNumV2`.
type MaxItemNumRule struct{}

func (r *MaxItemNumRule) Key() string {
	return "BizDataRuleMaxItemNum"
}

func (r *MaxItemNumRule) Desc() string {
	return "报价单内报价项、交付项数目不能超过配置最大值"
}

func (r *MaxItemNumRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuoteItemsAllStatus,
		quote_context.QuoteContextKeyDeliveryItems,
	}
}

func (r *MaxItemNumRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteBaseInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	maxItemNum := config.GetMaxItemNum(ctx)
	if len(quoteCtx.Persisted.QuoteItemsAllStatus)+len(quoteCtx.Persisted.DeliveryItems) > maxItemNum {
		result.Pass = false
		result.ErrorCode = errors.CodeNItemNumExceedMaxNum
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "当前报价单中报价项、交付项数目超过%d，为保证流程正常，禁止添加！", maxItemNum)
	}
	return result, nil
}

func (r *MaxItemNumRule) BlockLevel() string {
	return BlockLevelError
}

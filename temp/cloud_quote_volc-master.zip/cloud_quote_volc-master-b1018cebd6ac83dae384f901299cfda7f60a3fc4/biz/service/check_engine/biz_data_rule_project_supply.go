package check_engine

import (
	"context"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ProjectSupplyRule 项目制补充协议校验。
//
// 来源：原 ProjectSupplyChecker。
// 校验目标（仅当报价单 IsProjectSupplyAgreement 时生效）：
//  1. 父报价单合同有效期约束：
//     - 续约+增购：当前 PriceValidPeriodStartTime 必须晚于父合同结束时间
//     - 仅增购：    当前 PriceValidPeriodStartTime 必须晚于或等于父合同开始时间
//  2. 若所有报价项均非默认生成（GenerateTypeDefault），必须存在"增购行为"：
//     即至少一个子报价项相比父报价项 UsedAmount 增加 或 PurchaseTimes 增加。
//
// 与原 checker 的差异：
//   - 父报价单 ItemContextMap 由 `loaderParentItemContextMap` 加载；
//   - 父合同有效期由 `loaderParentContractTime` 加载；
//   - 当前 ItemContextMap 复用 `QuoteContextKeyItemContextMap`；
//   - Rule 仅做校验对比，无 RPC / 无 DB。
type ProjectSupplyRule struct{}

func (r *ProjectSupplyRule) Key() string {
	return "BizDataRuleProjectSupply"
}

func (r *ProjectSupplyRule) Desc() string {
	return "项目制补充协议校验：" +
		"1) 父合同有效期约束（续约+增购：开始时间晚于父结束时间；仅增购：开始时间不早于父开始时间）；" +
		"2) 当不存在默认生成报价项时，必须包含增购行为（数量增加或购买周期增加）。"
}

func (r *ProjectSupplyRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyParentItemContextMap,
		quote_context.QuoteContextKeyParentContractTime,
	}
}

func (r *ProjectSupplyRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if !quote.IsProjectSupplyAgreement() {
		return result, nil
	}

	// 1) 父合同有效期校验
	if quoteCtx.Parent == nil {
		return result, nil
	}
	parentContract := quoteCtx.Parent.External.ContractInfo
	if parentContract == nil {
		return result, nil
	}
	if multienv.IsContainsSupplyScene(quote.SupplyScene, multienv.SupplySceneContractRenewal) {
		if !quote.PriceValidPeriodStartTime.After(parentContract.ValidEnd) {
			result.Pass = false
			result.ErrorCode = errors.CodeNProjectSupplyCheckFailed
			result.ErrorMsg = "补充项目制报价单-增购&续约，变更场景下，预估合同有效期-开始时间必须晚于原结束时间"
			return result, nil
		}
	} else {
		if quote.PriceValidPeriodStartTime.Before(parentContract.ValidBegin) {
			result.Pass = false
			result.ErrorCode = errors.CodeNProjectSupplyCheckFailed
			result.ErrorMsg = "补充项目制报价单-增购，变更场景下，预估合同有效期-开始时间必须晚于或等于原开始时间"
			return result, nil
		}
	}

	// 2) 增购行为校验
	allItems := append([]*model.QuoteItem{}, quoteCtx.Persisted.QuoteItems...)
	allItems = append(allItems, quoteCtx.Persisted.DeliveryItems...)
	existGenerateTypeDefault := false
	for _, qi := range allItems {
		if qi.GenerateType == constants.GenerateTypeDefault {
			existGenerateTypeDefault = true
			break
		}
	}
	if existGenerateTypeDefault {
		return result, nil
	}

	itemCtxMap := quoteCtx.Persisted.ItemContextMap
	parentItemCtxMap := quoteCtx.Parent.Persisted.ItemContextMap
	increasePurchase := false
	for _, currentItem := range allItems {
		if currentItem.ParentItemID == 0 {
			continue
		}
		curCtx := itemCtxMap[currentItem.Id]
		parentCtx := parentItemCtxMap[currentItem.ParentItemID]
		if curCtx == nil || parentCtx == nil {
			continue
		}
		curNum, _ := decimal.NewFromString(curCtx.UsedAmount)
		parentNum, _ := decimal.NewFromString(parentCtx.UsedAmount)
		if curNum.GreaterThan(parentNum) || curCtx.PurchaseTimes > parentCtx.PurchaseTimes {
			increasePurchase = true
			break
		}
	}
	if !increasePurchase {
		result.Pass = false
		result.ErrorCode = errors.CodeNProjectSupplyCheckFailed
		result.ErrorMsg = "项目制续约必须同时完成续期 + 增购，当前报价单未包含增购操作（增购定义：对已有报价项延长购买时长 / 增加购买数量，或新增任意报价项），请返回修改商品配置。"
		return result, nil
	}
	return result, nil
}

func (r *ProjectSupplyRule) BlockLevel() string {
	return BlockLevelError
}

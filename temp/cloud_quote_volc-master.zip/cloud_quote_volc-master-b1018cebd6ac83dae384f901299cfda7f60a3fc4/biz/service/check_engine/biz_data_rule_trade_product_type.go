package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// TradeProductTypeRule —— 报价单涉及商品类型校验。
//
// 与原 QuoteData.TradeProductTypeCheck 保持错误码与文案完全一致：
//   - 非项目制报价单：不允许涉及非标品；
//   - 阶梯报价：报价单涉及商品只能是公有云（标品）；
//   - BP分销-特殊报价：报价单涉及商品只能是公有云（标品）。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - ProductTypeMap ⇔ Quote.GetProductTypeMap（基于 Quote.QuoteRelatedProduct JSON 解析）；
//   - onlyContainsOnline ⇔ len(ProductTypeMap)==1 && containsOnline。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type TradeProductTypeRule struct{}

func (r *TradeProductTypeRule) Key() string { return "BizDataRuleTradeProductType" }
func (r *TradeProductTypeRule) Desc() string {
	return "报价单涉及商品类型校验：非项目制不允许选择非标品；阶梯报价 / BP分销-特殊报价仅允许公有云（标品）"
}
func (r *TradeProductTypeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *TradeProductTypeRule) BlockLevel() string { return BlockLevelError }

func (r *TradeProductTypeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteRelatedProductCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	productTypeMap, err := quote.GetProductTypeMap(ctx)
	if err != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteRelatedProductCheckFailed
		result.ErrorMsg = err.Error()
		return result, nil
	}
	_, containsOnline := productTypeMap[multienv.TradeProductTypeOnline]
	_, containsNoStandard := productTypeMap[multienv.TradeProductTypeNoStandard]
	onlyContainsOnline := len(productTypeMap) == 1 && containsOnline

	if quote.QuoteType != multienv.QuoteTypeProjectBased && containsNoStandard {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteRelatedProductCheckFailed
		result.ErrorMsg = "非项目制报价单涉及商品不允许选择非标品"
		return result, nil
	}
	if quote.QuoteType == multienv.QuoteTypeProgressive && !onlyContainsOnline {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteRelatedProductCheckFailed
		result.ErrorMsg = "阶梯报价，报价单涉及商品只能是公有云（标品）"
		return result, nil
	}
	if quote.IsDistributionBizTypeCustom() && !onlyContainsOnline {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteRelatedProductCheckFailed
		result.ErrorMsg = "BP分销-特殊报价，报价单涉及商品只能是公有云（标品）"
		return result, nil
	}
	return result, nil
}

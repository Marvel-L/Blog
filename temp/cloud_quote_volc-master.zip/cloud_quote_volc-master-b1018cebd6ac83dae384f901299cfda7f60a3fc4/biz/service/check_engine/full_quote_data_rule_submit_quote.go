package check_engine

import (
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/coupon_validation"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

func newPassCheckResult(rule QuoteBizRule) *CheckResult {
	return &CheckResult{Pass: true, BlockLevel: rule.BlockLevel(), RuleKey: rule.Key(), RuleDesc: rule.Desc()}
}

func failCheckResult(result *CheckResult, apiErr errors.APIError) *CheckResult {
	result.Pass = false
	result.ErrorCode = errors.ErrorCodeN(apiErr.GetCodeInt())
	result.ErrorMsg = apiErrorMessage(apiErr)
	return result
}

func apiErrorMessage(apiErr errors.APIError) string {
	if apiErr == nil {
		return ""
	}
	if errStruct, ok := apiErr.(*errors.APIErrorStruct); ok {
		return fmt.Sprintf(errStruct.Message, errStruct.Args...)
	}
	return apiErr.Error()
}

func fullQuoteAllItems(quoteCtx *quote_context.QuoteContext) []*model.QuoteItem {
	allItems := make([]*model.QuoteItem, 0, len(quoteCtx.Persisted.QuoteItemsAllStatus)+len(quoteCtx.Persisted.DeliveryItems))
	allItems = append(allItems, quoteCtx.Persisted.QuoteItemsAllStatus...)
	allItems = append(allItems, quoteCtx.Persisted.DeliveryItems...)
	return allItems
}

func ValidateFullQuoteTriggerQuoteItemIDList(triggerInfo *model.TriggerInfo, quoteItemMap map[int64]*model.QuoteItem, rebateCouponWay ...int) errors.APIError {
	if triggerInfo.ConsumeRebateProductList == "" && len(triggerInfo.QuoteItemIDList) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "代金券未指定参与消费金额计算商品和报价项")
	}
	consumeRebateProductMap := util.StrSplitToMap(triggerInfo.ConsumeRebateProductList, ",")
	if len(triggerInfo.QuoteItemIDList) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "代金券未指定参与账单金额计算报价项")
	}

	tradeProductMap := map[string]struct{}{}
	for _, quoteItemID := range triggerInfo.QuoteItemIDList {
		quoteItem := quoteItemMap[quoteItemID]
		if quoteItem == nil {
			return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "参与账单金额计算报价项%d在报价单中不存在").WithArgs(quoteItemID)
		}
		if quoteItem.IsSpDeductItem() {
			return errors.NewBizErrWithMsg(errors.CodeNDeductNotSupportCoupon, "抵扣计费项【%d】不支持关联代金券").WithArgs(quoteItemID)
		}
		tradeProductMap[quoteItem.TradeProduct] = struct{}{}
	}

	if !util.StrSetEqual(tradeProductMap, consumeRebateProductMap) {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "代金券参与账单金额计算商品与报价项不一致")
	}

	couponWay := 0
	if len(rebateCouponWay) > 0 {
		couponWay = rebateCouponWay[0]
	}
	if couponWay != couponconfigconst.RebateCouponWayByAmountPercent {
		return nil
	}
	if triggerInfo.StatConsumeRebateProductList == "" {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "按账单金额比例返券必须指定统计商品")
	}
	if len(triggerInfo.StatQuoteItemIDList) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "按账单金额比例返券必须指定统计报价项")
	}
	return validateFullQuoteStatTriggerInfo(triggerInfo, quoteItemMap, util.StrSplitToMap(triggerInfo.StatConsumeRebateProductList, ","), consumeRebateProductMap)
}

func validateFullQuoteStatTriggerInfo(triggerInfo *model.TriggerInfo, quoteItemMap map[int64]*model.QuoteItem, statProductMap, consumeRebateProductMap map[string]struct{}) errors.APIError {

	statQuoteItemTradeProductMap := make(map[string]struct{})
	for _, statQuoteItemID := range triggerInfo.StatQuoteItemIDList {
		quoteItem := quoteItemMap[statQuoteItemID]
		if quoteItem == nil {
			return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "统计报价项%d在报价单中不存在").WithArgs(statQuoteItemID)
		}
		if quoteItem.IsSpDeductItem() {
			return errors.NewBizErrWithMsg(errors.CodeNDeductNotSupportCoupon, "抵扣计费项【%d】不支持关联代金券").WithArgs(statQuoteItemID)
		}
		statQuoteItemTradeProductMap[quoteItem.TradeProduct] = struct{}{}
	}

	if !util.StrSetEqual(statQuoteItemTradeProductMap, statProductMap) {
		return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "代金券统计商品与统计报价项不一致")
	}

	for consumeProduct := range consumeRebateProductMap {
		if _, ok := statProductMap[consumeProduct]; !ok {
			return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "计算商品%s不在统计商品范围内").WithArgs(consumeProduct)
		}
	}
	statQuoteItemSet := map[int64]struct{}{}
	for _, id := range triggerInfo.StatQuoteItemIDList {
		statQuoteItemSet[id] = struct{}{}
	}
	for _, id := range triggerInfo.QuoteItemIDList {
		if _, ok := statQuoteItemSet[id]; !ok {
			return errors.NewBizErrWithMsg(errors.CodeNValidateCouponTriggerInfoFailed, "计算报价项%d不在统计报价项范围内").WithArgs(id)
		}
	}
	return nil
}

func validateFullQuoteCouponRuleValidity(ctx context.Context, coupon *model.CouponConfigDB, quoteBeginMonth, quoteEndMonth string) errors.APIError {
	ruleInfo, err := coupon_validation.ParseRuleValidityInfo(coupon)
	if err != nil {
		return errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券(id=%d)规则有效期数据异常", coupon.Id))
	}
	if ruleInfo.Type != couponconfigconst.RuleValidityTypeSpecifiedMonth {
		return nil
	}
	if ruleInfo.BeginMonth < quoteBeginMonth {
		logs.CtxError(ctx, "[validateFullQuoteCouponRuleValidity] couponId=%d, 规则有效期开始月份[%s]早于报价单合同有效期开始月份[%s]", coupon.Id, ruleInfo.BeginMonth, quoteBeginMonth)
		return errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券规则(%d)有效期(%s~%s)超出合同有效期(%s~%s),请修改代金券有效期,确保其在合同有效期范围内。", coupon.Id, ruleInfo.BeginMonth, ruleInfo.EndMonth, quoteBeginMonth, quoteEndMonth))
	}
	if ruleInfo.EndMonth > quoteEndMonth {
		logs.CtxError(ctx, "[validateFullQuoteCouponRuleValidity] couponId=%d, 规则有效期结束月份[%s]晚于报价单合同有效期结束月份[%s]", coupon.Id, ruleInfo.EndMonth, quoteEndMonth)
		return errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券规则(%d)有效期(%s~%s)超出合同有效期(%s~%s),请修改代金券有效期,确保其在合同有效期范围内。", coupon.Id, ruleInfo.BeginMonth, ruleInfo.EndMonth, quoteBeginMonth, quoteEndMonth))
	}
	return nil
}

func sameFullQuoteDiscounts(ctx context.Context, newList, oldList []string) bool {
	if len(newList) == len(oldList) {
		return true
	}
	newMap := map[string]bool{}
	oldMap := map[string]bool{}
	for _, v := range newList {
		if v != "" {
			newMap[v] = true
		}
	}
	for _, v := range oldList {
		if v != "" {
			oldMap[v] = true
		}
	}
	logs.CtxInfo(ctx, "[FullQuoteModifyDiscountRule]isSame_data, old=%v, new=%v", oldMap, newMap)
	for oldK := range oldMap {
		if !newMap[oldK] {
			logs.CtxInfo(ctx, "[FullQuoteModifyDiscountRule]isSame_oldK(%s)在新优惠范围内不存在", oldK)
			return false
		}
	}
	for newK := range newMap {
		if !oldMap[newK] {
			logs.CtxInfo(ctx, "[FullQuoteModifyDiscountRule]isSame_newK(%s)在新优惠范围内不存在", newK)
			return false
		}
	}
	return true
}

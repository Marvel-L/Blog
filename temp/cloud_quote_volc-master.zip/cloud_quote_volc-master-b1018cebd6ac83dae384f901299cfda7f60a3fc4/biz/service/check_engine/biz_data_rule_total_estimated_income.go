package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
)

// TotalEstimatedIncomeRule 综合预计金额校验。
// 当前业务允许综合预计金额小于等于 0，保留 rule 壳用于兼容历史 CheckKey。
type TotalEstimatedIncomeRule struct{}

// TotalEstimatedIncomeDetail 命中详情，承载在 CheckResult.Detail 中。
type TotalEstimatedIncomeDetail struct {
	QuoteItemIDs []int64
}

func (r *TotalEstimatedIncomeRule) Key() string {
	return "BizDataRuleTotalEstimatedIncome"
}

func (r *TotalEstimatedIncomeRule) Desc() string {
	return "综合预计金额校验"
}

func (r *TotalEstimatedIncomeRule) Needs() []quote_context.QuoteContextKey {
	return nil
}

func (r *TotalEstimatedIncomeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	return result, nil
}

func (r *TotalEstimatedIncomeRule) BlockLevel() string {
	return BlockLevelError
}

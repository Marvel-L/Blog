package check_engine

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/account_info"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// CustomerDetailRule —— 火山注册账号校验。
//
// 与原 QuoteData.CustomerDetailCheckV2（quote_data_field_check.go:280-364，非 BytePlus）
// 与 QuoteData.CustomerDetailCheckBP（quote_data_field_check.go:366-416，BytePlus）保持
// 错误码与文案完全一致。
//
// 分支选择 multienv.IsBytePlus() 与原 GetCustomerDetailCheck()（quote_data_field_check.go:146-152）一致。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsPrmQuote                  ⇔ Quote.IsPrmQuote()
//   - IsInnerQuote                ⇔ Quote.IsInnerQuote()
//   - AccountIDs                  ⇔ strings.Split(Quote.CustomerDetail, ",")（去空）
//   - ContractAccountIDs          ⇔ strings.Split(Quote.ContractAccount, ",")（去空）
//   - SupportMultiAccount         ⇔ Quote 字段直接派生（详见 supportMultiAccountFromPersisted）
//   - onlyContainsOnline / Offline ⇔ Quote.GetProductTypeMap 派生
//   - IsDistributionCustom        ⇔ Quote.DistributionBizTypeCode == multienv.DistributionBizTypeCodeCustom
//
// 副作用剥离（§9）：原 V2 末尾 r.RelatedAccountIDsCheck 调用已由独立 RelatedAccountIDsRule 承担，本 Rule 不再调用。
//
// 校验类 RPC（§8.11，仅做有效性判定）：
//   - account_info.ListAccountAndVerifyByIds —— 由 loaderAccountAndVerifyInfos 加载到 External
//   - account_service.CheckFinalCustomer —— BP 分销特殊报价分支允许在 Rule 内直接调用
type CustomerDetailRule struct{}

func (r *CustomerDetailRule) Key() string { return "BizDataRuleCustomerDetail" }
func (r *CustomerDetailRule) Desc() string {
	return "火山注册账号校验：必填判定、账号数量限制、企业实名、账号来源、与商品类型/客户类型组合的合法性"
}
func (r *CustomerDetailRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyAccountAndVerifyInfos,
	}
}
func (r *CustomerDetailRule) BlockLevel() string { return BlockLevelError }

func (r *CustomerDetailRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNAccountIDCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if multienv.IsBytePlus() {
		return r.checkBP(ctx, quoteCtx, quote, result)
	}
	return r.checkV2(ctx, quoteCtx, quote, result)
}

// checkV2 与 QuoteData.CustomerDetailCheckV2 完全一致。
func (r *CustomerDetailRule) checkV2(ctx context.Context, quoteCtx *quote_context.QuoteContext, quote *model.Quote, result *CheckResult) (*CheckResult, error) {
	if quote.IsPrmQuote() {
		return result, nil
	}
	accountIDs := splitAccountIDs(quote.CustomerDetail)
	contractAccountIDs := splitAccountIDs(quote.ContractAccount)

	if len(accountIDs) == 0 {
		if quote.OrderType == multienv.GetContractTypeOfficialWebAuto() && quote.EffectiveType == constants.EffectiveTypeAccount {
			result.Pass = false
			result.ErrorCode = errors.CodeNCustomerAccountRequired
			result.ErrorMsg = "签约方式为【官网自助下单】时，客户 ID 必填"
			return result, nil
		}
	} else if len(accountIDs) > 10 {
		result.Pass = false
		result.ErrorCode = errors.CodeNAccountCountExceedLimit
		result.ErrorMsg = fmt.Sprintf("客户账号不支持超10个报价，请删除多余账号后按需分批进行报价。当前账号数量%d，账号列表%s", len(accountIDs), strings.Join(accountIDs, ","))
		return result, nil
	} else if len(accountIDs) > 1 {
		productTypeMap, err := quote.GetProductTypeMap(ctx)
		if err != nil {
			return nil, err
		}
		if !supportMultiAccountFromPersisted(quote, productTypeMap) {
			result.Pass = false
			result.ErrorCode = errors.CodeNMultiAccountUnsupported
			result.ErrorMsg = fmt.Sprintf("仅公有云（标品）且直签场景下允许客户账号多选。请删除多余账号后按需分批进行报价。当前账号数量%d，账号列表%s", len(accountIDs), strings.Join(accountIDs, ","))
			return result, nil
		}
	}
	if len(contractAccountIDs) == 0 {
		if quote.OrderType == multienv.GetContractTypeOfficialWebAuto() && quote.EffectiveType == constants.EffectiveTypeAccount {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractAccountRequired
			result.ErrorMsg = "签约方式为【官网自助下单】时，签约火山账号 ID 必填"
			return result, nil
		}
	}
	if len(accountIDs) == 0 {
		return result, nil
	}

	accountInfos := quoteCtx.External.AccountAndVerifyInfos
	accountMap := map[string]*account_info.AccountAndVerifyInfo{}
	var officialWebsiteCreateAccounts []*account_info.AccountAndVerifyInfo
	var salesCreateAccounts []*account_info.AccountAndVerifyInfo
	for _, accountInfo := range accountInfos {
		if !accountInfo.IsEnterpriseIdentity() {
			result.Pass = false
			result.ErrorCode = errors.CodeNAccountIDCheckFailed
			result.ErrorMsg = "用户账号非企业实名认证账号：" + strconv.FormatInt(accountInfo.AccountID, 10)
			return result, nil
		}
		accountMap[strconv.FormatInt(accountInfo.AccountID, 10)] = accountInfo
		switch accountInfo.CreateSource {
		case account_info.CreateSourceOfficialWebsite:
			officialWebsiteCreateAccounts = append(officialWebsiteCreateAccounts, accountInfo)
		case account_info.CreateSourceSales:
			salesCreateAccounts = append(salesCreateAccounts, accountInfo)
		default:
			result.Pass = false
			result.ErrorCode = errors.CodeNAccountCreateSourceInvalid
			result.ErrorMsg = fmt.Sprintf("该客户账号%d来源不支持绑定报价单，请使用官网注册或销售代客创建账号", accountInfo.AccountID)
			return result, nil
		}
		if accountInfo.IsClosed() {
			result.Pass = false
			result.ErrorCode = errors.CodeNAccountClosed
			result.ErrorMsg = fmt.Sprintf("当前账号%d已注销，不支持报价", accountInfo.AccountID)
			return result, nil
		}
	}
	if len(accountMap) != len(accountIDs) {
		for _, accountIDStr := range accountIDs {
			if _, ok := accountMap[accountIDStr]; !ok {
				result.Pass = false
				result.ErrorCode = errors.CodeNAccountNotFound
				result.ErrorMsg = fmt.Sprintf("用户账号%s不存在，请检查账号 ID 是否正确", accountIDStr)
				return result, nil
			}
		}
		result.Pass = false
		result.ErrorCode = errors.CodeNDuplicateAccountID
		result.ErrorMsg = fmt.Sprintf("输入账号有重复，请删除重复账号后重试。账号列表%s", strings.Join(accountIDs, ","))
		return result, nil
	}
	if len(officialWebsiteCreateAccounts) > 10 {
		result.Pass = false
		result.ErrorCode = errors.CodeNOfficialWebsiteAccountCountExceedLimit
		result.ErrorMsg = fmt.Sprintf("客户自助注册账号不支持超10个报价，请删除多余账号后按需分批进行报价。当前账号数量%d，账号列表%s", len(officialWebsiteCreateAccounts), accountIDsFromAccountInfos(officialWebsiteCreateAccounts))
		return result, nil
	}
	if len(salesCreateAccounts) > 1 {
		result.Pass = false
		result.ErrorCode = errors.CodeNSalesCreateAccountCountExceedLimit
		result.ErrorMsg = fmt.Sprintf("线下代客创建的账号不允许多选。请删除多余账号后按需分批进行报价。当前账号数量%d，账号列表%s", len(salesCreateAccounts), accountIDsFromAccountInfos(salesCreateAccounts))
		return result, nil
	}

	productTypeMap, err := quote.GetProductTypeMap(ctx)
	if err != nil {
		return nil, err
	}
	onlyOnline := isOnlyOnline(productTypeMap)
	onlyOffline := isOnlyOffline(productTypeMap)
	if onlyOnline {
		if len(accountIDs) != len(officialWebsiteCreateAccounts) {
			result.Pass = false
			result.ErrorCode = errors.CodeNPublicCloudAccountCreateSourceInvalid
			result.ErrorMsg = fmt.Sprintf("涉及商品类型仅包含公有云商品时，只允许选择客户自注册账号（%s账号为线下代客创建类型，请移除账号或者修改涉及商品类型）", accountIDsFromAccountInfos(salesCreateAccounts))
			return result, nil
		}
	} else if onlyOffline {
		if quote.TradeTypeCode == multienv.CustomerTypeCodeEcoDist {
			logs.CtxInfo(ctx, "客户类型生态-分销，支持填写线下待客创建账号和客户自主创建账号")
		} else if len(accountIDs) != len(salesCreateAccounts) {
			result.Pass = false
			result.ErrorCode = errors.CodeNPrivateCloudAccountCreateSourceInvalid
			result.ErrorMsg = fmt.Sprintf("涉及商品类型仅包含私有云商品时，只允许选择线下代客创建账号（%s账号为客户自注册创建类型，请移除账号或者修改涉及商品类型或者联系销运创建线下账号）", accountIDsFromAccountInfos(officialWebsiteCreateAccounts))
			return result, nil
		}
	}
	return result, nil
}

// checkBP 与 QuoteData.CustomerDetailCheckBP 完全一致。
func (r *CustomerDetailRule) checkBP(ctx context.Context, quoteCtx *quote_context.QuoteContext, quote *model.Quote, result *CheckResult) (*CheckResult, error) {
	if quote.CustomerDetail == "" {
		if quote.OrderType == multienv.GetContractTypeOfficialWebAuto() && quote.EffectiveType == constants.EffectiveTypeAccount {
			result.Pass = false
			result.ErrorCode = errors.CodeNCustomerAccountRequired
			result.ErrorMsg = "签约方式为【官网自助下单】时，客户 ID 必填"
			return result, nil
		}
		if quote.IsDistributionBizTypeCustom() {
			result.Pass = false
			result.ErrorCode = errors.CodeNBPSpecialCustomerAccountRequired
			result.ErrorMsg = "Partner Special Discount quotation requires end customer console user ID linked to Distributor Console User Layer. Please check your selected quotation model and End Customer Console User ID, or guide partners to invite and register an end customer console user ID account."
			return result, nil
		}
		return result, nil
	}
	accountIDs := splitAccountIDs(quote.CustomerDetail)
	if quote.IsInnerQuote() && len(accountIDs) > 1 {
		result.Pass = false
		result.ErrorCode = errors.CodeNBPInnerMultiAccountUnsupported
		result.ErrorMsg = fmt.Sprintf("内部客户账号不允许多选。请删除多余账号后按需分批进行报价。当前账号数量%d，账号列表%s", len(accountIDs), strings.Join(accountIDs, ","))
		return result, nil
	}
	if quote.IsDistributionBizTypeCustom() {
		if len(accountIDs) != 1 {
			result.Pass = false
			result.ErrorCode = errors.CodeNBPSpecialAccountCountInvalid
			result.ErrorMsg = fmt.Sprintf("Partner Special Discount quotation does not support multi-select accounts. Delete redundant accounts and quote batch by batch. Current account count is %d, account list is %s.", len(accountIDs), strings.Join(accountIDs, ","))
			return result, nil
		}
		isFinalCustomer, _, err := account_service.CheckFinalCustomer(ctx, accountIDs[0])
		if err != nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNFinalCustomerCheckFailed
			result.ErrorMsg = fmt.Sprintf("最终客户校验失败，请检查客户 ID 或稍后重试。客户 ID %s", accountIDs[0])
			return result, nil
		}
		if !isFinalCustomer {
			result.Pass = false
			result.ErrorCode = errors.CodeNBPSpecialCustomerNotFinalCustomer
			result.ErrorMsg = fmt.Sprintf("Under the Partner Special Discount quotation, the quoted end customer console user ID %s must belong to the customer associated with the opportunity. Navigate to the opportunity-bound account page to Console User or switch to another existing account under this customer.", accountIDs[0])
			return result, nil
		}
	}

	for _, accountInfo := range quoteCtx.External.AccountAndVerifyInfos {
		if accountInfo.CreateSource != account_info.CreateSourceOfficialWebsite {
			result.Pass = false
			result.ErrorCode = errors.CodeNBPAccountCreateSourceInvalid
			result.ErrorMsg = fmt.Sprintf("该客户账号%d来源不支持绑定报价单，请使用官网注册账号", accountInfo.AccountID)
			return result, nil
		}
		if !accountInfo.IsEnterpriseIdentity() {
			result.Pass = false
			result.ErrorCode = errors.CodeNBPAccountNotEnterpriseVerified
			result.ErrorMsg = fmt.Sprintf("Partner Special Discount quotation is not allowed because enterprise authentication for Account %d is incomplete. Please advise the customer to complete authentication before retrying.", accountInfo.AccountID)
			return result, nil
		}
		if accountInfo.IsClosed() {
			result.Pass = false
			result.ErrorCode = errors.CodeNAccountClosed
			result.ErrorMsg = fmt.Sprintf("当前账号%d已注销，不支持报价", accountInfo.AccountID)
			return result, nil
		}
	}
	return result, nil
}

func accountIDsFromAccountInfos(accountInfos []*account_info.AccountAndVerifyInfo) string {
	accountIDs := make([]string, 0, len(accountInfos))
	for _, accountInfo := range accountInfos {
		accountIDs = append(accountIDs, strconv.FormatInt(accountInfo.AccountID, 10))
	}
	return util.GetJsonStr(accountIDs)
}

// splitAccountIDs 将逗号分隔的账号 ID 串拆分并去空。
func splitAccountIDs(s string) []string {
	if s == "" {
		return nil
	}
	var ids []string
	for _, id := range strings.Split(s, ",") {
		id = strings.TrimSpace(id)
		if id == "" {
			continue
		}
		ids = append(ids, id)
	}
	return ids
}

// supportMultiAccountFromPersisted 与 QuoteData.SupportMultiAccount 派生口径一致：
//   - IsDirectSellNormalOrProgressive 或
//   - IsProjectBasedSupply
//
// 两个判定均仅依赖 Quote 字段（OrderTypeCode / TradeTypeCode / QuoteType / QuoteScene / 商品类型派生）。
func supportMultiAccountFromPersisted(quote *model.Quote, productTypeMap map[constants.ProductType]interface{}) bool {
	// 项目制补充协议
	if quote.QuoteType == constants.ProjectBasedTrue && quote.QuoteScene == multienv.SceneSupplyAgreement {
		return true
	}
	// 直销-标品-纸质合同-普通/阶梯
	paperContract := quote.OrderTypeCode == multienv.ContractTypeCodePaperContract &&
		multienv.IsAllDirectTradeType(quote.TradeTypeCode) &&
		isOnlyStandardProduct(productTypeMap) &&
		(quote.QuoteType == multienv.QuoteTypeNormal || quote.QuoteType == multienv.QuoteTypeProgressive)
	// 直销-公有云-官网自助-普通
	webAuto := quote.OrderTypeCode == multienv.ContractTypeCodeOfficialWebAuto &&
		multienv.IsAllDirectTradeType(quote.TradeTypeCode) &&
		isOnlyOnline(productTypeMap) &&
		quote.QuoteType == multienv.QuoteTypeNormal
	return paperContract || webAuto
}

// isOnlyOnline 与 QuoteDataCheckHelper.onlyContainsOnline 派生口径一致。
func isOnlyOnline(productTypeMap map[constants.ProductType]interface{}) bool {
	if len(productTypeMap) != 1 {
		return false
	}
	_, ok := productTypeMap[multienv.TradeProductTypeOnline]
	return ok
}

// isOnlyOffline 与 QuoteDataCheckHelper.onlyContainsOffline 派生口径一致。
func isOnlyOffline(productTypeMap map[constants.ProductType]interface{}) bool {
	if len(productTypeMap) != 1 {
		return false
	}
	_, ok := productTypeMap[multienv.TradeProductTypeOffline]
	return ok
}

// isOnlyStandardProduct 与 QuoteDataCheckHelper.onlyContainsStandardProduct 派生口径一致：
// 仅包含 Online 与 Offline 两种标品。
func isOnlyStandardProduct(productTypeMap map[constants.ProductType]interface{}) bool {
	_, online := productTypeMap[multienv.TradeProductTypeOnline]
	_, offline := productTypeMap[multienv.TradeProductTypeOffline]
	if len(productTypeMap) == 2 && online && offline {
		return true
	}
	return isOnlyOnline(productTypeMap) || isOnlyOffline(productTypeMap)
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// RelatedChargeItemRule 关联计费项校验（方舟）。
//
// 与原 RelatedChargeItemChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / ItemValues / ItemContextMap / External.ProductInfoMap / External.ConfigTreeMap；
//   - Rule 仅做数据校验，不做任何 DB / RPC 查询；下游
//     quote_item_service.GetRelatedChargeItemsByLoaded 不再依赖 *gorm.DB。
type RelatedChargeItemRule struct{}

func (r *RelatedChargeItemRule) Key() string {
	return "BizDataRuleRelatedChargeItem"
}

func (r *RelatedChargeItemRule) Desc() string {
	return "关联计费项(方舟)校验：报价项关联计费项必须满足配置树定义。"
}

func (r *RelatedChargeItemRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyProductInfo,
		quote_context.QuoteContextKeyConfigTreeMap,
	}
}

func (r *RelatedChargeItemRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNRelatedChargeItemCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if !config.GetSwitchIsOpenByName(ctx, config.SwitchRelatedChargeItemChecker) {
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems
	itemContextMap := quoteCtx.Persisted.ItemContextMap
	productInfoMap := quoteCtx.External.ProductInfoMap
	configTreeMap := quoteCtx.External.ConfigTreeMap

	var chargeItemInfos []quote_item_service.ChargeItemInfo
	bizCtxMap := make(map[int64]*quote_item_service.RelatedChargeItemBizCtx, len(quoteItems))
	for _, quoteItem := range quoteItems {
		itemContext, ok := itemContextMap[quoteItem.Id]
		if !ok {
			return nil, i18nfmt.Errorf(ctx, "报价项上下文对象没有找到")
		}
		chargeItemInfos = append(chargeItemInfos, quote_item_service.ChargeItemInfo{
			TradeProduct:   itemContext.TradeProduct,
			ConfigCode:     itemContext.ConfigurationCode,
			ChargeItemCode: itemContext.ChargeItemCode,
			QuoteItemID:    quoteItem.Id,
		})
		bizCtxMap[quoteItem.Id] = &quote_item_service.RelatedChargeItemBizCtx{
			ItemCtx:     itemContext,
			ProductInfo: productInfoMap[itemContext.TradeProduct],
			ConfigTree:  configTreeMap[itemContext.GetConfigTreeKey()],
		}
	}
	getRelatedChargeItemsReq := quote_item_service.GetRelatedChargeItemsReq{
		QuoteID:         quote.Id,
		ChargeItemInfos: chargeItemInfos,
	}
	getRelatedChargeItemsResp, err := getRelatedChargeItemsReq.GetRelatedChargeItemsByLoaded(
		ctx, quote, quoteItems, bizCtxMap,
	)
	if err != nil {
		return nil, err
	}
	if getRelatedChargeItemsResp != nil && len(getRelatedChargeItemsResp.RelatedProductChargeItemInfos) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNRelatedChargeItemCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "关联计费项(方舟)校验失败")
		result.Detail = getRelatedChargeItemsResp.RelatedProductChargeItemInfos
		return result, nil
	}
	return result, nil
}

func (r *RelatedChargeItemRule) BlockLevel() string {
	return BlockLevelError
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// QuoteTypeRule —— 报价类型校验。
//
// 与原 QuoteData.QuoteTypeCheck 保持错误码与文案完全一致：
//   - QuoteType 必须在枚举映射中；
//   - PRM 报价仅支持 QuoteTypeNormal；
//   - 内部客户报价不支持 QuoteTypeProgressive。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsPrmQuote   ⇔ Quote.IsPrmQuote()
//   - IsInnerQuote ⇔ Quote.IsInnerQuote()
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type QuoteTypeRule struct{}

func (r *QuoteTypeRule) Key() string { return "BizDataRuleQuoteType" }
func (r *QuoteTypeRule) Desc() string {
	return "报价类型校验：枚举有效性 / 伙伴报价仅支持普通报价 / 内部客户不支持阶梯报价"
}
func (r *QuoteTypeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *QuoteTypeRule) BlockLevel() string { return BlockLevelError }

func (r *QuoteTypeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteTypeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if _, ok := multienv.GetQuoteTypeMapping()[quote.QuoteType]; !ok {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteTypeCheckFailed
		result.ErrorMsg = "报价类型枚举错误"
		return result, nil
	}
	if quote.IsPrmQuote() && quote.QuoteType != multienv.QuoteTypeNormal {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteTypeCheckFailed
		result.ErrorMsg = "伙伴报价只支持报价类型【普通报价】"
		return result, nil
	}
	if quote.IsInnerQuote() && quote.QuoteType == multienv.QuoteTypeProgressive {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteTypeCheckFailed
		result.ErrorMsg = "阶梯报价不支持内部客户报价"
		return result, nil
	}
	return result, nil
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// UnStandardDeliveryItemCostRule 手动添加非标品交付项成本&出厂价校验。
//
// 与原 UnStandardDeliveryItemCostChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / DeliveryItems / ItemCalMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明。
//
// 注意：原 checker 使用 quoteBizData.AllDeliveryItems（仅含交付项），此处对齐使用 Persisted.DeliveryItems。
type UnStandardDeliveryItemCostRule struct{}

func (r *UnStandardDeliveryItemCostRule) Key() string {
	return "BizDataRuleUnStandardDeliveryItemCost"
}

func (r *UnStandardDeliveryItemCostRule) Desc() string {
	return "手动添加非标品交付项成本&出厂价校验：" +
		"非配置清单报价单中，手动添加的非标品交付项必须存在算价结果，" +
		"且单位成本/出厂价均为固定金额且金额一致。"
}

func (r *UnStandardDeliveryItemCostRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyItemCalMap,
	}
}

func (r *UnStandardDeliveryItemCostRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNUnStandardDeliveryItemCostCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	if quote.IsConfigList() {
		return result, nil
	}
	deliveryItems := quoteCtx.Persisted.DeliveryItems
	itemCalMap := quoteCtx.Persisted.ItemCalMap

	invalidDeliveryItemIDsByQuoteItemID := make(map[int64][]int64)
	for _, deliveryItem := range deliveryItems {
		if !deliveryItem.IsManuelUnStandardDeliveryItem() {
			continue
		}
		itemCalculate, ok := itemCalMap[deliveryItem.Id]
		if !ok {
			invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong] = append(invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong], deliveryItem.Id)
			continue
		}
		unitCost := itemCalculate.GetUnitCost()
		factoryPrice := itemCalculate.GetFactoryPrice()
		if unitCost == nil || factoryPrice == nil {
			invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong] = append(invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong], deliveryItem.Id)
			continue
		}
		if unitCost.TotalCostFunction != constants.TotalCostFunctionFixedPrice {
			invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong] = append(invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong], deliveryItem.Id)
			continue
		}
		if factoryPrice.ExFactoryPriceFunction != constants.TotalCostFunctionFixedPrice {
			invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong] = append(invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong], deliveryItem.Id)
			continue
		}
		if unitCost.TotalCost != factoryPrice.ExFactoryPrice {
			invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong] = append(invalidDeliveryItemIDsByQuoteItemID[deliveryItem.ItemBelong], deliveryItem.Id)
			continue
		}
	}

	if len(invalidDeliveryItemIDsByQuoteItemID) > 0 {
		invalidQuoteItemIDs := make([]int64, 0, len(invalidDeliveryItemIDsByQuoteItemID))
		for quoteItemID := range invalidDeliveryItemIDsByQuoteItemID {
			invalidQuoteItemIDs = append(invalidQuoteItemIDs, quoteItemID)
		}
		result.Pass = false
		result.ErrorCode = errors.CodeNUnStandardDeliveryItemCostCheckFailed
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "手动添加非标品交付项成本&出厂价校验失败，报价项ID：%v", invalidQuoteItemIDs)
		result.Detail = invalidDeliveryItemIDsByQuoteItemID
		return result, nil
	}
	return result, nil
}

func (r *UnStandardDeliveryItemCostRule) BlockLevel() string {
	return BlockLevelError
}

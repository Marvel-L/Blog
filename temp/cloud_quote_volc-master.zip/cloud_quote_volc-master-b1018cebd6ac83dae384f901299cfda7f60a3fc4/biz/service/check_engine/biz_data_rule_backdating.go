package check_engine

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// BackdatingRule —— [开始日早于提单日] 倒签校验。
//
// 与原 QuoteData.BackdatingCheck 保持错误码与文案完全一致：
//   - 倒签场景仅支持线下纸质签约；
//   - 内部客户 / 项目制不支持倒签；
//   - BackdatingReason 必填且必须命中合法枚举；
//   - 部分原因要求 BackdatingContractNo 必填，且通过合同系统校验合同有效性。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - skipBackdatingCheck ⇔ Quote.IsInModifyProcess()（与 update_quote_detail.go:71 / quote_data_quote_gen.go:46 一致）；
//   - IsBackdating ⇔ 仅固定日期生效（PriceValidPeriod 为空）下，PriceValidPeriodStartTime 早于今日日初。
//
// 校验类 RPC contract_client.GetMetaDetail 按 §8.11 允许在 Rule 内直接调用。
// 仅依赖 Persisted.Quote。
type BackdatingRule struct{}

func (r *BackdatingRule) Key() string { return "BizDataRuleBackdating" }
func (r *BackdatingRule) Desc() string {
	return "倒签校验：[开始日早于提单日] 仅支持线下纸质签约；内部客户/项目制不支持；原因必填且合法；部分原因要求关联合同号且合同存在"
}
func (r *BackdatingRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *BackdatingRule) BlockLevel() string { return BlockLevelError }

func (r *BackdatingRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote

	// skipBackdatingCheck 与 update_quote_detail.go:71 / quote_data_quote_gen.go:46 一致：审批修改中跳过
	if quote.IsInModifyProcess() {
		return result, nil
	}

	// IsBackdating 派生口径：仅固定日期生效（PriceValidPeriod 为空）下，PriceValidPeriodStartTime 早于今日日初
	if !isBackdatingFromPersisted(quote) {
		return result, nil
	}

	if quote.OrderType != multienv.GetContractTypePaperContract() {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "合同[开始日早于提单日]只能支持线下纸质签约"
		return result, nil
	}
	if quote.TradeType.InnerCustomer() {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "内部客户不支持[开始日早于提单日]"
		return result, nil
	}
	if quote.QuoteType == multienv.QuoteTypeProjectBased {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "项目制不支持[开始日早于提单日]"
		return result, nil
	}
	if quote.BackdatingReason == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "[开始日早于提单日]时，原因不能为空"
		return result, nil
	}
	if _, exist := multienv.GetBackdatingReasonMap()[quote.BackdatingReason]; !exist {
		result.Pass = false
		result.ErrorCode = errors.CodeNBackDatingCheckFailed
		result.ErrorMsg = "[开始日早于提单日]原因非法"
		return result, nil
	}
	if _, exist := multienv.BackdatingReasonNeedContractMap()[quote.BackdatingReason]; exist {
		if quote.BackdatingContractNo == "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNBackDatingCheckFailed
			result.ErrorMsg = "[开始日早于提单日]合同编号不能为空"
			return result, nil
		}
		// 校验类 RPC：判定外部合同号有效性
		detail, err := contract_client.GetMetaDetail(ctx, quote.BackdatingContractNo)
		if err != nil {
			logs.CtxError(ctx, "GetMetaDetailFail, BackdatingContractNo=%s, err=%s", quote.BackdatingContractNo, err.Error())
			result.Pass = false
			result.ErrorCode = errors.CodeNBackDatingCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
		if detail == nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNBackDatingCheckFailed
			result.ErrorMsg = "合同编号对应合同信息不存在"
			return result, nil
		}
	}
	return result, nil
}

// isBackdatingFromPersisted 与 QuoteDataCheckHelper.IsBackdating 派生口径一致：
//   - 仅固定日期生效场景（PriceValidPeriod 为空）下判定；
//   - PriceValidPeriodStartTime 的"日初"早于今日"日初"即视为倒签。
func isBackdatingFromPersisted(quote *model.Quote) bool {
	if quote.PriceValidPeriod != "" {
		return false
	}
	if quote.PriceValidPeriodStartTime.IsZero() {
		return false
	}
	priceStartBeginning := util.ToBeginningOfDay(quote.PriceValidPeriodStartTime)
	nowBeginning := util.ToBeginningOfDay(time.Now())
	return priceStartBeginning.Before(nowBeginning)
}

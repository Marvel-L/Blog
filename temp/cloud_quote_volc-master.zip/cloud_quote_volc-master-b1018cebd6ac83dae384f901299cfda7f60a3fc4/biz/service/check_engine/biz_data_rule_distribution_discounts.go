package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// DistributionDiscountsRule 分销折扣校验。
//
// 与原 DistributionDiscountsChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / DeliveryItems / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 仅做数据校验，不做任何 DB / RPC 查询；
//   - 不再调用 item_context.GetDistributionDiscountsIllegal（其内部会重新构造
//     itemContext），改为直接复用预加载的 ItemContextMap，调用
//     itemContext.ValidateDistributionDiscounts(ctx, nil)（configTree 传 nil
//     时只做存在性/匹配性校验，与原 checker 行为一致）。
//
// 注意：原 checker 用 quoteBizData.GetAllItems()（含报价项 + 交付项，不含失效），
// 此处对齐使用 Persisted.QuoteItems + Persisted.DeliveryItems。
type DistributionDiscountsRule struct{}

func (r *DistributionDiscountsRule) Key() string {
	return "BizDataRuleDistributionDiscounts"
}

func (r *DistributionDiscountsRule) Desc() string {
	return "分销折扣校验：" +
		"1) 非 BP 分销-特殊折扣报价单，分销折扣不允许有值；" +
		"2) BP 分销-特殊折扣，非公有云报价项的分销折扣不允许有值；" +
		"3) 分销折扣层级需匹配分销商配置；" +
		"4) 分销折扣项必填且力度需满足规则。"
}

func (r *DistributionDiscountsRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *DistributionDiscountsRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributionDiscountsIllegal
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	// 仅 BP 分销-特殊折扣场景需要继续逐项校验；其它场景下，原 checker 通过
	// item_context.GetDistributionDiscountsIllegal 早退，此处对齐。
	quote := quoteCtx.Persisted.Quote
	if !quote.IsDistributionBizTypeCustom() {
		return result, nil
	}

	itemContextMap := quoteCtx.Persisted.ItemContextMap

	allItems := make([]*model.QuoteItem, 0, len(quoteCtx.Persisted.QuoteItems)+len(quoteCtx.Persisted.DeliveryItems))
	allItems = append(allItems, quoteCtx.Persisted.QuoteItems...)
	allItems = append(allItems, quoteCtx.Persisted.DeliveryItems...)

	var illegalItemIDs []int64
	for _, quoteItem := range allItems {
		itemContext, ok := itemContextMap[quoteItem.Id]
		if !ok || itemContext == nil {
			return nil, i18nfmt.Errorf(ctx, "QuoteItemValues not exist, quoteItemID=%d", quoteItem.Id)
		}
		if err := itemContext.ValidateDistributionDiscounts(ctx, nil); err != nil {
			illegalItemIDs = append(illegalItemIDs, quoteItem.Id)
		}
	}

	if len(illegalItemIDs) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNDistributionDiscountsIllegal
		result.ErrorMsg = "DistributionDiscounts illegal"
		result.Detail = illegalItemIDs
		return result, nil
	}
	return result, nil
}

func (r *DistributionDiscountsRule) BlockLevel() string {
	return BlockLevelError
}

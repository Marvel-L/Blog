package check_engine

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	quoteerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

func TestRelatedBusinessDiscountRebateGuaranteeSet(t *testing.T) {
	rebateSet, guaranteeItemSets := relatedBusinessDiscountRebateGuaranteeSet(
		model.RebateItemList{
			&model.RebateItem{QuoteItemID: 11, IsRebateWritten: constants.RebateWritten},
			&model.RebateItem{QuoteItemID: 12, IsRebateWritten: 0},
		},
		[]*model.GuaranteeItem{
			{GuaranteeType: multienv.GuaranteeTypePartial, RelatedQuoteItemId: "[101,102]"},
			{GuaranteeType: multienv.GuaranteeTypePartial, RelatedQuoteItemId: "[201]"},
			{GuaranteeType: 0, RelatedQuoteItemId: "[301]"},
		},
	)

	if !rebateSet[11] || rebateSet[12] {
		t.Fatalf("unexpected rebateSet: %#v", rebateSet)
	}
	if len(guaranteeItemSets) != 2 {
		t.Fatalf("unexpected guarantee item set count: %d", len(guaranteeItemSets))
	}
	if !guaranteeItemSets[0][101] || !guaranteeItemSets[0][102] || guaranteeItemSets[0][201] {
		t.Fatalf("unexpected first guarantee item set: %#v", guaranteeItemSets[0])
	}
	if !guaranteeItemSets[1][201] || guaranteeItemSets[1][101] {
		t.Fatalf("unexpected second guarantee item set: %#v", guaranteeItemSets[1])
	}
}

func TestRelatedBusinessDiscountMissingGuarantee(t *testing.T) {
	t.Run("same guarantee rule passes", func(t *testing.T) {
		got := relatedBusinessDiscountMissingGuarantee(
			[]map[int64]bool{{1: true, 2: true}},
			map[int64]int64{1: 2},
		)
		if len(got) != 0 {
			t.Fatalf("expected no missing guarantee, got %#v", got)
		}
	})

	t.Run("cross guarantee rule fails", func(t *testing.T) {
		got := relatedBusinessDiscountMissingGuarantee(
			[]map[int64]bool{
				{1: true},
				{2: true},
			},
			map[int64]int64{1: 2},
		)
		if got[1] != 2 || got[2] != 1 || len(got) != 2 {
			t.Fatalf("expected both related items missing in rule dimension, got %#v", got)
		}
	})
}

func TestRelatedBusinessDiscountRuleNeeds(t *testing.T) {
	t.Run("返回依赖键", func(t *testing.T) {
		mockey.PatchConvey("返回依赖键", t, func() {
			rule := &RelatedBusinessDiscountRule{}

			convey.So(rule.Needs(), convey.ShouldResemble, []quote_context.QuoteContextKey{
				quote_context.QuoteContextKeyQuote,
				quote_context.QuoteContextKeyQuoteItems,
				quote_context.QuoteContextKeyItemContextMap,
				quote_context.QuoteContextKeyRebateItemList,
				quote_context.QuoteContextKeyGuaranteeItems,
			})
		})
	})
}

func TestRelatedBusinessDiscountRuleCheck(t *testing.T) {
	rule := &RelatedBusinessDiscountRule{}

	t.Run("关联规则未开启时直接通过", func(t *testing.T) {
		mockey.PatchConvey("关联规则未开启", t, func() {
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{}).Build()

			result, err := rule.Check(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeTrue)
			convey.So(result.ErrorCode, convey.ShouldEqual, 0)
		})
	})

	t.Run("保底范围不一致时返回失败详情", func(t *testing.T) {
		mockey.PatchConvey("保底范围不一致", t, func() {
			quote := &model.Quote{}
			quote.Id = 1001
			quoteItems := []*model.QuoteItem{{}, {}}
			quoteItems[0].Id = 11
			quoteItems[1].Id = 12
			quoteCtx := &quote_context.QuoteContext{
				Persisted: quote_context.QuoteContextPersisted{
					Quote:      quote,
					QuoteItems: quoteItems,
					ItemContextMap: map[int64]*item_context.ItemContext{
						11: {},
						12: {},
					},
					GuaranteeItems: []*model.GuaranteeItem{
						{
							GuaranteeType:      multienv.GuaranteeTypePartial,
							RelatedQuoteItemId: "[11]",
						},
					},
				},
			}
			mockey.Mock(config.GetSwitchByName).Return(&config.SwitchModel{
				IsOpen:    true,
				WhiteList: []string{"all"},
			}).Build()
			mockey.Mock(relatedBusinessDiscountRepeatKeyMap).Return(map[string]int64{"repeat-key": 11}).Build()
			mockey.Mock(quote_item_service.GetRelatedRuleMap).Return(nil).Build()
			mockey.Mock(relatedBusinessDiscountRelatedItemMap).Return(map[int64]int64{
				11: 12,
				12: 11,
			}).Build()

			result, err := rule.Check(context.Background(), quoteCtx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result.Pass, convey.ShouldBeFalse)
			convey.So(result.ErrorCode, convey.ShouldEqual, quoteerrors.CodeNRelatedQuoteItemNotSameDiscountType)
			convey.So(result.ErrorMsg, convey.ShouldEqual, "报价项商务优惠缺失")
			convey.So(result.Detail, convey.ShouldResemble, &missingBusinessDiscountDetail{
				MissingRebateItemIDMap:    map[int64]int64{},
				MissingRebateReasonMap:    map[int64]string{},
				MissingGuaranteeItemIDMap: map[int64]int64{12: 11},
			})
		})
	})
}

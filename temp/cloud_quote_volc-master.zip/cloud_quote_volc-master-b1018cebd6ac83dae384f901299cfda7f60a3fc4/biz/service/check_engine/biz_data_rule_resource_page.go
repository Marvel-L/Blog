package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
)

// ResourcePageRule 报价资源单一致性校验。
//
// 来源：原 ResourcePageChecker（resource_page_service.ResourcePageDataCheck）。
// 仅当报价单 SupportResourcePage 且非 BytePlus 环境生效。校验内容：
//  1. 没填资源单时，若报价项实时匹配出资源卡且配置要求强制填写，报错；
//  2. 填了资源单时，对比"实时匹配资源卡"与"DB 资源卡"，若 DB 缺少必填资源卡，报错。
//
// 与原 checker 的差异：
//   - 资源单 / DB 资源卡 resp / 实时匹配资源卡列表均由 QuoteContext 加载；
//   - 写副作用（软删过期资源卡、空时软删资源单）按 §9 剥离到入口层
//     `op_check_dispatch.preCleanExpiredResourceItemsIfSupport`。
type ResourcePageRule struct{}

func (r *ResourcePageRule) Key() string {
	return "BizDataRuleResourcePage"
}

func (r *ResourcePageRule) Desc() string {
	return "报价资源单校验：" +
		"1) 当报价项实时匹配出资源卡且配置要求强制填写时，必须存在资源单；" +
		"2) 已存在资源单时，DB 中不能缺失实时匹配出的资源卡。"
}

func (r *ResourcePageRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyResourcePage,
		quote_context.QuoteContextKeyResourceItemsFromQuote,
		quote_context.QuoteContextKeyResourceItemRespsFromDB,
	}
}

func (r *ResourcePageRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return result, nil
	}
	if multienv.IsBytePlus() {
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if !quote.SupportResourcePage(ctx) {
		return result, nil
	}

	itemRespListFromItem := quoteCtx.Persisted.ResourceItemsFromQuote
	resourcePage := quoteCtx.Persisted.ResourcePage

	// 没有填写资源单
	if resourcePage == nil || resourcePage.Id == 0 {
		mandatoryFilling := config.GetEnumConfig(ctx, constants.ResourcePage)[constants.MandatoryFilling] == "true"
		if len(itemRespListFromItem) > 0 && mandatoryFilling {
			result.Pass = false
			result.ErrorCode = errors.CodeNResourcePageCheckFailed
			result.ErrorMsg = "报价资源单信息不存在，请重新填写并保存"
			return result, nil
		}
		return result, nil
	}

	itemRespListFromDB := quoteCtx.Persisted.ResourceItemRespsFromDB

	resourceItemFromItemMap := map[string]*model.ResourceItemResp{}
	for _, itemResp := range itemRespListFromItem {
		resourceItemFromItemMap[itemResp.GetResourceCardCheckKey()] = itemResp
		for _, subResourceItem := range itemResp.SubResourceItems {
			resourceItemFromItemMap[subResourceItem.GetResourceCardCheckKey()] = itemResp
		}
	}
	resourceItemFromDBMap := map[string]*model.ResourceItemResp{}
	for _, itemResp := range itemRespListFromDB {
		resourceItemFromDBMap[itemResp.GetResourceCardCheckKey()] = itemResp
		for _, subResourceItem := range itemResp.SubResourceItems {
			resourceItemFromDBMap[subResourceItem.GetResourceCardCheckKey()] = subResourceItem
		}
	}

	for _, resourceItem := range resourceItemFromItemMap {
		if _, ok := resourceItemFromDBMap[resourceItem.GetResourceCardCheckKey()]; !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNResourcePageCheckFailed
			result.ErrorMsg = "报价资源卡信息有缺失，请重新填写并保存"
			return result, nil
		}
	}

	return result, nil
}

func (r *ResourcePageRule) BlockLevel() string {
	return BlockLevelError
}

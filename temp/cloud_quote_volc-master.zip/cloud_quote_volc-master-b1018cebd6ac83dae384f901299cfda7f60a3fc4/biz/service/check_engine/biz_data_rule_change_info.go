package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ChangeInfoRule —— 报价单变更内容长度/场景校验。
//
// 与原 QuoteData.ChangeInfoCheck 保持错误码与文案完全一致：
//   - 仅当报价单类型为变更时才允许填写 ChangeInfo；
//   - 变更内容长度不超过 1000。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type ChangeInfoRule struct{}

func (r *ChangeInfoRule) Key() string { return "BizDataRuleChangeInfo" }
func (r *ChangeInfoRule) Desc() string {
	return "报价单变更内容校验：仅当报价单类型为变更时才允许填写 ChangeInfo，且长度不超过 1000"
}
func (r *ChangeInfoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *ChangeInfoRule) BlockLevel() string { return BlockLevelError }

func (r *ChangeInfoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNChangeInfoCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.ChangeInfo == "" {
		return result, nil
	}
	if quote.QuoteScene != multienv.SceneChangeQuote && quote.QuoteScene != multienv.SceneChangeSupplyAgreement {
		result.Pass = false
		result.ErrorCode = errors.CodeNChangeInfoCheckFailed
		result.ErrorMsg = "仅当报价单类型为变更时，才允许填写变更内容"
		return result, nil
	}
	if len([]rune(quote.ChangeInfo)) > 1000 {
		result.Pass = false
		result.ErrorCode = errors.CodeNChangeInfoCheckFailed
		result.ErrorMsg = "变更内容长度最大1000"
		return result, nil
	}
	return result, nil
}

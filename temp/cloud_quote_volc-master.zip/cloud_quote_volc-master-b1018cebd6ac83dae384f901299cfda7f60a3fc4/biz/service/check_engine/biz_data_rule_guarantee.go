package check_engine

import (
	"context"
	stderrors "errors"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/guarantee_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// GuaranteeRule 是旧版校验引擎的保底整单规则。
//
// 数据统一从报价上下文读取；当前单依赖由 QuoteContextLoader 声明。
// 补充协议明确选择结转时按需构造父单报价上下文，不把父单数据平铺到当前单。
// 新版基础引擎同时注册完整配置校验和各专项规则，复用同一套保底领域校验能力。
type GuaranteeRule struct{}

func (r *GuaranteeRule) Key() string {
	return "BizDataRuleGuarantee"
}

func (r *GuaranteeRule) Desc() string {
	return "保底信息校验：" +
		"1) 当前报价单需支持保底；" +
		"2) 部分保底类型必须绑定有效报价项；" +
		"3) 周期保底起止时间需在报价单生效/失效月份范围内；" +
		"4) 抵扣计费项不支持参与保底；" +
		"5) 保底报价项包含特定白名单商品时，保底采购总席位数必须大于 0；" +
		"6) 非补充协议不允许填写保底是否结转，补充协议结转需关联有效父单根规则；" +
		"7) 直接子规则单位保底金额加总不能超过父规则单位保底金额；" +
		"8) 父规则为部分报价项参与保底时，子规则也必须为部分报价项参与保底；" +
		"9) 父子保底规则三元组不能完全一致。"
}

func (r *GuaranteeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyGuaranteeItems,
	}
}

func (r *GuaranteeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNNotSupportGuarantee
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	guaranteeItems := quoteCtx.Persisted.GuaranteeItems
	if len(guaranteeItems) == 0 {
		return result, nil
	}
	parentCarryForwardData, err := r.loadParentCarryForwardQuoteData(ctx, quoteCtx.Persisted.Quote, guaranteeItems)
	if err != nil {
		return nil, err
	}
	for _, guaranteeItem := range guaranteeItems {
		if err := r.checkOne(ctx, result, quoteCtx, guaranteeItem, parentCarryForwardData); err != nil {
			return nil, err
		}
		if !result.Pass {
			return result, nil
		}
	}
	if err := r.checkRuleTreeForSubmit(ctx, result, quoteCtx); err != nil {
		return nil, err
	}
	if !result.Pass {
		return result, nil
	}
	return result, nil
}

// loadParentCarryForwardQuoteData 在存在显式结转选择时加载父单结转校验数据。
func (r *GuaranteeRule) loadParentCarryForwardQuoteData(ctx context.Context, quote *model.Quote, guaranteeItems []*model.GuaranteeItem) (*guarantee_item_service.GuaranteeCarryForwardQuoteData, error) {
	if quote == nil || quote.ParentQuoteID == 0 || !hasExplicitCarryForwardGuarantee(guaranteeItems) {
		return nil, nil
	}
	parentQuoteCtx, err := loadParentQuoteContextForGuaranteeCarryForward(ctx, quote)
	if err != nil {
		return nil, err
	}
	if parentQuoteCtx == nil || parentQuoteCtx.Persisted.Quote == nil {
		return nil, nil
	}
	return &guarantee_item_service.GuaranteeCarryForwardQuoteData{
		Quote:          parentQuoteCtx.Persisted.Quote,
		GuaranteeItems: parentQuoteCtx.Persisted.GuaranteeItems,
		QuoteItems:     parentQuoteCtx.Persisted.QuoteItems,
		ItemValues:     parentQuoteCtx.Persisted.ItemValues,
	}, nil
}

// loadParentQuoteContextForGuaranteeCarryForward 加载补充协议父单的保底、报价项和属性上下文。
func loadParentQuoteContextForGuaranteeCarryForward(ctx context.Context, quote *model.Quote) (*quote_context.QuoteContext, error) {
	if quote == nil || !quote.IsSupplyAgreement() || quote.ParentQuoteID == 0 {
		return nil, nil
	}
	return quote_context.NewQuoteContextLoader(quote.ParentQuoteID, nil).
		WithKeys(
			quote_context.QuoteContextKeyQuote,
			quote_context.QuoteContextKeyQuoteItems,
			quote_context.QuoteContextKeyItemValues,
			quote_context.QuoteContextKeyGuaranteeItems,
		).
		Load(ctx)
}

// hasExplicitCarryForwardGuarantee 判断当前单是否存在需要执行结转校验的保底规则。
func hasExplicitCarryForwardGuarantee(guaranteeItems []*model.GuaranteeItem) bool {
	for _, guaranteeItem := range guaranteeItems {
		if guaranteeItem != nil && guaranteeItem.CarryForward != model.CarryForwardNone {
			return true
		}
	}
	return false
}

// checkOne 执行单条保底规则的送审基础校验。
func (r *GuaranteeRule) checkOne(ctx context.Context, result *CheckResult, quoteCtx *quote_context.QuoteContext, guaranteeItem *model.GuaranteeItem, parentCarryForwardData *guarantee_item_service.GuaranteeCarryForwardQuoteData) error {
	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems

	supportGuarantee, err := quote.SupportGuarantee(ctx)
	if err != nil {
		return err
	}
	if !supportGuarantee {
		r.setFailResult(result, errors.CodeNNotSupportGuarantee, i18nfmt.Sprintf(ctx, "当前报价单不支持保底，请删除保底信息"), guaranteeItem)
		return nil
	}
	if guaranteeItem.GuaranteeType == multienv.GuaranteeTypePartial && len(guaranteeItem.GetRelatedQuoteItemId()) == 0 {
		r.setFailResult(result, errors.CodeNGuaranteeNoQuoteItem, i18nfmt.Sprintf(ctx, "当前报价单保底信息未绑定有效报价项，请绑定报价项或删除保底信息"), guaranteeItem)
		return nil
	}
	if guaranteeItem.GuaranteeCategory == multienv.GuaranteeCategoryCycle {
		quoteBeginMonth := quote.PriceValidPeriodStartTime.Format(util.DateFormatMonth)
		quoteEndMonth := quote.PriceValidPeriodEndTime.Format(util.DateFormatMonth)
		if guaranteeItem.GuaranteeStartTime < quoteBeginMonth || guaranteeItem.GuaranteeEndTime > quoteEndMonth {
			r.setFailResult(result, errors.CodeNQuoteItemInvalidProductInvalid,
				i18nfmt.Sprintf(ctx, "保底规则(%d)有效期(%s~%s)超出合同有效期(%s~%s),请修改保底有效期,确保其在合同有效期范围内。",
					guaranteeItem.Id, guaranteeItem.GuaranteeStartTime, guaranteeItem.GuaranteeEndTime, quoteBeginMonth, quoteEndMonth), guaranteeItem)
			return nil
		}
	}
	relatedItemIds := util.SliceToMap(guaranteeItem.GetRelatedQuoteItemId())
	for _, quoteItem := range quoteItems {
		if !quoteItem.IsSpDeductItem() {
			continue
		}
		if _, ok := relatedItemIds[quoteItem.Id]; ok {
			r.setFailResult(result, errors.CodeNDeductNotSupportGuarantee, i18nfmt.Sprintf(ctx, "抵扣计费项【%d】不支持参与保底", quoteItem.Id), guaranteeItem)
			return nil
		}
	}
	// 数量校验
	if err := guarantee_item_service.ValidateGuaranteeTotalSeats(ctx, quoteItems, guaranteeItem); err != nil {
		r.setFailResult(result, errors.CodeNGuaranteeTotalSeatsInvalid, getGuaranteeTotalSeatsErrorMsg(ctx, err), guaranteeItem)
		return nil
	}
	carryForwardQuoteData := map[int64]*guarantee_item_service.GuaranteeCarryForwardQuoteData{
		quote.Id: {
			Quote:          quote,
			GuaranteeItems: []*model.GuaranteeItem{guaranteeItem},
			QuoteItems:     quoteItems,
			ItemValues:     quoteCtx.Persisted.ItemValues,
		},
	}
	if parentCarryForwardData != nil {
		carryForwardQuoteData[quote.ParentQuoteID] = parentCarryForwardData
	}
	if err := guarantee_item_service.ValidateGuaranteeCarryForward(ctx, nil, quote, guaranteeItem,
		guarantee_item_service.WithGuaranteeCarryForwardQuoteDataMap(carryForwardQuoteData),
	); err != nil {
		var apiErr *errors.APIErrorStruct
		if stderrors.As(err, &apiErr) {
			r.setFailResult(result, errors.ErrorCodeN(apiErr.GetCodeInt()), i18nfmt.Sprint(ctx, err.Error()), guaranteeItem)
			return nil
		}
		return err
	}
	return nil
}

func (r *GuaranteeRule) BlockLevel() string {
	return BlockLevelError
}

// checkRuleTreeForSubmit 执行多保底规则树送审校验，并把结构化错误写入 Detail。
func (r *GuaranteeRule) checkRuleTreeForSubmit(ctx context.Context, result *CheckResult, quoteCtx *quote_context.QuoteContext) error {
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return nil
	}
	err := guarantee_item_service.ValidateGuaranteeRuleTreeForSubmit(
		ctx,
		quoteCtx.Persisted.Quote,
		quoteCtx.Persisted.GuaranteeItems,
		quoteCtx.Persisted.QuoteItems,
	)
	if err == nil {
		return nil
	}
	var apiErr errors.APIError
	if stderrors.As(err, &apiErr) && apiErr.GetCodeInt() == int(errors.CodeNTccConfigNotFound) {
		return err
	}
	code, msg := getGuaranteeRuleTreeError(ctx, err)
	r.setFailResult(result, code, msg, nil)
	detail := guarantee_item_service.GetGuaranteeRuleTreeErrorDetail(err)
	if detail == nil {
		detail = &guarantee_item_service.GuaranteeRuleTreeErrorDetail{
			Reason:           string(guarantee_item_service.GuaranteeRuleTreeErrorReasonCheckFailed),
			GuaranteeItemIDs: collectGuaranteeItemIDs(quoteCtx.Persisted.GuaranteeItems),
		}
	}
	result.Detail = detail
	return nil
}

func (r *GuaranteeRule) setFailResult(result *CheckResult, code errors.ErrorCodeN, msg string, guaranteeItem *model.GuaranteeItem) {
	result.Pass = false
	result.ErrorCode = code
	result.ErrorMsg = msg
	if guaranteeItem != nil {
		result.Detail = []int64{guaranteeItem.Id}
	}
}

// getGuaranteeRuleTreeError 将规则树校验错误转换为 check engine 结果错误码和文案。
func getGuaranteeRuleTreeError(ctx context.Context, err error) (errors.ErrorCodeN, string) {
	code := errors.CodeNGuaranteeRuleTreeInvalid
	var apiErr errors.APIError
	if stderrors.As(err, &apiErr) {
		if apiErr.GetCodeInt() != 0 {
			code = errors.ErrorCodeN(apiErr.GetCodeInt())
		}
		return code, fmt.Sprintf(apiErr.GetMessage(ctx, nil), apiErr.GetArgs()...)
	}
	return code, i18nfmt.Sprint(ctx, err.Error())
}

func getGuaranteeTotalSeatsErrorMsg(ctx context.Context, err error) string {
	if apiErr, ok := err.(errors.APIError); ok {
		return fmt.Sprintf(apiErr.GetMessage(ctx, nil), apiErr.GetArgs()...)
	}
	return err.Error()
}

// collectGuaranteeItemIDs 收集有效保底规则 ID，用于兜底错误详情。
func collectGuaranteeItemIDs(guaranteeItems []*model.GuaranteeItem) []int64 {
	var ids []int64
	for _, guaranteeItem := range guaranteeItems {
		if guaranteeItem == nil || guaranteeItem.Id == 0 {
			continue
		}
		ids = append(ids, guaranteeItem.Id)
	}
	return ids
}

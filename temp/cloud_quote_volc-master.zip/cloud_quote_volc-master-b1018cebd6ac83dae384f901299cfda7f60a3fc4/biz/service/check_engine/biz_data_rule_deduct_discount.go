package check_engine

import (
	"context"
	"strconv"
	"strings"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/price_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// DeductDiscountRule 抵扣报价项折扣校验。
//
// 来源：原 DeductDiscountChecker。
// 校验目标：抵扣报价项的折扣不能高于以下三个参考值（任一不通过即异常）：
//  1. SP 包内对应「计费项 + 计费方式」的官网系数（DiscountRate）；
//  2. 本单内同一 RepeatCheckKeyWithoutSpDeduct 命中的按量计费报价项折扣；
//  3. 当无法在本单内匹配按量计费时，参考合同价折扣（多账号取最低）。
//
// 与原 checker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - `price_client.ListContractDiscountRaw` 属于校验时按需 RPC，与报价单上下文非强关联，
//     遵循 §11 校验类调用允许在 Rule 内直接执行的约定，不再绕一层 loader；
//   - SP 抵扣计费项缓存 `SpDeductChargeItemsCache.GetSpDeductChargeItemInfo` 是本地内存读，
//     同样在 Rule 内直接执行。
type DeductDiscountRule struct{}

// deductDiscountIllegalInfo 抵扣折扣异常信息。
// 与原 DeductDiscountIllegalInfo 字段一致，仅命名空间不同。
type deductDiscountIllegalInfo struct {
	QuoteItemID                     int64
	RelatedItemID                   int64
	DeductItemDiscount              string
	QuoteItemDiscount               string
	QuoteItemDiscountItemID         int64
	ContractPriceDiscount           string
	ContractPriceDiscountContractNo string
	DeductChargeItemDiscount        string
}

type deductQuoteDiscountInfo struct {
	QuoteItemID       int64
	QuoteItemDiscount decimal.Decimal
}

type deductContractPriceDiscountInfo struct {
	ContractNo            string
	ContractPriceDiscount decimal.Decimal
}

func (r *DeductDiscountRule) Key() string {
	return "BizDataRuleDeductDiscount"
}

func (r *DeductDiscountRule) Desc() string {
	return "抵扣报价项折扣校验：" +
		"1) 抵扣报价项折扣不得高于其 SP 包对应「计费项 + 计费方式」的官网系数；" +
		"2) 当存在同等口径的本单按量计费报价项时，抵扣折扣不得高于该本单按量折扣；" +
		"3) 当本单内不存在按量计费时，抵扣折扣不得高于多账号最低合同价折扣。"
}

func (r *DeductDiscountRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *DeductDiscountRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDeductDiscountIllegal
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if len(quoteCtx.Persisted.QuoteItems) == 0 || len(quoteCtx.Persisted.ItemContextMap) == 0 {
		return result, nil
	}

	itemContextMap := quoteCtx.Persisted.ItemContextMap
	var normalQuoteItems, deductQuoteItems []*model.QuoteItem
	for _, quoteItem := range quoteCtx.Persisted.QuoteItems {
		if quoteItem == nil {
			continue
		}
		if quoteItem.IsSpDeductItem() {
			deductQuoteItems = append(deductQuoteItems, quoteItem)
		} else {
			normalQuoteItems = append(normalQuoteItems, quoteItem)
		}
	}
	if len(deductQuoteItems) == 0 {
		return result, nil
	}

	// 构建本单按量 RepeatCheckKey -> normalItemID 映射
	normalItemKeyMap := map[string]int64{}
	for _, quoteItem := range normalQuoteItems {
		itemCtx, ok := itemContextMap[quoteItem.Id]
		if !ok || itemCtx == nil {
			continue
		}
		for _, repeatCheckKey := range itemCtx.GetRepeatCheckKeyWithoutSpDeduct() {
			normalItemKeyMap[repeatCheckKey] = itemCtx.ItemID
		}
	}

	var (
		quoteDiscountMap  = map[int64]*deductQuoteDiscountInfo{}  // 本单按量折扣
		deductDiscountMap = map[int64]decimal.Decimal{}           // SP 包官网系数
		contractQueryMap  = map[int64]*item_context.ItemContext{} // 需要查合同价的抵扣报价项
	)

	for _, quoteItem := range deductQuoteItems {
		deductItemCtx, ok := itemContextMap[quoteItem.Id]
		if !ok || deductItemCtx == nil {
			continue
		}
		// 数据兜底：原 checker 在关联 SP 包报价项缺失时直接报 ErrBadRequestError；
		// 这里保持一致语义，按系统错误返回。
		if itemContextMap[deductItemCtx.RelatedItemID] == nil {
			return nil, errors.ErrBadRequestError.WithArgs("关联SP包报价项不存在")
		}
		if deductItemCtx.IsExactChargeItem() {
			if spDeductChargeItemInfo := product_config_parser.SpDeductChargeItemsCache.GetSpDeductChargeItemInfo(
				deductItemCtx.SpPkgInfo,
				deductItemCtx.TradeProduct,
				deductItemCtx.ChargeItemCode,
				deductItemCtx.ChargeMethodCode,
			); spDeductChargeItemInfo != nil && !spDeductChargeItemInfo.DiscountRate.IsZero() {
				deductDiscountMap[deductItemCtx.ItemID] = spDeductChargeItemInfo.DiscountRate
			}
		}
		// 本单按量优先于合同价：先查本单内同口径按量折扣
		quoteExist := false
		for _, repeatCheckKey := range deductItemCtx.GetRepeatCheckKeyWithoutSpDeduct() {
			normalItemID, ok := normalItemKeyMap[repeatCheckKey]
			if !ok {
				continue
			}
			normalItemCtx := itemContextMap[normalItemID]
			if normalItemCtx == nil || normalItemCtx.Discount == nil {
				continue
			}
			discount, ok := convertDeductDiscount(ctx, normalItemCtx, normalItemCtx.Discount.PricingFunction, normalItemCtx.Discount.UnitPrice)
			if !ok {
				continue
			}
			quoteDiscountMap[deductItemCtx.ItemID] = &deductQuoteDiscountInfo{
				QuoteItemID:       normalItemCtx.ItemID,
				QuoteItemDiscount: discount,
			}
			quoteExist = true
			break
		}
		if !quoteExist {
			contractQueryMap[deductItemCtx.ItemID] = deductItemCtx
		}
	}

	contractDiscountMap, err := r.getContractDiscounts(ctx, quoteCtx.Persisted.Quote, contractQueryMap)
	if err != nil {
		return nil, err
	}
	logs.CtxInfo(ctx, "DeductDiscountRule compare info , quoteDiscountMap : %s", util.GetJsonStr(quoteDiscountMap))
	logs.CtxInfo(ctx, "DeductDiscountRule compare info , contractDiscountMap : %s", util.GetJsonStr(contractDiscountMap))
	logs.CtxInfo(ctx, "DeductDiscountRule compare info , deductDiscountMap : %s", util.GetJsonStr(deductDiscountMap))

	var illegalItems []int64
	var illegalInfos []*deductDiscountIllegalInfo
	for _, quoteItem := range deductQuoteItems {
		itemCtx, ok := itemContextMap[quoteItem.Id]
		if !ok || itemCtx == nil || itemCtx.Discount == nil {
			continue
		}
		var (
			illegal     = false
			illegalInfo = &deductDiscountIllegalInfo{
				QuoteItemID:        itemCtx.ItemID,
				RelatedItemID:      itemCtx.RelatedItemID,
				DeductItemDiscount: itemCtx.Discount.UnitPrice.String(),
			}
		)
		if deductDiscount, ok := deductDiscountMap[itemCtx.ItemID]; ok {
			if itemCtx.Discount.UnitPrice.GreaterThan(deductDiscount) {
				illegalInfo.DeductChargeItemDiscount = deductDiscount.String()
				illegal = true
			}
		}
		if quoteDiscountInfo, ok := quoteDiscountMap[itemCtx.ItemID]; ok {
			if itemCtx.Discount.UnitPrice.GreaterThan(quoteDiscountInfo.QuoteItemDiscount) {
				illegalInfo.QuoteItemDiscountItemID = quoteDiscountInfo.QuoteItemID
				illegalInfo.QuoteItemDiscount = quoteDiscountInfo.QuoteItemDiscount.String()
				illegal = true
			}
		} else if contractDiscountInfo, ok := contractDiscountMap[itemCtx.ItemID]; ok && contractDiscountInfo != nil {
			if itemCtx.Discount.UnitPrice.GreaterThan(contractDiscountInfo.ContractPriceDiscount) {
				illegalInfo.ContractPriceDiscountContractNo = contractDiscountInfo.ContractNo
				illegalInfo.ContractPriceDiscount = contractDiscountInfo.ContractPriceDiscount.String()
				illegal = true
			}
		}
		if illegal {
			illegalItems = append(illegalItems, itemCtx.ItemID)
			illegalInfos = append(illegalInfos, illegalInfo)
		}
	}
	if len(illegalInfos) != 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNDeductDiscountIllegal
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "抵扣报价项 %v 折扣异常", illegalItems)
		result.Detail = illegalInfos
		return result, nil
	}
	return result, nil
}

func (r *DeductDiscountRule) BlockLevel() string {
	return BlockLevelError
}

// getContractDiscounts 按 quote.CustomerDetail 中每个 accountID 调用
// price_client.ListContractDiscountRaw，挑出每个抵扣报价项最低的合同价折扣。
// 与原 DeductDiscountChecker.getContractDiscounts 一一对齐。
func (r *DeductDiscountRule) getContractDiscounts(
	ctx context.Context,
	quote *model.Quote,
	itemContexts map[int64]*item_context.ItemContext,
) (map[int64]*deductContractPriceDiscountInfo, error) {
	contractDiscountMap := map[int64]*deductContractPriceDiscountInfo{}
	if quote == nil || quote.CustomerDetail == "" || len(itemContexts) == 0 {
		return contractDiscountMap, nil
	}
	for _, accountID := range strings.Split(quote.CustomerDetail, ",") {
		var contractQueryReqs []*price_client.BatchQueryItem
		for _, itemCtx := range itemContexts {
			var payType string
			if payTypeIn, ok := multienv.ContractPriceCanPrePayMapping[itemCtx.CanPrePayCode]; ok {
				payType = payTypeIn
			}
			contractQueryReqs = append(contractQueryReqs, &price_client.BatchQueryItem{
				ExternalID:            strconv.FormatInt(itemCtx.ItemID, 10),
				AccountID:             accountID,
				Product:               itemCtx.TradeProduct,
				PayType:               payType,
				ConfigurationCategory: itemCtx.ConfigCategoryCode,
				Configuration:         itemCtx.ConfigurationCode,
				BillingMethodCode:     itemCtx.ChargeMethodCode,
				RegionCode:            itemCtx.RegionCode,
				ChargeElementCode:     itemCtx.ChargeUnitCode,
				PriceFactor:           itemCtx.PriceFactorCode,
				ChargeItemCode:        itemCtx.ChargeItemCode,
				SellingMode:           itemCtx.SellingModeCode,
			})
		}
		contractDiscounts, err := price_client.ListContractDiscountRaw(ctx, contractQueryReqs)
		if err != nil {
			return nil, err
		}
		for _, contractDiscount := range contractDiscounts {
			itemID, _ := strconv.ParseInt(contractDiscount.ExternalID, 10, 64)
			itemCtx := itemContexts[itemID]
			if itemCtx == nil {
				continue
			}
			unitPrice, _ := decimal.NewFromString(contractDiscount.UnitPrice)
			discount, ok := convertDeductDiscount(ctx, itemCtx, contractDiscount.BillingFunction, unitPrice)
			if !ok {
				continue
			}
			existDiscount := contractDiscountMap[itemID]
			if existDiscount == nil || discount.LessThan(existDiscount.ContractPriceDiscount) {
				contractDiscountMap[itemID] = &deductContractPriceDiscountInfo{
					ContractNo:            contractDiscount.ContractNo,
					ContractPriceDiscount: discount,
				}
			}
		}
	}
	return contractDiscountMap, nil
}

// convertDeductDiscount 将「计费函数 + 单价」转为可比折扣，与
// `DeductDiscountChecker.convertDiscount` 一一对齐。
func convertDeductDiscount(
	ctx context.Context,
	itemCtx *item_context.ItemContext,
	pricingFunction string,
	unitPrice decimal.Decimal,
) (decimal.Decimal, bool) {
	if unitPrice.IsZero() {
		return decimal.Zero, false
	}
	if pricingFunction == constants.DiscountFunctionSimpleDiscount {
		return unitPrice, true
	}
	if pricingFunction == constants.DiscountFunctionFixedPrice {
		priceInfo, _ := itemCtx.GetDisplayPriceInfo(ctx)
		realPriceInfo := itemCtx.GetRealPriceInfo(priceInfo)
		if realPriceInfo == nil || realPriceInfo.PricingFunction != constants.PricingFunctionFixedPrice || realPriceInfo.Price.IsZero() {
			return decimal.Zero, false
		}
		return unitPrice.Div(realPriceInfo.Price), true
	}
	return decimal.Zero, false
}

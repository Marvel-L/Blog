package check_engine

import (
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/coupon_validation"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

// FullQuoteCouponOriginalBillProductRule 校验原价口径金额返券仅使用 AI 商品。
type FullQuoteCouponOriginalBillProductRule struct{}

func (r *FullQuoteCouponOriginalBillProductRule) Key() string {
	return "BizDataRuleFullQuoteCouponOriginalBillProduct"
}

func (r *FullQuoteCouponOriginalBillProductRule) Desc() string {
	return "账单原价金额口径的金额返券仅支持 AI 商品。"
}

func (r *FullQuoteCouponOriginalBillProductRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyCouponList,
		quote_context.QuoteContextKeyProductInfo,
	}
}

func (r *FullQuoteCouponOriginalBillProductRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil {
		return result, nil
	}
	for _, coupon := range quoteCtx.Persisted.CouponList {
		if coupon == nil ||
			(coupon.RebateCouponWay != couponconfigconst.RebateCouponWayByAmount &&
				coupon.RebateCouponWay != couponconfigconst.RebateCouponWayByAmountPercent) {
			continue
		}

		var triggerInfo model.TriggerInfo
		if err := json.Unmarshal([]byte(coupon.TriggerInfo), &triggerInfo); err != nil {
			logs.CtxError(ctx, "[FullQuoteCouponOriginalBillProductRule] unmarshal trigger info failed, couponID=%d, err=%s", coupon.Id, err.Error())
			return failCheckResult(result, errors.ErrCustomerError.WithArgs("代金券触发条件解析失败")), nil
		}
		if apiErr := coupon_validation.ValidateOriginalBillCouponAIProducts(
			coupon.RebateCouponWay,
			coupon.BillCaliber,
			&triggerInfo,
			quoteCtx.External.ProductInfoMap,
		); apiErr != nil {
			return failCheckResult(result, apiErr), nil
		}
	}
	return result, nil
}

func (r *FullQuoteCouponOriginalBillProductRule) BlockLevel() string { return BlockLevelError }

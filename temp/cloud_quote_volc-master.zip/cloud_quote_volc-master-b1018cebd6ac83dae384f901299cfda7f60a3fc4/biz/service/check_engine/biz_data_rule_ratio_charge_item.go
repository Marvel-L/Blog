package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// RatioChargeItemRule 比例计费项校验。
//
// 校验逻辑：
//  1. 找出所有比例计费项（PricingFunction=PricingFunctionRelatedChargeItemRatio）
//  2. 找出比例关联计费项（priceInfo.RelatedChargeItems）
//  3. 比例计费项所在解决方案下的计费项，必须至少存在一个属于比例关联计费项；
//     否则报错 "未添加比例关联计费项，请返回'商品折扣页'查看'比例关联计费项'并添加"。
//
// 与原 RatioChargeItemChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems / ItemValues / ItemContextMap / External.PriceInfoMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明。
type RatioChargeItemRule struct{}

func (r *RatioChargeItemRule) Key() string {
	return "BizDataRuleRatioChargeItem"
}

func (r *RatioChargeItemRule) Desc() string {
	return "比例计费项校验：报价单中存在比例计费项时，其所在解决方案下必须至少包含一个比例关联计费项。"
}

func (r *RatioChargeItemRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyPriceInfoMap,
	}
}

func (r *RatioChargeItemRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNRatioChargeItemCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quoteItems := quoteCtx.Persisted.QuoteItems
	if len(quoteItems) == 0 {
		return result, nil
	}

	itemContextMap := quoteCtx.Persisted.ItemContextMap
	priceInfoMap := quoteCtx.External.PriceInfoMap

	// 解决方案 -> 该方案下的全部计费项 ItemContext.GetKey()
	solutionChargeItemMap := map[int64][]string{}
	// 报价项ID -> 比例计费项 quoteItem
	ratioQuoteItemMap := map[int64]*model.QuoteItem{}
	// 报价项ID -> 该比例计费项关联的计费项 key 集合
	relatedChargeItemMap := map[int64]map[string]struct{}{}

	for _, quoteItem := range quoteItems {
		itemCtx, ok := itemContextMap[quoteItem.Id]
		if !ok || itemCtx == nil {
			return nil, i18nfmt.Errorf(ctx, "报价项部分上下文对象没有找到: [%v]", quoteItem.Id)
		}

		solutionChargeItemMap[quoteItem.QuoteSolutionID] = append(solutionChargeItemMap[quoteItem.QuoteSolutionID], itemCtx.GetKey())

		if itemCtx.PriceType != constants.PricingFunctionRelatedChargeItemRatio {
			continue
		}
		ratioQuoteItemMap[quoteItem.Id] = quoteItem

		// 从 PriceInfoMap 查询该比例计费项的关联计费项；按 ChargeItemKey 索引
		priceInfo := priceInfoMap[itemCtx.GetChargeItemKey()]
		m := map[string]struct{}{}
		if priceInfo != nil {
			for _, relatedChargeItem := range priceInfo.RelatedChargeItems {
				m[item_context.GetRatioChargeItemKey(relatedChargeItem)] = struct{}{}
			}
		}
		relatedChargeItemMap[quoteItem.Id] = m
	}

	for ratioQuoteItemID, ratioQuoteItem := range ratioQuoteItemMap {
		solutionChargeItems := solutionChargeItemMap[ratioQuoteItem.QuoteSolutionID] // 比例计费项所在解决方案下所有计费项
		m := relatedChargeItemMap[ratioQuoteItemID]                                  // 比例关联的计费项
		notContainsNum := 0
		for _, solutionChargeItem := range solutionChargeItems {
			if _, ok := m[solutionChargeItem]; !ok {
				notContainsNum++
			}
		}
		if len(solutionChargeItems) == notContainsNum { // 解决方案下所有计费项都不属于比例关联计费项
			result.Pass = false
			result.ErrorCode = errors.CodeNRatioChargeItemCheckFailed
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "未添加比例关联计费项，请返回\"商品折扣页\"查看\"比例关联计费项\"并添加")
			return result, nil
		}
	}
	return result, nil
}

func (r *RatioChargeItemRule) BlockLevel() string {
	return BlockLevelError
}

package check_engine

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// 规则注册Demo
var quoteBizRuleRegistry = NewRuleRegistry().
	// 注册CheckKey和rule的关联关系
	RegisterCheckKey(checkQuoteBaseInfo).WithRules(
	&MaxItemNumRule{},
	&CombineRuleRule{},
	&ProjectSupplyRule{},
	&ResourcePageRule{},
	&QuoteBaseInfoBasicRule{},
	&DistributorInfoRule{},
	// 7.24.2 拆出的纯字段类原子校验
	&DistributionBizTypeRule{},
	&ProjectAttributesRule{},
	&QuoteNotesRule{},
	&GiveAwayInfoRule{},
	&EffectiveInfoRule{},
	&ChangeInfoRule{},
	&EstimatedTradingMonthlyIncomeRule{},
	&PublicCloudEstimateRule{},
	// 7.24.3 拆出的 helper 派生类原子校验
	&LongLifeReasonRule{},
	&EstimatedTradingTimeRule{},
	&MdInfoRule{},
	&ProgressiveInfoRule{},
	&QuoteEstimateBySalesRule{},
	&ProjectQuoteDataRule{},
	&BackdatingRule{},
	&SolutionInfoRule{},
	&TradeProductTypeRule{},
	&PartnerNameRule{},
	&CustomerNameRule{},
	&TradeTypeRule{},
	&PriceValidPeriodRule{},
	&RelatedAccountIDsRule{},
	&PartnerContractNoRule{},
	&CustomerDetailRule{},
	&CustomerQuoteQualificationRule{},
	&QuoteTypeRule{},
	&OrderTypeRule{},
	// 其他rule...
).
	// 报价项维度：0元报价/计费项/售卖模式等原子规则均挂在此 CheckKey 下
	RegisterCheckKey(checkQuoteItem).WithRules(
	&ZeroQuoteRule{},
	&ItemSellingModeValidRule{},
	&ItemEffectiveRule{},
	&RatioChargeItemRule{},
	&ItemDiscountRule{},
	&RelatedChargeItemRule{},
	&UnStandardDeliveryItemCostRule{},
	&EstimatedIncomeRule{},
	&ProductCustomerScopeRule{},
	&RelatedProductRule{},
	&DistributionDiscountsRule{},
	&ConfigListRule{},
	&DeductDiscountRule{},
).
	// 综合预计金额维度：历史仅全量业务数据校验(allCheckerKeys)执行，SubmitQuote 主链路不执行
	RegisterCheckKey(checkTotalEstimatedIncome).WithRules(
	&TotalEstimatedIncomeRule{},
).
	// 保底维度：保底相关原子规则均挂在此 CheckKey 下
	RegisterCheckKey(checkGuaranteeItem).WithRules(
	&GuaranteeRule{},
	&GuaranteePercentageRule{},
).
	// 返佣维度：返佣相关原子规则均挂在此 CheckKey 下
	RegisterCheckKey(checkRebate).WithRules(
	&RebateRule{},
	&JointPrintOrderRule{},
).
	// 商务优惠维度：送审前后商务优惠范围一致性等原子规则均挂在此 CheckKey 下
	RegisterCheckKey(checkBizDiscount).WithRules(
	&FullQuoteModifyDiscountRule{},
).
	// 关联报价项商务优惠维度：历史仅全量业务数据校验(allCheckerKeys)执行，SubmitQuote 主链路不执行
	RegisterCheckKey(checkRelatedBizDiscount).WithRules(
	&RelatedBusinessDiscountRule{},
).
	// 代金券申请维度
	RegisterCheckKey(checkCoupon).WithRules(
	&CouponApplyRule{},
	&CouponParamRule{},
	&FullQuoteCouponFollowContractRule{},
	&FullQuoteCouponValidityRangeRule{},
	&FullQuoteCouponTriggerItemRule{},
	&FullQuoteCouponOriginalBillProductRule{},
).
	// 信控申请维度
	RegisterCheckKey(checkCredit).WithRules(
	&CreditApplyRule{},
).
	// 注册OpType和CheckKey的关联关系,间接将CheckKey的rule关联给OpType
	RegisterOpType(QuoteBizOpTypeSubmitQuote).WithCheckKeys(
	checkQuoteBaseInfo,
	checkQuoteItem,
	checkGuaranteeItem,
	checkRebate,
	checkBizDiscount,
	checkCoupon,
	checkCredit,
	// 其他checkKey...
).
	// 业务数据校验接口与历史 allCheckerKeys 对齐，额外包含关联报价项商务优惠维度
	RegisterOpType(QuoteBizOpTypeBizDataCheck).WithCheckKeys(
	checkQuoteBaseInfo,
	checkQuoteItem,
	checkGuaranteeItem,
	checkRebate,
	checkBizDiscount,
	checkCoupon,
	checkCredit,
	checkRelatedBizDiscount,
).
	// 注册OpType和AccessCheckRule的关联关系
	RegisterOpType(QuoteBizOpTypeSubmitQuote).WithAccessCheckRules(
	&QuoteCanOperateRule{},
).
	RegisterOpType(QuoteBizOpTypeBizDataCheck).WithAccessCheckRules(
	&QuoteCanOperateRule{},
)

func init() {
	mustValidateRuleRegistry(quoteBizRuleRegistry)
}

type CheckResultOption func(r *CheckResult)

func ShouldSkipBlockRule(skipRuleMap map[string]bool, ruleKey string) bool {
	return skipRuleMap[ruleKey]
}

func WithSkipBlockRules(skipRuleMap map[string]bool) CheckResultOption {
	return func(r *CheckResult) {
		if r != nil && !r.Pass && ShouldSkipBlockRule(skipRuleMap, r.RuleKey) {
			r.BlockLevel = BlockLevelWarn
			r.Pass = true
		}
	}
}

type OpChecker struct {
	OpType             QuoteBizOpType
	Tx                 *gorm.DB
	QuoteCtx           *quote_context.QuoteContext
	FailFast           bool // 是否快速失败，默认false
	CheckResultOptions []CheckResultOption
}

func (oc *OpChecker) CheckOperation(ctx context.Context) ([]*CheckResult, error) {
	accessCheckResults, err := oc.CheckOpAccess(ctx)
	if err != nil {
		return nil, err
	}
	bizDataCheckResults, err := oc.CheckOpBizData(ctx)
	if err != nil {
		return nil, err
	}
	return append(accessCheckResults, bizDataCheckResults...), nil
}

func (oc *OpChecker) CheckOpAccess(ctx context.Context) ([]*CheckResult, error) {
	if oc.QuoteCtx == nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNGetBizCheckerFailed, "quote context is nil")
	}
	accessCheckRules, err := quoteBizRuleRegistry.getAccessCheckRules(oc.OpType)
	if err != nil {
		return nil, err
	}
	return oc.checkRules(ctx, accessCheckRules)
}

func (oc *OpChecker) CheckOpBizData(ctx context.Context) ([]*CheckResult, error) {
	if oc.QuoteCtx == nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNGetBizCheckerFailed, "quote context is nil")
	}
	bizDataCheckRules, err := quoteBizRuleRegistry.getBizDataCheckRules(oc.OpType)
	if err != nil {
		return nil, err
	}
	return oc.checkRules(ctx, bizDataCheckRules)
}

func (oc *OpChecker) checkRules(ctx context.Context, rules []QuoteBizRule) ([]*CheckResult, error) {
	if oc.QuoteCtx == nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNGetBizCheckerFailed, "quote context is nil")
	}
	var checkResults []*CheckResult
	var needKeys []quote_context.QuoteContextKey
	for _, rule := range rules {
		needKeys = append(needKeys, rule.Needs()...)
	}
	needKeys = uniqueQuoteContextKeys(needKeys)
	quoteCtx, err := quote_context.NewLoaderByQuoteContext(oc.QuoteCtx, oc.Tx).WithKeys(needKeys...).Load(ctx)
	if err != nil {
		return nil, err
	}
	oc.QuoteCtx = quoteCtx
	for _, rule := range rules {
		checkResult, err := rule.Check(ctx, oc.QuoteCtx)
		if err != nil {
			return nil, err
		}
		// 约定：Rule 必须返回字段完备的 CheckResult，禁止返回 nil；这里仅作兜底防御
		if checkResult == nil {
			checkResult = &CheckResult{
				Pass:       false,
				BlockLevel: BlockLevelError,
				RuleKey:    rule.Key(),
				RuleDesc:   rule.Desc(),
				ErrorCode:  errors.CodeNGetBizCheckerFailed,
				ErrorMsg:   "rule returned nil result",
			}
		}
		// 自动回填关键字段，避免单条 Rule 漏写导致下游误判
		if checkResult.RuleKey == "" {
			checkResult.RuleKey = rule.Key()
		}
		if checkResult.RuleDesc == "" {
			checkResult.RuleDesc = rule.Desc()
		}
		if checkResult.BlockLevel == "" {
			checkResult.BlockLevel = rule.BlockLevel()
		}
		for _, option := range oc.CheckResultOptions {
			option(checkResult)
		}
		checkResults = append(checkResults, checkResult)
		if oc.FailFast && !checkResult.Pass && checkResult.BlockLevel == BlockLevelError {
			break
		}
	}
	return checkResults, nil
}

// GetOpRuleDesc 获取相关操作业务规则
func GetOpRuleDesc(ctx context.Context, opType QuoteBizOpType) ([]string, error) {
	var ruleDescList []string
	accessCheckRules, err := quoteBizRuleRegistry.getAccessCheckRules(opType)
	if err != nil {
		return nil, err
	}
	bizDataCheckRules, err := quoteBizRuleRegistry.getBizDataCheckRules(opType)
	if err != nil {
		return nil, err
	}
	alllRules := append(accessCheckRules, bizDataCheckRules...)
	for _, rule := range alllRules {
		ruleDescList = append(ruleDescList, rule.Desc())
	}
	return ruleDescList, nil
}

func uniqueQuoteContextKeys(keys []quote_context.QuoteContextKey) []quote_context.QuoteContextKey {
	if len(keys) <= 1 {
		return keys
	}
	seen := make(map[quote_context.QuoteContextKey]struct{}, len(keys))
	result := make([]quote_context.QuoteContextKey, 0, len(keys))
	for _, key := range keys {
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		result = append(result, key)
	}
	return result
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/combine_rule/rule_check"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// CombineRuleRule 组合规则校验。
//
// 来源：原 CombineRuleChecker。
// 校验目标：报价单内每个 QuoteSolution 关联的报价项商品集合，需满足模板解决方案
// 配置的组合规则约束。
//
// 迁移到 check_engine 后：
//   - QuoteItems / QuoteSolutions / 组合规则均通过 QuoteContextLoader 预加载，
//     Rule 不持有 *gorm.DB；
//   - 仅做数据校验，不做任何 DB / RPC 查询。
type CombineRuleRule struct{}

func (r *CombineRuleRule) Key() string {
	return "BizDataRuleCombineRule"
}

func (r *CombineRuleRule) Desc() string {
	return "组合规则校验：报价单内每个解决方案下的报价项商品集合需满足模板解决方案配置的组合规则。"
}

func (r *CombineRuleRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyQuoteSolutions,
		quote_context.QuoteContextKeyCombineRulesBySolution,
	}
}

func (r *CombineRuleRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCombineRuleCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quoteSolutionProductMap := map[int64]map[string]interface{}{}
	for _, quoteItem := range quoteCtx.Persisted.QuoteItems {
		if quoteItem == nil || quoteItem.QuoteSolutionID <= 0 {
			continue
		}
		productMap, ok := quoteSolutionProductMap[quoteItem.QuoteSolutionID]
		if !ok {
			productMap = map[string]interface{}{}
		}
		productMap[quoteItem.TradeProduct] = struct{}{}
		quoteSolutionProductMap[quoteItem.QuoteSolutionID] = productMap
	}
	if len(quoteSolutionProductMap) == 0 {
		return result, nil
	}

	for quoteSolutionID, productMap := range quoteSolutionProductMap {
		var rules []*model.CombineRule
		if quoteCtx.Persisted.CombineRulesBySolution != nil {
			rules = quoteCtx.Persisted.CombineRulesBySolution[quoteSolutionID]
		}
		if err := rule_check.CheckRelatedProduct(ctx, productMap, rules); err != nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNCombineRuleCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
	}
	return result, nil
}

func (r *CombineRuleRule) BlockLevel() string {
	return BlockLevelError
}

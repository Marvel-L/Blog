package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// PublicCloudEstimateRule —— 公有云标品销售预估金额范围校验。
//
// 与原 QuoteData.PublicCloudEstimateCheck 保持错误码与文案完全一致：
//   - 配置清单场景不允许填写 PublicCloudEstimate 大于 0；
//   - 非配置清单场景需 ≥ 0 且 ≤ QuoteEstimateBySales。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type PublicCloudEstimateRule struct{}

func (r *PublicCloudEstimateRule) Key() string { return "BizDataRulePublicCloudEstimate" }
func (r *PublicCloudEstimateRule) Desc() string {
	return "公有云标品销售预估金额校验：配置清单场景不允许填写；非配置清单场景需 ≥ 0 且 ≤ QuoteEstimateBySales"
}
func (r *PublicCloudEstimateRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *PublicCloudEstimateRule) BlockLevel() string { return BlockLevelError }

func (r *PublicCloudEstimateRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNPublicCloudEstimateCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.QuoteScene.GeneralizedConfigListScene() {
		if quote.PublicCloudEstimate.Sign() > 0 {
			result.Pass = false
			result.ErrorCode = errors.CodeNPublicCloudEstimateCheckFailed
			result.ErrorMsg = "配置清单不支持【销售预估金额-公有云标品】大于0"
			return result, nil
		}
		return result, nil
	}
	if quote.PublicCloudEstimate.Sign() < 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNPublicCloudEstimateCheckFailed
		result.ErrorMsg = "【销售预估金额-公有云标品】不可小于0"
		return result, nil
	}
	if quote.PublicCloudEstimate.GreaterThan(quote.QuoteEstimateBySales) {
		result.Pass = false
		result.ErrorCode = errors.CodeNPublicCloudEstimateCheckFailed
		result.ErrorMsg = "【销售预估金额-公有云标品】不可大于【销售预估金额】"
		return result, nil
	}
	return result, nil
}

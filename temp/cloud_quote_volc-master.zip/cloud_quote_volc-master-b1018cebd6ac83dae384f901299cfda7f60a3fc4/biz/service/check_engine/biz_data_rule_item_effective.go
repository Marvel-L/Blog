package check_engine

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ItemEffectiveRule 报价项有效性校验。
//
// 与原 ItemEffectiveChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems / DeliveryItems / ItemValues / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - 内联了原 ValidateQuoteItems 函数核心逻辑，避免对 quote_service 的反向依赖。
//
// 注意：原 ItemEffectiveChecker 使用 quoteBizData.GetAllItems()（报价项 + 交付项）。
type ItemEffectiveRule struct{}

func (r *ItemEffectiveRule) Key() string {
	return "BizDataRuleItemEffective"
}

func (r *ItemEffectiveRule) Desc() string {
	return "报价项有效性校验：原报价单中商品对应的商品、配置、计费项、折扣线、报价方式必须仍在有效/可提交范围内。"
}

func (r *ItemEffectiveRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *ItemEffectiveRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNItemEffectiveCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	var allItems []*model.QuoteItem
	allItems = append(allItems, quoteCtx.Persisted.QuoteItems...)
	allItems = append(allItems, quoteCtx.Persisted.DeliveryItems...)
	if len(allItems) == 0 {
		return result, nil
	}

	// ValidateQuoteItems 会对 QuoteItemValue 删除，防止影响后面业务流程，进行数据复制
	itemValuesCopy := map[int64][]*model.QuoteItemValue{}
	for itemID, itemValues := range quoteCtx.Persisted.ItemValues {
		var copyValues []*model.QuoteItemValue
		copyValues = append(copyValues, itemValues...)
		itemValuesCopy[itemID] = copyValues
	}

	message, err := r.validateQuoteItems(ctx, allItems, itemValuesCopy, quoteCtx.Persisted.Quote)
	if err != nil {
		return nil, err
	}
	if message != "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNItemEffectiveCheckFailed
		result.ErrorMsg = message
	}
	return result, nil
}

func (r *ItemEffectiveRule) BlockLevel() string {
	return BlockLevelError
}

// validateQuoteItems 内联自 quote_service.ValidateQuoteItems，避免循环依赖。
func (r *ItemEffectiveRule) validateQuoteItems(
	ctx context.Context,
	quoteItems []*model.QuoteItem,
	itemValuesMap map[int64][]*model.QuoteItemValue,
	quote *model.Quote,
) (string, error) {
	quoteItemMap := map[int64]*model.QuoteItem{}
	for _, quoteItem := range quoteItems {
		quoteItemMap[quoteItem.Id] = quoteItem
	}
	itemContextMap, err := item_context.NewItemContextByQuoteItemValues(ctx, quote, quoteItems, itemValuesMap)
	if err != nil {
		return "", err
	}
	checkResult, _, err := item_context.QuoteItemsValidCheck(ctx, quoteItemMap, itemValuesMap, itemContextMap)
	if err != nil {
		return "", err
	}
	validateFrom := i18nfmt.Sprintf(ctx, "%s", "提交审批")
	if len(itemValuesMap) == 0 {
		return "", errors.ErrCustomerError.WithArgs(i18nfmt.Sprintf(ctx, "原报价单中的所有商品对应的商品、配置、计费项、折扣线、报价方式已失效，不可%s！", validateFrom))
	}

	message := ""
	quoteItemIDs := ""
	productNameMap := map[string]interface{}{}
	for quoteItemID, productName := range checkResult {
		if _, ok := productNameMap[productName]; !ok {
			message = message + "【" + productName + "】" + "、"
			productNameMap[productName] = struct{}{}
		}
		quoteItemIDs = fmt.Sprintf("%s 【%d】、", quoteItemIDs, quoteItemID)
	}
	if message != "" {
		message = strings.TrimRight(message, "、")
		quoteItemIDs = strings.TrimRight(quoteItemIDs, "、")
		message = i18nfmt.Sprintf(ctx, "原报价单中商品%s的报价项%s对应的商品、配置、计费项、折扣线、报价方式已失效，不在可%s范围！", message, quoteItemIDs, validateFrom)
	}
	return message, nil
}

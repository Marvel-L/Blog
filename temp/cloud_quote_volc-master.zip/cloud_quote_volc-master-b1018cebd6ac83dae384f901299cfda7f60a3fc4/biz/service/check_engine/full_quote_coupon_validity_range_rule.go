package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
)

// FullQuoteCouponValidityRangeRule 校验指定月份型代金券规则有效期必须为报价单预估合同有效期的子集。
type FullQuoteCouponValidityRangeRule struct{}

func (r *FullQuoteCouponValidityRangeRule) Key() string {
	return "BizDataRuleFullQuoteCouponValidityRange"
}

func (r *FullQuoteCouponValidityRangeRule) Desc() string {
	return "代金券规则有效期必须落在报价单预估合同有效期内。"
}

func (r *FullQuoteCouponValidityRangeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote, quote_context.QuoteContextKeyCouponList}
}

func (r *FullQuoteCouponValidityRangeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return result, nil
	}
	quoteDB := quoteCtx.Persisted.Quote
	quoteBeginMonth := quoteDB.PriceValidPeriodStartTime.Format("2006-01")
	quoteEndMonth := quoteDB.PriceValidPeriodEndTime.Format("2006-01")
	for _, coupon := range quoteCtx.Persisted.CouponList {
		if coupon == nil {
			continue
		}
		if apiErr := validateFullQuoteCouponRuleValidity(ctx, coupon, quoteBeginMonth, quoteEndMonth); apiErr != nil {
			return failCheckResult(result, apiErr), nil
		}
	}
	return result, nil
}

func (r *FullQuoteCouponValidityRangeRule) BlockLevel() string { return BlockLevelError }

package check_engine

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

// ZeroQuoteRule 0元报价项校验
//
//  1. 报价单包含0元报价项时，必须至少有一个与0元报价项对应的非0元报价的、税率一致、部署方式一致的报价项；
//     累进报价只要包含非0部分，按非0报价处理；
//  2. 报价单包含0元报价项时（含累进报价包含0元），只能线下纸质签约；
//  3. 报价单包含0元报价项时（含累进报价包含0元），赠送场景、赠送原因不可为空。
//
// 多条报错信息合并返回。
//
// 与原 ZeroQuoteChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems / External.ProductInfoMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明。
//
// 注意：原 ZeroQuoteChecker 中的 quoteBizData.AllQuoteItems 只包含 ItemSceneQuoteItem 的报价项，
// 并不含交付项；此处仅使用 Persisted.QuoteItems 与之对齐。
type ZeroQuoteRule struct{}

func (r *ZeroQuoteRule) Key() string {
	return "BizDataRuleZeroQuote"
}

func (r *ZeroQuoteRule) Desc() string {
	return "0元报价项校验：" +
		"1) 报价单包含赠送报价项时，赠送场景、赠送原因不可为空；" +
		"2) 报价单包含赠送报价项时，只能线下纸质签约；" +
		"3) 报价单包含0元刊例价报价项时，只能线下纸质签约；" +
		"4) 报价单包含0元报价项（含累进报价含0元）时，必须至少有一个与之对应的、非0元报价的、税率一致、部署方式一致的报价项；累进报价只要包含非0部分，按非0报价处理；" +
		"上述多条不满足时合并返回错误信息。"
}

func (r *ZeroQuoteRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyProductInfo,
	}
}

func (r *ZeroQuoteRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	// 默认通过结果，所有字段完备；失败分支会基于此结构补 ErrorCode / ErrorMsg
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}

	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNZeroQuoteCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	var (
		quoteDB        = quoteCtx.Persisted.Quote
		quoteItems     = quoteCtx.Persisted.QuoteItems
		productInfoMap = quoteCtx.External.ProductInfoMap
		errorMsgList   []string

		hasGiveAwayItem  bool
		hasZeroPrice     bool
		hasZeroQuoteItem bool
	)

	for _, item := range quoteItems {
		if item.IsZeroPrice == multienv.IsZeroPriceYes {
			hasZeroPrice = true
			hasZeroQuoteItem = true
		} else if !quoteDB.QuoteScene.GeneralizedConfigListScene() && multienv.IsGiveAwayType(item.GiveAwayType) {
			hasGiveAwayItem = true
			hasZeroQuoteItem = true
		}
	}

	if !hasZeroQuoteItem {
		return result, nil
	}

	if hasGiveAwayItem && (quoteDB.GiveAwayScene == "" || quoteDB.GiveAwayReason == "") {
		errorMsgList = append(errorMsgList, i18nfmt.Sprintf(ctx, "报价单包含赠送报价项，赠送场景、赠送原因不可为空。"))
	}
	if hasGiveAwayItem && quoteDB.OrderType != multienv.GetContractTypePaperContract() {
		errorMsgList = append(errorMsgList, i18nfmt.Sprintf(ctx, "报价单包含赠送报价项，只能线下纸质签约。"))
	}
	if hasZeroPrice && quoteDB.OrderType != multienv.GetContractTypePaperContract() {
		errorMsgList = append(errorMsgList, i18nfmt.Sprintf(ctx, "报价单包含0元刊例价报价项，只能线下纸质签约。"))
	}

	// 按税率、部署方式分组
	groups := map[string][]*model.QuoteItem{}
	for _, item := range quoteItems {
		productInfo, exist := productInfoMap[item.TradeProduct]
		if !exist || productInfo == nil {
			logs.CtxError(ctx, "[ZeroQuoteRule] 报价项关联商品信息不存在, itemID=%d", item.Id)
			return nil, errors.ErrCustomerError.WithArgs("报价项关联商品信息查询失败")
		}
		groupKey := fmt.Sprintf("%d_%s", item.ItemType, productInfo.TaxRate.StringFixed(4))
		groups[groupKey] = append(groups[groupKey], item)
	}

	for groupKey, items := range groups {
		var (
			tempHasGiveAwayItem bool
			tempHasZeroPrice    bool
			tempHasNonZeroItem  bool
		)
		for _, item := range items {
			if item.IsZeroPrice == multienv.IsZeroPriceYes {
				tempHasZeroPrice = true
			} else if !quoteDB.QuoteScene.GeneralizedConfigListScene() && multienv.IsGiveAwayType(item.GiveAwayType) {
				tempHasGiveAwayItem = true
			} else {
				tempHasNonZeroItem = true
			}
		}
		if !tempHasNonZeroItem {
			logs.CtxError(ctx, "[ZeroQuoteRule] groupKey[%s]分组下报价项，无非0元报价项", groupKey)
			if tempHasGiveAwayItem {
				errorMsgList = append(errorMsgList, i18nfmt.Sprintf(ctx, "报价单包含赠送报价项时，必须至少有一个与赠送报价项对应的非赠送报价的、税率一致、部署方式一致的报价项。"))
			} else if tempHasZeroPrice {
				errorMsgList = append(errorMsgList, i18nfmt.Sprintf(ctx, "报价单包含0元刊例价报价项时，必须至少有一个与0元刊例价报价项对应的非0元刊例价报价的、税率一致、部署方式一致的报价项。"))
			}
			break
		}
	}

	if len(errorMsgList) > 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNZeroQuoteCheckFailed
		result.ErrorMsg = strings.Join(errorMsgList, "")
	}
	return result, nil
}

func (r *ZeroQuoteRule) BlockLevel() string {
	return BlockLevelError
}

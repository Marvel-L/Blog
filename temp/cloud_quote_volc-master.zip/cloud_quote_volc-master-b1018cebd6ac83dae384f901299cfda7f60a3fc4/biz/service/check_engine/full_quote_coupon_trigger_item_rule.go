package check_engine

import (
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

// FullQuoteCouponTriggerItemRule 校验代金券触发条件中的报价项。
type FullQuoteCouponTriggerItemRule struct{}

func (r *FullQuoteCouponTriggerItemRule) Key() string { return "BizDataRuleFullQuoteCouponTriggerItem" }

func (r *FullQuoteCouponTriggerItemRule) Desc() string {
	return "代金券触发条件中的报价项必须属于当前报价单，且匹配参与消费金额计算/统计商品。"
}

func (r *FullQuoteCouponTriggerItemRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuoteItemsAllStatus,
		quote_context.QuoteContextKeyDeliveryItems,
		quote_context.QuoteContextKeyCouponList,
	}
}

func (r *FullQuoteCouponTriggerItemRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil {
		return result, nil
	}
	allItems := fullQuoteAllItems(quoteCtx)
	if len(allItems) == 0 || len(quoteCtx.Persisted.CouponList) == 0 {
		return result, nil
	}
	quoteItemMap := make(map[int64]*model.QuoteItem, len(allItems))
	for _, item := range allItems {
		if item != nil {
			quoteItemMap[item.Id] = item
		}
	}
	for _, coupon := range quoteCtx.Persisted.CouponList {
		if coupon == nil || (coupon.RebateCouponWay != couponconfigconst.RebateCouponWayByAmountPercent && coupon.RebateCouponWay != couponconfigconst.RebateCouponWayByAmount) {
			continue
		}
		info, err := coupon.GetTriggerInfo()
		if err != nil || info == nil {
			apiErr := errors.ErrCustomerError.WithArgs(fmt.Sprintf("代金券(id=%d)触发条件数据异常", coupon.Id))
			return failCheckResult(result, apiErr), nil
		}
		apiErr := ValidateFullQuoteTriggerQuoteItemIDList(info, quoteItemMap, coupon.RebateCouponWay)
		if apiErr != nil {
			logs.CtxError(ctx, "[FullQuoteCouponTriggerItemRule]_校验代金券配置触发条件中的报价项ID列表失败，couponId=%d, err=%s", coupon.Id, apiErr.Error())
			return failCheckResult(result, apiErr), nil
		}
	}
	return result, nil
}

func (r *FullQuoteCouponTriggerItemRule) BlockLevel() string { return BlockLevelError }

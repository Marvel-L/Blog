package check_engine

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

// ItemSellingModeValidRule 校验报价项当前售卖模式是否合法。
//
// 仅处理报价项；交付项分两种情况：
//  1. 自动生成的交付项，在报价项不合法时会被一起删除，因此不需要单独校验售卖模式
//  2. 手动添加的交付项不会添加公有云的，因此不需要校验售卖模式
//
// 与原 ItemSellingModeValidChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明。
type ItemSellingModeValidRule struct{}

func (r *ItemSellingModeValidRule) Key() string {
	return "BizDataRuleItemSellingModeValid"
}

func (r *ItemSellingModeValidRule) Desc() string {
	return "报价项售卖模式合法性校验：公有云报价项当前售卖模式必须合法，否则不允许提交。"
}

func (r *ItemSellingModeValidRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *ItemSellingModeValidRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNItemInvalidSpotBlocked
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quoteItems := quoteCtx.Persisted.QuoteItems
	if len(quoteItems) == 0 {
		return result, nil
	}

	itemContextMap := quoteCtx.Persisted.ItemContextMap
	var invalidItemIDs []int64
	for _, quoteItem := range quoteItems {
		itemCtx, ok := itemContextMap[quoteItem.Id]
		if !ok || itemCtx == nil {
			logs.CtxError(ctx, "[ItemSellingModeValidRule] itemContext missing, quoteItemID=%d", quoteItem.Id)
			return nil, errors.ErrInternalError.WithArgs("quote item context missing, quoteItemID=%d", quoteItem.Id)
		}
		if !itemCtx.IsPublicItem() {
			continue
		}
		valid, err := itemCtx.IsValidSellingMode(ctx)
		if err != nil {
			logs.CtxError(ctx, "[ItemSellingModeValidRule] IsValidSellingMode err, quoteItemID=%d, err=%s", quoteItem.Id, err.Error())
			return nil, err
		}
		if !valid {
			invalidItemIDs = append(invalidItemIDs, quoteItem.Id)
		}
	}

	if len(invalidItemIDs) == 0 {
		return result, nil
	}

	result.Pass = false
	result.ErrorCode = errors.CodeNItemInvalidSpotBlocked
	result.ErrorMsg = buildItemSellingModeInvalidMsg(ctx, invalidItemIDs)
	result.Detail = invalidItemIDs
	return result, nil
}

func (r *ItemSellingModeValidRule) BlockLevel() string {
	return BlockLevelError
}

func buildItemSellingModeInvalidMsg(ctx context.Context, itemIDs []int64) string {
	sort.Slice(itemIDs, func(i, j int) bool {
		return itemIDs[i] < itemIDs[j]
	})
	ids := make([]string, 0, len(itemIDs))
	for _, itemID := range itemIDs {
		ids = append(ids, fmt.Sprintf("%d", itemID))
	}
	return i18nfmt.Sprintf(ctx, "报价项【%s】不支持报价，请删除后提交", strings.Join(ids, "、"))
}

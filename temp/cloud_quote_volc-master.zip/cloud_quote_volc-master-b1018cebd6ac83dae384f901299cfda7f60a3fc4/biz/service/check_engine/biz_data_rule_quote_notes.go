package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// QuoteNotesRule —— 报价逻辑必填校验。
//
// 与原 QuoteData.QuoteNotesCheck 保持错误码与文案完全一致：
// 报价单 QuoteNotes 字段不能为空。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type QuoteNotesRule struct{}

func (r *QuoteNotesRule) Key() string  { return "BizDataRuleQuoteNotes" }
func (r *QuoteNotesRule) Desc() string { return "报价逻辑校验：报价单 QuoteNotes 字段不能为空" }
func (r *QuoteNotesRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *QuoteNotesRule) BlockLevel() string { return BlockLevelError }

func (r *QuoteNotesRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteNotesCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	if quoteCtx.Persisted.Quote.QuoteNotes == "" {
		result.Pass = false
		result.ErrorCode = errors.CodeNQuoteNotesCheckFailed
		result.ErrorMsg = "报价逻辑必填"
		return result, nil
	}
	return result, nil
}

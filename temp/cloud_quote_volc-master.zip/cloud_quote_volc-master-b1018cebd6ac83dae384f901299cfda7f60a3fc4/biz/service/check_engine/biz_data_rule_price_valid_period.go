package check_engine

import (
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// PriceValidPeriodRule —— 预估合同有效期校验。
//
// 与原 QuoteData.PriceValidPeriodCheck 保持错误码与文案完全一致：
//   - 涉及公有云 / 解决方案 / 一体机：仅支持固定日期生效；
//   - OrderType=官网自助下单：仅支持固定日期生效；
//   - 固定日期场景：开始时间 < 结束时间；结束时间 ≤ MaxEndTime；
//     生态-分销/代销/AI生态/集成解决方案 客户类型还需在伙伴授权时间区间内；
//   - 自签订之日起场景：PeriodUnit / PeriodNum 必须有效。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsFixedTimeEffective ⇔ Quote.PriceValidPeriod == ""；
//   - PriceStartTime ⇔ Quote.PriceValidPeriodStartTime；
//   - PriceEndTime   ⇔ Quote.PriceValidPeriodEndTime；
//   - PriceValidPeriod struct ⇔ json.Unmarshal(Quote.PriceValidPeriod)；
//   - ProductTypeMap ⇔ Quote.GetProductTypeMap()；
//   - tradeTypeGrantMap ⇔ External.TradeTypeGrantMap。
type PriceValidPeriodRule struct{}

func (r *PriceValidPeriodRule) Key() string { return "BizDataRulePriceValidPeriod" }
func (r *PriceValidPeriodRule) Desc() string {
	return "预估合同有效期校验：含商品类型 / 签约方式约束、固定日期/期间合法性、伙伴授权时间区间内"
}
func (r *PriceValidPeriodRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyPartnerGrant,
	}
}
func (r *PriceValidPeriodRule) BlockLevel() string { return BlockLevelError }

func (r *PriceValidPeriodRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	productTypeMap, err := quote.GetProductTypeMap(ctx)
	if err != nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
		result.ErrorMsg = err.Error()
		return result, nil
	}
	_, containsOnline := productTypeMap[multienv.TradeProductTypeOnline]
	_, containsSolution := productTypeMap[multienv.TradeProductTypeSolution]
	_, containsIntegratedMachine := productTypeMap[multienv.TradeProductTypeIntegratedMachine]
	isFixedTimeEffective := quote.PriceValidPeriod == ""

	if (containsOnline || containsSolution || containsIntegratedMachine) && !isFixedTimeEffective {
		result.Pass = false
		result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
		result.ErrorMsg = "涉及公有云或者解决方案或者一体机的报价单，预估合同有效期只能选择固定日期生效"
		return result, nil
	}
	if quote.OrderType == multienv.GetContractTypeOfficialWebAuto() && !isFixedTimeEffective {
		result.Pass = false
		result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
		result.ErrorMsg = "签约方式为【官网自助下单】，预估合同有效期只能选择固定日期生效"
		return result, nil
	}

	if isFixedTimeEffective {
		priceStart := quote.PriceValidPeriodStartTime
		priceEnd := quote.PriceValidPeriodEndTime
		if priceStart.After(priceEnd) || priceStart.Equal(priceEnd) {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
			result.ErrorMsg = "预估合同有效期开始时间不可以大于等于结束时间"
			return result, nil
		}
		maxEndTime, _ := util.CheckTimeWithZone(constants.MaxEndTime)
		if priceEnd.After(maxEndTime) {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
			result.ErrorMsg = "预估合同有有效期结束时间暂不支持超过2038-01-01 00:00:00"
			return result, nil
		}

		needPartnerContract := multienv.NeedPartnerContractTradeTypeCodeMap[quote.TradeTypeCode]
		if needPartnerContract && quoteCtx.External.TradeTypeGrantMap != nil {
			if grant, ok := quoteCtx.External.TradeTypeGrantMap[quote.TradeTypeCode]; ok && grant != nil {
				if grant.ValidatedTime == 0 || grant.InvalidatedTime == 0 {
					result.Pass = false
					result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
					result.ErrorMsg = "客户类型授权有效期信息不完整"
					return result, nil
				}
				validatedTime := util.SecToTimestamp(grant.ValidatedTime)
				invalidatedTime := util.SecToTimestamp(grant.InvalidatedTime)
				if priceStart.Before(util.ToBeginningOfDay(validatedTime)) ||
					priceEnd.After(util.ToEndOfDay(invalidatedTime)) {
					result.Pass = false
					result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
					result.ErrorMsg = "预估合同有效期要在伙伴分销协议有效期内"
					return result, nil
				}
			}
		}
	} else {
		priceValidPeriod := &model.PriceValidPeriod{}
		if err := json.Unmarshal([]byte(quote.PriceValidPeriod), priceValidPeriod); err != nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
		if _, ok := multienv.GetTimeUnitMapping()[priceValidPeriod.PeriodUnit]; !ok {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
			result.ErrorMsg = "自签订之日起生效时间单位数据错误 " + quote.PriceValidPeriod
			return result, nil
		}
		if priceValidPeriod.PeriodNum == 0 {
			result.Pass = false
			result.ErrorCode = errors.CodeNContractPriceTimeCheckFailed
			result.ErrorMsg = "自签订之日起，时长不可为0"
			return result, nil
		}
	}
	return result, nil
}

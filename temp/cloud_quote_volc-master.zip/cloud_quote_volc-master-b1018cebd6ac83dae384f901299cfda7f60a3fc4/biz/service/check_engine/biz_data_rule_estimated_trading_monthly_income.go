package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// EstimatedTradingMonthlyIncomeRule —— 预估上量月收入校验。
//
// 与原 QuoteData.EstimatedTradingMonthlyIncomeCheck 保持错误码与文案完全一致：
// 非配置清单场景下，EstimatedTradingMonthlyIncome 必须 ≤ QuoteEstimateBySales。
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type EstimatedTradingMonthlyIncomeRule struct{}

func (r *EstimatedTradingMonthlyIncomeRule) Key() string {
	return "BizDataRuleEstimatedTradingMonthlyIncome"
}
func (r *EstimatedTradingMonthlyIncomeRule) Desc() string {
	return "预估上量月收入校验：非配置清单场景下，EstimatedTradingMonthlyIncome 必须 ≤ QuoteEstimateBySales"
}
func (r *EstimatedTradingMonthlyIncomeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *EstimatedTradingMonthlyIncomeRule) BlockLevel() string { return BlockLevelError }

func (r *EstimatedTradingMonthlyIncomeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNMonthlyIncomeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.QuoteScene.GeneralizedConfigListScene() {
		return result, nil
	}
	if quote.QuoteEstimateBySales.IsZero() && quote.EstimatedTradingMonthlyIncome.IsZero() {
		return result, nil
	}
	if quote.EstimatedTradingMonthlyIncome.GreaterThan(quote.QuoteEstimateBySales) {
		result.Pass = false
		result.ErrorCode = errors.CodeNMonthlyIncomeCheckFailed
		result.ErrorMsg = "预估上量月收入必须小于等于预估销售金额"
		return result, nil
	}
	return result, nil
}

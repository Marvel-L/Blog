package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// CustomerNameRule —— 客户账号名校验。
//
// 与原 QuoteData.CustomerNameCheck 保持错误码与文案完全一致：
// 非内部 / 非 PRM / 非 BytePlus 场景下，若 CustomerName 非空，
// 必须等于商机上挂载的客户账号名（OppInfo.AccountInfo.AccountName）。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsInnerQuote ⇔ Quote.IsInnerQuote()
//   - IsPrmQuote   ⇔ Quote.IsPrmQuote()
//   - customerName ⇔ External.OppInfo.AccountInfo.AccountName
//
// 仅依赖 Persisted.Quote + External.OppInfo，不发起任何 RPC / DB 查询。
type CustomerNameRule struct{}

func (r *CustomerNameRule) Key() string { return "BizDataRuleCustomerName" }
func (r *CustomerNameRule) Desc() string {
	return "客户账号名校验：报价单 CustomerName 必须与商机客户账号名一致"
}
func (r *CustomerNameRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyOppInfo,
	}
}
func (r *CustomerNameRule) BlockLevel() string { return BlockLevelError }

func (r *CustomerNameRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNCustomerNameCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.CustomerName == "" || quote.IsInnerQuote() || quote.IsPrmQuote() || multienv.IsBytePlus() {
		return result, nil
	}
	var customerName string
	if quoteCtx.External.OppInfo != nil && quoteCtx.External.OppInfo.AccountInfo != nil {
		customerName = quoteCtx.External.OppInfo.AccountInfo.AccountName
	}
	if quote.CustomerName != customerName {
		result.Pass = false
		result.ErrorCode = errors.CodeNCustomerNameCheckFailed
		result.ErrorMsg = "CustomerName not belong to this opportunity"
		return result, nil
	}
	return result, nil
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// OrderTypeRule —— 签约方式校验。
//
// 与原 QuoteData.OrderTypeCheck 保持错误码与文案完全一致：
//   - OrderType 必须在 GetContractTypeMapping 中；
//   - 内部报价：签约方式只能选【官网自助下单】；
//   - 非纸质合同：
//   - 涉及私有云/解决方案/一体机/非标品 报价单，签约方式只能选【纸质签约】；
//   - 客户类型为生态-代销，签约方式只能选【纸质签约】；
//   - OrderTypeCode 必须在 GetContractTypeCodeToTypeMapping 中。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsInnerQuote                ⇔ Quote.IsInnerQuote()
//   - containsOffline             ⇔ ProductTypeMap[TradeProductTypeOffline] 命中
//   - containsNoStandard          ⇔ ProductTypeMap[TradeProductTypeNoStandard] 命中
//   - containsSolution            ⇔ ProductTypeMap[TradeProductTypeSolution] 命中
//   - containsIntegratedMachine   ⇔ ProductTypeMap[TradeProductTypeIntegratedMachine] 命中
//
// 仅依赖 Persisted.Quote，不发起任何 RPC / DB 查询。
type OrderTypeRule struct{}

func (r *OrderTypeRule) Key() string { return "BizDataRuleOrderType" }
func (r *OrderTypeRule) Desc() string {
	return "签约方式校验：枚举有效性 / 内部报价签约方式限制 / 涉及私有云等限制 / 生态分销代销限制 / 阶梯报价限制"
}
func (r *OrderTypeRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *OrderTypeRule) BlockLevel() string { return BlockLevelError }

func (r *OrderTypeRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNOrderTypeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if _, ok := multienv.GetContractTypeMapping()[quote.OrderType]; !ok {
		result.Pass = false
		result.ErrorCode = errors.CodeNOrderTypeCheckFailed
		result.ErrorMsg = "签约方式错误"
		return result, nil
	}

	if quote.IsInnerQuote() {
		if quote.OrderType != multienv.GetContractTypeOfficialWebAuto() {
			result.Pass = false
			result.ErrorCode = errors.CodeNOrderTypeCheckFailed
			result.ErrorMsg = "内部报价，签约方式只能选【产品和服务协议（官网自助下单）】"
			return result, nil
		}
	} else if quote.OrderType != multienv.GetContractTypePaperContract() {
		productTypeMap, err := quote.GetProductTypeMap(ctx)
		if err != nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNOrderTypeCheckFailed
			result.ErrorMsg = err.Error()
			return result, nil
		}
		_, containsOffline := productTypeMap[multienv.TradeProductTypeOffline]
		_, containsNoStandard := productTypeMap[multienv.TradeProductTypeNoStandard]
		_, containsSolution := productTypeMap[multienv.TradeProductTypeSolution]
		_, containsIntegratedMachine := productTypeMap[multienv.TradeProductTypeIntegratedMachine]
		if containsOffline || containsNoStandard || containsSolution || containsIntegratedMachine {
			result.Pass = false
			result.ErrorCode = errors.CodeNOrderTypeCheckFailed
			result.ErrorMsg = "涉及私有云或者解决方案或者一体机的报价单，签约方式只能选【产品和服务协议（合同纸质签约）】"
			return result, nil
		}
		if quote.TradeTypeCode == multienv.CustomerTypeCodeEcoDist {
			result.Pass = false
			result.ErrorCode = errors.CodeNOrderTypeCheckFailed
			result.ErrorMsg = "客户类型为生态-分销，签约方式只能选【产品和服务协议（合同纸质签约）】"
			return result, nil
		}
	}

	if _, ok := multienv.GetContractTypeCodeToTypeMapping()[quote.OrderTypeCode]; !ok {
		result.Pass = false
		result.ErrorCode = errors.CodeNOrderTypeCheckFailed
		result.ErrorMsg = "OrderTypeCode error"
		return result, nil
	}
	return result, nil
}

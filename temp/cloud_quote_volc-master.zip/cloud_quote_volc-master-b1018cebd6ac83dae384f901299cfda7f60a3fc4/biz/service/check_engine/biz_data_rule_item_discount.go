package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_option_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

// ItemDiscountRule 折扣信息校验。
//
// 与原 ItemDiscountChecker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖 Quote / QuoteItems / ItemValues / ItemContextMap；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明。
//
// 注意：原 ItemDiscountChecker 使用 quoteBizData.AllQuoteItems（仅含报价项，不含交付项），
// 此处对齐使用 Persisted.QuoteItems。
type ItemDiscountRule struct{}

func (r *ItemDiscountRule) Key() string {
	return "BizDataRuleItemDiscount"
}

func (r *ItemDiscountRule) Desc() string {
	return "折扣信息校验：" +
		"1) 报价项必须有合法折扣信息；" +
		"2) 项目制报价单的简单折扣/固定金额折扣，UnitPrice 为 0 且未指派时报错；" +
		"3) 阶梯报价折扣需通过 ValidateProgressiveQuote；" +
		"4) 含 0 折扣的节省计划商品/抵扣计费项不允许；" +
		"5) 节省计划商品折扣不为 10 折时不能存在抵扣计费项；" +
		"6) 节省计划商品不在白名单时不允许小于 10 折。"
}

func (r *ItemDiscountRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemValues,
		quote_context.QuoteContextKeyItemContextMap,
	}
}

func (r *ItemDiscountRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNDiscountError
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}

	quote := quoteCtx.Persisted.Quote
	quoteItems := quoteCtx.Persisted.QuoteItems
	itemContextMap := quoteCtx.Persisted.ItemContextMap

	var (
		progressiveInfoModel *config_option_service.ProgressiveInfoModel
		err                  error
	)
	if quote.QuoteType == multienv.QuoteTypeProgressive {
		if progressiveInfoModel, err = config_option_service.GenProgressiveInfo(quote.ProgressiveInfo); err != nil {
			logs.CtxError(ctx, "[ItemDiscountRule] GenProgressiveInfo failed, progressiveInfo=%s, err=%s", quote.ProgressiveInfo, err.Error())
			return nil, err
		}
	}

	deductItemMap := map[int64][]int64{}
	for _, quoteItem := range quoteItems {
		if quoteItem.IsSpDeductItem() {
			deductItemMap[quoteItem.RelatedItemID] = append(deductItemMap[quoteItem.RelatedItemID], quoteItem.Id)
		}
	}

	var (
		illegalHasDeduct  = map[int64][]int64{}
		illegalSpDiscount []int64
	)

	for _, quoteItem := range quoteItems {
		if quoteItem.ItemScene == constants.ItemSceneDeliveryItem {
			continue
		}
		if quoteItem.AutoGenerate == constants.ItemAutoGenerateTrue {
			continue
		}
		itemContext := itemContextMap[quoteItem.Id]
		if itemContext == nil {
			return nil, errors.ErrBadRequestError.WithArgs("报价项不存在")
		}
		discount := itemContext.Discount
		if discount == nil {
			result.Pass = false
			result.ErrorCode = errors.CodeNDiscountError
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "错误的折扣信息")
			return result, nil
		}
		if quote.QuoteType == multienv.QuoteTypeProjectBased &&
			(discount.PricingFunction == constants.DiscountFunctionSimpleDiscount ||
				discount.PricingFunction == constants.DiscountFunctionFixedPrice) &&
			discount.UnitPrice.IsZero() && !discount.Assigned {
			result.Pass = false
			result.ErrorCode = errors.CodeNDiscountError
			result.ErrorMsg = i18nfmt.Sprintf(ctx, "报价项 %d 折扣信息未补全，请先完善报价单信息后再送审", quoteItem.Id)
			return result, nil
		} else if quote.QuoteType == multienv.QuoteTypeProgressive {
			if err = discount.ValidateProgressiveQuote(progressiveInfoModel); err != nil {
				result.Pass = false
				result.ErrorCode = errors.CodeNDiscountError
				result.ErrorMsg = err.Error()
				return result, nil
			}
		}
		if quote.IsConfigList() {
			continue
		}
		if discount.ContainsZeroDiscount() {
			if quoteItem.IsSpProduct() {
				result.Pass = false
				result.ErrorCode = errors.CodeNSPNotSupportGiveAway
				result.ErrorMsg = i18nfmt.Sprintf(ctx, "节省计划商品【%s】不支持0元", quoteItem.TradeProduct)
				return result, nil
			}
			if quoteItem.IsSpDeductItem() {
				result.Pass = false
				result.ErrorCode = errors.CodeNDeductNotSupportGiveAway
				result.ErrorMsg = i18nfmt.Sprintf(ctx, "抵扣计费项【%d】不支持0元", quoteItem.Id)
				return result, nil
			}
		}
		if quoteItem.IsSpProduct() && !discount.NoDiscount() {
			if len(deductItemMap[quoteItem.Id]) > 0 {
				illegalHasDeduct[quoteItem.Id] = deductItemMap[quoteItem.Id]
			}
			configurationCalculateData, _ := itemContext.GetConfigurationCalculateData(ctx)
			if configurationCalculateData == nil || !configurationCalculateData.QuoteSpWhiteList {
				illegalSpDiscount = append(illegalSpDiscount, quoteItem.Id)
			}
		}
	}

	if len(illegalHasDeduct) != 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNSpPkgNotSupportDeduct
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "节省计划商品 %v 折扣不为10折但存在抵扣计费项", util.MapKeysToSlice(illegalHasDeduct))
		result.Detail = illegalHasDeduct
		return result, nil
	}
	if len(illegalSpDiscount) != 0 {
		result.Pass = false
		result.ErrorCode = errors.CodeNSpDiscountNotSupportLessThanTen
		result.ErrorMsg = i18nfmt.Sprintf(ctx, "节省计划商品 %v 不在白名单不支持小于10折", illegalSpDiscount)
		result.Detail = illegalSpDiscount
		return result, nil
	}
	return result, nil
}

func (r *ItemDiscountRule) BlockLevel() string {
	return BlockLevelError
}

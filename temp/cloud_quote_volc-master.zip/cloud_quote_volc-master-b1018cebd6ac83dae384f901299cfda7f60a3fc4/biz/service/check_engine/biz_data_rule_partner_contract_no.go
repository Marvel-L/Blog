package check_engine

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// PartnerContractNoRule —— 分销协议（伙伴合同号）校验。
//
// 与原 QuoteData.PartnerContractNoCheck（quote_data_field_check.go:418-470）保持错误码与文案完全一致：
//   - 内部 / PRM 报价单：跳过；
//   - 客户类型需要分销协议（NeedPartnerContractTradeTypeCodeMap）：
//   - 若 PartnerContractNo 为空，且伙伴授权下无可用合同号，提示"未找到可用的分销协议"；
//     否则放行（兜底填充由入口层数据补全完成，§9 Rule 不写回 Quote）；
//   - 校验 PartnerContractNo 中每个合同号必须存在于伙伴授权 PartnerContractListMap 中；
//   - 客户类型不需要分销协议：PartnerContractNo 必须为空。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsInnerQuote / IsPrmQuote ⇔ Quote.IsInnerQuote() / Quote.IsPrmQuote()；
//   - partnerGrant              ⇔ External.TradeTypeGrantMap[TradeTypeCode]。
//
// 副作用剥离（§9）：
//   - Rule 内不写回 quote.PartnerContractNo；兜底填充能力保留在原入口前置链路，
//     待 7.24.4 收尾时迁移到入口数据补全步骤；
//   - helper.partnerContract = validContracts[0] 在原代码中仅供测试断言、生产无消费，丢弃。
//
// 仅依赖 Persisted.Quote + External.TradeTypeGrantMap。
type PartnerContractNoRule struct{}

func (r *PartnerContractNoRule) Key() string { return "BizDataRulePartnerContractNo" }
func (r *PartnerContractNoRule) Desc() string {
	return "分销协议校验：客户类型需要分销协议时，PartnerContractNo 必须命中伙伴授权下的合同号；不需要时必须为空"
}
func (r *PartnerContractNoRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyPartnerGrant,
	}
}
func (r *PartnerContractNoRule) BlockLevel() string { return BlockLevelError }

func (r *PartnerContractNoRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNPartnerContractCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.IsInnerQuote() || quote.IsPrmQuote() {
		return result, nil
	}

	needPartnerContract := multienv.NeedPartnerContractTradeTypeCodeMap[quote.TradeTypeCode]

	if !needPartnerContract {
		if quote.PartnerContractNo != "" {
			result.Pass = false
			result.ErrorCode = errors.CodeNPartnerContractCheckFailed
			result.ErrorMsg = "非生态-分销、生态-代销、AI生态/集成解决方案，不支持选择分销协议"
			return result, nil
		}
		return result, nil
	}

	grant := quoteCtx.External.TradeTypeGrantMap[quote.TradeTypeCode]

	if quote.PartnerContractNo == "" {
		// 入口层数据补全负责按授权下合同号兜底填充；若授权下无可用合同号，给出原提示
		if !hasAnyPartnerContractNo(grant) {
			result.Pass = false
			result.ErrorCode = errors.CodeNPartnerContractCheckFailed
			result.ErrorMsg = "生态-分销、生态-代销、AI生态/集成解决方案，未找到可用的分销协议"
			return result, nil
		}
		return result, nil
	}

	for _, contractNo := range strings.Split(quote.PartnerContractNo, ",") {
		contractNo = strings.TrimSpace(contractNo)
		if contractNo == "" {
			continue
		}
		if !partnerContractExists(grant, contractNo) {
			result.Pass = false
			result.ErrorCode = errors.CodeNPartnerContractCheckFailed
			result.ErrorMsg = "分销协议不存在：" + contractNo
			return result, nil
		}
	}
	return result, nil
}

// hasAnyPartnerContractNo 伙伴授权下是否存在任意一条非空合同号。
func hasAnyPartnerContractNo(grant *crm_service.PartnerGrant) bool {
	if grant == nil || len(grant.PartnerList) == 0 {
		return false
	}
	for _, partnerInfo := range grant.PartnerList {
		for contractNo := range partnerInfo.PartnerContractListMap {
			if contractNo != "" {
				return true
			}
		}
	}
	return false
}

// partnerContractExists 在伙伴授权下查找指定合同号。
func partnerContractExists(grant *crm_service.PartnerGrant, contractNo string) bool {
	if grant == nil {
		return false
	}
	for _, partnerInfo := range grant.PartnerList {
		if _, ok := partnerInfo.PartnerContractListMap[contractNo]; ok {
			return true
		}
	}
	return false
}

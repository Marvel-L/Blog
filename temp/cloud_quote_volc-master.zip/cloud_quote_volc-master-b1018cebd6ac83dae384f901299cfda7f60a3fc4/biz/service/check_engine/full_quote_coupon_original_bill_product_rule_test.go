package check_engine

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice/couponconfigconst"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
)

func TestFullQuoteCouponOriginalBillProductRule(t *testing.T) {
	rule := &FullQuoteCouponOriginalBillProductRule{}

	t.Run("规则依赖商品信息", func(t *testing.T) {
		convey.Convey("规则依赖商品信息", t, func() {
			convey.So(rule.Needs(), convey.ShouldResemble, []quote_context.QuoteContextKey{
				quote_context.QuoteContextKeyCouponList,
				quote_context.QuoteContextKeyProductInfo,
			})
		})
	})

	tests := []struct {
		name         string
		triggerInfo  model.TriggerInfo
		rebateWay    int
		billCaliber  int
		productInfos map[string]*trade_client.TradeProductVersionInfo
		wantPass     bool
	}{
		{
			name:        "原价非AI商品失败",
			triggerInfo: model.TriggerInfo{ConsumeRebateProductList: "non-ai"},
			rebateWay:   couponconfigconst.RebateCouponWayByAmount,
			billCaliber: couponconfigconst.BillCaliberOriginal,
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"non-ai": {IsAIProduct: multienv.IsAIProductFalse},
			},
			wantPass: false,
		},
		{
			name: "原价比例返券统计AI商品通过",
			triggerInfo: model.TriggerInfo{
				ConsumeRebateProductList:     "ai-a",
				StatConsumeRebateProductList: "ai-a,ai-b",
			},
			rebateWay:   couponconfigconst.RebateCouponWayByAmountPercent,
			billCaliber: couponconfigconst.BillCaliberOriginal,
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"ai-a": {IsAIProduct: multienv.IsAIProductTrue},
				"ai-b": {IsAIProduct: multienv.IsAIProductTrue},
			},
			wantPass: true,
		},
		{
			name:        "非原价口径跳过AI限制",
			triggerInfo: model.TriggerInfo{ConsumeRebateProductList: "non-ai"},
			rebateWay:   couponconfigconst.RebateCouponWayByAmount,
			billCaliber: couponconfigconst.BillCaliberDiscount,
			productInfos: map[string]*trade_client.TradeProductVersionInfo{
				"non-ai": {IsAIProduct: multienv.IsAIProductFalse},
			},
			wantPass: true,
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			convey.Convey(tt.name, t, func() {
				triggerJSON, err := json.Marshal(tt.triggerInfo)
				convey.So(err, convey.ShouldBeNil)

				result, err := rule.Check(context.Background(), &quote_context.QuoteContext{
					Persisted: quote_context.QuoteContextPersisted{
						CouponList: model.CouponConfigDBList{&model.CouponConfigDB{
							RebateCouponWay: tt.rebateWay,
							BillCaliber:     tt.billCaliber,
							TriggerInfo:     string(triggerJSON),
						}},
					},
					External: quote_context.QuoteContextExternal{
						ProductInfoMap: tt.productInfos,
					},
				})

				convey.So(err, convey.ShouldBeNil)
				convey.So(result.Pass, convey.ShouldEqual, tt.wantPass)
			})
		})
	}
}

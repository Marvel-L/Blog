package check_engine

import (
	"context"
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/rebate_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// RelatedBusinessDiscountRule 关联报价项商务优惠（返佣/保底）成对一致校验。
//
// 来源：原 RelatedQuoteItemBusinessDiscountChecker。
// 核心校验：
//  1. 命中 SwitchRelatedChargeItemConfig 关联规则的两条报价项，返佣写入状态必须一致；
//  2. 同上，保底（部分参与）覆盖范围必须一致；
//  3. 缺失返佣的报价项，按 PRM 返回的支持范围（none/all/part）回填 Detail。
//
// 与原 checker 的差异：
//   - 数据来源由 callback CallbackInfo 切换到 QuoteContext，依赖
//     Quote / QuoteItems / ItemContextMap / RebateItemList / GuaranteeItems；
//   - tx 不再使用，依赖通过 QuoteContextLoader 显式声明；
//   - PRM 返佣支持范围属于"按需调用、非报价单强关联"数据，按 §11 直接在 Rule 内调用
//     `rebate_item_service.GetPrmRebateRange`（其参数为 itemCtxMap，无 tx 依赖），不新增 loader。
type RelatedBusinessDiscountRule struct{}

// missingBusinessDiscountDetail 与原 MissingData 字段保持一致，仅命名空间不同。
type missingBusinessDiscountDetail struct {
	MissingRebateItemIDMap    map[int64]int64
	MissingRebateReasonMap    map[int64]string // 返佣缺失原因映射: key=报价项ID, value=返佣支持情况(none/all/part)
	MissingGuaranteeItemIDMap map[int64]int64
}

func (r *RelatedBusinessDiscountRule) Key() string {
	return "BizDataRuleRelatedBusinessDiscount"
}

func (r *RelatedBusinessDiscountRule) Desc() string {
	return "关联报价项商务优惠（返佣/保底）必须成对一致：" +
		"1) 命中关联规则的两条报价项，返佣写入状态必须一致；" +
		"2) 命中关联规则的两条报价项，保底（部分参与）覆盖范围必须一致；" +
		"3) 缺失返佣的报价项，按 PRM 支持范围（none/all/part）回填提示。"
}

func (r *RelatedBusinessDiscountRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyQuoteItems,
		quote_context.QuoteContextKeyItemContextMap,
		quote_context.QuoteContextKeyRebateItemList,
		quote_context.QuoteContextKeyGuaranteeItems,
	}
}

func (r *RelatedBusinessDiscountRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	// 与原 checker 一致：未开通关联规则配置时直接通过
	configModel := config.GetSwitchByName(ctx, config.SwitchRelatedChargeItemConfig)
	if configModel == nil || !configModel.IsOpen || len(configModel.WhiteList) == 0 {
		return result, nil
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		return result, nil
	}
	quoteItems := quoteCtx.Persisted.QuoteItems
	itemContextMap := quoteCtx.Persisted.ItemContextMap
	if len(quoteItems) == 0 || len(itemContextMap) == 0 {
		return result, nil
	}

	// 1) repeatKey -> quoteItemID
	repeatKeyToID := relatedBusinessDiscountRepeatKeyMap(quoteItems, itemContextMap)

	// 2) 返佣存在映射、保底规则维度的报价项覆盖集合
	rebateSet, guaranteeItemSets := relatedBusinessDiscountRebateGuaranteeSet(quoteCtx.Persisted.RebateItemList, quoteCtx.Persisted.GuaranteeItems)

	// 3) 关联规则
	relatedRuleMap := quote_item_service.GetRelatedRuleMap(ctx)

	// 4) 关联报价项映射
	relatedQuoteItemIDMap := relatedBusinessDiscountRelatedItemMap(ctx, quoteItems, itemContextMap, relatedRuleMap, repeatKeyToID)

	// 5) 检查返佣/保底缺失
	missingRebateMap := relatedBusinessDiscountMissingRebate(rebateSet, relatedQuoteItemIDMap)
	missingGuaranteeMap := relatedBusinessDiscountMissingGuarantee(guaranteeItemSets, relatedQuoteItemIDMap)
	if len(missingRebateMap) == 0 && len(missingGuaranteeMap) == 0 {
		return result, nil
	}

	// 6) 返佣缺失原因（PRM 范围）
	missingRebateReasonMap := map[int64]string{}
	if len(missingRebateMap) > 0 {
		reason, err := r.buildMissingRebateReasonMap(ctx, quoteCtx.Persisted.Quote, quoteItems, itemContextMap, missingRebateMap)
		if err != nil {
			return nil, err
		}
		missingRebateReasonMap = reason
	}

	result.Pass = false
	result.ErrorCode = errors.CodeNRelatedQuoteItemNotSameDiscountType
	result.ErrorMsg = "报价项商务优惠缺失"
	result.Detail = &missingBusinessDiscountDetail{
		MissingRebateItemIDMap:    missingRebateMap,
		MissingRebateReasonMap:    missingRebateReasonMap,
		MissingGuaranteeItemIDMap: missingGuaranteeMap,
	}
	return result, nil
}

func (r *RelatedBusinessDiscountRule) BlockLevel() string {
	return BlockLevelError
}

// buildMissingRebateReasonMap 与原 buildMissingRebateReasonMap 对齐。
// 数据加载部分：原版本走 GetPrmRebateData，内部用 tx + NewItemContextByQuoteItems 重建 itemCtxMap。
// 这里直接复用 quote_context 已加载的 ItemContextMap，按"公有云在线报价项 + 非 SP 抵扣项"过滤后，
// 调用 GetPrmRebateRange（无 tx），符合 §8 第 8 条 Rule 不依赖 tx 的强约束。
func (r *RelatedBusinessDiscountRule) buildMissingRebateReasonMap(
	ctx context.Context,
	quote *model.Quote,
	quoteItems []*model.QuoteItem,
	itemContextMap map[int64]*item_context.ItemContext,
	missingRebateMap map[int64]int64,
) (map[int64]string, error) {
	// 与 GetPrmRebateData 内的过滤完全一致：公有云 + 非 SP 抵扣 + ItemScene=报价项
	onlineItemCtxMap := map[int64]*item_context.ItemContext{}
	for _, quoteItem := range quoteItems {
		if quoteItem == nil || quoteItem.IsSpDeductItem() {
			continue
		}
		if quoteItem.ItemScene != constants.ItemSceneQuoteItem || quoteItem.ItemType != multienv.TradeProductTypeOnline {
			continue
		}
		if itemCtx, ok := itemContextMap[quoteItem.Id]; ok && itemCtx != nil {
			onlineItemCtxMap[quoteItem.Id] = itemCtx
		}
	}
	prmRebateDataMap, err := rebate_item_service.GetPrmRebateRange(ctx, quote, onlineItemCtxMap)
	if err != nil {
		return nil, err
	}
	result := make(map[int64]string, len(missingRebateMap))
	for quoteItemID := range missingRebateMap {
		prmItem, ok := prmRebateDataMap[strconv.FormatInt(quoteItemID, 10)]
		if ok && prmItem != nil {
			result[quoteItemID] = prmItem.RebateRange
			continue
		}
		// PRM 未返回时按"不支持"兜底
		result[quoteItemID] = constants.RebateSupportNone
	}
	return result, nil
}

// 与原 getRepeatKeyMap 一致
func relatedBusinessDiscountRepeatKeyMap(
	quoteItems []*model.QuoteItem,
	itemContextMap map[int64]*item_context.ItemContext,
) map[string]int64 {
	repeatKeyToID := make(map[string]int64)
	for _, quoteItem := range quoteItems {
		itemCtx := itemContextMap[quoteItem.Id]
		if itemCtx == nil {
			continue
		}
		for _, k := range itemCtx.GetRepeatCheckKey() {
			repeatKeyToID[k] = quoteItem.Id
		}
	}
	return repeatKeyToID
}

// 与原 getRebateGuaranteeSet 一致，保底侧按单条规则分别处理，避免跨规则/跨分组通过。
func relatedBusinessDiscountRebateGuaranteeSet(
	rebateItems model.RebateItemList,
	guaranteeItems []*model.GuaranteeItem,
) (map[int64]bool, []map[int64]bool) {
	rebateSet := make(map[int64]bool)
	for _, rebate := range rebateItems {
		if rebate.IsRebateWritten == constants.RebateWritten {
			rebateSet[rebate.QuoteItemID] = true
		}
	}
	var guaranteeItemSets []map[int64]bool
	for _, guaranteeItem := range guaranteeItems {
		if guaranteeItem == nil || guaranteeItem.GuaranteeType != multienv.GuaranteeTypePartial {
			continue
		}
		relatedQuoteItemIDs := guaranteeItem.GetRelatedQuoteItemId()
		if len(relatedQuoteItemIDs) == 0 {
			continue
		}
		// 保底侧不能做全局并集；PM 口径要求关联报价项必须命中同一条保底规则。
		guaranteeItemSet := make(map[int64]bool, len(relatedQuoteItemIDs))
		for _, id := range relatedQuoteItemIDs {
			guaranteeItemSet[id] = true
		}
		guaranteeItemSets = append(guaranteeItemSets, guaranteeItemSet)
	}
	return rebateSet, guaranteeItemSets
}

// 与原 getMissingRebate 一致
func relatedBusinessDiscountMissingRebate(rebateSet map[int64]bool, relatedQuoteItemMap map[int64]int64) map[int64]int64 {
	missingRebateMap := make(map[int64]int64)
	for quoteItemID, relatedQuoteItemID := range relatedQuoteItemMap {
		hasRebateA := rebateSet[quoteItemID]
		hasRebateB := rebateSet[relatedQuoteItemID]
		if hasRebateA != hasRebateB {
			if !hasRebateA {
				missingRebateMap[quoteItemID] = relatedQuoteItemID
			}
			if !hasRebateB {
				missingRebateMap[relatedQuoteItemID] = quoteItemID
			}
		}
	}
	return missingRebateMap
}

// relatedBusinessDiscountMissingGuarantee 对齐原 getMissingGuarantee 口径，按单条保底规则维度判断关联项缺失。
func relatedBusinessDiscountMissingGuarantee(guaranteeItemSets []map[int64]bool, relatedQuoteItemMap map[int64]int64) map[int64]int64 {
	missingGuaranteeMap := make(map[int64]int64)
	for _, guaranteeItemSet := range guaranteeItemSets {
		for quoteItemID, relatedQuoteItemID := range relatedQuoteItemMap {
			hasGuaranteeA := guaranteeItemSet[quoteItemID]
			hasGuaranteeB := guaranteeItemSet[relatedQuoteItemID]
			if hasGuaranteeA == hasGuaranteeB {
				continue
			}
			if !hasGuaranteeA {
				missingGuaranteeMap[quoteItemID] = relatedQuoteItemID
			}
			if !hasGuaranteeB {
				missingGuaranteeMap[relatedQuoteItemID] = quoteItemID
			}
		}
	}
	return missingGuaranteeMap
}

// 与原 getRelatedQuoteItemMap 一致
func relatedBusinessDiscountRelatedItemMap(
	ctx context.Context,
	quoteItems []*model.QuoteItem,
	itemContextMap map[int64]*item_context.ItemContext,
	relatedRuleMap map[string][]*quote_item_service.RelatedMultiFieldsRule,
	repeatKeyToID map[string]int64,
) map[int64]int64 {
	relatedQuoteItemIDMap := make(map[int64]int64)
	for _, quoteItem := range quoteItems {
		itemCtx := itemContextMap[quoteItem.Id]
		if itemCtx == nil {
			continue
		}
		ruleList := relatedRuleMap[itemCtx.TradeProduct]
		if len(ruleList) == 0 {
			continue
		}
		indexMap, valMap := quote_item_service.BuildNodeTypeIndexAndValue(itemCtx)
		for _, rule := range ruleList {
			ruleMatch := true
			for fieldKey, srcVal := range rule.SrcFormValues {
				curVal, ok := valMap[fieldKey]
				if !ok || curVal != srcVal {
					ruleMatch = false
					break
				}
			}
			if !ruleMatch {
				continue
			}
			mutated := quote_item_service.ReplaceMultipleFieldValues(itemCtx.CfgNodeList, indexMap, rule.DstFormValues)
			newItemCtx := itemCtx.RefreshItemContextByCfgNodes(ctx, mutated)
			newRepeatKeys := newItemCtx.GetRepeatCheckKey()
			if len(newRepeatKeys) == 0 {
				continue
			}
			newItemCtxKey := newRepeatKeys[0]
			if _, ok := repeatKeyToID[newItemCtxKey]; !ok {
				continue
			}
			relatedQuoteItemIDMap[quoteItem.Id] = repeatKeyToID[newItemCtxKey]
		}
	}
	return relatedQuoteItemIDMap
}

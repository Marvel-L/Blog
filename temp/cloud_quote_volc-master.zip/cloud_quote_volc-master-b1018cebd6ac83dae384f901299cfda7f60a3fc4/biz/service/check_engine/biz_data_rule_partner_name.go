package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// PartnerNameRule —— 伙伴账号名校验。
//
// 与原 QuoteData.PartnerNameCheck 保持错误码与文案完全一致：
// 非内部 / 非 PRM / 非 BytePlus 场景下，若 PartnerName 非空，
// 必须等于商机上挂载的伙伴账号名（OppInfo.PartnerInfo.AccountName）。
//
// 与 QuoteDataCheckHelper 派生口径一致：
//   - IsInnerQuote ⇔ Quote.IsInnerQuote()
//   - IsPrmQuote   ⇔ Quote.IsPrmQuote()
//   - partnerName  ⇔ External.OppInfo.PartnerInfo.AccountName
//
// 仅依赖 Persisted.Quote + External.OppInfo，不发起任何 RPC / DB 查询。
type PartnerNameRule struct{}

func (r *PartnerNameRule) Key() string { return "BizDataRulePartnerName" }
func (r *PartnerNameRule) Desc() string {
	return "伙伴账号名校验：报价单 PartnerName 必须与商机伙伴账号名一致"
}
func (r *PartnerNameRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyOppInfo,
	}
}
func (r *PartnerNameRule) BlockLevel() string { return BlockLevelError }

func (r *PartnerNameRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := &CheckResult{
		Pass:       true,
		BlockLevel: r.BlockLevel(),
		RuleKey:    r.Key(),
		RuleDesc:   r.Desc(),
	}
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNPartnerNameCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	if quote.PartnerName == "" || quote.IsInnerQuote() || quote.IsPrmQuote() || multienv.IsBytePlus() {
		return result, nil
	}
	var partnerName string
	if quoteCtx.External.OppInfo != nil && quoteCtx.External.OppInfo.PartnerInfo != nil {
		partnerName = quoteCtx.External.OppInfo.PartnerInfo.AccountName
	}
	if quote.PartnerName != partnerName {
		result.Pass = false
		result.ErrorCode = errors.CodeNPartnerNameCheckFailed
		result.ErrorMsg = "PartnerName not belong to this opportunity"
		return result, nil
	}
	return result, nil
}

package check_engine

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// CustomerQuoteQualificationRule —— 客户报价资格校验。
//
// 与原 QuoteData.CustomerQuoteQualificationCheck 保持一致：
//   - 直销客户：配价账号存在代销关系时禁止直销报价；
//   - 生态-代销/生态-分销客户：仅在不支持联合打单时，校验客户邀约类型与报价客户类型匹配；
//   - BytePlus 环境跳过客户邀约类型校验。
type CustomerQuoteQualificationRule struct{}

func (r *CustomerQuoteQualificationRule) Key() string { return "BizDataRuleCustomerQuoteQualification" }
func (r *CustomerQuoteQualificationRule) Desc() string {
	return "客户报价资格校验：直销账号代销关系校验、生态客户邀约类型匹配校验"
}
func (r *CustomerQuoteQualificationRule) Needs() []quote_context.QuoteContextKey {
	return []quote_context.QuoteContextKey{
		quote_context.QuoteContextKeyQuote,
		quote_context.QuoteContextKeyAccountFinancialRole,
		quote_context.QuoteContextKeyCustomerGrantType,
	}
}
func (r *CustomerQuoteQualificationRule) BlockLevel() string { return BlockLevelError }

func (r *CustomerQuoteQualificationRule) Check(_ context.Context, quoteCtx *quote_context.QuoteContext) (*CheckResult, error) {
	result := newPassCheckResult(r)
	if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
		result.Pass = false
		result.ErrorCode = errors.CodeNTradeTypeCheckFailed
		result.ErrorMsg = "quote context is missing"
		return result, nil
	}
	quote := quoteCtx.Persisted.Quote
	switch quote.TradeTypeCode {
	case multienv.CustomerTypeCodeDirectSell:
		return r.directCustomerFinancialRoleCheck(quoteCtx.External.AccountFinancialRoleList, result)
	case multienv.CustomerTypeCodeEcoAgent, multienv.CustomerTypeCodeEcoSell:
		return r.partnerInviteTypeCheck(quoteCtx, result)
	default:
		return result, nil
	}
}

func (r *CustomerQuoteQualificationRule) partnerInviteTypeCheck(quoteCtx *quote_context.QuoteContext, result *CheckResult) (*CheckResult, error) {
	quote := quoteCtx.Persisted.Quote
	if multienv.IsBytePlus() {
		return result, nil
	}
	jointPrintOrder := quote.ParseJointPrintOrder()
	if jointPrintOrder != nil && jointPrintOrder.Support {
		return result, nil
	}
	accountIDs := splitAccountIDs(quote.CustomerDetail)
	grantTypeMap := quoteCtx.External.CustomerGrantTypeMap
	for _, accountID := range accountIDs {
		grantInfo := grantTypeMap[accountID]
		if grantInfo == nil {
			apiErr := errors.NewBizErrWithMsg(errors.CodeNTradeTypeCheckFailed, "未查询到配价账号%s的客户邀约类型").WithArgs(accountID)
			return failCheckResult(result, apiErr), nil
		}
		expectedTradeTypeCode, ok := multienv.PartnerGrantTradeTypeCodeMap[grantInfo.GrantType]
		if !ok || expectedTradeTypeCode != quote.TradeTypeCode {
			grantTypeName := multienv.PartnerGrantTypeNameMap[grantInfo.GrantType]
			tradeTypeName := string(quote.TradeType)
			if tradeTypeName == "" {
				tradeTypeName = string(multienv.GetTradeCodeTypeMapping()[quote.TradeTypeCode])
			}
			apiErr := errors.NewBizErrWithMsg(errors.CodeNPartnerInviteTypeMismatch, "该账号%s的业务类型为%s，不支持%s报价。如需切换业务类型，请伙伴与客户完成业务类型变更后，再发起报价。若有疑问，可联系渠道运营同学。").WithArgs(accountID, grantTypeName, tradeTypeName)
			return failCheckResult(result, apiErr), nil
		}
	}
	return result, nil
}

func (r *CustomerQuoteQualificationRule) directCustomerFinancialRoleCheck(roleInfoList []*account_service.ListAccountFinancialRoleResp, result *CheckResult) (*CheckResult, error) {
	for _, roleInfo := range roleInfoList {
		if util.Int32In(account_service.FinancialBizRoleFinalCustomer, roleInfo.FinancialRoleList) {
			apiErr := errors.NewBizErrWithMsg(errors.CodeNAccountExistsDistributionRelation, "该账号%s存在代销关系，不支持直销报价。如需直销报价，请在伙伴管理平台解除代销关系。若有疑问，可联系生态运营/ 渠道运营同学").WithArgs(roleInfo.AccountID)
			return failCheckResult(result, apiErr), nil
		}
	}
	return result, nil
}

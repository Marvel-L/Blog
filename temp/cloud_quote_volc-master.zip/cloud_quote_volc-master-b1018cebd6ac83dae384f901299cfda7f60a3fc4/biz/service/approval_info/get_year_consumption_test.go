package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_GetYearConsumption_BitsUTGen(t *testing.T) {
	t.Run("ApiID为空或不存在时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟ApiID获取失败
			mockey.MockUnsafe(one_service.GetApiID).Return("", false).Build()

			// 构造参数，Id不需要显式赋值（使用零值）
			ctx := context.Background()
			quote := &model.Quote{}

			resp, errDetail := GetYearConsumption(ctx, quote)

			// 断言错误返回
			convey.So(resp, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "YearConsumptionQueryID not found")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoYearConsumption)
		})
	})

	t.Run("OneService查询返回错误时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟ApiID正常返回
			mockey.MockUnsafe(one_service.GetApiID).Return("api-123", true).Build()
			// 模拟OneService调用返回错误
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]YearConsumptionResult]).
				To(func(ctx context.Context, apiId string, params map[string]interface{}) ([]YearConsumptionResult, error) {
					return nil, errors.New("backend failure")
				}).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PAN-001", CustomerName: "CN-001"}

			resp, errDetail := GetYearConsumption(ctx, quote)

			// 断言错误返回
			convey.So(resp, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "backend failure")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoYearConsumption)
		})
	})

	t.Run("成功解析返回消费聚合", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟ApiID正常返回
			mockey.MockUnsafe(one_service.GetApiID).Return("api-xyz", true).Build()
			// 模拟i18n转换
			mockey.MockUnsafe(i18nfmt.Sprint).Return(
				mockey.Sequence("PUB").Then("PRI"),
			).Build()
			// 模拟OneService调用成功返回两条数据
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]YearConsumptionResult]).
				To(func(ctx context.Context, apiId string, params map[string]interface{}) ([]YearConsumptionResult, error) {
					return []YearConsumptionResult{
						{GoodsDeploymentType: "公有云", SumAccrualAmount: decimal.NewFromFloat(10.5)},
						{GoodsDeploymentType: "私有云", SumAccrualAmount: decimal.NewFromFloat(20.25)},
					}, nil
				}).Build()

			ctx := context.Background()
			quote := &model.Quote{
				ParentAccountNumber: "PAN-XYZ",
				CustomerName:        "CN-XYZ",
			}

			resp, errDetail := GetYearConsumption(ctx, quote)

			// 成功分支断言
			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			// 校验键值是否正确
			convey.So(resp["PUB"].String(), convey.ShouldEqual, decimal.NewFromFloat(10.5).String())
			convey.So(resp["PRI"].String(), convey.ShouldEqual, decimal.NewFromFloat(20.25).String())
			// 校验汇总值
			expectedAll := decimal.NewFromFloat(10.5).Add(decimal.NewFromFloat(20.25))
			convey.So(resp[allDeploymentType].String(), convey.ShouldEqual, expectedAll.String())
		})
	})
}

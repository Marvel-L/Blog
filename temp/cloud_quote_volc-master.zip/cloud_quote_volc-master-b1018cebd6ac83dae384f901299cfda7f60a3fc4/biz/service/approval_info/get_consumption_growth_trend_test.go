package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_GetConsumptionGrowthTrend_BitsUTGen(t *testing.T) {
	t.Run("获取消费趋势失败返回错误详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockErr := errors.New("mock error")
			mockey.Mock(getConsumptionGrowthTrendData).Return([]ConsumptionGrowthTrendData(nil), mockErr).Build()

			ctx := context.Background()
			quote := &model.Quote{}

			result, detail := GetConsumptionGrowthTrend(ctx, quote)

			convey.So(result, convey.ShouldBeNil)
			convey.So(detail, convey.ShouldNotBeNil)
			convey.So(detail.ErrorMsg, convey.ShouldEqual, mockErr.Error())
			convey.So(detail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoGrowthTrend)
		})
	})

	t.Run("成功聚合消费趋势数据", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			translate := func(input string) string {
				return input + "_翻译"
			}
			mockData := []ConsumptionGrowthTrendData{
				{Cmonth: "", GoodsDeploymentType: "type1", SumAccrualAmount: decimal.NewFromFloat(999)},
				{Cmonth: "2024-01", GoodsDeploymentType: "type1", SumAccrualAmount: decimal.NewFromFloat(10)},
				{Cmonth: "2024-02", GoodsDeploymentType: "type1", SumAccrualAmount: decimal.NewFromFloat(20)},
				{Cmonth: "2024-03", GoodsDeploymentType: "type2", SumAccrualAmount: decimal.NewFromFloat(5)},
				{Cmonth: "2024-04", GoodsDeploymentType: "", SumAccrualAmount: decimal.NewFromFloat(1)},
			}
			mockey.Mock(getConsumptionGrowthTrendData).Return(mockData, nil).Build()
			mockey.MockUnsafe(i18nfmt.Sprint).To(func(ctx context.Context, format string) string {
				return translate(format)
			}).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent", CustomerName: "customer"}

			result, detail := GetConsumptionGrowthTrend(ctx, quote)

			convey.So(detail, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)

			type1Key := translate("type1")
			monthMap1Iface, existType1 := result[type1Key]
			convey.So(existType1, convey.ShouldBeTrue)
			monthMap1, ok := monthMap1Iface.(map[string]decimal.Decimal)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(monthMap1, convey.ShouldNotBeNil)
			convey.So(len(monthMap1), convey.ShouldEqual, 2)

			vJan, existJan := monthMap1["2024-01"]
			convey.So(existJan, convey.ShouldBeTrue)
			convey.So(vJan.Equal(decimal.NewFromFloat(10)), convey.ShouldBeTrue)

			vFeb, existFeb := monthMap1["2024-02"]
			convey.So(existFeb, convey.ShouldBeTrue)
			convey.So(vFeb.Equal(decimal.NewFromFloat(20)), convey.ShouldBeTrue)

			_, existBlank := monthMap1[""]
			convey.So(existBlank, convey.ShouldBeFalse)

			type2Key := translate("type2")
			monthMap2Iface, existType2 := result[type2Key]
			convey.So(existType2, convey.ShouldBeTrue)
			monthMap2, ok := monthMap2Iface.(map[string]decimal.Decimal)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(monthMap2, convey.ShouldNotBeNil)
			convey.So(len(monthMap2), convey.ShouldEqual, 1)

			vMar, existMar := monthMap2["2024-03"]
			convey.So(existMar, convey.ShouldBeTrue)
			convey.So(vMar.Equal(decimal.NewFromFloat(5)), convey.ShouldBeTrue)
		})
	})
}

func Test_getConsumptionGrowthTrendData_BitsUTGen(t *testing.T) {
	t.Run("获取接口ID失败时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{}
			quote.Id = 11

			mockey.MockUnsafe(one_service.GetApiID).Return("", false).Build()

			data, err := getConsumptionGrowthTrendData(ctx, quote)

			convey.So(data, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "firstProductLineProductApiId not found")
		})
	})

	t.Run("查询消费趋势接口报错时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent-001", CustomerName: "cust-a"}
			quote.Id = 22
			mockApiID := "api-456"
			mockParams := map[string]interface{}{"parent_account_number": "mock"}
			mockErr := errors.New("mock fail")

			mockey.MockUnsafe(one_service.GetApiID).Return(mockApiID, true).Build()
			mockey.MockUnsafe(one_service.BuildParentParams).Return(mockParams).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]ConsumptionGrowthTrendData]).To(func(ctx context.Context, apiID string, params map[string]interface{}) ([]ConsumptionGrowthTrendData, error) {
				convey.So(apiID, convey.ShouldEqual, mockApiID)
				convey.So(params, convey.ShouldResemble, mockParams)
				var empty []ConsumptionGrowthTrendData
				return empty, mockErr
			}).Build()

			data, err := getConsumptionGrowthTrendData(ctx, quote)

			convey.So(data, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock fail")
		})
	})

	t.Run("成功获取消费趋势数据", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent-002", CustomerName: "cust-b"}
			quote.Id = 33
			mockApiID := "api-success"
			mockParams := map[string]interface{}{"parent_account_number": "mock-success"}
			expected := []ConsumptionGrowthTrendData{
				{Cmonth: "2024-01", GoodsDeploymentType: "type-a", SumAccrualAmount: decimal.NewFromFloat(123.45)},
				{Cmonth: "2024-02", GoodsDeploymentType: "type-b", SumAccrualAmount: decimal.NewFromFloat(67.89)},
			}

			mockey.MockUnsafe(one_service.GetApiID).Return(mockApiID, true).Build()
			mockey.MockUnsafe(one_service.BuildParentParams).Return(mockParams).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]ConsumptionGrowthTrendData]).To(func(ctx context.Context, apiID string, params map[string]interface{}) ([]ConsumptionGrowthTrendData, error) {
				convey.So(apiID, convey.ShouldEqual, mockApiID)
				convey.So(params, convey.ShouldResemble, mockParams)
				return expected, nil
			}).Build()

			data, err := getConsumptionGrowthTrendData(ctx, quote)

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldResemble, expected)
		})
	})
}

package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_GetQuantityPriceConsumption_BitsUTGen(t *testing.T) {
	t.Run("字节加速环境返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟字节加速环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			ctx := context.Background()
			quote := &model.Quote{
				QuoteType:           0,
				ParentAccountNumber: "parent-001",
			}

			res, err := GetQuantityPriceConsumption(ctx, quote)

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("项目制或父账号为空返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非字节加速环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			ctx := context.Background()

			// 场景一：项目制
			projectQuote := &model.Quote{
				QuoteType:           multienv.QuoteTypeProjectBased,
				ParentAccountNumber: "parent-002",
			}
			res1, err1 := GetQuantityPriceConsumption(ctx, projectQuote)
			convey.So(res1, convey.ShouldBeNil)
			convey.So(err1, convey.ShouldBeNil)

			// 场景二：父账号为空
			emptyParentQuote := &model.Quote{
				QuoteType:           0,
				ParentAccountNumber: "",
			}
			res2, err2 := GetQuantityPriceConsumption(ctx, emptyParentQuote)
			convey.So(res2, convey.ShouldBeNil)
			convey.So(err2, convey.ShouldBeNil)
		})
	})

	t.Run("一站式API返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非字节加速环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// 模拟一站式接口报错
			apiErr := errors.New("db failed")
			mockey.Mock(one_service.GetCustomerIncomeMonthly).Return(nil, apiErr).Build()

			ctx := context.Background()
			quote := &model.Quote{
				QuoteType:           0,
				ParentAccountNumber: "parent-003",
			}

			res, errDetail := GetQuantityPriceConsumption(ctx, quote)

			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "db failed")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoQuantityPriceConsumption)
		})
	})

	t.Run("成功返回月消耗与年总额", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非字节加速环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			// 模拟成功返回，其中包含需要跳过的记录和需要累加的记录
			results := []*one_service.AccountIncomeResult{
				{Cmonth: "", AccrualAmount: "10"},          // 跳过：月份为空
				{Cmonth: "2024-01", AccrualAmount: ""},     // 跳过：金额为空
				{Cmonth: "2024-01", AccrualAmount: "10.5"}, // 2024-01 累加项1
				{Cmonth: "2024-02", AccrualAmount: "20"},   // 2024-02
				{Cmonth: "2024-01", AccrualAmount: "0.5"},  // 2024-01 累加项2
			}
			mockey.Mock(one_service.GetCustomerIncomeMonthly).Return(results, nil).Build()

			ctx := context.Background()
			quote := &model.Quote{
				QuoteType:           0,
				ParentAccountNumber: "parent-004",
			}

			res, errDetail := GetQuantityPriceConsumption(ctx, quote)

			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)

			// 校验年总额
			sumVal, ok := res["sum_price"].(decimal.Decimal)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(sumVal, convey.ShouldResemble, decimal.RequireFromString("31.0"))

			// 校验月度消耗
			monthMap, ok := res["month_price"].(map[string]decimal.Decimal)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(monthMap["2024-01"], convey.ShouldResemble, decimal.RequireFromString("11.0"))
			convey.So(monthMap["2024-02"], convey.ShouldResemble, decimal.RequireFromString("20"))
		})
	})
}

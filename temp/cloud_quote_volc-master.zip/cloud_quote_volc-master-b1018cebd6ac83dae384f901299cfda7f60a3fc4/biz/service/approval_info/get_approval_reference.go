package approval_info

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"
	"encoding/json"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/golimit"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/gopkg/logs"
)

type GetQuoteApprovalReferenceReq struct {
	QuoteID     int64
	MessageKeys []string
}

type GetQuoteApprovalReferenceResp struct {
	GraphMap map[string]interface{}
	ErrorMap map[string]*ErrorDetail
}

type ErrorDetail struct {
	ErrorMsg  string
	ErrorCode errors.ErrorCodeN
}

type ApprovalRoleSupportKey struct {
	Role string
	Keys []string
}
type referenceResultItem struct {
	key       string
	result    interface{}
	errDetail *ErrorDetail
}

func (r *GetQuoteApprovalReferenceReq) Handle(ctx context.Context) (interface{}, error) {
	// 1、过滤报价单
	tx := dal.DBProxy.NewRequest(ctx)
	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		return nil, err
	}
	if quote == nil || quote.IsInnerQuoteV2() {
		logs.CtxInfo(ctx, "内部报价单, 无需获取审批人参考信息")
		return nil, nil
	}
	// 2、获取query中支持的key
	supportQueryKeys := r.GetSupportQueryKeys(ctx)
	if len(supportQueryKeys) == 0 {
		logs.CtxWarn(ctx, "当前用户角色不支持任何参考key, input=%v", r.MessageKeys)
		return &GetQuoteApprovalReferenceResp{GraphMap: nil}, nil
	}

	// 3、获取key对应的参考信息
	graph, errMap := fetchReferenceInfo(ctx, quote, supportQueryKeys)
	return &GetQuoteApprovalReferenceResp{GraphMap: graph, ErrorMap: errMap}, nil
}

func (r *GetQuoteApprovalReferenceReq) GetSupportQueryKeys(ctx context.Context) map[string]struct{} {
	// 1、获取当前用户支持的审批信息key
	userSupportApprovalKeys := r.GetUserSupportApprovalKeys(ctx)
	if len(userSupportApprovalKeys) == 0 {
		return nil
	}
	// 2、获取入参中当前角色支持的审批信息key
	supportQueryKeys := make(map[string]struct{})
	for _, key := range r.MessageKeys {
		if _, ok := userSupportApprovalKeys[key]; ok {
			supportQueryKeys[key] = struct{}{}
		}
	}
	return supportQueryKeys
}

func (r *GetQuoteApprovalReferenceReq) GetUserSupportApprovalKeys(ctx context.Context) map[string]struct{} {
	// 1、获取当前用户角色
	currentUser, err := dal.AccountDao.CurrentUser(ctx)
	if err != nil || currentUser == nil {
		logs.CtxError(ctx, "getSupportQueryKeys CurrentUser fail, err=%v", err)
		return nil
	}
	accountTypeArr := strings.Split(string(currentUser.AccountType), ",")

	// 2、从TCC读取角色支持的key配置
	roleWhiteList := config.GetSwitchWhiteList(ctx, config.SwitchApprovalInfoRolePermissions)
	if len(roleWhiteList) == 0 {
		logs.CtxInfo(ctx, "ApprovalInfoRolePermissions.WhiteList empty")
		return nil
	}
	roleKeyMap := make(map[string][]string)
	for _, roleSupportKeyStr := range roleWhiteList {
		var roleSupportKey ApprovalRoleSupportKey
		if err = json.Unmarshal([]byte(roleSupportKeyStr), &roleSupportKey); err != nil {
			logs.CtxWarn(ctx, "parse role support key fail, roleSupportKeyStr=%s, err=%v", roleSupportKeyStr, err)
			continue
		}
		roleKeyMap[roleSupportKey.Role] = roleSupportKey.Keys
	}

	// 3、计算当前用户支持的key
	userSupportKeyMap := make(map[string]struct{})
	for _, role := range accountTypeArr {
		if keys, ok := roleKeyMap[role]; ok {
			for _, key := range keys {
				userSupportKeyMap[key] = struct{}{}
			}
		}
	}
	return userSupportKeyMap
}

// 并发获取各个key的参考信息
func fetchReferenceInfo(ctx context.Context, quote *model.Quote, keys map[string]struct{}) (map[string]interface{}, map[string]*ErrorDetail) {
	// 统计有效任务数量，避免读写不一致
	taskCount := 0
	for key := range keys {
		if referenceFetcherRegistry[key] != nil {
			taskCount++
		} else {
			logs.CtxWarn(ctx, "reference fetcher not found for key=%s", key)
		}
	}
	results := map[string]interface{}{}
	errorMap := make(map[string]*ErrorDetail)
	if taskCount == 0 {
		return results, errorMap
	}

	g := golimit.NewG(taskCount)
	respChan := make(chan referenceResultItem, taskCount)
	for key := range keys {
		f := referenceFetcherRegistry[key]
		if f == nil {
			continue
		}
		k := key
		g.Run(func() {
			r, errDetail := f(ctx, quote)
			respChan <- referenceResultItem{key: k, result: r, errDetail: errDetail}
		})
	}

	for i := 0; i < taskCount; i++ {
		item := <-respChan
		if item.errDetail != nil {
			logs.CtxInfo(ctx, "fetch reference fail, key=%s, err=%v", item.key, item.errDetail)
			errorMap[item.key] = item.errDetail
			continue
		}
		results[item.key] = item.result
	}
	close(respChan)
	return results, errorMap
}

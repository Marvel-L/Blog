package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_GetOverdueAmount_BitsUTGen(t *testing.T) {
	t.Run("BytePlus 环境返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟BytePlus环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			quote := &model.Quote{ParentAccountNumber: "P001", CustomerName: "客户A"}
			retMap, detail := GetOverdueAmount(context.Background(), quote)

			convey.So(retMap, convey.ShouldBeNil)
			convey.So(detail, convey.ShouldBeNil)
		})
	})

	t.Run("获取逾期金额数据失败返回错误详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 保证非BytePlus环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// 模拟内部数据获取失败
			mockey.Mock(getOverdueAmountData).Return(nil, errors.New("mock err")).Build()

			quote := &model.Quote{ParentAccountNumber: "P002", CustomerName: "客户B"}
			retMap, detail := GetOverdueAmount(context.Background(), quote)

			convey.So(retMap, convey.ShouldBeNil)
			convey.So(detail, convey.ShouldNotBeNil)
			convey.So(detail.ErrorMsg, convey.ShouldContainSubstring, "mock err")
			convey.So(detail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoOverdueAmount)
		})
	})

	t.Run("成功返回逾期金额与逾期率", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 保证非BytePlus环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// 模拟成功返回数据
			mockData := &OverdueAmountData{
				OverdueAmountAll: decimal.NewFromFloat(123.45),
				OverdueRate:      decimal.NewFromFloat(0.12),
			}
			mockey.Mock(getOverdueAmountData).Return(mockData, nil).Build()

			quote := &model.Quote{ParentAccountNumber: "P003", CustomerName: "客户C"}
			retMap, detail := GetOverdueAmount(context.Background(), quote)

			convey.So(detail, convey.ShouldBeNil)
			convey.So(retMap, convey.ShouldNotBeNil)
			convey.So(retMap[OverdueAmountKey].String(), convey.ShouldEqual, decimal.NewFromFloat(123.45).String())
			convey.So(retMap[OverdueRateKey].String(), convey.ShouldEqual, decimal.NewFromFloat(0.12).String())
		})
	})
}

func Test_getOverdueAmountData_BitsUTGen(t *testing.T) {
	t.Run("当未获取到逾期金额接口ID时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent", CustomerName: "customer"}
			quote.Id = 123
			mockey.MockUnsafe(one_service.GetApiID).Return("", false).Build()

			data, err := getOverdueAmountData(ctx, quote)

			convey.So(data, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "overdueAmountApiId not found")
		})
	})

	t.Run("当查询逾期金额接口报错时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent", CustomerName: "customer"}
			quote.Id = 456
			mockErr := errors.New("mock one service error")
			mockey.MockUnsafe(one_service.GetApiID).Return("api123", true).Build()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[OverdueAmountData]).To(func(ctx context.Context, apiId string, params map[string]interface{}) (OverdueAmountData, error) {
				return OverdueAmountData{}, mockErr
			}).Build()

			data, err := getOverdueAmountData(ctx, quote)

			convey.So(data, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})

	t.Run("当成功获取逾期金额数据时返回结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent", CustomerName: "customer"}
			quote.Id = 789
			expectedData := OverdueAmountData{
				MainCustomerName:   "main",
				MainCustomerNumber: "number",
				OverdueAmountAll:   decimal.NewFromFloat(12.34),
				OverdueRate:        decimal.NewFromFloat(56.78),
			}
			mockey.MockUnsafe(one_service.GetApiID).Return("api456", true).Build()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[OverdueAmountData]).To(func(ctx context.Context, apiId string, params map[string]interface{}) (OverdueAmountData, error) {
				return expectedData, nil
			}).Build()

			data, err := getOverdueAmountData(ctx, quote)

			convey.So(err, convey.ShouldBeNil)
			convey.So(data, convey.ShouldNotBeNil)
			convey.So(*data, convey.ShouldResemble, expectedData)
		})
	})
}

package approval_info

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

// 结果键常量（用于汇总返回）
const quantityPriceSumPrice = "sum_price"
const quantityPriceMonthPrice = "month_price"

// GetQuantityPriceConsumption 获取公有云量价月消耗+年消耗
func GetQuantityPriceConsumption(ctx context.Context, quote *model.Quote) (map[string]interface{}, *ErrorDetail) {
	if multienv.IsBytePlus() {
		return nil, nil
	}
	if quote.IsProjectBased() || quote.ParentAccountNumber == "" {
		return nil, nil
	}
	parentAccountNumber := quote.ParentAccountNumber
	results, err := one_service.GetCustomerIncomeMonthly(ctx, parentAccountNumber)
	if err != nil {
		logs.CtxError(ctx, "GetCustomerIncome failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoQuantityPriceConsumption,
		}
	}
	monthConsumption := map[string]decimal.Decimal{}
	yearConsumption := decimal.Zero
	for _, result := range results {
		if result.Cmonth == "" || result.AccrualAmount == "" {
			continue
		}
		val := decimal.RequireFromString(result.AccrualAmount)
		if cur, ok := monthConsumption[result.Cmonth]; ok {
			monthConsumption[result.Cmonth] = cur.Add(val)
		} else {
			monthConsumption[result.Cmonth] = val
		}
		yearConsumption = yearConsumption.Add(val)
	}

	res := map[string]interface{}{
		quantityPriceSumPrice:   yearConsumption,
		quantityPriceMonthPrice: monthConsumption,
	}
	return res, nil
}

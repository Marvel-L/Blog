package approval_info

import (
	"context"
	errors "errors"
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	v2 "code.byted.org/gopkg/gorm/v2"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	gorm "gorm.io/gorm"
	"reflect"
)

func Test_GetCooperationTime_BitsUTGen(t *testing.T) {
	t.Run("查询报价单失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest 返回一个空的 *gorm.DB
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单失败
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return(nil, errors.New("db error")).Build()

			ctx := context.Background()
			quote := &model.Quote{CustomerName: "Acme"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoCooperationTime)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "db error")
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldEqual, 0)
		})
	})

	t.Run("无已生效报价单返回0", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单成功但为空
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return([]*model.Quote{}, nil).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PN-001"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldEqual, 0)
		})
	})

	t.Run("查询合同号失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单成功且非空
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return([]*model.Quote{{}}, nil).Build()

			// Mock 查询合同号失败
			mockey.Mock(mockey.GetMethod(dal.QuoteContractDao, "ContractCodesByQuoteIDs")).Return(nil, errors.New("contract dao error")).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PN-002"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoCooperationTime)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "contract dao error")
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldEqual, 0)
		})
	})

	t.Run("无合同号返回0", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单成功且非空
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return([]*model.Quote{{}}, nil).Build()

			// Mock 合同号为空
			mockey.Mock(mockey.GetMethod(dal.QuoteContractDao, "ContractCodesByQuoteIDs")).Return([]string{}, nil).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PN-003"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldEqual, 0)
		})
	})

	t.Run("查询合同信息失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单成功且非空
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return([]*model.Quote{{}}, nil).Build()

			// Mock 合同号非空
			mockey.Mock(mockey.GetMethod(dal.QuoteContractDao, "ContractCodesByQuoteIDs")).Return([]string{"C-001"}, nil).Build()

			// Mock 查询合同信息失败
			mockey.Mock(contract_client.ListContractTime).Return(nil, errors.New("list contract meta error")).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PN-004"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoCooperationTime)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "list contract meta error")
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldEqual, 0)
		})
	})

	t.Run("成功返回计算的合作时间", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock 查询报价单成功且非空
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).Return([]*model.Quote{{}}, nil).Build()

			// Mock 合同号非空
			mockey.Mock(mockey.GetMethod(dal.QuoteContractDao, "ContractCodesByQuoteIDs")).Return([]string{"C-001", "C-002"}, nil).Build()

			// 构造合同开始时间早于当前，结束时间晚于当前
			start := time.Now().Add(-10 * 24 * time.Hour).Format("2006-01-02 15:04:05")
			endFuture := time.Now().Add(5 * 24 * time.Hour).Format("2006-01-02 15:04:05")
			cts := []*contract_client.ContractTime{
				{ContractCode: "C-001", BeginTime: start, EndTime: endFuture},
				{ContractCode: "C-002", BeginTime: "", EndTime: ""}, // 无效数据，校验忽略
			}
			mockey.Mock(contract_client.ListContractTime).Return(cts, nil).Build()

			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "PN-005"}

			ret, errDetail := GetCooperationTime(ctx, quote)

			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(ret.Cmp(decimal.Zero), convey.ShouldBeGreaterThan, 0)
		})
	})

}

func Test_calMaxCooperationTime_BitsUTGen(t *testing.T) {
	t.Run("无有效开始时间返回0", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 这里会触发日志调用，避免默认logger为空导致的空指针
			mockey.MockUnsafe(logs.CtxInfo).Return().Build()

			ctx := context.Background()
			contractTimes := []*contract_client.ContractTime{
				nil,
				{BeginTime: "", EndTime: ""}, // 空值
				{BeginTime: "invalid time", EndTime: time.Now().Format(util.DBDateFormatTpl)}, // 开始时间不可解析
			}

			res := calMaxCooperationTime(ctx, contractTimes)
			convey.So(res, convey.ShouldResemble, decimal.Zero)
		})
	})

	t.Run("开始时间在未来返回0", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			futureBegin := time.Now().Add(2 * time.Hour).Format(util.DBDateFormatTpl)
			contractTimes := []*contract_client.ContractTime{
				{BeginTime: futureBegin, EndTime: ""}, // 开始时间在未来
			}

			res := calMaxCooperationTime(ctx, contractTimes)
			convey.So(res, convey.ShouldResemble, decimal.Zero)
		})
	})

	t.Run("无限合同无结束时间按当前时间计算", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 为了稳定断言，这里对decimal的Div与Mul进行打桩
			// Div返回固定值，Mul也返回固定值，确保最终返回可断言
			mockey.MockUnsafe(decimal.Decimal.Div).Return(decimal.NewFromInt(101)).Build()
			mockey.MockUnsafe(decimal.Decimal.Mul).Return(decimal.NewFromInt(202)).Build()

			ctx := context.Background()
			pastBegin := time.Now().Add(-2 * time.Hour).Format(util.DBDateFormatTpl)
			contractTimes := []*contract_client.ContractTime{
				{BeginTime: pastBegin, EndTime: ""}, // 没有结束时间
			}

			res := calMaxCooperationTime(ctx, contractTimes)
			convey.So(res, convey.ShouldResemble, decimal.NewFromInt(202))
		})
	})

	t.Run("合同未结束将结束时间置为现在", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 同样对decimal进行打桩，确保结果稳定
			mockey.MockUnsafe(decimal.Decimal.Div).Return(decimal.NewFromInt(7)).Build()
			mockey.MockUnsafe(decimal.Decimal.Mul).Return(decimal.NewFromInt(77)).Build()

			ctx := context.Background()
			pastBegin := time.Now().Add(-1 * time.Hour).Format(util.DBDateFormatTpl)
			futureEnd := time.Now().Add(3 * time.Hour).Format(util.DBDateFormatTpl)
			contractTimes := []*contract_client.ContractTime{
				{BeginTime: pastBegin, EndTime: futureEnd}, // 结束时间在未来
			}

			res := calMaxCooperationTime(ctx, contractTimes)
			convey.So(res, convey.ShouldResemble, decimal.NewFromInt(77))
		})
	})
}

func Test_getEffectiveQuotesByCustomerInfo_BitsUTGen(t *testing.T) {
	t.Run("BP环境-查询已生效报价-返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟BP环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			// 在桩函数内部校验条件，避免外部引用条件造成不可预期问题
			var statusOk, sceneOk, hasCustName, hasParentNum bool
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).To(
				func(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.Quote, error) {
					if v, ok := condition["quote_status"]; ok {
						statusOk = v == constants.StatusEffective
					}
					if v, ok := condition["quote_scene"]; ok {
						if scenes, ok2 := v.([]multienv.QuoteScene); ok2 {
							sceneOk = reflect.DeepEqual(scenes, multienv.GetQuoteSceneWithOutChangeDiscount())
						}
					}
					_, hasCustName = condition["customer_name"]
					_, hasParentNum = condition["parent_account_number"]
					return nil, errors.New("mock db err")
				},
			).Build()

			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "CustA",
				ParentAccountNumber: "ParentX",
			}

			ids, err := getEffectiveQuotesByCustomerInfo(ctx, nil, quote)

			// 断言错误返回
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock db err")
			convey.So(ids, convey.ShouldBeNil)

			// 校验条件是否正确（BP环境应使用customer_name）
			convey.So(statusOk, convey.ShouldBeTrue)
			convey.So(sceneOk, convey.ShouldBeTrue)
			convey.So(hasCustName, convey.ShouldBeTrue)
			convey.So(hasParentNum, convey.ShouldBeFalse)
		})
	})

	t.Run("BP环境-查询已生效报价-成功返回ID列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟BP环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			var statusOk, sceneOk, hasCustName, hasParentNum bool
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).To(
				func(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.Quote, error) {
					if v, ok := condition["quote_status"]; ok {
						statusOk = v == constants.StatusEffective
					}
					if v, ok := condition["quote_scene"]; ok {
						if scenes, ok2 := v.([]multienv.QuoteScene); ok2 {
							sceneOk = reflect.DeepEqual(scenes, multienv.GetQuoteSceneWithOutChangeDiscount())
						}
					}
					_, hasCustName = condition["customer_name"]
					_, hasParentNum = condition["parent_account_number"]
					return []*model.Quote{
						{BaseDB: framework.BaseDB{Id: 101}},
						{BaseDB: framework.BaseDB{Id: 202}},
					}, nil
				},
			).Build()

			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "CustB",
				ParentAccountNumber: "ParentY",
			}

			ids, err := getEffectiveQuotesByCustomerInfo(ctx, nil, quote)

			// 成功返回
			convey.So(err, convey.ShouldBeNil)
			convey.So(ids, convey.ShouldResemble, []int64{101, 202})

			// 校验条件
			convey.So(statusOk, convey.ShouldBeTrue)
			convey.So(sceneOk, convey.ShouldBeTrue)
			convey.So(hasCustName, convey.ShouldBeTrue)
			convey.So(hasParentNum, convey.ShouldBeFalse)
		})
	})

	t.Run("CN环境-查询已生效报价-成功返回空列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟CN环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			var statusOk, sceneOk, hasCustName, hasParentNum bool
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindAllQuoteByConditions")).To(
				func(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.Quote, error) {
					if v, ok := condition["quote_status"]; ok {
						statusOk = v == constants.StatusEffective
					}
					if v, ok := condition["quote_scene"]; ok {
						if scenes, ok2 := v.([]multienv.QuoteScene); ok2 {
							sceneOk = reflect.DeepEqual(scenes, multienv.GetQuoteSceneWithOutChangeDiscount())
						}
					}
					_, hasCustName = condition["customer_name"]
					_, hasParentNum = condition["parent_account_number"]
					return []*model.Quote{}, nil
				},
			).Build()

			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "CustC",
				ParentAccountNumber: "ParentZ",
			}

			ids, err := getEffectiveQuotesByCustomerInfo(ctx, nil, quote)

			// 成功返回空
			convey.So(err, convey.ShouldBeNil)
			convey.So(ids, convey.ShouldResemble, []int64{})

			// 校验条件（CN环境应使用父级客户编号）
			convey.So(statusOk, convey.ShouldBeTrue)
			convey.So(sceneOk, convey.ShouldBeTrue)
			convey.So(hasParentNum, convey.ShouldBeTrue)
			convey.So(hasCustName, convey.ShouldBeFalse)
		})
	})
}

func Test_parseContractDateTime_BitsUTGen(t *testing.T) {
	t.Run("空字符串输入", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 空字符串直接返回零时间与false
			tm, ok := parseContractDateTime("")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(tm.IsZero(), convey.ShouldBeTrue)
		})
	})

	t.Run("格式错误导致解析失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非法格式触发解析错误，走err!=nil分支
			tm, ok := parseContractDateTime("not-a-date")
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(tm.IsZero(), convey.ShouldBeTrue)
		})
	})

	t.Run("远古占位时间被过滤", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 年份为1的占位时间需要被过滤，返回零时间与false
			s := "0001-01-01 00:00:00"
			tm, ok := parseContractDateTime(s)
			convey.So(ok, convey.ShouldBeFalse)
			convey.So(tm.IsZero(), convey.ShouldBeTrue)
		})
	})

	t.Run("合法时间解析成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法时间应解析成功，返回非零时间与true
			s := "2024-12-31 23:59:58"
			tm, ok := parseContractDateTime(s)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(tm.IsZero(), convey.ShouldBeFalse)

			// 与util.ParseInLocation结果保持一致
			expect, err := util.ParseInLocation(util.DBDateFormatTpl, s)
			convey.So(err, convey.ShouldBeNil)
			convey.So(tm.Equal(expect), convey.ShouldBeTrue)
		})
	})
}

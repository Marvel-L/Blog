package approval_info

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

type OverdueAmountData struct {
	MainCustomerName   string          `gorm:"column:main_customer_name"`   // 主客户名称
	MainCustomerNumber string          `gorm:"column:main_customer_number"` // 主客户编号
	OverdueAmountAll   decimal.Decimal `gorm:"column:overdue_amount_all"`   // 逾期金额总和
	OverdueRate        decimal.Decimal `gorm:"column:overdue_rate"`         // 逾期率
}

const OverdueRateKey = "overdue_rate"

func GetOverdueAmount(ctx context.Context, quote *model.Quote) (map[string]decimal.Decimal, *ErrorDetail) {
	if multienv.IsBytePlus() {
		return nil, nil
	}
	// 获取逾期金额数据
	overdueAmountResult, err := getOverdueAmountData(ctx, quote)
	if err != nil {
		logs.CtxError(ctx, "GetOverdueAmount failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoOverdueAmount,
		}
	}
	overdueAmountResultMap := map[string]decimal.Decimal{
		OverdueAmountKey: overdueAmountResult.OverdueAmountAll,
		OverdueRateKey:   overdueAmountResult.OverdueRate,
	}
	return overdueAmountResultMap, nil
}

func getOverdueAmountData(ctx context.Context, quote *model.Quote) (*OverdueAmountData, error) {
	// 1、获取逾期金额ApiID
	overdueAmountApiId, ok := one_service.GetApiID(one_service.OverdueAmountQueryID)
	if !ok || overdueAmountApiId == "" {
		logs.CtxError(ctx, "GetOverdueAmount failed, quote_id=%d, err=%s", quote.Id, "overdueAmountApiId not found")
		return nil, errors.ErrInternalError.WithArgs("overdueAmountApiId not found")
	}
	// 2、构造参数
	params := one_service.BuildParentParams(quote.ParentAccountNumber, quote.CustomerName)
	// 3、调用OneService查询一级产品线的消耗比例
	overdueAmountResult, err := one_service.GetOneServiceCommonInfo[OverdueAmountData](ctx, overdueAmountApiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetOverdueAmount failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, err
	}
	return &overdueAmountResult, nil
}

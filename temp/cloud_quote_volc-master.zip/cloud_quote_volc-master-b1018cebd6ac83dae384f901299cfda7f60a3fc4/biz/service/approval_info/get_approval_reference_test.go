package approval_info

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	v2 "code.byted.org/gopkg/gorm/v2"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_fetchReferenceInfo_BitsUTGen(t *testing.T) {
	t.Run("无可用任务返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{}
			fetchers := map[string]ReferenceFetcher{
				"missing": nil,
			}
			mockey.MockValue(&referenceFetcherRegistry).To(fetchers)

			keys := map[string]struct{}{
				"missing": {},
			}
			result, errMap := fetchReferenceInfo(ctx, quote, keys)

			convey.So(result, convey.ShouldBeEmpty)
			convey.So(errMap, convey.ShouldBeEmpty)
		})
	})

	t.Run("全部任务成功写入结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{}
			fetchers := map[string]ReferenceFetcher{
				"key1": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return "value1", nil
				},
				"key2": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return 2, nil
				},
			}
			mockey.MockValue(&referenceFetcherRegistry).To(fetchers)

			keys := map[string]struct{}{
				"key1": {},
				"key2": {},
			}
			result, errMap := fetchReferenceInfo(ctx, quote, keys)

			convey.So(result, convey.ShouldResemble, map[string]interface{}{
				"key1": "value1",
				"key2": 2,
			})
			convey.So(errMap, convey.ShouldBeEmpty)
		})
	})

	t.Run("部分任务失败与跳过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{}
			expectedErr := &ErrorDetail{ErrorMsg: "err"}
			fetchers := map[string]ReferenceFetcher{
				"keyError": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return nil, expectedErr
				},
				"keySuccess": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return "ok", nil
				},
				"keySkip": nil,
			}
			mockey.MockValue(&referenceFetcherRegistry).To(fetchers)

			keys := map[string]struct{}{
				"keyError":   {},
				"keySuccess": {},
				"keySkip":    {},
			}
			result, errMap := fetchReferenceInfo(ctx, quote, keys)

			convey.So(result, convey.ShouldResemble, map[string]interface{}{
				"keySuccess": "ok",
			})
			convey.So(errMap, convey.ShouldHaveLength, 1)
			convey.So(errMap["keyError"], convey.ShouldResemble, expectedErr)
			convey.So(errMap, convey.ShouldNotContainKey, "keySuccess")
		})
	})
}

func Test_GetQuoteApprovalReferenceReq_GetUserSupportApprovalKeys_BitsUTGen(t *testing.T) {
	t.Run("当前用户为空或获取失败时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 避免日志包空指针
			mockey.MockUnsafe(logs.CtxError).Return().Build()
			mockey.MockUnsafe(logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(logs.CtxWarn).Return().Build()

			// 初始化全局变量，保证方法存在
			mockey.MockValue(&dal.AccountDao).To(dal.AccountDao)

			// 无用户上下文，命中首个返回分支
			ctx := context.Background()
			req := &GetQuoteApprovalReferenceReq{}

			res := req.GetUserSupportApprovalKeys(ctx)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("角色白名单为空返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 避免日志包空指针
			mockey.MockUnsafe(logs.CtxError).Return().Build()
			mockey.MockUnsafe(logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(logs.CtxWarn).Return().Build()

			// 初始化全局变量
			mockey.MockValue(&dal.AccountDao).To(dal.AccountDao)

			// 构造有用户但白名单为空，命中第二个返回分支
			user := gptr.Of(model.Account{AccountType: constants.AccountType("roleA")})
			ctx := context.WithValue(context.Background(), constants.CtxCurrentUser, user)
			mockey.Mock(config.GetSwitchWhiteList).Return([]string{}).Build()

			req := &GetQuoteApprovalReferenceReq{}
			res := req.GetUserSupportApprovalKeys(ctx)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("正常返回用户支持的审批keys，包含多角色与重复去重，同时忽略无效JSON", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 避免日志包空指针
			mockey.MockUnsafe(logs.CtxError).Return().Build()
			mockey.MockUnsafe(logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(logs.CtxWarn).Return().Build()

			// 初始化全局变量
			mockey.MockValue(&dal.AccountDao).To(dal.AccountDao)

			// 用户拥有多个角色，其中一个角色在白名单内不存在，覆盖ok=false分支
			user := gptr.Of(model.Account{AccountType: constants.AccountType("roleA,roleB,roleX")})
			ctx := context.WithValue(context.Background(), constants.CtxCurrentUser, user)

			// 白名单包含有效与无效的JSON，且有重复key与无关角色
			roleWhiteList := []string{
				`{"Role":"roleA","Keys":["k1","k2"]}`,
				`{"Role":"roleC","Keys":["k999"]}`,
				`not a json`,
				`{"Role":"roleB","Keys":["k2","k3"]}`,
			}
			mockey.Mock(config.GetSwitchWhiteList).Return(roleWhiteList).Build()

			req := &GetQuoteApprovalReferenceReq{}
			res := req.GetUserSupportApprovalKeys(ctx)

			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 3)

			_, ok1 := res["k1"]
			_, ok2 := res["k2"]
			_, ok3 := res["k3"]
			_, ok999 := res["k999"]

			convey.So(ok1, convey.ShouldBeTrue)
			convey.So(ok2, convey.ShouldBeTrue)
			convey.So(ok3, convey.ShouldBeTrue)
			convey.So(ok999, convey.ShouldBeFalse)
		})
	})
}

func Test_GetQuoteApprovalReferenceReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("数据库查询报错返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与请求
			ctx := context.Background()
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     123,
				MessageKeys: []string{"k1"},
			}

			// 初始化全局DBProxy并mock NewRequest，避免真实依赖
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// mock查询报价单返回错误
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return((*model.Quote)(nil), errors.New("db error")).Build()

			// 执行
			resp, err := req.Handle(ctx)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db error")
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("内部报价单跳过参考信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     456,
				MessageKeys: []string{"k1"},
			}

			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 返回内部报价单
			q := &model.Quote{TradeTypeCode: multienv.CustomerTypeCodeEPSInner}
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(q, nil).Build()

			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("当前用户无支持key返回空图", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     789,
				MessageKeys: []string{"a", "b"},
			}

			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 返回非内部报价单
			q := &model.Quote{TradeTypeCode: 0}
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(q, nil).Build()

			// 当前用户不支持任何key
			mockey.MockUnsafe((*GetQuoteApprovalReferenceReq).GetSupportQueryKeys).Return(map[string]struct{}{}).Build()

			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			respObj, ok := resp.(*GetQuoteApprovalReferenceResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(respObj.GraphMap, convey.ShouldBeNil)
			convey.So(respObj.ErrorMap, convey.ShouldBeNil)
		})
	})

	t.Run("成功返回参考信息包含错误项", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     1001,
				MessageKeys: []string{"k1", "k2", "k3"},
			}

			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 返回非内部报价单
			q := &model.Quote{TradeTypeCode: 0}
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteDao, "FindQuoteByID")).Return(q, nil).Build()

			// 支持的key集合
			mockey.MockUnsafe((*GetQuoteApprovalReferenceReq).GetSupportQueryKeys).Return(map[string]struct{}{
				"k1": {},
				"k2": {},
				"k3": {},
			}).Build()

			// 注册参考信息获取器：k1成功，k2失败，k3未注册（触发缺少fetcher分支）
			mockey.MockValue(&referenceFetcherRegistry).To(map[string]ReferenceFetcher{
				"k1": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return "ok1", nil
				},
				"k2": func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
					return nil, &ErrorDetail{ErrorMsg: "err2"}
				},
				// "k3" 故意不注册
			})

			resp, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			respObj, ok := resp.(*GetQuoteApprovalReferenceResp)
			convey.So(ok, convey.ShouldBeTrue)

			// 结果断言
			convey.So(respObj.GraphMap["k1"], convey.ShouldEqual, "ok1")
			convey.So(respObj.ErrorMap["k2"], convey.ShouldNotBeNil)
			convey.So(respObj.ErrorMap["k2"].ErrorMsg, convey.ShouldEqual, "err2")
			// 未注册的key不应出现在结果或错误中
			convey.So(respObj.GraphMap["k3"], convey.ShouldBeNil)
			convey.So(respObj.ErrorMap["k3"], convey.ShouldBeNil)
		})
	})
}

func Test_GetQuoteApprovalReferenceReq_GetSupportQueryKeys_BitsUTGen(t *testing.T) {
	t.Run("用户支持Key为空时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求入参
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     1,
				MessageKeys: []string{"k1", "k2"},
			}
			// 模拟用户支持的key为空
			mockey.Mock((*GetQuoteApprovalReferenceReq).GetUserSupportApprovalKeys).Return(nil).Build()

			res := req.GetSupportQueryKeys(context.Background())

			// 由于用户支持的key为空，应直接返回nil
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("部分消息Key命中用户支持集合时返回对应子集", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求入参，包含命中与未命中的key以及重复key
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     1,
				MessageKeys: []string{"k1", "k2", "k3", "k3"},
			}
			// 模拟用户支持的key集合
			userKeys := map[string]struct{}{
				"k1": {},
				"k3": {},
			}
			mockey.Mock((*GetQuoteApprovalReferenceReq).GetUserSupportApprovalKeys).Return(userKeys).Build()

			res := req.GetSupportQueryKeys(context.Background())

			// 命中k1和k3，去重后长度为2
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 2)
			convey.So(res, convey.ShouldContainKey, "k1")
			convey.So(res, convey.ShouldContainKey, "k3")
		})
	})

	t.Run("用户支持Key非空但消息Key均不命中时返回空map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求入参，全部为未命中的key
			req := &GetQuoteApprovalReferenceReq{
				QuoteID:     1,
				MessageKeys: []string{"a", "b"},
			}
			// 模拟用户支持的key不为空，但与消息key不匹配
			userKeys := map[string]struct{}{
				"x": {},
				"y": {},
			}
			mockey.Mock((*GetQuoteApprovalReferenceReq).GetUserSupportApprovalKeys).Return(userKeys).Build()

			res := req.GetSupportQueryKeys(context.Background())

			// 返回空map但非nil
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})
	})
}

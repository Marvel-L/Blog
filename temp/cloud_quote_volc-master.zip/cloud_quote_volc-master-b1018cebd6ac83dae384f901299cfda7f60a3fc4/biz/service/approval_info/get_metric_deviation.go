package approval_info

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quantity_price_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
	"gorm.io/gorm"
)

type MetricDeviationData struct {
	Department     string          `gorm:"column:department"`      // 一级产品线
	BizLine        string          `gorm:"column:bizline"`         // 二级产品线
	AvgDiscount    decimal.Decimal `gorm:"column:avg_discount"`    // 平均折扣
	ActualDiscount decimal.Decimal `gorm:"column:actual_discount"` // 实际折扣
}

const (
	AvgDiscountKey              = "avg_discount"                   // 平均折扣
	ActualDiscountKey           = "actual_discount"                // 实际折扣
	QuantityPriceDiscountKey    = "quantity_price_discount"        // 量价折扣
	AvgDeviationRatioKey        = "avg_deviation_ratio"            // 均值偏移率
	QuantityPriceDeviationRatio = "quantity_price_deviation_ratio" // 量价偏移率
)

func GetMetricDeviation(ctx context.Context, quote *model.Quote) (map[string]map[string]map[string]decimal.Decimal, *ErrorDetail) {
	if multienv.IsBytePlus() {
		return nil, nil
	}
	if quote.IsProjectBased() {
		return nil, nil
	}
	// 1、获取二级产品线信息
	tx := dal.DBProxy.NewRequest(ctx)
	bizLineInfoMap, err := getBizLineInfo(ctx, tx, quote)
	if err != nil {
		logs.CtxError(ctx, "MetricDeviation: get biz line info failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoMetricDeviation,
		}
	}
	if len(bizLineInfoMap) == 0 {
		return nil, nil
	}

	// 2、计算报价单的量价金额
	quantityPriceDetail, err := quantity_price_service.GetQuantityPriceDetail(ctx, tx, quote)
	if err != nil {
		logs.CtxError(ctx, "MetricDeviation: get quantity price detail failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoMetricDeviation,
		}
	}
	// 3、获取二级产品线在当前量价区间对应的折扣（使用产品折扣线 DepartmentDiscountLines）
	bizLineToQuantityPriceDiscount := getBizLineToQuantityPriceDiscount(ctx, quote, quantityPriceDetail.QuantityPriceAmount, bizLineInfoMap)

	// 4、从tcc获取一级产品线
	departmentWhiteList := config.GetSwitchWhiteList(ctx, config.SwitchMetricDeviationSupportDepartment)
	if len(departmentWhiteList) == 0 {
		logs.CtxWarn(ctx, "MetricDeviation: switch %s white list is empty, quote_id=%d", config.SwitchMetricDeviationSupportDepartment, quote.Id)
		return nil, nil
	}

	// 5、从OneService查询指标偏差
	metricDeviationData, err := getMetricDeviationData(ctx, quote, departmentWhiteList)
	if err != nil {
		logs.CtxError(ctx, "MetricDeviation: get metric deviation data failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoMetricDeviation,
		}
	}

	// 6、构造返回结果
	metricDeviationResults := buildMetricDeviationResult(metricDeviationData, bizLineToQuantityPriceDiscount)
	return metricDeviationResults, nil

}

// getMetricDeviationData 获取指标偏差数据
func getMetricDeviationData(ctx context.Context, quote *model.Quote, productBizLines []string) ([]MetricDeviationData, error) {
	// 1、获取指标偏差ApiID
	metricDeviationApiId, ok := one_service.GetApiID(one_service.MetricDeviationQueryID)
	if !ok || metricDeviationApiId == "" {
		logs.CtxError(ctx, "GetMetricDeviationData failed, quote_id=%d, err=%s", quote.Id, "metricDeviationApiId not found")
		return nil, errors.ErrInternalError.WithArgs("metricDeviationApiId not found")
	}
	// 2、构造参数
	params := map[string]interface{}{}
	params["parent_account_number"] = quote.ParentAccountNumber
	params["product_biz_lines"] = productBizLines
	// 3、调用OneService查询指标偏差
	metricDeviationResults, err := one_service.GetOneServiceCommonInfo[[]MetricDeviationData](ctx, metricDeviationApiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetMetricDeviationData failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, err
	}
	return metricDeviationResults, nil
}

// getBizLineInfo 获取二级产品线信息map
func getBizLineInfo(ctx context.Context, tx *gorm.DB, quote *model.Quote) (map[string]*product_service.DepartmentInfo, error) {
	// 1、获取二级产品线名称列表
	summary, apiErr := assistant.Callback(
		ctx, tx, quote.Id,
		assistant.WithCallbackInfoKeys([]assistant.CallbackKey{assistant.CallbackKeyBizLine}),
	)
	if apiErr != nil {
		logs.CtxError(ctx, "MetricDeviation: get biz line name failed, quote_id=%d, err=%s", quote.Id, apiErr.Error())
		return nil, apiErr
	}
	if len(summary.BizLineNameList) == 0 {
		logs.CtxInfo(ctx, "MetricDeviation: no public-cloud secondary product lines in quote, quote_id=%d", quote.Id)
		return nil, nil
	}

	// 2、从缓存中读取二级产品线信息
	bizLineInfoMap, err := product_service.ListDepartmentInfoByNamesFromCache(ctx, 2, summary.BizLineNameList)
	if err != nil {
		logs.CtxError(ctx, "MetricDeviation: list biz line from cache failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, err
	}
	return bizLineInfoMap, nil
}

// getBizLineToQuantityPriceDiscount 获取二级产品线到量价折扣的映射
func getBizLineToQuantityPriceDiscount(ctx context.Context, quote *model.Quote, quantityAmount decimal.Decimal, bizLineInfoMap map[string]*product_service.DepartmentInfo) map[string]decimal.Decimal {
	// 1、根据销售渠道选择量价折扣线类型（直销/渠道电销），不考虑保底折扣线
	QuantityPriceLineType := constants.QuantityPriceLineMap[quote.SalesChannelType]
	if QuantityPriceLineType == 0 {
		QuantityPriceLineType = constants.QuantityPriceLineTypeDirect
	}

	// 2、记录每个二级产品线在当前量价区间对应的折扣（使用产品折扣线 DepartmentDiscountLines）
	bizLineToQuantityPriceDiscount := map[string]decimal.Decimal{}
	for name, info := range bizLineInfoMap {
		if info == nil || len(info.QuantityPriceDiscountLines) == 0 {
			logs.CtxWarn(ctx, "MetricDeviation: biz line discount line missing, biz_line=%s", name)
			continue
		}
		quantityPriceDiscountLine := info.QuantityPriceDiscountLines[QuantityPriceLineType]
		if quantityPriceDiscountLine == nil {
			logs.CtxWarn(ctx, "MetricDeviation: biz line type discount line missing, biz_line=%s, type=%d", name, QuantityPriceLineType)
			continue
		}
		// 量价区间边界
		intervalDecimals := util.StrSplitToDecimalArr(quantityPriceDiscountLine.PriceInterval)
		if len(intervalDecimals) == 0 {
			logs.CtxWarn(ctx, "MetricDeviation: price interval empty, biz_line=%s", name)
			continue
		}
		idx := util.IntervalIndexRightClosed(quantityAmount, intervalDecimals)
		// 产品折扣线的折扣值
		departmentDiscountValues := util.StrSplitToDecimalArr(quantityPriceDiscountLine.DepartmentDiscountLines)
		if len(departmentDiscountValues) == 0 {
			logs.CtxWarn(ctx, "MetricDeviation: department discount lines empty, biz_line=%s", name)
			continue
		}
		if idx >= len(departmentDiscountValues) {
			// 容错：索引越界时取最后一个折扣
			idx = len(departmentDiscountValues) - 1
		}
		bizLineToQuantityPriceDiscount[name] = departmentDiscountValues[idx]
	}
	return bizLineToQuantityPriceDiscount

}

// buildMetricDeviationResult 构造指标偏差结果
func buildMetricDeviationResult(metricDeviationData []MetricDeviationData, bizLineToQuantityPriceDiscount map[string]decimal.Decimal) map[string]map[string]map[string]decimal.Decimal {
	// map【一级产品线】【二级产品线】【指标】decimal
	result := map[string]map[string]map[string]decimal.Decimal{}
	for _, data := range metricDeviationData {
		// 实际折扣为null或<=0，直接跳过该条 实际折扣为0，平均折扣必然为0
		if data.ActualDiscount.LessThanOrEqual(decimal.Zero) {
			continue
		}
		// 若该二级产品线没有对应的量价折扣，直接跳过
		quantityPriceDiscount, ok := bizLineToQuantityPriceDiscount[data.BizLine]
		if !ok {
			continue
		}
		if _, ok = result[data.Department]; !ok {
			result[data.Department] = map[string]map[string]decimal.Decimal{}
		}
		if _, ok = result[data.Department][data.BizLine]; !ok {
			result[data.Department][data.BizLine] = map[string]decimal.Decimal{}
		}
		actualDiscount := data.ActualDiscount
		avgDiscount := data.AvgDiscount
		result[data.Department][data.BizLine][ActualDiscountKey] = actualDiscount
		result[data.Department][data.BizLine][AvgDiscountKey] = avgDiscount
		result[data.Department][data.BizLine][QuantityPriceDiscountKey] = quantityPriceDiscount

		// 量价指导线偏移率 QuantityPriceDeviationRatio = (实际折扣 - 量价折扣) / 实际折扣
		result[data.Department][data.BizLine][QuantityPriceDeviationRatio] = (actualDiscount.Sub(quantityPriceDiscount)).Div(actualDiscount)
		// 火山均值偏移率 AvgDeviationRatio = (实际折扣 - 平均折扣) / 实际折扣
		result[data.Department][data.BizLine][AvgDeviationRatioKey] = (actualDiscount.Sub(avgDiscount)).Div(actualDiscount)
	}
	return result
}

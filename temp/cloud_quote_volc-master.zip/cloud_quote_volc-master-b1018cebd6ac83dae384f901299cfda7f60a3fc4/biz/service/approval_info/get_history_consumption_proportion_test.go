package approval_info

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_buildConsumptionProportion_BitsUTGen(t *testing.T) {
	t.Run("总金额为0时返回空map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 总金额为0，提前返回空map
			ctx := context.Background()
			lm := decimal.Zero
			results := []ProductLineConsumptionResult{
				{ProductTeam: cloudBaseProductLine, SumAccrualAmount: decimal.Zero},
				{ProductTeam: "其他A", SumAccrualAmount: decimal.Zero},
			}

			res := buildConsumptionProportion(ctx, lm, results)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})
	})

	t.Run("BytePlus环境下返回大模型与BytePlus云基础占比", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// BytePlus环境下云基础键应为“BytePlus-云基础”，并返回大模型占比
			ctx := context.Background()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()
			mockey.MockUnsafe(i18nfmt.Sprint).
				When(func(_ context.Context, format string) bool { return format == largeModelName }).Return("LM").
				When(func(_ context.Context, format string) bool { return format == otherProductLine }).Return("OTHER").
				Build()

			lm := decimal.NewFromFloat(10) // 大模型 10
			results := []ProductLineConsumptionResult{
				{ProductTeam: cloudBaseProductLineBP, SumAccrualAmount: decimal.NewFromFloat(20)}, // 云基础 20
				{ProductTeam: "非云1", SumAccrualAmount: decimal.Zero},                              // 非云为0，不影响分支
			}

			res := buildConsumptionProportion(ctx, lm, results)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res["LM"], convey.ShouldNotBeNil)
			convey.So(res[cloudBaseProductLineBP], convey.ShouldNotBeNil)
			convey.So(res["OTHER"], convey.ShouldBeNil)

			lmRatio := res["LM"].(decimal.Decimal)
			cbRatio := res[cloudBaseProductLineBP].(decimal.Decimal)
			convey.So(lmRatio.IsZero(), convey.ShouldBeFalse)
			convey.So(cbRatio.IsZero(), convey.ShouldBeFalse)
		})
	})

	t.Run("非BytePlus环境且只有非云基础产品线，跳过零金额项", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非云基础分支返回“其他产品线”映射，且跳过零金额项
			ctx := context.Background()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockUnsafe(i18nfmt.Sprint).
				When(func(_ context.Context, format string) bool { return format == largeModelName }).Return("LM").
				When(func(_ context.Context, format string) bool { return format == otherProductLine }).Return("OTHER").
				Build()

			lm := decimal.Zero
			results := []ProductLineConsumptionResult{
				{ProductTeam: cloudBaseProductLine, SumAccrualAmount: decimal.Zero}, // 云基础为0
				{ProductTeam: "其他A", SumAccrualAmount: decimal.NewFromFloat(5)},     // 非云A为5
				{ProductTeam: "其他B", SumAccrualAmount: decimal.Zero},                // 非云B为0，应跳过
			}

			res := buildConsumptionProportion(ctx, lm, results)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res["LM"], convey.ShouldBeNil)
			convey.So(res[cloudBaseProductLine], convey.ShouldBeNil)
			convey.So(res[cloudBaseProductLineBP], convey.ShouldBeNil)

			otherVal := res["OTHER"]
			convey.So(otherVal, convey.ShouldNotBeNil)
			otherMap := otherVal.(map[string]interface{})
			convey.So(otherMap["其他A"], convey.ShouldNotBeNil)
			convey.So(otherMap["其他B"], convey.ShouldBeNil)

			// “其他A”占比应非零
			otherARatio := otherMap["其他A"].(decimal.Decimal)
			convey.So(otherARatio.IsZero(), convey.ShouldBeFalse)
		})
	})

	t.Run("非BytePlus环境且只有云基础产品线", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非BytePlus下云基础键应为“云基础”，且只有云基础占比
			ctx := context.Background()
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockUnsafe(i18nfmt.Sprint).
				When(func(_ context.Context, format string) bool { return format == largeModelName }).Return("LM").
				When(func(_ context.Context, format string) bool { return format == otherProductLine }).Return("OTHER").
				Build()

			lm := decimal.Zero
			results := []ProductLineConsumptionResult{
				{ProductTeam: cloudBaseProductLine, SumAccrualAmount: decimal.NewFromFloat(15)}, // 仅云基础
			}

			res := buildConsumptionProportion(ctx, lm, results)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(res[cloudBaseProductLine], convey.ShouldNotBeNil)
			convey.So(res[cloudBaseProductLineBP], convey.ShouldBeNil)
			convey.So(res["LM"], convey.ShouldBeNil)
			convey.So(res["OTHER"], convey.ShouldBeNil)

			cbRatio := res[cloudBaseProductLine].(decimal.Decimal)
			convey.So(cbRatio.IsZero(), convey.ShouldBeFalse)
		})
	})
}

func Test_GetHistoryConsumptionProportion_BitsUTGen(t *testing.T) {
	t.Run("并发查询大模型失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与输入
			ctx := context.Background()
			quote := &model.Quote{
				ParentAccountNumber: "parent-001",
				CustomerName:        "customer-001",
			}

			// Mock GetApiID：大模型返回未找到，一级产品线返回正常
			mockey.Mock(one_service.GetApiID).
				When(func(key string) bool { return key == one_service.LargeModelProductQueryID }).
				Return("", false).
				When(func(key string) bool { return key == one_service.FirstProductLineProductQueryID }).
				Return("api-first", true).
				Build()

			// Mock 一级产品线查询成功，避免内部真实调用
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]ProductLineConsumptionResult]).
				Return([]ProductLineConsumptionResult{
					{ProductTeam: cloudBaseProductLine, SumAccrualAmount: decimal.NewFromFloat(10.0)},
				}, nil).
				Build()

			// 执行函数
			res, detail := GetHistoryConsumptionProportion(ctx, quote)

			// 断言错误分支（大模型失败）
			convey.So(res, convey.ShouldBeNil)
			convey.So(detail, convey.ShouldNotBeNil)
			convey.So(detail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoConsumptionProportion)
			convey.So(detail.ErrorMsg, convey.ShouldContainSubstring, "not found")
		})
	})

	t.Run("并发查询一级产品线失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与输入
			ctx := context.Background()
			quote := &model.Quote{
				ParentAccountNumber: "parent-002",
				CustomerName:        "customer-002",
			}

			// Mock GetApiID：大模型返回正常，一级产品线返回未找到
			mockey.Mock(one_service.GetApiID).
				When(func(key string) bool { return key == one_service.LargeModelProductQueryID }).
				Return("api-large", true).
				When(func(key string) bool { return key == one_service.FirstProductLineProductQueryID }).
				Return("", false).
				Build()

			// Mock 大模型查询成功
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[float64]).
				Return(13.0, nil).
				Build()

			// 执行函数
			res, detail := GetHistoryConsumptionProportion(ctx, quote)

			// 断言错误分支（一级产品线失败）
			convey.So(res, convey.ShouldBeNil)
			convey.So(detail, convey.ShouldNotBeNil)
			convey.So(detail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoConsumptionProportion)
			convey.So(detail.ErrorMsg, convey.ShouldContainSubstring, "not found")
		})
	})

	t.Run("并发查询成功返回占比结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与输入
			ctx := context.Background()
			quote := &model.Quote{
				ParentAccountNumber: "parent-003",
				CustomerName:        "customer-003",
			}

			// Mock GetApiID：两者都正常返回
			mockey.Mock(one_service.GetApiID).
				When(func(key string) bool { return key == one_service.LargeModelProductQueryID }).
				Return("api-large", true).
				When(func(key string) bool { return key == one_service.FirstProductLineProductQueryID }).
				Return("api-first", true).
				Build()

			// Mock 大模型消费
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[float64]).
				Return(30.0, nil).
				Build()

			// Mock 一级产品线消费：云基础、有其他产品线（含0值以测试跳过）
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]ProductLineConsumptionResult]).
				Return([]ProductLineConsumptionResult{
					{ProductTeam: cloudBaseProductLine, SumAccrualAmount: decimal.NewFromFloat(20.0)},
					{ProductTeam: "存储", SumAccrualAmount: decimal.NewFromFloat(10.0)},
					{ProductTeam: "CDN", SumAccrualAmount: decimal.Zero},
				}, nil).
				Build()

			// Mock i18n：直接返回原文，避免外部依赖
			mockey.MockUnsafe(i18nfmt.Sprint).To(func(_ context.Context, format string) string { return format }).Build()
			// Mock 环境：非BytePlus
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			// 执行函数
			res, detail := GetHistoryConsumptionProportion(ctx, quote)

			// 校验成功分支
			convey.So(detail, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)

			// 校验关键字段存在
			largeKey := i18nfmt.Sprint(ctx, largeModelName)
			otherKey := i18nfmt.Sprint(ctx, otherProductLine)
			convey.So(res[largeKey], convey.ShouldNotBeNil)
			convey.So(res[cloudBaseProductLine], convey.ShouldNotBeNil)
			convey.So(res[otherKey], convey.ShouldNotBeNil)

			// 校验类型与其他产品线明细
			_, okLarge := res[largeKey].(decimal.Decimal)
			_, okCloud := res[cloudBaseProductLine].(decimal.Decimal)
			convey.So(okLarge, convey.ShouldBeTrue)
			convey.So(okCloud, convey.ShouldBeTrue)

			otherMap, okOther := res[otherKey].(map[string]interface{})
			convey.So(okOther, convey.ShouldBeTrue)
			convey.So(otherMap["存储"], convey.ShouldNotBeNil)
			convey.So(otherMap["CDN"], convey.ShouldBeNil)
		})
	})
}

func Test_getLargeModelConsumption_BitsUTGen(t *testing.T) {
	t.Run("获取ApiID失败返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：GetApiID返回空与false，触发内部错误分支
			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "cust",
				ParentAccountNumber: "parent-001",
			}

			amount, err := getLargeModelConsumption(ctx, quote)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "largeModelProductApiId not found")
			convey.So(amount.String(), convey.ShouldEqual, decimal.Zero.String())
		})
	})

	t.Run("OneService查询大模型消耗返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：GetApiID返回正确，但GetOneServiceCommonInfo返回错误
			mockey.MockUnsafe(one_service.GetApiID).Return("api-large-model", true).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[float64]).Return(float64(0), errors.New("query failed")).Build()

			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "cust",
				ParentAccountNumber: "parent-001",
			}

			amount, err := getLargeModelConsumption(ctx, quote)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "query failed")
			convey.So(amount.String(), convey.ShouldEqual, decimal.Zero.String())
		})
	})

	t.Run("查询成功返回大模型消耗Decimal金额", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：GetApiID与GetOneServiceCommonInfo均成功，返回正确金额
			mockey.MockUnsafe(one_service.GetApiID).Return("api-large-model", true).Build()
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[float64]).Return(float64(12.3456), nil).Build()

			ctx := context.Background()
			quote := &model.Quote{
				CustomerName:        "cust",
				ParentAccountNumber: "parent-001",
			}

			amount, err := getLargeModelConsumption(ctx, quote)

			convey.So(err, convey.ShouldBeNil)
			convey.So(amount.String(), convey.ShouldEqual, decimal.NewFromFloat(12.3456).String())
		})
	})
}

func Test_getFirstProductLineConsumption_BitsUTGen(t *testing.T) {
	t.Run("一级产品线ApiID不存在时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备：mock获取ApiID失败
			mockey.Mock(one_service.GetApiID).Return("", false).Build()

			quote := &model.Quote{ParentAccountNumber: "pa-001", CustomerName: "cust-001"}
			ctx := context.Background()

			// 调用
			out, err := getFirstProductLineConsumption(ctx, quote)

			// 断言
			convey.So(out, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "firstProductLineProductApiId not found")
		})
	})

	t.Run("OneService查询失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备：mock获取ApiID成功
			mockey.Mock(one_service.GetApiID).Return("api-first-product-line", true).Build()
			// 准备：mock OneService 查询返回错误
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]ProductLineConsumptionResult]).Return(nil, errors.New("mock query error")).Build()

			quote := &model.Quote{ParentAccountNumber: "pa-002", CustomerName: "cust-002"}
			ctx := context.Background()

			// 调用
			out, err := getFirstProductLineConsumption(ctx, quote)

			// 断言
			convey.So(out, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock query error")
		})
	})
}

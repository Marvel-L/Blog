package approval_info

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_RegisterReferenceFetcher_BitsUTGen(t *testing.T) {
	t.Run("空key不注册", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 重置全局注册表，避免受init影响
			mockey.MockValue(&referenceFetcherRegistry).To(map[string]ReferenceFetcher{})

			// 非nil函数，但key为空
			f := func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
				return "any", nil
			}

			RegisterReferenceFetcher("", f)

			convey.So(len(referenceFetcherRegistry), convey.ShouldEqual, 0)
		})
	})

	t.Run("nil函数不注册", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 重置全局注册表
			mockey.MockValue(&referenceFetcherRegistry).To(map[string]ReferenceFetcher{})

			// 非空key，但函数为nil
			var f ReferenceFetcher = nil
			RegisterReferenceFetcher("key1", f)

			convey.So(len(referenceFetcherRegistry), convey.ShouldEqual, 0)
		})
	})

	t.Run("正常注册成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 重置全局注册表
			mockey.MockValue(&referenceFetcherRegistry).To(map[string]ReferenceFetcher{})

			key := "valid_key"
			f := func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
				return "ok", nil
			}

			RegisterReferenceFetcher(key, f)

			convey.So(len(referenceFetcherRegistry), convey.ShouldEqual, 1)
			convey.So(referenceFetcherRegistry, convey.ShouldContainKey, key)

			// 调用存入的函数，验证确实被注册
			res, errDetail := referenceFetcherRegistry[key](context.Background(), nil)
			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(res, convey.ShouldEqual, "ok")
		})
	})
}

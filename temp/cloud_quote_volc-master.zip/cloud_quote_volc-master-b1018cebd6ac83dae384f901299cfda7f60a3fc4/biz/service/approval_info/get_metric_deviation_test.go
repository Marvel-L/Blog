package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/assistant"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quantity_price_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	v2 "code.byted.org/gopkg/gorm/v2"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	gorm "gorm.io/gorm"
)

func Test_GetMetricDeviation_BitsUTGen(t *testing.T) {
	t.Run("字节Plus环境直接返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备上下文与参数
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0}

			// mock 字节plus环境
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			// 调用
			res, errDetail := GetMetricDeviation(ctx, quote)

			// 断言返回空
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldBeNil)
		})
	})

	t.Run("项目制报价单直接返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			// 项目制
			quote := &model.Quote{QuoteType: multienv.QuoteTypeProjectBased}

			// 非字节plus
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldBeNil)
		})
	})

	t.Run("获取二级产品线信息失败返回错误详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// 初始化DBProxy并mock NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// mock 获取二级产品线失败
			mockey.Mock(getBizLineInfo).Return(nil, errors.New("biz line err")).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "biz line err")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoMetricDeviation)
		})
	})

	t.Run("无二级产品线信息返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 返回空map
			mockey.Mock(getBizLineInfo).Return(map[string]*product_service.DepartmentInfo{}, nil).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldBeNil)
		})
	})

	t.Run("获取量价金额失败返回错误详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 构造非空二级产品线，以便进入下一步
			bizLineInfo := map[string]*product_service.DepartmentInfo{
				"BL1": {Name: "BL1", QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
					1: {PriceInterval: "0,100,200", DepartmentDiscountLines: "0.05,0.1,0.15"},
				}},
			}
			mockey.Mock(getBizLineInfo).Return(bizLineInfo, nil).Build()

			// 量价金额失败
			mockey.Mock(quantity_price_service.GetQuantityPriceDetail).Return(nil, errors.New("qp err")).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "qp err")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoMetricDeviation)
		})
	})

	t.Run("一级产品线白名单为空返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0, SalesChannelType: constants.SalesChannelTypeDirect}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 非空二级产品线
			bizLineInfo := map[string]*product_service.DepartmentInfo{
				"BL1": {Name: "BL1", QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
					1: {PriceInterval: "0,100,200", DepartmentDiscountLines: "0.05,0.1,0.15"},
				}},
			}
			mockey.Mock(getBizLineInfo).Return(bizLineInfo, nil).Build()

			// 量价金额正常
			qp := &quantity_price_service.QuantityPriceDetail{
				QuantityPriceAmount: decimal.NewFromFloat(150),
			}
			mockey.Mock(quantity_price_service.GetQuantityPriceDetail).Return(qp, nil).Build()

			// 白名单为空
			mockey.Mock(config.GetSwitchWhiteList).Return([]string{}).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldBeNil)
		})
	})

	t.Run("查询指标偏差失败返回错误详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0, SalesChannelType: constants.SalesChannelTypeDirect}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 二级产品线非空
			bizLineInfo := map[string]*product_service.DepartmentInfo{
				"BL1": {Name: "BL1", QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
					1: {PriceInterval: "0,100,200", DepartmentDiscountLines: "0.05,0.1,0.15"},
				}},
			}
			mockey.Mock(getBizLineInfo).Return(bizLineInfo, nil).Build()

			// 量价金额正常
			qp := &quantity_price_service.QuantityPriceDetail{
				QuantityPriceAmount: decimal.NewFromFloat(150),
			}
			mockey.Mock(quantity_price_service.GetQuantityPriceDetail).Return(qp, nil).Build()

			// 白名单非空
			mockey.Mock(config.GetSwitchWhiteList).Return([]string{"D1"}).Build()

			// 查询指标偏差失败
			mockey.Mock(getMetricDeviationData).Return(nil, errors.New("one service err")).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(res, convey.ShouldBeNil)
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldContainSubstring, "one service err")
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoMetricDeviation)
		})
	})

	t.Run("正常流程返回正确的指标偏差结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{QuoteType: 0, SalesChannelType: constants.SalesChannelTypeDirect}

			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 二级产品线信息，折扣线与区间设置
			bizLineInfo := map[string]*product_service.DepartmentInfo{
				"BL1": {
					Name: "BL1",
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						1: {PriceInterval: "0,100,200", DepartmentDiscountLines: "0.05,0.1,0.15"},
					},
				},
			}
			mockey.Mock(getBizLineInfo).Return(bizLineInfo, nil).Build()

			// 量价金额：150，命中区间[100,200]，折扣取0.1
			qp := &quantity_price_service.QuantityPriceDetail{
				QuantityPriceAmount: decimal.NewFromFloat(150),
			}
			mockey.Mock(quantity_price_service.GetQuantityPriceDetail).Return(qp, nil).Build()

			// 白名单非空
			mockey.Mock(config.GetSwitchWhiteList).Return([]string{"D1"}).Build()

			// 指标偏差数据
			data := []MetricDeviationData{
				{Department: "D1", BizLine: "BL1", AvgDiscount: decimal.NewFromFloat(0.12), ActualDiscount: decimal.NewFromFloat(0.2)},
				{Department: "D1", BizLine: "BL2", AvgDiscount: decimal.NewFromFloat(0.2), ActualDiscount: decimal.Zero},              // 跳过
				{Department: "D2", BizLine: "BL3", AvgDiscount: decimal.NewFromFloat(0.2), ActualDiscount: decimal.NewFromFloat(0.2)}, // 跳过
			}
			mockey.Mock(getMetricDeviationData).Return(data, nil).Build()

			res, errDetail := GetMetricDeviation(ctx, quote)
			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)

			// 校验结果包含部门与二级产品线
			convey.So(res, convey.ShouldContainKey, "D1")
			convey.So(res["D1"], convey.ShouldContainKey, "BL1")

			// 校验关键指标值
			actual := res["D1"]["BL1"][ActualDiscountKey].String()
			avg := res["D1"]["BL1"][AvgDiscountKey].String()
			qpDiscount := res["D1"]["BL1"][QuantityPriceDiscountKey].String()
			qpDev := res["D1"]["BL1"][QuantityPriceDeviationRatio].String()
			avgDev := res["D1"]["BL1"][AvgDeviationRatioKey].String()

			convey.So(actual, convey.ShouldEqual, decimal.NewFromFloat(0.2).String())
			convey.So(avg, convey.ShouldEqual, decimal.NewFromFloat(0.12).String())
			convey.So(qpDiscount, convey.ShouldEqual, decimal.NewFromFloat(0.1).String())
			// (0.2 - 0.1) / 0.2 = 0.5
			convey.So(qpDev, convey.ShouldEqual, decimal.NewFromFloat(0.5).String())
			// (0.2 - 0.12) / 0.2 = 0.4
			convey.So(avgDev, convey.ShouldEqual, decimal.NewFromFloat(0.4).String())
		})
	})
}

func Test_getBizLineToQuantityPriceDiscount_BitsUTGen(t *testing.T) {
	t.Run("直销渠道覆盖全部分支", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				SalesChannelType: constants.SalesChannelTypeDirect,
			}
			quantityAmount := decimal.New(25, 0)
			bizLineInfoMap := map[string]*product_service.DepartmentInfo{
				"line_nil": nil,
				"line_empty_lines": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{},
				},
				"line_missing_type": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeChannelTelemarketing: {
							PriceInterval:           "1,10",
							DepartmentDiscountLines: "0.5",
						},
					},
				},
				"line_interval_empty": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeDirect: {
							PriceInterval:           "",
							DepartmentDiscountLines: "0.1",
						},
					},
				},
				"line_discount_empty": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeDirect: {
							PriceInterval:           "1,10",
							DepartmentDiscountLines: "",
						},
					},
				},
				"line_idx_overflow": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeDirect: {
							PriceInterval:           "1,10",
							DepartmentDiscountLines: "0.1",
						},
					},
				},
				"line_valid": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeDirect: {
							PriceInterval:           "1,10,20",
							DepartmentDiscountLines: "0.1,0.2,0.3",
						},
					},
				},
			}

			result := getBizLineToQuantityPriceDiscount(ctx, quote, quantityAmount, bizLineInfoMap)

			overflowExpect, err := decimal.NewFromString("0.1")
			convey.So(err, convey.ShouldBeNil)
			validExpect, err := decimal.NewFromString("0.3")
			convey.So(err, convey.ShouldBeNil)

			convey.So(len(result), convey.ShouldEqual, 2)

			overflowValue, ok := result["line_idx_overflow"]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(overflowValue.Equal(overflowExpect), convey.ShouldBeTrue)

			validValue, ok := result["line_valid"]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(validValue.Equal(validExpect), convey.ShouldBeTrue)
		})
	})

	t.Run("渠道类型缺省使用默认折扣线", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			quote := &model.Quote{
				SalesChannelType: "unknown_channel",
			}
			quantityAmount := decimal.New(4, 0)
			bizLineInfoMap := map[string]*product_service.DepartmentInfo{
				"line_default": {
					QuantityPriceDiscountLines: map[int]*product_service.QuantityPriceDiscountLine{
						constants.QuantityPriceLineTypeDirect: {
							PriceInterval:           "1,5",
							DepartmentDiscountLines: "0.2,0.4",
						},
					},
				},
			}

			result := getBizLineToQuantityPriceDiscount(ctx, quote, quantityAmount, bizLineInfoMap)

			convey.So(len(result), convey.ShouldEqual, 1)
			expected, err := decimal.NewFromString("0.2")
			convey.So(err, convey.ShouldBeNil)

			value, ok := result["line_default"]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(value.Equal(expected), convey.ShouldBeTrue)
		})
	})
}

func Test_buildMetricDeviationResult_BitsUTGen(t *testing.T) {
	t.Run("实际折扣不大于0时跳过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：实际折扣为0或负数，应该被跳过，最终结果为空
			data := []MetricDeviationData{
				{Department: "DeptA", BizLine: "BL1", AvgDiscount: decimal.NewFromFloat(0.0), ActualDiscount: decimal.NewFromFloat(0.0)},
				{Department: "DeptA", BizLine: "BL1", AvgDiscount: decimal.NewFromFloat(0.1), ActualDiscount: decimal.NewFromFloat(-0.2)},
			}
			bizLineToQuantityPriceDiscount := map[string]decimal.Decimal{
				"BL1": decimal.NewFromFloat(0.2),
			}

			result := buildMetricDeviationResult(data, bizLineToQuantityPriceDiscount)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("二级产品线没有对应折扣时跳过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：有实际折扣，但是找不到对应的量价折扣，应该被跳过
			data := []MetricDeviationData{
				{Department: "DeptB", BizLine: "BL_missing", AvgDiscount: decimal.NewFromFloat(0.1), ActualDiscount: decimal.NewFromFloat(0.3)},
			}
			bizLineToQuantityPriceDiscount := map[string]decimal.Decimal{
				"BL_other": decimal.NewFromFloat(0.5),
			}

			result := buildMetricDeviationResult(data, bizLineToQuantityPriceDiscount)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("正常构造与重复键分支覆盖", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：同时覆盖一级产品线初始化、二级产品线初始化、已存在键的分支
			data := []MetricDeviationData{
				{Department: "D1", BizLine: "B1", AvgDiscount: decimal.NewFromFloat(0.1), ActualDiscount: decimal.NewFromFloat(0.5)}, // 一级与二级首次初始化
				{Department: "D1", BizLine: "B2", AvgDiscount: decimal.NewFromFloat(0.3), ActualDiscount: decimal.NewFromFloat(0.6)}, // 一级存在，二级初始化
				{Department: "D1", BizLine: "B1", AvgDiscount: decimal.NewFromFloat(0.2), ActualDiscount: decimal.NewFromFloat(0.8)}, // 一级与二级都已存在，覆盖
			}
			bizLineToQuantityPriceDiscount := map[string]decimal.Decimal{
				"B1": decimal.NewFromFloat(0.2),
				"B2": decimal.NewFromFloat(0.4),
			}

			result := buildMetricDeviationResult(data, bizLineToQuantityPriceDiscount)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(len(result["D1"]), convey.ShouldEqual, 2)

			// 校验 B1 最后一次数据覆盖
			d1b1 := result["D1"]["B1"]
			convey.So(d1b1[ActualDiscountKey].Cmp(decimal.NewFromFloat(0.8)), convey.ShouldEqual, 0)
			convey.So(d1b1[AvgDiscountKey].Cmp(decimal.NewFromFloat(0.2)), convey.ShouldEqual, 0)
			convey.So(d1b1[QuantityPriceDiscountKey].Cmp(decimal.NewFromFloat(0.2)), convey.ShouldEqual, 0)

			expQPD1 := decimal.NewFromFloat(0.8).Sub(decimal.NewFromFloat(0.2)).Div(decimal.NewFromFloat(0.8))
			expADR1 := decimal.NewFromFloat(0.8).Sub(decimal.NewFromFloat(0.2)).Div(decimal.NewFromFloat(0.8))
			convey.So(d1b1[QuantityPriceDeviationRatio].Cmp(expQPD1), convey.ShouldEqual, 0)
			convey.So(d1b1[AvgDeviationRatioKey].Cmp(expADR1), convey.ShouldEqual, 0)

			// 校验 B2
			d1b2 := result["D1"]["B2"]
			convey.So(d1b2[ActualDiscountKey].Cmp(decimal.NewFromFloat(0.6)), convey.ShouldEqual, 0)
			convey.So(d1b2[AvgDiscountKey].Cmp(decimal.NewFromFloat(0.3)), convey.ShouldEqual, 0)
			convey.So(d1b2[QuantityPriceDiscountKey].Cmp(decimal.NewFromFloat(0.4)), convey.ShouldEqual, 0)

			expQPD2 := decimal.NewFromFloat(0.6).Sub(decimal.NewFromFloat(0.4)).Div(decimal.NewFromFloat(0.6))
			expADR2 := decimal.NewFromFloat(0.6).Sub(decimal.NewFromFloat(0.3)).Div(decimal.NewFromFloat(0.6))
			convey.So(d1b2[QuantityPriceDeviationRatio].Cmp(expQPD2), convey.ShouldEqual, 0)
			convey.So(d1b2[AvgDeviationRatioKey].Cmp(expADR2), convey.ShouldEqual, 0)
		})
	})
}

func Test_getBizLineInfo_BitsUTGen(t *testing.T) {
	t.Run("场景一：Callback返回API错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基本入参
			ctx := context.Background()
			tx := &gorm.DB{}
			quote := &model.Quote{}
			quote.Id = 123

			// Mock Callback返回API错误
			summary := &assistant.CallbackInfo{BizLineNameList: []string{"deptA"}}
			apiErr := pkg_errors.ErrCustomerError.WithArgs("mock api error")
			mockey.MockUnsafe(assistant.Callback).Return(summary, apiErr).Build()

			// 调用待测函数
			got, err := getBizLineInfo(ctx, tx, quote)

			// 断言
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock api error")
		})
	})

	t.Run("场景二：BizLineNameList为空直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基本入参
			ctx := context.Background()
			tx := &gorm.DB{}
			quote := &model.Quote{}
			quote.Id = 456

			// Mock Callback返回空的二级产品线列表
			summary := &assistant.CallbackInfo{BizLineNameList: []string{}}
			mockey.MockUnsafe(assistant.Callback).Return(summary, pkg_errors.APIError(nil)).Build()

			// 调用待测函数
			got, err := getBizLineInfo(ctx, tx, quote)

			// 断言
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("场景三：缓存查询失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基本入参
			ctx := context.Background()
			tx := &gorm.DB{}
			quote := &model.Quote{}
			quote.Id = 789

			// Mock Callback返回正常的列表
			summary := &assistant.CallbackInfo{BizLineNameList: []string{"deptB"}}
			mockey.MockUnsafe(assistant.Callback).Return(summary, pkg_errors.APIError(nil)).Build()

			// Mock 缓存查询失败
			mockey.MockUnsafe(product_service.ListDepartmentInfoByNamesFromCache).Return(map[string]*product_service.DepartmentInfo(nil), errors.New("cache error")).Build()

			// 调用待测函数
			got, err := getBizLineInfo(ctx, tx, quote)

			// 断言
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "cache error")
		})
	})

	t.Run("场景四：成功返回二级产品线信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基本入参
			ctx := context.Background()
			tx := &gorm.DB{}
			quote := &model.Quote{}
			quote.Id = 101112

			// Mock Callback返回正常的列表
			summary := &assistant.CallbackInfo{BizLineNameList: []string{"deptC", "deptD"}}
			mockey.MockUnsafe(assistant.Callback).Return(summary, pkg_errors.APIError(nil)).Build()

			// Mock 缓存返回部门信息
			retMap := map[string]*product_service.DepartmentInfo{
				"deptC": {ID: 1, Name: "deptC"},
				"deptD": {ID: 2, Name: "deptD"},
			}
			mockey.MockUnsafe(product_service.ListDepartmentInfoByNamesFromCache).Return(retMap, error(nil)).Build()

			// 调用待测函数
			got, err := getBizLineInfo(ctx, tx, quote)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(len(got), convey.ShouldEqual, 2)
			convey.So(got["deptC"].Name, convey.ShouldEqual, "deptC")
			convey.So(got["deptD"].Name, convey.ShouldEqual, "deptD")
		})
	})
}

func Test_getMetricDeviationData_BitsUTGen(t *testing.T) {
	t.Run("ApiID 不存在返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备参数
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent_001"}
			productBizLines := []string{"A", "B"}

			// 执行
			res, err := getMetricDeviationData(ctx, quote, productBizLines)

			// 断言：应返回内部错误
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "metricDeviationApiId not found")
		})
	})

	t.Run("OneService 返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备参数
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent_002"}
			productBizLines := []string{"C"}

			// Mock返回有效的ApiID
			mockey.MockUnsafe(one_service.GetApiID).Return("api_valid_001", true).Build()
			// Mock泛型函数让其返回错误
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]MetricDeviationData]).Return([]MetricDeviationData(nil), errors.New("one service error")).Build()

			// 执行
			res, err := getMetricDeviationData(ctx, quote, productBizLines)

			// 断言：应返回OneService的错误
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "one service error")
		})
	})

	t.Run("查询成功返回结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备参数
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent_003"}
			productBizLines := []string{"D", "E"}

			// Mock返回有效的ApiID
			mockey.MockUnsafe(one_service.GetApiID).Return("api_valid_002", true).Build()
			// Mock泛型函数让其返回成功结果
			expected := []MetricDeviationData{
				{Department: "Dept1", BizLine: "BL1", AvgDiscount: decimal.NewFromFloat(0.15), ActualDiscount: decimal.NewFromFloat(0.10)},
				{Department: "Dept2", BizLine: "BL2", AvgDiscount: decimal.NewFromFloat(0.20), ActualDiscount: decimal.NewFromFloat(0.18)},
			}
			mockey.MockGeneric(one_service.GetOneServiceCommonInfo[[]MetricDeviationData]).Return(expected, nil).Build()

			// 执行
			res, err := getMetricDeviationData(ctx, quote, productBizLines)

			// 断言：成功返回结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldResemble, expected)
		})
	})

	t.Run("ApiID 为空字符串返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备参数
			ctx := context.Background()
			quote := &model.Quote{ParentAccountNumber: "parent_004"}
			productBizLines := []string{"F"}

			// Mock返回空字符串但ok为true
			mockey.MockUnsafe(one_service.GetApiID).Return("", true).Build()

			// 执行
			res, err := getMetricDeviationData(ctx, quote, productBizLines)

			// 断言：应返回内部错误
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "metricDeviationApiId not found")
		})
	})
}

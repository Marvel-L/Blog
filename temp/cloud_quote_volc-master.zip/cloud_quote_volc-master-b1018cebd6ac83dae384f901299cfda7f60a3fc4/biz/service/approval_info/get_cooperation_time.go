package approval_info

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/contract_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
	"gorm.io/gorm"
)

const yearNanos = int64(time.Hour) * 24 * 365

func GetCooperationTime(ctx context.Context, quote *model.Quote) (decimal.Decimal, *ErrorDetail) {
	// 1、查询当前客户已生效的报价单ID
	tx := dal.DBProxy.NewRequest(ctx)
	quoteIDs, err := getEffectiveQuotesByCustomerInfo(ctx, tx, quote)
	if err != nil {
		return decimal.Zero, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoCooperationTime,
		}
	}

	if len(quoteIDs) == 0 {
		return decimal.Zero, nil
	}
	// 2、查询合同号
	contractCodes, err := dal.QuoteContractDao.ContractCodesByQuoteIDs(tx, quoteIDs)
	if err != nil {
		logs.CtxError(ctx, "get contract map by quote ids failed, err=%v", err)
		return decimal.Zero, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoCooperationTime,
		}
	}
	if len(contractCodes) == 0 {
		return decimal.Zero, nil
	}
	// 3、批量查询合同信息
	contractTimes, err := contract_client.ListContractTime(ctx, contractCodes)
	if err != nil {
		logs.CtxError(ctx, "list contract meta failed, err=%v", err)
		return decimal.Zero, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoCooperationTime,
		}
	}
	// 4、计算最大合作时间
	return calMaxCooperationTime(ctx, contractTimes), nil
}

// getEffectiveQuotesByCustomerInfo 根据客户标识查询已生效的报价单
func getEffectiveQuotesByCustomerInfo(ctx context.Context, tx *gorm.DB, quote *model.Quote) ([]int64, error) {
	// 直接使用map作为条件
	condition := make(map[string]interface{})
	// 添加已生效状态条件
	condition["quote_status"] = constants.StatusEffective
	condition["quote_scene"] = multienv.GetQuoteSceneWithOutChangeDiscount()

	// 根据环境类型添加客户标识条件
	if multienv.IsBytePlus() {
		// BP环境，CustomerName查询
		condition["customer_name"] = quote.CustomerName
	} else {
		// CN环境，ParentAccountNumber查询
		condition["parent_account_number"] = quote.ParentAccountNumber
	}

	// 查询已生效的报价单
	quotes, err := dal.QuoteDao.FindAllQuoteByConditions(ctx, tx, condition)
	if err != nil {
		return nil, err
	}
	logs.CtxInfo(ctx, "find effective quotes success, count: %d", len(quotes))
	quoteIDs := make([]int64, 0, len(quotes))
	for _, q := range quotes {
		quoteIDs = append(quoteIDs, q.Id)
	}

	return quoteIDs, nil
}

func calMaxCooperationTime(ctx context.Context, contractTimes []*contract_client.ContractTime) decimal.Decimal {
	// 解析并找出最早开始时间与最晚结束时间
	var (
		earliestStart time.Time
		latestEnd     time.Time
	)

	for _, meta := range contractTimes {
		if meta == nil {
			continue
		}
		// 解析 BeginTime
		if t, ok := parseContractDateTime(meta.BeginTime); ok {
			if earliestStart.IsZero() || t.Before(earliestStart) {
				earliestStart = t
			}
		}
		// 解析 EndTime
		if t, ok := parseContractDateTime(meta.EndTime); ok {
			if t.After(latestEnd) {
				latestEnd = t
			}
		}
	}

	// 无有效合同开始时间
	if earliestStart.IsZero() {
		logs.CtxInfo(ctx, "GetMaxCooperationTime: missing start time")
		return decimal.Zero
	}
	// 合同开始时间未到，合作时间为0
	if time.Now().Before(earliestStart) {
		return decimal.Zero
	}

	// 有开始时间，无结束时间，表示无限时间合同，按当前时间计算
	if latestEnd.IsZero() {
		latestEnd = time.Now()
	}
	// 合同未结束，合作时间为当前时间与合同开始时间的差值
	if time.Now().Before(latestEnd) {
		latestEnd = time.Now()
	}
	timeDiff := latestEnd.Sub(earliestStart)
	return decimal.NewFromInt(timeDiff.Nanoseconds()).Div(decimal.NewFromInt(yearNanos)).Mul(decimal.NewFromInt(12))
}

// parseContractDateTime 解析固定格式的日期时间：YYYY-MM-DD HH:MM:SS
func parseContractDateTime(s string) (time.Time, bool) {
	if s == "" {
		return time.Time{}, false
	}
	if t, err := util.ParseInLocation(util.DBDateFormatTpl, s); err == nil {
		// 过滤无效时间，如零值时间或远古占位时间
		if t.IsZero() || t.Year() <= 1 {
			return time.Time{}, false
		}
		return t, true
	}
	return time.Time{}, false
}

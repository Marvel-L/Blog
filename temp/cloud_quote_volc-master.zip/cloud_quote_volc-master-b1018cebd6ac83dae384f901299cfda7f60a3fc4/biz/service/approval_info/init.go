package approval_info

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var referenceFetcherRegistry = map[string]ReferenceFetcher{}

const (
	CooperationTimeKey              = "month_diff"                     // 合作时间的月差（按一年365计算）
	YearConsumptionKey              = "year_consumption"               // 公有云、私有云年消费金额（主客户维度）
	MarketPublicCloudConsumptionKey = "market_public_consumption"      // 市场公有云年消耗（主客户维度）
	QuantityPriceMonthPriceKey      = "quantity_price"                 // 公有云量价月消耗+年消耗（主客户维度）
	HistoryConsumptionProportionKey = "history_consumption_proportion" // 历史消耗占比（按一级产品线）
	ConsumptionGrowthTrendKey       = "consumption_growth_trend"       // 公有云、私有云月消耗趋势（主客户维度）
	OverdueAmountKey                = "overdue_amount"                 // 逾期金额（主客户维度）
	MetricDeviationKey              = "metric_deviation"               // 指标偏差（按一级产品线）
)

func init() {
	// month_diff: 合作时间的月差（按30天月计算）
	RegisterReferenceFetcher(CooperationTimeKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetCooperationTime(ctx, quote)
	})
	// year_consumption: 公有云、私有云年消费金额（主客户维度）
	RegisterReferenceFetcher(YearConsumptionKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetYearConsumption(ctx, quote)
	})
	// market_public_consumption: 市场公有云年消耗（主客户维度）
	RegisterReferenceFetcher(MarketPublicCloudConsumptionKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return MarketPublicCloudConsumption(ctx, quote)
	})
	// quantity_price_month_price: 公有云量价月消耗（主客户维度）
	RegisterReferenceFetcher(QuantityPriceMonthPriceKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetQuantityPriceConsumption(ctx, quote)
	})
	// consumption_proportion: 历史消耗占比（按一级产品线）
	RegisterReferenceFetcher(HistoryConsumptionProportionKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetHistoryConsumptionProportion(ctx, quote)
	})
	// consumption_growth_trend: 公有云、私有云月消耗趋势（主客户维度）
	RegisterReferenceFetcher(ConsumptionGrowthTrendKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetConsumptionGrowthTrend(ctx, quote)
	})
	// overdue_amount: 逾期金额（主客户维度）
	RegisterReferenceFetcher(OverdueAmountKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetOverdueAmount(ctx, quote)
	})
	// metric_deviation: 指标偏差（按一级产品线）
	RegisterReferenceFetcher(MetricDeviationKey, func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail) {
		return GetMetricDeviation(ctx, quote)
	})
}

// ReferenceFetcher 根据key获取参考信息的函数定义
type ReferenceFetcher func(ctx context.Context, quote *model.Quote) (interface{}, *ErrorDetail)

// RegisterReferenceFetcher 注册 key 对应的处理函数
func RegisterReferenceFetcher(key string, f ReferenceFetcher) {
	if key == "" || f == nil {
		return
	}
	referenceFetcherRegistry[key] = f
}

package approval_info

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

type ConsumptionGrowthTrendData struct {
	Cmonth              string          `gorm:"column:cmonth"`                // 月份
	GoodsDeploymentType string          `gorm:"column:goods_deployment_type"` // 部署方式
	SumAccrualAmount    decimal.Decimal `gorm:"column:sum_accrual_amount"`    // 累计金额
}

func GetConsumptionGrowthTrend(ctx context.Context, quote *model.Quote) (map[string]interface{}, *ErrorDetail) {
	// 1、获取消费趋势数据
	consumptionTrendResults, err := getConsumptionGrowthTrendData(ctx, quote)
	if err != nil {
		logs.CtxError(ctx, "GetConsumptionGrowthTrendData failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoGrowthTrend,
		}
	}
	// 2、map【部署方式】map【月份】decimal
	deploymentMap := make(map[string]interface{})
	for _, result := range consumptionTrendResults {
		if result.Cmonth == "" || result.GoodsDeploymentType == "" {
			continue
		}
		amt := result.SumAccrualAmount
		goodsDeploymentType := i18nfmt.Sprint(ctx, result.GoodsDeploymentType)
		monthMap, ok := deploymentMap[goodsDeploymentType]
		if !ok {
			monthMap = make(map[string]decimal.Decimal)
			deploymentMap[goodsDeploymentType] = monthMap
		}
		monthMap.(map[string]decimal.Decimal)[result.Cmonth] = amt
	}
	return deploymentMap, nil
}

func getConsumptionGrowthTrendData(ctx context.Context, quote *model.Quote) ([]ConsumptionGrowthTrendData, error) {
	// 1、获取消费趋势ApiID
	consumptionTrendApiId, ok := one_service.GetApiID(one_service.ConsumptionTrendQueryID)
	if !ok || consumptionTrendApiId == "" {
		logs.CtxError(ctx, "GetConsumptionTrend failed, quote_id=%d, err=%s", quote.Id, "consumptionTrendApiId not found")
		return nil, errors.ErrInternalError.WithArgs("firstProductLineProductApiId not found")
	}
	// 2、构造参数
	params := one_service.BuildParentParams(quote.ParentAccountNumber, quote.CustomerName)
	// 3、调用OneService查询一级产品线的消耗比例
	consumptionTrendResults, err := one_service.GetOneServiceCommonInfo[[]ConsumptionGrowthTrendData](ctx, consumptionTrendApiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetFirstProductLineConsumption failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, err
	}
	return consumptionTrendResults, nil
}

package approval_info

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quantity_price_service"
	"code.byted.org/gopkg/logs"
)

// MarketPublicCloudConsumption 通过报价单ID获取市场公有云年消耗
// 1. 使用主客户ACC请求标签系统，获取市场公有云年消耗
// 2. 返回市场公有云消耗，格式为GraphMap["market_public_consumption"] = "标签code"
func MarketPublicCloudConsumption(ctx context.Context, quote *model.Quote) (string, *ErrorDetail) {
	if multienv.IsBytePlus() {
		return "", nil
	}
	// 创建QuantityPriceDetail结构体并调用已有的GetQuantityPriceAmountMarket方法
	quantityPriceDetail := &quantity_price_service.QuantityPriceDetail{}

	err := quantityPriceDetail.GetQuantityPriceAmountMarket(ctx, quote.ParentAccountNumber)
	if err != nil {
		logs.CtxError(ctx, "获取市场公有云年消耗失败, parentAccountNumber=%s, err=%s", quote.ParentAccountNumber, err.Error())
		return "", &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoMarketPublicConsumption,
		}
	}

	// 获取标签结果
	labelCode := quantityPriceDetail.QuantityPriceAmountMarket
	logs.CtxInfo(ctx, "获取市场公有云年消耗标签, parentAccountNumber=%s, labelCode=%s", quote.ParentAccountNumber, labelCode)
	return labelCode, nil
}

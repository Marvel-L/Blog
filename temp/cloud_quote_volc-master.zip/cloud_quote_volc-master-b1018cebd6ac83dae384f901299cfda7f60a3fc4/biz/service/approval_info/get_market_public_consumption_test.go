package approval_info

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	dal_model "code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quantity_price_service"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/label"
	"code.byted.org/lang/gg/gptr"
	labelsdkmodel "code.byted.org/ve-arch/customer-label-sdk/model"
	"code.byted.org/ve-arch/volcengine-go-sdk/service/customerlabel"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_MarketPublicCloudConsumption_BitsUTGen(t *testing.T) {
	t.Run("字节Plus环境无需查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()
			ctx := context.Background()
			quote := &dal_model.Quote{ParentAccountNumber: "parent-1"}
			mockey.MockUnsafe(multienv.IsBytePlus).Return(true).Build()

			label, errDetail := MarketPublicCloudConsumption(ctx, quote)
			convey.So(label, convey.ShouldEqual, "")
			convey.So(errDetail, convey.ShouldBeNil)
		})
	})

	t.Run("查询量价失败返回错误信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()
			ctx := context.Background()
			quote := &dal_model.Quote{ParentAccountNumber: "parent-2"}
			mockErr := errors.New("mock failure")
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*quantity_price_service.QuantityPriceDetail).GetQuantityPriceAmountMarket).Return(mockErr).Build()

			label, errDetail := MarketPublicCloudConsumption(ctx, quote)
			convey.So(label, convey.ShouldEqual, "")
			convey.So(errDetail, convey.ShouldNotBeNil)
			convey.So(errDetail.ErrorMsg, convey.ShouldEqual, mockErr.Error())
			convey.So(errDetail.ErrorCode, convey.ShouldEqual, pkg_errors.CodeNApprovalInfoMarketPublicConsumption)
		})
	})

	t.Run("查询量价成功返回标签值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			defer mockey.UnPatchAll()
			ctx := context.Background()
			quote := &dal_model.Quote{ParentAccountNumber: "parent-3"}
			expectedLabel := "label-xyz"
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			mockey.MockUnsafe(config.GetGlobalConf).Return(&config.Conf{
				LabelClientConfig: &config.LabelClientConfig{LabelKeyMarketARR: "market_arr"},
			}).Build()
			mockey.Mock(label.DescribeObjectLabels).To(func(_ context.Context, req labelsdkmodel.DescribeObjectLabelRequest) ([]*customerlabel.ObjectLabelValueForDescribeObjectLabelsOutput, error) {
				convey.So(req.ObjectId, convey.ShouldEqual, quote.ParentAccountNumber)
				convey.So(*req.LabelKey, convey.ShouldEqual, "market_arr")
				return []*customerlabel.ObjectLabelValueForDescribeObjectLabelsOutput{{LabelValue: gptr.Of(expectedLabel)}}, nil
			}).Build()

			label, errDetail := MarketPublicCloudConsumption(ctx, quote)
			convey.So(errDetail, convey.ShouldBeNil)
			convey.So(label, convey.ShouldEqual, expectedLabel)
		})
	})
}

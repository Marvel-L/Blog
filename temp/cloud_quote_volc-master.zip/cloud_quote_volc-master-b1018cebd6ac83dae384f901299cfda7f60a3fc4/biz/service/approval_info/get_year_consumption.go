package approval_info

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

type YearConsumptionResult struct {
	GoodsDeploymentType string          `gorm:"column:goods_deployment_type"` // 公有云、私有云
	SumAccrualAmount    decimal.Decimal `gorm:"column:sum_accrual_amount"`    // 计费金额
}

const allDeploymentType = "all"

func GetYearConsumption(ctx context.Context, quote *model.Quote) (map[string]decimal.Decimal, *ErrorDetail) {
	// 1、获取ApiID
	apiId, ok := one_service.GetApiID(one_service.YearConsumptionQueryID)
	if !ok || apiId == "" {
		logs.CtxError(ctx, "GetYearConsumption failed, quote_id=%d, err=%s", quote.Id, "YearConsumptionQueryID not found")
		return nil, &ErrorDetail{
			ErrorMsg:  "YearConsumptionQueryID not found",
			ErrorCode: errors.CodeNApprovalInfoYearConsumption,
		}
	}

	// 2、构造参数
	params := one_service.BuildParentParams(quote.ParentAccountNumber, quote.CustomerName)

	// 3、调用OneService查询
	results, err := one_service.GetOneServiceCommonInfo[[]YearConsumptionResult](ctx, apiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetYearConsumption failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  err.Error(),
			ErrorCode: errors.CodeNApprovalInfoYearConsumption,
		}
	}

	// 4、解析结果
	resp := map[string]decimal.Decimal{}
	var allAccrualAmount decimal.Decimal
	for _, result := range results {
		goodsDeploymentType := i18nfmt.Sprint(ctx, result.GoodsDeploymentType)
		resp[goodsDeploymentType] = result.SumAccrualAmount
		allAccrualAmount = allAccrualAmount.Add(resp[goodsDeploymentType])
	}
	resp[allDeploymentType] = allAccrualAmount
	return resp, nil
}

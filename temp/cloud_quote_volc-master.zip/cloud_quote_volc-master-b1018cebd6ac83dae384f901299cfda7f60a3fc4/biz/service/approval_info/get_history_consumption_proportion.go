package approval_info

import (
	"context"
	"sync"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/one_service"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

type ProductLineConsumptionResult struct {
	ProductTeam      string          `gorm:"column:product_team"`       // 一级产品线
	SumAccrualAmount decimal.Decimal `gorm:"column:sum_accrual_amount"` // 总金额
}

const largeModelName = "大模型"
const cloudBaseProductLine = "云基础"
const cloudBaseProductLineBP = "BytePlus-云基础"
const otherProductLine = "其他产品线"

func GetHistoryConsumptionProportion(ctx context.Context, quote *model.Quote) (map[string]interface{}, *ErrorDetail) {
	// 1、并发获取：大模型与一级产品线消耗
	var (
		largeModelAmount               decimal.Decimal
		firstProductLineProductResults []ProductLineConsumptionResult
		errLarge                       error
		errFirst                       error
		wg                             sync.WaitGroup
	)
	wg.Add(2)
	go func() {
		defer wg.Done()
		largeModelAmount, errLarge = getLargeModelConsumption(ctx, quote)
	}()
	go func() {
		defer wg.Done()
		firstProductLineProductResults, errFirst = getFirstProductLineConsumption(ctx, quote)
	}()
	wg.Wait()
	if errLarge != nil {
		logs.CtxError(ctx, "GetHistoryConsumptionProportion failed(large), quote_id=%d, err=%s", quote.Id, errLarge.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  errLarge.Error(),
			ErrorCode: errors.CodeNApprovalInfoConsumptionProportion,
		}
	}
	if errFirst != nil {
		logs.CtxError(ctx, "GetHistoryConsumptionProportion failed(first), quote_id=%d, err=%s", quote.Id, errFirst.Error())
		return nil, &ErrorDetail{
			ErrorMsg:  errFirst.Error(),
			ErrorCode: errors.CodeNApprovalInfoConsumptionProportion,
		}
	}

	// 2、构造返回结果
	res := buildConsumptionProportion(ctx, largeModelAmount, firstProductLineProductResults)
	return res, nil
}

// buildConsumptionProportion 汇总并构造返回占比：
func buildConsumptionProportion(ctx context.Context, largeModelAmount decimal.Decimal, firstProductLineProductResults []ProductLineConsumptionResult) map[string]interface{} {
	// 1、排除大模型的情况下：云基础总金额、非云基础总金额
	cloudBaseAmount := decimal.Zero
	noCloudBaseAmount := decimal.Zero
	for _, result := range firstProductLineProductResults {
		resultAmount := result.SumAccrualAmount
		if result.ProductTeam == cloudBaseProductLine || result.ProductTeam == cloudBaseProductLineBP {
			cloudBaseAmount = cloudBaseAmount.Add(resultAmount)
		} else {
			noCloudBaseAmount = noCloudBaseAmount.Add(resultAmount)
		}
	}

	// 2、总金额为：大模型 + 云基础 + 非云基础
	sumAll := largeModelAmount.Add(cloudBaseAmount).Add(noCloudBaseAmount)
	res := map[string]interface{}{}
	if sumAll.IsZero() {
		return res
	}

	// 3、非0金额，按占比返回
	if !largeModelAmount.IsZero() {
		res[i18nfmt.Sprint(ctx, largeModelName)] = largeModelAmount.Div(sumAll)
	}
	if !cloudBaseAmount.IsZero() {
		if multienv.IsBytePlus() {
			res[cloudBaseProductLineBP] = cloudBaseAmount.Div(sumAll)
		} else {
			res[cloudBaseProductLine] = cloudBaseAmount.Div(sumAll)
		}
	}
	if !noCloudBaseAmount.IsZero() {
		otherProductLineMap := make(map[string]interface{})
		for _, r := range firstProductLineProductResults {
			if r.ProductTeam == cloudBaseProductLine || r.ProductTeam == cloudBaseProductLineBP {
				continue
			}
			if r.SumAccrualAmount.IsZero() {
				continue
			}
			otherProductLineMap[r.ProductTeam] = r.SumAccrualAmount.Div(sumAll)
		}
		res[i18nfmt.Sprint(ctx, otherProductLine)] = otherProductLineMap
	}
	return res
}

func getLargeModelConsumption(ctx context.Context, quote *model.Quote) (decimal.Decimal, error) {
	// 1、获取大模型产品线的ApiID
	largeModelProductApiId, ok := one_service.GetApiID(one_service.LargeModelProductQueryID)
	if !ok || largeModelProductApiId == "" {
		logs.CtxError(ctx, "GetLargeModelConsumption failed, quote_id=%d, err=%s", quote.Id, "largeModelProductApiId not found")
		return decimal.Zero, errors.ErrInternalError.WithArgs("largeModelProductApiId not found")
	}
	// 2、构造参数
	params := one_service.BuildParentParams(quote.ParentAccountNumber, quote.CustomerName)
	// 3、调用OneService查询大模型产品线的消耗比例
	largeModelProductResults, err := one_service.GetOneServiceCommonInfo[float64](ctx, largeModelProductApiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetLargeModelConsumption failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return decimal.Zero, err
	}
	largeModelAmount := decimal.NewFromFloat(largeModelProductResults)
	return largeModelAmount, nil
}

func getFirstProductLineConsumption(ctx context.Context, quote *model.Quote) ([]ProductLineConsumptionResult, error) {
	// 1、获取一级产品线的ApiID
	firstProductLineProductApiId, ok := one_service.GetApiID(one_service.FirstProductLineProductQueryID)
	if !ok || firstProductLineProductApiId == "" {
		logs.CtxError(ctx, "GetFirstProductLineConsumption failed, quote_id=%d, err=%s", quote.Id, "firstProductLineProductApiId not found")
		return nil, errors.ErrInternalError.WithArgs("firstProductLineProductApiId not found")
	}
	// 2、构造参数
	params := one_service.BuildParentParams(quote.ParentAccountNumber, quote.CustomerName)
	// 3、调用OneService查询一级产品线的消耗比例
	firstProductLineProductResults, err := one_service.GetOneServiceCommonInfo[[]ProductLineConsumptionResult](ctx, firstProductLineProductApiId, params)
	if err != nil {
		logs.CtxError(ctx, "GetFirstProductLineConsumption failed, quote_id=%d, err=%s", quote.Id, err.Error())
		return nil, err
	}
	return firstProductLineProductResults, nil
}

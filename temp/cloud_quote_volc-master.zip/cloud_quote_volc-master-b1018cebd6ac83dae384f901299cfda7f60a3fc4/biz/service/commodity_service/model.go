package commodity_service

import (
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

type ProductFilter struct {
	SingleSale              bool                  // 是否独立售卖-解决方案外添加商品，设置true,返回独立售卖商品
	DeploymentType          constants.ProductType // 部署类型-不为所有时multienv.TradeProductDeploymentTypeAll，返回指定部署类型的商品
	CustomerScope           string                // 售卖范围-不为空时，内部客户报价可以报内部和内外部商品，外部客户只可以报价内外部客户的商品
	TradeTypeCode           int                   // 客户类型编码
	ConstraintAccountList   []int64               // 约束账号列表-不为空时，查询商品状态要进行商品约束匹配（约束匹配账号优先）
	ConstraintAccountNumber string                // 约束客户编号-不为空时，查询商品状态要进行商品约束匹配（约束匹配账号优先）
	ItemScene               int                   // 报价项交付项场景-1（报价项场景），不返回“线下仅用于交付BOM的通用商品”
	StandardProduct         string                // 标品or非标品-不为空时，返回标准类型一致的商品
	BelongingDepartmentList []string              // 一级产品线-不为空时，查询该一级产品线下的商品
	BizLineNameList         []string              // 二级产品线-不为空时，查询该二级产品线下的商品
	IgnoreStatus            bool                  // 忽略商品状态-true时，忽略商品状态过滤
	IgnoreSelectionRule     bool                  // 忽略商品选择规则-true时，忽略商品选择规则过滤
	SpPkgInfo               *model.SpPkgInfo      // SP包信息
}

type StandardSolution struct {
	StandardSolutionCode     string   `json:"StandardSolutionCode"`
	StandardSolutionName     string   `json:"StandardSolutionName"`
	StandardDepartmentName   string   `json:"StandardDepartmentName"`
	StandardSolutionType     string   `json:"StandardSolutionType"`
	StandardSolutionVersions []string `json:"StandardSolutionVersions"`
}

type TradeSolution struct {
	TradeSolutionCode     string   `json:"TradeSolutionCode"`
	TradeSolutionName     string   `json:"TradeSolutionName"`
	TradeSolution         string   `json:"TradeSolution"`
	TradeSolutionVersions []string `json:"TradeSolutionVersions"`
}

type SolutionInfo struct {
	Solution                string   `json:"Solution"`
	SolutionType            int8     `json:"SolutionType"`
	ZhName                  string   `json:"ZhName"`
	SolutionCode            string   `json:"SolutionCode"`
	StandardSolutionCode    string   `json:"StandardSolutionCode"`
	StandardSolutionName    string   `json:"StandardSolutionName"`
	DepartmentName          string   `json:"DepartmentName"`
	SolutionVersion         string   `json:"SolutionVersion"`
	StandardSolutionVersion string   `json:"StandardSolutionVersion"`
	TradeProducts           []string `json:"TradeProducts"`
	ID                      int64
	CatalogueCodeMapList    []string `json:"CatalogueCodeMapList"`
}

func (s *SolutionInfo) GetSolutionInfoKey() string {
	return fmt.Sprintf("%s::%s", s.Solution, s.SolutionVersion)
}

func GetSolutionInfoKey(solution, solutionVersion string) string {
	return fmt.Sprintf("%s::%s", solution, solutionVersion)
}

func (s *SolutionInfo) GetSolutionCatalogueCode(catalogueCodeKey string) string {
	for _, catalogueKV := range s.CatalogueCodeMapList {
		keyValueArr := strings.Split(catalogueKV, ":")
		key := keyValueArr[0]
		value := keyValueArr[1]
		if key == catalogueCodeKey {
			return value
		}
	}
	return ""
}

func (s *SolutionInfo) ContainsTradeProduct(tradeProduct string) bool {
	for _, product := range s.TradeProducts {
		if product == tradeProduct {
			return true
		}
	}
	return false
}

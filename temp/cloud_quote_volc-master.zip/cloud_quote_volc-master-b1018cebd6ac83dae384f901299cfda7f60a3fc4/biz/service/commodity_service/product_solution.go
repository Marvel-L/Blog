package commodity_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/product_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kv/redis-v6/pkg"
	"code.byted.org/videoarch/cloud_gopkg/products_client"
	"context"
	"github.com/bytedance/sonic"
)

const tradeSolutionInfoKey = "trade_solution_info_h"

func ListStandardSolutionInfo(ctx context.Context) ([]*StandardSolution, error) {

	solutionResult, err := product_client.ListSolutionProducts(ctx, products_client.ListSolutionProductsReq{
		Pagination: products_client.Pagination{
			Limit:  multienv.MaxPageLimit,
			Offset: multienv.PageOne,
		},
		SolutionProductStatus: []string{"pass"},
	})
	if err != nil {
		return nil, err
	}
	if solutionResult == nil {
		return nil, errors.ErrInternalError.WithArgs("产品解决方案查询失败")
	}

	var solutionProductCodes []string
	for _, solutionProduct := range solutionResult.List {
		solutionProductCodes = append(solutionProductCodes, solutionProduct.SolutionCode)
	}

	versionsResult, err := product_client.ListSolutionReleases(ctx, products_client.ListSolutionReleasesReq{
		Pagination: products_client.Pagination{
			Limit:  multienv.MaxPageLimit,
			Offset: multienv.PageOne,
		},
		SolutionProductCodes: solutionProductCodes,
	})

	if err != nil {
		return nil, err
	}
	if versionsResult == nil {
		return nil, errors.ErrInternalError.WithArgs("产品解决方案版本查询失败")
	}

	versionMap := map[string][]string{}

	for _, version := range versionsResult.List {
		if version.ReleaseStatus != "Pass" {
			continue
		}
		versionArr, ok := versionMap[version.SolutionCode]
		if !ok {
			versionMap[version.SolutionCode] = []string{version.ReleaseVersion}
		} else {
			versionMap[version.SolutionCode] = append(versionArr, version.ReleaseVersion)
		}
	}

	var standardSolutionList []*StandardSolution
	for _, solutionProduct := range solutionResult.List {
		var belongingDepartmentName string
		if solutionProduct.BelongingDepartment != nil {
			belongingDepartmentName = solutionProduct.BelongingDepartment.Name
		}

		var versions []string
		var ok bool
		if solutionProduct.SolutionProductType == constants.ProductNormalSolutionType {
			versions = []string{""}
		} else {
			versions, ok = versionMap[solutionProduct.SolutionCode]
			if !ok {
				continue
			}
		}
		standardSolutionList = append(standardSolutionList, &StandardSolution{
			StandardSolutionCode:     solutionProduct.SolutionCode,
			StandardSolutionName:     solutionProduct.SolutionProductName,
			StandardDepartmentName:   belongingDepartmentName,
			StandardSolutionType:     solutionProduct.SolutionProductType,
			StandardSolutionVersions: versions,
		})
	}
	return standardSolutionList, nil
}

func ListTradeSolutionInfo(ctx context.Context, standardSolutionCode string, standardSolutionVersion string, solutionType int8) ([]*TradeSolution, error) {
	tradeSolutionResult, err := trade_client.ListSolutionInfo(ctx, standardSolutionCode, solutionType)
	if err != nil {
		return nil, err
	}
	if tradeSolutionResult == nil {
		return nil, errors.ErrInternalError.WithArgs("商品解决方案查询失败")
	}

	var solutions []string
	for _, solution := range tradeSolutionResult.List {
		solutions = append(solutions, solution.Solution)
	}

	if len(solutions) == 0 {
		return nil, nil
	}

	versionsResult, err := trade_client.ListSolutionVersion(ctx, solutions, standardSolutionVersion)

	if err != nil {
		return nil, err
	}
	if versionsResult == nil {
		return nil, errors.ErrInternalError.WithArgs("商品解决方案版本查询失败")
	}

	versionMap := map[string][]string{}

	for _, version := range versionsResult.List {
		versionArr, ok := versionMap[version.Solution]
		if !ok {
			versionMap[version.Solution] = []string{version.SolutionVersion}
		} else {
			versionMap[version.Solution] = append(versionArr, version.SolutionVersion)
		}
	}

	var tradeSolutionList []*TradeSolution
	for _, tradeSolution := range tradeSolutionResult.List {
		versions, ok := versionMap[tradeSolution.Solution]
		if !ok {
			continue
		}

		tradeSolutionList = append(tradeSolutionList, &TradeSolution{
			TradeSolutionCode:     tradeSolution.SolutionCode,
			TradeSolutionName:     tradeSolution.ZhName,
			TradeSolution:         tradeSolution.Solution,
			TradeSolutionVersions: versions,
		})
	}
	return tradeSolutionList, nil
}

func listAllTradeSolutionInfo(ctx context.Context) ([]*SolutionInfo, error) {
	tradeSolutionResult, err := trade_client.ListSolutionInfo(ctx, "", 0)
	if err != nil {
		return nil, err
	}
	if tradeSolutionResult == nil {
		return nil, errors.ErrInternalError.WithArgs("商品解决方案查询失败")
	}

	solutionMap := map[string]*SolutionInfo{}
	var solutionEnNames []string
	for _, solution := range tradeSolutionResult.List {
		solutionEnNames = append(solutionEnNames, solution.Solution)
		solutionMap[solution.Solution] = &SolutionInfo{
			Solution:             solution.Solution,
			SolutionType:         solution.SolutionType,
			ZhName:               solution.ZhName,
			SolutionCode:         solution.SolutionCode,
			StandardSolutionCode: solution.StandardSolutionCode,
			StandardSolutionName: solution.StandardSolutionName,
			DepartmentName:       solution.DepartmentName,
			CatalogueCodeMapList: solution.CatalogueCodeMapList,
		}
	}

	versionsResult, err := trade_client.ListSolutionVersion(ctx, solutionEnNames, "")

	if err != nil {
		return nil, err
	}
	if versionsResult == nil {
		return nil, errors.ErrInternalError.WithArgs("商品解决方案版本查询失败")
	}

	var solutionInfos []*SolutionInfo
	for _, version := range versionsResult.List {

		solutionProductResult, err := trade_client.ListSolutionVersionProduct(ctx, version.Solution, version.SolutionVersion, multienv.MaxPageLimit)
		if err != nil {
			logs.CtxError(ctx, "trade_client.ListSolutionVersionProduct err : %s", err.Error())
			continue
		}
		if solutionProductResult == nil {
			return nil, errors.ErrInternalError.WithArgs("商品解决方案商品查询失败")
		}
		var tradeProducts []string
		for _, solutionProduct := range solutionProductResult.List {
			tradeProducts = append(tradeProducts, solutionProduct.Product)
		}

		solutionInfo := solutionMap[version.Solution]
		solutionInfos = append(solutionInfos, &SolutionInfo{
			ID:                      version.ID,
			Solution:                solutionInfo.Solution,
			SolutionType:            solutionInfo.SolutionType,
			ZhName:                  solutionInfo.ZhName,
			SolutionCode:            solutionInfo.SolutionCode,
			StandardSolutionCode:    solutionInfo.StandardSolutionCode,
			StandardSolutionName:    solutionInfo.StandardSolutionName,
			DepartmentName:          solutionInfo.DepartmentName,
			SolutionVersion:         version.SolutionVersion,
			StandardSolutionVersion: version.StandardSolutionVersion,
			TradeProducts:           tradeProducts,
			CatalogueCodeMapList:    solutionInfo.CatalogueCodeMapList,
		})
	}
	return solutionInfos, nil
}

func ListAllTradeSolutionInfoToRedis(ctx context.Context) error {
	allTradeSolutionInfos, err := listAllTradeSolutionInfo(ctx)
	if err != nil {
		return err
	}

	tradeSolutionMap := map[string]interface{}{}
	for _, tradeSolutionInfo := range allTradeSolutionInfos {
		tradeSolutionMap[tradeSolutionInfo.GetSolutionInfoKey()] = util.GetJsonStr(tradeSolutionInfo)
	}

	redisClient := redis_client.NewRedisClient()
	_, err = redisClient.HMSet(tradeSolutionInfoKey, tradeSolutionMap).Result()
	if err != nil {
		logs.CtxError(ctx, "save %s to cache error :%s", tradeSolutionInfoKey, err.Error())
		return err
	}
	return nil
}

func ListTradeSolutionInfoFromRedis() (map[string]*SolutionInfo, error) {
	redisClient := redis_client.NewRedisClient()
	tradeSolutionInfoStrMap, err := redisClient.HGetAll(tradeSolutionInfoKey).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	tradeSolutionInfoMap := map[string]*SolutionInfo{}
	for solutionKey, solutionInfoStr := range tradeSolutionInfoStrMap {
		solutionInfo := &SolutionInfo{}
		err = sonic.Unmarshal([]byte(solutionInfoStr), solutionInfo)
		if err != nil {
			return nil, err
		}
		tradeSolutionInfoMap[solutionKey] = solutionInfo
	}
	return tradeSolutionInfoMap, nil
}

func GetTradeSolutionInfoFromRedis(solution, solutionVersion string) (*SolutionInfo, error) {
	redisClient := redis_client.NewRedisClient()
	solutionInfoKey := GetSolutionInfoKey(solution, solutionVersion)
	tradeSolutionInfoStr, err := redisClient.HGet(tradeSolutionInfoKey, solutionInfoKey).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	solutionInfo := &SolutionInfo{}
	err = sonic.Unmarshal([]byte(tradeSolutionInfoStr), solutionInfo)
	if err != nil {
		return nil, err
	}
	return solutionInfo, nil
}

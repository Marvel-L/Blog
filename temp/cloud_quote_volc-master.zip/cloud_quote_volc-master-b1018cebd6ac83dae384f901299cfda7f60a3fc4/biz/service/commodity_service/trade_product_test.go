package commodity_service

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"encoding/json"
	"errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/constraint_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/product_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/kv/goredis"
	"code.byted.org/kv/redis-v6"
	"code.byted.org/kv/redis-v6/pkg"
	"code.byted.org/videoarch/cloud_gopkg/products_client"
	"github.com/bytedance/sonic"
	"github.com/shopspring/decimal"
)

func TestGetTradeProductByType(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*ListTradeProductInfoReq).ListTradeProduct).Return([]*trade_client.TradeProductVersionInfo{&trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}}, fmt.Errorf("your error")).Build()

			// Act
			var v = constants.ProductType(0)
			_, err := GetTradeProductByType(context.Background(), v, "")

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*ListTradeProductInfoReq).ListTradeProduct).Return([]*trade_client.TradeProductVersionInfo{&trade_client.TradeProductVersionInfo{
				TradeProduct: "",
			}}, nil).Build()

			// Act
			var v = constants.ProductType(0)
			_, err := GetTradeProductByType(context.Background(), v, "")

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}
func TestListTradeProductInfoReq_filterTradeProductInfo(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(map[string]int{"ECS": 1}).Build()
			mockey.Mock(product_config_parser.CustomerScopeMatch).Return(true).Build()

			// Act
			v1 := &ListTradeProductInfoReq{
				ProductFilter: &ProductFilter{
					SingleSale:            false,                                  // 是否独立售卖-解决方案外添加商品，设置true,返回独立售卖商品
					DeploymentType:        multienv.TradeProductDeploymentTypeAll, // 部署类型-不为所有时multienv.TradeProductDeploymentTypeAll，返回指定部署类型的商品
					CustomerScope:         "",                                     // 售卖范围-不为空时，内部客户报价可以报内部和内外部商品，外部客户只可以报价内外部客户的商品
					ConstraintAccountList: []int64{0},                             // 约束账号列表-不为空时，查询商品状态要进行商品约束匹配
					ItemScene:             1,                                      // 报价项交付项场景-1（报价项场景），不返回“线下仅用于交付BOM的通用商品”
					StandardProduct:       "",                                     // 标品or非标品-不为空时，返回标准类型一致的商品
					IgnoreStatus:          true,                                   // 忽略商品状态-true时，忽略商品状态过滤
				},
			}
			got := v1.filterTradeProductInfo(context.Background(), []*trade_client.ProductInfo{&trade_client.ProductInfo{
				Product:      "ECS",
				Status:       3,
				SalesChannel: "官网",
				CatalogueCodeMap: map[string]string{
					"product_source_subject": "first_party",
					"deployment_type":        "public_cloud",
					"product_type":           "service",
					"product_source":         "self_owned",
					"non_standard_product":   "standard_product",
					"selling_customer_scope": "external_customers",
				},
				SalesStatus: 4,
				SingleSale:  1,
				ProductTag:  "",
			}}, nil)

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})

}

// Test_ListTradeProductInfoReq_ListAllTradeProductFromServer tests the ListAllTradeProductFromServer method.
func Test_ListTradeProductInfoReq_ListAllTradeProductFromServer_BitsUTGen(t *testing.T) {
	// Common mock data
	productInfoList := []*trade_client.ProductInfo{
		{
			Product:          "prod-1",
			ChildProductCode: "child-prod-1",
			CatalogueCodeMap: map[string]string{
				multienv.DeploymentTypeKey:  multienv.PublicDeploymentType,
				multienv.StandardProductKey: multienv.StandardProductYes,
				multienv.ProductTypeKey:     "software",
				multienv.ProductSourceKey:   "self_owned",
			},
		},
	}
	productVersions := &commercialization_api.ListProductVersionForQuote{
		ProductList: []*commercialization_api.ProductVersionForQuoteResp{
			{
				Product:        "prod-1",
				ProductVersion: "v1.0",
				PriceVersion:   "pv1.0",
			},
		},
	}
	childProductResp := &products_client.ListChildProductResp{
		List: []products_client.ListChildProduct{
			{
				Code:                "child-prod-1",
				Name:                "Child Product 1",
				StandardProductCode: "std-prod-1",
				StandardProductName: "Standard Product 1",
				BelongingDepartment: "Dept A",
				BizLineName:         "Biz B",
			},
		},
	}

	t.Run("Successful full update", func(t *testing.T) {
		mockey.PatchConvey("Successful full update with empty TradeProductList", t, func() {
			req := &ListTradeProductInfoReq{
				TradeProductList: []string{},
			}
			mockRedisClient := &goredis.Client{Client: &redis.Client{}}
			mockStatusCmd := redis.NewStatusCmd()

			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(mockRedisClient).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HMSet")).Return(mockStatusCmd).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result[0].ProductVersion, convey.ShouldEqual, "v1.0")
		})
	})

	t.Run("Successful partial update", func(t *testing.T) {
		mockey.PatchConvey("Successful partial update with existing cache", t, func() {
			req := &ListTradeProductInfoReq{
				TradeProductList: []string{"prod-1"},
			}
			mockRedisClient := &goredis.Client{Client: &redis.Client{}}
			mockStatusCmd := redis.NewStatusCmd()
			mockHGetAllCmd := redis.NewStringStringMapCmd()

			cachedData, _ := json.Marshal([]string{"prod-existing"})
			mockey.Mock((*redis.StringStringMapCmd).Result).Return(map[string]string{"child-prod-1": string(cachedData)}, nil).Build()

			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(mockRedisClient).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HGetAll")).Return(mockHGetAllCmd).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HMSet")).Return(mockStatusCmd).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
		})
	})

	t.Run("Failure on ListProductInfo", func(t *testing.T) {
		mockey.PatchConvey("Should return error when ListProductInfo fails", t, func() {
			req := &ListTradeProductInfoReq{}
			expectedErr := errors.New("list product info error")
			mockey.Mock(trade_client.ListProductInfo).Return(nil, expectedErr).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure on ListProductVersions", func(t *testing.T) {
		mockey.PatchConvey("Should return error when ListProductVersions fails", t, func() {
			req := &ListTradeProductInfoReq{}
			expectedErr := errors.New("list product versions error")
			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(nil, expectedErr).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure on ListChildProducts", func(t *testing.T) {
		mockey.PatchConvey("Should return error when ListChildProducts fails", t, func() {
			req := &ListTradeProductInfoReq{}
			expectedErr := errors.New("list child products error")
			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(nil, expectedErr).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure on first redis HMSet", func(t *testing.T) {
		mockey.PatchConvey("Should return error when the first HMSet to redis fails", t, func() {
			req := &ListTradeProductInfoReq{}
			mockRedisClient := &goredis.Client{Client: &redis.Client{}}
			expectedErr := errors.New("redis hmset error")
			mockStatusCmd := redis.NewStatusCmd()
			mockStatusCmd.SetErr(expectedErr)

			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(mockRedisClient).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HMSet")).Return(mockStatusCmd).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Partial update with redis HGetAll returning pkg.Nil", func(t *testing.T) {
		mockey.PatchConvey("Should return nil, nil when HGetAll returns pkg.Nil", t, func() {
			req := &ListTradeProductInfoReq{
				TradeProductList: []string{"prod-1"},
			}
			mockRedisClient := &goredis.Client{Client: &redis.Client{}}
			mockStatusCmd := redis.NewStatusCmd()
			mockHGetAllCmd := redis.NewStringStringMapCmd()
			mockHGetAllCmd.SetErr(pkg.Nil)

			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(mockRedisClient).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HMSet")).Return(mockStatusCmd).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HGetAll")).Return(mockHGetAllCmd).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Partial update with redis HGetAll returning error", func(t *testing.T) {
		mockey.PatchConvey("Should return error when HGetAll returns a generic error", t, func() {
			req := &ListTradeProductInfoReq{
				TradeProductList: []string{"prod-1"},
			}
			mockRedisClient := &goredis.Client{Client: &redis.Client{}}
			mockStatusCmd := redis.NewStatusCmd()
			expectedErr := errors.New("hgetall generic error")
			mockHGetAllCmd := redis.NewStringStringMapCmd()
			mockHGetAllCmd.SetErr(expectedErr)

			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(productVersions, nil).Build()
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(mockRedisClient).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HMSet")).Return(mockStatusCmd).Build()
			mockey.Mock(mockey.GetMethod(mockRedisClient, "HGetAll")).Return(mockHGetAllCmd).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Empty tradeProductMap after processing", func(t *testing.T) {
		mockey.PatchConvey("Should return nil, nil when no products are processed", t, func() {
			req := &ListTradeProductInfoReq{}
			mockey.Mock(trade_client.ListProductInfo).Return(productInfoList, nil).Build()
			mockey.Mock(trade_client.ListProductVersions).Return(&commercialization_api.ListProductVersionForQuote{}, nil).Build() // Empty versions
			mockey.Mock(product_client.ListChildProducts).Return(childProductResp, nil).Build()

			result, err := req.ListAllTradeProductFromServer(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_GetTradeProductListByArray_BitsUTGen(t *testing.T) {
	t.Run("error when GetTradeProductByArray fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(GetTradeProductByArray).Return(nil, errors.New("mock error")).Build()

			result, err := GetTradeProductListByArray(context.Background(), []string{"prod-1"}, false)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("success when GetTradeProductByArray returns map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expected := map[string]*trade_client.TradeProductVersionInfo{
				"prod-1": {TradeProduct: "prod-1", TradeProductName: "Product One"},
				"prod-2": {TradeProduct: "prod-2", TradeProductName: "Product Two"},
			}
			mockey.Mock(GetTradeProductByArray).Return(expected, nil).Build()

			result, err := GetTradeProductListByArray(context.Background(), []string{"prod-1", "prod-2"}, true)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, len(expected))

			actualMap := map[string]*trade_client.TradeProductVersionInfo{}
			for _, info := range result {
				actualMap[info.TradeProduct] = info
			}
			for key, info := range expected {
				convey.So(actualMap[key], convey.ShouldEqual, info)
			}
		})
	})
}

func Test_GetTradeProductCalDataMap_BitsUTGen(t *testing.T) {
	t.Run("空商品列表直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			var productInfoList []*trade_client.ProductInfo

			res, err := GetTradeProductCalDataMap(ctx, productInfoList)
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Redis HMGet返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与商品列表
			ctx := context.Background()
			productInfoList := []*trade_client.ProductInfo{
				{Product: "p_err"},
			}

			// 构造并返回自定义redis客户端，避免空指针
			mockClient := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.MockUnsafe(redis_client.NewRedisClient).Return(mockClient).Build()

			// HMGet替换为不走真实process的实现
			mockey.Mock(mockey.GetMethod(mockClient, "HMGet")).To(func(key string, fields ...string) *redis.SliceCmd {
				// 这里返回一个空的SliceCmd对象，后续通过Result的mock返回错误
				return &redis.SliceCmd{}
			}).Build()

			// Result返回错误，覆盖函数的错误返回分支
			mockey.MockUnsafe((*redis.SliceCmd).Result).Return(nil, errors.New("hmget err")).Build()

			res, err := GetTradeProductCalDataMap(ctx, productInfoList)
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "hmget err")
		})
	})

	t.Run("成功返回，包含nil、空字符串、非字符串、有效与无效JSON", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			productInfoList := []*trade_client.ProductInfo{
				{Product: "p1"},
				{Product: "p2"},
				{Product: "p3"},
				{Product: "p4"},
				{Product: "p5"},
			}

			mockClient := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.MockUnsafe(redis_client.NewRedisClient).Return(mockClient).Build()
			mockey.Mock(mockey.GetMethod(mockClient, "HMGet")).To(func(key string, fields ...string) *redis.SliceCmd {
				// 校验一下key与fields的拼接不影响后续逻辑
				_ = constants.TradeProductCalKey
				_ = fields
				return &redis.SliceCmd{}
			}).Build()

			// 构造返回的dataMap数组：
			// 1. nil
			// 2. 空字符串
			// 3. 非字符串类型(int)
			// 4. 有效JSON
			// 5. 无效JSON
			validCal := trade_client.TradeProductCalData{
				TradeProduct:        "p4",
				FollowQuantityPrice: true,
			}
			validJSONBytes, _ := json.Marshal(validCal)
			validJSONStr := string(validJSONBytes)
			invalidJSONStr := "{invalid-json}"

			dataMap := []interface{}{
				nil,
				"",
				123,
				validJSONStr,
				invalidJSONStr,
			}

			mockey.MockUnsafe((*redis.SliceCmd).Result).Return(dataMap, nil).Build()

			res, err := GetTradeProductCalDataMap(ctx, productInfoList)
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)

			// p1: nil数据，走默认值
			convey.So(res["p1"], convey.ShouldNotBeNil)
			convey.So(res["p1"].TradeProduct, convey.ShouldEqual, "p1")
			convey.So(res["p1"].FollowQuantityPrice, convey.ShouldEqual, false)

			// p2: 空字符串，走默认值
			convey.So(res["p2"], convey.ShouldNotBeNil)
			convey.So(res["p2"].TradeProduct, convey.ShouldEqual, "p2")
			convey.So(res["p2"].FollowQuantityPrice, convey.ShouldEqual, false)

			// p3: 非字符串类型，走默认值
			convey.So(res["p3"], convey.ShouldNotBeNil)
			convey.So(res["p3"].TradeProduct, convey.ShouldEqual, "p3")
			convey.So(res["p3"].FollowQuantityPrice, convey.ShouldEqual, false)

			// p4: 解析成功，覆盖默认值
			convey.So(res["p4"], convey.ShouldNotBeNil)
			convey.So(res["p4"].TradeProduct, convey.ShouldEqual, "p4")
			convey.So(res["p4"].FollowQuantityPrice, convey.ShouldEqual, true)

			// p5: 解析失败，保持默认值
			convey.So(res["p5"], convey.ShouldNotBeNil)
			convey.So(res["p5"].TradeProduct, convey.ShouldEqual, "p5")
			convey.So(res["p5"].FollowQuantityPrice, convey.ShouldEqual, false)
		})
	})
}

func Test_SaveTradeProductCalData_BitsUTGen(t *testing.T) {
	t.Run("序列化失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造必要参数
			ctx := context.Background()
			tradeProduct := "TP-MARSHAL-ERR"
			calData := &trade_client.TradeProductCalData{FollowQuantityPrice: true}

			// 打桩sonic.Marshal返回错误，导致序列化失败
			mockey.MockUnsafe(sonic.Marshal).Return(nil, errors.New("marshal fail")).Build()

			// 调用并断言
			err := SaveTradeProductCalData(ctx, tradeProduct, calData)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to serialize trade product cal data")
		})
	})

	t.Run("Redis HSet返回错误时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造必要参数
			ctx := context.Background()
			tradeProduct := "TP-HSET-ERR"
			calData := &trade_client.TradeProductCalData{FollowQuantityPrice: false}

			// 初始化可用的redis客户端并打桩NewRedisClient
			mockClient := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()

			// 打桩HSet返回错误
			mockey.Mock(mockey.GetMethod(mockClient, "HSet")).To(func(key, field string, value interface{}) *redis.BoolCmd {
				cmd := redis.NewBoolCmd("hset", key, field, value)
				cmd.SetErr(errors.New("hset error"))
				return cmd
			}).Build()

			// 调用并断言
			err := SaveTradeProductCalData(ctx, tradeProduct, calData)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "hset error")
		})
	})

	t.Run("序列化和Redis HSet成功时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造必要参数
			ctx := context.Background()
			tradeProduct := "TP-SUCCESS"
			calData := &trade_client.TradeProductCalData{FollowQuantityPrice: true}

			// 初始化可用的redis客户端并打桩NewRedisClient
			mockClient := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()

			// 打桩HSet返回成功的BoolCmd（无错误）
			mockey.Mock(mockey.GetMethod(mockClient, "HSet")).To(func(key, field string, value interface{}) *redis.BoolCmd {
				return redis.NewBoolCmd("hset", key, field, value)
			}).Build()

			// 调用并断言
			err := SaveTradeProductCalData(ctx, tradeProduct, calData)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ListTradeProductInfoReq_ListTradeProduct_BitsUTGen(t *testing.T) {
	t.Run("Return error when cache retrieval fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			ctx := context.Background()
			req := &ListTradeProductInfoReq{}

			mockey.Mock((*ListTradeProductInfoReq).ListTradeProductFromCache).Return(nil, errors.New("cacheErr")).Build()

			// Act
			ret, err := req.ListTradeProduct(ctx)

			// Assert
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "cacheErr")
		})
	})

	t.Run("Return nil when cache returns empty list", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			ctx := context.Background()
			req := &ListTradeProductInfoReq{}

			mockey.Mock((*ListTradeProductInfoReq).ListTradeProductFromCache).Return(nil, nil).Build()

			// Act
			ret, err := req.ListTradeProduct(ctx)

			// Assert
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return error when selection rules retrieval fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			ctx := context.Background()
			req := &ListTradeProductInfoReq{}

			pi := &trade_client.ProductInfo{
				ZhName:           "A",
				Product:          "p1",
				SalesStatus:      4,
				SalesChannel:     "x",
				StandardProduct:  1,
				TaxRate:          decimal.New(0, 0),
				CatalogueCodeMap: map[string]string{},
			}
			mockey.Mock((*ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{pi}, nil).Build()
			mockey.Mock(GetProductSelectRules).Return(nil, errors.New("selErr")).Build()

			// Act
			ret, err := req.ListTradeProduct(ctx)

			// Assert
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "selErr")
		})
	})

	t.Run("Return error when cal data retrieval fails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			ctx := context.Background()
			req := &ListTradeProductInfoReq{}

			pi := &trade_client.ProductInfo{
				ZhName:           "A",
				Product:          "p1",
				SalesStatus:      4,
				SalesChannel:     "x",
				StandardProduct:  1,
				TaxRate:          decimal.New(0, 0),
				CatalogueCodeMap: map[string]string{},
			}

			mockey.Mock((*ListTradeProductInfoReq).ListTradeProductFromCache).Return([]*trade_client.ProductInfo{pi}, nil).Build()
			mockey.Mock(GetProductSelectRules).Return(map[string]*trade_client.SelectionRuleData{}, nil).Build()
			mockey.Mock((*ListTradeProductInfoReq).filterTradeProductInfo).To(func(_ *ListTradeProductInfoReq, _ context.Context, list []*trade_client.ProductInfo, _ map[string]*trade_client.SelectionRuleData) []*trade_client.ProductInfo {
				return list
			}).Build()
			mockey.Mock(GetTradeProductCalDataMap).Return(nil, errors.New("cal-err")).Build()

			// Act
			ret, err := req.ListTradeProduct(ctx)

			// Assert
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "cal-err")
		})
	})

	t.Run("Successful path with selection rules and sorting", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			ctx := context.Background()
			req := &ListTradeProductInfoReq{}

			pi1 := &trade_client.ProductInfo{
				ZhName:                     "A",
				Product:                    "p1",
				StandardProductCode:        "spc1",
				StandardProductName:        "spn1",
				ChildProductCode:           "cpc1",
				ChildProductName:           "cpn1",
				BelongingDepartment:        "dept1",
				BizLineName:                "biz1",
				ProductVersion:             "pv1",
				PriceVersion:               "prv1",
				Status:                     1,
				ProductType:                10,
				StandardProduct:            1,
				ProductTag:                 "tag",
				TradeProductType:           "type",
				TaxRate:                    decimal.New(10, 0),
				ActivationType:             2,
				ProductCode:                "code1",
				ProductDesc:                "desc1",
				InvoiceProject:             "inv1",
				InvoiceItem:                "item1",
				IncomeCode:                 "income1",
				CombinedSaleInvoiceProject: "c-inv1",
				CombinedSaleInvoiceItem:    "c-item1",
				CombinedSaleTaxRate:        decimal.New(30, 0),
				CombinedSaleIncomeCode:     "c-income1",
				DeliveryMethodID:           "dm1",
				ProductSource:              "self",
				SalesMode:                  "mode",
				IsAIProduct:                1,
				CatalogueCodeMap:           map[string]string{},
				SingleSale:                 1,
				SalesStatus:                4,
				SalesChannel:               "x",
				DeliveryMethodZhName:       "dmzn1",
			}
			pi2 := &trade_client.ProductInfo{
				ZhName:                     "B",
				Product:                    "p2",
				StandardProductCode:        "spc2",
				StandardProductName:        "spn2",
				ChildProductCode:           "cpc2",
				ChildProductName:           "cpn2",
				BelongingDepartment:        "dept2",
				BizLineName:                "biz2",
				ProductVersion:             "pv2",
				PriceVersion:               "prv2",
				Status:                     2,
				ProductType:                20,
				StandardProduct:            2,
				ProductTag:                 "tag2",
				TradeProductType:           "type2",
				TaxRate:                    decimal.New(20, 0),
				ActivationType:             3,
				ProductCode:                "code2",
				ProductDesc:                "desc2",
				InvoiceProject:             "inv2",
				InvoiceItem:                "item2",
				IncomeCode:                 "income2",
				CombinedSaleInvoiceProject: "c-inv2",
				CombinedSaleInvoiceItem:    "c-item2",
				CombinedSaleTaxRate:        decimal.New(40, 0),
				CombinedSaleIncomeCode:     "c-income2",
				DeliveryMethodID:           "dm2",
				ProductSource:              "self",
				SalesMode:                  "mode2",
				IsAIProduct:                0,
				CatalogueCodeMap:           map[string]string{},
				SingleSale:                 0,
				SalesStatus:                3,
				SalesChannel:               "y",
				DeliveryMethodZhName:       "dmzn2",
			}
			productList := []*trade_client.ProductInfo{pi1, pi2}

			mockey.Mock((*ListTradeProductInfoReq).ListTradeProductFromCache).Return(productList, nil).Build()

			selectionRule := &trade_client.SelectionRuleData{
				Product:             "p2",
				Details:             []*trade_client.SelectionRuleDetail{{Priority: 1, Field: "F"}},
				ConfigPublicDisplay: 1,
				Display:             1,
			}
			mockey.Mock(GetProductSelectRules).Return(map[string]*trade_client.SelectionRuleData{
				"p2": selectionRule,
			}, nil).Build()

			mockey.Mock((*ListTradeProductInfoReq).filterTradeProductInfo).To(func(_ *ListTradeProductInfoReq, _ context.Context, list []*trade_client.ProductInfo, _ map[string]*trade_client.SelectionRuleData) []*trade_client.ProductInfo {
				return list
			}).Build()

			calMap := map[string]*trade_client.TradeProductCalData{
				"p1": {TradeProduct: "p1", FollowQuantityPrice: true},
			}
			mockey.Mock(GetTradeProductCalDataMap).Return(calMap, nil).Build()

			// Act
			ret, err := req.ListTradeProduct(ctx)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(len(ret), convey.ShouldEqual, 2)

			// Sort should be descending by TradeProductName => "B", "A"
			convey.So(ret[0].TradeProductName, convey.ShouldEqual, "B")
			convey.So(ret[1].TradeProductName, convey.ShouldEqual, "A")

			// Verify selection rule branching
			convey.So(ret[0].TradeProduct, convey.ShouldEqual, "p2")
			convey.So(ret[0].SelectionRuleDetails, convey.ShouldNotBeNil)
			convey.So(len(ret[0].SelectionRuleDetails), convey.ShouldEqual, 1)
			convey.So(ret[0].ConfigPublicDisplay, convey.ShouldEqual, 1)
			convey.So(ret[0].InvoiceItem, convey.ShouldEqual, "item2")
			convey.So(ret[0].IncomeCode, convey.ShouldEqual, "income2")
			convey.So(ret[0].CombinedSaleInvoiceProject, convey.ShouldEqual, "c-inv2")
			convey.So(ret[0].CombinedSaleInvoiceItem, convey.ShouldEqual, "c-item2")
			convey.So(ret[0].CombinedSaleTaxRate.Equal(decimal.New(40, 0)), convey.ShouldBeTrue)
			convey.So(ret[0].CombinedSaleIncomeCode, convey.ShouldEqual, "c-income2")

			convey.So(ret[1].TradeProduct, convey.ShouldEqual, "p1")
			convey.So(ret[1].SelectionRuleDetails, convey.ShouldBeNil)
			convey.So(ret[1].ConfigPublicDisplay, convey.ShouldEqual, 0)
			convey.So(ret[1].InvoiceItem, convey.ShouldEqual, "item1")
			convey.So(ret[1].IncomeCode, convey.ShouldEqual, "income1")
			convey.So(ret[1].CombinedSaleInvoiceProject, convey.ShouldEqual, "c-inv1")
			convey.So(ret[1].CombinedSaleInvoiceItem, convey.ShouldEqual, "c-item1")
			convey.So(ret[1].CombinedSaleTaxRate.Equal(decimal.New(30, 0)), convey.ShouldBeTrue)
			convey.So(ret[1].CombinedSaleIncomeCode, convey.ShouldEqual, "c-income1")

			// Verify cal data mapping effects
			convey.So(ret[1].CalculateData, convey.ShouldNotBeNil)
			convey.So(ret[1].CalculateData.FollowQuantityPrice, convey.ShouldEqual, true)
			convey.So(ret[0].CalculateData, convey.ShouldBeNil)
		})
	})
}

//go:noinline
func newTradeProductInfoForTest(product string) *trade_client.ProductInfo {
	return &trade_client.ProductInfo{
		Product:      product,
		Status:       multienv.TradeProductStatusOn,
		SalesChannel: "官网",
		CatalogueCodeMap: map[string]string{
			multienv.DeploymentTypeKey:  multienv.PublicDeploymentType,
			multienv.CustomerScopeKey:   multienv.CustomerScopeInternalAndExternal,
			multienv.StandardProductKey: "standard_product",
		},
		SalesStatus:         multienv.SalesStatusOfficialSale,
		SingleSale:          int8(1),
		ProductTag:          "",
		BelongingDepartment: "dept-pass",
		BizLineName:         "biz-pass",
	}
}

//go:noinline
func newSpPkgInfoForTest() *model.SpPkgInfo {
	return &model.SpPkgInfo{
		ProductCode:           "sp-product",
		ConfigurationCode:     "sp-config",
		SpBuyDurationCode:     "sp-duration",
		CommitFeeIntervalCode: "sp-fee",
	}
}

//go:noinline
func getProductCodesForTest(productInfoList []*trade_client.ProductInfo) []string {
	ret := make([]string, 0, len(productInfoList))
	for _, productInfo := range productInfoList {
		ret = append(ret, productInfo.Product)
	}
	return ret
}
func Test_ListTradeProductInfoReq_filterTradeProductInfo_BitsUTGen(t *testing.T) {
	type args struct {
		ctx              context.Context
		req              *ListTradeProductInfoReq
		productInfoList  []*trade_client.ProductInfo
		allSelectRuleMap map[string]*trade_client.SelectionRuleData
	}
	tests := []struct {
		name      string
		setup     func()
		buildArgs func() args
		wantCodes []string
	}{
		{
			name: "无商品过滤条件时仅按售卖状态和售卖渠道过滤",
			buildArgs: func() args {
				invalidSalesStatus := newTradeProductInfoForTest("invalid-sales-status")
				invalidSalesStatus.SalesStatus = 0

				invalidSalesChannel := newTradeProductInfoForTest("invalid-sales-channel")
				invalidSalesChannel.SalesChannel = "厂商、运营商"

				passProduct := newTradeProductInfoForTest("plain-pass")

				return args{
					ctx: context.Background(),
					req: &ListTradeProductInfoReq{},
					productInfoList: []*trade_client.ProductInfo{
						invalidSalesStatus,
						invalidSalesChannel,
						passProduct,
					},
					allSelectRuleMap: nil,
				}
			},
			wantCodes: []string{"plain-pass"},
		},
		{
			name: "完整商品过滤时命中各类剔除分支并保留合法商品",
			setup: func() {
				mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(map[string]int{
					"constraint-pass": multienv.TradeProductStatusOn,
				}).Build()
				mockey.MockValue(&product_config_parser.SpDeductChargeItemsCache).To(product_config_parser.SpDeductChargeItemsCache)
				mockey.Mock(mockey.GetMethod(product_config_parser.SpDeductChargeItemsCache, "GetSpDeductProducts")).Return(map[string]bool{
					"selection-rule-display-pass": true,
					"constraint-pass":             true,
					"plain-pass":                  true,
				}).Build()
			},
			buildArgs: func() args {
				deploymentMismatch := newTradeProductInfoForTest("deployment-mismatch")
				deploymentMismatch.CatalogueCodeMap[multienv.DeploymentTypeKey] = multienv.PrivateDeploymentType

				scopeMismatch := newTradeProductInfoForTest("scope-mismatch")
				scopeMismatch.CatalogueCodeMap[multienv.CustomerScopeKey] = multienv.CustomerScopeInternal

				singleSaleMismatch := newTradeProductInfoForTest("single-sale-mismatch")
				singleSaleMismatch.SingleSale = multienv.CanNotSingleSale

				tagMismatch := newTradeProductInfoForTest("tag-mismatch")
				tagMismatch.ProductTag = "prefix-" + multienv.ProductTagOfflineBOMGeneralProduct + "-suffix"

				standardMismatch := newTradeProductInfoForTest("standard-mismatch")
				standardMismatch.CatalogueCodeMap[multienv.StandardProductKey] = "other-standard"

				deptMismatch := newTradeProductInfoForTest("dept-mismatch")
				deptMismatch.BelongingDepartment = "other-dept"

				bizMismatch := newTradeProductInfoForTest("biz-mismatch")
				bizMismatch.BizLineName = "other-biz"

				selectionRuleMismatch := newTradeProductInfoForTest("selection-rule-mismatch")

				statusMismatch := newTradeProductInfoForTest("status-mismatch")
				statusMismatch.Status = multienv.TradeProductStatusToOff

				spPkgMismatch := newTradeProductInfoForTest("sp-pkg-mismatch")

				selectionRuleDisplayPass := newTradeProductInfoForTest("selection-rule-display-pass")

				constraintPass := newTradeProductInfoForTest("constraint-pass")
				constraintPass.Status = multienv.TradeProductStatusToOff

				plainPass := newTradeProductInfoForTest("plain-pass")

				return args{
					ctx: context.Background(),
					req: &ListTradeProductInfoReq{
						ProductFilter: &ProductFilter{
							SingleSale:              true,
							DeploymentType:          multienv.TradeProductDeploymentTypePublic,
							CustomerScope:           multienv.QuoteCustomerScopeExternal,
							ConstraintAccountList:   []int64{1},
							ItemScene:               constants.ItemSceneQuoteItem,
							StandardProduct:         "standard_product",
							BelongingDepartmentList: []string{"dept-pass"},
							BizLineNameList:         []string{"biz-pass"},
							IgnoreStatus:            false,
							IgnoreSelectionRule:     false,
							SpPkgInfo:               newSpPkgInfoForTest(),
						},
					},
					productInfoList: []*trade_client.ProductInfo{
						deploymentMismatch,
						scopeMismatch,
						singleSaleMismatch,
						tagMismatch,
						standardMismatch,
						deptMismatch,
						bizMismatch,
						selectionRuleMismatch,
						statusMismatch,
						spPkgMismatch,
						selectionRuleDisplayPass,
						constraintPass,
						plainPass,
					},
					allSelectRuleMap: map[string]*trade_client.SelectionRuleData{
						"selection-rule-mismatch": {
							Product: "selection-rule-mismatch",
							Display: 2,
						},
						"selection-rule-display-pass": {
							Product: "selection-rule-display-pass",
							Display: 1,
						},
					},
				}
			},
			wantCodes: []string{"selection-rule-display-pass", "constraint-pass", "plain-pass"},
		},
		{
			name: "忽略状态和选品规则时待下架商品也会保留",
			setup: func() {
				mockey.Mock((*constraint_service.MatchConstraintProductReq).Match).Return(map[string]int(nil)).Build()
			},
			buildArgs: func() args {
				ignorePass := newTradeProductInfoForTest("ignore-pass")
				ignorePass.Status = multienv.TradeProductStatusToOff

				return args{
					ctx: context.Background(),
					req: &ListTradeProductInfoReq{
						ProductFilter: &ProductFilter{
							DeploymentType:      multienv.TradeProductDeploymentTypeAll,
							CustomerScope:       multienv.QuoteCustomerScopeAll,
							IgnoreStatus:        true,
							IgnoreSelectionRule: true,
							SpPkgInfo:           nil,
						},
					},
					productInfoList: []*trade_client.ProductInfo{
						ignorePass,
					},
					allSelectRuleMap: map[string]*trade_client.SelectionRuleData{
						"ignore-pass": {
							Product: "ignore-pass",
							Display: 2,
						},
					},
				}
			},
			wantCodes: []string{"ignore-pass"},
		},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				if tc.setup != nil {
					tc.setup()
				}
				args := tc.buildArgs()
				got := args.req.filterTradeProductInfo(args.ctx, args.productInfoList, args.allSelectRuleMap)
				convey.So(getProductCodesForTest(got), convey.ShouldResemble, tc.wantCodes)
			})
		})
	}
}

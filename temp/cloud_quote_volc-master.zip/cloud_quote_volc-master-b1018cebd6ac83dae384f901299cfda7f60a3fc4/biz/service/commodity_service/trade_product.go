package commodity_service

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"github.com/bytedance/sonic"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/constraint_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/kv/redis-v6/pkg"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/product_client"
	"code.byted.org/videoarch/cloud_gopkg/products_client"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/gopkg/logs"
)

const childProductCodeTradeProductKey = "child_product_code_trade_product_h"
const tradeProductInfoKey = "trade_product_info_h"

type ListTradeProductInfoReq struct {
	TradeProductList  []string
	ChildProductCodes []string
	ProductFilter     *ProductFilter
}

func (r *ListTradeProductInfoReq) ListTradeProduct(ctx context.Context) ([]*trade_client.TradeProductVersionInfo, error) {
	productVersionInfoList := make([]*trade_client.TradeProductVersionInfo, 0)
	productInfoList, err := r.ListTradeProductFromCache()
	if err != nil {
		return nil, err
	}
	if len(productInfoList) == 0 {
		return nil, nil
	}
	allSelectRuleMap, err := GetProductSelectRules(productInfoList)
	if err != nil {
		return nil, err
	}
	productInfoList = r.filterTradeProductInfo(ctx, productInfoList, allSelectRuleMap)

	// 批量获取商品计算数据
	allCalDataMap, err := GetTradeProductCalDataMap(ctx, productInfoList)
	if err != nil {
		return nil, err
	}

	for _, productInfo := range productInfoList {
		// 从批量获取的数据中获取商品计算数据
		calData := allCalDataMap[productInfo.Product]

		productVersionInfo := &trade_client.TradeProductVersionInfo{
			TradeProductName:           productInfo.ZhName,
			TradeProduct:               productInfo.Product,
			StandardProductCode:        productInfo.StandardProductCode,
			StandardProductName:        productInfo.StandardProductName,
			ChildProductCode:           productInfo.ChildProductCode,
			ChildProductName:           productInfo.ChildProductName,
			BelongingDepartment:        productInfo.BelongingDepartment,
			BizLineName:                productInfo.BizLineName,
			ProductVersion:             productInfo.ProductVersion,
			PriceVersion:               productInfo.PriceVersion,
			Status:                     productInfo.Status,
			ProductType:                productInfo.ProductType,
			StandardProduct:            productInfo.StandardProduct,
			ProductTag:                 productInfo.ProductTag,
			TradeProductType:           productInfo.TradeProductType,
			ActivationType:             productInfo.ActivationType,
			ProductCode:                productInfo.ProductCode,
			ProductDesc:                productInfo.ProductDesc,
			InvoiceProject:             productInfo.InvoiceProject,
			InvoiceItem:                productInfo.InvoiceItem,
			TaxRate:                    productInfo.TaxRate,
			IncomeCode:                 productInfo.IncomeCode,
			CombinedSaleInvoiceProject: productInfo.CombinedSaleInvoiceProject,
			CombinedSaleInvoiceItem:    productInfo.CombinedSaleInvoiceItem,
			CombinedSaleTaxRate:        productInfo.CombinedSaleTaxRate,
			CombinedSaleIncomeCode:     productInfo.CombinedSaleIncomeCode,
			DeliveryMethodID:           productInfo.DeliveryMethodID,
			ProductSource:              productInfo.ProductSource,
			SalesMode:                  productInfo.SalesMode,
			IsAIProduct:                productInfo.IsAIProduct,
			CatalogueCodeMap:           productInfo.CatalogueCodeMap,
			SingleSale:                 productInfo.SingleSale,
			CalculateData:              calData,
		}
		selectionRuleData := allSelectRuleMap[productInfo.Product]
		if selectionRuleData != nil {
			productVersionInfo.SelectionRuleDetails = selectionRuleData.Details
			productVersionInfo.ConfigPublicDisplay = selectionRuleData.ConfigPublicDisplay
		}
		productVersionInfoList = append(productVersionInfoList, productVersionInfo)
	}
	sort.Slice(productVersionInfoList, func(i, j int) bool {
		return productVersionInfoList[i].TradeProductName > productVersionInfoList[j].TradeProductName
	})

	return productVersionInfoList, nil
}

func (r *ListTradeProductInfoReq) ListTradeProductFromCache() ([]*trade_client.ProductInfo, error) {
	logs.Info("ListTradeProductInfoReq : %s", util.GetJsonStr(r))

	var tradeProductList []string
	var allTradeProductList []string

	childProductCodeMap := map[string]bool{}
	for _, childProductCode := range r.ChildProductCodes {
		childProductCodeMap[childProductCode] = true
	}
	redisClient := redis_client.NewRedisClient()
	allChildProductCodeMap, err := redisClient.HGetAll(childProductCodeTradeProductKey).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	for childProductCode, tradeProductArrStr := range allChildProductCodeMap {
		var tradeProductArr []string
		err = sonic.Unmarshal([]byte(tradeProductArrStr), &tradeProductArr)
		if err != nil {
			return nil, err
		}
		if _, ok := childProductCodeMap[childProductCode]; ok {
			tradeProductList = append(tradeProductList, tradeProductArr...)
		}
		allTradeProductList = append(allTradeProductList, tradeProductArr...)
	}

	tradeProductList = append(tradeProductList, r.TradeProductList...)
	if len(r.TradeProductList) == 0 && len(r.ChildProductCodes) == 0 {
		tradeProductList = allTradeProductList
	}

	if len(tradeProductList) == 0 {
		return nil, nil
	}

	tradeProductArr, err := redisClient.HMGet(tradeProductInfoKey, tradeProductList...).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var ret []*trade_client.ProductInfo
	for _, tradeProduct := range tradeProductArr {
		tradeProductInfoStr, ok := tradeProduct.(string)
		if ok {
			tradeProductInfo := &trade_client.ProductInfo{}
			err = sonic.Unmarshal([]byte(tradeProductInfoStr), tradeProductInfo)
			if err != nil {
				return nil, err
			}
			ret = append(ret, tradeProductInfo)
		}
	}
	return ret, nil
}

func (r *ListTradeProductInfoReq) ListAllTradeProductFromServer(ctx context.Context) ([]*trade_client.ProductInfo, error) {

	req := &commercialization_api.ListProductReq{
		ProductList: r.TradeProductList,
	}

	productInfoList, err := trade_client.ListProductInfo(ctx, req)
	if err != nil {
		return nil, err
	}

	// 补充价格版本信息
	childProductCodeMap := map[string]bool{}
	var childProductCodes []string
	for _, productInfo := range productInfoList {
		childProductCodeMap[productInfo.ChildProductCode] = true
	}
	productVersionMap := map[string]*commercialization_api.ProductVersionForQuoteResp{}
	for childProductCode := range childProductCodeMap {
		//time.Sleep(1 * time.Second)
		productVersions, err := trade_client.ListProductVersions(ctx, &commercialization_api.ListProductVersionForQuoteReq{
			ProductCodeList: []string{childProductCode},
		})
		if err != nil {
			return nil, err
		}
		for _, productVersion := range productVersions.ProductList {
			productVersionMap[productVersion.Product] = productVersion
		}
		childProductCodes = append(childProductCodes, childProductCode)
	}
	childProductResp, err := product_client.ListChildProducts(ctx, products_client.ListChildProductReq{
		Pagination: products_client.Pagination{
			Limit:  len(childProductCodes),
			Offset: 1,
		},
		ProductCodes: childProductCodes,
	}, false)
	if err != nil {
		return nil, err
	}
	childProductMap := map[string]*products_client.ListChildProduct{}
	for i, childProduct := range childProductResp.List {
		childProductMap[childProduct.Code] = &childProductResp.List[i]
	}

	childProductCodeProductMap := map[string][]string{}
	tradeProductMap := map[string]interface{}{}

	for _, productInfo := range productInfoList {
		productVersion, ok := productVersionMap[productInfo.Product]
		if !ok {
			logs.CtxError(ctx, "商品版本缺失 product: %s ,childProductCode: %s ", productInfo.Product, productInfo.ChildProductCode)
			continue
		}

		childProduct, ok := childProductMap[productInfo.ChildProductCode]
		if !ok {
			logs.CtxError(ctx, "子产品缺失 childProductCode: %s ", productInfo.ChildProductCode)
			continue
		}
		deploymentType := productInfo.CatalogueCodeMap[multienv.DeploymentTypeKey]
		productType := multienv.DeploymentTypeMapping[deploymentType]
		standardProductType := productInfo.CatalogueCodeMap[multienv.StandardProductKey]
		productInfo.StandardProductCode = childProduct.StandardProductCode
		productInfo.StandardProductName = childProduct.StandardProductName
		productInfo.ChildProductName = childProduct.Name
		productInfo.BelongingDepartment = childProduct.BelongingDepartment
		productInfo.BizLineName = childProduct.BizLineName
		productInfo.ProductVersion = productVersion.ProductVersion
		productInfo.PriceVersion = productVersion.PriceVersion
		productInfo.ProductType = int(productType)
		productInfo.StandardProduct = multienv.StandardProductMapping[standardProductType]
		productInfo.TradeProductType = productInfo.CatalogueCodeMap[multienv.ProductTypeKey]
		productInfo.ProductSource = productInfo.CatalogueCodeMap[multienv.ProductSourceKey]

		childProductCodeProductMap[productInfo.ChildProductCode] = append(childProductCodeProductMap[productInfo.ChildProductCode], productInfo.Product)
		tradeProductMap[productInfo.Product] = util.GetJsonStr(productInfo)
	}
	if len(tradeProductMap) == 0 {
		return nil, nil
	}

	redisClient := redis_client.NewRedisClient()
	_, err = redisClient.HMSet(tradeProductInfoKey, tradeProductMap).Result()
	if err != nil {
		logs.CtxError(ctx, "save %s to cache error :%s", tradeProductInfoKey, err.Error())
		return nil, err
	}

	m := map[string]interface{}{}

	if len(r.TradeProductList) > 0 { // 部分更新，需要将商品信息拼入子产品关联的商品缓存中
		allChildProductCodeMap, err := redisClient.HGetAll(childProductCodeTradeProductKey).Result()
		if err == pkg.Nil {
			return nil, nil
		}
		if err != nil {
			return nil, err
		}
		for childProductCode, tradeProductArr := range childProductCodeProductMap {
			tradeProductArrStrFromCache := allChildProductCodeMap[childProductCode]
			var tradeProductArrFromCache []string
			err = sonic.Unmarshal([]byte(tradeProductArrStrFromCache), &tradeProductArrFromCache)
			if err != nil {
				return nil, err
			}
			tradeProductCacheMap := map[string]bool{}
			for _, childProductCodeTradeProduct := range tradeProductArrFromCache {
				tradeProductCacheMap[childProductCodeTradeProduct] = true
			}
			for _, tradeProduct := range tradeProductArr {
				if _, ok := tradeProductCacheMap[tradeProduct]; !ok {
					tradeProductArrFromCache = append(tradeProductArrFromCache, tradeProduct)
				}
			}

			m[childProductCode] = util.GetJsonStr(tradeProductArrFromCache)
		}

	} else {
		for childProductCode, tradeProductArr := range childProductCodeProductMap {
			m[childProductCode] = util.GetJsonStr(tradeProductArr)
		}
	}

	_, err = redisClient.HMSet(childProductCodeTradeProductKey, m).Result()
	if err != nil {
		logs.CtxError(ctx, "save %s to cache error :%s", childProductCodeTradeProductKey, err.Error())
		return nil, err
	}

	return productInfoList, nil
}

func QueryTradeProductVersionInfo(ctx context.Context, tradeProduct string, tradeProducts []string, productFilter *ProductFilter) ([]*trade_client.TradeProductVersionInfo, error) {

	if len(tradeProducts) == 0 {
		listProductReq := &commercialization_api.ListProductReq{
			Product: tradeProduct,
		}
		productInfoList, err := trade_client.ListProductInfo(ctx, listProductReq)
		if err != nil {
			return nil, err
		}
		for _, productInfo := range productInfoList {
			tradeProducts = append(tradeProducts, productInfo.Product)
		}
	}

	if len(tradeProducts) == 0 {
		return nil, nil
	}

	req := &ListTradeProductInfoReq{
		TradeProductList: tradeProducts,
		ProductFilter:    productFilter,
	}
	return req.ListTradeProduct(ctx)
}

func GetTradeProductByArray(ctx context.Context, tradeProductArr []string, ignoreStatus bool) (map[string]*trade_client.TradeProductVersionInfo, error) {
	req := &ListTradeProductInfoReq{
		TradeProductList: util.GetUniqKeys(tradeProductArr),
		ProductFilter: &ProductFilter{
			SingleSale:     false,
			DeploymentType: multienv.TradeProductDeploymentTypeAll,
			CustomerScope:  "",
			IgnoreStatus:   ignoreStatus,
		},
	}
	productInfos, err := req.ListTradeProduct(ctx)
	if err != nil {
		return nil, err
	}
	effectiveTradeProductMap := map[string]*trade_client.TradeProductVersionInfo{}
	for _, productInfo := range productInfos {
		effectiveTradeProductMap[productInfo.TradeProduct] = productInfo
	}

	return effectiveTradeProductMap, nil
}

func GetTradeProductListByArray(ctx context.Context, tradeProductArr []string, ignoreStatus bool) ([]*trade_client.TradeProductVersionInfo, error) {
	productInfoMap, err := GetTradeProductByArray(ctx, tradeProductArr, ignoreStatus)
	if err != nil {
		return nil, err
	}
	var productInfoList []*trade_client.TradeProductVersionInfo
	for _, productInfo := range productInfoMap {
		productInfoList = append(productInfoList, productInfo)
	}
	return productInfoList, nil
}

// filterTradeProductInfo 私部属性、售卖渠道过滤、非标品（商品状态、售卖状态业务层过滤）
func (r *ListTradeProductInfoReq) filterTradeProductInfo(ctx context.Context, productInfoList []*trade_client.ProductInfo, allSelectRuleMap map[string]*trade_client.SelectionRuleData) []*trade_client.ProductInfo {
	var constraintProductStatusMap map[string]int
	var spDeductProducts map[string]bool
	if r.ProductFilter != nil {
		var productModelList []*commercialization_api.ProductConstraintModel
		for _, productInfo := range productInfoList {
			if productInfo.Status == multienv.TradeProductStatusOn {
				continue
			}
			productModelList = append(productModelList, &commercialization_api.ProductConstraintModel{
				Product: productInfo.Product,
				Status:  int8(productInfo.Status),
			})
		}
		matchReq := &constraint_service.MatchConstraintProductReq{
			AccountIDList:    r.ProductFilter.ConstraintAccountList,
			ProductModelList: productModelList,
			CustomerID:       r.ProductFilter.ConstraintAccountNumber,
		}
		constraintProductStatusMap = matchReq.Match(ctx)

		if r.ProductFilter.SpPkgInfo.HasSpPkgInfo() {
			spDeductProducts = product_config_parser.SpDeductChargeItemsCache.GetSpDeductProducts(r.ProductFilter.SpPkgInfo)
		}
	}
	var filteredProductInfoList []*trade_client.ProductInfo

	for _, productInfo := range productInfoList {
		//售卖状态过滤：保留商品售卖状态为公测、邀测、正式售卖的商品列表
		if _, ok := multienv.TradeProductSalesStatusCheckMapping[productInfo.SalesStatus]; !ok {
			logs.CtxInfo(ctx, "filterTradeProductInfo because of 【SalesStatus】，productInfo :%s ", util.GetJsonStr(productInfo))
			continue
		}
		channelsStr := productInfo.SalesChannel
		channels := strings.Split(channelsStr, multienv.SalesChannelSeparator)
		salesChannelFiltered := true
		for _, channel := range channels {
			if _, ok := multienv.ProductUnEffectiveSalesChannelMapping[channel]; !ok {
				salesChannelFiltered = false
				break
			}
		}
		if salesChannelFiltered {
			logs.CtxInfo(ctx, "filterTradeProductInfo because of 【SalesChannel】，productInfo :%s ", util.GetJsonStr(productInfo))
			continue
		}
		if r.ProductFilter != nil {
			statusMap := map[int]interface{}{multienv.TradeProductStatusOn: struct{}{}}
			if r.ProductFilter.IgnoreStatus {
				statusMap[multienv.TradeProductStatusToOff] = struct{}{}
			}
			catalogueCodeMap := productInfo.CatalogueCodeMap
			deploymentType := catalogueCodeMap[multienv.DeploymentTypeKey]
			productType := multienv.DeploymentTypeMapping[deploymentType]
			if r.ProductFilter.DeploymentType != multienv.TradeProductDeploymentTypeAll &&
				r.ProductFilter.DeploymentType != productType {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【DeploymentType】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			customerScope := catalogueCodeMap[multienv.CustomerScopeKey]
			if !product_config_parser.CustomerScopeMatch(r.ProductFilter.CustomerScope, customerScope) {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【CustomerScope】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			if r.ProductFilter.SingleSale && productInfo.SingleSale == multienv.CanNotSingleSale {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【SingleSale】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			if r.ProductFilter.TradeTypeCode == multienv.CustomerTypeCodeEcoDist && productInfo.SalesMode == multienv.SalesModePickupVoucher {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【SalesModePickupVoucher】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			//“线下仅用于交付BOM的通用商品”，不能在报价BOM中选到，只能在交付BOM中选到。
			if r.ProductFilter.ItemScene == constants.ItemSceneQuoteItem &&
				strings.Contains(productInfo.ProductTag, multienv.ProductTagOfflineBOMGeneralProduct) {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【ProductTag】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			if r.ProductFilter.StandardProduct != "" &&
				r.ProductFilter.StandardProduct != catalogueCodeMap[multienv.StandardProductKey] {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【StandardProduct】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			// 一级产品线过滤
			if len(r.ProductFilter.BelongingDepartmentList) > 0 {
				if !util.StrIn(productInfo.BelongingDepartment, r.ProductFilter.BelongingDepartmentList) {
					logs.CtxInfo(ctx, "filterTradeProductInfo because of 【BelongingDepartmentList】，productInfo :%s ", util.GetJsonStr(productInfo))
					continue
				}
			}

			// 二级产品线过滤
			if len(r.ProductFilter.BizLineNameList) > 0 {
				if !util.StrIn(productInfo.BizLineName, r.ProductFilter.BizLineNameList) {
					logs.CtxInfo(ctx, "filterTradeProductInfo because of 【BizLineNameList】，productInfo :%s ", util.GetJsonStr(productInfo))
					continue
				}
			}

			if !r.ProductFilter.IgnoreSelectionRule {
				selectionRuleData := allSelectRuleMap[productInfo.Product]
				if selectionRuleData != nil && selectionRuleData.Display != 1 {
					logs.CtxInfo(
						ctx,
						"filterTradeProductInfo because of 【selectionRule】, tradeProduct : [%s] selectionRule :%s ",
						productInfo.Product,
						util.GetJsonStr(selectionRuleData),
					)
					continue
				}
			}

			productStatus := productInfo.Status
			if constraintProductStatus, ok := constraintProductStatusMap[productInfo.Product]; ok {
				productStatus = constraintProductStatus
				logs.CtxInfo(
					ctx,
					"filterTradeProductInfo match constraint, tradeProduct : [%s] accountIDList :%s , original status : %d , constraint status : %d",
					productInfo.Product,
					util.GetJsonStr(r.ProductFilter.ConstraintAccountList),
					productInfo.Status,
					constraintProductStatus,
				)
			}

			if _, ok := statusMap[productStatus]; !ok {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【Status】，productInfo :%s ", util.GetJsonStr(productInfo))
				continue
			}

			if r.ProductFilter.SpPkgInfo.HasSpPkgInfo() && !spDeductProducts[productInfo.Product] {
				logs.CtxInfo(ctx, "filterTradeProductInfo because of 【SpPkgInfo】，spPkgInfo :%s , productInfo :%s ", util.GetJsonStr(r.ProductFilter.SpPkgInfo), util.GetJsonStr(productInfo))
				continue
			}
		}
		filteredProductInfoList = append(filteredProductInfoList, productInfo)
	}

	return filteredProductInfoList
}

func GetProductInfoFromCache(ctx context.Context, tradeProduct string) (*trade_client.TradeProductVersionInfo, error) {
	req := &ListTradeProductInfoReq{
		TradeProductList: []string{tradeProduct},
		ProductFilter: &ProductFilter{
			SingleSale:          false,
			DeploymentType:      multienv.TradeProductDeploymentTypeAll,
			CustomerScope:       "",
			IgnoreStatus:        true,
			IgnoreSelectionRule: true,
		},
	}
	productInfos, err := req.ListTradeProduct(ctx)
	if err != nil {
		return nil, err
	}

	if len(productInfos) == 0 || productInfos[0].TradeProduct != tradeProduct {
		return nil, errors.ErrBadRequestError.WithArgs("商品信息查询失败")
	}
	return productInfos[0], nil
}

func GetTradeProductByType(ctx context.Context, deploymentType constants.ProductType, standardProduct string) (map[string]*trade_client.TradeProductVersionInfo, error) {
	req := &ListTradeProductInfoReq{
		ProductFilter: &ProductFilter{
			DeploymentType:      deploymentType,
			StandardProduct:     standardProduct,
			IgnoreStatus:        true,
			IgnoreSelectionRule: true,
		},
	}
	productInfos, err := req.ListTradeProduct(ctx)
	if err != nil {
		return nil, err
	}
	effectiveTradeProductMap := map[string]*trade_client.TradeProductVersionInfo{}
	for _, productInfo := range productInfos {
		effectiveTradeProductMap[productInfo.TradeProduct] = productInfo
	}
	return effectiveTradeProductMap, nil
}

func GetAllTradeProductMap(ctx context.Context) (map[string]*trade_client.TradeProductVersionInfo, error) {
	req := &ListTradeProductInfoReq{
		ProductFilter: &ProductFilter{
			IgnoreStatus:        true,
			IgnoreSelectionRule: true,
			DeploymentType:      multienv.TradeProductDeploymentTypeAll,
		},
	}
	productInfos, err := req.ListTradeProduct(ctx)
	if err != nil {
		return nil, err
	}
	tradeProductMap := map[string]*trade_client.TradeProductVersionInfo{}
	for _, productInfo := range productInfos {
		tradeProductMap[productInfo.TradeProduct] = productInfo
	}
	return tradeProductMap, nil
}

// GetTradeProductCalDataMap 批量获取商品计算数据
func GetTradeProductCalDataMap(ctx context.Context, productInfoList []*trade_client.ProductInfo) (map[string]*trade_client.TradeProductCalData, error) {
	if len(productInfoList) == 0 {
		return nil, nil
	}

	redisClient := redis_client.NewRedisClient()

	tradeProducts := make([]string, 0, len(productInfoList))
	for _, productInfo := range productInfoList {
		tradeProducts = append(tradeProducts, productInfo.Product)
	}

	dataMap, err := redisClient.HMGet(constants.TradeProductCalKey, tradeProducts...).Result()
	if err != nil {
		return nil, err
	}

	calDataMap := make(map[string]*trade_client.TradeProductCalData, len(tradeProducts))

	// 先都给默认值，防止某些商品redis中没有
	for _, tradeProduct := range tradeProducts {
		calDataMap[tradeProduct] = &trade_client.TradeProductCalData{
			TradeProduct:        tradeProduct,
			FollowQuantityPrice: false,
		}
	}
	for _, calDataStr := range dataMap {
		if calDataStr == nil {
			continue
		}
		if dataStr, ok := calDataStr.(string); ok && dataStr != "" {
			if cal, parseErr := util.ParseJsonStr[trade_client.TradeProductCalData](dataStr); parseErr == nil {
				calDataMap[cal.TradeProduct] = &cal
			} else {
				logs.CtxError(ctx, "parseJsonStr TradeProductCalData error: %s, dataStr: %s", parseErr.Error(), dataStr)
			}
		}
	}

	return calDataMap, nil
}

// SaveTradeProductCalData 保存商品计算数据到redis
func SaveTradeProductCalData(ctx context.Context, tradeProduct string, calData *trade_client.TradeProductCalData) error {
	redisClient := redis_client.NewRedisClient()

	// 序列化数据
	data := util.GetJsonStr(calData)
	if data == "" {
		return fmt.Errorf("failed to serialize trade product cal data")
	}
	// 存储到redis hash中
	_, err := redisClient.HSet(constants.TradeProductCalKey, tradeProduct, data).Result()
	if err != nil {
		return err
	}

	logs.CtxInfo(ctx, "saveTradeProductCalData success, TradeProduct: %s, FollowQuantityPrice: %v",
		tradeProduct, calData.FollowQuantityPrice)
	return nil
}

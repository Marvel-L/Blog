package commodity_service

import (
	"context"
	"sort"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"github.com/bytedance/sonic"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kv/redis-v6/pkg"
)

const tradeSelectionRuleInfoKey = "trade_selection_rule_h"

type ListAllSelectionRuleToRedisReq struct {
	Token      string
	ProductArr []string
}

func (r *ListAllSelectionRuleToRedisReq) Handle(ctx context.Context) (interface{}, error) {
	conf := config.GetGlobalConf(ctx)
	if conf == nil {
		return nil, errors.ErrInternalError.WithArgs("get conf error")
	}
	if conf.CronConf.AllowHttpCall && conf.CronConf.HttpCallToken == r.Token {
		return ListAllSelectionRuleToRedis(ctx, r.ProductArr)
	} else {
		return nil, errors.ErrInvalidParam.WithArgs("token", r.Token)
	}
}

func ListAllSelectionRuleToRedis(ctx context.Context, tradeProductList []string) ([]*trade_client.SelectionRuleData, error) {
	productMap := util.StrSliceToMap(tradeProductList)
	var selectionRuleDatas []*trade_client.SelectionRuleData
	tradeProductMap, err := GetAllTradeProductMap(ctx)
	if err != nil {
		return nil, err
	}
	var productErrorList []string
	for tradeProduct, productInfo := range tradeProductMap {
		if len(productMap) > 0 && !productMap[tradeProduct] {
			continue
		}
		selectionRuleData, err := trade_client.GetSelectionRuleByProduct(ctx, &commercialization_api.ListSelectionRuleReq{
			Product:       tradeProduct,
			PageSize:      1,
			PageNo:        1,
			IsNewest:      1,
			FallbackValue: 1,
		})
		if err != nil {
			logs.CtxError(ctx, "GetSelectionRuleByProduct error tradeProduct %s, error %s", tradeProduct, err.Error())
			productErrorList = append(productErrorList, tradeProduct)
			continue
		}
		container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)
		if err != nil {
			logs.CtxError(ctx, "product_config_load.GetConfigContainer error tradeProduct %s, error %s", tradeProduct, err.Error())
			continue
		}
		configCategoryNeed := false
		configCategoryEnumMap := container.GetSchemaKeyEnumMap(ctx, tradeProduct, constants.SchemaConfigCategory)
		if _, ok := configCategoryEnumMap[""]; !ok || len(configCategoryEnumMap) > 1 {
			configCategoryNeed = true
		}
		var noConfig bool
		if productInfo.ProductType == int(multienv.TradeProductDeploymentTypePublic) {
			noConfig = true
		}
		excludeSchemaKeyMap := util.StrSliceToMap(constants.EnableExcludeSchemaKeys)
		for _, detail := range selectionRuleData.Details {
			detail.FormSchemaKey = constants.SelectRuleFieldSchemaKeyMap[detail.Field]
			if detail.FormSchemaKey == constants.SchemaConfig {
				detail.FieldType = 1
				detail.Choose = 1
				noConfig = false
			}
			if configCategoryNeed && detail.FormSchemaKey == constants.SchemaConfigCategory {
				detail.FieldType = 1
				detail.Choose = 1
			}
			if _, ok := excludeSchemaKeyMap[detail.FormSchemaKey]; ok {
				formatExcludeDetail(ctx, productInfo, selectionRuleData, detail)
			}
		}
		if noConfig { // 临时处理，后续看商品侧是否调整
			selectionRuleData.Details = append(selectionRuleData.Details, &trade_client.SelectionRuleDetail{
				Priority:      2,
				Field:         "Config",
				FieldName:     "配置名称",
				FieldType:     1,
				Necessary:     1,
				Choose:        1,
				SubField:      nil,
				FormSchemaKey: constants.SchemaConfig,
				HasAll:        multienv.FiledSupportSelectAllTrue,
			})
		}
		redisClient := redis_client.NewRedisClient()
		_, err = redisClient.HSet(tradeSelectionRuleInfoKey, tradeProduct, util.GetJsonStr(selectionRuleData)).Result()
		if err != nil {
			logs.CtxError(ctx, "GetSelectionRuleByProduct error redisClient.HSet tradeProduct %s, error %s", tradeProduct, err.Error())
			productErrorList = append(productErrorList, tradeProduct)
			continue
		}
		selectionRuleDatas = append(selectionRuleDatas, selectionRuleData)
	}
	logs.CtxInfo(ctx, "ListAllSelectionRuleToRedis productErrorList %s", productErrorList)
	return selectionRuleDatas, nil
}

func GetProductSelectRules(productInfoList []*trade_client.ProductInfo) (map[string]*trade_client.SelectionRuleData, error) {
	var productList []string
	for _, productInfo := range productInfoList {
		productList = append(productList, productInfo.Product)
	}

	redisClient := redis_client.NewRedisClient()
	selectionRuleDataArr, err := redisClient.HMGet(tradeSelectionRuleInfoKey, productList...).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	ret := map[string]*trade_client.SelectionRuleData{}
	for _, selectionRuleData := range selectionRuleDataArr {
		var selectionRule trade_client.SelectionRuleData
		selectionRuleDataStr, ok := selectionRuleData.(string)
		if ok {
			err = sonic.Unmarshal([]byte(selectionRuleDataStr), &selectionRule)
			if err != nil {
				return nil, err
			}
			ret[selectionRule.Product] = &selectionRule
		}
	}
	return ret, nil
}

func GetProductSelectRule(productCode string) (*trade_client.SelectionRuleData, error) {
	if productCode == "" {
		return nil, nil
	}

	redisClient := redis_client.NewRedisClient()
	selectionRuleDataStr, err := redisClient.HGet(tradeSelectionRuleInfoKey, productCode).Result()
	if err == pkg.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	selectionRule, err := util.ParseJsonStr[*trade_client.SelectionRuleData](selectionRuleDataStr)
	if err != nil {
		return nil, err
	}
	return selectionRule, nil
}

func formatExcludeDetail(ctx context.Context, productInfo *trade_client.TradeProductVersionInfo, selectionRuleData *trade_client.SelectionRuleData, selectionRuleDetail *trade_client.SelectionRuleDetail) {
	if productInfo.ProductType != int(multienv.TradeProductDeploymentTypePublic) {
		return // 只处理公有云
	}
	if selectionRuleData.HasExclude {
		return // 多字段排除，保留第一个字段的排除
	}
	if len(selectionRuleDetail.Exclude) == 0 {
		return
	}
	excludeDataList := selectionRuleDetail.Exclude
	sort.Slice(excludeDataList, func(i, j int) bool {
		return strings.Compare(excludeDataList[j].Code, excludeDataList[i].Code) > 0
	})
	if len(excludeDataList) > 20 {
		excludeDataList = excludeDataList[:20]
	}
	var names []string
	var codes []string
	for _, excludeData := range excludeDataList {
		if excludeData.Name == "" || excludeData.Code == "" {
			logs.CtxError(ctx, "formatExcludeDetail excludeData error Name:[%s],Code:[%s]", excludeData.Name, excludeData.Code)
			continue
		}
		if strings.Contains(excludeData.Name, ",") || strings.Contains(excludeData.Code, ",") {
			logs.CtxError(ctx, "formatExcludeDetail excludeData error Name:[%s],Code:[%s]", excludeData.Name, excludeData.Code)
			continue
		}
		names = append(names, excludeData.Name)
		codes = append(codes, excludeData.Code)
	}
	if len(names) > 0 && len(codes) > 0 {
		selectionRuleDetail.ExcludeDetail = &trade_client.ExcludeDetail{
			Names: strings.Join(names, ","),
			Codes: strings.Join(codes, ","),
		}
		selectionRuleData.HasExclude = true
	}
}

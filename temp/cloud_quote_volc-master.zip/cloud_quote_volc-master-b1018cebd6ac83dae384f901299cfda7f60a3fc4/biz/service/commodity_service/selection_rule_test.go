package commodity_service

import (
	"context"
	"fmt"
	"strings"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/commercialization_sdk_go/commercialization_api"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/kv/goredis"
	"code.byted.org/kv/redis-v6"
	"code.byted.org/kv/redis-v6/pkg"
	"errors"
)

func TestListAllSelectionRuleToRedis(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{"": &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
			}}, fmt.Errorf("your error")).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{&trade_client.SelectionRuleDetail{
					Field:         "",
					FormSchemaKey: "",
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, fmt.Errorf("your error")).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(false, fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetJsonStr).Return("").Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), []string{""})

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{"": &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
			}}, nil).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{&trade_client.SelectionRuleDetail{
					Field:         "",
					FormSchemaKey: "",
				}},
			}, fmt.Errorf("your error")).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, fmt.Errorf("your error")).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(false, fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetJsonStr).Return("").Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), nil)

			// Assert
			convey.So(len(got), convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{"": &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
			}}, nil).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{&trade_client.SelectionRuleDetail{
					Field:         "",
					FormSchemaKey: "",
				}},
			}, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, fmt.Errorf("your error")).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(false, fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetJsonStr).Return("").Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), nil)

			// Assert
			convey.So(len(got), convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{"": &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
			}}, nil).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfig,
					},
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfigCategory,
					},
				},
			}, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"123": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(false, fmt.Errorf("your error")).Build()
			mockey.Mock(util.GetJsonStr).Return("").Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), nil)

			// Assert
			convey.So(len(got), convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #5", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{"": &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
			}}, nil).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfig,
					},
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfigCategory,
					},
				},
			}, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"123": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(true, nil).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), nil)

			// Assert
			convey.So(len(got), convey.ShouldNotEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #6", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(GetAllTradeProductMap).Return(map[string]*trade_client.TradeProductVersionInfo{
				"123": &trade_client.TradeProductVersionInfo{
					ProductType:     0,
					StandardProduct: 0,
				},
				"456": &trade_client.TradeProductVersionInfo{
					ProductType:     0,
					StandardProduct: 0,
				},
			}, nil).Build()
			mockey.Mock(trade_client.GetSelectionRuleByProduct).Return(&trade_client.SelectionRuleData{
				Details: []*trade_client.SelectionRuleDetail{
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfig,
					},
					{
						Field:         "",
						FormSchemaKey: constants.SchemaConfigCategory,
					},
				},
			}, nil).Build()
			mockey.Mock(product_config_load.GetConfigContainer).Return(&product_config_load.ConfigContainer{}, nil).Build()
			mockey.Mock((*product_config_load.ConfigContainer).GetSchemaKeyEnumMap).Return(map[string]*product_config_load.EnumOption{"123": &product_config_load.EnumOption{}}).Build()
			mockey.Mock(redis_client.NewRedisClient).Return(&goredis.Client{
				Client: &redis.Client{},
			}).Build()
			mockey.Mock((*redis.BoolCmd).Result).Return(true, nil).Build()
			v := &goredis.Client{
				Client: &redis.Client{},
			}
			mockey.Mock(mockey.GetMethod(v, "HSet")).To(func(key string, field string, value interface{}) *redis.BoolCmd {
				v1 := &redis.BoolCmd{}
				v1.SetVal(false)
				// v1.SetErr(fmt.Errorf("your error"))
				return v1 // Add your code
			}).Build()

			// Act
			got, err := ListAllSelectionRuleToRedis(context.Background(), []string{"123"})

			// Assert
			convey.So(len(got), convey.ShouldEqual, 1)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_formatExcludeDetail(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("Private", t, func() {
			// Arrange
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// Act
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePrivate),
			}
			formatExcludeDetail(context.Background(), productInfo, nil, nil)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
		mockey.PatchConvey("HasExclude", t, func() {
			// Arrange
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// Act
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			selectionRuleData := &trade_client.SelectionRuleData{
				HasExclude: true,
			}
			formatExcludeDetail(context.Background(), productInfo, selectionRuleData, nil)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
		mockey.PatchConvey("Exclude empty", t, func() {
			// Arrange
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// Act
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			selectionRuleData := &trade_client.SelectionRuleData{
				HasExclude: false,
			}
			selectionRuleDetail := &trade_client.SelectionRuleDetail{}
			formatExcludeDetail(context.Background(), productInfo, selectionRuleData, selectionRuleDetail)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// Act
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			selectionRuleData := &trade_client.SelectionRuleData{
				HasExclude: false,
			}
			selectionRuleDetail := &trade_client.SelectionRuleDetail{
				Exclude: []*commercialization_api.SelectionRuleExcludeData{
					{Code: "1", Name: "1"},
					{Code: "3", Name: "3"},
					{Code: "2", Name: "2"},
					{Code: "4", Name: ""},
					{Code: "", Name: "5"},
					{Code: "6,", Name: "6"},
					{Code: "7", Name: "7,"},
				},
			}
			formatExcludeDetail(context.Background(), productInfo, selectionRuleData, selectionRuleDetail)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
			convey.So(selectionRuleDetail.ExcludeDetail.Names, convey.ShouldEqual, "1,2,3")
			convey.So(selectionRuleDetail.ExcludeDetail.Codes, convey.ShouldEqual, "1,2,3")
		})
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockUnsafe(multienv.IsBytePlus).Return(false).Build()
			// Act
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType: int(multienv.TradeProductDeploymentTypePublic),
			}
			selectionRuleData := &trade_client.SelectionRuleData{
				HasExclude: false,
			}
			selectionRuleDetail := &trade_client.SelectionRuleDetail{
				Exclude: []*commercialization_api.SelectionRuleExcludeData{
					{Code: "1", Name: "1"},
					{Code: "2", Name: "2"},
					{Code: "3", Name: "3"},
					{Code: "4", Name: "4"},
					{Code: "5", Name: "5"},
					{Code: "6", Name: "6"},
					{Code: "7", Name: "7"},
					{Code: "8", Name: "8"},
					{Code: "9", Name: "9"},
					{Code: "10", Name: "10"},
					{Code: "11", Name: "11"},
					{Code: "12", Name: "12"},
					{Code: "13", Name: "13"},
					{Code: "14", Name: "14"},
					{Code: "15", Name: "15"},
					{Code: "16", Name: "16"},
					{Code: "17", Name: "17"},
					{Code: "18", Name: "18"},
					{Code: "19", Name: "19"},
					{Code: "20", Name: "20"},
					{Code: "21", Name: "21"},
				},
			}
			formatExcludeDetail(context.Background(), productInfo, selectionRuleData, selectionRuleDetail)

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
			convey.So(strings.Split(selectionRuleDetail.ExcludeDetail.Names, ","), convey.ShouldHaveLength, 20)
			convey.So(strings.Split(selectionRuleDetail.ExcludeDetail.Codes, ","), convey.ShouldHaveLength, 20)
		})
	})
}

func Test_GetProductSelectRule_BitsUTGen(t *testing.T) {
	defer mockey.UnPatchAll()

	t.Run("Empty product code returns nil data", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rule, err := GetProductSelectRule("")
			convey.So(rule, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Redis returns pkg Nil so no rule", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockClient := &goredis.Client{Client: &redis.Client{}}
			stringCmd := &redis.StringCmd{}

			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()
			mockey.Mock(mockey.GetMethod(mockClient, "HGet")).To(func(key, field string) *redis.StringCmd {
				return stringCmd
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("", pkg.Nil).Build()

			rule, err := GetProductSelectRule("product-nil")
			convey.So(rule, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Redis returns unexpected error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockClient := &goredis.Client{Client: &redis.Client{}}
			stringCmd := &redis.StringCmd{}
			mockErr := errors.New("redis failure")

			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()
			mockey.Mock(mockey.GetMethod(mockClient, "HGet")).To(func(key, field string) *redis.StringCmd {
				return stringCmd
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("", mockErr).Build()

			rule, err := GetProductSelectRule("product-error")
			convey.So(rule, convey.ShouldBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})

	t.Run("JSON parsing failure surfaces error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockClient := &goredis.Client{Client: &redis.Client{}}
			stringCmd := &redis.StringCmd{}

			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()
			mockey.Mock(mockey.GetMethod(mockClient, "HGet")).To(func(key, field string) *redis.StringCmd {
				return stringCmd
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return("{invalid-json", error(nil)).Build()

			rule, err := GetProductSelectRule("product-json")
			convey.So(rule, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
		})
	})

	t.Run("Successful selection rule retrieval", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockClient := &goredis.Client{Client: &redis.Client{}}
			stringCmd := &redis.StringCmd{}
			expectedProduct := "product-success"
			jsonStr := `{"Product":"product-success","Display":1}`

			mockey.Mock(redis_client.NewRedisClient).Return(mockClient).Build()
			mockey.Mock(mockey.GetMethod(mockClient, "HGet")).To(func(key, field string) *redis.StringCmd {
				return stringCmd
			}).Build()
			mockey.Mock((*redis.StringCmd).Result).Return(jsonStr, error(nil)).Build()

			rule, err := GetProductSelectRule(expectedProduct)
			convey.So(err, convey.ShouldBeNil)
			convey.So(rule, convey.ShouldNotBeNil)
			convey.So(rule, convey.ShouldHaveSameTypeAs, &trade_client.SelectionRuleData{})
			convey.So(rule.Product, convey.ShouldEqual, expectedProduct)
		})
	})
}

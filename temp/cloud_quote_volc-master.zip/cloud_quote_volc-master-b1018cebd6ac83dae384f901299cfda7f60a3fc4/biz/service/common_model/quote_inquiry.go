package common_model

type QuoteCommonResp struct {
	QuoteID     int64
	QuoteItemID int64
}

package service

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_InsertReq_GetCreator_BitsUTGen(t *testing.T) {
	t.Run("请求来自OpenAPI且成功找到用户", func(t *testing.T) {
		mockey.PatchConvey("请求来自OpenAPI且成功找到用户", t, func() {
			// 准备测试数据
			req := InsertReq{CreatorAccountID: "test_creator_id"}
			mockAccount := &model.Account{AccountID: "test_creator_id", Name: "Test Creator"}
			ctx := context.Background()

			// Mock依赖项
			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(mockAccount, nil).Build()

			// 调用目标函数
			account, err := req.GetCreator(ctx, nil)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(account, convey.ShouldEqual, mockAccount)
		})
	})

	t.Run("请求来自OpenAPI但FindKaniUserWithCache返回错误", func(t *testing.T) {
		mockey.PatchConvey("请求来自OpenAPI但FindKaniUserWithCache返回错误", t, func() {
			req := InsertReq{CreatorAccountID: "test_creator_id"}
			mockErr := errors.New("find user error")
			ctx := context.Background()

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(nil, mockErr).Build()

			account, err := req.GetCreator(ctx, nil)

			convey.So(account, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, mockErr.Error())
			_, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
		})
	})

	t.Run("请求来自OpenAPI但FindKaniUserWithCache返回nil用户", func(t *testing.T) {
		mockey.PatchConvey("请求来自OpenAPI但FindKaniUserWithCache返回nil用户", t, func() {
			req := InsertReq{CreatorAccountID: "test_creator_id"}
			ctx := context.Background()

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(nil, nil).Build()

			account, err := req.GetCreator(ctx, nil)

			convey.So(account, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建人没有填，请传入CreatorAccountID")
			_, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
		})
	})

	t.Run("请求来自报价平台且成功获取当前用户", func(t *testing.T) {
		mockey.PatchConvey("请求来自报价平台且成功获取当前用户", t, func() {
			req := InsertReq{}
			mockCurrentUser := &model.Account{AccountID: "current_user_id", Name: "Current User"}
			ctx := context.Background()

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(mockCurrentUser, nil).Build()

			account, err := req.GetCreator(ctx, (*gorm.DB)(nil))

			convey.So(err, convey.ShouldBeNil)
			convey.So(account, convey.ShouldEqual, mockCurrentUser)
		})
	})

	t.Run("请求来自报价平台但获取当前用户失败", func(t *testing.T) {
		mockey.PatchConvey("请求来自报价平台但获取当前用户失败", t, func() {
			req := InsertReq{}
			mockErr := errors.New("current user not found")
			ctx := context.Background()

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(nil, mockErr).Build()

			account, err := req.GetCreator(ctx, (*gorm.DB)(nil))

			convey.So(account, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})
}

func Test_InsertReq_GetSalesAccountID_BitsUTGen(t *testing.T) {
	t.Run("OpenAPI请求 - 成功获取销售账号ID", func(t *testing.T) {
		mockey.PatchConvey("OpenAPI请求 - 成功获取销售账号ID", t, func() {
			req := InsertReq{CreatorAccountID: "test_creator_id"}
			mockAccount := &model.Account{AccountID: "expected_account_id"}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(mockAccount, nil).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "expected_account_id")
		})
	})

	t.Run("OpenAPI请求 - 查找用户时发生错误", func(t *testing.T) {
		mockey.PatchConvey("OpenAPI请求 - 查找用户时发生错误", t, func() {
			req := InsertReq{CreatorAccountID: "test_creator_id"}
			mockErr := errors.New("database error")

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(nil, mockErr).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database error")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})

	t.Run("OpenAPI请求 - 未找到用户", func(t *testing.T) {
		mockey.PatchConvey("OpenAPI请求 - 未找到用户", t, func() {
			req := InsertReq{CreatorAccountID: "non_existent_id"}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(nil, nil).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建人没有填，请传入CreatorAccountID")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})

	t.Run("平台请求 - 当前用户是销售", func(t *testing.T) {
		mockey.PatchConvey("平台请求 - 当前用户是销售", t, func() {
			req := InsertReq{}
			currentUser := &model.Account{
				AccountID:   "current_sales_id",
				AccountType: constants.AccountTypeUser,
			}

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "current_sales_id")
		})
	})

	t.Run("平台请求 - 获取当前用户失败", func(t *testing.T) {
		mockey.PatchConvey("平台请求 - 获取当前用户失败", t, func() {
			req := InsertReq{}
			mockErr := errors.New("get current user failed")

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(nil, mockErr).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "get current user failed")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})

	t.Run("平台请求 - 当前用户非销售 - 成功获取参数中销售信息", func(t *testing.T) {
		mockey.PatchConvey("平台请求 - 当前用户非销售 - 成功获取参数中销售信息", t, func() {
			req := InsertReq{SalesAccountID: "sales.person@example.com"}
			currentUser := &model.Account{
				AccountID:   "pm_id",
				AccountType: constants.AccountTypePM,
			}
			mockEmployee := &lark_client.Employee{
				Email: "sales.person@example.com",
			}

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
			mockey.Mock(lark_client.GetEmployeeDetailByEmail).Return(mockEmployee, nil).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "sales.person@example.com")
		})
	})

	t.Run("平台请求 - 当前用户非销售 - 获取销售信息时发生错误", func(t *testing.T) {
		mockey.PatchConvey("平台请求 - 当前用户非销售 - 获取销售信息时发生错误", t, func() {
			req := InsertReq{SalesAccountID: "sales.person@example.com"}
			currentUser := &model.Account{
				AccountID:   "pm_id",
				AccountType: constants.AccountTypePM,
			}
			mockErr := errors.New("lark api error")

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
			mockey.Mock(lark_client.GetEmployeeDetailByEmail).Return(nil, mockErr).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), nil)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "lark api error")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})

	t.Run("平台请求 - 当前用户非销售 - 未找到参数中的销售信息", func(t *testing.T) {
		mockey.PatchConvey("平台请求 - 当前用户非销售 - 未找到参数中的销售信息", t, func() {
			req := InsertReq{SalesAccountID: "non_existent_sales@example.com"}
			currentUser := &model.Account{
				AccountID:   "pm_id",
				AccountType: constants.AccountTypePM,
			}

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
			mockey.Mock(lark_client.GetEmployeeDetailByEmail).Return(nil, nil).Build()

			accountID, err := req.GetSalesAccountID(context.Background(), &gorm.DB{})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "销售没有填，请传入SalesAccountID, 使用字节的邮箱")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})
}

func Test_InsertReq_GetSalesAccountIDByScene_BitsUTGen(t *testing.T) {
	t.Run("场景一：来自OpenAPI且为通用配置清单场景，成功获取销售ID", func(t *testing.T) {
		mockey.PatchConvey("场景一：来自OpenAPI且为通用配置清单场景，成功获取销售ID", t, func() {
			ctx := context.WithValue(context.Background(), constants.RequestFrom, constants.RequestFromOpenApi)
			req := InsertReq{
				SalesAccountID: "test.sales@example.com",
			}
			mockAccount := &model.Account{
				AccountID: "final_account_id",
			}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(mockAccount, nil).Build()

			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneConfigurationList, multienv.QuoteTypeNormal)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "final_account_id")
		})
	})

	t.Run("场景二：来自OpenAPI且为项目制报价类型，成功获取销售ID", func(t *testing.T) {
		mockey.PatchConvey("场景二：来自OpenAPI且为项目制报价类型，成功获取销售ID", t, func() {
			ctx := context.WithValue(context.Background(), constants.RequestFrom, constants.RequestFromOpenApi)
			req := InsertReq{
				SalesAccountID: "test.sales@example.com",
			}
			mockAccount := &model.Account{
				AccountID: "final_account_id_project",
			}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(mockAccount, nil).Build()

			// 使用一个不属于通用配置清单的场景
			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneSupplyAgreement, multienv.QuoteTypeProjectBased)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "final_account_id_project")
		})
	})

	t.Run("场景三：来自OpenAPI，但FindKaniUserWithCache查找用户失败", func(t *testing.T) {
		mockey.PatchConvey("场景三：来自OpenAPI，但FindKaniUserWithCache查找用户失败", t, func() {
			ctx := context.WithValue(context.Background(), constants.RequestFrom, constants.RequestFromOpenApi)
			req := InsertReq{
				SalesAccountID: "nonexistent.sales@example.com",
			}
			expectedErr := errors.New("kani user not found")

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(quote_account_service.FindKaniUserWithCache).Return(nil, expectedErr).Build()

			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneConfigurationList, multienv.QuoteTypeNormal)

			convey.So(err, convey.ShouldNotBeNil)
			// 修复：将 "User Not Found" 改为 "UserNotFound" 以匹配错误码
			convey.So(err.Error(), convey.ShouldContainSubstring, "UserNotFound")
			convey.So(err.Error(), convey.ShouldContainSubstring, "kani user not found")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})

	t.Run("场景四：非OpenAPI请求，回退到GetSalesAccountID方法", func(t *testing.T) {
		mockey.PatchConvey("场景四：非OpenAPI请求，回退到GetSalesAccountID方法", t, func() {
			ctx := context.Background()
			req := InsertReq{}

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(InsertReq.GetSalesAccountID).Return("fallback_id", nil).Build()

			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneConfigurationList, multienv.QuoteTypeNormal)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "fallback_id")
		})
	})

	t.Run("场景五：来自OpenAPI但SalesAccountID为空，回退到GetSalesAccountID方法", func(t *testing.T) {
		mockey.PatchConvey("场景五：来自OpenAPI但SalesAccountID为空，回退到GetSalesAccountID方法", t, func() {
			ctx := context.WithValue(context.Background(), constants.RequestFrom, constants.RequestFromOpenApi)
			req := InsertReq{
				SalesAccountID: "",
			}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(InsertReq.GetSalesAccountID).Return("fallback_id_2", nil).Build()

			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneConfigurationList, multienv.QuoteTypeProjectBased)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "fallback_id_2")
		})
	})

	t.Run("场景六：来自OpenAPI但场景和类型不匹配，回退到GetSalesAccountID方法", func(t *testing.T) {
		mockey.PatchConvey("场景六：来自OpenAPI但场景和类型不匹配，回退到GetSalesAccountID方法", t, func() {
			ctx := context.WithValue(context.Background(), constants.RequestFrom, constants.RequestFromOpenApi)
			req := InsertReq{
				SalesAccountID: "test.sales@example.com",
			}

			mockey.Mock(util.RequestFromOpen).Return(true).Build()
			mockey.Mock(InsertReq.GetSalesAccountID).Return("fallback_id_3", nil).Build()

			// 场景和类型均不满足if条件
			accountID, err := req.GetSalesAccountIDByScene(ctx, nil, multienv.SceneSupplyAgreement, multienv.QuoteTypeNormal)

			convey.So(err, convey.ShouldBeNil)
			convey.So(accountID, convey.ShouldEqual, "fallback_id_3")
		})
	})

	t.Run("场景七：回退到GetSalesAccountID方法且该方法返回错误", func(t *testing.T) {
		mockey.PatchConvey("场景七：回退到GetSalesAccountID方法且该方法返回错误", t, func() {
			ctx := context.Background()
			req := InsertReq{}
			expectedErr := errors.New("get sales id error")

			mockey.Mock(util.RequestFromOpen).Return(false).Build()
			mockey.Mock(InsertReq.GetSalesAccountID).Return("", expectedErr).Build()

			accountID, err := req.GetSalesAccountIDByScene(ctx, &gorm.DB{}, multienv.SceneConfigurationList, multienv.QuoteTypeNormal)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "get sales id error")
			convey.So(accountID, convey.ShouldBeEmpty)
		})
	})
}

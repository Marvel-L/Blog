package combine_rule

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
)

type DeleteCombineRuleReq struct {
	RuleIDs []int64
}
type DeleteCombineRuleResp struct {
	DelRuleIDs []int64
}

func (r *DeleteCombineRuleReq) Handle(c context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(c)
	err := dal.CombineRuleDao.SoftDeleteRules(tx, r.RuleIDs)
	if err != nil {
		return nil, err
	}

	return &DeleteCombineRuleResp{
		DelRuleIDs: r.RuleIDs,
	}, nil

}

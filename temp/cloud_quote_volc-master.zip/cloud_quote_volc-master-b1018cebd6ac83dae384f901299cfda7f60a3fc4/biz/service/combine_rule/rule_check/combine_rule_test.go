package rule_check

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"context"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

func backTestCombineRuleCheck(t *testing.T) {
	Init()

	mmap := map[string]interface{}{}
	mmap["ECS_veStack_License_Renew"] = struct{}{}
	mmap["ECS_veStack_Subscription"] = struct{}{}

	//combineRule := &model.CombineRule{
	//	RuleType:             constants.CombineRuleTypeIncludeAll,
	//	TemplateSolutionId:   1,
	//	TradeProduct:         "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS_veStack_License_Renew\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"ECS_veStack_Subscription\"}]",
	//	TradeSolutionName:    "解决方案1",
	//	TradeSolutionVersion: "20222000",
	//}
	productStr := "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS_veStack_License_Renew\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"ECS_veStack_License_Renew\"}]"

	err := AddRuleProductCheck(context.TODO(), productStr, constants.CombineRuleTypeMutex)
	fmt.Println(err)

}
func backTestRuleCanUseCheck(t *testing.T) {
	Init()
	trade_client.Init(&config.Commodity{
		Host:   "b-trade-api.byted.org",
		AppID:  "NWFiM2UxNmU2YWF",
		Secret: "zYyN2NkZWM5ZTYxNGMGI0OTZmZmZj",
	})

	var combineRules []*model.CombineRule

	combineRules = append(combineRules, &model.CombineRule{
		RuleType:     constants.CombineRuleTypeNeedOne,
		TradeProduct: "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"testwsx\"}]",
	})

	combineRules = append(combineRules, &model.CombineRule{
		RuleType:     constants.CombineRuleTypeDepend,
		TradeProduct: "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"testwsx\"}]",
	})

	combineRules = append(combineRules, &model.CombineRule{
		RuleType:     constants.CombineRuleTypeMutex,
		TradeProduct: "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"testwsx\"}]",
	})

	combineRules = append(combineRules, &model.CombineRule{
		RuleType:     constants.CombineRuleTypeIncludeAll,
		TradeProduct: "[{\"zh\":\"云服务器-veStack全栈版-软件更新与支持\",\"en\":\"ECS\"},{\"zh\":\"云服务器-veStack全栈版-私部订阅\",\"en\":\"testwsx\"}]",
	})

	effectiveCombineRules, err := RuleCanUseCheck(context.TODO(), combineRules)
	fmt.Println(err)
	fmt.Println(effectiveCombineRules)

}

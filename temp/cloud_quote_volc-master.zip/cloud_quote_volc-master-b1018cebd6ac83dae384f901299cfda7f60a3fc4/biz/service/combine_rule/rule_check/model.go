package rule_check

type ProductNameModel struct {
	ZhName string `json:"zh"`
	EnName string `json:"en"`
}

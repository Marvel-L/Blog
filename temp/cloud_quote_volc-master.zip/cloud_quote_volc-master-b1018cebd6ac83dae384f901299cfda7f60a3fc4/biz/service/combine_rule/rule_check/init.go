package rule_check

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"context"
	"sync"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

var _checkerMappings = map[constants.CombineRuleType]CombineRuleChecker{}
var once sync.Once

func Init() {

	var err error
	once.Do(func() {

		checkers := getAllCheckers()
		for _, checker := range checkers {
			if err = registerChecker(checker); err != nil {
				panic(err)
			}
		}

	})

}

func getAllCheckers() []CombineRuleChecker {
	var ret []CombineRuleChecker

	ret = append(ret, &NeedOneChecker{})
	ret = append(ret, &DependRuleChecker{})
	ret = append(ret, &MutexRuleChecker{})
	ret = append(ret, &IncludeAllRuleChecker{})

	return ret
}

func registerChecker(checker CombineRuleChecker) error {

	if checker == nil {
		return i18nfmt.NewError(context.Background(), "checker_is_nil")
	}

	if _, exist := _checkerMappings[checker.getRuleType()]; exist {
		return i18nfmt.Errorf(context.Background(), "checker[%d]", checker.getRuleType())
	}

	_checkerMappings[checker.getRuleType()] = checker

	return nil
}

package rule_check

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"
	"encoding/json"
)

type IncludeAllRuleChecker struct {
}

func (c IncludeAllRuleChecker) getRuleType() constants.CombineRuleType {
	return constants.CombineRuleTypeIncludeAll
}

func (c IncludeAllRuleChecker) CheckProduct(ctx context.Context, relatedProductMap map[string]interface{}, combineRule *model.CombineRule) error {
	var products []*ProductNameModel
	err := json.Unmarshal([]byte(combineRule.TradeProduct), &products)
	if err != nil {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误，组合规则ID ：%d", combineRule.Id))
	}
	for _, product := range products {
		if _, ok := relatedProductMap[product.EnName]; !ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "相关商品不满足商品解决方案%s %s 商品组合规则中必选规则", combineRule.TradeSolutionName, combineRule.TradeSolutionVersion))
		}
	}
	return nil
}
func (c IncludeAllRuleChecker) CheckRuleProduct(ctx context.Context, ruleProductStr string) error {
	var products []*ProductNameModel
	err := json.Unmarshal([]byte(ruleProductStr), &products)
	if err != nil {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误 ：%s", ruleProductStr))
	}
	productMap := map[string]interface{}{}
	for _, nameModel := range products {
		productMap[nameModel.EnName] = struct{}{}
	}
	if len(productMap) == 0 {
		return errors.ErrInternalError.WithArgs("未选商品，不允许添加")
	}
	if len(productMap) != len(products) {
		return errors.ErrInternalError.WithArgs("商品重复，不允许添加")
	}

	return nil
}

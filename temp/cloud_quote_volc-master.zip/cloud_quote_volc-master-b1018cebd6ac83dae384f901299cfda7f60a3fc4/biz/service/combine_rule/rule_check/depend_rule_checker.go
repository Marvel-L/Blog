package rule_check

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

type DependRuleChecker struct {
}

func (c DependRuleChecker) getRuleType() constants.CombineRuleType {
	return constants.CombineRuleTypeDepend
}

func (c DependRuleChecker) CheckProduct(ctx context.Context, relatedProductMap map[string]interface{}, combineRule *model.CombineRule) error {
	var products []*ProductNameModel
	err := json.Unmarshal([]byte(combineRule.TradeProduct), &products)
	if err != nil {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误，组合规则ID ：%d", combineRule.Id))
	}

	matchNum := 0
	for _, product := range products {
		if _, ok := relatedProductMap[product.EnName]; ok {
			matchNum++
		}
	}
	if matchNum != 0 && matchNum != len(products) {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "相关商品不满足商品解决方案%s %s 商品组合规则中依赖规则", combineRule.TradeSolutionName, combineRule.TradeSolutionVersion))
	}
	return nil
}

func (c DependRuleChecker) CheckRuleProduct(ctx context.Context, ruleProductStr string) error {
	var products []*ProductNameModel
	err := json.Unmarshal([]byte(ruleProductStr), &products)
	if err != nil {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误 ：%s", ruleProductStr))
	}
	productMap := map[string]interface{}{}
	for _, nameModel := range products {
		productMap[nameModel.EnName] = struct{}{}
	}
	if len(productMap) != len(products) {
		return errors.ErrInternalError.WithArgs("商品重复，不允许添加")
	}
	if len(products) < 2 {
		return errors.ErrInternalError.WithArgs("依赖规则至少需要选择两个商品")
	}

	return nil
}

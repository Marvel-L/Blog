package rule_check

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"context"
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

type CombineRuleChecker interface {
	//getRuleType 获取组合规则类型
	getRuleType() constants.CombineRuleType
	//CheckProduct 查相关商品是否符合商品组合规则
	CheckProduct(ctx context.Context, relatedProductMap map[string]interface{}, combineRule *model.CombineRule) error
	//CheckRuleProduct 检查商品信息字符串是否允许被设置入当前类型组合规则
	CheckRuleProduct(ctx context.Context, ruleProductStr string) error
}

// CheckRelatedProduct 检查相关商品是否符合商品组合规则
func CheckRelatedProduct(ctx context.Context, relatedProductMap map[string]interface{}, combineRules []*model.CombineRule) error {

	for _, combineRule := range combineRules {
		checker, ok := _checkerMappings[combineRule.RuleType]
		if !ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则检查器不存在,类型 %d", combineRule.RuleType))
		}
		err := checker.CheckProduct(ctx, relatedProductMap, combineRule)
		if err != nil {
			return err
		}
	}
	return nil
}

// AddRuleProductCheck 检查商品信息字符串是否允许被设置入当前类型组合规则
func AddRuleProductCheck(ctx context.Context, ruleProductStr string, ruleType constants.CombineRuleType) error {

	checker, ok := _checkerMappings[ruleType]
	if !ok {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则检查器不存在,类型 %d", ruleType))
	}
	return checker.CheckRuleProduct(ctx, ruleProductStr)
}

// RuleCanUseCheck 检查当前组合规则是否可以继续使用
func RuleCanUseCheck(ctx context.Context, combineRules []*model.CombineRule) ([]*model.CombineRule, error) {
	effectiveProductMap, err := getEffectiveProductMap(ctx, combineRules)
	if err != nil {
		return nil, err
	}
	var effectiveCombineRules []*model.CombineRule
	for _, combineRule := range combineRules {
		checker, ok := _checkerMappings[combineRule.RuleType]
		if !ok {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则检查器不存在,类型 %d", combineRule.RuleType))
		}

		var products []*ProductNameModel
		err = json.Unmarshal([]byte(combineRule.TradeProduct), &products)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误 ：%s", combineRule.TradeProduct))
		}
		var effectiveProducts []*ProductNameModel
		for _, ruleProduct := range products {
			if _, productEffective := effectiveProductMap[ruleProduct.EnName]; productEffective {
				effectiveProducts = append(effectiveProducts, ruleProduct)
			}
		}
		effectiveProductStr := util.GetJsonStr(effectiveProducts)
		if err = checker.CheckRuleProduct(ctx, effectiveProductStr); err == nil {
			combineRule.TradeProduct = effectiveProductStr
			effectiveCombineRules = append(effectiveCombineRules, combineRule)
		} else {
			logs.CtxInfo(ctx, "combineRule product not effective [original product] %s ,[effective product] %s", combineRule.TradeProduct, effectiveProductStr)
		}
	}
	return effectiveCombineRules, nil
}

func getEffectiveProductMap(ctx context.Context, combineRules []*model.CombineRule) (map[string]*trade_client.TradeProductVersionInfo, error) {
	originalProductMap := map[string]interface{}{}
	for _, combineRule := range combineRules {
		var products []*ProductNameModel
		err := json.Unmarshal([]byte(combineRule.TradeProduct), &products)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "商品组合规则解析错误 ：%s", combineRule.TradeProduct))
		}
		for _, productNameModel := range products {
			originalProductMap[productNameModel.EnName] = struct{}{}
		}
	}
	var productArr []string
	for productEnName := range originalProductMap {
		productArr = append(productArr, productEnName)
	}
	return commodity_service.GetTradeProductByArray(ctx, productArr, true)
}

package combine_rule

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/combine_rule/rule_check"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

type AddCombineRuleReq struct {
	Rules []*RuleModel
}

type RuleModel struct {
	RuleID               int64
	RuleType             constants.CombineRuleType
	TemplateSolutionId   int64
	TradeProduct         string
	TradeSolutionName    string
	TradeSolutionVersion string
}

func (r *AddCombineRuleReq) Handle(c context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(c)

	tplSolutionIDMap := make(map[int64]struct{})
	for _, rule := range r.Rules {
		_, ok := constants.CombineRuleTypeMapping[rule.RuleType]
		if !ok {
			return nil, errors.ErrCustomerError.WithArgs("商品组合规则类型错误，请确认")
		}

		tplSolutionIDMap[rule.TemplateSolutionId] = struct{}{}
	}
	var tplSolutionIDs []int64
	for tplSolutionID, _ := range tplSolutionIDMap {
		tplSolutionIDs = append(tplSolutionIDs, tplSolutionID)
	}

	solution, err := dal.TemplateSolutionDao.FindTplSolutionByIDs(tx, tplSolutionIDs)
	if err != nil {
		return nil, err
	}

	if len(solution) != len(tplSolutionIDs) {
		return nil, errors.ErrCustomerError.WithArgs("部分解决方案不存在，请确认解决方案是否有效")
	}

	var rules []*model.CombineRule
	currentUser, err := dal.AccountDao.CurrentUser(c)
	if err != nil {
		return nil, err
	}
	for _, rule := range r.Rules {
		err = rule_check.AddRuleProductCheck(c, rule.TradeProduct, rule.RuleType)
		if err != nil {
			return nil, err
		}
		combineRule := &model.CombineRule{
			RuleType:             rule.RuleType,
			TemplateSolutionId:   rule.TemplateSolutionId,
			TradeProduct:         rule.TradeProduct,
			TradeSolutionName:    rule.TradeSolutionName,
			TradeSolutionVersion: rule.TradeSolutionVersion,
			CreatorAccountId:     currentUser.AccountID,
		}
		combineRule.Id = rule.RuleID
		rules = append(rules, combineRule)
	}

	err = dal.CombineRuleDao.Save(tx, rules, &model.CombineRule{})
	if err != nil {
		return nil, err
	}
	return rules, nil
}

package combine_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type ListCombineRuleReq struct {
	framework.Pagination
	TemplateSolutionID int64
	TemplateID         int64
	QuoteID            int64
}

type ListCombineRuleResp struct {
	framework.Pagination
	List []*CombineRuleDisplay
}

type CombineRuleDisplay struct {
	Id                   int64
	RuleType             constants.CombineRuleType
	TemplateSolutionId   int64
	TradeProduct         string
	TradeSolution        string
	TradeSolutionName    string
	TradeSolutionVersion string
}

func (r *ListCombineRuleReq) Handle(c context.Context) (interface{}, error) {
	tx := dal.DBProxy.NewRequest(c)
	var tplSolutionIDs []int64
	if r.TemplateID > 0 {
		tplSolutions, err := dal.TemplateSolutionDao.FindTplSolution(tx, []int64{r.TemplateID})
		if err != nil {
			return nil, err
		}
		for _, tplSolution := range tplSolutions {
			tplSolutionIDs = append(tplSolutionIDs, tplSolution.Id)
		}

	} else if r.QuoteID > 0 {
		quoteItems, err := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, r.QuoteID, constants.ItemStatusNormal, multienv.TradeProductTypeAll, constants.ItemSceneQuoteItem)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(err)
		}
		quoteSolutionMap := map[int64]interface{}{}
		for _, quoteItem := range quoteItems {
			if quoteItem.QuoteSolutionID > 0 {
				quoteSolutionMap[quoteItem.QuoteSolutionID] = struct{}{}
			}
		}
		var quoteSolutionIDs []int64
		for quoteSolutionID, _ := range quoteSolutionMap {
			quoteSolutionIDs = append(quoteSolutionIDs, quoteSolutionID)
		}
		quoteSolutions, err := dal.QuoteSolutionDao.FindQuoteSolutionByIDs(tx, quoteSolutionIDs)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(err)
		}
		for _, quoteSolution := range quoteSolutions {
			tplSolutionIDs = append(tplSolutionIDs, quoteSolution.TemplateSolutionId)
		}
	}
	var list []*CombineRuleDisplay
	if len(tplSolutionIDs) == 0 {
		return &ListCombineRuleResp{
			Pagination: r.Pagination,
			List:       list,
		}, nil
	}
	condition, _ := r.getCondition(tplSolutionIDs)
	ruleList, total, err := dal.CombineRuleDao.FindRulesByConditions(tx, condition, r.Limit, r.Offset)
	if err != nil {
		return nil, err
	}
	r.Pagination.Total = total

	for _, rule := range ruleList {
		tplSolutionIDs = append(tplSolutionIDs, rule.TemplateSolutionId)
	}
	solutionMap, err := dal.TemplateSolutionDao.FindTplSolutionMapByIDs(tx, tplSolutionIDs)

	for _, combineRule := range ruleList {
		tplSolution, ok := solutionMap[combineRule.TemplateSolutionId]

		var tradeSolution string
		if ok {
			tradeSolution = tplSolution.TradeSolution
		}

		list = append(list, &CombineRuleDisplay{
			Id:                   combineRule.Id,
			RuleType:             combineRule.RuleType,
			TemplateSolutionId:   combineRule.TemplateSolutionId,
			TradeProduct:         combineRule.TradeProduct,
			TradeSolution:        tradeSolution,
			TradeSolutionName:    combineRule.TradeSolutionName,
			TradeSolutionVersion: combineRule.TradeSolutionVersion,
		})
	}

	return &ListCombineRuleResp{
		Pagination: r.Pagination,
		List:       list,
	}, nil

}

func (r *ListCombineRuleReq) getCondition(tplSolutionIDs []int64) (framework.Condition, error) {
	condition := framework.Condition{}
	if r.TemplateSolutionID > 0 {
		condition["template_solution_id"] = r.TemplateSolutionID
	}
	if len(tplSolutionIDs) > 0 {
		condition["template_solution_id"] = tplSolutionIDs
	}
	condition["status"] = 0
	return condition, nil
}

package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

type callerConfigList struct {
}

func (c callerConfigList) dependKeys() []CallbackKey {
	return []CallbackKey{CallbackKeyQuote}
}

func (c callerConfigList) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	if container.Quote == nil {
		logs.CtxWarn(ctx, "[callerConfigList] quote is nil")
		return nil
	}
	quoteCreateFrom := container.Quote.QuoteCreateFrom
	if quoteCreateFrom == 0 {
		logs.CtxInfo(ctx, "[callerConfigList] QuoteCreateFrom is zero")
		return nil
	}
	configList, err := dal.QuoteDao.FindQuoteByID(tx, quoteCreateFrom)
	if dal.IsExceptionError(err) {
		logs.CtxError(ctx, "[callerConfigList] FindQuoteByIDFail, quoteID=%d, err=%s", quoteCreateFrom, err.Error())
		return errors.ErrCustomerError.WithArgs("查询报项目制报价单配置清单失败")

	}
	container.ConfigList = configList
	return nil
}

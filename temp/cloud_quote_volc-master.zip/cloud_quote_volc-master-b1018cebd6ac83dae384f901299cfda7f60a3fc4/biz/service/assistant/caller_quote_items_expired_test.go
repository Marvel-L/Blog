package assistant

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_callerQuoteItemsExpired_Callback_BitsUTGen(t *testing.T) {
	t.Run("quote id is zero returns customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			c := callerQuoteItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 0}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单号为空")
			convey.So(container.AllQuoteItemsExpired, convey.ShouldBeNil)
		})
	})

	t.Run("dao error returns wrapped customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByStatus")).Return(
				([]*model.QuoteItem)(nil), stderrors.New("query failed"),
			).Build()

			c := callerQuoteItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 2001}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询失效报价项列表失败")
			convey.So(container.AllQuoteItemsExpired, convey.ShouldBeNil)
		})
	})

	t.Run("success populates expired quote items", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			items := []*model.QuoteItem{
				{QuoteID: 2002},
				{QuoteID: 2002},
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByStatus")).Return(items, nil).Build()

			c := callerQuoteItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 2002}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldBeNil)
			convey.So(container.AllQuoteItemsExpired, convey.ShouldResemble, items)
		})
	})
}

package assistant

import (
	"context"
	stdErrors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_callerProductInfo_Callback_BitsUTGen(t *testing.T) {
	t.Run("ReturnNilWhenNoItems", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			handler := callerProductInfo{}
			container := &CallbackInfo{}
			apiErr := handler.Callback(ctx, nil, nil, container)
			convey.So(apiErr, convey.ShouldBeNil)
			convey.So(container.ProductInfos, convey.ShouldBeNil)
		})
	})
	t.Run("ReturnErrorWhenServiceFails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			handler := callerProductInfo{}
			container := &CallbackInfo{
				AllQuoteItems: []*model.QuoteItem{
					{TradeProduct: "tp-error"},
				},
			}
			mockey.MockUnsafe(commodity_service.GetTradeProductByArray).Return(nil, stdErrors.New("service failure")).Build()
			apiErr := handler.Callback(ctx, nil, nil, container)
			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(container.ProductInfos, convey.ShouldBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "查询商品信息失败")
		})
	})
	t.Run("PopulateProductInfosOnSuccess", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			handler := callerProductInfo{}
			container := &CallbackInfo{
				AllQuoteItems: []*model.QuoteItem{
					{TradeProduct: "tp-success"},
				},
			}
			expectedMap := map[string]*trade_client.TradeProductVersionInfo{
				"tp-success": {
					TradeProduct:     "tp-success",
					TradeProductName: "Product Success",
				},
			}
			mockey.MockUnsafe(commodity_service.GetTradeProductByArray).Return(expectedMap, nil).Build()
			apiErr := handler.Callback(ctx, nil, nil, container)
			convey.So(apiErr, convey.ShouldBeNil)
			convey.So(container.ProductInfos, convey.ShouldResemble, expectedMap)
		})
	})
}

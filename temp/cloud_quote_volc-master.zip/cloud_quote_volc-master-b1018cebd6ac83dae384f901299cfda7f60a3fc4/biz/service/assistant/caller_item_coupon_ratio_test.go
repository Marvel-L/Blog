package assistant

import (
	"context"
	errors "errors"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_callerItemCouponRatio_Callback_BitsUTGen(t *testing.T) {
	t.Run("QuoteID is zero returns customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := callerItemCouponRatio{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 0}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), nil, cbCtx, container)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(fmt.Sprint(apiErr.GetArgs()), convey.ShouldContainSubstring, "quoteID is empty")
		})
	})

	t.Run("DAO returns error propagates customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Ensure the global DAO variable is initialized and method is mocked.
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteItemCouponRatioDao, "FindByQuoteID")).Return(
				([]*model.QuoteItemCouponRatio)(nil), errors.New("db access error"),
			).Build()

			c := callerItemCouponRatio{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 12345}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(fmt.Sprint(apiErr.GetArgs()), convey.ShouldContainSubstring, "db access error")
		})
	})

	t.Run("Successful fetch sets container list and returns nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			list := []*model.QuoteItemCouponRatio{
				{QuoteID: 777, QuoteItemID: 888},
			}
			mockey.MockUnsafe(mockey.GetMethod(dal.QuoteItemCouponRatioDao, "FindByQuoteID")).Return(
				list, nil,
			).Build()

			c := callerItemCouponRatio{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 777}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(apiErr, convey.ShouldBeNil)
			convey.So(container.QuoteItemCouponRatioList, convey.ShouldNotBeNil)
			convey.So(len(container.QuoteItemCouponRatioList), convey.ShouldEqual, 1)
			convey.So(container.QuoteItemCouponRatioList[0].QuoteID, convey.ShouldEqual, 777)
			convey.So(container.QuoteItemCouponRatioList[0].QuoteItemID, convey.ShouldEqual, 888)
		})
	})
}

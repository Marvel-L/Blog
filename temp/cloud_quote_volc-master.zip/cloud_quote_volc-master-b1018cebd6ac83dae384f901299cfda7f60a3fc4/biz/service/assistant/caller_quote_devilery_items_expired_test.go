package assistant

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_callerQuoteDeliveryItemsExpired_Callback_BitsUTGen(t *testing.T) {
	t.Run("quote id is zero returns customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			c := callerQuoteDeliveryItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 0}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单号为空")
			convey.So(container.AllDeliveryItemsExpired, convey.ShouldBeNil)
		})
	})

	t.Run("dao error returns wrapped customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByStatus")).Return(
				([]*model.QuoteItem)(nil), stderrors.New("query failed"),
			).Build()

			c := callerQuoteDeliveryItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 1001}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询失效交付项列表失败")
			convey.So(container.AllDeliveryItemsExpired, convey.ShouldBeNil)
		})
	})

	t.Run("success populates expired delivery items", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			items := []*model.QuoteItem{
				{QuoteID: 1002},
				{QuoteID: 1002},
			}
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByStatus")).Return(items, nil).Build()

			c := callerQuoteDeliveryItemsExpired{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 1002}}
			container := &CallbackInfo{}

			err := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(err, convey.ShouldBeNil)
			convey.So(container.AllDeliveryItemsExpired, convey.ShouldResemble, items)
		})
	})
}

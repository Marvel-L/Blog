package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

type callerQuoteContract struct {
}

func (c callerQuoteContract) dependKeys() []CallbackKey {
	return nil
}

func (c callerQuoteContract) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteContract]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	contract, err := dal.QuoteContractDao.FindQuoteContractByQuoteID(tx, quoteID)
	if dal.IsExceptionError(err) {
		logs.CtxError(ctx, "[callerQuoteContract]FindQuoteContractByQuoteIDFail, quoteID=%d, err=%s", quoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询关联合同失败")
	}

	if contract != nil {
		container.QuoteContract = contract
	}

	return nil
}

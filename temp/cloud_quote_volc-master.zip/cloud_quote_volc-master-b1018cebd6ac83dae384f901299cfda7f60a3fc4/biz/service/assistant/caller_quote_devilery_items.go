package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteDeliveryItems struct {
}

func (c callerQuoteDeliveryItems) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerQuoteDeliveryItems) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteItems]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	allItems, err := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, quoteID, constants.ItemStatusNormal, multienv.TradeProductTypeAll, constants.ItemSceneDeliveryItem)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询交付项列表失败")
	}
	container.AllDeliveryItems = allItems
	return nil
}

package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteResourcePage struct {
}

// dependKeys 依赖
func (c callerQuoteResourcePage) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

// Callback 数据召回
func (c callerQuoteResourcePage) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteResourcePage]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	resourcePage, err := dal.QuoteResourcePageDao.FindPageByQuoteID(tx, quoteID)
	if dal.IsExceptionError(err) {
		return errors.ErrCustomerError.WithArgs(err.Error())
	}
	if resourcePage.Id > 0 {
		container.ResourcePage = resourcePage
	}
	return nil
}

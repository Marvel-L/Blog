package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

type callerCoupon struct {
}

func (c callerCoupon) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerCoupon) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerCoupon]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	items, err := dal.CommonApplyItemDao.FindApplyItem(tx, quoteID, multienv.ApplyBizKeyCoupon)
	if err != nil {
		logs.CtxError(ctx, "[callerCoupon]FindApplyItem, quoteID=%d, err=%s", quoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询代金券配置信息失败")
	}
	if len(items) == 0 {
		return nil
	}

	var ids []int64
	for _, item := range items {
		ids = append(ids, item.ConfigID)
	}

	list, err := dal.ExtraConfigCouponDao.FindByIdList(ctx, tx, ids)
	if err != nil {
		logs.CtxError(ctx, "[callerCoupon]ExtraConfigCouponDao_FindByIdList, ids=%v, err=%s", ids, err.Error())
		return errors.ErrCustomerError.WithArgs("查询代金券配置信息失败")
	}
	container.CouponList = list

	return nil
}

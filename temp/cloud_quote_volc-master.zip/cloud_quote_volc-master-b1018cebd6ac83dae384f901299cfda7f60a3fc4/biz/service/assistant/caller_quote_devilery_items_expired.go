package assistant

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type callerQuoteDeliveryItemsExpired struct {
}

func (c callerQuoteDeliveryItemsExpired) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerQuoteDeliveryItemsExpired) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteDeliveryItemsExpired]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	allItems, err := dal.QuoteItemDao.FindQuoteItemsByStatus(
		tx,
		quoteID,
		[]int{constants.DataInvalidStatus},
		constants.ItemStatusAll,
		multienv.TradeProductTypeAll,
		constants.ItemSceneDeliveryItem,
	)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询失效交付项列表失败")
	}
	container.AllDeliveryItemsExpired = allItems
	return nil
}

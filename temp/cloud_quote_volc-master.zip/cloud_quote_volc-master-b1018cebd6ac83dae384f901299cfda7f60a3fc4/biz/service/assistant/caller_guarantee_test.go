package assistant

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_callerGuarantee_Callback_BitsUTGen(t *testing.T) {
	t.Run("QuoteID is zero returns customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := callerGuarantee{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 0}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), nil, cbCtx, container)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(fmt.Sprint(apiErr.GetArgs()), convey.ShouldContainSubstring, "报价单号为空")
			convey.So(container.GuaranteeItems, convey.ShouldBeNil)
		})
	})

	t.Run("DAO exception returns customer error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return(
				([]*model.GuaranteeItem)(nil), errors.New("db access error"),
			).Build()

			c := callerGuarantee{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 12345}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(fmt.Sprint(apiErr.GetArgs()), convey.ShouldContainSubstring, "查询保底信息失败")
			convey.So(container.GuaranteeItems, convey.ShouldBeNil)
		})
	})

	t.Run("Empty result keeps guarantee items unset", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return(
				([]*model.GuaranteeItem)(nil), nil,
			).Build()

			c := callerGuarantee{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 67890}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(apiErr, convey.ShouldBeNil)
			convey.So(container.GuaranteeItems, convey.ShouldBeNil)
		})
	})

	t.Run("Successful fetch stores all guarantee items", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			items := []*model.GuaranteeItem{
				{QuoteID: 777, RootGuaranteeID: 11},
				{QuoteID: 777, RootGuaranteeID: 22},
			}
			mockey.MockUnsafe(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return(
				items, nil,
			).Build()

			c := callerGuarantee{}
			cbCtx := &CallbackContext{Param: Param{QuoteID: 777}}
			container := &CallbackInfo{}

			apiErr := c.Callback(context.Background(), &gorm.DB{}, cbCtx, container)

			convey.So(apiErr, convey.ShouldBeNil)
			convey.So(container.GuaranteeItems, convey.ShouldResemble, items)
			convey.So(len(container.GuaranteeItems), convey.ShouldEqual, 2)
			convey.So(container.GuaranteeItems[0].RootGuaranteeID, convey.ShouldEqual, int64(11))
			convey.So(container.GuaranteeItems[1].RootGuaranteeID, convey.ShouldEqual, int64(22))
		})
	})
}

package assistant

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type callerConfigRelatedQuote struct {
}

func (c callerConfigRelatedQuote) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerConfigRelatedQuote) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerConfigRelatedQuote]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	relatedQuotes, err := dal.QuoteDao.FindQuoteByConfigListQuoteID(tx, quoteID)
	if dal.IsExceptionError(err) {
		return errors.ErrCustomerError.WithArgs(err.Error())
	}

	container.ConfigRelatedQuote = relatedQuotes

	return nil
}

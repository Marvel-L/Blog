package assistant

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/gopkg/context"
)

func Test_CallbackWithQuote(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(doCallback).Return(nil).Build()

			// Act
			callbackInfo, err := CallbackWithQuote(context.Background(), &gorm.DB{}, &model.Quote{},
				WithCallbackInfoKeys(
					[]CallbackKey{
						CallbackKeyQuoteItems, // 报价项
					},
				),
			)

			// Assert
			convey.So(callbackInfo, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

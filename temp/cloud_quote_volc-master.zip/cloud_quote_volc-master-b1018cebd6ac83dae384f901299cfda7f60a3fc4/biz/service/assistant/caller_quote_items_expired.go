package assistant

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type callerQuoteItemsExpired struct {
}

func (c callerQuoteItemsExpired) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerQuoteItemsExpired) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteItemsExpired]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	allItems, err := dal.QuoteItemDao.FindQuoteItemsByStatus(
		tx,
		quoteID,
		[]int{constants.DataInvalidStatus},
		constants.ItemStatusAll,
		multienv.TradeProductTypeAll,
		constants.ItemSceneQuoteItem,
	)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询失效报价项列表失败")
	}
	container.AllQuoteItemsExpired = allItems
	return nil
}

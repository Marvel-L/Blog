package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteItemsAllStatus struct {
}

// dependKeys 依赖
func (c callerQuoteItemsAllStatus) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

// Callback 数据召回
func (c callerQuoteItemsAllStatus) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteItems]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	allItems, err := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, quoteID, constants.ItemStatusAll, multienv.TradeProductTypeAll, constants.ItemSceneQuoteItem)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询报价项列表失败")
	}
	container.AllQuoteItems = allItems
	return nil
}

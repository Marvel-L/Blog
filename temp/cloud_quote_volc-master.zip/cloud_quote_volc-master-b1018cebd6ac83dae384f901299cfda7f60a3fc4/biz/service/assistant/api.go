package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

/**
 * 报价单助手 一些复杂、可复用逻辑封装
 */

type caller interface {
	dependKeys() []CallbackKey // 前置依赖
	Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError
}

type CallbackContext struct {
	calledKeys       map[CallbackKey]bool //
	Param            Param                //
	CallbackInfoKeys []CallbackKey        // 要查询的信息Key，建议按逻辑顺序调整
}

type Param struct {
	QuoteID int64 // 报价单ID
}

// CallbackInfo 报价单相关汇总数据
type CallbackInfo struct {
	Quote                    *model.Quote                                     // 报价单信息
	OriginQuote              *model.Quote                                     // 原始报价单信息
	AllQuoteSolutions        []*model.QuoteSolution                           // 报价单解决方案列表
	AllQuoteItems            []*model.QuoteItem                               // 报价项列表
	AllQuoteItemsExpired     []*model.QuoteItem                               // 失效报价项列表
	AllDeliveryItems         []*model.QuoteItem                               // 交付项列表
	AllDeliveryItemsExpired  []*model.QuoteItem                               // 失效交付项列表
	AllItemValues            map[int64][]*model.QuoteItemValue                // 全量属性map，key=ItemID
	AllItemCalMap            map[int64]*model.QuoteItemCalculate              // 报价项利润率map，key=ItemID
	BelongingDepartmentList  []string                                         // 一级产品线
	BizLineNameList          []string                                         // 二级产品线
	BizLineQuoteItemMapping  map[string]map[int64]bool                        // 二级产品线=报价项ID映射
	QuoteItemBizLineMapping  map[int64]string                                 // 报价项ID=二级产品线映射
	CouponList               model.CouponConfigDBList                         // 代金券配置列表
	CreditList               model.ExtraConfigCreditDBList                    // 信控配置列表
	RebateItemList           model.RebateItemList                             // 返佣列表
	GuaranteeItems           []*model.GuaranteeItem                           // 保底规则列表，单保底场景长度为 1
	ResourcePage             *model.QuoteResourcePage                         // 资源单
	QuoteResourceItems       model.QuoteResourceItems                         // 资源卡
	RelatedSupplyQuotes      []*model.Quote                                   // 补充报价单
	QuoteContract            *model.QuoteContract                             // 报价单关联合同
	ConfigRelatedQuote       []*model.Quote                                   // 配置清单关联报价单列表
	ConfigList               *model.Quote                                     // 项目制报价单配置清单信息
	ProductInfos             map[string]*trade_client.TradeProductVersionInfo // 商品信息列表
	QuoteItemCouponRatioList []*model.QuoteItemCouponRatio                    // 报价项返券比例列表
}

func (c *CallbackInfo) GetAllItems() []*model.QuoteItem {
	var allItems []*model.QuoteItem
	if len(c.AllQuoteItems) > 0 {
		allItems = append(allItems, c.AllQuoteItems...)
	}
	if len(c.AllDeliveryItems) > 0 {
		allItems = append(allItems, c.AllDeliveryItems...)
	}
	return allItems
}

func (c *CallbackInfo) GetQuoteItemMap() map[int64]*model.QuoteItem {
	quoteItemMap := map[int64]*model.QuoteItem{}
	for _, quoteItem := range c.GetAllItems() {
		quoteItemMap[quoteItem.Id] = quoteItem
	}
	return quoteItemMap
}

func (c *CallbackInfo) GetRebateItemMap() map[int64]*model.RebateItem {
	rebateMap := map[int64]*model.RebateItem{}
	for _, rebateItem := range c.RebateItemList {
		rebateMap[rebateItem.QuoteItemID] = rebateItem
	}
	return rebateMap
}

func (c *CallbackInfo) GetQuoteSolutionMap() map[int64]*model.QuoteSolution {
	quoteSolutionMap := map[int64]*model.QuoteSolution{}
	for _, quoteSolution := range c.AllQuoteSolutions {
		quoteSolutionMap[quoteSolution.Id] = quoteSolution
	}
	return quoteSolutionMap
}

func (c *CallbackInfo) GetCouponConfigMap() map[int64]*model.CouponConfigDB {
	couponConfigMap := map[int64]*model.CouponConfigDB{}
	for _, couponConfig := range c.CouponList {
		couponConfigMap[couponConfig.Id] = couponConfig
	}
	return couponConfigMap
}

func Callback(ctx context.Context, tx *gorm.DB, quoteID int64, opts ...CallbackOption) (*CallbackInfo, errors.APIError) {

	var (
		info = &CallbackInfo{}
		err  errors.APIError
	)

	// 调用方未指定tx时，认为不需要单独开启事务，独立创建tx
	if tx == nil {
		tx = dal.DBProxy.NewRequest(ctx)
	}

	cbCtx := &CallbackContext{
		calledKeys: map[CallbackKey]bool{},
		Param: Param{
			QuoteID: quoteID,
		},
		CallbackInfoKeys: []CallbackKey{
			CallbackKeyQuote, // 默认返回报价单实体信息
		},
	}

	for _, opt := range opts {
		opt.F(cbCtx)
	}

	for _, key := range cbCtx.CallbackInfoKeys {
		if err = doCallback(ctx, tx, cbCtx, info, key); err != nil {
			logs.CtxError(ctx, "[Callback]doCallbackFail, key=%s, err=%s", key, err.Error())
			return info, err
		}
	}

	return info, nil
}

func CallbackWithQuote(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote, opts ...CallbackOption) (*CallbackInfo, errors.APIError) {

	var (
		info = &CallbackInfo{}
		err  errors.APIError
	)

	// 调用方未指定tx时，认为不需要单独开启事务，独立创建tx
	if tx == nil {
		tx = dal.DBProxy.NewRequest(ctx)
	}

	cbCtx := &CallbackContext{
		calledKeys: map[CallbackKey]bool{},
		Param: Param{
			QuoteID: quoteDB.Id,
		},
		CallbackInfoKeys: []CallbackKey{},
	}

	// 默认返回入参报价单实体信息
	info.Quote = quoteDB

	for _, opt := range opts {
		opt.F(cbCtx)
	}

	for _, key := range cbCtx.CallbackInfoKeys {
		if err = doCallback(ctx, tx, cbCtx, info, key); err != nil {
			logs.CtxError(ctx, "[Callback]doCallbackFail, key=%s, err=%s", key, err.Error())
			return info, err
		}
	}

	return info, nil
}

func doCallback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, info *CallbackInfo, key CallbackKey) errors.APIError {

	// 避免循环、重复调用
	if cbCtx.calledKeys[key] {
		return nil
	}

	c := callerMap[key]
	if c == nil {
		argosnotifylogs.CtxError(ctx, "[assistant.Summary]match callback key fail, key=%s", key)
		return errors.ErrCustomerError.WithArgs("内部错误")
	}

	for _, pre := range c.dependKeys() {
		if err := doCallback(ctx, tx, cbCtx, info, pre); err != nil {
			return err
		}
	}

	if err := c.Callback(ctx, tx, cbCtx, info); err != nil {
		logs.CtxError(ctx, "[assistant.Summary]Callback Fail, key=%s, err=%s", key, err.Error())
		return err
	}

	cbCtx.calledKeys[key] = true
	return nil
}

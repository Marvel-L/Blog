package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

// 报价单信息
type callerQuote struct {
}

func (c callerQuote) dependKeys() []CallbackKey {
	return nil
}

func (c callerQuote) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {

	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuote]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	quoteDB, err := dal.QuoteDao.FindQuoteByID(tx, quoteID)
	if err != nil {
		logs.CtxError(ctx, "[assistant.Summary]FindQuoteByIDFail, quoteID=%d, err=%s", quoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询报价单信息失败")
	}
	if quoteDB == nil {
		logs.CtxError(ctx, "[assistant.Summary]FindQuoteByID_NotFound, quoteID=%d, err=%s", quoteID)
		return errors.ErrCustomerError.WithArgs("查询报价单信息失败")
	}

	container.Quote = quoteDB

	return nil
}

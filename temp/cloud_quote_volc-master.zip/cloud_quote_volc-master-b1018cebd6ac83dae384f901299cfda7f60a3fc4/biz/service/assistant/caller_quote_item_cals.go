package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteItemCals struct {
}

func (c callerQuoteItemCals) dependKeys() []CallbackKey {
	return nil
}

func (c callerQuoteItemCals) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteItemCals]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	cals, err := dal.QuoteItemCalculateDao.QuoteItemCalsByQuoteID(tx, quoteID)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询报价项利润率信息失败")
	}
	calMap := map[int64]*model.QuoteItemCalculate{}
	for _, cal := range cals {
		calMap[cal.QuoteItemID] = cal
	}
	container.AllItemCalMap = calMap
	return nil
}

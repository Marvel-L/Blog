package assistant

var callerMap = map[CallbackKey]caller{
	CallbackKeyQuote:                callerQuote{},                     // 报价单
	CallbackKeyOriginQuote:          callerOriginQuote{},               // 原始报价单
	CallbackKeyQuoteSolutions:       callerQuoteSolutions{},            // 报价单解决方案
	CallbackKeyQuoteItems:           callerQuoteItems{},                // 报价项
	CallbackKeyQuoteItemsExpired:    callerQuoteItemsExpired{},         // 失效报价项
	CallbackKeyQuoteItemsAllStatus:  callerQuoteItemsAllStatus{},       // 报价项，所有状态（包含草稿）
	CallbackKeyDeliveryItems:        callerQuoteDeliveryItems{},        // 交付项
	CallbackKeyDeliveryItemsExpired: callerQuoteDeliveryItemsExpired{}, // 失效交付项
	CallbackKeyItemValues:           callerQuoteItemValues{},           // 属性列表
	CallbackKeyItemCalculates:       callerQuoteItemCals{},             // 试算信息
	CallbackKeyBizLine:              callerBizLine{},                   // 产品线
	CallbackKeyApplyCouponItems:     callerCoupon{},                    // 代金券
	CallbackKeyApplyCreditItems:     callerCredit{},                    // 信控
	CallbackKeyRebate:               callerRebate{},                    // 返佣
	CallbackKeyGuaranteeItem:        callerGuarantee{},                 // 保底列表
	CallbackKeyResourcePage:         callerQuoteResourcePage{},         // 资源单
	CallbackKeyResourceItems:        callerQuoteResourceItems{},        // 资源卡
	CallbackKeySupplyAgreement:      callerQuoteSupplyAgreement{},      // 补充协议列表
	CallbackKeyQuoteContract:        callerQuoteContract{},             // 报价单关联合同
	CallbackKeyConfigRelatedQuote:   callerConfigRelatedQuote{},        // 配置清单关联报价单列表
	CallbackKeyConfigList:           callerConfigList{},                // 项目制报价单关联的配置清单
	CallbackKeyAllRebateData:        callerAllRebateData{},             // 返佣记录信息
	CallbackKeyProductInfo:          callerProductInfo{},               // 报价项&交付项商品信息
	CallbackKeyItemCouponRatio:      callerItemCouponRatio{},           // 报价项-代金券返券比例

}

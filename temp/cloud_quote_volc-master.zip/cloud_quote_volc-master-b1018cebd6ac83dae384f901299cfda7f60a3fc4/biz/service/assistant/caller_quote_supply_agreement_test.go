package assistant

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

// All comments and test scenario descriptions must be in english.
func Test_callerQuoteSupplyAgreement_Callback_BitsUTGen(t *testing.T) {
	// Initialize the target struct for testing.
	c := callerQuoteSupplyAgreement{}
	// Initialize a dummy gorm.DB instance as it's passed but not directly used by the top-level logic.
	mockTx := &gorm.DB{}

	t.Run("should return error when quote id is zero", func(t *testing.T) {
		mockey.PatchConvey("should return error when quote id is zero", t, func() {
			// Prepare input with zero QuoteID.
			cbCtx := &CallbackContext{
				Param: Param{QuoteID: 0},
			}
			container := &CallbackInfo{}

			// Mock logging function to ensure it's called.
			mockey.Mock(argosnotifylogs.CtxError).Return().Build()

			// Execute the function.
			err := c.Callback(context.Background(), mockTx, cbCtx, container)

			// Assert that a specific customer error is returned.
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单号为空")
		})
	})

	t.Run("should return error when database query fails with an exception", func(t *testing.T) {
		mockey.PatchConvey("should return error when database query fails with an exception", t, func() {
			// Prepare input with a non-zero QuoteID.
			cbCtx := &CallbackContext{
				Param: Param{QuoteID: 123},
			}
			container := &CallbackInfo{}
			dbErr := errors.New("database connection failed")

			// Mock the DAO method to return a generic database error.
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByParentID")).Return(nil, dbErr).Build()

			// Execute the function.
			err := c.Callback(context.Background(), mockTx, cbCtx, container)

			// Assert that the database error is wrapped and returned.
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})
	})

	t.Run("should succeed when database returns record not found", func(t *testing.T) {
		mockey.PatchConvey("should succeed when database returns record not found", t, func() {
			// Prepare input with a non-zero QuoteID.
			cbCtx := &CallbackContext{
				Param: Param{QuoteID: 456},
			}
			container := &CallbackInfo{}

			// Mock the DAO method to simulate a "record not found" scenario.
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByParentID")).Return(nil, gorm.ErrRecordNotFound).Build()

			// Execute the function.
			err := c.Callback(context.Background(), mockTx, cbCtx, container)

			// Assert that the function succeeds and the container's slice is nil.
			convey.So(err, convey.ShouldBeNil)
			convey.So(container.RelatedSupplyQuotes, convey.ShouldBeNil)
		})
	})

	t.Run("should succeed and populate container when quotes are found", func(t *testing.T) {
		mockey.PatchConvey("should succeed and populate container when quotes are found", t, func() {
			// Prepare input with a non-zero QuoteID.
			cbCtx := &CallbackContext{
				Param: Param{QuoteID: 789},
			}
			container := &CallbackInfo{}
			// Prepare mock data to be returned by the DAO.
			mockQuotes := []*model.Quote{
				{QuoteNo: "SUPPLY-001"},
				{QuoteNo: "SUPPLY-002"},
			}

			// Mock the DAO method to return the mock data successfully.
			mockey.Mock(mockey.GetMethod(dal.QuoteDao, "FindQuoteByParentID")).Return(mockQuotes, nil).Build()

			// Execute the function.
			err := c.Callback(context.Background(), mockTx, cbCtx, container)

			// Assert that the function succeeds and the container is populated correctly.
			convey.So(err, convey.ShouldBeNil)
			convey.So(container.RelatedSupplyQuotes, convey.ShouldResemble, mockQuotes)
			convey.So(len(container.RelatedSupplyQuotes), convey.ShouldEqual, 2)
		})
	})
}

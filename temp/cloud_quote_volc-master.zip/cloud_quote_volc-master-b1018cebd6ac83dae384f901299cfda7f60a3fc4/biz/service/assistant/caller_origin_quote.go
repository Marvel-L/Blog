package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

type callerOriginQuote struct {
}

func (c callerOriginQuote) dependKeys() []CallbackKey {
	return []CallbackKey{CallbackKeyQuote}
}

func (c callerOriginQuote) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	if container.Quote == nil {
		logs.CtxWarn(ctx, "[callerOriginQuote] quote is nil")
		return nil
	}
	originQuoteID := container.Quote.OriginQuoteID
	if originQuoteID == 0 {
		logs.CtxInfo(ctx, "[callerOriginQuote] OriginQuoteID is zero")
		return nil
	}
	originQuote, err := dal.QuoteDao.FindQuoteByID(tx, originQuoteID)
	if dal.IsExceptionError(err) {
		logs.CtxError(ctx, "[callerOriginQuote] FindQuoteByIDFail, quoteID=%d, err=%s", originQuoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询原始报价单失败")
	}
	container.OriginQuote = originQuote
	return nil
}

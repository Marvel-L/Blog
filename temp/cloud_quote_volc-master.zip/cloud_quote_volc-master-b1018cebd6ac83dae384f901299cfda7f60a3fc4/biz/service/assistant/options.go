package assistant

type CallbackOption struct {
	F func(o *CallbackContext)
}

func WithCallbackInfoKeys(keys []CallbackKey) CallbackOption {
	return CallbackOption{
		F: func(o *CallbackContext) {
			o.CallbackInfoKeys = append(o.CallbackInfoKeys, keys...)
		},
	}
}

package assistant

type CallbackKey int

const (
	CallbackKeyNone                 CallbackKey = iota // 占位符
	CallbackKeyQuote                                   // 报价单实体
	CallbackKeyOriginQuote                             // 原始报价单
	CallbackKeyQuoteItems                              // 报价项列表
	CallbackKeyDeliveryItems                           // 交付项列表
	CallbackKeyItemValues                              // 属性信息
	CallbackKeyItemCalculates                          // 报价项试算信息
	CallbackKeyBizLine                                 // 产品线信息
	CallbackKeyApplyCouponItems                        // 代金券信息
	CallbackKeyApplyCreditItems                        // 信控配置信息
	CallbackKeyRebate                                  // 返佣信息
	CallbackKeyGuaranteeItem                           // 保底列表
	CallbackKeyQuoteSolutions                          // 报价单解决方案列表
	CallbackKeyQuoteItemsAllStatus                     // 报价项所有状态（包含草稿）
	CallbackKeyResourcePage                            // 报价资源单
	CallbackKeyResourceItems                           // 报价资源卡
	CallbackKeySupplyAgreement                         // 报价单补充协议
	CallbackKeyQuoteContract                           // 报价单关联合同号
	CallbackKeyQuoteItemsExpired                       // 失效报价项列表
	CallbackKeyDeliveryItemsExpired                    // 失效交付项列表
	CallbackKeyConfigRelatedQuote                      // 配置清单关联报价单列表
	CallbackKeyConfigList                              // 项目制报价单关联的配置清单
	CallbackKeyAllRebateData                           // 返佣记录信息
	CallbackKeyProductInfo                             // 报价项商品信息
	CallbackKeyItemCouponRatio                         // 报价项-代金券返券比例
)

package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

// 返佣配置
type callerAllRebateData struct {
}

func (c callerAllRebateData) dependKeys() []CallbackKey {
	return nil
}

func (c callerAllRebateData) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerAllRebateData]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	list, err := dal.RebateItemDao.FindRebateItemsByQuoteID(tx, quoteID)
	if err != nil {
		logs.CtxError(ctx, "[callerAllRebateData]FindRebateItemsByQuoteIDFail, quoteID=%d, err=%s", quoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询返佣信息失败")
	}

	container.RebateItemList = list
	return nil
}

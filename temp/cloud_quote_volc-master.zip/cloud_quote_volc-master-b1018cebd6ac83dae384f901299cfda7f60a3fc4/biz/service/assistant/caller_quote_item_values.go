package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteItemValues struct {
}

func (c callerQuoteItemValues) dependKeys() []CallbackKey {
	return nil
}

func (c callerQuoteItemValues) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteItemValues]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	itemValueMap, err := dal.QuoteItemValueDao.QuoteItemValueMapByQuoteID(tx, quoteID)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询报价项属性信息失败")
	}
	container.AllItemValues = itemValueMap
	return nil
}

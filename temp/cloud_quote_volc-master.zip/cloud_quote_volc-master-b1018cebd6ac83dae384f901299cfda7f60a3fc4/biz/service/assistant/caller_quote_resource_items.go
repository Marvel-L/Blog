package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteResourceItems struct {
}

// dependKeys 依赖
func (c callerQuoteResourceItems) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

// Callback 数据召回
func (c callerQuoteResourceItems) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteResourceItems]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	resourceItems, err := dal.QuoteResourceItemDao.FindItemsByQuoteID(tx, quoteID)
	if err != nil {
		return errors.ErrCustomerError.WithArgs(err.Error())
	}
	container.QuoteResourceItems = resourceItems
	return nil
}

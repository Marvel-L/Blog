package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

// 保底
type callerGuarantee struct {
}

func (c callerGuarantee) dependKeys() []CallbackKey {
	return nil
}

func (c callerGuarantee) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerGuarantee]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	guaranteeItems, err := dal.GuaranteeItemDao.FindListByQuoteID(tx, quoteID)
	if dal.IsExceptionError(err) {
		logs.CtxError(ctx, "[callerGuarantee]FindByQuoteIDFail, quoteID=%d, err=%s", quoteID, err.Error())
		return errors.ErrCustomerError.WithArgs("查询保底信息失败")
	}

	if len(guaranteeItems) > 0 {
		container.GuaranteeItems = guaranteeItems
	}

	return nil
}

package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type callerQuoteSolutions struct {
}

func (c callerQuoteSolutions) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerQuoteSolutions) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteSolutions]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}
	quoteSolutions, err := dal.QuoteSolutionDao.FindQuoteSolutionsByQuoteID(tx, quoteID)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询报价单解决方案列表失败")
	}
	container.AllQuoteSolutions = quoteSolutions
	return nil
}

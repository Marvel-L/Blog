package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// 报价项商品信息
type callerProductInfo struct {
}

func (c callerProductInfo) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerProductInfo) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	allItems := container.GetAllItems()
	if len(allItems) == 0 {
		return nil
	}

	var productArr []string
	for _, quoteItem := range allItems {
		productArr = append(productArr, quoteItem.TradeProduct)
	}

	productInfoArr, err := commodity_service.GetTradeProductByArray(ctx, productArr, true)
	if err != nil {
		logs.CtxError(ctx, "[callerProductInfo] ListTradeProductFromCache, productArr=%s, err=%s", util.GetJsonStr(productInfoArr), err.Error())
		return errors.ErrCustomerError.WithArgs("查询商品信息失败")
	}
	container.ProductInfos = productInfoArr
	return nil
}

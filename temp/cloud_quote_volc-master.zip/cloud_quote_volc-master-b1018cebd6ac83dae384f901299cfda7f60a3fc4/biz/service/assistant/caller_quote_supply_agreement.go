package assistant

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// 查询当前报价单的补充协议列表
type callerQuoteSupplyAgreement struct {
}

func (c callerQuoteSupplyAgreement) dependKeys() []CallbackKey {
	return []CallbackKey{}
}

func (c callerQuoteSupplyAgreement) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		argosnotifylogs.CtxError(ctx, "[callerQuoteSupplyAgreement]Callback报价单号为空")
		return errors.ErrCustomerError.WithArgs("报价单号为空")
	}

	// 查询当前报价单的补充协议，比如关系为：A=>B=>[C,D]，则「A的补充协议为B」，「B的补充协议为C+D」
	// 仅支持补充报价单，不再有补充配置清单
	quotes, err := dal.QuoteDao.FindQuoteByParentID(tx, quoteID)
	if dal.IsExceptionError(err) {
		return errors.ErrCustomerError.WithArgs(err.Error())
	}

	container.RelatedSupplyQuotes = quotes

	return nil
}

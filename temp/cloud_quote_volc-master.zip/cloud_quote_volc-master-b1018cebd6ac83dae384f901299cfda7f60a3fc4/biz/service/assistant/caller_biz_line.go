package assistant

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

// 产品线信息计算
type callerBizLine struct {
}

func (c callerBizLine) dependKeys() []CallbackKey {
	return []CallbackKey{CallbackKeyQuoteItems}
}

func (c callerBizLine) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	if len(container.AllQuoteItems) == 0 {
		return nil
	}
	var (
		productArr              []string
		belongingDepartmentList []string                      // 一级产品线
		bizLineNameList         []string                      // 二级产品线
		itemTradeProductMapping = map[string][]int64{}        // 商品=>报价项关联关系
		bizLineItemsMapping     = map[string]map[int64]bool{} // 报价项=>二级产品线关联关系
		quoteItemBizLineMapping = map[int64]string{}          // 二级产品线=>报价项关联关系
	)
	for _, item := range container.AllQuoteItems {
		productArr = append(productArr, item.TradeProduct)
		itemTradeProductMapping[item.TradeProduct] = append(itemTradeProductMapping[item.TradeProduct], item.Id)
	}
	productArr = util.SingleList(productArr)
	req := &commodity_service.ListTradeProductInfoReq{
		TradeProductList: productArr,
	}
	productInfos, err := req.ListTradeProductFromCache()
	if err != nil {
		logs.CtxError(ctx, "[callerBizLine]ListTradeProductFromCacheFail, err=%s", err.Error())
		return errors.ErrCustomerError.WithArgs("")
	}
	for _, product := range productInfos {
		belongingDepartmentList = append(belongingDepartmentList, product.BelongingDepartment)
		bizLineNameList = append(bizLineNameList, product.BizLineName)
		itemIds := itemTradeProductMapping[product.Product]
		for _, id := range itemIds {
			idMap := bizLineItemsMapping[product.BizLineName]
			if idMap == nil {
				idMap = map[int64]bool{}
			}
			idMap[id] = true
			bizLineItemsMapping[product.BizLineName] = idMap
			quoteItemBizLineMapping[id] = product.BizLineName
		}
	}
	belongingDepartmentList = util.SingleList(belongingDepartmentList)
	bizLineNameList = util.SingleList(bizLineNameList)
	container.BelongingDepartmentList = belongingDepartmentList
	container.BizLineNameList = bizLineNameList
	container.BizLineQuoteItemMapping = bizLineItemsMapping
	container.QuoteItemBizLineMapping = quoteItemBizLineMapping
	return nil
}

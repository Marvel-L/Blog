package assistant

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"context"
	"gorm.io/gorm"
)

type callerItemCouponRatio struct{}

func (c callerItemCouponRatio) dependKeys() []CallbackKey { return []CallbackKey{} }

func (c callerItemCouponRatio) Callback(ctx context.Context, tx *gorm.DB, cbCtx *CallbackContext, container *CallbackInfo) errors.APIError {
	quoteID := cbCtx.Param.QuoteID
	if quoteID == 0 {
		return errors.ErrCustomerError.WithArgs("quoteID is empty")
	}
	itemCouponRatioList, err := dal.QuoteItemCouponRatioDao.FindByQuoteID(tx, quoteID)
	if err != nil {
		return errors.ErrCustomerError.WithArgs(err.Error())
	}
	container.QuoteItemCouponRatioList = itemCouponRatioList
	return nil
}

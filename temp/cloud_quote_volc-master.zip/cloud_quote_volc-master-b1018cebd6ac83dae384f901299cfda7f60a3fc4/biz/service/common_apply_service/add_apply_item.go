package common_apply_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/common_apply_service/apply_checker"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_log"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service"
)

type AddApplyItemReq struct {
	service.InsertReq
	QuoteID          int64   `json:"QuoteID"`
	ConfigID         int64   `json:"ConfigID"`
	ConfigIDs        []int64 `json:"ConfigIDs"`
	BizKey           string  `json:"BizKey"`
	SkipQuoteSupport bool    `json:"SkipQuoteSupport"`
}

func (r *AddApplyItemReq) Handle(ctx context.Context) (interface{}, error) {

	var allConfigs []int64
	// ConfigID参数与ConfigIDs参数互斥
	if r.ConfigID > 0 {
		allConfigs = []int64{r.ConfigID}
	} else {
		allConfigs = r.ConfigIDs
	}

	var resp []*model.CommonApplyItem
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {

		quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
		if err != nil {
			return errors.ErrInternalError.WithArgs(err)
		}

		// 当前config_id是否已经关联过
		if err = r.validateConfigRelExist(ctx, tx, r.BizKey, allConfigs, quote); err != nil {
			logs.CtxError(ctx, "validateConfigRelExistFail, err=%s", err.Error())
			return err
		}

		// 校验AccountID是否属于当前报价单
		if err = r.validateRelateAccountIds(ctx, tx, r.BizKey, allConfigs, quote); err != nil {
			logs.CtxError(ctx, "validateRelateAccountIdsFail, err=%s", err.Error())
			return err
		}

		// 全报价单业务校验
		if _, err := processcheck.FullQuoteDataCheck(ctx, tx,
			processcheck.OpTypeAddApplyItem,
			processcheck.WithQuoteDataCheckSetQuoteDBBefore(quote),      //
			processcheck.WithQuoteDataCheckSetApplyItemBizKey(r.BizKey), //
		); err != nil {
			return err
		}

		for _, configID := range allConfigs {
			item, err := r.addApplyItem(ctx, tx, r.BizKey, configID, quote)
			if err != nil {
				return err
			}
			resp = append(resp, item)
		}
		// 记录审批中修改操作日志（代金券/信控关联新增入口），仅新版审批中修改单据记录
		quote_log.RecordApprovalModifyLog(ctx, quote, constants.ActionModifyAddApplyItem, "")
		return err
	})

	return resp, err
}

// 校验当前config是否已经关联过，避免重复关联
func (r *AddApplyItemReq) validateConfigRelExist(ctx context.Context, tx *gorm.DB, bizKey string, configIDList []int64, quote *model.Quote) error {

	items, err := dal.CommonApplyItemDao.FindApplyItem(tx, quote.Id, bizKey)
	if err != nil {
		return errors.ErrCustomerError.WithArgs("查询已关联配置失败")
	}

	for _, item := range items {
		if util.Int64In(item.ConfigID, configIDList) {
			logs.CtxError(ctx, "validateConfigRelExistFail, 配置[%d]已关联过当前报价单", item.ConfigID)
			return errors.ErrCustomerError.WithArgs(i18nfmt.Sprintf(ctx, "配置[%d]已关联过当前报价单", item.ConfigID))
		}
	}

	return nil
}

func (r *AddApplyItemReq) validateRelateAccountIds(ctx context.Context, tx *gorm.DB, bizKey string, configIDList []int64, quote *model.Quote) error {

	var (
		accountIds []string
		err        error
	)

	if bizKey == multienv.ApplyBizKeyCoupon {
		accountIds, err = r.fetchCouponAccountIds(ctx, tx, configIDList)
		if err != nil {
			return err
		}
	} else if bizKey == multienv.ApplyBizKeyCredit {
		accountIds, err = r.fetchCreditAccountIds(ctx, tx, configIDList)
		if err != nil {
			return err
		}
	}

	logs.CtxInfo(ctx, "validateRelateAccountIds, accountIds=%v", accountIds)

	if !quote.ContainsAccountIDs(accountIds) {
		return errors.ErrCustomerError.WithArgs("优惠配置中包含报价单中不存在的账号")
	}

	return nil
}

func (r *AddApplyItemReq) fetchCouponAccountIds(ctx context.Context, tx *gorm.DB, configIDList []int64) ([]string, error) {
	list, err := dal.ExtraConfigCouponDao.FindByIdList(ctx, tx, configIDList)
	if err != nil {
		return nil, errors.ErrCustomerError.WithArgs("查询返券配置失败")
	}
	var accountIds []string
	for _, v := range list {
		accountIds = append(accountIds, strings.Split(v.AccountID, ",")...)
		var info model.TriggerInfo
		_ = json.Unmarshal([]byte(v.TriggerInfo), &info)
		for _, trigger := range info.Triggers {
			for _, vv := range trigger.ProgressiveGroups {
				accountIds = append(accountIds, fmt.Sprintf("%d", vv.AccountID))
			}
		}
	}

	return util.SingleList(accountIds), nil
}

func (r *AddApplyItemReq) fetchCreditAccountIds(ctx context.Context, tx *gorm.DB, configIDList []int64) ([]string, error) {
	list, err := dal.ExtraConfigCreditDao.FindByIds(ctx, tx, configIDList)
	if err != nil {
		return nil, errors.ErrCustomerError.WithArgs("查询信控配置失败")
	}
	var accountIds []string
	for _, v := range list {
		accountIds = append(accountIds, fmt.Sprintf("%d", v.AccountID))
	}
	return accountIds, nil
}

func (r *AddApplyItemReq) addApplyItem(ctx context.Context, tx *gorm.DB, bizKey string, configID int64, quote *model.Quote) (*model.CommonApplyItem, error) {

	var err error

	if err := processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeAddApplyItem, quote); err != nil {
		return nil, err
	}
	//if quote.QuoteStatus.CanNotSubmit() {
	//	return nil, errors.ErrBadRequestError.WithArgs("当前报价单已经提交，不可添加申请配置条目")
	//}
	if !r.SkipQuoteSupport {
		canApply, err := apply_checker.CanApply(ctx, tx, quote, bizKey)
		if err != nil {
			return nil, err
		}
		if !canApply {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "当前报价单不支持申请%s", multienv.GetApplyBizDesc(bizKey)))
		}
	}

	creator, err := r.GetCreator(ctx, tx)
	if err != nil {
		return nil, err
	}

	applyItem := &model.CommonApplyItem{
		QuoteID:          r.QuoteID,
		ConfigID:         configID,
		BizKey:           bizKey,
		CreatorAccountId: creator.AccountID,
	}
	if err = dal.CommonApplyItemDao.Save(tx, applyItem, &model.CommonApplyItem{}); err != nil {
		return nil, errors.ErrCustomerError.WithArgs(i18nfmt.Sprintf(ctx, "添加申请配置条目失败 error %s", err.Error()))
	}
	return applyItem, nil
}

package apply_checker

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
)

type CouponApplyChecker struct {
}

func (c *CouponApplyChecker) getApplyBizKey() string {
	return multienv.ApplyBizKeyCoupon
}

func (c *CouponApplyChecker) canApply(ctx context.Context, tx *gorm.DB, quote *model.Quote) (bool, error) {
	return quote.SupportCoupon(ctx)

}

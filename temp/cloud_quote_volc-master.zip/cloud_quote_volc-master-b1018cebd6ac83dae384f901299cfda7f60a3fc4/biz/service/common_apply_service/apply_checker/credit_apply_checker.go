package apply_checker

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"gorm.io/gorm"
)

type CreditApplyChecker struct {
}

func (c *CreditApplyChecker) getApplyBizKey() string {
	return multienv.ApplyBizKeyCredit
}

func (c *CreditApplyChecker) canApply(ctx context.Context, tx *gorm.DB, quote *model.Quote) (bool, error) {
	supportCredit, err := quote.SupportCredit(ctx)
	if err != nil {
		return false, err
	}
	if !supportCredit {
		return supportCredit, nil
	}

	condition := framework.Condition{}
	condition["quote_id"] = quote.Id
	condition["status"] = 0
	condition["standard_product"] = multienv.TradeProductStandardYes
	condition["item_type"] = multienv.TradeProductDeploymentTypePublic
	condition["item_scene"] = constants.ItemSceneQuoteItem
	count, err := dal.QuoteItemDao.CountQuoteItemByConditions(ctx, tx, condition)
	if err != nil {
		return false, err
	}
	if count <= 0 {
		return false, nil
	}

	return true, nil
}

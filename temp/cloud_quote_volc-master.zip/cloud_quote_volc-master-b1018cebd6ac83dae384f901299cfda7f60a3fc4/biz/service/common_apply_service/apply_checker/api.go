package apply_checker

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

type ApplyChecker interface {
	getApplyBizKey() string
	canApply(ctx context.Context, tx *gorm.DB, quote *model.Quote) (bool, error)
}

func CanApply(ctx context.Context, tx *gorm.DB, quote *model.Quote, bizKey string) (bool, error) {

	applyChecker := _applyCheckerMap[bizKey]
	if applyChecker == nil {
		return false, errors.ErrInternalError.WithArgs("申请类型错误，获取申请条目校验器失败")
	}
	return applyChecker.canApply(ctx, tx, quote)
}

func CheckQuoteApplyItem(ctx context.Context, tx *gorm.DB, quoteDB *model.Quote) error {
	applyItems, err := FindUsedApplyItem(tx, quoteDB.Id, "")
	if err != nil {
		return err
	}
	for _, applyItem := range applyItems {
		canApply, err := CanApply(ctx, tx, quoteDB, applyItem.BizKey)
		if err != nil {
			return err
		}
		if !canApply {
			applyBizDesc := multienv.GetApplyBizDesc(applyItem.BizKey)
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "当前报价单不支持%s申请，请先删除%s申请信息", applyBizDesc, applyBizDesc))
		}
	}

	return nil
}

// FindUsedApplyItem 获取有效申请（同种类型申请多次添加，最后一次添加有效）=> 调整为返回全部有效列表
func FindUsedApplyItem(tx *gorm.DB, quoteID int64, bizKey string) ([]*model.CommonApplyItem, error) {
	usedApplyItem := make([]*model.CommonApplyItem, 0)
	applyItems, err := dal.CommonApplyItemDao.FindApplyItem(tx, quoteID, bizKey)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return usedApplyItem, nil
		}
		return nil, errors.ErrCustomerError.WithArgs(i18nfmt.Sprintf(context.TODO(), "查询申请条目失败 error: %s", err.Error()))
	}
	return applyItems, nil
}

func GetBusinessDiscountInfo(tx *gorm.DB, quoteID int64) []string {
	var businessDiscount []string

	guaranteeItems, _ := dal.GuaranteeItemDao.FindListByQuoteID(tx, quoteID)
	if len(guaranteeItems) > 0 {
		businessDiscount = append(businessDiscount, multienv.GetBusinessDiscountGuarantee())
	}
	couponApplyItems, _ := FindUsedApplyItem(tx, quoteID, multienv.ApplyBizKeyCoupon)
	if len(couponApplyItems) > 0 {
		businessDiscount = append(businessDiscount, multienv.GetBusinessDiscountCoupon())
	}
	rebates, _ := dal.RebateItemDao.FindRealRebateItemsByQuoteID(tx, quoteID)
	if len(rebates) > 0 {
		businessDiscount = append(businessDiscount, multienv.GetBusinessDiscountRebate())
	}
	creditApplyItems, _ := FindUsedApplyItem(tx, quoteID, multienv.ApplyBizKeyCredit)

	if len(creditApplyItems) > 0 {
		businessDiscount = append(businessDiscount, multienv.GetBusinessDiscountCredit())
	}

	// 赠送场景计算
	quoteItems, _ := dal.QuoteItemDao.FindQuoteItemsByQuoteID(tx, quoteID, constants.ItemStatusAll, multienv.TradeProductTypeAll, constants.ItemSceneQuoteItem)
	for _, item := range quoteItems {
		if multienv.IsGiveAwayType(item.GiveAwayType) {
			businessDiscount = append(businessDiscount, multienv.GetBusinessDiscountGiveAway())
			break
		}
	}

	return businessDiscount
}

// GetBusinessDiscountInfoWithLang 保持原有商务优惠识别逻辑不变，
// 仅在中国区英文请求中翻译响应展示标签。
func GetBusinessDiscountInfoWithLang(ctx context.Context, tx *gorm.DB, quoteID int64) []string {
	businessDiscounts := GetBusinessDiscountInfo(tx, quoteID)
	if !multienv.NeedEnglishTranslation(ctx) {
		return businessDiscounts
	}
	for index, discount := range businessDiscounts {
		businessDiscounts[index] = multienv.I18nFormat(ctx, discount, false)
	}
	return businessDiscounts
}

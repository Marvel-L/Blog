package apply_checker

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func TestGetBusinessDiscountInfo(t *testing.T) {
	tx := &gorm.DB{}
	quoteID := int64(1001)

	t.Run("命中全部业务折扣", func(t *testing.T) {
		mockey.PatchConvey("命中全部业务折扣", t, func() {
			mockey.Mock(multienv.I18nFormat).To(func(_ context.Context, v string, _ bool) string {
				return v
			}).Build()
			mockey.Mock(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return([]*model.GuaranteeItem{{}}, nil).Build()
			mockey.Mock(FindUsedApplyItem).To(func(_ *gorm.DB, _ int64, bizKey string) ([]*model.CommonApplyItem, error) {
				switch bizKey {
				case multienv.ApplyBizKeyCoupon, multienv.ApplyBizKeyCredit:
					return []*model.CommonApplyItem{{}}, nil
				default:
					return []*model.CommonApplyItem{}, nil
				}
			}).Build()
			mockey.Mock(mockey.GetMethod(dal.RebateItemDao, "FindRealRebateItemsByQuoteID")).Return(model.RebateItemList{&model.RebateItem{}}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByQuoteID")).Return([]*model.QuoteItem{
				{GiveAwayType: multienv.GiveAwayTypeStd},
			}, nil).Build()

			got := GetBusinessDiscountInfo(tx, quoteID)

			convey.So(got, convey.ShouldResemble, []string{
				multienv.BusinessDiscountGuarantee,
				multienv.BusinessDiscountCoupon,
				multienv.BusinessDiscountRebate,
				multienv.BusinessDiscountCredit,
				multienv.BusinessDiscountGiveAway,
			})
		})
	})

	t.Run("仅赠送项命中时只追加一次", func(t *testing.T) {
		mockey.PatchConvey("仅赠送项命中时只追加一次", t, func() {
			mockey.Mock(multienv.I18nFormat).To(func(_ context.Context, v string, _ bool) string {
				return v
			}).Build()
			mockey.Mock(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return([]*model.GuaranteeItem{}, nil).Build()
			mockey.Mock(FindUsedApplyItem).Return([]*model.CommonApplyItem{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.RebateItemDao, "FindRealRebateItemsByQuoteID")).Return(model.RebateItemList{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByQuoteID")).To(
				func(_ *gorm.DB, _ int64, itemStatus int, itemType constants.ProductType, itemScene int) ([]*model.QuoteItem, error) {
					convey.So(itemStatus, convey.ShouldEqual, constants.ItemStatusAll)
					convey.So(itemType, convey.ShouldEqual, multienv.TradeProductTypeAll)
					convey.So(itemScene, convey.ShouldEqual, constants.ItemSceneQuoteItem)
					return []*model.QuoteItem{
						{GiveAwayType: multienv.GiveAwayTypeRange},
						{GiveAwayType: multienv.GiveAwayTypeStd},
					}, nil
				},
			).Build()

			got := GetBusinessDiscountInfo(tx, quoteID)

			convey.So(got, convey.ShouldResemble, []string{multienv.BusinessDiscountGiveAway})
		})
	})

	t.Run("没有任何业务折扣时返回空切片", func(t *testing.T) {
		mockey.PatchConvey("没有任何业务折扣时返回空切片", t, func() {
			mockey.Mock(multienv.I18nFormat).To(func(_ context.Context, v string, _ bool) string {
				return v
			}).Build()
			mockey.Mock(mockey.GetMethod(dal.GuaranteeItemDao, "FindListByQuoteID")).Return([]*model.GuaranteeItem{}, nil).Build()
			mockey.Mock(FindUsedApplyItem).Return([]*model.CommonApplyItem{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.RebateItemDao, "FindRealRebateItemsByQuoteID")).Return(model.RebateItemList{}, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.QuoteItemDao, "FindQuoteItemsByQuoteID")).Return([]*model.QuoteItem{
				{GiveAwayType: ""},
			}, nil).Build()

			got := GetBusinessDiscountInfo(tx, quoteID)

			convey.So(got, convey.ShouldResemble, []string(nil))
		})
	})
}

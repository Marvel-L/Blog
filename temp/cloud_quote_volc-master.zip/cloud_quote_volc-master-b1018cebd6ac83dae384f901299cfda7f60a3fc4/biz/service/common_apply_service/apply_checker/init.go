package apply_checker

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"context"
	"sync"
)

var _applyCheckerMap = map[string]ApplyChecker{}
var once sync.Once

func Init() {
	var err error
	once.Do(func() {
		checkers := getAllChecker()
		for _, checker := range checkers {
			if err = registerChecker(checker); err != nil {
				panic(err)
			}
		}

	})

}

func getAllChecker() []ApplyChecker {
	var ret []ApplyChecker
	ret = append(ret, &CouponApplyChecker{})
	ret = append(ret, &CreditApplyChecker{})
	return ret
}

func registerChecker(applyChecker ApplyChecker) error {
	if applyChecker == nil {
		return i18nfmt.NewError(context.Background(), "applyChecker_is_nil")
	}
	if _, exist := _applyCheckerMap[applyChecker.getApplyBizKey()]; exist {
		return i18nfmt.Errorf(context.Background(), "applyChecker[%s]", applyChecker.getApplyBizKey())
	}
	_applyCheckerMap[applyChecker.getApplyBizKey()] = applyChecker
	return nil
}

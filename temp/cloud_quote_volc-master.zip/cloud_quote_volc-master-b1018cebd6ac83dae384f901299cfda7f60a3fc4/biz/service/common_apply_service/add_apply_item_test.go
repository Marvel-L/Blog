package common_apply_service

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_AddApplyItemReq_fetchCouponAccountIds_BitsUTGen(t *testing.T) {
	// 初始化公共变量
	ctx := context.Background()
	tx := &gorm.DB{}
	r := &AddApplyItemReq{}
	configIDs := []int64{1, 2}

	mockey.PatchConvey("Test_AddApplyItemReq_fetchCouponAccountIds", t, func() {
		mockey.PatchConvey("成功场景 - 正常获取并去重账号ID", func() {
			// 场景描述：
			// 当 dal.ExtraConfigCouponDao.FindByIdList 成功返回包含多个配置的数据时，函数应能正确解析所有来源的 AccountID，并进行去重后返回。
			// 数据构造：
			// - Mock dal.ExtraConfigCouponDao.FindByIdList 返回一个包含两个 CouponConfigDB 对象的列表。
			// - 第一个对象的 AccountID 是 "1001,1002"，TriggerInfo 包含一个 ProgressiveGroup，其 AccountID 是 2001。
			// - 第二个对象的 AccountID 是 "1002,1003"，TriggerInfo 包含两个 ProgressiveGroup，其 AccountID 分别是 2002 和 2003。
			// - 数据中存在重复的 AccountID "1002"。
			// 逻辑链路：
			// 1. Mock dal.ExtraConfigCouponDao.FindByIdList 正常返回预设的 CouponConfigDB 列表。
			// 2. 调用 fetchCouponAccountIds 函数。
			// 3. 验证返回的 error 为 nil。
			// 4. 验证返回的 []string 包含了所有唯一的 AccountID ("1001", "1002", "1003", "2001", "2002", "2003")，顺序不保证。

			// 数据构造
			triggerInfo1, _ := json.Marshal(&model.TriggerInfo{
				Triggers: []*model.Trigger{
					{ProgressiveGroups: []*model.ProgressiveGroup{{AccountID: 2001}}},
				},
			})
			triggerInfo2, _ := json.Marshal(&model.TriggerInfo{
				Triggers: []*model.Trigger{
					{ProgressiveGroups: []*model.ProgressiveGroup{{AccountID: 2002}, {AccountID: 2003}}},
				},
			})

			mockList := model.CouponConfigDBList{
				{AccountID: "1001,1002", TriggerInfo: string(triggerInfo1)},
				{AccountID: "1002,1003", TriggerInfo: string(triggerInfo2)},
			}

			// Mock
			mockey.Mock(mockey.GetMethod(dal.ExtraConfigCouponDao, "FindByIdList")).Return(mockList, nil).Build()

			// 调用
			accountIds, err := r.fetchCouponAccountIds(ctx, tx, configIDs)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(accountIds), convey.ShouldEqual, 6)
			convey.So(accountIds, convey.ShouldContain, "1001")
			convey.So(accountIds, convey.ShouldContain, "1002")
			convey.So(accountIds, convey.ShouldContain, "1003")
			convey.So(accountIds, convey.ShouldContain, "2001")
			convey.So(accountIds, convey.ShouldContain, "2002")
			convey.So(accountIds, convey.ShouldContain, "2003")
		})

		mockey.PatchConvey("成功场景 - 数据库返回空列表", func() {
			// 场景描述：
			// 当 dal.ExtraConfigCouponDao.FindByIdList 返回一个空列表时，函数应返回一个空的账号ID列表，且不报错。
			// 数据构造：
			// - Mock dal.ExtraConfigCouponDao.FindByIdList 返回一个空的 model.CouponConfigDBList 和 nil error。
			// 逻辑链路：
			// 1. Mock dal.ExtraConfigCouponDao.FindByIdList 返回空列表。
			// 2. 调用 fetchCouponAccountIds 函数。
			// 3. 验证返回的 error 为 nil。
			// 4. 验证返回的 []string 为一个非nil的空切片。

			// 数据构造
			mockList := model.CouponConfigDBList{}

			// Mock
			mockey.Mock(mockey.GetMethod(dal.ExtraConfigCouponDao, "FindByIdList")).Return(mockList, nil).Build()

			// 调用
			accountIds, err := r.fetchCouponAccountIds(ctx, tx, configIDs)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(accountIds, convey.ShouldNotBeNil)
			convey.So(len(accountIds), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("成功场景 - TriggerInfo为空或无效JSON", func() {
			// 场景描述：
			// 当返回的记录中 TriggerInfo 字段为空字符串或无效JSON时，函数应能容错并继续处理 AccountID 字段，不应报错。
			// 数据构造：
			// - Mock dal.ExtraConfigCouponDao.FindByIdList 返回两条记录。
			// - 第一条记录的 TriggerInfo 为空字符串。
			// - 第二条记录的 TriggerInfo 为无效JSON字符串。
			// 逻辑链路：
			// 1. Mock dal.ExtraConfigCouponDao.FindByIdList 返回预设数据。
			// 2. 调用 fetchCouponAccountIds 函数。
			// 3. 验证返回的 error 为 nil。
			// 4. 验证返回的 []string 仅包含从 AccountID 字段解析出的ID。

			// 数据构造
			mockList := model.CouponConfigDBList{
				{AccountID: "1001,1002", TriggerInfo: ""},
				{AccountID: "1003", TriggerInfo: "this is not json"},
			}

			// Mock
			mockey.Mock(mockey.GetMethod(dal.ExtraConfigCouponDao, "FindByIdList")).Return(mockList, nil).Build()

			// 调用
			accountIds, err := r.fetchCouponAccountIds(ctx, tx, configIDs)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(accountIds), convey.ShouldEqual, 3)
			convey.So(accountIds, convey.ShouldContain, "1001")
			convey.So(accountIds, convey.ShouldContain, "1002")
			convey.So(accountIds, convey.ShouldContain, "1003")
		})

		mockey.PatchConvey("失败场景 - 数据库查询失败", func() {
			// 场景描述：
			// 当 dal.ExtraConfigCouponDao.FindByIdList 调用返回错误时，函数应捕获该错误并向上抛出包装后的业务错误。
			// 数据构造：
			// - Mock dal.ExtraConfigCouponDao.FindByIdList 返回一个非 nil 的 error。
			// 逻辑链路：
			// 1. Mock dal.ExtraConfigCouponDao.FindByIdList 返回一个 error。
			// 2. 调用 fetchCouponAccountIds 函数。
			// 3. 验证返回的 accountIds 为 nil。
			// 4. 验证返回的 error 不为 nil，且错误信息包含 "查询返券配置失败"。

			// 数据构造
			dbError := errors.New("database connection failed")

			// Mock
			mockey.Mock(mockey.GetMethod(dal.ExtraConfigCouponDao, "FindByIdList")).Return(nil, dbError).Build()

			// 调用
			accountIds, err := r.fetchCouponAccountIds(ctx, tx, configIDs)

			// 断言
			convey.So(accountIds, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询返券配置失败")
		})
	})
}

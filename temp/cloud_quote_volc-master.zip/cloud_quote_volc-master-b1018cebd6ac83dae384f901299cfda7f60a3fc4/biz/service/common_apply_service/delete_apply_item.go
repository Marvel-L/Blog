package common_apply_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_log"
	"context"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type DeleteApplyItemReq struct {
	QuoteID      int64
	ConfigID     int64
	ConfigIDList []int64
	BizKey       string
}

func (r *DeleteApplyItemReq) Handle(ctx context.Context) (interface{}, error) {

	var resp []*model.CommonApplyItem
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {

		var configIDList []int64
		if r.ConfigID > 0 {
			configIDList = []int64{r.ConfigID}
		} else {
			configIDList = r.ConfigIDList
		}

		for _, configID := range configIDList {
			items, err := r.deleteApplyItem(ctx, tx, configID)
			if err != nil {
				return err
			}
			resp = append(resp, items...)
		}

		return err
	})
	return resp, err
}

func (r *DeleteApplyItemReq) deleteApplyItem(ctx context.Context, tx *gorm.DB, configID int64) ([]*model.CommonApplyItem, error) {

	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		return nil, err
	}

	if err := processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeDelApplyItem, quote); err != nil {
		return nil, err
	}
	//if quote.QuoteStatus.CanNotSubmit() {
	//	return nil, errors.ErrBadRequestError.WithArgs("当前报价单已经提交，不可删除代金券配置")
	//}

	// 全报价单业务校验
	if _, err := processcheck.FullQuoteDataCheck(ctx, tx,
		processcheck.OpTypeDelApplyItem,
		processcheck.WithQuoteDataCheckSetQuoteDBBefore(quote),        //
		processcheck.WithQuoteDataCheckSetApplyItemBizKey(r.BizKey),   //
		processcheck.WithQuoteDataCheckSetApplyItemConfigID(configID), //
	); err != nil {
		return nil, err
	}

	applyItem, err := dal.CommonApplyItemDao.FindApplyItemByConfigID(tx, r.QuoteID, configID, r.BizKey)
	if err != nil {
		return nil, errors.ErrCustomerError.WithArgs(i18nfmt.Sprintf(ctx, "查询申请条目失败 error: %s", err.Error()))
	}
	err = dal.CommonApplyItemDao.SoftDeleteApplyItemByConfigID(tx, r.QuoteID, configID, r.BizKey)
	if err != nil {
		return nil, err
	}
	// 记录审批中修改操作日志（代金券/信控关联删除入口），仅新版审批中修改单据记录
	quote_log.RecordApprovalModifyLog(ctx, quote, constants.ActionModifyDeleteApplyItem, "")
	return applyItem, nil
}

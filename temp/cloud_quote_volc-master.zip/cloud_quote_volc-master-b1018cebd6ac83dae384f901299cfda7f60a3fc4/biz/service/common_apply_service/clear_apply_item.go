package common_apply_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/processcheck"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_log"
	"context"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

type ClearApplyItemReq struct {
	QuoteID int64
	BizKey  string
}

func (r *ClearApplyItemReq) Handle(ctx context.Context) (interface{}, error) {

	var resp interface{}
	var err error
	err = dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
		resp, err = r.clearApplyItem(ctx, tx)
		return err
	})
	return resp, err
}

func (r *ClearApplyItemReq) clearApplyItem(ctx context.Context, tx *gorm.DB) (interface{}, error) {

	quote, err := dal.QuoteDao.FindQuoteByID(tx, r.QuoteID)
	if err != nil {
		return nil, err
	}

	if err := processcheck.AllowQuoteOP(ctx, tx, processcheck.OpTypeClearApplyItem, quote); err != nil {
		return nil, err
	}
	//if quote.QuoteStatus.CanNotSubmit() {
	//	return nil, errors.ErrBadRequestError.WithArgs("当前报价单已经提交，不可清除优惠配置")
	//}

	// 全报价单业务校验
	if _, err := processcheck.FullQuoteDataCheck(ctx, tx,
		processcheck.OpTypeClearApplyItem,
		processcheck.WithQuoteDataCheckSetQuoteDBBefore(quote),      //
		processcheck.WithQuoteDataCheckSetApplyItemBizKey(r.BizKey), //
	); err != nil {
		return nil, err
	}

	err = dal.CommonApplyItemDao.SoftDeleteApplyItemAll(tx, r.QuoteID, r.BizKey)
	if err != nil {
		return nil, err
	}

	// 记录审批中修改操作日志（代金券/信控关联清空入口），仅新版审批中修改单据记录
	quote_log.RecordApprovalModifyLog(ctx, quote, constants.ActionModifyClearApplyItem, "")

	return nil, nil
}

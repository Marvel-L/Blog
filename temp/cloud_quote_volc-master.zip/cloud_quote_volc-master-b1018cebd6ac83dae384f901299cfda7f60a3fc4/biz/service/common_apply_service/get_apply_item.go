package common_apply_service

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/common_apply_service/apply_checker"
	"context"
)

type GetApplyItemReq struct {
	QuoteID int64
	BizKey  string
}

func (r *GetApplyItemReq) Handle(ctx context.Context) (interface{}, error) {

	tx := dal.DBProxy.NewRequest(ctx)
	applyItems, err := apply_checker.FindUsedApplyItem(tx, r.QuoteID, r.BizKey)
	if err != nil {
		return nil, err
	}
	return applyItems, nil
}

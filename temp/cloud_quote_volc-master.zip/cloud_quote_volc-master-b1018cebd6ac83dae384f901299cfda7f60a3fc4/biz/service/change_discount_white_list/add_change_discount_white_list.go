package change_discount_white_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/gopkg/logs"
	"context"
	"strings"
	"time"
)

type AddChangeDiscountWhiteListReq struct {
	WhiteLists []string
}

type AddChangeDiscountWhiteListResp struct {
	Success bool
}

func (r *AddChangeDiscountWhiteListReq) Handle(ctx context.Context) (interface{}, error) {
	currentUser, apiErr := dal.AccountDao.CurrentUser(ctx)
	if apiErr != nil {
		return currentUser, apiErr
	}
	if !currentUser.AccountType.Contains(constants.AccountTypeAdmin) {
		return nil, i18nfmt.NewError(ctx, "current user not allow this operation")
	}
	var whiteListToSave []*model.ChangeDiscountWhiteList
	for _, whiteList := range r.WhiteLists {
		arr := strings.Split(whiteList, ",")
		if len(arr) != 4 {
			continue
		}
		whiteListToSave = append(whiteListToSave, &model.ChangeDiscountWhiteList{

			CreatorAccountID:  currentUser.AccountID,
			CustomerAccountID: arr[0],
			TradeProduct:      arr[1],
			ConfigCode:        arr[2],
			ChargeItemCode:    arr[3],
		})
	}
	if len(whiteListToSave) > 0 {
		tx := dal.DBProxy.NewRequest(ctx)
		if err := dal.ChangeDiscountWhiteListDao.BatchSave(
			tx,
			whiteListToSave,
			&model.ChangeDiscountWhiteList{},
			multienv.ChangeDiscountQuoteItemMaxSaveNum,
		); err != nil {
			return nil, err
		}
	}

	if err := refreshUpdateTime(ctx); err != nil {
		return nil, err
	}
	if err := LoadWhiteList(ctx); err != nil {
		logs.CtxError(ctx, "LoadChangeDiscountWhiteList change_discount_white_list.LoadWhiteList error: %s", err.Error())
	}

	return &AddChangeDiscountWhiteListResp{
		Success: true,
	}, nil
}

func refreshUpdateTime(ctx context.Context) error {
	redisClient := redis_client.NewRedisClient()
	timeStr := time.Now().Format(time.RFC3339)
	_, err := redisClient.Set(WhiteListUpdateTimeKey, timeStr, 0).Result()
	if err != nil {
		return i18nfmt.Errorf(ctx, "redisClient.Set(WhiteListUpdateTimeKey, timeStr,0) error: %s", err.Error())
	}
	return nil
}

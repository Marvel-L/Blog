package change_discount_white_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/gopkg/logs"
	"context"
)

const WhiteListUpdateTimeKey = "change_discount_white_list_update_time"

var whiteListMap map[string]map[string]int64
var accountWhiteListMap map[string]bool

func LoadWhiteList(ctx context.Context) error {
	curWhiteListMap := map[string]map[string]int64{}
	curAccountWhiteListMap := map[string]bool{}
	tx := dal.DBProxy.NewRequest(ctx)
	allWhiteList, err := dal.ChangeDiscountWhiteListDao.FindAllWhiteList(tx)
	if err != nil {
		return err
	}
	for _, whiteList := range allWhiteList {
		indexMap, indexOk := curWhiteListMap[whiteList.GetIndexKey()]
		if !indexOk {
			indexMap = map[string]int64{}
			curWhiteListMap[whiteList.GetIndexKey()] = indexMap
		}
		indexMap[whiteList.GetConfigChargeItemKey()] = whiteList.Id
		curAccountWhiteListMap[whiteList.CustomerAccountID] = true
	}
	whiteListMap = curWhiteListMap
	accountWhiteListMap = curAccountWhiteListMap
	return nil
}

func GetWhiteListMap(ctx context.Context) map[string]map[string]int64 {
	if whiteListMap == nil {
		if err := LoadWhiteList(ctx); err != nil {
			logs.CtxError(ctx, "GetWhiteListMap(ctx context.Context) error: %s ", err.Error())
		}
	}
	return whiteListMap
}

func GetAccountWhiteListMap(ctx context.Context) map[string]bool {
	if accountWhiteListMap == nil {
		if err := LoadWhiteList(ctx); err != nil {
			logs.CtxError(ctx, "GetWhiteListMap(ctx context.Context) error: %s ", err.Error())
		}
	}
	return accountWhiteListMap
}

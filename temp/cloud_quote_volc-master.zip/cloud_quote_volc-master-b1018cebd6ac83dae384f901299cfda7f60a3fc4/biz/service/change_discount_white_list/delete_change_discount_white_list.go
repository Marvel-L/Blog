package change_discount_white_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/gopkg/logs"
	"context"
)

type DeleteChangeDiscountWhiteListReq struct {
	WhiteListIDs []int64
}

type DeleteChangeDiscountWhiteListResp struct {
	Success bool
}

func (r *DeleteChangeDiscountWhiteListReq) Handle(ctx context.Context) (interface{}, error) {
	currentUser, apiErr := dal.AccountDao.CurrentUser(ctx)
	if apiErr != nil {
		return currentUser, apiErr
	}
	if !currentUser.AccountType.Contains(constants.AccountTypeAdmin) {
		return nil, i18nfmt.NewError(ctx, "current user not allow this operation")
	}

	if len(r.WhiteListIDs) > 0 {
		tx := dal.DBProxy.NewRequest(ctx)
		if err := dal.ChangeDiscountWhiteListDao.SoftDeleteByCondition(tx, dal.Condition{
			"id": r.WhiteListIDs,
		}); err != nil {
			return nil, err
		}
	}

	if err := refreshUpdateTime(ctx); err != nil {
		return nil, err
	}

	if err := LoadWhiteList(ctx); err != nil {
		logs.CtxError(ctx, "LoadChangeDiscountWhiteList change_discount_white_list.LoadWhiteList error: %s", err.Error())
	}

	return &DeleteChangeDiscountWhiteListResp{
		Success: true,
	}, nil
}

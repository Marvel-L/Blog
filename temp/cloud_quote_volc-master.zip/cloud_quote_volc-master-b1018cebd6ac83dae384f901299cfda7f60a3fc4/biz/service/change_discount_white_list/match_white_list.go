package change_discount_white_list

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"
	"fmt"
)

type MatchWhiteListReq struct {
	CustomerAccountID string
	TradeProduct      string
	ConfigCode        string
	ChargeItemCode    string
}

type MatchWhiteListResp struct {
	Match       bool
	WhiteListID int64
}

func (r *MatchWhiteListReq) Handle(ctx context.Context) (interface{}, error) {
	match, whiteListID := r.Match(ctx)
	return &MatchWhiteListResp{
		Match:       match,
		WhiteListID: whiteListID,
	}, nil
}

func (r *MatchWhiteListReq) Match(ctx context.Context) (bool, int64) {
	wlMap := GetWhiteListMap(ctx)
	configChargeItemMap := wlMap[r.GetIndexKey()]
	if len(configChargeItemMap) == 0 {
		return false, 0
	}
	chargeItemKeys := r.GetConfigChargeItemKeys()
	for _, chargeItemKey := range chargeItemKeys {
		if whiteListID, ok := configChargeItemMap[chargeItemKey]; ok {
			return true, whiteListID
		}
	}
	return false, 0
}
func (r *MatchWhiteListReq) AccountMatch(ctx context.Context) bool {
	acWhiteListMap := GetAccountWhiteListMap(ctx)
	_, match := acWhiteListMap[r.CustomerAccountID]
	return match
}

func (r *MatchWhiteListReq) GetIndexKey() string {
	return fmt.Sprintf("%s::%s", r.CustomerAccountID, r.TradeProduct)
}
func (r *MatchWhiteListReq) GetConfigChargeItemKeys() []string {
	return []string{
		fmt.Sprintf("%s::%s", r.ConfigCode, r.ChargeItemCode),
		fmt.Sprintf("%s::%s", r.ConfigCode, constants.SelectAll),
		fmt.Sprintf("%s::%s", constants.SelectAll, constants.SelectAll),
	}
}

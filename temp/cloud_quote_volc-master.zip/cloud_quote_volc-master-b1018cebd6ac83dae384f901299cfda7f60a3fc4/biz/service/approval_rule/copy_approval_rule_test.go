package approval_rule

import (
	"context"
	"database/sql"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	v2 "code.byted.org/gopkg/gorm/v2"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_CopyApprovalRuleReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("规则编号为空返回参数缺失错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &CopyApprovalRuleReq{}

			resp, err := req.Handle(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【规则编号】不能为空")
		})
	})

	t.Run("获取锁失败时直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &CopyApprovalRuleReq{RuleID: 1001}
			mockey.Mock(approvalRulePermission.userPermissionCheck).
				Return(&model.Account{AccountID: "operator@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).
				Return((func())(nil), pkg_errors.NewBizErrWithMsg(pkg_errors.CodeNApprovalRuleInOperation, "当前审批规则正在操作中，请稍后重试")).
				Build()

			resp, err := req.Handle(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前审批规则正在操作中，请稍后重试")
		})
	})

	t.Run("原规则详情解析失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &CopyApprovalRuleReq{RuleID: 1002}
			mockey.Mock(approvalRulePermission.userPermissionCheck).
				Return(&model.Account{AccountID: "operator@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Transaction).
				To(func(_ *gorm.DB, fc func(tx *gorm.DB) error, _ ...*sql.TxOptions) error {
					return fc(&gorm.DB{})
				}).Build()
			originRule := &model.ApprovalRule{
				RuleType:   "typeA",
				RuleName:   "ruleA",
				RuleDetail: "invalid-json",
			}
			originRule.Id = 1002
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(originRule, nil).Build()

			resp, err := req.Handle(context.Background())

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "原规则详情解析失败，无法复制")
		})
	})

	t.Run("复制成功返回新规则编号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &CopyApprovalRuleReq{RuleID: 1003}
			mockey.Mock(approvalRulePermission.userPermissionCheck).
				Return(&model.Account{AccountID: "operator@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Transaction).
				To(func(_ *gorm.DB, fc func(tx *gorm.DB) error, _ ...*sql.TxOptions) error {
					return fc(&gorm.DB{})
				}).Build()

			originRule := &model.ApprovalRule{
				RuleType: "typeA",
				RuleName: "ruleA",
				RuleDetail: util.GetJsonStr(&model.ApprovalRuleDetailDB{
					QuoteTypes:   []int{1},
					TradeTypes:   []int{2},
					MonitorType:  "monitor_type",
					MonitorScope: multienv.ApprovalMonitorScopeQuote,
				}),
			}
			originRule.Id = 1003
			var savedRule *model.ApprovalRule
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(originRule, nil).Build()
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "SaveRule")).
				To(func(_ *gorm.DB, rule *model.ApprovalRule) error {
					savedRule = rule
					rule.Id = 2003
					return nil
				}).Build()

			resp, err := req.Handle(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(savedRule, convey.ShouldNotBeNil)
			convey.So(savedRule.RuleType, convey.ShouldEqual, originRule.RuleType)
			convey.So(savedRule.RuleName, convey.ShouldEqual, originRule.RuleName)
			convey.So(savedRule.CreatorEmail, convey.ShouldEqual, "operator@example.com")
			convey.So(savedRule.RuleStatus, convey.ShouldEqual, multienv.ApprovalRuleStatusInitialed)
			convey.So(savedRule.EffectiveTime.IsZero(), convey.ShouldBeTrue)
			convey.So(savedRule.RuleDetail, convey.ShouldEqual, originRule.RuleDetail)
			actual, ok := resp.(*CopyApprovalRuleResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(actual.RuleID, convey.ShouldEqual, 2003)
		})
	})
}

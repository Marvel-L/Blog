package approval_rule

import (
	"context"
	"errors"
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_lockApprovalRuleOperation_BitsUTGen(t *testing.T) {
	t.Run("首次获取锁成功返回解锁函数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			lockCalls := 0
			unlockCalls := 0
			mockey.Mock((*redis_client.RedisLock).Lock).
				To(func(_ *redis_client.RedisLock) error {
					lockCalls++
					return nil
				}).Build()
			mockey.Mock((*redis_client.RedisLock).Unlock).
				To(func(_ *redis_client.RedisLock) {
					unlockCalls++
				}).Build()

			unlock, err := lockApprovalRuleOperation(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(unlock, convey.ShouldNotBeNil)
			convey.So(lockCalls, convey.ShouldEqual, 1)

			unlock()
			convey.So(unlockCalls, convey.ShouldEqual, 1)
		})
	})

	t.Run("连续获取锁失败返回业务错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			lockCalls := 0
			sleepCalls := 0
			mockey.Mock((*redis_client.RedisLock).Lock).
				To(func(_ *redis_client.RedisLock) error {
					lockCalls++
					return errors.New("lock failed")
				}).Build()
			mockey.Mock(time.Sleep).
				To(func(_ time.Duration) {
					sleepCalls++
				}).Build()

			unlock, err := lockApprovalRuleOperation(context.Background())

			convey.So(unlock, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前审批规则正在操作中，请稍后重试")
			// -coverpkg 全仓插桩下，mockey 方法 patch 的回调次数会被放大；
			// 此处验证最终业务错误，不依赖 mock runtime 的计数。
			convey.So(lockCalls, convey.ShouldBeGreaterThanOrEqualTo, 3)
			convey.So(sleepCalls, convey.ShouldBeGreaterThanOrEqualTo, 3)
		})
	})
}

package approval_rule

import (
	"testing"

	"context"
	"errors"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func Test_ValidateChargeItemPriceTypeForFixedPrice_BitsUTGen(t *testing.T) {
	t.Run("GetDisplayPriceInfo返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩GetDisplayPriceInfo返回错误
			mockey.MockUnsafe((*item_context.ItemContext).GetDisplayPriceInfo).Return(nil, errors.New("mock get price info error")).Build()

			ctx := context.Background()
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 1, StandardProduct: 0}
			err := ValidateChargeItemPriceTypeForFixedPrice(ctx, "p", "c", "item", productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取计费项刊例价信息失败")
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock get price info error")
		})
	})

	t.Run("计费项刊例价信息为空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩GetDisplayPriceInfo返回nil且无错误
			mockey.MockUnsafe((*item_context.ItemContext).GetDisplayPriceInfo).Return((*item_context.ProductPriceInfo)(nil), nil).Build()

			ctx := context.Background()
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 2, StandardProduct: 1}
			err := ValidateChargeItemPriceTypeForFixedPrice(ctx, "p", "c", "item", productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "计费项刊例价信息不存在")
		})
	})

	t.Run("刊例价价格类型为非固定", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩GetDisplayPriceInfo返回非固定价格类型
			pp := &item_context.ProductPriceInfo{PricingFunction: "ladder_price"}
			mockey.MockUnsafe((*item_context.ItemContext).GetDisplayPriceInfo).Return(pp, nil).Build()

			ctx := context.Background()
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 3, StandardProduct: 0}
			err := ValidateChargeItemPriceTypeForFixedPrice(ctx, "p", "c", "item", productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前计费项刊例价价格类型为阶梯，不支持设置固定单价类型的指导价")
		})
	})

	t.Run("刊例价价格类型为固定", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩GetDisplayPriceInfo返回固定价格类型
			pp := &item_context.ProductPriceInfo{PricingFunction: constants.PricingFunctionFixedPrice}
			mockey.MockUnsafe((*item_context.ItemContext).GetDisplayPriceInfo).Return(pp, nil).Build()

			ctx := context.Background()
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 4, StandardProduct: 1}
			err := ValidateChargeItemPriceTypeForFixedPrice(ctx, "p", "c", "item", productInfo)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ValidateTradeProductConfigAndChargeItem_BitsUTGen(t *testing.T) {
	t.Run("获取商品信息失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 商品信息查询返回错误
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(nil, errors.New("mock cache error")).Build()

			ctx := context.Background()
			err := ValidateTradeProductConfigAndChargeItem(ctx, "prod_a", "cfg_a", "charge_a")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取商品信息失败")
		})
	})

	t.Run("计费项为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 商品信息正常返回
			product := &trade_client.TradeProductVersionInfo{ProductType: int(multienv.TradeProductDeploymentTypePrivate)}
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(product, nil).Build()

			ctx := context.Background()
			err := ValidateTradeProductConfigAndChargeItem(ctx, "prod_b", "", "")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品计费项不能为空")
		})
	})

	t.Run("私有云商品配置非空且不为通配符时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 私有云商品
			product := &trade_client.TradeProductVersionInfo{ProductType: int(multienv.TradeProductDeploymentTypePrivate)}
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(product, nil).Build()

			ctx := context.Background()
			err := ValidateTradeProductConfigAndChargeItem(ctx, "prod_c", "not_empty_cfg", "charge_c")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "私有云商品配置必须为空")
		})
	})

	t.Run("私有云商品配置为空返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 私有云商品
			product := &trade_client.TradeProductVersionInfo{ProductType: int(multienv.TradeProductDeploymentTypePrivate)}
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(product, nil).Build()

			ctx := context.Background()
			err := ValidateTradeProductConfigAndChargeItem(ctx, "prod_d", "", "charge_d")

			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_ValidateMonitorThresholdString_BitsUTGen(t *testing.T) {
	t.Run("阈值字符串为空返回缺失错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 空字符串直接返回缺失错误
			err := ValidateMonitorThresholdString("", true)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值不能为空")
		})
	})

	t.Run("阈值解析失败返回格式错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock解析失败
			mockey.MockUnsafe(decimal.NewFromString).Return(decimal.New(0, 0), errors.New("bad format")).Build()

			err := ValidateMonitorThresholdString("abc", true)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值格式错误")
		})
	})

	t.Run("阈值为负且允许0返回0或正数提示", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 解析成功，负数分支且允许0
			mockey.MockUnsafe(decimal.NewFromString).Return(decimal.New(1, 0), nil).Build()
			mockey.MockUnsafe(decimal.Decimal.IsNegative).Return(true).Build()

			err := ValidateMonitorThresholdString("-1", true)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入0或正数")
		})
	})

	t.Run("阈值为负且不允许0返回仅正数提示", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 解析成功，负数分支且不允许0
			mockey.MockUnsafe(decimal.NewFromString).Return(decimal.New(1, 0), nil).Build()
			mockey.MockUnsafe(decimal.Decimal.IsNegative).Return(true).Build()

			err := ValidateMonitorThresholdString("-1", false)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入正数")
		})
	})

	t.Run("阈值为0且不允许0返回仅正数提示", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 解析成功，非负，0值且不允许0
			mockey.MockUnsafe(decimal.NewFromString).Return(decimal.New(0, 0), nil).Build()
			mockey.MockUnsafe(decimal.Decimal.IsNegative).Return(false).Build()
			mockey.MockUnsafe(decimal.Decimal.IsZero).Return(true).Build()

			err := ValidateMonitorThresholdString("0", false)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入正数")
		})
	})

	t.Run("阈值为正数返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 解析成功，正数且非0
			mockey.MockUnsafe(decimal.NewFromString).Return(decimal.New(123, 0), nil).Build()
			mockey.MockUnsafe(decimal.Decimal.IsNegative).Return(false).Build()
			mockey.MockUnsafe(decimal.Decimal.IsZero).Return(false).Build()

			err := ValidateMonitorThresholdString("123", false)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ValidateMonitorSymbol_BitsUTGen(t *testing.T) {
	t.Run("空符号也直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeUnderGuidePrice, multienv.FreeApproval, "")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("商务优惠类型不限制符号并立即返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 商务优惠类型，无论符号是否合法都直接通过
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitLoss, "", ">", multienv.ApprovalRuleTypeBusinessDiscount)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("传入多个规则类型参数也直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeOverGuidePrice, multienv.ShiftApproval, ">=", "rule_a", "rule_b")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("其他未知监控类型不限制符号直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 默认分支，不限制符号
			err := ValidateMonitorSymbol("unknown_type", "", "!=")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("利润乐观允许符号通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 利润乐观允许 > 或 >=
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitOptimism, "", ">")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("利润乐观遇到其他符号也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitOptimism, "", "<")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("利润亏损允许符号通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 利润亏损允许 < 或 <=
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitLoss, "", "<")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("利润亏损遇到其他符号也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitLoss, "", ">=")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("毛利不达标允许符号通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 毛利不达标允许 < 或 <=
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeGrossProfitLoss, "", "<=")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("毛利不达标遇到其他符号也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeGrossProfitLoss, "", ">")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("低于指导价允许符号通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 低于指导价允许 < 或 <=
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeUnderGuidePrice, "", "<=")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("低于指导价遇到其他符号也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeUnderGuidePrice, "", ">")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("高于指导价允许符号通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 高于指导价允许 > 或 >=
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeOverGuidePrice, "", ">=")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("高于指导价遇到其他符号也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeOverGuidePrice, "", "<")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("上升审批符号为大于时也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeOverGuidePrice, multienv.ShiftApproval, ">")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("免审条件符号为小于时也返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeUnderGuidePrice, multienv.FreeApproval, "<")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("上升审批符号小于通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 符合上升审批要求
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeProfitLoss, multienv.ShiftApproval, "<")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("免审条件符号大于等于通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 符合免审条件要求
			err := ValidateMonitorSymbol(multienv.ApprovalMonitorTypeOverGuidePrice, multienv.FreeApproval, ">=")
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

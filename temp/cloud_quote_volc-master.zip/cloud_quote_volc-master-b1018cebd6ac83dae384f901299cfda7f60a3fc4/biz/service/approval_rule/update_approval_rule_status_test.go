package approval_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	v2 "code.byted.org/gopkg/gorm/v2"
	"code.byted.org/lang/gg/gptr"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func toJSON(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

func Test_UpdateApprovalRuleStatusReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("查找规则失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求和上下文
			ctx := context.Background()
			req := &UpdateApprovalRuleStatusReq{
				RuleID:     1001,
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).
				Return(&model.Account{AccountID: "user@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()

			// Mock全局DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock查询规则失败
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(nil, pkg_errors.NewRecordNotFoundErr("审批规则不存在")).Build()

			// 执行
			resp, err := req.Handle(ctx)

			// 断言
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批规则不存在")
		})
	})

	t.Run("权限校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &UpdateApprovalRuleStatusReq{
				RuleID:     1002,
				RuleStatus: multienv.ApprovalQuoteTypeExpired,
			}
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).
				Return(&model.Account{AccountID: "user@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()

			// Mock全局DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock查询规则成功
			rule := &model.ApprovalRule{CreatorEmail: "creator@example.com"}
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(rule, nil).Build()

			// Mock权限校验失败
			mockey.Mock(approvalRulePermission.rulePermissionCheck).
				Return((*model.Account)(nil), pkg_errors.NewUserNoPermissionErr("当前用户没有审批规则操作权限")).
				Build()

			// 执行
			resp, err := req.Handle(ctx)

			// 断言
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前用户没有审批规则操作权限")
		})
	})

	t.Run("事务内变更状态失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &UpdateApprovalRuleStatusReq{
				RuleID:     1003,
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).
				Return(&model.Account{AccountID: "user@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()

			// Mock全局DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock查询规则成功
			rule := &model.ApprovalRule{CreatorEmail: "user@example.com"}
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(rule, nil).Build()

			// Mock权限校验通过
			mockey.Mock(approvalRulePermission.rulePermissionCheck).
				Return(&model.Account{AccountID: "user@example.com"}, nil).
				Build()

			// Mock事务执行，直接调用回调函数
			mockey.Mock((*gorm.DB).Transaction).
				To(func(_ *gorm.DB, fc func(tx *gorm.DB) error, _ ...*sql.TxOptions) error {
					return fc(&gorm.DB{})
				}).Build()

			// Mock变更状态失败
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatus).
				Return((*UpdateApprovalRuleStatusResp)(nil), pkg_errors.NewBizErrWithMsg(pkg_errors.CodeNApprovalRuleOperationNotAllow, "审批规则状态不允许")).
				Build()

			// 执行
			resp, err := req.Handle(ctx)

			// 断言
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批规则状态不允许")
		})
	})

	t.Run("事务内变更状态成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &UpdateApprovalRuleStatusReq{
				RuleID:     1004,
				RuleStatus: multienv.ApprovalQuoteTypeExpired,
			}
			mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).
				Return(&model.Account{AccountID: "user2@example.com"}, nil).
				Build()
			mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()

			// Mock全局DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// Mock查询规则成功
			rule := &model.ApprovalRule{CreatorEmail: "user2@example.com"}
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(rule, nil).Build()

			// Mock权限校验通过
			mockey.Mock(approvalRulePermission.rulePermissionCheck).
				Return(&model.Account{AccountID: "user2@example.com"}, nil).
				Build()

			// Mock事务执行，直接调用回调函数
			mockey.Mock((*gorm.DB).Transaction).
				To(func(_ *gorm.DB, fc func(tx *gorm.DB) error, _ ...*sql.TxOptions) error {
					return fc(&gorm.DB{})
				}).Build()

			// Mock变更状态成功
			expectedResp := &UpdateApprovalRuleStatusResp{
				RuleID:     req.RuleID,
				RuleStatus: req.RuleStatus,
			}
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatus).
				Return(expectedResp, nil).
				Build()

			// 执行
			resp, err := req.Handle(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			actual, ok := resp.(*UpdateApprovalRuleStatusResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(actual.RuleID, convey.ShouldEqual, req.RuleID)
			convey.So(actual.RuleStatus, convey.ShouldEqual, req.RuleStatus)
		})
	})
}

func Test_UpdateApprovalRuleStatusReq_changeRuleStatusEffective_BitsUTGen(t *testing.T) {
	t.Run("当重复规则检查返回错误时应直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造入参
			ctx := context.Background()
			tx := &gorm.DB{}
			r := &UpdateApprovalRuleStatusReq{}
			originRuleDB := &model.ApprovalRule{}
			originRuleDB.Id = int64(1001)

			// 初始化全局变量
			mockey.MockValue(&dal.ApprovalRuleDao).To(dal.ApprovalRuleDao)

			// Mock 检查重复规则，返回错误
			mockey.MockUnsafe((*UpdateApprovalRuleStatusReq).checkDuplicateRulesBeforeEffective).
				Return(pkg_errors.NewBizErrWithMsg(pkg_errors.CodeNApprovalRuleParamIllegal, "mock-check-error")).
				Build()

			// 调用目标函数
			err := r.changeRuleStatusEffective(ctx, tx, originRuleDB)

			// 断言返回的错误来自重复校验
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock-check-error")
		})
	})

	t.Run("重复规则检查通过但数据库更新失败应返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造入参
			ctx := context.Background()
			tx := &gorm.DB{}
			r := &UpdateApprovalRuleStatusReq{}
			originRuleDB := &model.ApprovalRule{}
			originRuleDB.Id = int64(2002)

			// 初始化全局变量
			mockey.MockValue(&dal.ApprovalRuleDao).To(dal.ApprovalRuleDao)

			// Mock 重复规则检查通过
			mockey.MockUnsafe((*UpdateApprovalRuleStatusReq).checkDuplicateRulesBeforeEffective).
				Return(nil).
				Build()

			// Mock 数据库更新失败
			mockey.MockUnsafe(mockey.GetMethod(dal.ApprovalRuleDao, "UpdateRuleByIDWithStatus")).
				Return(pkg_errors.NewInternalDBError(errors.New("db failed"))).
				Build()

			// 调用目标函数
			err := r.changeRuleStatusEffective(ctx, tx, originRuleDB)

			// 断言返回的错误来自数据库更新失败
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db failed")
		})
	})

	t.Run("重复规则检查通过且数据库更新成功应返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造入参
			ctx := context.Background()
			tx := &gorm.DB{}
			r := &UpdateApprovalRuleStatusReq{}
			originRuleDB := &model.ApprovalRule{}
			originRuleDB.Id = int64(3003)

			// 初始化全局变量
			mockey.MockValue(&dal.ApprovalRuleDao).To(dal.ApprovalRuleDao)

			// Mock 重复规则检查通过
			mockey.MockUnsafe((*UpdateApprovalRuleStatusReq).checkDuplicateRulesBeforeEffective).
				Return(nil).
				Build()

			// Mock 数据库更新成功
			mockey.MockUnsafe(mockey.GetMethod(dal.ApprovalRuleDao, "UpdateRuleByIDWithStatus")).
				Return(nil).
				Build()

			// 调用目标函数
			err := r.changeRuleStatusEffective(ctx, tx, originRuleDB)

			// 断言成功无错误
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpdateApprovalRuleStatusReq_checkDuplicateRulesBeforeEffective_BitsUTGen(t *testing.T) {
	t.Run("规则详情解析失败，返回参数非法错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造非法的规则详情，触发解析失败
			originRule := &model.ApprovalRule{
				RuleDetail: "{", // 非法JSON
			}
			req := &UpdateApprovalRuleStatusReq{}
			ctx := context.Background()
			tx := &gorm.DB{}

			err := req.checkDuplicateRulesBeforeEffective(ctx, tx, originRule)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "规则详情解析失败")
		})
	})

	t.Run("内部重复校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置产品线监控范围，并制造重复的产品线配置
			detailDB := &model.ApprovalRuleDetailDB{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{2},
				FormField:    "fieldA",
				MonitorType:  "monitorA",
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "Dept1", BizLineName: "BizA"},
					{DepartmentName: "Dept1", BizLineName: "BizA"}, // 重复
				},
			}
			originRule := &model.ApprovalRule{
				RuleDetail: toJSON(detailDB),
			}
			req := &UpdateApprovalRuleStatusReq{}
			ctx := context.Background()
			tx := &gorm.DB{}

			err := req.checkDuplicateRulesBeforeEffective(ctx, tx, originRule)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【产品线监控配置】存在重复")
		})
	})

	t.Run("外部重复校验函数返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造正常的规则详情（整单监控，无内部重复）
			detailDB := &model.ApprovalRuleDetailDB{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{1},
				FormField:    "F",
				MonitorType:  "M",
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			originRule := &model.ApprovalRule{
				RuleDetail: toJSON(detailDB),
			}
			req := &UpdateApprovalRuleStatusReq{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// mock外部判重逻辑返回错误
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkDuplicateRules).Return([]*RepeatApprovalRuleDetail(nil), pkg_errors.NewInternalDBError(errors.New("db error"))).Build()

			err := req.checkDuplicateRulesBeforeEffective(ctx, tx, originRule)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db error")
		})
	})

	t.Run("存在重复规则返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造正常的规则详情（整单监控，无内部重复）
			detailDB := &model.ApprovalRuleDetailDB{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{1},
				FormField:    "F",
				MonitorType:  "M",
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			originRule := &model.ApprovalRule{
				RuleDetail: toJSON(detailDB),
			}
			req := &UpdateApprovalRuleStatusReq{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// mock外部判重逻辑返回重复规则
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkDuplicateRules).Return(
				[]*RepeatApprovalRuleDetail{
					{RuleID: 101, RepeatKeys: []string{"k1"}},
					{RuleID: 202, RepeatKeys: []string{"k2"}},
				}, nil,
			).Build()

			err := req.checkDuplicateRulesBeforeEffective(ctx, tx, originRule)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "存在重复")
		})
	})

	t.Run("无重复规则返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造正常的规则详情（整单监控，无内部重复）
			detailDB := &model.ApprovalRuleDetailDB{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{1},
				FormField:    "F",
				MonitorType:  "M",
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			originRule := &model.ApprovalRule{
				RuleDetail: toJSON(detailDB),
			}
			req := &UpdateApprovalRuleStatusReq{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// mock外部判重逻辑返回空
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkDuplicateRules).Return([]*RepeatApprovalRuleDetail{}, nil).Build()

			err := req.checkDuplicateRulesBeforeEffective(ctx, tx, originRule)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpdateApprovalRuleStatusReq_changeRuleStatus_BitsUTGen(t *testing.T) {
	t.Run("状态流转不合法，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造非法状态流转：从已失效到生效不被允许
			ctx := context.Background()
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     1001,
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			originRuleDB := &model.ApprovalRule{
				RuleStatus: multienv.ApprovalQuoteTypeExpired,
			}

			resp, err := r.changeRuleStatus(ctx, nil, originRuleDB)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批规则状态不允许从")
		})
	})

	t.Run("目标状态生效，内部变更失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造合法状态流转：草稿到生效
			ctx := context.Background()
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     1002,
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			originRuleDB := &model.ApprovalRule{
				RuleStatus: multienv.ApprovalRuleStatusInitialed,
			}
			var tx *gorm.DB = nil

			// 打桩使内部生效变更返回错误
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatusEffective).Return(errors.New("change effective failed")).Build()

			resp, err := r.changeRuleStatus(ctx, tx, originRuleDB)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "change effective failed")
		})
	})

	t.Run("目标状态生效，变更成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造合法状态流转：草稿到生效
			ctx := context.Background()
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     1003,
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			originRuleDB := &model.ApprovalRule{
				RuleStatus: multienv.ApprovalRuleStatusInitialed,
			}
			var tx *gorm.DB = nil

			// 打桩使内部生效变更成功
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatusEffective).Return(nil).Build()

			resp, err := r.changeRuleStatus(ctx, tx, originRuleDB)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.RuleID, convey.ShouldEqual, r.RuleID)
			convey.So(resp.RuleStatus, convey.ShouldEqual, r.RuleStatus)
		})
	})

	t.Run("目标状态失效，内部变更失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造合法状态流转：生效到失效
			ctx := context.Background()
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     1004,
				RuleStatus: multienv.ApprovalQuoteTypeExpired,
			}
			originRuleDB := &model.ApprovalRule{
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			var tx *gorm.DB = nil

			// 打桩使内部失效变更返回错误
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatusExpired).Return(errors.New("change expired failed")).Build()

			resp, err := r.changeRuleStatus(ctx, tx, originRuleDB)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "change expired failed")
		})
	})

	t.Run("目标状态失效，变更成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造合法状态流转：生效到失效
			ctx := context.Background()
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     1005,
				RuleStatus: multienv.ApprovalQuoteTypeExpired,
			}
			originRuleDB := &model.ApprovalRule{
				RuleStatus: multienv.ApprovalQuoteTypeEffective,
			}
			var tx *gorm.DB = nil

			// 打桩使内部失效变更成功
			mockey.Mock((*UpdateApprovalRuleStatusReq).changeRuleStatusExpired).Return(nil).Build()

			resp, err := r.changeRuleStatus(ctx, tx, originRuleDB)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.RuleID, convey.ShouldEqual, r.RuleID)
			convey.So(resp.RuleStatus, convey.ShouldEqual, r.RuleStatus)
		})
	})
}

func Test_UpdateApprovalRuleStatusReq_changeRuleStatusExpired_BitsUTGen(t *testing.T) {
	t.Run("变更规则状态为已失效-更新成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求与上下文
			ctx := context.Background()
			tx := &gorm.DB{}
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     *gptr.Of(int64(123)),
				RuleStatus: *gptr.Of(multienv.ApprovalQuoteTypeExpired),
			}
			originRuleDB := &model.ApprovalRule{}

			// 初始化并打桩全局DAO变量
			mockey.MockValue(&dal.ApprovalRuleDao).To(dal.ApprovalRuleDao)
			mockey.MockUnsafe(mockey.GetMethod(dal.ApprovalRuleDao, "UpdateRuleByIDWithStatus")).Return(nil).Build()

			// 调用待测方法
			err := r.changeRuleStatusExpired(ctx, tx, originRuleDB)

			// 断言返回为成功
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("变更规则状态为已失效-更新失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求与上下文
			ctx := context.Background()
			tx := &gorm.DB{}
			r := &UpdateApprovalRuleStatusReq{
				RuleID:     *gptr.Of(int64(456)),
				RuleStatus: *gptr.Of(multienv.ApprovalQuoteTypeExpired),
			}
			originRuleDB := &model.ApprovalRule{}

			// 初始化并打桩全局DAO变量
			mockey.MockValue(&dal.ApprovalRuleDao).To(dal.ApprovalRuleDao)
			mockey.MockUnsafe(mockey.GetMethod(dal.ApprovalRuleDao, "UpdateRuleByIDWithStatus")).Return(errors.New("db error")).Build()

			// 调用待测方法
			err := r.changeRuleStatusExpired(ctx, tx, originRuleDB)

			// 断言返回为错误
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db error")
		})
	})
}

package approval_rule

import (
	"testing"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_ListApprovalRulesReq_getCondition_BitsUTGen(t *testing.T) {
	t.Run("全部条件有效，返回完整查询条件", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造完整请求，包含所有过滤条件与合法时间
			ruleTypes := []string{"TYPE_A", "TYPE_B"}
			creatorEmails := []string{"a@b.com", "c@d.com"}
			ruleStatus := []string{"enabled", "disabled"}
			ruleName := "abc"
			ruleID := "123"

			startCreated := time.Date(2024, 1, 2, 5, 6, 0, 0, time.UTC)
			endCreated := time.Date(2024, 4, 5, 6, 7, 0, 0, time.UTC)
			startEffective := time.Date(2025, 2, 3, 5, 6, 0, 0, time.UTC)
			endEffective := time.Date(2025, 7, 8, 9, 10, 0, 0, time.UTC)

			req := &ListApprovalRulesReq{
				RuleTypes:             ruleTypes,
				RuleName:              ruleName,
				RuleID:                ruleID,
				CreatorEmails:         creatorEmails,
				RuleStatus:            ruleStatus,
				CreatedTimeStartStr:   startCreated.Format(time.RFC3339),
				CreatedTimeEndStr:     endCreated.Format(time.RFC3339),
				EffectiveTimeStartStr: startEffective.Format(time.RFC3339),
				EffectiveTimeEndStr:   endEffective.Format(time.RFC3339),
			}

			condition, err := req.getCondition()

			convey.So(err, convey.ShouldBeNil)
			convey.So(condition, convey.ShouldNotBeNil)
			convey.So(condition["rule_type"], convey.ShouldResemble, ruleTypes)
			convey.So(condition["rule_name like"], convey.ShouldEqual, dal.MakeFuzzQuery(ruleName))
			convey.So(condition["id like"], convey.ShouldEqual, dal.MakeFuzzQuery(ruleID))
			convey.So(condition["creator_email"], convey.ShouldResemble, creatorEmails)
			convey.So(condition["rule_status"], convey.ShouldResemble, ruleStatus)

			startCreatedParsed, _ := util.CheckTime(req.CreatedTimeStartStr)
			endCreatedParsed, _ := util.CheckTime(req.CreatedTimeEndStr)
			convey.So(condition["created_time >="], convey.ShouldResemble, util.ToBeginningOfDay(startCreatedParsed))
			convey.So(condition["created_time <="], convey.ShouldResemble, util.ToEndOfDay(endCreatedParsed))

			startEffectiveParsed, _ := util.CheckTime(req.EffectiveTimeStartStr)
			endEffectiveParsed, _ := util.CheckTime(req.EffectiveTimeEndStr)
			convey.So(condition["effective_time >="], convey.ShouldResemble, util.ToBeginningOfDay(startEffectiveParsed))
			convey.So(condition["effective_time <="], convey.ShouldResemble, util.ToEndOfDay(endEffectiveParsed))
		})
	})

	t.Run("创建时间开始格式错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 创建时间开始非法
			req := &ListApprovalRulesReq{
				CreatedTimeStartStr: "invalid-start",
				CreatedTimeEndStr:   time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC).Format(time.RFC3339),
			}

			condition, err := req.getCondition()

			convey.So(condition, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【创建时间-开始时间】格式不正确")
		})
	})

	t.Run("创建时间结束格式错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 创建时间结束非法
			req := &ListApprovalRulesReq{
				CreatedTimeStartStr: time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC).Format(time.RFC3339),
				CreatedTimeEndStr:   "invalid-end",
			}

			condition, err := req.getCondition()

			convey.So(condition, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【创建时间-结束时间】格式不正确")
		})
	})

	t.Run("生效时间开始格式错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 生效时间开始非法
			req := &ListApprovalRulesReq{
				EffectiveTimeStartStr: "invalid-effective-start",
				EffectiveTimeEndStr:   time.Date(2025, 1, 2, 0, 0, 0, 0, time.UTC).Format(time.RFC3339),
			}

			condition, err := req.getCondition()

			convey.So(condition, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【生效时间-开始时间】格式不正确")
		})
	})

	t.Run("生效时间结束格式错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 生效时间结束非法
			req := &ListApprovalRulesReq{
				EffectiveTimeStartStr: time.Date(2025, 1, 2, 0, 0, 0, 0, time.UTC).Format(time.RFC3339),
				EffectiveTimeEndStr:   "invalid-effective-end",
			}

			condition, err := req.getCondition()

			convey.So(condition, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【生效时间-结束时间】格式不正确")
		})
	})

	t.Run("只设置基本过滤条件且未设置时间，返回基本条件", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 仅设置基本过滤条件，未设置时间不应包含任何时间过滤字段
			req := &ListApprovalRulesReq{
				RuleTypes:     []string{"TYPE_X"},
				RuleName:      "hello",
				RuleID:        "RID-001",
				CreatorEmails: []string{"x@y.com"},
				RuleStatus:    []string{"active"},
			}

			condition, err := req.getCondition()

			convey.So(err, convey.ShouldBeNil)
			convey.So(condition["rule_type"], convey.ShouldResemble, []string{"TYPE_X"})
			convey.So(condition["rule_name like"], convey.ShouldEqual, dal.MakeFuzzQuery("hello"))
			convey.So(condition["id like"], convey.ShouldEqual, dal.MakeFuzzQuery("RID-001"))
			convey.So(condition["creator_email"], convey.ShouldResemble, []string{"x@y.com"})
			convey.So(condition["rule_status"], convey.ShouldResemble, []string{"active"})

			_, okCreatedGe := condition["created_time >="]
			_, okCreatedLe := condition["created_time <="]
			_, okEffectiveGe := condition["effective_time >="]
			_, okEffectiveLe := condition["effective_time <="]
			convey.So(okCreatedGe, convey.ShouldBeFalse)
			convey.So(okCreatedLe, convey.ShouldBeFalse)
			convey.So(okEffectiveGe, convey.ShouldBeFalse)
			convey.So(okEffectiveLe, convey.ShouldBeFalse)
		})
	})
}

func Test_ListApprovalRulesReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("用户权限校验失败，直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &ListApprovalRulesReq{
				approvalRulePermission: approvalRulePermission{},
				Pagination: framework.Pagination{
					Limit:  10,
					Offset: 1,
				},
			}
			ctx := context.Background()

			// 初始化并mock DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 用户权限检查失败
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(nil, pkg_errors.NewUserNoPermissionErr("当前用户没有审批规则操作权限")).Build()

			// 调用并断言
			resp, err := req.Handle(ctx)
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前用户没有审批规则操作权限")
		})
	})

	t.Run("条件构造失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &ListApprovalRulesReq{
				approvalRulePermission: approvalRulePermission{},
				Pagination: framework.Pagination{
					Limit:  5,
					Offset: 2,
				},
			}
			ctx := context.Background()

			// 初始化并mock DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{}, nil).Build()

			// getCondition返回错误
			mockey.Mock((*ListApprovalRulesReq).getCondition).Return(nil, pkg_errors.NewBizErrWithMsg(pkg_errors.CodeNTimeFormatError, "【创建时间-开始时间】格式不正确")).Build()

			// 调用并断言
			resp, err := req.Handle(ctx)
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "格式不正确")
		})
	})

	t.Run("查询审批规则数据库错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &ListApprovalRulesReq{
				approvalRulePermission: approvalRulePermission{},
				Pagination: framework.Pagination{
					Limit:  10,
					Offset: 3,
				},
			}
			ctx := context.Background()

			// 初始化并mock DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{}, nil).Build()

			// getCondition成功
			mockey.Mock((*ListApprovalRulesReq).getCondition).Return(framework.Condition{}, nil).Build()

			// 数据库查询失败
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRulesByCondition")).Return(nil, int64(0), pkg_errors.NewInternalDBError(errors.New("db error"))).Build()

			// 调用并断言
			resp, err := req.Handle(ctx)
			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db error")
		})
	})

	t.Run("查询审批规则成功，返回列表和分页", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &ListApprovalRulesReq{
				approvalRulePermission: approvalRulePermission{},
				Pagination: framework.Pagination{
					Limit:  2,
					Offset: 1,
				},
			}
			ctx := context.Background()

			// 初始化并mock DBProxy
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockDB := &gorm.DB{Config: &gorm.Config{}}
			mockey.Mock((*v2.DBProxy).NewRequest).Return(mockDB).Build()

			// 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{}, nil).Build()

			// getCondition成功
			mockey.Mock((*ListApprovalRulesReq).getCondition).Return(framework.Condition{"rule_type": []string{"A"}}, nil).Build()

			// 返回两条规则数据
			now := time.Now()
			rules := []*model.ApprovalRule{
				{
					RuleType:      "typeA",
					RuleName:      "rule-1",
					CreatorEmail:  "a@b.com",
					RuleStatus:    "enabled",
					EffectiveTime: now,
				},
				{
					RuleType:      "typeB",
					RuleName:      "rule-2",
					CreatorEmail:  "c@d.com",
					RuleStatus:    "disabled",
					EffectiveTime: now.Add(time.Hour),
				},
			}
			total := int64(2)
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRulesByCondition")).Return(rules, total, nil).Build()

			// 调用并断言
			resp, err := req.Handle(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)

			out, ok := resp.(*ListApprovalRulesResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(out.Pagination.Limit, convey.ShouldEqual, 2)
			convey.So(out.Pagination.Offset, convey.ShouldEqual, 1)
			convey.So(out.Pagination.Total, convey.ShouldEqual, total)
			convey.So(len(out.List), convey.ShouldEqual, 2)
			convey.So(out.List[0].RuleType, convey.ShouldEqual, "typeA")
			convey.So(out.List[0].RuleName, convey.ShouldEqual, "rule-1")
			convey.So(out.List[1].RuleType, convey.ShouldEqual, "typeB")
			convey.So(out.List[1].RuleName, convey.ShouldEqual, "rule-2")
		})
	})
}

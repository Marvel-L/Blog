package approval_rule

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	v2 "code.byted.org/gopkg/gorm/v2"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

func Test_GetApprovalRuleDetailReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("权限校验失败：当前用户未登录", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 不设置用户，触发未登录分支
			ctx := context.Background()
			req := &GetApprovalRuleDetailReq{RuleID: 1}

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "用户未登录")
		})
	})

	t.Run("查询规则失败：规则不存在", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 设置管理员用户使权限通过
			ctx := context.WithValue(context.Background(), constants.CtxCurrentUser, &model.Account{
				AccountType: constants.AccountTypeAdmin,
			})
			req := &GetApprovalRuleDetailReq{RuleID: 123}

			// 初始化并mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()
			// Mock 规则查询失败
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(
				(*model.ApprovalRule)(nil), pkg_errors.NewRecordNotFoundErr("规则不存在"),
			).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "规则不存在")
		})
	})

	t.Run("规则详情解析失败：JSON不合法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 设置管理员用户使权限通过
			ctx := context.WithValue(context.Background(), constants.CtxCurrentUser, &model.Account{
				AccountType: constants.AccountTypeAdmin,
			})
			req := &GetApprovalRuleDetailReq{RuleID: 456}

			// 初始化并mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()
			// 返回非法JSON的规则详情，触发解析报错
			badRule := &model.ApprovalRule{
				RuleType:   "T",
				RuleName:   "N",
				RuleStatus: "S",
				RuleDetail: "{", // 非法JSON
			}
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(
				badRule, nil,
			).Build()

			resp, err := req.Handle(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			// 断言JSON解析错误信息
			convey.So(err.Error(), convey.ShouldContainSubstring, "unexpected end of JSON input")
		})
	})

	t.Run("成功返回规则详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 设置管理员用户使权限通过
			ctx := context.WithValue(context.Background(), constants.CtxCurrentUser, &model.Account{
				AccountType: constants.AccountTypeAdmin,
			})
			req := &GetApprovalRuleDetailReq{RuleID: 789}

			// 初始化并mock DBProxy.NewRequest
			mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
			mockey.Mock((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()

			// 构造合法的规则详情JSON
			validJSON := `{
				"QuoteTypes": [1, 2],
				"TradeTypes": [3],
				"FormField": "字段",
				"MonitorType": "typeA",
				"MonitorScope": "scopeX",
				"IsIntervalMode": true,
				"LowerCompareRules": ["all_greater"],
				"UpperCompareRules": ["all_less_or_equal"],
				"CustomScopes": [
					{ "LeftValue": null, "MonitorFuncType": "func", "RightValues": null }
				],
				"QuoteMonitorConfig": {
					"MonitorFuncType": "gt",
					"MonitorThreshold": "100.5",
					"MonitorExtra": "extra"
				},
				"ProductLineMonitorConfigs": [
					{ "DepartmentName": "dep1", "BizLineName": "biz1",
					  "ThresholdConfig": { "MonitorFuncType": "gt", "MonitorThreshold": "200", "MonitorExtra": "ex2" } }
				],
				"TradeProductMonitorConfigs": [
					{
					  "ProductCode": "P",
					  "ProductName": "Name",
					  "ConfigurationCode": "CfgC",
					  "ConfigurationName": "CfgN",
					  "ChargeItemCode": "C",
					  "ChargeItemName": "CN",
					  "ThresholdConfig": { "MonitorFuncType": "lt", "MonitorThreshold": "300", "MonitorExtra": "ex3" }
					}
				]
			}`
			okRule := &model.ApprovalRule{
				BaseDB:     framework.BaseDB{Id: 789},
				RuleType:   "RULE_T",
				RuleName:   "RULE_N",
				RuleStatus: "enabled",
				RuleDetail: validJSON,
			}
			mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(
				okRule, nil,
			).Build()

			respI, err := req.Handle(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(respI, convey.ShouldNotBeNil)

			resp := respI.(*GetApprovalRuleDetailResp)
			convey.So(resp.RuleID, convey.ShouldEqual, 789)
			convey.So(resp.RuleType, convey.ShouldEqual, "RULE_T")
			convey.So(resp.RuleName, convey.ShouldEqual, "RULE_N")
			convey.So(resp.RuleStatus, convey.ShouldEqual, "enabled")
			convey.So(resp.QuoteTypes, convey.ShouldResemble, []int{1, 2})
			convey.So(resp.TradeTypes, convey.ShouldResemble, []int{3})
			convey.So(resp.FormField, convey.ShouldEqual, "字段")
			convey.So(resp.MonitorType, convey.ShouldEqual, "typeA")
			convey.So(resp.MonitorScope, convey.ShouldEqual, "scopeX")
			convey.So(resp.IsIntervalMode, convey.ShouldBeTrue)
			convey.So(resp.LowerCompareRules, convey.ShouldResemble, []string{"all_greater"})
			convey.So(resp.UpperCompareRules, convey.ShouldResemble, []string{"all_less_or_equal"})
			convey.So(resp.CustomScopes, convey.ShouldNotBeNil)
			convey.So(len(resp.CustomScopes), convey.ShouldEqual, 1)
			convey.So(resp.QuoteMonitorConfig, convey.ShouldNotBeNil)
			convey.So(resp.QuoteMonitorConfig.MonitorFuncType, convey.ShouldEqual, "gt")
			convey.So(resp.ProductLineMonitorConfigs, convey.ShouldNotBeNil)
			convey.So(len(resp.ProductLineMonitorConfigs), convey.ShouldEqual, 1)
			convey.So(resp.ProductLineMonitorConfigs[0].DepartmentName, convey.ShouldEqual, "dep1")
			convey.So(resp.TradeProductMonitorConfigs, convey.ShouldNotBeNil)
			convey.So(len(resp.TradeProductMonitorConfigs), convey.ShouldEqual, 1)
			convey.So(resp.TradeProductMonitorConfigs[0].ProductCode, convey.ShouldEqual, "P")
		})
	})
}

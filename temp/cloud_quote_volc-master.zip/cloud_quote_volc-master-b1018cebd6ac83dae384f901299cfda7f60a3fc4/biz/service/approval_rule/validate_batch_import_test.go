package approval_rule

import (
	"context"
	"errors"
	"testing"

	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/fileparser"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_parser"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	errors001 "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_ValidateApprovalRuleBatchImportReq_validateProductConfigAndChargeItem_BitsUTGen(t *testing.T) {
	t.Run("配置与计费项均为所有选项直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备最简单场景，直接走早返回分支
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: constants.SelectAll,
				ChargeItemCode:    constants.SelectAll,
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tp",
			}
			var rowErrors []string

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(rowErrors), convey.ShouldEqual, 0)
		})
	})

	t.Run("获取商品配置容器失败跳过校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 容器获取失败，触发日志告警并直接返回
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: "cfgA",
				ChargeItemCode:    "ciA",
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpA",
			}
			var rowErrors []string

			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(nil, errors.New("container error")).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(rowErrors), convey.ShouldEqual, 0)
		})
	})

	t.Run("配置不存在与计费项获取keys失败导致不存在错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置不存在 + 计费项keys获取失败 + 关联关系不存在
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: "cfgB",
				ChargeItemCode:    "ciB",
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpB",
			}
			var rowErrors []string

			container := &product_config_load.ConfigContainer{}
			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigInfoFromCache).Return((*product_config_load.ConfigurationInfo)(nil)).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetChargeItemKeyListFromHash).Return([]string(nil), errors.New("redis failed")).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigNodeListWithoutFilter).Return([]*product_config_parser.ConfigNode(nil)).Build()
			mockey.MockUnsafe(ValidateTradeProductConfigAndChargeItem).Return(nil).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(rowErrors, convey.ShouldContain, "该配置不存在")
			convey.So(rowErrors, convey.ShouldContain, "该计费项不存在")
			convey.So(rowErrors, convey.ShouldContain, "该计费项不属于指定配置")
		})
	})

	t.Run("计费项存在且关联关系存在，无任何错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置存在，计费项存在，关联关系存在，最终无错误
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: "cfgC",
				ChargeItemCode:    "ci_exists",
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpC",
			}
			var rowErrors []string

			container := &product_config_load.ConfigContainer{}
			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigInfoFromCache).Return(&product_config_load.ConfigurationInfo{}).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetChargeItemKeyListFromHash).Return([]string{
				"tpC::cfgC::ci_exists", "tpC::cfgX::ciX",
			}, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigNodeListWithoutFilter).Return([]*product_config_parser.ConfigNode{
				{NodeName: "ok"},
			}).Build()
			mockey.MockUnsafe(ValidateTradeProductConfigAndChargeItem).Return(nil).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(rowErrors), convey.ShouldEqual, 0)
		})
	})

	t.Run("计费项未匹配且关联关系缺失且公私云校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 计费项keys可获取但不匹配 + 关联关系缺失 + 公私云校验返回错误
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: "cfgD",
				ChargeItemCode:    "ciD",
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpD",
			}
			var rowErrors []string

			container := &product_config_load.ConfigContainer{}
			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigInfoFromCache).Return(&product_config_load.ConfigurationInfo{}).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetChargeItemKeyListFromHash).Return([]string{
				"tpD::cfgD::other", "tpD::cfgX::ciX",
			}, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigNodeListWithoutFilter).Return([]*product_config_parser.ConfigNode(nil)).Build()
			mockey.MockUnsafe(ValidateTradeProductConfigAndChargeItem).Return(errors.New("校验失败：商品计费项不能为空")).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(rowErrors, convey.ShouldContain, "该计费项不存在")
			convey.So(rowErrors, convey.ShouldContain, "该计费项不属于指定配置")
			convey.So(rowErrors, convey.ShouldContain, "校验失败：商品计费项不能为空")
		})
	})

	t.Run("仅配置非所有选项计费项为所有选项触发公私云校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置非所有选项且存在，计费项为所有选项跳过计费项与关联校验，仅进行公私云校验
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: "cfgE",
				ChargeItemCode:    constants.SelectAll,
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpE",
			}
			var rowErrors []string

			container := &product_config_load.ConfigContainer{}
			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetConfigInfoFromCache).Return(&product_config_load.ConfigurationInfo{}).Build()
			mockey.MockUnsafe(ValidateTradeProductConfigAndChargeItem).Return(nil).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(rowErrors), convey.ShouldEqual, 0)
		})
	})

	t.Run("仅计费项非所有选项配置为所有选项校验计费项存在性", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 配置为所有选项跳过配置校验，计费项非所有选项但未匹配成功，关联关系不校验
			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ConfigurationCode: constants.SelectAll,
				ChargeItemCode:    "ciF",
			}
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     0,
				StandardProduct: 0,
				TradeProduct:    "tpF",
			}
			var rowErrors []string

			container := &product_config_load.ConfigContainer{}
			mockey.MockUnsafe(product_config_load.GetConfigContainer).Return(container, nil).Build()
			mockey.MockUnsafe((*product_config_load.ConfigContainer).GetChargeItemKeyListFromHash).Return([]string{
				"tpF::cfgY::ciY", "tpF::cfgZ::ciZ",
			}, nil).Build()
			mockey.MockUnsafe(ValidateTradeProductConfigAndChargeItem).Return(nil).Build()

			err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors)

			convey.So(err, convey.ShouldBeNil)
			convey.So(rowErrors, convey.ShouldContain, "该计费项不存在")
			convey.So(len(rowErrors), convey.ShouldEqual, 1)
		})
	})
}

func Test_getProductLineMap_BitsUTGen(t *testing.T) {
	t.Run("一级产品线缓存查询失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当查询一级产品线时返回错误
			mockey.MockUnsafe(product_service.ListDepartmentInfoFromCache).
				When(func(ctx context.Context, level int) bool { return level == 1 }).
				Return(nil, errors.New("first level redis error")).
				Build()

			ctx := context.Background()
			gotMap, err := getProductLineMap(ctx)

			// 断言错误返回
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "first level redis error")
			convey.So(gotMap, convey.ShouldBeNil)
		})
	})

	t.Run("二级产品线缓存查询失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 一级产品线返回正常数据
			firstLevels := []*product_service.DepartmentInfo{
				{ID: 100, Name: "一线X"},
			}
			// 二级产品线返回错误
			mockey.MockUnsafe(product_service.ListDepartmentInfoFromCache).
				When(func(ctx context.Context, level int) bool { return level == 1 }).
				Return(firstLevels, nil).
				When(func(ctx context.Context, level int) bool { return level == 2 }).
				Return(nil, errors.New("second level redis error")).
				Build()

			ctx := context.Background()
			gotMap, err := getProductLineMap(ctx)

			// 断言错误返回
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "second level redis error")
			convey.So(gotMap, convey.ShouldBeNil)
		})
	})

	t.Run("成功返回完整产品线映射", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造一级产品线（包含同一ID的不同名称，覆盖append逻辑）
			firstLevels := []*product_service.DepartmentInfo{
				{ID: 1, Name: "一线A"},
				{ID: 1, Name: "一线A别名"},
				{ID: 2, Name: "一线B"},
				{ID: 3, Name: "一线C"},
			}
			// 构造二级产品线，包含ParentID为0（继续分支）以及不存在父级映射的情况
			secondLevels := []*product_service.DepartmentInfo{
				{Name: "二线A1", ParentID: 1},
				{Name: "二线A2", ParentID: 1},
				{Name: "二线B1", ParentID: 2},
				{Name: "孤儿", ParentID: 999}, // 不存在的父级ID
				{Name: "无父级", ParentID: 0},  // ParentID为0应被跳过
			}

			// 正常返回一级和二级产品线数据
			mockey.MockUnsafe(product_service.ListDepartmentInfoFromCache).
				When(func(ctx context.Context, level int) bool { return level == 1 }).
				Return(firstLevels, nil).
				When(func(ctx context.Context, level int) bool { return level == 2 }).
				Return(secondLevels, nil).
				Build()

			ctx := context.Background()
			gotMap, err := getProductLineMap(ctx)

			// 成功返回
			convey.So(err, convey.ShouldBeNil)
			convey.So(gotMap, convey.ShouldNotBeNil)

			// 顶层映射包含所有一级产品线名称
			convey.So(len(gotMap), convey.ShouldEqual, 4)

			// ParentID=1的二级产品线应同时挂到“一线A”和“一线A别名”
			convey.So(gotMap["一线A"]["二线A1"], convey.ShouldBeTrue)
			convey.So(gotMap["一线A"]["二线A2"], convey.ShouldBeTrue)
			convey.So(gotMap["一线A别名"]["二线A1"], convey.ShouldBeTrue)
			convey.So(gotMap["一线A别名"]["二线A2"], convey.ShouldBeTrue)

			// ParentID=2的二级产品线仅挂到“一线B”
			convey.So(gotMap["一线B"]["二线B1"], convey.ShouldBeTrue)
			convey.So(gotMap["一线B"]["二线A1"], convey.ShouldBeFalse)

			// ParentID=0的二级产品线不会被加入
			convey.So(gotMap["一线A"]["无父级"], convey.ShouldBeFalse)

			// 不存在的父级ID不会被加入
			convey.So(gotMap["一线A"]["孤儿"], convey.ShouldBeFalse)
			convey.So(gotMap["一线B"]["孤儿"], convey.ShouldBeFalse)

			// 没有子产品线的一级产品线保持空映射
			convey.So(len(gotMap["一线C"]), convey.ShouldEqual, 0)
		})
	})
}

func Test_getMonitorPriceTypeFromChinese_BitsUTGen(t *testing.T) {
	t.Run("输入为枚举值simple_discount原样返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入为枚举值，应该原样返回
			in := multienv.SimpleDiscount
			out := getMonitorPriceTypeFromChinese(in)
			convey.So(out, convey.ShouldEqual, in)
		})
	})

	t.Run("输入为枚举值fixed_price原样返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入为枚举值，应该原样返回
			in := multienv.FixedPrice
			out := getMonitorPriceTypeFromChinese(in)
			convey.So(out, convey.ShouldEqual, in)
		})
	})

	t.Run("输入为中文‘单一折扣’返回枚举值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入为中文并带空格，应该返回单一折扣的枚举值
			in := "  " + multienv.DiscountFunctionSimpleDiscountName + "  "
			out := getMonitorPriceTypeFromChinese(in)
			convey.So(out, convey.ShouldEqual, multienv.SimpleDiscount)
		})
	})

	t.Run("输入为中文‘固定单价’返回枚举值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入为中文并带空格，应该返回固定单价的枚举值
			in := "  " + multienv.DiscountFunctionFixedPriceName + "  "
			out := getMonitorPriceTypeFromChinese(in)
			convey.So(out, convey.ShouldEqual, multienv.FixedPrice)
		})
	})

	t.Run("输入为其他字符串走默认分支并去除空格", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入为未知字符串并带空格，应该返回去除空格后的原值
			in := "  未知类型  "
			out := getMonitorPriceTypeFromChinese(in)
			convey.So(out, convey.ShouldEqual, "未知类型")
		})
	})
}

func Test_getTradeProductMap_BitsUTGen(t *testing.T) {
	t.Run("GetAllTradeProductMap返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟commodity_service返回错误
			mockey.MockUnsafe(commodity_service.GetAllTradeProductMap).Return(nil, errors.New("mock error")).Build()

			ctx := context.Background()
			result, err := getTradeProductMap(ctx)

			// 断言走错误返回分支
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock error")
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("成功返回并过滤空商品code", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造包含有效商品与空商品code的数据
			p1 := &trade_client.TradeProductVersionInfo{TradeProduct: "prodA", TradeProductName: "A"}
			p2 := &trade_client.TradeProductVersionInfo{TradeProduct: ""}
			p3 := &trade_client.TradeProductVersionInfo{TradeProduct: "prodB", TradeProductName: "B"}
			inputMap := map[string]*trade_client.TradeProductVersionInfo{
				"k1": p1,
				"k2": p2,
				"k3": p3,
			}
			mockey.MockUnsafe(commodity_service.GetAllTradeProductMap).Return(inputMap, nil).Build()

			ctx := context.Background()
			result, err := getTradeProductMap(ctx)

			// 断言成功返回，并且空商品code被过滤
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result["prodA"], convey.ShouldEqual, p1)
			convey.So(result["prodB"], convey.ShouldEqual, p3)
			_, exists := result[""]
			convey.So(exists, convey.ShouldBeFalse)
		})
	})

	t.Run("成功返回空输入map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟返回nil输入map
			mockey.MockUnsafe(commodity_service.GetAllTradeProductMap).Return(nil, nil).Build()

			ctx := context.Background()
			result, err := getTradeProductMap(ctx)

			// 断言成功返回且结果为空map
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})
}

func Test_getApprovalRuleTypeFromChinese_BitsUTGen(t *testing.T) {
	t.Run("中文映射命中返回枚举值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入包含首尾空格的中文名，验证能返回枚举值
			input := " 出厂价利润监控 "
			got := getApprovalRuleTypeFromChinese(input)
			convey.So(got, convey.ShouldEqual, multienv.ApprovalRuleTypeProfitCalculate)
		})
	})

	t.Run("中文映射未命中则原样返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 输入非中文的枚举字符串，验证未命中映射时原样返回（同时校验去除空格）
			input := " guideline_price "
			got := getApprovalRuleTypeFromChinese(input)
			convey.So(got, convey.ShouldEqual, "guideline_price")
		})
	})
}

func Test_validateNonLegalCharacters_BitsUTGen(t *testing.T) {
	t.Run("包含英文逗号返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 将多语言错误格式化函数打桩为直接fmt.Errorf，避免外部依赖
			mockey.MockUnsafe(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error {
				return fmt.Errorf(format, a...)
			}).Build()

			ctx := context.Background()
			err := validateNonLegalCharacters(ctx, "abc,def", "xyz")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "字段包含非法字符")
			convey.So(err.Error(), convey.ShouldContainSubstring, ",")
		})
	})

	t.Run("包含中文逗号返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error {
				return fmt.Errorf(format, a...)
			}).Build()

			ctx := context.Background()
			err := validateNonLegalCharacters(ctx, "a，b")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "字段包含非法字符")
			convey.So(err.Error(), convey.ShouldContainSubstring, "，")
		})
	})

	t.Run("包含英文分号返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error {
				return fmt.Errorf(format, a...)
			}).Build()

			ctx := context.Background()
			err := validateNonLegalCharacters(ctx, "hello;world")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "字段包含非法字符")
			convey.So(err.Error(), convey.ShouldContainSubstring, ";")
		})
	})

	t.Run("包含中文分号返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error {
				return fmt.Errorf(format, a...)
			}).Build()

			ctx := context.Background()
			err := validateNonLegalCharacters(ctx, "甲；乙")
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "字段包含非法字符")
			convey.So(err.Error(), convey.ShouldContainSubstring, "；")
		})
	})

	t.Run("不包含非法字符返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error {
				return fmt.Errorf(format, a...)
			}).Build()

			ctx := context.Background()
			err := validateNonLegalCharacters(ctx, "abc", "def", "中文正常")
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_validateMonitorRuleTypeConsistency_BitsUTGen(t *testing.T) {
	t.Run("当期望类型为空时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 期望类型为空，应该直接返回nil
			ctx := context.Background()
			err := validateMonitorRuleTypeConsistency(ctx, "", "任意类型")
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("当类型一致时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 使用中文并包含空格，验证转换与去空格后类型一致返回nil
			ctx := context.Background()
			expectedType := "profit_calculate"
			actualType := " 出厂价利润监控 "
			err := validateMonitorRuleTypeConsistency(ctx, expectedType, actualType)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("当类型不一致时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 类型不一致时应返回错误，打桩i18nfmt.Errorf避免外部依赖
			mockey.MockUnsafe(i18nfmt.Errorf).Return(errors.New("mock: 导入的审批规则类型与当前规则类型不一致")).Build()

			ctx := context.Background()
			expectedType := "guideline_price"
			actualType := "出厂价利润监控" // 转换为profit_calculate，触发不一致
			err := validateMonitorRuleTypeConsistency(ctx, expectedType, actualType)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "导入的审批规则类型与当前规则类型不一致")
		})
	})
}

func Test_ValidateApprovalRuleBatchImportResp_IsSuccess_BitsUTGen(t *testing.T) {
	t.Run("接收者为nil时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当接收者为nil时，应返回false
			var r *ValidateApprovalRuleBatchImportResp
			got := r.IsSuccess()
			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("错误详情为nil时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 错误详情为nil，长度为0，应返回true
			r := &ValidateApprovalRuleBatchImportResp{ErrorDetails: nil}
			got := r.IsSuccess()
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("错误详情非空时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 错误详情存在内容，长度大于0，应返回false
			r := &ValidateApprovalRuleBatchImportResp{ErrorDetails: map[int][]string{1: {"错误信息"}}}
			got := r.IsSuccess()
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_ValidateApprovalRuleBatchImportReq_validateChargeItemPriceType_BitsUTGen(t *testing.T) {
	t.Run("当刊例价信息获取失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟获取刊例价信息失败
			mockey.Mock((*item_context.ItemContext).GetDisplayPriceInfo).Return(nil, errors.New("mock fail")).Build()

			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ProductCode:       "product",
				ConfigurationCode: "config",
				ChargeItemCode:    "charge",
			}
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 1, StandardProduct: 1}

			err := r.validateChargeItemPriceType(ctx, data, productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取计费项刊例价信息失败")
		})
	})

	t.Run("当刊例价信息不存在时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟返回nil且无错误
			mockey.Mock((*item_context.ItemContext).GetDisplayPriceInfo).Return(nil, nil).Build()

			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ProductCode:       "product",
				ConfigurationCode: "config",
				ChargeItemCode:    "charge",
			}
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 2, StandardProduct: 0}

			err := r.validateChargeItemPriceType(ctx, data, productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "计费项刊例价信息不存在")
		})
	})

	t.Run("当刊例价为阶梯价格时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟刊例价为非固定价格
			priceInfo := &item_context.ProductPriceInfo{PricingFunction: "ladder_price"}
			mockey.Mock((*item_context.ItemContext).GetDisplayPriceInfo).Return(priceInfo, nil).Build()

			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ProductCode:       "product",
				ConfigurationCode: "config",
				ChargeItemCode:    "charge",
			}
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 3, StandardProduct: 1}

			err := r.validateChargeItemPriceType(ctx, data, productInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前计费项刊例价价格类型为阶梯，不支持设置固定单价类型的指导价")
		})
	})

	t.Run("当刊例价为固定价格时校验成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟刊例价为固定价格
			priceInfo := &item_context.ProductPriceInfo{PricingFunction: constants.PricingFunctionFixedPrice}
			mockey.Mock((*item_context.ItemContext).GetDisplayPriceInfo).Return(priceInfo, nil).Build()

			ctx := context.Background()
			r := &ValidateApprovalRuleBatchImportReq{}
			data := &fileparser.UploadApprovalRuleTradeProductData{
				ProductCode:       "product",
				ConfigurationCode: "config",
				ChargeItemCode:    "charge",
			}
			productInfo := &trade_client.TradeProductVersionInfo{ProductType: 4, StandardProduct: 0}

			err := r.validateChargeItemPriceType(ctx, data, productInfo)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ValidateApprovalRuleBatchImportReq_updateLarkSheetWithErrors_BitsUTGen(t *testing.T) {
	t.Run("SpreadSheetURLParser返回错误导致提前返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟URL解析失败
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(nil, errors.New("bad url")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{
				1: {"错误A"},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "bad url")
		})
	})

	t.Run("获取表格内容失败使用默认列位置_产品线模板_并设置样式失败但不影响返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// URL解析成功
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok", SheetID: "sht"}, nil).Build()
			// 获取表格内容失败
			mockey.Mock(lark_client.GetSheetContent).Return(nil, nil, errors.New("fetch failed")).Build()

			// 捕获写入参数
			var capturedColumnIndex int
			var capturedRecords []map[string]interface{}
			var capturedFields []string

			mockey.Mock(lark_client.UpdateColumnDataToSheet).To(func(ctx context.Context, r *lark_client.UpdateColumnDataToSheetReq) (string, error) {
				capturedColumnIndex = r.ColumnIndex
				capturedRecords = r.Records
				capturedFields = r.Fields
				return "rangeA", nil
			}).Build()

			// 设置样式失败但不影响最终返回
			mockey.Mock(lark_client.UpdateSheetStyle).Return(errors.New("style failed")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{
				1: {"错误1", "错误2"},
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedColumnIndex, convey.ShouldEqual, 6)  // 产品线模板默认列位置
			convey.So(len(capturedRecords), convey.ShouldEqual, 1) // 仅表头
			convey.So(capturedFields, convey.ShouldResemble, []string{"errMsg"})
		})
	})

	t.Run("获取表格内容失败使用默认列位置_商品模板_设置样式成功返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok2", SheetID: "sht2"}, nil).Build()
			mockey.Mock(lark_client.GetSheetContent).Return(nil, nil, errors.New("fetch failed")).Build()

			var capturedColumnIndex int
			var capturedRecords []map[string]interface{}

			mockey.Mock(lark_client.UpdateColumnDataToSheet).To(func(ctx context.Context, r *lark_client.UpdateColumnDataToSheetReq) (string, error) {
				capturedColumnIndex = r.ColumnIndex
				capturedRecords = r.Records
				return "rangeB", nil
			}).Build()

			mockey.Mock(lark_client.UpdateSheetStyle).Return(nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleTradeProduct,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{
				1: {"X1"},
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedColumnIndex, convey.ShouldEqual, 8)  // 商品模板默认列位置
			convey.So(len(capturedRecords), convey.ShouldEqual, 1) // 仅表头
		})
	})

	t.Run("获取表格内容失败使用默认列位置_默认模板键", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok3", SheetID: "sht3"}, nil).Build()
			mockey.Mock(lark_client.GetSheetContent).Return(nil, nil, errors.New("fetch failed")).Build()

			var capturedColumnIndex int
			mockey.Mock(lark_client.UpdateColumnDataToSheet).To(func(ctx context.Context, r *lark_client.UpdateColumnDataToSheetReq) (string, error) {
				capturedColumnIndex = r.ColumnIndex
				return "rangeC", nil
			}).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: "unknown_model_key",
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedColumnIndex, convey.ShouldEqual, 8) // 默认位置
		})
	})

	t.Run("表头包含错误信息列_并写入每行错误_样式成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok4", SheetID: "sht4"}, nil).Build()
			// 行数据，第一行表头包含“错误信息”
			rows := [][]string{
				{"审批规则类型", "一级产品线", "错误信息", "其他"},
				{"row1c1", "row1c2", "", ""},
				{"row2c1", "row2c2", "", ""},
				{"row3c1", "row3c2", "", ""},
			}
			mockey.Mock(lark_client.GetSheetContent).Return(nil, rows, nil).Build()

			var capturedColumnIndex int
			var capturedRecords []map[string]interface{}

			mockey.Mock(lark_client.UpdateColumnDataToSheet).To(func(ctx context.Context, r *lark_client.UpdateColumnDataToSheetReq) (string, error) {
				capturedColumnIndex = r.ColumnIndex
				capturedRecords = r.Records
				return "rangeD", nil
			}).Build()

			mockey.Mock(lark_client.UpdateSheetStyle).Return(nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{
				1: {"E1", "E2"},
				3: {"E3"},
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedColumnIndex, convey.ShouldEqual, 3)                 // 错误信息列下标(0-based)=2 => 1-indexed=3
			convey.So(len(capturedRecords), convey.ShouldEqual, 4)                // 表头 + 3行
			convey.So(capturedRecords[0]["errMsg"], convey.ShouldEqual, "错误信息")   // 表头
			convey.So(capturedRecords[1]["errMsg"], convey.ShouldEqual, "E1; E2") // 第1行错误
			convey.So(capturedRecords[2]["errMsg"], convey.ShouldEqual, "")       // 第2行无错误
			convey.So(capturedRecords[3]["errMsg"], convey.ShouldEqual, "E3")     // 第3行错误
		})
	})

	t.Run("表头不包含错误信息列_按最后有内容列之后定位_并len(rows)==1仅写表头", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok5", SheetID: "sht5"}, nil).Build()
			// 仅一行表头，最后一个非空列在索引1(0-based)，因此列位置应为1+2=3
			rows := [][]string{
				{"审批规则类型", "一级产品线", "", ""},
			}
			mockey.Mock(lark_client.GetSheetContent).Return(nil, rows, nil).Build()

			var capturedColumnIndex int
			var capturedRecords []map[string]interface{}
			mockey.Mock(lark_client.UpdateColumnDataToSheet).To(func(ctx context.Context, r *lark_client.UpdateColumnDataToSheetReq) (string, error) {
				capturedColumnIndex = r.ColumnIndex
				capturedRecords = r.Records
				return "rangeE", nil
			}).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedColumnIndex, convey.ShouldEqual, 3)
			convey.So(len(capturedRecords), convey.ShouldEqual, 1) // 仅表头
			convey.So(capturedRecords[0]["errMsg"], convey.ShouldEqual, "错误信息")
		})
	})

	t.Run("写入数据失败提前返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(lark_client.SpreadSheetURLParser).Return(&lark_client.DocsURLInfo{SpreadSheetToken: "tok6", SheetID: "sht6"}, nil).Build()
			// 行数据，不含“错误信息”列，需计算最后非空列
			rows := [][]string{
				{"审批规则类型", ""},
				{"row1", ""},
			}
			mockey.Mock(lark_client.GetSheetContent).Return(nil, rows, nil).Build()

			// 写入数据失败
			mockey.Mock(lark_client.UpdateColumnDataToSheet).Return("", errors.New("update failed")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey: constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl: "https://feishu.cn/sheets/shtcnxx",
			}
			err := req.updateLarkSheetWithErrors(context.Background(), map[int][]string{
				1: {"x"},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update failed")
		})
	})
}

func Test_getErrorMessage_BitsUTGen(t *testing.T) {
	t.Run("错误为nil返回空字符串", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当错误为nil时，应返回空字符串
			var err error = nil
			msg := getErrorMessage(err)
			convey.So(msg, convey.ShouldEqual, "")
		})
	})
	t.Run("APIErrorStruct格式化消息提取", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当为APIErrorStruct时，返回格式化后的Message
			apiErr := &errors001.APIErrorStruct{
				Message: "校验失败: %s - %d",
				Args:    []interface{}{"ABC", 5},
			}
			msg := getErrorMessage(apiErr)
			convey.So(msg, convey.ShouldEqual, fmt.Sprintf(apiErr.Message, apiErr.Args...))
		})
	})
	t.Run("普通错误返回原始消息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非APIErrorStruct的错误，直接返回err.Error()
			normalErr := errors.New("普通错误信息")
			msg := getErrorMessage(normalErr)
			convey.So(msg, convey.ShouldEqual, "普通错误信息")
		})
	})
}

func Test_ValidateApprovalRuleBatchImportReq_Handle_BitsUTGen(t *testing.T) {
	t.Run("规则类型为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批规则类型不能为空")
		})
	})

	t.Run("监控类型为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控类型不能为空")
		})
	})

	t.Run("解析飞书表格失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟解析失败
			mockey.MockUnsafe(fileparser.Parse).Return(nil, "", fmt.Errorf("parse failed")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "parse failed")
		})
	})

	t.Run("不支持的导入类型返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟解析成功但使用不支持的ModelKey
			mockey.MockUnsafe(fileparser.Parse).Return(nil, "", nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    "unknown_model_key",
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "不支持的导入类型")
		})
	})

	t.Run("产品线模板类型断言失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 返回错误类型的数据以触发类型断言失败
			wrong := []*fileparser.UploadApprovalRuleTradeProductData{}
			mockey.MockUnsafe(fileparser.Parse).Return(wrong, "", nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "产品线数据解析错误")
		})
	})

	t.Run("产品线校验返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 正确类型数据
			pl := []*fileparser.UploadApprovalRuleProductLineData{
				{DataIndex: 1, RuleType: "指导价监控", FirstProductLineName: "A", MonitorSymbol: "<", MonitorThreshold: "10"},
			}
			mockey.MockUnsafe(fileparser.Parse).Return(pl, "", nil).Build()
			// 模拟校验失败
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).validateProductLineData).Return(nil, fmt.Errorf("validate error")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate error")
		})
	})

	t.Run("产品线校验成功但写入错误信息失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			pl := []*fileparser.UploadApprovalRuleProductLineData{
				{DataIndex: 1, RuleType: "指导价监控", FirstProductLineName: "A", MonitorSymbol: "<", MonitorThreshold: "10"},
			}
			mockey.MockUnsafe(fileparser.Parse).Return(pl, "", nil).Build()
			// 模拟校验成功返回resp
			resp := &ValidateApprovalRuleBatchImportResp{
				ErrorDetails:         map[int][]string{1: {"err1"}},
				ModelUrl:             "http://feishu.cn/sheets/shtcn123",
				ValidatedProductLine: nil,
			}
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).validateProductLineData).Return(resp, nil).Build()
			// 写入错误信息失败
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).updateLarkSheetWithErrors).Return(fmt.Errorf("write error")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleProductLine,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			rsp, ok := ret.(*ValidateApprovalRuleBatchImportResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(rsp, convey.ShouldNotBeNil)
			convey.So(rsp.ErrorDetails, convey.ShouldNotBeEmpty)
		})
	})

	t.Run("商品模板类型断言失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 返回错误类型的数据以触发类型断言失败
			wrong := []*fileparser.UploadApprovalRuleProductLineData{}
			mockey.MockUnsafe(fileparser.Parse).Return(wrong, "", nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleTradeProduct,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品数据解析错误")
		})
	})

	t.Run("商品校验返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tp := []*fileparser.UploadApprovalRuleTradeProductData{
				{DataIndex: 1, RuleType: "指导价监控", ProductCode: "p1", MonitorSymbol: "<", MonitorThreshold: "10"},
			}
			mockey.MockUnsafe(fileparser.Parse).Return(tp, "", nil).Build()
			// 模拟校验失败
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).validateTradeProductData).Return(nil, fmt.Errorf("validate trade error")).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleTradeProduct,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate trade error")
		})
	})

	t.Run("商品校验成功并写入错误信息成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			tp := []*fileparser.UploadApprovalRuleTradeProductData{
				{DataIndex: 1, RuleType: "指导价监控", ProductCode: "p1", MonitorSymbol: "<", MonitorThreshold: "10"},
			}
			mockey.MockUnsafe(fileparser.Parse).Return(tp, "", nil).Build()
			// 模拟校验成功返回resp
			resp := &ValidateApprovalRuleBatchImportResp{
				ErrorDetails:          map[int][]string{},
				ModelUrl:              "http://feishu.cn/sheets/shtcn123",
				ValidatedTradeProduct: tp,
			}
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).validateTradeProductData).Return(resp, nil).Build()
			// 写入错误信息成功
			mockey.Mock((*ValidateApprovalRuleBatchImportReq).updateLarkSheetWithErrors).Return(nil).Build()

			req := &ValidateApprovalRuleBatchImportReq{
				ModelKey:    constants.UploadModeKeyApprovalRuleTradeProduct,
				ModelUrl:    "http://feishu.cn/sheets/shtcn123",
				RuleType:    "guideline_price",
				MonitorType: "monitor_type",
			}
			ret, err := req.Handle(context.Background())
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldNotBeNil)
			rsp, ok := ret.(*ValidateApprovalRuleBatchImportResp)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(rsp, convey.ShouldNotBeNil)
			convey.So(rsp.ValidatedTradeProduct, convey.ShouldNotBeEmpty)
		})
	})
}

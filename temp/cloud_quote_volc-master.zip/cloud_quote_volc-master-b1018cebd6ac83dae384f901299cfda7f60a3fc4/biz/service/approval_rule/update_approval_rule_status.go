package approval_rule

import (
	"context"
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
)

type UpdateApprovalRuleStatusReq struct {
	approvalRulePermission
	RuleID     int64  // 规则ID
	RuleStatus string // 规则状态（要变更为的状态）
}

type UpdateApprovalRuleStatusResp struct {
	RuleID     int64  // 规则ID
	RuleStatus string // 规则状态（变更后的状态）
}

func (r *UpdateApprovalRuleStatusReq) Handle(ctx context.Context) (interface{}, error) {
	var allowedDepartments map[string]struct{}
	var departmentInfo map[string]*lark_client.DepartmentInfo
	if r.RuleStatus == multienv.ApprovalQuoteTypeEffective {
		currentUser, err := dal.AccountDao.CurrentUser(ctx)
		if err != nil {
			return nil, errors.NewUserNotFoundErr("用户未登录")
		}
		allowedDepartments, departmentInfo = loadApprovalRuleRestriction(ctx, currentUser.AccountID)
	}

	unlock, err := lockApprovalRuleOperation(ctx)
	if err != nil {
		return nil, err
	}
	defer unlock()

	tx := dal.DBProxy.NewRequest(ctx)
	ruleDB, err := dal.ApprovalRuleDao.FindRuleByID(tx, r.RuleID)
	if err != nil {
		return nil, err
	}

	// 仅本人可操作自己的规则
	if _, err := r.rulePermissionCheck(ctx, ruleDB); err != nil {
		return nil, err
	}
	if r.RuleStatus == multienv.ApprovalQuoteTypeEffective {
		if err = validateStoredApprovalRuleRestriction(ruleDB, allowedDepartments, departmentInfo); err != nil {
			return nil, err
		}
	}

	var resp interface{}
	err = tx.Transaction(func(tx *gorm.DB) error {
		resp, err = r.changeRuleStatus(ctx, tx, ruleDB)
		return err
	})

	return resp, err
}

func (r *UpdateApprovalRuleStatusReq) changeRuleStatus(ctx context.Context, tx *gorm.DB, originRuleDB *model.ApprovalRule) (*UpdateApprovalRuleStatusResp, error) {
	// 校验状态流转是否合法
	if !multienv.ApprovalRuleStatusExistBefore(r.RuleStatus, originRuleDB.RuleStatus) {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "审批规则状态不允许从【%s】变更为【%s】").WithArgs(originRuleDB.RuleStatus, r.RuleStatus)
	}

	// 根据目标状态执行不同的变更逻辑
	switch r.RuleStatus {
	case multienv.ApprovalQuoteTypeEffective:
		if err := r.changeRuleStatusEffective(ctx, tx, originRuleDB); err != nil {
			return nil, err
		}
	case multienv.ApprovalQuoteTypeExpired:
		if err := r.changeRuleStatusExpired(ctx, tx, originRuleDB); err != nil {
			return nil, err
		}
	}

	return &UpdateApprovalRuleStatusResp{
		RuleID:     r.RuleID,
		RuleStatus: r.RuleStatus,
	}, nil
}

// changeRuleStatusEffective 草稿 -> 生效中
func (r *UpdateApprovalRuleStatusReq) changeRuleStatusEffective(ctx context.Context, tx *gorm.DB, originRuleDB *model.ApprovalRule) error {
	// 在状态改为生效时，检查是否存在重复规则（兜底）
	if err := r.checkDuplicateRulesBeforeEffective(ctx, tx, originRuleDB); err != nil {
		return err
	}

	return dal.ApprovalRuleDao.UpdateRuleByIDWithStatus(tx, originRuleDB.Id, multienv.ApprovalRuleStatusInitialed, map[string]interface{}{
		"rule_status":    multienv.ApprovalQuoteTypeEffective,
		"effective_time": time.Now(),
	})
}

// changeRuleStatusExpired 生效中 -> 已失效
func (r *UpdateApprovalRuleStatusReq) changeRuleStatusExpired(ctx context.Context, tx *gorm.DB, originRuleDB *model.ApprovalRule) error {
	return dal.ApprovalRuleDao.UpdateRuleByIDWithStatus(tx, originRuleDB.Id, multienv.ApprovalQuoteTypeEffective, map[string]interface{}{
		"rule_status":    multienv.ApprovalQuoteTypeExpired,
		"effective_time": time.Time{},
	})
}

// checkDuplicateRulesBeforeEffective 兜底重复校验：在状态改为生效时检查重复规则
func (r *UpdateApprovalRuleStatusReq) checkDuplicateRulesBeforeEffective(ctx context.Context, tx *gorm.DB, originRuleDB *model.ApprovalRule) error {
	// 解析当前规则详情
	ruleDetail, err := originRuleDB.GetApprovalRuleDetail()
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "规则详情解析失败")
	}

	// 复用现有的重复校验逻辑
	tempReq := &UpsertApprovalRuleReq{
		RuleID:                     originRuleDB.Id,
		QuoteTypes:                 ruleDetail.QuoteTypes,
		TradeTypes:                 ruleDetail.TradeTypes,
		FormField:                  ruleDetail.FormField,
		RuleType:                   ruleDetail.RuleType,
		RuleName:                   ruleDetail.RuleName,
		MonitorType:                ruleDetail.MonitorType,
		MonitorScope:               ruleDetail.MonitorScope,
		CustomScopes:               ruleDetail.CustomScopes,
		QuoteMonitorConfig:         ruleDetail.QuoteMonitorConfig,
		ProductLineMonitorConfigs:  ruleDetail.ProductLineMonitorConfigs,
		TradeProductMonitorConfigs: ruleDetail.TradeProductMonitorConfigs,
	}

	// 先进行内部重复校验：产品线配置和商品配置
	if err := tempReq.checkInternalDuplicate(ctx); err != nil {
		return err
	}

	// 调用现有的重复校验逻辑（排除当前规则ID）
	repeatRules, err := tempReq.checkDuplicateRules(ctx, tx, originRuleDB.Id)
	if err != nil {
		return err
	}

	// 如果存在重复规则，返回错误
	if len(repeatRules) > 0 {
		ruleIDsStr := buildDuplicateRuleIDsString(repeatRules)
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "当前审批规则和其他规则%s存在重复").WithArgs(ruleIDsStr)
	}

	return nil
}

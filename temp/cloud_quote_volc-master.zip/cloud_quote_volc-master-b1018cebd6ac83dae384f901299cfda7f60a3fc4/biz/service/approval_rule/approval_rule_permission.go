package approval_rule

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type approvalRulePermission struct {
}

// userPermissionCheck 当前用户是否允许操作审批规则（菜单权限：仅超管可见、可查询）
func (p approvalRulePermission) userPermissionCheck(ctx context.Context) (*model.Account, error) {
	currentUser, err := dal.AccountDao.CurrentUser(ctx)
	if err != nil {
		return nil, errors.NewUserNotFoundErr("用户未登录")
	}
	if !currentUser.AccountType.CanOperateApprovalRule() {
		return currentUser, errors.NewUserNoPermissionErr("当前用户没有审批规则操作权限")
	}
	return currentUser, nil
}

// rulePermissionCheck 当前用户是否允许操作入参审批规则（编辑/生效/失效他人规则需要权限校验）
func (p approvalRulePermission) rulePermissionCheck(ctx context.Context, ruleDB *model.ApprovalRule) (*model.Account, error) {
	currentUser, err := p.userPermissionCheck(ctx)
	if err != nil {
		return currentUser, err
	}
	// 只有规则创建人可以编辑/生效/失效自己的规则
	if ruleDB.CreatorEmail != currentUser.AccountID {
		return currentUser, errors.NewUserNoPermissionErr("当前用户没有此审批规则操作权限，规则ID：%d").WithArgs(ruleDB.Id)
	}
	return currentUser, nil
}

package approval_rule

import (
	"context"
	"sort"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/gopkg/logs"
)

func loadApprovalRuleRestriction(
	ctx context.Context,
	operatorEmail string,
) (map[string]struct{}, map[string]*lark_client.DepartmentInfo) {
	if isEmailInWhiteList(operatorEmail, config.GetSwitchWhiteList(ctx, config.SwitchApprovalRuleOperatorWhitelist)) {
		return nil, nil
	}

	allowedDepartments := normalizedWhiteList(
		config.GetSwitchWhiteList(ctx, config.SwitchApprovalRuleApplicantDepartmentWhitelist),
	)
	if len(allowedDepartments) == 0 {
		logs.CtxWarn(ctx, "approval rule applicant department whitelist is empty, skip restriction")
		return nil, nil
	}

	departmentInfo, err := product_service.GetOrganizationDepartmentInfoFromCache(ctx)
	if err != nil {
		logs.CtxWarn(ctx, "get organization department info failed, skip approval rule restriction, err=%v", err)
		return nil, nil
	}
	if len(departmentInfo) == 0 {
		logs.CtxWarn(ctx, "organization department info is empty, skip approval rule restriction")
		return nil, nil
	}
	return allowedDepartments, departmentInfo
}

func validateApprovalRuleRestriction(
	customScopes []*model.MonitorScopeConfig,
	allowedDepartments map[string]struct{},
	departmentInfo map[string]*lark_client.DepartmentInfo,
) error {
	if len(allowedDepartments) == 0 || len(departmentInfo) == 0 {
		return nil
	}

	applicantScopeFound := false
	hasInvalidDepartment := false
	for _, scope := range customScopes {
		if scope == nil || scope.LeftValue == nil ||
			scope.LeftValue.Value != multienv.ApprovalCustomScopeApplicantSalesDepartment {
			continue
		}

		applicantScopeFound = true
		if len(scope.RightValues) == 0 {
			return errors.NewBizErrWithMsg(
				errors.CodeNApprovalRuleParamIllegal,
				"受限操作人配置审批规则时，【申请人（销售）所属销售团队】不能为空",
			)
		}
		for _, rightValue := range scope.RightValues {
			departmentName, resolved := resolveDepartmentNamePath(rightValue, departmentInfo)
			if !resolved {
				hasInvalidDepartment = true
				continue
			}
			if _, ok := allowedDepartments[departmentName]; !ok {
				hasInvalidDepartment = true
			}
		}
	}

	if !applicantScopeFound {
		return errors.NewBizErrWithMsg(
			errors.CodeNApprovalRuleParamIllegal,
			"受限操作人配置审批规则时，必须配置【申请人（销售）所属销售团队】",
		)
	}
	if hasInvalidDepartment {
		return errors.NewBizErrWithMsg(
			errors.CodeNApprovalRuleParamIllegal,
			"受限操作人配置审批规则时，【申请人（销售）所属销售团队】仅允许选择：%s",
		).WithArgs(strings.Join(sortedSetValues(allowedDepartments), "、"))
	}
	return nil
}

func validateStoredApprovalRuleRestriction(
	rule *model.ApprovalRule,
	allowedDepartments map[string]struct{},
	departmentInfo map[string]*lark_client.DepartmentInfo,
) error {
	if len(allowedDepartments) == 0 || len(departmentInfo) == 0 {
		return nil
	}
	ruleDetail, err := rule.GetApprovalRuleDetail()
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "规则详情解析失败")
	}
	return validateApprovalRuleRestriction(ruleDetail.CustomScopes, allowedDepartments, departmentInfo)
}

func isEmailInWhiteList(email string, whiteList []string) bool {
	email = strings.TrimSpace(email)
	if email == "" {
		return false
	}
	for _, whiteEmail := range whiteList {
		whiteEmail = strings.TrimSpace(whiteEmail)
		if whiteEmail != "" && strings.EqualFold(whiteEmail, email) {
			return true
		}
	}
	return false
}

func normalizedWhiteList(whiteList []string) map[string]struct{} {
	values := make(map[string]struct{}, len(whiteList))
	for _, value := range whiteList {
		value = strings.TrimSpace(value)
		if value != "" {
			values[value] = struct{}{}
		}
	}
	return values
}

func resolveDepartmentNamePath(
	rightValue *model.MonitorValueConfig,
	departmentInfo map[string]*lark_client.DepartmentInfo,
) (string, bool) {
	if rightValue == nil {
		return "", false
	}

	departmentIDPath := strings.Split(strings.TrimSpace(rightValue.ValueDesc), "/")
	for i := range departmentIDPath {
		departmentIDPath[i] = strings.TrimSpace(departmentIDPath[i])
		if departmentIDPath[i] == "" {
			return "", false
		}
	}
	if strings.TrimSpace(rightValue.Value) != departmentIDPath[len(departmentIDPath)-1] {
		return "", false
	}

	departmentNamePath := ""
	foundKnownDepartment := false
	for _, departmentID := range departmentIDPath {
		info, ok := departmentInfo[departmentID]
		if !ok || info == nil || strings.TrimSpace(info.Name) == "" {
			// 组织架构缓存可能不包含指定根部门之外的上级节点。
			if !foundKnownDepartment {
				continue
			}
			return "", false
		}
		foundKnownDepartment = true
		departmentNamePath = strings.TrimSpace(info.Name)
	}
	return departmentNamePath, departmentNamePath != ""
}

func sortedSetValues(values map[string]struct{}) []string {
	result := make([]string, 0, len(values))
	for value := range values {
		result = append(result, value)
	}
	sort.Strings(result)
	return result
}

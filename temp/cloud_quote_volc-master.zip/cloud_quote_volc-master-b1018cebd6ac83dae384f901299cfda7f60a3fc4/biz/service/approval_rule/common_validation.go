package approval_rule

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// ValidateMonitorThresholdString 校验监控阈值字符串
func ValidateMonitorThresholdString(thresholdStr string, allowZero bool) error {
	if thresholdStr == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "监控阈值不能为空")
	}

	// 解析为decimal进行校验
	threshold, err := decimal.NewFromString(thresholdStr)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "监控阈值格式错误：%s").WithArgs(thresholdStr)
	}

	// 校验负数
	if threshold.IsNegative() {
		if allowZero {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "监控阈值仅支持输入0或正数")
		} else {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "监控阈值仅支持输入正数")
		}
	}

	// 校验0值（当不允许0时）
	if !allowZero && threshold.IsZero() {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "监控阈值仅支持输入正数")
	}

	return nil
}

// ValidateTradeProductConfigAndChargeItem 校验商品配置和计费项
func ValidateTradeProductConfigAndChargeItem(ctx context.Context, productCode, configCode, chargeItemCode string) error {
	// 获取商品信息，判断是公有云还是私有云
	productInfo, err := commodity_service.GetProductInfoFromCache(ctx, productCode)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "获取商品信息失败：%s").WithArgs(err.Error())
	}

	// 计费项不能为空
	if chargeItemCode == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "商品计费项不能为空")
	}

	// 私有云商品：配置必须为空
	if productInfo.ProductType == int(multienv.TradeProductDeploymentTypePrivate) &&
		configCode != "" && configCode != constants.SelectAll {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "私有云商品配置必须为空")
	}

	return nil
}

// ValidateMonitorSymbol 校验监控符号是否符合规则要求
// 根据监控类型和FormField校验符号的合法性
// ruleType: 审批规则类型，用于判断是否为商务优惠（商务优惠支持所有监控符号）
func ValidateMonitorSymbol(monitorType, formField, symbol string, ruleType ...string) error {
	return nil
}

// ValidateChargeItemPriceTypeForFixedPrice 校验计费项刊例价价格类型（用于固定单价类型）
// 当选择固定单价类型时，计费项的刊例价必须是固定价格类型，不能是阶梯价格
func ValidateChargeItemPriceTypeForFixedPrice(ctx context.Context, productCode, configCode, chargeItemCode string, productInfo *trade_client.TradeProductVersionInfo) error {
	itemCtx := &item_context.ItemContext{
		TradeProduct:      productCode,
		ConfigurationCode: configCode,
		ChargeItemCode:    chargeItemCode,
		SellingModeCode:   multienv.SellingModeCalculateCostInstance, // 使用默认售卖模式
		ProductType:       constants.ProductType(productInfo.ProductType),
		StandardProduct:   productInfo.StandardProduct,
	}

	// 获取计费项刊例价价格信息
	priceInfo, err := itemCtx.GetDisplayPriceInfo(ctx)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "获取计费项刊例价信息失败：%s").WithArgs(err.Error())
	}

	if priceInfo == nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "计费项刊例价信息不存在")
	}

	if priceInfo.PricingFunction != constants.PricingFunctionFixedPrice {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "当前计费项刊例价价格类型为阶梯，不支持设置固定单价类型的指导价")
	}

	return nil
}

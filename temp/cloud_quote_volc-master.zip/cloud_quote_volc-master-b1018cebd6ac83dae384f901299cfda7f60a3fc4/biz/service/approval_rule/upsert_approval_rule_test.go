package approval_rule

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkg_errors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/lang/gg/gptr"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

// 辅助方法：构造一个监控范围配置
//
//go:noinline
func newScope(scopeType string, rightValues []string) *model.MonitorScopeConfig {
	rvs := make([]*model.MonitorValueConfig, 0, len(rightValues))
	for _, v := range rightValues {
		rvs = append(rvs, gptr.Of(model.MonitorValueConfig{Value: v}))
	}
	return &model.MonitorScopeConfig{
		LeftValue:   gptr.Of(model.MonitorValueConfig{Value: scopeType}),
		RightValues: rvs,
	}
}

// 辅助方法：构造一个右值为空的监控范围配置
//
//go:noinline
func newScopeEmpty(scopeType string) *model.MonitorScopeConfig {
	return &model.MonitorScopeConfig{
		LeftValue:   gptr.Of(model.MonitorValueConfig{Value: scopeType}),
		RightValues: []*model.MonitorValueConfig{},
	}
}
func Test_UpsertApprovalRuleReq_hasCustomScopesIntersection_BitsUTGen(t *testing.T) {
	t.Run("同时无任何自定义范围时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 两侧自定义范围都为空
			req := &UpsertApprovalRuleReq{
				CustomScopes: nil,
			}
			existing := &model.ApprovalRuleDetail{
				CustomScopes: nil,
			}

			got := req.hasCustomScopesIntersection(existing)
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("存在类型但无交集时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 两侧都有同一类型，但右值完全无交集
			req := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					newScope("type1", []string{"A", "B"}),
				},
			}
			existing := &model.ApprovalRuleDetail{
				CustomScopes: []*model.MonitorScopeConfig{
					newScope("type1", []string{"C"}),
				},
			}

			got := req.hasCustomScopesIntersection(existing)
			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("一侧缺失类型视为所有，另一类型有交集返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 一侧缺失某类型，另一类型有交集，整体应返回true
			req := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					newScope("type2", []string{"X"}),      // existing缺失该类型
					newScope("type3", []string{"Y", "Z"}), // 与existing有交集Y
				},
			}
			existing := &model.ApprovalRuleDetail{
				CustomScopes: []*model.MonitorScopeConfig{
					newScope("type3", []string{"Y"}), // 与req的type3有交集
				},
			}

			got := req.hasCustomScopesIntersection(existing)
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("当前规则某类型右值为空视为所有，最终返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当前规则某类型右值为空（视为所有），另一类型有交集
			req := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					newScopeEmpty("type4"),                // 空表示所有
					newScope("type5", []string{"M", "N"}), // 与existing有交集M
				},
			}
			existing := &model.ApprovalRuleDetail{
				CustomScopes: []*model.MonitorScopeConfig{
					newScope("type4", []string{"P"}), // 与空的type4继续
					newScope("type5", []string{"M"}), // 与req有交集M
				},
			}

			got := req.hasCustomScopesIntersection(existing)
			convey.So(got, convey.ShouldBeTrue)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkInternalDuplicate_BitsUTGen(t *testing.T) {
	t.Run("产品线重复返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造产品线重复的配置，触发错误返回
			ctx := context.Background()
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "一级A", BizLineName: "二级A"},
					{DepartmentName: "一级A", BizLineName: "二级A"}, // 重复
				},
			}

			err := req.checkInternalDuplicate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			// 使用err.Error()进行错误信息断言，避免GetMessage(nil)导致空指针
			convey.So(err.Error(), convey.ShouldContainSubstring, "产品线监控配置")
			if apiErr, ok := err.(hertz.APIError); ok {
				convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleParamIllegal))
				args := apiErr.GetArgs()
				convey.So(len(args), convey.ShouldEqual, 2)
				convey.So(fmt.Sprintf("%v", args[0]), convey.ShouldEqual, "一级A")
				convey.So(fmt.Sprintf("%v", args[1]), convey.ShouldEqual, "二级A")
			}
		})
	})

	t.Run("产品线无重复返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造产品线无重复的配置，期望返回nil
			ctx := context.Background()
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "一级A", BizLineName: "二级A"},
					{DepartmentName: "一级A", BizLineName: "二级B"},
				},
			}

			err := req.checkInternalDuplicate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("商品维度重复返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造商品维度重复，触发错误返回
			ctx := context.Background()
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "pA", ConfigurationCode: "cfgA", ChargeItemCode: "charge1"},
					{ProductCode: "pA", ConfigurationCode: "cfgA", ChargeItemCode: "charge1"}, // 重复
				},
			}

			err := req.checkInternalDuplicate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			// 使用err.Error()进行错误信息断言，避免GetMessage(nil)导致空指针
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品监控配置")
			if apiErr, ok := err.(hertz.APIError); ok {
				convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleParamIllegal))
				args := apiErr.GetArgs()
				convey.So(len(args), convey.ShouldEqual, 3)
				convey.So(fmt.Sprintf("%v", args[0]), convey.ShouldEqual, "pA")
				convey.So(fmt.Sprintf("%v", args[1]), convey.ShouldEqual, "cfgA")
				convey.So(fmt.Sprintf("%v", args[2]), convey.ShouldEqual, "charge1")
			}
		})
	})

	t.Run("商品维度无重复返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造商品维度不重复，期望返回nil
			ctx := context.Background()
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "pA", ConfigurationCode: "cfgA", ChargeItemCode: "charge1"},
					{ProductCode: "pA", ConfigurationCode: "cfgA", ChargeItemCode: "charge2"},
				},
			}

			err := req.checkInternalDuplicate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("监控范围不匹配返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 监控范围不匹配，两个分支都不进入，期望返回nil
			ctx := context.Background()
			req := &UpsertApprovalRuleReq{
				MonitorScope:               "unknown_scope",
				ProductLineMonitorConfigs:  []*model.ProductLineMonitorConfig{},
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{},
			}

			err := req.checkInternalDuplicate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_hasBasicFieldsIntersection_BitsUTGen(t *testing.T) {
	t.Run("报价类型无交集返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 报价类型无交集，其他字段保持一致
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{2},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{3},
				TradeTypes:   []int{2},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("客户类型无交集返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 报价类型有交集，客户类型无交集
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("表单字段不一致返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 报价类型与客户类型都有交集，表单字段不一致
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4, 5},
				FormField:    "F1",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 6},
				FormField:    "F2",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("审批规则类型不一致返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 前三项一致，审批规则类型不一致
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4, 5},
				FormField:    "F",
				RuleType:     "RT1",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 6},
				FormField:    "F",
				RuleType:     "RT2",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("监控范围不一致返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 前四项一致，监控范围不一致
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4, 5},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS1",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 6},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS2",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("监控类型不一致返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 前五项一致，监控类型不一致
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4, 5},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT1",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 6},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT2",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("所有基础字段均有交集返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有字段均一致且有交集
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{4, 5},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 6},
				FormField:    "F",
				RuleType:     "RT",
				MonitorScope: "MS",
				MonitorType:  "MT",
			}

			ret := r.hasBasicFieldsIntersection(existing)
			convey.So(ret, convey.ShouldBeTrue)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkAndFixMonitorFuncType_BitsUTGen(t *testing.T) {
	t.Run("默认类型返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：未知规则类型，函数直接返回nil
			ctx := context.Background()
			r := &UpsertApprovalRuleReq{
				RuleType: "unknown_type",
			}

			err := r.checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("跨三档量价区间修正整单阈值配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：跨三档量价区间，整单配置会被统一覆盖
			ctx := context.Background()
			r := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeExceedThreeQuantity,
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType: multienv.ApprovalMonitorFuncLessThan,
				},
			}

			err := r.checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(r.QuoteMonitorConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(r.QuoteMonitorConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("跨三档量价区间修正商品阈值配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeExceedThreeQuantity,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "p1"},
					{ProductCode: "p2"},
				},
			}

			err := r.checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(r.TradeProductMonitorConfigs[0].ThresholdConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(r.TradeProductMonitorConfigs[1].ThresholdConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("跨三档量价区间修正产品线阈值配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeExceedThreeQuantity,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "一级产品线A"},
					{DepartmentName: "一级产品线B"},
				},
			}

			err := r.checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(r.ProductLineMonitorConfigs[0].ThresholdConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(r.ProductLineMonitorConfigs[1].ThresholdConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("商务优惠类型透传校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeBusinessDiscount,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
			}

			err := r.checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "仅支持【产品线】监控范围")
		})
	})

	t.Run("指导价监控透传校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			mockey.Mock((*UpsertApprovalRuleReq).checkGuidelinePriceMonitorFunc).Return(errors.New("guideline error")).Build()

			err := (&UpsertApprovalRuleReq{RuleType: multienv.ApprovalRuleTypeGuidelinePrice}).checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "guideline error")
		})
	})

	t.Run("出厂价利润监控透传校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			mockey.Mock((*UpsertApprovalRuleReq).checkProfitCalculateMonitorFunc).Return(errors.New("profit error")).Build()

			err := (&UpsertApprovalRuleReq{RuleType: multienv.ApprovalRuleTypeProfitCalculate}).checkAndFixMonitorFuncType(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "profit error")
		})
	})
}

// 这里的测试覆盖 getRepeatKeys 的所有分支，包括有无自定义范围两种情况
func Test_UpsertApprovalRuleReq_getRepeatKeys_BitsUTGen(t *testing.T) {
	t.Run("无自定义范围时返回固定键集合", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求结构体
			r := &UpsertApprovalRuleReq{}

			// 使用指针工具设置字符串字段的值
			formFieldPtr := gptr.Of("FormA")
			ruleTypePtr := gptr.Of("RuleX")
			monitorScopePtr := gptr.Of("ScopeAll")
			monitorTypePtr := gptr.Of("TypePrice")

			// 构造规则详情，无自定义范围
			existingDetail := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{3, 4},
				FormField:    *formFieldPtr,
				RuleType:     *ruleTypePtr,
				MonitorScope: *monitorScopePtr,
				MonitorType:  *monitorTypePtr,
				// CustomScopes 为 nil，覆盖分支 len(existingDetail.CustomScopes) == 0
			}

			// 调用目标方法
			keys := r.getRepeatKeys(existingDetail)

			// 期望结果为固定六个键
			expected := []string{
				fmt.Sprintf("报价类型:%v", existingDetail.QuoteTypes),
				fmt.Sprintf("客户类型:%v", existingDetail.TradeTypes),
				fmt.Sprintf("表单字段:%s", existingDetail.FormField),
				fmt.Sprintf("审批规则类型:%s", existingDetail.RuleType),
				fmt.Sprintf("监控范围:%s", existingDetail.MonitorScope),
				fmt.Sprintf("监控类型:%s", existingDetail.MonitorType),
			}

			// 断言结果
			convey.So(keys, convey.ShouldResemble, expected)
			convey.So(len(keys), convey.ShouldEqual, 6)
		})
	})

	t.Run("存在自定义范围时返回固定键与自定义范围键", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求结构体
			r := &UpsertApprovalRuleReq{}

			// 构造包含自定义范围的详情
			existingDetail := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{9},
				TradeTypes:   []int{}, // 空切片用于验证格式 "%v" 输出为 "[]"
				FormField:    "FormB",
				RuleType:     "RuleY",
				MonitorScope: "ScopeCustom",
				MonitorType:  "TypeRisk",
				CustomScopes: []*model.MonitorScopeConfig{
					{}, {},
				},
			}

			// 调用目标方法
			keys := r.getRepeatKeys(existingDetail)

			// 期望结果包含固定六个键和自定义范围统计键
			expected := []string{
				fmt.Sprintf("报价类型:%v", existingDetail.QuoteTypes),
				fmt.Sprintf("客户类型:%v", existingDetail.TradeTypes),
				fmt.Sprintf("表单字段:%s", existingDetail.FormField),
				fmt.Sprintf("审批规则类型:%s", existingDetail.RuleType),
				fmt.Sprintf("监控范围:%s", existingDetail.MonitorScope),
				fmt.Sprintf("监控类型:%s", existingDetail.MonitorType),
			}
			expected = append(expected, fmt.Sprintf("自定义范围:%d个", len(existingDetail.CustomScopes)))

			// 断言结果
			convey.So(keys, convey.ShouldResemble, expected)
			convey.So(len(keys), convey.ShouldEqual, 7)
		})
	})
}

func Test_groupCustomScopesByType_BitsUTGen(t *testing.T) {
	t.Run("左值为空的范围应被忽略", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造左值为空的范围
			scopes := []*model.MonitorScopeConfig{
				{
					LeftValue:   nil,
					RightValues: []*model.MonitorValueConfig{gptr.Of(model.MonitorValueConfig{Value: "x"})},
				},
			}

			result := groupCustomScopesByType(scopes)

			// 结果应为空映射
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("右值包含nil仅过滤有效值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造右值包含nil的情况
			scopes := []*model.MonitorScopeConfig{
				{
					LeftValue: gptr.Of(model.MonitorValueConfig{Value: "typeA"}),
					RightValues: []*model.MonitorValueConfig{
						nil,
						gptr.Of(model.MonitorValueConfig{Value: "v1"}),
						nil,
						gptr.Of(model.MonitorValueConfig{Value: "v2"}),
					},
				},
			}

			result := groupCustomScopesByType(scopes)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result["typeA"], convey.ShouldResemble, []string{"v1", "v2"})
			convey.So(len(result), convey.ShouldEqual, 1)
		})
	})

	t.Run("同一类型多次出现以最后一次覆盖且支持空右值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 同一类型出现两次，后者右值为空（nil切片）
			scopes := []*model.MonitorScopeConfig{
				{
					LeftValue:   gptr.Of(model.MonitorValueConfig{Value: "typeX"}),
					RightValues: []*model.MonitorValueConfig{gptr.Of(model.MonitorValueConfig{Value: "a"})},
				},
				{
					LeftValue:   gptr.Of(model.MonitorValueConfig{Value: "typeX"}),
					RightValues: nil,
				},
			}

			result := groupCustomScopesByType(scopes)

			// 应以最后一次覆盖，得到空切片
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result["typeX"], convey.ShouldResemble, []string{})
		})
	})

	t.Run("多类型分组正常返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造多类型
			scopes := []*model.MonitorScopeConfig{
				{
					LeftValue: gptr.Of(model.MonitorValueConfig{Value: "t1"}),
					RightValues: []*model.MonitorValueConfig{
						gptr.Of(model.MonitorValueConfig{Value: "a"}),
						gptr.Of(model.MonitorValueConfig{Value: "b"}),
					},
				},
				{
					LeftValue: gptr.Of(model.MonitorValueConfig{Value: "t2"}),
					RightValues: []*model.MonitorValueConfig{
						gptr.Of(model.MonitorValueConfig{Value: "c"}),
					},
				},
			}

			result := groupCustomScopesByType(scopes)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result["t1"], convey.ShouldResemble, []string{"a", "b"})
			convey.So(result["t2"], convey.ShouldResemble, []string{"c"})
		})
	})
}

func Test_UpsertApprovalRuleReq_groupCustomScopesByType_BitsUTGen(t *testing.T) {
	t.Run("自定义范围为空时返回空映射", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 自定义范围为空时，结果应为空映射
			r := &UpsertApprovalRuleReq{
				CustomScopes: nil,
			}
			result := r.groupCustomScopesByType()
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("包含LeftValue为nil的范围应被跳过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造LeftValue为nil的范围，应该被跳过不参与分组
			r := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: nil,
						RightValues: []*model.MonitorValueConfig{
							{Value: "X"},
						},
					},
				},
			}
			result := r.groupCustomScopesByType()
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("RightValues包含nil与非nil且相同类型后者覆盖前者", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 包含右值为nil与非nil的情况，nil应被过滤；相同类型的后者覆盖前者
			r := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: &model.MonitorValueConfig{Value: "typeA"},
						RightValues: []*model.MonitorValueConfig{
							nil,
							{Value: "A1"},
							nil,
							{Value: "A2"},
						},
					},
					{
						LeftValue: &model.MonitorValueConfig{Value: "typeB"},
						RightValues: []*model.MonitorValueConfig{
							nil,
						},
					},
					{
						LeftValue: &model.MonitorValueConfig{Value: "typeA"},
						RightValues: []*model.MonitorValueConfig{
							{Value: "A3"},
						},
					},
				},
			}

			result := r.groupCustomScopesByType()

			// 相同类型后者覆盖前者
			convey.So(result["typeA"], convey.ShouldResemble, []string{"A3"})
			// 只有nil右值时应得到空切片
			convey.So(result["typeB"], convey.ShouldResemble, []string{})
			convey.So(len(result), convey.ShouldEqual, 2)
		})
	})
}

func Test_checkUpperThreshold_BitsUTGen(t *testing.T) {
	t.Run("配置为nil或非区间模式返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := checkUpperThreshold(nil, true, "任意配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldBeNil)

			cfg := &model.MonitorThresholdConfig{}
			err = checkUpperThreshold(cfg, false, "任意配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("区间模式下两侧都为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{}

			err := checkUpperThreshold(cfg, true, "第1个产品线监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "至少需要配置一侧阈值")
		})
	})

	t.Run("上界阈值超过100返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				UpperFuncType:  multienv.ApprovalMonitorFuncLessThan,
				UpperThreshold: decimal.NewFromInt(101),
			}

			err := checkUpperThreshold(cfg, true, "第2个产品线监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: true})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【上界阈值】最大值为100")
		})
	})

	t.Run("下界大于上界返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
				MonitorThreshold: decimal.NewFromInt(30),
				UpperFuncType:    multienv.ApprovalMonitorFuncLessThanOrEqual,
				UpperThreshold:   decimal.NewFromInt(20),
			}

			err := checkUpperThreshold(cfg, true, "第3个产品线监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "下界阈值不能大于上界阈值")
		})
	})

	t.Run("仅配置上界且范围合法返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				UpperFuncType:  multienv.ApprovalMonitorFuncLessThanOrEqual,
				UpperThreshold: decimal.NewFromInt(20),
			}

			err := checkUpperThreshold(cfg, true, "第4个产品线监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: true})
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_isSameDimension_BitsUTGen(t *testing.T) {
	t.Run("基本字段不相交返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基本字段的报价类型无交集，直接返回false
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{1},
				FormField:    "f1",
				RuleType:     "rt",
				MonitorScope: "ms1",
				MonitorType:  "mt1",
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2},
				TradeTypes:   []int{1},
				FormField:    "f1",
				RuleType:     "rt",
				MonitorScope: "ms1",
				MonitorType:  "mt1",
			}

			result := r.isSameDimension(existing)
			convey.So(result, convey.ShouldBeFalse)
		})
	})

	t.Run("基本字段相交但自定义范围不相交返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基础字段全部匹配，但自定义范围同类型无交集，应返回false
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{5},
				FormField:    "fieldA",
				RuleType:     "ruleX",
				MonitorScope: "scopeY",
				MonitorType:  "monitorZ",
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "region"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "A"}),
						},
					},
				},
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{5, 9},
				FormField:    "fieldA",
				RuleType:     "ruleX",
				MonitorScope: "scopeY",
				MonitorType:  "monitorZ",
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "region"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "B"}),
						},
					},
				},
			}

			result := r.isSameDimension(existing)
			convey.So(result, convey.ShouldBeFalse)
		})
	})

	t.Run("基本字段与自定义范围均相交返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 基础字段匹配，自定义范围存在交集，同时包含只在一侧存在的类型（视为全量），应返回true
			r := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{2, 4},
				TradeTypes:   []int{8, 9},
				FormField:    "f2",
				RuleType:     "ruleX",
				MonitorScope: "scopeY",
				MonitorType:  "monitorZ",
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "region"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "A"}),
							gptr.Of(model.MonitorValueConfig{Value: "C"}),
						},
					},
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "platform"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "web"}),
						},
					},
				},
			}
			existing := &model.ApprovalRuleDetail{
				QuoteTypes:   []int{2, 3},
				TradeTypes:   []int{7, 8},
				FormField:    "f2",
				RuleType:     "ruleX",
				MonitorScope: "scopeY",
				MonitorType:  "monitorZ",
				CustomScopes: []*model.MonitorScopeConfig{
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "region"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "A"}),
							gptr.Of(model.MonitorValueConfig{Value: "B"}),
						},
					},
					{
						LeftValue: gptr.Of(model.MonitorValueConfig{Value: "country"}),
						RightValues: []*model.MonitorValueConfig{
							gptr.Of(model.MonitorValueConfig{Value: "cn"}),
						},
					},
				},
			}

			result := r.isSameDimension(existing)
			convey.So(result, convey.ShouldBeTrue)
		})
	})
}

func buildOriginRule(ruleType, ruleName, monitorType, monitorScope, formField string, quoteTypes, tradeTypes []int, customScopes []*model.MonitorScopeConfig, qmc *model.MonitorThresholdConfig) *model.ApprovalRule {
	detailDB := &model.ApprovalRuleDetailDB{
		QuoteTypes:         quoteTypes,
		TradeTypes:         tradeTypes,
		FormField:          formField,
		MonitorType:        monitorType,
		MonitorScope:       monitorScope,
		CustomScopes:       customScopes,
		QuoteMonitorConfig: qmc,
	}
	return &model.ApprovalRule{
		RuleType:   ruleType,
		RuleName:   ruleName,
		RuleDetail: util.GetJsonStr(detailDB),
	}
}

func Test_UpsertApprovalRuleReq_checkEnumValues_BitsUTGen(t *testing.T) {
	t.Run("报价类型包含非法值时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非法报价类型
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{99},
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【报价类型】包含非法值")
		})
	})

	t.Run("客户类型包含非法值时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法报价类型，非法客户类型
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{multienv.QuoteTypeNormal},
				TradeTypes: []int{9999},
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【客户类型】包含非法值")
		})
	})

	t.Run("表单字段非空且非法时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法报价类型与客户类型，非法表单字段
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{multienv.QuoteTypeNormal, multienv.QuoteTypeProjectBased},
				TradeTypes: []int{multienv.CustomerTypeCodeDirectSell, multienv.CustomerTypeCodeEcoAgent},
				FormField:  "unknown_field",
				RuleType:   multienv.ApprovalRuleTypeProfitCalculate,
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【表单字段】非法值")
		})
	})

	t.Run("审批规则类型非法时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法报价类型与客户类型，非法审批规则类型
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{multienv.QuoteTypeNormal, multienv.QuoteTypeProjectBased, multienv.QuoteTypeProgressive},
				TradeTypes: []int{multienv.CustomerTypeCodeDirectSell, multienv.CustomerTypeCodeBPDistributor, multienv.CustomerTypeCodeEcoAgent},
				RuleType:   "unknown_type",
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【审批规则类型】非法值")
		})
	})

	t.Run("所有枚举合法且表单字段为空时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法报价类型、客户类型，表单字段为空，合法审批规则类型
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{multienv.QuoteTypeNormal},
				TradeTypes: []int{multienv.CustomerTypeCodeEcoSolution},
				FormField:  "",
				RuleType:   multienv.ApprovalRuleTypeGuidelinePrice,
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("所有枚举合法且表单字段合法时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法报价类型、客户类型，表单字段为合法值，合法审批规则类型
			req := &UpsertApprovalRuleReq{
				QuoteTypes: []int{multienv.QuoteTypeProgressive},
				TradeTypes: []int{multienv.CustomerTypeCodeSLV},
				FormField:  multienv.ShiftApproval,
				RuleType:   multienv.ApprovalRuleTypeExceedThreeQuantity,
			}
			ctx := context.Background()

			err := req.checkEnumValues(ctx)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_hasTradeProductDataDuplicate_BitsUTGen(t *testing.T) {
	t.Run("存在重复商品配置时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前规则包含两个商品配置
			r := &UpsertApprovalRuleReq{
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P1", ConfigurationCode: "C1", ChargeItemCode: "CH1"},
					{ProductCode: "P2", ConfigurationCode: "C2", ChargeItemCode: "CH2"},
				},
			}
			// 已存在规则中包含一个与当前规则重复的配置
			existing := &model.ApprovalRuleDetail{
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P1", ConfigurationCode: "C1", ChargeItemCode: "CH1"},
					{ProductCode: "P3", ConfigurationCode: "C3", ChargeItemCode: "CH3"},
				},
			}

			res := r.hasTradeProductDataDuplicate(existing)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("无重复商品配置时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前规则仅一个商品配置
			r := &UpsertApprovalRuleReq{
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P1", ConfigurationCode: "C1", ChargeItemCode: "CH1"},
				},
			}
			// 已存在规则中配置均不与当前规则相同
			existing := &model.ApprovalRuleDetail{
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P2", ConfigurationCode: "C1", ChargeItemCode: "CH1"},
					{ProductCode: "P1", ConfigurationCode: "C2", ChargeItemCode: "CH1"},
					{ProductCode: "P1", ConfigurationCode: "C1", ChargeItemCode: "CH2"},
				},
			}

			res := r.hasTradeProductDataDuplicate(existing)
			convey.So(res, convey.ShouldBeFalse)
		})
	})
}

func Test_UpsertApprovalRuleReq_hasProductLineDataDuplicate_BitsUTGen(t *testing.T) {
	t.Run("存在重复的产品线配置时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前请求包含两个产品线，其中一个与已存在的规则重复
			req := &UpsertApprovalRuleReq{
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "DeptA", BizLineName: "Biz1"},
					{DepartmentName: "DeptB", BizLineName: "Biz2"},
				},
			}
			existingDetail := &model.ApprovalRuleDetail{
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "DeptX", BizLineName: "BizX"},
					{DepartmentName: "DeptA", BizLineName: "Biz1"},
				},
			}

			res := req.hasProductLineDataDuplicate(existingDetail)
			convey.So(res, convey.ShouldBeTrue)
		})
	})

	t.Run("不存在重复的产品线配置时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前请求与已存在规则完全不重复
			req := &UpsertApprovalRuleReq{
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "DeptA", BizLineName: "Biz1"},
				},
			}
			existingDetail := &model.ApprovalRuleDetail{
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "DeptA", BizLineName: "Biz2"},
					{DepartmentName: "DeptB", BizLineName: "Biz1"},
				},
			}

			res := req.hasProductLineDataDuplicate(existingDetail)
			convey.So(res, convey.ShouldBeFalse)
		})
	})
}

func Test_UpsertApprovalRuleReq_hasDataDuplicate_BitsUTGen(t *testing.T) {
	t.Run("监控范围为产品线且存在重复数据时返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造产品线配置，使当前规则与已存在规则存在重复
			r := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "销售一部", BizLineName: "零售业务"},
					{DepartmentName: "技术部", BizLineName: "基础设施"},
				},
			}
			existing := &model.ApprovalRuleDetail{
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "销售一部", BizLineName: "零售业务"}, // 与r重复
					{DepartmentName: "市场部", BizLineName: "推广业务"},
				},
			}

			got := r.hasDataDuplicate(existing)
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("监控范围为商品且无重复数据时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造商品配置，当前规则与已存在规则无交集
			r := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P1", ConfigurationCode: "C1", ChargeItemCode: "I1"},
				},
			}
			existing := &model.ApprovalRuleDetail{
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "P2", ConfigurationCode: "C2", ChargeItemCode: "I2"},
				},
			}

			got := r.hasDataDuplicate(existing)
			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("监控范围为整单时直接返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 整单监控无需比较，直接返回true
			r := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			existing := &model.ApprovalRuleDetail{}

			got := r.hasDataDuplicate(existing)
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("监控范围为未知值时返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 未知监控范围走默认分支，返回false
			r := &UpsertApprovalRuleReq{
				MonitorScope: "unknown_scope",
			}
			existing := &model.ApprovalRuleDetail{}

			got := r.hasDataDuplicate(existing)
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_UpsertApprovalRuleReq_isCustomScopesEqual_BitsUTGen(t *testing.T) {
	t.Run("长度不一致返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 自定义范围长度不同
			r := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					{MonitorFuncType: "A"},
				},
			}
			originScopes := []*model.MonitorScopeConfig{
				{MonitorFuncType: "A"},
				{MonitorFuncType: "B"},
			}

			// 期望直接返回false
			got := r.isCustomScopesEqual(originScopes)
			convey.So(got, convey.ShouldBeFalse)
		})
	})

	t.Run("长度一致且内容完全相同返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 自定义范围长度和内容完全一致
			custom := []*model.MonitorScopeConfig{
				{MonitorFuncType: "A"},
				{MonitorFuncType: "B"},
			}
			r := &UpsertApprovalRuleReq{
				CustomScopes: custom,
			}
			originScopes := []*model.MonitorScopeConfig{
				{MonitorFuncType: "A"},
				{MonitorFuncType: "B"},
			}

			// 期望JSON相等返回true
			got := r.isCustomScopesEqual(originScopes)
			convey.So(got, convey.ShouldBeTrue)
		})
	})

	t.Run("长度一致但内容不同返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 自定义范围长度一致但内容不同
			r := &UpsertApprovalRuleReq{
				CustomScopes: []*model.MonitorScopeConfig{
					{MonitorFuncType: "A"},
					{MonitorFuncType: "B"},
				},
			}
			originScopes := []*model.MonitorScopeConfig{
				{MonitorFuncType: "A"},
				{MonitorFuncType: "C"},
			}

			// 期望JSON不相等返回false
			got := r.isCustomScopesEqual(originScopes)
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkTradeProductPriceType_BitsUTGen(t *testing.T) {
	t.Run("阈值配置为空直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求与配置，阈值配置为nil
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:     "p1",
				ChargeItemCode:  "",
				ThresholdConfig: nil,
			}

			err := r.checkTradeProductPriceType(context.Background(), cfg, 1)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("阈值配置MonitorExtra为空直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求与配置，MonitorExtra为空
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p1",
				ChargeItemCode: "",
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: "",
				},
			}

			err := r.checkTradeProductPriceType(context.Background(), cfg, 2)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("固定单价且未选择计费项返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 固定单价但计费项为空
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p2",
				ChargeItemCode: "",
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: multienv.FixedPrice,
				},
			}

			err := r.checkTradeProductPriceType(context.Background(), cfg, 3)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "必须选择具体计费项")
		})
	})

	t.Run("固定单价且选择全选计费项返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 固定单价但计费项为全选
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p3",
				ChargeItemCode: constants.SelectAll,
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: multienv.FixedPrice,
				},
			}

			err := r.checkTradeProductPriceType(context.Background(), cfg, 4)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "必须选择具体计费项")
		})
	})

	t.Run("固定单价且校验计费项价格类型失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 固定单价且选择了具体计费项，但内部校验返回错误
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p4",
				ChargeItemCode: "ci-001",
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: multienv.FixedPrice,
				},
			}

			mockey.Mock((*UpsertApprovalRuleReq).validateChargeItemPriceType).Return(errors.New("校验失败")).Build()

			err := r.checkTradeProductPriceType(context.Background(), cfg, 5)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "校验失败")
		})
	})

	t.Run("固定单价且校验计费项价格类型成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 固定单价且选择了具体计费项，内部校验成功
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p5",
				ChargeItemCode: "ci-002",
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: multienv.FixedPrice,
				},
			}

			mockey.Mock((*UpsertApprovalRuleReq).validateChargeItemPriceType).Return(nil).Build()

			err := r.checkTradeProductPriceType(context.Background(), cfg, 6)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("非固定单价类型直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非固定单价类型，不触发校验
			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:    "p6",
				ChargeItemCode: "",
				ThresholdConfig: &model.MonitorThresholdConfig{
					MonitorExtra: "other_price_type",
				},
			}

			err := r.checkTradeProductPriceType(context.Background(), cfg, 7)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkEffectiveRuleModification_BitsUTGen(t *testing.T) {
	t.Run("原规则详情解析失败时返回参数非法错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 规则详情为非法JSON
			origin := &model.ApprovalRule{
				RuleType:   "A",
				RuleName:   "R",
				RuleDetail: "invalid-json",
			}
			req := &UpsertApprovalRuleReq{}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			// 错误信息包含特定提示
			convey.So(err.Error(), convey.ShouldContainSubstring, "原规则详情解析失败")
			// 校验错误码
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleParamIllegal))
		})
	})

	t.Run("审批规则类型不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "B", // 不同
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批规则类型")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("规则名称不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleY", // 不同
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "规则名称")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("监控类型不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType2", // 不同
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控类型")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("监控范围不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope2", // 不同
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控范围")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("表单字段不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormB", // 不同
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "表单字段")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("报价类型不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2, 3}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2}, // 不同
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价类型")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("客户类型不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4, 5}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4}, // 不同
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "客户类型")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("整单监控配置不同返回不允许修改错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// origin为nil，req为非nil，JSON不同导致不相等
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:     "A",
				RuleName:     "RuleX",
				MonitorType:  "MType",
				MonitorScope: "MScope",
				FormField:    "FormA",
				QuoteTypes:   []int{1, 2},
				TradeTypes:   []int{3, 4},
				CustomScopes: nil,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{ // 与origin不同
					MonitorFuncType: "X",
					// MonitorThreshold使用零值即可
					MonitorExtra: "E",
				},
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "整单监控配置")
			apiErr, ok := err.(hertz.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCodeInt(), convey.ShouldEqual, int(pkg_errors.CodeNApprovalRuleOperationNotAllow))
		})
	})

	t.Run("所有字段一致时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有字段完全一致
			origin := buildOriginRule("A", "RuleX", "MType", "MScope", "FormA", []int{1, 2}, []int{3, 4}, nil, nil)
			req := &UpsertApprovalRuleReq{
				RuleType:           "A",
				RuleName:           "RuleX",
				MonitorType:        "MType",
				MonitorScope:       "MScope",
				FormField:          "FormA",
				QuoteTypes:         []int{1, 2},
				TradeTypes:         []int{3, 4},
				CustomScopes:       nil,
				QuoteMonitorConfig: nil,
			}
			err := req.checkEffectiveRuleModification(context.Background(), origin)
			// 预期不返回错误
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_upsertRule_BitsUTGen(t *testing.T) {
	t.Run("用户权限检查失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &UpsertApprovalRuleReq{}

			// mock 用户权限检查失败
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(nil, errors.New("no permission")).Build()

			// 调用函数
			resp, err := req.upsertRule(context.Background(), &gorm.DB{})

			// 断言：应返回错误，且resp为nil
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "no permission")
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("内部判重失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求
			req := &UpsertApprovalRuleReq{}

			// mock 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "user@test.com"}, nil).Build()
			// mock 内部判重失败
			mockey.Mock((*UpsertApprovalRuleReq).checkInternalDuplicate).Return(errors.New("internal duplicate")).Build()

			// 调用函数
			resp, err := req.upsertRule(context.Background(), &gorm.DB{})

			// 断言：应返回错误，且resp为nil
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "internal duplicate")
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("规则详情序列化失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求（使之进入到序列化分支）
			req := &UpsertApprovalRuleReq{
				QuoteTypes:   []int{1},
				TradeTypes:   []int{2},
				FormField:    "form_field",
				RuleType:     "rule_type",
				RuleName:     "rule_name",
				MonitorType:  "monitor_type",
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}

			// mock 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "user@test.com"}, nil).Build()
			// mock 内部判重通过
			mockey.Mock((*UpsertApprovalRuleReq).checkInternalDuplicate).Return(nil).Build()
			// mock 序列化失败
			mockey.MockUnsafe(json.Marshal).Return(nil, errors.New("marshal failed")).Build()

			// 调用函数
			resp, err := req.upsertRule(context.Background(), &gorm.DB{})

			// 断言：应返回参数非法错误信息，且resp为nil
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "规则详情序列化失败")
			convey.So(resp, convey.ShouldBeNil)
		})
	})

	t.Run("创建规则路径成功并返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求，RuleID为0触发创建逻辑
			req := &UpsertApprovalRuleReq{
				RuleID:            0,
				QuoteTypes:        []int{1},
				TradeTypes:        []int{2},
				FormField:         "ff",
				RuleType:          "rt",
				RuleName:          "rn",
				MonitorType:       "mt",
				MonitorScope:      multienv.ApprovalMonitorScopeQuote,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllGreater},
				UpperCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllLess},
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
					MonitorThreshold: decimal.NewFromInt(10),
					UpperFuncType:    multienv.ApprovalMonitorFuncLessThan,
					UpperThreshold:   decimal.NewFromInt(20),
				},
			}

			// mock 用户权限检查成功
			currentUser := &model.Account{AccountID: "creator@test.com"}
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(currentUser, nil).Build()
			// mock 内部判重通过
			mockey.Mock((*UpsertApprovalRuleReq).checkInternalDuplicate).Return(nil).Build()

			// 捕获创建方法的入参
			var capturedCreator string
			var capturedDetail string
			mockey.Mock((*UpsertApprovalRuleReq).createRule).To(
				func(_ *UpsertApprovalRuleReq, ctx context.Context, tx *gorm.DB, creatorEmail string, ruleDetailJSON string) (*UpsertApprovalRuleResp, error) {
					// 记录入参
					capturedCreator = creatorEmail
					capturedDetail = ruleDetailJSON
					return &UpsertApprovalRuleResp{RuleID: 12345}, nil
				},
			).Build()

			// 调用函数
			resp, err := req.upsertRule(context.Background(), &gorm.DB{})

			// 断言：成功返回，且入参符合预期
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.RuleID, convey.ShouldEqual, 12345)
			convey.So(capturedCreator, convey.ShouldEqual, currentUser.AccountID)
			convey.So(capturedDetail, convey.ShouldNotBeEmpty)

			ruleDetail := &model.ApprovalRuleDetailDB{}
			err = json.Unmarshal([]byte(capturedDetail), ruleDetail)
			convey.So(err, convey.ShouldBeNil)
			convey.So(ruleDetail.IsIntervalMode, convey.ShouldBeTrue)
			convey.So(ruleDetail.LowerCompareRules, convey.ShouldResemble, []string{multienv.ApprovalMonitorCompareRuleAllGreater})
			convey.So(ruleDetail.UpperCompareRules, convey.ShouldResemble, []string{multienv.ApprovalMonitorCompareRuleAllLess})
			convey.So(ruleDetail.QuoteMonitorConfig.UpperThreshold.Equal(decimal.NewFromInt(20)), convey.ShouldBeTrue)
		})
	})

	t.Run("更新规则路径成功并返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求，RuleID非0触发更新逻辑
			req := &UpsertApprovalRuleReq{
				RuleID:            100,
				QuoteTypes:        []int{3},
				TradeTypes:        []int{4},
				FormField:         "ff2",
				RuleType:          "rt2",
				RuleName:          "rn2",
				MonitorType:       "mt2",
				MonitorScope:      multienv.ApprovalMonitorScopeQuote,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleMaxGreaterOrEqual},
				UpperCompareRules: []string{multienv.ApprovalMonitorCompareRuleMinLessOrEqual},
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThanOrEqual,
					MonitorThreshold: decimal.NewFromInt(15),
					UpperFuncType:    multienv.ApprovalMonitorFuncLessThanOrEqual,
					UpperThreshold:   decimal.NewFromInt(25),
				},
			}

			// mock 用户权限检查成功
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "user2@test.com"}, nil).Build()
			// mock 内部判重通过
			mockey.Mock((*UpsertApprovalRuleReq).checkInternalDuplicate).Return(nil).Build()

			// 捕获更新方法的入参
			var capturedUpdateDetail string
			mockey.Mock((*UpsertApprovalRuleReq).updateRule).To(
				func(_ *UpsertApprovalRuleReq, ctx context.Context, tx *gorm.DB, ruleDetailJSON string) (*UpsertApprovalRuleResp, error) {
					capturedUpdateDetail = ruleDetailJSON
					return &UpsertApprovalRuleResp{RuleID: 100}, nil
				},
			).Build()

			// 调用函数
			resp, err := req.upsertRule(context.Background(), &gorm.DB{})

			// 断言：成功返回，且入参符合预期
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.RuleID, convey.ShouldEqual, 100)
			convey.So(capturedUpdateDetail, convey.ShouldNotBeEmpty)

			ruleDetail := &model.ApprovalRuleDetailDB{}
			err = json.Unmarshal([]byte(capturedUpdateDetail), ruleDetail)
			convey.So(err, convey.ShouldBeNil)
			convey.So(ruleDetail.IsIntervalMode, convey.ShouldBeTrue)
			convey.So(ruleDetail.LowerCompareRules, convey.ShouldResemble, []string{multienv.ApprovalMonitorCompareRuleMaxGreaterOrEqual})
			convey.So(ruleDetail.UpperCompareRules, convey.ShouldResemble, []string{multienv.ApprovalMonitorCompareRuleMinLessOrEqual})
			convey.So(ruleDetail.QuoteMonitorConfig.UpperFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncLessThanOrEqual)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkProfitCalculateMonitorFunc_BitsUTGen(t *testing.T) {
	t.Run("整单配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【整单监控配置】不能为空")
		})
	})

	t.Run("整单非区间模式阈值为负返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
					MonitorThreshold: decimal.NewFromInt(-1),
				},
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入0或正数")
		})
	})

	t.Run("整单区间模式仅配置上界时校验通过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeQuote,
				IsIntervalMode: true,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					UpperFuncType:  multienv.ApprovalMonitorFuncLessThanOrEqual,
					UpperThreshold: decimal.NewFromInt(20),
				},
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("产品线配置缺少阈值返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					nil,
				},
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "产品线监控配置必须设置监控阈值配置")
		})
	})

	t.Run("产品线区间模式左右阈值合法时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
							MonitorThreshold: decimal.NewFromInt(0),
							UpperFuncType:    multienv.ApprovalMonitorFuncLessThanOrEqual,
							UpperThreshold:   decimal.NewFromInt(10),
						},
					},
				},
			}

			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("商品区间模式上界阈值非法时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeTradeProduct,
				IsIntervalMode: true,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThan,
							UpperThreshold: decimal.NewFromInt(-1),
						},
					},
				},
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入0或正数")
		})
	})

	t.Run("商品配置缺少阈值返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p1",
					},
				},
			}

			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品监控配置必须设置监控阈值配置")
		})
	})

	t.Run("监控范围为未知值时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: "unknown_scope",
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("商品区间模式仅配置上界且合法时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeTradeProduct,
				IsIntervalMode: true,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p2",
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThanOrEqual,
							UpperThreshold: decimal.NewFromInt(5),
						},
					},
				},
			}
			err := req.checkProfitCalculateMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkGuidelinePriceMonitorFunc_BitsUTGen(t *testing.T) {
	t.Run("产品线监控阈值配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					nil,
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "产品线监控配置必须设置监控阈值配置")
		})
	})

	t.Run("产品线监控价格类型非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorThreshold: decimal.NewFromInt(10),
							MonitorExtra:     "fixed_price",
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "仅支持【单一折扣】监控价格类型")
		})
	})

	t.Run("商品区间模式仅配置上界时校验通过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*UpsertApprovalRuleReq).checkTradeProductPriceType).Return(nil).Build()
			req := &UpsertApprovalRuleReq{
				MonitorType:    multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope:   multienv.ApprovalMonitorScopeTradeProduct,
				IsIntervalMode: true,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p1",
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThan,
							UpperThreshold: decimal.NewFromInt(30),
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("产品线区间模式仅配置上界且单一折扣时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorType:    multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorExtra:   multienv.SimpleDiscount,
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThanOrEqual,
							UpperThreshold: decimal.NewFromInt(30),
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("产品线区间模式上界为负时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorType:    multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorExtra:   multienv.SimpleDiscount,
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThan,
							UpperThreshold: decimal.NewFromInt(-1),
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入0或正数")
		})
	})

	t.Run("商品价格类型校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*UpsertApprovalRuleReq).checkTradeProductPriceType).Return(errors.New("price type error")).Build()
			req := &UpsertApprovalRuleReq{
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p2",
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorThreshold: decimal.NewFromInt(10),
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "price type error")
		})
	})

	t.Run("商品监控阈值配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p3",
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品监控配置必须设置监控阈值配置")
		})
	})

	t.Run("商品非区间模式阈值合法时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*UpsertApprovalRuleReq).checkTradeProductPriceType).Return(nil).Build()
			req := &UpsertApprovalRuleReq{
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "p4",
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType:  multienv.ApprovalMonitorFuncLessThan,
							MonitorThreshold: decimal.NewFromInt(15),
						},
					},
				},
			}

			err := req.checkGuidelinePriceMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkBusinessDiscountMonitorFunc_BitsUTGen(t *testing.T) {
	t.Run("非产品线范围返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{MonitorScope: multienv.ApprovalMonitorScopeQuote}

			err := req.checkBusinessDiscountMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "仅支持【产品线】监控范围")
		})
	})

	t.Run("非区间模式缺少监控函数返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorThreshold: decimal.NewFromInt(10),
						},
					},
				},
			}

			err := req.checkBusinessDiscountMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "必须设置监控函数")
		})
	})

	t.Run("产品线监控阈值配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{},
				},
			}

			err := req.checkBusinessDiscountMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "产品线监控配置必须设置监控阈值配置")
		})
	})

	t.Run("区间模式仅配置上界且不超过100返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThanOrEqual,
							UpperThreshold: decimal.NewFromInt(100),
						},
					},
				},
			}

			err := req.checkBusinessDiscountMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("区间模式上界超过100返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType:  multienv.ApprovalMonitorFuncLessThan,
							UpperThreshold: decimal.NewFromInt(101),
						},
					},
				},
			}

			err := req.checkBusinessDiscountMonitorFunc(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【上界阈值】最大值为100")
		})
	})
}

func Test_UpsertApprovalRuleReq_fixExceedThreeQuantityMonitorFunc_BitsUTGen(t *testing.T) {
	t.Run("整单范围会重置整单阈值配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
					MonitorThreshold: decimal.NewFromInt(9),
				},
			}

			err := req.fixExceedThreeQuantityMonitorFunc(context.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(req.QuoteMonitorConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(req.QuoteMonitorConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})

	t.Run("产品线和商品范围都会逐项重置阈值配置", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			productLineReq := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "dep1"},
					{DepartmentName: "dep2"},
				},
			}
			tradeProductReq := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "p1"},
					{ProductCode: "p2"},
				},
			}

			err := productLineReq.fixExceedThreeQuantityMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
			convey.So(productLineReq.ProductLineMonitorConfigs[0].ThresholdConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(productLineReq.ProductLineMonitorConfigs[1].ThresholdConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)

			err = tradeProductReq.fixExceedThreeQuantityMonitorFunc(context.Background())
			convey.So(err, convey.ShouldBeNil)
			convey.So(tradeProductReq.TradeProductMonitorConfigs[0].ThresholdConfig.MonitorFuncType, convey.ShouldEqual, multienv.ApprovalMonitorFuncEqual)
			convey.So(tradeProductReq.TradeProductMonitorConfigs[1].ThresholdConfig.MonitorThreshold.Equal(decimal.Zero), convey.ShouldBeTrue)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkRuleCompareRule_BitsUTGen(t *testing.T) {
	t.Run("整单范围直接跳过校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeQuote,
				IsIntervalMode: true,
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("跨三档规则直接跳过校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				RuleType:       multienv.ApprovalRuleTypeExceedThreeQuantity,
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("非区间模式直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{ThresholdConfig: &model.MonitorThresholdConfig{}},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("区间模式未配置任何阈值规则返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:   multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode: true,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{ThresholdConfig: &model.MonitorThresholdConfig{}},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【监控阈值规则】不能为空")
		})
	})

	t.Run("下界规则方向非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllLess},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType: multienv.ApprovalMonitorFuncLessThan,
						},
					},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【下界监控阈值规则】只能选大于类规则")
		})
	})

	t.Run("上界规则方向非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				UpperCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllGreater},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType: multienv.ApprovalMonitorFuncLessThan,
						},
					},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【上界监控阈值规则】只能选小于类规则")
		})
	})

	t.Run("配置了下界规则但左侧符号为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllGreater},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{ThresholdConfig: &model.MonitorThresholdConfig{}},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "左侧符号不能为空")
		})
	})

	t.Run("左侧符号与下界规则方向不匹配返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllGreater},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType: multienv.ApprovalMonitorFuncLessThanOrEqual,
						},
					},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【下界监控阈值规则】必须包含大于等于类规则")
		})
	})

	t.Run("右侧符号非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				UpperCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllLess},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							UpperFuncType: multienv.ApprovalMonitorFuncGreaterThan,
						},
					},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "右侧符号只能为 < 或 <=")
		})
	})

	t.Run("产品线配置的左右规则都匹配时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				MonitorScope:      multienv.ApprovalMonitorScopeProductLine,
				IsIntervalMode:    true,
				LowerCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllGreaterOrEqual},
				UpperCompareRules: []string{multienv.ApprovalMonitorCompareRuleAllLess},
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					nil,
					{
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType: multienv.ApprovalMonitorFuncLessThanOrEqual,
							UpperFuncType:   multienv.ApprovalMonitorFuncLessThan,
						},
					},
				},
			}

			err := req.checkRuleCompareRule(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_validateChargeItemPriceType_BitsUTGen(t *testing.T) {
	t.Run("商品信息获取失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求参数
			req := &UpsertApprovalRuleReq{}
			ctx := context.Background()
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:       "p-code",
				ConfigurationCode: "cfg-code",
				ChargeItemCode:    "ci-code",
			}

			// 商品信息获取失败
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(nil, errors.New("db fail")).Build()

			err := req.validateChargeItemPriceType(ctx, cfg, 1)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取商品信息失败")
		})
	})

	t.Run("校验计费项价格类型失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{}
			ctx := context.Background()
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:       "p-code",
				ConfigurationCode: "cfg-code",
				ChargeItemCode:    "ci-code",
			}

			// 商品信息获取成功
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     1,
				StandardProduct: 1,
			}
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()

			// 校验固定单价失败
			mockey.MockUnsafe(ValidateChargeItemPriceTypeForFixedPrice).Return(errors.New("非法计费项")).Build()

			err := req.validateChargeItemPriceType(ctx, cfg, 1)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品监控配置")
			convey.So(err.Error(), convey.ShouldContainSubstring, "非法计费项")
		})
	})

	t.Run("商品信息与计费项校验都成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{}
			ctx := context.Background()
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:       "p-code",
				ConfigurationCode: "cfg-code",
				ChargeItemCode:    "ci-code",
			}

			// 商品信息获取成功
			productInfo := &trade_client.TradeProductVersionInfo{
				ProductType:     2,
				StandardProduct: 0,
			}
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).Return(productInfo, nil).Build()

			// 校验固定单价成功
			mockey.MockUnsafe(ValidateChargeItemPriceTypeForFixedPrice).Return(nil).Build()

			err := req.validateChargeItemPriceType(ctx, cfg, 2)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkTradeProductConfigAndChargeItem_BitsUTGen(t *testing.T) {
	t.Run("校验失败时返回包装后的错误信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 私有云商品且配置不为空，触发校验失败
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).
				Return(&trade_client.TradeProductVersionInfo{ProductType: int(multienv.TradeProductDeploymentTypePrivate)}, nil).
				Build()

			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:       "prod-1",
				ConfigurationCode: "conf-1",
				ChargeItemCode:    "charge-1",
			}

			err := r.checkTradeProductConfigAndChargeItem(context.Background(), cfg, 1)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "第1个商品监控配置：")
			convey.So(err.Error(), convey.ShouldContainSubstring, "私有云商品配置必须为空")
		})
	})

	t.Run("校验通过时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 公有云商品且计费项不为空，校验通过
			mockey.MockUnsafe(commodity_service.GetProductInfoFromCache).
				Return(&trade_client.TradeProductVersionInfo{ProductType: 0}, nil).
				Build()

			r := &UpsertApprovalRuleReq{}
			cfg := &model.TradeProductMonitorConfig{
				ProductCode:       "prod-2",
				ConfigurationCode: "conf-2",
				ChargeItemCode:    "charge-2",
			}

			err := r.checkTradeProductConfigAndChargeItem(context.Background(), cfg, 2)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_checkMonitorThreshold_BitsUTGen(t *testing.T) {
	t.Run("配置为nil直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			err := checkMonitorThreshold(nil, false, "任意配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("区间模式下左侧未配置时跳过左阈值校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				MonitorThreshold: decimal.NewFromInt(-1),
			}
			err := checkMonitorThreshold(cfg, true, "第0个商品监控配置", MonitorThresholdRule{AllowZero: false, HasMaxLimit: false})
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("校验字符串非法返回包含配置名前缀的错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 负数触发内部校验错误
			cfg := &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
				MonitorThreshold: decimal.NewFromInt(-1),
			}
			configName := "第1个商品监控配置"
			err := checkMonitorThreshold(cfg, false, configName, MonitorThresholdRule{AllowZero: false, HasMaxLimit: false})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, configName)
			convey.So(err.Error(), convey.ShouldContainSubstring, "监控阈值仅支持输入正数")
		})
	})

	t.Run("有最大值限制且阈值大于100返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
				MonitorThreshold: decimal.NewFromInt(101),
			}
			configName := "第2个商品监控配置"
			err := checkMonitorThreshold(cfg, false, configName, MonitorThresholdRule{AllowZero: true, HasMaxLimit: true})
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, configName)
			convey.So(err.Error(), convey.ShouldContainSubstring, "最大值为100")
		})
	})

	t.Run("有最大值限制且阈值不超过100返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			cfg := &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
				MonitorThreshold: decimal.NewFromInt(100),
			}
			err := checkMonitorThreshold(cfg, false, "第3个商品监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: true})
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("无最大值限制校验通过返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 允许0值且无最大值限制
			cfg := &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
				MonitorThreshold: decimal.NewFromInt(0),
			}
			err := checkMonitorThreshold(cfg, false, "第4个商品监控配置", MonitorThresholdRule{AllowZero: true, HasMaxLimit: false})
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpsertApprovalRuleReq_checkReq_BitsUTGen(t *testing.T) {
	t.Run("空审批规则类型返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				RuleType: "",
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【审批规则类型】不能为空")
		})
	})

	t.Run("空规则名称返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				RuleType: multienv.ApprovalRuleTypeProfitCalculate,
				RuleName: "",
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【规则名称】不能为空")
		})
	})

	t.Run("规则名称超长返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			longName := ""
			for i := 0; i < 101; i++ {
				longName += "a"
			}
			req := &UpsertApprovalRuleReq{
				RuleType: multienv.ApprovalRuleTypeProfitCalculate,
				RuleName: longName,
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【规则名称】长度不能超过100个字符")
		})
	})

	t.Run("报价类型为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				RuleType:   multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:   "name",
				QuoteTypes: []int{
					// 为空
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【报价类型】不能为空")
		})
	})

	t.Run("客户类型为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpsertApprovalRuleReq{
				RuleType:   multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:   "name",
				QuoteTypes: []int{multienv.QuoteTypeNormal},
				TradeTypes: []int{
					// 为空
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【客户类型】不能为空")
		})
	})

	t.Run("枚举值校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(errors.New("枚举错误")).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:   multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:   "name",
				QuoteTypes: []int{multienv.QuoteTypeNormal},
				TradeTypes: []int{multienv.CustomerTypeCodeDirectSell},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "枚举错误")
		})
	})

	t.Run("跨三档默认监控类型自动填充", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkCustomScopes).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeExceedThreeQuantity,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  "",
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "dep", BizLineName: "biz"},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldBeNil)
			convey.So(req.MonitorType, convey.ShouldEqual, multienv.ApprovalMonitorTypeExceedThreeQuantity)
		})
	})

	t.Run("监控类型为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  "",
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【监控类型】不能为空")
		})
	})

	t.Run("监控范围为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: "",
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【监控范围】不能为空")
		})
	})

	t.Run("指导价监控不支持整单监控范围返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeGuidelinePrice,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeUnderGuidePrice,
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【指导价监控】类型的审批规则，【监控范围】仅支持【产品线】或【商品】")
		})
	})

	t.Run("自定义范围校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkCustomScopes).Return(errors.New("自定义范围错误")).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "dep", BizLineName: "biz"},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "自定义范围错误")
		})
	})

	t.Run("整单监控配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:           multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:           "name",
				QuoteTypes:         []int{multienv.QuoteTypeNormal},
				TradeTypes:         []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:        multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope:       multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: nil,
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【整单监控配置】不能为空")
		})
	})

	t.Run("产品线监控配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:                  multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:                  "name",
				QuoteTypes:                []int{multienv.QuoteTypeNormal},
				TradeTypes:                []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:               multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope:              multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【产品线监控配置】不能为空")
		})
	})

	t.Run("产品线一级产品线名称为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeBusinessDiscount,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "", BizLineName: "biz"},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【一级产品线】不能为空")
		})
	})

	t.Run("产品线二级产品线名称为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeBusinessDiscount,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "dep", BizLineName: ""},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【二级产品线】不能为空")
		})
	})

	t.Run("商品监控配置为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:                   multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:                   "name",
				QuoteTypes:                 []int{multienv.QuoteTypeNormal},
				TradeTypes:                 []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:                multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope:               multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【商品监控配置】不能为空")
		})
	})

	t.Run("商品监控配置项为nil返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					nil,
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【商品监控配置】不能为空")
		})
	})

	t.Run("商品编码为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: ""},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【商品】不能为空")
		})
	})

	t.Run("商品监控配置与计费项关系校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkTradeProductConfigAndChargeItem).Return(errors.New("关系错误")).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{ProductCode: "prod"},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "关系错误")
		})
	})

	t.Run("商品监控配置监控价格类型非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkTradeProductConfigAndChargeItem).Return(nil).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeTradeProduct,
				TradeProductMonitorConfigs: []*model.TradeProductMonitorConfig{
					{
						ProductCode: "prod",
						ThresholdConfig: &model.MonitorThresholdConfig{
							MonitorFuncType:  multienv.ApprovalMonitorFuncGreaterThan,
							MonitorThreshold: decimal.NewFromInt(1),
							MonitorExtra:     "illegal_extra",
						},
					},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "【商品监控配置】")
			convey.So(err.Error(), convey.ShouldContainSubstring, "【监控价格类型】非法")
		})
	})

	t.Run("针对审批规则类型监控函数校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(errors.New("函数类型错误")).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncLessThan,
					MonitorThreshold: decimal.NewFromInt(1),
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "函数类型错误")
		})
	})

	t.Run("监控阈值规则校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkEnumValues).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkRuleCompareRule).Return(errors.New("compare rule error")).Build()

			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "name",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeQuote,
				QuoteMonitorConfig: &model.MonitorThresholdConfig{
					MonitorFuncType:  multienv.ApprovalMonitorFuncLessThan,
					MonitorThreshold: decimal.NewFromInt(1),
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "compare rule error")
		})
	})

	t.Run("成功路径返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkAndFixMonitorFuncType).Return(nil).Build()
			mockey.MockUnsafe((*UpsertApprovalRuleReq).checkRuleCompareRule).Return(nil).Build()
			// 不mock枚举校验，使用真实合法枚举
			req := &UpsertApprovalRuleReq{
				RuleType:     multienv.ApprovalRuleTypeProfitCalculate,
				RuleName:     "ok",
				QuoteTypes:   []int{multienv.QuoteTypeNormal},
				TradeTypes:   []int{multienv.CustomerTypeCodeDirectSell},
				MonitorType:  multienv.ApprovalMonitorTypeProfitLoss,
				MonitorScope: multienv.ApprovalMonitorScopeProductLine,
				ProductLineMonitorConfigs: []*model.ProductLineMonitorConfig{
					{DepartmentName: "dep", BizLineName: "biz"},
				},
			}
			err := req.checkReq(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

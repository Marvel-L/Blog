package approval_rule

import (
	"context"
	stdErrors "errors"
	"strings"
	"testing"

	"github.com/bytedance/mockey"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	v2 "code.byted.org/gopkg/gorm/v2"
)

func TestUpsertApprovalRuleTestRestriction(t *testing.T) {
	mockey.PatchConvey("保存时传入当前操作人和请求范围，校验失败应阻断", t, func() {
		restrictionErr := stdErrors.New("test restriction failed")
		currentUser := &model.Account{AccountID: "qa@example.com"}
		customScopes := []*model.MonitorScopeConfig{{}}
		allowedDepartments := map[string]struct{}{"允许部门": {}}
		departmentInfo := approvalRuleDepartmentInfo()

		mockey.Mock((*UpsertApprovalRuleReq).checkReq).Return(nil).Build()
		mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
		mockey.Mock(loadApprovalRuleRestriction).
			To(func(_ context.Context, operatorEmail string) (map[string]struct{}, map[string]*lark_client.DepartmentInfo) {
				if operatorEmail != currentUser.AccountID {
					t.Fatalf("loadApprovalRuleRestriction() operatorEmail = %q, want %q", operatorEmail, currentUser.AccountID)
				}
				return allowedDepartments, departmentInfo
			}).
			Build()
		mockey.Mock(validateApprovalRuleRestriction).
			To(func(
				gotScopes []*model.MonitorScopeConfig,
				gotAllowedDepartments map[string]struct{},
				gotDepartmentInfo map[string]*lark_client.DepartmentInfo,
			) error {
				if len(gotScopes) != 1 || gotScopes[0] != customScopes[0] {
					t.Fatalf("validateApprovalRuleRestriction() scopes = %#v, want %#v", gotScopes, customScopes)
				}
				if len(gotAllowedDepartments) != 1 || len(gotDepartmentInfo) != 1 {
					t.Fatalf("validateApprovalRuleRestriction() received unexpected restriction data")
				}
				return restrictionErr
			}).
			Build()

		resp, err := (&UpsertApprovalRuleReq{CustomScopes: customScopes}).Handle(context.Background())

		if !stdErrors.Is(err, restrictionErr) {
			t.Fatalf("Handle() error = %v, want %v", err, restrictionErr)
		}
		if resp != nil {
			t.Fatalf("Handle() response = %#v, want nil", resp)
		}
	})
}

func TestEffectiveApprovalRuleTestRestriction(t *testing.T) {
	mockey.PatchConvey("生效时传入原规则，校验失败应阻断状态变更", t, func() {
		restrictionErr := stdErrors.New("test restriction failed")
		currentUser := &model.Account{AccountID: "qa@example.com"}
		ruleDB := &model.ApprovalRule{CreatorEmail: currentUser.AccountID}
		allowedDepartments := map[string]struct{}{"允许部门": {}}
		departmentInfo := approvalRuleDepartmentInfo()

		mockey.Mock(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
		mockey.Mock(loadApprovalRuleRestriction).Return(allowedDepartments, departmentInfo).Build()
		mockey.Mock(lockApprovalRuleOperation).Return(func() {}, nil).Build()
		mockey.MockValue(&dal.DBProxy).To(&v2.DBProxy{})
		mockey.MockUnsafe((*v2.DBProxy).NewRequest).Return(&gorm.DB{}).Build()
		mockey.Mock(mockey.GetMethod(dal.ApprovalRuleDao, "FindRuleByID")).Return(ruleDB, nil).Build()
		mockey.Mock(approvalRulePermission.rulePermissionCheck).Return(currentUser, nil).Build()
		mockey.Mock(validateStoredApprovalRuleRestriction).
			To(func(
				gotRule *model.ApprovalRule,
				gotAllowedDepartments map[string]struct{},
				gotDepartmentInfo map[string]*lark_client.DepartmentInfo,
			) error {
				if gotRule != ruleDB {
					t.Fatalf("validateStoredApprovalRuleRestriction() rule = %#v, want %#v", gotRule, ruleDB)
				}
				if len(gotAllowedDepartments) != 1 || len(gotDepartmentInfo) != 1 {
					t.Fatalf("validateStoredApprovalRuleRestriction() received unexpected restriction data")
				}
				return restrictionErr
			}).
			Build()

		resp, err := (&UpdateApprovalRuleStatusReq{
			RuleID:     1,
			RuleStatus: multienv.ApprovalQuoteTypeEffective,
		}).Handle(context.Background())

		if !stdErrors.Is(err, restrictionErr) {
			t.Fatalf("Handle() error = %v, want %v", err, restrictionErr)
		}
		if resp != nil {
			t.Fatalf("Handle() response = %#v, want nil", resp)
		}
	})
}

func TestLoadApprovalRuleRestriction(t *testing.T) {
	t.Run("邮箱白名单内不限制", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(config.GetSwitchWhiteList).
				To(func(_ context.Context, name string) []string {
					if name == config.SwitchApprovalRuleOperatorWhitelist {
						return []string{" exempt@example.com "}
					}
					return []string{"允许部门"}
				}).
				Build()

			allowedDepartments, departmentInfo := loadApprovalRuleRestriction(context.Background(), "EXEMPT@example.com")
			if len(allowedDepartments) != 0 || len(departmentInfo) != 0 {
				t.Fatalf("loadApprovalRuleRestriction() = (%v, %v), want disabled", allowedDepartments, departmentInfo)
			}
		})
	})

	t.Run("邮箱白名单外执行限制", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(config.GetSwitchWhiteList).
				To(func(_ context.Context, name string) []string {
					if name == config.SwitchApprovalRuleApplicantDepartmentWhitelist {
						return []string{"允许部门"}
					}
					return nil
				}).
				Build()
			mockey.Mock(product_service.GetOrganizationDepartmentInfoFromCache).
				Return(approvalRuleDepartmentInfo(), nil).
				Build()

			allowedDepartments, departmentInfo := loadApprovalRuleRestriction(context.Background(), "restricted@example.com")
			if len(allowedDepartments) != 1 || len(departmentInfo) != 1 {
				t.Fatalf("loadApprovalRuleRestriction() = (%v, %v), want enabled", allowedDepartments, departmentInfo)
			}
		})
	})

	t.Run("配置或缓存不可用时放行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(config.GetSwitchWhiteList).Return(nil).Build()
			allowedDepartments, departmentInfo := loadApprovalRuleRestriction(context.Background(), "restricted@example.com")
			if len(allowedDepartments) != 0 || len(departmentInfo) != 0 {
				t.Fatalf("loadApprovalRuleRestriction() = (%v, %v), want disabled", allowedDepartments, departmentInfo)
			}
		})
	})
}

func TestValidateApprovalRuleRestriction(t *testing.T) {
	allowedDepartments := map[string]struct{}{
		"创造力服务平台-官网平台-质量保障": {},
	}
	departmentInfo := map[string]*lark_client.DepartmentInfo{
		"od-platform": {Name: "创造力服务平台"},
		"od-website":  {Name: "创造力服务平台-官网平台"},
		"od-quality":  {Name: "创造力服务平台-官网平台-质量保障"},
	}

	t.Run("合法部门ID路径通过", func(t *testing.T) {
		err := validateApprovalRuleRestriction(
			[]*model.MonitorScopeConfig{
				{
					LeftValue: &model.MonitorValueConfig{Value: multienv.ApprovalCustomScopeApplicantSalesDepartment},
					RightValues: []*model.MonitorValueConfig{
						{
							Value:     "od-quality",
							ValueDesc: "od-company/od-platform/od-website/od-quality",
						},
					},
				},
			},
			allowedDepartments,
			departmentInfo,
		)
		if err != nil {
			t.Fatalf("validateApprovalRuleRestriction() error = %v", err)
		}
	})

	t.Run("未知部门ID不在错误中展示", func(t *testing.T) {
		err := validateApprovalRuleRestriction(
			[]*model.MonitorScopeConfig{
				{
					LeftValue: &model.MonitorValueConfig{Value: multienv.ApprovalCustomScopeApplicantSalesDepartment},
					RightValues: []*model.MonitorValueConfig{
						{
							Value:     "od-other",
							ValueDesc: "od-platform/od-other",
						},
					},
				},
			},
			allowedDepartments,
			departmentInfo,
		)
		if err == nil || !strings.Contains(err.Error(), "仅允许选择：创造力服务平台-官网平台-质量保障") {
			t.Fatalf("validateApprovalRuleRestriction() error = %v", err)
		}
		if strings.Contains(err.Error(), "od-other") {
			t.Fatalf("validateApprovalRuleRestriction() error = %v, must not contain department ID", err)
		}
	})

	t.Run("缺少申请人部门范围时拒绝", func(t *testing.T) {
		err := validateApprovalRuleRestriction(nil, allowedDepartments, departmentInfo)
		if err == nil || !strings.Contains(err.Error(), "必须配置【申请人（销售）所属销售团队】") {
			t.Fatalf("validateApprovalRuleRestriction() error = %v", err)
		}
	})

	t.Run("未启用限制时放行", func(t *testing.T) {
		if err := validateApprovalRuleRestriction(nil, nil, nil); err != nil {
			t.Fatalf("validateApprovalRuleRestriction() error = %v", err)
		}
	})
}

func TestValidateStoredApprovalRuleRestriction(t *testing.T) {
	allowedDepartments := map[string]struct{}{"允许部门": {}}
	departmentInfo := map[string]*lark_client.DepartmentInfo{
		"od-allowed": {Name: "允许部门"},
	}
	err := validateStoredApprovalRuleRestriction(
		&model.ApprovalRule{RuleDetail: "invalid"},
		allowedDepartments,
		departmentInfo,
	)
	if err == nil || !strings.Contains(err.Error(), "规则详情解析失败") {
		t.Fatalf("validateStoredApprovalRuleRestriction() error = %v", err)
	}
}

func approvalRuleDepartmentInfo() map[string]*lark_client.DepartmentInfo {
	return map[string]*lark_client.DepartmentInfo{
		"od-allowed": {
			DepartmentId: "od-allowed",
			Name:         "允许部门",
		},
	}
}

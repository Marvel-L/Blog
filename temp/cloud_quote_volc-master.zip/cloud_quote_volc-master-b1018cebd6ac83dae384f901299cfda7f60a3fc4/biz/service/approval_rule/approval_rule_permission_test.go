package approval_rule

import (
	"context"
	errors "errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_approvalRulePermission_rulePermissionCheck_BitsUTGen(t *testing.T) {
	t.Run("用户未登录导致权限校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟用户未登录，直接在用户校验处返回错误
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return((*model.Account)(nil), errors.New("用户未登录")).Build()

			p := approvalRulePermission{}
			ctx := context.Background()
			rule := &model.ApprovalRule{CreatorEmail: "creator@demo"}

			acc, err := p.rulePermissionCheck(ctx, rule)

			convey.So(acc, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "用户未登录")
		})
	})

	t.Run("当前用户无审批规则权限导致权限校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟当前用户存在但无审批规则操作权限
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "userA@demo"}, errors.New("当前用户没有审批规则操作权限")).Build()

			p := approvalRulePermission{}
			ctx := context.Background()
			rule := &model.ApprovalRule{CreatorEmail: "creator@demo"}

			acc, err := p.rulePermissionCheck(ctx, rule)

			convey.So(acc, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前用户没有审批规则操作权限")
		})
	})

	t.Run("非创建人编辑规则返回无操作权限错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟用户校验通过，但不是规则创建人
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "userA@demo"}, nil).Build()

			p := approvalRulePermission{}
			ctx := context.Background()
			rule := &model.ApprovalRule{CreatorEmail: "creator@demo"} // 与当前用户不一致

			acc, err := p.rulePermissionCheck(ctx, rule)

			convey.So(acc, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前用户没有此审批规则操作权限")
		})
	})

	t.Run("创建人自己操作规则成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟用户校验通过且为创建人
			mockey.Mock(approvalRulePermission.userPermissionCheck).Return(&model.Account{AccountID: "creator@demo"}, nil).Build()

			p := approvalRulePermission{}
			ctx := context.Background()
			rule := &model.ApprovalRule{CreatorEmail: "creator@demo"}

			acc, err := p.rulePermissionCheck(ctx, rule)

			convey.So(err, convey.ShouldBeNil)
			convey.So(acc, convey.ShouldNotBeNil)
			convey.So(acc.AccountID, convey.ShouldEqual, "creator@demo")
		})
	})
}

func Test_approvalRulePermission_userPermissionCheck_BitsUTGen(t *testing.T) {
	t.Run("当前用户未登录返回用户未登录错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟CurrentUser返回错误，触发用户未登录分支
			mockey.MockUnsafe(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return((*model.Account)(nil), errors.New("mock db error")).Build()

			ctx := context.Background()
			p := approvalRulePermission{}

			user, err := p.userPermissionCheck(ctx)

			convey.So(user, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "用户未登录")
		})
	})

	t.Run("当前用户无审批规则权限返回无权限错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前用户
			currentUser := &model.Account{
				AccountType: constants.AccountType("user"),
				AccountID:   "uid_123",
				Username:    "tester",
				Name:        "测试用户",
			}
			// 模拟CurrentUser返回正常用户
			mockey.MockUnsafe(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
			// 模拟权限判断为false，触发无权限分支
			mockey.MockUnsafe(constants.AccountType.CanOperateApprovalRule).Return(false).Build()

			ctx := context.Background()
			p := approvalRulePermission{}

			user, err := p.userPermissionCheck(ctx)

			convey.So(user, convey.ShouldEqual, currentUser)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前用户没有审批规则操作权限")
		})
	})

	t.Run("当前用户有审批规则权限返回用户无错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造当前用户
			currentUser := &model.Account{
				AccountType: constants.AccountType("admin"),
				AccountID:   "uid_456",
				Username:    "adminer",
				Name:        "管理员",
			}
			// 模拟CurrentUser返回正常用户
			mockey.MockUnsafe(mockey.GetMethod(dal.AccountDao, "CurrentUser")).Return(currentUser, nil).Build()
			// 模拟权限判断为true，走成功返回分支
			mockey.MockUnsafe(constants.AccountType.CanOperateApprovalRule).Return(true).Build()

			ctx := context.Background()
			p := approvalRulePermission{}

			user, err := p.userPermissionCheck(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(user, convey.ShouldEqual, currentUser)
		})
	})
}

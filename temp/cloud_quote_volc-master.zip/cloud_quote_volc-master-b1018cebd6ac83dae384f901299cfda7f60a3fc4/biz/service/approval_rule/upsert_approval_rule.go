package approval_rule

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

var (
	greaterCompareRules = map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllGreater:        true,
		multienv.ApprovalMonitorCompareRuleMaxGreater:        true,
		multienv.ApprovalMonitorCompareRuleAllGreaterOrEqual: true,
		multienv.ApprovalMonitorCompareRuleMaxGreaterOrEqual: true,
	}
	lessCompareRules = map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllLess:        true,
		multienv.ApprovalMonitorCompareRuleMinLess:        true,
		multienv.ApprovalMonitorCompareRuleAllLessOrEqual: true,
		multienv.ApprovalMonitorCompareRuleMinLessOrEqual: true,
	}
	validCompareRules = func() map[string]bool {
		m := make(map[string]bool, len(greaterCompareRules)+len(lessCompareRules))
		for k := range greaterCompareRules {
			m[k] = true
		}
		for k := range lessCompareRules {
			m[k] = true
		}
		return m
	}()
)

type UpsertApprovalRuleReq struct {
	approvalRulePermission
	RuleID                     int64                              // 规则编号
	QuoteTypes                 []int                              // 报价类型列表
	TradeTypes                 []int                              // 客户类型列表
	FormField                  string                             // 表单字段
	RuleType                   string                             // 审批规则类型
	RuleName                   string                             // 规则名称
	MonitorType                string                             // 监控类型
	MonitorScope               string                             // 监控范围
	CustomScopes               []*model.MonitorScopeConfig        // 自定义范围列表
	QuoteMonitorConfig         *model.MonitorThresholdConfig      // 整单监控配置
	ProductLineMonitorConfigs  []*model.ProductLineMonitorConfig  // 产品线监控配置列表
	TradeProductMonitorConfigs []*model.TradeProductMonitorConfig // 商品监控配置列表
	IsIntervalMode             bool                               // 是否区间模式（新前端传 true，老前端不传默认 false）
	LowerCompareRules          []string                           // 左侧/下界聚合策略列表；各条配置按自身 funcType 匹配其中一条
	UpperCompareRules          []string                           // 右侧/上界聚合策略列表；各条配置按自身 funcType 匹配其中一条
}

type UpsertApprovalRuleResp struct {
	RuleID              int64                       // 规则编号
	RepeatApprovalRules []*RepeatApprovalRuleDetail // 重复规则列表
}

type RepeatApprovalRuleDetail struct {
	RuleID     int64    // 规则编号
	RepeatKeys []string // 重复键列表
}

func (r *UpsertApprovalRuleReq) Handle(ctx context.Context) (interface{}, error) {
	if err := r.checkReq(ctx); err != nil {
		return nil, err
	}
	currentUser, err := dal.AccountDao.CurrentUser(ctx)
	if err != nil {
		return nil, errors.NewUserNotFoundErr("用户未登录")
	}
	allowedDepartments, departmentInfo := loadApprovalRuleRestriction(ctx, currentUser.AccountID)
	if err = validateApprovalRuleRestriction(r.CustomScopes, allowedDepartments, departmentInfo); err != nil {
		return nil, err
	}

	unlock, err := lockApprovalRuleOperation(ctx)
	if err != nil {
		return nil, err
	}
	defer unlock()

	tx := dal.DBProxy.NewRequest(ctx)
	var resp interface{}
	err = tx.Transaction(func(tx *gorm.DB) error {
		var err error
		resp, err = r.upsertRule(ctx, tx)
		return err
	})

	return resp, err
}

func (r *UpsertApprovalRuleReq) upsertRule(ctx context.Context, tx *gorm.DB) (*UpsertApprovalRuleResp, error) {
	currentUser, err := r.userPermissionCheck(ctx)
	if err != nil {
		return nil, err
	}

	// 内部判重：产品线配置和商品配置
	if err = r.checkInternalDuplicate(ctx); err != nil {
		return nil, err
	}

	// 构建规则详情
	ruleDetail := &model.ApprovalRuleDetailDB{
		QuoteTypes:                 r.QuoteTypes,
		TradeTypes:                 r.TradeTypes,
		FormField:                  r.FormField,
		MonitorType:                r.MonitorType,
		MonitorScope:               r.MonitorScope,
		CustomScopes:               r.CustomScopes,
		QuoteMonitorConfig:         r.QuoteMonitorConfig,
		ProductLineMonitorConfigs:  r.ProductLineMonitorConfigs,
		TradeProductMonitorConfigs: r.TradeProductMonitorConfigs,
		IsIntervalMode:             r.IsIntervalMode,
		LowerCompareRules:          r.LowerCompareRules,
		UpperCompareRules:          r.UpperCompareRules,
	}

	ruleDetailJSON, err := json.Marshal(ruleDetail)
	if err != nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "规则详情序列化失败")
	}

	if r.RuleID == 0 {
		// 创建规则
		return r.createRule(ctx, tx, currentUser.AccountID, string(ruleDetailJSON))
	}

	return r.updateRule(ctx, tx, string(ruleDetailJSON))
}

func (r *UpsertApprovalRuleReq) createRule(ctx context.Context, tx *gorm.DB, creatorEmail string, ruleDetailJSON string) (*UpsertApprovalRuleResp, error) {
	// 检查是否存在重复规则
	repeatRules, err := r.checkDuplicateRules(ctx, tx, 0)
	if err != nil {
		return nil, err
	}

	if len(repeatRules) > 0 {
		ruleIDsStr := buildDuplicateRuleIDsString(repeatRules)
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "当前审批规则和其他规则%s存在重复").WithArgs(ruleIDsStr)
	}

	ruleDB := &model.ApprovalRule{
		RuleType:     r.RuleType,
		RuleName:     r.RuleName,
		CreatorEmail: creatorEmail,
		RuleStatus:   multienv.ApprovalRuleStatusInitialed,
		RuleDetail:   ruleDetailJSON,
	}

	if err = dal.ApprovalRuleDao.SaveRule(tx, ruleDB); err != nil {
		return nil, err
	}

	return &UpsertApprovalRuleResp{
		RuleID:              ruleDB.Id,
		RepeatApprovalRules: nil,
	}, nil
}

func (r *UpsertApprovalRuleReq) updateRule(ctx context.Context, tx *gorm.DB, ruleDetailJSON string) (*UpsertApprovalRuleResp, error) {
	originRuleDB, err := dal.ApprovalRuleDao.FindRuleByID(tx, r.RuleID)
	if err != nil {
		return nil, err
	}

	if _, err = r.rulePermissionCheck(ctx, originRuleDB); err != nil {
		return nil, err
	}

	if err = r.checkOrigin(ctx, originRuleDB); err != nil {
		return nil, err
	}

	// 检查是否存在重复规则（排除自己）
	repeatRules, err := r.checkDuplicateRules(ctx, tx, r.RuleID)
	if err != nil {
		return nil, err
	}

	if len(repeatRules) > 0 {
		ruleIDsStr := buildDuplicateRuleIDsString(repeatRules)
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "当前审批规则和其他规则%s存在重复").WithArgs(ruleIDsStr)
	}

	updates := map[string]interface{}{
		"rule_type":   r.RuleType,
		"rule_name":   r.RuleName,
		"rule_detail": ruleDetailJSON,
	}
	if err = dal.ApprovalRuleDao.UpdateRuleByID(tx, originRuleDB.Id, updates); err != nil {
		return nil, err
	}

	return &UpsertApprovalRuleResp{
		RuleID:              r.RuleID,
		RepeatApprovalRules: nil,
	}, nil
}

func (r *UpsertApprovalRuleReq) checkReq(ctx context.Context) error {
	if r.RuleType == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【审批规则类型】不能为空")
	}
	if r.RuleName == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【规则名称】不能为空")
	}
	if len([]rune(r.RuleName)) > 100 {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【规则名称】长度不能超过100个字符")
	}
	if len(r.QuoteTypes) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【报价类型】不能为空")
	}
	if len(r.TradeTypes) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【客户类型】不能为空")
	}

	// 校验枚举值范围
	if err := r.checkEnumValues(ctx); err != nil {
		return err
	}

	// 跨三档量价区间：如果没有传监控类型，设置默认监控类型【exceed_three_quantity_monitor】
	if r.RuleType == multienv.ApprovalRuleTypeExceedThreeQuantity && r.MonitorType == "" {
		r.MonitorType = multienv.ApprovalMonitorTypeExceedThreeQuantity
	}

	if r.MonitorType == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【监控类型】不能为空")
	}
	if r.MonitorScope == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【监控范围】不能为空")
	}

	// 指导价监控：监控范围仅支持 产品线/商品
	if r.RuleType == multienv.ApprovalRuleTypeGuidelinePrice && r.MonitorScope == multienv.ApprovalMonitorScopeQuote {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【指导价监控】类型的审批规则，【监控范围】仅支持【产品线】或【商品】")
	}

	// 校验自定义范围：如果选择了字段名称，则右侧的值不能为空
	if err := r.checkCustomScopes(ctx); err != nil {
		return err
	}

	// 根据监控范围验证配置
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeQuote:
		if r.QuoteMonitorConfig == nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【整单监控配置】不能为空")
		}
	case multienv.ApprovalMonitorScopeProductLine:
		if len(r.ProductLineMonitorConfigs) == 0 {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【产品线监控配置】不能为空")
		}
		for _, config := range r.ProductLineMonitorConfigs {
			if config.DepartmentName == "" {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【一级产品线】不能为空")
			}
			if config.BizLineName == "" {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【二级产品线】不能为空")
			}
		}
	case multienv.ApprovalMonitorScopeTradeProduct:
		// 商品不支持为空，配置支持为空表示所有，计费项支持为空表示所有
		if len(r.TradeProductMonitorConfigs) == 0 {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【商品监控配置】不能为空")
		}
		for i, config := range r.TradeProductMonitorConfigs {
			if config == nil {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【商品监控配置】不能为空")
			}
			if config.ProductCode == "" {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【商品】不能为空")
			}
			// 校验配置和计费项的关系（需要区分公有云和私有云）
			if err := r.checkTradeProductConfigAndChargeItem(ctx, config, i+1); err != nil {
				return err
			}
			if config.ThresholdConfig != nil {
				if err := checkMonitorExtra(config.ThresholdConfig, "【商品监控配置】"); err != nil {
					return err
				}
			}
		}
	}

	// 针对特定审批规则类型，校验和修正监控函数类型
	if err := r.checkAndFixMonitorFuncType(ctx); err != nil {
		return err
	}

	// 规则层统一校验 LowerCompareRules / UpperCompareRules（仅新前端）
	if err := r.checkRuleCompareRule(ctx); err != nil {
		return err
	}

	return nil
}

func checkMonitorExtra(config *model.MonitorThresholdConfig, configName string) error {
	if config == nil {
		return nil
	}
	if config.MonitorExtra == "" {
		return nil
	}
	// 支持固定单价和单一折扣两种监控价格类型
	if config.MonitorExtra != multienv.FixedPrice && config.MonitorExtra != multienv.SimpleDiscount {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s【监控价格类型】非法，仅支持固定单价或单一折扣").WithArgs(configName)
	}
	return nil
}

// checkCustomScopes 校验自定义范围：左值、符号、右值都不能为空
func (r *UpsertApprovalRuleReq) checkCustomScopes(ctx context.Context) error {
	if len(r.CustomScopes) == 0 {
		return nil
	}

	for i, scope := range r.CustomScopes {
		if scope.LeftValue == nil || scope.LeftValue.Value == "" {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【自定义范围】第%d项：左值不能为空").WithArgs(i + 1)
		}
		if scope.MonitorFuncType == "" {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【自定义范围】第%d项：监控函数不能为空").WithArgs(i + 1)
		}
		if len(scope.RightValues) == 0 {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【自定义范围】第%d项：右值不能为空").WithArgs(i + 1)
		}
		for _, rightValue := range scope.RightValues {
			if rightValue == nil || rightValue.Value == "" {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【自定义范围】第%d项：右值不能为空").WithArgs(i + 1)
			}
		}
	}

	return nil
}

// checkEnumValues 校验枚举值范围
func (r *UpsertApprovalRuleReq) checkEnumValues(ctx context.Context) error {
	// 1. 校验报价类型
	validQuoteTypes := map[int]bool{
		multienv.QuoteTypeNormal:       true,
		multienv.QuoteTypeProjectBased: true,
		multienv.QuoteTypeProgressive:  true,
	}
	for _, quoteType := range r.QuoteTypes {
		if !validQuoteTypes[quoteType] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
				"【报价类型】包含非法值：%d，仅支持：0-普通报价、1-项目制报价、2-阶梯报价").WithArgs(quoteType)
		}
	}

	// 2. 校验客户类型
	validTradeTypes := map[int]bool{
		multienv.CustomerTypeCodeDirectSell:      true,
		multienv.CustomerTypeCodeEcoAgent:        true,
		multienv.CustomerTypeCodeEcoSell:         true,
		multienv.CustomerTypeCodeEcoDist:         true,
		multienv.CustomerTypeCodeEPSInner:        true,
		multienv.CustomerTypeCodeByteInner:       true,
		multienv.CustomerTypeCodeBPDistributor:   true,
		multienv.CustomerTypeCodeEcoSalesByProxy: true,
		multienv.CustomerTypeCodeEcoSolution:     true,
		multienv.CustomerTypeCodeSLV:             true,
		multienv.CustomerTypeCodePartnerStandard: true,
	}
	for _, tradeType := range r.TradeTypes {
		if !validTradeTypes[tradeType] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
				"【客户类型】包含非法值：%d").WithArgs(tradeType)
		}
	}

	// 3. 校验表单字段
	if r.FormField != "" {
		validFormFields := map[string]bool{
			multienv.ShiftApproval: true,
			multienv.FreeApproval:  true,
		}
		if !validFormFields[r.FormField] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
				"【表单字段】非法值：%s，仅支持：shift_approval-上升审批、free_approval-免审条件").WithArgs(r.FormField)
		}
	}

	// 4. 校验审批规则类型
	validRuleTypes := map[string]bool{
		multienv.ApprovalRuleTypeProfitCalculate:     true,
		multienv.ApprovalRuleTypeBusinessDiscount:    true,
		multienv.ApprovalRuleTypeGuidelinePrice:      true,
		multienv.ApprovalRuleTypeExceedThreeQuantity: true,
	}
	if !validRuleTypes[r.RuleType] {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
			"【审批规则类型】非法值：%s，仅支持：profit_calculate-出厂价利润监控、business_discount-商务优惠、guideline_price-指导价监控、exceed_three_quantity-跨3档量价区间").WithArgs(r.RuleType)
	}

	return nil
}

// checkAndFixMonitorFuncType 校验和修正比较函数类型
func (r *UpsertApprovalRuleReq) checkAndFixMonitorFuncType(ctx context.Context) error {
	switch r.RuleType {
	case multienv.ApprovalRuleTypeExceedThreeQuantity:
		// 跨3档量价区间：直接赋值为ApprovalMonitorFuncEqual
		return r.fixExceedThreeQuantityMonitorFunc(ctx)
	case multienv.ApprovalRuleTypeBusinessDiscount:
		// 商务优惠：校验监控范围和比较函数
		return r.checkBusinessDiscountMonitorFunc(ctx)
	case multienv.ApprovalRuleTypeGuidelinePrice:
		// 指导价监控：校验监控类型与比较函数
		return r.checkGuidelinePriceMonitorFunc(ctx)
	case multienv.ApprovalRuleTypeProfitCalculate:
		// 出厂价利润监控：校验监控类型与比较函数
		return r.checkProfitCalculateMonitorFunc(ctx)
	}
	return nil
}

// checkGuidelinePriceMonitorFunc 校验指导价监控的比较函数
func (r *UpsertApprovalRuleReq) checkGuidelinePriceMonitorFunc(ctx context.Context) error {
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeProductLine:
		for i, cfg := range r.ProductLineMonitorConfigs {
			if cfg == nil || cfg.ThresholdConfig == nil {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【指导价监控】类型的审批规则，第%d个产品线监控配置必须设置监控阈值配置").WithArgs(i + 1)
			}

			// 产品线维度仅支持单一折扣
			if cfg.ThresholdConfig.MonitorExtra != "" && cfg.ThresholdConfig.MonitorExtra != multienv.SimpleDiscount {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【指导价监控】类型的审批规则，产品线监控配置仅支持【单一折扣】监控价格类型")
			}

			// 校验监控阈值（产品线仅支持正数，无最大值限制）
			if err := checkMonitorThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}

			// 校验区间阈值（产品线允许0和正数，不限制最大值）
			if err := checkUpperThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
		}
	case multienv.ApprovalMonitorScopeTradeProduct:
		for i, cfg := range r.TradeProductMonitorConfigs {
			if cfg == nil || cfg.ThresholdConfig == nil {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【指导价监控】类型的审批规则，第%d个商品监控配置必须设置监控阈值配置").WithArgs(i + 1)
			}

			// 商品维度的价格类型校验
			if err := r.checkTradeProductPriceType(ctx, cfg, i+1); err != nil {
				return err
			}

			// 校验监控阈值（商品允许0和正数，不限制最大值）
			if err := checkMonitorThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个商品监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}

			// 校验区间阈值（商品允许0和正数，不限制最大值）
			if err := checkUpperThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个商品监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
		}
	}

	return nil
}

// checkProfitCalculateMonitorFunc 校验出厂价利润监控的比较函数
func (r *UpsertApprovalRuleReq) checkProfitCalculateMonitorFunc(ctx context.Context) error {
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeQuote:
		// 整单：需要展示监控阈值
		if r.QuoteMonitorConfig == nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【出厂价利润监控】类型的审批规则，【整单监控配置】不能为空")
		}
		// 校验监控阈值范围（利润监控允许0，无最大值限制）
		if err := checkMonitorThreshold(r.QuoteMonitorConfig, r.IsIntervalMode, "【整单监控配置】",
			MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
			return err
		}
		// 校验区间上界阈值
		if err := checkUpperThreshold(r.QuoteMonitorConfig, r.IsIntervalMode, "【整单监控配置】",
			MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
			return err
		}
	case multienv.ApprovalMonitorScopeProductLine:
		for i, cfg := range r.ProductLineMonitorConfigs {
			if cfg == nil || cfg.ThresholdConfig == nil {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【出厂价利润监控】类型的审批规则，第%d个产品线监控配置必须设置监控阈值配置").WithArgs(i + 1)
			}
			// 校验监控阈值范围（利润监控允许0，无最大值限制）
			if err := checkMonitorThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
			// 校验区间上界阈值
			if err := checkUpperThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
		}
	case multienv.ApprovalMonitorScopeTradeProduct:
		for i, cfg := range r.TradeProductMonitorConfigs {
			if cfg == nil || cfg.ThresholdConfig == nil {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【出厂价利润监控】类型的审批规则，第%d个商品监控配置必须设置监控阈值配置").WithArgs(i + 1)
			}
			// 校验监控阈值范围（利润监控允许0，无最大值限制）
			if err := checkMonitorThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个商品监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
			// 校验区间上界阈值
			if err := checkUpperThreshold(cfg.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个商品监控配置", i+1),
				MonitorThresholdRule{AllowZero: true, HasMaxLimit: false}); err != nil {
				return err
			}
		}
	}

	return nil
}

// fixExceedThreeQuantityMonitorFunc 跨3档量价区间类型处理
func (r *UpsertApprovalRuleReq) fixExceedThreeQuantityMonitorFunc(ctx context.Context) error {
	// 根据监控范围修正对应的配置
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeQuote:
		// 整单监控
		r.QuoteMonitorConfig = &model.MonitorThresholdConfig{
			MonitorFuncType:  multienv.ApprovalMonitorFuncEqual,
			MonitorThreshold: decimal.Zero,
		}
	case multienv.ApprovalMonitorScopeProductLine:
		// 产品线监控
		for _, config := range r.ProductLineMonitorConfigs {
			config.ThresholdConfig = &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncEqual,
				MonitorThreshold: decimal.Zero,
			}
		}

	case multienv.ApprovalMonitorScopeTradeProduct:
		// 商品监控
		for _, config := range r.TradeProductMonitorConfigs {
			config.ThresholdConfig = &model.MonitorThresholdConfig{
				MonitorFuncType:  multienv.ApprovalMonitorFuncEqual,
				MonitorThreshold: decimal.Zero,
			}
		}
	}

	return nil
}

// checkBusinessDiscountMonitorFunc 校验商务优惠的监控范围
func (r *UpsertApprovalRuleReq) checkBusinessDiscountMonitorFunc(ctx context.Context) error {
	// 商务优惠类型仅支持产品线监控范围
	if r.MonitorScope != multienv.ApprovalMonitorScopeProductLine {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【商务优惠】类型的审批规则仅支持【产品线】监控范围")
	}

	// 校验产品线监控配置
	for i, config := range r.ProductLineMonitorConfigs {
		if config.ThresholdConfig == nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【商务优惠】类型的审批规则，第%d个产品线监控配置必须设置监控阈值配置").WithArgs(i + 1)
		}
		// 非区间模式：MonitorFuncType不能为空；区间模式：由checkUpperThreshold校验至少一侧有值
		if !r.IsIntervalMode && config.ThresholdConfig.MonitorFuncType == "" {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【商务优惠】类型的审批规则，第%d个产品线监控配置必须设置监控函数").WithArgs(i + 1)
		}
		// 校验左侧阈值（商务优惠有最大值限制）
		if err := checkMonitorThreshold(config.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
			MonitorThresholdRule{AllowZero: true, HasMaxLimit: true}); err != nil {
			return err
		}
		// 校验区间阈值（商务优惠有最大值限制）
		if err := checkUpperThreshold(config.ThresholdConfig, r.IsIntervalMode, fmt.Sprintf("第%d个产品线监控配置", i+1),
			MonitorThresholdRule{AllowZero: true, HasMaxLimit: true}); err != nil {
			return err
		}
	}

	return nil
}

func (r *UpsertApprovalRuleReq) checkOrigin(ctx context.Context, originRuleDB *model.ApprovalRule) error {
	// 草稿状态：允许任意修改
	if originRuleDB.RuleStatus == multienv.ApprovalRuleStatusInitialed {
		return nil
	}

	// 生效状态：仅允许修改产品线范围和商品范围
	if originRuleDB.RuleStatus == multienv.ApprovalQuoteTypeEffective {
		return r.checkEffectiveRuleModification(ctx, originRuleDB)
	}

	// 其他状态：不允许编辑
	return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "当前审批规则状态不允许编辑，当前规则状态：%s").WithArgs(originRuleDB.RuleStatus)
}

// checkEffectiveRuleModification 检查对已生效规则的修改是否合法
func (r *UpsertApprovalRuleReq) checkEffectiveRuleModification(ctx context.Context, originRuleDB *model.ApprovalRule) error {
	// 解析原规则详情
	originDetail, err := originRuleDB.GetApprovalRuleDetail()
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "原规则详情解析失败")
	}

	// 检查不允许修改的字段
	if r.RuleType != originDetail.RuleType {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【审批规则类型】")
	}
	if r.RuleName != originDetail.RuleName {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【规则名称】")
	}
	if r.MonitorType != originDetail.MonitorType {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【监控类型】")
	}
	if r.MonitorScope != originDetail.MonitorScope {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【监控范围】")
	}
	if r.FormField != originDetail.FormField {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【表单字段】")
	}

	// 检查报价类型和客户类型
	if !util.IntSliceEqual(r.QuoteTypes, originDetail.QuoteTypes) {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【报价类型】")
	}
	if !util.IntSliceEqual(r.TradeTypes, originDetail.TradeTypes) {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【客户类型】")
	}

	// 检查整单监控配置
	if !r.isQuoteMonitorConfigEqual(originDetail.QuoteMonitorConfig) {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleOperationNotAllow, "生效中的规则不允许修改【整单监控配置】")
	}

	return nil
}

// isCustomScopesEqual 比较自定义范围是否相等
func (r *UpsertApprovalRuleReq) isCustomScopesEqual(originScopes []*model.MonitorScopeConfig) bool {
	if len(r.CustomScopes) != len(originScopes) {
		return false
	}

	// 简化比较：转换为JSON字符串比较
	currentJSON := util.GetJsonStr(r.CustomScopes)
	originJSON := util.GetJsonStr(originScopes)
	return currentJSON == originJSON
}

// isQuoteMonitorConfigEqual 比较整单监控配置是否相等
func (r *UpsertApprovalRuleReq) isQuoteMonitorConfigEqual(originConfig *model.MonitorThresholdConfig) bool {
	// 简化比较：转换为JSON字符串比较
	currentJSON := util.GetJsonStr(r.QuoteMonitorConfig)
	originJSON := util.GetJsonStr(originConfig)
	return currentJSON == originJSON
}

// checkInternalDuplicate 内部判重：当前规则内数据判重
// 1.监控范围=产品线：一级产品线+二级产品线，不允许重复
// 2.监控范围=商品：商品+配置+计费项，不允许重复（有多个商品时，只要有交集就认为是重复的）
//
//	a.所有选项和具体选项，支持同时存在，不互相判重；仅做同一个维度数据间的判重
func (r *UpsertApprovalRuleReq) checkInternalDuplicate(ctx context.Context) error {
	if r.MonitorScope == multienv.ApprovalMonitorScopeProductLine {
		// 产品线：一级产品线+二级产品线不允许重复
		seen := make(map[string]bool)
		for _, config := range r.ProductLineMonitorConfigs {
			key := fmt.Sprintf("%s|%s", config.DepartmentName, config.BizLineName)
			if seen[key] {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【产品线监控配置】存在重复：一级产品线=%s，二级产品线=%s").WithArgs(config.DepartmentName, config.BizLineName)
			}
			seen[key] = true
		}
	}

	if r.MonitorScope == multienv.ApprovalMonitorScopeTradeProduct {
		// 商品：商品+配置+计费项不允许重复（同一维度）
		seen := make(map[string]bool)
		for _, config := range r.TradeProductMonitorConfigs {
			key := fmt.Sprintf("%s|%s|%s", config.ProductCode, config.ConfigurationCode, config.ChargeItemCode)
			if seen[key] {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【商品监控配置】存在重复：商品=%s，配置=%s，计费项=%s").WithArgs(config.ProductCode, config.ConfigurationCode, config.ChargeItemCode)
			}
			seen[key] = true
		}
	}

	return nil
}

// checkDuplicateRules 检查是否存在重复规则
func (r *UpsertApprovalRuleReq) checkDuplicateRules(ctx context.Context, tx *gorm.DB, excludeRuleID int64) ([]*RepeatApprovalRuleDetail, error) {
	// 查询所有草稿和生效中的规则
	condition := framework.Condition{
		"rule_status": []string{multienv.ApprovalRuleStatusInitialed, multienv.ApprovalQuoteTypeEffective},
	}

	allRules, _, err := dal.ApprovalRuleDao.FindRulesByCondition(tx, condition, 10000, 1)
	if err != nil {
		return nil, err
	}

	var repeatRules []*RepeatApprovalRuleDetail

	for _, existingRule := range allRules {
		// 跳过自己和其他规则判重
		if existingRule.Id == excludeRuleID {
			continue
		}

		existingDetail, err := existingRule.GetApprovalRuleDetail()
		if err != nil {
			continue
		}

		// 步骤1：判断是否为同一维度
		if !r.isSameDimension(existingDetail) {
			continue
		}

		// 步骤2：在同一维度内进行数据判重
		if r.hasDataDuplicate(existingDetail) {
			repeatKeys := r.getRepeatKeys(existingDetail)
			repeatRules = append(repeatRules, &RepeatApprovalRuleDetail{
				RuleID:     existingRule.Id,
				RepeatKeys: repeatKeys,
			})
		}
	}

	return repeatRules, nil
}

// isSameDimension 判断是否为同一维度
func (r *UpsertApprovalRuleReq) isSameDimension(existingDetail *model.ApprovalRuleDetail) bool {
	// 条件1：6个字段全部有交集
	if !r.hasBasicFieldsIntersection(existingDetail) {
		return false
	}

	// 条件2：自定义范围全部有交集
	if !r.hasCustomScopesIntersection(existingDetail) {
		return false
	}

	// 同时满足以上两个条件说明是同一纬度，才可进行数据判重
	return true
}

// hasDataDuplicate 判断在同一维度内是否存在数据重复
func (r *UpsertApprovalRuleReq) hasDataDuplicate(existingDetail *model.ApprovalRuleDetail) bool {
	// 根据监控范围进行不同的数据判重逻辑
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeProductLine:
		return r.hasProductLineDataDuplicate(existingDetail)
	case multienv.ApprovalMonitorScopeTradeProduct:
		return r.hasTradeProductDataDuplicate(existingDetail)
	case multienv.ApprovalMonitorScopeQuote:
		// 整单监控：如果在同一维度（基础字段和自定义范围都有交集），则判定为重复
		return true
	default:
		return false
	}
}

// hasProductLineDataDuplicate 判断产品线数据是否重复
func (r *UpsertApprovalRuleReq) hasProductLineDataDuplicate(existingDetail *model.ApprovalRuleDetail) bool {
	// 构建当前规则的产品线集合
	currentProductLines := make(map[string]bool)
	for _, config := range r.ProductLineMonitorConfigs {
		key := fmt.Sprintf("%s|%s", config.DepartmentName, config.BizLineName)
		currentProductLines[key] = true
	}

	// 检查已存在规则的产品线是否有重复
	for _, existingConfig := range existingDetail.ProductLineMonitorConfigs {
		key := fmt.Sprintf("%s|%s", existingConfig.DepartmentName, existingConfig.BizLineName)
		if currentProductLines[key] {
			return true // 发现重复的产品线配置
		}
	}

	return false
}

// hasTradeProductDataDuplicate 判断商品数据是否重复（有交集）
func (r *UpsertApprovalRuleReq) hasTradeProductDataDuplicate(existingDetail *model.ApprovalRuleDetail) bool {
	// 构建当前规则的商品集合
	currentProducts := make(map[string]bool)
	for _, config := range r.TradeProductMonitorConfigs {
		key := fmt.Sprintf("%s|%s|%s", config.ProductCode, config.ConfigurationCode, config.ChargeItemCode)
		currentProducts[key] = true
	}

	// 检查已存在规则的商品是否有交集
	for _, existingConfig := range existingDetail.TradeProductMonitorConfigs {
		key := fmt.Sprintf("%s|%s|%s", existingConfig.ProductCode, existingConfig.ConfigurationCode, existingConfig.ChargeItemCode)
		if currentProducts[key] {
			return true // 发现重复的商品配置
		}
	}

	return false
}

// hasBasicFieldsIntersection 判断基础字段是否全部有交集
func (r *UpsertApprovalRuleReq) hasBasicFieldsIntersection(existingDetail *model.ApprovalRuleDetail) bool {
	// 1. 报价类型（多选）
	if len(util.SliceIntersect(r.QuoteTypes, existingDetail.QuoteTypes)) == 0 {
		return false
	}

	// 2. 客户类型（多选）
	if len(util.SliceIntersect(r.TradeTypes, existingDetail.TradeTypes)) == 0 {
		return false
	}

	// 3. 表单字段（单选）
	if r.FormField != existingDetail.FormField {
		return false
	}

	// 4. 审批规则类型（单选）
	if r.RuleType != existingDetail.RuleType {
		return false
	}

	// 5. 监控范围（单选）
	if r.MonitorScope != existingDetail.MonitorScope {
		return false
	}

	// 6. 监控类型（单选）
	if r.MonitorType != existingDetail.MonitorType {
		return false
	}

	return true
}

// hasCustomScopesIntersection 判断自定义范围是否全部有交集
func (r *UpsertApprovalRuleReq) hasCustomScopesIntersection(existingDetail *model.ApprovalRuleDetail) bool {
	// 将自定义范围按类型分组
	currentScopes := r.groupCustomScopesByType()
	existingScopes := groupCustomScopesByType(existingDetail.CustomScopes)

	// 获取所有类型
	allTypes := make(map[string]bool)
	for t := range currentScopes {
		allTypes[t] = true
	}
	for t := range existingScopes {
		allTypes[t] = true
	}

	// 检查每个类型是否有交集
	for scopeType := range allTypes {
		currentValues := currentScopes[scopeType]
		existingValues := existingScopes[scopeType]

		// 如果某个规则不存在该类型，认为是所有选项
		if len(currentValues) == 0 || len(existingValues) == 0 {
			// 有一个为空（所有），认为有交集
			continue
		}

		// 两个都存在，判断是否有交集
		if len(util.StrSliceIntersect(currentValues, existingValues)) == 0 {
			// 必须所有自定义范围，全部存在交集，则认为是同一个维度
			return false
		}
	}

	return true
}

// groupCustomScopesByType 将自定义范围按类型分组
func (r *UpsertApprovalRuleReq) groupCustomScopesByType() map[string][]string {
	result := make(map[string][]string)
	for _, scope := range r.CustomScopes {
		if scope.LeftValue != nil && scope.LeftValue.Value != "" {
			scopeType := scope.LeftValue.Value
			values := make([]string, 0)
			for _, rv := range scope.RightValues {
				if rv != nil {
					values = append(values, rv.Value)
				}
			}
			result[scopeType] = values
		}
	}
	return result
}

func groupCustomScopesByType(scopes []*model.MonitorScopeConfig) map[string][]string {
	result := make(map[string][]string)
	for _, scope := range scopes {
		if scope.LeftValue != nil && scope.LeftValue.Value != "" {
			scopeType := scope.LeftValue.Value
			values := make([]string, 0)
			for _, rv := range scope.RightValues {
				if rv != nil {
					values = append(values, rv.Value)
				}
			}
			result[scopeType] = values
		}
	}
	return result
}

// buildDuplicateRuleIDsString 构建重复规则ID列表字符串
func buildDuplicateRuleIDsString(repeatRules []*RepeatApprovalRuleDetail) string {
	var ruleIDs []string
	for _, repeatRule := range repeatRules {
		ruleIDs = append(ruleIDs, fmt.Sprintf("%d", repeatRule.RuleID))
	}
	return strings.Join(ruleIDs, "、")
}

// getRepeatKeys 获取重复的维度键
func (r *UpsertApprovalRuleReq) getRepeatKeys(existingDetail *model.ApprovalRuleDetail) []string {
	keys := []string{
		fmt.Sprintf("报价类型:%v", existingDetail.QuoteTypes),
		fmt.Sprintf("客户类型:%v", existingDetail.TradeTypes),
		fmt.Sprintf("表单字段:%s", existingDetail.FormField),
		fmt.Sprintf("审批规则类型:%s", existingDetail.RuleType),
		fmt.Sprintf("监控范围:%s", existingDetail.MonitorScope),
		fmt.Sprintf("监控类型:%s", existingDetail.MonitorType),
	}

	if len(existingDetail.CustomScopes) > 0 {
		keys = append(keys, fmt.Sprintf("自定义范围:%d个", len(existingDetail.CustomScopes)))
	}

	return keys
}

// checkTradeProductPriceType 校验商品维度的价格类型
func (r *UpsertApprovalRuleReq) checkTradeProductPriceType(ctx context.Context, cfg *model.TradeProductMonitorConfig, index int) error {
	if cfg.ThresholdConfig == nil || cfg.ThresholdConfig.MonitorExtra == "" {
		return nil
	}

	// 如果选择了固定单价类型
	if cfg.ThresholdConfig.MonitorExtra == multienv.FixedPrice {
		// 1. 必须选择到具体计费项
		if cfg.ChargeItemCode == "" || cfg.ChargeItemCode == constants.SelectAll {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
				"【指导价监控】类型的审批规则，第%d个商品监控配置选择【固定单价】类型时，必须选择具体计费项").WithArgs(index)
		}

		// 2. 校验计费项刊例价价格类型
		if err := r.validateChargeItemPriceType(ctx, cfg, index); err != nil {
			return err
		}
	}

	return nil
}

// checkTradeProductConfigAndChargeItem 校验商品监控配置中配置和计费项的关系
// - 公有云商品：配置为空时，计费项必须为空（表示所有）
// - 私有云商品：配置可以为空，可以直接选择计费项
func (r *UpsertApprovalRuleReq) checkTradeProductConfigAndChargeItem(ctx context.Context, config *model.TradeProductMonitorConfig, index int) error {
	if err := ValidateTradeProductConfigAndChargeItem(ctx, config.ProductCode, config.ConfigurationCode, config.ChargeItemCode); err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
			"第%d个商品监控配置：%s").WithArgs(index, err.Error())
	}
	return nil
}

// validateChargeItemPriceType 校验计费项刊例价价格类型
func (r *UpsertApprovalRuleReq) validateChargeItemPriceType(ctx context.Context, cfg *model.TradeProductMonitorConfig, index int) error {
	// 获取商品信息，填充ProductType和StandardProduct
	productInfo, err := commodity_service.GetProductInfoFromCache(ctx, cfg.ProductCode)
	if err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
			"【指导价监控】类型的审批规则，第%d个商品监控配置获取商品信息失败：%s").WithArgs(index, err.Error())
	}
	if err := ValidateChargeItemPriceTypeForFixedPrice(ctx, cfg.ProductCode, cfg.ConfigurationCode, cfg.ChargeItemCode, productInfo); err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
			"【指导价监控】类型的审批规则，第%d个商品监控配置%s").WithArgs(index, err.Error())
	}

	return nil
}

// MonitorThresholdRule 监控阈值校验规则
type MonitorThresholdRule struct {
	AllowZero   bool // 是否允许输入0
	HasMaxLimit bool // 是否有最大值限制
}

// checkMonitorThreshold 校验监控阈值（左侧/下界）
func checkMonitorThreshold(config *model.MonitorThresholdConfig, isIntervalMode bool, configName string, rule MonitorThresholdRule) error {
	if config == nil {
		return nil
	}
	// 区间模式仅配右侧时，左侧阈值无业务意义，跳过校验
	if isIntervalMode && config.MonitorFuncType == "" {
		return nil
	}
	if err := ValidateMonitorThresholdString(config.MonitorThreshold.String(), rule.AllowZero); err != nil {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s%s").WithArgs(configName, err.Error())
	}

	// 最大值为100（仅当有最大值限制时）
	if rule.HasMaxLimit {
		maxThreshold := decimal.NewFromInt(100)
		if config.MonitorThreshold.GreaterThan(maxThreshold) {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s【监控阈值】最大值为100").WithArgs(configName)
		}
	}

	return nil
}

// checkUpperThreshold 校验区间上界（仅 isIntervalMode=true 时生效）
// 校验项：
//  1. 左右至少一侧有值（MonitorFuncType 和 UpperFuncType 不能同时为空）
//  2. 若配置了上界，校验上界阈值的范围（非负、最大值限制）
//  3. 若两侧都配置，下界 ≤ 上界
func checkUpperThreshold(config *model.MonitorThresholdConfig, isIntervalMode bool, configName string, rule MonitorThresholdRule) error {
	if config == nil || !isIntervalMode {
		return nil
	}

	// 至少一侧有值
	if config.MonitorFuncType == "" && config.UpperFuncType == "" {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s【区间配置】至少需要配置一侧阈值（下界或上界）").WithArgs(configName)
	}

	// 如果配置了上界函数，需要校验上界阈值
	if config.UpperFuncType != "" {
		if err := ValidateMonitorThresholdString(config.UpperThreshold.String(), rule.AllowZero); err != nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s%s").WithArgs(configName, err.Error())
		}

		// 最大值限制（如果有）
		if rule.HasMaxLimit {
			maxThreshold := decimal.NewFromInt(100)
			if config.UpperThreshold.GreaterThan(maxThreshold) {
				return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s【上界阈值】最大值为100").WithArgs(configName)
			}
		}
	}

	// 如果两侧都配置了，需要校验区间语义：左边界<=右边界
	if config.MonitorFuncType != "" && config.UpperFuncType != "" {
		if config.MonitorThreshold.GreaterThan(config.UpperThreshold) {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "%s【区间配置】下界阈值不能大于上界阈值").WithArgs(configName)
		}
	}

	return nil
}

// checkRuleCompareRule 规则层统一校验 LowerCompareRules / UpperCompareRules
// 老前端（IsIntervalMode=false）：直接跳过，触发时走 default 兜底
// 新前端（IsIntervalMode=true）：
//   - LowerCompareRules 和 UpperCompareRules 至少一个非空
//   - 各元素必须合法
//   - 存在左侧区间（leftFuncType 非空）时，LowerCompareRules 必须含至少一个大于类规则
//   - 存在右侧区间（upperFuncType 非空）时，UpperCompareRules 必须含至少一个小于类规则
//   - 每条配置的 leftFuncType 必须在 LowerCompareRules 中能找到匹配方向的规则
//   - 每条配置的 upperFuncType 必须在 UpperCompareRules 中能找到匹配方向的规则
func (r *UpsertApprovalRuleReq) checkRuleCompareRule(ctx context.Context) error {
	// 整单维度不需要 CompareRule
	if r.MonitorScope == multienv.ApprovalMonitorScopeQuote {
		return nil
	}

	// 跨3档量价区间不走阈值规则聚合逻辑
	if r.RuleType == multienv.ApprovalRuleTypeExceedThreeQuantity {
		return nil
	}

	// 老前端（全为非区间模式）：直接跳过，不校验
	if !r.hasAnyIntervalMode() {
		return nil
	}

	// 新前端：至少一个非空
	if len(r.LowerCompareRules) == 0 && len(r.UpperCompareRules) == 0 {
		return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【监控阈值规则】不能为空，请至少配置下界或上界监控阈值规则")
	}

	// 校验各元素合法性，同时分类统计
	hasGreaterStrict := false  // 含严格大于类（>）
	hasGreaterOrEqual := false // 含大于等于类（>=）
	hasLessStrict := false     // 含严格小于类（<）
	hasLessOrEqual := false    // 含小于等于类（<=）

	greaterStrictRules := map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllGreater: true,
		multienv.ApprovalMonitorCompareRuleMaxGreater: true,
	}
	greaterOrEqualRules := map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllGreaterOrEqual: true,
		multienv.ApprovalMonitorCompareRuleMaxGreaterOrEqual: true,
	}
	lessStrictRules := map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllLess: true,
		multienv.ApprovalMonitorCompareRuleMinLess: true,
	}
	lessOrEqualRules := map[string]bool{
		multienv.ApprovalMonitorCompareRuleAllLessOrEqual: true,
		multienv.ApprovalMonitorCompareRuleMinLessOrEqual: true,
	}

	for _, rule := range r.LowerCompareRules {
		if !validCompareRules[rule] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【下界监控阈值规则】包含非法值：%s").WithArgs(rule)
		}
		if !greaterCompareRules[rule] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【下界监控阈值规则】只能选大于类规则，非法值：%s").WithArgs(rule)
		}
		if greaterStrictRules[rule] {
			hasGreaterStrict = true
		}
		if greaterOrEqualRules[rule] {
			hasGreaterOrEqual = true
		}
	}
	for _, rule := range r.UpperCompareRules {
		if !validCompareRules[rule] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【上界监控阈值规则】包含非法值：%s").WithArgs(rule)
		}
		if !lessCompareRules[rule] {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "【上界监控阈值规则】只能选小于类规则，非法值：%s").WithArgs(rule)
		}
		if lessStrictRules[rule] {
			hasLessStrict = true
		}
		if lessOrEqualRules[rule] {
			hasLessOrEqual = true
		}
	}

	// 按每条配置的 funcType 强校验数组中必须有对应方向的规则
	var checkErr error
	r.forEachThresholdConfig(func(tc *model.MonitorThresholdConfig, configName string) bool {
		if tc == nil {
			return false
		}
		// LowerCompareRules 非空时，必须填左侧符号；否则命中时 funcType 为空，永远不命中
		if len(r.LowerCompareRules) > 0 && tc.MonitorFuncType == "" {
			checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
				"%s 配置了下界监控阈值规则，左侧符号不能为空").WithArgs(configName)
			return true
		}
		// UpperCompareRules 非空时，必须填右侧符号
		if len(r.UpperCompareRules) > 0 && tc.UpperFuncType == "" {
			checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
				"%s 配置了上界监控阈值规则，右侧符号不能为空").WithArgs(configName)
			return true
		}
		if tc.MonitorFuncType != "" {
			// 区间左侧符号只允许 < 或 <=（语义为 阈值 < x 或 阈值 <= x）
			if tc.MonitorFuncType != multienv.ApprovalMonitorFuncLessThan &&
				tc.MonitorFuncType != multienv.ApprovalMonitorFuncLessThanOrEqual {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
					"%s 左侧符号只能为 < 或 <=，非法值：%s").WithArgs(configName, tc.MonitorFuncType)
				return true
			}
			// less_than_or_equal 在左侧语义为 阈值 <= x（即 x >= 阈值），需要大于等于类规则
			// less_than 在左侧语义为 阈值 < x（即 x > 阈值），需要严格大于类规则
			if tc.MonitorFuncType == multienv.ApprovalMonitorFuncLessThanOrEqual && !hasGreaterOrEqual {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
					"%s 左侧符号为 <= 时，【下界监控阈值规则】必须包含大于等于类规则").WithArgs(configName)
				return true
			}
			if tc.MonitorFuncType == multienv.ApprovalMonitorFuncLessThan && !hasGreaterStrict {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
					"%s 左侧符号为 < 时，【下界监控阈值规则】必须包含大于类规则").WithArgs(configName)
				return true
			}
		}
		if tc.UpperFuncType != "" {
			// 区间右侧符号只允许 < 或 <=
			if tc.UpperFuncType != multienv.ApprovalMonitorFuncLessThan &&
				tc.UpperFuncType != multienv.ApprovalMonitorFuncLessThanOrEqual {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal,
					"%s 右侧符号只能为 < 或 <=，非法值：%s").WithArgs(configName, tc.UpperFuncType)
				return true
			}
			if tc.UpperFuncType == multienv.ApprovalMonitorFuncLessThan && !hasLessStrict {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
					"%s 右侧符号为 < 时，【上界监控阈值规则】必须包含小于类规则").WithArgs(configName)
				return true
			}
			if tc.UpperFuncType == multienv.ApprovalMonitorFuncLessThanOrEqual && !hasLessOrEqual {
				checkErr = errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss,
					"%s 右侧符号为 <= 时，【上界监控阈值规则】必须包含小于等于类规则").WithArgs(configName)
				return true
			}
		}
		return false
	})
	return checkErr
}

// hasAnyIntervalMode 是否为区间模式（即新前端）
func (r *UpsertApprovalRuleReq) hasAnyIntervalMode() bool {
	return r.IsIntervalMode
}

// forEachThresholdConfig 遍历区间模式下的所有阈值配置，fn 返回 true 时提前终止
func (r *UpsertApprovalRuleReq) forEachThresholdConfig(fn func(tc *model.MonitorThresholdConfig, configName string) bool) {
	if !r.IsIntervalMode {
		return
	}
	switch r.MonitorScope {
	case multienv.ApprovalMonitorScopeProductLine:
		for i, cfg := range r.ProductLineMonitorConfigs {
			if cfg == nil {
				continue
			}
			if fn(cfg.ThresholdConfig, fmt.Sprintf("第%d个产品线监控配置", i+1)) {
				return
			}
		}
	case multienv.ApprovalMonitorScopeTradeProduct:
		for i, cfg := range r.TradeProductMonitorConfigs {
			if cfg == nil {
				continue
			}
			if fn(cfg.ThresholdConfig, fmt.Sprintf("第%d个商品监控配置", i+1)) {
				return
			}
		}
	}
}

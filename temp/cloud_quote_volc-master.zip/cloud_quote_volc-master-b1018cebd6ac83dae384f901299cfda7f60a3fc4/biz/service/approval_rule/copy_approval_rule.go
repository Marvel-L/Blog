package approval_rule

import (
	"context"
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/gopkg/logs"
)

type CopyApprovalRuleReq struct {
	approvalRulePermission
	RuleID int64 // 被复制的规则编号
}

type CopyApprovalRuleResp struct {
	RuleID int64 // 新生成的草稿规则编号
}

func (r *CopyApprovalRuleReq) Handle(ctx context.Context) (interface{}, error) {
	if r.RuleID <= 0 {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "【规则编号】不能为空")
	}

	currentUser, err := r.userPermissionCheck(ctx)
	if err != nil {
		return nil, err
	}

	unlock, err := lockApprovalRuleOperation(ctx)
	if err != nil {
		return nil, err
	}
	defer unlock()

	tx := dal.DBProxy.NewRequest(ctx)
	var resp *CopyApprovalRuleResp
	err = tx.Transaction(func(tx *gorm.DB) error {
		originRule, err := dal.ApprovalRuleDao.FindRuleByID(tx, r.RuleID)
		if err != nil {
			return err
		}
		if _, err = originRule.GetApprovalRuleDetail(); err != nil {
			return errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamIllegal, "原规则详情解析失败，无法复制")
		}

		newRule := &model.ApprovalRule{
			RuleType:      originRule.RuleType,
			RuleName:      originRule.RuleName,
			CreatorEmail:  currentUser.AccountID,
			RuleStatus:    multienv.ApprovalRuleStatusInitialed,
			EffectiveTime: time.Time{},
			RuleDetail:    originRule.RuleDetail,
		}
		if err = dal.ApprovalRuleDao.SaveRule(tx, newRule); err != nil {
			return err
		}

		logs.CtxInfo(ctx, "[CopyApprovalRule] originRuleID=%d, newRuleID=%d, operator=%s",
			originRule.Id, newRule.Id, currentUser.AccountID)
		resp = &CopyApprovalRuleResp{RuleID: newRule.Id}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return resp, nil
}

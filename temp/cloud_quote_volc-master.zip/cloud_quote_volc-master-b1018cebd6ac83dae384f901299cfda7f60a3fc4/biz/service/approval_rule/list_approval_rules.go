package approval_rule

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type ListApprovalRulesReq struct {
	approvalRulePermission
	framework.Pagination
	RuleTypes             []string // 审批规则类型列表
	RuleName              string   // 规则名称
	RuleID                string   // 规则编号（支持模糊搜索，所以类型定义为string）
	CreatorEmails         []string // 创建人邮箱列表
	RuleStatus            []string // 规则状态列表
	CreatedTimeStartStr   string   // 创建时间开始时间
	CreatedTimeEndStr     string   // 创建时间结束时间
	EffectiveTimeStartStr string   // 生效时间开始时间
	EffectiveTimeEndStr   string   // 生效时间结束时间
}

type ListApprovalRulesResp struct {
	framework.Pagination
	List []*ApprovalRuleBaseInfo
}

type ApprovalRuleBaseInfo struct {
	RuleID        int64     // 规则编号
	RuleType      string    // 审批规则类型
	RuleName      string    // 规则名称
	CreatorEmail  string    // 创建人邮箱
	RuleStatus    string    // 规则状态
	CreatedTime   time.Time // 创建时间
	UpdatedTime   time.Time // 更新时间
	EffectiveTime time.Time // 生效时间
}

func (r *ListApprovalRulesReq) Handle(ctx context.Context) (interface{}, error) {
	if _, err := r.userPermissionCheck(ctx); err != nil {
		return nil, err
	}

	tx := dal.DBProxy.NewRequest(ctx)

	condition, err := r.getCondition()
	if err != nil {
		return nil, err
	}

	rules, total, err := dal.ApprovalRuleDao.FindRulesByCondition(tx, condition, r.Limit, r.Offset)
	if err != nil {
		return nil, err
	}

	list := make([]*ApprovalRuleBaseInfo, 0, len(rules))
	for _, rule := range rules {
		list = append(list, &ApprovalRuleBaseInfo{
			RuleID:        rule.Id,
			RuleType:      rule.RuleType,
			RuleName:      rule.RuleName,
			CreatorEmail:  rule.CreatorEmail,
			RuleStatus:    rule.RuleStatus,
			CreatedTime:   rule.CreatedTime,
			UpdatedTime:   rule.UpdatedTime,
			EffectiveTime: rule.EffectiveTime,
		})
	}

	return &ListApprovalRulesResp{
		Pagination: framework.Pagination{
			Limit:  r.Limit,
			Offset: r.Offset,
			Total:  total,
		},
		List: list,
	}, nil
}

func (r *ListApprovalRulesReq) getCondition() (framework.Condition, error) {
	condition := framework.Condition{}

	if len(r.RuleTypes) > 0 {
		condition["rule_type"] = r.RuleTypes
	}

	if r.RuleName != "" {
		condition["rule_name like"] = dal.MakeFuzzQuery(r.RuleName)
	}

	if r.RuleID != "" {
		condition["id like"] = dal.MakeFuzzQuery(r.RuleID)
	}

	if len(r.CreatorEmails) > 0 {
		condition["creator_email"] = r.CreatorEmails
	}

	if len(r.RuleStatus) > 0 {
		condition["rule_status"] = r.RuleStatus
	}

	if r.CreatedTimeStartStr != "" && r.CreatedTimeEndStr != "" {
		var err error
		var startTime, endTime time.Time
		if startTime, err = util.CheckTime(r.CreatedTimeStartStr); err != nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNTimeFormatError, "【创建时间-开始时间】格式不正确")
		}
		if endTime, err = util.CheckTime(r.CreatedTimeEndStr); err != nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNTimeFormatError, "【创建时间-结束时间】格式不正确")
		}
		condition["created_time >="] = util.ToBeginningOfDay(startTime)
		condition["created_time <="] = util.ToEndOfDay(endTime)
	}

	if r.EffectiveTimeStartStr != "" && r.EffectiveTimeEndStr != "" {
		var err error
		var startTime, endTime time.Time
		if startTime, err = util.CheckTime(r.EffectiveTimeStartStr); err != nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNTimeFormatError, "【生效时间-开始时间】格式不正确")
		}
		if endTime, err = util.CheckTime(r.EffectiveTimeEndStr); err != nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNTimeFormatError, "【生效时间-结束时间】格式不正确")
		}
		condition["effective_time >="] = util.ToBeginningOfDay(startTime)
		condition["effective_time <="] = util.ToEndOfDay(endTime)
	}

	return condition, nil
}

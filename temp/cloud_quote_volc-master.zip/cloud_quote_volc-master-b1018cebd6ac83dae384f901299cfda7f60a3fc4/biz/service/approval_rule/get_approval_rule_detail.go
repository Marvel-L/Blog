package approval_rule

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

type GetApprovalRuleDetailReq struct {
	approvalRulePermission
	RuleID int64 // 规则编号
}

type GetApprovalRuleDetailResp struct {
	RuleID                     int64                              // 规则编号
	RuleStatus                 string                             // 规则状态
	QuoteTypes                 []int                              // 报价类型列表
	TradeTypes                 []int                              // 客户类型列表
	FormField                  string                             // 表单字段
	RuleType                   string                             // 审批规则类型
	RuleName                   string                             // 规则名称
	MonitorType                string                             // 监控类型
	MonitorScope               string                             // 监控范围
	CustomScopes               []*model.MonitorScopeConfig        // 自定义范围列表
	QuoteMonitorConfig         *model.MonitorThresholdConfig      // 整单监控配置
	ProductLineMonitorConfigs  []*model.ProductLineMonitorConfig  // 产品线监控配置列表
	TradeProductMonitorConfigs []*model.TradeProductMonitorConfig // 商品监控配置列表
	IsIntervalMode             bool                               // 是否区间模式
	LowerCompareRules          []string                           // 左侧/下界聚合策略列表
	UpperCompareRules          []string                           // 右侧/上界聚合策略列表
}

func (r *GetApprovalRuleDetailReq) Handle(ctx context.Context) (interface{}, error) {
	// 查看他人规则：超管可以查看所有规则
	if _, err := r.userPermissionCheck(ctx); err != nil {
		return nil, err
	}

	tx := dal.DBProxy.NewRequest(ctx)

	// 查询规则基本信息
	ruleDB, err := dal.ApprovalRuleDao.FindRuleByID(tx, r.RuleID)
	if err != nil {
		return nil, err
	}

	// 解析规则详情
	ruleDetail, err := ruleDB.GetApprovalRuleDetail()
	if err != nil {
		return nil, err
	}
	resp := &GetApprovalRuleDetailResp{
		RuleID:                     ruleDetail.RuleID,
		RuleStatus:                 ruleDetail.RuleStatus,
		QuoteTypes:                 ruleDetail.QuoteTypes,
		TradeTypes:                 ruleDetail.TradeTypes,
		FormField:                  ruleDetail.FormField,
		RuleType:                   ruleDetail.RuleType,
		RuleName:                   ruleDetail.RuleName,
		MonitorType:                ruleDetail.MonitorType,
		MonitorScope:               ruleDetail.MonitorScope,
		CustomScopes:               ruleDetail.CustomScopes,
		QuoteMonitorConfig:         ruleDetail.QuoteMonitorConfig,
		ProductLineMonitorConfigs:  ruleDetail.ProductLineMonitorConfigs,
		TradeProductMonitorConfigs: ruleDetail.TradeProductMonitorConfigs,
		IsIntervalMode:             ruleDetail.IsIntervalMode,
		LowerCompareRules:          ruleDetail.LowerCompareRules,
		UpperCompareRules:          ruleDetail.UpperCompareRules,
	}

	return resp, nil
}

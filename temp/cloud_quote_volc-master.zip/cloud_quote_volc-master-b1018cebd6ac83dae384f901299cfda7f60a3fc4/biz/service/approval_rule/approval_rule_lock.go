package approval_rule

import (
	"context"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/redis_client"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
)

func lockApprovalRuleOperation(ctx context.Context) (func(), error) {
	lockValue := logid.GenLogID()
	var err error
	for i := 0; i < 3; i++ {
		ruleLock := redis_client.RedisLock{
			LockKey: multienv.ApprovalRuleMutexLockRuleIDKey,
			Value:   lockValue,
			Timeout: 60 * time.Second,
		}
		if err = ruleLock.Lock(); err == nil {
			return ruleLock.Unlock, nil
		}
		time.Sleep(time.Millisecond * 500)
	}
	logs.CtxWarn(ctx, "获取审批规则操作锁失败，key=%s, err=%v", multienv.ApprovalRuleMutexLockRuleIDKey, err)
	return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleInOperation, "当前审批规则正在操作中，请稍后重试")
}

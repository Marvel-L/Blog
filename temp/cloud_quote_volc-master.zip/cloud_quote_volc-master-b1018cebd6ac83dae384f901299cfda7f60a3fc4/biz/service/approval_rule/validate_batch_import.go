package approval_rule

import (
	"context"
	errors2 "errors"
	"fmt"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/fileparser"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_config_load"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/lark_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/trade_client"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

type ValidateApprovalRuleBatchImportReq struct {
	ModelKey    string `json:",required"` // 模版类型（approvalRuleProductLineUpload/approvalRuleTradeProductUpload）
	ModelUrl    string `json:",required"`
	RuleType    string `json:"RuleType"`    // 审批规则类型
	MonitorType string `json:"MonitorType"` // 监控类型
	FormField   string `json:"FormField"`   // 表单字段（上升审批/免审条件）
}

type ValidateApprovalRuleBatchImportResp struct {
	ErrorDetails          map[int][]string                                 `json:"ErrorDetails"` // 行号 -> 错误信息列表
	ModelUrl              string                                           `json:"ModelUrl"`
	ValidatedProductLine  []*fileparser.UploadApprovalRuleProductLineData  `json:"ValidatedProductLine,omitempty"`  // 校验通过的产品线数据
	ValidatedTradeProduct []*fileparser.UploadApprovalRuleTradeProductData `json:"ValidatedTradeProduct,omitempty"` // 校验通过的商品数据
}

// IsSuccess 判断校验是否成功（无错误）
func (r *ValidateApprovalRuleBatchImportResp) IsSuccess() bool {
	if r == nil {
		return false
	}
	return len(r.ErrorDetails) == 0
}

func (r *ValidateApprovalRuleBatchImportReq) Handle(ctx context.Context) (interface{}, error) {
	// 0. 校验必填字段
	if r.RuleType == "" {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "审批规则类型不能为空")
	}
	if r.MonitorType == "" {
		return nil, errors.NewBizErrWithMsg(errors.CodeNApprovalRuleParamMiss, "监控类型不能为空")
	}

	// 1. 解析飞书表格
	uploadDataList, _, err := fileparser.Parse(ctx, r.ModelUrl, r.ModelKey)
	if err != nil {
		logs.CtxError(ctx, "解析飞书表格失败: %v", err)
		return nil, err
	}

	// 2. 根据不同的模板类型进行校验
	var resp *ValidateApprovalRuleBatchImportResp
	switch r.ModelKey {
	case constants.UploadModeKeyApprovalRuleProductLine:
		productLineDataList, ok := uploadDataList.([]*fileparser.UploadApprovalRuleProductLineData)
		if !ok {
			return nil, errors.ErrCustomerError.WithArgs("产品线数据解析错误")
		}
		logs.CtxInfo(ctx, "成功解析产品线数据，共 %d 行", len(productLineDataList))
		for i, data := range productLineDataList {
			logs.CtxInfo(ctx, "第 %d 行数据: %+v", i+1, data)
		}
		resp, err = r.validateProductLineData(ctx, productLineDataList)
	case constants.UploadModeKeyApprovalRuleTradeProduct:
		tradeProductDataList, ok := uploadDataList.([]*fileparser.UploadApprovalRuleTradeProductData)
		if !ok {
			return nil, errors.ErrCustomerError.WithArgs("商品数据解析错误")
		}
		logs.CtxInfo(ctx, "成功解析商品数据，共 %d 行", len(tradeProductDataList))
		for i, data := range tradeProductDataList {
			logs.CtxInfo(ctx, "第 %d 行数据: %+v", i+1, data)
		}
		resp, err = r.validateTradeProductData(ctx, tradeProductDataList)
	default:
		return nil, errors.ErrCustomerError.WithArgs("不支持的导入类型")
	}

	if err != nil {
		return nil, err
	}

	// 将错误信息写入飞书表格（即使没有错误也要写入，以清空之前的错误信息）
	if resp != nil {
		if err := r.updateLarkSheetWithErrors(ctx, resp.ErrorDetails); err != nil {
			logs.CtxError(ctx, "写入错误信息到飞书表格失败: %v", err)
		}
	}

	return resp, nil
}

// validateProductLineData 校验产品线导入数据
func (r *ValidateApprovalRuleBatchImportReq) validateProductLineData(ctx context.Context, dataList []*fileparser.UploadApprovalRuleProductLineData) (*ValidateApprovalRuleBatchImportResp, error) {
	resp := &ValidateApprovalRuleBatchImportResp{
		ErrorDetails:         make(map[int][]string),
		ModelUrl:             r.ModelUrl,
		ValidatedProductLine: []*fileparser.UploadApprovalRuleProductLineData{},
	}

	// 获取所有产品线信息用于校验
	productLineMap, err := getProductLineMap(ctx)
	if err != nil {
		return nil, err
	}

	// 使用map判重，key为数据唯一标识, value为第一次出现的行号
	duplicateCheckMap := make(map[string]int)

	for _, data := range dataList {
		if data.IsBlankData() {
			continue
		}

		var rowErrors []string

		// 1. 表格内容合法性校验
		// a. 二级产品线支持所有选项，为空时默认为"所有选项"
		if data.SecondProductLineName == "" {
			data.SecondProductLineName = constants.SelectAll
		}

		// 2. 表格内数据判重
		// 判重维度：审批规则类型 + 一级产品线 + 二级产品线 + 监控符号 + 监控阈值
		duplicateKey := fmt.Sprintf("%s|%s|%s|%s|%s",
			data.RuleType,
			data.FirstProductLineName,
			data.SecondProductLineName,
			data.MonitorSymbol,
			data.MonitorThreshold)
		if firstRowIndex, exists := duplicateCheckMap[duplicateKey]; exists {
			rowErrors = append(rowErrors, fmt.Sprintf("与第%d行数据重复", firstRowIndex+1))
		} else {
			duplicateCheckMap[duplicateKey] = data.DataIndex
		}

		// 3. 表格内容合法性校验
		// a. 跨三档量价区间，允许监控符号为空，监控阈值无需填写，后端直接过滤无监控符号
		ruleTypeEnum := getApprovalRuleTypeFromChinese(data.RuleType)
		isExceedThreeQuantity := ruleTypeEnum == multienv.ApprovalRuleTypeExceedThreeQuantity
		if !isExceedThreeQuantity {
			if data.MonitorSymbol == "" {
				rowErrors = append(rowErrors, "监控符号不能为空")
			}
			// 监控阈值校验
			if err := ValidateMonitorThresholdString(data.MonitorThreshold, true); err != nil {
				rowErrors = append(rowErrors, getErrorMessage(err))
			}
		}

		// b. 校验填写的一级产品线&二级产品线合法性
		// i. 校验一级产品线名称是否存在
		secondLineMap, firstLineExists := productLineMap[data.FirstProductLineName]
		if !firstLineExists {
			rowErrors = append(rowErrors, "该一级产品线不存在")
		} else {
			// ii. 校验二级产品线名称是否存在，同时校验二级产品线与一级产品线在系统中的关联关系
			if data.SecondProductLineName != constants.SelectAll {
				secondLineExists := secondLineMap[data.SecondProductLineName]
				if !secondLineExists {
					rowErrors = append(rowErrors, fmt.Sprintf("二级产品线'%s'不属于一级产品线'%s'", data.SecondProductLineName, data.FirstProductLineName))
				}
			}
		}

		// c. 非法字符校验
		// 检测逗号、分号等非法字符，发现后报错
		if err := validateNonLegalCharacters(ctx, data.FirstProductLineName, data.SecondProductLineName); err != nil {
			rowErrors = append(rowErrors, getErrorMessage(err))
		}

		// 2. 表格内容&规则内容匹配校验
		// a. 表格中导入「审批规则类型」与当前规则的「审批规则类型」保持一致
		if err := validateMonitorRuleTypeConsistency(ctx, r.RuleType, data.RuleType); err != nil {
			rowErrors = append(rowErrors, getErrorMessage(err))
		}

		// b. 表格中导入监控符号与当前规则中要求一致
		if !isExceedThreeQuantity && data.MonitorSymbol != "" {
			if err := validateMonitorSymbol(ctx, r.RuleType, r.FormField, r.MonitorType, data.MonitorSymbol); err != nil {
				rowErrors = append(rowErrors, getErrorMessage(err))
			}
		}

		if len(rowErrors) > 0 {
			resp.ErrorDetails[data.DataIndex] = rowErrors
		} else {
			// 校验通过，添加到验证成功的数据列表中
			resp.ValidatedProductLine = append(resp.ValidatedProductLine, data)
		}
	}

	return resp, nil
}

// validateTradeProductData 校验商品导入数据
func (r *ValidateApprovalRuleBatchImportReq) validateTradeProductData(ctx context.Context, dataList []*fileparser.UploadApprovalRuleTradeProductData) (*ValidateApprovalRuleBatchImportResp, error) {
	resp := &ValidateApprovalRuleBatchImportResp{
		ErrorDetails:          make(map[int][]string),
		ModelUrl:              r.ModelUrl,
		ValidatedTradeProduct: []*fileparser.UploadApprovalRuleTradeProductData{},
	}

	// 获取所有商品信息用于校验
	tradeProductMap, err := getTradeProductMap(ctx)
	if err != nil {
		return nil, err
	}

	// 用于判重的map: key为数据唯一标识, value为第一次出现的行号
	duplicateCheckMap := make(map[string]int)

	for _, data := range dataList {
		if data.IsBlankData() {
			continue
		}

		var rowErrors []string

		// 1. 表格内容合法性校验
		// a. 配置、计费项允许为空，为空时默认为“所有选项”
		if data.ConfigurationCode == "" {
			data.ConfigurationCode = constants.SelectAll
		}
		if data.ChargeItemCode == "" {
			data.ChargeItemCode = constants.SelectAll
		}

		// b. 监控价格类型标准化
		ruleTypeEnum := getApprovalRuleTypeFromChinese(data.RuleType)
		// 将中文监控价格类型转换为枚举值
		if data.MonitorPriceType != "" {
			data.MonitorPriceType = getMonitorPriceTypeFromChinese(data.MonitorPriceType)
		}

		// 2. 表格内数据判重
		// 判重维度：审批规则类型 + 商品code + 配置code + 计费项code + 监控价格类型 + 监控符号 + 监控阈值
		duplicateKey := fmt.Sprintf("%s|%s|%s|%s|%s|%s|%s",
			data.RuleType,
			data.ProductCode,
			data.ConfigurationCode,
			data.ChargeItemCode,
			data.MonitorPriceType,
			data.MonitorSymbol,
			data.MonitorThreshold)
		if firstRowIndex, exists := duplicateCheckMap[duplicateKey]; exists {
			rowErrors = append(rowErrors, fmt.Sprintf("与第%d行数据重复", firstRowIndex+1))
		} else {
			duplicateCheckMap[duplicateKey] = data.DataIndex
		}

		// 3. 表格内容合法性校验
		// a. 跨三档量价区间，允许监控符号为空，监控阈值无需填写，若导入时不为空，也需要直接过滤
		isExceedThreeQuantity := ruleTypeEnum == multienv.ApprovalRuleTypeExceedThreeQuantity
		if isExceedThreeQuantity {
			// 跨三档量价区间，允许监控符号、监控阈值为空，若导入时不为空，也需要直接过滤
			if data.MonitorSymbol != "" || data.MonitorThreshold != "" {
				resp.ErrorDetails[data.DataIndex] = []string{"跨三档量价区间不支持监控符号和监控阈值"}
				continue
			}
			if data.ChargeItemCode != constants.SelectAll {
				rowErrors = append(rowErrors, "跨三档量价区间监控，计费项必须为空或'所有选项'")
				resp.ErrorDetails[data.DataIndex] = rowErrors
				continue
			}
		} else {
			// 非跨三档量价区间，监控符号和监控阈值必填
			if data.MonitorSymbol == "" {
				rowErrors = append(rowErrors, "监控符号不能为空")
			}
			// 监控阈值校验
			if err := ValidateMonitorThresholdString(data.MonitorThreshold, true); err != nil {
				rowErrors = append(rowErrors, getErrorMessage(err))
			}
		}

		// b. 校验填写的商品合法性
		// i. 校验商品名称是否存在
		productInfo, productExists := tradeProductMap[data.ProductCode]
		if !productExists {
			rowErrors = append(rowErrors, "该商品不存在")
		} else {
			// ii. 校验配置、计费项是否存在
			// iii. 校验商品与配置、计费项存在关系
			if err := r.validateProductConfigAndChargeItem(ctx, data, productInfo, &rowErrors); err != nil {
				logs.CtxError(ctx, "校验商品配置和计费项失败: %v", err)
			}
		}

		// c. 校验监控价格类型
		// 固定单价仅支持：指导价监控 + 具体计费项
		if data.MonitorPriceType == multienv.FixedPrice {
			if ruleTypeEnum != multienv.ApprovalRuleTypeGuidelinePrice {
				rowErrors = append(rowErrors, "固定单价仅支持指导价监控类型")
			} else if data.ChargeItemCode == constants.SelectAll || data.ChargeItemCode == "" {
				rowErrors = append(rowErrors, "固定单价必须选择具体计费项")
			} else if productExists {
				// 校验计费项刊例价价格类型
				if err := r.validateChargeItemPriceType(ctx, data, productInfo); err != nil {
					rowErrors = append(rowErrors, getErrorMessage(err))
				}
			}
		}

		// 针对指导价监控，还需要校验监控价格类型的其他规则
		isGuidePrice := ruleTypeEnum == multienv.ApprovalRuleTypeGuidelinePrice
		if isGuidePrice {
			// i. 计费项不为空，监控价格类型可以为"单一折扣"或"固定单价"
			// ii. 计费项为空，监控价格类型只能为"单一折扣"
			if data.ChargeItemCode == constants.SelectAll || data.ChargeItemCode == "" {
				if data.MonitorPriceType != "" && data.MonitorPriceType != multienv.SimpleDiscount {
					rowErrors = append(rowErrors, "计费项为空时，监控价格类型只能为单一折扣")
				}
			} else {
				if data.MonitorPriceType != "" && data.MonitorPriceType != multienv.SimpleDiscount && data.MonitorPriceType != multienv.FixedPrice {
					rowErrors = append(rowErrors, "计费项监控价格类型只支持单一折扣或固定单价")
				}
			}
		}

		// d. 非法字符校验
		// 检测逗号、分号等非法字符，发现后报错
		if err := validateNonLegalCharacters(ctx, data.ProductCode, data.ConfigurationCode, data.ChargeItemCode); err != nil {
			rowErrors = append(rowErrors, getErrorMessage(err))
		}

		// 2. 表格内容&规则内容匹配校验
		// a. 表格中导入「审批规则类型」与当前规则的「审批规则类型」保持一致
		if err := validateMonitorRuleTypeConsistency(ctx, r.RuleType, data.RuleType); err != nil {
			rowErrors = append(rowErrors, getErrorMessage(err))
		}

		// b. 表格中导入监控符号与当前规则中要求一致
		// i. 上升审批，监控符号必须为小于、小于等于
		// ii. 免审条件，监控符号必须为大于、大于等于
		// iii. 商务优惠，支持所有监控符号
		if !isExceedThreeQuantity && data.MonitorSymbol != "" {
			if err := validateMonitorSymbol(ctx, r.RuleType, r.FormField, r.MonitorType, data.MonitorSymbol); err != nil {
				rowErrors = append(rowErrors, getErrorMessage(err))
			}
		}
		if len(rowErrors) > 0 {
			resp.ErrorDetails[data.DataIndex] = rowErrors
		} else {
			// 校验通过，添加到验证成功的数据列表中
			resp.ValidatedTradeProduct = append(resp.ValidatedTradeProduct, data)
		}
	}

	return resp, nil
}

// getProductLineMap 获取产品线映射 (一级产品线 -> 二级产品线列表)
func getProductLineMap(ctx context.Context) (map[string]map[string]bool, error) {
	// 获取一级产品线信息
	firstLevelDepartments, err := product_service.ListDepartmentInfoFromCache(ctx, 1)
	if err != nil {
		return nil, err
	}

	// 获取二级产品线信息
	secondLevelDepartments, err := product_service.ListDepartmentInfoFromCache(ctx, 2)
	if err != nil {
		return nil, err
	}

	// 构建一级产品线ID到名称的映射（用于通过二级产品线的ParentID查找一级产品线名称）
	firstDeptIDToNameMap := make(map[int64][]string)
	for _, firstDept := range firstLevelDepartments {
		firstDeptIDToNameMap[firstDept.ID] = append(firstDeptIDToNameMap[firstDept.ID], firstDept.Name)
	}

	// 构建一级产品线 -> 二级产品线列表的映射
	productLineMap := make(map[string]map[string]bool)
	for _, firstDept := range firstLevelDepartments {
		productLineMap[firstDept.Name] = map[string]bool{}
	}

	for _, secondDept := range secondLevelDepartments {
		if secondDept.ParentID == 0 {
			continue
		}
		if firstLineNames, exists := firstDeptIDToNameMap[secondDept.ParentID]; exists {
			for _, firstLineName := range firstLineNames {
				productLineMap[firstLineName][secondDept.Name] = true
			}
		}
	}

	return productLineMap, nil
}

// getTradeProductMap 获取商品映射 (商品code -> 商品信息)
func getTradeProductMap(ctx context.Context) (map[string]*trade_client.TradeProductVersionInfo, error) {
	// 从 commodity_service 获取商品信息
	productsMap, err := commodity_service.GetAllTradeProductMap(ctx)
	if err != nil {
		return nil, err
	}

	productMap := make(map[string]*trade_client.TradeProductVersionInfo)
	for _, product := range productsMap {
		if product.TradeProduct != "" {
			productMap[product.TradeProduct] = product
		}
	}

	return productMap, nil
}

// validateNonLegalCharacters 校验非法字符
func validateNonLegalCharacters(ctx context.Context, fields ...string) error {
	illegalChars := []string{",", "，", ";", "；"}
	for _, field := range fields {
		for _, char := range illegalChars {
			if strings.Contains(field, char) {
				return i18nfmt.Errorf(ctx, "字段包含非法字符：%s", char)
			}
		}
	}
	return nil
}

// validateProductConfigAndChargeItem 校验商品的配置和计费项
func (r *ValidateApprovalRuleBatchImportReq) validateProductConfigAndChargeItem(ctx context.Context, data *fileparser.UploadApprovalRuleTradeProductData, productInfo *trade_client.TradeProductVersionInfo, rowErrors *[]string) error {
	// 如果配置和计费项都是"所有选项"，则不需要校验
	if data.ConfigurationCode == constants.SelectAll && data.ChargeItemCode == constants.SelectAll {
		return nil
	}

	// 获取商品配置容器
	container, err := product_config_load.GetConfigContainer(ctx, constants.ProductType(productInfo.ProductType), productInfo.StandardProduct)
	if err != nil {
		logs.CtxWarn(ctx, "获取商品配置容器失败，跳过配置校验: %v", err)
		return nil // 不阻断流程，仅记录警告
	}

	// 1. 校验配置存在性
	if data.ConfigurationCode != constants.SelectAll {
		configInfo := container.GetConfigInfoFromCache(productInfo.TradeProduct, data.ConfigurationCode)
		if configInfo == nil {
			*rowErrors = append(*rowErrors, "该配置不存在")
		}
	}

	// 2. 校验计费项存在性
	if data.ChargeItemCode != constants.SelectAll {
		chargeItemExists := false

		// 获取商品所有的 chargeItemKeys
		chargeItemKeys, err := container.GetChargeItemKeyListFromHash(ctx, productInfo.TradeProduct)
		if err != nil {
			logs.CtxWarn(ctx, "获取计费项key列表失败，跳过计费项校验: %v", err)
		} else {
			// 从key列表中提取计费项code进行匹配
			for _, chargeItemKey := range chargeItemKeys {
				if util.GetCode(chargeItemKey) == data.ChargeItemCode {
					chargeItemExists = true
					break
				}
			}
		}

		if !chargeItemExists {
			*rowErrors = append(*rowErrors, "该计费项不存在")
		}
	}

	// 3. 校验商品与配置、计费项的关联关系
	if data.ConfigurationCode != constants.SelectAll && data.ChargeItemCode != constants.SelectAll {
		// 构造chargeItemKey: 商品code::配置code::计费项code
		chargeItemKey := fmt.Sprintf("%s::%s::%s", productInfo.TradeProduct, data.ConfigurationCode, data.ChargeItemCode)
		configNodes := container.GetConfigNodeListWithoutFilter(ctx, chargeItemKey)

		if len(configNodes) == 0 {
			*rowErrors = append(*rowErrors, "该计费项不属于指定配置")
		}
	}

	// 4. 商品配置和计费项公有云私有云校验
	if err := ValidateTradeProductConfigAndChargeItem(ctx, productInfo.TradeProduct, data.ConfigurationCode, data.ChargeItemCode); err != nil {
		*rowErrors = append(*rowErrors, getErrorMessage(err))
	}

	return nil
}

// updateLarkSheetWithErrors 将错误信息写回飞书表格
func (r *ValidateApprovalRuleBatchImportReq) updateLarkSheetWithErrors(ctx context.Context, errorDetails map[int][]string) error {
	// 解析飞书表格
	docsURLInfo, err := lark_client.SpreadSheetURLParser(r.ModelUrl)
	if err != nil {
		return err
	}

	// 获取表格内容以确定实际的列数
	_, rows, err := lark_client.GetSheetContent(ctx, r.ModelUrl)
	if err != nil {
		logs.CtxWarn(ctx, "获取表格内容失败，使用默认列位置: %v", err)
	}

	// 准备写入的数据
	fields := []string{"errMsg"}
	var records []map[string]interface{}

	// 添加表头
	records = append(records, map[string]interface{}{"errMsg": "错误信息"})

	// 根据表格实际行数写入错误信息（不管有没有错误都写，以清空之前的错误）
	if len(rows) > 1 {
		// 为每一行数据准备错误信息（从第2行开始，第1行是表头）
		for i := 1; i < len(rows); i++ {
			var errMsg string
			if errStr, exists := errorDetails[i]; exists && len(errStr) > 0 {
				errMsg = strings.Join(errStr, "; ")
			}
			records = append(records, map[string]interface{}{"errMsg": errMsg})
		}
	}

	// 确定写入的列位置：先检查是否已存在"错误信息"列
	var columnIndex int
	errorColumnExists := false

	if len(rows) > 0 && len(rows[0]) > 0 {
		// 检查表头行（第一行）是否已经有"错误信息"列
		for i, cell := range rows[0] {
			if strings.TrimSpace(cell) == "错误信息" {
				columnIndex = i + 1 // 转为1-indexed
				errorColumnExists = true
				break
			}
		}

		// 如果不存在"错误信息"列，找到最后一个有内容的列，在其后添加
		if !errorColumnExists {
			maxColIndex := 0
			for _, row := range rows {
				for i := len(row) - 1; i >= 0; i-- {
					if strings.TrimSpace(row[i]) != "" {
						if i > maxColIndex {
							maxColIndex = i
						}
						break
					}
				}
			}
			// 错误信息列应该在最后一个有内容的列之后
			// maxColIndex是0-indexed的数组索引，需要+1转到下一列，再+1转为飞书API的1-indexed列号
			columnIndex = maxColIndex + 2
		}
	} else {
		// 如果无法获取表格内容，使用默认列位置
		switch r.ModelKey {
		case constants.UploadModeKeyApprovalRuleProductLine:
			columnIndex = 6 // 产品线模板：审批规则类型、一级产品线、二级产品线、监控符号、监控阈值、错误信息
		case constants.UploadModeKeyApprovalRuleTradeProduct:
			columnIndex = 8 // 商品模板：审批规则类型、商品名称、配置名称、计费项code、监控价格类型、监控符号、监控阈值、错误信息
		default:
			columnIndex = 8 // 默认位置
		}
	}

	// 写入数据
	rangeInfo, err := lark_client.UpdateColumnDataToSheet(ctx, &lark_client.UpdateColumnDataToSheetReq{
		SpreadSheetToken: docsURLInfo.SpreadSheetToken,
		Fields:           fields,
		Records:          records,
		ColumnIndex:      columnIndex,
		RowIndex:         1,
	})
	if err != nil {
		return err
	}

	// 如果有错误，设置单元格样式（高亮错误行）
	if len(errorDetails) > 0 {
		if err = lark_client.UpdateSheetStyle(ctx, docsURLInfo.SpreadSheetToken, rangeInfo); err != nil {
			logs.CtxWarn(ctx, "设置表格样式失败: %v", err)
		}
	}
	return nil
}

// getApprovalRuleTypeFromChinese 获取中文字段对应枚举值
func getApprovalRuleTypeFromChinese(chineseField string) string {
	// 去除首尾空格
	chineseField = strings.TrimSpace(chineseField)

	// 创建反向映射：中文 -> 枚举值
	reverseMapping := make(map[string]string)
	for enumValue, chineseName := range multienv.ApprovalRuleFieldNameMapping {
		reverseMapping[chineseName] = enumValue
	}

	if enumType, exists := reverseMapping[chineseField]; exists {
		return enumType
	}

	return chineseField
}

// validateMonitorRuleTypeConsistency 校验审批规则类型一致性
func validateMonitorRuleTypeConsistency(ctx context.Context, expectedType, actualType string) error {
	// 将导入的中文类型转换为枚举值
	actualEnumType := getApprovalRuleTypeFromChinese(actualType)

	if expectedType != "" && actualEnumType != expectedType {
		return i18nfmt.Errorf(ctx, "导入的审批规则类型与当前规则类型不一致")
	}
	return nil
}

// validateMonitorSymbol 校验监控符号是否符合规则要求
func validateMonitorSymbol(ctx context.Context, ruleType, formField, monitorType, symbol string) error {
	return ValidateMonitorSymbol(monitorType, formField, symbol, ruleType)
}

// validateChargeItemPriceType 校验计费项刊例价价格类型 当选择固定单价类型时，计费项的刊例价必须是固定价格类型，不能是阶梯价格
func (r *ValidateApprovalRuleBatchImportReq) validateChargeItemPriceType(ctx context.Context, data *fileparser.UploadApprovalRuleTradeProductData, productInfo *trade_client.TradeProductVersionInfo) error {
	return ValidateChargeItemPriceTypeForFixedPrice(ctx, data.ProductCode, data.ConfigurationCode, data.ChargeItemCode, productInfo)
}

// getMonitorPriceTypeFromChinese 将中文监控价格类型转换为枚举值
func getMonitorPriceTypeFromChinese(chineseName string) string {
	chineseName = strings.TrimSpace(chineseName)

	// 如果已经是枚举值，直接返回
	if chineseName == multienv.SimpleDiscount || chineseName == multienv.FixedPrice {
		return chineseName
	}

	switch chineseName {
	case multienv.DiscountFunctionSimpleDiscountName:
		return multienv.SimpleDiscount
	case multienv.DiscountFunctionFixedPriceName:
		return multienv.FixedPrice
	default:
		return chineseName
	}
}

// getErrorMessage 提取错误的纯消息内容，不包含错误码等信息
func getErrorMessage(err error) string {
	if err == nil {
		return ""
	}
	// 如果是自定义的APIErrorStruct，提取Message字段
	var apiErr *errors.APIErrorStruct
	if errors2.As(err, &apiErr) {
		return fmt.Sprintf(apiErr.Message, apiErr.Args...)
	}
	// 否则返回原始错误信息
	return err.Error()
}

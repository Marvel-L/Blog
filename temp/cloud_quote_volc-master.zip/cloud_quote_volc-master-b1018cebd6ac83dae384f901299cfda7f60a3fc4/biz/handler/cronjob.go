package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/cronjob/api"
	"code.byted.org/middleware/hertz/pkg/app"
)

// ExecuteCronjob20200101 执行定时任务
func (h *Handler) ExecuteCronjob20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &api.ExecuteCronjobReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/error_detail"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *Handler) UpdateErrorDetails20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &error_detail.UpdateErrorDetailsReq{})
}

func (h *Handler) GetErrorDetails20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &error_detail.GetErrorDetailsReq{})
}

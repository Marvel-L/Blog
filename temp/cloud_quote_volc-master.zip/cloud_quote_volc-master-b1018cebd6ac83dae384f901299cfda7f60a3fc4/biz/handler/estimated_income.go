package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/estimated_income_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// InitQuoteItemEstimatedIncome20200101 分摊报价项预计金额
func (h *Handler) InitQuoteItemEstimatedIncome20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &estimated_income_service.InitQuoteItemEstimatedIncomeReq{})
}

// UpdateQuoteItemsEstimatedIncome20200101 更新预计金额
func (h *Handler) UpdateQuoteItemsEstimatedIncome20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &estimated_income_service.UpdateQuoteItemsEstimatedIncomeReq{})
}

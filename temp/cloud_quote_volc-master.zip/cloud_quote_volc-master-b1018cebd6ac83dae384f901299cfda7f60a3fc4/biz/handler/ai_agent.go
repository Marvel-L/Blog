package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/ai_agent"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetNotSupportSelectionReason20200101 获取商品不支持选品原因
func (h *AnonymousHandler) GetNotSupportSelectionReason20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &ai_agent.GetNotSupportSelectionReasonReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_event"
	"code.byted.org/middleware/hertz/pkg/app"
)

// AddQuoteEvent20200101 新增报价变更事件
func (h *Handler) AddQuoteEvent20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_event.AddQuoteEventReq{})
}

// SendQuoteEvent20200101 发送报价变更事件
func (h *Handler) SendQuoteEvent20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_event.SendQuoteEventReq{})
}

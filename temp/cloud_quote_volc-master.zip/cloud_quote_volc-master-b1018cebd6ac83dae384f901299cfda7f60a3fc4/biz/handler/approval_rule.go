package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/approval_rule"
	"code.byted.org/middleware/hertz/pkg/app"
)

// ListApprovalRules20200101 获取审批规则列表
func (h *Handler) ListApprovalRules20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.ListApprovalRulesReq{})
}

// GetApprovalRuleDetail20200101 获取审批规则详情
func (h *Handler) GetApprovalRuleDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.GetApprovalRuleDetailReq{})
}

// CopyApprovalRule20200101 复制审批规则
func (h *Handler) CopyApprovalRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.CopyApprovalRuleReq{})
}

// UpsertApprovalRule20200101 新增/修改审批规则
func (h *Handler) UpsertApprovalRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.UpsertApprovalRuleReq{})
}

// UpdateApprovalRuleStatus20200101 修改审批规则状态
func (h *Handler) UpdateApprovalRuleStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.UpdateApprovalRuleStatusReq{})
}

// ValidateApprovalRuleBatchImport20200101 校验审批规则批量导入
func (h *Handler) ValidateApprovalRuleBatchImport20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_rule.ValidateApprovalRuleBatchImportReq{})
}

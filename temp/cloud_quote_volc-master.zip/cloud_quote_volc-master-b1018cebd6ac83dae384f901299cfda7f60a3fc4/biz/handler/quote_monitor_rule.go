package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/monitor_rule"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/monitor_rule/rule_type"
	"code.byted.org/middleware/hertz/pkg/app"
)

// ListQuoteMonitorRules20200101 获取报价监控规则列表
func (h *Handler) ListQuoteMonitorRules20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &monitor_rule.ListQuoteMonitorRulesReq{})
}

// GetQuoteMonitorRuleDetail20200101 获取报价监控规则详情
func (h *Handler) GetQuoteMonitorRuleDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &monitor_rule.GetQuoteMonitorRuleDetailReq{})
}

// UpsertQuoteMonitorRule20200101 新增/修改报价监控规则
func (h *Handler) UpsertQuoteMonitorRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &monitor_rule.UpsertQuoteMonitorRuleReq{})
}

// UpdateQuoteMonitorRuleStatus20200101 修改报价监控规则状态
func (h *Handler) UpdateQuoteMonitorRuleStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &monitor_rule.UpdateQuoteMonitorRuleStatusReq{})
}

// ListLarkApprovalRoles20200101 获取飞书审批角色列表
func (h *Handler) ListLarkApprovalRoles20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rule_type.ListLarkApprovalRolesReq{})
}

func (h *Handler) GetApprovalTimeOutAlarmTime20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &monitor_rule.GetApprovalTimeOutAlarmTimeReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/change_discount_white_list"
	"code.byted.org/middleware/hertz/pkg/app"
)

// AddChangeDiscountWhiteList20200101  新增变价商品白名单
func (h *Handler) AddChangeDiscountWhiteList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &change_discount_white_list.AddChangeDiscountWhiteListReq{})
}

// DeleteChangeDiscountWhiteList20200101  删除变价商品白名单
func (h *Handler) DeleteChangeDiscountWhiteList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &change_discount_white_list.DeleteChangeDiscountWhiteListReq{})
}

// MatchWhiteList20200101  匹配变价商品白名单
func (h *Handler) MatchWhiteList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &change_discount_white_list.MatchWhiteListReq{})
}

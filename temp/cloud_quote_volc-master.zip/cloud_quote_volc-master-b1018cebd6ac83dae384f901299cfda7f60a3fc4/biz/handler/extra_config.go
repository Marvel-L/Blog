package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/creditconfigservice"
	"code.byted.org/middleware/hertz/pkg/app"
)

// 附属额外信息配置

// ExtraCreateOrUpdateCouponConfig20200101 创建/更新代金券配置
func (h *Handler) ExtraCreateOrUpdateCouponConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &couponconfigservice.CreateCouponReq{})
}

// ExtraConfigCouponDetail20200101 获取返券配置详情
func (h *Handler) ExtraConfigCouponDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &couponconfigservice.DetailReq{})
}

// ExtraConfigCouponBatchGet20200101 批量获取返券配置详情
func (h *Handler) ExtraConfigCouponBatchGet20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &couponconfigservice.BatchGetReq{})
}

// BatchGetCreditConfig20200101 批量获取信控配置详情
func (h *Handler) BatchGetCreditConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &creditconfigservice.BatchGetCreditReq{})
}

// BatchCreateOrUpdateCreditConfig20200101 批量创建创建/更新信控配置
func (h *Handler) BatchCreateOrUpdateCreditConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &creditconfigservice.BatchCreateCreditReq{})
}

// GetCouponQuoteItemCalInfo20200101 获取代金券对应报价项计算信息
func (h *Handler) GetCouponQuoteItemCalInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &couponconfigservice.GetCouponQuoteItemCalInfoReq{})
}

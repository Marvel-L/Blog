package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/account_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/lark_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/passport_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *Handler) FinancialRelationCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &account_service.FinancialRelationCheckReq{})
}

func (h *Handler) ListAccountRaw20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &passport_service.ListAccountRawReq{})
}

func (h *Handler) ListAccountInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &passport_service.ListAccountInfoReq{})
}

func (h *Handler) SetKV20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &account_service.SetKVReq{})
}

func (h *Handler) GetKV20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &account_service.GetKVReq{})
}

func (h *Handler) SearchEmployees20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_service.SearchEmployeesReq{})
}

func (h *Handler) ListAccountFinancialRole20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &account_service.ListAccountFinancialRoleReq{})
}

func (h *Handler) GetAccountDistributorInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &account_service.GetAccountDistributorInfoReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/system"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetEnum20200101 获取枚举
func (h *Handler) GetEnum20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.GetEnumByKeyReq{})
}

// GetOffPeakHoursBillingConfig20200101 获取闲时计费配置
func (h *Handler) GetOffPeakHoursBillingConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.GetOffPeakHoursBillingConfigReq{})
}

// GetAllOffPeakHoursBillingConfig20200101 获取全量闲时计费配置
func (h *Handler) GetAllOffPeakHoursBillingConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.GetAllOffPeakHoursBillingConfigReq{})
}

func (h *AnonymousHandler) HealthCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.HealthCheckReq{})
}

// ListConstantsByScene20200101 根据场景获取常量列表
func (h *Handler) ListConstantsByScene20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.ListConstantsBySceneReq{})
}

// GetSwitchByName20200101 根据名字获取开关
func (h *Handler) GetSwitchByName20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &system.GetSwitchByNameReq{})
}

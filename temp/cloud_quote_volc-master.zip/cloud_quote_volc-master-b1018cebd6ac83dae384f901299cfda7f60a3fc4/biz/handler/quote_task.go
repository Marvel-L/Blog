package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_task"
	"code.byted.org/middleware/hertz/pkg/app"
)

// CreateOrUpdateQuoteTask20200101 创建或更新报价任务
func (h *Handler) CreateOrUpdateQuoteTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.CreateOrUpdateQuoteTaskReq{})
}

// ExecuteQuoteTask20200101 执行报价任务
func (h *Handler) ExecuteQuoteTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.ExecuteQuoteTaskReq{})
}

// ListQuoteTask20200101 报价任务列表查询
func (h *Handler) ListQuoteTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.ListQuoteTaskReq{})
}

// UploadContractByLark20200101 导入账号合同列表
func (h *Handler) UploadContractByLark20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.UploadContractByLarkReq{})
}

// ListQuoteSubTask20200101 报价子任务列表查询
func (h *Handler) ListQuoteSubTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.ListQuoteSubTaskReq{})
}

// UploadChargeItemsByLark20200101 导入变价计费项
func (h *Handler) UploadChargeItemsByLark20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.UploadChargeItemsByLarkReq{})
}

// ListQuoteTaskChargeItems20200101  获取变价计费项列表
func (h *Handler) ListQuoteTaskChargeItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.ListQuoteTaskChargeItemsReq{})
}

// DeleteQuoteTaskChargeItems20200101  删除变价计费项
func (h *Handler) DeleteQuoteTaskChargeItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_task.DeleteQuoteTaskChargeItemsReq{})
}

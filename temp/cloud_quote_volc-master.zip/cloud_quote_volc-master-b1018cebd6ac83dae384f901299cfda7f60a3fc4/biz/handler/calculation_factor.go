package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/calculation_factor"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetCalculationFactorOption20200101 获取计算因子配置选项
func (h *Handler) GetCalculationFactorOption20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.GetCalculationFactorOptionReq{})
}

// AddCalculationFactor20200101 添加/编辑计算因子
func (h *Handler) AddCalculationFactor20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.AddCalculationFactorReq{})
}

// EnableCalculationFactor20200101 启用计算因子
func (h *Handler) EnableCalculationFactor20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.EnableCalculationFactorReq{})
}

// AbandonCalculationFactor20200101 作废计算因子
func (h *Handler) AbandonCalculationFactor20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.AbandonCalculationFactorReq{})
}

// ListCalculationFactor20200101 计算因子列表查询
func (h *Handler) ListCalculationFactor20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.ListCalculationFactorReq{})
}

// CalculationFactorCacheRefresh20200101 计算因子缓存刷新
func (h *Handler) CalculationFactorCacheRefresh20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &calculation_factor.CalculationFactorCacheRefreshReq{})
}

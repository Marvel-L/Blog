package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetDuplicatedDiscountSnapshot20200101 获取报价单重复合同价快照
func (h *Handler) GetDuplicatedDiscountSnapshot20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetDuplicatedDiscountSnapshotReq{})
}

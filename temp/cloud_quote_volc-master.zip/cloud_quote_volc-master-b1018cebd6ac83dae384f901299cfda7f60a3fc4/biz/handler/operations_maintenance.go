package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/lark_approval_process"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_status_service"
	"code.byted.org/eps-platform/cloud_quote_volc/cronjob"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *Handler) QuoteTransStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_status_service.QuoteTransStatusReq{})
}

func (h *Handler) SmsChangeCronJob20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.SmsChangeCronJobReq{})
}

func (h *Handler) ApprovalTimeOutExec20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.ApprovalTimeOutExecReq{})
}

func (h *Handler) ApprovalTimeoutAlarmSaleOP20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.ApprovalTimeoutAlarmSaleOPReq{})
}

func (h *Handler) ApprovalTimeoutRuleCheckCronJob20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.ApprovalTimeoutRuleCheckCronJobReq{})
}

func (h *Handler) ApprovalModifyProgressSync20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.ApprovalModifyProgressSyncReq{})
}

func (h *Handler) OperateLarkApprovalTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.OperateLarkApprovalTaskReq{})
}

func (h *Handler) RetryNotifyContractDataRefresh20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.RetryNotifyContractDataRefreshReq{})
}

// BackfillCouponHistoryFields20200101 补偿代金券历史缺失字段。todo 刷数后删除
func (h *Handler) BackfillCouponHistoryFields20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &couponconfigservice.BackfillCouponHistoryFieldsReq{})
}

// RefreshQuoteItemCalculate20200101 刷新报价项计算历史数据。todo 刷数后删除
func (h *Handler) RefreshQuoteItemCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.RefreshQuoteItemCalculateReq{})
}

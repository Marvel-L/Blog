package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/item_context"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service_by_engine_v2"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// DeleteQuoteItem20200101 删除报价项
func (h *Handler) DeleteQuoteItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.DeleteQuoteItemFromQuoteReq{})
}

// AddQuoteItemV220200101 添加报价项V2
func (h *Handler) AddQuoteItemV220200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.AddQuoteItemValuesReqV2{})
}

// BatchAddQuoteItem20200101 批量添加报价项
func (h *Handler) BatchAddQuoteItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.BatchAddQuoteItemReq{})
}

// GetProductQuoteOption20200101 获取报价项配置选项
func (h *Handler) GetProductQuoteOption20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetQuoteProductOption{})
}

// GetDynamicProductOption20200101 获取报价项动态配置选项
func (h *Handler) GetDynamicProductOption20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetDynamicProductOptionReq{})
}

// CopyQuoteItems20200101 复制报价项
func (h *Handler) CopyQuoteItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.CopyQuoteItemsReq{})
}

// ListQuoteItemsV220200101 报价项列表V2版本
func (h *Handler) ListQuoteItemsV220200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.ListQuoteItemsV2Req{})
}

// UpdateQuoteApprovalTaxRate20200101 审批中修改报价项税率
func (h *Handler) UpdateQuoteApprovalTaxRate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.UpdateQuoteApprovalTaxRateReq{})
}

// ListRatioChargeItem20200101 查询比例关联计费项
func (h *Handler) ListRatioChargeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.ListRatioChargeItemReq{})
}

// ListProductChargeItem20200101 获取报价项配置列表
func (h *Handler) ListProductChargeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.ListProductChargeItemReq{})
}

// CalculateQuoteItem20200101 单个报价项询价
func (h *Handler) CalculateQuoteItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.CalculateQuoteItemReq{})
}

// BatchGetProductQuoteOptions20200101 批量获取报价项配置选项
func (h *Handler) BatchGetProductQuoteOptions20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.BatchGetProductQuoteOptionsReq{})
}

// GetQuoteTradeProducts20200101 获取报价单所有报价商品
func (h *Handler) GetQuoteTradeProducts20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetQuoteTradeProductsReq{})
}

// GetDiscountFunction20200101 获取报价方式
func (h *Handler) GetDiscountFunction20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetDiscountFunctionReq{})
}

// ListUsableCalculationFactor20200101 计算因子查询
func (h *Handler) ListUsableCalculationFactor20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &item_context.ListUsableCalculationFactorReq{})
}

// GetProductAllEnums20200101 获取选品字段全量枚举
func (h *Handler) GetProductAllEnums20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetProductAllEnumsReq{})
}

// ListConfigChargeItem20200101 获取全量计费项列表
func (h *Handler) ListConfigChargeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.ListConfigChargeItemReq{})
}

// ListAllConfigChargeItem20200101 获取全量计费项列表(不过滤)
func (h *Handler) ListAllConfigChargeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.ListAllConfigChargeItemReq{})
}

// BatchCheckQuoteItem20200101 报价项参数校验
func (h *Handler) BatchCheckQuoteItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.BatchCheckQuoteItemReq{})
}

// RefreshSelectAllExclude20200101 刷新所有选项排除项明细
func (h *Handler) RefreshSelectAllExclude20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.RefreshSelectAllExcludeReq{})
}

// CheckAndTransferToOptions20200101 校验转换报价项参数校验
func (h *Handler) CheckAndTransferToOptions20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.CheckAndTransferToOptionsReq{})
}

// GetRelatedChargeItems20200101 获取计费项配置
func (h *Handler) GetRelatedChargeItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.GetRelatedChargeItemsReq{})
}

// ValidateQuoteItems20200101 校验计费项有效性
func (h *Handler) ValidateQuoteItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service_by_engine_v2.ValidateQuoteItemsReq{})
}

func (h *Handler) CalQuoteItemTotalDiscount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_item_service.CalQuoteItemTotalDiscountReq{})
}

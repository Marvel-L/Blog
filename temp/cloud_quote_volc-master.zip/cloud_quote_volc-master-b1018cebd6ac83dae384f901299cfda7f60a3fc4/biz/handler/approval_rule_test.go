package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/approval_rule"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerCopyApprovalRule20200101(t *testing.T) {
	t.Run("透传复制审批规则请求", func(t *testing.T) {
		mockey.PatchConvey("透传复制审批规则请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "approval_rule_copy")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "approval_rule_copy")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*approval_rule.CopyApprovalRuleReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.CopyApprovalRule20200101(baseCtx, reqCtx)
		})
	})
}

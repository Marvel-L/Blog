package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/resource_page_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetResourcePageDetailForEdit20200101 查询报价资源单信息用于编辑
func (h *Handler) GetResourcePageDetailForEdit20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &resource_page_service.GetResourcePageDetailForEditReq{})
}

// GetResourcePageDetail20200101 查询报价资源单信息
func (h *Handler) GetResourcePageDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &resource_page_service.GetResourcePageDetailReq{})
}

// SaveResourcePageDetail20200101 保存报价资源单信息
func (h *Handler) SaveResourcePageDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &resource_page_service.SaveResourcePageDetailReq{})
}

// ListResourcePage20200101 查询客户指定受控卡报价单信息
func (h *Handler) ListResourcePage20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &resource_page_service.ListResourcePageReq{})
}

// ChangeResourcePageDetail20200101 报价资源单变更
func (h *Handler) ChangeResourcePageDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &resource_page_service.ChangeResourcePageDetailReq{})
}

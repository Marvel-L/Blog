package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/config_list"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *Handler) PutOnConfigList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &config_list.PutOnConfigListReq{})
}

func (h *Handler) PullOffConfigList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &config_list.PullOffConfigListReq{})
}

func (h *Handler) UseConfigList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &config_list.UseConfigListReq{})
}

func (h *Handler) UseConfigListPreCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &config_list.UseConfigListPreCheckReq{})
}

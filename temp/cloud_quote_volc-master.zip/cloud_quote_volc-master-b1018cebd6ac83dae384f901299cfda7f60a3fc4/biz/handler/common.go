package handler

import (
	"context"
	"fmt"
	"net/http"

	hertzCtx "code.byted.org/middleware/hertz/byted/ctx"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/models"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
)

type Handler struct {
	vhertz.CommonActionHandler
}

func GenHandler() *Handler {
	return &Handler{}
}

type AnonymousHandler struct {
	vhertz.CommonActionHandler
}

func GenAnonymousHandler() *AnonymousHandler {
	return &AnonymousHandler{}
}

func (h *AnonymousHandler) handle(c context.Context, ctx *app.RequestContext, req interface{}) {
	var (
		err    vhertz.APIError
		resp   interface{}
		action = ctx.GetString(constants.CtxAction)
	)

	defer func() {
		h.doResp(c, ctx, resp, err)
	}()
	validateErr := binding.BindAndValidate(ctx, req)
	if validateErr != nil {
		err = vhertz.NewErrorStruct(ctx.GetString(constants.CtxAction), validateErr.Error(), http.StatusBadRequest)
		return
	}

	if parsableReq, ok := req.(framework.ParsableReq); ok {
		var parsableErr error
		c = hertzCtx.CacheRPCContext(ctx)
		resp, parsableErr = parsableReq.Handle(c)
		if parsableErr != nil {
			if apiErr, ok := parsableErr.(errors.APIError); ok {
				err = apiErr
			} else {
				err = errors.ErrInternalError.WithArgs(parsableErr)
			}
			codeN := err.GetCodeInt()
			if codeN > 0 {
				logs.CtxWarn(c, "%v err=%v", action, err)
			} else {
				logs.CtxError(c, "%v err=%v", action, err)
			}
			return
		}
	}

}

func (h *Handler) handle(c context.Context, ctx *app.RequestContext, req interface{}) {
	var (
		err    vhertz.APIError
		resp   interface{}
		action = ctx.GetString(constants.CtxAction)
	)

	defer func() {
		h.doResp(c, ctx, resp, err)
	}()

	defer util.DefaultRecovery(c, fmt.Sprintf("request_%s", action))()

	validateErr := binding.BindAndValidate(ctx, req)
	if validateErr != nil {
		err = vhertz.NewErrorStruct(action, validateErr.Error(), http.StatusBadRequest)
		return
	}

	if parsableReq, ok := req.(framework.ParsableReq); ok {
		var parsableErr error
		c = hertzCtx.CacheRPCContext(ctx)
		resp, parsableErr = parsableReq.Handle(c)
		if parsableErr != nil {
			if apiErr, ok := parsableErr.(errors.APIError); ok {
				err = apiErr
			} else {
				err = errors.ErrInternalError.WithArgs(parsableErr)
			}
			codeN := err.GetCodeInt()
			if codeN > 0 {
				logs.CtxWarn(c, "%v err=%v", action, err)
			} else {
				logs.CtxError(c, "%v err=%v", action, err)
			}
		}
	}

}

func (h *Handler) doResp(c context.Context, ctx *app.RequestContext, result interface{}, err vhertz.APIError) {
	if err != nil {
		vhertz.ErrorResp(c, ctx, err)
	} else {
		if isRawResult(result) {
			ctx.JSON(http.StatusOK, result)
		} else {
			vhertz.DoResponse(c, ctx, result)
		}
	}
}

func isRawResult(result interface{}) bool {
	if result == nil {
		return false
	}
	_, ok := result.(models.RawResult)
	return ok
}

func (h *AnonymousHandler) doResp(c context.Context, ctx *app.RequestContext, result interface{}, err vhertz.APIError) {
	if err != nil {
		vhertz.ErrorResp(c, ctx, err)
	} else {
		if isRawResult(result) {
			ctx.JSON(http.StatusOK, result)
		} else {
			vhertz.DoResponse(c, ctx, result)
		}
	}
}

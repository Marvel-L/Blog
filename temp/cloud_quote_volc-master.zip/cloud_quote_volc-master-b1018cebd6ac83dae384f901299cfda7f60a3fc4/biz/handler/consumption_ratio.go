package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/consumption_ratio_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetConsumptionRatio20200101 获取消费结构
func (h *Handler) GetConsumptionRatio20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &consumption_ratio_service.GetConsumptionRatioReq{})
}

// SaveConsumptionRatio20200101 保存消费结构
func (h *Handler) SaveConsumptionRatio20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &consumption_ratio_service.SaveConsumptionRatioReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/guarantee_item_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// RecommendGuarantee20200101 报价单推荐保底判断
func (h *Handler) RecommendGuarantee20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.RecommendGuaranteeReq{})
}

// AddOrUpdateGuaranteeItem20200101 添加或更新报价单保底信息
func (h *Handler) AddOrUpdateGuaranteeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.AddOrUpdateGuaranteeItemReq{})
}

// GetGuaranteeItem20200101 获取报价单保底信息
func (h *Handler) GetGuaranteeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.GetGuaranteeItemReq{})
}

// GetGuaranteeItems20200101 获取报价单多保底规则树
func (h *Handler) GetGuaranteeItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.GetGuaranteeItemsReq{})
}

// DeleteGuaranteeItem20200101 删除报价单保底信息
func (h *Handler) DeleteGuaranteeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.DeleteGuaranteeItemReq{})
}

// BackfillGuaranteeItemFields20200101 补偿保底规则派生字段
func (h *Handler) BackfillGuaranteeItemFields20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &guarantee_item_service.BackfillGuaranteeItemFieldsReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/approval_info"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetQuoteApprovalReference20200101 获取报价审批人参考信息
func (h *Handler) GetQuoteApprovalReference20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &approval_info.GetQuoteApprovalReferenceReq{})
}

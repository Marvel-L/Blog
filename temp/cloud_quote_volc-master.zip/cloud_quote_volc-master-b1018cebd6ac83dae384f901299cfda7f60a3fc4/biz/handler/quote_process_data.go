package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/process_data"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetStructProcessData20200101 获取结构化报价过程数据
func (h *Handler) GetStructProcessData20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &process_data.GetStructProcessDataReq{})
}

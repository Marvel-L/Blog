package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/profit_cal_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetProfitCalculate20200101 获取利润率测算汇总
func (h *Handler) GetProfitCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.GetProfitCalculateReq{})
}

// SaveProfitCalculate20200101 保存利润率测算汇总
func (h *Handler) SaveProfitCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.SaveProfitCalculateReq{})
}

// RefreshCostAndCalculate20200101 重新获取商品侧成本，并重算利润率
func (h *Handler) RefreshCostAndCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.RefreshCostAndCalculateReq{})
}

// UploadDeliveryItemCostByLark20200101 上传交付项成本
func (h *Handler) UploadDeliveryItemCostByLark20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.UploadDeliveryItemCostByLarkReq{})
}

// GetCostConflictItems20200101 获取成本冲突交付项
func (h *Handler) GetCostConflictItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.GetCostConflictItemsReq{})
}

// GetProductLineProfitCalculate20200101 获取产品线润率测算汇总
func (h *Handler) GetProductLineProfitCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.GetProductLineProfitCalculateReq{})
}

// SaveProductLineProfitCalculate20200101 保存产品线润率测算汇总
func (h *Handler) SaveProductLineProfitCalculate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &profit_cal_service.SaveProductLineProfitCalculateReq{})
}

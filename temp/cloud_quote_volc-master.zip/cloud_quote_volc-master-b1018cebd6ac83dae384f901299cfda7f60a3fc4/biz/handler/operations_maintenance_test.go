package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/extraconfig/couponconfigservice"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerBackfillCouponHistoryFields20200101(t *testing.T) {
	mockey.PatchConvey("透传代金券历史字段补偿请求", t, func() {
		handler := &Handler{}
		baseCtx := context.WithValue(context.Background(), "source", "coupon_backfill")
		requestCtx := app.NewContext(0)

		mockey.Mock((*Handler).handle).To(func(_ *Handler, ctx context.Context, reqCtx *app.RequestContext, req interface{}) {
			convey.So(ctx.Value("source"), convey.ShouldEqual, "coupon_backfill")
			convey.So(reqCtx, convey.ShouldEqual, requestCtx)
			_, ok := req.(*couponconfigservice.BackfillCouponHistoryFieldsReq)
			convey.So(ok, convey.ShouldBeTrue)
		}).Build()

		handler.BackfillCouponHistoryFields20200101(baseCtx, requestCtx)
	})
}

func TestHandlerRefreshQuoteItemCalculate20200101(t *testing.T) {
	mockey.PatchConvey("透传报价项计算历史数据刷新请求", t, func() {
		handler := &Handler{}
		baseCtx := context.WithValue(context.Background(), "source", "quote_item_calculate_refresh")
		requestCtx := app.NewContext(0)

		mockey.Mock((*Handler).handle).To(func(_ *Handler, ctx context.Context, reqCtx *app.RequestContext, req interface{}) {
			convey.So(ctx.Value("source"), convey.ShouldEqual, "quote_item_calculate_refresh")
			convey.So(reqCtx, convey.ShouldEqual, requestCtx)
			_, ok := req.(*quote_item_service.RefreshQuoteItemCalculateReq)
			convey.So(ok, convey.ShouldBeTrue)
		}).Build()

		handler.RefreshQuoteItemCalculate20200101(baseCtx, requestCtx)
	})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/oa_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *AnonymousHandler) AgileProcessCallback20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &oa_service.OaCallbackReq{})
}

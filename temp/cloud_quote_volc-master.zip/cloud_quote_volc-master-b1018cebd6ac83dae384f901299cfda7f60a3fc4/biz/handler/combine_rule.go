package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/combine_rule"
	"code.byted.org/middleware/hertz/pkg/app"
)

// AddCombineRule20200101 添加组合规则
func (h *Handler) AddCombineRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &combine_rule.AddCombineRuleReq{})
}

// ListCombineRule20200101 组合规则列表
func (h *Handler) ListCombineRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &combine_rule.ListCombineRuleReq{})
}

// DeleteCombineRule20200101 删除组合规则
func (h *Handler) DeleteCombineRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &combine_rule.DeleteCombineRuleReq{})
}

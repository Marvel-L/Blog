package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/refresh_task"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/refresh_task/create_refresh_task"
	"code.byted.org/middleware/hertz/pkg/app"
)

// RefreshTaskList20200101 查询报价刷数任务列表
func (h *Handler) RefreshTaskList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &refresh_task.RefreshTaskListReq{})
}

// CreateRefreshTask20200101 创建报价刷数任务
func (h *Handler) CreateRefreshTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &create_refresh_task.CreateRefreshTaskReq{})
}

// DeleteRefreshTask20200101 删除报价刷数任务
func (h *Handler) DeleteRefreshTask20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &refresh_task.DeleteRefreshTaskReq{})
}

// CreateDataRefreshApproval20200101 创建刷数审批
func (h *Handler) CreateDataRefreshApproval20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &refresh_task.CreateDataRefreshApprovalReq{})
}

// DataRefreshApprovalList20200101 刷数审批列表
func (h *Handler) DataRefreshApprovalList20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &refresh_task.DataRefreshApprovalListReq{})
}

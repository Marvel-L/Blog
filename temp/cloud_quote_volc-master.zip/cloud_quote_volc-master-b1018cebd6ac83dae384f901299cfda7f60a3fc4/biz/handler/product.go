package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// ListStandardProductsForQuotes20200101 查询报价单产品(crm接口已迁移，仅报价平台使用)
func (h *Handler) ListStandardProductsForQuotes20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListStandardProductReq{})
}

// ListChildProducts20200101 查询子产品列表(crm接口已迁移，仅报价平台使用)
func (h *Handler) ListChildProducts20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListChildProductsReq{})
}

// ListTradeProductsForQuotes20200101 查询商品列表
func (h *Handler) ListTradeProductsForQuotes20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListTradeProductsForQuotesReq{})
}

// QueryTradeProducts20200101 模糊查询商品列表
func (h *Handler) QueryTradeProducts20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.QueryTradeProductsReq{})
}

// ListStandardSolutionForQuotes20200101 查询产品解决方案列表
func (h *Handler) ListStandardSolutionForQuotes20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListStandardSolutionForQuotesReq{})
}

// ListTradeSolutionForQuotes20200101 查询商品解决方案列表
func (h *Handler) ListTradeSolutionForQuotes20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListTradeSolutionForQuotesReq{})
}

// ListDepartmentsInfo20200101 获取一级产品线以及子产品编码
func (h *Handler) ListDepartmentsInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListDepartmentInfoReq{})
}

// ListDepartments20200101 获取产品线
func (h *Handler) ListDepartments20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListDepartmentReq{})
}

// ListAllChargeItems20200101 获取全量计费项列表
func (h *Handler) ListAllChargeItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListAllChargeItemsReq{})
}

// ListEmployees20200101 获取组织架构列表
func (h *Handler) ListEmployees20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.ListEmployeesReq{})
}

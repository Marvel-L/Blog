package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_contract_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// ContractBindReleaseQuote20200101 合同绑定or释放报价单
func (h *Handler) ContractBindReleaseQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_contract_service.ContractBindReleaseQuoteReq{})
}

// ContractGenerateNotify20200101 合同生成同步
func (h *Handler) ContractGenerateNotify20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_contract_service.ContractGenerateNotifyReq{})
}

// SyncRefreshStatus20200101 同步合同履约刷数状态
func (h *Handler) SyncRefreshStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_contract_service.SyncRefreshStatusReq{})
}

// BatchGetQuoteIDByContractCode20200101 根据合同号批量获取报价单ID
func (h *Handler) BatchGetQuoteIDByContractCode20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_contract_service.BatchGetQuoteIDByContractCodeReq{})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/discount_line"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetDiscountLine20200101 获取报价项折扣线
func (h *Handler) GetDiscountLine20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_line.GetDiscountLine{})
}

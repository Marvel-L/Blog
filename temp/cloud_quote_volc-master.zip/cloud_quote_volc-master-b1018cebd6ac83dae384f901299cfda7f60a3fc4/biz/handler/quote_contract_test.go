package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_contract_service"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerSyncRefreshStatus20200101(t *testing.T) {
	t.Run("透传同步履约刷数请求", func(t *testing.T) {
		mockey.PatchConvey("透传同步履约刷数请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "quote_contract")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "quote_contract")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*quote_contract_service.SyncRefreshStatusReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.SyncRefreshStatus20200101(baseCtx, reqCtx)
		})
	})
}

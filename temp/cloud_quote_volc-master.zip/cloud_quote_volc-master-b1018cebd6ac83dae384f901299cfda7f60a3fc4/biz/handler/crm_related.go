package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// SearchOpportunityInfo20200101 获取商机信息
func (h *Handler) SearchOpportunityInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.SearchOpportunityInfoReq{})
}

// ListPartnerContract20200101 分销协议列表
func (h *Handler) ListPartnerContract20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.ListPartnerContractReq{})
}

// GetVirtualOppNumber20200101 获取虚拟商机信息
func (h *Handler) GetVirtualOppNumber20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.GetVirtualOppNumberReq{})
}

// VirtualOppNumberCheck20200101 核销虚拟商机信息（测试用）
func (h *Handler) VirtualOppNumberCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.VirtualOppNumberCheckReq{})
}

// GetPartnerGrant20200101 获取伙伴授权
func (h *Handler) GetPartnerGrant20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.GetPartnerGrantReq{})
}

// GetOpportunityInfo20200101 获取商机信息
func (h *Handler) GetOpportunityInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.GetOpportunityInfoReq{})
}

// GetCrmQuoteNumMap20200101 获取crm报价单号map
func (h *Handler) GetCrmQuoteNumMap20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.GetCrmQuoteNumMapReq{})
}

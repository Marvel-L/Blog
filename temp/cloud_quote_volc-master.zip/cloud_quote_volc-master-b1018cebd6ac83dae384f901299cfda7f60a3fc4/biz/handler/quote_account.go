package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_account_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *Handler) CreateAccount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_account_service.CreateAccountReq{})
}

//func (h *Handler) ListAccounts20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &quote_account_service.ListPrincipalReq{})
//}

func (h *Handler) Whoami20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_account_service.GetCurrentUserReq{})
}

//func (h *Handler) RemoveAccount20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &quote_account_service.RemoveAccountReq{})
//}

// GetQuoteAccount20200101 获取报价用户信息
func (h *Handler) GetQuoteAccount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_account_service.GetGetQuoteAccountReq{})
}

package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/refresh_task"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/refresh_task/create_refresh_task"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerRefreshTaskList20200101(t *testing.T) {
	t.Run("透传刷数任务列表请求", func(t *testing.T) {
		mockey.PatchConvey("透传刷数任务列表请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "refresh_task_list")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "refresh_task_list")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*refresh_task.RefreshTaskListReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.RefreshTaskList20200101(baseCtx, reqCtx)
		})
	})
}

func TestHandlerCreateRefreshTask20200101(t *testing.T) {
	t.Run("透传创建刷数任务请求", func(t *testing.T) {
		mockey.PatchConvey("透传创建刷数任务请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "create_refresh_task")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "create_refresh_task")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*create_refresh_task.CreateRefreshTaskReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.CreateRefreshTask20200101(baseCtx, reqCtx)
		})
	})
}

func TestHandlerDeleteRefreshTask20200101(t *testing.T) {
	t.Run("透传删除刷数任务请求", func(t *testing.T) {
		mockey.PatchConvey("透传删除刷数任务请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "delete_refresh_task")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "delete_refresh_task")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*refresh_task.DeleteRefreshTaskReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.DeleteRefreshTask20200101(baseCtx, reqCtx)
		})
	})
}

func TestHandlerCreateDataRefreshApproval20200101(t *testing.T) {
	t.Run("透传创建刷数审批请求", func(t *testing.T) {
		mockey.PatchConvey("透传创建刷数审批请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "create_data_refresh_approval")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "create_data_refresh_approval")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*refresh_task.CreateDataRefreshApprovalReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.CreateDataRefreshApproval20200101(baseCtx, reqCtx)
		})
	})
}

func TestHandlerDataRefreshApprovalList20200101(t *testing.T) {
	t.Run("透传刷数审批列表请求", func(t *testing.T) {
		mockey.PatchConvey("透传刷数审批列表请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "data_refresh_approval_list")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "data_refresh_approval_list")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*refresh_task.DataRefreshApprovalListReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.DataRefreshApprovalList20200101(baseCtx, reqCtx)
		})
	})
}

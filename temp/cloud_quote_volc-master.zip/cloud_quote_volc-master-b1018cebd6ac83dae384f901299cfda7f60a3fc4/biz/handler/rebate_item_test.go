package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/rebate_item_service"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerBatchGetRebateItems20200101(t *testing.T) {
	t.Run("透传批量查询请求", func(t *testing.T) {
		mockey.PatchConvey("透传批量查询请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "rebate")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "rebate")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*rebate_item_service.BatchGetRebateItemsReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.BatchGetRebateItems20200101(baseCtx, reqCtx)
		})
	})
}

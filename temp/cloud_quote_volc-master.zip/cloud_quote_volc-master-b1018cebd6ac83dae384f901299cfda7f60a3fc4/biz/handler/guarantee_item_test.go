package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/guarantee_item_service"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerGetGuaranteeItems20200101(t *testing.T) {
	t.Run("透传多保底规则树请求", func(t *testing.T) {
		mockey.PatchConvey("透传多保底规则树请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "guarantee")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "guarantee")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*guarantee_item_service.GetGuaranteeItemsReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.GetGuaranteeItems20200101(baseCtx, reqCtx)
		})
	})
}

func TestHandlerBackfillGuaranteeItemFields20200101(t *testing.T) {
	t.Run("透传补偿派生字段请求", func(t *testing.T) {
		mockey.PatchConvey("透传补偿派生字段请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "guarantee")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "guarantee")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*guarantee_item_service.BackfillGuaranteeItemFieldsReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.BackfillGuaranteeItemFields20200101(baseCtx, reqCtx)
		})
	})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/rebate_item_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// AddOrUpdateRebateItems20200101 添加或更新报价特殊返佣信息
func (h *Handler) AddOrUpdateRebateItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rebate_item_service.AddOrUpdateRebateItemsReq{})
}

// GetRebateItems20200101 获取报价特殊返佣信息
func (h *Handler) GetRebateItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rebate_item_service.GetRebateItemsReq{})
}

// BatchGetRebateItems20200101 批量获取报价特殊返佣信息
func (h *Handler) BatchGetRebateItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rebate_item_service.BatchGetRebateItemsReq{})
}

// DeleteRebateItems20200101 删除报价特殊返佣信息
func (h *Handler) DeleteRebateItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rebate_item_service.DeleteRebateItemsReq{})
}

// GetSpecialRebatePolicy20200101 获取适合特殊返佣政策
func (h *Handler) GetSpecialRebatePolicy20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &rebate_item_service.GetSpecialRebatePolicyReq{})
}

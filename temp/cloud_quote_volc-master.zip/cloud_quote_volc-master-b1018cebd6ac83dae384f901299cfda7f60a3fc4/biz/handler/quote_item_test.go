package handler

import (
	"context"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_item_service_by_engine_v2"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestHandlerValidateQuoteItems20200101(t *testing.T) {
	t.Run("透传新版校验计费项请求", func(t *testing.T) {
		mockey.PatchConvey("透传新版校验计费项请求", t, func() {
			h := &Handler{}
			baseCtx := context.WithValue(context.Background(), "source", "validate_quote_items")
			reqCtx := app.NewContext(0)

			mockey.Mock((*Handler).handle).To(func(_ *Handler, c context.Context, ctx *app.RequestContext, req interface{}) {
				convey.So(c.Value("source"), convey.ShouldEqual, "validate_quote_items")
				convey.So(ctx, convey.ShouldEqual, reqCtx)
				_, ok := req.(*quote_item_service_by_engine_v2.ValidateQuoteItemsReq)
				convey.So(ok, convey.ShouldBeTrue)
			}).Build()

			h.ValidateQuoteItems20200101(baseCtx, reqCtx)
		})
	})
}

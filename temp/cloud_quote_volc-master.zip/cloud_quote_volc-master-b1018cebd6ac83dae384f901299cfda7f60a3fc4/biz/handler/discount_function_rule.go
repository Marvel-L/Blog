package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/discount_function_rule"
	"code.byted.org/middleware/hertz/pkg/app"
)

// CreateOrUpdateRule20200101 创建/更新报价方式规则
func (h *Handler) CreateOrUpdateRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_function_rule.CreateOrUpdateRuleReq{})
}

// ListDiscountFunctionRules20200101 报价方式规则列表
func (h *Handler) ListDiscountFunctionRules20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_function_rule.ListDiscountFunctionRulesReq{})
}

// SubmitDiscountFunctionRule20200101 提交报价方式规则
func (h *Handler) SubmitDiscountFunctionRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_function_rule.SubmitDiscountFunctionRuleReq{})
}

// GetRuleApprovalInstanceInfo20200101 获取审批信息
func (h *Handler) GetRuleApprovalInstanceInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_function_rule.GetRuleApprovalInstanceInfoReq{})
}

// UpdateDiscountFunctionRuleCache20200101 刷新报价方式规则缓存
func (h *Handler) UpdateDiscountFunctionRuleCache20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &discount_function_rule.UpdateDiscountFunctionRuleCacheReq{})
}

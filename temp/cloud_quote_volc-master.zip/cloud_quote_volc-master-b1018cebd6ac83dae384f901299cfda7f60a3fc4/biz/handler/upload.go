package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/upload_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// GetUploadLarkModel20200101 获取上传飞书模板
func (h *Handler) GetUploadLarkModel20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &upload_service.GetUploadLarkModelReq{})
}

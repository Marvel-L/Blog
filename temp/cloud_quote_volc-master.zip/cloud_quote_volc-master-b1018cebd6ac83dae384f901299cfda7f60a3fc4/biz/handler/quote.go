package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/crm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/inquery_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quantity_price_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_contract_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service_by_engine"
	"code.byted.org/middleware/hertz/pkg/app"
)

// CreateEmptyQuote20200101 创建空白报价单
func (h *Handler) CreateEmptyQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.CreateWhiteQuoteReq{})
}

// UpdateQuoteDetail20200101 更新报价单
func (h *Handler) UpdateQuoteDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.UpdateQuoteDetailReq{})
}

// AbandonQuote20200101 作废报价单
func (h *Handler) AbandonQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.AbandonQuoteReq{})
}

// ChangeQuote20200101 变更报价单
func (h *Handler) ChangeQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ChangeQuoteReq{})
}

// SubmitQuoteV220200101 异步提交报价单
func (h *Handler) SubmitQuoteV220200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service_by_engine.SubmitQuoteReq{})
}

// ListQuotes20200101 报价单列表
func (h *Handler) ListQuotes20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListQuotesReq{})
}

// GetQuoteContractReq20200101 获取报价合同创建参数
func (h *Handler) GetQuoteContractReq20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_contract_service.GetQuoteContractReq{})
}

// SyncQuoteStatus20200101 手动同步报价单状态
func (h *Handler) SyncQuoteStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &crm_service.SyncQuoteStatusReq{})
}

// ListCustomerType20200101 获取客户类型列表
func (h *Handler) ListCustomerType20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListCustomerTypeReq{})
}

// GetQuoteInfo20200101 获取报价单简要信息
func (h *Handler) GetQuoteInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteInfoReq{})
}

// DeleteQuote20200101 删除报价单（删除报价单以及相关报价项）
func (h *Handler) DeleteQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.DeleteQuoteReq{})
}

// ListQuotesUsedTemplate20200101 查询使用某个模版的报价单列表
func (h *Handler) ListQuotesUsedTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListQuotesUsedTemplateReq{})
}

// BatchUpdateDiscount20200101 批量设置报价单报价项折扣
func (h *Handler) BatchUpdateDiscount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.BatchUpdateDiscountReq{})
}

// CopyQuote20200101 复制报价单
func (h *Handler) CopyQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.CopyQuoteReq{})
}

// QuoteRepeatCheck20200101 报价单整单验重
func (h *Handler) QuoteRepeatCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.QuoteRepeatCheckReq{})
}

// ListQuotesByAccount20200101 历史报价单列表
func (h *Handler) ListQuotesByAccount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListQuotesByAccountReq{})
}

// ListQuotesByOpportunity20200101 根据商机获取历史报价单
func (h *Handler) ListQuotesByOpportunity20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListQuotesByOpportunityReq{})
}

// GetQuoteBaseInfo20200101 获取报价单基本信息
func (h *Handler) GetQuoteBaseInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteBaseInfoReq{})
}

// ListQuoteSolution20200101 报价单内解决方案列表
func (h *Handler) ListQuoteSolution20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ListQuoteSolutionReq{})
}

// GetQuoteItemsSummary20200101 获取清单汇总
func (h *Handler) GetQuoteItemsSummary20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteItemsSummaryReq{})
}

// StartModifyProcess20200101 发起报价单审批修改
func (h *Handler) StartModifyProcess20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.StartModifyProcessReq{})
}

// SalesOpModifySubmitted20200101 销运审批修改审批中报价单
func (h *Handler) SalesOpModifySubmitted20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.SalesOpModifySubmittedReq{})
}

// GetSalesOpModifyLog20200101 获取销运修改审批中报价单日志
func (h *Handler) GetSalesOpModifyLog20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetSalesOpModifyLogReq{})
}

// AllowSupplementaryAgreement20200101 是否允许发起补充协议
func (h *Handler) AllowSupplementaryAgreement20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.AllowSupplementaryAgreementReq{})
}

// SupplyQuote20200101 发起补充协议
func (h *Handler) SupplyQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.SupplyQuoteReq{})
}

// GetQuoteDiff20200101 报价单对比
func (h *Handler) GetQuoteDiff20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteDiffReq{})
}

// ChangeQuoteStatus20200101 qa修改报价单状态
func (h *Handler) ChangeQuoteStatus20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.ChangeQuoteStatusReq{})
}

// UpdateQuoteGiveAwayInfo20200101 更新报价单赠送信息
func (h *Handler) UpdateQuoteGiveAwayInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.UpdateQuoteGiveAwayReq{})
}

// GetQuoteModifyInfo20200101 获取报价单修改信息
func (h *Handler) GetQuoteModifyInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteModifyInfoReq{})
}

// GetGiveAwayInfo20200101 获取报价单赠送信息
func (h *Handler) GetGiveAwayInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetGiveAwayInfoReq{})
}

// QuoteBizDataCheck20200101 整单业务数据校验
func (h *Handler) QuoteBizDataCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service_by_engine.QuoteBizDataCheckReq{})
}

// QuoteBizDataRefresh20200101 整单业务数据刷新
func (h *Handler) QuoteBizDataRefresh20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service_by_engine.QuoteBizDataRefreshReq{})
}

// GetQuoteDiscountCategory20200101 计算报价项折扣范围
func (h *Handler) GetQuoteDiscountCategory20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteDiscountCategoryReq{})
}

// PreviewApprovalFlow20200101 预览报价单预计审批流程
func (h *Handler) PreviewApprovalFlow20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.PreviewApprovalFlowReq{})
}

// GetQuantityPriceDetail20200101 获取量价金额详细
func (h *Handler) GetQuantityPriceDetail20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quantity_price_service.GetQuantityPriceDetailReq{})
}

// GetQuoteRealDiscount20200101 计算报价项真实折扣
func (h *Handler) GetQuoteRealDiscount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &inquery_service.GetQuoteRealDiscountReq{})
}

func (h *Handler) GetQuoteLarkApprovalInstance20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.GetQuoteLarkApprovalInstanceReq{})
}

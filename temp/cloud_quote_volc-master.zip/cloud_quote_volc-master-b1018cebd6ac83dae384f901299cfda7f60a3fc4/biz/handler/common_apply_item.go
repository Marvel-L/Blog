package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/common_apply_service"
	"code.byted.org/middleware/hertz/pkg/app"
)

// AddCommonApplyItem20200101 添加通用申请条目
func (h *Handler) AddCommonApplyItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &common_apply_service.AddApplyItemReq{})
}

// GetCommonApplyItem20200101 获取通用申请条目
func (h *Handler) GetCommonApplyItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &common_apply_service.GetApplyItemReq{})
}

// DeleteCommonApplyItem20200101 删除通用申请条目
func (h *Handler) DeleteCommonApplyItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &common_apply_service.DeleteApplyItemReq{})
}

// ClearCommonApplyItem20200101 清空通用申请条目
func (h *Handler) ClearCommonApplyItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &common_apply_service.ClearApplyItemReq{})
}

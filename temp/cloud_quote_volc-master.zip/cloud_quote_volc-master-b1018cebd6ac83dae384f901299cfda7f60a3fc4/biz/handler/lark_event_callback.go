package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/lark_approval_process"
	"code.byted.org/middleware/hertz/pkg/app"
)

func (h *AnonymousHandler) LarkApprovalProcessCallback20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.LarkApprovalProcessCallbackReq{})
}

// GetLarkMockData20200101 获取飞书模拟参数
func (h *Handler) GetLarkMockData20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.GetLarkMockDataReq{})
}

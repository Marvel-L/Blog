package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_template"
	"code.byted.org/middleware/hertz/pkg/app"
)

// CreateMainTemplate20200101 创建主模板
func (h *Handler) CreateMainTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CreateMainTemplateReq{})
}

// CreateDraftTemplate20200101 创建草稿模板
func (h *Handler) CreateDraftTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CreateDraftTemplateReq{})
}

// ListQuoteTemplates20200101 报价单模板列表
func (h *Handler) ListQuoteTemplates20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.ListQuoteTemplatesReq{})
}

// GetQuoteTplBaseInfo20200101 报价单模板基础信息
func (h *Handler) GetQuoteTplBaseInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.GetQuoteTplBaseInfoReq{})
}

// ListTplItems20200101 获取模板项列表
func (h *Handler) ListTplItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.ListTplItemsReq{})
}

// GetProductTemplateOption20200101 获取报价项配置选项
func (h *Handler) GetProductTemplateOption20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.GetTemplateProductOption{})
}

// BatchGetProductTemplateOption20200101 批量获取报价项配置
func (h *Handler) BatchGetProductTemplateOption20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.BatchGetTplProductOption{})
}

// AddTemplateItem20200101 添加模板项
func (h *Handler) AddTemplateItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.AddTemplateItemValuesReq{})
}

// BatchAddTemplateItem20200101 批量添加模版项
func (h *Handler) BatchAddTemplateItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.BatchAddTemplateItemReq{})
}

// GetRefreshInfo20200101 一键刷新模版内解决方案
func (h *Handler) GetRefreshInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.GetRefreshInfoReq{})
}

// RefreshSolutionVersion20200101 确认刷新模版内容
func (h *Handler) RefreshSolutionVersion20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.RefreshSolutionVersionReq{})
}

//暂时不做删除，与现有逻辑冲突
////DeleteTemplate20200101 删除模板草稿
//func (h *Handler) DeleteTemplate20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &quote_template.DeleteTemplateReq{})
//}

// DeleteTemplateItem20200101 删除模板里的某些模板项
func (h *Handler) DeleteTemplateItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.DeleteTemplateItemsReq{})
}

// PutOnTemplateDraft20200101 上架模板草稿
func (h *Handler) PutOnTemplateDraft20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.PutOnTemplateDraftReq{})
}

// UseTemplate20200101 使用模板
func (h *Handler) UseTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.UseTemplateReq{})
}

// PullOffTemplate20200101 下架模板草稿
func (h *Handler) PullOffTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.PullOffTemplateReq{})
}

// UpdateTemplate20200101 编辑模板参数
func (h *Handler) UpdateTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.UpdateTemplateReq{})
}

// CanUseTemplateInQuote20200101 某个报价单能否使用模板
func (h *Handler) CanUseTemplateInQuote20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CanUseTemplateInQuoteReq{})
}

// ListTplSolution20200101 报价模板内解决方案列表
func (h *Handler) ListTplSolution20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.ListTplSolutionReq{})
}

// ListTplChargeItem20200101 获取模板项项配置列表
func (h *Handler) ListTplChargeItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.ListTplChargeItemReq{})
}

// CalculateTplItem20200101 获取报价项配置列表
func (h *Handler) CalculateTplItem20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CalculateTplItemReq{})
}

// BatchUpdateTplDiscount20200101 模板一键折扣
func (h *Handler) BatchUpdateTplDiscount20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.BatchUpdateTplDiscountReq{})
}

// TemplateCanCopy20200101 模板可复制判断（复制模板前先判断模板是否可复制）
func (h *Handler) TemplateCanCopy20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.TemplateCanCopyReq{})
}

// CopyTemplate20200101 模板复制
func (h *Handler) CopyTemplate20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CopyTemplateReq{})
}

// CopyTplItems20200101 模板项复制
func (h *Handler) CopyTplItems20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.CopyTplItemsReq{})
}

// TemplateRepeatCheck20200101 模板项验重
func (h *Handler) TemplateRepeatCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.TemplateRepeatCheckReq{})
}

// UploadTplItemsByLark20200101 飞书模板上传模板项
func (h *Handler) UploadTplItemsByLark20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.UploadTplItemsByLarkReq{})
}

// UseTemplatePreCheck20200101 使用模板预检
func (h *Handler) UseTemplatePreCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_template.UseTemplatePreCheckReq{})
}

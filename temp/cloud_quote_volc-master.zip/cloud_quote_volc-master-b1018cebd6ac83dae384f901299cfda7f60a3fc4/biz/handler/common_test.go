package handler

import (
	"context"
	"errors"
	"net/http"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/models"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	pkgerrors "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

type stubParsableReq struct {
	handle func(context.Context) (interface{}, error)
}

func (r *stubParsableReq) Handle(ctx context.Context) (interface{}, error) {
	return r.handle(ctx)
}

type stubRawResult struct {
	models.BaseRawResult
	Value string
}

func TestAnonymousHandlerHandle(t *testing.T) {
	t.Run("绑定失败返回请求错误", func(t *testing.T) {
		mockey.PatchConvey("绑定失败返回请求错误", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "AnonymousAction")
			baseCtx := context.WithValue(context.Background(), "source", "caller")
			bindErr := errors.New("bind failed")

			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()
			mockey.Mock((*AnonymousHandler).doResp).To(func(ctx context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(ctx.Value("source"), convey.ShouldEqual, "caller")
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.HttpStatus(), convey.ShouldEqual, http.StatusBadRequest)
				convey.So(err.Error(), convey.ShouldContainSubstring, bindErr.Error())
			}).Build()

			h.handle(baseCtx, reqCtx, &struct{}{})
		})
	})

	t.Run("普通错误转换为内部错误", func(t *testing.T) {
		mockey.PatchConvey("普通错误转换为内部错误", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "AnonymousAction")
			reqCtx.Set("trace_id", "anonymous-trace")
			plainErr := errors.New("service unavailable")
			req := &stubParsableReq{
				handle: func(ctx context.Context) (interface{}, error) {
					convey.So(ctx.Value("trace_id"), convey.ShouldEqual, "anonymous-trace")
					return nil, plainErr
				},
			}

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(logs.CtxWarn).To(func(context.Context, string, ...interface{}) {
				t.Fatalf("unexpected warn log")
			}).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock((*AnonymousHandler).doResp).To(func(_ context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.GetCode(), convey.ShouldEqual, pkgerrors.ErrInternalError.GetCode())
				convey.So(err.Error(), convey.ShouldContainSubstring, plainErr.Error())
			}).Build()

			h.handle(context.Background(), reqCtx, req)
		})
	})

	t.Run("接口错误保留原始错误并记录告警", func(t *testing.T) {
		mockey.PatchConvey("接口错误保留原始错误并记录告警", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "AnonymousAction")
			reqCtx.Set("trace_id", "anonymous-trace")
			apiErr := pkgerrors.NewErr(pkgerrors.CodeNProductRPCError, "ProductError", "rpc failed", http.StatusBadGateway)
			req := &stubParsableReq{
				handle: func(ctx context.Context) (interface{}, error) {
					convey.So(ctx.Value("trace_id"), convey.ShouldEqual, "anonymous-trace")
					return nil, apiErr
				},
			}
			warnCalled := false

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(logs.CtxWarn).To(func(context.Context, string, ...interface{}) {
				warnCalled = true
			}).Build()
			mockey.Mock(logs.CtxError).To(func(context.Context, string, ...interface{}) {
				t.Fatalf("unexpected error log")
			}).Build()
			mockey.Mock((*AnonymousHandler).doResp).To(func(_ context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldEqual, apiErr)
				convey.So(warnCalled, convey.ShouldBeTrue)
			}).Build()

			h.handle(context.Background(), reqCtx, req)
		})
	})
}

func TestHandlerHandle(t *testing.T) {
	t.Run("成功处理请求并透传缓存上下文", func(t *testing.T) {
		mockey.PatchConvey("成功处理请求并透传缓存上下文", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "HandlerAction")
			reqCtx.Set("trace_id", "handler-trace")
			resp := map[string]string{"status": "ok"}
			recoveryFlag := ""
			req := &stubParsableReq{
				handle: func(ctx context.Context) (interface{}, error) {
					convey.So(ctx.Value("trace_id"), convey.ShouldEqual, "handler-trace")
					return resp, nil
				},
			}

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(util.DefaultRecovery).To(func(ctx context.Context, flag string) func() {
				convey.So(ctx, convey.ShouldNotBeNil)
				recoveryFlag = flag
				return func() {}
			}).Build()
			mockey.Mock((*Handler).doResp).To(func(_ context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldResemble, resp)
				convey.So(err, convey.ShouldBeNil)
				convey.So(recoveryFlag, convey.ShouldEqual, "request_HandlerAction")
			}).Build()

			h.handle(context.Background(), reqCtx, req)
		})
	})

	t.Run("请求未实现接口时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("请求未实现接口时返回空响应", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "HandlerAction")

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(util.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock((*Handler).doResp).To(func(_ context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldBeNil)
			}).Build()

			h.handle(context.Background(), reqCtx, &struct{}{})
		})
	})

	t.Run("接口错误按错误日志分支处理", func(t *testing.T) {
		mockey.PatchConvey("接口错误按错误日志分支处理", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			reqCtx.Set(constants.CtxAction, "HandlerAction")
			reqCtx.Set("trace_id", "handler-trace")
			apiErr := pkgerrors.NewErr(pkgerrors.HistoryInternalErrCode, "InternalError", "downstream failed", http.StatusInternalServerError)
			req := &stubParsableReq{
				handle: func(ctx context.Context) (interface{}, error) {
					convey.So(ctx.Value("trace_id"), convey.ShouldEqual, "handler-trace")
					return nil, apiErr
				},
			}
			errorCalled := false

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(util.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock(logs.CtxWarn).To(func(context.Context, string, ...interface{}) {
				t.Fatalf("unexpected warn log")
			}).Build()
			mockey.Mock(logs.CtxError).To(func(context.Context, string, ...interface{}) {
				errorCalled = true
			}).Build()
			mockey.Mock((*Handler).doResp).To(func(_ context.Context, c *app.RequestContext, result interface{}, err vhertz.APIError) {
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldEqual, apiErr)
				convey.So(errorCalled, convey.ShouldBeTrue)
			}).Build()

			h.handle(context.Background(), reqCtx, req)
		})
	})
}

func TestHandlerDoResp(t *testing.T) {
	t.Run("有错误时走错误响应", func(t *testing.T) {
		mockey.PatchConvey("有错误时走错误响应", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			baseCtx := context.WithValue(context.Background(), "source", "handler")
			apiErr := pkgerrors.NewErr(pkgerrors.HistoryInternalErrCode, "InternalError", "response failed", http.StatusInternalServerError)

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(ctx.Value("source"), convey.ShouldEqual, "handler")
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(err, convey.ShouldEqual, apiErr)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(context.Context, *app.RequestContext, interface{}) {
				t.Fatalf("unexpected normal response")
			}).Build()

			h.doResp(baseCtx, reqCtx, map[string]string{"status": "ignored"}, apiErr)
		})
	})

	t.Run("原始结果直接写入JSON", func(t *testing.T) {
		mockey.PatchConvey("原始结果直接写入JSON", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			raw := &stubRawResult{Value: "raw"}

			mockey.Mock((*app.RequestContext).JSON).To(func(code int, obj interface{}) {
				convey.So(code, convey.ShouldEqual, http.StatusOK)
				convey.So(obj, convey.ShouldEqual, raw)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(context.Context, *app.RequestContext, interface{}) {
				t.Fatalf("unexpected normal response")
			}).Build()

			h.doResp(context.Background(), reqCtx, raw, nil)
		})
	})

	t.Run("普通结果走统一响应", func(t *testing.T) {
		mockey.PatchConvey("普通结果走统一响应", t, func() {
			h := &Handler{}
			reqCtx := app.NewContext(0)
			baseCtx := context.WithValue(context.Background(), "source", "handler")
			resp := map[string]string{"status": "ok"}

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(ctx.Value("source"), convey.ShouldEqual, "handler")
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldResemble, resp)
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(context.Context, *app.RequestContext, vhertz.APIError) {
				t.Fatalf("unexpected error response")
			}).Build()

			h.doResp(baseCtx, reqCtx, resp, nil)
		})
	})
}

func TestAnonymousHandlerDoResp(t *testing.T) {
	t.Run("有错误时走错误响应", func(t *testing.T) {
		mockey.PatchConvey("有错误时走错误响应", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			baseCtx := context.WithValue(context.Background(), "source", "anonymous")
			apiErr := pkgerrors.NewErr(pkgerrors.HistoryInternalErrCode, "InternalError", "response failed", http.StatusInternalServerError)

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(ctx.Value("source"), convey.ShouldEqual, "anonymous")
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(err, convey.ShouldEqual, apiErr)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(context.Context, *app.RequestContext, interface{}) {
				t.Fatalf("unexpected normal response")
			}).Build()

			h.doResp(baseCtx, reqCtx, map[string]string{"status": "ignored"}, apiErr)
		})
	})

	t.Run("原始结果直接写入JSON", func(t *testing.T) {
		mockey.PatchConvey("原始结果直接写入JSON", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			raw := &stubRawResult{Value: "raw"}

			mockey.Mock((*app.RequestContext).JSON).To(func(code int, obj interface{}) {
				convey.So(code, convey.ShouldEqual, http.StatusOK)
				convey.So(obj, convey.ShouldEqual, raw)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(context.Context, *app.RequestContext, interface{}) {
				t.Fatalf("unexpected normal response")
			}).Build()

			h.doResp(context.Background(), reqCtx, raw, nil)
		})
	})

	t.Run("普通结果走统一响应", func(t *testing.T) {
		mockey.PatchConvey("普通结果走统一响应", t, func() {
			h := &AnonymousHandler{}
			reqCtx := app.NewContext(0)
			baseCtx := context.WithValue(context.Background(), "source", "anonymous")
			resp := map[string]string{"status": "ok"}

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(ctx.Value("source"), convey.ShouldEqual, "anonymous")
				convey.So(c, convey.ShouldEqual, reqCtx)
				convey.So(result, convey.ShouldResemble, resp)
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(context.Context, *app.RequestContext, vhertz.APIError) {
				t.Fatalf("unexpected error response")
			}).Build()

			h.doResp(baseCtx, reqCtx, resp, nil)
		})
	})
}

package handler

import (
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/commodity_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/control_resource_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/kani_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/lark_approval_process"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/prm_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/product_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_one_click_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/quote_service"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/tool_service"
	"code.byted.org/eps-platform/cloud_quote_volc/cronjob"
	"code.byted.org/middleware/hertz/pkg/app"
)

// RefreshProductConfig20200101 刷新商品配置
func (h *Handler) RefreshProductConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_service.RefreshProductConfigReq{})
}

// RefreshProductInfo20200101 刷新商品信息
func (h *Handler) RefreshProductInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &product_service.RefreshProductInfoReq{})
}

// CreateSpecialPolicy20200101 创建特殊返佣
func (h *Handler) CreateSpecialPolicy20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &prm_service.CreateSpecialPolicyReq{})
}

// GenLarkApprovalFormItemConfig20200101 获取指定审批code对应的表单配置信息
func (h *Handler) GenLarkApprovalFormItemConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.GenLarkApprovalFormItemConfigReq{})
}

// RefreshLarkApprovalFormItemConfig20200101 更新指定审批code对应的表单配置信息到缓存中
func (h *Handler) RefreshLarkApprovalFormItemConfig20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.RefreshLarkApprovalFormItemConfigReq{})
}

// RefreshControlCardInfo20200101 刷新受控卡信息
func (h *Handler) RefreshControlCardInfo20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &control_resource_service.RefreshControlCardInfoReq{})
}

// AppendTradeTypeCode20200101 刷新报价单客户类型编码
//func (h *Handler) AppendTradeTypeCode20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &quote_service.AppendTradeTypeCodeReq{})
//}

// RefreshQuoteApproval20200101 刷新报价单审批信息
//func (h *Handler) RefreshQuoteApproval20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &tool_service.RefreshQuoteApprovalReq{})
//}

// OneClickCreateQuoteByLark20200101 飞书模板一键创建报价单
func (h *Handler) OneClickCreateQuoteByLark20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &quote_one_click_service.OneClickCreateQuoteByLarkReq{})
}

// GetTradeProductByType20200101 查询商品信息
func (h *Handler) GetTradeProductByType20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.GetTradeProductByTypeReq{})
}

// LarkApprovalStatusAudit20200101 飞书审批状态稽核
func (h *Handler) LarkApprovalStatusAudit20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.LarkApprovalStatusAuditReq{})
}

// AppendContractEntity20200101 刷新报价单签约主体
//func (h *Handler) AppendContractEntity20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &quote_service.AppendContractEntityReq{})
//}

// RefreshSelectionRule20200101 刷选品规则
func (h *Handler) RefreshSelectionRule20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &commodity_service.ListAllSelectionRuleToRedisReq{})
}

// LarkFormOptionAudit20200101 飞书表单字段选项稽核
func (h *Handler) LarkFormOptionAudit20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &cronjob.LarkFormOptionAuditReq{})
}

// DraftQuoteExpiredCheck20200101 手动触发草稿报价单过期检查
func (h *Handler) DraftQuoteExpiredCheck20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.DraftQuoteExpiredCheckReq{})
}

// AppendFangzhouQuoteItems20200101 刷方舟报价项
//func (h *Handler) AppendFangzhouQuoteItems20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &tool_service.AppendFangzhouQuoteItemsReq{})
//}

//// RefreshSaleChannelType20200101 刷新报价单数据
//func (h *Handler) RefreshSaleChannelType20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &tool_service.RefreshSaleChannelTypeReq{})
//}

// RefreshKaniCache20200101 刷新kani缓存信息
func (h *Handler) RefreshKaniCache20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &kani_service.RefreshKaniCacheReq{})
}

// GetLarkExcelData20200101 获取飞书表格数据
func (h *Handler) GetLarkExcelData20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.GetLarkExcelDataReq{})
}

//// CheckInterfaceIdentical20200101 校验接口数据是否一致
//func (h *Handler) CheckInterfaceIdentical20200101(c context.Context, ctx *app.RequestContext) {
//	h.handle(c, ctx, &tool_service.CheckInterfaceIdenticalReq{})
//}

func (h *Handler) GetQuoteSubmitEntity20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &lark_approval_process.GetQuoteSubmitEntityReq{})
}

// RefreshQuoteEffectiveTime20200101 刷新已生效报价单-生效时间
func (h *Handler) RefreshQuoteEffectiveTime20200101(c context.Context, ctx *app.RequestContext) {
	h.handle(c, ctx, &tool_service.RefreshQuoteEffectiveTimeReq{})
}

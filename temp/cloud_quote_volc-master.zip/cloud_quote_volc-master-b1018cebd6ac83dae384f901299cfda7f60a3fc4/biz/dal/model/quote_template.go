package model

import (
	"strings"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type QuoteTemplate struct {
	framework.BaseDB
	TemplateName           string
	TemplateCode           string
	TemplateDesc           string
	TemplateVersion        string
	TemplateStatus         int
	CreatorAccountId       string
	TemplateComposableType int
	TemplateApplyType      int
	TemplateVersionType    int
	LatestVersion          int
	TemplateParentId       int64
	TemplateMainId         int64
	TemplateMaxVersion     int
	PublishTime            time.Time
	RecallTime             time.Time
	TplCopyFrom            int64
	RelatedProducts        string
	TemplateItemNum        int
	ProductTags            string
	TemplateTags           framework.GormStrList
}

func (m *QuoteTemplate) TableName() string {
	return "quote_template"
}

// GetRelatedTradeProducts 模版包含的TradeProduct数组
func (m *QuoteTemplate) GetRelatedTradeProducts() []string {
	var relatedTradeProducts []string
	for _, tradeProduct := range strings.Split(m.RelatedProducts, ",") {
		tradeProduct = strings.TrimSpace(tradeProduct)
		if tradeProduct == "" {
			continue
		}
		relatedTradeProducts = append(relatedTradeProducts, tradeProduct)
	}

	return relatedTradeProducts
}

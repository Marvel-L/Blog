package model

import (
	"testing"

	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// TestQuoteItemCloneFidelity 校验 QuoteItem.Clone() 完整保留快照复制所依赖的敏感字段。
//
// 审批中修改快照复制要求“原样冻结”，报价项字段必须逐字段复制、不得重新派生。
// 本用例锁定曾被变更单复制逻辑重新派生、导致快照失真的字段：
// IncomeType / ConfigIsPublic / SalesMode / ConfigPublicDisplay，以及其它关键业务字段。
func TestQuoteItemCloneFidelity(t *testing.T) {
	convey.Convey("QuoteItem.Clone 完整复制敏感字段", t, func() {
		src := &QuoteItem{
			BaseDB:              framework.BaseDB{Id: 999},
			IncomeType:          "by_measure",
			SalesMode:           "SavingsPlans",
			ConfigIsPublic:      1,
			ConfigPublicDisplay: 2,
			IsZeroPrice:         1,
			TaxRuleType:         "combined_sale",
			InvoiceProject:      "invoice-x",
		}
		got := src.Clone()

		convey.So(got.Id, convey.ShouldEqual, 0) // 仅主键置零
		// 以下字段必须与原值完全一致（快照冻结）
		convey.So(got.IncomeType, convey.ShouldEqual, src.IncomeType)
		convey.So(got.SalesMode, convey.ShouldEqual, src.SalesMode)
		convey.So(got.ConfigIsPublic, convey.ShouldEqual, src.ConfigIsPublic)
		convey.So(got.ConfigPublicDisplay, convey.ShouldEqual, src.ConfigPublicDisplay)
		convey.So(got.IsZeroPrice, convey.ShouldEqual, src.IsZeroPrice)
		convey.So(got.TaxRuleType, convey.ShouldEqual, src.TaxRuleType)
		convey.So(got.InvoiceProject, convey.ShouldEqual, src.InvoiceProject)
	})
}

// TestCloneResetsSnapshotFrom 校验 Clone() 会把 snapshot_from 归零。
//
// 快照复制依赖此不变量：Clone 后必须由复制逻辑显式赋 snapshot_from=源ID，
// 避免克隆体误继承源对象的 snapshot_from 造成来源链错乱。
func TestCloneResetsSnapshotFrom(t *testing.T) {
	convey.Convey("Clone 归零 snapshot_from", t, func() {
		convey.Convey("CouponConfigDB", func() {
			src := &CouponConfigDB{BaseDB: framework.BaseDB{Id: 10}, SnapshotFrom: 7}
			convey.So(src.Clone().SnapshotFrom, convey.ShouldEqual, 0)
		})
		convey.Convey("GuaranteeItem", func() {
			src := &GuaranteeItem{BaseDB: framework.BaseDB{Id: 10}, SnapshotFrom: 7}
			convey.So(src.Clone().SnapshotFrom, convey.ShouldEqual, 0)
		})
	})
}

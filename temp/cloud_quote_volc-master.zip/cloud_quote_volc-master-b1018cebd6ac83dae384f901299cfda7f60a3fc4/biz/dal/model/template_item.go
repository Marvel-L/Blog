package model

import (
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

const (
	TemplateItemID = "TemplateItemID"
)

// TemplateItem 报价模板项
type TemplateItem struct {
	framework.BaseDB
	TemplateID            int64
	ProductCode           string
	ProductRelease        string
	PricingVersion        string
	CreatorAccountID      string
	ProductName           string
	StandardProductCode   string
	StandardProductName   string
	ProductDepartmentName string
	TradeProduct          string
	TradeProductName      string
	ParentItemID          int64
	ItemType              constants.ProductType
	TemplateSolutionID    int64
	PriceInfoSnapshot     string
	ItemStatus            int //模板项状态：0-正式，1-草稿
	ItemCopyFrom          int64
	StandardProduct       int
	TemplateSolutionType  int
	GiveAwayType          string // 赠送类型：赠送、区间赠送
	ActivationType        int    // 开通类型：0-其他，1-开通型
	IsZeroPrice           int    // 是否0元刊例价：0-否，1-是
	SalesMode             string // 商品售卖模式：SavingsPlans-节省计划, Others-其他类型商品
}

func (m *TemplateItem) TableName() string {
	return "template_item"
}

func (m *TemplateItem) GetCacheVersion() string {
	if m.ItemType == multienv.TradeProductTypeOffline {
		return m.PricingVersion
	}
	return m.ProductRelease
}

func (m *TemplateItem) GetQuotePriceVersion() string { //线上标品算价不传价格版本
	if m.ItemType == multienv.TradeProductTypeOffline {
		return m.PricingVersion
	}
	return ""
}

func (m *TemplateItem) GetProductKey() string {
	if m.ItemType == multienv.TradeProductTypeOnline {
		return m.TradeProduct
	}
	return fmt.Sprintf("%d%s%s", m.TemplateSolutionID, constants.Separator, m.TradeProduct)
}

// IsZeroQuote 是否为0元报价
func (m *TemplateItem) IsZeroQuote() bool {
	return m.GiveAwayType == multienv.GetGiveAwayTypeStd()
}

func (m *TemplateItem) IsPublicStandard() bool {
	return m.ItemType == multienv.TradeProductTypeOnline && m.StandardProduct == multienv.TradeProductStandardYes
}

func (m *TemplateItem) IsPrivateStandard() bool {
	return m.ItemType == multienv.TradeProductTypeOffline && m.StandardProduct == multienv.TradeProductStandardYes
}

func (m *TemplateItem) GetRelatedProductType() constants.ProductType {
	if m.TemplateSolutionType == constants.QuoteSolutionTypeDefaultSolution {
		return multienv.TradeProductTypeSolution
	}
	if m.TemplateSolutionType == constants.QuoteSolutionTypeIntegratedMachine {
		return multienv.TradeProductTypeIntegratedMachine
	}
	if m.ItemType == multienv.TradeProductDeploymentTypePublic {
		return multienv.TradeProductTypeOnline
	}
	if m.ItemType == multienv.TradeProductDeploymentTypePrivate &&
		m.StandardProduct == multienv.TradeProductStandardYes {
		return multienv.TradeProductTypeOffline
	}
	if m.ItemType == multienv.TradeProductDeploymentTypePrivate &&
		m.StandardProduct == multienv.TradeProductStandardNo {
		return multienv.TradeProductTypeNoStandard
	}
	return m.ItemType
}

func (m *TemplateItem) IsSpProduct() bool {
	return m.SalesMode == multienv.SalesModeSavingsPlans
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"fmt"
)

type TemplateSolution struct {
	framework.BaseDB
	TemplateId              int64
	StandardSolutionCode    string
	StandardSolutionName    string
	StandardSolutionVersion string
	TradeSolutionCode       string
	TradeSolution           string
	TradeSolutionName       string
	TradeSolutionVersion    string
	StandardDepartmentName  string
	CreatorAccountId        string
	ParentSolutionId        int64
	SolutionType            int //类型：1-解决方案，2-一体机套餐
	SolutionCopyFrom        int64
	DeploymentType          string
	TradeSolutionType       string
}

func (m *TemplateSolution) TableName() string {
	return "template_solution"
}

func (m *TemplateSolution) GetTradeSolutionKey() string {
	return fmt.Sprintf("%s::%s", m.TradeSolution, m.TradeSolutionVersion)
}

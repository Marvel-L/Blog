package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// QuoteResourceChangeLog 报价单资源单变更表
type QuoteResourceChangeLog struct {
	framework.BaseDB
	ResourcePageID            int64  // 所属资源单id
	QuoteID                   int64  // 所属报价单id
	OperationID               string // 业务侧操作id
	ChangeType                int    // 变更类型：1-修改供卡数量，2-提前交付
	CurrentApprovalInstanceID string // 飞书表单审批实例ID
	ChangeStatus              string // 变更状态：Submitted-审批中，Pass-审批通过，Reject-审批驳回
	ResourceNumData           string // 资源卡数变更原始数据
	Remark                    string // 备注
	ApplicantEmail            string // 提交申请人邮箱
	BackupData                string // 数据变更记录
}

// TableName 表名称
func (r *QuoteResourceChangeLog) TableName() string {
	return "quote_resource_change_log"
}

// GetChangeTypeDesc 获取变更类型描述
func (r *QuoteResourceChangeLog) GetChangeTypeDesc() string {
	return constants.ChangeTypeMap[r.ChangeType]
}

// ResourceNumData 资源卡增量数据对象
type ResourceNumData struct {
	ResourceItemID int64 `json:"ResourceItemID"`
	ResourceNumAdd int64 `json:"ResourceNumAdd"`
}

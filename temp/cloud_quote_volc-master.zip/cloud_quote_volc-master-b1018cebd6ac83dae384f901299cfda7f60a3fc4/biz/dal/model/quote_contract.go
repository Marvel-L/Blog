package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

const (
	ContractSourceQuote        = 1
	ContractSourceCoordination = 2
)

var ContractSourceMapping = map[int]string{
	ContractSourceQuote:        "报价合同",
	ContractSourceCoordination: "在线协同",
}

type QuoteContract struct {
	framework.BaseDB
	ContractCode     string
	ContractStatus   string
	QuoteID          int64
	CreatorAccountID string
	AfterOaResp      string
	ContractSource   int
}

type QuoteContractResp struct {
	ContractCode   string
	ContractStatus string
	QuoteID        int64
}

func (q *QuoteContract) TableName() string {
	return "quote_contract"
}

func (q *QuoteContract) GenResp() *QuoteContractResp {
	return &QuoteContractResp{
		ContractCode:   q.ContractCode,
		ContractStatus: q.ContractStatus,
		QuoteID:        q.QuoteID,
	}
}

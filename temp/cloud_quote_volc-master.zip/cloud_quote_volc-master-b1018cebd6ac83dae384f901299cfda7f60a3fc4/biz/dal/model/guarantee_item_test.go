package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func Test_GuaranteeItem_GenResp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test GuaranteeItem.GenResp", t, func() {
		mockey.PatchConvey("正常场景: 所有字段都为有效值", func() {
			totalSeats := int64(88)

			m := &GuaranteeItem{
				BaseDB:                framework.BaseDB{Id: 1},
				QuoteID:               101,
				GuaranteeType:         1,
				GuaranteeAmount:       decimal.New(1000, 2),
				GuaranteeRule:         "rule1",
				RelatedQuoteItemId:    "[123, 456]",
				CreatorAccountId:      "creator_acc",
				AccountId:             "acc1,acc2",
				AccumulateType:        "typeA",
				GuaranteeCategory:     0,
				GuaranteeInterval:     30,
				GuaranteeStartTime:    "2023-01-01T00:00:00Z",
				GuaranteeEndTime:      "2023-12-31T23:59:59Z",
				TotalSeats:            &totalSeats,
				GuaranteeProductSeats: `[{"TradeProduct":"prod-a","Seats":88}]`,
			}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:       1,
				QuoteID:               101,
				GuaranteeType:         1,
				GuaranteeAmount:       decimal.New(1000, 2),
				GuaranteeRule:         "rule1",
				RelatedQuoteItemId:    []int64{123, 456},
				AccountID:             []string{"acc1", "acc2"},
				AccumulateType:        "typeA",
				GuaranteeCategory:     0,
				GuaranteeInterval:     30,
				GuaranteeStartTime:    "2023-01-01T00:00:00Z",
				GuaranteeEndTime:      "2023-12-31T23:59:59Z",
				TotalSeats:            &totalSeats,
				GuaranteeProductSeats: []GuaranteeProductSeat{{TradeProduct: "prod-a", Seats: 88}},
			}
			convey.So(resp, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("异常场景: RelatedQuoteItemId为无效JSON字符串", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 2},
				QuoteID:            102,
				RelatedQuoteItemId: "invalid-json",
				AccountId:          "acc3",
			}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:    2,
				QuoteID:            102,
				GuaranteeType:      0,
				GuaranteeAmount:    decimal.Decimal{},
				GuaranteeRule:      "",
				RelatedQuoteItemId: nil,
				AccountID:          []string{"acc3"},
				AccumulateType:     "",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "",
				GuaranteeEndTime:   "",
			}
			convey.So(resp, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景: RelatedQuoteItemId为空JSON数组", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 3},
				QuoteID:            103,
				RelatedQuoteItemId: "[]",
				AccountId:          "acc4",
			}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:    3,
				QuoteID:            103,
				GuaranteeType:      0,
				GuaranteeAmount:    decimal.Decimal{},
				GuaranteeRule:      "",
				RelatedQuoteItemId: []int64{},
				AccountID:          []string{"acc4"},
				AccumulateType:     "",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "",
				GuaranteeEndTime:   "",
			}
			convey.So(resp, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景: AccountId为空字符串", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 4},
				QuoteID:            104,
				RelatedQuoteItemId: "[1]",
				AccountId:          "",
			}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:    4,
				QuoteID:            104,
				GuaranteeType:      0,
				GuaranteeAmount:    decimal.Decimal{},
				GuaranteeRule:      "",
				RelatedQuoteItemId: []int64{1},
				AccountID:          []string{""},
				AccumulateType:     "",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "",
				GuaranteeEndTime:   "",
			}
			convey.So(resp, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景: AccountId不含逗号", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 5},
				QuoteID:            105,
				RelatedQuoteItemId: "[2, 3]",
				AccountId:          "single_acc",
			}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:    5,
				QuoteID:            105,
				GuaranteeType:      0,
				GuaranteeAmount:    decimal.Decimal{},
				GuaranteeRule:      "",
				RelatedQuoteItemId: []int64{2, 3},
				AccountID:          []string{"single_acc"},
				AccumulateType:     "",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "",
				GuaranteeEndTime:   "",
			}
			convey.So(resp, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景: 输入为零值GuaranteeItem", func() {

			m := &GuaranteeItem{}

			resp, err := m.GenResp()
			convey.So(err, convey.ShouldBeNil)

			expected := &GuaranteeResp{
				GuaranteeItemID:    0,
				QuoteID:            0,
				GuaranteeType:      0,
				GuaranteeAmount:    decimal.Decimal{},
				GuaranteeRule:      "",
				RelatedQuoteItemId: nil,
				AccountID:          []string{""},
				AccumulateType:     "",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "",
				GuaranteeEndTime:   "",
			}
			convey.So(resp, convey.ShouldResemble, expected)
			convey.So(resp.TotalSeats, convey.ShouldBeNil)
		})
	})
}

func Test_GuaranteeItem_GenRespV2_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_GuaranteeItem_GenRespV2", t, func() {
		mockey.PatchConvey("success: RelatedQuoteItemId is a valid json array string", func() {
			totalSeats := int64(66)

			m := &GuaranteeItem{
				BaseDB:                framework.BaseDB{Id: 1001},
				QuoteID:               2002,
				GuaranteeType:         1,
				GuaranteeAmount:       decimal.New(5000, 2),
				GuaranteeRule:         "test_rule",
				RelatedQuoteItemId:    "[10, 20, 30]",
				CreatorAccountId:      "creator-123",
				AccountId:             "account-456",
				AccumulateType:        "MONTHLY",
				GuaranteeCategory:     0,
				GuaranteeInterval:     1,
				GuaranteeStartTime:    "2024-01-01T00:00:00Z",
				GuaranteeEndTime:      "2024-12-31T23:59:59Z",
				TotalSeats:            &totalSeats,
				GuaranteeProductSeats: `[{"TradeProduct":"prod-a","Seats":66}]`,
			}

			resp, err := m.GenRespV2()
			convey.So(err, convey.ShouldBeNil)

			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.GuaranteeItemID, convey.ShouldEqual, m.Id)
			convey.So(resp.QuoteID, convey.ShouldEqual, m.QuoteID)
			convey.So(resp.GuaranteeType, convey.ShouldEqual, m.GuaranteeType)
			convey.So(resp.GuaranteeAmount.Equal(m.GuaranteeAmount), convey.ShouldBeTrue)
			convey.So(resp.GuaranteeRule, convey.ShouldEqual, m.GuaranteeRule)
			convey.So(resp.RelatedQuoteItemId, convey.ShouldResemble, []int64{10, 20, 30})
			convey.So(resp.AccountID, convey.ShouldEqual, m.AccountId)
			convey.So(resp.AccumulateType, convey.ShouldEqual, m.AccumulateType)
			convey.So(resp.GuaranteeCategory, convey.ShouldEqual, m.GuaranteeCategory)
			convey.So(resp.GuaranteeInterval, convey.ShouldEqual, m.GuaranteeInterval)
			convey.So(resp.GuaranteeStartTime, convey.ShouldEqual, m.GuaranteeStartTime)
			convey.So(resp.GuaranteeEndTime, convey.ShouldEqual, m.GuaranteeEndTime)
			convey.So(resp.TotalSeats, convey.ShouldEqual, m.TotalSeats)
			convey.So(resp.GuaranteeProductSeats, convey.ShouldResemble, []GuaranteeProductSeat{{TradeProduct: "prod-a", Seats: 66}})
		})

		mockey.PatchConvey("success: RelatedQuoteItemId is an invalid json string", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 1002},
				QuoteID:            2003,
				GuaranteeType:      2,
				GuaranteeAmount:    decimal.New(100, 0),
				GuaranteeRule:      "invalid_rule",
				RelatedQuoteItemId: "this is not a json",
				AccountId:          "account-789",
				AccumulateType:     "YEARLY",
				GuaranteeCategory:  1,
				GuaranteeInterval:  12,
				GuaranteeStartTime: "2023-01-01T00:00:00Z",
				GuaranteeEndTime:   "2023-12-31T23:59:59Z",
			}

			resp, err := m.GenRespV2()
			convey.So(err, convey.ShouldBeNil)

			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.GuaranteeItemID, convey.ShouldEqual, m.Id)
			convey.So(resp.QuoteID, convey.ShouldEqual, m.QuoteID)
			convey.So(resp.GuaranteeType, convey.ShouldEqual, m.GuaranteeType)
			convey.So(resp.GuaranteeAmount.Equal(m.GuaranteeAmount), convey.ShouldBeTrue)
			convey.So(resp.GuaranteeRule, convey.ShouldEqual, m.GuaranteeRule)
			convey.So(resp.RelatedQuoteItemId, convey.ShouldBeNil)
			convey.So(resp.AccountID, convey.ShouldEqual, m.AccountId)
			convey.So(resp.AccumulateType, convey.ShouldEqual, m.AccumulateType)
			convey.So(resp.GuaranteeCategory, convey.ShouldEqual, m.GuaranteeCategory)
			convey.So(resp.GuaranteeInterval, convey.ShouldEqual, m.GuaranteeInterval)
			convey.So(resp.GuaranteeStartTime, convey.ShouldEqual, m.GuaranteeStartTime)
			convey.So(resp.GuaranteeEndTime, convey.ShouldEqual, m.GuaranteeEndTime)
			convey.So(resp.TotalSeats, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success: RelatedQuoteItemId is an empty json array string", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 1003},
				QuoteID:            2004,
				GuaranteeType:      1,
				GuaranteeAmount:    decimal.New(200, 0),
				GuaranteeRule:      "empty_array_rule",
				RelatedQuoteItemId: "[]",
				AccountId:          "account-101",
				AccumulateType:     "CONTRACT",
				GuaranteeCategory:  0,
				GuaranteeInterval:  0,
				GuaranteeStartTime: "2025-01-01T00:00:00Z",
				GuaranteeEndTime:   "2025-12-31T23:59:59Z",
			}

			resp, err := m.GenRespV2()
			convey.So(err, convey.ShouldBeNil)

			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.GuaranteeItemID, convey.ShouldEqual, m.Id)
			convey.So(resp.QuoteID, convey.ShouldEqual, m.QuoteID)
			convey.So(resp.GuaranteeType, convey.ShouldEqual, m.GuaranteeType)
			convey.So(resp.GuaranteeAmount.Equal(m.GuaranteeAmount), convey.ShouldBeTrue)
			convey.So(resp.GuaranteeRule, convey.ShouldEqual, m.GuaranteeRule)
			convey.So(resp.RelatedQuoteItemId, convey.ShouldNotBeNil)
			convey.So(len(resp.RelatedQuoteItemId), convey.ShouldEqual, 0)
			convey.So(resp.AccountID, convey.ShouldEqual, m.AccountId)
			convey.So(resp.AccumulateType, convey.ShouldEqual, m.AccumulateType)
			convey.So(resp.GuaranteeCategory, convey.ShouldEqual, m.GuaranteeCategory)
			convey.So(resp.GuaranteeInterval, convey.ShouldEqual, m.GuaranteeInterval)
			convey.So(resp.GuaranteeStartTime, convey.ShouldEqual, m.GuaranteeStartTime)
			convey.So(resp.GuaranteeEndTime, convey.ShouldEqual, m.GuaranteeEndTime)
			convey.So(resp.TotalSeats, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success: RelatedQuoteItemId is an empty string", func() {

			m := &GuaranteeItem{
				BaseDB:             framework.BaseDB{Id: 1004},
				QuoteID:            2005,
				GuaranteeType:      3,
				GuaranteeAmount:    decimal.New(300, 0),
				GuaranteeRule:      "empty_string_rule",
				RelatedQuoteItemId: "",
				AccountId:          "account-202",
				AccumulateType:     "DAILY",
				GuaranteeCategory:  1,
				GuaranteeInterval:  1,
				GuaranteeStartTime: "2022-01-01T00:00:00Z",
				GuaranteeEndTime:   "2022-01-31T23:59:59Z",
			}

			resp, err := m.GenRespV2()
			convey.So(err, convey.ShouldBeNil)

			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.GuaranteeItemID, convey.ShouldEqual, m.Id)
			convey.So(resp.QuoteID, convey.ShouldEqual, m.QuoteID)
			convey.So(resp.GuaranteeType, convey.ShouldEqual, m.GuaranteeType)
			convey.So(resp.GuaranteeAmount.Equal(m.GuaranteeAmount), convey.ShouldBeTrue)
			convey.So(resp.GuaranteeRule, convey.ShouldEqual, m.GuaranteeRule)
			convey.So(resp.RelatedQuoteItemId, convey.ShouldBeNil)
			convey.So(resp.AccountID, convey.ShouldEqual, m.AccountId)
			convey.So(resp.AccumulateType, convey.ShouldEqual, m.AccumulateType)
			convey.So(resp.GuaranteeCategory, convey.ShouldEqual, m.GuaranteeCategory)
			convey.So(resp.GuaranteeInterval, convey.ShouldEqual, m.GuaranteeInterval)
			convey.So(resp.GuaranteeStartTime, convey.ShouldEqual, m.GuaranteeStartTime)
			convey.So(resp.GuaranteeEndTime, convey.ShouldEqual, m.GuaranteeEndTime)
			convey.So(resp.TotalSeats, convey.ShouldBeNil)
		})
	})
}

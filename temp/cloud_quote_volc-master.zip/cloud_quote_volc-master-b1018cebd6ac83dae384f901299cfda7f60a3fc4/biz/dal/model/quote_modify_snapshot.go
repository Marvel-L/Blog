package model

// 审批中修改版本链字段计算（新版审批中修改）。
//
// 对应技术方案「发起审批中修改」版本链示例（原单 100 与快照 101/102/103）：
//
//	原单 100 - V3   origin_snapshot_id=101 parent_snapshot_id=103
//	快照 103 - V2   snapshot_from=100 origin_snapshot_id=101 parent_snapshot_id=102
//	快照 102 - V1   snapshot_from=100 origin_snapshot_id=101 parent_snapshot_id=101
//	快照 101 - V0   snapshot_from=100 origin_snapshot_id=0   parent_snapshot_id=0
//
// 发起审批中修改时：先基于原单当前状态复制生成快照单（写入 SnapshotChainFieldsForNewSnapshot
// 计算出的字段），快照入库拿到新快照ID后，再用 OriginChainFieldsAfterSnapshot 更新原单。

// SnapshotChainFieldsForNewSnapshot 计算发起审批中修改时，基于原单复制出的「快照单」应写入的版本链字段。
// 接收者 q 为原单（复制前的当前状态）。返回值语义：
//   - snapshotFrom：快照所属报价单ID，恒为原单ID。
//   - originSnapshotID：继承原单当前 origin_snapshot_id（首次发起时为 0，即该快照自身就是版本链起点 V0）。
//   - parentSnapshotID：继承原单当前 parent_snapshot_id（首次发起时为 0，否则指向上一个快照）。
func (q *Quote) SnapshotChainFieldsForNewSnapshot() (originSnapshotID, parentSnapshotID, snapshotFrom int64) {
	return q.OriginSnapshotID, q.ParentSnapshotID, q.Id
}

// OriginChainFieldsAfterSnapshot 计算快照单入库、拿到新快照ID后，「原单」应更新的版本链字段。
// 接收者 q 为原单（更新前的当前状态），newSnapshotID 为刚生成的快照单ID。返回值语义：
//   - originSnapshotID：首次发起（原单原 origin_snapshot_id==0）时以本次首个快照ID作为版本链起点；否则保持不变。
//   - parentSnapshotID：始终指向最新快照ID。
func (q *Quote) OriginChainFieldsAfterSnapshot(newSnapshotID int64) (originSnapshotID, parentSnapshotID int64) {
	originSnapshotID = q.OriginSnapshotID
	if originSnapshotID == 0 {
		originSnapshotID = newSnapshotID
	}
	parentSnapshotID = newSnapshotID
	return
}

// NewModifyProcessCanNotEditField 校验新版审批中修改链路下，原单相对修改前是否改动了不可修改字段。
//
// 对应技术方案「审批中修改限制」：新版审批中修改仅锁定以下三类字段，其余字段按草稿态权限放开：
//  1. 报价类型 QuoteType
//  2. 客户类型 TradeTypeCode
//  3. 阶梯档位阈值（阶梯报价的 ProgressiveInfo，含累计维度/档位阈值/累计类型）
//
// 返回 (是否一致, 首个不一致的字段名)。isSame=false 时表示命中了不可修改字段。
// old 为修改前的原单，q 为修改后的原单。
func (q *Quote) NewModifyProcessCanNotEditField(old *Quote) (isSame bool, field string) {
	if old == nil {
		return true, ""
	}
	if q.QuoteType != old.QuoteType {
		return false, "QuoteType"
	}
	if q.TradeTypeCode != old.TradeTypeCode {
		return false, "TradeTypeCode"
	}
	// 阶梯档位阈值：阶梯报价单的 ProgressiveInfo 保持不可修改
	if q.ProgressiveInfo != old.ProgressiveInfo {
		return false, "ProgressiveInfo"
	}
	return true, ""
}

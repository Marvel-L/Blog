package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"encoding/json"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type QuoteMonitorRule struct {
	framework.BaseDB
	RuleID        int64     // 规则ID
	RuleType      string    // 规则类型
	RuleName      string    // 规则名称
	CreatorEmail  string    // 创建人邮箱
	RuleStatus    string    // 规则状态
	EffectiveTime time.Time // 生效时间
	BizCode       string    // 业务编码
	RuleDetail    string    // 规则详情
	ChangeStatus  int64     // 变更状态，0-正常，1-变更中
	ExpiredNotify int64     // 失效通知，0-未通知，1-已通知
}

func (r *QuoteMonitorRule) GetApprovalTimeoutRuleDetail() *QuoteApprovalTimeoutMonitorRuleDetail {
	if r.RuleType != multienv.RuleTypeQuoteApprovalTimeoutMonitor {
		return nil
	}
	var ruleDetail *QuoteApprovalTimeoutMonitorRuleDetail
	_ = json.Unmarshal([]byte(r.RuleDetail), &ruleDetail)
	return ruleDetail
}

func (r *QuoteMonitorRule) TableName() string {
	return "quote_monitor_rule"
}

// QuoteApprovalTimeoutMonitorRuleDetail RuleType=RuleTypeQuoteApprovalTimeoutMonitor时RuleDetail的JSON结构
type QuoteApprovalTimeoutMonitorRuleDetail struct {
	ApprovalType  string                   // 飞书审批表单类型
	QuoteScenes   []string                 // 报价单场景列表
	ApprovalRoles []string                 // 飞书审批角色列表
	ReminderTypes []string                 // 提醒类型列表
	MessageConfig *LarkMessageConfigDetail // 飞书消息配置
	GroupConfig   *LarkGroupConfigDetail   // 飞书群配置
}

type LarkMessageConfigDetail struct {
	DateType          string   // 提醒日类型
	TimeoutType       string   // 超时类型
	TimePoint         string   // 超时时间点
	TimeInterval      int64    // 超时小时数
	MessageTemplate   string   // 飞书消息模板
	ReminderFrequency int64    // 提醒频次
	BlacklistEmails   []string // 黑名单邮箱列表
}

type LarkGroupConfigDetail struct {
	DateType              string   // 提醒日类型
	DefaultNotifierEmails []string // 默认通知人邮箱列表
	BlacklistEmails       []string // 黑名单邮箱列表
}

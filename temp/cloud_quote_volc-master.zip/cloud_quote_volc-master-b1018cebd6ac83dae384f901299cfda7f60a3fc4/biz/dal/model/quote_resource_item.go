package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"fmt"
)

// QuoteResourceItem 报价资源卡
type QuoteResourceItem struct {
	framework.BaseDB
	ResourcePageID     int64  // 所属资源单id
	QuoteID            int64  // 所属报价单id
	QuoteItemID        int64  // 关联报价项id
	CreatorAccountID   string // 创建人email
	CustomerAccountID  string // 客户账号
	ResourceCardName   string // 资源卡名称
	TradeProduct       string // 商品code
	TradeProductName   string // 商品中文名
	PrePayTypeCode     string // 付费方式code
	PrePayTypeName     string // 付费方式名字
	ConfigCategory     string // 配置分类
	ConfigCode         string // 配置code
	ConfigName         string // 配置名字
	ChargeMethodCode   string // 计费方式code
	ChargeMethodName   string // 计费方式名字
	RegionCode         string // 地域code
	RegionName         string // 地域名字
	ChargeUnitCode     string // 计费单元code
	ChargeUnitName     string // 计费单元名字
	ChargeItemCode     string // 计费项code
	ResourceNum        int64  // 配置数量
	ResourceItemBelong int64  // 父级资源卡id
}

// TableName 表名称
func (r *QuoteResourceItem) TableName() string {
	return "quote_resource_item"
}

// GenResp 获取资源卡业务对象
func (r *QuoteResourceItem) GenResp() *ResourceItemResp {
	return &ResourceItemResp{
		ResourceItemID:     r.Id,
		QuoteID:            r.QuoteID,
		QuoteItemID:        r.QuoteItemID,
		ResourceCardName:   r.ResourceCardName,
		TradeProduct:       r.TradeProduct,
		TradeProductName:   r.TradeProductName,
		PrePayTypeCode:     r.PrePayTypeCode,
		PrePayTypeName:     r.PrePayTypeName,
		ConfigCategory:     r.ConfigCategory,
		ConfigCode:         r.ConfigCode,
		ConfigName:         r.ConfigName,
		ChargeMethodCode:   r.ChargeMethodCode,
		ChargeMethodName:   r.ChargeMethodName,
		RegionCode:         r.RegionCode,
		RegionName:         r.RegionName,
		ChargeUnitCode:     r.ChargeUnitCode,
		ChargeUnitName:     r.ChargeUnitName,
		ChargeItemCode:     r.ChargeItemCode,
		ResourceNum:        r.ResourceNum,
		ResourceItemBelong: r.ResourceItemBelong,
		ResourceNumLimit:   0,
	}
}

// QuoteResourceItems 报价项资源卡数组包装对象
type QuoteResourceItems []*QuoteResourceItem

// GenResp 报价项资源卡数组包装对象
func (i QuoteResourceItems) GenResp() []*ResourceItemResp {
	var ret []*ResourceItemResp
	for _, quoteResourceItem := range i {
		ret = append(ret, quoteResourceItem.GenResp())
	}
	return ret
}

// ResourceItemResp 报价项资源卡业务对象
type ResourceItemResp struct {
	ResourceItemID     int64  // 资源卡id
	QuoteID            int64  // 关联报价单id
	QuoteItemID        int64  // 关联报价项id
	ResourceCardName   string // 资源卡名称
	TradeProduct       string // 商品code
	TradeProductName   string // 商品中文名
	PrePayTypeCode     string // 付费方式code
	PrePayTypeName     string // 付费方式名字
	ConfigCategory     string // 配置分类
	ConfigCode         string // 配置code
	ConfigName         string // 配置名字
	ChargeMethodCode   string // 计费方式code
	ChargeMethodName   string // 计费方式名字
	RegionCode         string // 地域code
	RegionName         string // 地域名字
	ChargeUnitCode     string // 计费单元code
	ChargeUnitName     string // 计费单元名字
	ChargeItemCode     string // 计费项code
	ResourceNum        int64  // 配置数量
	ResourceItemBelong int64  // 父级资源卡id
	SubResourceItems   []*ResourceItemResp
	ResourceNumLimit   int                          //资源卡数量限制，配置数量需要是限制数量的整数倍
	DefaultNumLimit    int                          `json:"-"`
	SellingModeCode    string                       `json:"-"`
	ItemStatus         int                          `json:"-"`
	SubResourceItemMap map[string]*ResourceItemResp `json:"-"`
	ParentResourceItem *ResourceItemResp            `json:"-"`
}

// GetResourceCardKey 获取资源卡唯一key
func (r *ResourceItemResp) GetResourceCardKey() string {
	return fmt.Sprintf("%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
		r.ResourceCardName, constants.Separator,
		r.TradeProduct, constants.Separator,
		r.PrePayTypeCode, constants.Separator,
		r.ConfigCategory, constants.Separator,
		r.ConfigCode, constants.Separator,
		r.ChargeMethodCode, constants.Separator,
		r.RegionCode, constants.Separator,
		r.ChargeUnitCode, constants.Separator,
		r.ChargeItemCode)
}

// GetResourceCardCheckKey 获取资源卡校验key
func (r *ResourceItemResp) GetResourceCardCheckKey() string {
	return fmt.Sprintf("%d%s%s", r.QuoteItemID, constants.Separator, r.GetResourceCardKey())
}

// GetControlResourceKey 获取受控资源卡资源卡key
func (r *ResourceItemResp) GetControlResourceKey() string {
	return fmt.Sprintf(
		"%s%s%s%s%s",
		r.TradeProduct,
		constants.Separator,
		r.ConfigCode,
		constants.Separator,
		r.ChargeUnitName,
	)
}

// GetDBData 资源卡业务数据转存储数据对象
func (r *ResourceItemResp) GetDBData(quoteID, resourcePageID int64, creatorAccountID, customerAccountID string) *QuoteResourceItem {
	return &QuoteResourceItem{
		BaseDB: framework.BaseDB{
			Id: r.ResourceItemID,
		},
		ResourcePageID:    resourcePageID,
		QuoteID:           quoteID,
		QuoteItemID:       r.QuoteItemID,
		CreatorAccountID:  creatorAccountID,
		CustomerAccountID: customerAccountID,
		ResourceCardName:  r.ResourceCardName,
		TradeProduct:      r.TradeProduct,
		TradeProductName:  r.TradeProductName,
		PrePayTypeCode:    r.PrePayTypeCode,
		PrePayTypeName:    r.PrePayTypeName,
		ConfigCategory:    r.ConfigCategory,
		ConfigCode:        r.ConfigCode,
		ConfigName:        r.ConfigName,
		ChargeMethodCode:  r.ChargeMethodCode,
		ChargeMethodName:  r.ChargeMethodName,
		RegionCode:        r.RegionCode,
		RegionName:        r.RegionName,
		ChargeUnitCode:    r.ChargeUnitCode,
		ChargeUnitName:    r.ChargeUnitName,
		ChargeItemCode:    r.ChargeItemCode,
		ResourceNum:       r.ResourceNum,
	}
}

func (r *QuoteResourceItem) Clone() *QuoteResourceItem {
	raw := *r
	raw.Id = 0
	return &raw
}

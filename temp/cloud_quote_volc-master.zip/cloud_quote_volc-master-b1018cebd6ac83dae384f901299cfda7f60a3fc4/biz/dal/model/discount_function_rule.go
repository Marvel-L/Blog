package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"strings"
	"time"
)

type DiscountFunctionRule struct {
	framework.BaseDB
	DeploymentType            int       //  部署方式：0-公有云，1-私有云
	RelatedProduct            string    //  商品英文名
	RelatedProductName        string    //  商品中文名
	PrePayType                string    //  付费方式
	PrePayTypeName            string    //  付费方式名字
	BelongingDepartment       string    //  一级产品线
	BizLineName               string    //  二级产品线
	DiscountFunction          string    //  报价方式
	DiscountFunctionName      string    //  报价方式名字
	ApplyReason               string    //  申请原因
	RuleStatus                string    //  报价方式状态
	CreatorAccountId          string    //  创建人id
	EffectiveTime             time.Time //生效时间
	UnEffectiveTime           time.Time // 终止时间
	CurrentApprovalInstanceId string    //飞书表单审批实例ID

}

func (r *DiscountFunctionRule) TableName() string {
	return "discount_function_rule"
}

func (r *DiscountFunctionRule) CanEdit() bool {
	return r.RuleStatus == constants.RuleStatusInitialed ||
		r.RuleStatus == constants.RuleStatusReject
}

func (r *DiscountFunctionRule) GetPrePayTypeNameArr() []string {
	if r.PrePayTypeName == "" {
		return nil
	} else {
		return strings.Split(r.PrePayTypeName, ",")
	}
}

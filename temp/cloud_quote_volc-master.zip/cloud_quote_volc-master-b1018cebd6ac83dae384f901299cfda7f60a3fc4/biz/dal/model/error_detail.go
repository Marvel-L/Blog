package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

type ErrorDetail struct {
	framework.BaseDB
	ErrorCode  string // 错误码
	ErrorMsg   string // 错误信息
	ErrorCause string // 错误原因
	Solution   string // 解决方案
	Link       string // 链接
}

func (r *ErrorDetail) TableName() string {
	return "error_detail"
}

package model

import (
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type OaApplication struct {
	framework.BaseDB
	QuoteID           int64  //审批主体id
	Content           string //
	BizParam          string //飞书审批表单参数
	AuditStatus       string //审批实例状态-Pass-Pending-Reject
	FormCode          string //飞书审批表单编码
	FormInstanceID    string //审批中心审批编号
	FormInstanceUrl   string //飞书表单url
	ProcessInstanceID string //飞书表单审批实例ID
	ApplicantID       int64  //申请人邮箱
	CurrentAssignee   string //当前处理人
	ApplicationType   string //申请类型
	CallbackContent   string //飞书回调数据
	TotalMinutes      int64  //总用时(分钟)
}

func (a *OaApplication) TableName() string {
	return "oa_application"
}

type OaApplicationResp struct {
	QuoteID           int64
	AuditStatus       string
	FormCode          string
	FormInstanceID    string
	FormInstanceUrl   string
	ProcessInstanceID string
	ApplicantID       string
	TotalMinutes      int64
	OaCreatedTime     string
	SerialNumber      string
	IsLarkApproval    bool // 是否飞书审批
}

func (a *OaApplication) GenRespNoApplicant() *OaApplicationResp {
	return &OaApplicationResp{
		QuoteID:           a.QuoteID,
		AuditStatus:       a.AuditStatus,
		FormCode:          a.FormCode,
		FormInstanceID:    a.FormInstanceID,
		FormInstanceUrl:   a.FormInstanceUrl,
		ProcessInstanceID: a.ProcessInstanceID,
		TotalMinutes:      a.TotalMinutes,
		OaCreatedTime:     a.CreatedTime.Format(time.RFC3339),
	}
}

func (a *OaApplication) GenResp(applicantAccountID string) *OaApplicationResp {
	return &OaApplicationResp{
		QuoteID:           a.QuoteID,
		AuditStatus:       a.AuditStatus,
		FormCode:          a.FormCode,
		FormInstanceID:    a.FormInstanceID,
		FormInstanceUrl:   a.FormInstanceUrl,
		ProcessInstanceID: a.ProcessInstanceID,
		ApplicantID:       applicantAccountID,
		TotalMinutes:      a.TotalMinutes,
	}
}

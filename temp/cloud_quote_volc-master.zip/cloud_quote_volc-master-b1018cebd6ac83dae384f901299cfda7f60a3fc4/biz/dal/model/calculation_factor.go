package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"fmt"
	"github.com/shopspring/decimal"
	"strings"
	"time"
)

// CalculationFactor  计算因子表
type CalculationFactor struct {
	framework.BaseDB

	FactorType         string
	TradeProduct       string
	TradeProductName   string
	CanPrePayCode      string
	CanPrePayName      string
	ConfigCategoryCode string
	ConfigCategoryName string
	ConfigCode         string
	ConfigName         string
	SellingModeCode    string
	SellingModeName    string
	ChargeMethodCode   string
	ChargeMethodName   string
	RegionCode         string
	RegionName         string
	ChargeUnitCode     string
	ChargeUnitName     string
	PriceFactorCode    string
	PriceFactorName    string
	ChargeItemCode     string
	FactorDefaultValue decimal.Decimal
	FactorStatus       string
	CustomerAccountId  string
	CreatorAccountId   string
	AbandonedTime      time.Time
	PercentageValue    string
}

func (c *CalculationFactor) TableName() string {
	return "calculation_factor"
}

func (c *CalculationFactor) GetKey() string {
	return fmt.Sprintf("%s::%s::%s::%s::%s", c.FactorType, c.TradeProduct, c.ConfigCode, c.SellingModeCode, c.ChargeItemCode)
}

func (c *CalculationFactor) GetUniqKey() string {
	return fmt.Sprintf("%s::%s::%s::%s::%s::%s", c.FactorType, c.TradeProduct, c.ConfigCode, c.SellingModeCode, c.ChargeItemCode, c.CustomerAccountId)
}

func (c *CalculationFactor) GetCacheKey() string {
	return fmt.Sprintf("%s%s", multienv.CalculationFactorHashKey, c.CustomerAccountId)
}

func GetCalculationFactorCacheKey(customerAccountId string) string {
	return fmt.Sprintf("%s%s", multienv.CalculationFactorHashKey, customerAccountId)
}

func (c *CalculationFactor) GetPercentageValues() []decimal.Decimal {
	if c.PercentageValue == "" {
		return nil
	}
	percentageDecimal, _ := GetPercentageDecimal(c.PercentageValue)
	return percentageDecimal
}

func GetPercentageDecimal(percentageValue string) ([]decimal.Decimal, error) {
	var percentageDecimals []decimal.Decimal
	percentageValues := strings.Split(percentageValue, ",")
	for _, percentage := range percentageValues {
		percentageDecimal, err := decimal.NewFromString(percentage)
		if err != nil {
			return nil, err
		}
		percentageDecimals = append(percentageDecimals, percentageDecimal)
	}
	return percentageDecimals, nil
}

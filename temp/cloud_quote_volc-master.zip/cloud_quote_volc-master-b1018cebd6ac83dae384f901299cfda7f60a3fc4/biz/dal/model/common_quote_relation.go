package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

type CommonQuoteRelation struct {
	framework.BaseDB
	QuoteId           int64
	QuoteItemId       int64
	EntityId          int64
	CustomerAccountId string
	CreatorAccountId  string
	RelationScene     int64
}

func (r *CommonQuoteRelation) TableName() string {
	return "common_quote_relation"
}

func (r *CommonQuoteRelation) Clone() *CommonQuoteRelation {
	quoteRelation := *r
	quoteRelation.Id = 0
	return &quoteRelation
}

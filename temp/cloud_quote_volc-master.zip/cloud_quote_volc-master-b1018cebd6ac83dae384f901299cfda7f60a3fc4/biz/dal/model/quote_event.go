package model

import (
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// QuoteEvent 报价变更事件表
type QuoteEvent struct {
	framework.BaseDB
	QuoteID        int64
	QuoteSource    string
	DataID         int64
	EventTypes     string
	EventTimestamp time.Time
	Extra          string
}

type EventExtra struct {
	RequestID string `json:"RequestID,omitempty"`
	IsTest    bool   `json:"IsTest,omitempty"`
	MsgID     string `json:"MsgID,omitempty"`
}

func (m *QuoteEvent) TableName() string {
	return "quote_event"
}

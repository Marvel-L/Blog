package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// CommonApplyItem 通用申请条目 支持代金券申请、信控申请
type CommonApplyItem struct {
	framework.BaseDB
	QuoteID          int64
	ConfigID         int64
	BizKey           string
	CreatorAccountId string
}

func (m *CommonApplyItem) TableName() string {
	return "common_apply_item"
}

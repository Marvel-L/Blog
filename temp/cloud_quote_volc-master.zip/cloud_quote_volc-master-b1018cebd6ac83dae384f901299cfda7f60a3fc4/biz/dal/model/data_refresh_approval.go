package model

import (
	"encoding/json"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// DataRefreshApproval 刷数审批
type DataRefreshApproval struct {
	framework.BaseDB
	CreatorAccountID string
	QuoteID          int64
	ContractNo       string
	RefreshTaskIDs   string `gorm:"column:refresh_task_ids"`
	ApprovalStatus   string
}

func (m *DataRefreshApproval) TableName() string {
	return "data_refresh_approval"
}

type DataRefreshApprovalResp struct {
	DataRefreshApprovalID int64
	CreatedTime           string
	UpdatedTime           string
	CreatorAccountID      string
	QuoteID               int64
	ContractNo            string
	RefreshTaskIDs        string
	RefreshTaskIDList     []int64
	ApprovalStatus        string
}

func (m *DataRefreshApproval) GenResp() *DataRefreshApprovalResp {
	refreshTaskIDList := make([]int64, 0)
	if m.RefreshTaskIDs != "" {
		_ = json.Unmarshal([]byte(m.RefreshTaskIDs), &refreshTaskIDList)
	}
	return &DataRefreshApprovalResp{
		DataRefreshApprovalID: m.Id,
		CreatedTime:           util.FormatDateTimeWithZone(m.CreatedTime),
		UpdatedTime:           util.FormatDateTimeWithZone(m.UpdatedTime),
		CreatorAccountID:      m.CreatorAccountID,
		QuoteID:               m.QuoteID,
		ContractNo:            m.ContractNo,
		RefreshTaskIDs:        m.RefreshTaskIDs,
		RefreshTaskIDList:     refreshTaskIDList,
		ApprovalStatus:        m.ApprovalStatus,
	}
}

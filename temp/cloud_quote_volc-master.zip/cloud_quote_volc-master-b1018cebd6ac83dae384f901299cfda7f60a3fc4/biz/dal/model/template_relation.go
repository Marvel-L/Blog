package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// TemplateRelation 报价单模板关系表
type TemplateRelation struct {
	framework.BaseDB
	TemplateId       int64
	QuoteId          int64
	QuoteScene       multienv.QuoteScene
	CreatorAccountId string
}

func (m *TemplateRelation) TableName() string {
	return "template_relation"
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/shopspring/decimal"
)

// QuoteItemCouponRatio 报价项-代金券返券比例表
type QuoteItemCouponRatio struct {
	framework.BaseDB
	QuoteID        int64
	QuoteItemID    int64
	CouponConfigID int64
	CouponRatio    decimal.Decimal
	CouponAmount   decimal.Decimal
}

// TableName 指定表名
func (m *QuoteItemCouponRatio) TableName() string {
	return "quote_item_coupon_ratio"
}

// Clone 复制一份记录（清空主键），用于快照原样复制。
func (m *QuoteItemCouponRatio) Clone() *QuoteItemCouponRatio {
	raw := *m
	raw.Id = 0
	return &raw
}

type QuoteItemCouponRatioList []*QuoteItemCouponRatio

type QuoteItemCouponRatioInfo struct {
	QuoteItemID      int64
	CouponConfigID   int64
	ItemCouponAmount decimal.Decimal // 报价项返券金额
	ItemCouponRatio  decimal.Decimal // 报价项返券比例
}

func (m *QuoteItemCouponRatio) ToQuoteItemCouponRatioInfo() *QuoteItemCouponRatioInfo {
	return &QuoteItemCouponRatioInfo{
		QuoteItemID:      m.QuoteItemID,
		CouponConfigID:   m.CouponConfigID,
		ItemCouponAmount: m.CouponAmount,
		ItemCouponRatio:  m.CouponRatio,
	}
}

package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

//ChangeDiscountQuoteItem 变价报价单报价项表
type ChangeDiscountQuoteItem struct {
	framework.BaseDB
	CreatorAccountID      string
	QuoteID               int64
	QuoteTaskID           int64
	QuoteSubTaskID        int64
	TaskChargeItemID      int64
	TradeProduct          string
	TradeProductName      string
	ProductDepartmentName string
	SecondaryProductLine  string
	ActivationType        int
	PrePayTypeCode        string
	PrePayTypeName        string
	ConfigCategory        string
	ConfigCode            string
	ConfigName            string
	SellingMode           string
	ChargeItemTag         string
	ChargeMethodCode      string
	ChargeMethodName      string
	RegionCode            string
	RegionName            string
	ChargeUnitCode        string
	ChargeUnitName        string
	PriceFactorCode       string
	PriceFactorName       string
	ChargeItemCode        string
	Discount              string
	PriceInfoSnapshot     string
	PriceVersion          string
}

func (m *ChangeDiscountQuoteItem) TableName() string {
	return "change_discount_quote_item"
}

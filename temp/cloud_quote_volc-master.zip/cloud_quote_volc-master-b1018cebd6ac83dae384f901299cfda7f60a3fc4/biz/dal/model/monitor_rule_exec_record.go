package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

type MonitorRuleExecRecord struct {
	framework.BaseDB
	RuleID      int64  // 规则id
	QueryKey    string // 查询key
	ActionData  string // 操作数据
	ActionEmail string // 操作邮箱
}

func (r *MonitorRuleExecRecord) TableName() string {
	return "monitor_rule_exec_record"
}

// MonitorRuleExecRecordEmail 监控规则执行记录操作邮箱
type MonitorRuleExecRecordEmail struct {
	SendEmail  []string // 发送邮箱
	BlackEmail []string // 黑名单邮箱
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
)

type QuoteSolution struct {
	framework.BaseDB
	QuoteId                 int64
	StandardSolutionCode    string
	StandardSolutionName    string
	StandardSolutionVersion string
	TradeSolutionCode       string
	TradeSolution           string
	TradeSolutionName       string
	TradeSolutionVersion    string
	StandardDepartmentName  string
	CreatorAccountId        string
	TemplateSolutionId      int64
	QuoteTemplateId         int64
	SolutionCopyFrom        int64
	SolutionType            int //类型：1-解决方案，2-一体机套餐
	DeploymentType          string
	TradeSolutionType       string
}

func (m *QuoteSolution) TableName() string {
	return "quote_solution"
}

func (m *QuoteSolution) GetSolutionInfo() string {
	return i18nfmt.Sprintf(context.Background(), "产品解决方案: %s %s 商品解决方案套餐: %s %s", m.StandardSolutionName, m.StandardSolutionVersion, m.TradeSolutionName, m.TradeSolutionVersion)
}

func (m *QuoteSolution) Clone() *QuoteSolution {
	newSolution := *m
	newSolution.Id = 0
	return &newSolution
}

func (m *QuoteSolution) ItemNeedDiscountLine() bool {
	return m.Id == 0 ||
		m.DeploymentType == multienv.PublicDeploymentType ||
		m.SolutionType == constants.QuoteSolutionTypeIntegratedMachine
}
func (m *QuoteSolution) IsPrivateSolution() bool {
	return m.DeploymentType == multienv.PrivateDeploymentType &&
		m.SolutionType == constants.QuoteSolutionTypeDefaultSolution
}

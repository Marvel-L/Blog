package model

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/env"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logs"
)

type Quote struct {
	framework.BaseDB
	Code                          string                // 该字段目前处于废弃状态，并非【报价单编码含义】
	OpportunityID                 multienv.OppNumber    // 商机
	CustomerDetail                string                // 配价火山账号ID
	SalesAccountID                string                // 销售
	SolutionConsultantID          string                // 产解行解
	CreatorAccountID              string                // 创建人
	QuoteStatus                   constants.QuoteStatus // 报价单状态
	Content                       string                //
	DeliveryForm                  string                //
	TotalSales                    decimal.Decimal       //
	IncomeNoTax                   decimal.Decimal       //
	Vat                           decimal.Decimal       //
	Cost                          decimal.Decimal       //
	GrossMarginRate               decimal.Decimal       //
	ProfitMarginRate              decimal.Decimal       //
	QuoteEstimateBySales          decimal.Decimal       //
	EstimatedTradingMonthlyIncome decimal.Decimal       // 预估上量月收入
	TradeType                     multienv.TradeType    // 客户类型
	OrderType                     string                // 签约方式-产品和服务协议（合同纸质签约）
	QuoteValidPeriod              int                   //
	PriceValidPeriodStartTime     time.Time             // 预估合同有效期-开始
	PriceValidPeriodEndTime       time.Time             // 预估合同有效期-结束
	QuoteNotes                    string                //
	AppAccountID                  string                //
	ExpiredTime                   time.Time             //
	MainQuoteID                   int64                 //
	ParentQuoteID                 int64                 // 补充协议报价单的父级报价单
	QuoteNo                       string                // 报价单编码
	QuoteScene                    multienv.QuoteScene   //
	QuoteUpdated                  int                   //
	QuoteCopyFrom                 int64                 //
	PriceValidPeriod              string                //
	CustomerName                  string                // 最终客户
	PartnerName                   string                // 关联伙伴名称
	PartnerContractNo             string                //
	QuoteRelatedProduct           string                //
	LongLifeReason                string                //
	ProjectName                   string                //
	ProjectCode                   string                //
	EffectiveType                 int                   //
	VerifiedName                  string                //
	ProjectAttribute              int                   //
	CustomerInfoSnapshot          string                //
	StatementOfWork               string                //
	ProjectBased                  int                   //
	QuoteCreateFrom               int64                 //
	ProjectProfitCalculate        string                //
	QuoteName                     string                //
	SalesDepartment               string                // 销售所属行业,单选
	SolutionDepartment            string                // 解决方案所属行业,单选
	RelatedResDepartment          string                // 涉及资源方,多选
	ProjectAttributes             string                //
	QuoteType                     int                   // 报价类型：0-普通报价，1-项目制报价，2-阶梯报价
	ProgressiveInfo               string                // 阶梯信息
	GiveAwayScene                 string                // 赠送场景：无条件赠送
	GiveAwayReason                string                // 赠送原因
	BackdatingContractNo          string                // [开始日早于提单日]关联合同号
	BackdatingReason              string                // [开始日早于提单日]原因
	ModifyStatus                  int                   // 审批修改状态：0-无修改，1-修改中
	ModifyStartTime               time.Time             // 发起修改时间
	ModifyContext                 string                // 修改上下文
	ChangeInfo                    string                // 报价单变更-变更内容
	OriginQuoteID                 int64                 // 报价单变更直接父级/上一版报价单ID
	CreditRiskInfo                string                // 信控风险评估信息
	MdInfo                        string                // 主数据信息
	EstimatedTradingTime          time.Time             // 预估上量时间
	ConsumptionRatio              string                // 消费结构
	FactoryPriceProfitCalculate   string                // 出厂价利润率测算汇总
	LatestResourceProfitCalculate string                // 最新资源价利润率测算汇总
	ProductLineProfitCalculate    string                // 折扣线利润率测算
	UnapprovedProductLines        string                // 未立项一级二级产品线
	SupplyScene                   string                // 补充协议场景, 1-报价单变更 2-合同有效期变更 3-合同条款变更
	TradeTypeCode                 int                   // 客户类型:1-直签,2-生态-代销,3-生态-代售,4-生态-分销,5-EPS内部客户,6-字节内部客户
	OrderTypeCode                 int                   // 签约方式:1-产品和服务协议（官网自助下单）,2-产品和服务协议（合同纸质签约）
	ProjectApprovalInstanceID     string                // 项目立项审批实例ID
	ProjectApprovalLink           string                // 项目立项审批流url
	ApprovalStartTime             time.Time             // 审批创建时间
	ApprovalEndTime               time.Time             // 审批结束时间
	MainConfigID                  int64                 // 主配置清单编码
	ParentConfigID                int64                 // 父配置清单编码
	ProjectProfitChanged          string                // 单位目标成本利润率测算变更
	FactoryPriceProfitChanged     string                // 出厂价利润率测算变更
	LatestResourceProfitChanged   string                // 最新资源价利润率测算变更
	ProductLineProfitChanged      string                // 产品线利润率测算变更
	SubTaskID                     int64                 // 子变价任务id
	TaskID                        int64                 // 报价任务id
	GrayScale                     int                   // 灰度类型:0-非灰度,1-商机二期灰度
	DistributionBizTypeCode       int                   // 分销业务类型code
	DistributorInfos              string                // 分销商信息
	ContractEntity                string                // 签约主体
	ContractAccount               string                // 签约火山账号ID
	ContractPriceEntity           string                // 配价主体
	CustomerAccount               string                // 最终客户火山账号ID
	JointPrintOrder               string                // 联合打单信息
	CustomerIndustryInfo          string                // 客户行业信息
	PriceEntityIndustryInfo       string                // 配价主体行业线信息
	PublicCloudEstimate           decimal.Decimal       // 销售预估金额-公有云标品
	SalesChannelType              string                // 销售渠道类型：direct-直销，channel_telemarketing-渠道/电销
	ParentAccountNumber           string                // 最终客户父级客户编号
	QuantityPriceDetail           string                // 量价详情
	ContractPriceAcc              string                // 配价主体客户编号
	EffectiveTime                 time.Time             // 报价单生效时间
	OriginSnapshotID              int64                 // 审批中修改版本链首次快照ID；0表示未形成版本链或当前记录为首次快照
	ParentSnapshotID              int64                 // 上一版本快照单ID；原单上表示最新快照ID，0表示无上一版本
	SnapshotFrom                  int64                 // 快照所属报价单ID（快照单指向原单ID；原单该字段为0）
	RootQuoteID                   int64                 // 变更链根报价单ID；原始报价单/链路最初的新签或补协单
}

type QuoteResp struct {
	ID                            int64
	Code                          string
	OpportunityID                 multienv.OppNumber
	CustomerDetail                string
	SalesAccountID                string
	SolutionConsultantID          string
	CreatorAccountID              string
	AppAccountID                  string
	QuoteStatus                   constants.QuoteStatus
	Content                       string
	DeliveryForm                  []string
	TotalSales                    decimal.Decimal
	IncomeNoTax                   decimal.Decimal
	Vat                           decimal.Decimal
	Cost                          decimal.Decimal
	GrossMarginRate               decimal.Decimal
	ProfitMarginRate              decimal.Decimal
	CreatedTime                   string
	UpdatedTime                   string
	CreatedTimeStr                string
	UpdatedTimeStr                string
	TradeType                     multienv.TradeType
	OrderType                     string
	QuoteValidPeriod              int
	PriceValidPeriodStartTime     string
	PriceValidPeriodEndTime       string
	PriceValidPeriodStartTimeStr  string
	PriceValidPeriodEndTimeStr    string
	QuoteEstimateBySales          decimal.Decimal
	EstimatedTradingMonthlyIncome decimal.Decimal // 预估上量月收入
	QuoteNotes                    string
	ExpiredTime                   time.Time
	MainQuoteID                   int64
	ParentQuoteID                 int64
	ParentConfigID                int64
	QuoteNo                       string
	QuoteScene                    multienv.QuoteScene
	PriceValidPeriod              string
	CustomerName                  string
	PartnerName                   string
	PartnerContractNo             string
	QuoteRelatedProduct           string
	LongLifeReason                string
	ProjectName                   string
	ProjectCode                   string
	BizSource                     string
	EffectiveType                 int
	VerifiedName                  string
	ProjectAttribute              int
	ProjectAttributes             string
	ProjectAttributeStr           string
	CustomerInfoSnapshot          string
	StatementOfWork               string
	ProjectBased                  int
	QuoteCreateFrom               int64
	ProjectProfitCalculate        string
	QuoteName                     string
	QuoteCopyFrom                 int64
	SalesDepartment               string           // 销售所属行业,单选
	SolutionDepartment            string           // 解决方案所属行业,单选
	RelatedResDepartment          string           // 涉及资源方,多选
	QuoteType                     int              // 报价类型：0-普通报价，1-项目制报价，2-阶梯报价
	ProgressiveInfo               string           // 阶梯信息
	GiveAwayScene                 string           // 赠送场景：无条件赠送
	GiveAwayReason                string           // 赠送原因
	BackdatingContractNo          string           // [开始日早于提单日]关联合同号
	BackdatingReason              string           // [开始日早于提单日]原因
	ModifyStatus                  int              // 审批修改状态：0-无修改，1-修改中
	ChangeInfo                    string           // 报价单变更——变更内容
	OriginQuoteID                 int64            // 变更报价单直接父级/上一版报价单ID
	MdInfo                        string           // 主数据信息
	EstimatedTradingTime          time.Time        // 预估上量时间
	UnapprovedProductLines        string           // 未立项一级二级产品线
	SupplyScene                   string           // 补充协议场景, 1-报价单变更 2-合同有效期变更 3-合同条款变更
	TradeTypeCode                 int              //客户类型:1-直签,2-生态-代销,3-生态-代售,4-生态-分销,5-EPS内部客户,6-字节内部客户
	OrderTypeCode                 int              //签约方式:1-产品和服务协议（官网自助下单）,2-产品和服务协议（合同纸质签约）
	ProjectApprovalInstanceID     string           // 项目立项审批实例ID
	ProjectApprovalLink           string           // 项目立项审批流URL
	ApprovalStartTime             time.Time        // 审批创建时间
	ApprovalEndTime               time.Time        // 审批结束时间
	SubTaskID                     int64            // 子变价任务id
	TaskID                        int64            // 报价任务id
	GrayScale                     int              // 灰度类型:0-非灰度,1-商机二期灰度
	DistributionBizTypeCode       int              // 分销业务类型code
	DistributorInfos              *DistributorInfo // 分销商信息
	ContractEntity                string           // 合同主体
	ContractAccount               string           // 签约火山账号ID
	ContractPriceEntity           string           // 配价主体
	CustomerAccount               string           // 最终客户火山账号ID
	JointPrintOrder               string           // 联合打单信息
	CustomerIndustryInfo          string           // 客户行业信息
	PriceEntityIndustryInfo       string           // 配价主体行业线信息
	PublicCloudEstimate           decimal.Decimal  // 销售预估金额-公有云标品
	SalesChannelType              string           // 销售渠道类型：direct-直销，channel_telemarketing-渠道/电销
	EffectiveTime                 string           // 报价单生效时间
	RootQuoteID                   int64            // 变更链根报价单ID（原始报价单）
	OriginSnapshotID              int64            // 审批中修改版本链首次快照ID；0表示未形成版本链或当前记录为首次快照
	ParentSnapshotID              int64            // 上一版本快照单ID；原单上表示最新快照ID，0表示无上一版本
	SnapshotFrom                  int64            // 快照所属报价单ID（快照单指向原单ID；原单该字段为0）
}

type QuoteRespSimpleInfo struct {
	ID                            int64
	Code                          string
	OpportunityID                 multienv.OppNumber
	CustomerDetail                string
	SalesAccountID                string
	SolutionConsultantID          string
	CreatorAccountID              string
	AppAccountID                  string
	QuoteStatus                   constants.QuoteStatus
	Content                       string
	DeliveryForm                  []string
	TotalSales                    decimal.Decimal
	IncomeNoTax                   decimal.Decimal
	Vat                           decimal.Decimal
	Cost                          decimal.Decimal
	GrossMarginRate               decimal.Decimal
	ProfitMarginRate              decimal.Decimal
	CreatedTime                   time.Time
	UpdatedTime                   time.Time
	TradeType                     multienv.TradeType
	OrderType                     string
	QuoteValidPeriod              int
	PriceValidPeriodStartTime     time.Time
	PriceValidPeriodEndTime       time.Time
	QuoteEstimateBySales          decimal.Decimal
	EstimatedTradingMonthlyIncome decimal.Decimal
	QuoteNotes                    string
	MainQuoteID                   int64
	ParentQuoteID                 int64
	QuoteNo                       string
	QuoteScene                    multienv.QuoteScene
	PriceValidPeriod              string
	CustomerName                  string
	PartnerName                   string
	PartnerContractNo             string
	QuoteRelatedProduct           string
	LongLifeReason                string
	ProjectName                   string
	ProjectCode                   string
	BizSource                     string
	EffectiveType                 int
	ProjectAttribute              int
	ProjectAttributes             string
	ProjectAttributeStr           string
	VerifiedName                  string
	StatementOfWork               string
	ProjectBased                  int
	QuoteCreateFrom               int64
	ProjectProfitCalculate        string
	QuoteName                     string
	QuoteCopyFrom                 int64
	SalesDepartment               string           // 销售所属行业,单选
	SolutionDepartment            string           // 解决方案所属行业,单选
	RelatedResDepartment          string           // 涉及资源方,多选
	QuoteType                     int              // 报价类型：0-普通报价，1-项目制报价，2-阶梯报价
	ProgressiveInfo               string           // 阶梯信息
	GiveAwayScene                 string           // 赠送场景：无条件赠送
	GiveAwayReason                string           // 赠送原因
	BusinessDiscounts             string           // 商务优惠，多选：保底、信控、赠送、返佣、代金券
	BackdatingContractNo          string           // [开始日早于提单日]关联合同号
	BackdatingReason              string           // [开始日早于提单日]原因
	ModifyStatus                  int              // 审批修改状态：0-无修改，1-修改中
	ChangeInfo                    string           // 报价单变更——变更内容
	OriginQuoteID                 int64            // 变更报价单直接父级/上一版报价单ID
	MdInfo                        string           // 主数据信息
	UnapprovedProductLines        string           // 未立项一级二级产品线
	SupplyScene                   string           // 补充协议场景, 1-报价单变更 2-合同有效期变更 3-合同条款变更
	TradeTypeCode                 int              //客户类型:1-直签,2-生态-代销,3-生态-代售,4-生态-分销,5-EPS内部客户,6-字节内部客户
	OrderTypeCode                 int              //签约方式:1-产品和服务协议（官网自助下单）,2-产品和服务协议（合同纸质签约）
	ProjectApprovalInstanceID     string           // 项目立项审批实例ID
	ProjectApprovalLink           string           // 项目立项审批流URL
	ApprovalStartTime             time.Time        // 审批创建时间
	ApprovalEndTime               time.Time        // 审批结束时间
	GrayScale                     int              // 灰度类型:0-非灰度,1-商机二期灰度
	DistributionBizTypeCode       int              // 分销业务类型code
	DistributorInfos              *DistributorInfo // 分销商信息
	ContractEntity                string           // 合同主体
	ContractAccount               string           // 签约火山账号ID
	ContractPriceEntity           string           // 配价主体
	CustomerAccount               string           // 最终客户火山账号ID
	CustomerIndustryInfo          string           // 客户行业信息
	PriceEntityIndustryInfo       string           // 配价主体行业线信息
	PublicCloudEstimate           decimal.Decimal  // 销售预估金额-公有云标品
	SalesChannelType              string           // 销售渠道类型：direct-直销，channel_telemarketing-渠道/电销
	RootQuoteID                   int64            // 变更链根报价单ID（原始报价单）
}

type QuoteModifyContext struct {
	ModifyRemark        string `json:"ModifyRemark"`        // 修改审批建议
	Promoter            string `json:"Promoter"`            // 发起人邮箱 一般为超管
	DiscountSnapshot    string `json:"DiscountSnapshot"`    // 发起时 商务优惠快照
	QuoteCategoryBefore string `json:"QuoteCategoryBefore"` // 驳回前折扣范围
}

// DistributorInfo 分销商信息
type DistributorInfo struct {
	FirstDistributor  *CustomerInfo // 1级分销商
	SecondDistributor *CustomerInfo // 2级分销商
	FinalCustomer     *CustomerInfo // 最终客户
}

// CustomerInfo 客户信息
type CustomerInfo struct {
	CustomerType string // 客户类型，FirstDistributor=1级分销商，SecondDistributor=2级分销商，FinalCustomer=最终客户
	AccountID    string
	OwnerID      string
	CustomerName string
}

type JointPrintOrder struct {
	OpportunitySrcKey   string `json:"OpportunitySrcKey"`   // 商机来源key
	Support             bool   `json:"Support"`             // 是否支持联合打单
	PrintSceneDec       string `json:"PrintSceneDec"`       // 联打场景
	PrintSceneOppRole   string `json:"PrintSceneOppRole"`   // 联打场景:联打发起角色
	PrintSceneJointRole string `json:"PrintSceneJointRole"` // 联打场景:联打协作角色
	CustomerOwnerRole   string `json:"CustomerOwnerRole"`   // 客户所有人角色
	Collaborator        string `json:"Collaborator"`        // 联合打单协作人
	PolicyName          string `json:"PolicyName"`          // 政策名称
	PolicyLink          string `json:"PolicyLink"`          // 政策链接
	ChangeSupport       bool   `json:"ChangeSupport"`       // Support变更
}

type CustomerIndustryInfo struct {
	IndustryKey    string `json:"IndustryKey"`    // 客户一级行业key
	IndustryDec    string `json:"IndustryDec"`    // 客户一级行业名称
	SubIndustryKey string `json:"SubIndustryKey"` // 客户二级行业key
	SubIndustryDec string `json:"SubIndustryDec"` // 客户二级行业名称
}

func (q *Quote) TableName() string {
	return "quote"
}

func (q *Quote) GenResp(c context.Context) *QuoteResp {
	sourceMap := config.GetSourceMap(c)
	bizSource := multienv.GetDefaultBizSource()
	source, ok := sourceMap[q.AppAccountID]
	if ok {
		bizSource = source
	}
	enumConfig := config.GetEnumConfig(c, constants.EnumKeyProjectAttribute)
	projectAttributeArr := strings.Split(q.ProjectAttributes, ",")
	var projectAttributeStrArr []string
	for _, projectAttribute := range projectAttributeArr {
		if s, enumOk := enumConfig[projectAttribute]; enumOk {
			projectAttributeStrArr = append(projectAttributeStrArr, s)
		}
	}

	distributorInfos := &DistributorInfo{}
	_ = json.Unmarshal([]byte(q.DistributorInfos), distributorInfos)

	return &QuoteResp{
		ID:                            q.Id,
		Code:                          q.Code,
		OpportunityID:                 q.OpportunityID,
		CustomerDetail:                q.CustomerDetail,
		SalesAccountID:                q.SalesAccountID,
		SolutionConsultantID:          q.SolutionConsultantID,
		CreatorAccountID:              q.CreatorAccountID,
		AppAccountID:                  q.AppAccountID,
		QuoteStatus:                   q.QuoteStatus,
		Content:                       q.Content,
		TotalSales:                    q.TotalSales,
		IncomeNoTax:                   q.IncomeNoTax,
		Vat:                           q.Vat,
		Cost:                          q.Cost,
		GrossMarginRate:               q.GrossMarginRate,
		ProfitMarginRate:              q.ProfitMarginRate,
		CreatedTime:                   util.FormatDateTimeWithZone(q.CreatedTime),
		UpdatedTime:                   util.FormatDateTimeWithZone(q.UpdatedTime),
		CreatedTimeStr:                util.FormatDateTimeWithZone(q.CreatedTime),
		UpdatedTimeStr:                util.FormatDateTimeWithZone(q.UpdatedTime),
		TradeType:                     q.TradeType,
		OrderType:                     q.OrderType,
		QuoteValidPeriod:              q.QuoteValidPeriod,
		PriceValidPeriodStartTime:     util.FormatDateTimeWithZone(q.PriceValidPeriodStartTime),
		PriceValidPeriodEndTime:       util.FormatDateTimeWithZone(q.PriceValidPeriodEndTime),
		PriceValidPeriodStartTimeStr:  util.FormatDateTimeWithZone(q.PriceValidPeriodStartTime),
		PriceValidPeriodEndTimeStr:    util.FormatDateTimeWithZone(q.PriceValidPeriodEndTime),
		QuoteEstimateBySales:          q.QuoteEstimateBySales,
		EstimatedTradingMonthlyIncome: q.EstimatedTradingMonthlyIncome,
		QuoteNotes:                    q.QuoteNotes,
		ExpiredTime:                   q.ExpiredTime,
		MainQuoteID:                   q.MainQuoteID,
		ParentQuoteID:                 q.ParentQuoteID,
		ParentConfigID:                q.ParentConfigID,
		QuoteNo:                       q.QuoteNo,
		QuoteScene:                    q.QuoteScene,
		PriceValidPeriod:              q.PriceValidPeriod,
		CustomerName:                  q.CustomerName,
		PartnerName:                   q.PartnerName,
		PartnerContractNo:             q.PartnerContractNo,
		QuoteRelatedProduct:           q.QuoteRelatedProduct,
		LongLifeReason:                q.LongLifeReason,
		ProjectName:                   q.ProjectName,
		ProjectCode:                   q.ProjectCode,
		BizSource:                     bizSource,
		EffectiveType:                 q.EffectiveType,
		VerifiedName:                  q.VerifiedName,
		ProjectAttribute:              q.ProjectAttribute,
		ProjectAttributes:             q.ProjectAttributes,
		ProjectAttributeStr:           strings.Join(projectAttributeStrArr, "、"),
		CustomerInfoSnapshot:          q.CustomerInfoSnapshot,
		StatementOfWork:               q.StatementOfWork,
		ProjectBased:                  q.ProjectBased,
		QuoteCreateFrom:               q.QuoteCreateFrom,
		QuoteName:                     q.QuoteName,
		QuoteCopyFrom:                 q.QuoteCopyFrom,
		SalesDepartment:               q.SalesDepartment,
		SolutionDepartment:            q.SolutionDepartment,
		RelatedResDepartment:          q.RelatedResDepartment,
		QuoteType:                     q.QuoteType,
		ProgressiveInfo:               q.ProgressiveInfo,
		GiveAwayScene:                 q.GiveAwayScene,
		GiveAwayReason:                q.GiveAwayReason,
		BackdatingContractNo:          q.BackdatingContractNo,
		BackdatingReason:              q.BackdatingReason,
		ModifyStatus:                  q.ModifyStatus,
		ChangeInfo:                    q.ChangeInfo,
		OriginQuoteID:                 q.OriginQuoteID,
		MdInfo:                        q.MdInfo,
		EstimatedTradingTime:          q.EstimatedTradingTime,
		UnapprovedProductLines:        q.UnapprovedProductLines,
		SupplyScene:                   q.SupplyScene,
		TradeTypeCode:                 q.TradeTypeCode,
		OrderTypeCode:                 q.OrderTypeCode,
		ProjectApprovalInstanceID:     q.ProjectApprovalInstanceID,
		ProjectApprovalLink:           q.ProjectApprovalLink,
		ApprovalStartTime:             q.ApprovalStartTime,
		ApprovalEndTime:               q.ApprovalEndTime,
		SubTaskID:                     q.SubTaskID,
		TaskID:                        q.TaskID,
		GrayScale:                     q.GrayScale,
		DistributionBizTypeCode:       q.DistributionBizTypeCode,
		DistributorInfos:              distributorInfos,
		ContractEntity:                q.ContractEntity,
		ContractAccount:               q.ContractAccount,
		ContractPriceEntity:           q.ContractPriceEntity,
		CustomerAccount:               q.CustomerAccount,
		JointPrintOrder:               q.JointPrintOrder,
		CustomerIndustryInfo:          q.CustomerIndustryInfo,
		PriceEntityIndustryInfo:       q.PriceEntityIndustryInfo,
		PublicCloudEstimate:           q.PublicCloudEstimate,
		SalesChannelType:              q.SalesChannelType,
		EffectiveTime:                 util.FormatDateTimeWithZone(q.EffectiveTime),
		RootQuoteID:                   q.RootQuoteID,
		OriginSnapshotID:              q.OriginSnapshotID,
		ParentSnapshotID:              q.ParentSnapshotID,
		SnapshotFrom:                  q.SnapshotFrom,
	}
}
func (q *Quote) GenRespV2(c context.Context) *QuoteRespSimpleInfo {
	sourceMap := config.GetSourceMap(c)
	bizSource := multienv.GetDefaultBizSource()
	source, ok := sourceMap[q.AppAccountID]
	if ok {
		bizSource = source
	}
	enumConfig := config.GetEnumConfig(c, constants.EnumKeyProjectAttribute)
	projectAttributeArr := strings.Split(q.ProjectAttributes, ",")
	var projectAttributeStrArr []string
	for _, projectAttribute := range projectAttributeArr {
		if s, enumOk := enumConfig[projectAttribute]; enumOk {
			projectAttributeStrArr = append(projectAttributeStrArr, s)
		}
	}

	distributorInfos := &DistributorInfo{}
	_ = json.Unmarshal([]byte(q.DistributorInfos), distributorInfos)

	return &QuoteRespSimpleInfo{
		ID:                            q.Id,
		Code:                          q.Code,
		OpportunityID:                 q.OpportunityID,
		CustomerDetail:                q.CustomerDetail,
		SalesAccountID:                q.SalesAccountID,
		SolutionConsultantID:          q.SolutionConsultantID,
		CreatorAccountID:              q.CreatorAccountID,
		AppAccountID:                  q.AppAccountID,
		QuoteStatus:                   q.QuoteStatus,
		Content:                       q.Content,
		TotalSales:                    q.TotalSales,
		IncomeNoTax:                   q.IncomeNoTax,
		Vat:                           q.Vat,
		Cost:                          q.Cost,
		GrossMarginRate:               q.GrossMarginRate,
		ProfitMarginRate:              q.ProfitMarginRate,
		CreatedTime:                   q.CreatedTime,
		UpdatedTime:                   q.UpdatedTime,
		TradeType:                     q.TradeType,
		OrderType:                     q.OrderType,
		QuoteValidPeriod:              q.QuoteValidPeriod,
		PriceValidPeriodStartTime:     q.PriceValidPeriodStartTime,
		PriceValidPeriodEndTime:       q.PriceValidPeriodEndTime,
		QuoteEstimateBySales:          q.QuoteEstimateBySales,
		EstimatedTradingMonthlyIncome: q.EstimatedTradingMonthlyIncome,
		QuoteNotes:                    q.QuoteNotes,
		MainQuoteID:                   q.MainQuoteID,
		ParentQuoteID:                 q.ParentQuoteID,
		QuoteNo:                       q.QuoteNo,
		QuoteScene:                    q.QuoteScene,
		PriceValidPeriod:              q.PriceValidPeriod,
		CustomerName:                  q.CustomerName,
		PartnerName:                   q.PartnerName,
		PartnerContractNo:             q.PartnerContractNo,
		QuoteRelatedProduct:           q.QuoteRelatedProduct,
		LongLifeReason:                q.LongLifeReason,
		ProjectName:                   q.ProjectName,
		ProjectCode:                   q.ProjectCode,
		BizSource:                     bizSource,
		EffectiveType:                 q.EffectiveType,
		ProjectAttribute:              q.ProjectAttribute,
		ProjectAttributes:             q.ProjectAttributes,
		ProjectAttributeStr:           strings.Join(projectAttributeStrArr, "、"),
		VerifiedName:                  q.VerifiedName,
		StatementOfWork:               q.StatementOfWork,
		ProjectBased:                  q.ProjectBased,
		QuoteCreateFrom:               q.QuoteCreateFrom,
		ProjectProfitCalculate:        q.ProjectProfitCalculate,
		QuoteName:                     q.QuoteName,
		QuoteCopyFrom:                 q.QuoteCopyFrom,
		SalesDepartment:               q.SalesDepartment,
		SolutionDepartment:            q.SolutionDepartment,
		RelatedResDepartment:          q.RelatedResDepartment,
		QuoteType:                     q.QuoteType,
		ProgressiveInfo:               q.ProgressiveInfo,
		GiveAwayScene:                 q.GiveAwayScene,
		GiveAwayReason:                q.GiveAwayReason,
		BackdatingContractNo:          q.BackdatingContractNo,
		BackdatingReason:              q.BackdatingReason,
		ModifyStatus:                  q.ModifyStatus,
		ChangeInfo:                    q.ChangeInfo,
		OriginQuoteID:                 q.OriginQuoteID,
		MdInfo:                        q.MdInfo,
		UnapprovedProductLines:        q.UnapprovedProductLines,
		SupplyScene:                   q.SupplyScene,
		TradeTypeCode:                 q.TradeTypeCode,
		OrderTypeCode:                 q.OrderTypeCode,
		ProjectApprovalInstanceID:     q.ProjectApprovalInstanceID,
		ProjectApprovalLink:           q.ProjectApprovalLink,
		ApprovalStartTime:             q.ApprovalStartTime,
		ApprovalEndTime:               q.ApprovalEndTime,
		GrayScale:                     q.GrayScale,
		DistributionBizTypeCode:       q.DistributionBizTypeCode,
		DistributorInfos:              distributorInfos,
		ContractEntity:                q.ContractEntity,
		ContractAccount:               q.ContractAccount,
		ContractPriceEntity:           q.ContractPriceEntity,
		CustomerAccount:               q.CustomerAccount,
		CustomerIndustryInfo:          q.CustomerIndustryInfo,
		PriceEntityIndustryInfo:       q.PriceEntityIndustryInfo,
		PublicCloudEstimate:           q.PublicCloudEstimate,
		SalesChannelType:              q.SalesChannelType,
		RootQuoteID:                   q.RootQuoteID,
	}
}

func (q *Quote) Expired() bool {
	nowTime := time.Now()
	return q.ExpiredTime.Before(nowTime)
}

func (q *Quote) Passed() bool {
	return q.QuoteStatus == constants.StatusPass
}

func (q *Quote) GetProductTypeMap(c context.Context) (map[constants.ProductType]interface{}, error) {
	var productTypeArr []constants.ProductType
	if q.QuoteRelatedProduct == "" {
		productTypeArr = []constants.ProductType{multienv.TradeProductTypeOnline}
	} else {
		err := json.Unmarshal([]byte(q.QuoteRelatedProduct), &productTypeArr)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(c, "报价单涉及商品类型错误 %s err : %s", q.QuoteRelatedProduct, err.Error()))
		}
		if len(productTypeArr) == 0 {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(c, "报价单涉及商品类型错误 %s", q.QuoteRelatedProduct))
		}
	}
	productTypeMap := map[constants.ProductType]interface{}{}
	for _, productType := range productTypeArr {
		productTypeMap[productType] = struct{}{}
	}
	return productTypeMap, nil
}

func (q *Quote) NeedContractRepeatCheck(c context.Context) (bool, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return false, err
	}
	_, containsOnline := productTypeMap[multienv.TradeProductTypeOnline]
	_, containsSolution := productTypeMap[multienv.TradeProductTypeSolution]
	_, containsIntegratedMachine := productTypeMap[multienv.TradeProductTypeIntegratedMachine]
	return containsOnline || containsSolution || containsIntegratedMachine, nil

}

func (q *Quote) GetProductTypeArrayForOA(c context.Context) ([]string, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return nil, err
	}

	var ret []string

	for t := range productTypeMap {
		ret = append(ret, multienv.GetTradeProductTypeNameMapping()[t])
	}

	return ret, nil
}
func (q *Quote) GetProjectInfo() string {
	if q.NeedProjectInfo() {
		return fmt.Sprintf("%s(%s)", q.ProjectName, q.ProjectCode)
	} else {
		return ""
	}

}

func (q *Quote) GetProductType(c context.Context) ([]int, error) {
	var productTypeArr []int
	if q.QuoteRelatedProduct == "" {
		productTypeArr = []int{int(multienv.TradeProductTypeOnline)}
	} else {
		err := json.Unmarshal([]byte(q.QuoteRelatedProduct), &productTypeArr)
		if err != nil {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(c, "报价单涉及商品类型错误 %s err : %s", q.QuoteRelatedProduct, err.Error()))
		}
		if len(productTypeArr) == 0 {
			return nil, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(c, "报价单涉及商品类型错误 %s", q.QuoteRelatedProduct))
		}
	}

	return productTypeArr, nil
}

func (q *Quote) InnerQuote(c context.Context) bool {
	return q.OpportunityID.IsVirtualOppNumbers() && q.TradeType.InnerCustomer()
}

func (q *Quote) FixedContractEffectiveTime(c context.Context) bool {
	return q.PriceValidPeriod == ""
}

func (q *Quote) SupportGuarantee(c context.Context) (bool, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return false, err
	}
	var support bool
	supportGuaranteeScene := q.QuoteScene.GeneralizedQuoteScene() || q.IsSupplyAgreement()
	support = q.FixedContractEffectiveTime(c) && //预估合同有效期：固定日期生效
		(q.AppAccountID == config.GetOpenApiAppKeyCrm(c) || q.AppAccountID == constants.OpenApiAppKeyQuote) && // 报价单来源：crm、报价平台
		productTypeMap[multienv.TradeProductTypeOnline] != nil && // 含公有云商品的混合云报价可进入保底流程，参与范围由后续规则校验限定
		supportGuaranteeScene &&
		q.QuoteType != multienv.QuoteTypeProgressive &&
		multienv.SupportGuaranteeTradeTypeCodeMap[q.TradeTypeCode]
	return support, nil
}

func (q *Quote) SupportRebate(c context.Context) (bool, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return false, err
	}
	support := !env.IsBytePlus() &&
		(q.AppAccountID == config.GetOpenApiAppKeyCrm(c) || q.AppAccountID == constants.OpenApiAppKeyQuote) &&
		productTypeMap[multienv.TradeProductTypeOnline] != nil && //报价单涉及商品勾选了公有云
		(q.TradeType == multienv.GetCustomerTypeEcoAgent() || q.TradeType == multienv.GetCustomerTypeEcoSell()) &&
		q.QuoteType != multienv.QuoteTypeProgressive
	return support, nil
}

// ParseJointPrintOrder 解析联打信息
func (q *Quote) ParseJointPrintOrder() *JointPrintOrder {
	if q.JointPrintOrder == "" {
		return nil
	}
	jointPrintOrder := &JointPrintOrder{}
	_ = json.Unmarshal([]byte(q.JointPrintOrder), jointPrintOrder)
	return jointPrintOrder
}

func (q *Quote) ParseCustomerIndustryInfo() *CustomerIndustryInfo {
	if q.CustomerIndustryInfo == "" {
		return nil
	}
	customerIndustryInfo := &CustomerIndustryInfo{}
	_ = json.Unmarshal([]byte(q.CustomerIndustryInfo), customerIndustryInfo)
	return customerIndustryInfo
}

func (q *Quote) SupportCoupon(c context.Context) (bool, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return false, err
	}

	isCRMOrQuote := q.AppAccountID == config.GetOpenApiAppKeyCrm(c) || q.AppAccountID == constants.OpenApiAppKeyQuote //
	containsOnline := productTypeMap[multienv.TradeProductTypeOnline] != nil                                          //报价单涉及商品勾选了公有云
	isGeneralizedQuoteSceneOrSupplyAgreement := q.QuoteScene.GeneralizedQuoteScene() || q.IsSupplyAgreement()         // 普通报价或补充协议
	isProgressive := q.QuoteType == multienv.QuoteTypeProgressive

	support := isCRMOrQuote && containsOnline &&
		isGeneralizedQuoteSceneOrSupplyAgreement && !isProgressive

	return support, nil
}

func (q *Quote) SupportCredit(c context.Context) (bool, error) {
	productTypeMap, err := q.GetProductTypeMap(c)
	if err != nil {
		return false, err
	}

	isCRMOrQuote := q.AppAccountID == config.GetOpenApiAppKeyCrm(c) || q.AppAccountID == constants.OpenApiAppKeyQuote //
	containsOnline := productTypeMap[multienv.TradeProductTypeOnline] != nil                                          //报价单涉及商品勾选了公有云
	isGeneralizedQuoteScene := q.QuoteScene.GeneralizedQuoteScene()                                                   // 普通报价
	support := isCRMOrQuote && containsOnline && isGeneralizedQuoteScene &&
		!q.TradeType.InnerCustomer() &&
		q.CustomerDetail != ""
	return support, nil
}

// SupportResourcePage 是否支持填写资源单
func (q *Quote) SupportResourcePage(c context.Context) bool {
	return q.IsQuote() && !q.TradeType.InnerCustomer()
}

// SupportResourcePageQuery 是否支持查询报价资源单列表
func (q *Quote) SupportResourcePageQuery(c context.Context) bool {
	return q.QuoteStatus == constants.StatusPass ||
		q.QuoteStatus == constants.StatusToBeEffective ||
		q.QuoteStatus == constants.StatusEffective
}

// IsProjectBased 项目制报价
func (q *Quote) IsProjectBased() bool {
	return q.QuoteType == multienv.QuoteTypeProjectBased
}

// SupportProfitCalculate 是否支持利润测算。
func (q *Quote) SupportProfitCalculate(ctx context.Context) bool {
	if q == nil {
		return false
	}
	return true
}

func (q *Quote) SupportProject() bool {
	return q.IsConfigList() || q.IsProjectBased()
}

// IsPublicCommon 公有云报价
func (q *Quote) IsPublicCommon() bool {
	return (q.QuoteScene == multienv.SceneNew ||
		q.QuoteScene == multienv.SceneChangeQuote ||
		q.QuoteScene == multienv.SceneSupplyAgreement ||
		q.QuoteScene == multienv.SceneChangeSupplyAgreement) &&
		(q.QuoteType == multienv.QuoteTypeNormal ||
			q.QuoteType == multienv.QuoteTypeProgressive)
}

// IsPublicNew 公有云新签报价
func (q *Quote) IsPublicNew() bool {
	return q.QuoteScene == multienv.SceneNew &&
		(q.QuoteType == multienv.QuoteTypeNormal ||
			q.QuoteType == multienv.QuoteTypeProgressive)
}

// IsPublicChange 公有云变更报价
func (q *Quote) IsPublicChange() bool {
	return q.IsChangeQuoteCommon() && (q.QuoteType == multienv.QuoteTypeNormal ||
		q.QuoteType == multienv.QuoteTypeProgressive)
}

// IsChangeQuoteCommon 公有云变更报价或者公有云变更补充报价单
func (q *Quote) IsChangeQuoteCommon() bool {
	return q.QuoteScene == multienv.SceneChangeQuote ||
		q.QuoteScene == multienv.SceneChangeSupplyAgreement
}

func (q *Quote) NeedProjectInfo() bool {
	return q.IsProjectBased() || q.IsConfigList()
}

func (q *Quote) IsConfigList() bool {
	return q.QuoteScene.GeneralizedConfigListScene()
}

func (q *Quote) IsQuote() bool {
	if q == nil {
		return false
	}
	return !q.IsConfigList()
}

func (q *Quote) GetQuoteSceneInfo() string {
	if q.QuoteScene.GeneralizedConfigListScene() {
		return i18nfmt.Sprintf(context.Background(), "配置清单")
	} else {
		return i18nfmt.Sprintf(context.Background(), "报价单")
	}
}

func (q *Quote) IsProgressive() bool {
	return q.QuoteType == multienv.QuoteTypeProgressive
}

func (q *Quote) ContainsAccountIDs(accountIDs []string) bool {
	accountIDMap := map[string]bool{}
	for _, accountID := range strings.Split(q.CustomerDetail, ",") {
		accountIDMap[accountID] = true
	}
	for _, accountID := range accountIDs {
		if !accountIDMap[accountID] {
			return false
		}
	}
	return true
}

// IsBackdating 是否为[开始日早于提单日] 通过前置环节(新建、更新)时做强校验
func (q *Quote) IsBackdating() bool {
	return q.BackdatingReason != ""
}

// CanBackdating 是否允许倒签: 纸质签约、非内部客户、非项目制
func (q *Quote) CanBackdating() bool {
	return q.OrderType == multienv.GetContractTypePaperContract() &&
		!q.TradeType.InnerCustomer() &&
		q.QuoteType != multienv.QuoteTypeProjectBased
}

// IsInnerQuote 报价单是否为内部报价单
func (q *Quote) IsInnerQuote() bool {
	return q.TradeType.InnerCustomer() && q.OpportunityID.IsVirtualOppNumbers()
}

func (q *Quote) IsInnerQuoteV2() bool {
	return q.TradeTypeCode == multienv.CustomerTypeCodeEPSInner || q.TradeTypeCode == multienv.CustomerTypeCodeByteInner
}

// IsInModifyProcess 是否处于审批修改中
func (q *Quote) IsInModifyProcess() bool {
	return q.ModifyStatus == constants.ApprovalModifyStatusStart &&
		q.QuoteStatus == constants.StatusSubmit
}

// InModifyVersionChain 是否已进入新版审批中修改版本链（已形成快照链路）。
// 对应灰度场景三：origin_snapshot_id 和 parent_snapshot_id 均有值（>0），
// 说明该单据已走过新版审批中修改，必须继续走新链路，不可回退到老逻辑。
func (q *Quote) InModifyVersionChain() bool {
	return q.OriginSnapshotID > 0 && q.ParentSnapshotID > 0
}

// IsNewModifyProcessData 是否为新版审批中修改数据（新老链路识别）。
// 只要 origin_snapshot_id 或 parent_snapshot_id 任一有值，即视为新链路数据。
func (q *Quote) IsNewModifyProcessData() bool {
	return q.OriginSnapshotID > 0 || q.ParentSnapshotID > 0
}

// IsSnapshot 是否为快照单（snapshot_from 指向原单ID；原单该字段为0）。
func (q *Quote) IsSnapshot() bool {
	return q.SnapshotFrom > 0
}

// ShouldSkipJointOrderRebateRefresh 新版审批中修改再次送审时，是否应跳过联合打单返佣刷新。
// 修改期间用户已在原单上直接增删改返佣，重新送审无需再按 PRM 覆盖同步，避免冲掉用户改动。
func (q *Quote) ShouldSkipJointOrderRebateRefresh() bool {
	return q.IsInModifyProcess() && q.IsNewModifyProcessData()
}

// CanEdit 是否可编辑
func (q *Quote) CanEdit() bool {
	return q.IsInModifyProcess() || q.QuoteStatus.IsBeforeApproveStatus()
}

// IsPrmQuote 是否为伙伴报价单
func (q *Quote) IsPrmQuote() bool {
	return q.AppAccountID == constants.OpenApiAppKeyPrm || q.AppAccountID == constants.PrmAccount
}

// IsSupplyAgreement 报价单是否为补充报价单
func (q *Quote) IsSupplyAgreement() bool {
	return q.QuoteScene == multienv.SceneSupplyAgreement || q.QuoteScene == multienv.SceneChangeSupplyAgreement
}

// IsPublicChangeSupplyAgreement 报价单是否为补充变更报价单
func (q *Quote) IsPublicChangeSupplyAgreement() bool {
	return q.QuoteScene == multienv.SceneChangeSupplyAgreement &&
		(q.QuoteType == multienv.QuoteTypeNormal || q.QuoteType == multienv.QuoteTypeProgressive)
}

// IsSupplyConfigList 报价单是否为补充配置清单
func (q *Quote) IsSupplyConfigList() bool {
	return q.QuoteScene == multienv.SceneSupplyConfigurationList
}

// IsPublicSupplyAgreement 报价单是否为公有云补充报价单
func (q *Quote) IsPublicSupplyAgreement() bool {
	return (q.QuoteType == multienv.QuoteTypeNormal || q.QuoteType == multienv.QuoteTypeProgressive) && q.IsSupplyAgreement()
}

// IsProjectSupplyAgreement 报价单是否为补充项目制报价单
func (q *Quote) IsProjectSupplyAgreement() bool {
	return q.IsProjectBased() && q.IsSupplyAgreement()
}

// IsProjectBasedChange 报价单是否为项目制变更
func (q *Quote) IsProjectBasedChange() bool {
	return q.IsProjectBased() && q.IsChangeQuoteCommon()
}

// CanCalcDiscountCategory 是否可以计算折扣范围
func (q *Quote) CanCalcDiscountCategory() bool {

	if q.QuoteScene.GeneralizedConfigListScene() {
		return false
	}

	return true
}

// CanAbandon 是否可作废
func (q *Quote) CanAbandon() bool {
	if q.IsSupplyAgreement() ||
		q.QuoteScene == multienv.SceneChangeQuote ||
		q.QuoteScene == multienv.SceneChangeSupplyAgreement ||
		q.QuoteScene == multienv.SceneChangeConfigurationList {
		// 补充协议- 只有报价单状态=【草稿】、【审批驳回】、【审批通过】时，允许作废
		if _, exist := constants.AllowedSupplyAgreementAbandonStatus[q.QuoteStatus]; !exist {
			return false
		}
		return true
	}
	return false
}

func (q *Quote) ConfigListCanBeUsed() bool {
	_, quoteStatusOk := constants.ConfigListCanBeUsedStatusMap[q.QuoteStatus]
	return q.IsConfigList() && quoteStatusOk

}

// SupplyConfigListStatusCanBeUsed 补充配置清单可使用
func (q *Quote) SupplyConfigListStatusCanBeUsed() bool {
	_, quoteStatusOk := constants.ConfigListCanBeUsedStatusMap[q.QuoteStatus]
	return q.IsSupplyConfigList() && quoteStatusOk

}

func (q *Quote) GetModifyContext() (*QuoteModifyContext, error) {
	var mctx QuoteModifyContext
	if err := json.Unmarshal([]byte(q.ModifyContext), &mctx); err != nil {
		return &mctx, err
	}
	return &mctx, nil
}

func (q *Quote) Clone() *Quote {
	raw := *q
	raw.Id = 0
	return &raw
}

func (q *Quote) GetProfitCalculate(calculateType int, dataScope int) string {
	if dataScope == constants.ProfitDataScopeAll {
		switch calculateType {
		case constants.CalculateTypeUnitCost:
			return q.ProjectProfitCalculate
		case constants.CalculateTypeLatestResourcePrice:
			return q.LatestResourceProfitCalculate
		default:
			// 保持 master 兼容：未识别的测算类型仍按出厂价口径读取，避免旧调用默认落到最新资源价。
			return q.FactoryPriceProfitCalculate
		}
	} else {
		switch calculateType {
		case constants.CalculateTypeUnitCost:
			return q.ProjectProfitChanged
		case constants.CalculateTypeLatestResourcePrice:
			return q.LatestResourceProfitChanged
		default:
			// 保持 master 兼容：未识别的测算类型仍按出厂价口径读取，避免旧调用默认落到最新资源价。
			return q.FactoryPriceProfitChanged
		}
	}
}

func (q *Quote) GetProductLineProfitCalculate(dataScope int) string {
	if dataScope == constants.ProfitDataScopeAll {
		return q.ProductLineProfitCalculate
	} else {
		return q.ProductLineProfitChanged
	}
}

func (q *Quote) GetSupplySceneList() []string {
	return strings.Split(q.SupplyScene, ",")
}

func (q *Quote) GetAccountIDMap() map[string]bool {
	accountIDs := strings.Split(q.CustomerDetail, ",")
	m := map[string]bool{}
	for _, accountID := range accountIDs {
		m[accountID] = true
	}
	return m
}

func (q *Quote) GetChangeDiscountQuotePreviewLink(ctx context.Context) string {
	conf := config.GetGlobalConf(ctx)
	if conf == nil || conf.QuoteApp == nil || conf.QuoteApp.ChangeDiscountQuotePreviewLink == "" {
		logs.CtxError(ctx, "GetChangeDiscountQuotePreviewLink nil")
		return ""
	}
	return fmt.Sprintf(conf.QuoteApp.ChangeDiscountQuotePreviewLink, q.Id)
}

func (q *Quote) IsChangeDiscountQuote() bool {
	return q.QuoteScene == multienv.SceneBatchChangeDiscount
}

func (q *Quote) IsGrayScaleOpp2() bool {
	return q.GrayScale == multienv.GrayscaleOpp2
}

func (q *Quote) IsDistributionBizTypeCustom() bool {
	return q.DistributionBizTypeCode == multienv.DistributionBizTypeCodeCustom
}

func (p *CustomerInfo) DeepEqual(ano *CustomerInfo) bool {
	if p == ano {
		return true
	} else if p == nil || ano == nil {
		return false
	}

	if p.CustomerType != ano.CustomerType {
		return false
	}
	if p.AccountID != ano.AccountID {
		return false
	}
	if p.OwnerID != ano.OwnerID {
		return false
	}
	if p.CustomerName != ano.CustomerName {
		return false
	}

	return true
}

// GetEntityAccountID 获取配价主体、签约主体账号
func (q *Quote) GetEntityAccountID() string {
	var accountIDs []string
	if q.CustomerDetail != "" {
		accountIDs = append(accountIDs, strings.Split(q.CustomerDetail, ",")...)
	}
	if q.ContractAccount != "" {
		accountIDs = append(accountIDs, strings.Split(q.ContractAccount, ",")...)
	}
	if len(accountIDs) == 0 {
		return ""
	}
	accountIDs = util.GetUniqKeys(accountIDs)
	return strings.Join(accountIDs, ",")
}

// GetCustomerDetailAccountID 获取配价账号id列表
func (q *Quote) GetCustomerDetailAccountID() []int64 {
	if q.CustomerDetail == "" {
		return nil
	}
	accountIDStrArr := strings.Split(q.CustomerDetail, ",")
	var accountIDArr []int64
	for _, accountIDStr := range accountIDStrArr {
		accountIDArr = append(accountIDArr, util.StrToInt64(accountIDStr))
	}
	return accountIDArr
}

// GetCustomerAccountID 获取最终客户账号id列表
func (q *Quote) GetCustomerAccountID() []int64 {
	var accountIDArr []int64
	if q == nil {
		return accountIDArr
	}
	if !multienv.IsBytePlus() {
		if q.CustomerAccount == "" {
			return accountIDArr
		}
		accountIDStrArr := strings.Split(q.CustomerAccount, ",")
		for _, accountIDStr := range accountIDStrArr {
			accountIDArr = append(accountIDArr, util.StrToInt64(accountIDStr))
		}
		return accountIDArr
	}
	//BP分销场景，使用一级分销、二级分销和最终客户账号
	if q.TradeTypeCode == multienv.CustomerTypeCodeBPDistributor {
		// 当前 BP分销 只有特殊报价一种类型
		if q.IsDistributionBizTypeCustom() {
			distributorInfos := &DistributorInfo{}
			_ = json.Unmarshal([]byte(q.DistributorInfos), distributorInfos)
			if distributorInfos.FirstDistributor != nil && distributorInfos.FirstDistributor.AccountID != "" {
				accountIDArr = append(accountIDArr, util.StrToInt64(distributorInfos.FirstDistributor.AccountID))
			}
		}
	} else {
		// 使用配价账号
		if q.CustomerDetail == "" {
			return accountIDArr
		}
		accountIDStrArr := strings.Split(q.CustomerDetail, ",")
		for _, accountIDStr := range accountIDStrArr {
			if accountIDStr == "" {
				continue
			}
			accountIDArr = append(accountIDArr, util.StrToInt64(accountIDStr))
		}
	}
	if len(accountIDArr) == 0 {
		return accountIDArr
	}
	return accountIDArr
}

// GetConstraintAccountIDs 获取报价单约束账号id列表
func (q *Quote) GetConstraintAccountIDs() []int64 {
	var accountIDArr []int64
	if q == nil {
		return accountIDArr
	}
	//BP分销场景，使用一级分销、二级分销和最终客户账号
	if q.TradeTypeCode == multienv.CustomerTypeCodeBPDistributor {
		// 当前 BP分销 只有特殊报价一种类型
		if q.IsDistributionBizTypeCustom() {
			distributorInfos := &DistributorInfo{}
			_ = json.Unmarshal([]byte(q.DistributorInfos), distributorInfos)
			if distributorInfos.FirstDistributor != nil && distributorInfos.FirstDistributor.AccountID != "" {
				accountIDArr = append(accountIDArr, util.StrToInt64(distributorInfos.FirstDistributor.AccountID))
			}
		}
	} else {
		// 使用配价账号
		if q.CustomerDetail == "" {
			return accountIDArr
		}
		accountIDStrArr := strings.Split(q.CustomerDetail, ",")
		for _, accountIDStr := range accountIDStrArr {
			if accountIDStr == "" {
				continue
			}
			accountIDArr = append(accountIDArr, util.StrToInt64(accountIDStr))
		}
	}
	if len(accountIDArr) == 0 {
		return accountIDArr
	}
	sort.Slice(accountIDArr, func(i, j int) bool {
		return accountIDArr[i] > accountIDArr[j]
	})
	return accountIDArr
}

func (q *Quote) SupportExclude() bool {
	if q == nil {
		return false
	}
	if q.IsInnerQuoteV2() {
		return false
	}
	return true
}

func (q *Quote) SupportExcludeRefresh() bool {
	if !q.SupportExclude() {
		return false
	}
	if !q.CanEdit() {
		return false
	}
	return true
}

func (q *Quote) ParseDistributorInfo() *DistributorInfo {
	if q.DistributorInfos == "" {
		return nil
	}
	distributorInfo := &DistributorInfo{}
	_ = json.Unmarshal([]byte(q.DistributorInfos), distributorInfo)
	return distributorInfo
}

// SupportPublicCloudEstimate 是否支持预计金额流程
func (q *Quote) SupportPublicCloudEstimate() bool {
	return q.PublicCloudEstimate.GreaterThan(decimal.Zero)
}

// GetPriceEntityIndustryKey 获取配价主体行业线
func (q *Quote) GetPriceEntityIndustryKey() string {
	if q.PriceEntityIndustryInfo == "" {
		return ""
	}
	industryInfo := &CustomerIndustryInfo{}
	_ = json.Unmarshal([]byte(q.PriceEntityIndustryInfo), industryInfo)
	return industryInfo.IndustryKey
}

// GetCustomerIndustryKey 获取客户主体行业线
func (q *Quote) GetCustomerIndustryKey() string {
	if q.CustomerIndustryInfo == "" {
		return ""
	}
	industryInfo := &CustomerIndustryInfo{}
	_ = json.Unmarshal([]byte(q.CustomerIndustryInfo), industryInfo)
	return industryInfo.IndustryKey
}

// GetIndustryKey 获取客户主体行业线(配价主体行业线兜底)
func (q *Quote) GetIndustryKey() string {
	customerIndustryKey := q.GetCustomerIndustryKey()
	if customerIndustryKey != "" {
		return customerIndustryKey
	}
	return q.GetPriceEntityIndustryKey()
}

// SupportQuantityPrice 是否支持量价
func (q *Quote) SupportQuantityPrice() bool {
	if q.IsProjectBased() || q.IsConfigList() {
		return false
	}
	if q.IsInnerQuote() {
		return false
	}
	if !q.SupportPublicCloudEstimate() {
		return false
	}
	if q.SalesChannelType == "" {
		// 防止未刷数
		return false
	}
	return true
}

func (q *Quote) GetPriceValidPeriodDays() int {
	if q.PriceValidPeriod == "" { //固定日期生效
		duration := util.ToBeginningOfDay(q.PriceValidPeriodEndTime).Sub(util.ToBeginningOfDay(q.PriceValidPeriodStartTime))
		return int(duration.Hours()/24) + 1
	} else { //自签订之日起
		priceValidPeriod, _ := util.ParseJsonStr[*PriceValidPeriod](q.PriceValidPeriod)
		return priceValidPeriod.GetPeriodDayNum()
	}
}

type PriceValidPeriod struct {
	PeriodNum  int
	PeriodUnit constants.PeriodUnit
}

// Over5Years 是否超过5年
func (p *PriceValidPeriod) Over5Years() bool {
	if p.PeriodUnit == constants.PeriodUnitDay {
		return p.PeriodNum > 1825 // 365*5
	} else if p.PeriodUnit == constants.PeriodUnitMonth {
		return p.PeriodNum > 60
	} else if p.PeriodUnit == constants.PeriodUnitYear {
		return p.PeriodNum > 5
	}
	// 其他情况认为不超过5年
	return false
}

func (p *PriceValidPeriod) GetPeriodDayNum() int {
	if p.PeriodUnit == constants.PeriodUnitDay {
		return p.PeriodNum
	} else if p.PeriodUnit == constants.PeriodUnitMonth {
		return p.PeriodNum * 30
	} else if p.PeriodUnit == constants.PeriodUnitYear {
		return p.PeriodNum * 365
	}
	return 0
}

func (q *Quote) IsNewConfigList(ctx context.Context) bool {
	return q.IsConfigList()
}

func (q *Quote) SupportSpProduct() bool {
	if q.IsConfigList() {
		return true
	}
	if q.QuoteType == multienv.QuoteTypeProgressive {
		return false
	}
	if multienv.IsBytePlus() {
		if q.TradeTypeCode == multienv.CustomerTypeCodeDirectSell ||
			q.TradeTypeCode == multienv.CustomerTypeCodeSLV {
			return true
		}
		return false
	}
	if q.TradeTypeCode == multienv.CustomerTypeCodeDirectSell ||
		q.TradeTypeCode == multienv.CustomerTypeCodeEcoAgent ||
		q.TradeTypeCode == multienv.CustomerTypeCodeEcoSell {
		return true
	}
	return false
}

func (q *Quote) SupportPickupVoucherProduct() bool {
	return q.TradeTypeCode != multienv.CustomerTypeCodeEcoDist
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"fmt"
)

//ChangeDiscountWhiteList 变价商品白名单
type ChangeDiscountWhiteList struct {
	framework.BaseDB
	CreatorAccountID  string
	CustomerAccountID string
	TradeProduct      string
	ConfigCode        string
	ChargeItemCode    string
}

func (m *ChangeDiscountWhiteList) TableName() string {
	return "change_discount_white_list"
}

func (m *ChangeDiscountWhiteList) GetIndexKey() string {
	return fmt.Sprintf("%s::%s", m.CustomerAccountID, m.TradeProduct)
}
func (m *ChangeDiscountWhiteList) GetConfigChargeItemKey() string {
	return fmt.Sprintf("%s::%s", m.ConfigCode, m.ChargeItemCode)
}

package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

var (
	FormAttrType_Select = "select"
	FormAttrType_Number = "number"
	FormAttrType_Input  = "input"
)

type FormSchema struct {
	framework.BaseDB
	AttrKey          string
	DisplayName      string
	AttrRequired     int
	CreatorAccountID string
	AttrType         string
	AttrDescription  string
	ParentAttrKey    string
	AttrCategory     string
	BizScene         int
	Sort             int64
}

func (a *FormSchema) TableName() string {
	return "form_schema"
}

package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

//ContractPriceTask 国际短信变价合同价创建任务表
type ContractPriceTask struct {
	framework.BaseDB
	QuoteID          int64
	BatchQuoteItemID string
	TaskStatus       string
	TaskMsg          string
}

func (m *ContractPriceTask) TableName() string {
	return "contract_price_task"
}

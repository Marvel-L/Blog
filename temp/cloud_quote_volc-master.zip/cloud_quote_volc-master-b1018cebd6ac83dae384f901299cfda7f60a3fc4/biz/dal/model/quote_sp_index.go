package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

const TableNameQuoteSpIndex = "quote_sp_index"

// QuoteSpIndex 节省计划索引表
type QuoteSpIndex struct {
	framework.BaseDB
	QuoteID         int64
	QuoteItemID     int64
	CustomerAccount string
	TradeProduct    string
	ConfigCode      string
	ChargeItemCode  string
}

func (l *QuoteSpIndex) TableName() string {
	return TableNameQuoteSpIndex
}

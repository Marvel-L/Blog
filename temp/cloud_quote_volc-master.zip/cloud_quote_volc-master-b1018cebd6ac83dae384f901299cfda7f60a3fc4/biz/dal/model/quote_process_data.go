package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type QuoteProcessData struct {
	framework.BaseDB
	QuoteID         int64  // 报价单ID
	BizScene        string // 业务场景
	BizCode         string // 业务唯一编码
	CalculateResult string // 计算结果
	CalculateDetail string // 计算明细
}

func (r *QuoteProcessData) TableName() string {
	return "quote_process_data"
}

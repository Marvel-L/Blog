package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"time"
)

// QuoteResourcePage 报价资源单
type QuoteResourcePage struct {
	framework.BaseDB
	QuoteID            int64     // 报价单id
	CreatorAccountID   string    // 创建人email
	CustomerAccountID  string    // 客户账号
	ExpectDeliveryTime time.Time // 期望工供卡时间
	UseBeforeContract  int       // 是否允许提前交付:0-不允许，1-允许
}

// TableName 表名称
func (r *QuoteResourcePage) TableName() string {
	return "quote_resource_page"
}

// DataCopy 数据复制
func (r *QuoteResourcePage) DataCopy(resourcePage *QuoteResourcePage) {
	r.Id = resourcePage.Id
	r.QuoteID = resourcePage.QuoteID
	r.ExpectDeliveryTime = resourcePage.ExpectDeliveryTime
	r.UseBeforeContract = resourcePage.UseBeforeContract
}

// DataEquals 判断是否相同
func (r *QuoteResourcePage) DataEquals(resourcePage *QuoteResourcePage) bool {
	return r.ExpectDeliveryTime.Equal(resourcePage.ExpectDeliveryTime)
}

func (r *QuoteResourcePage) Clone() *QuoteResourcePage {
	raw := *r
	raw.Id = 0
	return &raw
}

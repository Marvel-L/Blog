package model

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

func TestQuote_GenRespContainsResolvedRootQuoteID(t *testing.T) {
	mockey.PatchConvey("响应下发变更链根单ID", t, func() {
		mockey.Mock(multienv.I18nFormat).To(func(_ context.Context, value string, _ bool) string {
			return value
		}).Build()

		quote := &Quote{
			BaseDB:           framework.BaseDB{Id: 300},
			QuoteScene:       multienv.SceneChangeQuote,
			OriginQuoteID:    200,
			RootQuoteID:      100,
			OriginSnapshotID: 101,
			ParentSnapshotID: 102,
			SnapshotFrom:     103,
		}
		resp := quote.GenResp(context.Background())
		convey.So(resp.RootQuoteID, convey.ShouldEqual, int64(100))
		convey.So(resp.OriginSnapshotID, convey.ShouldEqual, int64(101))
		convey.So(resp.ParentSnapshotID, convey.ShouldEqual, int64(102))
		convey.So(resp.SnapshotFrom, convey.ShouldEqual, int64(103))
		convey.So(quote.GenRespV2(context.Background()).RootQuoteID, convey.ShouldEqual, int64(100))

		legacyQuote := &Quote{
			BaseDB:        framework.BaseDB{Id: 200},
			QuoteScene:    multienv.SceneChangeQuote,
			OriginQuoteID: 100,
		}
		// 历史单次变更在 root_quote_id 回填前只保留 OriginQuoteID；
		// 详情接口下发持久化字段原值，根单关系由后续批量回填补齐。
		convey.So(legacyQuote.GenResp(context.Background()).RootQuoteID, convey.ShouldEqual, int64(0))
		convey.So(legacyQuote.GenRespV2(context.Background()).RootQuoteID, convey.ShouldEqual, int64(0))

		rootQuote := &Quote{BaseDB: framework.BaseDB{Id: 100}, QuoteScene: multienv.SceneNew}
		convey.So(rootQuote.GenResp(context.Background()).RootQuoteID, convey.ShouldEqual, int64(0))
		convey.So(rootQuote.GenRespV2(context.Background()).RootQuoteID, convey.ShouldEqual, int64(0))
	})
}

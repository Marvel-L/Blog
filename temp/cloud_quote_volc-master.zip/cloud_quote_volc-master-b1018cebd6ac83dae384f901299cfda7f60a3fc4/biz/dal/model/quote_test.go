package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestQuoteItemCalculate_IsCalculatedTotalDiscount(t *testing.T) {
	tests := []struct {
		name string
		cal  *QuoteItemCalculate
		want bool
	}{
		{
			name: "nil",
			cal:  nil,
			want: false,
		},
		{
			name: "total coupon amount greater than zero",
			cal: &QuoteItemCalculate{
				TotalCouponAmount: decimal.NewFromInt(1),
			},
			want: true,
		},
		{
			name: "rebate amount greater than zero",
			cal: &QuoteItemCalculate{
				RebateAmount: decimal.NewFromInt(1),
			},
			want: true,
		},
		{
			name: "total estimated income greater than zero",
			cal: &QuoteItemCalculate{
				TotalEstimatedIncome: decimal.NewFromInt(1),
			},
			want: true,
		},
		{
			name: "all zero",
			cal:  &QuoteItemCalculate{},
			want: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.cal.IsCalculatedTotalDiscount(); got != tt.want {
				t.Fatalf("IsCalculatedTotalDiscount() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestQuoteItemCalculate_GetEstimatedIncome(t *testing.T) {
	tests := []struct {
		name string
		cal  *QuoteItemCalculate
		want decimal.Decimal
	}{
		{
			name: "not calculated total discount uses income no tax",
			cal: &QuoteItemCalculate{
				IncomeNoTax: decimal.NewFromInt(100),
			},
			want: decimal.NewFromInt(100),
		},
		{
			name: "total estimated income greater than zero uses total estimated income",
			cal: &QuoteItemCalculate{
				IncomeNoTax:          decimal.NewFromInt(100),
				TotalEstimatedIncome: decimal.NewFromInt(80),
			},
			want: decimal.NewFromInt(80),
		},
		{
			name: "total coupon amount marks calculated and uses total estimated income",
			cal: &QuoteItemCalculate{
				IncomeNoTax:       decimal.NewFromInt(100),
				TotalCouponAmount: decimal.NewFromInt(1),
			},
			want: decimal.Zero,
		},
		{
			name: "rebate amount marks calculated and uses total estimated income",
			cal: &QuoteItemCalculate{
				IncomeNoTax:  decimal.NewFromInt(100),
				RebateAmount: decimal.NewFromInt(1),
			},
			want: decimal.Zero,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.cal.GetEstimatedIncome(); !got.Equal(tt.want) {
				t.Fatalf("GetEstimatedIncome() = %s, want %s", got.String(), tt.want.String())
			}
		})
	}
}

func TestQuote_SupportCoupon(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{multienv.TradeProductTypeOnline: 1}, nil).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return("").Build()
			mockey.Mock((multienv.QuoteScene).GeneralizedQuoteScene).Return(false).Build()
			// Act
			var v1 = multienv.QuoteScene(0)
			v2 := &Quote{
				AppAccountID: "",
				QuoteScene:   v1,
				QuoteType:    0,
			}
			supportCoupon, _ := v2.SupportCoupon(context.Background())

			// Assert
			convey.So(supportCoupon, convey.ShouldEqual, false)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func TestQuote_SupportCredit(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			var v = constants.ProductType(0)
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{v: nil}, nil).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return("").Build()
			mockey.Mock((multienv.QuoteScene).GeneralizedQuoteScene).Return(false).Build()

			// Act
			var v1 = multienv.TradeType("")
			var v2 = multienv.QuoteScene(0)
			v3 := &Quote{
				CustomerDetail: "",
				TradeType:      v1,
				AppAccountID:   "",
				QuoteScene:     v2,
			}
			supportCredit, _ := v3.SupportCredit(context.Background())

			// Assert
			convey.So(supportCredit, convey.ShouldEqual, false)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_Quote_ParseDistributorInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test Quote.ParseDistributorInfo", t, func() {
		mockey.PatchConvey("场景：DistributorInfos 字段为空字符串", func() {
			// 场景描述：
			// 构造数据：Quote 实例的 DistributorInfos 字段为空字符串。
			// 逻辑链路：
			// 1. 调用 ParseDistributorInfo 方法。
			// 2. 方法内部的第一个 if 条件 q.DistributorInfos == "" 为 true。
			// 3. 方法直接返回 nil。
			q := &Quote{
				DistributorInfos: "",
			}

			// 调用
			result := q.ParseDistributorInfo()

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：DistributorInfos 字段为合法的JSON字符串", func() {
			// 场景描述：
			// 构造数据：Quote 实例的 DistributorInfos 字段为一个合法的JSON字符串。
			// 逻辑链路：
			// 1. 调用 ParseDistributorInfo 方法。
			// 2. 方法内部的第一个 if 条件为 false。
			// 3. 初始化一个 DistributorInfo 结构体指针。
			// 4. 调用 json.Unmarshal 将 JSON 字符串反序列化到该结构体中。
			// 5. 返回反序列化后的结构体指针。
			// 注意：本测试假设 model.CustomerInfo 结构体与测试数据兼容。
			distributorJSON := `{
                "FirstDistributor":  {"SomeField": "distributor1"},
                "SecondDistributor": {"SomeField": "distributor2"},
                "FinalCustomer":     {"SomeField": "customer"}
            }`
			q := &Quote{
				DistributorInfos: distributorJSON,
			}

			// 调用
			result := q.ParseDistributorInfo()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)

			// 为了避免因不清楚 CustomerInfo 真实结构而导致断言失败，
			// 此处我们只断言指针不为 nil，并假设反序列化成功填充了内容。
			convey.So(result.FirstDistributor, convey.ShouldNotBeNil)
			convey.So(result.SecondDistributor, convey.ShouldNotBeNil)
			convey.So(result.FinalCustomer, convey.ShouldNotBeNil)
			// 如果 CustomerInfo 结构已知，可以使用 ShouldResemble 进行深度比较。
			// 例如，如果 CustomerInfo 只有一个 Name 字段：
			// expected := &DistributorInfo{
			// 	FirstDistributor: &CustomerInfo{Name: "distributor1"},
			// 	...
			// }
			// convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("场景：DistributorInfos 字段为非法的JSON字符串", func() {
			// 场景描述：
			// 构造数据：Quote 实例的 DistributorInfos 字段为一个非法的JSON字符串。
			// 逻辑链路：
			// 1. 调用 ParseDistributorInfo 方法。
			// 2. 方法内部的第一个 if 条件为 false。
			// 3. 初始化一个 DistributorInfo 结构体指针。
			// 4. 调用 json.Unmarshal，但由于JSON格式错误，反序列化失败。函数忽略该错误。
			// 5. 返回未经修改的、字段为空的 DistributorInfo 结构体指针。
			q := &Quote{
				DistributorInfos: `{"FirstDistributor":, "invalid"}`,
			}

			// 调用
			result := q.ParseDistributorInfo()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, &DistributorInfo{})
		})
	})
}

func TestQuote_ParseJointPrintOrder(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &Quote{
				JointPrintOrder: "",
			}
			got := v.ParseJointPrintOrder()

			// Assert
			convey.So(got, convey.ShouldResemble, (*JointPrintOrder)(nil))
		})
	})
	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &Quote{
				JointPrintOrder: "{\"OpportunitySrcDec\":\"客户推荐\",\"OpportunitySrcKey\":\"Channel Referral\",\"Support\":true,\"PrintScene\":\"直销::渠道\",\"PrintSceneCode\":\"xx::xx\",\"CustomerOwnerRole\":\"直销\",\"Collaborator\":\"xxx@bytedance.com\",\"PolicyName\":\"xxx\",\"PolicyLink\":\"http://xxxxx\",\"ChangeSupport\":false}",
			}
			got := v.ParseJointPrintOrder()

			// Assert
			convey.So(got, convey.ShouldNotBeNil)
		})
	})
}

func Test_Quote_SupportGuarantee_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	mockey.PatchConvey("Test Quote SupportGuarantee", t, func() {
		mockey.PatchConvey("should return true when all conditions are met (AppAccountID is Quote platform)", func() {

			q := &Quote{
				AppAccountID:  constants.OpenApiAppKeyQuote,
				QuoteType:     multienv.QuoteTypeNormal,
				TradeTypeCode: multienv.CustomerTypeCodeDirectSell, // Supported TradeTypeCode
				QuoteScene:    multienv.SceneNew,
			}

			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(true).Build()
			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return true when all conditions are met (AppAccountID is CRM)", func() {

			crmAppKey := "test_crm_app_key"
			q := &Quote{
				AppAccountID:  crmAppKey,
				QuoteType:     multienv.QuoteTypeNormal,
				TradeTypeCode: multienv.CustomerTypeCodeDirectSell, // Supported TradeTypeCode
				QuoteScene:    multienv.SceneNew,
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return(crmAppKey).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return error when GetProductTypeMap fails", func() {

			q := &Quote{}
			expectedErr := errors.New("get product map error")
			mockey.Mock((*Quote).GetProductTypeMap).Return(nil, expectedErr).Build()
			support, err := q.SupportGuarantee(ctx)
			convey.So(support, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("should return false when FixedContractEffectiveTime is false", func() {

			q := &Quote{}

			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(false).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return false when AppAccountID is invalid", func() {

			q := &Quote{
				AppAccountID: "invalid_app_id",
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(config.GetOpenApiAppKeyCrm).Return("crm_app_key").Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should allow hybrid cloud when other admission requirements are met", func() {

			q := &Quote{
				AppAccountID:  constants.OpenApiAppKeyQuote,
				QuoteScene:    multienv.SceneNew,
				TradeTypeCode: multienv.CustomerTypeCodeDirectSell,
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline:  struct{}{},
				multienv.TradeProductTypeOffline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return false when productType is not online", func() {

			q := &Quote{
				AppAccountID: constants.OpenApiAppKeyQuote,
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOffline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return false when GeneralizedQuoteScene is false", func() {

			q := &Quote{
				AppAccountID: constants.OpenApiAppKeyQuote,
				QuoteScene:   multienv.QuoteScene(99),
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(false).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return false when QuoteType is progressive", func() {

			q := &Quote{
				AppAccountID:  constants.OpenApiAppKeyQuote,
				QuoteScene:    multienv.SceneNew,
				QuoteType:     multienv.QuoteTypeProgressive,
				TradeTypeCode: multienv.CustomerTypeCodeDirectSell,
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return false when TradeTypeCode is valid but not supported in guarantee map", func() {
			q := &Quote{
				AppAccountID:  constants.OpenApiAppKeyQuote,
				QuoteScene:    multienv.SceneNew,
				QuoteType:     multienv.QuoteTypeNormal,
				TradeTypeCode: multienv.CustomerTypeCodeEcoDist, // A valid but unsupported type
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return false when TradeTypeCode is an unknown code", func() {

			q := &Quote{
				AppAccountID:  constants.OpenApiAppKeyQuote,
				QuoteScene:    multienv.SceneNew,
				QuoteType:     multienv.QuoteTypeNormal,
				TradeTypeCode: 999, // An invalid code
			}
			mockey.Mock((*Quote).GetProductTypeMap).Return(map[constants.ProductType]interface{}{
				multienv.TradeProductTypeOnline: struct{}{},
			}, nil).Build()
			mockey.Mock((*Quote).FixedContractEffectiveTime).Return(true).Build()
			mockey.Mock(multienv.QuoteScene.GeneralizedQuoteScene).Return(true).Build()

			support, err := q.SupportGuarantee(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(support, convey.ShouldBeFalse)
		})
	})
}

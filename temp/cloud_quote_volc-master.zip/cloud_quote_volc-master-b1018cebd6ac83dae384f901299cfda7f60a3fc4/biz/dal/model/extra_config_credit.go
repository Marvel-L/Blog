package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/shopspring/decimal"
)

// ExtraConfigCreditDB 报价申请信控配置单
type ExtraConfigCreditDB struct {
	framework.BaseDB
	BizContractNo    string          `gorm:"column:biz_contract_no;NOT NULL"`            // 信控合同号
	AccountID        int64           `gorm:"column:account_id;default:0;NOT NULL"`       // 账户ID
	CreditLine       decimal.Decimal `gorm:"column:credit_line;default:0.0;NOT NULL"`    // 授信额度
	CreditLineBefore decimal.Decimal `gorm:"column:credit_line_before"`                  // 申请时的额度快照
	SettlementCycle  int             `gorm:"column:settlement_cycle;default:0;NOT NULL"` // 结算周期 1:月结 2:季度结
	PaymentCycle     int             `gorm:"column:payment_cycle;default:0;NOT NULL"`    // 付款周期 默认30天
	Creator          string          `gorm:"column:creator;NOT NULL"`                    // 创建者 email
	Remark           string          `gorm:"column:remark"`                              // 申请原因
	CopyFrom         int64           `gorm:"column:copy_from;default:0;NOT NULL"`        // 原配置ID
}

func (m *ExtraConfigCreditDB) TableName() string {
	return "extra_config_credit"
}

func (m *ExtraConfigCreditDB) Clone() *ExtraConfigCreditDB {
	raw := *m
	raw.Id = 0
	return &raw
}

type ExtraConfigCreditDBList []*ExtraConfigCreditDB

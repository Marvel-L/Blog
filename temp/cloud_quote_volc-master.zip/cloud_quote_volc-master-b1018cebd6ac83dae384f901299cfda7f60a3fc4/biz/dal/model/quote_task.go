package model

import (
	"context"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// QuoteTask 报价任务
type QuoteTask struct {
	framework.BaseDB
	CreatorAccountID  string
	TaskName          string
	TaskType          string
	TaskNotes         string
	ContractLarkURL   string
	ChargeItemLarkURL string
	TaskStatus        string
	ExecutionStatus   string
	ExecutionMsg      string
}

func (m *QuoteTask) TableName() string {
	return "quote_task"
}

type QuoteTaskResp struct {
	QuoteTaskID       int64
	CreatorAccountID  string
	TaskName          string
	TaskType          string
	TaskNotes         string
	ContractLarkURL   string
	ChargeItemLarkURL string
	TaskStatus        string
	ExecutionStatus   string
	ExecutionMsg      string
}

func (m *QuoteTask) GenResp() *QuoteTaskResp {
	return &QuoteTaskResp{
		QuoteTaskID:       m.Id,
		CreatorAccountID:  m.CreatorAccountID,
		TaskName:          m.TaskName,
		TaskType:          m.TaskType,
		TaskNotes:         m.TaskNotes,
		ContractLarkURL:   m.ContractLarkURL,
		ChargeItemLarkURL: m.ChargeItemLarkURL,
		TaskStatus:        m.TaskStatus,
		ExecutionStatus:   m.ExecutionStatus,
		ExecutionMsg:      m.ExecutionMsg,
	}
}

func (m *QuoteTask) SupportToUpdate() bool {
	return m.TaskStatus == multienv.TaskStatusInitialed || m.TaskStatus == multienv.TaskStatusCheckFailed
}
func (m *QuoteTask) SupportImportContract() bool {
	executionStatusOk := multienv.SupportImportContractExecutionStatusMap[m.ExecutionStatus]
	return executionStatusOk && m.SupportToUpdate()
}
func (m *QuoteTask) SupportDoImportContract() bool {
	return m.SupportToUpdate() && m.ExecutionStatus == multienv.ExecutionStatusImportContract
}
func (m *QuoteTask) SupportImportChargeItem() bool {
	executionStatusOk := multienv.SupportImportChargeItemExecutionStatusMap[m.ExecutionStatus]
	return m.TaskStatus == multienv.TaskStatusCheckFailed || (executionStatusOk && m.SupportToUpdate())
}
func (m *QuoteTask) SupportDoImportChargeItem() bool {
	return m.SupportToUpdate() && m.ExecutionStatus == multienv.ExecutionStatusImportChargeItem
}
func (m *QuoteTask) SupportToExecute() bool {
	return m.TaskStatus == multienv.TaskStatusCheckFailed ||
		(m.TaskStatus == multienv.TaskStatusInitialed &&
			m.ExecutionStatus == multienv.ExecutionStatusImportChargeItemSuccessful)
}
func (m *QuoteTask) ToolSupportToExecute() bool {
	return m.SupportToExecute() || m.TaskStatus == multienv.TaskStatusExecuting ||
		m.TaskStatus == multienv.TaskStatusPartialFailed || m.TaskStatus == multienv.TaskStatusFailed
}

func (m *QuoteTask) GetContractDetailPageLink(ctx context.Context) string {
	return fmt.Sprintf(config.GetGlobalConf(ctx).QuoteApp.QuoteTaskContractLink, m.Id)
}

func (m *QuoteTask) TaskCompleted() bool {
	return m.TaskStatus == multienv.TaskStatusPartialFailed || m.TaskStatus == multienv.TaskStatusFailed ||
		m.TaskStatus == multienv.TaskStatusSuccessful
}

package model

import (
	"testing"

	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// TestSnapshotChainFields 按技术方案「发起审批中修改」版本链示例（原单100，快照101/102/103），
// 模拟连续三次发起，逐轮校验快照单与原单应写入的版本链字段与文档完全一致。
func TestSnapshotChainFields(t *testing.T) {
	convey.Convey("版本链字段计算-复现文档 V0~V3 示例", t, func() {
		// 原单 100，首次发起前 origin/parent 均为 0
		origin := &Quote{BaseDB: framework.BaseDB{Id: 100}}

		convey.Convey("第一次发起：生成快照101(V0)", func() {
			// 快照单字段：继承原单当前 origin/parent(均0)，snapshot_from=原单ID
			oSnap, pSnap, from := origin.SnapshotChainFieldsForNewSnapshot()
			convey.So(oSnap, convey.ShouldEqual, 0)
			convey.So(pSnap, convey.ShouldEqual, 0)
			convey.So(from, convey.ShouldEqual, 100)

			// 假设快照入库拿到ID=101，更新原单
			oOrigin, pOrigin := origin.OriginChainFieldsAfterSnapshot(101)
			convey.So(oOrigin, convey.ShouldEqual, 101) // 首次发起，origin_snapshot_id 落为首个快照ID
			convey.So(pOrigin, convey.ShouldEqual, 101)
			origin.OriginSnapshotID, origin.ParentSnapshotID = oOrigin, pOrigin

			convey.Convey("第二次发起：生成快照102(V1)", func() {
				oSnap, pSnap, from := origin.SnapshotChainFieldsForNewSnapshot()
				convey.So(oSnap, convey.ShouldEqual, 101) // 快照102.origin_snapshot_id=101
				convey.So(pSnap, convey.ShouldEqual, 101) // 快照102.parent_snapshot_id=101
				convey.So(from, convey.ShouldEqual, 100)

				oOrigin, pOrigin := origin.OriginChainFieldsAfterSnapshot(102)
				convey.So(oOrigin, convey.ShouldEqual, 101) // 非首次，保持不变
				convey.So(pOrigin, convey.ShouldEqual, 102) // 指向最新快照
				origin.OriginSnapshotID, origin.ParentSnapshotID = oOrigin, pOrigin

				convey.Convey("第三次发起：生成快照103(V2)，原单成为V3", func() {
					oSnap, pSnap, from := origin.SnapshotChainFieldsForNewSnapshot()
					convey.So(oSnap, convey.ShouldEqual, 101) // 快照103.origin_snapshot_id=101
					convey.So(pSnap, convey.ShouldEqual, 102) // 快照103.parent_snapshot_id=102
					convey.So(from, convey.ShouldEqual, 100)

					oOrigin, pOrigin := origin.OriginChainFieldsAfterSnapshot(103)
					convey.So(oOrigin, convey.ShouldEqual, 101) // 原单.origin_snapshot_id=101
					convey.So(pOrigin, convey.ShouldEqual, 103) // 原单.parent_snapshot_id=103
				})
			})
		})
	})
}

// TestNewModifyProcessCanNotEditField 校验新版审批中修改的字段锁定：仅报价类型/客户类型/阶梯档位阈值不可改。
func TestNewModifyProcessCanNotEditField(t *testing.T) {
	convey.Convey("新版审批中修改字段锁定", t, func() {
		old := &Quote{
			QuoteType:     1,
			TradeTypeCode: 1,
		}
		old.ProgressiveInfo = `{"ProgressiveType":"a","MeasureInterval":"1,2","AccumulateType":"single"}`

		convey.Convey("其余字段变化：允许（如 QuoteName 不在锁定范围）", func() {
			cur := *old
			cur.QuoteName = "changed"
			isSame, field := cur.NewModifyProcessCanNotEditField(old)
			convey.So(isSame, convey.ShouldBeTrue)
			convey.So(field, convey.ShouldBeEmpty)
		})
		convey.Convey("报价类型变化：拦截", func() {
			cur := *old
			cur.QuoteType = 2
			isSame, field := cur.NewModifyProcessCanNotEditField(old)
			convey.So(isSame, convey.ShouldBeFalse)
			convey.So(field, convey.ShouldEqual, "QuoteType")
		})
		convey.Convey("客户类型变化：拦截", func() {
			cur := *old
			cur.TradeTypeCode = 6
			isSame, field := cur.NewModifyProcessCanNotEditField(old)
			convey.So(isSame, convey.ShouldBeFalse)
			convey.So(field, convey.ShouldEqual, "TradeTypeCode")
		})
		convey.Convey("阶梯档位阈值变化：拦截", func() {
			cur := *old
			cur.ProgressiveInfo = `{"ProgressiveType":"a","MeasureInterval":"1,2,3","AccumulateType":"single"}`
			isSame, field := cur.NewModifyProcessCanNotEditField(old)
			convey.So(isSame, convey.ShouldBeFalse)
			convey.So(field, convey.ShouldEqual, "ProgressiveInfo")
		})
		convey.Convey("old 为 nil：默认放过", func() {
			cur := *old
			isSame, _ := cur.NewModifyProcessCanNotEditField(nil)
			convey.So(isSame, convey.ShouldBeTrue)
		})
	})
}

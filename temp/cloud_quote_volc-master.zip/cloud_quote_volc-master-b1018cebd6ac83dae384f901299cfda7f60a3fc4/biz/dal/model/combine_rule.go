package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type CombineRule struct {
	framework.BaseDB
	RuleType             constants.CombineRuleType
	TemplateSolutionId   int64
	TradeProduct         string
	TradeSolutionName    string
	TradeSolutionVersion string
	CreatorAccountId     string
}

func (m *CombineRule) TableName() string {
	return "combine_rule"
}

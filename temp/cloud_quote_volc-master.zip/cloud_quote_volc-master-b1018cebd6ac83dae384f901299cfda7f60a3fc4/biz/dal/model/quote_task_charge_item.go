package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

//QuoteTaskChargeItem 变价任务计费项表
type QuoteTaskChargeItem struct {
	framework.BaseDB
	CreatorAccountID      string
	QuoteTaskID           int64
	TradeProduct          string
	TradeProductName      string
	ProductDepartmentName string
	SecondaryProductLine  string
	ActivationType        int
	PrePayTypeCode        string
	PrePayTypeName        string
	ConfigCategory        string
	ConfigCode            string
	ConfigName            string
	SellingMode           string
	ChargeItemTag         string
	ChargeMethodCode      string
	ChargeMethodName      string
	RegionCode            string
	RegionName            string
	ChargeUnitCode        string
	ChargeUnitName        string
	PriceFactorCode       string
	PriceFactorName       string
	ChargeItemCode        string
	Discount              string
	PriceInfoSnapshot     string
	PriceVersion          string
}

func (m *QuoteTaskChargeItem) TableName() string {
	return "quote_task_charge_item"
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type LarkApprovalInstance struct {
	framework.BaseDB
	EntityId           int64                     //审批主体id
	FormData           string                    //表单参数原始数据
	BizParam           string                    //飞书审批表单参数
	InstanceStatus     int                       //审批实例状态：-1:申请中、0:审批中、1:已通过、2:已拒绝、3:已撤回、4:已删除、5:已撤销
	FormCode           string                    //飞书审批表单编码
	InstanceID         string                    //审批中心审批编号
	ApprovalInstanceId string                    //飞书表单审批实例ID
	ApprovalLink       string                    //飞书表单url
	ApplicantEmail     string                    //申请人邮箱
	CurrentAssignee    string                    //当前处理人
	ApplicationType    constants.ApplicationType //申请类型
	CallbackContent    string                    //飞书回调数据
	TotalMinutes       int64                     //总用时(分钟)
	SerialNumber       string                    //飞书审批单编号
}

func (r *LarkApprovalInstance) TableName() string {
	return "lark_approval_instance"
}

// GenQuoteOAApplication 转换报价审批单
func (r *LarkApprovalInstance) GenQuoteOAApplication() *OaApplication {
	if r.ApplicationType != constants.QuoteApply &&
		r.ApplicationType != constants.ApplicationTypeConfigListApply &&
		r.ApplicationType != constants.ChangeDiscountQuoteApply &&
		r.ApplicationType != constants.InnerQuoteApply &&
		r.ApplicationType != constants.ProjectBasedQuoteApply {
		return nil
	}
	return &OaApplication{
		BaseDB: framework.BaseDB{
			Id:          r.Id,
			CreatedTime: r.CreatedTime,
			UpdatedTime: r.UpdatedTime,
		},
		QuoteID:           r.EntityId,
		BizParam:          r.BizParam,
		AuditStatus:       constants.LarkStatusToOaStatus(r.InstanceStatus),
		FormCode:          r.FormCode,
		FormInstanceID:    r.InstanceID,
		FormInstanceUrl:   r.ApprovalLink,
		ProcessInstanceID: r.ApprovalInstanceId,
		ApplicantID:       0,
		CurrentAssignee:   r.CurrentAssignee,
		ApplicationType:   string(r.ApplicationType),
		CallbackContent:   r.CallbackContent,
		TotalMinutes:      r.TotalMinutes,
	}
}

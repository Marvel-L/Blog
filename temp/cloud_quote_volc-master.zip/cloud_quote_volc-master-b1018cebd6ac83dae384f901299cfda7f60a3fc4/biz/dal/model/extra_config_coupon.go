package model

import (
	"fmt"
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// CouponConfigDB 返券配置
type CouponConfigDB struct {
	framework.BaseDB
	CouponType              int                            `gorm:"column:coupon_type;default:0;NOT NULL"`                // 代金券类型
	RebateCouponWay         int                            `gorm:"column:rebate_coupon_way;default:0;NOT NULL"`          // 返券方式：按消费金额、分期、其他
	ApplySource             int                            `gorm:"column:apply_source;default:0;NOT NULL"`               // 申请来源：1 费用中心后台 2 CRM系统
	CouponUsage             string                         `gorm:"column:coupon_usage;NOT NULL"`                         // 用途标签："1,2,3" 取填写表单“适用场景”
	OpportunityNumber       string                         `gorm:"column:opportunity_number;NOT NULL"`                   // 商机编号
	OpportunityName         string                         `gorm:"column:opportunity_name;NOT NULL"`                     // 商机名称
	OpportunityCustomerName string                         `gorm:"column:opportunity_customer_name;NOT NULL"`            // 商机所属客户名称
	Applicant               string                         `gorm:"column:applicant;NOT NULL"`                            // 申请人邮箱
	ApplicantDepartment     string                         `gorm:"column:applicant_department;NOT NULL"`                 // 申请人所属行业
	Remark                  string                         `gorm:"column:remark"`                                        // 备注信息
	EnableBalanceAlert      int                            `gorm:"column:enable_balance_alert;default:0;NOT NULL"`       // 是否提醒：0 不需要提醒，1 需要提醒。默认 0
	DisableInnerExpireAlert int                            `gorm:"column:disable_inner_expire_alert;default:0;NOT NULL"` // 是否关闭券到期内部提醒 0 不关闭提醒 1 关闭提醒
	BalanceAlertThreshold   float64                        `gorm:"column:balance_alert_threshold;NOT NULL"`              // 余额不足提醒百分比，取整数,10代表10%
	CouponAlarmMembers      string                         `gorm:"column:coupon_alarm_members;NOT NULL"`                 // 关注人列表，邮箱列表
	TriggerInfo             string                         `gorm:"column:trigger_info"`                                  // 返券配置
	OrderTypeLimit          string                         `gorm:"column:order_type_limit;NOT NULL"`                     // 适用订单类型：新购、转正、更配、续费，支持多选
	ValidTimeType           int                            `gorm:"column:valid_time_type;default:0;NOT NULL"`            // 有效期类型：1 指定日期 2 指定天数
	ValidBeginTime          time.Time                      `gorm:"column:valid_begin_time;NOT NULL"`                     // 有效开始时间
	ValidEndTime            time.Time                      `gorm:"column:valid_end_time;NOT NULL"`                       // 有效结束时间
	ValidDays               int                            `gorm:"column:valid_days;NOT NULL"`                           // 获取后n天有效
	UsageLimit              int                            `gorm:"column:usage_limit;default:0;NOT NULL"`                // 使用次数 1 单次使用  2 多次使用
	AmountLimit             float64                        `gorm:"column:amount_limit;default:0;NOT NULL"`               // 满x元可用
	PayTypeLimit            string                         `gorm:"column:pay_type_limit;NOT NULL"`                       // 付费方式：pre/post/all，多个
	Creator                 string                         `gorm:"column:creator;NOT NULL"`                              // 创建人邮箱
	AccountID               string                         `gorm:"column:account_id;NOT NULL"`                           // 客户账号，多账号逗号分割
	AccumulateType          string                         `gorm:"column:accumulate_type;NOT NULL"`                      // 累计类型:single-独立累计,all-多账号合并累计
	CopyFrom                int64                          `gorm:"column:copy_from;default:0;NOT NULL"`                  // 补充协议场景原配置ID
	ChangeFrom              int64                          `gorm:"column:change_from;default:0;NOT NULL"`                // 变更场景原配置ID
	BillCaliber             int                            `gorm:"column:bill_caliber;default:0;NOT NULL"`               // 账单金额统计口径：0-应付金额，1-原价，2-折后账单金额
	RebatePeriod            int                            `gorm:"column:rebate_period;default:1;NOT NULL"`              // 返券周期（月）
	RefreshType             int                            `gorm:"column:refresh_type;default:0;NOT NULL"`               // 刷数类型：0-未刷数，1-刷数新增，2-刷数废弃
	RuleValidityInfo        string                         `gorm:"column:rule_validity_info"`                            // 规则有效期信息JSON
	CapInfo                 string                         `gorm:"column:cap_info"`                                      // 返券封顶信息JSON
	RebateThresholdType     int                            `gorm:"column:rebate_threshold_type;default:0;NOT NULL"`      // 返券门槛类型：0-未知，1-有门槛，2-无门槛
	ProductLimits           []*CouponConfigProductsLimitDB `gorm:"-"`                                                    //
	SnapshotFrom            int64                          `gorm:"column:snapshot_from;default:0;NOT NULL"`              // 快照来源代金券配置ID；非快照数据为0
}

func (m *CouponConfigDB) TableName() string {
	return "extra_config_coupon"
}

func (m *CouponConfigDB) Clone() *CouponConfigDB {
	raw := *m
	raw.Id = 0
	raw.SnapshotFrom = 0
	var newProductList []*CouponConfigProductsLimitDB
	for _, product := range m.ProductLimits {
		newProduct := product.Clone()
		newProduct.ConfigID = 0
		newProductList = append(newProductList, newProduct)
	}
	raw.ProductLimits = newProductList
	return &raw
}

type CouponConfigDBList []*CouponConfigDB

// CouponConfigProductsLimitDB 代金券申请适用商品表
type CouponConfigProductsLimitDB struct {
	ID                  uint64    `gorm:"column:id;primary_key;AUTO_INCREMENT"`                   // 自增id
	ConfigID            int64     `gorm:"column:config_id;NOT NULL"`                              // 返券配置ID
	BillingMethod       string    `gorm:"column:billing_method;NOT NULL"`                         // 计费方式。例如：yearly, monthly, daily, once_pre, once_monthly 等等
	Product             string    `gorm:"column:product;NOT NULL"`                                // 商品code
	ZhName              string    `gorm:"column:zh_name;NOT NULL"`                                // 商品名称
	Configuration       string    `gorm:"column:configuration;NOT NULL"`                          // 商品配置（云服务配置、套餐包次数等）
	ConfigurationName   string    `gorm:"column:configuration_name;NOT NULL"`                     // 商品配置名称
	ChildProductCode    string    `gorm:"column:child_product_code;NOT NULL"`                     // 子产品code
	BelongingDepartment string    `gorm:"column:belonging_department;NOT NULL"`                   // 子产品所属团队
	ConfigurationType   int8      `gorm:"column:configuration_type;NOT NULL"`                     // 使用商品配置类型（代金券 v2.1 新增） 0: 未知类型（兼容旧逻辑） 1: 全部配置 2: 全部预付配置 3: 全部后付配置 4: 指定预付配置
	TimeLimitLower      int32     `gorm:"column:time_limit_lower;NOT NULL"`                       // 购买时长限制下限，-1 表示不限制，单位取决于 billing_method（代金券 v2.1 改名，相当于旧版接口的 TimeLimit）
	TimeLimitUpper      int32     `gorm:"column:time_limit_upper;NOT NULL"`                       // 购买时长限制上限，-1 表示不限制，单位取决于 billing_method（代金券 v2.1 新增）
	CanPrePay           int8      `gorm:"column:can_pre_pay;NOT NULL"`                            // TODO 目前未使用。配置项是否支持预付费
	CreatedTime         time.Time `gorm:"column:created_time;default:CURRENT_TIMESTAMP;NOT NULL"` // 创建时间
	UpdatedTime         time.Time `gorm:"column:updated_time;default:CURRENT_TIMESTAMP;NOT NULL"` // 更新时间
	Status              int       `gorm:"column:status;default:0;NOT NULL"`                       // 状态
	ChargeItemType      int       `gorm:"column:charge_item_type;default:0;NOT NULL"`             // 计费项类型 0 全部计费项 1 指定计费项
	ChargeItemCode      string    `gorm:"column:charge_item_code;NOT NULL"`                       // 计费项编号（ChargeItemType=1 时必传）
}

func (c *CouponConfigProductsLimitDB) TableName() string {
	return "extra_config_coupon_product_limit"
}

type CouponConfigProductsLimitDBList []*CouponConfigProductsLimitDB

func (c *CouponConfigProductsLimitDB) Clone() *CouponConfigProductsLimitDB {
	raw := *c
	raw.ID = 0
	return &raw
}

func (c *CouponConfigProductsLimitDB) ValueKey() string {
	return fmt.Sprintf("%s%s%s%s%s%s%d%s%d%s%d%s%d%s%d%s%s",
		c.BillingMethod, constants.Separator,
		c.Product, constants.Separator,
		c.Configuration, constants.Separator,
		c.ConfigurationType, constants.Separator,
		c.TimeLimitLower, constants.Separator,
		c.TimeLimitUpper, constants.Separator,
		c.CanPrePay, constants.Separator,
		c.ChargeItemType, constants.Separator,
		c.ChargeItemCode,
	)
}

func (m *CouponConfigDB) GetTriggerInfo() (*TriggerInfo, error) {
	triggerInfo, err := util.ParseJsonStr[*TriggerInfo](m.TriggerInfo)
	return triggerInfo, err
}

func (m *CouponConfigDB) GetRuleValidityInfo() (*RuleValidityInfo, error) {
	info, err := util.ParseJsonStr[*RuleValidityInfo](m.RuleValidityInfo)
	return info, err
}

func (m *CouponConfigDB) GetCapInfo() (*CapInfo, error) {
	info, err := util.ParseJsonStr[*CapInfo](m.CapInfo)
	return info, err
}

// RuleValidityInfo 规则有效期信息
type RuleValidityInfo struct {
	Type       int    // 规则有效期类型：0-跟随合同有效期 1-指定月份范围（按月）
	BeginMonth string // 规则有效期开始月份（yyyy-mm），type=1时必填
	EndMonth   string // 规则有效期结束月份（yyyy-mm），type=1时必填
}

// CapInfo 返券封顶信息
type CapInfo struct {
	Enabled     int     // 返券金额是否封顶：0-否 1-是
	OnceAmount  float64 // 单次封顶金额（>=0，0 表示不封顶）
	TotalAmount float64 // 累计封顶金额（>=0，0 表示不封顶）
}

type TriggerInfo struct {
	TotalAmount                  float64    // 预计返券金额 => 多账号代金券总额
	SingleAmount                 float64    // 单账号代金券总额
	Remark                       string     // 返券说明 限制200字
	ConsumeRebateProductList     string     // 纳入金额累计的商品信息列表
	QuoteItemIDList              []int64    // 报价项ID列表
	StatConsumeRebateProductList string     // 统计商品：门槛/档位命中-计算商品/计算报价项，用于返券金额折分与重量
	StatQuoteItemIDList          []int64    // 统计报价项：门槛/档位命中-计算商品/计算报价项，用于返券金额折分与重量
	Triggers                     []*Trigger // 条件列表
}

type Trigger struct {
	ProgressiveAmount float64             // 累计金额满x元
	Amount            float64             // 代金券面额
	RebateRatio       float64             // 返券比例
	Quantity          int                 // 代金券数量
	CouponOrder       int                 // 第x张，从1开始，<=20
	DaysAfterArchived int                 // 发券时间-合同归档后第x天
	ProgressiveGroups []*ProgressiveGroup //
}

type ProgressiveGroup struct {
	AccountID int64   // 账号ID
	Amount    float64 // 代金券面额
	Quantity  int     // 代金券数量
}

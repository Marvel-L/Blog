package model

import (
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// QuoteSubTask 报价子任务
type QuoteSubTask struct {
	framework.BaseDB
	CreatorAccountID          string
	QuoteTaskID               int64
	CustomerAccountID         string
	ContractCode              string
	PriceValidPeriodStartTime time.Time
	PriceValidPeriodEndTime   time.Time
	QuoteID                   int64
	SubTaskStatus             string
	SubTaskMsg                string
	QuoteNotes                string    // 变价审批原因
	ContractValidStartTime    time.Time // 合同有效期开始时间
}

func (m *QuoteSubTask) TableName() string {
	return "quote_sub_task"
}

func (m *QuoteSubTask) SubTaskCompleted() bool {
	return m.SubTaskStatus == multienv.SubTaskStatusFailed || m.SubTaskStatus == multienv.SubTaskStatusSuccessful
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

// TemplateItemValue 报价项目值
type TemplateItemValue struct {
	framework.BaseDB
	TemplateID            int64
	TemplateItemID        int64
	TemplateItemValue     string
	FormSchemaID          int64
	FormSchemaKey         string
	CreatorAccountID      string
	FormSchemaDisplay     string
	FormSchemaAttrType    string
	OptionEnumDescription string
}

func (m *TemplateItemValue) TableName() string {
	return "template_item_value"
}

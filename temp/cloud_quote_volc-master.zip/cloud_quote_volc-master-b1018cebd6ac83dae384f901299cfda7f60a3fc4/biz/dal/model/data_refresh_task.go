package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

// DataRefreshTask 报价刷数任务
type DataRefreshTask struct {
	framework.BaseDB
	CreatorAccountID string
	QuoteID          int64
	ContractNo       string
	BizScene         string
	ItemID           int64
	OpType           string
	TaskStatus       string
}

func (m *DataRefreshTask) TableName() string {
	return "data_refresh_task"
}

type DataRefreshTaskResp struct {
	DataRefreshTaskID int64
	CreatedTime       string
	UpdatedTime       string
	CreatorAccountID  string
	QuoteID           int64
	ContractNo        string
	BizScene          string
	ItemID            int64
	OpType            string
	TaskStatus        string
}

func (m *DataRefreshTask) GenResp() *DataRefreshTaskResp {
	return &DataRefreshTaskResp{
		DataRefreshTaskID: m.Id,
		CreatedTime:       util.FormatDateTimeWithZone(m.CreatedTime),
		UpdatedTime:       util.FormatDateTimeWithZone(m.UpdatedTime),
		CreatorAccountID:  m.CreatorAccountID,
		QuoteID:           m.QuoteID,
		ContractNo:        m.ContractNo,
		BizScene:          m.BizScene,
		ItemID:            m.ItemID,
		OpType:            m.OpType,
		TaskStatus:        m.TaskStatus,
	}
}

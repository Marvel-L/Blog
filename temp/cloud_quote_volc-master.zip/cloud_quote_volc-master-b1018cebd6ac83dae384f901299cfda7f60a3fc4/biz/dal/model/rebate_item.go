package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/shopspring/decimal"
)

// RebateItem 报价返佣信息表
type RebateItem struct {
	framework.BaseDB
	QuoteID             int64
	QuoteItemID         int64
	RebateLevelType     decimal.Decimal
	IsPerformanceSelect int
	CreatorAccountId    string
	SupportRebate       string
	IsRebateWritten     int // 是否写入过返佣比例 0 否， 1 是
}

type RebateItemList []*RebateItem

func (m *RebateItem) TableName() string {
	return "quote_rebate_item"
}

func (m *RebateItem) Clone() *RebateItem {
	raw := *m
	raw.Id = 0
	return &raw
}

type RebateItemResp struct {
	ID                  int64
	QuoteID             int64
	QuoteItemID         int64
	RebateLevelType     decimal.Decimal
	IsPerformanceSelect int
	CreatorAccountId    string
	SupportRebate       string
	IsRebateWritten     int
}

func (m *RebateItem) GenResp() *RebateItemResp {
	return &RebateItemResp{
		ID:                  m.Id,
		QuoteID:             m.QuoteID,
		QuoteItemID:         m.QuoteItemID,
		RebateLevelType:     m.RebateLevelType,
		IsPerformanceSelect: m.IsPerformanceSelect,
		CreatorAccountId:    m.CreatorAccountId,
		SupportRebate:       m.SupportRebate,
		IsRebateWritten:     m.IsRebateWritten,
	}
}

func (l RebateItemList) GenResp() []*RebateItemResp {
	if len(l) == 0 {
		return make([]*RebateItemResp, 0)
	}

	var ret []*RebateItemResp
	for _, rebate := range l {
		ret = append(ret, rebate.GenResp())
	}
	return ret
}

package model

import (
	"encoding/json"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type QuoteItemCalculate struct {
	framework.BaseDB
	QuoteItemID                          int64
	QuoteID                              int64
	IncomeNoTax                          decimal.Decimal //公有云-预计金额，私有云-折后售卖金额-算价接口算回，非标品-一口价（固定单价价格）
	Cost                                 decimal.Decimal
	GrossMargin                          decimal.Decimal
	GrossMarginRate                      decimal.Decimal
	OriginalPrice                        decimal.Decimal //刊例价售卖金额-算价接口算回
	RealDiscount                         decimal.Decimal //实际折扣-折后售卖金额/刊例价售卖金额
	UnitPrice                            decimal.Decimal //刊例价单价-刊例价售卖金额/(数量*时长)
	SingleCost                           decimal.Decimal //单位目标成本-商品提供（计费项维度）
	TotalCost                            decimal.Decimal //总目标成本-成本毛销算回
	ProfitRate                           decimal.Decimal //利润率-成本毛销算回
	OutputTax                            decimal.Decimal //销项税-成本毛销算回
	ExceededDiscount                     decimal.Decimal //超额折扣-商品提供（计费项维度）
	ExceededDiscountPrice                decimal.Decimal //超额折扣价格-超额折扣*刊例价售卖金额
	TaxRate                              decimal.Decimal //税率-商品提供（商品维度）
	OriginalMarketPrice                  decimal.Decimal //市场价销售金额
	UnitMarketPrice                      decimal.Decimal //市场价单价（计算结果）
	ExceededDiscountMarketPrice          decimal.Decimal //超额折扣市场价
	UnitCost                             string          //单位目标成本-商品提供（计费项维度）
	FactoryPrice                         string          //出厂价-商品提供（计费项维度）
	LatestResourcePrice                  string          //最新资源价-商品提供（计费项维度）
	TotalFactoryPrice                    decimal.Decimal //总出厂价算回
	FactoryPriceProfitRate               decimal.Decimal //出厂价利润率-成本毛销算回
	ProfitRateSpecialStatus              int             //利润率特殊状态：0-正常，1-百分百返券导致不可计算，2-其他原因导致不可计算
	TotalLatestResourcePrice             decimal.Decimal //总最新资源价-成本毛销算回
	LatestResourcePriceProfitRate        decimal.Decimal //最新资源价利润率-成本毛销算回
	HistoricalAvgCostRate                string          //历史平均成本率-成本毛销算回
	HistoricalAvgFactoryPriceRate        string          //历史平均出厂价率-成本毛销算回
	HistoricalAvgLatestResourcePriceRate string          //历史平均最新资源价率-成本毛销算回
	TotalCouponAmount                    decimal.Decimal // 综合返券金额
	TotalCouponRatio                     decimal.Decimal // 综合返券比例
	TotalDiscount                        decimal.Decimal // 综合折扣（仅公有云报价项&系统自动生成交付项有，私有云、非标品没有）
	RebateAmount                         decimal.Decimal // 返佣金额
	TotalEstimatedIncome                 decimal.Decimal // 综合预计金额（仅公有云报价项&系统自动生成交付项有，私有云、非标品没有）
}

func (qic *QuoteItemCalculate) TableName() string {
	return "quote_item_calculate"
}

func (qic *QuoteItemCalculate) GenResp() *QuoteItemCalculateResp {
	return &QuoteItemCalculateResp{
		QuoteItemID:                          qic.QuoteItemID,
		QuoteID:                              qic.QuoteID,
		IncomeNoTax:                          qic.IncomeNoTax,
		Cost:                                 qic.Cost,
		GrossMargin:                          qic.GrossMargin,
		GrossMarginRate:                      qic.GrossMarginRate,
		OriginalPrice:                        qic.OriginalPrice,
		RealDiscount:                         qic.RealDiscount,
		UnitPrice:                            qic.UnitPrice,
		SingleCost:                           qic.SingleCost,
		TotalCost:                            qic.TotalCost,
		ProfitRate:                           qic.ProfitRate,
		OutputTax:                            qic.OutputTax,
		ExceededDiscount:                     qic.ExceededDiscount,
		ExceededDiscountPrice:                qic.ExceededDiscountPrice,
		TaxRate:                              qic.TaxRate,
		OriginalMarketPrice:                  qic.OriginalMarketPrice,
		UnitMarketPrice:                      qic.UnitMarketPrice,
		ExceededDiscountMarketPrice:          qic.ExceededDiscountMarketPrice,
		UnitCost:                             qic.GetUnitCost(),
		FactoryPrice:                         qic.GetFactoryPrice(),
		LatestResourcePrice:                  qic.GetLatestResourcePrice(),
		TotalFactoryPrice:                    qic.TotalFactoryPrice,
		FactoryPriceProfitRate:               qic.FactoryPriceProfitRate,
		ProfitRateSpecialStatus:              qic.ProfitRateSpecialStatus,
		TotalLatestResourcePrice:             qic.TotalLatestResourcePrice,
		LatestResourcePriceProfitRate:        qic.LatestResourcePriceProfitRate,
		HistoricalAvgCostRate:                qic.HistoricalAvgCostRate,
		HistoricalAvgFactoryPriceRate:        qic.HistoricalAvgFactoryPriceRate,
		HistoricalAvgLatestResourcePriceRate: qic.HistoricalAvgLatestResourcePriceRate,
		TotalEstimatedIncome:                 qic.TotalEstimatedIncome,
		TotalCouponAmount:                    qic.TotalCouponAmount,
		TotalCouponRatio:                     qic.TotalCouponRatio,
		TotalDiscount:                        qic.TotalDiscount,
		RebateAmount:                         qic.RebateAmount,
	}
}

type QuoteItemCalculateResp struct {
	QuoteItemID                          int64
	QuoteID                              int64
	IncomeNoTax                          decimal.Decimal //折后售卖金额-算价接口算回
	IncomeNoTaxSystem                    decimal.Decimal //系统计算预计金额
	Cost                                 decimal.Decimal
	GrossMargin                          decimal.Decimal
	GrossMarginRate                      decimal.Decimal
	OriginalPrice                        decimal.Decimal         //刊例价售卖金额-算价接口算回
	RealDiscount                         decimal.Decimal         //实际折扣-折后售卖金额/刊例价售卖金额
	UnitPrice                            decimal.Decimal         //刊例价单价-刊例价售卖金额/(数量*时长)
	SingleCost                           decimal.Decimal         //单位目标成本-商品提供（计费项维度）
	TotalCost                            decimal.Decimal         //总目标成本-成本毛销算回
	ProfitRate                           decimal.Decimal         //利润率-成本毛销算回
	OutputTax                            decimal.Decimal         //销项税-成本毛销算回
	ExceededDiscount                     decimal.Decimal         //超额折扣-商品提供（计费项维度）
	ExceededDiscountPrice                decimal.Decimal         //超额折扣价格-超额折扣*刊例价售卖金额
	TaxRate                              decimal.Decimal         //税率-商品提供（商品维度）
	OriginalMarketPrice                  decimal.Decimal         //市场价销售金额
	UnitMarketPrice                      decimal.Decimal         //市场价单价（计算结果）
	ExceededDiscountMarketPrice          decimal.Decimal         //超额折扣市场价
	UnitCost                             *UnitCostObj            //单位目标成本
	FactoryPrice                         *FactoryPriceObj        // 出厂价
	LatestResourcePrice                  *LatestResourcePriceObj // 最新资源价
	TotalFactoryPrice                    decimal.Decimal         // 总出厂价
	FactoryPriceProfitRate               decimal.Decimal         // 出厂价利润率
	ProfitRateSpecialStatus              int                     // 利润率特殊状态：0-正常，1-百分百返券导致不可计算，2-其他原因导致不可计算
	TotalLatestResourcePrice             decimal.Decimal         // 总最新资源价
	LatestResourcePriceProfitRate        decimal.Decimal         // 最新资源价利润率
	HistoricalAvgCostRate                string                  //历史平均成本率-成本毛销算回
	HistoricalAvgFactoryPriceRate        string                  //历史平均出厂价率-成本毛销算回
	HistoricalAvgLatestResourcePriceRate string                  //历史平均最新资源价率-成本毛销算回
	TotalCouponAmount                    decimal.Decimal         // 综合返券金额
	TotalCouponRatio                     decimal.Decimal         // 综合返券比例
	TotalDiscount                        decimal.Decimal         // 综合折扣
	RebateAmount                         decimal.Decimal         // 返佣金额
	TotalEstimatedIncome                 decimal.Decimal         // 综合预计金额
}

func (qic *QuoteItemCalculate) GetSingleCostDisplay() string {
	if qic.SingleCost.Equal(decimal.NewFromInt(constants.NoCostValue)) {
		return ""
	}
	return qic.SingleCost.String()
}

func (qic *QuoteItemCalculate) GetTotalCostDisplay() string {
	if qic.TotalCost.Equal(decimal.NewFromInt(constants.NoCostValue)) {
		return ""
	}
	return qic.TotalCost.String()
}

func (qic *QuoteItemCalculate) GetUnitCost() *UnitCostObj {
	if qic.UnitCost == "" &&
		qic.SingleCost.Equal(decimal.NewFromInt(constants.NoCostValue)) {
		return nil
	}
	unitCostObj := &UnitCostObj{}
	if qic.UnitCost != "" {
		_ = json.Unmarshal([]byte(qic.UnitCost), unitCostObj)
	} else {
		unitCostObj.TotalCostFunction = constants.TotalCostFunctionFixedPrice
		unitCostObj.TotalCost = qic.SingleCost.String()
	}
	return unitCostObj
}
func (qic *QuoteItemCalculate) GetFactoryPrice() *FactoryPriceObj {
	if qic.FactoryPrice == "" {
		return nil
	}
	factoryPriceObj := &FactoryPriceObj{}
	_ = json.Unmarshal([]byte(qic.FactoryPrice), factoryPriceObj)
	return factoryPriceObj
}

func (qic *QuoteItemCalculate) GetLatestResourcePrice() *LatestResourcePriceObj {
	if qic.LatestResourcePrice == "" {
		return nil
	}
	latestResourcePriceObj := &LatestResourcePriceObj{}
	_ = json.Unmarshal([]byte(qic.LatestResourcePrice), latestResourcePriceObj)
	return latestResourcePriceObj
}

func (qic *QuoteItemCalculate) GetUnitCostStr() string {
	unitCost := qic.GetUnitCost()
	return util.GetJsonStr(unitCost)
}
func (qic *QuoteItemCalculate) GetFactoryPriceStr() string {
	factoryPrice := qic.GetFactoryPrice()
	return util.GetJsonStr(factoryPrice)
}

func (qic *QuoteItemCalculate) Clone() *QuoteItemCalculate {
	newItem := *qic
	newItem.Id = 0
	return &newItem
}

func (qic *QuoteItemCalculate) PriceCalReset() {
	// 算价会更新的字段，算价前进行重置
	qic.IncomeNoTax = decimal.Zero
	qic.OriginalPrice = decimal.Zero
	qic.RealDiscount = decimal.Zero
	qic.ExceededDiscountPrice = decimal.Zero
	qic.UnitPrice = decimal.Zero
	qic.OriginalMarketPrice = decimal.Zero
	qic.UnitMarketPrice = decimal.Zero
	qic.ExceededDiscountMarketPrice = decimal.Zero

	// 以下字段可重置也可不重置，暂时保留
	qic.SingleCost = decimal.NewFromInt(constants.NoCostValue)
	qic.UnitCost = ""
	qic.FactoryPrice = ""
	qic.LatestResourcePrice = ""
	qic.TotalCost = decimal.NewFromInt(constants.NoCostValue)
	qic.TotalFactoryPrice = decimal.NewFromInt(constants.NoCostValue)
	qic.TotalLatestResourcePrice = decimal.NewFromInt(constants.NoCostValue)
}

// ProfitCalReset 重置利润率测算相关数据
func (qic *QuoteItemCalculate) ProfitCalReset() {
	qic.SingleCost = decimal.NewFromInt(constants.NoCostValue)
	qic.UnitCost = ""
	qic.FactoryPrice = ""
	qic.LatestResourcePrice = ""
	qic.HistoricalAvgCostRate = ""
	qic.HistoricalAvgFactoryPriceRate = ""
	qic.HistoricalAvgLatestResourcePriceRate = ""
	qic.TotalCost = decimal.NewFromInt(constants.NoCostValue)
	qic.TotalFactoryPrice = decimal.NewFromInt(constants.NoCostValue)
	qic.TotalLatestResourcePrice = decimal.NewFromInt(constants.NoCostValue)
	qic.ProfitRate = decimal.Zero
	qic.FactoryPriceProfitRate = decimal.Zero
	qic.ProfitRateSpecialStatus = constants.ProfitRateSpecialStatusNormal
	qic.LatestResourcePriceProfitRate = decimal.Zero
	qic.OutputTax = decimal.Zero
}

// HasLatestResourcePriceData 判断是否存在最新资源价原始字段或测算结果。
func (qic *QuoteItemCalculate) HasLatestResourcePriceData() bool {
	if qic == nil {
		return false
	}
	return qic.LatestResourcePrice != "" ||
		!qic.TotalLatestResourcePrice.Equal(decimal.NewFromInt(constants.NoCostValue)) ||
		!qic.LatestResourcePriceProfitRate.IsZero() ||
		qic.HistoricalAvgLatestResourcePriceRate != ""
}

// ResetLatestResourcePrice 重置最新资源价原始字段及测算结果。
// 人工覆盖成本或重新拉取商品成本后，旧资源价不再可信，必须清理到 NoCostValue 哨兵值。
func (qic *QuoteItemCalculate) ResetLatestResourcePrice() {
	if qic == nil {
		return
	}
	qic.LatestResourcePrice = ""
	qic.TotalLatestResourcePrice = decimal.NewFromInt(constants.NoCostValue)
	qic.LatestResourcePriceProfitRate = decimal.Zero
	qic.HistoricalAvgLatestResourcePriceRate = ""
}

func (qic *QuoteItemCalculate) ShortOfCost() bool {
	return (qic.GetUnitCost() == nil && qic.HistoricalAvgCostRate == "") ||
		(qic.GetFactoryPrice() == nil && qic.HistoricalAvgFactoryPriceRate == "")
}

func (uc *UnitCostObj) String() string {
	return util.GetJsonStr(uc)
}

func (uc *UnitCostObj) GetUnitTargetCost() string {
	if uc.TotalCostFunction == constants.TotalCostFunctionFixedPrice {
		return uc.TotalCost
	} else {
		return uc.TotalCostInterval
	}
}

func (uc *FactoryPriceObj) String() string {
	return util.GetJsonStr(uc)
}

func (uc *FactoryPriceObj) GetFactoryPrice() string {
	if uc.ExFactoryPriceFunction == constants.TotalCostFunctionFixedPrice {
		return uc.ExFactoryPrice
	} else {
		return uc.ExFactoryPriceInterval
	}
}

func (p *LatestResourcePriceObj) String() string {
	return util.GetJsonStr(p)
}

func (p *LatestResourcePriceObj) GetLatestResourcePrice() string {
	if p.LatestResourcePriceFunction == constants.TotalCostFunctionFixedPrice {
		return p.LatestResourcePrice
	}
	return p.LatestResourcePriceInterval
}

func (qic *QuoteItemCalculate) GetEstimatedIncome() decimal.Decimal {
	if qic.IsCalculatedTotalDiscount() {
		return qic.TotalEstimatedIncome
	}
	return qic.IncomeNoTax
}

// IsCalculatedTotalDiscount 表示报价项是否已经计算过综合折扣。
func (qic *QuoteItemCalculate) IsCalculatedTotalDiscount() bool {
	if qic == nil {
		return false
	}
	return qic.TotalCouponAmount.GreaterThan(decimal.Zero) ||
		qic.RebateAmount.GreaterThan(decimal.Zero) ||
		qic.TotalEstimatedIncome.GreaterThan(decimal.Zero)
}

// UnitCostObj https://bytedance.larkoffice.com/docx/Dt5Td8OLNo5JxZxzIRiciyjlnPf
type UnitCostObj struct {
	TotalCostFunction        string // 目标成本类型
	TotalCostInterval        string // 目标成本阶梯-值部分
	TotalCostMeasureInterval string // 目标成本阶梯-阶梯部分
	TotalCost                string // 目标成本
}

// ExFactoryDiscountLineObj 出厂价折扣线信息  https://cloud.bytedance.net/bam/rd/eps.platform.cost/api_doc/show_doc?version=1.0.28&cluster=default&endpoint_id=1821779
type ExFactoryDiscountLineObj struct {
	InstanceSellingMode                       int    // 售卖模式
	ExFactoryPriceDiscountLineFunction        string // 出厂价折扣线类型
	ExFactoryPriceDiscountLineInterval        string // 出厂价折扣线-值部分
	ExFactoryPriceDiscountLineMeasureInterval string // 出厂价折扣线-阶梯部分
	ExFactoryPriceDiscountLine                string // 出厂价折扣线
}

// FactoryPriceObj https://bytedance.larkoffice.com/docx/Dt5Td8OLNo5JxZxzIRiciyjlnPf
type FactoryPriceObj struct {
	ExFactoryPriceFunction        string // 出厂价类型
	ExFactoryPriceInterval        string // 出厂价阶梯-值部分
	ExFactoryPriceMeasureInterval string // 出厂价阶梯-阶梯部分
	ExFactoryPrice                string // 出厂价
}

// LatestResourcePriceObj 保存商品侧返回的最新资源价原始字段。
type LatestResourcePriceObj struct {
	LatestResourcePriceFunction        string // 最新资源价类型
	LatestResourcePriceInterval        string // 最新资源价阶梯-值部分
	LatestResourcePriceMeasureInterval string // 最新资源价阶梯-阶梯部分
	LatestResourcePrice                string // 最新资源价
}

package model

import (
	"fmt"
	"time"

	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

type ApprovalRule struct {
	framework.BaseDB
	RuleType      string    // 审批规则类型
	RuleName      string    // 规则名称
	CreatorEmail  string    // 创建人邮箱
	RuleStatus    string    // 规则状态
	EffectiveTime time.Time // 生效时间
	RuleDetail    string    // 规则详情
}

// ApprovalRuleDetailDB RuleDetails数据库模型
type ApprovalRuleDetailDB struct {
	QuoteTypes                 []int                        // 报价类型列表
	TradeTypes                 []int                        // 客户类型列表
	FormField                  string                       // 表单字段
	MonitorType                string                       // 监控类型
	MonitorScope               string                       // 监控范围
	CustomScopes               []*MonitorScopeConfig        // 自定义范围列表
	QuoteMonitorConfig         *MonitorThresholdConfig      // 整单监控配置
	ProductLineMonitorConfigs  []*ProductLineMonitorConfig  // 产品线监控配置列表
	TradeProductMonitorConfigs []*TradeProductMonitorConfig // 商品监控配置列表
	// 多值聚合策略（产品线/商品维度）：提升到规则层，对该规则下所有监控对象统一生效
	IsIntervalMode    bool     // 是否区间模式（true=区间，false=老的单值比较）
	LowerCompareRules []string // 左侧/下界聚合策略列表；各条配置按自身 funcType（监控符号） 匹配其中一条
	UpperCompareRules []string // 右侧/上界聚合策略列表；各条配置按自身 funcType 匹配其中一条
}

// ApprovalRuleDetail 审批规则全量信息，业务逻辑使用
type ApprovalRuleDetail struct {
	RuleID     int64  // 规则编号
	RuleType   string // 审批规则类型
	RuleName   string // 规则名称
	RuleStatus string // 规则状态

	QuoteTypes                 []int                        // 报价类型列表
	TradeTypes                 []int                        // 客户类型列表
	FormField                  string                       // 表单字段
	MonitorType                string                       // 监控类型
	MonitorScope               string                       // 监控范围
	CustomScopes               []*MonitorScopeConfig        // 自定义范围列表
	QuoteMonitorConfig         *MonitorThresholdConfig      // 整单监控配置
	ProductLineMonitorConfigs  []*ProductLineMonitorConfig  // 产品线监控配置列表
	TradeProductMonitorConfigs []*TradeProductMonitorConfig // 商品监控配置列表
	// 多值聚合策略（产品线/商品维度）：提升到规则层，对该规则下所有监控对象统一生效
	IsIntervalMode    bool     // 是否区间模式（true=区间，false=老的单值比较）
	LowerCompareRules []string // 左侧/下界聚合策略列表；各条配置按自身 funcType 匹配其中一条
	UpperCompareRules []string // 右侧/上界聚合策略列表；各条配置按自身 funcType 匹配其中一条
}

func (r *ApprovalRule) TableName() string {
	return "approval_rule"
}

type ProductLineMonitorConfig struct {
	DepartmentName  string                  // 一级产品线名称
	BizLineName     string                  // 二级产品线名称
	ThresholdConfig *MonitorThresholdConfig // 监控阈值配置
}

type TradeProductMonitorConfig struct {
	ProductCode       string                  // 商品code
	ProductName       string                  // 商品名称
	ConfigurationCode string                  // 配置code
	ConfigurationName string                  // 配置名称
	ChargeItemCode    string                  // 计费项code
	ChargeItemName    string                  // 计费项名称
	ThresholdConfig   *MonitorThresholdConfig // 监控阈值配置
}

type MonitorScopeConfig struct {
	LeftValue       *MonitorValueConfig   // 监控左值
	MonitorFuncType string                // 监控函数
	RightValues     []*MonitorValueConfig // 监控右值列表
}

// MonitorThresholdConfig 监控阈值配置
// 非区间模式（ApprovalRuleDetail.IsIntervalMode=false）：语义为 监控对象 MonitorFuncType MonitorThreshold（如：利润率 < 10%）
// 区间模式（ApprovalRuleDetail.IsIntervalMode=true）：语义为 MonitorThreshold MonitorFuncType 监控对象 UpperFuncType UpperThreshold
//
//	例：10 <= 监控对象 < 20，表示 MonitorThreshold=10, MonitorFuncType="<=", UpperFuncType="<", UpperThreshold=20
//	左侧或右侧符号为空表示该侧无边界限制
type MonitorThresholdConfig struct {
	MonitorFuncType  string          // 监控函数（<, <=, >, >=, =）；区间场景下为左侧符号（< 或 <=，可为空表示无下界）
	MonitorThreshold decimal.Decimal // 监控阈值；区间场景下为左侧值（下界）
	MonitorExtra     string          // 监控额外参数（fixed_price/simple_discount）
	UpperFuncType    string          // 上界符号（< 或 <=，可为空表示无上界）
	UpperThreshold   decimal.Decimal // 上界阈值
}

type MonitorValueConfig struct {
	Value     string // 值
	ValueDesc string // 值描述
}

func (r *TradeProductMonitorConfig) GetChargeItemKey() string {
	return fmt.Sprintf("%s::%s::%s", r.ProductCode, r.ConfigurationCode, r.ChargeItemCode)
}

func (r *ApprovalRule) GetApprovalRuleDetail() (*ApprovalRuleDetail, error) {
	approvalRuleDetail := &ApprovalRuleDetail{
		RuleID:     r.Id,
		RuleType:   r.RuleType,
		RuleName:   r.RuleName,
		RuleStatus: r.RuleStatus,
	}
	approvalRuleDetailDB, err := util.ParseJsonStr[*ApprovalRuleDetailDB](r.RuleDetail)
	if err != nil {
		return nil, err
	}
	if approvalRuleDetailDB != nil {
		approvalRuleDetail.QuoteTypes = approvalRuleDetailDB.QuoteTypes
		approvalRuleDetail.TradeTypes = approvalRuleDetailDB.TradeTypes
		approvalRuleDetail.FormField = approvalRuleDetailDB.FormField
		approvalRuleDetail.MonitorType = approvalRuleDetailDB.MonitorType
		approvalRuleDetail.MonitorScope = approvalRuleDetailDB.MonitorScope
		approvalRuleDetail.CustomScopes = approvalRuleDetailDB.CustomScopes
		approvalRuleDetail.QuoteMonitorConfig = approvalRuleDetailDB.QuoteMonitorConfig
		approvalRuleDetail.ProductLineMonitorConfigs = approvalRuleDetailDB.ProductLineMonitorConfigs
		approvalRuleDetail.TradeProductMonitorConfigs = approvalRuleDetailDB.TradeProductMonitorConfigs
		approvalRuleDetail.IsIntervalMode = approvalRuleDetailDB.IsIntervalMode
		approvalRuleDetail.LowerCompareRules = approvalRuleDetailDB.LowerCompareRules
		approvalRuleDetail.UpperCompareRules = approvalRuleDetailDB.UpperCompareRules
	}
	return approvalRuleDetail, nil
}

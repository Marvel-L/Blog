package model

import (
	"time"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type DuplicatedDiscountSnapshot struct {
	framework.BaseDB
	DiscountID            uint64    // 合同价数据库唯一id
	DiscountCreatedTime   string    // 合同价创建时间
	DiscountUpdatedTime   time.Time // 合同价更新时间
	DiscountStatus        int       // 合同价状态
	QuoteID               int64
	Product               string // 商品 ECS
	ContractNo            string // 合同号 CN202206229231158
	ConfigurationCategory string // 配置分类
	Configuration         string // 配置(英文)
	ConfigurationName     string // 配置(中文)
	ChargeItemCode        string // 计费项名称
	BillingFunction       string // 计费方式(英文)
	BillingName           string // 计费方式(中文)
	BillingMethodCode     string // 计费方式(编码)
	RegionCode            string // 地域编码
	UnitPrice             string // 计费单元
	UnitPriceInterval     string //
	MeasureInterval       string //
	ChargeElementCode     string // 计费单元编码
	PriceFactor           string // 价格影响因子
	PayType               string //
	ExternalID            string //
	BeginTime             int64  // 开始时间
	EndTime               int64  // 结束时间
	Solution              string // 商品解决方案英文名
	SolutionVersion       string // 商品解决方案版本号
	SellingMode           string // 售卖模式
	Discount              string // 拼接多个字段形成的折扣信息
	Sequence              int64  // 合同价创建序列号
	CheckSource           int    // 报价类型：1-合同价，2-合同
	AccountID             string // 合同价账号
	OwnerID               string // OwnerID
	ChargeItemTag         string // 计费项分类
	ExcludeDetail         string // 排除明细
	SavingPlanDetail      string // 节省计划明细
	DiscountBusinessRole  int    // 合同价业务角色：0-标准合同价，1-抵扣合同价
	RelatedDiscountID     uint64 // 关联合同价ID：抵扣合同价时表示关联的SP包合同价ID
}

func (d *DuplicatedDiscountSnapshot) TableName() string {
	return "duplicated_discount_snapshot"
}

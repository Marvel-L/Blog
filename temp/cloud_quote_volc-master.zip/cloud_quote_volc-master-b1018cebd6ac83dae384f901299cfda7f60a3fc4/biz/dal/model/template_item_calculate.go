package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"github.com/shopspring/decimal"
)

type TemplateItemCalculate struct {
	framework.BaseDB
	TemplateId          int64
	TemplateItemId      int64
	IncomeNoTax         decimal.Decimal
	OriginalPrice       decimal.Decimal
	Cost                decimal.Decimal
	GrossMargin         decimal.Decimal
	GrossMarginRate     decimal.Decimal
	OriginalMarketPrice decimal.Decimal //市场价销售金额

}

func (m *TemplateItemCalculate) TableName() string {
	return "template_item_calculate"
}

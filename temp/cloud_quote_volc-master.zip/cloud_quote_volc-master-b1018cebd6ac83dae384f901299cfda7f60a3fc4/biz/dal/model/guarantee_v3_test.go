package model

import (
	"encoding/json"
	"reflect"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"context"
	"github.com/bytedance/mockey"
)

func TestGuaranteeV3LadderParsing(t *testing.T) {
	for _, tt := range []struct {
		name string
		raw  string
		fail bool
	}{
		{"strings", `["1","2.0000000001"]`, false},
		{"empty_array", `[]`, false},
		{"invalid_json", `[`, true},
		{"numbers", `[1,2]`, true},
		{"null_element", `["1",null]`, true},
		{"null_document", `null`, true},
		{"object", `{}`, true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			item := &GuaranteeItem{GuaranteeAmountMode: GuaranteeAmountModeUnequal, GuaranteeAmountLadder: &tt.raw}
			_, err := item.ParseGuaranteeAmountLadder()
			if (err != nil) != tt.fail {
				t.Fatalf("parse error = %v, want failure %v", err, tt.fail)
			}
			resp, err := item.GenResp()
			responseFail := tt.fail || tt.raw == "[]"
			if (err != nil) != responseFail || (responseFail && resp != nil) {
				t.Fatalf("response = %+v, error = %v", resp, err)
			}
			contractResp, err := item.GenRespV2()
			if (err != nil) != responseFail || (responseFail && contractResp != nil) {
				t.Fatalf("contract response = %+v, error = %v", contractResp, err)
			}
		})
	}
	var item *GuaranteeItem
	if ladder, err := item.ParseGuaranteeAmountLadder(); err != nil || ladder != nil {
		t.Fatalf("nil model: ladder=%v err=%v", ladder, err)
	}
	raw := "[]"
	for _, dirty := range []*GuaranteeItem{
		{GuaranteeAmountMode: GuaranteeAmountModeUnequal},
		{GuaranteeAmountLadder: &raw},
		{GuaranteeAmountMode: 2},
	} {
		if resp, err := dirty.GenResp(); err == nil || resp != nil {
			t.Fatalf("dirty amount mode accepted: %+v", dirty)
		}
	}
}

func TestGuaranteeV3HybridAdmission(t *testing.T) {
	mockey.PatchConvey("hybrid cloud preserves all other admission requirements", t, func() {
		mockey.Mock(config.GetSwitchIsOpenByName).Return(true).Build()
		mockey.Mock(config.GetOpenApiAppKeyCrm).Return("crm").Build()
		for _, tt := range []struct {
			name        string
			types       []constants.ProductType
			progressive bool
			want        bool
		}{
			{"public", []constants.ProductType{multienv.TradeProductTypeOnline}, false, true},
			{"hybrid", []constants.ProductType{multienv.TradeProductTypeOnline, multienv.TradeProductTypeOffline}, false, true},
			{"private", []constants.ProductType{multienv.TradeProductTypeOffline}, false, false},
			{"solution", []constants.ProductType{multienv.TradeProductTypeSolution}, false, false},
			{"progressive", []constants.ProductType{multienv.TradeProductTypeOnline}, true, false},
		} {
			raw, _ := json.Marshal(tt.types)
			quote := &Quote{AppAccountID: "crm", QuoteType: multienv.QuoteTypeNormal,
				TradeTypeCode: multienv.CustomerTypeCodeDirectSell, QuoteScene: multienv.SceneNew, QuoteRelatedProduct: string(raw)}
			if tt.progressive {
				quote.QuoteType = multienv.QuoteTypeProgressive
			}
			got, err := quote.SupportGuarantee(context.Background())
			if err != nil || got != tt.want {
				t.Fatalf("%s: got=%v err=%v want=%v", tt.name, got, err, tt.want)
			}
		}
	})
}

func TestGuaranteeV3ResponseAndClone(t *testing.T) {
	raw := `["1.0000000000","2.0000000001"]`
	item := &GuaranteeItem{
		GuaranteeAmountMode: GuaranteeAmountModeUnequal, GuaranteeAmountLadder: &raw,
		SameRuleCarryForward: SameRuleCarryForwardYes, CrossGroupCarryForwardID: 22,
		SnapshotFrom: 33,
	}
	resp, err := item.GenResp()
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(resp.GuaranteeAmountLadder, []string{"1.0000000000", "2.0000000001"}) ||
		resp.GuaranteeAmountMode != 1 || resp.SameRuleCarryForward != 1 || resp.CrossGroupCarryForwardID != 22 {
		t.Fatalf("fields were lost: %+v", resp)
	}
	contract, err := item.GenRespV2()
	if err != nil || !reflect.DeepEqual(contract.GuaranteeAmountLadder, resp.GuaranteeAmountLadder) {
		t.Fatalf("contract fields differ: %+v, %v", contract, err)
	}
	body, err := json.Marshal(contract)
	if err != nil {
		t.Fatal(err)
	}
	var wire struct {
		GuaranteeAmountMode      int
		GuaranteeAmountLadder    []string
		SameRuleCarryForward     int
		CrossGroupCarryForwardID int64
	}
	if err := json.Unmarshal(body, &wire); err != nil || wire.GuaranteeAmountMode != 1 ||
		wire.SameRuleCarryForward != 1 || wire.CrossGroupCarryForwardID != 22 ||
		!reflect.DeepEqual(wire.GuaranteeAmountLadder, resp.GuaranteeAmountLadder) {
		t.Fatalf("wire contract differs: %s, %v", body, err)
	}
	clone := item.Clone()
	if clone.Id != 0 || clone.SnapshotFrom != 0 || clone.GuaranteeAmountLadder == nil ||
		*clone.GuaranteeAmountLadder != raw || clone.CrossGroupCarryForwardID != 22 {
		t.Fatalf("clone fields differ: %+v", clone)
	}
	legacy, err := (&GuaranteeItem{}).GenResp()
	if err != nil || legacy.GuaranteeAmountLadder != nil || legacy.SameRuleCarryForward != 0 || legacy.GuaranteeAmountMode != 0 {
		t.Fatalf("legacy defaults differ: %+v, %v", legacy, err)
	}
}

package model

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"fmt"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

type Account struct {
	framework.BaseDB
	AccountID        string
	OtherID          string
	Name             string
	Username         string
	AvatarUrl        string
	AccountType      constants.AccountType
	CreatorID        int64
	CreatorAccountID string
}

type AccountResp struct {
	AccountID        string `json:",omitempty"`
	Name             string `json:"Name,omitempty"`
	Username         string `json:"Username,omitempty"`
	AvatarUrl        string
	AccountType      constants.AccountType
	CreatorAccountID string
	CreateDateTime   string
}

type MemberResp struct {
	ID int64
	//Role    RoleResp
	Account AccountResp
}

func (a *Account) TableName() string {
	return "account"
}

func (a *Account) GenResp() AccountResp {
	return *a.GenPtrResp()
}

func (a *Account) GenPtrResp() *AccountResp {
	return &AccountResp{
		AccountID:        a.AccountID,
		Name:             a.Name,
		Username:         a.Username,
		AvatarUrl:        a.AvatarUrl,
		AccountType:      a.AccountType,
		CreatorAccountID: a.CreatorAccountID,
		CreateDateTime:   util.FormatDateTimeWithZone(a.CreatedTime),
	}
}

func (a *Account) String() string {
	return fmt.Sprintf("%s (%s)", a.Name, a.AccountID)
}

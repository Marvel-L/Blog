package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

type QuoteItemValue struct {
	framework.BaseDB
	QuoteID               int64
	QuoteItemID           int64
	QuoteItemValue        string
	FormSchemaID          int64
	FormSchemaKey         string
	CreatorAccountID      string
	FormSchemaDisplay     string
	FormSchemaAttrType    string
	OptionEnumDescription string
	ExcludeDetail         string // 排除明细
}

func (r *QuoteItemValue) TableName() string {
	return "quote_item_value"
}

func (r *QuoteItemValue) Clone() *QuoteItemValue {
	clone := &QuoteItemValue{
		BaseDB:                r.BaseDB,
		QuoteID:               r.QuoteID,
		QuoteItemID:           r.QuoteItemID,
		QuoteItemValue:        r.QuoteItemValue,
		FormSchemaID:          r.FormSchemaID,
		FormSchemaKey:         r.FormSchemaKey,
		CreatorAccountID:      r.CreatorAccountID,
		FormSchemaDisplay:     r.FormSchemaDisplay,
		FormSchemaAttrType:    r.FormSchemaAttrType,
		OptionEnumDescription: r.OptionEnumDescription,
		ExcludeDetail:         r.ExcludeDetail,
	}
	clone.Id = 0
	return clone
}

func CloneQuoteItemValues(quoteItemValues []*QuoteItemValue, quoteItemId int64) []*QuoteItemValue {

	var ret []*QuoteItemValue
	for _, quoteItemValue := range quoteItemValues {
		clone := quoteItemValue.Clone()
		clone.QuoteItemID = quoteItemId
		ret = append(ret, clone)
	}
	return ret
}

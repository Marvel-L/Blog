package model

import "code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

type OperationLog struct {
	framework.BaseDB
	BizScene   int
	Operator   string
	EntityID   string
	Action     string
	Remark     string
	BackupData string
}

func (q *OperationLog) TableName() string {
	return "operation_log"
}

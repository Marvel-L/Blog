package model

import (
	"encoding/json"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"github.com/shopspring/decimal"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

const (
	CarryForwardNone = 0 // 不涉及
	CarryForwardYes  = 1 // 结转
	CarryForwardNo   = 2 // 不结转
)

const (
	// 金额模式和同规则结转均为持久化协议，零值需与数据库默认值保持一致。
	GuaranteeAmountModeEqual   = 0
	GuaranteeAmountModeUnequal = 1
	SameRuleCarryForwardNo     = 0
	SameRuleCarryForwardYes    = 1
)

// GuaranteeItem 报价单保底信息表
type GuaranteeItem struct {
	framework.BaseDB
	QuoteID                  int64
	RootGuaranteeID          int64 // root 规则为 0；子规则记录所属 root 保底规则 ID
	ParentGuaranteeID        int64 // root 规则为 0；子规则记录直接父保底规则 ID
	GuaranteeType            int
	GuaranteeAmount          decimal.Decimal
	GuaranteeTotalAmount     *decimal.Decimal // 后端公式计算或合同反写的规则维度保底总金额
	GuaranteeAmountMode      int
	GuaranteeAmountLadder    *string // 等额模式存储 NULL；非等额模式存储非空的周期金额 JSON 字符串数组
	GuaranteeRule            string
	RelatedQuoteItemId       string
	CreatorAccountId         string
	AccountId                string
	AccumulateType           string
	GuaranteeCategory        int // 保底类别，0-按合同有效期保底，1-周期保底
	GuaranteeInterval        int
	GuaranteeStartTime       string
	GuaranteeEndTime         string
	TotalSeats               *int64
	GuaranteeProductSeats    string
	CarryForward             int
	SameRuleCarryForward     int   // 0-不结转，1-按当前规则的相邻周期结转
	CrossGroupCarryForwardID int64 // 跨组结转目标根规则 ID，0 表示不跨组结转
	CopyFrom                 int64 // 补充协议规则来源，对应父单保底规则 ID
	ChangeFrom               int64 // 变更单规则来源，对应原单保底规则 ID
	SnapshotFrom             int64 // 审批中修改保底规则ID来源；非快照数据为 0
}

type GuaranteeProductSeat struct {
	TradeProduct string
	Seats        int64
}

func (m *GuaranteeItem) TableName() string {
	return "guarantee_item"
}

func (m *GuaranteeItem) Clone() *GuaranteeItem {
	raw := *m
	raw.Id = 0
	raw.SnapshotFrom = 0
	return &raw
}

type GuaranteeResp struct {
	GuaranteeItemID          int64
	QuoteID                  int64
	RootGuaranteeID          int64
	ParentGuaranteeID        int64
	GuaranteeType            int
	GuaranteeAmount          decimal.Decimal
	GuaranteeTotalAmount     *decimal.Decimal
	GuaranteeAmountMode      int
	GuaranteeAmountLadder    []string
	GuaranteeRule            string
	RelatedQuoteItemId       []int64
	AccountID                []string
	AccumulateType           string
	GuaranteeCategory        int
	GuaranteeInterval        int
	GuaranteeStartTime       string
	GuaranteeEndTime         string
	TotalSeats               *int64
	GuaranteeProductSeats    []GuaranteeProductSeat
	CarryForward             int
	SameRuleCarryForward     int
	CrossGroupCarryForwardID int64
	CopyFrom                 int64
	ChangeFrom               int64
	SnapshotFrom             int64
}
type GuaranteeRespV2 struct {
	GuaranteeItemID          int64
	QuoteID                  int64
	RootGuaranteeID          int64
	ParentGuaranteeID        int64
	GuaranteeType            int
	GuaranteeAmount          decimal.Decimal
	GuaranteeTotalAmount     *decimal.Decimal
	GuaranteeAmountMode      int
	GuaranteeAmountLadder    []string
	GuaranteeRule            string
	RelatedQuoteItemId       []int64
	AccountID                string
	AccumulateType           string
	GuaranteeCategory        int
	GuaranteeInterval        int
	GuaranteeStartTime       string
	GuaranteeEndTime         string
	TotalSeats               *int64
	GuaranteeProductSeats    []GuaranteeProductSeat
	CarryForward             int
	SameRuleCarryForward     int
	CrossGroupCarryForwardID int64
	CopyFrom                 int64
	ChangeFrom               int64
	SnapshotFrom             int64
}

func (m *GuaranteeItem) GenResp() (*GuaranteeResp, error) {
	ladder, err := m.responseGuaranteeAmountLadder()
	if err != nil {
		return nil, err
	}
	var relatedQuoteItemId []int64
	_ = json.Unmarshal([]byte(m.RelatedQuoteItemId), &relatedQuoteItemId)
	return &GuaranteeResp{
		GuaranteeItemID:          m.Id,
		QuoteID:                  m.QuoteID,
		RootGuaranteeID:          m.RootGuaranteeID,
		ParentGuaranteeID:        m.ParentGuaranteeID,
		GuaranteeType:            m.GuaranteeType,
		GuaranteeAmount:          m.GuaranteeAmount,
		GuaranteeTotalAmount:     m.GuaranteeTotalAmount,
		GuaranteeAmountMode:      m.GuaranteeAmountMode,
		GuaranteeAmountLadder:    ladder,
		GuaranteeRule:            m.GuaranteeRule,
		RelatedQuoteItemId:       relatedQuoteItemId,
		AccountID:                strings.Split(m.AccountId, ","),
		AccumulateType:           m.AccumulateType,
		GuaranteeCategory:        m.GuaranteeCategory,
		GuaranteeInterval:        m.GuaranteeInterval,
		GuaranteeStartTime:       m.GuaranteeStartTime,
		GuaranteeEndTime:         m.GuaranteeEndTime,
		TotalSeats:               m.TotalSeats,
		GuaranteeProductSeats:    m.GetGuaranteeProductSeats(),
		CarryForward:             m.CarryForward,
		SameRuleCarryForward:     m.SameRuleCarryForward,
		CrossGroupCarryForwardID: m.CrossGroupCarryForwardID,
		CopyFrom:                 m.CopyFrom,
		ChangeFrom:               m.ChangeFrom,
		SnapshotFrom:             m.SnapshotFrom,
	}, nil
}

func (m *GuaranteeItem) GenRespV2() (*GuaranteeRespV2, error) {
	ladder, err := m.responseGuaranteeAmountLadder()
	if err != nil {
		return nil, err
	}
	var relatedQuoteItemId []int64
	_ = json.Unmarshal([]byte(m.RelatedQuoteItemId), &relatedQuoteItemId)
	return &GuaranteeRespV2{
		GuaranteeItemID:          m.Id,
		QuoteID:                  m.QuoteID,
		RootGuaranteeID:          m.RootGuaranteeID,
		ParentGuaranteeID:        m.ParentGuaranteeID,
		GuaranteeType:            m.GuaranteeType,
		GuaranteeAmount:          m.GuaranteeAmount,
		GuaranteeTotalAmount:     m.GuaranteeTotalAmount,
		GuaranteeAmountMode:      m.GuaranteeAmountMode,
		GuaranteeAmountLadder:    ladder,
		GuaranteeRule:            m.GuaranteeRule,
		RelatedQuoteItemId:       relatedQuoteItemId,
		AccountID:                m.AccountId,
		AccumulateType:           m.AccumulateType,
		GuaranteeCategory:        m.GuaranteeCategory,
		GuaranteeInterval:        m.GuaranteeInterval,
		GuaranteeStartTime:       m.GuaranteeStartTime,
		GuaranteeEndTime:         m.GuaranteeEndTime,
		TotalSeats:               m.TotalSeats,
		GuaranteeProductSeats:    m.GetGuaranteeProductSeats(),
		CarryForward:             m.CarryForward,
		SameRuleCarryForward:     m.SameRuleCarryForward,
		CrossGroupCarryForwardID: m.CrossGroupCarryForwardID,
		CopyFrom:                 m.CopyFrom,
		ChangeFrom:               m.ChangeFrom,
		SnapshotFrom:             m.SnapshotFrom,
	}, nil
}

// ParseGuaranteeAmountLadder 严格解析阶梯 JSON，不将非法结构或空元素降级为空阶梯。
func (m *GuaranteeItem) ParseGuaranteeAmountLadder() ([]string, error) {
	if m == nil || m.GuaranteeAmountLadder == nil {
		return nil, nil
	}
	var values []*string
	if err := json.Unmarshal([]byte(*m.GuaranteeAmountLadder), &values); err != nil || values == nil {
		return nil, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底规则%d金额阶梯必须为JSON字符串数组").WithArgs(m.Id)
	}
	result := make([]string, len(values))
	for i, value := range values {
		if value == nil {
			return nil, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底规则%d金额阶梯不能包含空值").WithArgs(m.Id)
		}
		result[i] = *value
	}
	return result, nil
}

// responseGuaranteeAmountLadder 在响应序列化前校验金额模式、阶梯非空性及金额精度。
func (m *GuaranteeItem) responseGuaranteeAmountLadder() ([]string, error) {
	ladder, err := m.ParseGuaranteeAmountLadder()
	if err != nil {
		return nil, err
	}
	if (m.GuaranteeAmountMode == GuaranteeAmountModeEqual && m.GuaranteeAmountLadder != nil) ||
		(m.GuaranteeAmountMode == GuaranteeAmountModeUnequal && len(ladder) == 0) ||
		(m.GuaranteeAmountMode != GuaranteeAmountModeEqual && m.GuaranteeAmountMode != GuaranteeAmountModeUnequal) {
		return nil, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底规则%d金额模式与阶梯不一致").WithArgs(m.Id)
	}
	for _, value := range ladder {
		if _, err := ParseGuaranteeAmount(value); err != nil {
			return nil, err
		}
	}
	return ladder, nil
}

// ValidGuaranteeAmount 在任何比较/运算前限制指数，防止异常指数触发大整数扩展。
func ValidGuaranteeAmount(amount decimal.Decimal) bool {
	return amount.Exponent() >= -10 && amount.Exponent() <= 9 &&
		!amount.IsNegative() && amount.LessThan(decimal.New(1, 10))
}

func ParseGuaranteeAmount(value string) (decimal.Decimal, error) {
	amount, err := decimal.NewFromString(value)
	if err != nil || !ValidGuaranteeAmount(amount) {
		return decimal.Zero, errors.NewBizErrWithMsg(errors.CodeNGuaranteeRuleTreeInvalid, "保底金额必须为非负decimal(20,10)")
	}
	return amount, nil
}

func (m *GuaranteeItem) GetRelatedQuoteItemId() []int64 {
	relatedQuoteItemId, _ := util.ParseJsonStr[[]int64](m.RelatedQuoteItemId)
	return relatedQuoteItemId
}

func (m *GuaranteeItem) GetGuaranteeProductSeats() []GuaranteeProductSeat {
	guaranteeProductSeats, _ := util.ParseJsonStr[[]GuaranteeProductSeat](m.GuaranteeProductSeats)
	return guaranteeProductSeats
}

func (m *GuaranteeItem) GetGuaranteeProductSeatsMap() map[string]int64 {
	ret := map[string]int64{}
	for _, seat := range m.GetGuaranteeProductSeats() {
		ret[seat.TradeProduct] = seat.Seats
	}
	return ret
}

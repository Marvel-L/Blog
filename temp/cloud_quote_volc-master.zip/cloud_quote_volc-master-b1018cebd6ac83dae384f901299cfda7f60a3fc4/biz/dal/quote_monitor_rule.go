package dal

import (
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var QuoteMonitorRuleDao = &quoteMonitorRuleDao{}

type quoteMonitorRuleDao struct {
	baseDao
}

func (*quoteMonitorRuleDao) FindLastRuleByCondition(tx *gorm.DB, ruleID int64, condition framework.Condition) (*model.QuoteMonitorRule, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("rule_id = ? and status = 0", ruleID)
	ret := &model.QuoteMonitorRule{}
	err := sql.Order("id desc").Find(ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	if ret == nil || ret.Id == 0 {
		return nil, errors.NewRecordNotFoundErr("报价监控规则不存在，规则ID：%d").WithArgs(ruleID)
	}
	return ret, nil
}

func (*quoteMonitorRuleDao) FindRulesByCondition(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.QuoteMonitorRule, int64, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, errors.NewInternalDBError(err)
	}
	var ret []*model.QuoteMonitorRule
	err = sql.Order("rule_id desc, id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	if err != nil {
		return nil, 0, errors.NewInternalDBError(err)
	}
	return ret, total, nil
}

func (*quoteMonitorRuleDao) FindAllEffectiveRulesByRuleType(tx *gorm.DB, ruleType string) ([]*model.QuoteMonitorRule, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	sql = sql.Where("rule_type = ? and rule_status = ? and status = 0", ruleType, multienv.RuleStatusEffective)
	var ret []*model.QuoteMonitorRule
	err := sql.Order("id desc").Find(&ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return ret, nil
}

func (*quoteMonitorRuleDao) FindAllEffectiveRulesByBizCode(tx *gorm.DB, ruleType, bizCode string) ([]*model.QuoteMonitorRule, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	sql = sql.Where("rule_type = ? and biz_code = ? and rule_status = ? and status = 0", ruleType, bizCode, multienv.RuleStatusEffective)
	var ret []*model.QuoteMonitorRule
	err := sql.Order("id desc").Find(&ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return ret, nil
}

func (*quoteMonitorRuleDao) FindLastRuleByRuleID(tx *gorm.DB, ruleID int64) (*model.QuoteMonitorRule, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	sql = sql.Where("rule_id = ? and status = 0", ruleID)
	ret := &model.QuoteMonitorRule{}
	err := sql.Order("id desc").Find(ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	if ret == nil || ret.Id == 0 {
		return nil, errors.NewRecordNotFoundErr("报价监控规则不存在，规则ID：%d").WithArgs(ruleID)
	}
	return ret, nil
}

func (d *quoteMonitorRuleDao) SaveRule(tx *gorm.DB, ruleDB *model.QuoteMonitorRule) error {
	err := d.Save(tx, ruleDB, &model.QuoteMonitorRule{})
	if err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

func (*quoteMonitorRuleDao) FindChangingEffectiveRuleByRuleID(tx *gorm.DB, ruleID int64) (*model.QuoteMonitorRule, error) {
	sql := tx.Model(&model.QuoteMonitorRule{})
	sql = sql.Where("rule_id = ? and rule_status = ? and change_status = ? and status = 0", ruleID, multienv.RuleStatusEffective, multienv.ChangeStatusChanging)
	ret := &model.QuoteMonitorRule{}
	err := sql.Order("id desc").Find(ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	if ret == nil || ret.Id == 0 {
		return nil, errors.NewRecordNotFoundErr("变更中报价监控规则原生效规则不存在，规则ID：%d").WithArgs(ruleID)
	}
	return ret, nil
}

func (d *quoteMonitorRuleDao) UpdateRuleByID(tx *gorm.DB, id int64, updates map[string]interface{}) error {
	err := d.UpdateByCondition(tx, Condition{"id": id}, &model.QuoteMonitorRule{}, updates)
	if err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

func (d *quoteMonitorRuleDao) AbandonedRuleByID(tx *gorm.DB, id int64) error {
	updates := map[string]interface{}{
		"rule_status":    multienv.RuleStatusAbandoned,
		"status":         1,
		"effective_time": time.Time{},
	}
	return d.UpdateRuleByID(tx, id, updates)
}

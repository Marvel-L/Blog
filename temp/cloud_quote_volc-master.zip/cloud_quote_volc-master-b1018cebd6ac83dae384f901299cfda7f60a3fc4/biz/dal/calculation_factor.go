package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"gorm.io/gorm"
)

var CalculationFactorDao = &calculationFactorDao{}

type calculationFactorDao struct {
	baseDao
}

func (d *calculationFactorDao) FindFactorsByConditions(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.CalculationFactor, error) {
	sql := tx.Model(&model.CalculationFactor{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var ret []*model.CalculationFactor
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (d *calculationFactorDao) FindPageFactorsByConditions(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.CalculationFactor, int64, error) {
	sql := tx.Model(&model.CalculationFactor{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	var ret []*model.CalculationFactor
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *calculationFactorDao) FindFactorByID(tx *gorm.DB, factorID int64) (*model.CalculationFactor, error) {
	sql := tx.Model(&model.CalculationFactor{})
	sql = sql.Where("id = ? and status = 0", factorID)
	ret := &model.CalculationFactor{}
	err := sql.First(ret).Error
	return ret, err
}

func (d *calculationFactorDao) UpdateFactorStatusByIDs(tx *gorm.DB, ids []int64, factorStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": ids}, &model.CalculationFactor{}, map[string]interface{}{"factor_status": factorStatus})
}

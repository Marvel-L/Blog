package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var QuoteItemValueDao = &quoteItemValueDao{}

type quoteItemValueDao struct {
	baseDao
}

func (d *quoteItemValueDao) QuoteItemValueMapByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64) (map[int64][]*model.QuoteItemValue, error) {
	rows, err := d.findQuoteItemValuesByQuoteItemIDs(tx, quoteItemIDs)
	if err != nil {
		return nil, err
	}
	ret := map[int64][]*model.QuoteItemValue{}
	for _, row := range rows {
		ret[row.QuoteItemID] = append(ret[row.QuoteItemID], row)
	}
	return ret, nil
}

func (d *quoteItemValueDao) findQuoteItemValuesByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64) ([]*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_item_id in ? and status = 0", quoteItemIDs)
	var ret []*model.QuoteItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemValueDao) QuoteItemValueMapByQuoteItemIDsAndQuoteID(tx *gorm.DB, quoteItemIDs []int64, quoteID int64) (map[int64][]*model.QuoteItemValue, error) {
	rows, err := d.findQuoteItemValuesByQuoteItemIDsAndQuoteID(tx, quoteItemIDs, quoteID)
	if err != nil {
		return nil, err
	}
	ret := map[int64][]*model.QuoteItemValue{}
	for _, row := range rows {
		ret[row.QuoteItemID] = append(ret[row.QuoteItemID], row)
	}
	return ret, nil
}

func (d *quoteItemValueDao) findQuoteItemValuesByQuoteItemIDsAndQuoteID(tx *gorm.DB, quoteItemIDs []int64, quoteID int64) ([]*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_item_id in ? and status = 0 and quote_id = ?", quoteItemIDs, quoteID)
	var ret []*model.QuoteItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

// QuoteItemValueMapByQuoteItemIDsV2 quoteItemID -> []quoteItemValue
func (d *quoteItemValueDao) QuoteItemValueMapByQuoteItemIDsV2(tx *gorm.DB, quoteItemIDs []int64, quoteID int64) (map[int64][]*model.QuoteItemValue, error) {
	return d.QuoteItemValueMapByQuoteItemIDsAndQuoteID(tx, quoteItemIDs, quoteID)
}

func (d *quoteItemValueDao) findQuoteItemValuesByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.QuoteItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemValueDao) QuoteItemValueMapByQuoteID(tx *gorm.DB, quoteID int64) (map[int64][]*model.QuoteItemValue, error) {
	rows, err := d.findQuoteItemValuesByQuoteID(tx, quoteID)
	if err != nil {
		return nil, err
	}
	ret := map[int64][]*model.QuoteItemValue{}
	for _, row := range rows {
		ret[row.QuoteItemID] = append(ret[row.QuoteItemID], row)
	}
	return ret, nil
}

func (d *quoteItemValueDao) QuoteItemValuesByQuoteItemID(tx *gorm.DB, quoteItemID int64) ([]*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_item_id = ? and status = 0", quoteItemID)
	var ret []*model.QuoteItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemValueDao) QuoteItemValuesByQuoteItemIDsAndKey(tx *gorm.DB, quoteItemIDs []int64, formSchemaKey string) ([]*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_item_id in ? and form_schema_key = ? and status = 0", quoteItemIDs, formSchemaKey)
	var ret []*model.QuoteItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemValueDao) QuoteItemValuesByQuoteItemIDAndKey(tx *gorm.DB, quoteItemID int64, formSchemaKey string) (*model.QuoteItemValue, error) {
	sql := tx.Model(&model.QuoteItemValue{})
	sql = sql.Where("quote_item_id = ? and form_schema_key = ? and status = 0", quoteItemID, formSchemaKey)
	ret := &model.QuoteItemValue{}
	err := sql.First(ret).Error
	return ret, err
}

func (d *quoteItemValueDao) UpdateQuoteItemValueByIDs(tx *gorm.DB, quoteItemValueIDs []int64, quoteItemValue string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemValueIDs}, &model.QuoteItemValue{}, map[string]interface{}{
		"quote_item_value":        quoteItemValue,
		"option_enum_description": quoteItemValue,
	})
}

func (d *quoteItemValueDao) SoftDelete(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) error {
	condition := Condition{"quote_item_id": quoteItemIDs}
	condition["status"] = 0
	if quoteID > 0 {
		condition["quote_id"] = quoteID
	}
	return d.SoftDeleteData(tx, condition, &model.QuoteItemValue{})

}

func (d *quoteItemValueDao) DeleteValuesByItemID(tx *gorm.DB, quoteItemID int64) error {
	return tx.Where("quote_item_id = ? ", quoteItemID).Delete(&model.QuoteItemValue{}).Error
}

func (d *quoteItemValueDao) DeleteValuesByItemIDAndFormSchemaKey(tx *gorm.DB, quoteItemIDs []int64, formSchemaKey string) error {
	condition := Condition{"quote_item_id": quoteItemIDs, "form_schema_key": formSchemaKey, "status": 0}
	return d.SoftDeleteData(tx, condition, &model.QuoteItemValue{})
}

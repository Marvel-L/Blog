package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
	"fmt"
	"reflect"
	"strings"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/config"
	bgorm "code.byted.org/gopkg/gorm/v2"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

var (
	DBProxy *bgorm.DBProxy
)

type Condition map[string]interface{}

var FormSchemaMap map[string]map[string]*model.FormSchema

func Init(mc *config.QuoteApp) {
	var err error
	DBProxy, err = newDBClient(mc.WriteDB, mc.ReadDB...)
	if err != nil {
		panic(err)
	}
	tx := DBProxy.NewRequest(util.InitCtxWithLogID(logid.GenLogID()))
	FormSchemaMap = map[string]map[string]*model.FormSchema{}
	onlineFormSchema, err := FormSchemaDao.FindSchemaMapByScene(tx, constants.SchemaSceneOnlineStandard)
	if err != nil {
		panic(err)
	}
	offlineFormSchema, err := FormSchemaDao.FindSchemaMapByScene(tx, constants.SchemaSceneOfflineStandard)
	if err != nil {
		panic(err)
	}
	offlineNoStandardFormSchema, err := FormSchemaDao.FindSchemaMapByScene(tx, constants.SchemaSceneOfflineNoStandard)
	if err != nil {
		panic(err)
	}

	FormSchemaMap[util.GetMapKey(multienv.TradeProductDeploymentTypePublic, multienv.TradeProductStandardYes)] = onlineFormSchema
	FormSchemaMap[util.GetMapKey(multienv.TradeProductDeploymentTypePrivate, multienv.TradeProductStandardYes)] = offlineFormSchema
	FormSchemaMap[util.GetMapKey(multienv.TradeProductDeploymentTypePrivate, multienv.TradeProductStandardNo)] = offlineNoStandardFormSchema
}

// time_zone=+8:00
const basicDsn = "%s:%s@sd(%s)/%s?parseTime=True&loc=Local&time_zone=%s&%s"

func newDBClient(masterConf config.DBConf, slaveConfList ...config.DBConf) (*bgorm.DBProxy, error) {
	dbConnectionParamsStr := parseDsnParams(masterConf)

	timeZoneInfo := "%27%2B08%3A00%27"

	writerDsn := fmt.Sprintf(basicDsn,
		masterConf.UserName, masterConf.Password, masterConf.PSM, masterConf.DBName, timeZoneInfo, dbConnectionParamsStr)

	readerDsnList := make([]string, 0, len(slaveConfList))
	for _, slaveConf := range slaveConfList {
		readerDsnList = append(readerDsnList,
			fmt.Sprintf(basicDsn,
				slaveConf.UserName, slaveConf.Password, slaveConf.PSM, slaveConf.DBName, timeZoneInfo, dbConnectionParamsStr),
		)
	}

	dbProxy, err := bgorm.POpenWithConfig("bytedmysql", writerDsn, bgorm.Config{
		SkipDefaultTransaction: true,
		PrepareStmt:            true,
	}, readerDsnList...)
	if err != nil {
		return nil, err
	}
	//dbProxy.WithLogger(logs.DefaultLogger())
	dbProxy.WithIgnoreNotFoundErrLogger(logs.DefaultLogger())
	dbProxy.LogMode(true)
	return dbProxy, nil
}

func parseDsnParams(conf config.DBConf) string {
	query := make([]string, 0, 4)
	if !conf.UnUseGdprAuth {
		query = append(query, "use_gdpr_auth=true")
	}
	if conf.ConnectTimeout != "" {
		query = append(query, fmt.Sprintf("timeout=%s", conf.ConnectTimeout))
	}
	if conf.ReadTimeout != "" {
		query = append(query, fmt.Sprintf("readTimeout=%s", conf.ConnectTimeout))
	}
	if conf.WriteTimeout != "" {
		query = append(query, fmt.Sprintf("writeTimeout=%s", conf.WriteTimeout))
	}

	return strings.Join(query, "&")
}

type baseDao struct{}

func (baseDao) Save(tx *gorm.DB, data interface{}, tb schema.Tabler) error {
	return tx.Model(tb).Save(data).Error
}

func (baseDao) BatchSave(tx *gorm.DB, data interface{}, tb schema.Tabler, batchSize int) error {
	reflectValue := reflect.Indirect(reflect.ValueOf(data))
	switch reflectValue.Kind() {
	case reflect.Slice, reflect.Array:
		reflectLen := reflectValue.Len()
		for i := 0; i < reflectLen; i += batchSize {
			ends := i + batchSize
			if ends > reflectLen {
				ends = reflectLen
			}

			err := tx.Model(tb).Save(reflectValue.Slice(i, ends).Interface()).Error
			if err != nil {
				return err
			}
		}
	default:
		return tx.Model(tb).Save(data).Error
	}
	return nil
}

func (baseDao) SelectByCondition(tx *gorm.DB, condition Condition, tb schema.Tabler, ret interface{}) error {
	sql := tx.Model(tb)
	sql = framework.WhereMap(sql, condition)
	err := sql.Find(ret).Error
	return err
}

func (baseDao) UpdateByCondition(tx *gorm.DB, condition Condition, tb schema.Tabler, updates map[string]interface{}) error {
	sql := tx.Model(tb)
	sql = framework.WhereMap(sql, condition)
	return sql.Updates(updates).Error
}

func (d baseDao) SoftDeleteData(tx *gorm.DB, condition Condition, tb schema.Tabler) error {
	return d.UpdateByCondition(tx, condition, tb, map[string]interface{}{constants.DataStatusField: constants.DataDeleteStatus})
}

func (d baseDao) initDB(ctx context.Context, tx *gorm.DB) *gorm.DB {
	if tx != nil {
		return tx
	}
	return DBProxy.NewRequest(ctx)
}

func MakeFuzzQuery(s string) string {
	return "*" + s + "*"
}

// IsExceptionError 是否为预期外错误
func IsExceptionError(err error) bool {
	return err != nil && !errors.Is(err, gorm.ErrRecordNotFound)
}

package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var QuoteEventDao = &quoteEventDao{}

type quoteEventDao struct {
	baseDao
}

func (d *quoteEventDao) UpdateStatusByID(tx *gorm.DB, eventID int64, status int) error {
	return d.UpdateByCondition(tx, Condition{"id": eventID}, &model.QuoteEvent{}, map[string]interface{}{"status": status})
}

func (d *quoteEventDao) UpdateStatusAndExtraByID(tx *gorm.DB, eventID int64, status int, extra string) error {
	return d.UpdateByCondition(tx, Condition{"id": eventID}, &model.QuoteEvent{}, map[string]interface{}{"status": status, "extra": extra})
}

func (*quoteEventDao) FindEventsByIDs(tx *gorm.DB, eventIDs []int64) ([]*model.QuoteEvent, error) {
	sql := tx.Model(&model.QuoteEvent{})
	sql = sql.Where("id in ?", eventIDs)
	var ret []*model.QuoteEvent
	err := sql.Find(&ret).Error
	return ret, err
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var ContractPriceTaskDao = &contractPriceTaskDao{}

type contractPriceTaskDao struct {
	baseDao
}

func (*contractPriceTaskDao) FindContractPriceTaskByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.ContractPriceTask, error) {
	sql := tx.Model(&model.ContractPriceTask{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.ContractPriceTask
	err := sql.Find(&ret).Error
	return ret, err
}

func (*contractPriceTaskDao) FindContractPriceByTaskStatus(tx *gorm.DB, taskStatus string) ([]*model.ContractPriceTask, error) {
	sql := tx.Model(&model.ContractPriceTask{})
	sql = sql.Where("status = 0 and task_status = ?", taskStatus)
	var ret []*model.ContractPriceTask
	err := sql.Find(&ret).Error
	return ret, err
}

func (*contractPriceTaskDao) FindContractPriceByIDTaskStatus(tx *gorm.DB, quoteID int64, taskStatus string) ([]*model.ContractPriceTask, error) {
	sql := tx.Model(&model.ContractPriceTask{})
	sql = sql.Where("quote_id=? and status = 0 and task_status = ?", quoteID, taskStatus)
	var ret []*model.ContractPriceTask
	err := sql.Find(&ret).Error
	return ret, err
}

func (*contractPriceTaskDao) FindContractPriceByID(tx *gorm.DB, id int64) (*model.ContractPriceTask, error) {
	sql := tx.Model(&model.ContractPriceTask{})
	sql = sql.Where("id = ? and status = 0", id)
	var ret *model.ContractPriceTask
	err := sql.First(&ret).Error
	return ret, err
}

func (d *contractPriceTaskDao) UpdateContractPriceTaskStatus(tx *gorm.DB, taskID int64, taskStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": taskID}, &model.ContractPriceTask{}, map[string]interface{}{"task_status": taskStatus})
}

package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var QuoteTaskChargeItemDao = &quoteTaskChargeItemDao{}

type quoteTaskChargeItemDao struct {
	baseDao
}

func (*quoteTaskChargeItemDao) FindChargeItemsByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.QuoteTaskChargeItem, int64, error) {
	sql := tx.Model(&model.QuoteTaskChargeItem{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.QuoteTaskChargeItem
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *quoteTaskChargeItemDao) FindChargeItemsByTaskID(tx *gorm.DB, quoteTaskID int64) ([]*model.QuoteTaskChargeItem, error) {
	condition := framework.Condition{}
	condition["quote_task_id"] = quoteTaskID

	var chargeItems []*model.QuoteTaskChargeItem
	for i := 1; true; i++ {
		pageChargeItems, _, err := d.FindChargeItemsByConditions(tx, condition, 1000, i)
		if err != nil {
			return nil, err
		}
		chargeItems = append(chargeItems, pageChargeItems...)

		if len(pageChargeItems) < 1000 {
			break
		}
	}

	return chargeItems, nil
}

func (*quoteTaskChargeItemDao) ExistChargeItemsByTaskID(tx *gorm.DB, quoteTaskID int64) (bool, error) {
	sql := tx.Model(&model.QuoteTaskChargeItem{})
	sql = sql.Where("quote_task_id = ? and status = 0", quoteTaskID)
	ret := &model.QuoteTaskChargeItem{}
	err := sql.Order("id desc").Limit(1).Find(ret).Error
	if err != nil {
		return false, nil
	}
	if ret.Id > 0 {
		return true, nil
	}
	return false, nil
}

func (d *quoteTaskChargeItemDao) SoftDeleteByCondition(tx *gorm.DB, condition Condition) error {
	return d.SoftDeleteData(tx, condition, &model.QuoteTaskChargeItem{})
}

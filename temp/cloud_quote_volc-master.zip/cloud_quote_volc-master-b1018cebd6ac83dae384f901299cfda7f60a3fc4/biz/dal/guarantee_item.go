package dal

import (
	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var GuaranteeItemDao = &guaranteeItemDao{}

type guaranteeItemDao struct {
	baseDao
}

func (*guaranteeItemDao) FindByID(tx *gorm.DB, guaranteeItemID int64) (*model.GuaranteeItem, error) {
	sql := tx.Model(&model.GuaranteeItem{})
	sql = sql.Where("id = ? and status = 0", guaranteeItemID)
	ret := &model.GuaranteeItem{}
	err := sql.First(ret).Error
	return ret, err
}

func (*guaranteeItemDao) FindByQuoteID(tx *gorm.DB, quoteID int64) (*model.GuaranteeItem, error) {
	// 兼容旧单保底调用方：多保底场景只返回第一条，完整列表必须使用 FindListByQuoteID。
	sql := tx.Model(&model.GuaranteeItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	ret := &model.GuaranteeItem{}
	err := sql.First(ret).Error
	return ret, err
}

// FindListByQuoteID 查询单张报价单下全部有效保底规则。
func (*guaranteeItemDao) FindListByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.GuaranteeItem, error) {
	var ret []*model.GuaranteeItem
	err := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and status = 0", quoteID).
		Find(&ret).Error
	return ret, err
}

// FindValidByIDs 按保底规则 ID 列表查询有效保底规则。
func (*guaranteeItemDao) FindValidByIDs(tx *gorm.DB, ids []int64) ([]*model.GuaranteeItem, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	var ret []*model.GuaranteeItem
	err := tx.Model(&model.GuaranteeItem{}).
		Where("id in (?) and status = 0", ids).
		Find(&ret).Error
	return ret, err
}

// FindValidByQuoteIDs 按报价单 ID 列表查询有效保底规则，并按报价单分组返回。
func (*guaranteeItemDao) FindValidByQuoteIDs(tx *gorm.DB, quoteIDs []int64) (map[int64][]*model.GuaranteeItem, error) {
	ret := map[int64][]*model.GuaranteeItem{}
	if len(quoteIDs) == 0 {
		return ret, nil
	}
	var items []*model.GuaranteeItem
	err := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id in (?) and status = 0", quoteIDs).
		Find(&items).Error
	if err != nil {
		return nil, err
	}
	for _, item := range items {
		ret[item.QuoteID] = append(ret[item.QuoteID], item)
	}
	return ret, nil
}

func (*guaranteeItemDao) SoftDelete(tx *gorm.DB, guaranteeItemID int64) error {
	return tx.Model(&model.GuaranteeItem{}).Where("id = ? ", guaranteeItemID).Update("status", 1).Error
}

// BatchSoftDelete 按报价单和保底规则 ID 集合批量软删有效保底规则。
func (*guaranteeItemDao) BatchSoftDelete(tx *gorm.DB, quoteID int64, guaranteeItemIDs []int64) error {
	if len(guaranteeItemIDs) == 0 {
		return nil
	}
	return tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id in (?) and status = 0", quoteID, guaranteeItemIDs).
		Update("status", 1).Error
}

// GuaranteeItemBackfillQuery 是多保底字段补偿任务的范围扫描条件。
type GuaranteeItemBackfillQuery struct {
	StartID int64
	EndID   int64
	Limit   int
}

// ScanBackfillItems 按 ID 范围查询有效保底规则。
func (*guaranteeItemDao) ScanBackfillItems(tx *gorm.DB, query GuaranteeItemBackfillQuery) ([]*model.GuaranteeItem, error) {
	limit := query.Limit
	if limit <= 0 || limit > 100 {
		limit = 100
	}
	// 每批最多 100 条，具体是否可补由 service 层根据报价单关系和计算公式判断。
	sql := tx.Model(&model.GuaranteeItem{}).
		Where("status = 0").
		Where("id >= ? and id <= ?", query.StartID, query.EndID).
		Order("id asc").
		Limit(limit)
	var items []*model.GuaranteeItem
	err := sql.Find(&items).Error
	return items, err
}

// UpdateTotalAmountIfUnchanged 在保底总金额仍为扫描旧值时更新新值。
func (*guaranteeItemDao) UpdateTotalAmountIfUnchanged(tx *gorm.DB, quoteID, guaranteeItemID int64, oldValue *decimal.Decimal, newValue decimal.Decimal) (int64, error) {
	sql := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0", quoteID, guaranteeItemID)
	// 补偿更新使用乐观条件：只有 DB 仍等于扫描时的旧值才覆盖，避免覆盖并发写入。
	if oldValue == nil {
		sql = sql.Where("guarantee_total_amount is null")
	} else {
		sql = sql.Where("guarantee_total_amount = ?", oldValue)
	}
	ret := sql.Update("guarantee_total_amount", newValue)
	return ret.RowsAffected, ret.Error
}

// UpdateTotalAmount 强制更新保底总金额，不校验扫描旧值。
func (*guaranteeItemDao) UpdateTotalAmount(tx *gorm.DB, quoteID, guaranteeItemID int64, newValue decimal.Decimal) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0", quoteID, guaranteeItemID).
		Update("guarantee_total_amount", newValue)
	return ret.RowsAffected, ret.Error
}

// UpdateCopyFromIfZero 在 copy_from 仍为空时写入父单来源保底 ID。
func (*guaranteeItemDao) UpdateCopyFromIfZero(tx *gorm.DB, quoteID, guaranteeItemID, copyFrom int64) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0 and copy_from = 0", quoteID, guaranteeItemID).
		Update("copy_from", copyFrom)
	return ret.RowsAffected, ret.Error
}

// UpdateCopyFrom 强制更新父单来源保底 ID，不校验当前 copy_from。
func (*guaranteeItemDao) UpdateCopyFrom(tx *gorm.DB, quoteID, guaranteeItemID, copyFrom int64) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0", quoteID, guaranteeItemID).
		Update("copy_from", copyFrom)
	return ret.RowsAffected, ret.Error
}

// UpdateChangeFromIfZero 在 change_from 仍为空时写入原单来源保底 ID。
func (*guaranteeItemDao) UpdateChangeFromIfZero(tx *gorm.DB, quoteID, guaranteeItemID, changeFrom int64) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0 and change_from = 0", quoteID, guaranteeItemID).
		Update("change_from", changeFrom)
	return ret.RowsAffected, ret.Error
}

// UpdateChangeFrom 强制更新原单来源保底 ID，不校验当前 change_from。
func (*guaranteeItemDao) UpdateChangeFrom(tx *gorm.DB, quoteID, guaranteeItemID, changeFrom int64) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0", quoteID, guaranteeItemID).
		Update("change_from", changeFrom)
	return ret.RowsAffected, ret.Error
}

// UpdateCarryForwardIfUnchanged 在结转配置仍为扫描旧值时更新新值。
func (*guaranteeItemDao) UpdateCarryForwardIfUnchanged(tx *gorm.DB, quoteID, guaranteeItemID int64, oldCarryForward, newCarryForward int) (int64, error) {
	ret := tx.Model(&model.GuaranteeItem{}).
		Where("quote_id = ? and id = ? and status = 0 and carry_forward = ?", quoteID, guaranteeItemID, oldCarryForward).
		Update("carry_forward", newCarryForward)
	return ret.RowsAffected, ret.Error
}

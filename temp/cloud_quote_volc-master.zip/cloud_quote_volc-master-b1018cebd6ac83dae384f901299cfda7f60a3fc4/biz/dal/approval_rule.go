package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var ApprovalRuleDao = &approvalRuleDao{}

type approvalRuleDao struct {
	baseDao
}

func (*approvalRuleDao) FindRulesByCondition(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.ApprovalRule, int64, error) {
	sql := tx.Model(&model.ApprovalRule{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, errors.NewInternalDBError(err)
	}
	var ret []*model.ApprovalRule
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	if err != nil {
		return nil, 0, errors.NewInternalDBError(err)
	}
	return ret, total, nil
}

func (*approvalRuleDao) FindRuleByID(tx *gorm.DB, ruleID int64) (*model.ApprovalRule, error) {
	sql := tx.Model(&model.ApprovalRule{})
	sql = sql.Where("id = ? and status = 0", ruleID)
	ret := &model.ApprovalRule{}
	err := sql.Find(ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	if ret == nil || ret.Id == 0 {
		return nil, errors.NewRecordNotFoundErr("审批规则不存在，规则ID：%d").WithArgs(ruleID)
	}
	return ret, nil
}

func (d *approvalRuleDao) SaveRule(tx *gorm.DB, ruleDB *model.ApprovalRule) error {
	err := d.Save(tx, ruleDB, &model.ApprovalRule{})
	if err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

func (d *approvalRuleDao) UpdateRuleByID(tx *gorm.DB, id int64, updates map[string]interface{}) error {
	err := d.UpdateByCondition(tx, Condition{"id": id}, &model.ApprovalRule{}, updates)
	if err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

// UpdateRuleByIDWithStatus 更新审批规则（带状态校验）
// 只有当规则当前状态为 currentStatus 时才允许更新，防止并发修改导致的状态不一致
func (d *approvalRuleDao) UpdateRuleByIDWithStatus(tx *gorm.DB, id int64, currentStatus string, updates map[string]interface{}) error {
	condition := Condition{
		"id":          id,
		"rule_status": currentStatus,
	}
	err := d.UpdateByCondition(tx, condition, &model.ApprovalRule{}, updates)
	if err != nil {
		return errors.NewInternalDBError(err)
	}
	return nil
}

func (d *approvalRuleDao) ListByRuleStatus(tx *gorm.DB, ruleStatus string) ([]*model.ApprovalRule, error) {
	sql := tx.Model(&model.ApprovalRule{})
	sql = sql.Where("status = 0 and rule_status = ?", ruleStatus)
	var ret []*model.ApprovalRule
	err := sql.Find(&ret).Error
	return ret, err
}

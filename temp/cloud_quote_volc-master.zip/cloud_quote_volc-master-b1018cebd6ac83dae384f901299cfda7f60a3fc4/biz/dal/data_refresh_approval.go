package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var DataRefreshApprovalDao = &dataRefreshApprovalDao{}

type dataRefreshApprovalDao struct {
	baseDao
}

func (d *dataRefreshApprovalDao) Create(tx *gorm.DB, approval *model.DataRefreshApproval) error {
	return d.Save(tx, approval, &model.DataRefreshApproval{})
}

func (*dataRefreshApprovalDao) FindByID(tx *gorm.DB, id int64) (*model.DataRefreshApproval, error) {
	ret := &model.DataRefreshApproval{}
	err := tx.Model(&model.DataRefreshApproval{}).
		Where("status = 0 and id = ?", id).
		First(ret).Error
	return ret, err
}

func (*dataRefreshApprovalDao) FindByQuoteID(tx *gorm.DB, quoteID int64, limit, offset int) ([]*model.DataRefreshApproval, int64, error) {
	sql := tx.Model(&model.DataRefreshApproval{}).Where("status = 0 and quote_id = ?", quoteID)

	var total int64
	if err := sql.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var ret []*model.DataRefreshApproval
	err := sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *dataRefreshApprovalDao) FindByContractNoAndApprovalStatus(tx *gorm.DB, contractNo string, approvalStatus string) ([]*model.DataRefreshApproval, error) {
	return d.FindByContractNoAndApprovalStatusList(tx, contractNo, []string{approvalStatus})
}

func (*dataRefreshApprovalDao) FindByContractNoAndApprovalStatusList(tx *gorm.DB, contractNo string, approvalStatusList []string) ([]*model.DataRefreshApproval, error) {
	if len(approvalStatusList) == 0 {
		return []*model.DataRefreshApproval{}, nil
	}
	var ret []*model.DataRefreshApproval
	err := tx.Model(&model.DataRefreshApproval{}).
		Where("status = 0").
		Where("contract_no = ?", contractNo).
		Where("approval_status in (?)", approvalStatusList).
		Order("id desc").
		Find(&ret).Error
	return ret, err
}

func (*dataRefreshApprovalDao) FindByCondition(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.DataRefreshApproval, int64, error) {
	sql := tx.Model(&model.DataRefreshApproval{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")

	var total int64
	if err := sql.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var ret []*model.DataRefreshApproval
	err := sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *dataRefreshApprovalDao) UpdateApprovalStatusByID(tx *gorm.DB, id int64, approvalStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": id}, &model.DataRefreshApproval{}, map[string]interface{}{"approval_status": approvalStatus})
}

func (d *dataRefreshApprovalDao) UpdateApprovalStatusByIDAndStatusList(tx *gorm.DB, id int64, fromStatusList []string, toStatus string) error {
	if len(fromStatusList) == 0 {
		return nil
	}
	return d.UpdateByCondition(tx, Condition{"id": id, "approval_status": fromStatusList}, &model.DataRefreshApproval{}, map[string]interface{}{"approval_status": toStatus})
}

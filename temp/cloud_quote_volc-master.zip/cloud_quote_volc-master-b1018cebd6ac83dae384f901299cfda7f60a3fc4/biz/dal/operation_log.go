package dal

import (
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var OperationLogDao = &operationLogDao{}

type operationLogDao struct {
	baseDao
}

func (*operationLogDao) FindQuoteSubmitLog(tx *gorm.DB, quoteID int64) (*model.OperationLog, error) {
	sql := tx.Model(&model.OperationLog{})
	sql = sql.Where("biz_scene = ? and action = ?", constants.LogBizSceneSubmit, constants.ActionSubmitQuote)
	sql = sql.Where("entity_id = ? and status = 0", strconv.FormatInt(quoteID, 10))
	ret := &model.OperationLog{}
	err := sql.Last(ret).Error
	return ret, err
}

func (*operationLogDao) FindHealthCheckLog(tx *gorm.DB, dateTime string) (*model.OperationLog, error) {
	sql := tx.Model(&model.OperationLog{})
	sql = sql.Where("biz_scene = ? and operator = ? and  status = 0", constants.LogBizHealthCheck, dateTime)
	ret := &model.OperationLog{}
	err := sql.Last(ret).Error
	return ret, err
}

func (*operationLogDao) FindSalesOpModifyLogs(tx *gorm.DB, entityID int64) ([]*model.OperationLog, error) {
	sql := tx.Model(&model.OperationLog{})
	sql = sql.Where("entity_id = ? and biz_scene = ? and status = 0", entityID, constants.LogBizSalesOpModifySubmitted)
	var ret []*model.OperationLog
	err := sql.Order("id asc").Find(&ret).Error
	return ret, err
}

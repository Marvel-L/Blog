package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"gorm.io/gorm"
)

var TemplateDao = &templateDao{}

type templateDao struct {
	baseDao
}

type ListTemplateQuery struct {
	RelatedProducts []string
	TemplateKey     string
}

func (*templateDao) FindQuoteTemplateByID(tx *gorm.DB, quoteTemplateID int64) (*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("id = ? and status = 0", quoteTemplateID)
	ret := &model.QuoteTemplate{}
	err := sql.First(ret).Error
	return ret, err
}

func (*templateDao) FindQuoteTemplateByIDAndCode(tx *gorm.DB, quoteTemplateID int64, tplCode string) (*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("id = ? and status = 0", quoteTemplateID)
	if tplCode != "" {
		sql = sql.Where("template_code = ?", tplCode)
	}
	ret := &model.QuoteTemplate{}
	err := sql.First(ret).Error
	return ret, err
}

func (*templateDao) FindQuoteTemplatesByIDs(tx *gorm.DB, quoteTemplateIDs []int64) ([]*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("id in ? ", quoteTemplateIDs)
	var ret []*model.QuoteTemplate
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (*templateDao) FindQuoteTemplatesByParentIDs(tx *gorm.DB, parentIDs []int64) ([]*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("template_parent_id in ? and status = 0", parentIDs)
	var ret []*model.QuoteTemplate
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (r *templateDao) TemplatesMapByTemplateIDs(tx *gorm.DB, quoteTemplateIDs []int64) (map[int64]*model.QuoteTemplate, error) {
	rows, err := r.FindQuoteTemplatesByIDs(tx, quoteTemplateIDs)
	if err != nil {
		return nil, err
	}
	var ret = map[int64]*model.QuoteTemplate{}
	for _, row := range rows {
		ret[row.Id] = row
	}
	return ret, nil
}

func (r *templateDao) FindQuoteTemplateByName(tx *gorm.DB, quoteTemplateName string) (*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("template_name = ?", quoteTemplateName).Order("id desc")
	ret := &model.QuoteTemplate{}
	err := sql.First(ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return ret, err
}

func (r *templateDao) FindQuoteTemplateByCode(tx *gorm.DB, quoteTemplateCode string) (*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("template_code = ?", quoteTemplateCode).Order("id desc")
	ret := &model.QuoteTemplate{}
	err := sql.First(ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return ret, err
}

func (r *templateDao) FindQuoteTemplateByParentID(tx *gorm.DB, parentID int64) (*model.QuoteTemplate, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	sql = sql.Where("template_parent_id = ?", parentID)
	ret := &model.QuoteTemplate{}
	err := sql.First(ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}
	return ret, err
}

func (*templateDao) FindQuoteTemplateByConditions(tx *gorm.DB, condition framework.Condition, templateQuery *ListTemplateQuery, limit, offset int) ([]*model.QuoteTemplate, int64, error) {
	sql := tx.Model(&model.QuoteTemplate{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	if templateQuery != nil && len(templateQuery.RelatedProducts) > 0 {
		for _, tradeProduct := range templateQuery.RelatedProducts {
			fuzzTradeProduct := MakeFuzz("," + tradeProduct + ",")
			sql = sql.Where("related_products like ?", fuzzTradeProduct)
		}
	}

	if templateQuery != nil && len(templateQuery.TemplateKey) > 0 {
		sql = sql.Where("template_name like ? or template_code like ? ", MakeFuzz(templateQuery.TemplateKey), MakeFuzz(templateQuery.TemplateKey))
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.QuoteTemplate
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (r *templateDao) UpdateRelatedProductsByID(tx *gorm.DB, templateID int64, relatedProducts, productTags string) error {
	return r.UpdateByCondition(
		tx,
		Condition{"id": templateID},
		&model.QuoteTemplate{},
		map[string]interface{}{
			"related_products": relatedProducts,
			"product_tags":     productTags,
		},
	)
}

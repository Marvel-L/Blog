package dal

import (
	"errors"
	"testing"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_quoteContractDao_ContractCodesByQuoteIDs_BitsUTGen(t *testing.T) {
	t.Run("查询成功，存在多条合同号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造dao与tx
			q := &quoteContractDao{}
			tx := &gorm.DB{Config: &gorm.Config{}, Statement: &gorm.Statement{}}
			quoteIDs := []int64{101, 102}

			// Mock Where 返回自身
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Order 返回自身
			mockey.MockUnsafe((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Find 成功并写入两条数据
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if rowsPtr, ok := dest.(*[]*model.QuoteContract); ok {
					*rowsPtr = []*model.QuoteContract{
						{ContractCode: "C1"},
						{ContractCode: "C2"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// 调用
			ret, err := q.ContractCodesByQuoteIDs(tx, quoteIDs)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldResemble, []string{"C1", "C2"})
		})
	})

	t.Run("查询成功，无合同号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造dao与tx
			q := &quoteContractDao{}
			tx := &gorm.DB{Config: &gorm.Config{}, Statement: &gorm.Statement{}}
			quoteIDs := []int64{201, 202}

			// Mock Where 返回自身
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Order 返回自身
			mockey.MockUnsafe((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Find 成功但无数据
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if rowsPtr, ok := dest.(*[]*model.QuoteContract); ok {
					*rowsPtr = []*model.QuoteContract{}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// 调用
			ret, err := q.ContractCodesByQuoteIDs(tx, quoteIDs)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldResemble, []string{})
		})
	})

	t.Run("查询失败，数据库错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造dao与tx
			q := &quoteContractDao{}
			tx := &gorm.DB{Config: &gorm.Config{}, Statement: &gorm.Statement{}}
			quoteIDs := []int64{301}

			// Mock Where 返回自身
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Order 返回自身
			mockey.MockUnsafe((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				return db
			}).Build()
			// Mock Find 返回错误
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				return &gorm.DB{Error: errors.New("query failed")}
			}).Build()

			// 调用
			ret, err := q.ContractCodesByQuoteIDs(tx, quoteIDs)

			// 断言
			convey.So(ret, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "query failed")
		})
	})
}

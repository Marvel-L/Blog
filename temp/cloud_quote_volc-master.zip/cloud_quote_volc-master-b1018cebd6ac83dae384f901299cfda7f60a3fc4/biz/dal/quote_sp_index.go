package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var QuoteSpIndexDao = &quoteSpIndexDao{}

type quoteSpIndexDao struct {
	baseDao
}

func (*quoteSpIndexDao) FindSpIndexByAccountConfig(tx *gorm.DB, configAccountDataList [][]interface{}) ([]*model.QuoteSpIndex, error) {
	sql := tx.Model(&model.QuoteSpIndex{})
	sql = sql.Where("(trade_product, config_code, customer_account) IN ? and status = 0", configAccountDataList)
	var ret []*model.QuoteSpIndex
	err := sql.Find(&ret).Error
	return ret, err
}

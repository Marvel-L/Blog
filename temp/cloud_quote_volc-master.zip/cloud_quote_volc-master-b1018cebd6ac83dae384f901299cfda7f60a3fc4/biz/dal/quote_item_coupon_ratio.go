package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var QuoteItemCouponRatioDao = &quoteItemCouponRatioDao{}

type quoteItemCouponRatioDao struct {
	baseDao
}

// FindByQuoteID 根据报价单ID查询报价项-代金券返券比例记录
func (*quoteItemCouponRatioDao) FindByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.QuoteItemCouponRatio, error) {
	sql := tx.Model(&model.QuoteItemCouponRatio{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.QuoteItemCouponRatio
	err := sql.Find(&ret).Error
	return ret, err
}

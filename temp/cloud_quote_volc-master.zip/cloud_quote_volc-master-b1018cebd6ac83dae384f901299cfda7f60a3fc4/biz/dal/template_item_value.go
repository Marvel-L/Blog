package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var TemplateItemValueDao = &templateItemValueDao{}

type templateItemValueDao struct {
	baseDao
}

func (d *templateItemValueDao) templateItemValueMapByTemplateItemIDsAndTemplateIDs(tx *gorm.DB, templateItemIDs []int64, templateIDs []int64) (map[int64][]*model.TemplateItemValue, error) {
	rows, err := d.findTemplateItemValuesByTemplateItemIDsAndTemplateIDs(tx, templateItemIDs, templateIDs)
	if err != nil {
		return nil, err
	}
	ret := map[int64][]*model.TemplateItemValue{}
	for _, row := range rows {
		ret[row.TemplateItemID] = append(ret[row.TemplateItemID], row)
	}
	return ret, nil
}

func (d *templateItemValueDao) findTemplateItemValuesByTemplateItemIDsAndTemplateIDs(tx *gorm.DB, templateItemIDs []int64, templateIDs []int64) ([]*model.TemplateItemValue, error) {
	sql := tx.Model(&model.TemplateItemValue{})
	sql = sql.Where("template_item_id in ? AND template_id in ? AND status = 0", templateItemIDs, templateIDs)
	var ret []*model.TemplateItemValue
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

// TemplateItemValueMapByTemplateItemIDsV2 templateItemID -> []templateItemValue
func (d *templateItemValueDao) TemplateItemValueMapByTemplateItemIDsV2(tx *gorm.DB, templateItemIDs []int64, templateIDs []int64) (map[int64][]*model.TemplateItemValue, error) {
	return d.templateItemValueMapByTemplateItemIDsAndTemplateIDs(tx, templateItemIDs, templateIDs)
}

func (d *templateItemValueDao) TplItemValuesByItemIDsAndKey(tx *gorm.DB, itemIDs []int64, formSchemaKey string) ([]*model.TemplateItemValue, error) {
	sql := tx.Model(&model.TemplateItemValue{})
	sql = sql.Where("template_item_id in ? and form_schema_key = ?", itemIDs, formSchemaKey)
	var ret []*model.TemplateItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *templateItemValueDao) UpdateItemValueByIDs(tx *gorm.DB, itemValueIDs []int64, itemValue string) error {
	return d.UpdateByCondition(tx, Condition{"id": itemValueIDs},
		&model.TemplateItemValue{},
		map[string]interface{}{
			"template_item_value":     itemValue,
			"option_enum_description": itemValue,
		})
}

func (d *templateItemValueDao) UpdateTemplateIDAndStatus(tx *gorm.DB, templateItemID, templateID int64, status int) error {
	return d.UpdateByCondition(tx, Condition{"template_item_id": templateItemID},
		&model.TemplateItemValue{},
		map[string]interface{}{
			"template_id": templateID,
			"status":      status,
		})
}

func (d *templateItemValueDao) SoftDelete(tx *gorm.DB, templateID int64, templateItemIDs []int64) error {
	return d.SoftDeleteData(tx,
		Condition{
			"template_id":      templateID,
			"template_item_id": templateItemIDs},
		&model.TemplateItemValue{})
}

func (d *templateItemValueDao) DeleteValuesByItemID(tx *gorm.DB, templateItemID int64) error {
	return tx.Where("template_item_id = ? ", templateItemID).Delete(&model.TemplateItemValue{}).Error
}

func (d *templateItemValueDao) FindTemplateItemValuesByTemplateItemID(tx *gorm.DB, templateItemID int64) ([]*model.TemplateItemValue, error) {
	sql := tx.Model(&model.TemplateItemValue{})
	sql = sql.Where("template_item_id = ? and status = 0", templateItemID)
	var ret []*model.TemplateItemValue
	err := sql.Find(&ret).Error
	return ret, err
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"gorm.io/gorm"
)

var CommonQuoteRelation = &commonQuoteRelationDao{}

type commonQuoteRelationDao struct {
	baseDao
}

func (r *commonQuoteRelationDao) FindRelationByConditions(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.CommonQuoteRelation, error) {
	sql := tx.Model(&model.CommonQuoteRelation{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var ret []*model.CommonQuoteRelation
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (r *commonQuoteRelationDao) DeleteByQuoteItemIDScene(tx *gorm.DB, quoteItemIDs []int64, relationScene int) error {
	return r.SoftDeleteData(tx, Condition{"quote_item_id": quoteItemIDs, "relation_scene": relationScene}, &model.CommonQuoteRelation{})
}

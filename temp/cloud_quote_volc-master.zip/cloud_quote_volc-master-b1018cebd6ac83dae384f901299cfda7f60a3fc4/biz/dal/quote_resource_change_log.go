package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

// QuoteResourceChangeLogDao 数据查询dao
var QuoteResourceChangeLogDao = &quoteResourceChangeLogDao{}

type quoteResourceChangeLogDao struct {
	baseDao
}

// FindByID 根据id查询资源单变更记录
func (d *quoteResourceChangeLogDao) FindByID(tx *gorm.DB, id int64) (*model.QuoteResourceChangeLog, error) {
	sql := tx.Model(&model.QuoteResourceChangeLog{})
	sql = sql.Where("id = ? and status = 0", id)
	ret := &model.QuoteResourceChangeLog{}
	err := sql.First(ret).Error
	return ret, err
}

func (d *quoteResourceChangeLogDao) UpdateBackupData(tx *gorm.DB, id int64, backupData string) error {
	return d.UpdateByCondition(tx, Condition{"id": id}, &model.QuoteResourceChangeLog{}, map[string]interface{}{"backup_data": backupData})
}

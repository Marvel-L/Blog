package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"gorm.io/gorm"
)

var LarkApprovalInstanceDao = &larkApprovalInstance{}

type larkApprovalInstance struct {
	baseDao
}

func (*larkApprovalInstance) FindByInstanceAndApprovalCode(tx *gorm.DB, approvalCode string, instanceID string) (*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	sql = sql.Where("form_code = ? and  instance_id = ? ", approvalCode, instanceID)
	ret := &model.LarkApprovalInstance{}
	err := sql.First(ret).Error
	return ret, err
}

func (*larkApprovalInstance) FindByID(tx *gorm.DB, id int64) (*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	sql = sql.Where("id = ?", id)
	ret := &model.LarkApprovalInstance{}
	err := sql.First(ret).Error
	return ret, err
}

func (*larkApprovalInstance) FindByInstanceAndEntityID(tx *gorm.DB, entityID int64, approvalInstanceID string) (*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	sql = sql.Where("entity_id = ? and approval_instance_id = ?", entityID, approvalInstanceID)
	ret := &model.LarkApprovalInstance{}
	err := sql.First(ret).Error
	return ret, err
}

// FindByApplicationTypeAndEntityID 根据审批类型+审批主体查询最近的一条数据
func (*larkApprovalInstance) FindByApplicationTypeAndEntityID(tx *gorm.DB, entityID int64, applicationType string) (*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	sql = sql.Where("entity_id = ? and application_type = ?", entityID, applicationType).Order("id desc")
	ret := &model.LarkApprovalInstance{}
	err := sql.Find(ret).Error
	return ret, err
}

// ListLatestByEntityAndTypes 按创建顺序倒序查询指定主体最近的审批实例。
func (*larkApprovalInstance) ListLatestByEntityAndTypes(
	tx *gorm.DB,
	entityID int64,
	applicationTypes []constants.ApplicationType,
	limit int,
) ([]*model.LarkApprovalInstance, error) {
	if limit <= 0 {
		limit = 2
	}
	var ret []*model.LarkApprovalInstance
	// 只读取有效记录并按主键倒序，调用方约定第 1 条为当前版本、第 2 条为上一版本。
	err := tx.Model(&model.LarkApprovalInstance{}).
		Where("entity_id = ?", entityID).
		Where("application_type in (?)", applicationTypes).
		Where("status = ?", constants.DataNormalStatus).
		Order("id desc").
		Limit(limit).
		Find(&ret).Error
	return ret, err
}

func (*larkApprovalInstance) LarkApprovalInstanceMapByQuoteIDs(tx *gorm.DB, entityIDList []int64, applicationTypes []string) (map[int64]*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	sql = sql.Where("entity_id in (?) and application_type in (?)", entityIDList, applicationTypes)
	var rows []*model.LarkApprovalInstance
	if err := sql.Find(&rows).Error; err != nil {
		return nil, err
	}
	ret := map[int64]*model.LarkApprovalInstance{}
	// id asc遍历，新记录会覆盖旧记录
	for _, row := range rows {
		ret[row.EntityId] = row
	}
	return ret, nil
}

func (*larkApprovalInstance) FindInstanceByCondition(tx *gorm.DB, condition framework.Condition, pageSize int) ([]*model.LarkApprovalInstance, error) {
	sql := tx.Model(&model.LarkApprovalInstance{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status=0")
	var ret []*model.LarkApprovalInstance
	err := sql.Order("id desc").Limit(pageSize).Find(&ret).Error
	return ret, err
}

func (d *larkApprovalInstance) UpdateSerialNumber(tx *gorm.DB, id int64, serialNumber string) error {
	return d.UpdateByCondition(tx, Condition{"id": id}, &model.LarkApprovalInstance{}, map[string]interface{}{"serial_number": serialNumber})
}

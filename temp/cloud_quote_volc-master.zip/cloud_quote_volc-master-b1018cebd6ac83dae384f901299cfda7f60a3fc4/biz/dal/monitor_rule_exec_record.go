package dal

import (
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

type MonitorRuleExecRecordDao struct {
	baseDao
}

var MonitorRuleExecRecord = &MonitorRuleExecRecordDao{}

func (d *MonitorRuleExecRecordDao) FindByRuleIDAndQueryKey(tx *gorm.DB, ruleID int64, queryKey string) ([]*model.MonitorRuleExecRecord, error) {
	sql := tx.Model(&model.MonitorRuleExecRecord{})
	sql = sql.Where("rule_id = ? AND query_key = ?", ruleID, queryKey)
	var records []*model.MonitorRuleExecRecord
	err := sql.Order("id desc").Find(&records).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return records, nil
}

func (d *MonitorRuleExecRecordDao) FindSalesOpMessageLog(tx *gorm.DB, time time.Time, key string) ([]*model.MonitorRuleExecRecord, error) {
	sql := tx.Model(&model.MonitorRuleExecRecord{})
	sql = sql.Where("created_time >= ? and query_key = ?", time, key)
	var ret []*model.MonitorRuleExecRecord
	err := sql.Find(&ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return ret, nil
}

package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var TemplateItemDao = &templateItemDao{}

type templateItemDao struct {
	baseDao
}

func (d *templateItemDao) SoftDeleteTemplateItems(tx *gorm.DB, templateID int64, templateItemIDs []int64) error {

	return d.SoftDeleteData(tx,
		Condition{
			"template_id": templateID,
			"id":          templateItemIDs,
		}, &model.TemplateItem{})
}

func (*templateItemDao) FindTemplateItemsByTemplateID(tx *gorm.DB, templateID int64, itemStatus int) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id = ? and status = 0", templateID)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ?", itemStatus)
	}
	var ret []*model.TemplateItem
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindTplItemByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.TemplateItem, int64, error) {
	sql := tx.Model(&model.TemplateItem{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.TemplateItem
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

// FindTplItemByIdAndSolutionType search for the template items of the solution type in the template
func (*templateItemDao) FindTplItemByIdAndSolutionType(tx *gorm.DB, templateID int64, solutionType int) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id = ? and template_solution_type = ? and status = 0 ", templateID, solutionType)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindTemplateItemsByTemplateIDs(tx *gorm.DB, templateIDs []int64, ignoreTplItemIDs []int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id in ? and status = 0", templateIDs)
	if len(ignoreTplItemIDs) > 0 {
		sql = sql.Where("id not in ? ", ignoreTplItemIDs)
	}
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindRelatedTplItems(tx *gorm.DB, templateID int64, tradeProduct string, productType constants.ProductType, tplSolutionID, tplItemID int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id = ? and trade_product = ? and id != ? and status = 0 and item_status = 0 ", templateID, tradeProduct, tplItemID)
	if productType == multienv.TradeProductTypeOffline {
		sql = sql.Where("template_solution_id = ?", tplSolutionID)
	}
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindTemplateItemsByIDs(tx *gorm.DB, ids []int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("id in ? and status = 0", ids)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *templateItemDao) TemplateItemMapByIDs(tx *gorm.DB, ids []int64) (map[int64]*model.TemplateItem, []*model.TemplateItem, error) {
	templateItems, err := d.FindTemplateItemsByIDs(tx, ids)
	if err != nil {
		return nil, nil, err
	}
	ret := map[int64]*model.TemplateItem{}
	for _, item := range templateItems {
		ret[item.Id] = item
	}
	return ret, templateItems, err
}

func (*templateItemDao) FindTemplateItemsBySolutionIDs(tx *gorm.DB, solutionIDs []int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_solution_id in ? and status = 0", solutionIDs)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindTemplateItemsBySolutionIDsAndItemType(tx *gorm.DB, solutionIDs []int64, productType constants.ProductType, templateID int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where(
		"template_id = ? and template_solution_id in ? and item_type = ? and status = 0 and item_status = 0 and standard_product = ?",
		templateID,
		solutionIDs,
		productType,
		multienv.TradeProductStandardYes,
	)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) CountItemsByTemplateID(tx *gorm.DB, templateID int64) (int64, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id = ? and status = 0", templateID)
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return 0, err
	}
	return total, err
}

func (*templateItemDao) FindItemsByIDs(tx *gorm.DB, ids []int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("id in ? and status = 0", ids)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *templateItemDao) UpdateItemStatusByIDs(tx *gorm.DB, templateItemIDs []int64, itemStatus int) error {
	return d.UpdateByCondition(tx, Condition{"id": templateItemIDs}, &model.TemplateItem{}, map[string]interface{}{"item_status": itemStatus})
}

func (d *templateItemDao) UpdateSolutionIDBySolutionID(tx *gorm.DB, oldSolutionID, newSolutionID int64) error {
	return d.UpdateByCondition(tx, Condition{"template_solution_id": oldSolutionID}, &model.TemplateItem{}, map[string]interface{}{"template_solution_id": newSolutionID})
}

func (d *templateItemDao) UpdateItemGiveAwayTypeByIds(tx *gorm.DB, templateItemIDs []int64, giveAwayType string) error {
	return d.UpdateByCondition(tx, Condition{"id": templateItemIDs}, &model.TemplateItem{},
		map[string]interface{}{"give_away_type": giveAwayType},
	)
}

func (*templateItemDao) FindQuoteItemFrom(tx *gorm.DB, startItemID int64) ([]*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("id > ? ", startItemID)
	var ret []*model.TemplateItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemDao) FindTradeProductsByTemplateID(tx *gorm.DB, templateID int64) ([]string, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("template_id = ? and status = 0", templateID)
	sql.Distinct("trade_product")
	var ret []string
	err := sql.Pluck("trade_product", &ret).Error
	return ret, err
}

func (*templateItemDao) FindTemplateItemByID(tx *gorm.DB, id int64) (*model.TemplateItem, error) {
	sql := tx.Model(&model.TemplateItem{})
	sql = sql.Where("id = ? and status = 0", id)
	var ret *model.TemplateItem
	err := sql.First(&ret).Error
	return ret, err
}

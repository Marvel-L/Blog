package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var QuoteProcessDataDao = &quoteProcessData{}

type quoteProcessData struct {
	baseDao
}

func (*quoteProcessData) FindLastByCondition(tx *gorm.DB, condition framework.Condition) (*model.QuoteProcessData, error) {
	sql := tx.Model(&model.QuoteProcessData{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0").Order("id desc")
	ret := &model.QuoteProcessData{}
	err := sql.Find(ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return ret, nil
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var QuoteContractDao = &quoteContractDao{}

type quoteContractDao struct {
	baseDao
}

func (q *quoteContractDao) FindQuoteContractByQuoteID(tx *gorm.DB, quoteID int64) (*model.QuoteContract, error) {
	sql := tx.Model(&model.QuoteContract{})
	sql = sql.Where("quote_id = ?", quoteID)
	var ret *model.QuoteContract
	err := sql.First(&ret).Error
	return ret, err
}

func (q *quoteContractDao) FindQuoteContractByContractCode(tx *gorm.DB, contractCode string) (*model.QuoteContract, error) {
	sql := tx.Model(&model.QuoteContract{})
	sql = sql.Where("contract_code = ?", contractCode)
	var ret *model.QuoteContract
	err := sql.First(&ret).Error
	return ret, err
}

func (q *quoteContractDao) FindQuoteContractsByContractCodes(tx *gorm.DB, contractCodes []string) ([]*model.QuoteContract, error) {
	var ret []*model.QuoteContract
	if len(contractCodes) == 0 {
		return ret, nil
	}
	sql := tx.Model(&model.QuoteContract{})
	sql = sql.Where("contract_code IN (?)", contractCodes)
	err := sql.Find(&ret).Error
	return ret, err
}

// ContractMapByQuoteIDs return type: quoteID -> QuoteContract
func (q *quoteContractDao) ContractMapByQuoteIDs(tx *gorm.DB, quoteIDs []int64) (map[int64]*model.QuoteContract, error) {
	tx = tx.Where("quote_id in ?", quoteIDs)
	var rows []*model.QuoteContract
	if err := tx.Order("id").Find(&rows).Error; err != nil {
		return nil, err
	}
	ret := map[int64]*model.QuoteContract{}
	for _, row := range rows {
		ret[row.QuoteID] = row
	}

	return ret, nil
}

func (q *quoteContractDao) ContractCodesByQuoteIDs(tx *gorm.DB, quoteIDs []int64) ([]string, error) {
	tx = tx.Where("quote_id in ?", quoteIDs)
	var rows []*model.QuoteContract
	if err := tx.Order("id").Find(&rows).Error; err != nil {
		return nil, err
	}
	ret := make([]string, 0, len(rows))
	for _, row := range rows {
		ret = append(ret, row.ContractCode)
	}

	return ret, nil
}

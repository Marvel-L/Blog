package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var AccountDao = &accountDao{}

type accountDao struct {
	baseDao
}

// CurrentUser 获取当前用户，只有内部接口可以取到当前用户
func (d *accountDao) CurrentUser(c context.Context) (*model.Account, error) {
	if user, ok := c.Value(constants.CtxCurrentUser).(*model.Account); ok {
		return user, nil
	}
	return nil, errors.NewUserNotFoundErr("no user found")
}

func (d *accountDao) SaveAccount(tx *gorm.DB, account *model.Account) error {
	return tx.Model(&model.Account{}).Save([]*model.Account{account}).Error
}

func (d *accountDao) FindAllAccounts(c context.Context) ([]*model.Account, error) {
	sql := DBProxy.NewRequest(c)
	sql = sql.Where("status = 0 and id > 1")
	var ret []*model.Account
	if err := sql.Find(&ret).Order("created_date desc").Error; err != nil {
		return nil, err
	}
	return ret, nil
}

func (d *accountDao) FindUserByAccountID(tx *gorm.DB, accountID string) (*model.Account, error) {
	ret := &model.Account{}
	tx = tx.Model(model.Account{}).Where("account_id = ? and status = 0", accountID)
	if err := tx.First(ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

func (d *accountDao) FindDelUserByAccountID(tx *gorm.DB, accountID string) (*model.Account, error) {
	ret := &model.Account{}
	tx = tx.Model(model.Account{}).Where("account_id = ? and status = 1", accountID)
	if err := tx.First(ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

func (d *accountDao) FindAllAccountsByPagination(tx *gorm.DB, keyword string, accountIDs []string, limit, offset int) ([]*model.Account, int64, error) {
	sql := tx.Model(&model.Account{})
	var total int64
	sql = sql.Where("status = 0 and id > 1")
	if keyword != "" {
		fuzzKeyword := MakeFuzz(keyword)
		sql = sql.Where("name like ? or account_id like ?", fuzzKeyword, fuzzKeyword)
	}
	if accountIDs != nil && len(accountIDs) > 0 {
		sql = sql.Where("account_id in ?", accountIDs)
	}
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.Account
	if accountIDs == nil || len(accountIDs) == 0 {
		sql = sql.Limit(limit).Offset(framework.CalculateOffset(offset, limit))
	}
	err = sql.Find(&ret).Error
	return ret, total, err
}

//func (*accountDao) SoftDeleteAccount(tx *gorm.DB, accountId string) error {
//	return tx.Model(&model.Account{}).Where("account_id = ? ", accountId).Update("status", 1).Error
//}

//func (*accountDao) RecoverAccount(tx *gorm.DB, accountId string, accountType constants.AccountType) error {
//	update := map[string]interface{}{}
//	update["status"] = 0
//	update["account_type"] = accountType
//	return tx.Model(&model.Account{}).Where("account_id = ? ", accountId).Updates(update).Error
//}

// MakeFuzz MakeFuzz
func MakeFuzz(s string) string {
	return "%" + s + "%"
}

func (d *accountDao) FindUserByName(tx *gorm.DB, name string) (*model.Account, error) {
	ret := &model.Account{}
	tx = tx.Model(model.Account{}).Where("name = ? and status = 0", name)
	if err := tx.First(ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
	"gorm.io/gorm"
)

var ErrorDetailDao = &errorDetailDao{}

type errorDetailDao struct {
	baseDao
}

func (d *errorDetailDao) FindByErrorCodes(tx *gorm.DB, errorCodes []string) ([]*model.ErrorDetail, error) {
	sql := tx.Model(&model.ErrorDetail{})
	sql = sql.Where("error_code in ? and status = 0", errorCodes)
	var ret []*model.ErrorDetail
	err := sql.Find(&ret).Error
	if err != nil {
		return nil, errors.NewInternalDBError(err)
	}
	return ret, nil
}

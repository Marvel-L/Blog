package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var ChangeDiscountWhiteListDao = &changeDiscountWhiteListDao{}

type changeDiscountWhiteListDao struct {
	baseDao
}

func (*changeDiscountWhiteListDao) FindWhiteListByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.ChangeDiscountWhiteList, int64, error) {
	sql := tx.Model(&model.ChangeDiscountWhiteList{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.ChangeDiscountWhiteList
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *changeDiscountWhiteListDao) FindAllWhiteList(tx *gorm.DB) ([]*model.ChangeDiscountWhiteList, error) {
	condition := framework.Condition{}
	var whiteList []*model.ChangeDiscountWhiteList
	for i := 1; true; i++ {
		pageWhiteList, _, err := d.FindWhiteListByConditions(tx, condition, 1000, i)
		if err != nil {
			return nil, err
		}
		whiteList = append(whiteList, pageWhiteList...)
		if len(pageWhiteList) < 1000 {
			break
		}
	}
	return whiteList, nil
}

func (d *changeDiscountWhiteListDao) SoftDeleteByCondition(tx *gorm.DB, condition Condition) error {
	return d.SoftDeleteData(tx, condition, &model.ChangeDiscountWhiteList{})
}

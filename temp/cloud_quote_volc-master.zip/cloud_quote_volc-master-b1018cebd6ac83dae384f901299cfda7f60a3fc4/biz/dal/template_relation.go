package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"gorm.io/gorm"
)

var TemplateRelationDao = &templateRelationDao{}

type templateRelationDao struct {
	baseDao
}

func (d *templateRelationDao) SoftDeleteTemplateRelationByIDs(tx *gorm.DB, relationIDs []int64) error {
	return d.SoftDeleteData(tx, Condition{"id": relationIDs}, &model.TemplateRelation{})
}

func (d *templateRelationDao) SoftDeleteTemplateRelations(tx *gorm.DB, QuoteID int64, TemplateID int64) error {
	return d.SoftDeleteData(tx,
		Condition{
			"quote_id":    QuoteID,
			"template_id": TemplateID,
		}, &model.TemplateRelation{})
}

func (*templateRelationDao) FindRelationsByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.TemplateRelation, error) {
	sql := tx.Model(&model.TemplateRelation{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.TemplateRelation
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateRelationDao) FindRelationsByQuoteIDs(tx *gorm.DB, quoteIDs []int64) ([]*model.TemplateRelation, error) {
	sql := tx.Model(&model.TemplateRelation{})
	sql = sql.Where("quote_id in ? and status = 0", quoteIDs)
	var ret []*model.TemplateRelation
	err := sql.Find(&ret).Error
	return ret, err
}
func (*templateRelationDao) FindTemplateRelationsByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.TemplateRelation, int64, error) {
	sql := tx.Model(&model.TemplateRelation{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.TemplateRelation
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

type RelationCountRet struct {
	TemplateID int64
	Num        int64
}

func (*templateRelationDao) RelationCountsMapByTemplateIDs(tx *gorm.DB, templateIDs []int64) ([]*RelationCountRet, error) {
	sql := tx.Model(&model.TemplateRelation{})
	var ret []*RelationCountRet
	sql = sql.Select("template_id,count(1) as num").
		Where("template_id in ? and status = 0", templateIDs).Group("template_id")
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateRelationDao) RelationCountByTemplateID(tx *gorm.DB, templateID int64) (int64, error) {
	sql := tx.Model(&model.TemplateRelation{})
	var ret int64
	sql = sql.Select("template_id,count(1) as num").Where("template_id = ? and status = 0", templateID)
	err := sql.Count(&ret).Error
	return ret, err
}

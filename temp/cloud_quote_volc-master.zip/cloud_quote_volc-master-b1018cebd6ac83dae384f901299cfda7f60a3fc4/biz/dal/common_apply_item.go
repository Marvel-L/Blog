package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"context"
	"gorm.io/gorm"
)

var CommonApplyItemDao = &commonApplyItemDao{}

type commonApplyItemDao struct {
	baseDao
}

func (*commonApplyItemDao) FindApplyItem(tx *gorm.DB, quoteID int64, bizKey string) ([]*model.CommonApplyItem, error) {
	sql := tx.Model(&model.CommonApplyItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	if bizKey != "" {
		sql = sql.Where("biz_key = ?", bizKey)
	}
	var ret []*model.CommonApplyItem
	err := sql.Order("id asc").Find(&ret).Error
	return ret, err
}

func (c *commonApplyItemDao) FindApplyItemConfigIDs(tx *gorm.DB, quoteID int64, bizKey string) ([]int64, error) {
	sql := tx.Model(&model.CommonApplyItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	if bizKey != "" {
		sql = sql.Where("biz_key = ?", bizKey)
	}
	var ret []int64
	err := sql.Order("id asc").Pluck("config_id", &ret).Error
	return ret, err
}

func (*commonApplyItemDao) FindApplyItemByConfigID(tx *gorm.DB, quoteID int64, configID int64, bizKey string) ([]*model.CommonApplyItem, error) {
	sql := tx.Model(&model.CommonApplyItem{})
	sql = sql.Where("biz_key = ? and quote_id = ? and config_id = ? and status = 0", bizKey, quoteID, configID)
	var ret []*model.CommonApplyItem
	err := sql.Order("id asc").Find(&ret).Error
	return ret, err
}

func (c *commonApplyItemDao) FindApplyItemByConfigIDList(ctx context.Context, tx *gorm.DB, configIDList []int64, bizKey string) ([]*model.CommonApplyItem, error) {
	tx = c.initDB(ctx, tx)
	sql := tx.Model(&model.CommonApplyItem{})
	sql = sql.Where("biz_key = ? and config_id in (?) and status = 0", bizKey, configIDList)
	var ret []*model.CommonApplyItem
	err := sql.Order("id asc").Find(&ret).Error
	return ret, err
}

func (c *commonApplyItemDao) SoftDeleteApplyItemAll(tx *gorm.DB, quoteID int64, bizKey string) error {
	return c.SoftDeleteData(tx, Condition{"quote_id": quoteID, "biz_key": bizKey}, &model.CommonApplyItem{})
}

func (c *commonApplyItemDao) SoftDeleteApplyItemByConfigID(tx *gorm.DB, quoteID int64, configID int64, bizKey string) error {
	return c.SoftDeleteData(tx, Condition{"quote_id": quoteID, "config_id": configID, "biz_key": bizKey}, &model.CommonApplyItem{})
}

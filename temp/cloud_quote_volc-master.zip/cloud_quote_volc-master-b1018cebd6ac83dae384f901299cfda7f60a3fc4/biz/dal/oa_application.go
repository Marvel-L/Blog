package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var OaApplicationDao = &oaApplicationDao{}

type oaApplicationDao struct{}

func (d *oaApplicationDao) SaveOaApplication(tx *gorm.DB, app []*model.OaApplication) error {
	return tx.Model(&model.OaApplication{}).Save(app).Error
}

func (d *oaApplicationDao) FindOaApplicationByOaID(tx *gorm.DB, oaID int64) (*model.OaApplication, error) {
	tx = tx.Where("id = ?", oaID)
	ret := &model.OaApplication{}
	err := tx.First(ret).Error
	return ret, err
}

func (d *oaApplicationDao) FindOaApplicationByFormInstanceID(tx *gorm.DB, instanceID string) (*model.OaApplication, error) {
	tx = tx.Where("form_instance_id = ?", instanceID)
	ret := &model.OaApplication{}
	err := tx.First(ret).Error
	return ret, err
}

// OaMapByQuoteIDs return type: quoteID -> oa
func (d *oaApplicationDao) OaMapByQuoteIDs(tx *gorm.DB, quoteIDs []int64) (map[int64]*model.OaApplication, error) {
	tx = tx.Where("quote_id in ?", quoteIDs)
	var rows []*model.OaApplication
	if err := tx.Order("id").Find(&rows).Error; err != nil {
		return nil, err
	}
	ret := map[int64]*model.OaApplication{}
	for _, row := range rows {
		ret[row.QuoteID] = row
	}

	return ret, nil
}

func (d *oaApplicationDao) FindOaApplicationByQuoteID(tx *gorm.DB, quoteId int64) (*model.OaApplication, error) {
	tx = tx.Where("quote_id = ?", quoteId)
	ret := &model.OaApplication{}
	err := tx.Last(ret).Error
	return ret, err
}

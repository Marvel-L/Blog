package dal

import (
	"context"
	"errors"
	"time"

	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
)

var QuoteDao = &quoteDao{}

type quoteDao struct {
	baseDao
}

func (*quoteDao) FindQuoteByID(tx *gorm.DB, quoteID int64) (*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("id = ? and status = 0", quoteID)
	ret := &model.Quote{}
	err := sql.First(ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByConfigListQuoteID(tx *gorm.DB, configListQuoteID int64) ([]*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("quote_create_from = ? and status = 0", configListQuoteID)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByIDAndCustomerID(tx *gorm.DB, quoteID int64, customerID string) (*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("id = ? and status = 0", quoteID)
	if customerID != "" {
		sql = sql.Where("customer_detail = ? ", customerID)
	}
	ret := &model.Quote{}
	err := sql.First(ret).Error
	return ret, err
}

func (*quoteDao) FindQuotesByIDs(tx *gorm.DB, quoteIDs []int64) ([]*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("id in ? and status = 0", quoteIDs)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) ListQuoteByRange(tx *gorm.DB, start int64, end int64) ([]*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("id >= ? and id <=? and status = 0", start, end)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByCode(tx *gorm.DB, code string) (*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("code = ? and status = 0", code)
	ret := &model.Quote{}
	err := sql.First(ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByParentID(tx *gorm.DB, parentQuoteID int64) ([]*model.Quote, error) {

	sql := tx.Model(&model.Quote{})
	sql = sql.Where("parent_quote_id = ? and status = 0 and quote_scene = 30", parentQuoteID)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByParentConfigID(tx *gorm.DB, parentConfigID int64) ([]*model.Quote, error) {

	sql := tx.Model(&model.Quote{})
	sql = sql.Where("parent_config_id = ? and status = 0 and quote_scene = 300", parentConfigID)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) FindRelatedQuoteByMainID(tx *gorm.DB, mainQuoteID int64) ([]*model.Quote, error) {

	sql := tx.Model(&model.Quote{})
	sql = sql.Where("(main_quote_id = ? or id = ? )and status = 0", mainQuoteID, mainQuoteID)
	var ret []*model.Quote
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteDao) FindQuoteByConditions(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.Quote, int64, error) {
	sql := tx.Model(&model.Quote{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	if !util.RequestFromOpen(c) {
		currentUser, err := AccountDao.CurrentUser(c)
		if err != nil {
			return nil, 0, err
		}
		if currentUser != nil && currentUser.AccountType.Contains(constants.AccountTypeUser) {
			sql = sql.Where("sales_account_id = ? or solution_consultant_id = ? ", currentUser.AccountID, currentUser.AccountID)
		}
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.Quote
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (*quoteDao) FindQuoteByConditionsNoUser(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.Quote, int64, error) {
	sql := tx.Model(&model.Quote{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.Quote
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (*quoteDao) FindQuoteByConditionsNoUserWithoutCount(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var ret []*model.Quote
	err := sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, err
}

func (d *quoteDao) FindAllQuoteByConditions(c context.Context, tx *gorm.DB, condition framework.Condition) ([]*model.Quote, error) {
	var allQuotes []*model.Quote
	for i := 1; true; i++ {
		pageQuotes, err := d.FindQuoteByConditionsNoUserWithoutCount(c, tx, condition, 1000, i)
		if err != nil {
			return nil, err
		}
		allQuotes = append(allQuotes, pageQuotes...)
		if len(pageQuotes) < 1000 {
			break
		}
	}

	return allQuotes, nil
}

func (*quoteDao) QuoteItemCalsByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.QuoteItemCalculate, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Joins("join quote_item on quote_item.id = quote_item_calculate.quote_item_id")
	sql = sql.Where("quote_item.quote_id = ?", quoteID)
	var ret []*model.QuoteItemCalculate
	err := sql.Select("quote_item_calculate.*").Find(&ret).Error
	return ret, err
}

// QuoteItemCalcMapByQuoteID quoteItemID -> []quoteItemCalculate
func (d *quoteDao) QuoteItemCalcMapByQuoteID(tx *gorm.DB, quoteID int64) (map[int64]*model.QuoteItemCalculate, error) {
	rows, err := d.QuoteItemCalsByQuoteID(tx, quoteID)
	if err != nil {
		return nil, err
	}
	ret := map[int64]*model.QuoteItemCalculate{}
	for _, row := range rows {
		ret[row.QuoteItemID] = row
	}
	return ret, nil
}

func (d *quoteDao) UpdateQuoteStatusByQuoteID(tx *gorm.DB, quoteID int64, quoteStatus constants.QuoteStatus) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"quote_status": quoteStatus})
}

func (d *quoteDao) UpdateQuoteProfitCalculate(tx *gorm.DB, quoteID int64, projectProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"project_profit_calculate": projectProfitCalculate})
}
func (d *quoteDao) UpdateQuoteProfitCalculateChanged(tx *gorm.DB, quoteID int64, projectProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"project_profit_changed": projectProfitCalculate})
}

func (d *quoteDao) UpdateFactoryPriceProfitCalculate(tx *gorm.DB, quoteID int64, factoryPriceProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"factory_price_profit_calculate": factoryPriceProfitCalculate})
}

func (d *quoteDao) UpdateFactoryPriceProfitCalculateChanged(tx *gorm.DB, quoteID int64, factoryPriceProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"factory_price_profit_changed": factoryPriceProfitCalculate})
}

func (d *quoteDao) UpdateLatestResourceProfitCalculate(tx *gorm.DB, quoteID int64, latestResourceProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"latest_resource_profit_calculate": latestResourceProfitCalculate})
}

func (d *quoteDao) UpdateLatestResourceProfitCalculateChanged(tx *gorm.DB, quoteID int64, latestResourceProfitCalculate string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"latest_resource_profit_changed": latestResourceProfitCalculate})
}

func (d *quoteDao) UpdateQuoteCreditRiskInfo(tx *gorm.DB, quoteID int64, creditRiskInfo string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"credit_risk_info": creditRiskInfo})
}

func (d *quoteDao) SoftDeleteQuote(tx *gorm.DB, quoteIDs []int64) error {
	return d.SoftDeleteData(tx, Condition{"id": quoteIDs}, &model.Quote{})
}

func (*quoteDao) FindQuoteByOriginID(tx *gorm.DB, originID int64, withDeleted bool) ([]*model.Quote, error) {
	if originID == 0 {
		return nil, nil
	}
	sql := tx.Model(&model.Quote{})
	sql = sql.Where("origin_quote_id = ?", originID)
	if !withDeleted {
		sql = sql.Where("status = 0")
	}
	var ret []*model.Quote
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (d *quoteDao) UpdateConsumptionRatio(tx *gorm.DB, quoteID int64, consumptionRatio string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"consumption_ratio": consumptionRatio})
}

func (d *quoteDao) UpdateProductLineProfit(tx *gorm.DB, quoteID int64, productLineProfit string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"product_line_profit_calculate": productLineProfit})
}

func (d *quoteDao) UpdateProductLineProfitChanged(tx *gorm.DB, quoteID int64, productLineProfit string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"product_line_profit_changed": productLineProfit})
}

func (d *quoteDao) NotExist(quote *model.Quote) bool {
	if quote == nil {
		return true
	}
	return quote.Id == 0
}

func (d *quoteDao) UpdateQuoteTradeTypeCodeByQuoteID(tx *gorm.DB, quoteID int64, tradeTypeCode, orderTypeCode int) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"trade_type_code": tradeTypeCode, "order_type_code": orderTypeCode})
}

func (d *quoteDao) UpdateApprovalTime(tx *gorm.DB, quoteID int64, approvalStartTime, approvalEndTime time.Time) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"approval_start_time": approvalStartTime, "approval_end_time": approvalEndTime})
}

func (d *quoteDao) UpdateCreatorAccountID(tx *gorm.DB, quoteID int64, creatorAccountID, salesAccountID string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"creator_account_id": creatorAccountID, "sales_account_id": salesAccountID})
}

func (*quoteDao) FindQuoteAscByConditionsNoUser(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.Quote, error) {
	sql := tx.Model(&model.Quote{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")

	var ret []*model.Quote
	err := sql.Order("id asc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, err
}

// FindApprovalModifySyncQuotes 查询待同步审批进度的报价单，按 ID 游标递增扫描。
func (*quoteDao) FindApprovalModifySyncQuotes(tx *gorm.DB, lastID int64, limit int) ([]*model.Quote, error) {
	if limit <= 0 {
		limit = 100
	}
	var ret []*model.Quote
	// 仅扫描已重新送审且存在原始快照的正常报价单，避免旧流程单据进入回放。
	err := tx.Model(&model.Quote{}).
		Where("id > ?", lastID).
		Where("status = ?", constants.DataNormalStatus).
		Where("quote_status = ?", constants.StatusSubmit).
		Where("origin_snapshot_id > 0").
		Where("modify_status = ?", constants.ApprovalModifyStatusSubmitted).
		Order("id asc").
		Limit(limit).
		Find(&ret).Error
	return ret, err
}

// StartApprovalModifyByCAS 仅当报价单关键状态和版本链仍与读取时一致时发起审批中修改。
// 并发请求可能都完成快照复制，但只有一个事务能更新原单；失败事务中的快照会随事务回滚。
func (*quoteDao) StartApprovalModifyByCAS(tx *gorm.DB, quote *model.Quote, updates map[string]interface{}) (bool, error) {
	if quote == nil {
		return false, nil
	}
	result := tx.Model(&model.Quote{}).
		Where("id = ?", quote.Id).
		Where("status = ?", quote.Status).
		Where("quote_status = ?", quote.QuoteStatus).
		Where("modify_status = ?", quote.ModifyStatus).
		Where("origin_snapshot_id = ?", quote.OriginSnapshotID).
		Where("parent_snapshot_id = ?", quote.ParentSnapshotID).
		Updates(updates)
	return result.RowsAffected == 1, result.Error
}

// FinishApprovalModifySync 以 CAS 方式标记审批进度同步完成。
func (*quoteDao) FinishApprovalModifySync(tx *gorm.DB, quoteID int64) (bool, error) {
	// modify_status=2 是 CAS 前置条件，并发执行方只有一个能够完成 2 -> 3 状态迁移。
	result := tx.Model(&model.Quote{}).
		Where("id = ?", quoteID).
		Where("status = ?", constants.DataNormalStatus).
		Where("modify_status = ?", constants.ApprovalModifyStatusSubmitted).
		Update("modify_status", constants.ApprovalModifyStatusSyncFinished)
	return result.RowsAffected > 0, result.Error
}

func (d *quoteDao) UpdateQuoteStatusAndExpiredTimeByQuoteID(tx *gorm.DB, quoteID int64, quoteStatus constants.QuoteStatus, expiredTime time.Time) error {
	m := map[string]interface{}{"quote_status": quoteStatus}
	if !expiredTime.IsZero() {
		m["expired_time"] = expiredTime
	}
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, m)
}

func (d *quoteDao) UpdateModifyInfo(
	tx *gorm.DB,
	quoteID int64,
	modifyStatus int,
	modifyContext string,
	modifyStartTime time.Time,
) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"modify_status":     modifyStatus,
			"modify_context":    modifyContext,
			"modify_start_time": modifyStartTime,
		},
	)
}

func (d *quoteDao) UpdateModifyStatus(
	tx *gorm.DB,
	quoteID int64,
	modifyStatus int,
) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"modify_status": modifyStatus,
		},
	)
}

func (d *quoteDao) UpdateExpiredTime(
	tx *gorm.DB,
	quoteID int64,
	expiredTime time.Time,
) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"expired_time": expiredTime,
		},
	)
}

func (d *quoteDao) UpdateBackdatingContractNo(
	tx *gorm.DB,
	quoteID int64,
	backdatingContractNo string,
) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"backdating_contract_no": backdatingContractNo,
		},
	)
}

func (d *quoteDao) UpdatePriceValidPeriodStartTime(tx *gorm.DB, quoteID int64, startTime time.Time) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteID}, &model.Quote{}, map[string]interface{}{"price_valid_period_start_time": startTime})
}

func (d *quoteDao) UpdateTotalSalesInfo(
	tx *gorm.DB,
	quoteID int64,
	totalSales,
	incomeNoTax,
	vat decimal.Decimal,
) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"total_sales":   totalSales,
			"income_no_tax": incomeNoTax,
			"vat":           vat,
		},
	)
}

func (*quoteDao) FindMaxOpportunityIDByPrefix(tx *gorm.DB, prefix string) (string, error) {
	var oppID string
	err := tx.Model(&model.Quote{}).
		Select("opportunity_id").
		Where("opportunity_id like ?", prefix+"%").
		Order("opportunity_id DESC").
		Limit(1).
		Scan(&oppID).Error
	if err != nil {
		return "", err
	}
	return oppID, nil
}

// UpdateEffectiveTime 更新报价单生效时间
func (d *quoteDao) UpdateEffectiveTime(tx *gorm.DB, quoteID int64, effectiveTime time.Time) error {
	return d.UpdateByCondition(
		tx,
		Condition{"id": quoteID},
		&model.Quote{},
		map[string]interface{}{
			"effective_time": effectiveTime,
		},
	)
}

// FindAllQuoteIDsByConditions 根据条件查询所有符合条件的报价单id 注：此方法查询条件一定要做好限制，防止一次性查太多数据
func (d *quoteDao) FindAllQuoteIDsByConditions(tx *gorm.DB, condition framework.Condition) ([]int64, error) {
	if len(condition) == 0 {
		return nil, errors.New("empty condition")
	}

	sql := tx.Model(&model.Quote{})
	sql = framework.WhereMap(sql, condition)
	sql = sql.Where("status = 0")

	var quoteIDs []int64
	err := sql.Pluck("id", &quoteIDs).Error
	if err != nil {
		return nil, err
	}

	return quoteIDs, nil
}

package dal

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/gopkg/logs"
)

var ExtraConfigCouponDao = &extraConfigCouponDao{}

const (
	tOnlineCouponConfig        = "extra_config_coupon"
	tOnlineCouponConfigProduct = "extra_config_coupon_product_limit"
)

type extraConfigCouponDao struct {
	baseDao
}

func (c *extraConfigCouponDao) Create(ctx context.Context, tx *gorm.DB, vo *model.CouponConfigDB) error {

	tx = c.initDB(ctx, tx)

	err := tx.Table(tOnlineCouponConfig).Create(vo).Error
	if err != nil {
		logs.CtxError(ctx, "createCouponConfigFail, err:%s", err.Error())
		return i18nfmt.NewError(ctx, "createCouponConfigFail")
	}

	// 创建
	if len(vo.ProductLimits) == 0 {
		return nil
	}

	for _, v := range vo.ProductLimits {
		v.ConfigID = vo.Id
	}

	err = tx.Table(tOnlineCouponConfigProduct).CreateInBatches(vo.ProductLimits, len(vo.ProductLimits)).Error
	if err != nil {
		logs.CtxError(ctx, "createCouponConfigProductFail, err:%s", err.Error())
		return i18nfmt.NewError(ctx, "createCouponConfigProductFail")
	}

	return nil
}

func (c *extraConfigCouponDao) Update(ctx context.Context, tx *gorm.DB, vo *model.CouponConfigDB) error {

	tx = c.initDB(ctx, tx)

	updates := c.buildUpdates(ctx, vo)
	err := c.UpdateByMap(ctx, tx, vo.Id, updates)
	if err != nil {
		logs.CtxError(ctx, "updateCouponApplyFail, id=%s, err:%s", vo.Id, err.Error())
		return i18nfmt.NewError(ctx, "updateCouponApplyFail")
	}

	err = tx.Table(tOnlineCouponConfigProduct).Where("config_id = ?", vo.Id).Delete(nil).Error
	if err != nil {
		logs.CtxError(ctx, "deleteProductLimitFail, id=%s, err:%s", vo.Id, err.Error())
		return i18nfmt.NewError(ctx, "deleteProductLimitFail")
	}

	for _, v := range vo.ProductLimits {
		v.ConfigID = vo.Id
	}

	err = tx.Table(tOnlineCouponConfigProduct).CreateInBatches(vo.ProductLimits, len(vo.ProductLimits)).Error
	if err != nil {
		logs.CtxError(ctx, "createCouponApplyProductFail, err:%s", err.Error())
		return i18nfmt.NewError(ctx, "createCouponApplyProductFail")
	}
	return nil
}

func (c *extraConfigCouponDao) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := c.initDB(ctx, tx).Table(tOnlineCouponConfig)
	err := db.Where("id = ?", id).Updates(updates).Error
	if err != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.NewError(ctx, "UpdateByMapFail")
	}
	return nil
}

// UpdateHistoryFieldsIfUnchanged 按扫描时旧值更新历史代金券字段，避免覆盖并发编辑结果。
// todo 刷数后删除
func (c *extraConfigCouponDao) UpdateHistoryFieldsIfUnchanged(ctx context.Context, tx *gorm.DB, old *model.CouponConfigDB, updates map[string]interface{}) (int64, error) {
	if old == nil || len(updates) == 0 {
		return 0, nil
	}

	db := c.initDB(ctx, tx).Model(&model.CouponConfigDB{}).
		Where("id = ? and status = ?", old.Id, constants.DataNormalStatus).
		Where("rebate_coupon_way = ?", old.RebateCouponWay)
	if _, ok := updates["trigger_info"]; ok {
		db = db.Where("trigger_info = ?", old.TriggerInfo)
	}
	if _, ok := updates["rule_validity_info"]; ok {
		if old.RuleValidityInfo == "" {
			db = db.Where("(rule_validity_info is null or rule_validity_info = '')")
		} else {
			db = db.Where("rule_validity_info = ?", old.RuleValidityInfo)
		}
	}
	if _, ok := updates["cap_info"]; ok {
		if old.CapInfo == "" {
			db = db.Where("(cap_info is null or cap_info = '')")
		} else {
			db = db.Where("cap_info = ?", old.CapInfo)
		}
	}

	updateValues := make(map[string]interface{}, len(updates)+1)
	for key, value := range updates {
		updateValues[key] = value
	}
	updateValues["updated_time"] = time.Now()
	ret := db.Updates(updateValues)
	if ret.Error != nil {
		logs.CtxError(ctx, "UpdateHistoryFieldsIfUnchanged fail, id=%d, err=%v", old.Id, ret.Error)
		return 0, i18nfmt.NewError(ctx, "UpdateHistoryFieldsIfUnchangedFail")
	}
	return ret.RowsAffected, nil
}

func (c *extraConfigCouponDao) UpdateRefreshTypeByIDs(ctx context.Context, tx *gorm.DB, ids []int64, refreshType int) error {
	if len(ids) == 0 {
		return nil
	}
	db := c.initDB(ctx, tx).Table(tOnlineCouponConfig)
	err := db.Where("id in (?)", ids).Updates(map[string]interface{}{"refresh_type": refreshType}).Error
	if err != nil {
		logs.CtxError(ctx, "UpdateRefreshTypeByIDsFail, ids=%v, err:%v", ids, err)
		return i18nfmt.NewError(ctx, "UpdateRefreshTypeByIDsFail")
	}
	return nil
}

func (c *extraConfigCouponDao) buildUpdates(ctx context.Context, vo *model.CouponConfigDB) map[string]interface{} {
	ret := map[string]interface{}{
		"coupon_type":                vo.CouponType,
		"account_id":                 vo.AccountID,
		"accumulate_type":            vo.AccumulateType,
		"rebate_coupon_way":          vo.RebateCouponWay,
		"coupon_usage":               vo.CouponUsage,
		"applicant":                  vo.Applicant,
		"applicant_department":       vo.ApplicantDepartment,
		"apply_source":               vo.ApplySource,
		"enable_balance_alert":       vo.EnableBalanceAlert,
		"disable_inner_expire_alert": vo.DisableInnerExpireAlert,
		"balance_alert_threshold":    vo.BalanceAlertThreshold,
		"coupon_alarm_members":       vo.CouponAlarmMembers,
		"trigger_info":               vo.TriggerInfo,
		"order_type_limit":           vo.OrderTypeLimit,
		"valid_time_type":            vo.ValidTimeType,
		"valid_begin_time":           vo.ValidBeginTime,
		"valid_end_time":             vo.ValidEndTime,
		"valid_days":                 vo.ValidDays,
		"usage_limit":                vo.UsageLimit,
		"amount_limit":               vo.AmountLimit,
		"pay_type_limit":             vo.PayTypeLimit,
		"remark":                     vo.Remark,
		"copy_from":                  vo.CopyFrom,
		"change_from":                vo.ChangeFrom,
		"bill_caliber":               vo.BillCaliber,
		"rebate_period":              vo.RebatePeriod,
		"rule_validity_info":         vo.RuleValidityInfo,
		"cap_info":                   vo.CapInfo,
		"rebate_threshold_type":      vo.RebateThresholdType,
	}
	return ret
}

func (c *extraConfigCouponDao) UpdateConfigOnly(ctx context.Context, tx *gorm.DB, vo *model.CouponConfigDB) error {
	tx = c.initDB(ctx, tx)

	updates := c.buildUpdates(ctx, vo)
	err := c.UpdateByMap(ctx, tx, vo.Id, updates)
	if err != nil {
		logs.CtxError(ctx, "UpdateConfigOnlyFail, id=%s, err:%s", vo.Id, err.Error())
		return i18nfmt.NewError(ctx, "UpdateConfigOnlyFail")
	}

	return nil
}

func (c *extraConfigCouponDao) FindByID(ctx context.Context, tx *gorm.DB, id int64) (*model.CouponConfigDB, error) {
	sql := tx.Model(&model.CouponConfigDB{})
	sql = sql.Where("id = ? and status = ?", id, constants.DataNormalStatus)
	ret := &model.CouponConfigDB{}
	err := sql.First(ret).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	} else if err != nil {
		return nil, i18nfmt.NewError(ctx, "FindByApplyNoFail")
	}

	ret.ProductLimits, _ = c.getRelatedProducts(ctx, tx, id)
	return ret, nil
}

func (c *extraConfigCouponDao) FindByIdList(ctx context.Context, tx *gorm.DB, ids []int64) (model.CouponConfigDBList, error) {

	sql := tx.Model(&model.CouponConfigDB{})
	sql = sql.Where("id in (?) and status = ?", ids, constants.DataNormalStatus)
	var couponList []*model.CouponConfigDB
	err := sql.Find(&couponList).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	} else if err != nil {
		return nil, i18nfmt.NewError(ctx, "FindByIdListFail")
	}

	list, _ := c.getRelatedProductsByIdList(ctx, tx, ids)
	group := map[int64][]*model.CouponConfigProductsLimitDB{}
	for _, v := range list {
		group[v.ConfigID] = append(group[v.ConfigID], v)
	}

	for _, v := range couponList {
		v.ProductLimits = group[v.Id]
	}

	return couponList, nil
}

// FindByIDRange 分页查询指定 ID 闭区间内的有效代金券。
// todo 刷数后删除
func (c *extraConfigCouponDao) FindByIDRange(ctx context.Context, tx *gorm.DB, startID, endID int64, limit int) (model.CouponConfigDBList, error) {
	db := c.initDB(ctx, tx).Model(&model.CouponConfigDB{}).
		Where("id >= ? and id <= ? and status = ?", startID, endID, constants.DataNormalStatus).
		Order("id asc")
	if limit > 0 {
		db = db.Limit(limit)
	}

	var couponList model.CouponConfigDBList
	if err := db.Find(&couponList).Error; err != nil {
		logs.CtxError(ctx, "FindCouponByIDRangeFail, startID=%d, endID=%d, limit=%d, err=%v", startID, endID, limit, err)
		return nil, i18nfmt.NewError(ctx, "FindByIdListFail")
	}
	return couponList, nil
}

func (c *extraConfigCouponDao) getRelatedProducts(ctx context.Context, tx *gorm.DB, id int64) (model.CouponConfigProductsLimitDBList, error) {
	sql := tx.Model(&model.CouponConfigProductsLimitDB{})
	sql = sql.Where("config_id = ?  and status = ?", id, constants.DataNormalStatus).Order("id asc")
	var list []*model.CouponConfigProductsLimitDB
	err := sql.Find(&list).Error
	if err != nil {
		logs.CtxError(ctx, "getRelatedProductsFail, err:%s", err.Error())
		// 忽略错误信息
	}
	return list, nil
}

func (c *extraConfigCouponDao) getRelatedProductsByIdList(ctx context.Context, tx *gorm.DB, ids []int64) (model.CouponConfigProductsLimitDBList, error) {
	sql := tx.Model(&model.CouponConfigProductsLimitDB{})
	sql = sql.Where("config_id in (?) and status = ?", ids, constants.DataNormalStatus).Order("id asc")
	var list []*model.CouponConfigProductsLimitDB
	err := sql.Find(&list).Error
	if err != nil {
		logs.CtxError(ctx, "getRelatedProductsFail, err:%s", err.Error())
		// 忽略错误信息
	}
	return list, nil
}

func (c *extraConfigCouponDao) SoftDeleteByIds(tx *gorm.DB, ids []int64) error {
	return c.SoftDeleteData(tx, Condition{"id": ids}, &model.CouponConfigDB{})
}

func (c *extraConfigCouponDao) ListAll(ctx context.Context, tx *gorm.DB) (model.CouponConfigDBList, error) {
	sql := tx.Model(&model.CouponConfigDB{})
	sql = sql.Where("status = ?", constants.DataNormalStatus)
	var couponList []*model.CouponConfigDB
	err := sql.Find(&couponList).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	} else if err != nil {
		return nil, i18nfmt.NewError(ctx, "ListAllFail")
	}

	return couponList, nil
}

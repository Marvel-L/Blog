package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var QuoteSolutionDao = &quoteSolutionDao{}

type quoteSolutionDao struct {
	baseDao
}

func (*quoteSolutionDao) FindQuoteSolutionsByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.QuoteSolution, error) {
	sql := tx.Model(&model.QuoteSolution{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.QuoteSolution
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteSolutionDao) FindQuoteSolutionMapByQuoteID(tx *gorm.DB, quoteID int64) (map[int64]*model.QuoteSolution, error) {
	quoteSolutions, err := d.FindQuoteSolutionsByQuoteID(tx, quoteID)
	if err != nil {
		return nil, err
	}
	quoteSolutionMap := map[int64]*model.QuoteSolution{}
	for _, quoteSolution := range quoteSolutions {
		quoteSolutionMap[quoteSolution.Id] = quoteSolution
	}
	return quoteSolutionMap, err
}

func (*quoteSolutionDao) FindQuoteSolutionsByQuoteIDAndSolutionType(tx *gorm.DB, quoteID int64, solutionType int8) ([]*model.QuoteSolution, error) {
	sql := tx.Model(&model.QuoteSolution{})
	sql = sql.Where("quote_id = ? and solution_type = ? and status = 0", quoteID, solutionType)
	var ret []*model.QuoteSolution
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteSolutionDao) FindQuoteSolutionByIDs(tx *gorm.DB, ids []int64) ([]*model.QuoteSolution, error) {
	sql := tx.Model(&model.QuoteSolution{})
	sql = sql.Where("id in ? and status = 0", ids)
	var ret []*model.QuoteSolution
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteSolutionDao) FindQuoteSolutionByID(tx *gorm.DB, quoteSolutionID int64) (*model.QuoteSolution, error) {
	sql := tx.Model(&model.QuoteSolution{})
	sql = sql.Where("id = ? and status = 0", quoteSolutionID)
	ret := &model.QuoteSolution{}
	err := sql.First(ret).Error
	return ret, err
}

func (d *quoteSolutionDao) FindQuoteSolutionMapByIDs(tx *gorm.DB, ids []int64) (map[int64]*model.QuoteSolution, error) {
	quoteSolutions, err := d.FindQuoteSolutionByIDs(tx, ids)
	if err != nil {
		return nil, err
	}
	quoteSolutionMap := map[int64]*model.QuoteSolution{}
	for _, quoteSolution := range quoteSolutions {
		quoteSolutionMap[quoteSolution.Id] = quoteSolution
	}
	return quoteSolutionMap, err
}

func (d *quoteSolutionDao) SoftDelete(tx *gorm.DB, ids []int64) error {
	return d.SoftDeleteData(tx, Condition{"id": ids}, &model.QuoteSolution{})
}

func (d *quoteSolutionDao) FindAllSolution(tx *gorm.DB) ([]*model.QuoteSolution, error) {
	sql := tx.Model(&model.QuoteSolution{})
	sql = sql.Where("1 = 1").Order("id desc")
	var ret []*model.QuoteSolution
	err := sql.Find(&ret).Error
	return ret, err
}

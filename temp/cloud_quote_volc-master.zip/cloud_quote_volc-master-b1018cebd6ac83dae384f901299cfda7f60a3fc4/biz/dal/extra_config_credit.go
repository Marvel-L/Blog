package dal

import (
	"context"
	"errors"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

var ExtraConfigCreditDao = &extraConfigCreditDao{}

type extraConfigCreditDao struct {
	baseDao
}

func (c *extraConfigCreditDao) FindByIds(ctx context.Context, tx *gorm.DB, ids []int64) (model.ExtraConfigCreditDBList, error) {

	sql := tx.Model(&model.ExtraConfigCreditDB{})
	sql = sql.Where("id in (?) and status = ?", ids, constants.DataNormalStatus)
	var couponList []*model.ExtraConfigCreditDB
	err := sql.Find(&couponList).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	} else if err != nil {
		return nil, i18nfmt.NewError(ctx, "FindByIdListFail")
	}

	return couponList, nil
}

func (c *extraConfigCreditDao) SoftDeleteByIds(tx *gorm.DB, ids []int64) error {
	return c.SoftDeleteData(tx, Condition{"id": ids}, &model.ExtraConfigCreditDB{})
}

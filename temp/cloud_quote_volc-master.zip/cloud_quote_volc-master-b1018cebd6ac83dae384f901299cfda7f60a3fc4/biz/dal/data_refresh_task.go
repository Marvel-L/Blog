package dal

import (
	"errors"

	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var DataRefreshTaskDao = &dataRefreshTaskDao{}

type dataRefreshTaskDao struct {
	baseDao
}

func (d *dataRefreshTaskDao) Create(tx *gorm.DB, task *model.DataRefreshTask) error {
	return d.Save(tx, task, &model.DataRefreshTask{})
}

func (*dataRefreshTaskDao) FindByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.DataRefreshTask, error) {
	var ret []*model.DataRefreshTask
	err := tx.Model(&model.DataRefreshTask{}).
		Where("quote_id = ? and status = 0", quoteID).
		Order("id desc").
		Find(&ret).Error
	return ret, err
}

func (*dataRefreshTaskDao) FindByQuoteIDAndIDList(tx *gorm.DB, quoteID int64, ids []int64) ([]*model.DataRefreshTask, error) {
	sql := tx.Model(&model.DataRefreshTask{}).
		Where("quote_id = ? and status = 0", quoteID)
	if len(ids) > 0 {
		sql = sql.Where("id in (?)", ids)
	}

	var ret []*model.DataRefreshTask
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (*dataRefreshTaskDao) FindByID(tx *gorm.DB, id int64) (*model.DataRefreshTask, error) {
	ret := &model.DataRefreshTask{}
	err := tx.Model(&model.DataRefreshTask{}).
		Where("id = ? and status = 0", id).
		First(ret).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return ret, nil
}

func (*dataRefreshTaskDao) FindByIDList(tx *gorm.DB, ids []int64) ([]*model.DataRefreshTask, error) {
	ret := make([]*model.DataRefreshTask, 0)
	if len(ids) == 0 {
		return ret, nil
	}
	err := tx.Model(&model.DataRefreshTask{}).
		Where("id in (?) and status = 0", ids).
		Find(&ret).Error
	return ret, err
}

func (*dataRefreshTaskDao) FindByCondition(tx *gorm.DB, quoteID int64, itemID int64, opType string, bizScene string, taskStatusList []string) ([]*model.DataRefreshTask, error) {
	sql := tx.Model(&model.DataRefreshTask{}).Where("status = 0")
	if quoteID != 0 {
		sql = sql.Where("quote_id = ?", quoteID)
	}
	if itemID != 0 {
		sql = sql.Where("item_id = ?", itemID)
	}
	if opType != "" {
		sql = sql.Where("op_type = ?", opType)
	}
	if bizScene != "" {
		sql = sql.Where("biz_scene = ?", bizScene)
	}
	if len(taskStatusList) > 0 {
		sql = sql.Where("task_status in (?)", taskStatusList)
	}

	var ret []*model.DataRefreshTask
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

func (d *dataRefreshTaskDao) FindByContractNoAndItemIDsAndTaskStatus(tx *gorm.DB, contractNo string, itemIDs []int64, taskStatus string) ([]*model.DataRefreshTask, error) {
	return d.FindByContractNoAndItemIDsAndTaskStatusList(tx, contractNo, itemIDs, []string{taskStatus})
}

func (*dataRefreshTaskDao) FindByContractNoAndItemIDsAndTaskStatusList(tx *gorm.DB, contractNo string, itemIDs []int64, taskStatusList []string) ([]*model.DataRefreshTask, error) {
	if len(itemIDs) == 0 || len(taskStatusList) == 0 {
		return []*model.DataRefreshTask{}, nil
	}
	var ret []*model.DataRefreshTask
	err := tx.Model(&model.DataRefreshTask{}).
		Where("status = 0").
		Where("contract_no = ?", contractNo).
		Where("item_id in (?)", itemIDs).
		Where("task_status in (?)", taskStatusList).
		Order("id desc").
		Find(&ret).Error
	return ret, err
}

func (*dataRefreshTaskDao) ExistsByBizKey(tx *gorm.DB, quoteID int64, itemID int64, bizScene string) (bool, error) {
	var count int64
	err := tx.Model(&model.DataRefreshTask{}).
		Where("status = 0").
		Where("quote_id = ?", quoteID).
		Where("item_id = ?", itemID).
		Where("biz_scene = ?", bizScene).
		Count(&count).Error
	return count > 0, err
}

func (d *dataRefreshTaskDao) SoftDeleteByID(tx *gorm.DB, id int64) error {
	return d.SoftDeleteData(tx, Condition{"id": id}, &model.DataRefreshTask{})
}

func (d *dataRefreshTaskDao) BatchUpdateTaskStatusByIDs(tx *gorm.DB, ids []int64, taskStatus string) error {
	if len(ids) == 0 {
		return nil
	}
	return d.UpdateByCondition(tx, Condition{"id": ids}, &model.DataRefreshTask{}, map[string]interface{}{"task_status": taskStatus})
}

func (d *dataRefreshTaskDao) BatchUpdateTaskStatusByIDsAndStatus(tx *gorm.DB, ids []int64, fromStatus string, toStatus string) error {
	return d.BatchUpdateTaskStatusByIDsAndStatusList(tx, ids, []string{fromStatus}, toStatus)
}

func (d *dataRefreshTaskDao) BatchUpdateTaskStatusByIDsAndStatusList(tx *gorm.DB, ids []int64, fromStatusList []string, toStatus string) error {
	if len(ids) == 0 || len(fromStatusList) == 0 {
		return nil
	}
	return d.UpdateByCondition(tx, Condition{"id": ids, "task_status": fromStatusList}, &model.DataRefreshTask{}, map[string]interface{}{"task_status": toStatus})
}

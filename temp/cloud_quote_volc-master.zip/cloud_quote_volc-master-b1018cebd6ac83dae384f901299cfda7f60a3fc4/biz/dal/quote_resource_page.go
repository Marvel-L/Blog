package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

// QuoteResourcePageDao 数据查询对象
var QuoteResourcePageDao = &quoteResourcePageDao{}

type quoteResourcePageDao struct {
	baseDao
}

// FindPageByQuoteID 报价单查询资源单
func (d *quoteResourcePageDao) FindPageByQuoteID(tx *gorm.DB, quoteID int64) (*model.QuoteResourcePage, error) {
	sql := tx.Model(&model.QuoteResourcePage{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	ret := &model.QuoteResourcePage{}
	err := sql.First(ret).Error
	return ret, err
}

// FindPageMapByCustomerAccountID 客户账号模糊查询资源单
func (d *quoteResourcePageDao) FindPageMapByCustomerAccountID(
	tx *gorm.DB,
	customerAccountID string,
) (map[int64]*model.QuoteResourcePage, error) {
	sql := tx.Model(&model.QuoteResourcePage{})
	fuzzKeyword := MakeFuzz(customerAccountID)
	sql = sql.Where("customer_account_id like ? and status = 0", fuzzKeyword)
	var rows []*model.QuoteResourcePage
	if err := sql.Order("id").Find(&rows).Error; err != nil {
		return nil, err
	}
	ret := map[int64]*model.QuoteResourcePage{}
	for _, row := range rows {
		ret[row.QuoteID] = row
	}
	return ret, nil
}

// SoftDeleteResourcePage 删除资源单
func (d *quoteResourcePageDao) SoftDeleteResourcePage(tx *gorm.DB, quoteID int64) error {
	condition := Condition{"quote_id": quoteID}
	return d.SoftDeleteData(tx, condition, &model.QuoteResourcePage{})
}

// UpdateCustomerAccountIDByQuoteID 更新资源卡客户id
func (d *quoteResourcePageDao) UpdateCustomerAccountIDByQuoteID(
	tx *gorm.DB,
	quoteID int64,
	customerAccountID string,
) error {
	condition := Condition{"quote_id": quoteID}
	return d.UpdateByCondition(
		tx,
		condition,
		&model.QuoteResourcePage{},
		map[string]interface{}{"customer_account_id": customerAccountID},
	)
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var TemplateItemCalculateDao = &templateItemCalculateDao{}

type templateItemCalculateDao struct {
	baseDao
}

func (*templateItemCalculateDao) TplItemCalsByQuoteItemIDs(tx *gorm.DB, tplItemIDs []int64, templateID int64) ([]*model.TemplateItemCalculate, error) {
	sql := tx.Model(&model.TemplateItemCalculate{})
	sql = sql.Where("template_id = ? and template_item_id in ? and status = 0", templateID, tplItemIDs)
	var ret []*model.TemplateItemCalculate
	err := sql.Find(&ret).Error
	return ret, err
}

func (*templateItemCalculateDao) TplItemCalsByItemIDs(tx *gorm.DB, tplItemIDs []int64) ([]*model.TemplateItemCalculate, error) {
	sql := tx.Model(&model.TemplateItemCalculate{})
	sql = sql.Where("template_item_id in ? and status = 0", tplItemIDs)
	var ret []*model.TemplateItemCalculate
	err := sql.Find(&ret).Error
	return ret, err
}

// TplItemCalcMapByQuoteItemIDs templateItemID -> TemplateItemCalculate
func (d *templateItemCalculateDao) TplItemCalcMapByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64, templateID int64) (map[int64]*model.TemplateItemCalculate, error) {
	rows, err := d.TplItemCalsByQuoteItemIDs(tx, quoteItemIDs, templateID)
	if err != nil {
		return nil, err
	}
	ret := map[int64]*model.TemplateItemCalculate{}
	for _, row := range rows {
		ret[row.TemplateItemId] = row
	}
	return ret, nil
}

func (d *templateItemCalculateDao) SoftDelete(tx *gorm.DB, templateID int64, templateItemIDs []int64) error {
	return d.SoftDeleteData(tx,
		Condition{
			"template_id":      templateID,
			"template_item_id": templateItemIDs,
		}, &model.TemplateItemCalculate{})
}

func (d *templateItemCalculateDao) UpdateTemplateIDAndStatus(tx *gorm.DB, templateItemID, templateID int64, status int) error {
	return d.UpdateByCondition(tx,
		Condition{"template_item_id": templateItemID},
		&model.TemplateItemCalculate{},
		map[string]interface{}{
			"template_id": templateID,
			"status":      status,
		})
}

func (d *templateItemCalculateDao) InitItemCalMap(tx *gorm.DB, templateID int64, tplItemIDs []int64) (map[int64]*model.TemplateItemCalculate, error) {
	itemCals, err := d.TplItemCalsByQuoteItemIDs(tx, tplItemIDs, templateID)
	if err != nil {
		return nil, err
	}
	itemCalMap := map[int64]*model.TemplateItemCalculate{}
	for _, itemCal := range itemCals {
		itemCalMap[itemCal.TemplateItemId] = itemCal
	}

	for _, tplItemID := range tplItemIDs {
		_, ok := itemCalMap[tplItemID]
		if !ok {
			itemCalMap[tplItemID] = &model.TemplateItemCalculate{
				TemplateId:     templateID,
				TemplateItemId: tplItemID,
			}
		}
	}
	return itemCalMap, nil
}

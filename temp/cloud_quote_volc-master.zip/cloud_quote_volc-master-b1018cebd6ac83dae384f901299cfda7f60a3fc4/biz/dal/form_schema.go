package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/util"
	"gorm.io/gorm"
)

var FormSchemaDao = &formSchemaDao{}

type formSchemaDao struct {
	baseDao
}

func (f *formSchemaDao) FindSchemaByScene(tx *gorm.DB, bizScene int) ([]*model.FormSchema, error) {
	sql := tx.Model(&model.FormSchema{})
	sql = sql.Where("biz_scene = ? and status = 0", bizScene)
	var ret []*model.FormSchema
	err := sql.Find(&ret).Error
	return ret, err
}

func (f *formSchemaDao) FindSchemaMapByScene(tx *gorm.DB, bizScene int) (map[string]*model.FormSchema, error) {

	formSchemas, err := f.FindSchemaByScene(tx, bizScene)
	if err != nil {
		return nil, err
	}
	ret := map[string]*model.FormSchema{}
	for _, formSchema := range formSchemas {
		ret[formSchema.AttrKey] = formSchema
	}
	return ret, err
}

func (f formSchemaDao) FindFormSchemaByKey(productType constants.ProductType, standardProduct int, formSchemaKey string) *model.FormSchema {
	schemaMap := FormSchemaMap[util.GetMapKey(productType, standardProduct)]
	return schemaMap[formSchemaKey]
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
	"context"
	"gorm.io/gorm"
)

var DiscountFunctionRuleDao = &discountFunctionRuleDao{}

type discountFunctionRuleDao struct {
	baseDao
}

func (*discountFunctionRuleDao) FindByID(tx *gorm.DB, id int64) (*model.DiscountFunctionRule, error) {
	sql := tx.Model(&model.DiscountFunctionRule{})
	sql = sql.Where("id = ? and status = 0", id)
	ret := &model.DiscountFunctionRule{}
	err := sql.First(ret).Error
	return ret, err
}

func (*discountFunctionRuleDao) FindByConditions(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.DiscountFunctionRule, int64, error) {
	sql := tx.Model(&model.DiscountFunctionRule{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.DiscountFunctionRule
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (*discountFunctionRuleDao) FindByIDs(tx *gorm.DB, ids []int64) ([]*model.DiscountFunctionRule, error) {
	sql := tx.Model(&model.DiscountFunctionRule{})
	sql = sql.Where("id in ? and status = 0", ids)
	var ret []*model.DiscountFunctionRule
	err := sql.Find(&ret).Error
	return ret, err
}

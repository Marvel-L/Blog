package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var ChangeDiscountQuoteItemDao = &changeDiscountQuoteItemDao{}

type changeDiscountQuoteItemDao struct {
	baseDao
}

func (*changeDiscountQuoteItemDao) FindChangeDiscountQuoteItemByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.ChangeDiscountQuoteItem, int64, error) {
	sql := tx.Model(&model.ChangeDiscountQuoteItem{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.ChangeDiscountQuoteItem
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (*changeDiscountQuoteItemDao) FindChangeDiscountQuoteItemByConditionsWithOrder(tx *gorm.DB, condition framework.Condition, limit, offset int, orderType string) ([]*model.ChangeDiscountQuoteItem, int64, error) {
	sql := tx.Model(&model.ChangeDiscountQuoteItem{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.ChangeDiscountQuoteItem
	err = sql.Order(multienv.GetOrderSQL(orderType)).Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *changeDiscountQuoteItemDao) FindChangeDiscountQuoteItemByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.ChangeDiscountQuoteItem, error) {

	condition := framework.Condition{}
	condition["quote_id"] = quoteID

	var quoteItems []*model.ChangeDiscountQuoteItem
	for i := 1; true; i++ {
		pageQuoteItems, _, err := d.FindChangeDiscountQuoteItemByConditions(tx, condition, 1000, i)
		if err != nil {
			return nil, err
		}
		quoteItems = append(quoteItems, pageQuoteItems...)

		if len(pageQuoteItems) < 1000 {
			break
		}
	}

	return quoteItems, nil
}

func (*changeDiscountQuoteItemDao) FindChangeDiscountQuoteItemByID(tx *gorm.DB, ids []int64) ([]*model.ChangeDiscountQuoteItem, error) {
	sql := tx.Model(&model.ChangeDiscountQuoteItem{})
	sql = sql.Where("id in (?) and status = 0", ids)
	var ret []*model.ChangeDiscountQuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

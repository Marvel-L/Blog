package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var TemplateSolutionDao = &templateSolutionDao{}

type templateSolutionDao struct {
	baseDao
}

func (*templateSolutionDao) FindTplTradeSolution(tx *gorm.DB, templateID int64, tradeSolution string, tradeSolutionVersion string) (*model.TemplateSolution, error) {
	sql := tx.Model(&model.TemplateSolution{})
	sql = sql.Where("template_id = ? and trade_solution = ? and trade_solution_version = ? and status = 0", templateID, tradeSolution, tradeSolutionVersion)
	ret := &model.TemplateSolution{}

	err := sql.Last(ret).Error
	return ret, err
}

func (*templateSolutionDao) FindTplSolution(tx *gorm.DB, templateIDs []int64) ([]*model.TemplateSolution, error) {
	sql := tx.Model(&model.TemplateSolution{})
	sql = sql.Where("template_id in ? and status = 0", templateIDs)
	var ret []*model.TemplateSolution
	err := sql.Find(&ret).Error
	return ret, err
}
func (d *templateSolutionDao) FindTplSolutionMap(tx *gorm.DB, templateIDs []int64) (map[int64]*model.TemplateSolution, error) {
	tplSolutions, err := d.FindTplSolution(tx, templateIDs)
	if err != nil {
		return nil, err
	}
	tplSolutionMap := map[int64]*model.TemplateSolution{}
	for _, tplSolution := range tplSolutions {
		tplSolutionMap[tplSolution.Id] = tplSolution
	}
	return tplSolutionMap, err
}
func (d *templateSolutionDao) FindTplSolutionByIDs(tx *gorm.DB, ids []int64) ([]*model.TemplateSolution, error) {
	sql := tx.Model(&model.TemplateSolution{})
	sql = sql.Where("id in ? and status = 0", ids)
	var ret []*model.TemplateSolution
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *templateSolutionDao) FindTplSolutionMapByIDs(tx *gorm.DB, ids []int64) (map[int64]*model.TemplateSolution, error) {
	tplSolutions, err := d.FindTplSolutionByIDs(tx, ids)
	if err != nil {
		return nil, err
	}
	tplSolutionMap := map[int64]*model.TemplateSolution{}
	for _, tplSolution := range tplSolutions {
		tplSolutionMap[tplSolution.Id] = tplSolution
	}
	return tplSolutionMap, err
}

func (d *templateSolutionDao) SoftDelete(tx *gorm.DB, ids []int64) error {
	return d.SoftDeleteData(tx, Condition{"id": ids}, &model.TemplateSolution{})
}

func (d *templateSolutionDao) FindAllTplSolution(tx *gorm.DB) ([]*model.TemplateSolution, error) {
	sql := tx.Model(&model.TemplateSolution{})
	sql = sql.Where("1 = 1").Order("id desc")
	var ret []*model.TemplateSolution
	err := sql.Find(&ret).Error
	return ret, err
}

// FindTplSolutionWithSolutionType 查询模版解决方案(1：解决方案，2：一体机套餐)
func (*templateSolutionDao) FindTplSolutionWithSolutionType(tx *gorm.DB, templateIDs []int64, solutionType int) ([]*model.TemplateSolution, error) {
	sql := tx.Model(&model.TemplateSolution{})
	sql = sql.Where("template_id in ? and status = 0 and solution_type= ?", templateIDs, solutionType)
	var ret []*model.TemplateSolution
	err := sql.Find(&ret).Error
	return ret, err
}

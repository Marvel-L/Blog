package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var DiscountSnapshotDao = &discountSnapshotDao{}

type discountSnapshotDao struct {
	baseDao
}

func (*discountSnapshotDao) FindDiscountSnapshotsByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.DuplicatedDiscountSnapshot, error) {
	sql := tx.Model(&model.DuplicatedDiscountSnapshot{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.DuplicatedDiscountSnapshot
	err := sql.Find(&ret).Error
	return ret, err
}

func (*discountSnapshotDao) SoftDelete(tx *gorm.DB, quoteID int64, checkSource int) error {
	return tx.Model(&model.DuplicatedDiscountSnapshot{}).Where("quote_id = ? and check_source = ? and status = 0", quoteID, checkSource).Update("status", 1).Error
}

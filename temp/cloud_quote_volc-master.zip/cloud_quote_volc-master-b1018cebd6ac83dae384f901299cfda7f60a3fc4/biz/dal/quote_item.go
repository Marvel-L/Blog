package dal

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"
	"gorm.io/gorm/schema"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"
)

var QuoteItemDao = &quoteItemDao{}

type quoteItemDao struct {
	baseDao
}

type QuoteItemSaveOption func(tx *gorm.DB, items []*model.QuoteItem, tb schema.Tabler)

func WithQuoteItemSaveOptionSetModifyTime() QuoteItemSaveOption {
	return func(tx *gorm.DB, items []*model.QuoteItem, tb schema.Tabler) {
		now := time.Now()
		for _, item := range items {
			item.ModifyTime = now
		}
	}
}

func (d *quoteItemDao) SaveWithOption(tx *gorm.DB, items []*model.QuoteItem, tb schema.Tabler, opts ...QuoteItemSaveOption) error {
	for _, opt := range opts {
		opt(tx, items, tb)
	}
	return d.Save(tx, items, tb)
}

func (d *quoteItemDao) BatchSaveWithOption(tx *gorm.DB, items []*model.QuoteItem, tb schema.Tabler, batchSize int, opts ...QuoteItemSaveOption) error {
	for _, opt := range opts {
		opt(tx, items, tb)
	}
	return d.BatchSave(tx, items, tb, batchSize)
}

func (d *quoteItemDao) SoftDeleteQuoteItems(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) error {
	condition := Condition{"id": quoteItemIDs}
	if quoteID > 0 {
		condition["quote_id"] = quoteID
	}
	return d.SoftDeleteData(tx, condition, &model.QuoteItem{})
}

func (*quoteItemDao) FindQuoteItemsByQuoteID(tx *gorm.DB, quoteID int64, itemStatus int, itemType constants.ProductType, itemScene int) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ? ", itemStatus)
	}
	if itemType != multienv.TradeProductTypeAll {
		sql = sql.Where("item_type = ? ", itemType)
	}
	if itemScene != constants.ItemSceneAll {
		sql = sql.Where("item_scene = ? ", itemScene)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteItemDao) FindQuoteItemsByStatus(tx *gorm.DB, quoteID int64, statuses []int, itemStatus int, itemType constants.ProductType, itemScene int) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{}).Where("quote_id = ? and status in ?", quoteID, statuses)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ? ", itemStatus)
	}
	if itemType != multienv.TradeProductTypeAll {
		sql = sql.Where("item_type = ? ", itemType)
	}
	if itemScene != constants.ItemSceneAll {
		sql = sql.Where("item_scene = ? ", itemScene)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}
func (*quoteItemDao) FindRelatedQuoteItems(tx *gorm.DB, quoteID int64, tradeProduct string, productType constants.ProductType, quoteSolutionID, quoteItemID int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and trade_product = ? and id != ? and status = 0 and item_status = 0 and use_item = 1 and item_scene = 1 ", quoteID, tradeProduct, quoteItemID)
	if productType == multienv.TradeProductTypeOffline {
		sql = sql.Where("quote_solution_id = ?", quoteSolutionID)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteItemDao) CountQuoteItemsByQuoteID(tx *gorm.DB, quoteID int64) (int64, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return 0, err
	}
	return total, err
}

func (*quoteItemDao) FindQuoteItemsByIDs(tx *gorm.DB, ids []int64, itemStatus int) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("id in ? and status = 0", ids)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ? ", itemStatus)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

// FindQuoteItemsByQuoteIDAndIDs 校验删除请求中的报价项归属当前报价单，且仍处于正常数据状态。
func (*quoteItemDao) FindQuoteItemsByQuoteIDAndIDs(tx *gorm.DB, quoteID int64, ids []int64, itemStatus int) ([]*model.QuoteItem, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and id in ? and status = 0", quoteID, ids)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ? ", itemStatus)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

// FindManualDeliveryItems 查找手动拆解交付项
func (*quoteItemDao) FindManualDeliveryItems(tx *gorm.DB, quoteID int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and status = 0 and auto_generate = ? and item_scene = ?", quoteID, constants.ItemAutoGenerateFalse, constants.ItemSceneDeliveryItem)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

// FindManualDeliveryItemsByBelong 查找报价项对应的手动拆解交付项
func (*quoteItemDao) FindManualDeliveryItemsByBelong(tx *gorm.DB, quoteID int64, belongItemIDList []int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and item_belong in ? and status = 0 and auto_generate = ? and item_scene = ?", quoteID, belongItemIDList, constants.ItemAutoGenerateFalse, constants.ItemSceneDeliveryItem)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteItemDao) FindDeleteItemsByIDs(tx *gorm.DB, quoteID int64, ids []int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id = ? and (id in ? or item_belong in ? or related_item_id in ?) and status = 0", quoteID, ids, ids, ids)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteItemDao) FindQuoteItemByID(tx *gorm.DB, quoteItemID int64) (*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	//不能限制status为0
	sql = sql.Where("id = ? ", quoteItemID)
	ret := &model.QuoteItem{}
	err := sql.First(ret).Error
	return ret, err
}

func (*quoteItemDao) FindQuoteItemByBelong(tx *gorm.DB, belongItemID int64, autoGenerate int) (*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("item_belong = ? and item_scene = ? ", belongItemID, constants.ItemSceneDeliveryItem)
	if autoGenerate != constants.ItemAutoGenerateAll {
		sql = sql.Where("auto_generate = ? ", autoGenerate)
	}
	ret := &model.QuoteItem{}
	err := sql.First(ret).Error
	return ret, err
}

func (d *quoteItemDao) QuoteBatchUpdateItemMapByIDs(tx *gorm.DB, ids []int64, itemStatus int) (map[int64]*model.QuoteItem, []*model.QuoteItem, error) {
	quoteItems, err := d.FindQuoteItemsByIDs(tx, ids, itemStatus)
	if err != nil {
		return nil, nil, err
	}
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where(" item_belong in ? and status = 0 and item_scene = ? and auto_generate = ?", ids, constants.ItemSceneDeliveryItem, constants.ItemAutoGenerateTrue)
	var deliveryItems []*model.QuoteItem
	err = sql.Find(&deliveryItems).Error
	if err != nil {
		return nil, nil, err
	}
	quoteItems = append(quoteItems, deliveryItems...)

	ret := map[int64]*model.QuoteItem{}
	for _, item := range quoteItems {
		ret[item.Id] = item
	}
	return ret, quoteItems, err
}

func (*quoteItemDao) FindQuoteItemsByQuoteIDs(tx *gorm.DB, quoteIDs []int64, itemStatus int) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_id in ? and status = 0", quoteIDs)
	if itemStatus != constants.ItemStatusAll {
		sql = sql.Where("item_status = ? ", itemStatus)
	}
	var ret []*model.QuoteItem
	err := sql.Order("id desc").Find(&ret).Error
	return ret, err
}

// QuoteItemsByQuoteIDs quoteID -> []quoteItems
func (d *quoteItemDao) QuoteItemsByQuoteIDs(tx *gorm.DB, quoteIDs []int64, itemStatus int) (map[int64][]*model.QuoteItem, error) {
	quoteItems, err := d.FindQuoteItemsByQuoteIDs(tx, quoteIDs, itemStatus)
	if err != nil {
		return nil, err
	}
	ret := map[int64][]*model.QuoteItem{}
	for _, quoteItem := range quoteItems {
		ret[quoteItem.QuoteID] = append(ret[quoteItem.QuoteID], quoteItem)
	}
	return ret, err
}

func (d *quoteItemDao) UpdateItemStatusByIDs(tx *gorm.DB, quoteItemIDs []int64, itemStatus int) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemIDs}, &model.QuoteItem{}, map[string]interface{}{"item_status": itemStatus})
}

// UpdateStatusByQuoteIDAndIDs 按报价单和报价项 ID 更新数据状态，用于将原单带出项置失效。
func (*quoteItemDao) UpdateStatusByQuoteIDAndIDs(tx *gorm.DB, quoteID int64, quoteItemIDs []int64, status int) error {
	if len(quoteItemIDs) == 0 {
		return nil
	}
	return tx.Model(&model.QuoteItem{}).
		Where("quote_id = ? and id in ? and status = 0", quoteID, quoteItemIDs).
		Update("status", status).Error
}

func (d *quoteItemDao) UpdateItemApprovalByID(tx *gorm.DB, quoteItemID int64, approvers string, notifiers string, extraApprovals string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemID}, &model.QuoteItem{},
		map[string]interface{}{"approvers": approvers, "notifiers": notifiers, "extra_approvals": extraApprovals},
	)
}

func (d *quoteItemDao) UpdateItemGiveAwayTypeByIds(tx *gorm.DB, quoteItemIds []int64, giveAwayType string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemIds}, &model.QuoteItem{},
		map[string]interface{}{"give_away_type": giveAwayType},
	)
}

func (*quoteItemDao) FindQuoteItemByConditions(c context.Context, tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.QuoteItem, int64, error) {
	sql := tx.Model(&model.QuoteItem{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.QuoteItem
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *quoteItemDao) FindQuoteItemsBySolutionIDs(tx *gorm.DB, solutionIDs []int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("quote_solution_id in ? and status = 0", solutionIDs)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err

}

func (d *quoteItemDao) FindQuoteItemsBySolutionIDsAndItemType(tx *gorm.DB, solutionIDs []int64, productType constants.ProductType, quoteID int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where(
		"quote_id = ? and quote_solution_id in ? and item_type = ? and status = 0 and item_status = 0 and standard_product = ? and item_scene = ?",
		quoteID,
		solutionIDs,
		productType,
		multienv.TradeProductStandardYes,
		constants.ItemSceneQuoteItem,
	)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err

}

func (*quoteItemDao) CountQuoteItemByConditions(c context.Context, tx *gorm.DB, condition framework.Condition) (int64, error) {
	sql := tx.Model(&model.QuoteItem{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return 0, err
	}
	return total, err
}

func (*quoteItemDao) FindQuoteItemFrom(tx *gorm.DB, startItemID int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("id > ? ", startItemID)
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemDao) FindQuoteItemTradeProduct(tx *gorm.DB, startItemID, endItemID int64) ([]*model.QuoteItem, error) {
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("id >= ? and id <=?", startItemID, endItemID)
	sql = sql.Select("id", "trade_product")
	var ret []*model.QuoteItem
	err := sql.Order("id asc").Find(&ret).Error
	return ret, err
}

func (d *quoteItemDao) UpdateSecondaryProductLine(tx *gorm.DB, quoteItemID int64, secondaryProductLine string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemID}, &model.QuoteItem{}, map[string]interface{}{"secondary_product_line": secondaryProductLine})
}

func (d *quoteItemDao) UpdateModifyTime(tx *gorm.DB, quoteItemIDs []int64) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemIDs}, &model.QuoteItem{}, map[string]interface{}{"modify_time": time.Now()})
}

func (d *quoteItemDao) UpdateEstimatedIncome(tx *gorm.DB, quoteItemIDs []int64, estimatedIncome string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteItemIDs}, &model.QuoteItem{}, map[string]interface{}{"estimated_income": estimatedIncome})
}

// FindAllQuoteIDsByConditions 根据条件查询所有符合条件的报价单id 注：此方法查询条件一定要做好限制，防止一次性查太多数据
func (d *quoteItemDao) FindAllQuoteIDsByConditions(tx *gorm.DB, condition framework.Condition) ([]int64, error) {
	if len(condition) == 0 {
		return nil, errors.New("empty condition")
	}

	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Select("DISTINCT quote_id")
	sql = framework.WhereMap(sql, condition)
	sql = sql.Where("status = 0")

	var quoteIDs []int64
	err := sql.Pluck("quote_id", &quoteIDs).Error
	if err != nil {
		return nil, err
	}

	return quoteIDs, nil
}

// FindDeductItemsByRelatedIDs 根据SP包报价项ID列表查询其关联的抵扣报价项
// 用于ListQuoteItemsV2接口的层级关系查询：查询SP包时自动补查其抵扣项
func (*quoteItemDao) FindDeductItemsByRelatedIDs(
	tx *gorm.DB,
	relatedItemIDs []int64,
	status, itemScene int,
) ([]*model.QuoteItem, error) {
	if len(relatedItemIDs) == 0 {
		return nil, nil
	}
	sql := tx.Model(&model.QuoteItem{})
	sql = sql.Where("related_item_id IN (?) and item_business_role = ? and status = ?", relatedItemIDs, constants.QuoteItemBusinessRoleDeduct, status)
	if itemScene != constants.ItemSceneAll {
		sql = sql.Where("item_scene = ? ", itemScene)
	}
	var ret []*model.QuoteItem
	err := sql.Find(&ret).Error
	return ret, err
}

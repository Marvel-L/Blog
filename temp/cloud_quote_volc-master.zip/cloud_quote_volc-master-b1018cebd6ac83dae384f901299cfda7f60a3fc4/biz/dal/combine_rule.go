package dal

import (
	"strconv"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

var CombineRuleDao = &combineRuleDao{}

type combineRuleDao struct {
	baseDao
}

func (*combineRuleDao) FindQuoteSubmitLog(tx *gorm.DB, quoteID int64) (*model.CombineRule, error) {
	sql := tx.Model(&model.OperationLog{})
	sql = sql.Where("biz_scene = ? and action = ?", constants.LogBizSceneSubmit, constants.ActionSubmitQuote)
	sql = sql.Where("entity_id = ? and status = 0", strconv.FormatInt(quoteID, 10))
	ret := &model.CombineRule{}
	err := sql.Last(ret).Error
	return ret, err
}

func (*combineRuleDao) FindRulesByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.CombineRule, int64, error) {
	sql := tx.Model(&model.CombineRule{})
	if condition != nil && len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}

	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.CombineRule
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (*combineRuleDao) FindRulesBySolutions(tx *gorm.DB, tplSolutionIds []int64) ([]*model.CombineRule, error) {
	sql := tx.Model(&model.CombineRule{})
	sql = sql.Where("template_solution_id in ? and status = 0", tplSolutionIds)

	var ret []*model.CombineRule
	err := sql.Find(&ret).Error
	return ret, err
}

func (c *combineRuleDao) SoftDeleteRules(tx *gorm.DB, ruleIDS []int64) error {
	return c.SoftDeleteData(tx, Condition{"id": ruleIDS}, &model.CombineRule{})
}

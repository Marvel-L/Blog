package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"gorm.io/gorm"
)

// QuoteResourceItemDao 数据查询对象
var QuoteResourceItemDao = &quoteResourceItemDao{}

type quoteResourceItemDao struct {
	baseDao
}

// FindItemsByQuoteID 查询报价单数据库资源卡
func (d *quoteResourceItemDao) FindItemsByQuoteID(tx *gorm.DB, quoteID int64) (model.QuoteResourceItems, error) {
	sql := tx.Model(&model.QuoteResourceItem{})
	sql = sql.Where("quote_id = ? and status = 0 ", quoteID)
	var ret model.QuoteResourceItems
	err := sql.Find(&ret).Error
	return ret, err
}

// FindItemsByQuoteItemIDs 查询报价项数据库资源卡
func (d *quoteResourceItemDao) FindItemsByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64) (model.QuoteResourceItems, error) {
	sql := tx.Model(&model.QuoteResourceItem{})
	sql = sql.Where("quote_item_id in ? and status = 0 ", quoteItemIDs)
	var ret model.QuoteResourceItems
	err := sql.Find(&ret).Error
	return ret, err
}

// FindItemsByIDs 根据id查询资源卡信息
func (d *quoteResourceItemDao) FindItemsByIDs(tx *gorm.DB, ids []int64) (map[int64]*model.QuoteResourceItem, error) {
	sql := tx.Model(&model.QuoteResourceItem{})
	sql = sql.Where("id in ? and status = 0 ", ids)
	var rows []*model.QuoteResourceItem
	err := sql.Find(&rows).Error
	ret := map[int64]*model.QuoteResourceItem{}
	for _, row := range rows {
		ret[row.Id] = row
	}
	return ret, err
}

// FindPageItemsByCardName 根据卡名和报价单id查询资源卡信息
func (d *quoteResourceItemDao) FindPageItemsByCardName(
	tx *gorm.DB,
	cardName string,
	quoteIDs []int64,
) (*model.QuoteResourceItems, error) {
	sql := tx.Model(&model.QuoteResourceItem{})
	sql = sql.Where("quote_id in ? and resource_card_name = ?  and status = 0 ", quoteIDs, cardName)
	var ret *model.QuoteResourceItems
	err := sql.Find(&ret).Error
	return ret, err
}

// SoftDeleteResourceItems 根据id删除资源卡信息
func (d *quoteResourceItemDao) SoftDeleteResourceItems(tx *gorm.DB, ids []int64) error {
	condition := Condition{"id": ids}
	return d.SoftDeleteData(tx, condition, &model.QuoteResourceItem{})
}

// SoftDeleteResourceItemsByQuoteItem 根据报价单id和报价项id删除资源卡信息
func (d *quoteResourceItemDao) SoftDeleteResourceItemsByQuoteItem(
	tx *gorm.DB,
	quoteItemIDs []int64,
	quoteID int64,
) error {
	condition := Condition{"quote_item_id": quoteItemIDs, "quote_id": quoteID}
	return d.SoftDeleteData(tx, condition, &model.QuoteResourceItem{})
}

// AppendResourceNum 增加资源卡数
func (d *quoteResourceItemDao) AppendResourceNum(tx *gorm.DB, id int64, resourceNumAdd int64) error {
	sql := tx.Model(&model.QuoteResourceItem{})
	sql = sql.Where("id = ? ", id)
	return sql.Update("resource_num", gorm.Expr("resource_num + ?", resourceNumAdd)).Error
}

// UpdateCustomerAccountIDByQuoteID 更新资源卡客户id
func (d *quoteResourceItemDao) UpdateCustomerAccountIDByQuoteID(
	tx *gorm.DB,
	quoteID int64,
	customerAccountID string,
) error {
	condition := Condition{"quote_id": quoteID}
	return d.UpdateByCondition(
		tx,
		condition,
		&model.QuoteResourceItem{},
		map[string]interface{}{"customer_account_id": customerAccountID},
	)
}

package dal

import (
	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
)

var QuoteItemCalculateDao = &quoteItemCalculateDao{}

type quoteItemCalculateDao struct {
	baseDao
}

func (*quoteItemCalculateDao) FindCalByItemID(tx *gorm.DB, quoteItemID int64) (*model.QuoteItemCalculate, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Where("quote_item_id = ? and status = 0", quoteItemID)
	ret := &model.QuoteItemCalculate{}
	err := sql.First(ret).Error
	return ret, err
}

func (*quoteItemCalculateDao) QuoteItemCalsByItemIDs(tx *gorm.DB, quoteItemIDs []int64) ([]*model.QuoteItemCalculate, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Where("quote_item_id in ? and status = 0", quoteItemIDs)
	var ret []*model.QuoteItemCalculate
	err := sql.Find(&ret).Error
	return ret, err
}

func (*quoteItemCalculateDao) QuoteItemCalsByQuoteID(tx *gorm.DB, quoteID int64) ([]*model.QuoteItemCalculate, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret []*model.QuoteItemCalculate
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteItemCalculateDao) QuoteItemCalsMapByQuoteID(tx *gorm.DB, quoteID int64) (map[int64]*model.QuoteItemCalculate, error) {
	rows, err := d.QuoteItemCalsByQuoteID(tx, quoteID)
	if err != nil {
		return nil, err
	}
	ret := map[int64]*model.QuoteItemCalculate{}
	for _, row := range rows {
		ret[row.QuoteItemID] = row
	}
	return ret, nil
}

func (*quoteItemCalculateDao) QuoteItemCalsByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64, quoteID int64) ([]*model.QuoteItemCalculate, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Where("quote_id = ? and quote_item_id in ? and status = 0", quoteID, quoteItemIDs)
	var ret []*model.QuoteItemCalculate
	err := sql.Find(&ret).Error
	return ret, err
}

// QuoteItemCalcMapByQuoteItemIDs quoteItemID -> quoteItemCalculate
func (d *quoteItemCalculateDao) QuoteItemCalcMapByQuoteItemIDs(tx *gorm.DB, quoteItemIDs []int64, quoteID int64) (map[int64]*model.QuoteItemCalculate, error) {
	rows, err := d.QuoteItemCalsByQuoteItemIDs(tx, quoteItemIDs, quoteID)
	if err != nil {
		return nil, err
	}
	ret := map[int64]*model.QuoteItemCalculate{}
	for _, row := range rows {
		ret[row.QuoteItemID] = row
	}
	return ret, nil
}

func (d *quoteItemCalculateDao) SoftDelete(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) error {
	condition := Condition{"quote_item_id": quoteItemIDs}
	if quoteID > 0 {
		condition["quote_id"] = quoteID
	}
	return d.SoftDeleteData(tx, condition, &model.QuoteItemCalculate{})
}

func (d *quoteItemCalculateDao) UpdateQuoteIDAndStatus(tx *gorm.DB, quoteItemID, quoteID int64, status int) error {
	return d.UpdateByCondition(tx, Condition{"quote_item_id": quoteItemID}, &model.QuoteItemCalculate{},
		map[string]interface{}{
			"quote_id": quoteID,
			"status":   status,
		},
	)
}

func (d *quoteItemCalculateDao) GetInquiry(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) (decimal.Decimal, error) {
	sql := tx.Model(&model.QuoteItemCalculate{})
	sql = sql.Where("quote_id = ? and quote_item_id in ? and status = 0", quoteID, quoteItemIDs)
	var incomeArr []decimal.Decimal
	quoteIncome := decimal.NewFromInt(0)
	err := sql.Pluck("income_no_tax", &incomeArr).Error
	if err != nil {
		return quoteIncome, err
	}
	for _, quoteItemIncome := range incomeArr {
		quoteIncome = quoteIncome.Add(quoteItemIncome)
	}
	return quoteIncome, nil
}

func (d *quoteItemCalculateDao) InitItemCalMap(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) (map[int64]*model.QuoteItemCalculate, error) {
	itemCals, err := d.QuoteItemCalsByQuoteItemIDs(tx, quoteItemIDs, quoteID)
	if err != nil {
		return nil, err
	}
	itemCalMap := d.BuildInitItemCalMap(quoteID, quoteItemIDs, itemCals)
	return itemCalMap, nil
}

func (d *quoteItemCalculateDao) BuildInitItemCalMap(quoteID int64, quoteItemIDs []int64, itemCals []*model.QuoteItemCalculate) map[int64]*model.QuoteItemCalculate {
	itemCalMap := map[int64]*model.QuoteItemCalculate{}
	for _, itemCal := range itemCals {
		itemCalMap[itemCal.QuoteItemID] = itemCal
	}
	for _, quoteItemID := range quoteItemIDs {
		_, ok := itemCalMap[quoteItemID]
		if !ok {
			itemCalMap[quoteItemID] = &model.QuoteItemCalculate{
				QuoteID:           quoteID,
				QuoteItemID:       quoteItemID,
				SingleCost:        decimal.NewFromInt(constants.NoCostValue),
				TotalCost:         decimal.NewFromInt(constants.NoCostValue),
				TotalFactoryPrice: decimal.NewFromInt(constants.NoCostValue),
			}
		}
	}
	return itemCalMap
}

package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var QuoteSubTaskDao = &quoteSubTaskDao{}

type quoteSubTaskDao struct {
	baseDao
}

func (*quoteSubTaskDao) FindSubTasksByID(tx *gorm.DB, subTaskID int64) (*model.QuoteSubTask, error) {
	sql := tx.Model(&model.QuoteSubTask{})
	sql = sql.Where("id = ? and status = 0", subTaskID)
	ret := &model.QuoteSubTask{}
	err := sql.Find(ret).Error
	if err != nil {
		return nil, err
	}
	if ret.Id == 0 {
		err = gorm.ErrRecordNotFound
	}
	return ret, err
}

func (*quoteSubTaskDao) FindQuoteSubTasksByTaskID(tx *gorm.DB, quoteTaskID int64) ([]*model.QuoteSubTask, error) {
	sql := tx.Model(&model.QuoteSubTask{})
	sql = sql.Where("quote_task_id = ? and status = 0", quoteTaskID)
	var ret []*model.QuoteSubTask
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *quoteSubTaskDao) UpdateSubTaskStatusByID(tx *gorm.DB, subTaskID int64, subTaskStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": subTaskID}, &model.QuoteSubTask{}, map[string]interface{}{"sub_task_status": subTaskStatus})
}

func (d *quoteSubTaskDao) UpdateSubTaskStatusAndMsgByID(tx *gorm.DB, subTaskID int64, subTaskStatus, subTaskMsg string) error {
	return d.UpdateByCondition(tx, Condition{"id": subTaskID}, &model.QuoteSubTask{}, map[string]interface{}{"sub_task_status": subTaskStatus, "sub_task_msg": subTaskMsg})
}

func (d *quoteSubTaskDao) SoftDeleteSubTask(tx *gorm.DB, quoteTaskID int64) error {
	return d.SoftDeleteData(tx, Condition{"quote_task_id": quoteTaskID}, &model.QuoteSubTask{})
}

func (d *quoteSubTaskDao) UpdateQuoteIDBySubTaskID(tx *gorm.DB, subTaskID int64, quoteID int64) error {
	return d.UpdateByCondition(tx, Condition{"id": subTaskID}, &model.QuoteSubTask{}, map[string]interface{}{"quote_id": quoteID})
}

package dal

import (
	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
	"code.byted.org/eps-platform/cloud_quote_volc/pkg/constants"
	"github.com/shopspring/decimal"
	"gorm.io/gorm"
)

var RebateItemDao = &rebateItemDao{}

type rebateItemDao struct {
	baseDao
}

func (*rebateItemDao) FindRebateItemsByQuoteID(tx *gorm.DB, quoteID int64) (model.RebateItemList, error) {
	sql := tx.Model(&model.RebateItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID)
	var ret model.RebateItemList
	err := sql.Find(&ret).Error
	return ret, err
}

func (*rebateItemDao) FindRebateItemsByQuoteIDs(tx *gorm.DB, quoteIDs []int64) (model.RebateItemList, error) {
	sql := tx.Model(&model.RebateItem{})
	sql = sql.Where("quote_id in ? and status = 0", quoteIDs)
	var ret model.RebateItemList
	err := sql.Find(&ret).Error
	return ret, err
}

func (*rebateItemDao) FindRealRebateItemsByQuoteID(tx *gorm.DB, quoteID int64) (model.RebateItemList, error) {
	sql := tx.Model(&model.RebateItem{})
	sql = sql.Where("quote_id = ? and status = 0 and is_rebate_written = ?", quoteID, constants.RebateWritten)
	var ret model.RebateItemList
	err := sql.Find(&ret).Error
	return ret, err
}

func (d *rebateItemDao) SoftDeleteRebateItem(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) error {
	return d.SoftDeleteData(tx, Condition{"quote_id": quoteID, "quote_item_id": quoteItemIDs}, &model.RebateItem{})
}

// FindCreatePolicyRebates 查找创建返佣政策的返佣项
// is_rebate_written=1 表示填写了返佣政策 is_performance_select in (2,3) 表示支持计入业绩；两者满足其一就可以创建返佣政策
func (d *rebateItemDao) FindCreatePolicyRebates(tx *gorm.DB, quoteID int64) (model.RebateItemList, error) {
	sql := tx.Model(&model.RebateItem{})
	sql = sql.Where("quote_id = ? and status = 0", quoteID).
		Where("is_rebate_written = ? OR is_performance_select in (?,?)", constants.RebateWritten, constants.PerformanceSelectALL, constants.PerformanceSelectPart)
	var ret model.RebateItemList
	err := sql.Find(&ret).Error
	return ret, err
}

// ClearRebateLevelType 清空返佣比例
func (d *rebateItemDao) ClearRebateLevelType(tx *gorm.DB, quoteID int64, quoteItemIDs []int64) error {
	if len(quoteItemIDs) == 0 {
		return nil
	}
	return d.UpdateByCondition(tx, Condition{"quote_id": quoteID, "quote_item_id": quoteItemIDs}, &model.RebateItem{}, map[string]interface{}{
		"rebate_level_type": decimal.Zero,
		"is_rebate_written": constants.RebateNotWritten,
	})
}

package dal

import (
	"gorm.io/gorm"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv"

	"code.byted.org/eps-platform/cloud_quote_volc/pkg/framework"

	"code.byted.org/eps-platform/cloud_quote_volc/biz/dal/model"
)

var QuoteTaskDao = &quoteTaskDao{}

type quoteTaskDao struct {
	baseDao
}

func (*quoteTaskDao) FindQuoteTaskByID(tx *gorm.DB, quoteTaskID int64) (*model.QuoteTask, error) {
	sql := tx.Model(&model.QuoteTask{})
	sql = sql.Where("id = ? and status = 0", quoteTaskID)
	ret := &model.QuoteTask{}
	err := sql.Find(ret).Error
	if err != nil {
		return nil, err
	}
	if ret.Id == 0 {
		err = gorm.ErrRecordNotFound
	}
	return ret, err
}

func (*quoteTaskDao) FindTaskByConditions(tx *gorm.DB, condition framework.Condition, limit, offset int) ([]*model.QuoteTask, int64, error) {
	sql := tx.Model(&model.QuoteTask{})
	if len(condition) > 0 {
		sql = framework.WhereMap(sql, condition)
	}
	sql = sql.Where("status = 0")
	var total int64
	err := sql.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}
	var ret []*model.QuoteTask
	err = sql.Order("id desc").Limit(limit).Offset(framework.CalculateOffset(offset, limit)).Find(&ret).Error
	return ret, total, err
}

func (d *quoteTaskDao) UpdateTaskStatusByID(tx *gorm.DB, quoteTaskID int64, taskStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{"task_status": taskStatus})
}

func (d *quoteTaskDao) UpdateExecutionStatusByID(tx *gorm.DB, quoteTaskID int64, executionStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{"execution_status": executionStatus})
}

func (d *quoteTaskDao) UpdateTaskAndExecutionStatusByID(tx *gorm.DB, quoteTaskID int64, taskStatus, executionStatus string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{"task_status": taskStatus, "execution_status": executionStatus})
}

func (d *quoteTaskDao) UpdateTaskAndExecutionStatusAndMsgByID(tx *gorm.DB, quoteTaskID int64, taskStatus, executionStatus, executionMsg string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{"task_status": taskStatus, "execution_status": executionStatus, "execution_msg": executionMsg})
}

func (d *quoteTaskDao) UpdateContractLarkURLByID(tx *gorm.DB, quoteTaskID int64, contractLarkUrl string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{
		"task_status":       multienv.TaskStatusInitialed,
		"execution_status":  multienv.ExecutionStatusImportContract,
		"contract_lark_url": contractLarkUrl,
	})
}

func (d *quoteTaskDao) UpdateExecutionStatusAndMsg(tx *gorm.DB, quoteTaskID int64, executionStatus string, msg string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{
		"execution_status": executionStatus,
		"execution_msg":    msg,
	})
}

func (d *quoteTaskDao) UpdateChargeItemLarkURLByID(tx *gorm.DB, quoteTaskID int64, chargeItemLarkUrl string) error {
	return d.UpdateByCondition(tx, Condition{"id": quoteTaskID}, &model.QuoteTask{}, map[string]interface{}{
		"task_status":          multienv.TaskStatusInitialed,
		"execution_status":     multienv.ExecutionStatusImportChargeItem,
		"charge_item_lark_url": chargeItemLarkUrl,
	})
}

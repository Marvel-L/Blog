# 06. 自更新指引：代码合入后如何让 AI 增量修改本手册

> 目标：**代码变了，手册立刻跟着变**。避免"新增了 Rule 但清单不更新"的信息漂移。
>
> 本文件与 `05_prompt_templates.md §6` 配套使用：§6 给你**提示词原文**，本文件
> 说明**在哪里回填、验收标准是什么、怎么保证不改坏其它内容**。

## 1. 什么时候需要走自更新流程？

在 PR 合入前**必须**执行以下情形之一：

| 触发条件 | 需要回填的位置 |
|---|---|
| 新增 / 删除 / 重命名 loader | `01_current_state.md §2.4` |
| 新增 / 删除 / 重命名 Rule | `01_current_state.md §3.5` + `03_decision_playbook.md §5`（若通用） |
| 新增 / 删除 / 重命名 Refresher | `01_current_state.md §4.4` |
| 新增 `QuoteBizOpType` | `01_current_state.md §5.1、§6.2` |
| 新增 `QuoteBizDataType` 桶 | `01_current_state.md §5.1、§6.2` + `§3.5` 建立空桶行（Refresher 全局注册，不按桶组织） |
| 新增 / 修改 Refresher 别名（向后兼容老 key） | `biz/service/quote_service_by_engine/biz_data_refresh.go` 的 `refresherKeyAlias`，不需改文档（除非需要在 §4.4 标注历史 key） |
| 新增 CodeN 号段 | `01_current_state.md §3.4` |
| 新增 InputOption | `01_current_state.md §2.3`（如需在表格里点名） |
| 新增 `biz/service/quote_service_by_engine/` 入口对接 | `01_current_state.md §7` |
| 引入一种"新常见需求"（未来可能重复） | `03_decision_playbook.md §5` 速查表新增一行 |

**不需要回填的情形**（避免 AI 产出空 diff）：

- 只修改已有 Rule 的 Needs / BlockLevel / Desc（未新增/重命名）。
- 只修改已有 Refresher 的 Needs / Mods（未新增/重命名）。
- 只修改 Rule.Check 内部分支实现。
- 只修改错误文案（未新增 CodeN）。
- 只调整业务侧调用（不涉及 service_basic）。

## 2. 允许 AI 修改的文件与不允许触碰的部分

| 文件 | 允许改动 | 不允许改动 |
|---|---|---|
| `01_current_state.md` | §2.4 / §3.4 / §3.5 / §4.4 / §5.1 / §6.2 / §7 中的清单条目、表格行 | §1 分层总览、依赖方向；接口定义原文 |
| `03_decision_playbook.md` | §5 常见需求速查表（新增行） | §0 决策树、§6 反模式清单 |
| `02_conventions.md` | 无（**只由人工维护**） | 全文 |
| `04_change_checklist.md` | 无（**只由人工维护**） | 全文 |
| `05_prompt_templates.md` | 无（**只由人工维护**） | 全文 |
| `06_self_update_guide.md` | 无（**只由人工维护**） | 全文 |
| `README.md` | 无 | 全文 |

> 简言之：AI 只增量维护"清单/表格/速查"，不改"设计原则/骨架/流程"。

## 3. 标准回填示例

### 3.1 新增了一条 Rule

**代码差异**：新增了 `biz/service_basic/check_engine/biz_data_rule_quote_contact.go`
（`QuoteContactRule` / `BizDataRuleQuoteContact`，挂在 `QuoteBaseInfo` 桶）。

**回填 `01_current_state.md §3.5` 的 `QuoteBaseInfo` 行末尾追加**：

```
… / QuoteType / QuoteOrderType / QuoteContact
```

### 3.2 新增了一条 Refresher

**代码差异**：`biz/service_basic/refresh_engine/biz_data_refresher_quote_signal.go`
（`QuoteSignalRefresher` / `refreshQuoteSignal`，Mods = `Quote`）。

**回填 `01_current_state.md §4.4` 追加一行**：

```
| QuoteSignalRefresher | `refreshQuoteSignal` | Quote |
```

### 3.3 新增了一个 QuoteBizDataType 桶

**代码差异**：新增 `QuoteBizDataTypeContractPool` + 3 Rule + 1 Refresher。

**回填 `01_current_state.md`**：

- §5.1 `QuoteBizDataType` 枚举 → 追加 `ContractPool`。
- §6.2 OpType Stage 序列表 → 视 opType 的实际 WithStages 序列更新（如加入 SubmitQuote / BizDataCheck 顺序）。
- §3.5 → 新增 `ContractPool` 行，列出 3 个 Rule。
- §4.4 → 新增 Refresher 行。

### 3.4 新增了一种常见需求

如果本次需求是"通用型"（未来还可能再遇到），把它加进
`03_decision_playbook.md §5` 表：

```
| "<一句话需求>" | <落点结论> |
```

## 4. 使用步骤（人机协作）

```
[开发者]
  1. 完成代码，跑通 04 自检清单。
  2. 打开 05_prompt_templates.md §6 复制"自更新手册提示词"。
  3. 在【已完成的变更】处贴上：新增/删除的文件、struct、Key、CodeN、桶归属。

[AI]
  4. 严格按提示词修改 01_current_state.md（和可选的 03_decision_playbook.md §5）。
  5. 输出 diff。

[开发者]
  6. 检查 diff 是否命中禁改区（§1、§0 决策树、骨架代码等）。
  7. 一并提交到同一 PR。
```

## 5. 一次性提示词（可复制）

> 已收录到 `05_prompt_templates.md §6`，此处再列一次方便直接引用。

```
本轮需求已完成代码合入，现在请你只修改文档，不改代码。

已完成的变更：
- <路径 1>：新增 struct <XxxRule>，Key=<BizDataRuleXxx>，桶=<QuoteBizDataType>
- <路径 2>：新增 CodeNCheckXxx = 12345
- <路径 3>：新增 loader<Xxx>，QuoteContextKey<Xxx>，字段挂到 <Persisted/External/Inputs>
- <路径 4>：修改 RegisterOpType(QuoteBizOpTypeSubmitQuote).WithStages(...) 序列，位置 = <before QuoteBaseInfo>

请只改以下允许区（不得触碰其它内容）：
- ai-dev-plan/01_current_state.md：§2.4 / §3.4 / §3.5 / §4.4 / §5.1 / §6.2 / §7
- ai-dev-plan/03_decision_playbook.md：§5 常见需求速查表（仅当本次需求通用时追加）

强制约束：
1. 只允许追加/修改现有清单行，不允许新增标题、章节或代码块。
2. 输出 diff 形式的完整改动预览。
3. 不允许改动 02_conventions.md / 04_change_checklist.md / 05_prompt_templates.md /
   06_self_update_guide.md / README.md。
4. 修改后请复述一遍新的清单条目，用于人工二次确认。
```

## 6. 校验方式

自更新完成后，走一次快速校验：

1. `git diff ai-dev-plan/` 看只有允许区被改动。
2. 打开 `01_current_state.md` 相关小节，确认新条目与代码一致（struct 名 / Key / 桶）。
3. `grep -R "<新 Key>" biz/service_basic/` 与手册对齐。
4. 保证一个 PR 内包含"代码 + 回填 diff"，避免下一次需求时手册滞后。

## 7. 常见错误

| 错误 | 修复 |
|---|---|
| AI 顺手改了 `§1 分层总览` 或依赖方向 | 拒绝合入；提醒 AI 仅限允许区。 |
| AI 在 03 决策手册里改了决策树 | 拒绝合入；只允许追加 §5 表行。 |
| AI 新建了 md 文件 | 删除；本目录不允许新增文件（除非人工决策）。 |
| 回填内容与代码事实不符（如 Mods 漏 key） | 让 AI 重新读代码，产出新 diff。 |
| 只更新代码没更新手册 | PR 阻塞；补齐后再合入。 |

## 8. AI 输出契约（diff 格式）

自更新提示词的输出**必须**符合以下契约，否则不接受：

1. **仅使用 unified diff 或明确的"before / after"块**，不允许贴整个文件。
2. **每个改动都需要注明目标文件、目标小节（§X.Y）、原文（before）、新版（after）**。
3. **只列真正改动的行**，尽量减少上下文（≤5 行 context）。
4. **不允许改标题层级**（`##`、`###` 保持原有）。
5. **每份 diff 独立成块**，方便人工 review。

模板：

```
【回填目标】 ai-dev-plan/01_current_state.md §3.5 QuoteBaseInfo 行

【before】
| QuoteBaseInfo | ItemCount / ItemCombine / ... / QuoteType / QuoteOrderType |

【after】
| QuoteBaseInfo | ItemCount / ItemCombine / ... / QuoteType / QuoteOrderType / QuoteContactEmail |
```

## 9. 多种变更的合并示例

场景：一个 PR 同时新增 1 Loader + 2 Rule + 1 Refresher + 1 CodeN 号段。

AI 应输出 5 段 diff：

```
【diff 1/5】01_current_state.md §2.4：追加 loaderCustomerCreditGrade（外部一列）
【diff 2/5】01_current_state.md §3.4：新增号段 110131 说明
【diff 3/5】01_current_state.md §3.5：QuoteBaseInfo 桶追加 QuoteContactEmail、QuoteAccountBind
【diff 4/5】01_current_state.md §4.4：追加 ItemPerformanceFlagRefresher 行
【diff 5/5】03_decision_playbook.md §5：追加"新增账号强制绑定校验"速查行
```

每段都用 §8 契约的 before/after 结构表达。人工合并后一次性提交。

## 10. 失败案例（真实发生过的坑）

### 10.1 AI 修改了 §1 依赖方向

**表现**：AI 在自更新中错误把 `check_engine → engine_stage` 加入依赖方向图。

**后果**：手册与代码事实相反，误导后续开发。

**处理**：Revert 该段，重新提示词强调"§1 全部为禁改区"。

### 10.2 AI 创建了 07_xxx.md

**表现**：AI 觉得新增内容比较大，主动新建 md 文件。

**后果**：目录结构失控，多份文件间职责重叠。

**处理**：删除新建文件，把内容合并到 §5 或对应清单。

### 10.3 AI 删除了历史清单条目

**表现**：AI 为了"精简"删除了旧 Rule 条目。

**后果**：`01_current_state.md` 与真实代码不一致。

**处理**：Revert；提示词加强"不允许删除，除非代码同步移除"约束。

### 10.4 AI 用了错误的锚点

**表现**：AI 把新 Loader 写到 §3.5（Rule 桶）而不是 §2.4（Loader 清单）。

**后果**：清单错乱。

**处理**：在提示词中显式列出触发条件到锚点的映射表（本文件 §1 表格）。

## 11. 自更新流水线建议（可选自动化）

对高频改动，可以把下列脚本挂到 pre-commit / CI：

```bash
# 检查 registration.go 中的 Rule 是否都出现在 01_current_state.md §3.5
rg -oN "&check_engine\.([A-Za-z0-9_]+Rule)" biz/service_basic/engine_stage/registration.go \
  | sort -u \
  | while read -r line; do
      rule="${line##*.}"
      rule="${rule%\}}"
      grep -q "$rule" ai-dev-plan/01_current_state.md \
        || echo "MISSING in 01_current_state.md: $rule"
    done

# 检查 registration.go 中的 Refresher 是否都出现在 01_current_state.md §4.4
rg -oN "&refresh_engine\.([A-Za-z0-9_]+Refresher)" biz/service_basic/engine_stage/registration.go \
  | sort -u \
  | while read -r line; do
      ref="${line##*.}"
      ref="${ref%\}}"
      grep -q "$ref" ai-dev-plan/01_current_state.md \
        || echo "MISSING in 01_current_state.md: $ref"
    done
```

若任一条报 MISSING，说明手册未及时回填，PR 应阻塞至补齐。

## 12. 检查表（一句话总结每步）

| 阶段 | 检查项 |
|---|---|
| 代码合入前 | 04_change_checklist §G 已全部勾选。 |
| 自更新时 | 使用 05_prompt_templates §6 的提示词；仅允许改允许区。 |
| 自更新后 | 走 §6 校验；跑 §11 脚本；review diff 是否符合 §8 契约。 |
| 提交 PR | 一并附上代码 diff + 手册 diff；PR 描述引用变更清单。 |

# 02. 研发风格与规范（含代码骨架模板）

> 面向"新增 loader / rule / refresher / opType"的最小规范集合，遵守就能与
> 现有 `service_basic/` 代码保持一致。**AI 生成代码必须先读本文件**。

## 1. 通用风格

1. **文件粒度**：一个概念一个文件。loader / rule / refresher 都是"一个业务
   目标一个文件"，不允许在同一 `biz_data_rule_xxx.go` 内塞多个 struct。
2. **注释规范**：结构体上方使用中文注释块，固定小节：
   - Rule：`职责 / 触发条件 / 失败分支 → CodeN / 数据来源`。
   - Refresher：`职责 / 触发条件 / 失败分支 → CodeN / 写副作用 /
     数据来源 / Mods`。
   - Loader：说明是"持久化字段"还是"外部依赖"，并注明数据来源方法。
3. **英文命名 + 中文注释**：所有对外符号 English，包内注释与错误文案中文，
   面向用户的错误文案必须走 `i18nfmt.Sprintf(ctx, ...)`。
4. **日志规范**：使用 `code.byted.org/gopkg/logs`；关键错误加 `[<StructName>]`
   前缀，如 `[loaderQuote]FindQuoteByIDFail`。
5. **只使用 `errors.NewBizErrWithMsg` / `errors.ErrCustomerError.WithArgs`**
   返回 error；不允许裸 `fmt.Errorf` 出到调用方。
6. **禁止在 struct 里加可变字段**：Rule / Refresher / Loader 全部为无状态
   struct，`&XxxRule{}` 可安全共享单例。
7. **import 顺序**：标准库 → `code.byted.org/eps-platform/cloud_quote_volc/...`
   → 其它三方；组内按字母序。
8. **返回值约定**：
   - Rule 的 `Check` 返回 `(*CheckResult, error)`：业务失败走 `CheckResult.Pass=false`；
     上下文缺失/依赖崩溃走 `error`。
   - Refresher 的 `Refresh` 返回 `(*RefreshResult, error)`：
     - 无需更新 → `newPassRefreshResult(r), nil`（Pass=true, Changed=false）。
     - 写库成功 → `result{Changed:true}, nil`。
     - 依赖/DB 故障 → `result, err`（固定短路，详见 §5 第 7 条）。
     - 业务判定需阻断（极少用）→ `result{Pass:false, BlockLevel:Error}, nil`（固定短路）。
     - 允许降级 → `result{Pass:false, BlockLevel:Warn}, nil`（不短路，需满足 §4.4 前置条件）。

## 2. quote_context 侧规范

### 2.1 硬性约束

1. `QuoteContext` 的字段只允许被 loader 赋值，业务层不得直写。若数据被更新，
   业务侧必须使用 `WithReloadKeys` 触发对应字段重刷。
2. 新增字段：
   - 决定归属：持久化 → `QuoteContextPersisted`；外部依赖 → `QuoteContextExternal`；
     入参 → `QuoteContextInputs`。
   - 在 `quote_context/const.go` 追加对应 `QuoteContextKey`（**紧跟同类别最后
     一个 key**，保持分区注释）；同时在 `loaderMap` 里登记。
3. Loader 命名：`loader<Field>`，文件名 `loader_<field>.go`，其中 `<field>` 与
   `QuoteContextKey` 字段部分同名（小写下划线）。
4. Loader 内部限制：
   - 允许调 `dal.*Dao` / `biz/service/*` 查询方法。
   - 不允许写库、不允许调用其它 loader（依赖用 `dependKeys()` 声明）。
   - `param.QuoteID == 0` 必须 fail-fast，避免全表扫描。
5. InputOption：新增入参字段一律通过 `WithInputXxx(...)` 组合器暴露，且遵守
   "字段为空才赋值"惯例。

### 2.2 Loader 代码骨架

```go
package quote_context

import (
    "context"

    "code.byted.org/eps-platform/cloud_quote_volc/biz/dal"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/argosnotifylogs"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
    "code.byted.org/gopkg/logs"
    "gorm.io/gorm"
)

// loaderXxx 加载 <字段中文名>。
// 数据来源：dal.XxxDao.FindByQuoteID / biz/service/xxx_service.QueryYyy。
// 依赖：<列出依赖 key，无则写"无">。
type loaderXxx struct{}

func (c loaderXxx) dependKeys() []QuoteContextKey {
    return []QuoteContextKey{ /* 前置依赖 key，无则返回 nil */ }
}

func (c loaderXxx) load(ctx context.Context, tx *gorm.DB, param *loaderParam, qc *QuoteContext) error {
    quoteID := param.QuoteID
    if quoteID == 0 {
        argosnotifylogs.CtxError(ctx, "[loaderXxx]load报价单号为空")
        return errors.ErrCustomerError.WithArgs("报价单号为空")
    }

    data, err := dal.XxxDao.FindByQuoteID(tx, quoteID)
    if err != nil {
        logs.CtxError(ctx, "[loaderXxx]FindByQuoteIDFail, quoteID=%d, err=%s", quoteID, err.Error())
        return errors.ErrCustomerError.WithArgs("查询xxx信息失败")
    }
    qc.Persisted.Xxx = data // 或 qc.External.Xxx
    return nil
}
```

同时必须：

- `const.go` 中追加 `QuoteContextKeyXxx` 常量。
- `loaderMap` 中追加 `QuoteContextKeyXxx: loaderXxx{}`。
- `QuoteContextPersisted` / `QuoteContextExternal` 结构体中追加字段。

### 2.3 归属判定原则（Persisted vs External vs Inputs）

| 数据来源 | 归属 | 举例 |
|---|---|---|
| `dal.*Dao` 查本服务 DB | `Persisted` | Quote / QuoteItems / GuaranteeItems |
| RPC 调外部服务（trade/crm/prm/lark） | `External` | ProductInfoMap / OppInfo / PartnerGrant |
| 由外部拉取但**语义等价于持久化字段**（如 config 树） | `External` | ConfigTreeMap / ConfigInfoMap |
| 接口入参（HTTP/RPC 请求体） | `Inputs` | InputCouponList / InputCreditList |
| 由 QuoteContext 内其它 key 计算派生（无独立取数） | `Persisted` 或独立字段 | ItemContextMap（依赖 QuoteItems + ItemValues） |

判定口诀：**"读 DB → Persisted，调外部 → External，从请求来 → Inputs"**。

### 2.4 Loader 内调外部 Client 的骨架

```go
package quote_context

import (
    "context"

    "code.byted.org/eps-platform/cloud_quote_volc/pkg/crm_client"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
    "code.byted.org/gopkg/logs"
    "gorm.io/gorm"
)

// loaderCustomerCreditGrade 加载 CRM 客户信用等级（外部依赖）。
// 数据来源：crm_client.GetCustomerCreditGrade。
// 依赖：QuoteContextKeyQuote（用其 CustomerID）。
type loaderCustomerCreditGrade struct{}

func (c loaderCustomerCreditGrade) dependKeys() []QuoteContextKey {
    return []QuoteContextKey{QuoteContextKeyQuote}
}

func (c loaderCustomerCreditGrade) load(ctx context.Context, tx *gorm.DB, param *loaderParam, qc *QuoteContext) error {
    if qc.Persisted.Quote == nil {
        return errors.ErrCustomerError.WithArgs("报价单信息缺失")
    }
    grade, err := crm_client.GetCustomerCreditGrade(ctx, qc.Persisted.Quote.CustomerID)
    if err != nil {
        logs.CtxError(ctx, "[loaderCustomerCreditGrade] GetCustomerCreditGrade fail, customerID=%s, err=%s",
            qc.Persisted.Quote.CustomerID, err.Error())
        return errors.ErrCustomerError.WithArgs("查询客户信用等级失败")
    }
    qc.External.CustomerCreditGrade = grade
    return nil
}
```

**关键差异**：
- `tx` 参数在**外部依赖 loader** 里可以忽略（不涉及本服务 DB）。
- 通常依赖 `QuoteContextKeyQuote`，以获取 CustomerID 等入参。
- 失败文案用"查询 XX 信息失败"，与 DB 类 loader 保持风格一致。

### 2.5 多依赖 Loader 示例

真实代码中 `loaderProductInfo` 依赖 4 个 key（`QuoteItems / QuoteItemsExpired
/ DeliveryItems / DeliveryItemsExpired`），骨架如下：

```go
func (c loaderProductCategoryTree) dependKeys() []QuoteContextKey {
    return []QuoteContextKey{
        QuoteContextKeyQuoteItems,
        QuoteContextKeyDeliveryItems,
        // 若需要覆盖失效项：QuoteContextKeyQuoteItemsExpired
    }
}

func (c loaderProductCategoryTree) load(ctx context.Context, tx *gorm.DB, param *loaderParam, qc *QuoteContext) error {
    // 直接读多个前置字段
    items := append([]*model.QuoteItem{}, qc.Persisted.QuoteItems...)
    items = append(items, qc.Persisted.DeliveryItems...)
    if len(items) == 0 {
        return nil
    }
    // 抽 productKey 去调外部
    // ...
}
```

**关键**：多依赖时前置 key 全部列进 `dependKeys()`，`load` 内直接读
`qc.Persisted.*`；`executor` 会先按 dependKeys 递归加载，`load` 内**不允许**
再调用其它 loader。

### 2.6 业务层调用 Loader 时的 tx 传递规则

`NewQuoteContextLoader(quoteID, tx)` / `NewLoaderByQuoteContext(qc, tx)` 的第
二个参数 `tx *gorm.DB` 传递规则：

| 场景 | 传入 | 后果 |
|---|---|---|
| 业务在事务内（`dal.DBProxy.NewRequest(ctx).Transaction(...)`） | **必须传 tx** | Loader 与业务读写在同一事务，可见性一致 |
| 业务只读（不开事务） | 可传 `nil` | Loader 内部会 `dal.DBProxy.NewRequest(ctx)` 拿只读连接 |
| 业务在事务外但已 Save 过 | **必须传 tx** | 否则 loader 读到的是 Save 之前的旧数据 |
| 存量 `assistant.Callback*` 迁移 | 沿用原调用点的 tx | 保持事务边界不变 |

**踩坑高发**：从 Callback 迁移到 QuoteContext 时忘传 tx，导致读到事务外
数据，Rule 结果异常。

## 3. check_engine 侧规范

### 3.1 硬性约束

1. **Rule 只读**：不允许在 `Check` 内做 `dal.*Dao.Save/Update`、`Delete` 或
   任何 RPC 写。这类副作用必须迁到 loader（回填）或 refresher（更新）。
2. **原子拆分优先级**：
   - 同一"用户可修复动作"的多个短路分支保留在一个 Rule。
   - 不同修复动作 / 不同业务子域 / 不同 skip 需求必须拆开。
   - 参考 `ai-docs/check_engine_rule_atomization_plan.md` 第 1 节。
3. **BlockLevel 选择**：
   - Error：阻断送审。默认值。
   - Warn：只告警，可以继续；用于业务提示、白名单降级。
   - Info：仅日志，不透出用户。
4. **Needs 精确声明**：只列 `Check` 方法真正读到的 key，冗余会导致上游一次性
   聚合查询变胖。
5. **错误码**：
   - `ErrorCode` 沿用 `codeN.go` 中的老 `CodeNXxx`，兼容前端。
   - `BizErrorCode` 使用 `codeN_biz_data.go` 中 `CodeNCheck*` 6 位号段。
   - 新增号段只在对应号段的最大值后追加，不复用旧值。
6. **上下文缺失**：
   - `quoteCtx == nil || quoteCtx.Persisted.Quote == nil` → 直接
     `return nil, errors.NewBizErrWithMsg(errors.CodeNCheckQuoteContextMissing, "[XxxRule] quote context is missing")`。
   - 这不是"业务失败"，而是"上游取数出错"，用 error 走出，不占业务 CodeN。
7. **Desc 单行**：便于自动生成校验规则清单；避免多行、避免带 Markdown。
8. **Rule 内读 config / TCC 开关的边界**：
   - ✅ 允许：**业务语义分支**（场景专属放行）。例如
     `OpAccessQuoteOperationRule` 依据配置清单场景决定是否放行；这属于"规则的业务逻辑一部分"。
   - ❌ 禁止：把开关当作 **"是否启用本 Rule"** 的灰度切流器。灰度切流应
     由业务层 `WithSkipBlockRules` 或 `OverrideStages` 实现，避免规则集
     被业务开关污染。
   - 判定口诀：**"开关值改变的是校验结果 → 允许；开关值改变的是校验是否
     执行 → 归业务层"**。

### 3.2 Rule 代码骨架

```go
package check_engine

import (
    "context"

    "code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/engine_common"
    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// <Entity><Domain>Rule <一句话职责>。
//
// 职责：<...>。
// 触发条件：<无 / 满足 XXX 才校验>。
// 失败分支 → CodeN：
//  1. <分支描述> → CodeNCheck<XXX>(NNNNNN)
//  2. <分支描述> → CodeNCheck<YYY>(NNNNNN)
//
// 数据来源：Needs() 声明 <key1 / key2>；无 DB/RPC 查询；无写副作用。
type <Entity><Domain>Rule struct{}

func (r *<Entity><Domain>Rule) Key() string {
    return "BizDataRule<Entity><Domain>"
}

func (r *<Entity><Domain>Rule) Desc() string {
    return "<单行覆盖所有失败分支的描述>"
}

func (r *<Entity><Domain>Rule) Needs() []quote_context.QuoteContextKey {
    return []quote_context.QuoteContextKey{
        quote_context.QuoteContextKeyQuote,
        // ...
    }
}

func (r *<Entity><Domain>Rule) BlockLevel() engine_common.BlockLevel {
    return engine_common.BlockLevelError
}

func (r *<Entity><Domain>Rule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*engine_common.CheckResult, error) {
    if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
        return nil, errors.NewBizErrWithMsg(errors.CodeNCheckQuoteContextMissing, "[<Entity><Domain>Rule] quote context is missing")
    }
    result := newPassCheckResult(r)

    // 分支 1
    if /* 条件 */ {
        result.Pass = false
        result.ErrorCode = errors.CodeN<Old>       // 兼容前端
        result.ErrorMsg = i18nfmt.Sprintf(ctx, "…")
        result.BizErrorCode = errors.CodeNCheck<XXX>
        result.BizErrorMsg = i18nfmt.Sprintf(ctx, "…")
        return result, nil
    }

    // 分支 2
    // ...

    return result, nil
}
```

### 3.3 CheckResult.Detail 使用规范

- `Detail interface{}` 与 `Pass` **完全独立**：`Pass=true` 也可以携带 Detail
  用于前端展示（提示、埋点、辅助信息）。
- 典型用法：
  - `Info` 级 Rule：`Pass=true, BlockLevel=Info, Detail=<payload>`。
  - `Warn` 级 Rule：`Pass=false, BlockLevel=Warn, Detail=<payload>`（Warn 不阻断）。
  - `Error` 级 Rule：`Pass=false, BlockLevel=Error, Detail=<诊断细节>`。
- **约束**：Detail 必须可被 JSON 序列化；不允许放 `*gorm.DB`、`context.Context`
  等运行时对象。
- 业务侧从 `execResult.Stages[i].Check.Detail` 收集展示；如需要类型断言，
  建议在 Rule 所在包内定义具名 struct 便于对方复用。

### 3.4 配置 / 环境判断使用规范

Rule/Refresher 内**允许**读取业务配置与环境信息，但有严格边界：

1. **读取 TCC 开关 / 阈值配置**：使用 `biz/config` 包。
   - 数值/阈值：`config.GetMaxItemNum(ctx)` 等专用 getter。
   - 开关：`config.GetSwitchIsOpenByName(ctx, config.SwitchXxx)`。
   - 白名单：**不在 Rule/Refresher 内读**；由业务层 `WithSkipBlockRules` 传入。
   - 映射：`config.GetSwitchMapping(ctx, config.SwitchXxx)`。
2. **环境差异判断**：使用 `biz/service/multienv` 包。
   - `multienv.IsBytePlus()`：海外环境。
   - `quote.IsPrmQuote()` / `quote.IsInnerQuote()` / `quote.IsDistributionBizTypeCustom()`：报价单子类型。
   - 这类判断属于"业务语义分支"，允许在 Rule/Refresher 内直接使用。
3. **i18n 国际化**：所有面向用户的错误文案必须使用 `i18nfmt.Sprintf(ctx, "...")`。
4. **禁止**在 Rule/Refresher 内通过 config 开关实现"是否启用本 Rule"的灰度切流，
   这属于引擎编排层职责，应由业务层 `OverrideStages` 或 `WithSkipBlockRules` 控制。
   判定口诀见 §3.1 第 8 条。

## 4. refresh_engine 侧规范

### 4.1 硬性约束

1. **queryOnly 语义**：`queryOnly=true` 时应只查不写、`Changed=false`、不触发 reload。
   写库路径必须放在 `if !queryOnly { ... }` 块内，或提前 `return newPassRefreshResult(r), nil`。
   **queryOnly 入口仅在 `QuoteBizDataRefresh` 场景使用，送审主链路不传入。**
2. **Changed 语义**：只有真正落库（`BatchSave`、`Update`、`Delete` 成功）后
   才置 `true`；仅内存修改不算。
3. **Mods 覆盖面**：必须覆盖"本次直接写入的 key + 派生受影响的 key"。例如
   `ItemProductInfoRefresher.Mods` 覆盖 `QuoteItems / DeliveryItems /
   ItemCalMap / ItemContextMap`。
4. **允许调用 check_engine 的纯函数**：例如 `CouponTriggerInfoRefresher` 调
   `check_engine.ValidateFullQuoteTriggerQuoteItemIDList`。**禁止**依赖具体
   Rule struct。
5. **底层服务复用**：写库逻辑优先复用 `biz/service/*` 已有 service，避免在
   refresher 内直接写复杂业务；refresher 只做"取数 → 决策 → 转发写"的编排。
6. **错误码**：使用 `CodeNRefresh*` 号段（`codeN_biz_data.go` CC=30 起，即 `30xxxx`）。
7. **返回值语义（Pass=false vs error）**：
   - **`return result, err`**（err 非空）：依赖崩溃、DB 异常、上下文缺失等
     "取数/写库基础设施故障"。**固定短路主链路**（不受 FailFast 影响）。
   - **`return result{Pass:false, BlockLevel:Error}, nil`**：业务判断不通过
     且需要阻断后续流程（理论上少见；大多数"业务判断"应由前置 Rule 完成）。
     **同样固定短路**，因为 Mods 对应的数据未刷新，下游 Rule 读到旧值会误判。
   - **`return result{Pass:false, BlockLevel:Warn}, nil`**：业务判断不通过但
     允许降级，需满足 §4.4 的三项前置条件。执行器**不短路**，继续后续 stage。
   - **`return newPassRefreshResult(r), nil`**：无需更新，正常通过。
   - 落地原则：**依赖故障走 error；写库成功后不应该 Pass=false**（写库前已做
     业务判断，写成功即为成功）。

### 4.2 Refresher 代码骨架

```go
package refresh_engine

import (
    "context"

    "gorm.io/gorm"

    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/engine_common"
    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
    "code.byted.org/gopkg/logs"
)

// <Entity><Domain>Refresher <一句话职责>。
//
// 职责：<...>。
// 触发条件：<...>。
// 失败分支 → CodeN：
//  1. QuoteContext / Quote 缺失 → CodeNRefreshCtxMissing(200001)
//
// 写副作用：<列出写入的表 / dao 方法>；queryOnly=true 时不执行。
// 数据来源：Needs() 声明 <keys>；<其他说明>。
// Mods：<列出成功后需 reload 的 keys>。
type <Entity><Domain>Refresher struct{}

func (r *<Entity><Domain>Refresher) Key() string { return "refresh<Entity><Domain>" }

func (r *<Entity><Domain>Refresher) Desc() string { return "<一句话>" }

func (r *<Entity><Domain>Refresher) Needs() []quote_context.QuoteContextKey {
    return []quote_context.QuoteContextKey{
        quote_context.QuoteContextKeyQuote,
        // ...
    }
}

func (r *<Entity><Domain>Refresher) Mods() []quote_context.QuoteContextKey {
    return []quote_context.QuoteContextKey{
        // 列出所有直接写入 + 派生失效的 key
    }
}

func (r *<Entity><Domain>Refresher) BlockLevel() engine_common.BlockLevel {
    return engine_common.BlockLevelError
}

func (r *<Entity><Domain>Refresher) Refresh(ctx context.Context, tx *gorm.DB, quoteCtx *quote_context.QuoteContext, queryOnly bool) (*engine_common.RefreshResult, error) {
    if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
        return nil, errors.NewBizErrWithMsg(errors.CodeNRefreshCtxMissing, "[<Entity><Domain>Refresher] quote context is missing")
    }
    result := newPassRefreshResult(r)

    // 1) 取数 & 决策（只读）
    needUpdate := /* ... */

    if !needUpdate {
        return result, nil
    }

    // 2) queryOnly 短路（禁止走到写库）
    if queryOnly {
        return result, nil
    }

    // 3) 真正写库
    if err := dal.XxxDao.BatchSave(tx, /* payload */); err != nil {
        logs.CtxError(ctx, "[<Entity><Domain>Refresher] BatchSave failed, err=%s", err.Error())
        return result, err
    }
    result.Changed = true
    return result, nil
}
```

### 4.3 Refresher 之间的依赖表达

**约束**：Refresher 之间**不通过直接调用**互相依赖；只允许通过：

1. **`Needs()` 声明目标 key**：refresher B 若必须读到 refresher A 的 Mods
   产物（如 ItemProductTaxRule 依赖 ItemProductInfo 刷新后的商品版本），则
   B 的 Needs 中声明 A 的 Mods key。
2. **`OpStages` 顺序**：`registration.go` 里把 B 排在 A 之后；执行器会在 A
   Changed=true 时 reload `A.Mods()`，B 读到的即为最新数据。

**反模式**：Refresher B 内 `new(ARefresher).Refresh(...)`——严禁。

### 4.4 Refresher 允许降级为 Warn 的前置条件

**必须同时满足**才允许 `BlockLevel=Warn`：

1. `Mods()` 为空 **或** Mods 声明的 key **不被** OpStages 后续 stage 的
   Rule.Needs 引用。
2. 失败不产生资金/合同/授权类正确性影响。
3. 有 `logs.CtxWarn` + argos 告警埋点。

**反例**：`ItemProductInfoRefresher.Mods=[QuoteItems, DeliveryItems, ItemCalMap,
ItemContextMap]` 被大量下游 Rule 依赖，**不能**降级为 Warn。

## 5. engine_stage 侧规范

1. **新增 opType**：
   - 在 `engine_common/const.go` 新增枚举值（保持字符串与业务动作对齐）。
   - 在 `engine_stage/registration.go` 通过 `RegisterOpType(opType).WithStages(...).WithAccessRules(...)`
     绑定 stage 序列与准入 rule。
2. **新增 Rule**：
   - 必须在 `registration.go` 里通过 `RegisterBucket(bucket).WithRules(...)` 注册到对应桶
     （否则 `Validate` 会 panic）。
   - 注册顺序即桶内执行顺序；同一桶内保持"重上下文 → 具体校验"的自然顺序。
3. **新增 Refresher**：
   - 通过 `RegisterRefreshers(...)` 全局注册（refresher 不属于桶）。
   - 在需要的 opType 的 `WithStages(...)` 中通过 `RunRefresher(&XxxRefresher{})` 插入执行位置。
4. **OpStages 里的 StageItem**：使用 `CheckBucket(bucket)` 和 `RunRefresher(ref)` 构造，
   不手写字符串 key，避免拼写漂移。
5. **CheckResultOption**：白名单降级、按租户降级等"结果后处理"逻辑放在
   `engine_stage`，Rule 内不写这类分支。
   - `opts.ResultOpts` **仅作用于业务数据 Check 结果**，准入 rule 不支持白名单降级。
6. **业务开关**：不在 `service_basic/` 内感知业务开关；灰度、TCC 判断留在
   `biz/service/quote_service_by_engine/` 内决定是否调用 `Run`。
7. **首步一次性 Load vs Refresher 后 Reload**：
   - **首步一次性 Load**：Run 开始前遍历所有 stage 的 `Needs()`（含准入
     rule 的 Needs）做并集，一次性调用 Loader 补齐依赖。此时**不包含** Refresher
     `Mods()`——因为 Mods 是"写入"而非"读取"。
   - **Refresher 后 Reload**：refresher `Changed=true` 且 `Pass=true` 且 `!QueryOnly`
     且 `Mods()` 非空时，执行器用 `WithReloadKeys(modKeys...)` 重刷对应 key，供下游 stage 读取
     最新值。Reload 只刷 `Mods()` 声明的 key。
   - **跨 refresher 依赖**：refresher B 想读到 refresher A 的写入结果，
     需要：① A 在 stage 序列中排在 B 之前；② B 的 `Needs()` 声明 A.Mods
     包含的 key（执行器会在首步 Load 时加载 B.Needs，A 执行完 reload 后
     B 读到的就是最新值）。
8. **FailFast 与 Refresh 步短路**：
   - `opts.FailFast` **仅作用于 Check 步**：命中 Error 时是否立即停止。
   - **Refresh 步固定短路**：refresher 返回 err 或 `Pass=false+BlockLevel=Error`
     时，无论 FailFast 取值如何都立即停止——因为下游 Rule 会读到过时数据，
     继续执行会导致错误放行。
   - Warn/Info 级 refresh 结果不短路。
   - 已有 Blocking 后，执行器会跳过后续 Refresh 步，避免用过时数据写库。

### 5.1 registration.go 追加片段范例

```go
// —— 追加 Rule（在对应桶的 WithRules 中追加）——
RegisterBucket(engine_common.QuoteBizDataTypeQuoteBaseInfo).
WithRules(
    // ...existing rules...
    &check_engine.QuoteXxxRule{},
).

// —— 追加 Refresher（在 RegisterRefreshers 中追加）——
RegisterRefreshers(
    // ...existing refreshers...
    &refresh_engine.XxxRefresher{},
).

// —— 追加 opType（含准入 rule）——
RegisterOpType(engine_common.QuoteBizOpTypeXxx).
WithStages(
    // 前置刷新（按需）
    RunRefresher(&refresh_engine.SomeRefresher{}),
    // Check 桶
    CheckBucket(engine_common.QuoteBizDataTypeQuoteBaseInfo),
    CheckBucket(engine_common.QuoteBizDataTypeQuoteItem),
    // 后置刷新（按需）
    RunRefresher(&refresh_engine.XxxRefresher{}),
).
WithAccessRules(
    &check_engine.OpAccessXxxRule{},
)
```

## 6. CodeN 追加规范

1. 定位号段：查 `pkg/errors/codeN_biz_data.go` 中对应号段最大值 → 追加 `+1`。
2. 常量命名：`CodeNCheck<Entity><Domain>` / `CodeNRefresh<Entity><Domain>`。
3. 文案：中文，简短，尽量与 `Desc()` 保持语义一致，便于用户理解。
4. 严禁复用旧值；`ErrorCode`（老号段）与 `BizErrorCode`（新号段）成对存在。

## 7. 测试规范

1. **Loader**：`loader_<field>_test.go`，覆盖 `param.QuoteID=0`、DB 无结果、
   多依赖串联三类。
2. **Rule**：`biz_data_rule_<xxx>_test.go`，覆盖 pass、每个失败分支各一次、
   上下文缺失。
3. **Refresher**：`biz_data_refresher_<xxx>_test.go`，覆盖 queryOnly / Changed
   / Mods reload。
4. **Registration**：任何新增桶 / rule / refresher 必须让 `MustValidateRegistry`
   通过；跑单测 `go test ./biz/service_basic/engine_stage/...` 快速验证。
5. **命令速查**：
   ```bash
   # 目标包冒烟
   go test ./biz/service_basic/...
   # 注册表校验（Validate 会 panic → 单测失败）
   go test ./biz/service_basic/engine_stage/...
   # 覆盖率
   go test -cover ./biz/service_basic/check_engine/...
   ```

## 8. AI Native 协作规范

- 面向"AI 一句话生成 Rule / Refresher"的场景：
  1. 明确落到哪个包（本手册 `03_decision_playbook.md`）。
  2. 描述 Needs / Mods / BlockLevel / CodeN。
  3. 提供 Desc 单行文案。
  4. 生成后必须走 `04_change_checklist.md` 的自检清单。
  5. 生成后必须回填 `01_current_state.md` 相应清单（用
     `05_prompt_templates.md` 的自更新提示词）。

## 9. 正反对比：容易犯的 12 个错

> 每条给出**错误示范**与**修正示范**，AI 生成代码时对照检查。

### 9.1 Rule 里写库

```go
// 错误：Rule.Check 里直接更新
if err := dal.QuoteDao.Save(tx, quote); err != nil { ... }

// 正确：把回填放到 Refresher（并声明 Mods()），Rule 只读判断
```

### 9.2 Refresher 忽略 queryOnly

```go
// 错误：忽视 queryOnly，直接写
if err := dal.CouponDao.BatchSave(tx, list); err != nil { ... }

// 正确：先短路
if queryOnly {
    return result, nil
}
if err := dal.CouponDao.BatchSave(tx, list); err != nil { ... }
result.Changed = true
```

### 9.3 Loader 里带业务判断

```go
// 错误：Loader 内做业务筛选
if quote.QuoteType == constants.QuoteTypeXxx {
    return nil // 不加载
}

// 正确：Loader 总是加载完整片段；业务筛选留给 Rule
```

### 9.4 Needs 声明冗余

```go
// 错误：不使用的 key 也声明，导致主链路多余查询
return []QuoteContextKey{Quote, QuoteItems, ItemContextMap, ProductInfo, ...}

// 正确：只列 Check 内读到的字段
return []QuoteContextKey{Quote, CouponList}
```

### 9.5 Mods 漏 key

```go
// 错误：Refresher 直接改了 QuoteItems，但 Mods 只声明 CouponList
Mods() = []QuoteContextKey{CouponList}

// 正确：直接写入 + 派生失效 key 全部覆盖
Mods() = []QuoteContextKey{CouponList, QuoteItems, ItemCalMap}
```

### 9.6 BizErrorCode 复用旧值

```go
// 错误：复用别的分支的 CodeN
result.BizErrorCode = errors.CodeNCheckQuoteEcoSellFinalNotInOpp // 语义不匹配

// 正确：在同号段最大值 +1 追加新常量，语义唯一
```

### 9.7 上下文缺失走业务失败

```go
// 错误：quoteCtx==nil 时返回 CheckResult{Pass:false, BizErrorCode: 12xxxx}
// 会污染业务号段并被 Warn 白名单命中，无法通过监控发现

// 正确：走 error 出去
if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
    return nil, errors.NewBizErrWithMsg(errors.CodeNCheckQuoteContextMissing, ...)
}
```

### 9.8 中文文案硬编码

```go
// 错误
result.ErrorMsg = "报价单已提交，请稍后重试"

// 正确
result.ErrorMsg = i18nfmt.Sprintf(ctx, "报价单已提交，请稍后重试")
```

### 9.9 使用 `fmt.Errorf` 越过错误包

```go
// 错误
return nil, fmt.Errorf("find quote failed: %w", err)

// 正确
return errors.ErrCustomerError.WithArgs("查询报价单信息失败")
```

### 9.10 Rule / Refresher struct 带状态

```go
// 错误：单例被并发使用，字段可变会出问题
type XxxRule struct { cache map[string]bool }

// 正确：无状态；需要局部缓存放到方法内
type XxxRule struct{}
```

### 9.11 在 Rule 内 new Loader 再取数

```go
// 错误
qc2, _ := quote_context.NewQuoteContextLoader(id, tx).WithKeys(...).Load(ctx)
data := qc2.Persisted.Xxx

// 正确：把 key 加到 Needs()，让 engine_stage 一次性 Load；Rule 只读 quoteCtx
```

### 9.12 忘记在 registration 注册

```go
// 错误：只写了 Rule 文件，但没加进 registration.go
// 结果：init 阶段 MustValidateRegistry 不会 panic（因为它不知道你新加了 rule），
//       但 opType 触发时不会跑到；灰度悄悄失效
```

**修正**：新增/修改后立刻跑 `go test ./biz/service_basic/engine_stage/...`，并
grep 确认已在 `RegisterBucket(...).WithRules(...)` 或 `RegisterRefreshers(...)` 中注册。

## 10. Rule / Refresher 边界矩阵

| 能力 | Loader | Rule | Refresher | engine_stage | 业务层 |
|---|---|---|---|---|---|
| 读 DB / 外部 | ✅ | ❌ | ✅ | ❌ | ✅（初始化外） |
| 写 DB / 外部 | ❌ | ❌ | ✅（`!queryOnly`） | ❌ | ✅ |
| 判断业务条件 | ❌ | ✅ | ✅（决策是否写） | ❌ | ✅ |
| 触发 QuoteContext reload | ❌（自动） | ❌ | ✅（Mods） | ✅（编排） | ✅（`WithReloadKeys`） |
| 感知灰度开关 | ❌ | ❌ | ❌ | ❌ | ✅ |
| 编排顺序 | ❌ | ❌ | ❌ | ✅ | 通过 `OverrideStages` 微调 |
| 白名单降级 | ❌ | ❌ | ❌ | ✅（`CheckResultOption`，仅作用于业务 Check，不作用于 Access） | ✅（构造 skipRuleMap） |
| 事务与锁 | ❌ | ❌ | ❌ | ❌ | ✅ |
| 返回 err 的语义 | 取数失败，短路 | 上下文/依赖故障，短路 | 依赖/写库故障，**固定短路** | —— | —— |
| 返回 Pass=false 语义 | —— | 业务校验不通过，按 FailFast 决定 | Error 级固定短路；Warn 级降级继续 | —— | —— |

违反矩阵中任意一条即为反模式。

## 11. 并发与共享状态

- 所有 Registry / OpStages / loaderMap 都是**进程启动后只读**结构；不允许运行时
  再 `Register*`。
- Rule / Refresher / Loader 单例在多请求间共享，**必须无状态**。局部变量放
  在方法栈内。
- `QuoteContext` 视为**请求内可变**：`Persisted / External / Inputs` 字段是
  slice/map，禁止跨请求共享；一次业务流程内多个 goroutine 并发读写需要业务
  自己上锁（当前主链路都是同 goroutine 顺序执行）。

## 12. 日志与观测

- 使用 `logs.CtxError` / `logs.CtxWarn` / `logs.CtxInfo`，带 `[<StructName>]`
  前缀，附上 `quoteID`、`opType`、`ruleKey`、`errorCode` 等结构化字段。
- 严禁 `fmt.Println` / `log.Printf`。
- Rule / Refresher 内除失败点外少输出 Info；执行器已在 `runCheckStage /
  runRefreshStage` 打全局 hit 日志。
- 关键错误使用 `argosnotifylogs.CtxError` 触发告警（如 loader 内的关键
  fail-fast）。

## 13. 与既有 Callback 兼容规则

- 允许通过 `quote_context.ConvertToCallbackInfo(qc)` 把 QuoteContext 转成
  `assistant.CallbackInfo`，**仅用于**存量代码。
- **禁止**新代码引入 `assistant.CallbackWithQuote / Callback / CallbackKey`
  等。
- 若历史逻辑迁移遇到字段缺失，优先在 `quote_context/` 补 loader；不要在
  Converter 里增加新字段映射。

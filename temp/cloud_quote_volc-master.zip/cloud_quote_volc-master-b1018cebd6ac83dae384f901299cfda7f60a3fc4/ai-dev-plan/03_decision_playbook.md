# 03. 新增需求落地决策手册

> 拿到"一句话需求"或"技术方案文档"后，按下面这棵决策树先定位包，再选择
> 是**优化原文件**还是**新增文件**。每条路径末尾都给了参考落点。

## 0. 通用决策树（完整版）

```
新需求 (可以是 PRD / 技术方案 / 一句话)
 │
 ├─ Q0：是否属于 service_basic 领域？
 │       否 → 归入 biz/service/*，本手册不覆盖。
 │       是 ↓
 │
 ├─ Q1：需要新的"取数点"吗？（新增字段/新增依赖/放宽查询范围）
 │       是 → §1 quote_context
 │       否 ↓
 │
 ├─ Q2：是否新增/修改"业务校验语义"？（判断某条件是否成立，只读上下文）
 │       是 → §2 check_engine
 │       否 ↓
 │
 ├─ Q3：是否需要"写库/回填/联动更新"？（含 dao Save / Update / Delete，
 │       或者调 biz/service 写方法）
 │       是 → §3 refresh_engine
 │       否 ↓
 │
 ├─ Q4：是否新增/调整"场景编排"？（opType 顺序、桶、准入 rule、灰度切流）
 │       是 → §4 engine_stage / opType
 │       否 ↓
 │
 └─ Q5：是入口层胶水（分布式锁、事务、灰度、参数解析、DTO 转换）？
         是 → biz/service/quote_service_by_engine（不进 service_basic）
```

> **提示**：一个需求经常会横跨多个 Q。此时按顺序分别产出：Loader → Rule/Refresher
> → 注册 → 编排。**每一步都可独立提 PR**。

## 1. 新增/调整查询逻辑（quote_context）

### 1.1 决策分支

| 情况 | 选择 |
|---|---|
| 拓宽已有字段（如 `QuoteItems` 加载条件放宽） | **改原 loader 文件**，加参数或分支；必要时把 dao 层查询也改宽。 |
| 新数据来源与已有字段共享 `QuoteContextKey`，只是字段填充更全 | **改原 loader**。 |
| 全新字段（DB 表、外部服务） | **新增 loader**：`loader_<field>.go` + 新 `QuoteContextKey` + `loaderMap` 登记 + 类型定义放进 `QuoteContextPersisted` 或 `QuoteContextExternal`。 |
| 需要接口入参覆盖的数据 | **新增 InputOption**：`quote_context/quote_input.go` 追加 `WithInputXxx`，字段放进 `QuoteContextInputs`。 |
| 只是把老 `assistant.Callback*` 依赖挪进来 | **新增 loader** 并同时删掉调用点的 Callback；不要新增 Callback 依赖。 |
| 需要按父报价单加载 | 新建 `loaderParentXxx`，字段放到 `QuoteContext.Parent.Persisted` 或 `Parent.External`。 |
| 加载依赖多个 key（如 ProductInfo 依赖 QuoteItems） | `dependKeys()` 声明前置；不要在 load 内手动调用其它 loader。 |

### 1.2 新增流程

1. 决定归属（Persisted / External / Inputs / Parent）。
2. 编辑 `quote_context/const.go`：追加 `QuoteContextKeyXxx`（放在同分区末尾）。
3. 编辑 `quote_context/quote_context.go`：追加对应字段。
4. 新建 `quote_context/loader_<field>.go`：实现 `dependKeys` + `load`（参考
   `02_conventions.md` §2.2 骨架）。
5. `const.go` 的 `loaderMap` 追加映射。
6. 若需要入参覆盖：`quote_context/quote_input.go` 追加 `WithInputXxx`。
7. 单测：`loader_<field>_test.go` 覆盖 `QuoteID=0`、DB 无结果、依赖串联。
8. 回填 `01_current_state.md §2.4`（用 `06_self_update_guide.md` 提示词）。

### 1.3 反例

- 在 `check_engine` / `refresh_engine` 内部直接 `dao.Find...` 拿数据。
- 用 `CallbackInfoConverter` 兜住新写的业务代码——它只服务于**存量迁移**。
- 把外部依赖数据塞进 `Persisted`，或把持久化字段塞进 `External`。
- Loader 里判断"当前 QuoteType 不需要就跳过"——业务判断应留给 Rule。

## 2. 新增/调整业务校验（check_engine）

### 2.1 决策分支

| 情况 | 选择 |
|---|---|
| 已有 Rule 内新增短路分支，且属于同一"用户可修复动作"（例如同一字段新增枚举值校验） | **改原 rule 文件**，追加 `if` 分支，新增分支使用新的 `BizErrorCode`。 |
| 新增分支对应"不同用户修复动作 / 不同业务子域 / 需要独立 skip" | **新增 Rule 文件**；在 `registration.go` 对应桶追加。 |
| 属于一个新的业务实体（如新增"合同池"实体） | **新增 QuoteBizDataType 桶** + 若干 Rule；同时更新相关 `OpStages`。 |
| 只是准入判断（比如"仅审批中修改可执行"） | **新增 `op_access_rule_xxx.go`**，通过 `RegisterOpType(opType).WithAccessRules(...)` 挂载。 |
| 需要跨报价项聚合的整单校验 | **新增 `full_quote_rule_xxx.go`**，Key `BizDataRuleFullQuote<...>`。 |
| 新校验需要写库/更新兜底数据 | **禁止写在 Rule**；用 Refresher 表达（见 §3）。 |
| 新校验只是白名单降级 | **不要新增 Rule**：直接在业务层用 `WithSkipBlockRules` 传入 skipRuleMap。 |
| 校验依赖数据在 QuoteContext 里没有 | 先按 §1 新增 loader，再来写 Rule；Rule 内**不允许**取数。 |

### 2.2 常见新增流程

1. 新建 `biz/service_basic/check_engine/biz_data_rule_<实体>_<子域>.go`（参考
   `02_conventions.md` §3.2 骨架）。
2. 实现 `Key / Desc / Needs / BlockLevel / Check`；顶部注释按规范写。
3. 在 `pkg/errors/codeN_biz_data.go` 追加 `CodeNCheck<xxx>` 号段。
4. 在 `engine_stage/registration.go` 对应
   `RegisterBucket(QuoteBizDataTypeXxx).WithRules(...)` 追加（**保持注册顺序**）。
5. 补齐单测（pass / 每个分支 / 上下文缺失）。
6. 回填 `01_current_state.md §3.5`。

## 3. 新增/调整刷新逻辑（refresh_engine）

### 3.1 决策分支

| 情况 | 选择 |
|---|---|
| 老 refresher 想改写副作用范围 | **改原文件**，同步更新 `Mods()`，确保 `Changed`/`queryOnly` 语义。 |
| 新增一次"取数 → 决策 → 落库"的独立目标 | **新增 refresher**：`biz_data_refresher_<实体>_<子域>.go`。 |
| 只是把某个业务动作前的兜底更新逻辑收敛 | **新增 refresher**，并在 `OpStages` 该 opType 序列的 Check 阶段之前插入。 |
| 更新逻辑跨多个业务实体、必须同事务批量成功 | **保持一个 refresher**（"多个写库共享内存计算或必须原子"是原子化例外）。 |
| 想复用某条 Rule 的判断逻辑 | 抽出"判断纯函数"放到 `check_engine/full_quote_rule_xxx.go` 或独立文件里，供 Rule 和 Refresher 共用；**不要**在 refresher 内实例化 Rule。 |
| 需要按外部事件触发单个 refresher | 业务侧调 `Run` 时传 `opts.OverrideStages = []StageItem{RunRefresher(&XxxRefresher{})}`，使用 `QuoteBizOpTypeBizDataRefresh`。 |

### 3.2 常见新增流程

1. 新建 `biz/service_basic/refresh_engine/biz_data_refresher_<...>.go`（参考
   `02_conventions.md` §4.2 骨架）。
2. 实现 `Key / Desc / Needs / Mods / BlockLevel / Refresh`。
3. `queryOnly=true` 分支必须早返回或跳过写库。
4. 在 `pkg/errors/codeN_biz_data.go` 追加 `CodeNRefresh<xxx>`（CC=30 起，`30xxxx` 号段）。
5. 在 `engine_stage/registration.go`：
   - `RegisterRefreshers(...)` 中追加新 refresher。
   - 在需要的 opType 的 `RegisterOpType(opType).WithStages(...)` 中插入 `RunRefresher(&refresh_engine.XxxRefresher{})`。
6. 若历史别名需要保留，追加 `RefresherKeyAlias`。
7. 单测（queryOnly / Changed / Mods 覆盖）。
8. 回填 `01_current_state.md §4.4`。

## 4. 新增/调整场景编排（engine_stage / opType）

### 4.1 决策分支

| 情况 | 选择 |
|---|---|
| 只调整已有 opType 的执行顺序 | **改 `RegisterOpType(opType).WithStages(...)` 中的 StageItem 顺序**。 |
| 新增 opType（如"配置清单送审"） | **`engine_common.QuoteBizOpType` 追加常量** + `RegisterOpType(opType).WithStages(...)` 编排 stage 序列 + 视情况通过 `WithAccessRules(...)` 挂准入 rule。 |
| 新增桶（如 `QuoteBizDataTypeContractPool`） | **`engine_common.QuoteBizDataType` 追加** + `RegisterBucket(bucket).WithRules(...)` / `RegisterRefreshers(...)` + 相关 opType 的 `WithStages(...)` 中插入对应 StageItem。 |
| 一个 opType 需要按业务动态构造序列（如按 refresher key 触发） | **不动默认 stages**，业务层调用 `Run` 时通过 `opts.OverrideStages` 传入。 |
| 需要在 Rule 结果上做白名单降级 | **在业务侧构造 `WithSkipBlockRules(skipRuleMap)` 传给 `Run`**；不要在 Rule 内做。 |
| 新的 opType 只跑 Check 不跑 Refresh | 在 `WithStages(...)` 中只放 `CheckBucket(...)`，不放 `RunRefresher(...)`；不需要 Mode 过滤。 |

### 4.2 新增 opType 流程

1. `engine_common/const.go` 追加常量。
2. `engine_stage/registration.go` 中通过 `RegisterOpType(opType).WithStages(...).WithAccessRules(...)` 新增 opType 配置。
3. 视需要通过 `WithAccessRules(...)` 挂准入 rule。
4. 在 `biz/service/quote_service_by_engine/` 增加入口调用 `engine_stage.Run`
   （事务、锁、灰度、DTO 转换）。
5. 单测：确保 `MustValidateRegistry` 通过。
6. 回填 `01_current_state.md §5.1 / §6.2`。

## 5. 常见"一句话需求"落点速查（可持续扩充）

| 一句话需求 | 结论 |
|---|---|
| "在保底数量校验里加一个'席位数不能是负数'的分支" | 归属 `GuaranteeTotalSeatsRule`（已在保底桶）。改原文件，新增分支 + 新 `CodeNCheckGuarantee*`。 |
| "新增校验：账号必须绑定组织架构" | 新用户修复动作 → **新增** `biz_data_rule_quote_account_organization.go`，挂到 `QuoteBizDataTypeQuoteBaseInfo` 桶。 |
| "接入'合同池'实体，需要 3 条校验 + 1 条刷新" | 新增桶 `QuoteBizDataTypeContractPool` + 3 Rule + 1 Refresher；在 `SubmitQuote` / `BizDataCheck` 的 `WithStages(...)` 链中插入桶 key 与 refresher key。 |
| "把商品信息刷新前置到报价项校验之前" | 只调 `RegisterOpType(QuoteBizOpTypeSubmitQuote).WithStages(...)` 中的 StageItem 顺序。 |
| "AI 客户端要读取报价单全量商品信息" | 需要拓展查询：先看 `loaderProductInfo` 是否满足；不满足则**改 loader**或**新增 loader**（如 `loaderProductInfoDetail`），供上层复用。 |
| "报价单送审时强制刷新伙伴授权后再校验" | 新增 refresher（或复用），在 `RegisterOpType(QuoteBizOpTypeSubmitQuote).WithStages(...)` 链里把它排在 `QuoteBizDataTypeQuoteBaseInfo` 之前。 |
| "新增一个'预览模式'的整单校验入口，不写库" | 新 opType 或复用 `BizDataCheck`；定义只含 `CheckBucket(...)` 的 stage 序列（不含 Refresh），调用时 `QueryOnly=true`（注意：存量 refresher 对 queryOnly 支持不一致，预览场景不建议包含 refresh 阶段）。 |
| "某个规则只对试运行租户提示、不阻断" | 业务侧构造 skipRuleMap，`WithSkipBlockRules` 降级为 Warn；不动 Rule。 |
| "新增外部依赖：某 CRM 字段，用于多个 Rule" | 新增 `QuoteContextKey` + Loader（`QuoteContextExternal`），Rule 声明 `Needs` 引用即可，无需重复查询。 |
| "整单业务规则文档要自动生成" | 遍历 Registry.RulesByBizDataType(bucket) 获取每个 Rule 的 Key()/Desc()；准入 rule 通过 AccessRulesByOpType(opType) 获取。 |
| "配置清单送审时不再需要 XXX 校验" | 从对应 opType 的 `OpStages` 序列中移除该 QuoteBizDataType 桶（或调整桶结构，视影响面）。 |
| "老 Callback 数据里 A 字段还有 3 处使用" | 优先新增 loader，Rule / Refresher 迁移到 QuoteContext；仅存量代码继续用 CallbackInfoConverter。 |
| "新增：某规则失败时前端要展示自定义 Detail" | 在 `Rule.Check` 中给 `result.Detail = ...`；`Detail` 是 `interface{}`，需保证可 JSON 序列化；Pass=true 也可携带 Detail（详见 §3.3）。 |
| "同一实体的多个 Rule 有共用的判断函数" | 提出 `check_engine/xxx_common.go`（内部包私有 helper）；不要重复代码，也不要下沉到 `engine_common`（除非跨包）。 |
| "AI 一句话：给我加一条'报价单必须有联系人'的校验" | 新 Rule → `biz_data_rule_quote_contact.go`（`QuoteContactRule` / `BizDataRuleQuoteContact`）；挂到 `QuoteBizDataTypeQuoteBaseInfo` 桶。 |

## 6. 反模式清单（一票否决）

1. Rule 内 `dal.*.Save/Update/Delete` 或直接 `http` 调下游。
2. Refresher 忽略 `queryOnly` 直接写库。
3. Loader 里带业务判断（例如按 QuoteType 决定不查某表），业务判断留给 Rule。
4. 直接在业务包里读 `quote_context.loaderMap` 或调用未导出 loader。
5. 新增 Rule / Refresher 但忘了在 `registration.go` 注册（启动会 panic，但 CI
   前必须自查）。
6. `Needs()` 声明大而全，导致主链路一次性加载所有 key。
7. `BlockLevel` 全部 Error，或全部 Warn；应按用户是否可修复决定。
8. 复制 Callback 老逻辑到新 Rule / Refresher（应通过 loader 提供）。
9. 在 Rule / Refresher struct 里塞可变字段（应保持无状态）。
10. 使用裸 `fmt.Errorf` 返回错误，绕过 `errors` 包体系。
11. 用户可见文案硬编码中文，跳过 `i18nfmt.Sprintf(ctx, ...)`。
12. 忘记在 `Mods()` 中声明写入的 key，导致后续 Rule 读到脏数据。

## 7. 快速判定问句（写代码前自己问一遍）

- 我是不是在改数据来源？→ 落点 quote_context。
- 我是不是在判断"某条件是否成立"？→ 落点 check_engine。
- 我是不是在写库/更新？→ 落点 refresh_engine。
- 我是不是在决定"顺序、场景、灰度、参数"？→ 落点 engine_stage 或业务层。
- 我是不是在做业务胶水（DTO、锁、事务）？→ 保持在业务层。

## 8. 四类交付物模板

任何需求决策后，AI/RD **必须**同时输出下列四份内容（缺一不可）：

1. **决策摘要**：一句话说明落点（哪个包、改原文件还是新增、涉及哪些 opType/桶）。
2. **代码 diff**：按 `02_conventions.md` §2~§5 的骨架输出。
3. **注册 diff**：说明 `engine_stage/registration.go` 需要加/减的位置与顺序。
4. **回填 diff**：`01_current_state.md`（及可选的 `03_decision_playbook.md §5`）
   的清单更新，供 `06_self_update_guide.md` 使用。

模板示例：

```
【决策摘要】
本次在 check_engine 新增 Rule：QuoteContactRule（挂 QuoteBaseInfo 桶），
无新桶，SubmitQuote/BizDataCheck 序列不变。

【代码 diff】<...>

【注册 diff】
--- registration.go
+++ registration.go
@@
     RegisterBucket(engine_common.QuoteBizDataTypeQuoteBaseInfo).
     WithRules(
       ...existing...
+      &check_engine.QuoteContactRule{},
     ).

【回填 diff】
--- 01_current_state.md
+++ 01_current_state.md
@@ §3.5 QuoteBaseInfo 行末尾
- ... / QuoteType / QuoteOrderType
+ ... / QuoteType / QuoteOrderType / QuoteContact
```

## 9. QuoteContextKey 选择速查

场景 → 常用 key（`quote_context/const.go`）：

| 场景 | 建议 Needs |
|---|---|
| 判断报价单基础字段 | `QuoteContextKeyQuote` |
| 判断报价项数量/属性 | `QuoteContextKeyQuoteItems` + `QuoteContextKeyDeliveryItems`（+ `QuoteContextKeyQuoteItemsAllStatus` 若含草稿） |
| 判断报价项属性 map | `QuoteContextKeyItemValues` |
| 判断报价项利润率 | `QuoteContextKeyItemCalMap` |
| 判断保底 | `QuoteContextKeyGuaranteeItems` |
| 判断返佣/联合打单 | `QuoteContextKeyRebateItemList` + `QuoteContextKeyOppInfo` + `QuoteContextKeySpecialRebatePolicy` |
| 判断代金券 | `QuoteContextKeyCouponList` + `QuoteContextKeyApplyItems` |
| 判断信控 | `QuoteContextKeyCreditList` + `QuoteContextKeyApplyItems` |
| 判断资源单/资源卡 | `QuoteContextKeyResourcePage` + `QuoteContextKeyQuoteResourceItems` + `QuoteContextKeyResourceItemsFromQuote` |
| 判断报价单关联合同 | `QuoteContextKeyQuoteContract` |
| 判断商品信息 | `QuoteContextKeyProductInfo`（依赖 QuoteItems / DeliveryItems 已声明） |
| 判断商机/联打 | `QuoteContextKeyOppInfo` |
| 判断报价项 + ItemContext | `QuoteContextKeyItemContextMap` |
| 判断父报价单 | `QuoteContextKeyParentQuote` + `QuoteContextKeyParentQuoteItems` + ... |
| 判断分销商 | `QuoteContextKeyDistributorInfo` + `QuoteContextKeyPartnerGrant` |
| 判断账号邀约类型 | `QuoteContextKeyCustomerGrantType` + `QuoteContextKeyAccountAndVerifyInfos` |
| 判断项目制配置清单 | `QuoteContextKeyConfigList` + `QuoteContextKeyConfigRelatedQuote` |
| 判断代金券配比 | `QuoteContextKeyQuoteItemCouponRatioList` |
| 判断组合规则 | `QuoteContextKeyCombineRulesBySolution` |
| 判断补充协议 | `QuoteContextKeyRelatedSupplyQuotes` |
| 判断交付项目标成本 | `QuoteContextKeyDeliveryItemCost` |

> Loader 之间已声明依赖（如 `ProductInfo` 依赖 `QuoteItems + DeliveryItems`），
> 在 Needs 只声明"你自己直接读的"字段即可；上游会自动 pull 前置。

## 10. 20+ 真实场景决策案例

> 每条按"需求 → 落点 → 交付物"三段式；直接可作为 AI 上下文喂入。

### 10.1 保底新增校验

**需求**："保底采购总席位数不能超过合同人数上限，超过就阻断送审。"

- 落点：`check_engine` 保底桶。已有 `GuaranteeTotalSeatsRule` 校验非法值，
  但当前只覆盖"负数/非零校验"。
- 决策：**改原文件**，新增分支 → 新 `CodeNCheckGuaranteeTotalSeatsExceedContract`（1404NN，保底桶 CC=14，按文件 RR 号段）。
- 交付：Rule 修改 + CodeN 追加 + 回填 §3.4 + §3.5 说明不变（Rule 名保持）。

### 10.2 新增账号维度校验

**需求**："所有报价单必须绑定至少一个企业实名账号，未绑定则阻断。"

- 落点：`check_engine` 报价单基础信息桶。
- 决策：**新增** `biz_data_rule_quote_enterprise_account.go`
  (`QuoteEnterpriseAccountRule` / `BizDataRuleQuoteEnterpriseAccount`)。
- Needs：`Quote` + `AccountAndVerifyInfos`。
- Registration：`RegisterBucket(QuoteBizDataTypeQuoteBaseInfo).WithRules(...)` 追加。
- CodeN：`CodeNCheckQuoteEnterpriseAccountMissing`（12NNxx，QuoteBaseInfo 桶 CC=12，按文件 RR 号段最大值+1）。

### 10.3 新增外部依赖：客户信用等级

**需求**："报价单送审前调用 CRM 客户信用等级接口，用于判断能否申请信控。"

- 落点：跨层。需先扩 `quote_context`（新增 loader），再改 `check_engine`。
- 决策：
  1. 新增 `loader_customer_credit_grade.go` → `QuoteContextKeyCustomerCreditGrade`
     挂到 `QuoteContextExternal.CustomerCreditGrade`。
  2. 改 `CreditSupportRule` 引用该 key。
- 交付：两个 diff（loader + rule 修改）+ CodeN 可复用现有 `CodeNCheckCreditNotSupport`。

### 10.4 新增刷新：动态设置 QuoteItem 是否计入业绩

**需求**："送审时按新规则重新计算 QuoteItem.IncludeInPerformance 字段并落库。"

- 落点：`refresh_engine`。
- 决策：**新增** `biz_data_refresher_item_performance_flag.go`
  (`ItemPerformanceFlagRefresher` / `refreshItemPerformanceFlag`)。
- Needs：`Quote` + `QuoteItems` + `DeliveryItems`。
- Mods：`QuoteItems` + `DeliveryItems`。
- OpStages：插入到 `QuoteBizOpTypeSubmitQuote` 序列的 QuoteItem 桶之前。

### 10.5 调整 OpStages 顺序

**需求**："SubmitQuote 时要先刷 ItemCalFactorData 再校验 QuoteItem。"

- 落点：`engine_stage/registration.go`。
- 决策：**只调 `RegisterOpType(QuoteBizOpTypeSubmitQuote).WithStages(...)`**，把
  `RunRefresher(&refresh_engine.ItemCalFactorDataRefresher{})` 前移到
  `CheckBucket(engine_common.QuoteBizDataTypeQuoteItem)` 之前。
- **⚠ 必须评估**：
  1. 遍历该 refresher 的 `Mods()`（如 `ItemContextMap`），检查 QuoteItem 桶
     内所有 Rule 的 `Needs()` 是否读该 key；若读，则前置后 Rule 会看到刷新后
     的值（这通常正是目的）。
  2. 前置后可能导致 Rule 内的判定基线变化，单测需要重跑；如变化不符合预期，
     考虑新增 Rule 而不是调顺序。
  3. 前置 refresher 有额外的 DB 写副作用，需评估性能与失败回滚。
- 交付：仅一份 registration.go diff + 回填 §6.2 顺序表 + Rule 影响面说明。

### 10.6 新 opType：预览模式

**需求**："给前端一个'预览模式'的 API，跑完整校验但不写库，返回所有 warning。"

- 落点：`engine_common` + `engine_stage` + 业务层。
- 决策：
  1. `engine_common.QuoteBizOpTypePreview`。
  2. `RegisterOpType(QuoteBizOpTypePreview).WithStages(...)`：复用 BizDataCheck 的 Check 桶序列
     （只含 CheckBucket，不含任何 RunRefresher），无需 Mode 过滤。
  3. 业务层 `biz/service/quote_service_by_engine/preview.go` 新增入口。
- 交付：4 段 diff（const + registration + 业务入口 + 回填）。

### 10.6a 按报价单子类型分叉编排（新增/移除桶）

**需求**："配置清单送审不需要 Guarantee 桶（配置清单本身不允许配置保底）。"

- 落点：`engine_stage` + 业务层。
- **方案对比**：

  | 方案 | 做法 | 评价 |
  |---|---|---|
  | A. 新增 opType | `QuoteBizOpTypeSubmitConfigList`，独立 OpStages | ✅ 推荐；桶职责清晰、灰度可控；代价是业务入口需要按报价单类型分派 |
  | B. Rule 内加 if | `GuaranteeSupportRule.Check` 顶部 `if quote.IsConfigList() { return pass }` | ❌ 反模式；违反"Rule 无状态 + 只判断"，语义泄漏到规则内部 |
  | C. 业务层 `OverrideStages` | 每次调 `Run` 前根据类型剔除桶 | ⚠️ 可用但脆弱；桶顺序修改后所有入口都要跟改 |

- **决策规则**：
  - 分叉是**长期业务差异**（如"配置清单永远不需要 Guarantee"）→ 方案 A。
  - 分叉是**动态运行时决策**（如"根据 UUID 抽样跑不同子集"）→ 方案 C。
  - 无论如何都**不允许**走方案 B。
- 交付：常量 + OpStages diff + 业务分派入口 + 回填 §5.1/§6.2。

### 10.6b 复用已有桶前的合规检查

**需求**："新增 `CloneQuote` opType，想直接复用 `QuoteBaseInfo` 桶。"

- **合规检查（必须做，不能省）**：
  1. 遍历该桶内所有 Rule 的 `Check` 实现，`grep` 是否有 opType 硬编码（如
     "当前报价单已经提交，不可修改" 类专属送审语义）。
  2. 若有硬编码 → **不能直接复用**；先按"用户可修复动作"维度拆细，把 opType
     专属分支挪到准入 Rule 或独立 Rule。
  3. 若无硬编码 → 直接在 `RegisterOpType(NewOpType).WithStages(...)` 中用 `CheckBucket(...)` 引用桶。
- **反例**：当前 `OpAccessQuoteOperationRule` 内 `IsConfigList / IsInModifyProcess`
  这类判断本身就是 opType 语义；如复用到 Clone 场景需重新审视。
- 交付：合规检查报告 + WithStages diff + 若需拆分则附拆分方案。

### 10.7 单个规则灰度降级

**需求**："某白名单租户对 `ItemDeliveryCostRule` 只提示不阻断。"

- 落点：业务层。
- 决策：**不改 Rule**；业务侧构造
  `skipRuleMap := map[string]bool{"BizDataRuleItemDeliveryCost": true}` +
  `WithSkipBlockRules(skipRuleMap)` 传入 `Run`。
- ⚠ 语义提醒（见 `01_current_state.md §6.3`）：命中白名单后
  `BlockLevel` 变 `Warn` 且 `Pass=true`；业务侧要展示 warning 请按
  `r.BlockLevel == BlockLevelWarn` 收集，不能按 `!r.Pass` 过滤。

### 10.8 新增业务实体：合同池

**需求**："合同池上线，报价单送审要校验合同池 3 条规则，且需要 1 条兜底刷新。"

- 落点：跨层，最重的一类改动。
- 决策：
  1. `engine_common.QuoteBizDataTypeContractPool`。
  2. `quote_context` 新增 3~5 个 loader（合同池实体、明细、外部依赖）。
  3. `check_engine` 新增 3 个 Rule；`refresh_engine` 新增 1 个 Refresher。
  4. `registration.go`：注册桶 + Rule + Refresher；`RegisterOpType(QuoteBizOpTypeSubmitQuote).WithStages(...)`
     中插入 `CheckBucket(...)` 与 `RunRefresher(...)`。
- 交付：8~10 段 diff；提交策略：拆分 3 个 PR（loader / rule / refresher & 编排）。

### 10.9 修改 Loader 查询条件

**需求**："`loaderQuoteItems` 目前排除失效项，需要在特定 opType 下也包含失效项。"

- 落点：`quote_context`。
- 决策：**不要在原 loader 里加分支**；改用现成的 `loaderQuoteItemsExpired`
  分别取；如果两者需合并使用，则在 Rule 或 Refresher 内合并读。

### 10.10 CodeN 号段耗尽

**需求**："报价单基础信息号段快用完了，还剩 5 个位。"

- 决策：**不允许**换号段；当同号段满 999 后再讨论。号段规划上就是每类 1000
  个，够用。

### 10.11 新增 Warn 级 Rule

**需求**："上量时间距签约超过 24 个月，展示告警但不阻断。"

- 落点：`check_engine`。
- 决策：新增 Rule；`BlockLevel()` 返回 `BlockLevelWarn`；业务层不会因它中断
  流程，但会展示到前端 warning 列表。

### 10.12 Refresh 内部失败降级

**需求**："外部计费系统抖动时，refresher 不阻断主链路，改为 Warn 兜底。"

- **降级前置条件（必须同时满足）**：
  1. Refresher 的 `Mods()` 为空 **或** Mods 声明的 key **不被** OpStages 后续
     stage 的 Rule.Needs 引用（读取真实代码确认）。
  2. 失败对业务提交的正确性不产生资金/合同/授权类影响。
  3. 有明确的告警观测（`logs.CtxWarn` + argos 埋点）。
- **满足**上述条件 → `BlockLevel()` 返 `Warn`，`Refresh` 内 catch err 后
  `return result{Pass: true, Changed: false}, nil`。
- **不满足**任一条件 → 保持 `BlockLevel=Error`，`Refresh` 直接 `return
  result, err`，让上层终止。
- **反模式**：把 ItemProductInfoRefresher 这种 Mods 覆盖
  `QuoteItems / DeliveryItems / ItemCalMap / ItemContextMap` 的 refresher
  降级为 Warn——下游 Rule 会用过时数据校验，可能放行错误提交。

### 10.13 需要跨请求缓存（不推荐）

**需求**："商品树查询很贵，希望缓存 5 分钟。"

- 决策：**不在 Rule / Refresher / Loader 加缓存**；缓存放到 `biz/service/*` 层
  或 `pkg/*_client/` 层。Loader 只做取数编排。

### 10.14 需要 opts.OverrideStages 触发单个 Refresher

**需求**："配置清单更新后要单独刷新 QuoteRelatedResDep。"

- 决策：业务层调
  ```go
  engine_stage.Run(ctx, tx, QuoteBizOpTypeBizDataRefresh, qc, engine_stage.ExecOptions{
      FailFast:       true,
      OverrideStages: []engine_stage.StageItem{engine_stage.RunRefresher(&refresh_engine.QuoteRelatedResDepRefresher{})},
  })
  ```
- 不改默认 stages。

### 10.15 Rule 需要读父报价单

**需求**："项目制补充协议校验，需要读父报价单数据。"

- 决策：`Needs` 声明 `QuoteContextKeyParentQuote` + `ParentQuoteItems` 等；父
  上下文已在 `QuoteContext.Parent` 承载，Rule 内读 `quoteCtx.Parent.Persisted.Quote`。

### 10.16 QuoteBizDataType 桶被误用作准入

**需求**："想加一条'仅审批中可操作'的准入判断。"

- 决策：**不能**注册到业务数据桶；通过 `RegisterOpType(opType).WithAccessRules(...)`
  挂到 opType 上，走独立的准入 FailFast 路径。

### 10.17 InputOption 场景

**需求**："提交前对比接口入参代金券与 DB 已存代金券，出差异要拦截。"

- 决策：业务层调 `WithInputOpts(WithInputCouponList(reqCouponList))`；Rule 内
  比较 `quoteCtx.Inputs.CouponList` 与 `quoteCtx.Persisted.CouponList`。

### 10.18 存量 Rule 想拆细

**需求**："`QuoteAccountXxxRule` 太胖，想拆成 5 条独立 Rule。"

- 决策：按 `ai-docs/check_engine_rule_atomization_plan.md` 拆分原则。
- **Key 变化风险**：当前分支的 `engine_stage.WithSkipBlockRules` 已注释
  "历史 ruleKey 无使用记录，不再做兼容映射"（见 `executor.go:38`），即
  **旧 `compatibleRuleKeyMap` 机制已经不存在**。拆 Key 时不能再依赖它。
- 处理流程：
  1. PR 中列出旧 Key → 新 Key 的迁移表；
  2. 与业务侧一起把线上白名单 `skipRuleMap` 的 key 替换成新 Key；
  3. 变更同一批次上线，避免"旧 Key 白名单"命中不了新 Rule 造成回退困难。

### 10.19 校验规则文档要按业务描述生成

**需求**："产品经理希望看到 SubmitQuote 校验规则列表。"

- 决策：遍历 Registry 上 opType 绑定的 AccessRulesByOpType + 各桶 RulesByBizDataType，
  收集每个 Rule 的 Key()/Desc() 输出；无需修改任何 Rule。

### 10.20 修改历史 Refresher Key

**需求**："`refreshProductTaxRule` 名字重命名为 `refreshItemProductTaxRule`。"

- 决策：
  - Rename Key。
  - 在业务层 `quote_service_by_engine/biz_data_refresh.go` 的 `refresherKeyAlias` 里
    保留 `"refreshProductTaxRule" → "refreshItemProductTaxRule"` 映射（外部入参归一 + 出参还原）。
- 交付：refresher 修改 + alias 增加 + 回填 §4.4 表 Key 列。

### 10.21 Refresher 返回值的短路语义

**背景**：Refresher 返回 `(*RefreshResult, error)`，与 Rule 的 `(*CheckResult, error)`
签名对称，但执行器对它们的 FailFast 处理**不对称**。

- **固定短路（不受 FailFast 影响）**：
  1. `err != nil`——依赖/DB/RPC 故障。
  2. `rr.Pass==false && rr.BlockLevel==Error`——业务判定需要阻断（极少见，
     大多数"不该刷"的场景应提前走 Rule）。
  原因：refresher 失败意味着 Mods 对应的数据**未刷新**，下游 Rule 用旧值
  校验会产生误放行/误阻断；必须短路。
- **不短路**：
  1. `rr.Pass==false && rr.BlockLevel==Warn`——满足 §02_conventions.md §4.4
     三项前置条件的降级场景。
  2. `rr.Pass==true && rr.Changed==false`——无需更新，正常通过。
- **Rule 侧对比**：Rule 的 `Pass=false+Error` 按 `opts.FailFast` 决定是否短路；
  `Pass=false+Warn` 永不短路。
- **落地原则**：Refresher 里遇到"业务条件不满足、不应写库"的场景，
  **不要**返回 `Pass=false+Error`，而应直接 `return newPassRefreshResult(r), nil`
  （即"无需更新"）；真正的"应该刷新但刷新不了"才走 err 或 Pass=false+Error。

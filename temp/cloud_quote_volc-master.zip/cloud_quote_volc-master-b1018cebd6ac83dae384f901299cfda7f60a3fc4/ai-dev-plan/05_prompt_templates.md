# 05. AI 提示词模板（复制即用）

> 本文件是**给使用者的提示词库**。使用方法：
>
> 1. 从 `01_current_state.md` 复制"分层总览 + 相关小节"作为 AI 的**System 背景**。
> 2. 从下方选择匹配场景的模板，把 `<占位符>` 替换成你的需求信息，作为 **User Prompt**。
> 3. AI 完成后再用 §7 的"自检提示词"让它对照 `04_change_checklist.md` 逐项自查。
> 4. 最后用 §6 的"自更新手册提示词"让 AI 回填 `01_current_state.md`。
>
> ⚠ 所有模板都要求 AI **先读 `ai-dev-plan/`**，不允许自行发明命名与接口。

## 0. 通用 System 前缀（每次都放这段）

```
你正在为 cloud_quote_volc 仓库的报价系统写代码，目标目录：biz/service_basic/。
必读文档（依次阅读并作为唯一权威）：
- ai-dev-plan/01_current_state.md（现状事实）
- ai-dev-plan/02_conventions.md（规范与代码骨架）
- ai-dev-plan/03_decision_playbook.md（决策路径）
- ai-dev-plan/04_change_checklist.md（自检项）

强制约束：
1. 严格按 02_conventions.md 的代码骨架生成；命名、注释、CodeN、Needs/Mods 语义不得漂移。
2. 落点必须先通过 03_decision_playbook.md 的决策树判断，并在回答里显式说明"改原文件 / 新增文件"。
3. 生成完代码后，必须逐项回答 04_change_checklist.md 中相关的自检条目。
4. 生成完代码后，必须给出一段 diff 或完整代码块，用于 01_current_state.md 的对应清单回填。
5. 不允许引入 assistant.Callback*；不允许 Rule 内写库。
6. queryOnly 语义：所有 Refresher 必须正确实现 queryOnly=true 禁止写库的分支，`queryOnly=true` 时不执行任何写库操作且 `Changed=false`。
```

## 1. 新增查询逻辑（quote_context Loader）

```
【需求】<一句话描述数据来源与用途>
【落点】quote_context

请完成：
1. 在 `quote_context/const.go` 追加 QuoteContextKey；说明放在哪个分区。
2. 在 `quote_context/quote_context.go` 对应结构体追加字段（Persisted / External / Inputs / Parent 择一）。
3. 新建 `quote_context/loader_<field>.go`，按 02_conventions.md §2.2 骨架实现。
4. `loaderMap` 追加映射。
5. 若需要入参覆盖，在 `quote_context/quote_input.go` 追加 WithInputXxx。
6. 生成对应单测 `loader_<field>_test.go`，覆盖 QuoteID=0 / 无数据 / 依赖串联。

输出要求：
- 每个文件独立一个代码块，路径清楚标注。
- 结尾附一份"01_current_state.md §2.4 需要新增的清单条目"，格式与现有表一致。
```

## 2. 新增业务校验（check_engine Rule）

```
【需求】<一句话描述校验目标>
【落点】check_engine 的 <QuoteBaseInfo / QuoteItem / Guarantee / Rebate / Coupon /
       Credit / ResourcePage / FullQuote / OpAccess> 桶

请完成：
1. 判断改原 Rule 文件还是新增文件（参考 03_decision_playbook.md §2.1）。
   - 如果新增：文件名 `biz_data_rule_<实体>_<子域>.go`；struct `<Entity><Domain>Rule`；Key `BizDataRule<Entity><Domain>`。
2. 按 02_conventions.md §3.2 骨架生成 Rule 代码：
   - 明确 Needs()（只列真正读到的 key）
   - 明确 BlockLevel()
   - 明确失败分支及每个分支的 ErrorCode / BizErrorCode / 用户可读文案（i18nfmt）
   - Desc() 单行覆盖所有分支
3. 在 `pkg/errors/codeN_biz_data.go` 追加 CodeNCheck<XXX>（沿号段最大值 +1）。
4. 在 `engine_stage/registration.go` 对应桶 WithRules 中追加新 Rule。
5. 生成单测：pass / 每个失败分支 / 上下文缺失。

输出要求：
- 显式说明"改原文件"还是"新增文件"，并给出决策依据。
- 每个改动一段独立 diff 或完整代码块。
- 结尾附一份 01_current_state.md §3.5 表格需要新增的一行。
- 逐项确认 04_change_checklist.md §C 通过。
```

## 3. 新增刷新逻辑（refresh_engine Refresher）

```
【需求】<一句话描述刷新目标>
【落点】refresh_engine（全局注册，不属于任何桶，按 key 精确触发）

请完成：
1. 判断改原 Refresher 还是新增（参考 03_decision_playbook.md §3.1）。
   - 如果新增：文件名 `biz_data_refresher_<实体>_<子域>.go`；struct `<Entity><Domain>Refresher`；Key 由 Refresher.Key() 返回（驼峰命名，如 `refresh<Entity><Domain>`）。
2. 按 02_conventions.md §4.2 骨架生成 Refresher 代码：
   - Needs() 覆盖所有读取 key
   - Mods() 覆盖所有写入 + 派生失效 key
   - queryOnly=true 时禁止走到写库
   - 只有真实落库成功后置 Changed=true
3. 在 `pkg/errors/codeN_biz_data.go` 追加 CodeNRefresh<XXX>（CC=30 起，`30xxxx` 号段）。
4. 在 `engine_stage/registration.go`：
   - `RegisterRefreshers(...)` 全局追加
   - 在需要的 OpType 上用 `RegisterOpType(opType).WithStages(...)` 或追加到已有 WithStages 链中，用 `RunRefresher(&refresh_engine.XxxRefresher{})` 构造 StageItem
5. 如需兼容外部老 key，在 `biz/service/quote_service_by_engine/biz_data_refresh.go` 的 `refresherKeyAlias` 中追加别名映射。
6. 生成单测：queryOnly 不写库 / Changed 语义 / Mods reload 生效。

输出要求：
- 显式说明"改原文件"还是"新增文件"，并给出决策依据。
- 结尾附一份 01_current_state.md §4.4 表格需要新增的一行。
- 逐项确认 04_change_checklist.md §D 通过。
```

## 4. 新增场景（engine_stage / opType）

```
【需求】<描述新场景的业务动作、执行顺序、准入条件、灰度策略>

请完成：
1. 在 `engine_common/const.go` 追加 `QuoteBizOpType<Xxx>` 常量。
2. 在 `engine_stage/registration.go` 用新 DSL 注册 OpType：
   - `RegisterOpType(engine_common.QuoteBizOpType<Xxx>).`
   - `.WithStages(RunRefresher(&refresh_engine.XxxRefresher{}), CheckBucket(engine_common.QuoteBizDataTypeXxx), ...)`
   - 写清楚每一步是 refresher（用 `RunRefresher`）还是桶（用 `CheckBucket`），Stages 按声明顺序执行
3. 如需准入 Rule：`.WithAccessRules(&check_engine.OpAccessXxxRule{})` 挂在同一 OpType 链上（准入永远最先执行且 FailFast）。
4. 在 `biz/service/quote_service_by_engine/` 增加入口调用 `engine_stage.Run`（保留事务/锁/灰度）。
5. `MustValidateRegistry` 必须通过。

输出要求：
- 展示新 OpType Stage 序列的完整代码。
- 结尾附一份 01_current_state.md §5.1、§6.2 需要新增的表格行。
- 逐项确认 04_change_checklist.md §E / §F 通过。
```

## 5. 一句话 → 完整方案

```
我的需求：<一句话>

请你先扮演架构师：
1. 用 03_decision_playbook.md §0 的决策树判断落点，列出涉及的所有层。
2. 输出一个执行计划（分层动作清单）。
3. 询问我是否补充信息（如涉及的字段、外部依赖、灰度需求）。

在我确认后，你再扮演开发者：
- 依次调用 §1~§4 的模板生成代码。
- 每步生成后暂停，等我确认再继续。
- 最后调用 §6 的"自更新手册提示词"完成 01_current_state.md 回填。
```

## 6. 自更新手册提示词（**代码合入后必用**）

> 使用场景：AI 已生成并合入代码；现在需要把新增点回填到 `ai-dev-plan/01_current_state.md`
> （必要时也回填 `03_decision_playbook.md §5` 常见需求速查）。

```
本轮需求已完成代码合入，现在请你**只修改文档**，不改代码。

已完成的变更：
<列出：新增/修改了哪些文件，包括路径、struct/Key/CodeN/桶归属>

请按以下步骤更新 ai-dev-plan/：

Step 1 - 更新 01_current_state.md
- 如果新增 Loader → 在 §2.4 对应列表追加。
- 如果新增 Rule → 在 §3.5 表格对应桶行追加 Rule 名。
- 如果新增 Refresher → 在 §4.4 表格追加一行（Refresher / Key / Mods）。
- 如果新增 QuoteBizOpType → 在 §5.1 与 §6.2 表补齐。
- 如果新增 QuoteBizDataType → 在 §5.1、§6.2 补齐；§3.5 / §4.4 补齐相应桶。
- 如果新增 CodeN 号段 → 在 §3.4 补齐说明。

Step 2 - 更新 03_decision_playbook.md §5（当本次需求是"通用类型"时才追加）
- 只在下列情况追加：本次需求属于"未来还可能再遇到"的常见类型。
- 追加格式与现有速查表一致：一列"一句话需求"，一列"结论"。

Step 3 - 检查
- 输出 diff 形式的改动预览。
- 确保不改动 02_conventions.md / 04_change_checklist.md / 05_prompt_templates.md 的锚点；
  这三份文件只由人工维护。

强制约束：
- 不允许新增 md 文件；只能编辑已有的。
- 不允许修改 §1 分层总览、依赖方向等硬性约束段落。
- 不允许删除历史清单条目，除非本次代码同步移除。
```

## 7. 自检提示词（提交 PR 前）

```
请对本次生成的代码逐项对照 ai-dev-plan/04_change_checklist.md：
- 输出每个相关小节（A / 视情况 B~F）的勾选表。
- 每条要么 ✅（说明如何满足），要么 ❌（说明如何补上）。
- 有 ❌ 就先给补丁再收工。

同时给出：
- 需要人工验证的项（如涉及线上灰度、TCC 开关）。
- 建议跑的本地命令（引用 04_change_checklist.md §I）。
```

## 8. Meta 提示词（改进本手册）

> 使用场景：发现手册本身与代码不一致（例如接口签名、常量取值），需要 AI 一次性
> 把手册对齐到代码事实。

```
请对照当前分支 biz/service_basic/ 下的真实代码，扫描 ai-dev-plan/ 中的下列文件：
- 01_current_state.md
- 02_conventions.md
- 03_decision_playbook.md

对每一条与代码不符的描述，输出：
1. 位置（文件 + 小节 + 行号）
2. 手册当前描述 vs 代码事实
3. 修复建议（用 Edit 工具直接改）

不要修改 04_change_checklist.md / 05_prompt_templates.md /
06_self_update_guide.md 的锚点与结构。
```

## 9. 场景专用模板（补齐常见增量路径）

### 9.1 新增 InputOption（接口入参 → QuoteContext）

```
【需求】<接口参数字段 X 需要注入 QuoteContext.Inputs 作为 Rule 校验依据>

请完成：
1. 在 `quote_context/quote_context.go` 的 `QuoteContextInputs` 追加字段 X。
2. 在 `quote_context/quote_input.go` 追加 WithInputX(x ...) InputOption，
   保持"字段为空时才赋值"惯例。
3. 在使用侧 Rule 的 Needs 无需变化（Inputs 不走 loader）；Rule 内读
   quoteCtx.Inputs.X。
4. 业务层调用 loader 时使用 WithInputOpts(quote_context.WithInputX(...))。

输出要求：
- 独立展示 3 段 diff（结构体 / InputOption / Rule 读取）。
- 说明 InputOption 是否需要暴露给 refresh_engine（默认不需要）。
- 回填 01_current_state.md §2 相关表格（Inputs 字段增加）。
```

### 9.2 修改 Stage 顺序

```
【需求】<描述：把 refresher/桶从位置 A 移到位置 B，或调整两个桶顺序>

请完成：
1. 在 `engine_stage/registration.go` 编辑对应 `RegisterOpType(opType).WithStages(...)` 链中的 StageItem 顺序。
2. 给出编辑前后对比表（列出所有 StageItem.Key 序列）。
3. 说明为什么需要调整（业务上依赖顺序 or 性能考虑）。
4. 确认对下游 Rule 的 Needs 是否有影响（例如把 Refresh 前置后，某 Rule 依赖的
   key 是否可能被 Refresh 改写）。

输出要求：
- 完整的新版 WithStages 序列 + 顺序对比表。
- 回填 01_current_state.md §6.2 表格。
```

### 9.3 新增白名单降级（不改 Rule）

```
【需求】<把 Rule X 对某租户/某开关下从 Error 降级为 Warn>

请完成：
1. 不修改 Rule；在 `biz/service/quote_service_by_engine/` 或调用方业务层
   构造 skipRuleMap，key 使用 Rule.Key() 精确匹配。
2. 调 engine_stage.Run 时把 `WithSkipBlockRules(skipRuleMap)` 加到
   ExecOptions.ResultOpts。
3. 增加对开关/租户的判断（TCC 开关取值 → skipRuleMap）。

输出要求：
- 一段 quote_service_by_engine 侧的 diff（构造 skipRuleMap + 传入）。
- 无需 registration.go、01_current_state.md 变更。
- 单测：断言开关命中时该 Rule 结果被降级为 Warn 且不阻断。
```

### 9.4 存量 Callback 迁移到 QuoteContext

```
【需求】<某段老代码仍在使用 assistant.Callback* 获取字段 X>

请完成：
1. 在 `quote_context/` 判断字段 X 是否已有 loader；
   - 已有：直接改老代码，从 CallbackInfo 换成 QuoteContext。
   - 无：新增 loader（见 §1）。
2. 保证老逻辑逐步替换，最终清除 `assistant.CallbackWithQuote` 调用。
3. 如无法一次替换完，可临时使用 `quote_context.ConvertToCallbackInfo(qc)`
   把 QuoteContext 转成 CallbackInfo 兼容旧调用。

输出要求：
- 老代码替换 diff。
- 新增 loader（如有）。
- 说明是否引入 Converter；如引入，标注后续退场计划。
```

### 9.5 新增单元测试

```
【需求】<给新加的 Rule / Refresher / Loader 补齐测试>

请完成：
- Rule：pass / 每个失败分支 / 上下文缺失 / BlockLevel 断言。
- Refresher：queryOnly=true 不写库 / queryOnly=false 且条件成立 → Changed=true /
  条件不满足 → Changed=false / Mods reload 有效。
- Loader：QuoteID=0 / DB 无结果 / 有前置依赖串联 / 加载后 loadedKeys 幂等。

输出要求：
- 使用 `mockey.Mock` 或 gomock 桩掉 dao 与外部 client。
- 断言使用 `assert.Equal / assert.NotNil` 从 testify。
- 每个用例独立函数命名 `TestXxxRule_<Branch>`。
```

## 10. 完整问答样例（新增一条 Rule）

> ⚠ 本节的字段/CodeN 值为**示例**，实际以代码事实为准；AI 生成前必须先
> `grep` 校验字段是否存在、老码是否已有。

**输入**（User Prompt）：

```
需求：报价单送审时，若"客户联系人邮箱"为空则阻断，提示"请填写客户联系人邮箱"。
```

**AI 先做的调研（必要，写代码前一定要做）**：

```
1. grep -n "ContactEmail" biz/dal/model/quote.go
   → 若字段不存在：告知用户"Quote 模型没有 ContactEmail 字段，需要业务确认
     字段名（可能叫 ContactPerson / ContactInfo）或者先加 DDL"。
   → 若字段存在：继续。

2. grep -n "CodeN.*ContactEmail\|CodeN.*Contact" pkg/errors/codeN.go
   → 找是否有可复用的老 8 位码（如 CodeNQuoteContactRequired）。
   → 若无：新增一个业务导向老码 CodeNQuoteContactEmailRequired = 12000NNN
     （对应号段最大值 +1）。

3. rg "ErrorCodeN = 12[0-9][0-9][0-9][0-9]" pkg/errors/codeN_biz_data.go | sort
   → 找 QuoteBaseInfo 桶（CC=12）号段最大值，新号码在其上 +1。
```

**期望 AI 输出**（按四类交付物；仅在完成调研且字段/号段确认后）：

````
【决策摘要】
- 落点：check_engine 报价单基础信息桶（QuoteBaseInfo）。
- 决策：新增 Rule `QuoteContactEmailRule`（`BizDataRuleQuoteContactEmail`）。
- 数据来源：仅需 Quote 字段，无外部依赖。
- CodeN：报价单基础信息号段（CC=12）对应 RR 最大值 +1。
- Registration：`RegisterBucket(engine_common.QuoteBizDataTypeQuoteBaseInfo).WithRules(...)` 末尾追加。

【代码 diff】
--- biz/service_basic/check_engine/biz_data_rule_quote_contact_email.go (新增)
+++
package check_engine

import (
    "context"

    "code.byted.org/eps-platform/cloud_quote_volc/biz/service/multienv/i18nfmt"
    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/engine_common"
    "code.byted.org/eps-platform/cloud_quote_volc/biz/service_basic/quote_context"
    "code.byted.org/eps-platform/cloud_quote_volc/pkg/errors"
)

// QuoteContactEmailRule 报价单客户联系人邮箱必填校验。
//
// 职责：送审前检查 Quote.ContactEmail 字段非空。
// 触发条件：始终校验。
// 失败分支 → CodeN：
//  1. ContactEmail 为空 → CodeNCheckQuoteContactEmailMissing(12NNxx)
//
// 数据来源：Needs() 声明 Quote；无 DB/RPC 查询；无写副作用。
type QuoteContactEmailRule struct{}

func (r *QuoteContactEmailRule) Key() string  { return "BizDataRuleQuoteContactEmail" }
func (r *QuoteContactEmailRule) Desc() string { return "报价单必须填写客户联系人邮箱。" }
func (r *QuoteContactEmailRule) Needs() []quote_context.QuoteContextKey {
    return []quote_context.QuoteContextKey{quote_context.QuoteContextKeyQuote}
}
func (r *QuoteContactEmailRule) BlockLevel() engine_common.BlockLevel {
    return engine_common.BlockLevelError
}
func (r *QuoteContactEmailRule) Check(ctx context.Context, quoteCtx *quote_context.QuoteContext) (*engine_common.CheckResult, error) {
    if quoteCtx == nil || quoteCtx.Persisted.Quote == nil {
        return nil, errors.NewBizErrWithMsg(errors.CodeNCheckQuoteContextMissing, "[QuoteContactEmailRule] quote context is missing")
    }
    result := newPassCheckResult(r)
    if quoteCtx.Persisted.Quote.ContactEmail == "" {
        result.Pass = false
        result.ErrorCode = errors.CodeNQuoteContactEmailRequired // TODO: 若没有对应老码，可复用统一提示码
        result.ErrorMsg = i18nfmt.Sprintf(ctx, "请填写客户联系人邮箱")
        result.BizErrorCode = errors.CodeNCheckQuoteContactEmailMissing
        result.BizErrorMsg = i18nfmt.Sprintf(ctx, "请填写客户联系人邮箱")
        return result, nil
    }
    return result, nil
}

--- pkg/errors/codeN_biz_data.go
+++
+    CodeNCheckQuoteContactEmailMissing ErrorCodeN = 12NNxx // 报价单客户联系人邮箱必填（NN 取对应文件 RR 序号）

【注册 diff】
--- biz/service_basic/engine_stage/registration.go
+++
     RegisterBucket(engine_common.QuoteBizDataTypeQuoteBaseInfo).WithRules(
         ...existing rules...
+        &check_engine.QuoteContactEmailRule{},
     ).

【回填 diff】
--- ai-dev-plan/01_current_state.md
+++ §3.5 QuoteBaseInfo 行末尾
-  … / QuoteType / QuoteOrderType
+  … / QuoteType / QuoteOrderType / QuoteContactEmail

+++ §3.4 号段更新（如首次触碰对应 RR）
   加一行说明"12NNxx 报价单联系人邮箱必填"（可选）

【自检对照 04_change_checklist §C】
- [x] 文件/struct/Key 一致
- [x] Needs 只列真读的 key
- [x] Check 无写副作用
- [x] 上下文缺失走 error
- [x] BizErrorCode 使用新号段（CC=12）
- [x] BlockLevel=Error（可修复动作）
- [x] Desc 单行
- [x] 已在 registration.go 追加
- [x] 单测计划：pass / 空邮箱 / 上下文缺失
````

> AI 只要产出上面这种结构化四段（决策 / 代码 / 注册 / 回填 + 自检），即可直接
> 交付。

# 04. 新增/修改自检清单

> 把这份清单当作 PR 提交前的守门员。任何在 `biz/service_basic/` 内的改动，
> 都应逐项过一遍——漏掉任何一项都会引起启动失败、灰度失效或线上误拦截。
>
> AI 生成代码后请把本清单原文粘贴到 AI 上下文里，让它逐项确认已通过。

## A. 通用（所有改动）

- [ ] 变更点属于 `01_current_state.md` 描述的正确分层（quote_context / check_engine /
      refresh_engine / engine_stage / engine_common）。
- [ ] 所有面向用户的错误文案均使用 `i18nfmt.Sprintf(ctx, ...)`。
- [ ] 关键错误 `logs.CtxError` / `logs.CtxWarn` 带 `[<StructName>]` 前缀。
- [ ] 结构体注释头部完备：Rule/Refresher/Loader 都遵循 `02_conventions.md` §1
      的注释小节。
- [ ] 无裸 `fmt.Errorf` 出到调用方；返回 `errors.NewBizErrWithMsg / ErrCustomerError.WithArgs`。
- [ ] 单测覆盖成功路径与所有失败分支。
- [ ] `goimports -w` 已运行，import 顺序合规。
- [ ] `go vet ./biz/service_basic/...` 通过。
- [ ] `go test ./biz/service_basic/...` 通过。
- [ ] `go build ./...` 通过。

## B. quote_context 新增字段

- [ ] `QuoteContextKey` 常量已在 `const.go` 追加，位置紧跟同类别最后一个 key。
- [ ] 字段已归入 `QuoteContextPersisted` / `QuoteContextExternal` / `QuoteContextInputs`
      三者之一，位置正确。
- [ ] 新增 `loader<Field>` struct 实现 `dependKeys()` + `load(...)`。
- [ ] `loaderMap` 已登记新 key。
- [ ] 若为入参字段，`WithInputXxx` InputOption 已实现，且遵守"只在字段为空时赋值"。
- [ ] Loader 内没有写库、没有直接调用其它 loader（只走 `dependKeys()`）。
- [ ] `param.QuoteID == 0` 已 fail-fast。
- [ ] `loader_<field>_test.go` 覆盖 `QuoteID=0`、无数据、依赖串联三类。

## C. check_engine 新增/修改 Rule

- [ ] 文件名 / struct 名 / Key 三者语义一致（如 `biz_data_rule_item_count.go`
      / `ItemCountRule` / `BizDataRuleItemCount`）。
- [ ] `Needs()` 只声明真正读的 key（避免冗余）。
- [ ] `Check` 内**无任何写副作用**（dao Save/Update/Delete、HTTP write RPC 一律禁止）。
- [ ] 上下文缺失走 `return nil, errors.NewBizErrWithMsg(...)`，不占业务 CodeN。
- [ ] `ErrorCode` 使用 `codeN.go` 原有值以兼容前端；`BizErrorCode` 使用
      `codeN_biz_data.go` 新号段（未复用旧值）。
- [ ] `BlockLevel()` 与业务预期一致（可修复 → Error / 提示 → Warn / 埋点 → Info）。
- [ ] `Desc()` 单行、能覆盖所有失败分支语义。
- [ ] 已在 `engine_stage/registration.go` 的对应桶 / opType 注册（保持注册顺序）。
- [ ] 如果是准入 rule，已通过 `RegisterOpType(opType).WithAccessRules(...)` 挂载。
- [ ] 单测：pass / 每个失败分支 / 上下文缺失 / BlockLevel 断言。

## D. refresh_engine 新增/修改 Refresher

- [ ] 文件 / struct / Key 一致（如 `biz_data_refresher_coupon_trigger_info.go`
      / `CouponTriggerInfoRefresher` / `couponTriggerInfo`）。
- [ ] `Needs()` 覆盖读到的所有 key；`Mods()` 覆盖写入 + 派生失效的所有 key。
- [ ] `queryOnly=true` 分支中**没有任何写库调用**，且 `Changed=false`。
- [ ] 真正落库成功后才置 `Changed=true`；仅内存修改不置 `Changed`。
- [ ] 已在 `RegisterRefreshers(...)` 里追加。
- [ ] 已在对应 opType 的 `RegisterOpType(opType).WithStages(...)` 中通过 `RunRefresher(...)` 插入执行位置。
- [ ] 如果修改了历史 Key，`biz/service/quote_service_by_engine/biz_data_refresh.go` 中的 `refresherKeyAlias` 已补齐旧 → 新映射。
- [ ] 单测：queryOnly 不写库 / Changed 语义 / Mods reload 生效。

## E. engine_stage / engine_common 变更

- [ ] 新增 `QuoteBizOpType` 常量已在 `engine_common/const.go` 声明。
- [ ] 新增 `QuoteBizDataType` 桶已在 `engine_common/const.go` 声明。
- [ ] `RegisterOpType(opType).WithStages(...)` 中每个 StageItem 的 Key 都能被 `Registry.KindOf` 识别（使用 `CheckBucket(bucket)` / `RunRefresher(ref)` 构造可避免拼写错误）。
- [ ] 新增桶必须至少通过 `RegisterBucket(bucket).WithRules(...)` 注册一条 Rule（否则 Validate 报"unregistered"）。
- [ ] 准入 Rule 通过 `RegisterOpType(opType).WithAccessRules(...)` 单独挂载，未混入业务数据桶。
- [ ] `Registry.Validate()` 在 init 阶段执行且未 panic（可用
      `go test ./biz/service_basic/engine_stage/...` 触发）。

## F. 业务层联动

- [ ] 若引入新 opType，`biz/service/quote_service_by_engine/` 已有对应入口调用
      `engine_stage.Run` 并做灰度切换。
- [ ] 灰度开关 / 白名单降级仅在业务层构造，未污染 `service_basic`。
- [ ] 事务 / 分布式锁在业务入口处保持；`service_basic` 内不再新增锁语义。

## G. 文档 / 沉淀（必须回填）

- [ ] 更新 `ai-dev-plan/01_current_state.md` 相应清单：
  - 新 Loader → §2.4
  - 新 Rule → §3.5
  - 新 Refresher → §4.4
  - 新 opType / QuoteBizDataType → §5.1、§6.2
  - 新 CodeN 号段 → §3.4
- [ ] 如果出现了新的常见需求，追加到
      `ai-dev-plan/03_decision_playbook.md §5` 的速查表。
- [ ] 若新增了对外规则/描述需求，通过遍历 Registry 的 RulesByBizDataType / AccessRulesByOpType 获取每个 Rule 的 Key()/Desc() 生成文档。
- [ ] AI Native 生成的代码，在合入前**手动核对**过 Needs / Mods / CodeN。
- [ ] 使用 `05_prompt_templates.md` §6 的"自更新手册提示词"让 AI 完成回填。

## H. 灰度 & 回滚（如涉及线上行为变更）

- [ ] 已确认业务层 TCC / Switch 是否覆盖新逻辑。
- [ ] 如存在灰度开关，确认老链路是否仍可回退。
- [ ] 有埋点 / 日志能观察新 Rule / Refresher 的命中率与耗时。

## I. 命令速查（本地必跑）

```bash
# 1. 静态检查
gofmt -l ./biz/service_basic
go vet ./biz/service_basic/...

# 2. 单测（含 Registry.Validate）
go test ./biz/service_basic/...

# 3. 覆盖率（重点模块）
go test -cover ./biz/service_basic/check_engine/...
go test -cover ./biz/service_basic/refresh_engine/...
go test -cover ./biz/service_basic/engine_stage/...

# 4. 全量编译
go build ./...
```

## J. 一次性排查脚本（AI 生成代码后建议跑）

> 使用 `rg`（ripgrep）快速定位常见漂移点，可在 PR 前一键执行。

```bash
# 1. 新增 Rule 是否已注册到 registration.go
rg -n "type\s+[A-Z][A-Za-z0-9]+Rule\s+struct" biz/service_basic/check_engine/ \
  | awk -F: '{print $3}' | awk '{print $2}' \
  | while read s; do
      rg -q "&check_engine\.$s\b" biz/service_basic/engine_stage/registration.go \
        || echo "MISSING registration: $s"
    done

# 2. 新增 Refresher 是否已注册
rg -n "type\s+[A-Z][A-Za-z0-9]+Refresher\s+struct" biz/service_basic/refresh_engine/ \
  | awk -F: '{print $3}' | awk '{print $2}' \
  | while read s; do
      rg -q "&refresh_engine\.$s\b" biz/service_basic/engine_stage/registration.go \
        || echo "MISSING registration: $s"
    done

# 3. Rule 内不允许出现 Save / Update / Delete（只读约束）
rg -n "dal\.[A-Za-z]+Dao\.(Save|Update|Delete|BatchSave)" biz/service_basic/check_engine/ \
  && echo "❌ Rule 内出现写库调用" || echo "✅ Rule 只读"

# 4. Refresher 内 queryOnly 短路语句
rg -n "func .*Refresh\(" biz/service_basic/refresh_engine/ -l | \
  while read f; do
    rg -q "queryOnly" "$f" || echo "⚠️ 未处理 queryOnly: $f"
  done

# 5. 中文文案是否走 i18nfmt
rg -n 'ErrorMsg\s*=\s*"' biz/service_basic/check_engine/ biz/service_basic/refresh_engine/ \
  | grep -v 'i18nfmt.Sprintf' \
  && echo "❌ 存在硬编码文案" || echo "✅ 全部走 i18nfmt"

# 6. CodeN 号段是否重复
rg -n "ErrorCodeN\s*=\s*[0-9]+" pkg/errors/codeN_biz_data.go \
  | awk -F'= ' '{print $2}' | sort | uniq -d \
  && echo "❌ 存在重复号段" || echo "✅ CodeN 号段唯一"

# 7. Needs 声明的 key 是否都在 loaderMap 里
rg -n "QuoteContextKey[A-Z][A-Za-z0-9]+" biz/service_basic/check_engine/ biz/service_basic/refresh_engine/ \
  -o | sort -u | awk -F: '{print $NF}' | sort -u | \
  while read k; do
    rg -q "$k:\s+loader" biz/service_basic/quote_context/const.go \
      || echo "⚠️ Needs 声明但未在 loaderMap 登记：$k"
  done
```

## K. 常见漂移排查清单（PR 出现问题时看这里）

| 症状 | 排查点 |
|---|---|
| 启动 panic：`invalid quote biz registry: opType [X] refers unregistered key [Y]` | `WithStages(...)` 里的 `Y` 未在 `RegisterBucket` 或 `RegisterRefreshers` 注册；对齐 Key 拼写（建议用 `CheckBucket()`/`RunRefresher()` 构造）。 |
| 启动 panic：`rule key [X] duplicated in bucket [A] and [B]` | 同一 Rule 被误注册到两个桶；`Rule.Key()` 全局唯一。 |
| Rule 命中却没执行 | 忘了在 `registration.go` `WithRules(...)` 加入；跑 §J 脚本 1。 |
| Refresher 写了但 QuoteContext 里没生效 | `Mods()` 漏 key；或 `queryOnly=true` 时 `Changed=true` 造成误 reload；核对 `04_change_checklist §D`。 |
| Rule 内报"CtxMissing" 频繁 | 上游 Needs 声明与 Rule 使用不匹配；把 Rule 读到的字段全部列进 `Needs()`。 |
| BizDataCheck 报"quote context is nil" | 业务入口忘了 `Load(ctx)`；`quote_service_by_engine/biz_data_check.go` 的三段式必须完整。 |
| 白名单降级不生效 | `WithSkipBlockRules` 传入的 key 与 `Rule.Key()` 不匹配（大小写、前缀）。 |
| 主链路耗时暴涨 | 检查 Needs 是否声明冗余、`OpStages` 是否插入了不需要的 refresher。 |
| Refresh 步返回 Pass=false 但主链路继续执行 | 确认 BlockLevel：Error 固定短路；Warn 不短路。不应出现 Pass=false+Error 不短路（已在执行器修复）。 |
| Refresher 报错后下游 Rule 仍执行、放行脏数据 | 确认 refresher 正确返回 err（而不是吞掉错误返回 Pass=true）；执行器收到 err 已固定短路。 |
| 首步 Load 没加载到 Refresher Mods 的 key | 这是预期的；Mods 仅在 Changed=true 后通过 WithReloadKeys 增量 reload，不进首步 Needs 聚合。跨 refresher 依赖需按顺序 + 在下游 refresher 的 Needs 声明上游 Mods key。 |

## L. AI 代码生成后必答问题

> 让 AI 在给出代码后逐条回答：

0. **调研前置**：
   - Rule 用到的字段是否在 `biz/dal/model/` 真实存在？（`grep -n` 附证据）
   - 老 `CodeN` 是否已有可复用值？如新增，新老码分别是什么？位数是否符合
     `01_current_state.md §3.4`（老码 8 位 / 新码 6 位）？
   - Rule 依赖的 `QuoteContextKey` 是否都在 `loaderMap` 里？
1. 本次改动属于 §A 通用检查外，还涉及 §B/§C/§D/§E/§F 哪几节？
2. 是否新增了 `QuoteContextKey`？如是，`loaderMap` 是否登记？
3. 是否新增了 CodeN？取值多少？是否在对应号段的最大值 +1？
4. 是否新增/修改了 `RegisterOpType(opType).WithStages(...)` 的 StageItem 顺序？如是，前后对比列出。
5. 是否需要在 `biz/service/quote_service_by_engine/` 增加或修改入口？
6. 灰度回滚方案是什么？（TCC 开关 / 版本回滚 / 白名单降级）
7. §J 排查脚本预期是否全部通过？如未跑，需要在 PR 说明中标注。
8. `01_current_state.md` / `03_decision_playbook.md §5` 需要如何回填？给
   diff。
9. 若使用了 `WithSkipBlockRules`，业务层收集 warning 是否按
   `BlockLevel==Warn` 而非 `!Pass`？（避免语义踩坑）

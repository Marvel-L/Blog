# 01. 现状梳理：service_basic 下五个包

> 本文只描述**当前分支** `dev/refresh_upgrade` 上 `biz/service_basic/` 下五个包的
> 既定事实。写代码前必须先按这里的分层归属决定"新增逻辑落到哪个包"。
> 每次代码合入后，必须回填本文件对应小节（见 `06_self_update_guide.md`）。

## 0. 架构背景

本目录是飞书 Wiki [报价系统 QuoteContext + 校验引擎化技术方案](https://bytedance.larkoffice.com/wiki/Hgd8wUb1miPVDgkTBigcB1ifnec)
（token: `N1rzdj95IoCsBOxMSawce8jWnUe`）在 `cloud_quote_volc` 仓库内的代码化投影。
方案目标：在不拆服务的前提下，将三套分散的校验体系（`processcheck`、`biz_data_checker`、
`item_context/validator`）统一收敛到"QuoteContext 数据载体 + Rule/Refresher 策略 + Registry DSL
编排"的引擎化架构。

**当前架构状态（已落地，灰度切换中）**：

- 核心引擎层（engine_common / quote_context / check_engine / refresh_engine / engine_stage）已完整实现并通过单测。
- 所有业务 Rule 已完成原子化拆分，按 QuoteBizDataType 分桶注册；所有 Refresher 已完成原子化拆分，全局注册。
- CCRRNN 6 位分层错误码体系已全面启用（详见 §3.4）。
- 三个业务入口（SubmitQuote / BizDataCheck / BizDataRefresh）均通过 v2 包以灰度开关方式逐步切流到 engine_stage.Run，v1 旧链路保留作为回退（详见 §10）。
- 存量 `assistant.Callback*` 依赖通过 `quote_context.ConvertToCallbackInfo(qc)` 适配器兼容，供遗留代码逐步迁移。**新增需求一律以本手册为准，禁止新增 `assistant.Callback*` 依赖。**

**性能基线**：
- BizDataCheck：集群 p95 < 250ms、p99 < 500ms（不含外部依赖极端抖动）
- SubmitQuote 校验阶段：耗时较旧链路持平或下降
- DB 查询次数：通过 Needs 精准声明，较 callbackKeys 全量拉取下降 20%~40%

## 1. 分层总览

```
biz/service_basic/
├── engine_common/     # 通用契约：BlockLevel / QuoteBizOpType / QuoteBizDataType
│                      # StageKind / CheckResult / RefreshResult / 公共 helper
├── quote_context/     # 报价单上下文数据载体 + Loader（唯一取数入口）
├── check_engine/      # 只读校验规则集合（Rule 实现）
├── refresh_engine/    # 允许写库的刷新器集合（Refresher 实现）
└── engine_stage/      # 注册中心 + 执行入口（把 rule / refresher 组织到 opType 序列）
```

包内代表文件坐标（AI 生成代码时可直接引用）：

| 关注点 | 文件 | 关键符号（Symbol : Line） |
|---|---|---|
| QuoteContext 结构体 | `biz/service_basic/quote_context/quote_context.go` | `QuoteContext:25` / `QuoteContextPersisted:35` / `QuoteContextExternal:70` / `QuoteContextInputs:85` |
| QuoteContextKey 枚举 & loaderMap | `biz/service_basic/quote_context/const.go` | `QuoteContextKey* iota:6` / `loaderMap:63` |
| Loader 协议 | `biz/service_basic/quote_context/loader_data.go` | `loader interface:9` |
| Loader 派发器 | `biz/service_basic/quote_context/quote_context_loader.go` | `NewQuoteContextLoader:26` / `NewLoaderByQuoteContext:41` / `WithKeys:50` / `WithReloadKeys:56` / `WithInputOpts:62` / `Load:68` / `doLoad:108` |
| InputOption 组合器 | `biz/service_basic/quote_context/quote_input.go` | `InputOption:5` / `WithInputCouponList:7` / `WithInputCreditList:15` |
| Callback 兼容适配 | `biz/service_basic/quote_context/callback_info_converter.go` | `ConvertToCallbackInfo:52` |
| Rule 接口 | `biz/service_basic/check_engine/biz_rule.go` | `QuoteBizRule:11` / `newPassCheckResult:20` |
| Refresher 接口 | `biz/service_basic/refresh_engine/biz_refresher.go` | `QuoteBizRefresher:12` / `newPassRefreshResult:22` |
| 引擎公共常量 | `biz/service_basic/engine_common/const.go` | `BlockLevel:5` / `QuoteBizOpType:14` / `QuoteBizDataType:26` / `StageKind:40`（含 `StageKindAccess`） |
| 引擎公共模型 | `biz/service_basic/engine_common/model.go` | `CheckResult:9` / `RefreshResult:31` |
| 引擎公共 helper | `biz/service_basic/engine_common/func.go` | `HasApplyItem:15` / `GetAllItems:83` 等 |
| Registry DSL | `biz/service_basic/engine_stage/registry.go` | `Registry:15` / `RegisterBucket:41` / `RegisterRefreshers:56` / `RegisterOpType:76` / `WithStages:82` / `WithAccessRules:89` / `KindOf:100` / `Validate:162` / `MustValidateRegistry:227` |
| OpStages 场景序列 | `biz/service_basic/engine_stage/registration.go` | `init:17`（使用 `RegisterBucket`/`RegisterRefreshers`/`RegisterOpType` 链式 DSL 完成全部注册） |
| Refresher 别名兼容 | `biz/service/quote_service_by_engine/biz_data_refresh.go` | `refresherKeyAlias:22` / `resolveRefresherKey:36` / `restoreRefresherKey:44` |
| 引擎执行器 | `biz/service_basic/engine_stage/executor.go` | `Run:127` / `runAccessRules:282` / `runCheckStage:310` / `runRefreshStage:362` / `fillCheckResult:429` / `fillRefreshResult:454` / `ExecOptions:18` / `WithSkipBlockRules:42` |
| StageResult 模型 | `biz/service_basic/engine_stage/stage.go` | `StageItem:17` / `StageResult:33` / `CheckBucket:22` / `RunRefresher:27` / `IsBlocking:41` / `uniqueQuoteContextKeys:82` |
| CodeN 号段 | `pkg/errors/codeN_biz_data.go` | `CodeNCheck*:6-262` / `CodeNRefresh*:265+` |
| 业务入口 | `biz/service/quote_service_by_engine/` | `BizDataCheck:39`(biz_data_check.go) / `QuoteBizDataRefresh:78`(biz_data_refresh.go) / `SubmitQuote:53`(submit_quote.go) |

依赖方向（严格单向）：

```
engine_stage → check_engine, refresh_engine, quote_context, engine_common
check_engine  → quote_context, engine_common
refresh_engine → quote_context, engine_common, （极少数：check_engine 内的纯函数）
quote_context → dal, biz/service/*   （允许调 dao / 外部服务，是唯一取数点）
engine_common → 无业务依赖，只承载常量与结果模型
```

不允许出现的依赖：

- `check_engine` / `refresh_engine` → 反向依赖 `engine_stage`。
- `quote_context` → 依赖 `check_engine` / `refresh_engine` / `engine_stage`。
- `check_engine.Rule` 在 `Check` 里写库（只读约束）。
- 业务包（`biz/service/*`）直接 new loader / 直接读 `loaderMap`（loader 只由
  `QuoteContextLoader` 调度）。

主链路端到端时序（送审为例）：

```
biz/service/quote_service_by_engine/submit_quote.go
        │  (业务层：分布式锁、事务、灰度)
        ▼
quote_context.NewQuoteContextLoader(quoteID, tx).Load(ctx)  ← 拿到最小 QuoteContext（含 Quote）
        │
        ▼
engine_stage.Run(ctx, tx, opType, quoteCtx, opts)    ← 一次调用完成 access + stages
        │  1. collectNeeds：汇总 access rules + stages 中所有 Needs() → 一次性 Load 补齐依赖
        │  2. 跑准入 rule（固定 FailFast）
        │  3. 按 opType 绑定的 stage 序列执行 CheckBucket / RunRefresher
        │  4. Refresh 步：Changed=true 且非 QueryOnly 且 Mods() 非空 → reload Mods
        │     （Refresh 步 Error 固定短路；Check 步按 opts.FailFast 决定短路）
        ▼
返回 ExecResult{QuoteCtx, Stages, Blocking}
        │
        ▼
业务层根据 BlockingErr() / SummarizeCheckResults() 决定阻断 / 汇总 Warn / Info
```

## 2. quote_context 现状

### 2.1 核心结构

- `QuoteContext`：`quote_context/quote_context.go`
  - `Persisted`：报价单持久化数据（Quote / QuoteItems / GuaranteeItems / …）。
  - `External`：外部依赖数据（ProductInfoMap / OppInfo / PartnerGrant / …）。
  - `Inputs`：接口入参数据（CouponList / CreditList，用于对比 DB 已存值）。
  - `loadedKeys`：内部去重表，防止同 key 重复加载。
  - `Parent`：可选的父报价单上下文（补充协议场景）。
- `QuoteContextKey`：`quote_context/const.go`
  - 枚举形式（`iota`）声明所有可加载的数据片段，按"持久化 / 父报价单 / 外部依赖"
    分区，分区注释务必保留。
  - `loaderMap[QuoteContextKey] loader` 建立 key → loader 的一一映射。

### 2.2 Loader 协议

`quote_context/loader_data.go`：

```go
type loader interface {
    dependKeys() []QuoteContextKey
    load(ctx, tx, param, qc) error
}
```

- 每个字段对应一个 `loaderXxx` struct（`loader_<field>.go`）。
- `dependKeys()` 声明该 loader 依赖哪些其它 key，`doLoad` 内递归加载依赖。
- 相同 key 已在 `loadedKeys` 里则短路返回，避免重复查询。
- `WithReloadKeys` 支持业务写入后**强制重刷**同一批 key。
- 循环依赖用 `visiting` 集合识别，遇到即报错。
- 加载失败统一使用 `errors.ErrCustomerError.WithArgs("查询xxx信息失败")` 或
  `errors.NewBizErrWithMsg(...)`，禁止裸 `fmt.Errorf`。

### 2.3 QuoteContextLoader API

`quote_context/quote_context_loader.go`：

| API | 用途 |
|---|---|
| `NewQuoteContextLoader(quoteID, tx)` | 从头构建新的 QuoteContext。默认带 `QuoteContextKeyQuote`。 |
| `NewLoaderByQuoteContext(qc, tx)` | 基于已有 QuoteContext 增量加载/重刷（`engine_stage.Run` 使用）。 |
| `WithKeys(...)` | 声明本次要加载的持久化/外部 key。 |
| `WithReloadKeys(...)` | 声明必须强制刷新（哪怕已加载）的 key。 |
| `WithInputOpts(opts...)` | 注入 `InputOption`，仅赋值 `Inputs.*` 字段，不做加载。 |
| `Load(ctx)` | 触发一次加载 + 关联 Inputs，返回 `*QuoteContext`。 |

InputOption 组合器：`quote_context/quote_input.go`（如 `WithInputCouponList`，
只在字段为空时赋值，保持"外部入参一次注入"语义）。

### 2.4 现有 Loader 清单（示例，按类别）

- 持久化：`loaderQuote / loaderOriginQuote / loaderQuoteSolutions /
  loaderQuoteItems / loaderQuoteItemsExpired / loaderDeliveryItems /
  loaderItemValues / loaderItemCalMap / loaderBizLine / loaderCouponList /
  loaderCreditList / loaderRebateItemList / loaderGuaranteeItems /
  loaderResourcePage / loaderQuoteResourceItems / loaderRelatedSupplyQuotes /
  loaderQuoteContract / loaderConfigRelatedQuote / loaderConfigList /
  loaderQuoteItemCouponRatioList / loaderItemContextMap / loaderApplyItems /
  loaderCombineRulesBySolution / loaderDeliveryItemCost /
  loaderResourceItemsFromQuote / loaderResourceItemRespsFromDB /
  loaderQuoteItemsAllStatus`
- 父报价单：`loaderParentQuote / loaderParentGuaranteeItems /
  loaderParentQuoteItems / loaderParentDeliveryItems / loaderParentItemValues /
  loaderParentItemCalMap / loaderParentItemContextMap / loaderParentContractTime`
- 外部：`loaderProductInfo / loaderConfigTreeMap / loaderConfigInfoMap /
  loaderPriceInfoMap / loaderOppInfo / loaderSpecialRebatePolicy /
  loaderDistributorInfo / loaderPartnerGrant / loaderAccountAndVerifyInfos /
  loaderAccountFinancialRole / loaderCustomerGrantType`

> 需要新增字段时，先查是否可复用其中之一；确实缺失才走"新增 loader"路径。

### 2.5 迁移适配器

`quote_context/callback_info_converter.go` 把 `QuoteContext` 组装成老的
`assistant.CallbackInfo`，供历史代码逐步迁移。**新代码禁止再引入
`assistant.Callback*` 依赖**。

## 3. check_engine 现状

### 3.1 接口

`check_engine/biz_rule.go`：

```go
type QuoteBizRule interface {
    Key() string
    Desc() string
    Needs() []quote_context.QuoteContextKey
    BlockLevel() engine_common.BlockLevel
    Check(ctx, quoteCtx) (*engine_common.CheckResult, error)
}
```

- `newPassCheckResult(rule)`：构造完备的默认 pass 结果，Rule 内使用。
- Rule **只读** `quoteCtx`，不允许调用 dao / 外部服务写副作用；派生查询也
  尽量提前放到 loader。

### 3.2 命名与文件约定

- 单项数据校验：`biz_data_rule_{实体}_{子域}.go`，struct `<实体><子域>Rule`，
  Key `BizDataRule<实体><子域>`（如 `ItemCountRule` / `BizDataRuleItemCount`）。
- 整单业务校验：`full_quote_rule_xxx.go`，struct `FullQuoteXxxRule`，
  Key `BizDataRuleFullQuoteXxx`。
- 操作准入校验：`op_access_rule_xxx.go`，struct `OpAccessXxxRule`，
  Key `OpAccessRuleXxx`。
- 每个 Rule 顶部注释固定小节：**职责 / 触发条件 / 失败分支 → CodeN /
  数据来源**。
- `Desc()` 单行覆盖 Rule 全部失败语义，可用于自动生成校验规则文档。

### 3.3 结果模型

`engine_common.CheckResult` 主要字段：

| 字段 | 语义 |
|---|---|
| `Pass` | 是否通过 |
| `BlockLevel` | Error / Warn / Info；Error 才会 FailFast |
| `RuleKey` / `RuleDesc` | 稳定标识与文档描述 |
| `ErrorCode` / `ErrorMsg` | 对外主错误码，沿用 `pkg/errors/codeN.go` |
| `BizErrorCode` / `BizErrorMsg` | 原子化后的新号段（`codeN_biz_data.go` 中 `CodeNCheck*`），仅内部诊断 |
| `Detail` | 内部诊断细节 |

### 3.4 CodeN 号段（详见 `pkg/errors/codeN_biz_data.go`）

**两套并存的错误码**（AI 常混淆，务必分清）：

| 号段 | 位数 | 常量前缀 | 归属文件 | 用途 |
|---|---|---|---|---|
| `12000xxx` 等 8 位老号段 | 8 位 | `CodeNXxx`（无 Check/Refresh 前缀） | `pkg/errors/codeN.go` | 对外主错误码，前端根据它做 UI；例如 `CodeNNoQuoteItem = 12000004`。**新增 Rule 时优先复用已有值**，实在没有再新增。 |
| `1NNNNN` 6 位新号段 | 6 位 | `CodeNCheckXxx` / `CodeNRefreshXxx` | `pkg/errors/codeN_biz_data.go` | 原子化诊断码，仅内部日志/监控；`BizErrorCode` 使用。**必须新增**，不允许复用。 |

`CheckResult.ErrorCode` 用**老号段**，`CheckResult.BizErrorCode` 用**新号段**，两者同时填。

新号段规划（`codeN_biz_data.go`，当前已分配，CCRRNN 6位分层编码）：

- **CC（2位）业务大类**：
  - `10` → Check 公共系统错误（QuoteContext 缺失、依赖调用失败等）
    - `100001` 上下文缺失（`CodeNCheckQuoteContextMissing`）
    - `100002` 依赖派生计算/RPC 失败（`CodeNCheckDependencyCallFailed`）
  - `11` → 操作准入（AccessRules）：`1101xx` OpAccessQuoteOperationRule
  - `12` → 整单基础信息（QuoteBaseInfo 桶）：`1201xx` ~ `12NNxx`（RR 按文件名字母序从01递增）
  - `13` → 报价项（QuoteItem 桶）：`1301xx` ~ `13NNxx`
  - `14` → 保底（Guarantee 桶）：`1401xx` ~ `14NNxx`
  - `15` → 返佣（Rebate 桶）：`1501xx` ~ `15NNxx`
  - `16` → 代金券（Coupon 桶）：`1601xx` ~ `16NNxx`
  - `17` → 信控（Credit 桶）：`1701xx` ~ `17NNxx`
  - `18` → 资源单（ResourcePage 桶）：`1801xx` ~ `18NNxx`
  - `19` → 整单聚合校验（FullQuote 桶）：`1901xx` ~ `19NNxx`
  - `20`~`29` → Check 预留（后续新增桶/维度在此区间分配）
  - `30`+ → Refresh 维度（Refresher 专用，`CodeNRefresh*`，从 `300001` 起）
- **RR（2位）**：大类内规则编号，每个 Rule/Refresher 文件独占一个 RR，严格按文件名字母序从 01 开始递增
- **NN（2位）**：规则内错误条件序号，01 起递增，每个规则预留 99 个槽位

**新增流程**：

1. 优先查 `pkg/errors/codeN.go` 是否已有可复用的老码（如"通用申请校验失败"`CodeNCommonApplyCheckFailed`、"报价单不可操作"`CodeNQuoteNotSupportToOperate` 等）。
2. 若没合适的老码，**先在** `codeN.go` 追加一个业务导向的 8 位老码（`12000xxx`）。
3. **再在** `codeN_biz_data.go` 对应号段最大值 +1 追加 6 位新码（`1NNNNN`）。
4. Rule 使用示例：`ErrorCode = CodeN<Old>`（老码），`BizErrorCode = CodeNCheck<New>`（新码）。

### 3.5 现有 Rule 桶清单（截至当前分支）

| 桶 (QuoteBizDataType) | 主要 Rule |
|---|---|
| QuoteBaseInfo | QuoteType / QuoteOrderType / QuoteTradeType / QuoteDistributionType / QuoteProjectAttribute / QuoteNotes / QuoteEffectiveSubject / QuoteBPMdInfo / QuoteProjectData / QuoteGiveaway / QuoteChangeInfo / QuoteProgressiveInfo / QuoteProductType / QuoteEstimatedIncome / QuoteMonthlyIncome / QuotePriceValidPeriod / QuoteLongLifeReason / QuoteEstimatedTradingTime / QuoteUnapprovedProductLine / QuoteDistributorInfo / QuotePartnerName / QuoteCustomerName / QuotePartnerContract / QuoteProjectSupply / QuoteBackdating / QuoteAccountRequired / QuoteAccountCount / QuoteAccountEffective / QuoteBPFinalCustomer / QuoteAccountSource / QuoteAccountCustomer / QuoteRelatedAccount / QuoteUserAccount / **QuoteJointPrintOrder** |
| QuoteItem | **ItemCount / ItemDraft / ItemProductSupport / ItemDeliveryMissing** / ItemEffective / ItemProductScope / ItemProductCustomerScope / ItemSellingMode / **ItemCombine** / ItemZeroSupport / ItemZeroRelated / ItemRatioCharge / ItemChargeRelated / ItemDiscountMissing / ItemDiscountProgressive / ItemDiscountZero / ItemSpDiscount / ItemDistributionDiscount / ItemDeliveryCost / ItemEstimatedIncomeRequired / ItemProgressivePriceDuplicate / ItemGuaranteePercentage |
| Guarantee | GuaranteeSupport / GuaranteeItems / GuaranteeValidity / GuaranteeTotalSeats / GuaranteeCarryForward |
| Rebate | RebateItemsSupport |
| Coupon | CouponSupport / CouponParam / CouponValidity |
| Credit | CreditSupport |
| ResourcePage | ResourcePageInfoMissing |
| FullQuote | FullQuoteBusinessDiscountsChange / FullQuoteBusinessDiscountsRelated / FullQuoteEstimatedIncomeConsistency / FullQuoteCouponTrigger / FullQuoteDeductDiscountLevel |
| 准入（挂载在 opType 上） | OpAccessQuoteOperation |

## 4. refresh_engine 现状

### 4.1 接口

`refresh_engine/biz_refresher.go`：

```go
type QuoteBizRefresher interface {
    Key() string
    Desc() string
    Needs() []quote_context.QuoteContextKey
    Mods() []quote_context.QuoteContextKey
    BlockLevel() engine_common.BlockLevel
    Refresh(ctx, tx, quoteCtx, queryOnly) (*engine_common.RefreshResult, error)
}
```

- 与 Rule 相比多两点：
  - `Mods()` 显式声明"本 refresher 成功执行后，哪些 QuoteContextKey 需要重刷"。
  - `Refresh` 允许写库；`queryOnly=true` 时应只查不写且 `Changed=false`。
    **注意**：当前仅有 `ItemProductTaxRuleRefresher` 严格遵守 queryOnly 不写库；其余 refresher
    对 queryOnly 的支持程度不一（部分直接 return pass，部分底层服务自行处理），调用方应仅在
    `QuoteBizDataRefresh` 场景传入 queryOnly，送审主链路不传。
- 成功真正落库后才置 `Changed=true`；执行器据此触发 `WithReloadKeys(Mods()...)`。

### 4.2 命名约定

- 文件：`biz_data_refresher_{实体}_{子域}.go`。
- struct：`<实体><子域>Refresher`；Key 采用驼峰前缀（如 `refreshItemProductInfo`、
  `couponTriggerInfo`）。
- 顶部注释小节：**职责 / 触发条件 / 失败分支 → CodeN / 写副作用 / 数据来源 /
  Mods**。
- CodeN 使用 `CodeNRefresh*` 号段（`pkg/errors/codeN_biz_data.go` CC=30 起，即 `30xxxx`）。

### 4.3 允许的调用面

- 允许调用 `biz/service/*` 已有服务方法（如
  `quote_item_service.CalQuoteItemTotalDiscount`），只要它们最终在 `tx` 上完成写库。
- 允许直接使用 `dal.*Dao.BatchSave / Save / Update`。
- 允许复用 `check_engine` 中已经存在的**纯校验函数**（如
  `check_engine.ValidateFullQuoteTriggerQuoteItemIDList`），用于回填决策。
  **禁止**反向依赖 rule struct。

### 4.4 现有 Refresher 清单

| Refresher | Key | 主要 Mods |
|---|---|---|
| QuoteOppInfoRefresher | `refreshQuoteOppInfo` | Quote |
| RebateNotSupportCleanRefresher | `rebateNotSupportClean` | RebateItemList |
| RebateSupportUpdateRefresher | `rebateSupportUpdate` | QuoteItems / RebateItemList |
| ResourcePageCleanExpiredRefresher | `resourcePageCleanExpired` | ResourcePage / QuoteResourceItems |
| CouponTriggerInfoRefresher | `couponTriggerInfo` | CouponList |
| ItemDiscountHeirRefresher | `refreshItemDiscountHeir` | QuoteItems / DeliveryItems / ItemCalMap |
| ItemProductInfoRefresher | `refreshItemProductInfo` | QuoteItems / DeliveryItems / ItemCalMap / ItemContextMap |
| ItemProductTaxRuleRefresher | `refreshItemProductTaxRule` | QuoteItems / DeliveryItems / ItemCalMap |
| ItemCalFactorDataRefresher | `refreshItemCalFactorData` | ItemContextMap |
| ItemSelectAllExcludeRefresher | `refreshItemSelectAllExclude` | ItemValues |
| QuoteRelatedResDepRefresher | `refreshQuoteRelatedResDep` | Quote |
| ItemInquiryRefresher | `refreshItemInquiry` | QuoteItems / ItemCalMap |
| ItemTotalDiscountRefresher | `refreshItemTotalDiscount` | CouponList / QuoteItemCouponRatioList / ItemCalMap |

## 5. engine_common 现状

### 5.1 常量枚举

- `BlockLevel`：`Error` / `Warn` / `Info`。
- `QuoteBizOpType`：目前 3 个 —— `SubmitQuote` / `BizDataCheck` /
  `BizDataRefresh`。每个 opType 通过 `RegisterOpType().WithStages().WithAccessRules()`
  绑定独立的 stage 执行序列与准入规则。
- `QuoteBizDataType`（校验桶维度）：`QuoteBaseInfo` / `QuoteItem` /
  `Guarantee` / `Rebate` / `Coupon` / `Credit` / `ResourcePage` / `FullQuote`。
  refresher 全局注册、不属于任何桶。
- `StageKind`：`check`（桶校验）/ `refresh`（数据刷新）/ `access`（准入校验）。

### 5.2 结果模型

- `CheckResult` / `RefreshResult`（`engine_common/model.go`）：`engine_stage`
  中 `StageResult` 内嵌其中之一。

### 5.3 公共 helper（`engine_common/func.go`）

- `HasApplyItem` / `HasValidGuarantee` / `HasPublicStandardItem` /
  `HasManualDeliveryItem` / `IsOnlyOnline` / `IsOnlyOffline` /
  `IsOnlyStandardProduct` / `GetAllItems` / `ParseAccountIDs` /
  `GetAccountIDStr`。
- **只放跨多个 Rule/Refresher 复用的稳定纯函数**；一次性辅助逻辑不下沉。

## 6. engine_stage 现状

### 6.1 Registry（统一注册表）

`engine_stage/registry.go`：

- 内部四张表：
  - `ruleBuckets: map[QuoteBizDataType][]QuoteBizRule`（按桶分组，注册顺序即执行顺序）
  - `refresherByKey: map[string]QuoteBizRefresher`（refresher 全局唯一 key 注册，不与桶绑定）
  - `opStages: map[QuoteBizOpType][]StageItem`（每个 opType 的 stage 执行序列）
  - `opAccessRules: map[QuoteBizOpType][]QuoteBizRule`（每个 opType 的准入 rule）
- 构建 DSL（链式调用）：
  - `RegisterBucket(bucket).WithRules(...)`：声明桶并挂载 rule
  - `RegisterRefreshers(...)`：批量注册全局 refresher（以 `Key()` 为唯一 ID）
  - `RegisterOpType(opType).WithStages(...).WithAccessRules(...)`：声明 opType 并绑定
    stage 序列（用 `CheckBucket(bucket)` / `RunRefresher(ref)` 构造 StageItem）和准入 rule
- `KindOf(key)`：根据 key 反查是 Check 桶还是 Refresher。
- `Validate()` + `MustValidateRegistry`：启动期校验空 key / nil / 重复 key /
  opStages 引用未注册 key / refresher key 与桶名冲突 / access rule key 与业务 rule key 重复。
- 通过 `SetDefaultRegistry` / `DefaultRegistry()` 提供全局单例。

### 6.2 OpStages（场景序列事实源）

`engine_stage/registration.go` 中 `init()` 使用链式 DSL 一次性完成全部注册：

- `RegisterBucket(bucket).WithRules(...)`：按 QuoteBizDataType 桶挂载校验 rule
- `RegisterRefreshers(...)`：批量注册全局 refresher
- `RegisterOpType(opType).WithStages(...).WithAccessRules(...)`：为每个 opType 声明 stage 序列
  （使用 `CheckBucket(bucket)` 和 `RunRefresher(ref)` 构造 StageItem，check/refresh 可自由穿插）
  与准入 rule
- `MustValidateRegistry(reg)` + `SetDefaultRegistry(reg)`：校验后置为全局默认

当前各 opType 的 stage 序列：

| OpType | 序列顺序（简化） | FailFast |
|---|---|---|
| SubmitQuote | QuoteOppInfo → RebateNotSupportClean → RebateSupportUpdate → ResourcePageCleanExpired → CouponTriggerInfo → **[Check: QuoteBaseInfo → QuoteItem → Guarantee → Rebate → Coupon → Credit → ResourcePage → FullQuote]** → ItemDiscountHeir → ItemProductInfo → ItemProductTaxRule → ItemCalFactorData → ItemSelectAllExclude → QuoteRelatedResDep → ItemInquiry → ItemTotalDiscount | true |
| BizDataCheck | **[Check: QuoteBaseInfo → QuoteItem → Guarantee → Rebate → Coupon → Credit → ResourcePage → FullQuote]**（无 refresh 阶段） | false（收集全部失败） |
| BizDataRefresh | 无默认 stages（业务侧通过 `OverrideStages` 按 refresherKey 动态构造） | true |

> 准入 rule（`OpAccessQuoteOperationRule`）对三个 opType 均挂载，在 stage 序列之前固定 FailFast 执行。

**Refresher 别名兼容**：业务层 `quote_service_by_engine/biz_data_refresh.go` 维护
`refresherKeyAlias` 映射（如 `"refreshProductTaxRule" → "refreshItemProductTaxRule"`），
外部调用方可继续使用历史 key，入口处自动归一/还原。

### 6.3 Executor

`engine_stage/executor.go`：

- 唯一入口 `Run(ctx, tx, opType, quoteCtx, opts) (*ExecResult, error)`：
  1. 挑选 stages（`opts.OverrideStages` 非 nil 时覆盖，否则取 `opType` 绑定的默认序列）。
  2. 一次性收集所有 stages 的 `Needs()` 加上准入 rule 的 `Needs()` → 去重后
     通过 `NewLoaderByQuoteContext.WithKeys(...).Load` 补齐 QuoteContext。
  3. 先跑准入 rule（**固定 FailFast**），Error 阻断即返回。准入 rule 不支持白名单降级
     （`ResultOpts` 不对准入结果生效）。
  4. 按 stage 序列依次执行：
     - **CheckBucket**：遍历桶内所有 rule，依次执行 Check 并应用 `ResultOpts`
       （如白名单降级）；`opts.FailFast=true` 时任意 Check Error → 短路。
     - **RunRefresher**：执行 refresher；Refresh 步遇 `err` 或
       `Pass=false+BlockLevel=Error` **固定短路**（不受 FailFast 控制）；
       Changed=true 且非 QueryOnly 且 Mods() 非空 → 通过
       `WithReloadKeys(Mods()...)` 增量 reload，后续 stage 读到最新数据。
  5. 已有 Blocking 后，不再执行后续 Refresh 步（避免用过时数据写库）。
- `ExecOptions` 字段：
  - `QueryOnly bool`：传给 refresher，true 时跳过写库且不触发 reload。
  - `FailFast bool`：仅作用于 Check 步；准入和 Refresh 步固定短路。
  - `ResultOpts []CheckResultOption`：Check 结果后处理（如白名单降级），
    **不作用于准入 rule**。
  - `OverrideStages []StageItem`：覆盖默认 stage 序列。
- `CheckResultOption`：Rule 结果后处理器（如 `WithSkipBlockRules` 白名单降级）。

**⚠ `WithSkipBlockRules` 的真实语义**（`executor.go:42-49`）：

```go
if r != nil && !r.Pass && skipRuleMap[r.RuleKey] {
    r.BlockLevel = engine_common.BlockLevelWarn
    r.Pass = true   // ← 注意：同时把 Pass 改为 true
}
```

即命中白名单后：`BlockLevel` 降级为 `Warn` **且** `Pass=true`。
- 优点：不会阻断主链路（`Blocking` 不再命中）。
- 副作用：业务侧遍历 `execResult.Stages` 收集 warning 列表时，若按
  `r.Pass==false` 过滤会**漏掉降级项**。要展示 warning 需按
  `r.BlockLevel==Warn` 判断。

新增白名单降级前，务必和业务侧沟通清楚展示逻辑。

### 6.4 结果模型

- `StageResult{Kind, Check, Refresh}`：互斥承载具体结果。
- `ExecResult{QuoteCtx, Stages, Blocking}`：`Blocking` 为首个 Error 阻断结果。

## 7. 与业务层（`biz/service/quote_service_by_engine/`）的联动约束

- 三个业务入口已通过 `quote_service_by_engine` 走 `engine_stage.Run`：
  - **SubmitQuote**（`submit_quote.go`）：分布式锁 + 事务 + 完整 pipeline
    （FailFast=true，前置刷新 → Check 桶 → 后置刷新），送审主链路。
  - **BizDataCheck**（`biz_data_check.go`）：只读校验入口
    （FailFast=false，无 refresh 阶段，收集全部失败项返回）。
  - **QuoteBizDataRefresh**（`biz_data_refresh.go`）：按外部 refresherKey
    动态触发刷新（FailFast=true，OverrideStages 指定 refresher，QueryOnly 由调用方传入），
    事务包裹，支持 refresherKey 别名兼容。
- 新项目制报价流程已固定启用；`service_basic` 只暴露纯粹的 "opType → 执行序列" 语义。
- 业务层调用规约：
  1. 先用 `quote_context.NewQuoteContextLoader(quoteID, tx).Load(ctx)`
     拿到最小可用的 `QuoteContext`（默认带 Quote 基础数据）。
  2. 再交给 `engine_stage.Run(ctx, tx, opType, quoteCtx, opts)`；
     Run 内部会自动汇总 Needs() 补齐依赖、执行 access + stages、处理 reload。
  3. 业务侧读取 `result.BlockingErr()` 决定是否阻断、用
     `result.SummarizeCheckResults()` 或 `result.RefreshResults()` 汇总结果。

## 8. 现状回填提示（供 AI 使用）

代码合入后需要更新的小节（详见 `06_self_update_guide.md`）：

- 新增 loader → 更新 §2.4 "现有 Loader 清单"。
- 新增 Rule → 更新 §3.5 "现有 Rule 桶清单"。
- 新增 Refresher → 更新 §4.4 "现有 Refresher 清单"。
- 新增 opType / QuoteBizDataType → 同步更新 §5.1、§6.2 表。
- 新增 CodeN 号段 → 更新 §3.4。

## 9. 常见执行分支与失败路径速查

### 9.1 Executor 短路点（阅读 `engine_stage/executor.go` 得出）

| 触发点 | 短路行为 | 返回值/影响 |
|---|---|---|
| `Run` 入参 `quoteCtx==nil` | 立即返回 `errors.NewBizErrWithMsg(CodeNCheckQuoteContextMissing, "[engine_stage] quote context is nil")` | `ExecResult=nil` |
| `DefaultRegistry() == nil`（未 init） | 返回 `errors.NewBizErrWithMsg(CodeNGetBizCheckerFailed, "[engine_stage] registry not initialized")` | `ExecResult=nil` |
| `stages` 与 `accessRules` 均为空 | 返回 `&ExecResult{QuoteCtx: quoteCtx}` | 无任何执行 |
| 准入 rule Error → `blocking=true` | 立即 `return`，`ExecResult.Blocking` 命中首个准入失败 | 不再执行 stage |
| Rule `Check` 返回 `nil` | 由 `fillCheckResult` 兜底为 Error 结果，`ErrorCode=CodeNGetBizCheckerFailed` | 记录到 Stages |
| Refresher 返回 `nil` | 由 `fillRefreshResult` 兜底为 Error 结果，`ErrorCode=CodeNGetBizRefresherFailed` | 记录到 Stages，**不** reload |
| Refresh `Changed=true && !QueryOnly && Pass && Mods()非空` | 通过 `WithReloadKeys(Mods()...)` reload | 后续 stage 读到最新 QuoteContext |
| Check Error + `opts.FailFast=true` | `runCheckStage` 短路返回 | 后续 stage 不再执行；`Blocking` 已被记录 |
| Refresh 返回 err 或 Pass=false+Error | **固定短路**（不受 FailFast 控制） | 后续 stage 不再执行；避免下游 Rule 读过时数据 |
| 已有 Blocking 后遇到 Refresh stage | 跳过该 Refresh（日志 Warn），break | 避免用过时数据写库 |
| Rule `Needs()` 声明的 key 未注册 loader | 上游 `Load` 报 `[QuoteContextLoader] doLoad key fail` | Run 直接返回该 error |
| 循环依赖（loader dependKeys 成环） | `doLoad` 报 `[QuoteContextLoader] doLoad circular dependency` | Run 直接返回该 error |

### 9.2 常见错误码使用位置

| 错误码 | 出现文件 | 用途 |
|---|---|---|
| `CodeNCheckQuoteContextMissing`(100001) | 所有 Rule 入口保护 | 上下文缺失时 `return nil, err` |
| `CodeNCheckDependencyCallFailed`(100002) | Rule 内部派生查询失败 | 上下文可信但派生调用抖动 |
| `CodeNRefreshCtxMissing`(300001) | 所有 Refresher 入口保护 | 上下文缺失时 `return nil, err` |
| `CodeNGetBizCheckerFailed` | executor.go 与业务入口 | Run 前置校验、注册未初始化 |
| `CodeNGetBizRefresherFailed` | executor.go `fillRefreshResult` 兜底 | Refresher 返回 nil 时 |

### 9.3 号段速览

- `100001`~`100099`：CC=10，Check 公共/通用系统错误
- `110101`~`119999`：CC=11，操作准入（Access Rules）
- `120101`~`129999`：CC=12，整单基础信息（QuoteBaseInfo 桶）
- `130101`~`139999`：CC=13，报价项（QuoteItem 桶）
- `140101`~`149999`：CC=14，保底（Guarantee 桶）
- `150101`~`159999`：CC=15，返佣/联合打单（Rebate 桶）
- `160101`~`169999`：CC=16，代金券（Coupon 桶）
- `170101`~`179999`：CC=17，信控（Credit 桶）
- `180101`~`189999`：CC=18，资源单（ResourcePage 桶）
- `190101`~`199999`：CC=19，整单聚合校验（FullQuote 桶）
- `300001`+：CC=30+，refresh_engine 专用（公共错误从 `300001` 起，具体 Refresher 按 RR 分配）

> 追加新号段前，先 `grep 'ErrorCodeN = <CC 前缀>' pkg/errors/codeN_biz_data.go` 找到当前 RR/NN 最大值。

## 10. 常见业务入口（`biz/service/quote_service_by_engine/`）

| 入口函数 | 文件:line | 主要动作 |
|---|---|---|
| `SubmitQuote` | `submit_quote.go:53` | 分布式锁 + 事务；`NewQuoteContextLoader(quoteID, tx).Load(ctx)` 后调 `Run(SubmitQuote, FailFast=true)`；完整 pipeline：准入 → 前置刷新 → Check 全部桶 → 后置刷新 |
| `BizDataCheck` | `biz_data_check.go:39` | `NewQuoteContextLoader(quoteID, tx).Load(ctx)` 后调 `Run(BizDataCheck, FailFast=false)`；仅跑准入 + Check 桶（无 refresh 阶段），用 `SummarizeCheckResults()` 收集全部失败 |
| `QuoteBizDataRefresh` | `biz_data_refresh.go:78` | 事务；`NewQuoteContextLoader(quoteID, tx).Load(ctx)` 后调 `Run(BizDataRefresh, FailFast=true, OverrideStages=fromKeys, QueryOnly=fromReq)`；按外部 refresherKey 列表动态构造 stage 序列；支持 key 别名归一/还原 |

**业务层典型三段式**（以 SubmitQuote 为例）：

```go
// 1) 分布式锁 + 事务（业务层负责）
lock := redis_client.RedisLock{LockKey: "submit_quote_lock_" + quoteID, ...}
lock.Lock(); defer lock.Unlock()
err := dal.DBProxy.NewRequest(ctx).Transaction(func(tx *gorm.DB) error {
    // 2) 加载最小 QuoteContext
    qc, err := quote_context.NewQuoteContextLoader(quoteID, tx).Load(ctx)
    if err != nil { return err }

    // 3) 交给 engine_stage.Run（自动补齐 Needs、执行 access + stages、处理 reload）
    execResult, err := engine_stage.Run(ctx, tx, engine_common.QuoteBizOpTypeSubmitQuote, qc, engine_stage.ExecOptions{
        FailFast:   true,
        ResultOpts: []engine_stage.CheckResultOption{engine_stage.WithSkipBlockRules(skipRuleMap)},
    })
    if err != nil { return err }
    if err := execResult.BlockingErr(); err != nil { return err }

    // 4) 后续审批流程...
})
```

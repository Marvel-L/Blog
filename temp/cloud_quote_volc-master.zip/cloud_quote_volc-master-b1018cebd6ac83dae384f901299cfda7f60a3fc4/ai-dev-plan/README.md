# ai-dev-plan · 报价引擎标准化 AI 开发手册

本文件夹是 `cloud_quote_volc` 报价引擎（`biz/service_basic/`）的**唯一权威落地手册**，服务于基于「QuoteContext + check_engine/refresh_engine + engine_stage 分层编排」架构下的所有新增/修改需求。

- **架构背景**：Lark Wiki「报价系统 QuoteContext + 校验引擎化技术方案」（`Hgd8wUb1miPVDgkTBigcB1ifnec`）
- **目标读者**：RD 开发者 + AI 编码助手（Claude/Coco/Trae 等）
- **核心承诺**：按手册走 → 代码符合架构规范、启动不 panic、单测通过、灰度可回滚、文档自动同步

---

## 🚀 快速开始（30 秒上手）

拿到一句话需求后，**不要直接让 AI 写代码**，按以下步骤：

```
1. 复制 05_prompt_templates.md §0 的「通用 System 前缀」发给 AI
2. 从 §1~§4 / §9 选匹配场景的提示词模板，填好占位符
3. AI 产出代码后，把 04_change_checklist.md 喂给 AI 让它逐项自检
4. AI 自检通过后，跑 04_change_checklist.md §I 的本地命令
5. 代码合入前，用 §6「自更新手册提示词」让 AI 回填文档清单
```

---

## 📚 目录与使用时机

| 文件 | 核心内容 | 使用阶段 | 维护方 |
|---|---|---|---|
| **01_current_state.md** | 分层总览、所有已注册 Loader/Rule/Refresher/OpType/桶清单、执行时序、错误码号段 | 需求调研 → AI 上下文 | AI 增量维护清单，人工维护架构描述 |
| **02_conventions.md** | 命名规范、注释模板、代码骨架（Loader/Rule/Refresher）、归属判定原则、tx 传递规则 | AI 生成代码 → CR 对齐 | 人工维护 |
| **03_decision_playbook.md** | §0 决策树、四层改动分支表、15+ 常见需求落点速查、反模式清单 | 需求落点判断 → 是否新增文件决策 | AI 仅可追加 §5 速查表，其余人工维护 |
| **04_change_checklist.md** | 10 节自检清单（A~L）：通用/分层/业务联动/文档/灰度/命令速查/排查脚本/常见问题 | PR 提交前 → CR 审查 | 人工维护 |
| **05_prompt_templates.md** | 复制即用的提示词库：通用前缀/4 类核心改动/一句话方案/自更新/自检/Meta/5 类场景专用 | 每次让 AI 写代码时 | 人工维护 |
| **06_self_update_guide.md** | 自更新触发条件、允许改动区、diff 输出契约、失败案例、自动化校验脚本 | 代码合入后文档回填 | 人工维护 |
| **README.md** | 本文档 - 操作手册总入口 | 新人上手/查阅流程 | 人工维护 |

---

## 🔄 标准开发全流程（六步法）

### Step 1：定位现状（01_current_state.md）

打开 `01_current_state.md`，确认：
- 需求涉及的实体/字段是否**已经存在**（看 §2.4 Loader 清单 / §3.5 Rule 桶表 / §4.4 Refresher 表）
- 如果是校验类需求，是否已有同类 Rule 在对应桶里
- 如果是刷新类需求，是否已有 Refresher 覆盖
- 涉及哪个 OpType（SubmitQuote / BizDataCheck / BizDataRefresh / 其它），当前 Stage 序列是什么（§6.2）

### Step 2：决策落点（03_decision_playbook.md）

走 §0 的决策树：

```
新需求
 ├─ Q0：属于 service_basic 领域吗？→ 否 → 放 biz/service/*，本手册不覆盖
 ├─ Q1：需要新取数点？→ 是 → §1 quote_context（Loader / InputOption）
 ├─ Q2：新增/修改校验语义？→ 是 → §2 check_engine（Rule / 桶 / 准入 Rule）
 ├─ Q3：需要写库/回填/联动更新？→ 是 → §3 refresh_engine（Refresher）
 ├─ Q4：新增/调整场景编排？→ 是 → §4 engine_stage（OpType / Stage 顺序 / 准入）
 └─ Q5：入口层胶水（事务/锁/灰度/参数转换）？→ 是 → biz/service/quote_service_by_engine/
```

**关键判断**：改原文件 vs 新增文件？看对应层的决策分支表（§1.1 / §2.1 / §3.1 / §4.1）。

**经验法则**：
- 同一"用户可修复动作"的多个分支 → 改原 Rule 文件
- 不同修复动作 / 不同业务子域 / 需要独立 skip → 新增 Rule 文件
- 新业务实体 → 新增 QuoteBizDataType 桶

拿不准时查 §5「一句话需求落点速查表」，里面有 15+ 真实案例。

### Step 3：让 AI 生成代码（05_prompt_templates.md）

1. **先发 System 前缀**（§0，每次必发）：明确必读文档顺序 + 6 条强制约束
2. **选对应模板**：
   - 新增查询逻辑（Loader）→ §1
   - 新增业务校验（Rule）→ §2
   - 新增刷新逻辑（Refresher）→ §3
   - 新增场景（OpType）→ §4
   - 一句话需求不知道怎么拆 → §5（先让 AI 当架构师出方案，确认后再开发）
   - 其它常见场景 → §9（新增 InputOption / 修改 Stage 顺序 / 白名单降级 / Callback 迁移 / 新增单测）
3. **填好占位符**：把 `<需求描述>` / `<桶名>` / `<实体>` 等替换成真实信息
4. **让 AI 先出方案再写代码**：复杂需求建议先用 §5 模板让 AI 分层列计划，确认后再逐模板生成

### Step 4：代码规范检查（02_conventions.md）

AI 产出代码后，对照检查：

| 检查项 | 要点 |
|---|---|
| 文件粒度 | 一个概念一个文件，不允许多个 struct 塞同一文件 |
| 注释规范 | 结构体上方中文注释块，固定小节（Rule: 职责/触发条件/失败分支→CodeN/数据来源；Refresher 加写副作用/Mods） |
| 命名 | 文件 `biz_data_rule_<实体>_<子域>.go` / struct `<Entity><Domain>Rule` / Key `BizDataRule<Entity><Domain>` |
| 错误处理 | 不用裸 `fmt.Errorf`，用 `errors.NewBizErrWithMsg` / `ErrCustomerError.WithArgs` |
| 用户文案 | 全部用 `i18nfmt.Sprintf(ctx, ...)` |
| 日志前缀 | 关键错误加 `[<StructName>]` 前缀 |
| Loader | `param.QuoteID == 0` 必须 fail-fast；不写库、不调其它 loader；依赖走 `dependKeys()` |
| Rule | **纯只读**，无 Save/Update/Delete/RPC 写；Needs 精确声明；BlockLevel 按语义选择；上下文缺失走 error 而非 CheckResult |
| Refresher | Needs 覆盖所有读、Mods 覆盖所有写+派生失效；`queryOnly=true` 必须短路写库；真实落库成功才置 `Changed=true` |
| 归属判定 | 读 DB → Persisted；调外部 RPC → External；请求入参 → Inputs |

### Step 5：PR 前自检（04_change_checklist.md）

1. 先让 AI 对照 §7「自检提示词」逐项勾选输出
2. 本地跑 §I 命令速查：
   ```bash
   gofmt -l ./biz/service_basic
   go vet ./biz/service_basic/...
   go test ./biz/service_basic/...
   go test -cover ./biz/service_basic/check_engine/...
   go test -cover ./biz/service_basic/refresh_engine/...
   go test -cover ./biz/service_basic/engine_stage/...
   go build ./...
   ```
3. 跑 §J 一次性排查脚本（检查注册/只读/queryOnly/i18n/CodeN 唯一/Needs 登记）
4. 对照 §A~H 自检清单：
   - A 通用（所有改动必过）
   - B quote_context 新增字段
   - C check_engine Rule
   - D refresh_engine Refresher
   - E engine_stage/opType
   - F 业务层联动（事务/锁/灰度在业务层，不进 service_basic）
   - G **文档回填必须做**（见 Step 6）
   - H 灰度回滚（线上行为变更必看）
5. 回答 §L 的 9 个必答问题

#### 常见问题速查（§K 表）

| 症状 | 排查点 |
|---|---|
| 启动 panic: `opType [X] refers unregistered key [Y]` | `WithStages` 里的 Y 未注册；用 `CheckBucket()`/`RunRefresher()` 构造避免拼写错 |
| 启动 panic: `rule key [X] duplicated` | 同一 Rule 被注册到两个桶；Rule.Key() 全局唯一 |
| Rule 命中却没执行 | 忘在 `registration.go` `WithRules(...)` 加入；跑 §J 脚本 1 |
| Refresher 写了但 QuoteContext 没生效 | Mods() 漏 key；或 queryOnly=true 时误置 Changed=true |
| BizDataCheck 报 "quote context is nil" | 业务入口忘了 `Load(ctx)` |
| 白名单降级不生效 | `WithSkipBlockRules` 传入的 key 与 Rule.Key() 大小写不匹配 |
| Refresher 报错后下游仍执行 | 确认 Refresher 正确返回 err（不是吞掉错误返回 Pass=true） |

### Step 6：文档自更新（06_self_update_guide.md）

**代码合入前必须执行**，避免信息漂移：

1. 判断是否触发回填：看 06 §1 触发条件表（新增/删除/重命名 Loader/Rule/Refresher/OpType/桶/CodeN/入口对接 → 必须回填）
2. 复制 05_prompt_templates.md §6「自更新手册提示词」
3. 在【已完成的变更】处列出新增/修改的文件、struct、Key、CodeN、桶归属
4. AI 必须只改允许区：
   - `01_current_state.md`：§2.4 / §3.4 / §3.5 / §4.4 / §5.1 / §6.2 / §7（清单/表格行）
   - `03_decision_playbook.md`：仅 §5 速查表（通用需求追加行）
   - **禁止改动**：02/04/05/06/README，以及 01 的 §1 分层总览/依赖方向、03 的 §0 决策树/§6 反模式
5. 检查 AI 输出是否符合 §8 diff 契约（before/after 块，标注文件+小节，不贴整个文件）
6. 跑 §11 自动化校验脚本检查注册对齐
7. 代码 diff + 手册 diff **同一个 PR** 提交

---

## 🎯 典型场景操作指南

### 场景 1：新增一条校验规则（最常见）

示例：「报价单必须有联系人」

1. 查 01 §3.5，确认 `QuoteBaseInfo` 桶已有哪些 Rule，是否已有同类校验
2. 决策：新增文件（新用户修复动作）→ `biz_data_rule_quote_contact.go`
3. 用 05 §2 模板发给 AI，指定桶 = `QuoteBaseInfo`
4. AI 产出后检查：
   - struct = `QuoteContactRule`，Key = `BizDataRuleQuoteContact`
   - Needs 只读真正用到的 key（Quote）
   - 无写库调用
   - CodeNCheckQuoteContact 在 01 §3.4 号段最大值 +1
   - `registration.go` `RegisterBucket(QuoteBizDataTypeQuoteBaseInfo).WithRules(...)` 已追加
5. 单测覆盖：pass / 联系人缺失分支 / 上下文缺失
6. 回填：01 §3.5 的 QuoteBaseInfo 行追加 `QuoteContact`

### 场景 2：新增一个 Refresher（写副作用）

示例：「送审前刷新伙伴授权」

1. 查 01 §4.4，确认是否已有 Refresher 覆盖该逻辑
2. 查 01 §6.2，确认目标 OpType（SubmitQuote）当前 Stage 序列，决定插入位置
3. 用 05 §3 模板发给 AI
4. AI 产出后检查：
   - Mods() 覆盖所有写入 + 派生失效 key
   - `queryOnly=true` 分支不写库，Changed=false
   - 真实落库成功才置 Changed=true
   - 已在 `RegisterRefreshers(...)` 全局注册
   - 已在 `RegisterOpType(SubmitQuote).WithStages(...)` 中通过 `RunRefresher(...)` 插入正确位置
5. 回填：01 §4.4 追加行；01 §6.2 更新 SubmitQuote 序列

### 场景 3：白名单降级（不改 Rule）

示例：「某规则对试运行租户只警告不阻断」

**不要修改 Rule 代码**：
1. 在业务层（`biz/service/quote_service_by_engine/`）构造 skipRuleMap
2. key 用 Rule.Key() 精确匹配
3. 调 `engine_stage.Run` 时传 `WithSkipBlockRules(skipRuleMap)` 到 `ExecOptions.ResultOpts`
4. TCC 开关取值在业务层判断，构造 skipRuleMap
5. 单测：断言开关命中时该 Rule 结果为 Warn 且不阻断
6. 无需改 registration.go / 01_current_state.md

### 场景 4：存量 Callback 迁移到 QuoteContext

示例：「某段老代码用 assistant.Callback* 获取字段 X」

1. 在 quote_context/ 判断字段 X 是否已有 loader
   - 已有：直接改老代码，从 CallbackInfo 换成 QuoteContext
   - 无：按 §1 模板新增 Loader
2. 优先彻底替换，最终清除 `assistant.CallbackWithQuote` 调用
3. 如无法一次替换完，临时用 `quote_context.ConvertToCallbackInfo(qc)` 兼容，标注退场计划

### 场景 5：新增 InputOption（接口入参注入）

示例：「接口参数字段 X 需要作为 Rule 校验依据」

1. `QuoteContextInputs` 追加字段 X（不走 loader）
2. 新增 `WithInputX(x ...)` InputOption，遵守"字段为空才赋值"
3. Rule 内读 `quoteCtx.Inputs.X`，Needs 无需变化
4. 业务层 loader 调用时用 `WithInputOpts(quote_context.WithInputX(...))`
5. 用 05 §9.1 模板

### 场景 6：调整 Stage 执行顺序

示例：「把商品信息刷新前置到报价项校验之前」

1. 只改 `engine_stage/registration.go` 对应 `RegisterOpType(opType).WithStages(...)` 链
2. 给 AI 前后对比表（所有 StageItem.Key 序列）
3. 说明调整原因（业务依赖顺序 / 性能）
4. 确认对下游 Rule Needs 的影响（Refresh 前置后，某 Rule 依赖的 key 是否可能被改写）
5. 用 05 §9.2 模板
6. 回填：01 §6.2 更新序列

---

## ⚠️ 红线与反模式（一票否决）

以下行为**绝对禁止**，CR 直接打回：

1. ❌ Rule 内 `dal.*.Save/Update/Delete` 或直接调下游写 RPC
2. ❌ Refresher 忽略 `queryOnly` 直接写库
3. ❌ Loader 里带业务判断（按 QuoteType 决定不查某表），业务判断留给 Rule
4. ❌ 直接在业务包里读 `quote_context.loaderMap` 或调用未导出 loader
5. ❌ 新增 Rule/Refresher 但忘在 `registration.go` 注册（启动会 panic）
6. ❌ Needs() 声明大而全，导致主链路一次性加载所有 key
7. ❌ 所有 BlockLevel 都设 Error，或都设 Warn（应按用户是否可修复决定）
8. ❌ 在 Rule 内读 TCC 开关做"是否执行本 Rule"的灰度（灰度应在业务层用 `WithSkipBlockRules`）
9. ❌ 把事务/分布式锁加到 service_basic 内（事务/锁只在业务入口层）
10. ❌ 复制 Callback 老逻辑到新 Rule
11. ❌ Refresher 实例化 Rule 对象复用判断逻辑（应抽纯函数共用）
12. ❌ AI 自更新时改动 02/04/05/06/README.md 或 01 §1 / 03 §0 等禁改区

---

## 🔧 引擎核心架构速览

```
┌─────────────────────────────────────────────────────────────┐
│  业务入口 (biz/service/quote_service_by_engine/)              │
│  职责：事务 / 分布式锁 / 灰度开关 / DTO 转换 / skipRuleMap    │
│  调用：engine_stage.Run(ctx, tx, quoteCtx, opType, opts)     │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│  engine_stage（统一注册 + 唯一执行入口）                       │
│  - 链式 DSL 注册：RegisterBucket / RegisterRefreshers /      │
│    RegisterOpType(...).WithAccessRules().WithStages()        │
│  - 启动时 MustValidateRegistry 校验合法性                     │
│  - 执行：准入Rule(FailFast) → Stage序列(Refresher/CheckBucket)│
│  - FailFast：ExecOptions.FailFast 控制Check步；Refresh错误短路│
└─────────┬───────────────────────────────┬───────────────────┘
          │                               │
┌─────────▼─────────┐           ┌─────────▼─────────┐
│  check_engine     │           │  refresh_engine   │
│  (只读校验，无副作用)│           │  (写副作用/联动更新) │
│  - Rule.Key()     │           │  - Refresher.Key()│
│  - Needs/BlockLevel│           │  - Needs/Mods     │
│  - Check()        │           │  - Refresh()      │
└─────────┬─────────┘           └─────────┬─────────┘
          │                               │
          └───────────────┬───────────────┘
                          │
                ┌─────────▼─────────┐
                │  engine_common    │
                │  (底层契约，零依赖) │
                │  - OpType / 桶枚举 │
                │  - CheckResult等   │
                └─────────┬─────────┘
                          │
                ┌─────────▼─────────┐
                │  quote_context    │
                │  (统一上下文 + Loader)│
                │  - Persisted/     │
                │    External/Inputs│
                │  - dependKeys拓扑 │
                │    加载           │
                └───────────────────┘
```

**依赖方向（严格单向，不得反向）**：
```
engine_common（零依赖）
    ↑
quote_context（仅依赖 engine_common）
    ↑
check_engine / refresh_engine（依赖 engine_common + quote_context）
    ↑
engine_stage（依赖上面四层）
    ↑
业务入口（biz/service/quote_service_by_engine/）
```

---

## 📝 与其他文档的关系

| 位置 | 用途 | 是否作为落地依据 |
|---|---|---|
| `ai-dev-plan/`（本目录） | **当前唯一权威落地开发手册**：日常新增/修改需求的操作手册、代码规范、自检清单、提示词库 | ✅ 所有新增需求以此为准 |
| `ai-docs/check_engine_rule_atomization_plan.md` | check_engine 规则拆分原则、CCRRNN 错误码规范、master 旧规则迁移映射 | 📖 规则拆分与错误码分配参考 |
| `ai-docs/engine_orchestrator_integration_plan.md` | engine_stage 统一编排最终架构：分层结构、Registry DSL、执行流程、三个 OpType 序列 | 📖 引擎架构参考 |
| `ai-docs/refresh_engine_upgrade_plan.md` | refresh_engine Refresher 接口定义、全量 Refresher 清单、Needs/Mods 语义 | 📖 Refresher 设计参考 |
| Lark Wiki 技术方案 | 架构升级方向顶层设计 | 📖 方向参考，代码落地以本手册为准 |

> 三个 ai-docs 文档均已更新为当前代码终态，剔除了所有中间过渡方案，可作为架构背景参考。所有增量开发规范与清单只在 `ai-dev-plan/` 维护，AI 只能增量维护清单表格，不得随意新增 md 文件。

---

## ❓ 常见疑问（FAQ）

**Q: 我需要一个新的查询字段，是加 Loader 还是 InputOption？**
A: 数据来自 DB/外部 RPC → Loader；数据来自接口请求入参、用于覆盖默认查询 → InputOption。见 02 §2.3 归属判定表。

**Q: 一个需求同时涉及 Loader + Rule + Refresher 怎么办？**
A: 按顺序做：先 Loader（数据能取到）→ 再 Rule/Refresher（逻辑能写）→ 再注册编排（能跑起来）。**每一步都可以独立提 PR**，不需要一次性改完。

**Q: 什么时候用 OverrideStages，什么时候改注册？**
A: 默认场景 → 改 registration.go 注册；按外部事件触发单个 Refresher、或需要动态构造序列 → 业务层用 `opts.OverrideStages`。

**Q: queryOnly 到底做什么？哪些 Refresher 支持？**
A: `queryOnly=true` 表示预览/校验模式，**禁止任何写库**、`Changed=false`、不触发 Mods reload。所有 Refresher 必须正确实现 queryOnly 分支（写库操作放在 `if !queryOnly` 块内）。queryOnly 入口仅在 `QuoteBizDataRefresh` 场景使用，送审主链路（SubmitQuote）不传入；预览场景（BizDataCheck）不包含 Refresh 阶段。

**Q: Mods 里的 key 首步 Load 会加载吗？**
A: 不会。Mods 仅在 Refresher 执行且 `Changed=true` 后通过 `WithReloadKeys` 增量 reload，不进首步 Needs 聚合。跨 Refresher 依赖需按顺序 + 在下游 Refresher 的 Needs 声明上游 Mods key。

**Q: AI 自更新改了不该改的地方怎么办？**
A: 直接 Revert 对应段落，重新发提示词时**显式列出允许改动的文件+小节**（如：只允许改 `01_current_state.md §3.5` 的 QuoteBaseInfo 行），并在提示词里强调禁改区。

**Q: 如何快速验证注册没漏？**
A: 跑 04_change_checklist.md §J 的脚本：
```bash
# 检查 Rule 注册
rg -n "type\s+[A-Z][A-Za-z0-9]+Rule\s+struct" biz/service_basic/check_engine/ | ...
# 检查 Refresher 注册
rg -n "type\s+[A-Z][A-Za-z0-9]+Refresher\s+struct" biz/service_basic/refresh_engine/ | ...
# 或直接跑单测（MustValidateRegistry 会 panic）
go test ./biz/service_basic/engine_stage/...
```

**Q: CodeN 号段怎么分的？**
A: 见 01_current_state.md §3.4：
- 老错误码：8位，沿用 codeN.go 兼容前端（ErrorCode）
- 新错误码：6位 CCRRNN 分层编码（CC=业务大类/RR=文件序号/NN=错误序号）
  - Check 类：CC=10~19（公共10/准入11/QuoteBaseInfo12/QuoteItem13/Guarantee14/Rebate15/Coupon16/Credit17/ResourcePage18/FullQuote19）
  - Refresh 类：CC=30 起，CodeNRefresh*
- 新增号段一律在对应 CC 大类的当前 RR/NN 最大值+1 追加，不复用旧值

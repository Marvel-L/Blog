# Repository Guidelines

本文档旨在为 AI 编码代理及新加入的开发者提供 `volc_contract_process` 仓库的全面指引，以快速理解项目概览、技术栈、目录结构、开发流程及关键配置，确保高效、规范地进行开发协作。

## 1. 项目概览

- **项目名称**: 火山引擎报价合同系统
- **主要功能**:
  - 提供火山引擎业务中合同的生成、审批、管理、签署和归档等全生命周期管理能力。
  - 支持报价合同、信控合同、代理合同等多种类型的合同业务。
  - 通过内部 API (`/inner-api`, `/inner-top-contract`) 和开放 API (`/open-api`) 对外提供服务。
- **仓库地址**: `code.byted.org/eps-platform/volc_contract_process`
- **技术栈**:
  - **Go 版本**: `go 1.20`
  - **HTTP 框架**: `code.byted.org/middleware/hertz`
  - **RPC 框架**: `code.byted.org/kite/kitex`
  - **ORM**: `code.byted.org/gorm/bytedgorm` 
  - **数据库**: MySQL
  - **缓存**: `code.byted.org/kv/goredis`
  - **消息队列**: `code.byted.org/rocketmq/rocketmq-go-proxy` 及内部事件总线 (`biz/service/eventbus`)
  - **配置中心**: 内部 TCC
  - **主要内部依赖**:
    - `code.byted.org/eps-platform/vcp_gopkg`: 合同中心公共库
    - `code.byted.org/go-lark/lark`: 飞书 SDK
    - `code.byted.org/gopkg/logs`: 日志库
  - **主要第三方依赖**:
    - `github.com/robfig/cron/v3`: 定时任务

## 2. 目录结构

项目采用清晰的模块化分层结构，核心业务逻辑位于 `biz` 目录，公共能力沉淀在 `pkg` 目录。

```
.
├── AGENTS_TREE.txt
├── biz
│   ├── bizmodels
│   ├── dal
│   ├── handler
│   └── service
├── build.sh
├── .codebase
│   ├── apps.yaml
│   └── pipelines
│       └── ci.yaml
├── conf
├── cronjob
├── docs
├── .gitignore
├── go.mod
├── go.sum
├── .hertztool
├── main.go
├── middlewares
├── pkg
│   ├── argosnotifylogs
│   ├── bizurl
│   ├── conf
│   ├── const
│   ├── dailydeferremind
│   ├── env
│   ├── errors
│   ├── holidaycalc
│   ├── httpclient
│   ├── idgenerator
│   ├── masterelection
│   ├── mdparty
│   ├── preload
│   ├── proxy
│   ├── recovery
│   └── util
├── qodana.yaml
├── README.md
├── report.xml
├── router_gen.go
├── router.go
├── router_test.go
├── script
│   ├── bootstrap.sh
│   ├── devutil
│   ├── doc
│   ├── httprequests
│   ├── settings.py
│   ├── sql
│   └── top_config
└── templates
```

如需完整目录树，请本地运行 `tree -a -I ".git"` 查看。

### 关键文件与模块说明

- 业务合同（含产品报价合同、伙伴合同等）
  - 操作入口：`biz/handler/open_vcc_meta_biz.go`
  - 核心业务逻辑：`biz/service/workflow`（工作流引擎负责状态流转与步骤执行）
- 在线协同合同
  - 操作入口：`biz/service/salescontract/create_or_update.go`、`biz/service/salescontract/operate_contract.go`
  - 核心业务逻辑（审批流）：`biz/service/auditx`
- 销售合同
  - 核心业务逻辑：`biz/service/salescontract/api.go`

- **`main.go`**: 项目入口文件。负责初始化服务（`Init()`）、注册路由（`register()`）和启动 Hertz HTTP 服务。通过命令行参数 `-mode` (http/cron) 和 `-task` 区分不同的启动模式。
- **`router.go`**: 核心路由定义文件。使用 Hertz 框架注册所有 HTTP 路由，并为不同的路由组配置中间件。
  - **接口分组**: 主要分为 `/vcp` (旧版合同中心) 和 `/vcc` (新版火山合同中心) 两大组。每个组下又细分为 `/inner-api` (内部服务间调用), `/open-api` (对客或对其他BU开放), `/inner-top-contract` (对内顶层服务) 等，并应用不同的认证中间件（如 `InnerAuth`, `OpenAuth`, `AuthForInnerTOP`）。
- **`biz/`**: 核心业务逻辑目录。
  - **`handler/`**: HTTP 请求处理器，每个 handler 对应 `router.go` 中的一个或一组路由。文件名通常与路由路径相关，如 `inner_contract.go`。
  - **`service/`**: 业务逻辑服务层，被 `handler` 调用。封装了复杂的业务流程，如合同元数据处理 (`contractmeta`)、审批流 (`auditx`)、工作流 (`workflow`)、通知 (`notify`) 等。
  - **`dal/`**: 数据访问层 (Data Access Layer)，封装了对数据库的所有操作。使用 GORM 作为 ORM 框架，`model/` 子目录定义了数据库表映射的结构体。
  - **`bizmodels/`**: 定义了业务中使用的各种数据结构 (DTOs)，用于 handler 的请求/响应、service 间的参数传递。
- **`pkg/`**: 项目内的公共库。
  - **`conf/`**: 配置加载与管理。`init.go` 初始化配置加载器（默认从 TCC 加载），`configs.go` 定义了所有配置项的结构体 `GlobalConf`，对应 TCC 中的配置。
  - **`proxy/`**: 外部服务客户端代理。封装了对下游服务（如飞书、OA、IAM、TOS 对象存储等）的 RPC/HTTP 调用，是服务解耦和外部依赖管理的核心。
  - **`const/`**: 项目中使用的所有常量定义，如合同状态、业务类型、错误码等。
- **`middlewares/`**: Hertz 中间件。定义了请求处理流程中的通用逻辑，如认证 (`innerauth.go`, `openauth.go`)、日志 (`request_log.go`)、异常恢复 (`recovery.go`) 等。
- **`cronjob/`**: 定时任务实现。包含合同到期提醒、数据同步等后台任务。由 `main.go` 在 `cron` 模式下启动。

## 3. 开发与运行指引
### 组件开发与调试流程

1. **定义接口与模型**: 在 `biz/bizmodels/` 中定义新的请求/响应结构体。
2. **创建 Handler**: 在 `biz/handler/` 目录下创建新的 handler 文件，实现具体的 `vhertz.HandleAction` 接口。
3. **实现 Service**: 在 `biz/service/` 中创建或修改服务，封装核心业务逻辑。如果需要，调用 `dal` 层或 `proxy` 层。
4. **实现 DAL**: 如果涉及新的数据表操作，在 `biz/dal/model/` 中定义模型，并在 `biz/dal/` 中添加数据操作方法。
5. **注册路由**: 在 `router.go` 的 `customizeRegister` 函数中，将新的 handler 注册到合适的路由组。
6. **编写单元测试**: 为 `service` 和 `dal` 层的新增逻辑编写单元测试。
7. **本地调试**: 使用 `go run main.go` 启动服务，并通过 `script/httprequests/` 中的 `.http` 文件或 Postman 等工具进行接口调试。

## 4. 代码规范

代码遵循标准的 Go 语言规范，并结合了公司内部的最佳实践。核心要点如下（参考：`Golang编码规范.lark.md`）：

- **格式化**: 所有代码提交前必须使用 `gofmt` 或 `goimports` 进行格式化。推荐配置 IDE 保存时自动格式化。
- **命名**:
  - 包名使用小写，简洁且与目录名相关。
  - 变量、函数、结构体等遵循驼峰命名法。首字母大写表示导出（public），小写表示包内私有（private）。
  - 接口名以 `er` 结尾 (如 `Reader`)，实现则去掉 `er`。
  - Receiver 名称简短，通常是结构体名称的首字母缩写（如 `c` for `ContractService`）。
- **注释**:
  - 所有可导出的函数、类型、常量和变量都应有注释说明其用途。
  - 包注释需在 `package` 语句前提供，对包功能进行整体说明。
  - 实现复杂的逻辑时，应添加必要的行内注释。
- **错误处理**:
  - 函数返回错误时，`error` 应是最后一个返回值。
  - 禁止忽略 `error` 返回值，必须进行检查。除非明确知道不会出错。
  - 错误信息应包含上下文，使用 `fmt.Errorf("...: %w", err)` 包装底层错误。
- **函数抽象**:
  - 不要为只有一行有效业务代码的简单取值、格式化、map 查找或转发调用单独抽 helper 方法；优先在调用处直接表达，除非该抽象承载了明确的业务语义、复用复杂逻辑或隔离变化点。
- **并发**:
  - 启动 Goroutine 时必须考虑其生命周期管理，避免泄露。
  - 使用 `context` 来控制并发操作的取消、超时和传递请求范围的值。
  - 访问共享资源时，必须使用互斥锁 (`sync.Mutex`) 或其他同步原语保护。
- **测试**:
  - 核心业务逻辑和服务必须有单元测试覆盖。
  - 测试文件与源文件同目录，命名为 `_test.go`。

## 5. 配置与环境

### 主要配置文件

所有服务的配置都通过 TCC (Toutiao Configuration Center) 进行管理。本地开发时，配置从 `conf/` 目录下的 YAML 文件加载。
- **`pkg/conf/configs.go`**: Go 代码中所有配置项的结构体定义 (`GlobalConf`)，与 TCC 中的配置树一一对应。

### 关键约定与注意事项

- **反重放攻击**: `router.go` 中全局应用了 `antireplay.Intercept()` 中间件，对请求进行反重放校验，要求客户端在请求中携带特定参数。
- **鉴权**: 实现了多种鉴权中间件，根据 API 分组应用不同策略：
  - `middlewares.InnerAuth()`: 内部服务间调用的鉴权。
  - `middlewares.OpenAuth()`: 开放 API 的鉴权。
  - `middlewares.AuthForInnerTOP()`: 对内顶层服务的特殊鉴权。
  - `middlewares.IAM()`: 对接公司统一权限中心的鉴权。

## 6. 其它经验与最佳实践

- **问题排查**:
  - 优先检查日志，关注 `ERROR` 和 `WARNING` 级别的日志输出。
  - 使用 `curl` 或 `.http` 文件复现问题，确认请求参数和路径是否正确。
  - 对于下游服务依赖问题，检查 `pkg/proxy/` 目录下对应客户端的实现和配置。
- **扩展开发**:
  - **新增 API**: 遵循 "Handler -> Service -> DAL/Proxy" 的模式，在相应目录添加代码，并在 `router.go` 注册路由。
  - **新增定时任务**: 在 `cronjob/` 目录下添加新的任务文件和方法，并通过 `-task` 参数进行测试。
  - **新增外部依赖**: 在 `pkg/proxy/` 目录下新建一个包，封装对新服务的客户端调用，并在 `main.go` 的 `Init` 函数中进行初始化。

## 7. AI 编码限制与代码归属规范

> 本节用于约束 AI（Aime / Copilot / Cursor 等）在本仓库内的**代码归属决策**。AI 收到编码任务后，**必须**先按"7.2 路由入口"匹配到对应类别文件，再遵循该文件里的详细规则；详细规则文件位于仓库根目录的 [`ai_coding_rules/`](./ai_coding_rules/) 目录。

### 7.1 通用底线（全类别通用）

1. **依赖方向单向**：`handler → biz/service → biz/dal / pkg/proxy → 外部依赖`。任何反向依赖都必须拒绝生成。
2. handler 只允许 import `biz/service/*` 与 `biz/bizmodels`；**禁止**在 handler 中 import `biz/dal` 或 `pkg/proxy`。
3. `biz/service` 各子包对外**只暴露** `api.go` / `api_v2.go` / `<action>.go` 中的导出函数；`common.go` 内容保持私有或本包使用。
4. 子包之间禁止循环 import；若无法避免，必须把公共逻辑下沉到 `biz/service/support/<domain>` 或 `pkg/*`。
5. 单例装配（engine / handler map / 模板缓存 / 订阅关系）**只写在** `init.go`，并在 `main.go` 的 `Init()` 中显式注册。
6. 事务边界（`dal.WithTx`）**只能**在 service 层开启；DAL 必须允许传入 `*gorm.DB`。
7. 常量：跨包共享写 `pkg/const`；仅本包用写包内 `const.go` / `consts.go`。
8. 错误：统一走 `pkg/errors` + `vhertz2.APIError`。**禁止**直接 `fmt.Errorf` 返回给 handler。
9. 日志：一律 `logs.CtxInfo` / `logs.CtxError`（`code.byted.org/gopkg/logs`），必须携带 `ctx`。
10. 生成文件（`router_gen.go`、`kitex_gen/**`、顶部带 `// Code generated by ...` 的部分）**禁止手改**。
11. 每新增一个导出函数或业务动作文件，必须同时新增就近 `_test.go`（`goconvey + mockey` 风格）。
12. **禁止**在 `biz/service/` 根目录新增 `.go` 文件；根目录仅保留 `contract_process.go` / `upload_and_download.go` 两个历史入口。

### 7.2 路由入口（AI 决策第一步）

AI 收到编码任务后，先判断"这段代码属于哪个业务能力"，再对号入座到下列文件：

| 你要写的功能 | 归属类别 | 详细规则文件 |
| --- | --- | --- |
| 合同状态流转 / 审批引擎 / 报价合同 / 元数据 / 结算 / 事件 / 免签 / 优惠券 / 业务模式条款 | 核心业务引擎 | [`ai_coding_rules/01_core_business_engines.md`](./ai_coding_rules/01_core_business_engines.md) |
| 消息通知 / 飞书审批 / 飞书 & Lark 服务 / 进程内事件总线 | 通知与协同 | [`ai_coding_rules/02_notification_and_collaboration.md`](./ai_coding_rules/02_notification_and_collaboration.md) |
| RocketMQ 生产 / 消费 / 数据同步 / 数据比对 / 定时任务 | 数据与异步链路 | [`ai_coding_rules/03_data_and_async.md`](./ai_coding_rules/03_data_and_async.md) |
| 审核人分配 / 催办 / 风险条款 / 风险审核 / 风控规则 | 审核人与风险 | [`ai_coding_rules/04_reviewer_and_risk.md`](./ai_coding_rules/04_reviewer_and_risk.md) |
| 多环境差异 / 权限 / 主数据 | 配置与多环境 | [`ai_coding_rules/05_config_and_multi_env.md`](./ai_coding_rules/05_config_and_multi_env.md) |
| 合同模板 / 模板变量替换 / Word 转换 / 免税转换 | 模板与文档处理 | [`ai_coding_rules/06_template_and_document.md`](./ai_coding_rules/06_template_and_document.md) |
| account / quote / metaext / metaattachment / cooperationrecord 等被多包共用的下沉能力 | 二级支撑子域 | [`ai_coding_rules/07_support_subdomain.md`](./ai_coding_rules/07_support_subdomain.md) |
| 通用校验 / 评论 / 操作记录 / 公共工具 | 通用与校验 | [`ai_coding_rules/08_common_and_validation.md`](./ai_coding_rules/08_common_and_validation.md) |
| 顶层保留文件 / 遗留入口 / 未匹配到子包 | 顶层与遗留 | [`ai_coding_rules/09_root_and_legacy.md`](./ai_coding_rules/09_root_and_legacy.md) |

> 如果一段代码同时触发多个类别，**按主要业务动作归属**，其余部分通过跨包调用完成。例如"审批通过 → 发通知"：审批写在 `auditx`（类别 01），通知调用走 `notify`（类别 02）。

### 7.3 未匹配到任何包时的处理

- **不要**自动新建业务子包。必须先在 `ask_user` 中列出候选（新建包路径 + 归属类别 + 影响面），得到确认后再动手。
- **不要**为了绕过归属规则把逻辑塞到 `biz/service/common/` 或顶层文件——这属于违规。

### 7.4 修改既有代码时的最小改动原则

- 只修改与需求直接相关的文件，避免顺手重命名/搬移无关文件。
- 命名与既有文件保持一致（如 `workflow/` 内继续使用 `biz_api_` 前缀；`notify/` 内继续使用 `sender_<渠道>_` 前缀）。
- 如需重构，先按类别文件里的"重构触发条件"确认，再单开 MR。

### 7.5 提交前 AI 自检清单

- [ ] 归属类别文件已阅读，且新代码落到了唯一目标位置。
- [ ] 无反向依赖、无循环 import、无 handler 直接连 DB/RPC。
- [ ] 常量/错误码/DTO 已按 4 处（`pkg/const`、`pkg/errors`、`biz/bizmodels`、`biz/dal/model`）归位。
- [ ] 新增导出函数 = 新增 `_test.go`，主分支 + 错误分支覆盖。
- [ ] 未修改任何 `// Code generated by ...` 文件的自动生成段。
- [ ] `gofmt -w` + `go test ./...` 相关包通过。

---
*Generated by Aime, an AI DevOps assistant.*

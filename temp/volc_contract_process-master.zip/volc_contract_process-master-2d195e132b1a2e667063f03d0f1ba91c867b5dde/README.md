火山引擎报价合同系统


### 报价合同生成pdf
- 首先基于Word工具类在程序中补全数据，加工完毕后使用office命令行将Word转换为PDF
- Mac本地环境，需要安装soffice
  - 前提已安装 brew
  - 忽略 brew tap homebrew/cask
  - 忽略 brew install cask
  - brew install libreoffice

### other
其他说明 待补充


### BAM API 自动更新

```shell
# 安装
go install github.com/swaggo/swag/cmd/swag@latest
```

```shell
# 执行：建议在命令行单独执行，当前项目GO版本过高，执行报错
# 在本地安装GO1.8 执行如下命令即可。
swag init --parseDependency
```
swag 参考文档
https://github.com/swaggo/swag/blob/master/README_zh-CN.md#%E7%BB%93%E6%9E%84%E4%BD%93%E6%8F%8F%E8%BF%B0


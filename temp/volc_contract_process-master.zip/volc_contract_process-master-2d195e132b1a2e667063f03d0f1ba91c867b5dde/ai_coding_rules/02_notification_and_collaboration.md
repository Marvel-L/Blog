# 02 · 通知与协同（Notification & Collaboration）

**适用包**：`notify` · `feishuapproval` · `feishuservice` · `larkservice` · `eventbus`

承担合同域"消息发出去、事件传出去、飞书审批对接"三类职责。

## 1. 各包职责

| 包 | 职责 | 关键文件 |
| --- | --- | --- |
| `notify` | 统一通知编排：构造消息 + 按渠道派发 | `api.go` / `api_v2.go` / `msg_builders.go` / `msg_template.go` / `sender.go` / `sender_<渠道>.go` |
| `eventbus` | 进程内事件总线：发布 + 订阅执行 | `api.go` / `handler_<事件>.go` / `models.go` / `model_event_body.go` |
| `feishuapproval` | 飞书审批对接（自动价 / 风险条款角色 等） | `api.go` / `base.go` / `handler_<场景>_perm.go` / `feishumodel/` |
| `feishuservice` | 飞书非审批能力（消息卡片、群操作、身份查询等业务侧封装） | `api.go` |
| `larkservice` | Lark（同飞书）非审批能力，与 `feishuservice` 存在历史双写 | `api.go` |

## 2. 归属决策规则

1. **要"发消息 / 发邮件 / 通过卡片提醒"？** → `notify`。消息构造进 `msg_builders.go`，渠道派发进 `sender_<渠道>.go`。
2. **要"发进程内事件 / 让另一个包异步响应"？** → `eventbus`。事件类型加常量 + 一个 `handler_<事件>.go`。
3. **要"对接飞书审批（提单 / 回调 / 转派）"？** → `feishuapproval`。按业务场景加 `handler_<场景>_perm.go`。
4. **要"飞书非审批能力（发卡片、查用户、创建群）"？** → `feishuservice`（新代码优先）。`larkservice` 保留兼容，**禁止**在其中新增业务动作。
5. 如需新渠道 / 新事件 / 新审批场景，**新增文件**而非新增包。

## 3. 文件命名硬规则

`notify`：

- 通知模板与文案：`msg_template.go`。
- 消息 body 构造：`msg_builders.go` 中按 `Build<场景>Msg(ctx, ...) Msg`。
- 每一个下游渠道独占一份 `sender_<渠道>.go`（现存：`sender_c360_mq.go` / `sender_direct_event_message.go` / `sender_event_message.go` / `sender_lark_email.go` / `sender_lark_email_urgent.go`）。新渠道 = 新文件，**禁止**塞进已有 `sender_*.go`。
- 对外统一入口 `api.go` 的 `Send(ctx, msg)`；`api_v2.go` 用于版本升级，`api.go` 保留兼容。

`eventbus`：

- 事件类型常量放 `const.go`。
- 事件 body 放 `model_event_body.go`；聚合模型放 `models.go`。
- 每个订阅者一个 `handler_<事件>.go`（现存：`handler_co_status_change.go` / `handler_meta_archived.go`）+ 就近 `_test.go`。
- 订阅注册**只在** `init.go` 完成。禁止在业务包内 `init()` 里注册订阅。

`feishuapproval`：

- 场景按能力细分（现存：`handler_auto_price_perm.go` / `handler_risk_role_perm.go`）。
- 模型/DTO 放子包 `feishumodel/`；工具函数在 `util.go`；常量在 `const.go`。
- 对外暴露：`api.go`；`base.go` 承载协议层通用逻辑，禁止在业务动作里重复实现。

`feishuservice` / `larkservice`：

- `api.go` 中一个能力一个函数；模型走 `models.go`。
- 涉及飞书 OpenAPI 的具体调用**必须**走 `pkg/proxy/larkc` 或 `pkg/proxy/feishucli`，本包只做业务侧包装。

## 4. 跨包调用约束

- 任意业务包（`workflow / auditx / salescontract / contractmeta / ...`）都可以 `notify.Send(...)` 与 `eventbus.Publish(...)`；反向：`notify` / `eventbus` **禁止** import 业务包。
- `notify.Send` 内部的下游渠道调用**必须**走 `pkg/proxy/*cli`（飞书、邮件、C360 MQ、事件总线），禁止直接 HTTP/RPC。
- `feishuapproval` 与 `notify` 之间互不 import；如果审批完成需要通知，应在业务包里调用两者。
- `eventbus.handler_<事件>.go` 内部可以调用其他业务包的 `api.go`，但**禁止**再往回发同一事件（避免循环）。

## 5. AI 硬性禁止

- 禁止在业务包内直接调 `pkg/proxy/larkc` / `pkg/proxy/messagecli` 发通知——**必须**经过 `notify.Send`。
- 禁止在 `notify` 里做业务判断（例如"合同状态为 X 才发"），此类判断应放在调用方业务包。
- 禁止把飞书审批的回调逻辑塞进 `notify`，那是 `feishuapproval` 的地盘。
- 禁止在 `eventbus` 内做同步业务处理（数据库落库、状态流转），只做订阅派发。
- 禁止新增没有 `Init()` 注册的 handler；未注册的 handler 会静默失效。

## 6. 新渠道 / 新事件 / 新审批场景的流程

新渠道（notify）：
1. 在 `pkg/proxy/` 新建对应 `xxxcli` 包，封装 SDK。
2. 在 `notify/sender_<渠道>.go` 新文件中实现 `send<渠道>(ctx, msg)`。
3. 在 `sender.go` 的分发函数里补 case（按渠道枚举），并在 `const.go` 加渠道常量。
4. 补 `_test.go`。

新事件（eventbus）：
1. `const.go` 加事件类型常量。
2. `model_event_body.go` 加 body 结构体。
3. `handler_<事件>.go` 新增订阅者；`init.go` 中注册。
4. 生产方业务包调用 `eventbus.Publish(ctx, evt)`。

新审批场景（feishuapproval）：
1. `handler_<场景>_perm.go` 新文件（提单 + 回调）。
2. `feishumodel/` 加对应结构体。
3. `api.go` 暴露入口给业务包调用。

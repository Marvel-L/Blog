# 01 · 核心业务引擎（Core Business Engines）

**适用包**：`workflow` · `auditx` · `ruleengine` · `salescontract` · `contractmeta` · `contractsettlement` · `contractevent` · `fresh_seal` · `metaattach` · `coupon` · `businessmodeclause` · `quote` · `basicinfo` · `auto_price_approval`

这些包承载合同域的核心状态流转、审批、风险规则与销售/元数据编排，是本仓库的心脏。AI 在此类别下编码，**优先级高于**任何"快速实现"考虑。

## 1. 各包职责（选择归属包时使用）

| 包 | 唯一职责 | 典型入口 |
| --- | --- | --- |
| `workflow` | 业务合同（报价 / 信控 / 伙伴 / 代理）状态流转引擎，多状态 × 多操作 | `biz_api_*.go`（`submit / audit / gen_draft_file / update_struct_data / add_op_record`） |
| `auditx` | 在线协同合同的审批引擎（草稿/退回/销售/财税法/销售确认/信息完善/OA），状态 × 操作 → handler | `api.go` 中的 `Handle(ctx, pc)`；子包 `handler/h{状态}_{阶段}_{动作}.go` |
| `ruleengine` | 规则引擎主体 + `std.yaml` 规则配置 | `api.go`；`rule_test.go` |
| `salescontract` | 销售合同/在线协同合同的业务 API 编排层，承接 handler 请求 | `create_or_update.go` / `operate_contract.go` / `list_contract.go` / `urge_notify.go` / `fill_reviewer_name.go` / `get_pre_contract.go` |
| `contractmeta` | 业务合同元数据（版本、批量下载、去重校验、签署主体、过期提醒） | `api.go` / `api_v2.go` / `batch_download_helpers.go` / `sign_subject.go` / `expire_remind_info.go` |
| `contractsettlement` | 合同结算相关数据/流转 | `api.go` |
| `contractevent` | 合同事件（履约/终止/变更）的领域动作 | `api.go` |
| `fresh_seal` | 加盖新章相关流程 | `api.go` |
| `metaattach` | 元数据附件（合同附件 meta 侧） | `api.go` |
| `coupon` | 合同优惠券绑定/校验 | `api.go` |
| `businessmodeclause` | 业务模式条款配置与匹配 | `api.go` |
| `quote` | 报价相关的合同侧动作（非报价系统本身） | `api.go` |
| `basicinfo` | 合同基础信息读写 | `api.go` |
| `auto_price_approval` | 自动定价审批场景 | `api.go` |

## 2. 归属决策规则

AI 在收到一段"合同类"需求时，按下列顺序判断：

1. **是否修改合同状态？** → 归 `workflow`（业务合同）或 `auditx`（在线协同合同）。
2. **是否处理审核类操作（通过 / 退回 / 加签 / 转办 / 撤回 / 变更评审人）？** → 归 `auditx/handler/h{状态}_{阶段}_{动作}.go`。
3. **是否只读/写元数据字段（名称、附件、商品、签署主体、过期时间）？** → 归 `contractmeta`。
4. **是否是销售流程编排（handler 直接调）？** → 归 `salescontract`，由它再调用其他包。
5. **是否是结算/事件/加盖/附件/优惠券/条款/报价/基础信息/自动定价？** → 按上表一一归位，不允许多包共存实现。
6. 若上述均不匹配，**必须** `ask_user` 确认是否新建子包，禁止塞入 `salescontract` 或 `workflow` 兜底。

## 3. 单包文件命名硬规则

`workflow`：所有业务动作**必须**以 `biz_api_` 前缀，例如 `biz_api_<动作>.go`；`biz_api_model.go` 承载动作用到的结构体；`common.go` 仅私有工具。禁止把非 `biz_api_` 前缀的导出函数放进本包。

`auditx`：

- 引擎装配在 `init.go` 的 `Init()` 内用 `sync.Once`；engine 结构定义在 `api.go`。
- **每一个「状态 × 操作」组合独占一个文件**，命名 `h{状态码}_{阶段}_{动作}.go`（示例：`h101_solution_pass.go`、`h3_sales_sendback.go`、`h9_ftl_sign_withdraw.go`）。
- 复用型 handler 前缀 `multi_` 或 `sign_subject`；每个 handler 就近 `_test.go`。
- **禁止**新增没有 `AllHandlers()` 注册的 handler 文件；禁止在业务动作文件里直接读写 DB，必须调用 `biz/dal`。
- 上下文模型放子包 `auditmodel/`（`context.go` / `model.go`）。

`salescontract`：

- 一个动作一个文件，函数名与文件名一一对应，例如 `CreateOrUpdate → create_or_update.go`。
- `common.go` 只允许存放本包 3 个及以下的私有辅助函数；一旦函数被跨文件复用超过 3 个，拆到 `<subdomain>` 子包（参考已存在的 `productkey/`）。
- `model.go` 只放包内 DTO，跨包 DTO 必须迁到 `biz/bizmodels`。

`contractmeta`：

- 版本演进走 `api_v2.go` / `api_v3.go`，旧版保留兼容。
- 校验类逻辑（`check_*.go`）必须无副作用；有副作用的走 `api.go`。
- 元数据模型放 `model.go`，DB 模型不允许出现在本包。

其余包（`contractsettlement / contractevent / fresh_seal / metaattach / coupon / businessmodeclause / quote / basicinfo / auto_price_approval`）遵循 8 类文件模板：`api.go` / `api_test.go` / `init.go`（如需）/ `const.go` / `model.go` / `common.go` / `<action>.go` / `<action>_test.go`。

## 4. 跨包调用约束

- `salescontract` 是**顶层编排层**，允许调 `contractmeta / workflow / auditx / notify / eventbus / feishuapproval / multienv` 等；反过来**禁止**从 `workflow` / `auditx` 反向 import `salescontract`。
- `workflow` 与 `auditx` 之间**互不 import**：它们代表两种独立合同形态；如果确实需要通用能力，下沉到 `biz/service/support/<domain>` 或 `pkg/`。
- `contractmeta` 是最基础的读写层之一，**任何**业务包都可 import 它；它自身**不允许** import `workflow` / `auditx` / `salescontract`。
- `ruleengine` 保持无业务耦合：只按 `std.yaml` 规则 in/out，禁止在此判定合同专属字段。

## 5. AI 硬性禁止

- 禁止在这些包内新增 `main.go` / `router.go` / `handler` 导出结构体（那是 `biz/handler`）。
- 禁止绕过 `auditx.Handle` 直接调用 `handler/h*.go` 中的函数。
- 禁止在 `workflow / auditx` 的 `<action>.go` 内直接调用 `pkg/proxy/*`；必须通过本包 `common.go` 或对方业务包的 `api.go` 中转，保持"一个动作一个下游列表"可审计。
- 禁止在 `contractmeta` 中做通知发送、状态流转触发——那是 `notify` 和 `workflow/auditx` 的职责。
- 禁止将合同类型枚举、状态枚举字面量散落到多个文件；统一在 `pkg/const` 或本包 `const.go` 定义。

## 6. 新增子域的触发条件

只有当新需求满足以下**任意两条**时，才允许新建包：

1. 出现全新的合同类型或全新的业务对象（非既有对象的字段扩展）。
2. 预计将产生 5 个以上业务动作。
3. 需要独立的 engine / handler map / 事件订阅关系。
4. 与既有包的字段/状态几乎不重叠。

否则一律扩展既有包，走"新增 `<action>.go`"路径。

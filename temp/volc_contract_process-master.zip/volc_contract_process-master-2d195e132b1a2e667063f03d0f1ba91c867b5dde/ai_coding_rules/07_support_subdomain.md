# 07 · 二级支撑子域（Support Subdomain）

**适用目录**：`biz/service/support/`

**已存在子包**：`account` · `cooperationrecord` · `metaattachment` · `metacommodity` · `metaext` · `metasettlement` · `metasync` · `metatradeparty` · `quote` · `reviewrule` · `richtext` · `tradeservice` · `verifychange`

`support/` 不是"通用工具库"，而是"**多个业务包共用的业务能力**"。定位在业务包与 `pkg/` 之间：仍是业务逻辑（要感知合同/账号/报价等对象），但不属于任何单一业务包。

## 1. 归属决策规则

一段代码归入 `support/` 的**必要条件**（必须同时满足）：

1. 至少被 **2 个业务包** import；
2. 与业务对象强相关（读写合同/账号/报价/交易等表），不适合放 `pkg/`；
3. 不构成新的"业务动作对象"（否则应新建业务包）。

反例：只被一个业务包使用 → 属于该业务包的 `common.go`；纯工具、无业务感知 → 应上升到 `pkg/util`。

## 2. 各子包职责

| 子包 | 职责 |
| --- | --- |
| `support/account` | 账号信息读取、缓存、脱敏（供多包共用） |
| `support/cooperationrecord` | 合作记录读写 |
| `support/metaattachment` | 合同元数据附件的下沉读写 |
| `support/metacommodity` | 合同元数据商品条目读写 |
| `support/metaext` | 合同元数据扩展字段 |
| `support/metasettlement` | 合同元数据结算相关字段 |
| `support/metasync` | 合同元数据同步能力 |
| `support/metatradeparty` | 合同元数据交易方（甲方/乙方）读写 |
| `support/quote` | 报价（合同侧）读写共用能力 |
| `support/reviewrule` | 审核规则读写 |
| `support/richtext` | 富文本处理 |
| `support/tradeservice` | 交易系统的业务侧适配 |
| `support/verifychange` | 认证/变更相关的通用逻辑 |

## 3. 文件命名硬规则

- 每个子包遵守 8 类文件模板：`api.go` / `api_test.go` / `init.go` / `const.go` / `model.go` / `common.go` / `<action>.go` / `_test.go`。
- 子包名 = 目录名，全小写、不下划线。
- 每个子包的对外入口**只在** `api.go`；内部动作可拆到 `<action>.go`。

## 4. 跨包调用约束

- `support/*` 允许被任何业务包 import。
- `support/*` 之间可以互相调用，但**禁止**循环 import。
- `support/*` **禁止** import 上层业务包（`workflow / auditx / salescontract / contractmeta` 等）。若需要合同状态判断，改由入参传入，保持支撑包的独立性。
- `support/*` 允许调用 `biz/dal` 与 `pkg/proxy/*`。

## 5. AI 硬性禁止

- 禁止把只被一个业务包使用的逻辑放进 `support/`——一律回到该业务包的 `common.go` 或独立文件。
- 禁止在 `support/*` 内做通知发送、事件发布，那是 `notify` / `eventbus` 的职责。
- 禁止在 `support/*` 内声明业务状态枚举；状态枚举归 `pkg/const` 或对应业务包。
- 禁止 `support/*` 之间通过反射或全局变量互调；接口调用**必须**显式 import + 直接函数调用。

## 6. 新增 `support/*` 子包的流程

1. 用"必要条件"三点自查；不满足则**不允许**新建。
2. 目录命名：小写、单词（多单词无下划线，如 `metatradeparty`）。
3. 初始骨架：`api.go` + `api_test.go` + `model.go` + `README.md`（简短描述职责与依赖方）。
4. MR 中列出：本包被哪些业务包 import、为何不放业务包内、是否可能升级为独立业务包。

## 7. 常见混淆场景

| 场景 | 归属判定 |
| --- | --- |
| "取当前操作人所属账号信息"，多包都要用 | `support/account` |
| "取当前合同的商品条目"，仅 `contractmeta` 用 | `contractmeta` 内部 |
| "合同附件的通用查询/删除"，被 `contractmeta` + `salescontract` 都用 | `support/metaattachment` |
| "把富文本 HTML 转成合同显示格式" | `support/richtext` |
| "对报价系统的响应做业务侧字段映射，被审批和销售都用" | `support/quote` |
| "只有 auditx 使用的评审规则匹配" | `auditx` 内部；不进 `support/reviewrule` |

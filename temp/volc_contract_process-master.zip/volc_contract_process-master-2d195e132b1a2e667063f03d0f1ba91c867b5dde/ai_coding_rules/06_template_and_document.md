# 06 · 模板与文档处理（Template & Document）

**适用包**：`template` · `templatereplace` · `wordconvert` · `exemptconverter`

围绕合同模板管理、变量替换、Word 转换、免税单专用转换。

## 1. 各包职责

| 包 | 职责 |
| --- | --- |
| `template` | 合同模板主流程：模板 CRUD、加载、缓存、渲染引擎 |
| `templatereplace` | 模板变量的替换器（占位符 → 值） |
| `wordconvert` | Word 与其他格式互转（.docx ↔ pdf/html） |
| `exemptconverter` | 免税单场景专用文档转换 |

## 2. 归属决策规则

1. **要管模板本身（CRUD、版本、启停）？** → `template`。
2. **要处理变量占位符（`{{customer_name}}`）的解析与填充？** → `templatereplace`。
3. **要把 .docx 转成别的格式（预览、导出）？** → `wordconvert`。
4. **仅免税单文档专用的转换逻辑？** → `exemptconverter`。
5. 涉及"上传到 TOS / 下载 URL"的通用逻辑，走 `pkg/proxy/tosc`，禁止在模板包里重复实现。

## 3. 文件命名硬规则

`template`：

- 引擎主体：`engine.go`。
- 模型：`model.go`。
- 子包 `handler/`：每种模板类型或渲染阶段一个 handler 文件。
- 初始化（字体加载 / 模板预加载）：`init.go`。
- 对外 API：`api.go`。

`templatereplace`：

- 一种占位符规则一个文件：`placeholder_<类型>.go`。
- 变量映射与合同字段的对应关系：`mapping.go` 或按业务对象拆多个 `mapping_<对象>.go`。

`wordconvert`：

- 一种转换方向一个文件：`docx_to_pdf.go` / `docx_to_html.go`。
- 依赖的第三方库调用**必须**封装成本包内部函数，禁止在其它包直接调用第三方库。

`exemptconverter`：

- 单一场景，一个 `convert.go` + `convert_test.go` 起步，若扩展多种免税单类型再按 `<类型>.go` 拆分。

## 4. 跨包调用约束

- 业务包（`salescontract` / `workflow` / ...）需要生成文档时，**必须**调用 `template.Render(...)` 或 `wordconvert.Convert(...)`；禁止自己解析 docx。
- `template` 依赖 `templatereplace` 完成变量替换；反向禁止。
- `templatereplace` 允许 import `contractmeta` 读取合同字段 → 但**建议**通过入参传入 model，避免耦合。
- `wordconvert` / `exemptconverter` 不允许 import 任何合同业务包，纯做格式转换。

## 5. AI 硬性禁止

- 禁止在业务包内直接读 `templates/` 目录下的 .docx 文件——**必须**经过 `template` 包。
- 禁止把 TOS key / 桶名硬编码；一律走 `pkg/conf` 读取 + `pkg/proxy/tosc` 上传下载。
- 禁止在 `templatereplace` 内做数据库读操作；变量的真实值应由调用方通过入参提供（保持纯函数属性）。
- 禁止把 PDF/字体路径散落到多个文件；集中在 `init.go` 中加载并复用。
- 禁止在 `wordconvert` 内做合同业务判断（哪些合同需要转换、命名规则等），业务判断属于调用方。

## 6. 新增模板 / 新占位符类型 / 新转换方向的流程

新增模板：
1. 在 `templates/` 增加 .docx 文件。
2. 在 `template/model.go` 或 `pkg/const` 增加模板类型枚举。
3. 若渲染流程有差异，在 `template/handler/` 新增文件。

新增占位符类型：
1. `templatereplace/placeholder_<类型>.go` 新文件。
2. 注册到解析器（`init.go` 或 `engine.go` 中的注册表）。
3. 补 `_test.go`。

新增转换方向：
1. `wordconvert/<from>_to_<to>.go`。
2. 若依赖新第三方库，评估是否已在 `go.mod` 存在，避免引入重复依赖。

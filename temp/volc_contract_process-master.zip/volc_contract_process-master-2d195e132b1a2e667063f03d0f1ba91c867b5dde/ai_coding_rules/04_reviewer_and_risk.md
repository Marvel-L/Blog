# 04 · 审核人与风险（Reviewer & Risk）

**适用包**：`reviewer` · `reviewerremind` · `riskreviewer` · `riskclauserole` · `riskclausetpl` · `riskengineservice`

围绕合同的审核人分配、催办、风险条款/角色管理与风险引擎服务。

## 1. 各包职责

| 包 | 职责 |
| --- | --- |
| `reviewer` | 合同评审人（普通评审）的分配、查询、切换 |
| `reviewerremind` | 评审人催办：定时/条件触发提醒 |
| `riskreviewer` | 风险评审人（合规、法务方向）分配与流转 |
| `riskclauserole` | 风险条款对应的评审角色映射 |
| `riskclausetpl` | 风险条款模板：读、写、版本 |
| `riskengineservice` | 风险引擎服务侧包装：调用风险引擎接口 + 结果映射 |

## 2. 归属决策规则

1. **是普通评审人相关（分配/替换/追加）？** → `reviewer`。
2. **是要催 / 提醒评审人操作？** → `reviewerremind`；通知本身走 `notify.Send`，本包只做"该不该催、催谁"判断。
3. **是风险评审人（不同于普通评审）？** → `riskreviewer`。
4. **是风险条款与角色的映射？** → `riskclauserole`。
5. **是风险条款模板（CRUD、启用禁用）？** → `riskclausetpl`。
6. **是调用风险引擎（外部服务）来评估合同？** → `riskengineservice`。
7. 若某段代码同时命中 `riskreviewer` 与 `reviewer`（例如通用的"评审人切换"），**归 `reviewer`** 并通过参数区分类型；避免在两个包里各写一份。

## 3. 文件命名硬规则

- 8 类文件模板；每个 CRUD 动作独立文件：`create.go` / `list.go` / `update.go` / `delete.go` / `switch.go` / `remind.go` / `dispatch.go`。
- `riskengineservice`：一个下游接口一个文件，例如 `evaluate.go` / `query_rule.go`。**禁止**在此包内加合同状态判断，纯做"入参 → 下游 → 结果映射"。
- `reviewerremind`：判断"该不该催"的规则文件按触发点命名：`by_stage.go` / `by_timeout.go` / `by_business_type.go`。

## 4. 跨包调用约束

- `riskengineservice` 只依赖 `pkg/proxy/riskenginecli` + `pkg/const` + `pkg/errors`；**禁止** import 任何合同业务包。
- `riskclausetpl` / `riskclauserole` 允许被 `riskengineservice` / `auditx` / `workflow` 调用，反向禁止。
- `reviewer` / `riskreviewer` 允许调用 `pkg/proxy/iamcli` / `permission` / `larkc` 查询用户信息；禁止业务包在自己内部再查一次同样的用户信息。
- `reviewerremind` 依赖 `notify.Send`；**禁止**自己直接发飞书/邮件。

## 5. AI 硬性禁止

- 禁止把"评审人 = 谁"的判定散落到多个业务包；一律走 `reviewer.GetReviewer(...)` / `riskreviewer.GetReviewer(...)`。
- 禁止在 `riskengineservice` 内缓存规则（缓存能力放 `pkg/proxy/riskenginecli` 或独立缓存组件）。
- 禁止在 `riskclausetpl` 中做审批流转（那是 `auditx`）。
- 禁止在 `reviewerremind` 内直接落库操作记录，操作记录必须走 `oprecord` 包。
- 禁止在这些包内定义合同状态枚举——统一在 `pkg/const`。

## 6. 常见场景归属示例

| 需求 | 归属 |
| --- | --- |
| 新增"按业务模式分配评审人"策略 | `reviewer/dispatch_by_business_mode.go` |
| 新增"48h 未处理催办" | `reviewerremind/by_timeout.go` |
| 新增风险条款模板字段 | `riskclausetpl/model.go` + `update.go` |
| 新增风险条款角色 → 用户映射查询 | `riskclauserole/query.go` |
| 新增风险引擎"实时评估"接口 | `riskengineservice/evaluate_realtime.go` |
| 风险评审人转派给专家 | `riskreviewer/switch.go` |

# 03 · 数据与异步链路（Data & Async）

**适用包**：`mqconsumer` · `mpproducer` · `datasync` · `datamerge` · `datacompare` · `datarefresh` · `cronservice`

覆盖 RocketMQ 生产/消费、数据同步/合并/对比/刷新，以及定时任务的胶水层。

## 1. 各包职责

| 包 | 职责 | 定位 |
| --- | --- | --- |
| `mpproducer` | RocketMQ 生产者：向指定 topic 发消息 | 只做发送 + 序列化 + 失败重试 |
| `mqconsumer` | RocketMQ 消费者：接收消息 → 转发给业务包 | 只做接收、反序列化、路由 |
| `datasync` | 主动向下游/上游同步数据（推/拉） | 业务同步动作编排 |
| `datamerge` | 数据合并（同一实体多源合并） | 合并规则实现 |
| `datacompare` | 数据比对（诊断/巡检） | 比对逻辑与告警 |
| `datarefresh` | 缓存/派生数据刷新 | 幂等刷新逻辑 |
| `cronservice` | 定时任务通用底座：`base.go` 定义 Job 接口 + 通用能力 | 调度胶水，不写具体业务 |

## 2. 归属决策规则

1. **发 MQ 消息？** → `mpproducer/<topic 或场景>.go`。禁止业务包直接调 `pkg/proxy/rocketmq*`。
2. **收 MQ 消息？** → `mqconsumer/<topic>.go`：反序列化 → 调用业务包 `api.go`。
3. **业务侧要"主动把某类合同数据同步给下游/从上游拉回"？** → `datasync/<场景>.go`。
4. **多源数据需要按合并规则合并出一份主数据？** → `datamerge/<对象>.go`。
5. **需要对比两个数据源、报警不一致？** → `datacompare/<对象>.go`。
6. **需要定期刷新缓存/派生表？** → `datarefresh/<对象>.go`。
7. **定时任务触发入口？** → `cronjob/`（不在 `biz/service/` 内）。定时任务的具体业务实现放对应业务包，`cronservice` 只承载"Job 接口 + 通用调度胶水"。

## 3. 文件命名硬规则

- 所有包沿用 8 类文件模板：`api.go` / `api_test.go` / `init.go` / `const.go` / `model.go` / `common.go` / `<action|topic|对象>.go` / `_test.go`。
- `mpproducer` / `mqconsumer` 中：**每个 topic 独占一个文件**，命名 `<topic 简称>.go`。
- `cronservice/base.go`：只承载 Job 接口、生命周期方法、参数解析。**禁止**在此实现具体 Job 的业务逻辑。

## 4. 跨包调用约束

- `mpproducer` / `mqconsumer` **不允许** import 业务包的内部文件，只允许 import 业务包的 `api.go`。
- `mqconsumer` 的 handler 每处理一条消息**必须**幂等；若不幂等，需要在业务包里增加幂等键校验，禁止把幂等策略塞进 mqconsumer。
- `datasync` / `datamerge` / `datacompare` / `datarefresh` **必须**通过 `biz/dal` 读取本地数据、通过 `pkg/proxy/*cli` 访问下游；禁止绕过。
- `cronservice` 允许 import 业务包 `api.go`；业务包**禁止** import `cronservice`。

## 5. AI 硬性禁止

- 禁止在业务包内直接 `producer.Send(topic, body)`——**必须**经过 `mpproducer.Send<场景>(ctx, ...)`。
- 禁止在 `mqconsumer` 内做业务判断（"消息内合同状态为 X 才处理"），此类判断应放到业务包的 `api.go`。
- 禁止在 `datacompare` / `datarefresh` 中发通知或修改主数据；如需通知，调用 `notify.Send`；如需修改，调用对应业务包的 `api.go`。
- 禁止在 `cronservice/base.go` 内写具体业务代码——所有实际 Job 的实现放业务包并被 `cronjob/*` 调用。
- 禁止把定时任务频率、开关等硬编码在代码里；一律由 `pkg/conf` + TCC 控制。

## 6. 新增 topic / 新增同步链路的流程

新增 topic 生产：
1. 在 `pkg/proxy/rocketmq*` 或复用现有 producer client。
2. `mpproducer/<topic>.go` 新增文件：定义 body 结构体（若跨包共用则放 `biz/bizmodels`）、`Send<场景>(ctx, ...)` 函数、序列化、错误封装。
3. 补 `_test.go`。

新增 topic 消费：
1. `mqconsumer/<topic>.go` 新增文件：`Handle<场景>(ctx, msg) error`。
2. `init.go` 中注册订阅。
3. 幂等策略在业务包 `api.go` 中实现，`mqconsumer` 仅做透传。

新增数据同步：
1. 选归属：主动推 → `datasync`；多源合并 → `datamerge`；对比 → `datacompare`；缓存/派生 → `datarefresh`。
2. 单文件 = 单对象/单场景。
3. 调度入口放 `cronjob/`，业务逻辑放对应数据包。

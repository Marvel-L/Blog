# 09 · 顶层保留文件与遗留（Root & Legacy）

**适用文件**：`biz/service/contract_process.go` · `biz/service/upload_and_download.go`

`biz/service/` 目录**根路径下的 `.go` 文件属于历史遗留**，均使用 `package service`。AI 编码时对这两类文件采取**只维护、不扩张**策略。

## 1. 现存文件与职责

| 文件 | 包 | 现有职责 | 依赖 |
| --- | --- | --- | --- |
| `contract_process.go` | `service` | 合同流程顶层函数（早期实现，跨领域调度） | `workflow` / `masterdata` / `multienv` / `exportcli` / `larkc` / `accountcli` / `pkg/util` / `bizmodels` / `dal` |
| `upload_and_download.go` | `service` | 公共下载入口 `Download(ctx, downloadID)` | `dal.NewCommonUseDao` / `pkg/proxy/tosc` / `pkg/const` / `pkg/errors` |

## 2. 归属决策规则

- **绝对不允许**在 `biz/service/` 根目录新增 `.go` 文件。
- **绝对不允许**在这两个文件内新增导出函数——所有新逻辑必须落到对应的业务子包。
- 只有在下列场景才允许修改这两个文件：
  1. 修复 bug；
  2. 调整签名以兼容新版依赖；
  3. 逐步"抽走"逻辑到子包（重构 MR）。
- 抽离时，函数应搬到明确子包（如 `contract_process` 里的流程编排应搬到 `workflow` / `salescontract`；下载能力应搬到 `support/richtext` / `template` / 新建 `download` 包）并保留旧函数为 `@Deprecated` 转发层。

## 3. AI 硬性禁止

- 禁止新增 `biz/service/xxx.go`（根目录）文件。
- 禁止在 `contract_process.go` / `upload_and_download.go` 中扩大依赖面（新增 import 一个从未依赖过的业务包或 pkg）。
- 禁止对这两个文件做纯风格重构，避免引入回归；必须由业务重构 MR 触发。
- 禁止把新的下载/上传能力塞进 `upload_and_download.go`；新能力应落到具体业务包 + `pkg/proxy/tosc`。

## 4. 抽离步骤（AI 辅助重构）

1. 明确目标子包（走 `README.md` 的路由入口决策）。
2. 在目标子包新建 `<action>.go` 与 `_test.go`，把逻辑搬入。
3. 在原文件中保留旧函数签名，函数体只做一层转发调用；顶部注释 `// Deprecated: 请使用 xxx，本函数将在后续版本移除`。
4. 修改所有调用方指向新函数（若在同一 MR 内可控）；否则分 MR 递进。
5. 补全测试；确保 `go test ./...` 通过。

## 5. 未匹配到既有类别的兜底策略

若一段需求无法归入 `01`-`08` 中任何类别：

- **首选**：在 `ask_user` 中提出候选新建包（含目录、职责、依赖），得到确认后新建。
- **次选**：若确认属于合同流程编排的重构过渡态，可在 `contract_process.go` 内**临时保留**函数，但**必须**同步创建后续抽离计划（Meego 任务 / TODO 注释）。
- **禁止**：为了绕过归属规则把逻辑塞到 `common/`、`upload_and_download.go` 或 `contract_process.go`。

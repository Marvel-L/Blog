# 05 · 配置与多环境（Config & Multi-env）

**适用包**：`multienv` · `perm` · `masterdata`

处理"环境差异 / 权限 / 主数据"三类横向能力。这些包一旦改动会影响全站行为，AI 修改时**必须**评估兼容性。

## 1. 各包职责

| 包 | 职责 |
| --- | --- |
| `multienv` | 国内 vs BytePlus 双环境差异化。一个差异维度一个 `<name>_factor.go`；国际化文案在子包 `i18nfmt/` |
| `perm` | 业务侧权限校验封装（依赖 `pkg/proxy/permission`） |
| `masterdata` | 主数据读写（对接主数据系统） |

## 2. 归属决策规则

1. **同一逻辑在国内 / BytePlus 表现不同？** → 加 `multienv/<name>_factor.go`。禁止在业务包内 `if env == ...` 硬编码。
2. **要判断"当前用户能否操作某合同/字段"？** → `perm.Check<场景>(...)`。禁止在 handler 内直接查 IAM。
3. **要读客户 / 商品 / 组织 / 地区等主数据？** → `masterdata.Get<对象>(...)`。业务包禁止直接调 `pkg/proxy/mdcli`。

## 3. 文件命名硬规则

`multienv`：

- 一个差异维度 = 一个 `<name>_factor.go`（现存：`cooperation_factor.go` / `subject_info_factor.go` / `time_factor.go` / `time_discount_factor.go` / `notify_url_factor.go` / `exempt_factor.go` / `const_conver_factor.go` / `contract_status_factor.go`）。
- 常量放 `const.go` / `const_conver_factor.go`；聚合 API 放 `api.go`（对外调用只经过它）。
- 国际化文案：子包 `i18nfmt/`；**禁止**直接嵌入中英文字符串到 factor 文件。
- `init.go`：注册 factor 表（若采用注册模式）。

`perm`：

- 一个权限场景一个文件：`check_<场景>.go`。
- 权限点常量放 `const.go`。

`masterdata`：

- 一个主数据对象一个文件：`account.go` / `product.go` / `region.go` ...
- 缓存策略在 `pkg/proxy/mdcli` 或独立缓存组件，`masterdata` 不实现缓存，只做业务侧包装。

## 4. 跨包调用约束

- 所有业务包**必须**通过 `multienv` 访问环境差异；`multienv` **禁止** import 业务包。
- `perm` 只依赖 `pkg/proxy/permission` / `iamcli` / `pkg/const`；业务包对权限的直接调用集中到 `perm.Check*`。
- `masterdata` 只依赖 `pkg/proxy/mdcli` / `pkg/proxy/organizationcli` 等；禁止把主数据变更逻辑放这里（那属于对应下游系统）。
- `perm` 与 `masterdata` 之间不 import；如果权限判断依赖主数据，由调用方业务包串联。

## 5. AI 硬性禁止

- 禁止在业务包用 `env.IsBytePlus()` / `env.IsCN()` 做业务分支——**必须**下沉到 `multienv/<xxx>_factor.go`。
- 禁止在 `multienv` 里做 DB 读写或 RPC 调用；factor 是纯函数（可读 TCC 配置，不做副作用）。
- 禁止把权限点字符串（`"contract:create"`）散落到业务包，必须集中在 `perm/const.go` 或 `pkg/const`。
- 禁止在 `masterdata` 内定义合同专属字段的映射；那是 `contractmeta` 的责任。
- 禁止在业务包内保存主数据 ID → 名称的临时映射；跨调用共享的映射由 `masterdata` 或 `pkg/proxy/mdcli` 缓存管理。

## 6. 添加新差异维度的流程（multienv）

1. `const.go` 定义维度枚举。
2. 新文件 `<name>_factor.go`：`Get<Name>(ctx, ...)` 内部按 `env.Env()` 返回不同结果。
3. `api.go` 中暴露对外函数；如果需要注册模式，在 `init.go` 挂载。
4. 补 `_test.go`：**必须**对国内 / BytePlus 各覆盖至少一个用例。
5. 业务包按需替换硬编码 `if env == ...`。

## 7. 添加新权限点的流程（perm）

1. `const.go` 定义权限点常量。
2. `check_<场景>.go` 新文件：`Check<场景>(ctx, uid, resource) error`。
3. handler 层调用 `perm.Check<场景>`；不要在业务包内二次校验。

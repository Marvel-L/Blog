# 08 · 通用与校验（Common & Validation）

**适用包**：`validate` · `comment` · `oprecord` · `common` · `supply` · `thirdservice`

承担合同域内的通用校验、评论、操作记录以及部分历史遗留能力。

## 1. 各包职责

| 包 | 职责 |
| --- | --- |
| `validate` | 可复用的参数/业务校验器，被多个业务包调用 |
| `comment` | 合同评论：CRUD、@ 通知触发 |
| `oprecord` | 合同操作记录：写入、查询、按维度筛选 |
| `common` | service 层最小工具集（当前仅 `reviewer_utils.go`） |
| `supply` | 供应链/供货相关的业务侧封装（历史领域包，仅当明确该领域需求时使用） |
| `thirdservice` | 三方系统对接的业务侧封装（历史领域包） |

## 2. 归属决策规则

1. **是"参数或业务规则的通用校验"（合同号格式、金额边界、必填组合）？** → `validate`。
2. **是评论 CRUD？** → `comment`。
3. **是操作记录写入 / 查询？** → `oprecord`。**任何**业务动作（审批通过、评审人替换、字段修改）**必须**通过 `oprecord.Append(...)` 记录。
4. **是"只在 2 个及以上业务包共用、又不构成子域"的纯函数？** → `common`；否则回到本业务包或考虑升到 `pkg/util`。
5. **供应/供货领域？** → `supply`；否则**不要**乱塞。
6. **对接了新的三方系统？** → 优先考虑 `pkg/proxy/<xxxcli>` 做 SDK 封装，**业务侧**包装才放 `thirdservice`。

## 3. 文件命名硬规则

`validate`：

- 一个校验主题一个文件：`validate_<对象或规则>.go`。
- 内部只写纯函数：`Validate<对象>(req) error`；**禁止**在校验器里发通知 / 落库。

`comment`：

- 一个 CRUD 动作一个文件：`create.go` / `list.go` / `delete.go`。
- @ 触发通知走 `notify.Send`，禁止在本包直接调飞书 SDK。

`oprecord`：

- 一个记录类型一个文件：`append_<动作>.go` / `query_<维度>.go`。
- 记录模型放 `model.go`。**禁止**把状态枚举放本包，统一在 `pkg/const`。

`common`：

- 严格**只放跨业务包共用**的纯函数。当前只有 `reviewer_utils.go`；新增前应检查是否更适合放 `support/`。
- 单个文件函数量 > 5 或长度 > 400 行，必须拆到 `common_<主题>.go` 或提到 `support/`。

`supply` / `thirdservice`：

- 沿用 8 类文件模板。**禁止**新增杂项能力，只承接明确领域。

## 4. 跨包调用约束

- `validate` 无外部依赖（除 `pkg/const` / `pkg/errors`）；不允许 import 业务包。
- `comment` / `oprecord` 允许被任何业务包 import；`comment` 可 import `notify`，反向禁止。
- `common` 只允许被 `biz/service/*` import；不允许 `pkg/` 反向使用。
- `supply` / `thirdservice` 遵循业务包一般规则。

## 5. AI 硬性禁止

- 禁止在业务包内实现"手写正则校验合同号"——**必须**调用 `validate` 中的现成函数或新增函数。
- 禁止不写 `oprecord` 就完成状态类变更（审批、退回、评审人切换等）；缺失操作记录视为 bug。
- 禁止把"用户友好错误文案"塞进 `validate`，那属于 `multienv/i18nfmt` 或 `pkg/errors`。
- 禁止扩大 `common/` 的边界；每次向 `common/` 加代码都要审视"是否更该放 `support/` 或 `pkg/util`"。
- 禁止在 `thirdservice` 内堆积多个不相关的三方系统；每个三方系统的业务侧封装应各自一个包或每个系统一个文件（同一包内）。

## 6. 常见错误摆位纠正

| 错误做法 | 正确归属 |
| --- | --- |
| 在 `salescontract/common.go` 写"合同金额校验" | `validate/validate_amount.go`（若跨包用） |
| 在 `auditx/handler/xxx.go` 写"审批日志文案 + 落库" | `oprecord/append_audit.go` + `notify.Send` |
| 在 `common/` 加一个只被 `workflow` 用的辅助函数 | 移回 `workflow/common.go` |
| 在业务包内直接调用某三方 API | `pkg/proxy/<xxxcli>` + `thirdservice` 业务侧封装 |

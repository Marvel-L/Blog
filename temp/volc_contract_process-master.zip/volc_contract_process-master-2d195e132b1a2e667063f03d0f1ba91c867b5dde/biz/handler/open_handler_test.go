package handler

import (
	"context"
	"testing"
	"volc_contract_process/biz/service/fresh_seal"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/workflow"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func Test_OpenContract_List(t *testing.T) {
	t.Run("case List#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()
			freshSealService := fresh_seal.NewFreshSealApprovalService()

			listBizMethod := mockey.GetMethod(metaService, "ListBiz")
			mockey.Mock(listBizMethod).Return(&bizmodels.MetaListResp{
				List: []*bizmodels.ContractMetaItem{
					{
						Status: 12,
					},
				},
			}, nil).Build()

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				m, ok := obj.(*bizmodels.BizContractListParam)
				if ok {
					m.Scene = _const.ScenePayOnBehalf
				}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			defer mockey.UnPatchAll()

			// Act
			v := &openBizContractHandler{
				metaService:      metaService,
				freshSealService: freshSealService,
			}
			v.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{
				AccountID:     1111,
				Scene:         _const.ScenePayOnBehalf,
				Status:        "15",
				ValidityBegin: 176888888,
				ValidityEnd:   176888888,
			})

		})
	})
}

func Test_OpenContract_GetContractSignURL(t *testing.T) {
	t.Run("case GetContractSignURL#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()
			bizContractService := service.NewBizContractService()
			querySignUrlMethod := mockey.GetMethod(metaService, "QuerySignUrl")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(querySignUrlMethod).Return("", nil).Build()

			// Act
			v := &openBizContractHandler{
				bizContractService: bizContractService,
				metaService:        metaService,
			}
			v.GetContractSignURL20210101(context.Background(), &app.RequestContext{})

		})
	})
	t.Run("case GetContractSignURL#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()
			bizContractService := service.NewBizContractService()
			querySignUrlMethod := mockey.GetMethod(metaService, "QuerySignUrl")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				m, ok := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				if ok {
					m.BizScene = _const.BizScenePayOnBehalf
				}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(querySignUrlMethod).Return("", nil).Build()

			// Act
			v := &openBizContractHandler{
				bizContractService: bizContractService,
				metaService:        metaService,
			}
			v.GetContractSignURL20210101(context.Background(), &app.RequestContext{})

		})
	})
}

func Test_OpenContract_SubmitBizDraft(t *testing.T) {
	t.Run("case SubmitBizDraft#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()

			submitMethod := mockey.GetMethod(bizService, "Submit")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(submitMethod).Return(nil, errors.ErrInternalError).Build()

			// Act
			v := &openBizContractHandler{}
			v.SubmitBizDraft20210101(context.Background(), &app.RequestContext{})

		})
	})
}

func Test_OpenContract_CreateContractMetaBizDraft(t *testing.T) {
	t.Run("case CreateContractMetaBizDraft#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()

			createOrUpdateBizDraftMethod := mockey.GetMethod(bizService, "CreateOrUpdateBizDraft")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(createOrUpdateBizDraftMethod).Return(nil, errors.ErrInternalError).Build()

			// Act
			v := &openBizContractHandler{}
			v.CreateContractMetaBizDraft20210101(context.Background(), &app.RequestContext{})

			v.UpdateBizDraft20210101(context.Background(), &app.RequestContext{})

		})
	})
}

func Test_OpenContract_GetBizDetail(t *testing.T) {
	t.Run("case GetBizDetail#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()

			metaDetailMethod := mockey.GetMethod(metaService, "MetaDetail")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(metaDetailMethod).Return(nil, errors.ErrInternalError).Build()

			// Act
			v := &openBizContractHandler{
				metaService: metaService,
			}
			v.CreateContractMetaBizDraft20210101(context.Background(), &app.RequestContext{})

			v.UpdateBizDraft20210101(context.Background(), &app.RequestContext{})

		})
	})
}

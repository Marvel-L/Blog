package handler

import (
	"context"
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
	"time"

	"volc_contract_process/pkg/util"

	"code.byted.org/gopkg/logid"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metabasic"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/bizmodels/modelsthird"
	"volc_contract_process/biz/dal"
	audithandler "volc_contract_process/biz/service/auditx/handler"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/coupon"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/quote"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/biz/service/workflow"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/c360cli"
	"volc_contract_process/pkg/proxy/rediscli"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
)

type innerVCMetaHandler struct {
	base
	metaService       contractmeta.MetaService
	metaServiceV2     contractmeta.MetaServiceV2
	opRecordService   cooperationrecord.Service
	couponRuleService coupon.CouponRuleService
}

func NewInnerVCMetaHandler() vhertz.ActionHandler {
	return &innerVCMetaHandler{
		metaService:       contractmeta.NewMetaService(),
		metaServiceV2:     contractmeta.NewMetaServiceV2(),
		opRecordService:   cooperationrecord.NewService(),
		couponRuleService: coupon.NewCouponRuleService(),
	}
}

func (h *innerVCMetaHandler) adaptInnerListParam(ctx context.Context, c *app.RequestContext, param *bizmodels.MetaListParam) errors.APIError {
	var innerPageParam bizmodels.InnerPageParam
	if err := binding.BindAndValidate(c, &innerPageParam); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, InnerPageParam, err: %s", err.Error())
		return errors.ErrParamParseFail
	}
	if innerPageParam.Limit > 0 {
		param.Limit = innerPageParam.Limit
	}
	if innerPageParam.Offset > 0 {
		param.Offset = innerPageParam.Offset
	}
	// 兼容 默认值
	if param.Limit == 0 {
		param.Limit = 10
	}
	return nil
}

func (h *innerVCMetaHandler) List20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := h.adaptInnerListParam(ctx, c, &param); err != nil {
		logs.CtxError(ctx, "adaptInnerListParamFail, InnerPageParam, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	logs.CtxInfo(ctx, "[innerVCMetaHandler]ListParam, limit=%d, offset=%d", param.Limit, param.Offset)

	param.SourceType = _const.SourceTypeInner
	param.NeedCalcCooperationRole = true
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	innerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if innerUserInfo != nil {
		param.CurrentOperatorUID = innerUserInfo.EmployeeID
	} else {
		// 作为监控标识，当前该接口只会从费用中心发起，理论上都会有值。
		logs.CtxError(ctx, "InnerList_InnerUserInfoIsNil")
	}

	ret, err := h.metaService.ListBiz(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// MetaList20210101 用于解决 action 命名冲突，内部复用 List20210101
func (h *innerVCMetaHandler) MetaList20210101(ctx context.Context, c *app.RequestContext) {
	h.List20210101(ctx, c)
}

func (h *innerVCMetaHandler) ListExport20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}
	// 导出时需要查询管理信息
	param.UseManageInfo = true
	param.UseProjectInfo = true

	// 方法调用
	go h.metaService.Export(ctx, &param)

	vhertz.DoResponse(ctx, c, nil)

}

func (h *innerVCMetaHandler) Detail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaDetailReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	ret, err := h.metaService.Detail(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// MetaDetail20210101 用于解决 action 命名冲突，内部复用 Detail20210101
func (h *innerVCMetaHandler) MetaDetail20210101(ctx context.Context, c *app.RequestContext) {
	h.Detail20210101(ctx, c)
}

// ProcessList20210101 协作流程定义
func (h *innerVCMetaHandler) ProcessList20210101(ctx context.Context, c *app.RequestContext) {
	vhertz.DoResponse(ctx, c, map[string]interface{}{})
}

// RecordList20210101 协作记录列表
func (h *innerVCMetaHandler) RecordList20210101(ctx context.Context, c *app.RequestContext) {
	vhertz.DoResponse(ctx, c, map[string]interface{}{})
}

func (h *innerVCMetaHandler) DownloadAttachment20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaAttachmentDownloadParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaDownloadAttachmentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	fileData, _, filename, err := h.metaService.Download(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if len(fileData) == 0 {
		logs.CtxError(ctx, "DownloadBizContractFail, fileDataEmpty")
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", fileData)
}

// CustomAuditBizContract20210101 客户确认：接受 or 拒绝
func (h *innerVCMetaHandler) CustomAuditBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractCustomerAuditParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractCustomerAuditParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch param.BizScene {
	case _const.BizSceneQuoteContract:
		tt = workflow.TaskTypeQuoteCustomerAudit
	case _const.BizSceneCreditContract:
		tt = workflow.TaskTypeCreditCustomerAudit
	case _const.BizScenePartnerContract:
		tt = workflow.TaskTypePartnerCustomerAudit
	default:
		logs.CtxError(ctx, "OpenContractMetaBizCustomerAuditUnsupportedBizScene, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizScene[%d]", param.BizScene)))
		return
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &param,
	}

	resp, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizHandlerCustomerAuditFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// AbandonBizContract20210101 作废合同：仅允许作废草稿
func (h *innerVCMetaHandler) AbandonBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractAbandonParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractAbandonParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.AbandonBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "AbandonBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)

}

// AbortBizContract20210101 终止合同
func (h *innerVCMetaHandler) AbortBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractAbortParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractAbandonParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.AbortBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "AbandonBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)

}

// RevokeBizContract20210101 撤销合同
func (h *innerVCMetaHandler) RevokeBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractRevokeParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractRevokeParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.RevokeBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "RevokeBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Success": true,
		"Message": "撤销成功",
	})

}

func (h *innerVCMetaHandler) CheckLadderQuoteContractClash20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.CheckLadderQuoteContractClashReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 查询重复项
	resp, err := h.metaService.CheckLadderQuoteContractClash(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerVCMetaHandler) GetFeishuViewUrl20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	creator := c.Query("Creator")
	// 参数校验
	if len(creator) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Creator"))
		return
	}

	// 查询重复项
	viewUrl, err := h.metaService.QueryFeishuViewUrl(ctx, contractNo, creator)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, viewUrl)
}

func (h *innerVCMetaHandler) SearchOpportunity20210101(ctx context.Context, c *app.RequestContext) {

	var param opportunity.SfSearchOpportunityByAccountIdentityRequest
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "SearchOpportunityBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 查询重复项
	opportunitys, err := c360cli.SearchOpportunity(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, opportunitys)
}

// SearchAccountIndustryByCustomerName20210101 查询客户一级行业线
func (h *innerVCMetaHandler) SearchAccountIndustryByCustomerName20210101(ctx context.Context, c *app.RequestContext) {

	var param modelsthird.SearchAccountIndustryByCustomerNameReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "SearchAccountIndustryByCustomerNameBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if param.CustomerName == "" {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CustomerName"))
		return
	}

	industry, err := c360cli.SearchAccountIndustryByCustomerName(ctx, param.CustomerName)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, industry)
}

func (h *innerVCMetaHandler) GetContractRedirectInfo20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	operatorEmail := fetchEmployeeEmail(ctx)
	if len(operatorEmail) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("OperatorEmail"))
		return
	}

	req := &bizmodels.GetContractRedirectInfoReq{
		ContractNo:    contractNo,
		OperatorEmail: operatorEmail,
	}

	resp, err := h.metaService.GetContractRedirectInfo(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerVCMetaHandler) ListOperationRecord20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	// 查询重复项
	opRecords, err := h.opRecordService.ListByContractNo(ctx, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"List": opRecords,
	})
}

// GetEffectiveSubjectMap20210101 获取可使用我方主体列表
func (h *innerVCMetaHandler) GetEffectiveSubjectMap20210101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.GetEffectiveSubjectMapReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 查询重复项
	res, err := h.metaServiceV2.GetEffectiveSubjectMap(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// CheckRelateSubjectParty20210101 校验关联主体与我方主体关系
func (h *innerVCMetaHandler) CheckRelateSubjectParty20210101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.CheckRelateSubjectPartyReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 查询重复项
	err := h.metaServiceV2.CheckRelateSubjectParty(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// CheckCurrencyAndExchangeRate20210101 校验币种、汇率信息是否一致
func (h *innerVCMetaHandler) CheckCurrencyAndExchangeRate20210101(ctx context.Context, c *app.RequestContext) {

	var param metabasic.CheckCurrencyAndExchangeRateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 查询重复项
	res, err := basicinfo.CheckCurrencyAndExchangeRate(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}
	vhertz.DoResponse(ctx, c, res)
}

// GetQuoteFormInstanceUrl20210101 获取合同附加信息
func (h *innerVCMetaHandler) GetQuoteFormInstanceUrl20210101(ctx context.Context, c *app.RequestContext) {

	quoteID := c.Query("QuoteID")

	url, err := quote.NewQuoteService().GetQuoteFormInstanceUrl(ctx, quoteID)
	if err != nil {
		logs.CtxError(ctx, "GetQuoteFormInstanceUrlFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("GetQuoteFormInstanceUrlFail"))
		return
	}
	vhertz.DoResponse(ctx, c, url)
}

// UpdateUrgentInfo20210101 更新加急信息
func (h *innerVCMetaHandler) UpdateUrgentInfo20210101(ctx context.Context, c *app.RequestContext) {

	var param metasupport.UpdateUrgentInfoReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "UpdateUrgentInfoReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	innerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if innerUserInfo != nil {
		param.CurrentOperator = innerUserInfo.EmployeeEmail
	} else {
		// 作为监控标识，当前该接口只会从费用中心发起，理论上都会有值。
		logs.CtxError(ctx, "InnerList_InnerUserInfoIsNil")
	}
	if apiErr := param.Validate(); apiErr != nil {
		logs.CtxError(ctx, "UpdateUrgentInfoReqValidateFail, err: %s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}
	// 更新加急信息
	err := h.metaServiceV2.UpdateUrgentInfo(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"ContractNo": param.ContractNo,
	})
}

// GetUrgentInfo20210101 获取加急信息
func (h *innerVCMetaHandler) GetUrgentInfo20210101(ctx context.Context, c *app.RequestContext) {

	var param metasupport.GetUrgentInfoReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetUrgentInfoReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	innerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if innerUserInfo != nil {
		param.CurrentOperator = innerUserInfo.EmployeeEmail
	} else {
		// 作为监控标识，当前该接口只会从费用中心发起，理论上都会有值。
		logs.CtxError(ctx, "InnerList_InnerUserInfoIsNil")
	}
	if apiErr := param.Validate(); apiErr != nil {
		logs.CtxError(ctx, "GetUrgentInfoReqValidateFail, err: %s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}
	// 更新加急信息
	urgentInfo, err := h.metaServiceV2.GetUrgentInfo(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, urgentInfo)
}

// BatchDownloadMetaAttachment20210101 批量下载合同附件
func (h *innerVCMetaHandler) BatchDownloadMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaBatchAttachmentDownloadParam
	// 操作员信息
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BatchDownloadMetaAttachmentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 解析DownloadIDs以确定是单文件还是多文件下载
	downloadIDs := util.StringToUniqueTrimmedSlice(param.DownloadIDs)
	// 检查是否有可下载的文件
	if len(downloadIDs) == 0 {
		logs.CtxError(ctx, "BatchDownloadMetaAttachmentNoDownloadableFiles, DownloadIDs=%s", param.DownloadIDs)
		vhertz.ErrorResp(ctx, c, errors.ErrNoDownloadableFiles)
		return
	}
	// 检查文件数量限制
	if err := contractmeta.ValidateBatchDownloadFileCount(ctx, len(downloadIDs)); err != nil {
		logs.CtxError(ctx, "BatchDownloadMetaAttachmentFileCountExceeded, count=%d, err=%v", len(downloadIDs), err)
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 按照操作人、合同号和downloadIDs维度获取分布式锁
	redisLock, lockKey, lockSuccess := h.acquireDownloadLocks(ctx, param.CurrentOperator, param.ContractNo, downloadIDs)
	if !lockSuccess {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "正在下载请稍后")))
		return
	}

	// 确保在函数退出时释放锁
	defer h.releaseDownloadLocks(ctx, redisLock, lockKey)

	// 单文件下载时
	if len(downloadIDs) == 1 {
		downloadAttachmentCore(ctx, h.metaService, &bizmodels.MetaAttachmentDownloadParam{
			DownloadID:      downloadIDs[0],
			CurrentOperator: param.CurrentOperator,
		}, c)
		return
	}

	// 处理多文件下载
	h.handleMultiFileDownload(ctx, &param, c)
}

// handleMultiFileDownload 处理多文件下载
func (h *innerVCMetaHandler) handleMultiFileDownload(ctx context.Context, param *bizmodels.MetaBatchAttachmentDownloadParam, c *app.RequestContext) {

	tpl := contractmeta.BatchDownloadFilenameFormat
	filename := fmt.Sprintf(tpl, "", "")
	if param.ContractNo != "" {
		// 使用合同信息生成ZIP文件名
		meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, param.ContractNo)
		if err != nil {
			logs.CtxError(ctx, "batch_download_filename_meta_query_fail, contractNo=%s, err=%v", param.ContractNo, err)
			vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
			return
		}
		if meta == nil {
			logs.CtxError(ctx, "batch_download_filename_meta_not_found, contractNo=%s", param.ContractNo)
			vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
			return
		}
		filename = fmt.Sprintf(tpl, util.SanitizeString(param.ContractNo), util.SanitizeString(meta.ContractName))
	}

	// 设置多文件下载响应头
	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/zip")
	c.Response.Header.Set("Transfer-Encoding", "chunked")
	c.SetStatusCode(200)

	// 将响应 writer 传递给服务层，进行流式压缩与输出
	_, err := h.metaService.BatchDownload(ctx, param, c.Response.BodyWriter(), filename)
	if err != nil {
		// 流式场景下这里不再写入 JSON 错误到响应体，避免破坏已开始的输出
		logs.CtxError(ctx, "BatchDownloadMetaAttachmentFail, err: %s", err.Error())
		return
	}
}

// downloadAttachmentCore 单文件下载
func downloadAttachmentCore(ctx context.Context, metaService contractmeta.MetaService, param *bizmodels.MetaAttachmentDownloadParam, c *app.RequestContext) {
	fileData, _, filename, err := metaService.Download(ctx, param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if len(fileData) == 0 {
		logs.CtxError(ctx, "DownloadBizContractFail, fileDataEmpty")
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", fileData)
}

// acquireDownloadLocks 按照操作人、合同号和downloadIDs维度获取分布式锁
func (h *innerVCMetaHandler) acquireDownloadLocks(ctx context.Context, operator string, contractNo string, downloadIDs []string) (*rediscli.RedisLock, string, bool) {

	// 创建一个稳定且长度可控的锁键，包含操作人、合同号以及downloadIDs的哈希
	sort.Strings(downloadIDs)
	raw := strings.Join(downloadIDs, ",")
	sum := sha256.Sum256([]byte(raw))

	lockKey := fmt.Sprintf("vcp:contractmeta:batch_download:%s:%s:%x", operator, contractNo, sum)

	// 创建Redis分布式锁
	logID, _ := logid.GetLogIDFromCtx(ctx)
	redisLock := &rediscli.RedisLock{
		LockKey: lockKey,
		Value:   fmt.Sprintf("%s_%d", logID, time.Now().UnixNano()),
		Timeout: 5 * time.Minute,
	}

	// 获取锁
	if err := redisLock.Lock(); err != nil {
		logs.CtxError(ctx, "Failed to acquire distributed lock for key: %s, err: %v", lockKey, err)
		return nil, "", false
	}
	logs.CtxInfo(ctx, "Acquired distributed lock for key: %s", lockKey)

	return redisLock, lockKey, true
}

// releaseDownloadLocks 释放分布式锁
func (h *innerVCMetaHandler) releaseDownloadLocks(ctx context.Context, redisLock *rediscli.RedisLock, lockKey string) {
	redisLock.Unlock()
	logs.CtxInfo(ctx, "Released distributed lock for key: %s", lockKey)
}

// EditExternalCommodityList20210101 编辑外部报价项
// @ID /vcc/inner-api/meta@EditExternalCommodityList20210101
// @Router /vcc/inner-api/meta/Action_EditExternalCommodityList_Version_20210101 [post]
func (h *innerVCMetaHandler) EditExternalCommodityList20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.EditExternalCommodityListReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "EditExternalCommodityListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if apiErr := param.Validate(); apiErr != nil {
		logs.CtxError(ctx, "EditExternalCommodityListReqValidateFail, err: %s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}

	err := audithandler.EditExternalCommodityList(ctx, nil, param.ContractNo, param.CommodityList, param.IsSplitProduct)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"ContractNo": param.ContractNo,
	})
}

// ExportCouponConfig20210101 导出“返券规则”
func (h *innerVCMetaHandler) ExportCouponConfig20210101(ctx context.Context, c *app.RequestContext) {

	var req metasupport.ExportCouponConfigReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ExportCouponConfigReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if len(req.CurrentOperator) == 0 {
		req.CurrentOperator = queryOperator(ctx)
	}

	if apiErr := req.Validate(); apiErr != nil {
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}
	// 异步执行导出任务
	go func() {
		if apiErr := h.couponRuleService.ExportCouponRule(ctx, &req); apiErr != nil {
			logs.CtxError(ctx, "ExportCouponRuleFail, err:%v", apiErr)
		}
	}()

	vhertz.DoResponse(ctx, c, "success")
}

// CustomAuditBizContractInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 CustomAuditBizContract20210101
func (h *innerVCMetaHandler) CustomAuditBizContractInner20210101(ctx context.Context, c *app.RequestContext) {
	h.CustomAuditBizContract20210101(ctx, c)
}

// CheckLadderQuoteContractClashInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 CheckLadderQuoteContractClash20210101
func (h *innerVCMetaHandler) CheckLadderQuoteContractClashInner20210101(ctx context.Context, c *app.RequestContext) {
	h.CheckLadderQuoteContractClash20210101(ctx, c)
}

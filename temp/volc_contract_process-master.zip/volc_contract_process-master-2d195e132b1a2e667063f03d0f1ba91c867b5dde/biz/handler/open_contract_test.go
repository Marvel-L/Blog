package handler

import (
	"code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/service/accountmanagement"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/volcengine"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"encoding/json"
	errors001 "errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"net/http"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"
	metaattachmodel "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/fresh_seal"
	metaattachservice "volc_contract_process/biz/service/metaattach"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/support/verifychange"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/biz/service/workflow"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
	"volc_contract_process/pkg/proxy/mdcli"
)

type fakeOpenBizContractService struct {
	service.BizContractService
	listFn     func(context.Context, *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError)
	downloadFn func(context.Context, *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError)
}

func (f *fakeOpenBizContractService) List(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
	if f.listFn != nil {
		return f.listFn(ctx, param)
	}
	return &bizmodels.BizContractListResp{List: []*bizmodels.BizContract{{ContractNo: "C-1"}}, Total: 1, Limit: param.Limit, Offset: param.Offset}, nil
}

func (f *fakeOpenBizContractService) Download(ctx context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError) {
	if f.downloadFn != nil {
		return f.downloadFn(ctx, param)
	}
	return []byte("contract-data"), "contract.pdf", nil
}

type fakeOpenMetaService struct {
	contractmeta.MetaService
	listBizFn     func(context.Context, *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError)
	downloadBizFn func(context.Context, *bizmodels.MetaBizAttachmentDownloadParam) ([]byte, string, string, errors.APIError)
	querySignFn   func(context.Context, string, string) (string, errors.APIError)
}

func (f *fakeOpenMetaService) ListBiz(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
	if f.listBizFn != nil {
		return f.listBizFn(ctx, param)
	}
	return &bizmodels.MetaListResp{List: []*bizmodels.ContractMetaItem{{ContractNo: "C-1", BizScene: _const.BizSceneQuoteContract, BizAccountID: 123, SealAccountIDs: "123"}}, Total: 1, Limit: param.Limit, Offset: param.Offset}, nil
}

func (f *fakeOpenMetaService) DownloadBiz(ctx context.Context, param *bizmodels.MetaBizAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
	if f.downloadBizFn != nil {
		return f.downloadBizFn(ctx, param)
	}
	return []byte("meta-data"), "file-id", "meta.pdf", nil
}

func (f *fakeOpenMetaService) QuerySignUrl(ctx context.Context, contractNo string, accountID string) (string, errors.APIError) {
	if f.querySignFn != nil {
		return f.querySignFn(ctx, contractNo, accountID)
	}
	return "https://sign.example.com", nil
}

type fakeOpenFreshSealService struct {
	fresh_seal.FreshSealApprovalService
	canApplyFn func(context.Context, int, string, string, string, int) (bool, []string)
}

func (f *fakeOpenFreshSealService) CanApplyFreshSeal(ctx context.Context, archivedStatus int, freshSealApprovalNo string, sealAccountIDs string, accountId string, activeStatus int) (bool, []string) {
	if f.canApplyFn != nil {
		return f.canApplyFn(ctx, archivedStatus, freshSealApprovalNo, sealAccountIDs, accountId, activeStatus)
	}
	return true, nil
}

func TestOpenBizContractHandlerList20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			(&openBizContractHandler{}).List20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("普通业务场景调用老合同列表服务", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotSource _const.SourceType
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractListParam)
				param.Scene = 99
				param.AccountID = 100
				param.Limit = 10
				return nil
			}).Build()

			h := &openBizContractHandler{bizContractService: &fakeOpenBizContractService{listFn: func(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
				gotSource = param.SourceType
				return &bizmodels.BizContractListResp{List: []*bizmodels.BizContract{{ContractNo: "OLD-1"}}, Total: 1, Limit: param.Limit}, nil
			}}}
			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(gotSource, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body.(*bizmodels.BizContractListResp).List[0].ContractNo, convey.ShouldEqual, "OLD-1")
		})
	})

	t.Run("普通业务场景服务错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("old list")
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractListParam)
				param.Scene = 99
				param.AccountID = 100
				return nil
			}).Build()

			h := &openBizContractHandler{bizContractService: &fakeOpenBizContractService{listFn: func(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
				return nil, serviceErr
			}}}
			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("迁移场景路由到 listMeta", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			calledOldService := false
			calledMetaService := false
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractListParam)
				param.Scene = _const.SceneQuoteContract
				param.AccountID = 100
				param.Status = "1"
				return nil
			}).Build()

			h := &openBizContractHandler{
				bizContractService: &fakeOpenBizContractService{listFn: func(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
					calledOldService = true
					return nil, nil
				}},
				metaService: &fakeOpenMetaService{listBizFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
					calledMetaService = true
					convey.So(param.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
					convey.So(param.BizScene, convey.ShouldEqual, _const.BizSceneQuoteContract)
					return &bizmodels.MetaListResp{}, nil
				}},
				freshSealService: &fakeOpenFreshSealService{},
			}
			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(calledOldService, convey.ShouldBeFalse)
			convey.So(calledMetaService, convey.ShouldBeTrue)
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
		})
	})
}

func TestOpenBizContractHandlerListMeta(t *testing.T) {
	t.Run("代付场景缺少 AccountID 返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{}, freshSealService: &fakeOpenFreshSealService{}}

			h.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{SourceType: _const.SourceTypeOpen, Scene: _const.ScenePayOnBehalf})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("不支持的场景返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{}, freshSealService: &fakeOpenFreshSealService{}}

			h.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{SourceType: _const.SourceTypeOpen, Scene: 999})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("服务错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("list meta")
			h := &openBizContractHandler{
				metaService: &fakeOpenMetaService{listBizFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
					return nil, serviceErr
				}},
				freshSealService: &fakeOpenFreshSealService{},
			}

			h.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{SourceType: _const.SourceTypeOpen, Scene: _const.SceneQuoteContract, AccountID: 100})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时转换查询参数和响应列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotParam *bizmodels.MetaListParam
			h := &openBizContractHandler{
				metaService: &fakeOpenMetaService{listBizFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
					gotParam = param
					return &bizmodels.MetaListResp{List: []*bizmodels.ContractMetaItem{{ContractNo: "C-1", BizScene: _const.BizSceneQuoteContract, BizIdentifier: "B-1", BizAccountID: 100, SealAccountIDs: "100", Creator: 200}}, Total: 1, Limit: param.Limit, Offset: param.Offset}, nil
				}},
				freshSealService: &fakeOpenFreshSealService{},
			}

			h.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{SourceType: _const.SourceTypeOpen, Scene: _const.SceneQuoteContract, AccountID: 100, Status: "1,invalid", ContractNo: "C", Limit: 20, Offset: 3, CreateTimeBegin: 1704067200})

			convey.So(gotParam, convey.ShouldNotBeNil)
			convey.So(gotParam.BizScene, convey.ShouldEqual, _const.BizSceneQuoteContract)
			convey.So(gotParam.BizAccountID, convey.ShouldEqual, 100)
			convey.So(gotParam.CreatedTimeBegin, convey.ShouldEqual, "2024-01-01 08:00:00")
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body.(*bizmodels.BizContractListResp).List[0].ContractNo, convey.ShouldEqual, "C-1")
		})
	})

	t.Run("代付场景成功转换复合状态", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotParam *bizmodels.MetaListParam
			h := &openBizContractHandler{
				metaService: &fakeOpenMetaService{listBizFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
					gotParam = param
					return &bizmodels.MetaListResp{List: []*bizmodels.ContractMetaItem{{ContractNo: "P-1", BizScene: _const.BizScenePayOnBehalf, BizIdentifier: "PB-1", BizAccountID: 100, SealAccountIDs: "100", Creator: 200}}, Total: 1}, nil
				}},
				freshSealService: &fakeOpenFreshSealService{},
			}

			h.listMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractListParam{SourceType: _const.SourceTypeOpen, Scene: _const.ScenePayOnBehalf, AccountID: 100, Status: "1", CreateTimeEnd: 1704067200, ValidityBegin: 1704067200, ValidityEnd: 1704067200})

			convey.So(gotParam, convey.ShouldNotBeNil)
			convey.So(gotParam.BizScene, convey.ShouldEqual, _const.BizScenePayOnBehalf)
			convey.So(gotParam.CreatedTimeEnd, convey.ShouldEqual, "2024-01-01 08:00:00")
			convey.So(gotParam.ValidityBegin, convey.ShouldEqual, "2024-01-01 08:00:00")
			convey.So(gotParam.ValidityEnd, convey.ShouldEqual, "2024-01-01 08:00:00")
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestOpenBizContractHandlerConvertStatus(t *testing.T) {
	mockey.PatchConvey("状态映射转换", t, func() {
		h := &openBizContractHandler{}
		convey.So(h.convertCoStatus(context.Background(), 999, 88), convey.ShouldEqual, 88)
		convey.So(h.convertActiveStatus(context.Background(), 999, 77), convey.ShouldEqual, 77)
		convey.So(h.convertCoStatus(context.Background(), _const.BizSceneQuoteContract, 1), convey.ShouldEqual, _const.BizContractCoStatusMappings[1])
		convey.So(h.convertActiveStatus(context.Background(), _const.BizSceneQuoteContract, 1), convey.ShouldEqual, _const.BizContractActiveStatusMappings[1])
	})
}

func TestOpenBizContractHandlerDownload20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			(&openBizContractHandler{}).Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("查询合同失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, errors001.New("db fail")).Build()

			(&openBizContractHandler{}).Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("合同不存在返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return((*model.ContractMetaDB)(nil), nil).Build()

			(&openBizContractHandler{}).Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("账号无权限返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{SubjectAccountIds: "200,300"}, nil).Build()

			(&openBizContractHandler{}).Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("非销售合同通过 metaService 下载", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{BizScene: _const.BizSceneQuoteContract, ContractNo: "C-1", BizIdentifier: "B-1", SubjectAccountIds: "100,200"}, nil).Build()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{downloadBizFn: func(ctx context.Context, param *bizmodels.MetaBizAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				convey.So(param.BizScene, convey.ShouldEqual, _const.BizSceneQuoteContract)
				convey.So(param.BizIdentifier, convey.ShouldEqual, "B-1")
				return []byte("meta-body"), "fid", "meta.pdf", nil
			}}}
			c := &app.RequestContext{}

			h.Download20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "meta-body")
		})
	})

	t.Run("代付合同下载时传递合同号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "P-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{BizScene: _const.BizScenePayOnBehalf, ContractNo: "P-1", BizIdentifier: "PB-1", SubjectAccountIds: "100"}, nil).Build()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{downloadBizFn: func(ctx context.Context, param *bizmodels.MetaBizAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				convey.So(param.ContractNo, convey.ShouldEqual, "P-1")
				return []byte("pay-body"), "fid", "pay.pdf", nil
			}}}
			c := &app.RequestContext{}

			h.Download20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "pay-body")
		})
	})

	t.Run("非销售合同下载失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{BizScene: _const.BizSceneQuoteContract, ContractNo: "C-1", BizIdentifier: "B-1", SubjectAccountIds: "100"}, nil).Build()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{downloadBizFn: func(ctx context.Context, param *bizmodels.MetaBizAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return nil, "", "", errors.ErrorCommon.WithArgs("download biz")
			}}}

			h.Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("销售合同通过 bizContractService 下载", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "S-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{BizScene: _const.BizSceneSalesContract, ContractNo: "S-1", SubjectAccountIds: "100"}, nil).Build()
			h := &openBizContractHandler{bizContractService: &fakeOpenBizContractService{downloadFn: func(ctx context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError) {
				return []byte("sales-body"), "sales.pdf", nil
			}}}
			c := &app.RequestContext{}

			h.Download20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "sales-body")
		})
	})

	t.Run("销售合同下载失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "S-1"
				param.AccountID = 100
				return nil
			}).Build()
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{BizScene: _const.BizSceneSalesContract, ContractNo: "S-1", SubjectAccountIds: "100"}, nil).Build()
			h := &openBizContractHandler{bizContractService: &fakeOpenBizContractService{downloadFn: func(ctx context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError) {
				return nil, "", errors.ErrorCommon.WithArgs("sales download")
			}}}

			h.Download20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
}

func TestOpenBizContractHandlerListCardType20210101(t *testing.T) {
	t.Run("缺少注册地返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe((*app.RequestContext).Query).Return("").Build()

			(&openBizContractHandler{}).ListCardType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("docType 非数字返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				if key == "RegistCountry" {
					return "CN"
				}
				return "bad"
			}).Build()

			(&openBizContractHandler{}).ListCardType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("查询证件类型失败返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				if key == "RegistCountry" {
					return "CN"
				}
				return "2"
			}).Build()
			mockey.Mock(mdcli.QueryCardType).Return(nil, errors001.New("md fail")).Build()

			(&openBizContractHandler{}).ListCardType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("查询证件类型成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := []*mdcli.CardTypeData{{Code: "ID", CountryCode: "CN", Name: "身份证"}}
			mockey.MockUnsafe((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				if key == "RegistCountry" {
					return "CN"
				}
				return "2"
			}).Build()
			mockey.Mock(mdcli.QueryCardType).Return(expected, nil).Build()

			(&openBizContractHandler{}).ListCardType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

func TestOpenBizContractHandlerCreateAndUpdateBizDraft20210101(t *testing.T) {
	t.Run("创建草稿绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("创建草稿业务场景非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*bizmodels.OpenBizContractMetaCreateParam).BizScene = _const.SceneQuoteContract
				return nil
			}).Build()

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("创建草稿鉴权失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				param.BizScene = _const.ScenePayOnBehalf
				param.AccountID = 100
				return nil
			}).Build()
			c := &app.RequestContext{}
			c.Request.Header.Set(_const.HeaderAccountID, "200")

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("创建草稿成功设置 IsUpdate=false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				param.BizScene = _const.ScenePayOnBehalf
				param.AccountID = 100
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizService, "CreateOrUpdateBizDraft")).To(func(ctx context.Context, param *bizmodels.OpenBizContractMetaCreateParam) (workflow.Result, errors.APIError) {
				convey.So(param.IsUpdate, convey.ShouldBeFalse)
				return &workflow.ResultMetaBizCreate{ContractNo: "C-1"}, nil
			}).Build()
			c := &app.RequestContext{}
			c.Request.Header.Set(_const.HeaderAccountID, "100")

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body.(*workflow.ResultMetaBizCreate).ContractNo, convey.ShouldEqual, "C-1")
		})
	})

	t.Run("更新草稿成功设置 IsUpdate=true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				param.BizScene = _const.ScenePayOnBehalf
				param.AccountID = 100
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizService, "CreateOrUpdateBizDraft")).To(func(ctx context.Context, param *bizmodels.OpenBizContractMetaCreateParam) (workflow.Result, errors.APIError) {
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				return &workflow.ResultMetaBizCreate{ContractNo: "C-2"}, nil
			}).Build()
			c := &app.RequestContext{}
			c.Request.Header.Set(_const.HeaderAccountID, "100")

			(&openBizContractHandler{}).UpdateBizDraft20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body.(*workflow.ResultMetaBizCreate).ContractNo, convey.ShouldEqual, "C-2")
		})
	})

	t.Run("创建草稿服务错误透传", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("draft")
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				param.BizScene = _const.ScenePayOnBehalf
				param.AccountID = 100
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizService, "CreateOrUpdateBizDraft")).Return(nil, serviceErr).Build()
			c := &app.RequestContext{}
			c.Request.Header.Set(_const.HeaderAccountID, "100")

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), c)

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("创建草稿返回空结果返回内部定义错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				param.BizScene = _const.ScenePayOnBehalf
				param.AccountID = 100
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizService, "CreateOrUpdateBizDraft")).Return(nil, nil).Build()
			c := &app.RequestContext{}
			c.Request.Header.Set(_const.HeaderAccountID, "100")

			(&openBizContractHandler{}).CreateContractMetaBizDraft20210101(context.Background(), c)

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalDefError.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
}

func TestOpenBizContractHandlerSubmitBizDraft20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			(&openBizContractHandler{}).SubmitBizDraft20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("提交失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("submit")
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizService, "Submit")).Return(nil, serviceErr).Build()

			(&openBizContractHandler{}).SubmitBizDraft20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("提交成功返回结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			result := &workflow.ResultMetaSubmitBizDraft{Success: true}
			bizService := workflow.NewBizService()
			mockey.Mock(workflow.NewBizService).Return(bizService).Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizService, "Submit")).Return(result, nil).Build()

			(&openBizContractHandler{}).SubmitBizDraft20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body, convey.ShouldResemble, result)
		})
	})
}

func TestOpenBizContractHandlerGetContractSignURL20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			(&openBizContractHandler{}).GetContractSignURL20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("非代付场景返回无效参数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*bizmodels.OpenBizContractGetSignURLParam).BizScene = _const.BizSceneQuoteContract
				return nil
			}).Build()

			(&openBizContractHandler{}).GetContractSignURL20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInvalidParam.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("查询签约链接失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("sign url")
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				param.BizScene = _const.BizScenePayOnBehalf
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{querySignFn: func(ctx context.Context, contractNo string, accountID string) (string, errors.APIError) {
				return "", serviceErr
			}}}

			h.GetContractSignURL20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("查询签约链接成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				param.BizScene = _const.BizScenePayOnBehalf
				param.ContractNo = "C-1"
				param.AccountID = 100
				return nil
			}).Build()
			h := &openBizContractHandler{metaService: &fakeOpenMetaService{querySignFn: func(ctx context.Context, contractNo string, accountID string) (string, errors.APIError) {
				convey.So(contractNo, convey.ShouldEqual, "C-1")
				convey.So(accountID, convey.ShouldEqual, "100")
				return "https://sign.example.com", nil
			}}}

			h.GetContractSignURL20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.body.(map[string]interface{})["SignURL"], convey.ShouldEqual, "https://sign.example.com")
		})
	})
}

func Test_openBizContractHandler_ListCertificationTemplate20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockListCertificationTemplate := mockey.GetMethod(templateService, "ListCertificationTemplate")
			mockey.Mock(mockListCertificationTemplate).Return([]*filetemplateclient.VolcTemplate{{}}, nil).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.ListCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case BindFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockListCertificationTemplate := mockey.GetMethod(templateService, "ListCertificationTemplate")
			mockey.Mock(mockListCertificationTemplate).Return([]*filetemplateclient.VolcTemplate{{}}, nil).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.ListCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case ListFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockListCertificationTemplate := mockey.GetMethod(templateService, "ListCertificationTemplate")
			mockey.Mock(mockListCertificationTemplate).Return([]*filetemplateclient.VolcTemplate{{}}, errors.ErrInternalDefError).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.ListCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
}

func Test_openBizContractHandler_DownLoadCertificationTemplate20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockDownLoadCertificationTemplate := mockey.GetMethod(templateService, "DownLoadCertificationTemplate")
			mockey.Mock(mockDownLoadCertificationTemplate).Return([]byte{}, "", nil).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.DownLoadCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case BindFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockDownLoadCertificationTemplate := mockey.GetMethod(templateService, "DownLoadCertificationTemplate")
			mockey.Mock(mockDownLoadCertificationTemplate).Return("", nil).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.DownLoadCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case downloadFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			templateService := template.NewService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(hertz.ErrorResp).Return().Build()
			mockDownLoadCertificationTemplate := mockey.GetMethod(templateService, "DownLoadCertificationTemplate")
			mockey.Mock(mockDownLoadCertificationTemplate).Return([]byte{}, "", errors.ErrInternalError).Build()
			mockey.Mock(hertz.DoResponse).Return().Build()

			// Act
			v := &openBizContractHandler{
				templateService: templateService,
			}
			v.DownLoadCertificationTemplate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
}

func Test_openBizContractHandler_Audit20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.BizContractAuditParam: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.BizContractAuditParam)) = bizmodels.BizContractAuditParam{
						Scene:      1,
						ContractNo: "ContractNo",
						AccountID:  222,
					}
				}
				return nil
			}).Build()

			findByBizIdentifierAdaptorMethod := mockey.GetMethod(metaDao, "FindByBizIdentifierAdaptor")
			mockey.Mock(findByBizIdentifierAdaptorMethod).Return(&model.ContractMetaDB{
				BizAccountID: 111,
			}, nil).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()

			var doResponse interface{}

			mockey.Mock(hertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			// Act
			v := &openBizContractHandler{}
			v.Audit20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(doResponse, convey.ShouldEqual, "不存在合同记录")
		})
	})
}

func Test_openBizContractHandler_GetBizDetail20210101(t *testing.T) {
	t.Run("case openBizContractHandler_GetBizDetail success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.MetaDetailReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.MetaDetailReq)) = bizmodels.MetaDetailReq{
						ContractNo: "ContractNo",
						AccountID:  222,
					}
				}
				return nil
			}).Build()

			metaDetailMethod := mockey.GetMethod(metaService, "MetaDetail")
			mockey.Mock(metaDetailMethod).Return(&bizmodels.ContractMetaInfo{
				BizAccountID: 111,
			}, nil).Build()

			var doResponse interface{}

			mockey.Mock(hertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			// Act
			v := &openBizContractHandler{
				metaService: metaService,
			}
			v.GetBizDetail20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
}

func Test_openBizContractHandler_i18nFormatListMeta(t *testing.T) {
	// Arrange
	v := &openBizContractHandler{}
	type args struct {
		ctx  context.Context
		list []*bizmodels.BizContract
	}
	tests := []struct {
		name  string
		args  args
		mocks func()
	}{
		{
			name: "case #1",
			args: args{
				ctx:  context.Background(),
				list: []*bizmodels.BizContract{},
			},
			mocks: func() {
				mockey.Mock(multienv.I18nSubFormat).Return("ss").Build()
			},
		},
		{
			name: "case #2",
			args: args{
				ctx: context.Background(),
				list: []*bizmodels.BizContract{
					{
						Remark:  "",
						BizInfo: "",
					},
				},
			},
			mocks: func() {
				mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
				mockey.Mock(multienv.I18nSubFormat).Return("ss").Build()
			},
		},
		{
			name: "case #3",
			args: args{
				ctx: context.Background(),
				list: []*bizmodels.BizContract{
					{
						Remark:  "",
						BizInfo: "",
					},
				},
			},
			mocks: func() {
				mockey.Mock(conf.GetGlobalConf).Return(
					&conf.GlobalConf{
						I18NSubFormatConf: &conf.I18NSubFormatConf{},
					}).Build()
				mockey.Mock(multienv.I18nSubFormat).Return("ss").Build()
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				v.i18nFormatListMeta(
					tt.args.ctx,
					tt.args.list,
				)

				// Assert
				convey.So("your code", convey.ShouldEqual, "your code")
			})
		})
	}
}

func Test_openBizContractHandler_formatListCertificationTemplate(t *testing.T) {
	// Arrange
	v := &openBizContractHandler{}
	type args struct {
		ctx  context.Context
		list []*filetemplateclient.VolcTemplate
	}
	tests := []struct {
		name  string
		args  args
		mocks func()
	}{
		{
			name: "case #1",
			args: args{
				ctx:  context.Background(),
				list: []*filetemplateclient.VolcTemplate{&filetemplateclient.VolcTemplate{}},
			},
			mocks: func() {
				mockey.Mock(multienv.I18nFormat).Return("").Build()
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				v.formatListCertificationTemplate(
					tt.args.ctx,
					tt.args.list,
				)

				// Assert
				convey.So("your code", convey.ShouldEqual, "your code")
			})
		})
	}
}

func Test_GetSignDataBySubjectNo20210101(t *testing.T) {
	mockey.PatchConvey("Test GetSignDataBySubjectNo20210101", t, func() {
		// Mock dependencies
		reqCtx := &app.RequestContext{}
		mockSubjectNo := "testSubjectNo"
		mockSubjectInfoMap := map[string]*conf.SubjectPartyInfo{
			mockSubjectNo: {
				PartyName:      "Test Party",
				ContactName:    "Test Contact",
				ContactPhone:   "1234567890",
				ContactAddress: "Test Address",
			},
		}

		mockey.PatchConvey("Test missing subjectNo", func() {
			mockey.Mock(mockey.GetMethod(reqCtx, "Query")).Return("").Build()
			h := &openBizContractHandler{}
			h.GetSignDataBySubjectNo20210101(context.Background(), reqCtx)
			// Assertions for missing subjectNo
			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test GetSubjectNo2SubjectInfoMap failed", func() {
			mockey.Mock(mockey.GetMethod(reqCtx, "Query")).Return(mockSubjectNo).Build()
			mockey.Mock(conf.GetSubjectNo2SubjectInfoMap).Return(nil).Build()
			h := &openBizContractHandler{}
			h.GetSignDataBySubjectNo20210101(context.Background(), reqCtx)
			// Assertions for failed GetSubjectNo2SubjectInfoMap
			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		})

		mockey.PatchConvey("Test subjectNo not found in subjectInfoMap", func() {
			mockey.Mock(mockey.GetMethod(reqCtx, "Query")).Return(mockSubjectNo).Build()
			mockey.Mock(conf.GetSubjectNo2SubjectInfoMap).Return(map[string]*conf.SubjectPartyInfo{}).Build()
			h := &openBizContractHandler{}
			h.GetSignDataBySubjectNo20210101(context.Background(), reqCtx)
			// Assertions for subjectNo not found
			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		})

		mockey.PatchConvey("Test successful retrieval of subjectInfo", func() {
			mockey.Mock(mockey.GetMethod(reqCtx, "Query")).Return(mockSubjectNo).Build()
			mockey.Mock(conf.GetSubjectNo2SubjectInfoMap).Return(mockSubjectInfoMap).Build()
			h := &openBizContractHandler{}
			h.GetSignDataBySubjectNo20210101(context.Background(), reqCtx)
			// Assertions for successful retrieval
			expectedBody, _ := json.Marshal(map[string]interface{}{
				"PartyName":      "Test Party",
				"ContactName":    "Test Contact",
				"ContactPhone":   "1234567890",
				"ContactAddress": "Test Address",
			})
			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_GetEffectiveSubjectMap20210101(t *testing.T) {
	mockey.PatchConvey("Test GetEffectiveSubjectMap20210101", t, func() {
		metaServiceV2 := contractmeta.NewMetaServiceV2()
		h := &openBizContractHandler{
			metaServiceV2: metaServiceV2,
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("Test binding and validation failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test parameter validation failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*contractmeta.GetEffectiveSubjectMapReq).Validate).Return(errors.ErrorCommon.WithArgs("validation error")).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test GetEffectiveSubjectMap failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*contractmeta.GetEffectiveSubjectMapReq).Validate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(nil, errors.ErrorCommon.WithArgs("internal error")).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		})

		mockey.PatchConvey("Test GetEffectiveSubjectMap success", func() {
			expectedRes := map[string]*bizmodels.TradePartyInfoDetail{
				"account1": {
					AccountID: "account1",
					PartyName: "Party1",
				},
			}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*contractmeta.GetEffectiveSubjectMapReq).Validate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(expectedRes, nil).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			expectedBody, _ := json.Marshal(expectedRes)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_openBizContractHandler_GetNonFinalContractList20210101_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_openBizContractHandler_GetNonFinalContractList20210101", t, func() {
		verifyChangeService := verifychange.NewService()
		h := &openBizContractHandler{
			verifyChangeService: verifyChangeService,
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("场景: 参数绑定失败", func() {
			// 场景描述：
			// 模拟 binding.BindAndValidate 函数返回一个错误。
			// 逻辑链路：
			// 2. binding.BindAndValidate 返回错误。
			// 3. 函数记录错误日志并调用 vhertz.ErrorResp 返回参数解析失败的错误。
			// 4. 函数提前返回。
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h.GetNonFinalContractList20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `参数解析错误`)
		})

		mockey.PatchConvey("场景: 参数校验失败", func() {
			// 场景描述：
			// 模拟参数绑定成功，但参数的 Validate 方法返回一个错误。
			// 逻辑链路：
			// 2. binding.BindAndValidate 成功，并填充一个 AccountID 为 0 的无效参数。
			// 3. param.Validate() 方法返回错误。
			// 4. 函数记录错误日志并调用 vhertz.ErrorResp 返回参数校验失败的错误。
			// 5. 函数提前返回。
			var capturedError hertz.APIError
			validationErr := errors.ErrInvalidParam.WithArgs("AccountID")

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param, ok := obj.(*metasupport.GetNonFinalContractListReq)
				if ok {
					param.AccountID = 0 // 无效的 AccountID
					param.Limit = 10
				}
				return nil
			}).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(hertz.ErrorResp).To(func(c *app.RequestContext, err hertz.APIError) {
				capturedError = err
			}).Build()

			h.GetNonFinalContractList20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.Error(), convey.ShouldEqual, validationErr.Error())
		})

		mockey.PatchConvey("场景: verifyChangeService.GetNonFinalContractList 返回错误", func() {
			// 场景描述：
			// 模拟参数绑定和校验都成功，但底层的 service 调用返回一个错误。
			// 逻辑链路：
			// 1. 参数绑定和校验均成功。
			// 2. 调用 h.verifyChangeService.GetNonFinalContractList 方法，该方法被 mock 以返回一个错误。
			// 3. 函数调用 vhertz.ErrorResp 返回从 service 层得到的错误。
			var capturedError hertz.APIError
			serviceErr := errors.NewErr("SERVICE_ERROR", "service layer failed", 500)

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param, ok := obj.(*metasupport.GetNonFinalContractListReq)
				if ok {
					param.AccountID = 12345
					param.Limit = 10
				}
				return nil
			}).Build()
			mockey.Mock(hertz.ErrorResp).To(func(c *app.RequestContext, err hertz.APIError) {
				capturedError = err
			}).Build()
			mockey.Mock(mockey.GetMethod(h.verifyChangeService, "GetNonFinalContractList")).Return(nil, serviceErr).Build()

			h.GetNonFinalContractList20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldResemble, serviceErr)
		})

		mockey.PatchConvey("场景: 成功获取列表", func() {
			// 场景描述：
			// 所有步骤均成功，最终返回一个非终态合同列表。
			// 逻辑链路：
			// 1. 参数绑定和校验均成功。
			// 2. h.verifyChangeService.GetNonFinalContractList 方法成功返回一个合同列表。
			// 3. 函数调用 vhertz.DoResponse 返回成功响应。
			var capturedResp interface{}
			expectedResp := &metasupport.GetNonFinalContractListResp{
				List: []*metasupport.ContractData{
					{
						ContractNo:     "CN-TEST-001",
						ContractSource: 1,
						Status:         10,
						CreateTime:     time.Now().Format("2006-01-02 15:04:05"),
					},
				},
				Total:  1,
				Limit:  10,
				Offset: 0,
			}

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param, ok := obj.(*metasupport.GetNonFinalContractListReq)
				if ok {
					param.AccountID = 12345
					param.Limit = 10
					param.Offset = 0
				}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(h.verifyChangeService, "GetNonFinalContractList")).Return(expectedResp, nil).Build()
			mockey.Mock(hertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.GetNonFinalContractList20210101(context.Background(), c)

			convey.So(capturedResp, convey.ShouldNotBeNil)
			convey.So(capturedResp, convey.ShouldResemble, expectedResp)
		})
	})
}

func Test_openBizContractHandler_convertQueryStatus(t *testing.T) {
	// 测试`BizContractQueryStatusMappings`中对应状态映射不存在的场景
	t.Run("StatusMappingNotExist", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			var receiver *openBizContractHandler = &openBizContractHandler{}
			var ctxTest context.Context = context.Background()
			var bizSceneTest int = 1
			var statusTest int = 2
			// 运行被测函数
			got1, got2, got3, got4 := receiver.convertQueryStatus(ctxTest, bizSceneTest, statusTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 测试中未对`_const.BizContractQueryStatusMappings`进行mock，默认情况下`_const.BizContractQueryStatusMappings[bizSceneTest][statusTest]`不存在，会执行`if !exist`分支，返回`nil`，因此`got1`长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 同理，由于`_const.BizContractQueryStatusMappings[bizSceneTest][statusTest]`不存在，会执行`if !exist`分支，返回`nil`，所以`got2`长度为0
			convey.So(len(got2), convey.ShouldEqual, 0)
			// 因为`_const.BizContractQueryStatusMappings[bizSceneTest][statusTest]`不存在，执行`if !exist`分支，返回`nil`，故`got3`长度为0
			convey.So(len(got3), convey.ShouldEqual, 0)
			// 鉴于`_const.BizContractQueryStatusMappings[bizSceneTest][statusTest]`不存在，执行`if !exist`分支，返回`nil`，因此`got4`长度为0
			convey.So(len(got4), convey.ShouldEqual, 0)
		})
	})
}

func Test_openBizContractHandler_ListCountry20210101(t *testing.T) {
	mockey.PatchConvey("Test_openBizContractHandler_ListCountry20210101", t, func() {
		// 初始化handler和request context，用于所有子测试
		h := &openBizContractHandler{}
		c := &app.RequestContext{}

		mockey.PatchConvey("when ListCountry returns a list of countries successfully", func() {
			// 场景描述：
			// 模拟 innerapiaccountcli.ListCountry 成功返回国家列表的场景。
			// 构造数据：
			// - mockResp: 一个包含一个国家信息的 accountmanagement.ListForListCountryOutput 切片。
			// - capturedResult: 用于捕获 vhertz.DoResponse 的参数。
			// 逻辑链路：
			// 2. Mock innerapiaccountcli.ListCountry 返回 mockResp 和 nil error。
			// 3. Mock vhertz.DoResponse 以捕获其接收到的结果。
			// 4. 调用目标函数 ListCountry20210101。
			// 5. 断言 capturedResult 与 mockResp 相符。

			mockResp := []*accountmanagement.ListForListCountryOutput{
				{
					ChineseName:     gptr.Of("中国"),
					CodeNum:         gptr.Of(int32(86)),
					CodeThree:       gptr.Of("CHN"),
					CodeTwo:         gptr.Of("CN"),
					EnglishAbbrName: gptr.Of("China"),
					EnglishFullName: gptr.Of("People's Republic of China"),
				},
			}
			var capturedResult interface{}

			mockey.Mock(innerapiaccountcli.ListCountry).Return(mockResp, nil).Build()
			mockey.Mock(hertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h.ListCountry20210101(context.Background(), c)

			convey.So(capturedResult, convey.ShouldResemble, mockResp)
		})

		mockey.PatchConvey("when ListCountry returns an error", func() {
			// 场景描述：
			// 模拟 innerapiaccountcli.ListCountry 调用失败并返回错误的场景。
			// 构造数据：
			// - mockErr: 一个自定义的 APIError。
			// - capturedLog: 用于捕获 logs.CtxError 的日志信息。
			// - capturedAPIError: 用于捕获 vhertz.ErrorResp 的错误参数。
			// 逻辑链路：
			// 2. Mock innerapiaccountcli.ListCountry 返回 nil 和 mockErr。
			// 3. Mock logs.CtxError 以捕获日志输出。
			// 4. Mock vhertz.ErrorResp 以捕获返回给客户端的错误。
			// 5. 调用目标函数 ListCountry20210101。
			// 6. 断言日志内容符合预期，且返回的错误信息是预设的内部错误。

			mockErr := errors.ErrInternalError.WithArgs("upstream service failed")

			mockey.Mock(innerapiaccountcli.ListCountry).Return(nil, mockErr).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()

			h.ListCountry20210101(context.Background(), c)
			// 函数会包装原始错误，因此我们检查新错误的属性
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "获取国家/地区列表失败")
		})
	})
}

func Test_openBizContractHandler_ExistPartyMD20210101(t *testing.T) {
	mockey.PatchConvey("Test_openBizContractHandler_ExistPartyMD20210101", t, func() {
		// --- 通用准备 ---
		bizService := service.NewBizContractService()
		h := &openBizContractHandler{
			bizContractService: bizService,
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("场景：成功获取数据", func() {
			// 场景描述：
			// 构造数据：构造一个AccountID为12345的请求参数。
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 成功并填充param。
			// 2. `h.bizContractService.ExistPartyMD` 返回存在（true）且无错误。
			// 3. `innerapiaccountcli.GetVerification` 成功并返回有效的账户认证信息。
			// 4. `vhertz.DoResponse` 被调用，返回最终的map结果。
			// 5. 断言`vhertz.DoResponse`被调用，且返回的数据符合预期。

			// --- 数据准备 ---
			var capturedResponse interface{}
			testAccountID := int64(12345)
			mockVerifyInfo := &accountmanagement.GetVerifyInfoWithCountryOutput{
				CountryCodeTwo:  gptr.Of("CN"),
				VerifyName:      gptr.Of("测试客户"),
				IdentityType:    gptr.Of("2"),
				CertificateType: gptr.Of("1"),
				CertificateCode: gptr.Of("110101..."),
			}
			expectedRet := map[string]interface{}{
				"Exist":           true,
				"RegistCountry":   volcengine.StringValue(mockVerifyInfo.CountryCodeTwo),
				"CustomerName":    volcengine.StringValue(mockVerifyInfo.VerifyName),
				"IdentityType":    volcengine.StringValue(mockVerifyInfo.IdentityType),
				"CertificateType": volcengine.StringValue(mockVerifyInfo.CertificateType),
				"DocumentCode":    volcengine.StringValue(mockVerifyInfo.CertificateCode),
			}

			// --- Mock ---
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MdPartyExistParam); ok {
					p.AccountID = testAccountID
				}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizService, "ExistPartyMD")).Return(true, nil).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(mockVerifyInfo, nil).Build()
			mockey.Mock(hertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResponse = result
			}).Build()

			// --- 调用 ---
			h.ExistPartyMD20210101(context.Background(), c)

			// --- 断言 ---
			convey.So(capturedResponse, convey.ShouldNotBeNil)
			convey.So(capturedResponse, convey.ShouldResemble, expectedRet)
		})

		mockey.PatchConvey("场景：参数绑定失败", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 返回一个错误。
			// 2. `logs.CtxError` 被调用以记录错误。
			// 3. `vhertz.ErrorResp` 被调用，并传入 `errors.ErrParamParseFail`。
			// 4. 函数提前返回。
			// 5. 断言`vhertz.ErrorResp`被调用且错误符合预期。

			// --- 数据准备 ---
			bindErr := fmt.Errorf("bind error")

			// --- Mock ---
			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()

			// --- 调用 ---
			h.ExistPartyMD20210101(context.Background(), c)

			// --- 断言 ---
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "参数解析错误")
		})

		mockey.PatchConvey("场景：bizContractService.ExistPartyMD 返回错误", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 成功。
			// 2. `h.bizContractService.ExistPartyMD` 返回一个自定义错误。
			// 3. `vhertz.ErrorResp` 被调用，并传入该自定义错误。
			// 4. 函数提前返回。
			// 5. 断言`vhertz.ErrorResp`被调用且错误符合预期。

			// --- 数据准备 ---

			// --- Mock ---
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizService, "ExistPartyMD")).Return(false, errors.ErrorCommon.WithArgs("获取国家/地区列表失败")).Build()
			// --- 调用 ---
			h.ExistPartyMD20210101(context.Background(), c)

			// --- 断言 ---
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "获取国家/地区列表失败")
		})

		mockey.PatchConvey("场景：innerapiaccountcli.GetVerification 返回错误", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 和 `ExistPartyMD` 均成功。
			// 2. `innerapiaccountcli.GetVerification` 返回一个错误。
			// 3. `logs.CtxError` 被调用记录错误。
			// 4. `vhertz.ErrorResp` 被调用，并传入 `errors.ErrInternalError`。
			// 5. 函数提前返回。
			// 6. 断言`vhertz.ErrorResp`被调用且错误符合预期。

			// --- 数据准备 ---
			getVerifyErr := fmt.Errorf("get verification error")

			// --- Mock ---
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizService, "ExistPartyMD")).Return(true, nil).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(nil, getVerifyErr).Build()

			// --- 调用 ---
			h.ExistPartyMD20210101(context.Background(), c)

			// --- 断言 ---
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "获取账号信息失败")
		})

		mockey.PatchConvey("场景：innerapiaccountcli.GetVerification 返回nil结果", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 和 `ExistPartyMD` 均成功。
			// 2. `innerapiaccountcli.GetVerification` 返回 (nil, nil)。
			// 3. `logs.CtxError` 被调用记录错误。
			// 4. `vhertz.ErrorResp` 被调用，并传入 `errors.ErrInternalError`。
			// 5. 函数提前返回。
			// 6. 断言`vhertz.ErrorResp`被调用且错误符合预期。

			// --- 数据准备 ---

			// --- Mock ---
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizService, "ExistPartyMD")).Return(true, nil).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(nil, nil).Build()

			// --- 调用 ---
			h.ExistPartyMD20210101(context.Background(), c)

			// --- 断言 ---
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "获取账号信息失败")
		})
	})
}

func Test_openBizContractHandler_GetBizContractPreview20210101(t *testing.T) {
	t.Run("直接调用预览接口成功", func(t *testing.T) {
		mockey.PatchConvey("直接调用预览接口成功", t, func() {
			metaDao := dal.NewContractMetaDao()
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			reqCtx := &app.RequestContext{}

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.BizContractDetailParam)
				param.ContractNo = "CN-001"
				param.AccountID = 123
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			findByNoMethod := mockey.GetMethod(metaDao, "FindByNo")
			mockey.Mock(findByNoMethod).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "file-id",
			}, nil).Build()
			getAttachmentDataInfoMethod := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(getAttachmentDataInfoMethod).Return(&metaattachmodel.AttachmentDataInfo{
				CanView:     true,
				ContentType: "application/pdf",
				Data:        []byte("preview-data"),
			}, nil).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldEqual, "preview-data")
		})
	})

	t.Run("通过Action访问预览接口", func(t *testing.T) {
		mockey.PatchConvey("通过Action访问预览接口", t, func() {
			reqCtx := &app.RequestContext{}
			reqCtx.Request.URI().QueryArgs().Set("Action", "Preview")
			reqCtx.Request.URI().QueryArgs().Set("Version", "20210101")

			hertz.NewHandleAction(NewOpenBizContractHandler())(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})
	})
}

func Test_NewOpenBizContractHandler(t *testing.T) {
	t.Run("初始化依赖成功", func(t *testing.T) {
		mockey.PatchConvey("初始化依赖成功", t, func() {
			actionHandler := NewOpenBizContractHandler()
			handler, ok := actionHandler.(*openBizContractHandler)

			convey.So(ok, convey.ShouldBeTrue)
			convey.So(handler.bizContractService, convey.ShouldNotBeNil)
			convey.So(handler.metaService, convey.ShouldNotBeNil)
			convey.So(handler.metaServiceV2, convey.ShouldNotBeNil)
			convey.So(handler.templateService, convey.ShouldNotBeNil)
			convey.So(handler.verifyChangeService, convey.ShouldNotBeNil)
			convey.So(handler.freshSealService, convey.ShouldNotBeNil)
			convey.So(handler.attachmentService, convey.ShouldNotBeNil)
		})
	})
}

func Test_openBizContractHandler_GetBizContractPreview20210101_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("测试 GetBizContractPreview20210101 全分支覆盖", t, func() {
		mockey.PatchConvey("场景：参数绑定失败，直接返回参数错误", func() {
			// 场景描述：参数绑定阶段返回错误，函数应直接返回参数解析错误。
			reqCtx := &app.RequestContext{}
			handler := &openBizContractHandler{
				attachmentService: metaattachservice.NewAttachmentService(),
			}
			// Mock绑定失败
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("bind fail")).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "参数解析错误")
		})

		mockey.PatchConvey("场景：查询合同失败（FindByNo返回错误）", func() {
			// 场景描述：查询合同元数据返回错误，应该返回“查询合同失败”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-ERR"
				p.AccountID = 1
				return nil
			}).Build()
			// Mock Dao 与方法
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, errors001.New("db error")).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "查询合同失败")
		})

		mockey.PatchConvey("场景：合同不存在（FindByNo返回nil）", func() {
			// 场景描述：查询成功但没有数据，应该返回“合同不存在”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-NIL"
				p.AccountID = 1
				return nil
			}).Build()
			// Mock Dao 与方法返回nil
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return((*model.ContractMetaDB)(nil), nil).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "合同不存在")
		})

		mockey.PatchConvey("场景：账号无权限", func() {
			// 场景描述：查询到合同，但账号ID不在主体账号列表中，返回“no permission”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-NOPERM"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 与方法返回主体账号列表不包含123
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "456,789",
				FileIdUnsigned:    "fid-unused",
			}, nil).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "no permission")
		})

		mockey.PatchConvey("场景：合同文件下载ID为空", func() {
			// 场景描述：账号有权限，但未生成下载ID，返回“合同文件不存在”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-EMPTYDL"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 返回有权限但无文件ID
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "",
				FileIdSigned:      "",
			}, nil).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "合同文件不存在")
		})

		mockey.PatchConvey("场景：获取附件信息失败（服务返回错误）", func() {
			// 场景描述：下载ID存在，但附件服务返回错误，应该直接返回该错误信息。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-ATTACH-ERR"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 返回有效的下载ID
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "file-id",
			}, nil).Build()
			// Mock 附件服务返回错误
			mockey.Mock(mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")).Return(
				(*metaattachmodel.AttachmentDataInfo)(nil),
				errors.NewErr("InternalErr", "内部错误", http.StatusBadRequest),
			).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "内部错误")
		})

		mockey.PatchConvey("场景：附件信息为空", func() {
			// 场景描述：附件服务成功调用但返回nil，应该返回“获取文档数据失败”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-ATTACH-NIL"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 返回有效的下载ID
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "file-id",
			}, nil).Build()
			// Mock 附件服务返回nil且无错误
			mockey.Mock(mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")).Return(
				(*metaattachmodel.AttachmentDataInfo)(nil),
				nil,
			).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "获取文档数据失败")
		})

		mockey.PatchConvey("场景：文档不支持预览", func() {
			// 场景描述：附件数据返回但标记不可预览，应该返回“当前文档不支持预览”。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-ATTACH-NOVIEW"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 返回有效的下载ID
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "file-id",
			}, nil).Build()
			// Mock 附件服务返回不可预览
			mockey.Mock(mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")).Return(
				&metaattachmodel.AttachmentDataInfo{
					CanView:     false,
					ContentType: "application/pdf",
					Data:        []byte("no-view"),
				},
				nil,
			).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldContainSubstring, "当前文档不支持预览")
		})

		mockey.PatchConvey("场景：预览成功返回文件字节流", func() {
			// 场景描述：所有校验通过，附件服务返回可预览数据，最终通过 Data 返回200和文件数据。
			reqCtx := &app.RequestContext{}
			attachmentService := metaattachservice.NewAttachmentService()
			handler := &openBizContractHandler{
				attachmentService: attachmentService,
			}
			// Mock参数绑定成功
			mockey.MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.BizContractDetailParam)
				p.ContractNo = "CN-SUCC"
				p.AccountID = 123
				return nil
			}).Build()
			// Mock Dao 返回有效的下载ID和权限通过
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{
				SubjectAccountIds: "123,456",
				FileIdUnsigned:    "file-id",
			}, nil).Build()
			// Mock 附件服务返回可预览数据
			mockey.Mock(mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")).Return(
				&metaattachmodel.AttachmentDataInfo{
					CanView:     true,
					ContentType: "application/pdf",
					Data:        []byte("preview-data"),
				},
				nil,
			).Build()

			handler.GetBizContractPreview20210101(context.Background(), reqCtx)

			convey.So(reqCtx.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(reqCtx.Response.Body()), convey.ShouldEqual, "preview-data")
		})
	})
}

package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/pkg/errors"
)

func TestNewOpenRiviewRuleHandler(t *testing.T) {
	mockey.PatchConvey("创建 open review rule handler", t, func() {
		convey.So(NewOpenRiviewRuleHandler(), convey.ShouldNotBeNil)
	})
}

func TestOpenRiviewRuleHandlerListReviewRule20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
			(&openRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功透传 service 响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.ListReviewRuleReq).Status = "1" })
			expected := &modelreviewrule.ListReviewRuleResponse{Total: 2}
			(&openRiviewRuleHandler{service: &fakeReviewRuleService{listFn: func(ctx context.Context, req *modelreviewrule.ListReviewRuleReq) (*modelreviewrule.ListReviewRuleResponse, error) {
				return expected, nil
			}}}).ListReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.body, convey.ShouldEqual, expected)
		})
	})
}

func TestOpenRiviewRuleHandlerListSalesDepartment20210101(t *testing.T) {
	mockey.PatchConvey("成功返回销售行业", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(nil)
		(&openRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListSalesDepartment20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestOpenRiviewRuleHandlerListSalesDepartmentInfo20210101(t *testing.T) {
	mockey.PatchConvey("成功返回销售行业详情", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(nil)
		(&openRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListSalesDepartmentInfo20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

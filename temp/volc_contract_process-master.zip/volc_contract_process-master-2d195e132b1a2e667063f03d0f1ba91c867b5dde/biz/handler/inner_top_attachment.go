package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/metaattach"
)

type innerTOPAttachmentHandler struct {
	base
	attachmentService metaattach.AttachmentService
}

func NewInnerTOPAttachmentHandler() vhertz.ActionHandler {
	return &innerTOPAttachmentHandler{
		attachmentService: metaattach.NewAttachmentService(),
	}
}

// GetAttachmentPreviewInfo20200101 获取合同元数据附件预览信息
func (h *innerTOPAttachmentHandler) GetAttachmentPreviewInfo20200101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")
	currentOperator := c.Query("CurrentOperator")

	logs.CtxInfo(ctx, "GetAttachmentPreviewInfo, id=%s, version=%s, currentOperator=%s", downloadID, version, currentOperator)

	req := &bizmodels.GetAttachmentPreviewInfoReq{
		CurrentOperator: currentOperator,
		DownloadID:      downloadID,
		DocVersion:      version,
	}

	resp, err := h.attachmentService.GetAttachmentPreviewInfo(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetAttachmentPreviewInfoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

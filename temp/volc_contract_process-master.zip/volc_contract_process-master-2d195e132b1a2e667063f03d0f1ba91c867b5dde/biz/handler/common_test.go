package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/pkg/errors"
)

func TestInnerToolHandlerESignCallback20210101(t *testing.T) {
	mockey.PatchConvey("绑定失败返回参数错误", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
		(&innerToolHandler{}).ESignCallback20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
	})
}

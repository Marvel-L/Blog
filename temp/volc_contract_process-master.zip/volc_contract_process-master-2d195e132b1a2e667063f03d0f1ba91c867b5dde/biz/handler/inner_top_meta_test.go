package handler

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"testing"
	"time"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/bizmodels/metasupport"
	_const "volc_contract_process/pkg/const"

	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/contractmeta"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	. "github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	. "github.com/smartystreets/goconvey/convey"
)

func Test_innerTOPMetaHandler_GetMetaSimpleInfo20200101_BitsUTGen(t *testing.T) {
	// mockMetaService is a mock type for the contractmeta.MetaService interface, used for mocking its methods.
	type mockMetaService struct {
		contractmeta.MetaService
	}

	mockey.PatchConvey("Test GetMetaSimpleInfo20200101", t, func() {
		// Common setup
		h := &innerTOPMetaHandler{
			metaService: &mockMetaService{},
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("scenario: parameter binding and validation fails", func() {
			// 场景描述：
			// 模拟请求参数解析失败的场景。当 `binding.BindAndValidate` 返回错误时，函数应返回参数解析失败的特定错误。
			// 构造数据：
			// - 无特殊数据构造，仅关注模拟函数的返回值。
			// 逻辑链路：
			// 1. Mock hertz_ext_binding.BindAndValidate 返回一个非nil的错误。
			// 2. 函数捕获此错误，记录日志（本测试不关心），并调用 vhertz.ErrorResp。
			// 3. 传入 vhertz.ErrorResp 的错误应为 pkg_errors.ErrParamParseFail。
			// 4. 函数应提前返回，不执行后续的业务逻辑。

			bindErr := errors.New("mock bind and validate error")
			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()

			var errorRespCalled bool
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				convey.So(err, convey.ShouldEqual, pkg_errors.ErrParamParseFail)
			}).Build()

			h.GetMetaSimpleInfo20200101(context.Background(), c)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("scenario: meta service returns an error", func() {
			// 场景描述：
			// 模拟在参数解析成功后，调用下游服务 `h.metaService.MetaSimpleInfo` 返回错误的场景。
			// 构造数据：
			// - 构造一个自定义的 APIError 作为下游服务的错误返回值。
			// 逻辑链路：
			// 1. Mock hertz_ext_binding.BindAndValidate 返回 nil，表示参数解析成功。
			// 2. Mock h.metaService.MetaSimpleInfo 返回一个预设的 APIError。
			// 3. 函数捕获此错误，并调用 vhertz.ErrorResp，将错误透传给调用方。
			// 4. 传入 vhertz.ErrorResp 的错误应与下游服务返回的错误相同。
			// 5. 函数应提前返回，不调用 vhertz.DoResponse。

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			serviceErr := pkg_errors.NewErr("ServiceError", "mock service error from MetaSimpleInfo", 500)
			mockey.Mock((*mockMetaService).MetaSimpleInfo).Return(nil, serviceErr).Build()

			var errorRespCalled bool
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				convey.So(err, convey.ShouldResemble, serviceErr)
			}).Build()

			h.GetMetaSimpleInfo20200101(context.Background(), c)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("scenario: success", func() {
			// 场景描述：
			// 模拟成功获取合同简要信息的全流程。
			// 构造数据：
			// - 构造一个 bizmodels.ContractMetaSimpleInfo 结构体作为下游服务的成功响应。
			// 逻辑链路：
			// 1. Mock hertz_ext_binding.BindAndValidate 返回 nil。
			// 2. Mock h.metaService.MetaSimpleInfo 返回成功的响应数据和 nil 错误。
			// 3. 函数获取成功响应后，调用 vhertz.DoResponse 将数据封装成通用响应并返回。
			// 4. 传入 vhertz.DoResponse 的数据应与下游服务返回的数据相同。
			// 5. 不会调用 vhertz.ErrorResp。

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			expectedResp := &bizmodels.ContractMetaSimpleInfo{
				ID:            "contract-id-123",
				ContractName:  "Test Contract",
				ContractNo:    "TC-20240101",
				Version:       1,
				TemplateType:  gptr.Of(2),
				ValidityBegin: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				ValidityEnd:   time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC),
			}
			mockey.Mock((*mockMetaService).MetaSimpleInfo).Return(expectedResp, nil).Build()

			var doResponseCalled bool
			mockey.Mock(vhertz.DoResponse).To(func(c *app.RequestContext, resp interface{}) {
				doResponseCalled = true
				convey.So(resp, convey.ShouldResemble, expectedResp)
			}).Build()

			h.GetMetaSimpleInfo20200101(context.Background(), c)

			convey.So(doResponseCalled, convey.ShouldBeTrue)
		})
	})
}

func TestNewInnerTOPMetaHandler_BitsUTGen(t *testing.T) {
	// MockMetaService is a mock implementation of contractmeta.MetaService.
	// It's used to be returned by the mocked NewMetaService constructor.
	type MockMetaService struct {
		contractmeta.MetaService
	}

	mockey.PatchConvey("TestNewInnerTOPMetaHandler", t, func() {
		mockey.PatchConvey("should return a new handler with metaService initialized", func() {
			// 场景描述：
			// 测试 NewInnerTOPMetaHandler 函数能否成功创建一个 handler 实例，并正确初始化其内部的 metaService 字段。
			// 构造数据：
			// 创建一个 contractmeta.MetaService 接口的 mock 实例。
			// 逻辑链路：
			// 1. Mock contractmeta.NewMetaService() 函数，使其返回我们预先定义的 mock 实例。
			// 2. 调用目标函数 NewInnerTOPMetaHandler()。
			// 3. 断言返回的 handler 实例不为 nil。
			// 4. 断言返回的 handler 实例可以被成功类型转换为 *innerTOPMetaHandler（由于测试在同一个包下，可以访问未导出类型）。
			// 5. 断言 handler 实例内部的 metaService 字段是我们所 mock 的实例，以验证构造函数正确地执行了赋值操作。
			mockService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockService).Build()

			// 调用目标函数
			handler := NewInnerTOPMetaHandler()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)

			// 由于测试文件与源文件在同一个包（handler）下，可以直接访问未导出的类型 innerTOPMetaHandler
			h, ok := handler.(*innerTOPMetaHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(h.metaService, convey.ShouldEqual, mockService)
		})
	})
}

func Test_innerTOPMetaHandler_NeedSubjectChangeAgreement20200101(t *testing.T) {
	mockey.PatchConvey("Test_innerTOPMetaHandler_NeedSubjectChangeAgreement20200101", t, func() {
		// Initialize the handler with the mock service.
		h := &innerTOPMetaHandler{
			metaServiceV2: contractmeta.NewMetaServiceV2(),
		}
		// Create a hertz request context for the test.
		c := &app.RequestContext{}

		mockey.PatchConvey("success", func() {
			// 场景描述：
			// 构造数据：构造一个包含有效 AccountIDs 的请求参数。
			// 逻辑链路：
			// 2. Mock binding.BindAndValidate 成功，并填充有效的请求参数。
			// 3. 请求参数的 Validate 方法验证通过。
			// 4. Mock h.metaServiceV2.NeedSubjectChangeAgreement 返回成功结果。
			// 5. Mock vhertz.DoResponse 捕获最终的成功响应以进行断言。
			// 6. 调用目标函数，并验证响应是否符合预期。

			var capturedResult interface{}
			expectedRes := []*contractmeta.NeedSubjectChangeAgreementItem{
				{AccountID: "123", Need: true},
			}

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*contractmeta.NeedSubjectChangeAgreementReq); ok {
					p.AccountIDs = []string{"123"}
				}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "NeedSubjectChangeAgreement")).Return(expectedRes, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h.NeedSubjectChangeAgreement20200101(context.Background(), c)

			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{
				"List": expectedRes,
			})
		})

		mockey.PatchConvey("bind and validate fail", func() {
			// 场景描述：
			// 构造数据：无特定数据构造，依赖 Mock 模拟失败。
			// 逻辑链路：
			// 2. Mock binding.BindAndValidate 返回一个错误，模拟参数绑定失败。
			// 3. Mock logs.CtxError 捕获错误日志。
			// 4. Mock vhertz.ErrorResp 捕获错误响应以进行断言。
			// 5. 调用目标函数，并验证返回的错误是否为参数解析失败。

			var capturedError pkg_errors.APIError
			bindErr := errors.New("bind failed")

			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err.(pkg_errors.APIError)
			}).Build()

			h.NeedSubjectChangeAgreement20200101(context.Background(), c)

			convey.So(capturedError, convey.ShouldResemble, pkg_errors.ErrParamParseFail)
		})

		mockey.PatchConvey("param validate fail", func() {
			// 场景描述：
			// 构造数据：构造一个 AccountIDs 为空的请求参数。
			// 逻辑链路：
			// 2. Mock binding.BindAndValidate 成功，并填充 AccountIDs 为空的参数。
			// 3. 请求参数的 Validate 方法因 AccountIDs 为空而验证失败。
			// 4. Mock logs.CtxError 捕获错误日志。
			// 5. Mock vhertz.ErrorResp 捕获错误响应以进行断言。
			// 6. 调用目标函数，并验证返回的错误是否为参数缺失。

			var capturedError pkg_errors.APIError

			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*contractmeta.NeedSubjectChangeAgreementReq); ok {
					p.AccountIDs = []string{} // Empty slice to trigger validation failure
				}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err.(pkg_errors.APIError)
			}).Build()

			h.NeedSubjectChangeAgreement20200101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.Error(), convey.ShouldContainSubstring, "MissingParam")
		})

		mockey.PatchConvey("service fail", func() {
			// 场景描述：
			// 构造数据：构造一个包含有效 AccountIDs 的请求参数。
			// 逻辑链路：
			// 2. Mock binding.BindAndValidate 成功，并填充有效的请求参数。
			// 3. 请求参数的 Validate 方法验证通过。
			// 4. Mock h.metaServiceV2.NeedSubjectChangeAgreement 返回一个错误，模拟业务逻辑处理失败。
			// 5. Mock vhertz.ErrorResp 捕获错误响应以进行断言。
			// 6. 调用目标函数，并验证返回的错误是否为内部错误。

			var capturedError pkg_errors.APIError

			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*contractmeta.NeedSubjectChangeAgreementReq); ok {
					p.AccountIDs = []string{"123"}
				}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "NeedSubjectChangeAgreement")).Return(nil, pkg_errors.NewErr("ServiceError", "service error", 500)).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err.(pkg_errors.APIError)
			}).Build()

			h.NeedSubjectChangeAgreement20200101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
		})
	})
}

type Mock_MetaService_ListContractMeta20200101 struct {
	contractmeta.MetaService
}

func Test_innerTOPMetaHandler_UpdateExpireRemindInfo20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 避免日志空指针
			Mock(logs.CtxError).Return().Build()
			Mock(logs.CtxWarn).Return().Build()

			// 上下文
			// 参数绑定失败
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind error")).Build()

			h := &innerTOPMetaHandler{}
			c := &app.RequestContext{}

			h.UpdateExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("用户信息为空且参数校验失败", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 避免日志空指针
			Mock(logs.CtxError).Return().Build()
			Mock(logs.CtxWarn).Return().Build()

			// 没有用户信息
			// 绑定成功但缺少ContractNo导致校验失败
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*metasupport.UpdateExpireRemindReq)
				p.ContractNo = ""      // 触发MissingParam
				p.ExpireRemindFlag = 0 // 其他字段不校验
				return nil
			}).Build()

			h := &innerTOPMetaHandler{
				metaServiceV2: contractmeta.NewMetaServiceV2(),
			}
			c := &app.RequestContext{}

			h.UpdateExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"MissingParam"`)
		})
	})

	t.Run("校验通过但服务层返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 避免日志空指针
			Mock(logs.CtxError).Return().Build()
			Mock(logs.CtxWarn).Return().Build()

			// 有用户信息
			user := &bizmodels.AuthInnerUserInfo{EmployeeEmail: "operator@example.com"}
			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, user)

			// 绑定合法参数
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*metasupport.UpdateExpireRemindReq)
				p.CurrentOperator = "op_direct"
				p.ContractNo = "CN001"
				p.ExpireRemindFlag = 0
				return nil
			}).Build()

			metaServiceV2 := contractmeta.NewMetaServiceV2()
			var capturedReq *metasupport.UpdateExpireRemindReq
			Mock(GetMethod(metaServiceV2, "UpdateExpireRemindInfo")).To(func(ctx context.Context, req *metasupport.UpdateExpireRemindReq) error {
				capturedReq = req
				return fmt.Errorf("service internal")
			}).Build()

			h := &innerTOPMetaHandler{
				metaServiceV2: metaServiceV2,
			}
			c := &app.RequestContext{}

			h.UpdateExpireRemindInfo20200101(ctx, c)
			t.Log(string(c.Response.Body()))
			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"InternalError"`)
			So(capturedReq, ShouldNotBeNil)
		})
	})

	t.Run("成功返回响应", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 避免日志空指针
			Mock(logs.CtxError).Return().Build()
			Mock(logs.CtxWarn).Return().Build()

			// 有用户信息
			user := &bizmodels.AuthInnerUserInfo{EmployeeEmail: "user2@example.com"}
			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, user)

			// 绑定合法参数，ExpireRemindFlag为1时校验辅助字段也有效
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*metasupport.UpdateExpireRemindReq)
				p.CurrentOperator = "op_direct"
				p.ContractNo = "CN002"
				p.ExpireRemindFlag = _const.TRUE_FLAG_INT
				p.NoRemindType = _const.NonExpireRemindTypeRenewed
				p.NoRemindTypeSec = _const.NonExpireRemindTypeRenewedEnSec
				p.NoRemindReason = "已续约，无需提醒"
				return nil
			}).Build()

			metaServiceV2 := contractmeta.NewMetaServiceV2()
			var capturedReq *metasupport.UpdateExpireRemindReq
			Mock(GetMethod(metaServiceV2, "UpdateExpireRemindInfo")).To(func(ctx context.Context, req *metasupport.UpdateExpireRemindReq) error {
				capturedReq = req
				return nil
			}).Build()

			h := &innerTOPMetaHandler{
				metaServiceV2: metaServiceV2,
			}
			c := &app.RequestContext{}

			h.UpdateExpireRemindInfo20200101(ctx, c)
			t.Log(string(c.Response.Body()))
			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(c.Response.Body()), ShouldContainSubstring, `"ContractNo":"CN002"`)
			So(capturedReq, ShouldNotBeNil)
		})
	})
}

func Test_innerVCMetaHandler_GetExpireRemindInfo20210101_BitsUTGen(t *testing.T) {
	t.Run("失败场景-参数绑定失败", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 绑定失败返回参数解析错误
			c := &app.RequestContext{}
			h := &innerTOPMetaHandler{}

			Mock(logs.CtxError).Return().Build()
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h.GetExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("失败场景-参数校验失败且无用户信息", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 无用户信息导致CurrentOperator为空，校验失败
			c := &app.RequestContext{}
			h := &innerTOPMetaHandler{
				metaServiceV2: contractmeta.NewMetaServiceV2(),
			}

			Mock(logs.CtxError).Return().Build()
			Mock(logs.CtxWarn).Return().Build()
			Mock(binding.BindAndValidate).Return(nil).Build()

			h.GetExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"MissingParam"`)
		})
	})

	t.Run("失败场景-服务层返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Service层返回错误，走内部错误分支
			c := &app.RequestContext{}
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			h := &innerTOPMetaHandler{
				metaServiceV2: metaServiceV2,
			}

			Mock(logs.CtxError).Return().Build()
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*metasupport.GetExpireRemindReq); ok {

					p.CurrentOperator = "xxx"
					p.ContractNo = "CT20240001"
				}
				return nil
			}).Build()
			Mock(GetMethod(metaServiceV2, "GetExpireRemindInfo")).Return(nil, fmt.Errorf("internal fetch error")).Build()

			h.GetExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"InternalError"`)
			So(string(c.Response.Body()), ShouldContainSubstring, `internal fetch error`)
		})
	})

	t.Run("成功场景-获取提醒信息成功", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 成功返回提醒信息，最终响应为200且包含Result
			c := &app.RequestContext{}
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			h := &innerTOPMetaHandler{
				metaServiceV2: metaServiceV2,
			}

			Mock(logs.CtxError).Return().Build()
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*metasupport.GetExpireRemindReq); ok {

					p.CurrentOperator = "xxx"
					p.ContractNo = "CT20240002"
				}
				return nil
			}).Build()

			ret := &bizmodels.ExpireRemindInfo{
				ExpireRemindFlag: 0,
				NoRemindType:     1,
				NoRemindTypeSec:  "不再提醒类型",
				NoRemindReason:   "原因示例",
			}
			Mock(GetMethod(metaServiceV2, "GetExpireRemindInfo")).Return(ret, nil).Build()

			h.GetExpireRemindInfo20200101(context.Background(), c)

			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Result"`)
			So(string(c.Response.Body()), ShouldContainSubstring, `"ExpireRemindFlag":0`)
			So(string(c.Response.Body()), ShouldContainSubstring, `"NoRemindTypeSec":"不再提醒类型"`)
			So(string(c.Response.Body()), ShouldContainSubstring, `"NoRemindReason":"原因示例"`)
		})
	})
}

package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/lang/strings"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/comment"
	"volc_contract_process/pkg/errors"
)

// 评论模块
type innerCommentHandler struct {
	base
	commentService comment.CommentService
}

func NewInnerCommentHandler() vhertz.ActionHandler {
	return &innerCommentHandler{
		commentService: comment.NewCommentService(),
	}
}

// PublishComment20210101 发布评论
func (h *innerCommentHandler) PublishComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.PublishCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "PublishCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.Sender = fetchEmployeeEmail(ctx)

	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.commentService.PublishComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// DeleteComment20210101 删除评论
func (h *innerCommentHandler) DeleteComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.DeleteCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "DeleteCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.Operator = fetchEmployeeEmail(ctx)

	if strings.IsEmpty(param.CommentID) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CommentID"))
		return
	}

	if strings.IsEmpty(param.Operator) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Operator"))
		return
	}

	err := h.commentService.DeleteComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ListComment20210101 查询评论
func (h *innerCommentHandler) ListComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.ListCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ListCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if param.CommentScene <= 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CommentScene"))
		return
	}

	if strings.IsEmpty(param.RelatedID) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("RelatedID"))
		return
	}

	resp, err := h.commentService.ListComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// PublishCommentInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 PublishComment20210101
func (h *innerCommentHandler) PublishCommentInner20210101(ctx context.Context, c *app.RequestContext) {
	h.PublishComment20210101(ctx, c)
}

// DeleteCommentInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 DeleteComment20210101
func (h *innerCommentHandler) DeleteCommentInner20210101(ctx context.Context, c *app.RequestContext) {
	h.DeleteComment20210101(ctx, c)
}

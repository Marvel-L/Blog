package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/shopspring/decimal"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/fresh_seal"
	"volc_contract_process/biz/service/metaattach"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/support/verifychange"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/biz/service/workflow"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/dkmscli"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
	"volc_contract_process/pkg/proxy/mdcli"
	"volc_contract_process/pkg/util"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/service/accountmanagement"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/volcengine"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
)

// 该文件中API大多是来自控制台TOP的请求
type openBizContractHandler struct {
	base
	bizContractService  service.BizContractService
	metaService         contractmeta.MetaService
	metaServiceV2       contractmeta.MetaServiceV2
	templateService     template.Service
	verifyChangeService verifychange.Service
	freshSealService    fresh_seal.FreshSealApprovalService
	attachmentService   metaattach.AttachmentService
}

func NewOpenBizContractHandler() vhertz.ActionHandler {
	return &openBizContractHandler{
		bizContractService:  service.NewBizContractService(),
		metaService:         contractmeta.NewMetaService(),
		metaServiceV2:       contractmeta.NewMetaServiceV2(),
		templateService:     template.NewService(),
		verifyChangeService: verifychange.NewService(),
		freshSealService:    fresh_seal.NewFreshSealApprovalService(),
		attachmentService:   metaattach.NewAttachmentService(),
	}
}

// List20210101 外部接口-合同列表
// @Summary 外部接口-合同列表
// @Description  外部接口-合同列表
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@List20210101
// @Accept json
// @Param Action query string true "Action-默认值:List"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.BizContractListParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=bizmodels.BizContractListResp} "响应信息"
// @Router /vcp/open-api/contract_process/Action_List_Version_20210101 [get]
func (h *openBizContractHandler) List20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen

	// 注意 该接口需要逐步迁移，目前仅迁移报价
	if param.Scene == _const.SceneQuoteContract || // 报价
		param.Scene == _const.SceneCreditContract || // 信控
		param.Scene == _const.ScenePayOnBehalf { // 代付
		h.listMeta(ctx, c, &param)
		return
	}

	ret, err := h.bizContractService.List(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

func (h *openBizContractHandler) listMeta(ctx context.Context, c *app.RequestContext, param *bizmodels.BizContractListParam) {
	var bizScene int
	if param.Scene == _const.SceneQuoteContract {
		bizScene = _const.BizSceneQuoteContract
	} else if param.Scene == _const.SceneCreditContract {
		bizScene = _const.BizSceneCreditContract
	} else if param.Scene == _const.ScenePayOnBehalf {
		bizScene = _const.BizScenePayOnBehalf
		if param.AccountID == 0 {
			vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("AccountID"))
			return
		}
	} else {
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	metaParam := &bizmodels.MetaListParam{
		SourceType:      param.SourceType,
		CurrentOperator: param.CurrentOperator,
		BizScene:        bizScene,
		BizAccountID:    param.AccountID,
		ContractNo:      param.ContractNo,
		PrincipalParty:  param.PrincipalParty,
		EntrustedParty:  param.EntrustedParty,
		OrderBy:         param.OrderBy,
		Limit:           param.Limit,
		Offset:          param.Offset,
		IsMultiApply:    param.IsMultiApply,
	}

	if len(param.Status) > 0 {
		var cooperationStatusList []int
		var activeStatusList []int
		var metaStatusList []int
		statusStrList := strings.Split(param.Status, ",")
		for _, v := range statusStrList {
			v, err := strconv.ParseInt(v, 10, 64)
			if err != nil {
				continue
			}
			if metaParam.BizScene == _const.ScenePayOnBehalf {
				subCoStatusList, subMetaStatusList, _, subActiveStatusList := h.convertQueryStatus(ctx, metaParam.BizScene, int(v))
				if len(subCoStatusList) > 0 {
					cooperationStatusList = append(cooperationStatusList, subCoStatusList...)
				}
				if len(subMetaStatusList) > 0 {
					metaStatusList = append(metaStatusList, subMetaStatusList...)
				}
				if len(subActiveStatusList) > 0 {
					activeStatusList = append(activeStatusList, subActiveStatusList...)
				}
			} else {
				cooperationStatusList = append(cooperationStatusList, h.convertCoStatus(ctx, metaParam.BizScene, int(v)))
				activeStatusList = append(activeStatusList, h.convertActiveStatus(ctx, metaParam.BizScene, int(v)))
			}
		}

		cooperationStatusList = util.SingleIntList(cooperationStatusList)
		activeStatusList = util.SingleIntList(activeStatusList)
		metaStatusList = util.SingleIntList(metaStatusList)

		if len(cooperationStatusList) > 0 {
			metaParam.CooperationStatusList = cooperationStatusList
		}
		if len(activeStatusList) > 0 {
			metaParam.ActiveStatusList = activeStatusList
		}
		if len(metaStatusList) > 0 {
			metaParam.StatusList = util.JoinIntSlice(metaStatusList, ",")
		}
	}

	if param.CreateTimeBegin > 0 {
		t := time.Unix(param.CreateTimeBegin, 0)
		metaParam.CreatedTimeBegin = t.Format(_const.CommonDateFormatTpl)
	}

	if param.CreateTimeEnd > 0 {
		t := time.Unix(param.CreateTimeEnd, 0)
		metaParam.CreatedTimeEnd = t.Format(_const.CommonDateFormatTpl)
	}

	if param.ValidityBegin > 0 {
		t := time.Unix(param.ValidityBegin, 0)
		metaParam.ValidityBegin = t.Format(_const.CommonDateFormatTpl)
	}

	if param.ValidityEnd > 0 {
		t := time.Unix(param.ValidityEnd, 0)
		metaParam.ValidityEnd = t.Format(_const.CommonDateFormatTpl)
	}

	ret, err := h.metaService.ListBiz(ctx, metaParam)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	var StatusDescMethod = multienv.GetGenStatusDescMethod(param.SourceType)
	var metaList []*bizmodels.BizContract
	for _, v := range ret.List {
		status := model.ConvertContractStatus(ctx, v.BizScene,
			model.ConvertContractStatusParam{
				CoStatus:       v.CooperationStatus, // 协作状态
				ActiveStatus:   v.ActiveStatus,      // 生效状态
				Status:         v.Status,            // 合同状态
				ArchivedStatus: v.ArchivedStatus,    // 归档状态
				ContractNo:     v.ContractNo,        // 合同号
			},
		)
		// 校验是否可以申请鲜章
		canApplyPaper, _ := h.freshSealService.CanApplyFreshSeal(ctx, v.ArchivedStatus, v.FreshSealApprovalNo, v.SealAccountIDs, util.Int64ToString(int64(param.AccountID)), v.ActiveStatus)

		meta := &bizmodels.BizContract{
			ContractNo:          v.ContractNo,
			Identifier:          v.BizIdentifier,
			AccountID:           v.BizAccountID,
			SealAccountIDs:      v.SealAccountIDs,
			Creator:             strconv.FormatInt(v.Creator, 10),
			CreateTime:          v.CreatedTime,
			FinishTime:          v.FinishTime,
			ValidityBegin:       v.BeginTime,
			ValidityEnd:         v.EndTime,
			BizInfo:             v.BizData,
			Status:              status,
			StatusDesc:          StatusDescMethod(ctx, status),
			Remark:              v.Remark,
			AccountInfoList:     v.AccountInfoList,
			PrincipalParty:      v.PrincipalParty,
			EntrustedParty:      v.EntrustedParty,
			CanApplyPaper:       canApplyPaper,
			FreshSealApprovalNo: v.FreshSealApprovalNo,
		}
		if meta.AccountID == 0 {
			meta.AccountID, _ = strconv.ParseInt(v.SubjectAccountIDs, 10, 64)
		}
		meta.Scene = _sceneMappings[v.BizScene]
		metaList = append(metaList, meta)
	}

	// list转换
	list := &bizmodels.BizContractListResp{
		List:   metaList,
		Total:  ret.Total,
		Limit:  ret.Limit,
		Offset: ret.Offset,
	}

	h.i18nFormatListMeta(ctx, list.List)

	vhertz.DoResponse(ctx, c, list)

}

func (h *openBizContractHandler) i18nFormatListMeta(ctx context.Context, list []*bizmodels.BizContract) {
	if len(list) == 0 {
		return
	}
	globalConf := conf.GetGlobalConf(ctx)
	if globalConf == nil || globalConf.I18NSubFormatConf == nil {
		return
	}
	cfg := globalConf.I18NSubFormatConf
	for _, v := range list {
		v.Remark = multienv.I18nSubFormat(ctx, v.Remark, cfg.ListMetaRemark)
		v.BizInfo = multienv.I18nSubFormat(ctx, v.BizInfo, cfg.ListMetaBizInfo)
	}
}

var _sceneMappings = map[int]int{
	_const.BizSceneQuoteContract:  _const.SceneQuoteContract,
	_const.BizSceneCreditContract: _const.SceneCreditContract,
}

type BizContractQueryCondition struct {
	CooperationStatusList []int // 协同状态列表
	ActiveStatusList      []int // 生效状态列表
	ArchiveStatusList     []int // 归档状态列表
	StatusList            []int // 合同状态列表
}

// 接受 合同生成中、 拒绝 客户拒绝
// var _bizAuditBizContractOptionMetaStatusMap = map[int]int{
//	_const.AuditOpAccept: _const.ContractStatusGenerate,
//	_const.AuditOpReject: _const.ContractStatusCustomerRefuse,
// }

// ret: 协商状态列表、合同状态列表、归档状态列表、执行状态列表
func (h *openBizContractHandler) convertQueryStatus(ctx context.Context, bizScene int, status int) ([]int, []int, []int, []int) {
	conditions, exist := _const.BizContractQueryStatusMappings[bizScene][status]
	if !exist {
		return nil, nil, nil, nil
	}
	return conditions.CooperationStatusList, conditions.StatusList, conditions.ArchiveStatusList, conditions.ActiveStatusList
}

func (h *openBizContractHandler) convertCoStatus(ctx context.Context, bizScene int, status int) int {
	if bizScene == _const.BizSceneQuoteContract || bizScene == _const.BizSceneCreditContract || bizScene == _const.BizScenePayOnBehalf {
		return _const.BizContractCoStatusMappings[status]
	}
	return status
}

func (h *openBizContractHandler) convertActiveStatus(ctx context.Context, bizScene int, status int) int {
	if bizScene == _const.BizSceneQuoteContract || bizScene == _const.BizSceneCreditContract || bizScene == _const.BizScenePayOnBehalf {
		return _const.BizContractActiveStatusMappings[status]
	}
	return status
}

// Audit20210101 外部接口-合同审核
// @Summary 外部接口-合同审核
// @Description  外部接口-合同审核
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@Audit20210101
// @Accept json
// @Param Action query string true "Action-默认值:Audit"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.BizContractAuditParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=object} "响应信息"
// @Router /vcp/open-api/contract_process/Action_Audit_Version_20210101 [post]
func (h *openBizContractHandler) Audit20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractAuditParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractAuditReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen

	// 注意 该接口需要逐步迁移，目前仅迁移报价
	h.auditMeta(ctx, c, &param)
}

func (h *openBizContractHandler) auditMeta(ctx context.Context, c *app.RequestContext, param *bizmodels.BizContractAuditParam) {
	var bizScene int
	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch param.Scene {
	case _const.SceneQuoteContract:
		bizScene = _const.BizSceneQuoteContract
		tt = workflow.TaskTypeQuoteCustomerAudit
	case _const.SceneCreditContract:
		bizScene = _const.BizSceneCreditContract
		tt = workflow.TaskTypeCreditCustomerAudit
	case _const.ScenePayOnBehalf:
		ret, err := workflow.NewBizService().Audit(ctx, param)
		if err != nil {
			vhertz.ErrorResp(ctx, c, err)
			return
		}
		vhertz.DoResponse(ctx, c, ret)
		return
	default:
		logs.CtxError(ctx, "openBizContractHandlerAuditMetaUnsupportedBizScene, bizScene=%d", param.Scene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizScene[%d]", param.Scene)))
		return
	}

	// 兼容历史数据 meta表同步报价合同 缺失数据 走老流程 TODO：后续无历史未确认合同 可删除
	meta, e := dal.NewContractMetaDao().FindByBizIdentifierAdaptor(ctx, nil, param.ContractNo, param.ContractVersion, bizScene, param.Identifier)
	if e != nil {
		logs.CtxError(ctx, "FindByBizIdentifierFail, scene:%d, identifier:%s, err:%v", bizScene, param.Identifier, e)
		vhertz.DoResponse(ctx, c, "查询合同信息失败")
		return
	}
	if meta == nil {
		logs.CtxError(ctx, "FindByBizIdentifierFail, scene:%d, identifier:%s, meta is nil", bizScene, param.Identifier)
		vhertz.DoResponse(ctx, c, "不存在合同记录")
		return
	}
	// 若当前操作人非合同关联签约账号，不允许执行
	// todo:重点测试下这部分内容
	if meta.BizAccountID != param.AccountID || !util.StringIn(decimal.NewFromInt(param.AccountID).String(), strings.Split(meta.SealAccountIDs, ",")) {
		logs.CtxError(ctx, "[Audit]param invalid, bizScene=%d, oldMetaAccountID=%d, paramAccountID=%d", bizScene, meta.BizAccountID, param.AccountID)
		vhertz.DoResponse(ctx, c, "不存在合同记录")
		return
	}

	metaParam := bizmodels.OpenBizContractCustomerAuditParam{
		ContractNo:    param.ContractNo,
		AccountID:     param.AccountID,
		BizScene:      bizScene,
		BizIdentifier: param.Identifier,
		Operation:     param.Operation,
		RejectType:    param.RejectType,
		RejectReason:  param.RejectReason,
		Remark:        param.Remark,
		CardNo:        strings.ReplaceAll(param.CardNo, " ", ""),
		DocumentType:  strings.ReplaceAll(param.DocumentType, " ", ""),
		RegistCountry: strings.ReplaceAll(param.RegistCountry, " ", ""),
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &metaParam,
	}

	_, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizHandlerCustomerAuditFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// Download20210101 外部接口-合同下载
// @Summary 外部接口-合同下载
// @Description  外部接口-合同下载
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@Download20210101
// @Accept json
// @Param Action query string true "Action-默认值:Download"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.BizContractDetailParam false "请求参数"
// @Success 200  {object}  string "文件字节流"
// @Router /vcp/open-api/contract_process/Action_Download_Version_20210101 [get]
func (h *openBizContractHandler) Download20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDownloadReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	param.CurrentOperator = queryOperator(ctx)

	metaDB, e := dal.NewContractMetaDao().FindByNo(ctx, nil, param.ContractNo, 1)
	if e != nil {
		logs.CtxError(ctx, "FindContractMetaFail, ContractNo:%s, err:%v", param.ContractNo, e)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("查询合同失败,请稍后重试"))
		return
	}
	if metaDB == nil {
		logs.CtxError(ctx, "FindContractMetaFail, ContractNo:%s, MetaIsNil", param.ContractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("合同不存在,请稍后重试"))
		return
	}

	// 权限校验, 是合同关联账号即可下载
	if !util.StringIn(decimal.NewFromInt(param.AccountID).String(), strings.Split(metaDB.SubjectAccountIds, ",")) {
		logs.CtxError(ctx, "account[%d] no contract permission, no=%s", param.AccountID, param.ContractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("no permission"))
		return
	}

	if metaDB.BizScene != _const.BizSceneSalesContract {
		downloadParam := &bizmodels.MetaBizAttachmentDownloadParam{
			CurrentOperator: param.CurrentOperator,
			BizScene:        metaDB.BizScene,
			BizIdentifier:   metaDB.BizIdentifier,
		}
		if metaDB.BizScene == _const.ScenePayOnBehalf {
			downloadParam.ContractNo = metaDB.ContractNo
		}
		body, _, _, err := h.metaService.DownloadBiz(ctx, downloadParam)
		if err != nil {
			vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("下载失败,请稍后重试"))
			return
		}
		filename := fmt.Sprintf("%s.pdf", param.ContractNo)
		c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
		c.Response.Header.Set("Content-type", "application/octet-stream")
		c.Data(200, "application/octet-stream", body)
		return
	}

	body, filename, err := h.bizContractService.Download(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("下载失败,请稍后重试"))
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", body)

}

// GetBizContractPreview20210101 外部接口-合同预览
// @Summary 外部接口-合同预览
// @Description  外部接口-合同预览，仅支持浏览器允许的附件类型
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@GetBizContractPreview20210101
// @Accept json
// @Param Action query string true "Action-默认值:Preview"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.BizContractDetailParam false "请求参数"
// @Success 200  {object}  string "文件字节流"
// @Router /vcp/open-api/contract_process/Action_Preview_Version_20210101 [get]
func (h *openBizContractHandler) GetBizContractPreview20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractPreviewReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	param.SourceType = _const.SourceTypeOpen
	param.CurrentOperator = queryOperator(ctx)

	metaDB, e := dal.NewContractMetaDao().FindByNo(ctx, nil, param.ContractNo, 1)
	if e != nil {
		logs.CtxError(ctx, "FindContractMetaFail, ContractNo:%s, err:%v", param.ContractNo, e)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("查询合同失败,请稍后重试"))
		return
	}
	if metaDB == nil {
		logs.CtxError(ctx, "FindContractMetaFail, ContractNo:%s, MetaIsNil", param.ContractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("合同不存在,请稍后重试"))
		return
	}

	if !util.StringIn(decimal.NewFromInt(param.AccountID).String(), strings.Split(metaDB.SubjectAccountIds, ",")) {
		logs.CtxError(ctx, "account[%d] no contract permission, no=%s", param.AccountID, param.ContractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("no permission"))
		return
	}

	downloadID := metaDB.GetBizDownloadID()

	if downloadID == "" {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("合同文件不存在"))
		return
	}

	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, "")
	if err != nil {
		logs.CtxError(ctx, "PreviewMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	if !info.CanView {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前文档不支持预览"))
		return
	}

	c.Data(200, info.ContentType, info.Data)
}

// ExistPartyMD20210101 认证是否成功
// Audit20210101 认证是否成功
// @Summary 认证是否成功
// @Description  外部接口-合同审核
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@ExistPartyMD20210101
// @Accept json
// @Param Action query string true "Action-默认值:ExistPartyMD"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MdPartyExistParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=map[string]object{Exist=bool,RegistCountry=string,CustomerName=string,DocumentCode=string,IdentityType=int,CertificateType=int}} "响应信息"
// @Router /vcp/open-api/contract_process/Action_ExistPartyMD_Version_20210101 [get]
func (h *openBizContractHandler) ExistPartyMD20210101(ctx context.Context, c *app.RequestContext) { // ignore_security_alert IDOR

	var param bizmodels.MdPartyExistParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDownloadReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	exist, err := h.bizContractService.ExistPartyMD(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	verify, err1 := innerapiaccountcli.GetVerification(ctx, param.AccountID)
	if err1 != nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取账号信息失败"))
		return
	}
	if verify == nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, verify is nil")
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取账号信息失败"))
		return
	}

	var ret = map[string]interface{}{
		"Exist":           exist,
		"RegistCountry":   volcengine.StringValue(verify.CountryCodeTwo),
		"CustomerName":    volcengine.StringValue(verify.VerifyName),
		"IdentityType":    volcengine.StringValue(verify.IdentityType),    // 认证类型：个人-1 企业-2
		"CertificateType": volcengine.StringValue(verify.CertificateType), // 证件类型：身份证-1
		"DocumentCode":    volcengine.StringValue(verify.CertificateCode),
	}

	retBody, _ := json.Marshal(ret)
	dkmscli.CtxInfo(ctx, "ExistPartyMD，响应数据 => %s", string(retBody))

	vhertz.DoResponse(ctx, c, ret)
}

// ListCountry20210101 查询国家/地区
// @Summary 查询国家/地区
// @Description  查询国家/地区
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@ListCountry20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListCountry"
// @Param Version query string true "Version-默认值:20210101"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_ListCountry_Version_20210101 [get]
func (h *openBizContractHandler) ListCountry20210101(ctx context.Context, c *app.RequestContext) {

	resp, err := innerapiaccountcli.ListCountry(ctx, &accountmanagement.ListCountryInput{})
	if err != nil {
		logs.CtxError(ctx, "ListCountryFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取国家/地区列表失败"))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// ListCardType20210101 查询主数据证件类型
// @Summary 查询主数据证件类型
// @Description  查询主数据证件类型
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@ListCardType20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListCardType"
// @Param Version query string true "Version-默认值:20210101"
// @Param RegistCountry query string true "注册地国家"
// @Param docType query string true "docType"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_ListCardType_Version_20210101 [get]
func (h *openBizContractHandler) ListCardType20210101(ctx context.Context, c *app.RequestContext) {
	registCountry := c.Query("RegistCountry")
	if len(registCountry) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("RegistCountry"))
		return
	}
	docType := c.Query("docType")
	docTypeInt, err := strconv.ParseInt(docType, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("docType type exception"))
		return
	}

	resp, err := mdcli.QueryCardType(ctx, registCountry, int(docTypeInt))
	if err != nil {
		logs.CtxError(ctx, "ListCountryFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取国家/地区列表失败"))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// CreateContractMetaBizDraft20210101 创建业务合同草稿
// @Summary 创建业务合同草稿
// @Description  创建业务合同草稿
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@CreateContractMetaBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:CreateContractMetaBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractMetaCreateParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=workflow.CreateBizResp} "响应信息"
// @Router /vcc/open-api/meta/Action_CreateContractMetaBizDraft_Version_20210101 [post]
func (h *openBizContractHandler) CreateContractMetaBizDraft20210101(ctx context.Context, c *app.RequestContext) {
	h.doCreateOrUpdateBizDraft20210101(ctx, c, false)
}

// GetBizDetail20210101 查询合同详情
// @Summary 查询合同详情
// @Description  查询合同详情
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@GetBizDetail20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetBizDetail"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaDetailReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.ContractMetaInfo} "响应信息"
// @Router /vcc/open-api/meta/Action_GetBizDetail_Version_20210101 [get]
func (h *openBizContractHandler) GetBizDetail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaDetailReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizDetailParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.metaService.MetaDetail(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if resp != nil {
		if resp.BizAccountID == 0 || resp.BizAccountID != param.AccountID {
			// 合同不存在 返回空值
			logs.CtxInfo(ctx, "[openBizContractHandler]GetBizDetail, invalid AccountID, paramAccountID=%d, respAccountID=%d", param.AccountID, resp.BizAccountID)
			resp = nil
		}
	}

	vhertz.DoResponse(ctx, c, resp)

}

// UpdateBizDraft20210101 更新业务合同草稿
// @Summary 更新业务合同草稿
// @Description  更新业务合同草稿
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@UpdateBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:UpdateBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractMetaCreateParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=workflow.CreateBizResp} "响应信息"
// @Router /vcc/open-api/meta/Action_UpdateBizDraft_Version_20210101 [post]
func (h *openBizContractHandler) UpdateBizDraft20210101(ctx context.Context, c *app.RequestContext) {
	h.doCreateOrUpdateBizDraft20210101(ctx, c, true)
}

func (h *openBizContractHandler) doCreateOrUpdateBizDraft20210101(ctx context.Context, c *app.RequestContext, isUpdate bool) {

	var param bizmodels.OpenBizContractMetaCreateParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenContractMetaCreateParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.IsUpdate = isUpdate

	if param.BizScene != _const.ScenePayOnBehalf {
		logs.CtxError(ctx, "[openBizContractHandler]invalid BizScene, BizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("不允许的操作"))
		return
	}

	authAccountID := c.Request.Header.Get(_const.HeaderAccountID)
	if authAccountID != strconv.FormatInt(param.AccountID, 10) {
		logs.CtxError(ctx, "[openBizContractHandler]authFail, authAccountID=%s, paramAccountID=%d", authAccountID, param.AccountID)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("不允许的操作"))
		return
	}

	resp, err := workflow.NewBizService().CreateOrUpdateBizDraft(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizCreateHandlerFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if resp == nil {
		logs.CtxError(ctx, "OpenVCCMetaBizCreateHandlerFail, resp_is_nil")
		vhertz.ErrorResp(ctx, c, errors.ErrInternalDefError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// SubmitBizDraft20210101 提交业务合同草稿
// @Summary 提交业务合同草稿
// @Description  提交业务合同草稿
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@SubmitBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:SubmitBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractSubmitParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=workflow.BizSubmitResp} "响应信息"
// @Router /vcc/open-api/meta/Action_SubmitBizDraft_Version_20210101 [post]
func (h *openBizContractHandler) SubmitBizDraft20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractSubmitParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractSubmitParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	result, err := workflow.NewBizService().Submit(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "[openBizContractHandler]SubmitFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, result)

}

// GetContractSignURL20210101 获取签约链接
// @Summary 获取签约链接
// @Description  获取签约链接
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@GetContractSignURL20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetContractSignURL"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractGetSignURLParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{map[string]string{}{SignURL}} "响应信息"
// @Router /vcc/open-api/meta/Action_GetContractSignURL_Version_20210101 [get]
func (h *openBizContractHandler) GetContractSignURL20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractGetSignURLParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractGetSignURLParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 当前仅针对代付合同生效
	if param.BizScene != _const.BizScenePayOnBehalf {
		logs.CtxError(ctx, "OpenBizContractGetSignURLParamInvalid, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("BizScene"))
		return
	}

	url, err := h.metaService.QuerySignUrl(ctx, param.ContractNo, strconv.FormatInt(param.AccountID, 10))
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"SignURL": url,
	})

}

// ListCertificationTemplate20210101 获取证明文件列表
// @Summary 获取证明文件列表
// @Description  获取证明文件列表
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@ListCertificationTemplate20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListCertificationTemplate"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.ListCertificationTemplateReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_ListCertificationTemplate_Version_20210101 [get]
func (h *openBizContractHandler) ListCertificationTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.ListCertificationTemplateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ListCertificationTemplateReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	list, err := h.templateService.ListCertificationTemplate(ctx, &templateclient.ListTemplateReq{
		TemplateName: param.TemplateName,
		Limit:        param.Limit,
		Offset:       param.Offset,
	})
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 部分字段多语言适配
	h.formatListCertificationTemplate(ctx, list)

	vhertz.DoResponse(ctx, c, list)

}

func (h *openBizContractHandler) formatListCertificationTemplate(ctx context.Context, list []*templateclient.VolcTemplate) {
	for _, tpl := range list {
		tpl.Remark = multienv.I18nFormat(ctx, tpl.Remark)
	}
}

// DownLoadCertificationTemplate20210101 下载合同证明文件
// @Summary 下载合同证明文件
// @Description  下载合同证明文件
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@DownLoadCertificationTemplate20210101
// @Accept json
// @Param Action query string true "Action-默认值:DownLoadCertificationTemplate"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.DownLoadCertificationTemplateReq false "请求参数"
// @Success 200  {string} string "字节流"
// @Router /vcc/open-api/meta/Action_DownLoadCertificationTemplate_Version_20210101 [get]
func (h *openBizContractHandler) DownLoadCertificationTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.DownLoadCertificationTemplateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "DownLoadCertificationTemplateReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	authAccountID := c.Request.Header.Get(_const.HeaderAccountID)
	if authAccountID != strconv.FormatInt(int64(param.AccountID), 10) {
		logs.CtxError(ctx, "[openBizContractHandler]authFail, authAccountID=%s, paramAccountID=%d", authAccountID, param.AccountID)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("不允许的操作"))
		return
	}

	body, filename, err := h.templateService.DownLoadCertificationTemplate(ctx, param.TplKey, param.AccountID)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", body)
}

// GetSignDataBySubjectNo20210101 获取合同签约信息
// @Summary 获取合同签约信息
// @Description  获取合同签约信息
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@GetSignDataBySubjectNo20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetContractSignURL"
// @Param Version query string true "Version-默认值:20210101"
// @Param SubjectNo query string true "原合同号，示例：3423"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]string{}{PartyName=string,ContactName=string,ContactPhone=string,ContactAddress=string}} "响应信息"
// @Router /vcc/open-api/meta/Action_GetSignDataBySubjectNo_Version_20210101 [get]
func (h *openBizContractHandler) GetSignDataBySubjectNo20210101(ctx context.Context, c *app.RequestContext) {

	subjectNo := c.Query("SubjectNo")
	if len(subjectNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("subjectNo"))
		return
	}

	subjectInfoMap := conf.GetSubjectNo2SubjectInfoMap(ctx)
	if subjectInfoMap == nil {
		logs.CtxError(ctx, "GetSubjectNo2SubjectInfoMapFail")
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取主体信息失败"))
		return
	}
	subjectInfo, ok := subjectInfoMap[subjectNo]
	if !ok {
		logs.CtxError(ctx, "GetSubjectNo2SubjectInfoMapFail, subjectNo=%s", subjectNo)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取主体信息失败"))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"PartyName":      subjectInfo.PartyName,      // 主体名称
		"ContactName":    subjectInfo.ContactName,    // 联系人
		"ContactPhone":   subjectInfo.ContactPhone,   // 联系电话
		"ContactAddress": subjectInfo.ContactAddress, // 地址
	})

}

// GetEffectiveSubjectMap20210101 获取可使用我方主体列表
// @Summary 获取可使用我方主体列表
// @Description  获取可使用我方主体列表
// @Tags 合同相关接口-控制台
// @ID /vcc/open-api/meta@GetEffectiveSubjectMap20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetEffectiveSubjectMap"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body contractmeta.GetEffectiveSubjectMapReq true "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]*bizmodels.TradePartyInfoDetail} "响应信息"
// @Router /vcc/open-api/meta/Action_GetEffectiveSubjectMap_Version_20210101 [get]
func (h *openBizContractHandler) GetEffectiveSubjectMap20210101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.GetEffectiveSubjectMapReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// TOP 接口，默认只查询当前操作人的可用签约主体
	authAccountID := c.Request.Header.Get(_const.HeaderAccountID)
	param.AccountIDs = []string{authAccountID}
	// 查询重复项
	res, err := h.metaServiceV2.GetEffectiveSubjectMap(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// GetNonFinalContractList20210101 获取非终态合同列表
func (h *openBizContractHandler) GetNonFinalContractList20210101(ctx context.Context, c *app.RequestContext) {
	var param metasupport.GetNonFinalContractListReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, e := h.verifyChangeService.GetNonFinalContractList(ctx, &param)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/riskclauserole"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type fakeRiskClauseRoleService struct {
	riskclauserole.Service
	listFn       func(context.Context, *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error)
	createFn     func(context.Context, *riskclauserole.CreateRiskClauseRoleReq) error
	updateFn     func(context.Context, *riskclauserole.UpdateRiskClauseRoleReq) error
	deleteFn     func(context.Context, *riskclauserole.AuditRiskClauseRoleReq) error
	closeFn      func(context.Context, *riskclauserole.AuditRiskClauseRoleReq) error
	submitFn     func(context.Context, *riskclauserole.SubmitApprovalReq) (string, error)
	approveURLFn func(context.Context, string) (string, error)
}

func (f *fakeRiskClauseRoleService) List(ctx context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
	if f.listFn != nil {
		return f.listFn(ctx, req)
	}
	return &riskclauserole.ListRiskClauseRoleResp{Total: 1}, nil
}

func (f *fakeRiskClauseRoleService) CreateRiskClauseRole(ctx context.Context, req *riskclauserole.CreateRiskClauseRoleReq) error {
	if f.createFn != nil {
		return f.createFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseRoleService) UpdateRiskClauseRole(ctx context.Context, req *riskclauserole.UpdateRiskClauseRoleReq) error {
	if f.updateFn != nil {
		return f.updateFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseRoleService) DeleteRiskClauseRole(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
	if f.deleteFn != nil {
		return f.deleteFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseRoleService) CloseRiskClauseRole(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
	if f.closeFn != nil {
		return f.closeFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseRoleService) SubmitApproval(ctx context.Context, req *riskclauserole.SubmitApprovalReq) (string, error) {
	if f.submitFn != nil {
		return f.submitFn(ctx, req)
	}
	return "approve-1", nil
}

func (f *fakeRiskClauseRoleService) GetApproveViewUrl(ctx context.Context, approveId string) (string, error) {
	if f.approveURLFn != nil {
		return f.approveURLFn(ctx, approveId)
	}
	return "https://approve.example", nil
}

func (f *fakeRiskClauseRoleService) ChangeRiskRoleCreator(ctx context.Context, contractNo, newCreator string, oldCreators []string) error {
	return nil
}

func mockRiskRoleBind(fill func(interface{})) {
	mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
		if fill != nil {
			fill(obj)
		}
		return nil
	}).Build()
}

func fillValidCreateRiskRole(req *riskclauserole.CreateRiskClauseRoleReq) {
	req.ContractNo = "C-1"
	req.RiskClauseType = 1
	req.ContractClauseNo = "R-1"
	req.RiskLevel = "P1"
	req.Reviewer = "a@example.com"
	req.ContractClauseDescription = "desc"
	req.ContractClauseAnalysis = "analysis"
}

func fillValidUpdateRiskRole(req *riskclauserole.UpdateRiskClauseRoleReq) {
	req.RiskRoleID = 1
	req.RiskClauseType = 1
	req.ContractClauseNo = "R-1"
	req.RiskLevel = "P1"
	req.ContractClauseDescription = "desc"
	req.ContractClauseAnalysis = "analysis"
}

func fillValidAuditRiskRole(req *riskclauserole.AuditRiskClauseRoleReq) {
	req.ContractNo = "C-1"
	req.RiskRoleID = 1
}

func TestNewOpenRiskClauseRoleHandler(t *testing.T) {
	mockey.PatchConvey("创建 open 风险条款 handler", t, func() {
		convey.So(NewOpenRiskClauseRoleHandler(), convey.ShouldNotBeNil)
	})
}

func TestOpenRiskClauseRoleHandlerListRiskClauseRole20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
			(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).ListRiskClauseRole20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("上下文操作人覆盖请求操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockRiskRoleBind(func(obj interface{}) { obj.(*riskclauserole.ListRiskClauseRoleReq).CurrentOperator = "origin" })
			var got string
			h := &openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{listFn: func(ctx context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
				got = req.CurrentOperator
				return &riskclauserole.ListRiskClauseRoleResp{}, nil
			}}}
			h.ListRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "ctx@example.com"), &app.RequestContext{})
			convey.So(got, convey.ShouldEqual, "ctx@example.com")
			convey.So(rec.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestOpenRiskClauseRoleHandlerCreateRiskClauseRole20210101(t *testing.T) {
	t.Run("校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockRiskRoleBind(nil)
			(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).CreateRiskClauseRole20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
		})
	})
	t.Run("成功创建", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockRiskRoleBind(func(obj interface{}) { fillValidCreateRiskRole(obj.(*riskclauserole.CreateRiskClauseRoleReq)) })
			(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).CreateRiskClauseRole20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestOpenRiskClauseRoleHandlerUpdateRiskClauseRole20210101(t *testing.T) {
	mockey.PatchConvey("成功更新返回 success", t, func() {
		rec := mockRiskClauseTplResp()
		mockRiskRoleBind(func(obj interface{}) { fillValidUpdateRiskRole(obj.(*riskclauserole.UpdateRiskClauseRoleReq)) })
		(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).UpdateRiskClauseRole20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.body, convey.ShouldEqual, "success")
	})
}

func TestOpenRiskClauseRoleHandlerDeleteRiskClauseRole20210101(t *testing.T) {
	mockey.PatchConvey("成功删除返回空响应", t, func() {
		rec := mockRiskClauseTplResp()
		mockRiskRoleBind(func(obj interface{}) { fillValidAuditRiskRole(obj.(*riskclauserole.AuditRiskClauseRoleReq)) })
		(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).DeleteRiskClauseRole20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestOpenRiskClauseRoleHandlerCloseRiskClauseRole20210101(t *testing.T) {
	mockey.PatchConvey("成功关闭返回空响应", t, func() {
		rec := mockRiskClauseTplResp()
		mockRiskRoleBind(func(obj interface{}) { fillValidAuditRiskRole(obj.(*riskclauserole.AuditRiskClauseRoleReq)) })
		(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).CloseRiskClauseRole20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestOpenRiskClauseRoleHandlerSubmit20210101(t *testing.T) {
	mockey.PatchConvey("成功提交返回审批ID", t, func() {
		rec := mockRiskClauseTplResp()
		mockRiskRoleBind(func(obj interface{}) { obj.(*riskclauserole.SubmitApprovalReq).ContractNo = "C-1" })
		(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).Submit20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.body, convey.ShouldEqual, "approve-1")
	})
}

func TestOpenRiskClauseRoleHandlerGetApproveViewUrl20210101(t *testing.T) {
	t.Run("缺少 ApproveId 返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).GetApproveViewUrl20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("成功返回审批链接", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ApproveId", "approve-1")
			(&openRiskClauseRoleHandler{service: &fakeRiskClauseRoleService{}}).GetApproveViewUrl20210101(context.Background(), c)
			convey.So(rec.body, convey.ShouldEqual, "https://approve.example")
		})
	})
}

package handler

import (
	"bytes"
	"context"
	"fmt"
	"net/http"
	"testing"

	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/comment"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/protocol"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
)

func Test_innerCommentHandler_ListComment20210101(t *testing.T) {
	type args struct {
		c *app.RequestContext
	}

	PatchConvey("test", t, func() {
		h := &innerCommentHandler{
			commentService: comment.NewCommentService(),
		}
		PatchConvey("testdata case1", func() {
			// 函数入参准备
			req := bizmodels.ListCommentReq{
				RelatedID: "123456",
			}
			params := args{
				c: &app.RequestContext{
					Request: *protocol.NewRequest("", "", bytes.NewReader([]byte(util.ToJSON(req)))),
				},
			}
			// Mock 代码准备
			Mock(GetMethod(h.commentService, "ListComment")).Return(&bizmodels.ListCommentResp{
				CommentList: []*bizmodels.Comment{},
			}, nil).Build()
			// 函数调用
			h.ListComment20210101(context.Background(), params.c)
		})
	})
}

func Test_innerCommentHandler_PublishComment20210101(t *testing.T) {
	PatchConvey("Test PublishComment20210101", t, func() {
		// Mock dependencies
		commentService := comment.NewCommentService()
		handler := &innerCommentHandler{
			commentService: commentService,
		}
		mockCtx := &app.RequestContext{}

		PatchConvey("Test BindAndValidate failed", func() {
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test Validate failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(errors.ErrorCommon.WithArgs("validation failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test PublishComment failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(nil).Build()
			Mock(GetMethod(commentService, "PublishComment")).Return(nil, errors.ErrorCommon.WithArgs("publish comment failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test PublishComment success", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(nil).Build()
			expectedResp := &bizmodels.PublishCommentResp{CommentID: "123"}
			Mock(GetMethod(commentService, "PublishComment")).Return(expectedResp, nil).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(mockCtx.Response.Body()), ShouldContainSubstring, `{"CommentID":"123"}`)
		})
	})
}

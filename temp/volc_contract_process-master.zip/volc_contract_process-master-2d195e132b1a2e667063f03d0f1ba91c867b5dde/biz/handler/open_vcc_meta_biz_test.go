package handler

import (
	"context"
	jsonV2 "encoding/json"
	errors001 "errors"
	"fmt"
	"net/http"
	"testing"
	"time"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/service/accountmanagement"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metabasic"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/bizmodels/modelmetaext"
	"volc_contract_process/biz/bizmodels/modelsupply"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/supply"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/biz/service/support/metaext"
	"volc_contract_process/biz/service/workflow"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/idgenerator"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
	"volc_contract_process/pkg/proxy/riskenginecli"
)

func TestNewOpenVCCMetaBizHandlerHandler(t *testing.T) {
	mockey.PatchConvey("constructor initializes all services", t, func() {
		h := NewOpenVCCMetaBizHandlerHandler()
		convey.So(h, convey.ShouldNotBeNil)

		handler, ok := h.(*openVCCMetaBizHandler)
		convey.So(ok, convey.ShouldBeTrue)
		convey.So(handler.metaService, convey.ShouldNotBeNil)
		convey.So(handler.metaServiceV2, convey.ShouldNotBeNil)
		convey.So(handler.metaExtService, convey.ShouldNotBeNil)
		convey.So(handler.riskEngineService, convey.ShouldNotBeNil)
		convey.So(handler.supplyService, convey.ShouldNotBeNil)
		convey.So(handler.salesContractService, convey.ShouldNotBeNil)
		convey.So(handler.opRecordService, convey.ShouldNotBeNil)
		convey.So(handler.bizContractService, convey.ShouldNotBeNil)
	})
}

func Test_openVCCMetaBizHandler_IsMeetSupplyCondition20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo:     "ContractNo",
						OperatorID:     "OperatorID",
						WhetherProject: "WhetherProject",
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supplyService,
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldBeNil)
			convey.So(doResponse, convey.ShouldResemble, resp)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo:     "ContractNo",
						OperatorID:     "OperatorID",
						WhetherProject: "WhetherProject",
					}
				}
				return fmt.Errorf("BindAndValidateFail")
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supply.NewSupplyService(),
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ValidateFail_ContractNo", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo:     "",
						OperatorID:     "OperatorID",
						WhetherProject: "WhetherProject",
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supply.NewSupplyService(),
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("ContractNo"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ValidateFail_OperatorID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo: "ContractNo",
						// OperatorID:     "OperatorID",
						WhetherProject: "WhetherProject",
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supply.NewSupplyService(),
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("OperatorID"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ValidateFail_WhetherProject", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo: "ContractNo",
						OperatorID: "OperatorID",
						// WhetherProject: "WhetherProject",
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supply.NewSupplyService(),
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("WhetherProject"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case IsMeetSupplyConditionFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			supplyService := supply.NewSupplyService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.IsMeetSupplyConditionReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.IsMeetSupplyConditionReq)) = bizmodels.IsMeetSupplyConditionReq{
						ContractNo:     "ContractNo",
						OperatorID:     "OperatorID",
						WhetherProject: "WhetherProject",
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			mockIsMeetSupplyCondition := mockey.GetMethod(supplyService, "IsMeetSupplyCondition")
			resp := &modelsupply.IsMeetSupplyConditionResp{
				SupportSupply:    true,
				SupplyConditions: make([]string, 0),
			}
			mockey.Mock(mockIsMeetSupplyCondition).Return(resp, errors.ErrorCommon.WithArgs("IsMeetSupplyConditionFail")).Build()
			// Act
			v := &openVCCMetaBizHandler{
				supplyService: supply.NewSupplyService(),
			}
			v.IsMeetSupplyCondition20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("IsMeetSupplyConditionFail"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
}

func Test_openVCCMetaBizHandler_GetSupplyContractList20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.GetSupplyContractListReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.GetSupplyContractListReq)) = bizmodels.GetSupplyContractListReq{
						FromContractNo:    "CTxxxxxx",
						NeedSupplyRelease: true,
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			resp := &bizmodels.SupplyContractListResp{
				ParentContractList: []string{"ParentContractList"},
			}

			mockGetSupplyContractList := mockey.GetMethod(metaService, "GetSupplyContractList")
			mockey.Mock(mockGetSupplyContractList).Return(resp, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			v.GetSupplyContractList20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldBeNil)
			convey.So(doResponse, convey.ShouldResemble, resp)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.GetSupplyContractListReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.GetSupplyContractListReq)) = bizmodels.GetSupplyContractListReq{
						FromContractNo:    "CTxxxxxx",
						NeedSupplyRelease: true,
					}
				}
				return fmt.Errorf("")
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			resp := &bizmodels.SupplyContractListResp{
				ParentContractList: []string{"ParentContractList"},
			}

			mockGetSupplyContractList := mockey.GetMethod(metaService, "GetSupplyContractList")
			mockey.Mock(mockGetSupplyContractList).Return(resp, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			v.GetSupplyContractList20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.GetSupplyContractListReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.GetSupplyContractListReq)) = bizmodels.GetSupplyContractListReq{
						FromContractNo:    "",
						NeedSupplyRelease: true,
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			resp := &bizmodels.SupplyContractListResp{
				ParentContractList: []string{"ParentContractList"},
			}

			mockGetSupplyContractList := mockey.GetMethod(metaService, "GetSupplyContractList")
			mockey.Mock(mockGetSupplyContractList).Return(resp, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			v.GetSupplyContractList20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("FromContractNo"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case GetSupplyContractListFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				switch obj.(type) {
				case *bizmodels.GetSupplyContractListReq: // Here replace with your model type, like Task{}
					*(obj.(*bizmodels.GetSupplyContractListReq)) = bizmodels.GetSupplyContractListReq{
						FromContractNo:    "CTxxxxxx",
						NeedSupplyRelease: true,
					}
				}
				return nil
			}).Build()

			var errorResp vhertz.APIError
			var doResponse interface{}

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()

			resp := &bizmodels.SupplyContractListResp{
				ParentContractList: []string{"ParentContractList"},
			}

			mockGetSupplyContractList := mockey.GetMethod(metaService, "GetSupplyContractList")
			mockey.Mock(mockGetSupplyContractList).Return(resp, errors.ErrorCommon).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			v.GetSupplyContractList20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrorCommon)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
}

/**
 * @Author: wangzhen.12@bytedance.com
 * @Date: 2024/8/5 20:00
 * @Desc:
 */

func Test_openVCCMetaBizHandler_PreCheckCreateContractPrice(t *testing.T) {
	t.Run("case PreCheckCreateContractPrice#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaServiceV2()
			preCheckCreateContractPriceMethod := mockey.GetMethod(metaService, "PreCheckCreateContractPrice")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(preCheckCreateContractPriceMethod).Return(
				&modelcommodity.PreCheckCreateContractPriceReqResp{}, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaServiceV2: metaService,
			}
			v.PreCheckCreateContractPrice20210101(context.Background(), &app.RequestContext{})

		})
	})
	t.Run("case GetContractSignURL#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()
			bizContractService := service.NewBizContractService()
			querySignUrlMethod := mockey.GetMethod(metaService, "QuerySignUrl")

			mockey.Mock(vhertz.DoResponse).Return().Build()
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				m, ok := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				if ok {
					m.BizScene = _const.BizScenePayOnBehalf
				}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(querySignUrlMethod).Return("", nil).Build()

			// Act
			v := &openBizContractHandler{
				bizContractService: bizContractService,
				metaService:        metaService,
			}
			v.GetContractSignURL20210101(context.Background(), &app.RequestContext{})

		})
	})
}

func Test_openVCCMetaBizHandler_DownloadBizContract20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).DownloadBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaService, "DownloadBiz")).Return([]byte("{}"), "FileId", "FileName", nil).Build()
			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.DownloadBizContract20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{}`)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrorCommon.WithArgs("download failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaService, "DownloadBiz")).Return(nil, "", "", serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{metaService: metaService}).DownloadBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
	t.Run("empty file data", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaService, "DownloadBiz")).Return([]byte{}, "", "", nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{metaService: metaService}).DownloadBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldBeNil)
		})
	})
}

func Test_openVCCMetaBizHandler_GetBizViewURL20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetBizViewURL20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaService, "GetViewURLBiz")).Return("URL", "FileName", nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.GetBizViewURL20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `Result":{"URL":"URL"}`)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrorCommon.WithArgs("view failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaService, "GetViewURLBiz")).Return("", "", serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{metaService: metaService}).GetBizViewURL20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_ListOperationRecord20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("ContractNo").Build()
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return([]*bizmodels.CooperationRecord{{}}, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			expectedBody, _ := jsonV2.Marshal([]*bizmodels.CooperationRecord{{}})
			// Assert
			convey.So(string(ctx.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
		})
	})
	t.Run("case miss ContractNo", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("").Build()
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return([]*bizmodels.CooperationRecord{{}}, nil).Build()

			// Act
			v := &openVCCMetaBizHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			// Assert
			convey.So(string(ctx.Response.Body()), convey.ShouldContainSubstring, "The parameter [ContractNo] is missing.")
		})
	})
	t.Run("case ListByContractNoFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("ContractNo").Build()
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return(nil, fmt.Errorf("ListByContractNoFail")).Build()

			// Act
			v := &openVCCMetaBizHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			// Assert
			convey.So(string(ctx.Response.Body()), convey.ShouldContainSubstring, `ListByContractNoFail`)
		})
	})
}

func Test_openVCCMetaBizHandler_NeedSubjectChangeAgreement20210101(t *testing.T) {
	mockey.PatchConvey("Test NeedSubjectChangeAgreement20210101", t, func() {
		c := &app.RequestContext{}
		metaServiceV2 := contractmeta.NewMetaServiceV2()
		h := &openVCCMetaBizHandler{
			metaServiceV2: metaServiceV2,
		}

		mockey.PatchConvey("Test BindAndValidate failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate error")).Build()
			h.NeedSubjectChangeAgreement20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test Validate failed", func() {
			param := contractmeta.NeedSubjectChangeAgreementReq{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(errors.ErrorCommon.WithArgs("validate error")).Build()
			h.NeedSubjectChangeAgreement20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test NeedSubjectChangeAgreement failed", func() {
			param := contractmeta.NeedSubjectChangeAgreementReq{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "NeedSubjectChangeAgreement")).Return(nil, errors.ErrorCommon.WithArgs("internal error")).Build()
			h.NeedSubjectChangeAgreement20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		})

		mockey.PatchConvey("Test NeedSubjectChangeAgreement success", func() {
			param := contractmeta.NeedSubjectChangeAgreementReq{}
			expectedRes := []*contractmeta.NeedSubjectChangeAgreementItem{
				{AccountID: "123", Need: true},
			}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "NeedSubjectChangeAgreement")).Return(expectedRes, nil).Build()
			h.NeedSubjectChangeAgreement20210101(context.Background(), c)
			expectedBody, _ := jsonV2.Marshal(map[string]interface{}{"List": expectedRes})
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_openVCCMetaBizHandler_GetEffectiveSubjectMap20210101(t *testing.T) {
	mockey.PatchConvey("Test GetEffectiveSubjectMap20210101", t, func() {
		// Mock the app.RequestContext
		c := &app.RequestContext{}
		param := &contractmeta.GetEffectiveSubjectMapReq{}
		metaServiceV2 := contractmeta.NewMetaServiceV2()
		h := &openVCCMetaBizHandler{
			metaServiceV2: metaServiceV2,
		}

		// Mock the binding.BindAndValidate function
		mockey.PatchConvey("Test binding.BindAndValidate failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate failed")).Build()
			h := &openVCCMetaBizHandler{}
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		// Mock the param.Validate function
		mockey.PatchConvey("Test param.Validate failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(errors.ErrorCommon.WithArgs("validate failed")).Build()
			h := &openVCCMetaBizHandler{}
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		// Mock the metaServiceV2.GetEffectiveSubjectMap function
		mockey.PatchConvey("Test metaServiceV2.GetEffectiveSubjectMap failed", func() {
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(nil, errors.ErrorCommon.WithArgs("get effective subject map failed")).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		})

		// Mock the metaServiceV2.GetEffectiveSubjectMap function successfully
		mockey.PatchConvey("Test metaServiceV2.GetEffectiveSubjectMap success", func() {
			expectedRes := map[string]*bizmodels.TradePartyInfoDetail{
				"account1": {
					AccountID: "account1",
					// Fill in other fields as needed
				},
			}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(expectedRes, nil).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			expectedBody, _ := jsonV2.Marshal(expectedRes)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_openVCCMetaBizHandler_CheckCurrencyAndExchangeRate20210101(t *testing.T) {
	mockey.PatchConvey("Test_openVCCMetaBizHandler_CheckCurrencyAndExchangeRate20210101", t, func() {
		h := &openVCCMetaBizHandler{}
		c := &app.RequestContext{
			Keys: make(map[string]interface{}),
		}

		mockey.PatchConvey("success case", func() {
			// 场景描述：
			// 构造数据：构造一个有效的请求参数，使得所有校验和调用都成功。
			// 逻辑链路：
			// 1. mockey.Mock `binding.BindAndValidate`，模拟成功绑定并填充一个有效的 param 结构体。
			// 2. `param.Validate()` 调用成功。
			// 3. mockey.Mock `basicinfo.CheckCurrencyAndExchangeRate`，模拟服务调用成功，返回预期的响应。
			// 4. mockey.Mock `vhertz.DoResponse`，断言其被调用且传入了正确的响应数据。

			mockResp := &metabasic.CheckCurrencyAndExchangeRateResp{
				Agree: true,
				List:  []*metabasic.CurrencyAndExchangeRateData{},
			}

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p, ok := obj.(*metabasic.CheckCurrencyAndExchangeRateReq)
				convey.So(ok, convey.ShouldBeTrue)
				p.AccountIDs = []string{"12345"}
				p.CurrencyCode = "USD"
				return nil
			}).Build()

			mockey.Mock(basicinfo.CheckCurrencyAndExchangeRate).Return(mockResp, nil).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				resp, ok := result.(*metabasic.CheckCurrencyAndExchangeRateResp)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(resp, convey.ShouldResemble, mockResp)
			}).Build()

			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
		})

		mockey.PatchConvey("error case: bind and validate fail", func() {
			// 场景描述：
			// 构造数据：无。
			// 逻辑链路：
			// 1. mockey.Mock `binding.BindAndValidate`，使其返回一个错误。
			// 2. 函数应捕获此错误，记录日志，并调用 `vhertz.ErrorResp` 返回参数解析错误。
			// 3. 后续的 `param.Validate()` 和服务调用不应被执行。

			bindErr := errors001.New("bind error")
			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, errors.ErrParamParseFail)
			}).Build()

			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
		})

		mockey.PatchConvey("error case: param validate fail", func() {
			// 场景描述：
			// 构造数据：通过 Mock `binding.BindAndValidate` 填充一个无效的 param (AccountIDs为空)，这将导致 `param.Validate()` 失败。
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 成功，但填充了无效数据。
			// 2. `param.Validate()` 被调用并返回一个 "MissingParam" 错误。
			// 3. 函数应捕获此错误，记录日志，并调用 `vhertz.ErrorResp` 返回该错误。

			validateErr := errors.ErrMissingParam.WithArgs("AccountIDs")

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p, ok := obj.(*metabasic.CheckCurrencyAndExchangeRateReq)
				convey.So(ok, convey.ShouldBeTrue)
				// 设置无效数据，使 Validate() 失败
				p.AccountIDs = []string{}
				p.CurrencyCode = "CNY"
				return nil
			}).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.Error(), convey.ShouldEqual, validateErr.Error())
			}).Build()

			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
		})

		mockey.PatchConvey("error case: CheckCurrencyAndExchangeRate service fail", func() {
			// 场景描述：
			// 构造数据：构造有效的请求参数。
			// 逻辑链路：
			// 1. `binding.BindAndValidate` 和 `param.Validate()` 都成功。
			// 2. mockey.Mock `basicinfo.CheckCurrencyAndExchangeRate`，使其返回一个错误。
			// 3. 函数应捕获此错误，将其包装为 `ErrInternalError`，并调用 `vhertz.ErrorResp` 返回。

			serviceErr := errors.ErrorCommon.WithArgs("db connection failed")

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p, ok := obj.(*metabasic.CheckCurrencyAndExchangeRateReq)
				convey.So(ok, convey.ShouldBeTrue)
				p.AccountIDs = []string{"12345"}
				p.CurrencyCode = "USD"
				return nil
			}).Build()

			mockey.Mock(basicinfo.CheckCurrencyAndExchangeRate).Return(nil, serviceErr).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.Error(), convey.ShouldContainSubstring, "InternalError")
				convey.So(err.Error(), convey.ShouldContainSubstring, serviceErr.Error())
			}).Build()

			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
		})
	})
}

func Test_openVCCMetaBizHandler_SubmitComplianceCheck20210101(t *testing.T) {
	// MockRiskEngineService is a mock for the riskengineservice.RiskEngineService interface.
	type MockRiskEngineService struct {
		riskengineservice.RiskEngineService
	}

	mockey.PatchConvey("Test_openVCCMetaBizHandler_SubmitComplianceCheck20210101", t, func() {
		// 准备通用mock

		// 准备handler实例
		mockRiskEngineSvc := &MockRiskEngineService{}
		h := &openVCCMetaBizHandler{
			riskEngineService: mockRiskEngineSvc,
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("scenario: bind and validate fails", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. binding.BindAndValidate返回一个错误
			// 2. 函数记录错误日志并调用vhertz.ErrorResp返回参数解析错误
			var capturedError vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind error")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.SubmitComplianceCheck20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldResemble, errors.ErrParamParseFail)
		})

		mockey.PatchConvey("scenario: parameter validation fails", func() {
			// 场景描述：
			// 构造数据：构造一个无法通过Validate()方法的param
			// 逻辑链路：
			// 1. binding.BindAndValidate成功
			// 2. param.Validate()失败
			// 3. 函数记录错误日志并调用vhertz.ErrorResp返回相应的参数错误
			var capturedError vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			convey.Convey("when ContractNo is empty", func() {
				// 构造一个空的ContractNo，这将导致Validate返回ErrMissingParam
				mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
					param, ok := obj.(*bizmodels.SubmitComplianceCheckReq)
					if ok {
						param.ContractNo = ""
					}
					return nil
				}).Build()

				h.SubmitComplianceCheck20210101(context.Background(), c)

				convey.So(capturedError, convey.ShouldNotBeNil)
				convey.So(capturedError.GetCode(), convey.ShouldEqual, "MissingParam")
			})

			convey.Convey("when ContractNo has invalid prefix", func() {
				// 构造一个无效前缀的ContractNo，这将导致Validate返回ErrInvalidParam
				mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
					param, ok := obj.(*bizmodels.SubmitComplianceCheckReq)
					if ok {
						param.ContractNo = "INVALID-PREFIX"
					}
					return nil
				}).Build()

				h.SubmitComplianceCheck20210101(context.Background(), c)

				convey.So(capturedError, convey.ShouldNotBeNil)
				convey.So(capturedError.GetCode(), convey.ShouldEqual, "InvalidParam")
			})
		})

		mockey.PatchConvey("scenario: risk engine service submit fails", func() {
			// 场景描述：
			// 构造数据：构造一个有效的param
			// 逻辑链路：
			// 1. binding.BindAndValidate和param.Validate()都成功
			// 2. h.riskEngineService.Submit返回一个错误
			// 3. 函数调用vhertz.ErrorResp返回内部错误
			var capturedError vhertz.APIError
			submitErr := errors.NewErr("submit_fail", "submit failed", 500)

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param, ok := obj.(*bizmodels.SubmitComplianceCheckReq)
				if ok {
					param.ContractNo = "CT12345"
				}
				return nil
			}).Build()
			mockey.Mock((*MockRiskEngineService).Submit).Return(nil, submitErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.SubmitComplianceCheck20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(capturedError.GetArgs(), convey.ShouldResemble, []interface{}{submitErr})
		})

		mockey.PatchConvey("scenario: success", func() {
			// 场景描述：
			// 构造数据：构造一个有效的param
			// 逻辑链路：
			// 1. 所有前置步骤都成功
			// 2. h.riskEngineService.Submit返回成功响应
			// 3. 函数调用vhertz.DoResponse返回成功响应
			var doResponseCalled bool
			var capturedResp interface{}
			expectedResp := &riskenginecli.RiskEngineResp{RetCode: "0", RetMsg: "success"}

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				param, ok := obj.(*bizmodels.SubmitComplianceCheckReq)
				if ok {
					param.ContractNo = "PCT12345"
				}
				return nil
			}).Build()
			mockey.Mock((*MockRiskEngineService).Submit).Return(expectedResp, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
				capturedResp = result
			}).Build()

			h.SubmitComplianceCheck20210101(context.Background(), c)

			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedResp, convey.ShouldResemble, expectedResp)
		})
	})
}

func Test_openVCCMetaBizHandler_GetMetaExt20210101(t *testing.T) {
	mockey.PatchConvey("Test_openVCCMetaBizHandler_GetMetaExt20210101", t, func() {
		// General setup for all scenarios
		mockMetaExtSvc := metaext.NewService()
		h := &openVCCMetaBizHandler{
			metaExtService: mockMetaExtSvc,
		}
		c := &app.RequestContext{}

		// Mock common functions

		mockey.PatchConvey("Success", func() {
			// 场景描述:
			// 构造数据: 构造一个有效的请求参数，其中ContractNo不为空。
			// 逻辑链路:
			// 1. binding.BindAndValidate 成功，并填充了请求参数。
			// 2. param.Validate() 成功。
			// 3. dal.NewContractMetaDao().FindLastByNo 成功返回一个有效的合同元数据。
			// 4. h.metaExtService.GetMetaExtMap 成功返回扩展属性 map。
			// 5. vhertz.DoResponse 被调用，返回成功响应。

			// Data preparation
			param := modelmetaext.GetMetaExtReq{
				ContractNo: "test-contract-no",
				AttrKeys:   []string{"key1", "key2"},
			}
			metaDB := &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Id: 1,
				},
				ContractNo: "test-contract-no",
			}
			extMap := map[string]string{
				"key1": "value1",
				"key2": "value2",
			}
			var finalResp interface{}

			// Mocking
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if req, ok := obj.(*modelmetaext.GetMetaExtReq); ok {
					*req = param
				}
				return nil
			}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(metaDB, nil).Build()
			mockey.Mock(mockey.GetMethod(mockMetaExtSvc, "GetMetaExtMap")).Return(extMap, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				finalResp = result
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(finalResp, convey.ShouldResemble, extMap)
		})

		mockey.PatchConvey("Failure: BindAndValidate fails", func() {
			// 场景描述:
			// 构造数据: 无
			// 逻辑链路:
			// 1. binding.BindAndValidate 返回一个错误。
			// 2. 函数应记录错误并调用 vhertz.ErrorResp 返回参数解析失败的错误。

			// Data preparation
			bindErr := fmt.Errorf("bind error")
			var capturedErr vhertz.APIError

			// Mocking
			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(capturedErr, convey.ShouldEqual, errors.ErrParamParseFail)
		})

		mockey.PatchConvey("Failure: param.Validate fails", func() {
			// 场景描述:
			// 构造数据: 构造一个无效的请求参数，其中ContractNo为空。
			// 逻辑链路:
			// 1. binding.BindAndValidate 成功。
			// 2. param.Validate() 失败并返回一个错误。
			// 3. 函数应记录错误并调用 vhertz.ErrorResp 返回参数验证失败的错误。

			// Data preparation
			param := modelmetaext.GetMetaExtReq{
				ContractNo: "", // Empty contract number to fail validation
			}
			var capturedErr vhertz.APIError

			// Mocking
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if req, ok := obj.(*modelmetaext.GetMetaExtReq); ok {
					*req = param
				}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(capturedErr.Error(), convey.ShouldContainSubstring, "The parameter [ContractNo] is missing.")
		})

		mockey.PatchConvey("Failure: dal.FindLastByNo returns error", func() {
			// 场景描述:
			// 构造数据: 构造一个有效的请求参数。
			// 逻辑链路:
			// 1. binding.BindAndValidate 和 param.Validate() 均成功。
			// 2. dal.NewContractMetaDao().FindLastByNo 返回一个数据库错误。
			// 3. 函数应记录错误并调用 vhertz.ErrorResp 返回查询失败的错误。

			// Data preparation
			param := modelmetaext.GetMetaExtReq{
				ContractNo: "test-contract-no",
			}
			dbErr := fmt.Errorf("database error")
			var capturedErr vhertz.APIError

			// Mocking
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if req, ok := obj.(*modelmetaext.GetMetaExtReq); ok {
					*req = param
				}
				return nil
			}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, dbErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(capturedErr.Error(), convey.ShouldContainSubstring, "查询合同信息失败")
		})

		mockey.PatchConvey("Failure: dal.FindLastByNo returns nil (not found)", func() {
			// 场景描述:
			// 构造数据: 构造一个有效的请求参数。
			// 逻辑链路:
			// 1. binding.BindAndValidate 和 param.Validate() 均成功。
			// 2. dal.NewContractMetaDao().FindLastByNo 成功但返回 nil，表示合同不存在。
			// 3. 函数应记录错误并调用 vhertz.ErrorResp 返回 meta is nil 的错误。

			// Data preparation
			param := modelmetaext.GetMetaExtReq{
				ContractNo: "test-contract-no",
			}
			var capturedErr vhertz.APIError

			// Mocking
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if req, ok := obj.(*modelmetaext.GetMetaExtReq); ok {
					*req = param
				}
				return nil
			}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(capturedErr.Error(), convey.ShouldContainSubstring, "meta is nil")
		})

		mockey.PatchConvey("Failure: metaExtService.GetMetaExtMap returns error", func() {
			// 场景描述:
			// 构造数据: 构造一个有效的请求参数。
			// 逻辑链路:
			// 1. 前置步骤均成功，dal.NewContractMetaDao().FindLastByNo 返回有效合同。
			// 2. h.metaExtService.GetMetaExtMap 返回一个错误。
			// 3. 函数应记录错误并调用 vhertz.ErrorResp 返回内部错误的提示。

			// Data preparation
			param := modelmetaext.GetMetaExtReq{
				ContractNo: "test-contract-no",
			}
			metaDB := &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Id: 1,
				},
				ContractNo: "test-contract-no",
			}
			serviceErr := fmt.Errorf("service error")
			var capturedErr vhertz.APIError

			// Mocking
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if req, ok := obj.(*modelmetaext.GetMetaExtReq); ok {
					*req = param
				}
				return nil
			}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(metaDB, nil).Build()
			mockey.Mock(mockey.GetMethod(mockMetaExtSvc, "GetMetaExtMap")).Return(nil, serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// Call the target function
			h.GetMetaExt20210101(context.Background(), c)

			// Assertions
			convey.So(capturedErr.Error(), convey.ShouldContainSubstring, "GetMetaExtMapFail")
			convey.So(capturedErr, convey.ShouldResemble, errors.ErrInternalError.WithArgs("GetMetaExtMapFail"))
		})
	})
}

func Test_openVCCMetaBizHandler_GetContractSignURL20210101(t *testing.T) {
	t.Run("BindAndValidate returns parse error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			reqCtx := &app.RequestContext{}

			bindErr := errors001.New("bind failed")
			var capturedErr vhertz.APIError
			errorRespCalled := false
			doResponseCalled := false

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, _ interface{}) error {
				return bindErr
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doResponseCalled = true
			}).Build()

			handler.GetContractSignURL20210101(context.Background(), reqCtx)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("BizScene is not supported after binding", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			reqCtx := &app.RequestContext{}

			var capturedErr vhertz.APIError
			errorRespCalled := false
			doResponseCalled := false

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				param.BizScene = 999
				param.ContractNo = "CN-001"
				param.AccountID = 12
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doResponseCalled = true
			}).Build()

			handler.GetContractSignURL20210101(context.Background(), reqCtx)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInvalidParam.GetCode())
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"BizScene"})
		})
	})

	t.Run("QuerySignUrl returns api error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			handler := &openVCCMetaBizHandler{metaService: metaService}
			reqCtx := &app.RequestContext{}

			queryErr := errors.NewErr("QueryFailed", "query failed", 500)
			var rpcCtx context.Context
			var receivedContractNo string
			var receivedAccountID string
			var capturedErr vhertz.APIError
			errorRespCalled := false
			doResponseCalled := false

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				param.BizScene = _const.BizScenePayOnBehalf
				param.ContractNo = "CN-QUERY-ERR"
				param.AccountID = 12345
				return nil
			}).Build()
			mockey.MockUnsafe(mockey.GetMethod(metaService, "QuerySignUrl")).To(
				func(ctx context.Context, contractNo string, accountID string) (string, errors.APIError) {
					rpcCtx = ctx
					receivedContractNo = contractNo
					receivedAccountID = accountID
					return "", queryErr
				},
			).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doResponseCalled = true
			}).Build()

			handler.GetContractSignURL20210101(context.Background(), reqCtx)

			convey.So(rpcCtx, convey.ShouldNotBeNil)
			convey.So(receivedContractNo, convey.ShouldEqual, "CN-QUERY-ERR")
			convey.So(receivedAccountID, convey.ShouldEqual, "12345")
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, queryErr.GetCode())
		})
	})

	t.Run("QuerySignUrl returns sign url", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			handler := &openVCCMetaBizHandler{metaService: metaService}
			reqCtx := &app.RequestContext{}

			signURL := "https://sign.example.com/contract"
			var rpcCtx context.Context
			var receivedContractNo string
			var receivedAccountID string
			var capturedResult interface{}
			errorRespCalled := false
			doResponseCalled := false

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				param := obj.(*bizmodels.OpenBizContractGetSignURLParam)
				param.BizScene = _const.BizSceneMarket
				param.ContractNo = "CN-SUCCESS"
				param.AccountID = 67890
				return nil
			}).Build()
			mockey.MockUnsafe(mockey.GetMethod(metaService, "QuerySignUrl")).To(
				func(ctx context.Context, contractNo string, accountID string) (string, errors.APIError) {
					rpcCtx = ctx
					receivedContractNo = contractNo
					receivedAccountID = accountID
					return signURL, nil
				},
			).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				doResponseCalled = true
				capturedResult = result
			}).Build()

			handler.GetContractSignURL20210101(context.Background(), reqCtx)

			convey.So(rpcCtx, convey.ShouldNotBeNil)
			convey.So(receivedContractNo, convey.ShouldEqual, "CN-SUCCESS")
			convey.So(receivedAccountID, convey.ShouldEqual, "67890")
			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{"SignURL": signURL})
		})
	})
}

func Test_openVCCMetaBizHandler_SubmitBizDraft20210101(t *testing.T) {
	t.Run("BindAndValidate returns param parse error response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			bindErr := errors001.New("bind failed")
			var errorRespCalled bool
			var doResponseCalled bool
			var capturedErr vhertz.APIError

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				return bindErr
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			if capturedErr != nil {
				convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			}
		})
	})

	t.Run("Legacy quote scene maps to quote submit and returns success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			expectedParam := bizmodels.OpenBizContractSubmitParam{
				BaseBizContractParam: bizmodels.BaseBizContractParam{
					ContractNo:      "CN-QUOTE-1",
					ContractVersion: 2,
					BizScene:        _const.BizSceneQuoteContract,
					BizIdentifier:   "quote-biz-1",
				},
				CurrentOperator: "operator-quote",
				BizSource:       0,
				AccountID:       101,
			}
			expectedResp := &workflow.ResultMetaSubmitBizDraft{}
			var capturedTask *workflow.EventContext
			var capturedResult interface{}
			var doResponseCalled bool
			var errorRespCalled bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractSubmitParam) = expectedParam
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return expectedResp, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
				capturedResult = result
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, expectedResp)
			convey.So(capturedTask, convey.ShouldNotBeNil)
			if capturedTask != nil {
				convey.So(capturedTask.TaskType, convey.ShouldEqual, workflow.TaskTypeQuoteSubmit)
				capturedParam, ok := capturedTask.EventExtInfo.(*bizmodels.OpenBizContractSubmitParam)
				convey.So(ok, convey.ShouldBeTrue)
				if ok {
					convey.So(capturedParam.BaseBizContractParam, convey.ShouldResemble, expectedParam.BaseBizContractParam)
					convey.So(capturedParam.CurrentOperator, convey.ShouldEqual, expectedParam.CurrentOperator)
					convey.So(capturedParam.BizSource, convey.ShouldEqual, expectedParam.BizSource)
					convey.So(capturedParam.AccountID, convey.ShouldEqual, expectedParam.AccountID)
				}
			}
		})
	})

	t.Run("Legacy partner scene maps to partner submit and returns process error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			expectedParam := bizmodels.OpenBizContractSubmitParam{
				BaseBizContractParam: bizmodels.BaseBizContractParam{
					ContractNo:      "CN-PARTNER-1",
					ContractVersion: 3,
					BizScene:        _const.BizScenePartnerContract,
					BizIdentifier:   "partner-biz-1",
				},
				CurrentOperator: "operator-partner",
				BizSource:       0,
				AccountID:       202,
			}
			processErr := errors.NewErr("ProcessFail", "process failed", 500)
			var capturedTask *workflow.EventContext
			var capturedErr vhertz.APIError
			var errorRespCalled bool
			var doResponseCalled bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractSubmitParam) = expectedParam
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return nil, processErr
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			if capturedErr != nil {
				convey.So(capturedErr.GetCode(), convey.ShouldEqual, processErr.GetCode())
			}
			convey.So(capturedTask, convey.ShouldNotBeNil)
			if capturedTask != nil {
				convey.So(capturedTask.TaskType, convey.ShouldEqual, workflow.TaskTypePartnerSubmit)
				capturedParam, ok := capturedTask.EventExtInfo.(*bizmodels.OpenBizContractSubmitParam)
				convey.So(ok, convey.ShouldBeTrue)
				if ok {
					convey.So(capturedParam.BaseBizContractParam, convey.ShouldResemble, expectedParam.BaseBizContractParam)
					convey.So(capturedParam.BizSource, convey.ShouldEqual, expectedParam.BizSource)
				}
			}
		})
	})

	t.Run("Explicit partner quote source maps to partner quote submit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			expectedParam := bizmodels.OpenBizContractSubmitParam{
				BaseBizContractParam: bizmodels.BaseBizContractParam{
					ContractNo:      "CN-PARTNER-QUOTE-1",
					ContractVersion: 4,
					BizScene:        999,
					BizIdentifier:   "partner-quote-biz-1",
				},
				CurrentOperator: "operator-partner-quote",
				BizSource:       _const.BizSourcePartnerQuote,
				AccountID:       303,
			}
			expectedResp := &workflow.ResultMetaSubmitBizDraft{}
			var capturedTask *workflow.EventContext
			var capturedResult interface{}
			var doResponseCalled bool
			var errorRespCalled bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractSubmitParam) = expectedParam
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return expectedResp, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
				capturedResult = result
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, expectedResp)
			convey.So(capturedTask, convey.ShouldNotBeNil)
			if capturedTask != nil {
				convey.So(capturedTask.TaskType, convey.ShouldEqual, workflow.TaskTypePartnerQuoteSubmit)
				capturedParam, ok := capturedTask.EventExtInfo.(*bizmodels.OpenBizContractSubmitParam)
				convey.So(ok, convey.ShouldBeTrue)
				if ok {
					convey.So(capturedParam.BizSource, convey.ShouldEqual, expectedParam.BizSource)
					convey.So(capturedParam.BizScene, convey.ShouldEqual, expectedParam.BizScene)
				}
			}
		})
	})

	t.Run("Explicit market source maps to market submit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			expectedParam := bizmodels.OpenBizContractSubmitParam{
				BaseBizContractParam: bizmodels.BaseBizContractParam{
					ContractNo:      "CN-MARKET-1",
					ContractVersion: 5,
					BizScene:        888,
					BizIdentifier:   "market-biz-1",
				},
				CurrentOperator: "operator-market",
				BizSource:       _const.BizSourceMarket,
				AccountID:       404,
			}
			expectedResp := &workflow.ResultMetaSubmitBizDraft{}
			var capturedTask *workflow.EventContext
			var capturedResult interface{}
			var doResponseCalled bool
			var errorRespCalled bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractSubmitParam) = expectedParam
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return expectedResp, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
				capturedResult = result
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, expectedResp)
			convey.So(capturedTask, convey.ShouldNotBeNil)
			if capturedTask != nil {
				convey.So(capturedTask.TaskType, convey.ShouldEqual, workflow.TaskTypeMarketSubmitOA)
				capturedParam, ok := capturedTask.EventExtInfo.(*bizmodels.OpenBizContractSubmitParam)
				convey.So(ok, convey.ShouldBeTrue)
				if ok {
					convey.So(capturedParam.BizSource, convey.ShouldEqual, expectedParam.BizSource)
					convey.So(capturedParam.BizScene, convey.ShouldEqual, expectedParam.BizScene)
				}
			}
		})
	})

	t.Run("Unsupported biz scene returns common error response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := &openVCCMetaBizHandler{}
			requestContext := &app.RequestContext{}
			expectedParam := bizmodels.OpenBizContractSubmitParam{
				BaseBizContractParam: bizmodels.BaseBizContractParam{
					ContractNo:      "CN-UNSUPPORTED-1",
					ContractVersion: 6,
					BizScene:        777,
					BizIdentifier:   "unsupported-biz-1",
				},
				CurrentOperator: "operator-unsupported",
				BizSource:       0,
				AccountID:       505,
			}
			var processCalled bool
			var doResponseCalled bool
			var errorRespCalled bool
			var capturedErr vhertz.APIError

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractSubmitParam) = expectedParam
				return nil
			}).Build()
			mockey.MockUnsafe(i18nfmt.Sprintf).Return("unsupported scene").Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				processCalled = true
				return nil, nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				capturedErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()

			handler.SubmitBizDraft20210101(context.Background(), requestContext)

			convey.So(processCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(capturedErr, convey.ShouldNotBeNil)
			if capturedErr != nil {
				convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
				convey.So(capturedErr.GetArgs(), convey.ShouldHaveLength, 1)
				convey.So(capturedErr.GetArgs()[0], convey.ShouldEqual, "unsupported scene")
			}
		})
	})
}

func Test_openVCCMetaBizHandler_CreateBizDraft20210101(t *testing.T) {
	t.Run("Bind and validate failed returns error response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bindErr := errors001.New("bind error")
			mockey.MockUnsafe(binding.BindAndValidate).Return(bindErr).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "ParamParseFail")
		})
	})

	t.Run("Quote scene mapped and process returns error triggers error response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizScene: _const.BizSceneQuoteContract,
				IsUpdate: true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return nil, errors.ErrorCommon.WithArgs("workflow failed")
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeQuoteCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "ErrorCommon")
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "workflow failed")
		})
	})

	t.Run("Quote scene mapped and process returns nil result triggers error response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizScene: _const.BizSceneQuoteContract,
				IsUpdate: true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return nil, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeQuoteCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 500)
		})
	})

	t.Run("Quote scene mapped and process returns result triggers success response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizScene: _const.BizSceneQuoteContract,
				IsUpdate: true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return &workflow.ResultMetaBizCreate{ContractNo: "market-ok"}, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeQuoteCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "market-ok")
		})
	})

	t.Run("Partner scene mapped selects partner task type and returns success response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizScene: _const.BizScenePartnerContract,
				IsUpdate: true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return &workflow.ResultMetaBizCreate{ContractNo: "market-ok"}, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypePartnerCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "market-ok")
		})
	})

	t.Run("Direct biz source PartnerQuote selects partner quote task and returns success response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizSource: _const.BizSourcePartnerQuote,
				IsUpdate:  true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return &workflow.ResultMetaBizCreate{ContractNo: "market-ok"}, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypePartnerQuoteCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "market-ok")
		})
	})

	t.Run("Direct biz source Credit selects credit task and returns success response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizSource: _const.BizSourceCredit,
				IsUpdate:  true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return &workflow.ResultMetaBizCreate{ContractNo: "credit-ok"}, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeCreditCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "credit-ok")
		})
	})

	t.Run("Direct biz source Market selects market task and returns success response", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizSource: _const.BizSourceMarket,
				IsUpdate:  true,
			}
			var gotTaskType workflow.TaskType
			var gotIsUpdate bool

			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()
			mockey.Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = task.TaskType
				if p, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam); ok {
					gotIsUpdate = p.IsUpdate
				}
				return &workflow.ResultMetaBizCreate{ContractNo: "market-ok"}, nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeMarketCreateOrUpdateDraft)
			convey.So(gotIsUpdate, convey.ShouldBeFalse)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"ContractNo":"market-ok"`)
		})
	})

	t.Run("Zero biz source with unsupported scene returns unsupported biz source error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			param := bizmodels.OpenBizContractMetaCreateParam{
				BizSource: 0,
				BizScene:  1,
				IsUpdate:  true,
			}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				target, ok := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				if !ok {
					return errors001.New("unexpected bind target")
				}
				*target = param
				return nil
			}).Build()

			handler := &openVCCMetaBizHandler{}
			c := &app.RequestContext{}
			handler.CreateBizDraft20210101(context.Background(), c)

			convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "ErrorCommon")
		})
	})
}

func Test_openVCCMetaBizHandler_UpdateBizDraft20210101(t *testing.T) {
	t.Run("Bind and validate returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			bindErr := errors001.New("bind failed")

			var capturedErr vhertz.APIError

			mockey.MockUnsafe(binding.BindAndValidate).Return(bindErr).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(capturedErr.HttpStatus(), convey.ShouldEqual, errors.ErrParamParseFail.HttpStatus())
		})
	})

	t.Run("Fallback quote scene maps to quote task and responds successfully", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			expectedResult := &workflow.ResultMetaBizCreate{ContractNo: "quote"}

			var capturedResult interface{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizScene: _const.BizSceneQuoteContract,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				convey.So(task, convey.ShouldNotBeNil)
				convey.So(task.TaskType, convey.ShouldEqual, workflow.TaskTypeQuoteCreateOrUpdateDraft)

				param, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				convey.So(param.BizScene, convey.ShouldEqual, _const.BizSceneQuoteContract)
				convey.So(param.BizSource, convey.ShouldEqual, 0)

				return expectedResult, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedResult, convey.ShouldEqual, expectedResult)
		})
	})

	t.Run("Fallback partner scene maps to partner task and returns workflow error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			expectedErr := errors.ErrInternalError

			var capturedErr vhertz.APIError

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizScene:  _const.BizScenePartnerContract,
					BizSource: _const.BizSourcePartner,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				convey.So(task, convey.ShouldNotBeNil)
				convey.So(task.TaskType, convey.ShouldEqual, workflow.TaskTypePartnerCreateOrUpdateDraft)

				param, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				convey.So(param.BizScene, convey.ShouldEqual, _const.BizScenePartnerContract)
				convey.So(param.BizSource, convey.ShouldEqual, _const.BizSourcePartner)

				return nil, expectedErr
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, expectedErr.GetCode())
			convey.So(capturedErr.HttpStatus(), convey.ShouldEqual, expectedErr.HttpStatus())
		})
	})

	t.Run("Direct partner quote source maps to partner quote task", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			expectedResult := &workflow.ResultMetaBizCreate{ContractNo: "partnerQuote"}

			var capturedResult interface{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizScene:  _const.BizSceneQuoteContract,
					BizSource: _const.BizSourcePartnerQuote,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				convey.So(task, convey.ShouldNotBeNil)
				convey.So(task.TaskType, convey.ShouldEqual, workflow.TaskTypePartnerQuoteCreateOrUpdateDraft)

				param, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				convey.So(param.BizSource, convey.ShouldEqual, _const.BizSourcePartnerQuote)

				return expectedResult, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedResult, convey.ShouldEqual, expectedResult)
		})
	})

	t.Run("Direct credit source maps to credit task", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			expectedResult := &workflow.ResultMetaBizCreate{ContractNo: "credit"}

			var capturedResult interface{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizSource: _const.BizSourceCredit,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				convey.So(task, convey.ShouldNotBeNil)
				convey.So(task.TaskType, convey.ShouldEqual, workflow.TaskTypeCreditCreateOrUpdateDraft)

				param, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				convey.So(param.BizSource, convey.ShouldEqual, _const.BizSourceCredit)

				return expectedResult, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedResult, convey.ShouldEqual, expectedResult)
		})
	})

	t.Run("Direct market source maps to market task", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}
			expectedResult := &workflow.ResultMetaBizCreate{ContractNo: "market"}

			var capturedResult interface{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizSource: _const.BizSourceMarket,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(workflow.Process).To(func(ctx context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				convey.So(task, convey.ShouldNotBeNil)
				convey.So(task.TaskType, convey.ShouldEqual, workflow.TaskTypeMarketCreateOrUpdateDraft)

				param, ok := task.EventExtInfo.(*bizmodels.OpenBizContractMetaCreateParam)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(param.IsUpdate, convey.ShouldBeTrue)
				convey.So(param.BizSource, convey.ShouldEqual, _const.BizSourceMarket)

				return expectedResult, nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedResult, convey.ShouldEqual, expectedResult)
		})
	})

	t.Run("Unsupported zero biz source returns common error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			reqCtx := &app.RequestContext{}
			handler := &openVCCMetaBizHandler{}

			var capturedErr vhertz.APIError

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				target := obj.(*bizmodels.OpenBizContractMetaCreateParam)
				*target = bizmodels.OpenBizContractMetaCreateParam{
					BizScene: 999,
				}
				return nil
			}).Build()
			mockey.MockUnsafe(i18nfmt.Sprintf).Return("unsupported bizsource").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			handler.UpdateBizDraft20210101(context.Background(), reqCtx)

			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(len(capturedErr.GetArgs()), convey.ShouldEqual, 1)
			convey.So(capturedErr.GetArgs()[0], convey.ShouldEqual, "unsupported bizsource")
		})
	})
}

func Test_openVCCMetaBizHandler_CustomAuditBizContract20210101(t *testing.T) {
	mockey.PatchConvey("Test_openVCCMetaBizHandler_CustomAuditBizContract20210101", t, func() {

		mockey.PatchConvey("场景：参数绑定失败，直接返回错误响应", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			// Mock 参数绑定失败
			mockey.MockUnsafe(binding.BindAndValidate).Return(errors001.New("parse fail")).Build()

			// 捕获错误响应
			errCode := ""
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				errCode = e.GetCode()
			}).Build()

			// 拦截DoResponse防止真实调用
			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(errCode, convey.ShouldEqual, "ParamParseFail")
			convey.So(doRespCalled, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：不支持的BizSource，走默认分支返回ErrorCommon", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			// Mock 成功绑定参数，但设置不支持的BizSource
			targetParam := &bizmodels.OpenBizContractCustomerAuditParam{}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				*targetParam = *p
				p.BizSource = 999
				p.BizScene = 777
				return nil
			}).Build()

			// Mock 国际化
			mockey.MockUnsafe(i18nfmt.Sprintf).Return("unsupported").Build()

			// 捕获错误响应
			errCode := ""
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				errCode = e.GetCode()
			}).Build()

			// 保证未调用流程
			processCalled := false
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				processCalled = true
				return nil, nil
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(errCode, convey.ShouldEqual, "ErrorCommon")
			convey.So(processCalled, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：流程处理失败，返回流程错误", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			// Mock 成功绑定参数，设置来源为Market
			var gotParamPtr *bizmodels.OpenBizContractCustomerAuditParam
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				gotParamPtr = p
				p.BizSource = _const.BizSourceMarket
				return nil
			}).Build()

			// Mock 流程处理失败
			gotTaskType := workflow.TaskType(0)
			markErr := errors.ErrInternalError.WithArgs("流程错误")
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				return nil, markErr
			}).Build()

			// 捕获错误响应
			errCode := ""
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				errCode = e.GetCode()
			}).Build()

			// DoResponse不应被调用
			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeMarketCustomerAudit)
			convey.So(errCode, convey.ShouldEqual, "InternalError")
			convey.So(doRespCalled, convey.ShouldBeFalse)
			convey.So(gotParamPtr, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("场景：来源为Quote（通过BizScene转换），流程成功", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			// Mock 成功绑定参数，BizSource=0，BizScene=Quote
			var targetParam *bizmodels.OpenBizContractCustomerAuditParam
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				targetParam = p
				p.BizSource = 0
				p.BizScene = _const.BizSceneQuoteContract
				return nil
			}).Build()

			// Mock 流程成功
			gotTaskType := workflow.TaskType(0)
			var gotEventExtInfoPtr *bizmodels.OpenBizContractCustomerAuditParam
			respObj := &workflow.CreateBizResp{}
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				if v, ok := eventCtx.EventExtInfo.(*bizmodels.OpenBizContractCustomerAuditParam); ok {
					gotEventExtInfoPtr = v
				}
				return respObj, nil
			}).Build()

			// 捕获DoResponse
			var doRespResult interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespResult = result
			}).Build()

			// ErrorResp不应被调用
			errorRespCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeQuoteCustomerAudit)
			convey.So(gotEventExtInfoPtr, convey.ShouldEqual, targetParam)
			convey.So(doRespResult, convey.ShouldEqual, respObj)
			convey.So(errorRespCalled, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：来源为Partner（通过BizScene转换），流程成功", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			// Mock 成功绑定参数，BizSource=0，BizScene=Partner
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizSource = 0
				p.BizScene = _const.BizScenePartnerContract
				return nil
			}).Build()

			gotTaskType := workflow.TaskType(0)
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				return &workflow.CreateBizResp{}, nil
			}).Build()

			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypePartnerCustomerAudit)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：来源为PartnerQuote，流程成功", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizSource = _const.BizSourcePartnerQuote
				return nil
			}).Build()

			gotTaskType := workflow.TaskType(0)
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				return &workflow.CreateBizResp{}, nil
			}).Build()

			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypePartnerQuoteCustomerAudit)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：来源为Credit，流程成功", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizSource = _const.BizSourceCredit
				return nil
			}).Build()

			gotTaskType := workflow.TaskType(0)
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				return &workflow.CreateBizResp{}, nil
			}).Build()

			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeCreditCustomerAudit)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：来源为Market，流程成功", func() {
			h := &openVCCMetaBizHandler{}
			rc := &app.RequestContext{}

			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizSource = _const.BizSourceMarket
				return nil
			}).Build()

			gotTaskType := workflow.TaskType(0)
			mockey.Mock(workflow.Process).To(func(ctx context.Context, eventCtx *workflow.EventContext) (workflow.Result, errors.APIError) {
				gotTaskType = eventCtx.TaskType
				return &workflow.CreateBizResp{}, nil
			}).Build()

			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			h.CustomAuditBizContract20210101(context.Background(), rc)

			convey.So(gotTaskType, convey.ShouldEqual, workflow.TaskTypeMarketCustomerAudit)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})
	})
}

type fakeOpenVCCMetaBizMetaService struct {
	contractmeta.MetaService
	abandonBizFn                          func(context.Context, *bizmodels.OpenBizContractAbandonParam) errors.APIError
	revokeBizFn                           func(context.Context, *bizmodels.OpenBizContractRevokeParam) errors.APIError
	bizDetailFn                           func(context.Context, *bizmodels.MetaBizDetailParam) (*bizmodels.ContractMetaInfo, errors.APIError)
	metaDetailFn                          func(context.Context, *bizmodels.MetaDetailReq) (*bizmodels.ContractMetaInfo, errors.APIError)
	getCoStatusFn                         func(context.Context, *bizmodels.MetaCoStatusParam) (*bizmodels.MetaCoStatusInfo, errors.APIError)
	listMetaFn                            func(context.Context, *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError)
	downloadFn                            func(context.Context, *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError)
	getViewURLFn                          func(context.Context, *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError)
	getInProcessProductInfoFn             func(context.Context, bizmodels.GetInProcessProductReq) error
	queryLadderQuotationContractByCacheFn func(context.Context, *bizmodels.QueryLadderQuotationContractReq) (*bizmodels.QueryLadderQuotationContractResp, error)
	checkLadderQuoteContractClashFn       func(context.Context, *bizmodels.CheckLadderQuoteContractClashReq) (*bizmodels.CheckLadderQuoteContractClashResp, error)
	queryFeishuViewUrlFn                  func(context.Context, string, string) (string, error)
	getDepartmentInfoFn                   func(context.Context, *bizmodels.GetDepartmentInfoReq) (*bizmodels.GetDepartmentInfoResp, errors.APIError)
}

func (f *fakeOpenVCCMetaBizMetaService) AbandonBiz(ctx context.Context, param *bizmodels.OpenBizContractAbandonParam) errors.APIError {
	return f.abandonBizFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) RevokeBiz(ctx context.Context, param *bizmodels.OpenBizContractRevokeParam) errors.APIError {
	return f.revokeBizFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) BizDetail(ctx context.Context, param *bizmodels.MetaBizDetailParam) (*bizmodels.ContractMetaInfo, errors.APIError) {
	return f.bizDetailFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) MetaDetail(ctx context.Context, param *bizmodels.MetaDetailReq) (*bizmodels.ContractMetaInfo, errors.APIError) {
	return f.metaDetailFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) GetCoStatus(ctx context.Context, param *bizmodels.MetaCoStatusParam) (*bizmodels.MetaCoStatusInfo, errors.APIError) {
	return f.getCoStatusFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) ListMeta(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
	return f.listMetaFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) Download(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
	return f.downloadFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) GetViewURL(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
	return f.getViewURLFn(ctx, param)
}

func (f *fakeOpenVCCMetaBizMetaService) GetInProcessProductInfo(ctx context.Context, req bizmodels.GetInProcessProductReq) error {
	return f.getInProcessProductInfoFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaService) QueryLadderQuotationContractByCache(ctx context.Context, req *bizmodels.QueryLadderQuotationContractReq) (*bizmodels.QueryLadderQuotationContractResp, error) {
	return f.queryLadderQuotationContractByCacheFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaService) CheckLadderQuoteContractClash(ctx context.Context, req *bizmodels.CheckLadderQuoteContractClashReq) (*bizmodels.CheckLadderQuoteContractClashResp, error) {
	return f.checkLadderQuoteContractClashFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaService) QueryFeishuViewUrl(ctx context.Context, contractNo string, creator string) (string, error) {
	return f.queryFeishuViewUrlFn(ctx, contractNo, creator)
}

func (f *fakeOpenVCCMetaBizMetaService) GetDepartmentInfo(ctx context.Context, req *bizmodels.GetDepartmentInfoReq) (*bizmodels.GetDepartmentInfoResp, errors.APIError) {
	return f.getDepartmentInfoFn(ctx, req)
}

type fakeOpenVCCMetaBizMetaServiceV2 struct {
	contractmeta.MetaServiceV2
	preCheckCreateContractPriceFn  func(context.Context, *modelcommodity.PreCheckCreateContractPriceReq) (*modelcommodity.PreCheckCreateContractPriceReqResp, error)
	checkQuoteItemRepeatFn         func(context.Context, *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error)
	checkContractQuoteItemRepeatFn func(context.Context, *modelcommodity.CheckContractQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error)
	clearRelateQuoteFn             func(context.Context, *modelcommodity.ClearRelateQuoteReq) error
}

func (f *fakeOpenVCCMetaBizMetaServiceV2) PreCheckCreateContractPrice(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) (*modelcommodity.PreCheckCreateContractPriceReqResp, error) {
	return f.preCheckCreateContractPriceFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaServiceV2) CheckQuoteItemRepeat(ctx context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
	return f.checkQuoteItemRepeatFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaServiceV2) CheckContractQuoteItemRepeat(ctx context.Context, req *modelcommodity.CheckContractQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
	return f.checkContractQuoteItemRepeatFn(ctx, req)
}

func (f *fakeOpenVCCMetaBizMetaServiceV2) ClearRelateQuote(ctx context.Context, req *modelcommodity.ClearRelateQuoteReq) error {
	return f.clearRelateQuoteFn(ctx, req)
}

type fakeOpenVCCMetaBizSalesContractService struct {
	salescontract.SalesContractService
	syncContractByNoFn func(context.Context, string) error
}

func (f *fakeOpenVCCMetaBizSalesContractService) SyncContractByNo(ctx context.Context, contractNo string) error {
	return f.syncContractByNoFn(ctx, contractNo)
}

type fakeOpenVCCMetaBizContractService struct {
	service.BizContractService
	existPartyMDFn func(context.Context, *bizmodels.MdPartyExistParam) (bool, errors.APIError)
}

func (f *fakeOpenVCCMetaBizContractService) ExistPartyMD(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
	return f.existPartyMDFn(ctx, param)
}

func Test_openVCCMetaBizHandler_AbandonBizContract20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).AbandonBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedParam *bizmodels.OpenBizContractAbandonParam
			var capturedResult interface{} = "not-called"
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractAbandonParam) = bizmodels.OpenBizContractAbandonParam{ContractNo: "CN-ABANDON"}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{abandonBizFn: func(ctx context.Context, param *bizmodels.OpenBizContractAbandonParam) errors.APIError {
				capturedParam = param
				return nil
			}}}
			h.AbandonBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedParam.ContractNo, convey.ShouldEqual, "CN-ABANDON")
			convey.So(capturedResult, convey.ShouldBeNil)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("abandon failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{abandonBizFn: func(ctx context.Context, param *bizmodels.OpenBizContractAbandonParam) errors.APIError {
				return serviceErr
			}}}
			h.AbandonBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_RevokeBizContract20210101(t *testing.T) {
	t.Run("service success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedParam *bizmodels.OpenBizContractRevokeParam
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.OpenBizContractRevokeParam) = bizmodels.OpenBizContractRevokeParam{ContractNo: "CN-REVOKE"}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{revokeBizFn: func(ctx context.Context, param *bizmodels.OpenBizContractRevokeParam) errors.APIError {
				capturedParam = param
				return nil
			}}}
			h.RevokeBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedParam.ContractNo, convey.ShouldEqual, "CN-REVOKE")
			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{"Success": true, "Message": "撤销成功"})
		})
	})
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).RevokeBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("revoke failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{revokeBizFn: func(ctx context.Context, param *bizmodels.OpenBizContractRevokeParam) errors.APIError {
				return serviceErr
			}}}
			h.RevokeBizContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetBizDetail20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetBizDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("sets manager and returns detail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.ContractMetaInfo{ContractNo: "CN-BIZ"}
			var capturedParam *bizmodels.MetaBizDetailParam
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.MetaBizDetailParam) = bizmodels.MetaBizDetailParam{ContractNo: "CN-BIZ"}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{bizDetailFn: func(ctx context.Context, param *bizmodels.MetaBizDetailParam) (*bizmodels.ContractMetaInfo, errors.APIError) {
				capturedParam = param
				return resp, nil
			}}}
			h.GetBizDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedParam.IsManager, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{bizDetailFn: func(ctx context.Context, param *bizmodels.MetaBizDetailParam) (*bizmodels.ContractMetaInfo, errors.APIError) {
				return nil, serviceErr
			}}}
			h.GetBizDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetMetaDetail20210101(t *testing.T) {
	t.Run("sets manager and returns detail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.ContractMetaInfo{ContractNo: "CN-META"}
			var capturedParam *bizmodels.MetaDetailReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				*obj.(*bizmodels.MetaDetailReq) = bizmodels.MetaDetailReq{ContractNo: "CN-META"}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{metaDetailFn: func(ctx context.Context, param *bizmodels.MetaDetailReq) (*bizmodels.ContractMetaInfo, errors.APIError) {
				capturedParam = param
				return resp, nil
			}}}
			h.GetMetaDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedParam.IsManager, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetMetaDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("meta detail failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{metaDetailFn: func(ctx context.Context, param *bizmodels.MetaDetailReq) (*bizmodels.ContractMetaInfo, errors.APIError) {
				return nil, serviceErr
			}}}
			h.GetMetaDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetCoStatus20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetCoStatus20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.MetaCoStatusInfo{ContractNo: "CN-CO"}
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getCoStatusFn: func(ctx context.Context, param *bizmodels.MetaCoStatusParam) (*bizmodels.MetaCoStatusInfo, errors.APIError) {
				return resp, nil
			}}}
			h.GetCoStatus20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("co status failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getCoStatusFn: func(ctx context.Context, param *bizmodels.MetaCoStatusParam) (*bizmodels.MetaCoStatusInfo, errors.APIError) {
				return nil, serviceErr
			}}}
			h.GetCoStatus20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_ListMeta20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).ListMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("sets open source manager and operator from context", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.MetaListResp{}
			var capturedParam *bizmodels.MetaListParam
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error { return nil }).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{listMetaFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
				capturedParam = param
				return resp, nil
			}}}
			ctx := context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op@test"})
			h.ListMeta20210101(ctx, &app.RequestContext{})
			convey.So(capturedParam.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedParam.CurrentOperator, convey.ShouldEqual, "op@test")
			convey.So(capturedParam.IsManager, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("list failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{listMetaFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
				return nil, serviceErr
			}}}
			h.ListMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_ListSalesMeta20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).ListSalesMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("converts sales list param", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.MetaListResp{}
			var capturedParam *bizmodels.MetaListParam
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error { return nil }).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{listMetaFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
				capturedParam = param
				return resp, nil
			}}}
			ctx := context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "sales@test"})
			h.ListSalesMeta20210101(ctx, &app.RequestContext{})
			convey.So(capturedParam.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedParam.CurrentOperator, convey.ShouldEqual, "sales@test")
			convey.So(capturedParam.IsManager, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("sales list failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{listMetaFn: func(ctx context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
				return nil, serviceErr
			}}}
			h.ListSalesMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_DownloadContractMeta20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).DownloadContractMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("success writes file", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error { return nil }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{downloadFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return []byte("file-data"), "fid", "contract.pdf", nil
			}}}
			c := &app.RequestContext{}
			h.DownloadContractMeta20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), c)
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "file-data")
			convey.So(string(c.Response.Header.ContentType()), convey.ShouldEqual, "application/octet-stream")
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("download meta failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{downloadFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return nil, "", "", serviceErr
			}}}
			h.DownloadContractMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
	t.Run("empty file data returns error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{downloadFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return nil, "", "", nil
			}}}
			h.DownloadContractMeta20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldBeNil)
		})
	})
}

func Test_openVCCMetaBizHandler_GetMetaViewUrl20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetMetaViewUrl20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getViewURLFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
				return "https://view", "file", nil
			}}}
			h.GetMetaViewUrl20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{"URL": "https://view"})
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("view meta failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getViewURLFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
				return "", "", serviceErr
			}}}
			h.GetMetaViewUrl20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_UpdateFinance20210101(t *testing.T) {
	t.Run("missing contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("missing finance", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN1")
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), c)
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"Finance"})
		})
	})
	t.Run("find contract error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &MockContractMetaDao{}
			var capturedErr vhertz.APIError
			mockey.Mock(dal.NewContractMetaDao).Return(dao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, errors001.New("find failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN1")
			c.Request.URI().QueryArgs().Set("Finance", "FIN")
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
	t.Run("contract not found", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &MockContractMetaDao{}
			var capturedErr vhertz.APIError
			mockey.Mock(dal.NewContractMetaDao).Return(dao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN1")
			c.Request.URI().QueryArgs().Set("Finance", "FIN")
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
	t.Run("update error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &MockContractMetaDao{}
			var capturedErr vhertz.APIError
			mockey.Mock(dal.NewContractMetaDao).Return(dao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 9}}, nil).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(errors001.New("update failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN1")
			c.Request.URI().QueryArgs().Set("Finance", "FIN")
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("success updates every contract", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &MockContractMetaDao{}
			var updatedIDs []int64
			mockey.Mock(dal.NewContractMetaDao).Return(dao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).To(func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				return &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 9}}, nil
			}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).To(func(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
				updatedIDs = append(updatedIDs, id)
				convey.So(updates["finance"], convey.ShouldEqual, "FIN")
				return nil
			}).Build()
			var capturedResult interface{} = "not-called"
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN1,CN2")
			c.Request.URI().QueryArgs().Set("Finance", "FIN")
			(&openVCCMetaBizHandler{}).UpdateFinance20210101(context.Background(), c)
			convey.So(updatedIDs, convey.ShouldResemble, []int64{9, 9})
			convey.So(capturedResult, convey.ShouldBeNil)
		})
	})
}

func Test_openVCCMetaBizHandler_SyncOaSalesContract20210101(t *testing.T) {
	t.Run("missing contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).SyncOaSalesContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var gotContractNo string
			var capturedResult interface{} = "not-called"
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{salesContractService: &fakeOpenVCCMetaBizSalesContractService{syncContractByNoFn: func(ctx context.Context, contractNo string) error { gotContractNo = contractNo; return nil }}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "SCN-1")
			h.SyncOaSalesContract20210101(context.Background(), c)
			convey.So(gotContractNo, convey.ShouldEqual, "SCN-1")
			convey.So(capturedResult, convey.ShouldBeNil)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{salesContractService: &fakeOpenVCCMetaBizSalesContractService{syncContractByNoFn: func(ctx context.Context, contractNo string) error { return errors001.New("sync failed") }}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "SCN-ERR")
			h.SyncOaSalesContract20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetInProcessProduct20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetInProcessProduct20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("fills source operator and download id", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedReq bizmodels.GetInProcessProductReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				obj.(*bizmodels.GetInProcessProductReq).FetchProductConditions = []*bizmodels.FetchProductCondition{{TradeProduct: "ecs"}}
				return nil
			}).Build()
			mockey.Mock(idgenerator.GeneratorID).Return("FID-fixed").Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getInProcessProductInfoFn: func(ctx context.Context, req bizmodels.GetInProcessProductReq) error { capturedReq = req; return nil }}}
			h.GetInProcessProduct20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "op")
			convey.So(capturedReq.DownLoadId, convey.ShouldStartWith, "FID")
			convey.So(capturedResult, convey.ShouldEqual, capturedReq.DownLoadId)
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetInProcessProduct20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				obj.(*bizmodels.GetInProcessProductReq).FetchProductConditions = []*bizmodels.FetchProductCondition{{TradeProduct: "ecs"}}
				return nil
			}).Build()
			mockey.Mock(idgenerator.GeneratorID).Return("FID-error").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getInProcessProductInfoFn: func(ctx context.Context, req bizmodels.GetInProcessProductReq) error {
				return errors001.New("export failed")
			}}}
			h.GetInProcessProduct20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_QueryLadderQuotationContract20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).QueryLadderQuotationContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).QueryLadderQuotationContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.QueryLadderQuotationContractResp{IsRepeat: true}
			var capturedReq *bizmodels.QueryLadderQuotationContractReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*bizmodels.QueryLadderQuotationContractReq)
				r.AccountIds = "1"
				r.ProductList = "ecs"
				r.ValidityBegin = time.Now()
				r.ValidityEnd = time.Now().Add(time.Hour)
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{queryLadderQuotationContractByCacheFn: func(ctx context.Context, req *bizmodels.QueryLadderQuotationContractReq) (*bizmodels.QueryLadderQuotationContractResp, error) {
				capturedReq = req
				return resp, nil
			}}}
			h.QueryLadderQuotationContract20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "op")
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*bizmodels.QueryLadderQuotationContractReq)
				r.AccountIds = "1"
				r.ProductList = "ecs"
				r.ValidityBegin = time.Now()
				r.ValidityEnd = time.Now().Add(time.Hour)
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{queryLadderQuotationContractByCacheFn: func(ctx context.Context, req *bizmodels.QueryLadderQuotationContractReq) (*bizmodels.QueryLadderQuotationContractResp, error) {
				return nil, errors001.New("query ladder failed")
			}}}
			h.QueryLadderQuotationContract20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_CheckLadderQuoteContractClash20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.CheckLadderQuoteContractClashResp{Repeat: true}
			var capturedReq *bizmodels.CheckLadderQuoteContractClashReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*bizmodels.CheckLadderQuoteContractClashReq)
				r.AccountIds = "1"
				r.ProductList = "ecs"
				r.ValidityBegin = "2026-01-01 00:00:00"
				r.ValidityEnd = "2026-12-31 00:00:00"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{checkLadderQuoteContractClashFn: func(ctx context.Context, req *bizmodels.CheckLadderQuoteContractClashReq) (*bizmodels.CheckLadderQuoteContractClashResp, error) {
				capturedReq = req
				return resp, nil
			}}}
			h.CheckLadderQuoteContractClash20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "op")
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*bizmodels.CheckLadderQuoteContractClashReq)
				r.AccountIds = "1"
				r.ProductList = "ecs"
				r.ValidityBegin = "2026-01-01 00:00:00"
				r.ValidityEnd = "2026-12-31 00:00:00"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{checkLadderQuoteContractClashFn: func(ctx context.Context, req *bizmodels.CheckLadderQuoteContractClashReq) (*bizmodels.CheckLadderQuoteContractClashResp, error) {
				return nil, errors001.New("clash failed")
			}}}
			h.CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetFeishuViewUrl20210101(t *testing.T) {
	t.Run("missing contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetFeishuViewUrl20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("missing creator", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN")
			(&openVCCMetaBizHandler{}).GetFeishuViewUrl20210101(context.Background(), c)
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"Creator"})
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var gotContractNo, gotCreator string
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{queryFeishuViewUrlFn: func(ctx context.Context, contractNo string, creator string) (string, error) {
				gotContractNo = contractNo
				gotCreator = creator
				return "https://feishu", nil
			}}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN")
			c.Request.URI().QueryArgs().Set("Creator", "creator")
			h.GetFeishuViewUrl20210101(context.Background(), c)
			convey.So(gotContractNo, convey.ShouldEqual, "CN")
			convey.So(gotCreator, convey.ShouldEqual, "creator")
			convey.So(capturedResult, convey.ShouldEqual, "https://feishu")
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{queryFeishuViewUrlFn: func(ctx context.Context, contractNo string, creator string) (string, error) {
				return "", errors001.New("feishu failed")
			}}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN")
			c.Request.URI().QueryArgs().Set("Creator", "creator")
			h.GetFeishuViewUrl20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_PreCheckCreateContractPrice20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).PreCheckCreateContractPrice20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.PreCheckCreateContractPriceReqResp{Success: true}
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{preCheckCreateContractPriceFn: func(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) (*modelcommodity.PreCheckCreateContractPriceReqResp, error) {
				return resp, nil
			}}}
			h.PreCheckCreateContractPrice20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{preCheckCreateContractPriceFn: func(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) (*modelcommodity.PreCheckCreateContractPriceReqResp, error) {
				return nil, errors001.New("precheck failed")
			}}}
			h.PreCheckCreateContractPrice20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_CheckQuoteItemRepeat20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}
			var capturedReq *modelcommodity.CheckQuoteItemRepeatReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*modelcommodity.CheckQuoteItemRepeatReq)
				r.ContractNo = "CN"
				r.AccountIDs = []string{"1"}
				r.BizSource = 1
				r.QuoteNo = "Q"
				r.ProductList = []*bizmodels.ProductInfo{{TradeProduct: "ecs"}}
				r.ValidityBegin = time.Now()
				r.ValidityEnd = time.Now().Add(time.Hour)
				r.IsProject = "false"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{checkQuoteItemRepeatFn: func(ctx context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
				capturedReq = req
				return resp, nil
			}}}
			h.CheckQuoteItemRepeat20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "op")
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*modelcommodity.CheckQuoteItemRepeatReq)
				r.ContractNo = "CN"
				r.AccountIDs = []string{"1"}
				r.BizSource = 1
				r.QuoteNo = "Q"
				r.ProductList = []*bizmodels.ProductInfo{{TradeProduct: "ecs"}}
				r.ValidityBegin = time.Now()
				r.ValidityEnd = time.Now().Add(time.Hour)
				r.IsProject = "false"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{checkQuoteItemRepeatFn: func(ctx context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
				return nil, errors001.New("repeat failed")
			}}}
			h.CheckQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_CheckContractQuoteItemRepeat20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckContractQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).CheckContractQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}
			var capturedReq *modelcommodity.CheckContractQuoteItemRepeatReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				obj.(*modelcommodity.CheckContractQuoteItemRepeatReq).ContractNo = "CN"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{checkContractQuoteItemRepeatFn: func(ctx context.Context, req *modelcommodity.CheckContractQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
				capturedReq = req
				return resp, nil
			}}}
			h.CheckContractQuoteItemRepeat20210101(context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{CurrentOperator: "op"}), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "op")
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				obj.(*modelcommodity.CheckContractQuoteItemRepeatReq).ContractNo = "CN"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{checkContractQuoteItemRepeatFn: func(ctx context.Context, req *modelcommodity.CheckContractQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {
				return nil, errors001.New("contract repeat failed")
			}}}
			h.CheckContractQuoteItemRepeat20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_ClearRelateQuote20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).ClearRelateQuote20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("validate error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).ClearRelateQuote20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedReq *modelcommodity.ClearRelateQuoteReq
			var capturedResult interface{} = "not-called"
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*modelcommodity.ClearRelateQuoteReq)
				r.OperatorEmail = "op@test"
				r.OriginContractNo = "CN"
				r.RepeatMsgMap = map[string]map[string]string{"CN": {"1": "repeat"}}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{clearRelateQuoteFn: func(ctx context.Context, req *modelcommodity.ClearRelateQuoteReq) error {
				capturedReq = req
				return nil
			}}}
			h.ClearRelateQuote20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedResult, convey.ShouldBeNil)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				r := obj.(*modelcommodity.ClearRelateQuoteReq)
				r.OperatorEmail = "op@test"
				r.OriginContractNo = "CN"
				r.RepeatMsgMap = map[string]map[string]string{"CN": {"1": "repeat"}}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaServiceV2: &fakeOpenVCCMetaBizMetaServiceV2{clearRelateQuoteFn: func(ctx context.Context, req *modelcommodity.ClearRelateQuoteReq) error {
				return errors001.New("clear failed")
			}}}
			h.ClearRelateQuote20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_GetDepartmentInfo20210101(t *testing.T) {
	t.Run("missing contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).GetDepartmentInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.GetDepartmentInfoResp{}
			var capturedReq *bizmodels.GetDepartmentInfoReq
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getDepartmentInfoFn: func(ctx context.Context, req *bizmodels.GetDepartmentInfoReq) (*bizmodels.GetDepartmentInfoResp, errors.APIError) {
				capturedReq = req
				return resp, nil
			}}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN-DEP")
			h.GetDepartmentInfo20210101(context.Background(), c)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN-DEP")
			convey.So(capturedResult, convey.ShouldEqual, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("department failed")
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{metaService: &fakeOpenVCCMetaBizMetaService{getDepartmentInfoFn: func(ctx context.Context, req *bizmodels.GetDepartmentInfoReq) (*bizmodels.GetDepartmentInfoResp, errors.APIError) {
				return nil, serviceErr
			}}}
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("ContractNo", "CN-DEP")
			h.GetDepartmentInfo20210101(context.Background(), c)
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
}

func Test_openVCCMetaBizHandler_ExistPartyMD20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(errors001.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaBizHandler{}).ExistPartyMD20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("exist service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("exist failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{bizContractService: &fakeOpenVCCMetaBizContractService{existPartyMDFn: func(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
				return false, serviceErr
			}}}
			h.ExistPartyMD20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, serviceErr.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			verify := &accountmanagement.GetVerifyInfoWithCountryOutput{CountryCodeTwo: gptr.Of("CN"), VerifyName: gptr.Of("客户"), IdentityType: gptr.Of("2"), CertificateType: gptr.Of("1"), CertificateCode: gptr.Of("CODE")}
			var capturedParam *bizmodels.MdPartyExistParam
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				obj.(*bizmodels.MdPartyExistParam).AccountID = 123
				return nil
			}).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(verify, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaBizHandler{bizContractService: &fakeOpenVCCMetaBizContractService{existPartyMDFn: func(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
				capturedParam = param
				return true, nil
			}}}
			h.ExistPartyMD20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedParam.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			ret := capturedResult.(map[string]interface{})
			convey.So(ret["Exist"], convey.ShouldBeTrue)
			convey.So(ret["CustomerName"], convey.ShouldEqual, "客户")
		})
	})
	t.Run("verification error returns internal error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(nil, errors001.New("verify failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{bizContractService: &fakeOpenVCCMetaBizContractService{existPartyMDFn: func(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
				return true, nil
			}}}
			h.ExistPartyMD20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
	t.Run("verification nil returns internal error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(innerapiaccountcli.GetVerification).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaBizHandler{bizContractService: &fakeOpenVCCMetaBizContractService{existPartyMDFn: func(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
				return true, nil
			}}}
			h.ExistPartyMD20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

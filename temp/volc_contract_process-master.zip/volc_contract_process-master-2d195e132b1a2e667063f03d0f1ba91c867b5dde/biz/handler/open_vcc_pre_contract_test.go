package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/salescontract"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func TestNewOpenPreContractHandler(t *testing.T) {
	mockey.PatchConvey("创建 open 在线合同 handler", t, func() {
		convey.So(NewOpenPreContractHandler(), convey.ShouldNotBeNil)
	})
}

func TestOpenPreContractHandlerCreateOrUpdatePreContract20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&openPreContractHandler{}).CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("执行前标记 open 调用并修正部门", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var fixCalled bool
			var isOpenCall bool
			expected := &salescontract.CreateOrUpdateResp{PreContractNo: "P-1"}
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(basicinfo.FixDepartmentWhenSave).To(func(info *bizmodels.BasicInfo) {
				fixCalled = true
			}).Build()
			mockey.MockUnsafe((*salescontract.CreateOrUpdateReq).Execute).To(func(req *salescontract.CreateOrUpdateReq, ctx context.Context) (*salescontract.CreateOrUpdateResp, errors.APIError) {
				isOpenCall = req.IsOpenCall
				return expected, nil
			}).Build()

			(&openPreContractHandler{}).CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(fixCalled, convey.ShouldBeTrue)
			convey.So(isOpenCall, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
	t.Run("Execute 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("svc")
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(basicinfo.FixDepartmentWhenSave).Return().Build()
			mockey.MockUnsafe((*salescontract.CreateOrUpdateReq).Execute).Return(nil, serviceErr).Build()

			(&openPreContractHandler{}).CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
}

func TestOpenPreContractHandlerListUrgeNotifyUserList20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&openPreContractHandler{}).ListUrgeNotifyUserList20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功返回催办人员列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := []*bizmodels.UrgeNotifyInfo{{Email: "reviewer@example.com"}}
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe((*salescontract.ListUrgeNotifyUserListReq).Execute).Return(expected, nil).Build()

			(&openPreContractHandler{}).ListUrgeNotifyUserList20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

func TestOpenPreContractHandlerSendUrgeNotifyV220210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&openPreContractHandler{}).SendUrgeNotifyV220210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("优先使用 header 操作人并返回催办结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var operator string
			expected := map[string]bool{"reviewer@example.com": true}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.SendUrgeNotifyReq)
				req.CurrentOperator = "body@example.com"
				return nil
			}).Build()
			mockey.MockUnsafe((*salescontract.SendUrgeNotifyReq).Execute).To(func(req *salescontract.SendUrgeNotifyReq, ctx context.Context) (map[string]bool, errors.APIError) {
				operator = req.CurrentOperator
				return expected, nil
			}).Build()

			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@example.com")
			(&openPreContractHandler{}).SendUrgeNotifyV220210101(ctx, &app.RequestContext{})

			convey.So(operator, convey.ShouldEqual, "header@example.com")
			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"volc_contract_process/biz/service/riskclausetpl"
	"volc_contract_process/pkg/errors"
)

type innerRiskClauseTplHandler struct {
	base
	service riskclausetpl.Service
}

func NewRiskClauseTplHandler() vhertz.ActionHandler {
	return &innerRiskClauseTplHandler{
		service: riskclausetpl.NewService(),
	}
}

// CreateRiskClauseTemplate20210101 创建风险条款模板
func (h *innerRiskClauseTplHandler) CreateRiskClauseTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclausetpl.CreateRiskClauseTemplateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.CreateRiskClauseTemplate(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// UpdateRiskClauseTemplate20210101 更新风险条款模板
func (h *innerRiskClauseTplHandler) UpdateRiskClauseTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclausetpl.UpdateRiskClauseTemplateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UpdateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "UpdateRiskClauseTemplateValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.UpdateRiskClauseTemplate(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// AuditRiskClauseTemplate20210101 启用/关闭风险条款模板
func (h *innerRiskClauseTplHandler) AuditRiskClauseTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclausetpl.AuditRiskClauseTemplateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AuditRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "AuditRiskClauseTemplateValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.AuditRiskClauseTemplate(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ListRiskClauseTemplate20210101 查询风险条款模板列表
func (h *innerRiskClauseTplHandler) ListRiskClauseTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclausetpl.ListRiskClauseTemplateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AuditRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	resp, err := h.service.List(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// ListRiskClauseTemplateHistory20210101 查询风险条款模板历史记录
func (h *innerRiskClauseTplHandler) ListRiskClauseTemplateHistory20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclausetpl.ListRiskClauseTemplateHistoryReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AuditRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "ListRiskClauseTemplateHistoryFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.service.ListHistory(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

package handler

import (
	"context"
	"fmt"
	"mime/multipart"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/dgrijalva/jwt-go"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"
)

type innerAttachResponseRecorder struct {
	errorResp vhertz.APIError
	result    interface{}
}

func newInnerAttachResponseRecorder() *innerAttachResponseRecorder {
	recorder := &innerAttachResponseRecorder{}
	mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
		recorder.errorResp = err
	}).Build()
	mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
		recorder.result = result
	}).Build()
	return recorder
}

func mockInnerAttachQuery(values map[string]string) {
	mockey.Mock((*app.RequestContext).Query).To(func(key string) string {
		return values[key]
	}).Build()
}

func innerAttachUserCtx(email string) context.Context {
	return context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{
		EmployeeID:    123,
		EmployeeName:  "EmployeeName",
		EmployeeEmail: email,
	})
}

func Test_NewInnerVCCMetaAttachmentHandler(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			handler := NewInnerVCCMetaAttachmentHandler()

			v, ok := handler.(*innerVCCMetaAttachmentHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(v.attachmentService, convey.ShouldNotBeNil)
			convey.So(v.metaService, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_DownloadMetaAttachment20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{
				FileName: "FileName.test",
				Data:     []byte("{xxxxxxx}"),
			}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.DownloadMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), c)

			convey.So(c.Response.Header.Get("Content-Disposition"), convey.ShouldEqual, "attachment;filename=FileName.test")
			convey.So(c.Response.Header.Get("Content-type"), convey.ShouldEqual, "application/octet-stream")
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{xxxxxxx}")
		})
	})
	t.Run("case user info empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.DownloadMetaAttachment20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, errors.ErrorCommon.WithArgs("download fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.DownloadMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("download fail"))
		})
	})
	t.Run("case data info nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.DownloadMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_UploadMetaAttachment20210101(t *testing.T) {
	t.Run("case success with form file", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(&multipart.FileHeader{Filename: "contract.docx", Size: 10}, nil).Build()
			mockUploadAttachment := mockey.GetMethod(attachmentService, "UploadAttachment")
			mockey.Mock(mockUploadAttachment).To(func(ctx context.Context, req *metaattachmodels.UploadReq) (*metaattachmodels.UploadResp, errors.APIError) {
				convey.So(req.FileName, convey.ShouldEqual, "contract.docx")
				convey.So(req.File, convey.ShouldNotBeNil)
				return &metaattachmodels.UploadResp{FileID: "file-id", FileName: "contract.docx"}, nil
			}).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.UploadResp{FileID: "file-id", FileName: "contract.docx"})
		})
	})
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(nil, fmt.Errorf("no file")).Build()
			mockUploadAttachment := mockey.GetMethod(attachmentService, "UploadAttachment")
			mockey.Mock(mockUploadAttachment).Return(nil, errors.ErrorCommon.WithArgs("upload fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("upload fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetProcessFileInfo20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"ContractNo": "ContractNo"})
			mockGetProcessFileInfo := mockey.GetMethod(attachmentService, "GetProcessFileInfo")
			mockey.Mock(mockGetProcessFileInfo).Return(&metaattachmodels.GetProcessFileInfoResp{}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetProcessFileInfo20210101(innerAttachUserCtx("CurrentOperator"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.GetProcessFileInfoResp{})
		})
	})
	t.Run("case contract no missing", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{})

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("ContractNo"))
		})
	})
	t.Run("case user missing", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"ContractNo": "ContractNo"})

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("CurrentOperator"))
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"ContractNo": "ContractNo"})
			mockGetProcessFileInfo := mockey.GetMethod(attachmentService, "GetProcessFileInfo")
			mockey.Mock(mockGetProcessFileInfo).Return(nil, errors.ErrorCommon.WithArgs("process fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetProcessFileInfo20210101(innerAttachUserCtx("CurrentOperator"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("process fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_ViewMetaAttachment20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{
				CanView:     true,
				ContentType: "text/plain",
				Data:        []byte("preview-data"),
			}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ViewMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), c)

			convey.So(string(c.Response.Body()), convey.ShouldEqual, "preview-data")
		})
	})
	t.Run("case user info empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.ViewMetaAttachment20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, errors.ErrorCommon.WithArgs("view fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ViewMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("view fail"))
		})
	})
	t.Run("case data info nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ViewMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case cannot view", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: false}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ViewMetaAttachment20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetViewMetaAttachmentUrl20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: true}, nil).Build()
			mockGetAttachmentUrl := mockey.GetMethod(attachmentService, "GetAttachmentUrl")
			mockey.Mock(mockGetAttachmentUrl).Return("view-url", nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetViewMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldEqual, "view-url")
		})
	})
	t.Run("case user info empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetViewMetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, errors.ErrorCommon.WithArgs("info fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetViewMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("info fail"))
		})
	})
	t.Run("case data info nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetViewMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case cannot view", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: false}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetViewMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case get url fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: true}, nil).Build()
			mockGetAttachmentUrl := mockey.GetMethod(attachmentService, "GetAttachmentUrl")
			mockey.Mock(mockGetAttachmentUrl).Return("", fmt.Errorf("url fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetViewMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetDownloadMetaAttachmentUrl20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: true}, nil).Build()
			mockGetAttachmentUrl := mockey.GetMethod(attachmentService, "GetAttachmentUrl")
			mockey.Mock(mockGetAttachmentUrl).Return("download-url", nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetDownloadMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldEqual, "download-url")
		})
	})
	t.Run("case user info empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetDownloadMetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, errors.ErrorCommon.WithArgs("info fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetDownloadMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("info fail"))
		})
	})
	t.Run("case data info nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetDownloadMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case get url fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: true}, nil).Build()
			mockGetAttachmentUrl := mockey.GetMethod(attachmentService, "GetAttachmentUrl")
			mockey.Mock(mockGetAttachmentUrl).Return("", fmt.Errorf("url fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetDownloadMetaAttachmentUrl20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_MetaAttachmentUrl20210101(t *testing.T) {
	t.Run("case download success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).To(func(ctx context.Context, token string, claims jwt.Claims) error {
				downloadClaims := claims.(*bizmodels.DownloadClaims)
				*downloadClaims = bizmodels.DownloadClaims{DownloadId: "DownloadId", Version: "Version", IsView: false}
				return nil
			}).Build()
			mockey.Mock((*bizmodels.DownloadClaims).Valid).Return(nil).Build()
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{
				ContentType: "text/plain",
				FileName:    "FileName.test",
				Data:        []byte("{xxx}"),
			}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.MetaAttachmentUrl20210101(context.Background(), c)

			convey.So(c.Response.Header.Get("Content-Disposition"), convey.ShouldEqual, "attachment;filename=FileName.test")
			convey.So(c.Response.Header.Get("Content-type"), convey.ShouldEqual, "application/octet-stream")
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{xxx}")
		})
	})
	t.Run("case view success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).To(func(ctx context.Context, token string, claims jwt.Claims) error {
				downloadClaims := claims.(*bizmodels.DownloadClaims)
				*downloadClaims = bizmodels.DownloadClaims{DownloadId: "DownloadId", Version: "Version", IsView: true}
				return nil
			}).Build()
			mockey.Mock((*bizmodels.DownloadClaims).Valid).Return(nil).Build()
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{ContentType: "text/plain", Data: []byte("view-data")}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.MetaAttachmentUrl20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldEqual, "view-data")
		})
	})
	t.Run("case parse claims fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).Return(fmt.Errorf("parse fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.MetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case claim invalid", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).Return(nil).Build()
			mockey.Mock((*bizmodels.DownloadClaims).Valid).Return(fmt.Errorf("claim invalid")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.MetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).Return(nil).Build()
			mockey.Mock((*bizmodels.DownloadClaims).Valid).Return(nil).Build()
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, errors.ErrorCommon.WithArgs("meta url fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.MetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("meta url fail"))
		})
	})
	t.Run("case data info nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"Token": "token"})
			mockey.Mock(util.ParseClaims).Return(nil).Build()
			mockey.Mock((*bizmodels.DownloadClaims).Valid).Return(nil).Build()
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.MetaAttachmentUrl20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetMetaAttachmentURL20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			metaService := contractmeta.NewMetaService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetViewURL := mockey.GetMethod(metaService, "GetViewURL")
			mockey.Mock(mockGetViewURL).Return("https://example.com/file", "file.docx", nil).Build()

			v := &innerVCCMetaAttachmentHandler{metaService: metaService}
			v.GetMetaAttachmentURL20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.AttachmentURL{URL: "https://example.com/file", FileName: "file.docx"})
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			metaService := contractmeta.NewMetaService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetViewURL := mockey.GetMethod(metaService, "GetViewURL")
			mockey.Mock(mockGetViewURL).Return("", "", errors.ErrorCommon.WithArgs("view url fail")).Build()

			v := &innerVCCMetaAttachmentHandler{metaService: metaService}
			v.GetMetaAttachmentURL20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("view url fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetAttachmentPreviewInfo20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(logs.CtxInfo).Return().Build()
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(&peopleclient.Employee{Email: "EmployeeEmail"}, nil).Build()
			mockGetAttachmentPreviewInfo := mockey.GetMethod(attachmentService, "GetAttachmentPreviewInfo")
			mockey.Mock(mockGetAttachmentPreviewInfo).Return(&metaattachmodels.GetAttachmentPreviewInfoResp{
				AttachName: "demo.doc",
				CanPreview: true,
				PreviewURL: "PreviewURL",
			}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetAttachmentPreviewInfo20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.GetAttachmentPreviewInfoResp{
				AttachName: "demo.doc",
				CanPreview: true,
				PreviewURL: "PreviewURL",
			})
		})
	})
	t.Run("case user empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetAttachmentPreviewInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case get employee fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(nil, errors.ErrorCommon.WithArgs("employee fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetAttachmentPreviewInfo20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case employee nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(nil, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetAttachmentPreviewInfo20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case employee email mismatch", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(&peopleclient.Employee{Email: "other@example.com"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.GetAttachmentPreviewInfo20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldNotBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(logs.CtxInfo).Return().Build()
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(&peopleclient.Employee{Email: "EmployeeEmail"}, nil).Build()
			mockGetAttachmentPreviewInfo := mockey.GetMethod(attachmentService, "GetAttachmentPreviewInfo")
			mockey.Mock(mockGetAttachmentPreviewInfo).Return(nil, errors.ErrorCommon.WithArgs("preview fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetAttachmentPreviewInfo20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("preview fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_DownloadMetaAttachmentInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{FileName: "file.txt", Data: []byte("download")}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.DownloadMetaAttachmentInner20210101(innerAttachUserCtx("EmployeeEmail"), c)

			convey.So(string(c.Response.Body()), convey.ShouldEqual, "download")
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_ViewMetaAttachmentInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattach.NewAttachmentService()
			c := &app.RequestContext{}
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockGetAttachmentDataInfo := mockey.GetMethod(attachmentService, "GetAttachmentDataInfo")
			mockey.Mock(mockGetAttachmentDataInfo).Return(&metaattachmodels.AttachmentDataInfo{CanView: true, ContentType: "text/plain", Data: []byte("view")}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ViewMetaAttachmentInner20210101(innerAttachUserCtx("EmployeeEmail"), c)

			convey.So(string(c.Response.Body()), convey.ShouldEqual, "view")
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_UploadMetaAttachmentInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(nil, fmt.Errorf("no file")).Build()
			mockUploadAttachment := mockey.GetMethod(attachmentService, "UploadAttachment")
			mockey.Mock(mockUploadAttachment).Return(&metaattachmodels.UploadResp{FileID: "file-id"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.UploadMetaAttachmentInner20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.UploadResp{FileID: "file-id"})
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetProcessFileInfoInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"ContractNo": "ContractNo"})
			mockGetProcessFileInfo := mockey.GetMethod(attachmentService, "GetProcessFileInfo")
			mockey.Mock(mockGetProcessFileInfo).Return(&metaattachmodels.GetProcessFileInfoResp{}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetProcessFileInfoInner20210101(innerAttachUserCtx("CurrentOperator"), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.GetProcessFileInfoResp{})
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_GetAttachmentPreviewInfoInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(logs.CtxInfo).Return().Build()
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockInnerAttachQuery(map[string]string{"DownloadID": "download-id", "DocVersion": "v1"})
			mockey.Mock(larkc.GetEmployeeByIDWithCache).Return(&peopleclient.Employee{Email: "EmployeeEmail"}, nil).Build()
			mockGetAttachmentPreviewInfo := mockey.GetMethod(attachmentService, "GetAttachmentPreviewInfo")
			mockey.Mock(mockGetAttachmentPreviewInfo).Return(&metaattachmodels.GetAttachmentPreviewInfoResp{PreviewURL: "PreviewURL"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.GetAttachmentPreviewInfoInner20210101(innerAttachUserCtx("EmployeeEmail"), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.GetAttachmentPreviewInfoResp{PreviewURL: "PreviewURL"})
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_ApplyUploadInfo20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockApplyUploadInfo := mockey.GetMethod(attachmentService, "ApplyUploadInfo")
			mockey.Mock(mockApplyUploadInfo).Return(&metaattachmodels.PreSingedPostFormData{Key: "contract/file.docx", Addr: "bucket.example.com"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.PreSingedPostFormData{Key: "contract/file.docx", Addr: "bucket.example.com"})
		})
	})
	t.Run("case BindAndValidate fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case ApplyUploadInfo fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockApplyUploadInfo := mockey.GetMethod(attachmentService, "ApplyUploadInfo")
			mockey.Mock(mockApplyUploadInfo).Return(nil, errors.ErrorCommon.WithArgs("apply fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("apply fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_InitMultipartUpload20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockInitMultipartUpload := mockey.GetMethod(attachmentService, "InitMultipartUpload")
			mockey.Mock(mockInitMultipartUpload).Return(&metaattachmodels.InitMultipartUploadResp{TosKey: "contract/file.docx", UploadID: "upload-id"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.InitMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.InitMultipartUploadResp{TosKey: "contract/file.docx", UploadID: "upload-id"})
		})
	})
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.InitMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockInitMultipartUpload := mockey.GetMethod(attachmentService, "InitMultipartUpload")
			mockey.Mock(mockInitMultipartUpload).Return(nil, errors.ErrorCommon.WithArgs("init fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.InitMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("init fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_UploadMultipartPart20210101(t *testing.T) {
	t.Run("case success with form file", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(&multipart.FileHeader{Filename: "part", Size: 10}, nil).Build()
			mockUploadMultipartPart := mockey.GetMethod(attachmentService, "UploadMultipartPart")
			mockey.Mock(mockUploadMultipartPart).To(func(ctx context.Context, req *metaattachmodels.UploadMultipartPartReq) (*metaattachmodels.UploadMultipartPartResp, errors.APIError) {
				convey.So(req.File, convey.ShouldNotBeNil)
				return &metaattachmodels.UploadMultipartPartResp{ETag: "etag-1"}, nil
			}).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.UploadMultipartPart20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.UploadMultipartPartResp{ETag: "etag-1"})
		})
	})
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.UploadMultipartPart20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case form file absent and service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(nil, fmt.Errorf("no file")).Build()
			mockUploadMultipartPart := mockey.GetMethod(attachmentService, "UploadMultipartPart")
			mockey.Mock(mockUploadMultipartPart).Return(nil, errors.ErrorCommon.WithArgs("part fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.UploadMultipartPart20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("part fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_CompleteMultipartUpload20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockCompleteMultipartUpload := mockey.GetMethod(attachmentService, "CompleteMultipartUpload")
			mockey.Mock(mockCompleteMultipartUpload).Return(&metaattachmodels.CompleteMultipartUploadResp{TosKey: "contract/file.docx"}, nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, &metaattachmodels.CompleteMultipartUploadResp{TosKey: "contract/file.docx"})
		})
	})
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockCompleteMultipartUpload := mockey.GetMethod(attachmentService, "CompleteMultipartUpload")
			mockey.Mock(mockCompleteMultipartUpload).Return(nil, errors.ErrorCommon.WithArgs("complete fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("complete fail"))
		})
	})
}

func Test_innerVCCMetaAttachmentHandler_AbortMultipartUpload20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockAbortMultipartUpload := mockey.GetMethod(attachmentService, "AbortMultipartUpload")
			mockey.Mock(mockAbortMultipartUpload).Return(nil).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: metaattach.NewAttachmentService()}
			v.AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerAttachResponseRecorder()
			attachmentService := metaattach.NewAttachmentService()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockAbortMultipartUpload := mockey.GetMethod(attachmentService, "AbortMultipartUpload")
			mockey.Mock(mockAbortMultipartUpload).Return(errors.ErrorCommon.WithArgs("abort fail")).Build()

			v := &innerVCCMetaAttachmentHandler{attachmentService: attachmentService}
			v.AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("abort fail"))
		})
	})
}

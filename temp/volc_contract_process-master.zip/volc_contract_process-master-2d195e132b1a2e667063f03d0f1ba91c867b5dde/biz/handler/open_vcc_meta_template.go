package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——合同商品信息
type openVCCMetaTemplateHandler struct {
	base
	templateService template.Service
}

func NewOpenVCCMetaTemplateHandler() vhertz.ActionHandler {
	return &openVCCMetaTemplateHandler{
		templateService: template.NewService(),
	}
}

// GetTemplateReplaceMap20210101 获取生成模板所需参数
func (h *openVCCMetaTemplateHandler) GetTemplateReplaceMap20210101(ctx context.Context, c *app.RequestContext) {

	var req bizmodels.TemplateReplaceReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetTemplateReplaceMapParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err))
		return
	}

	resp, err := h.templateService.GetTemplateReplaceMap(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// GetContractTemplate20210101 获取生成模板所需参数
func (h *openVCCMetaTemplateHandler) GetContractTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req bizmodels.TemplateReplaceReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetTemplateReplaceMapParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.templateService.GetContractTemplate(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

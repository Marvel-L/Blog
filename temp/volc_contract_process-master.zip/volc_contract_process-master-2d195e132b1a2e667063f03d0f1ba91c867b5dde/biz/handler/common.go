package handler

import (
	"context"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service"
	"volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
)

// ESignCallback 电子签回调
func (h *innerToolHandler) ESignCallback20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.ESignCallbackReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDownloadReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := service.NewBizContractService().ESignCallback(ctx, &param); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

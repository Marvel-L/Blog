package handler

import (
	"context"
	"strconv"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"
)

// 火山合同中心——合同附件处理
type innerVCCMetaAttachmentHandler struct {
	base
	attachmentService metaattach.AttachmentService
	metaService       contractmeta.MetaService
}

func NewInnerVCCMetaAttachmentHandler() vhertz.ActionHandler {
	return &innerVCCMetaAttachmentHandler{
		attachmentService: metaattach.NewAttachmentService(),
		metaService:       contractmeta.NewMetaService(),
	}
}

// DownloadMetaAttachment20210101 下载合同元数据附件
func (h *innerVCCMetaAttachmentHandler) DownloadMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "DownloadMetaAttachment, id=%s, version:%s", downloadID, version)

	userInfo := h.fetchUserInfoFromCtx(ctx)
	if userInfo == nil {
		logs.CtxError(ctx, "DownloadMetaAttachmentFail, err: 用户信息为空")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("用户信息为空"))
		return
	}

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "DownloadMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+info.FileName)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", info.Data)

}

// UploadMetaAttachment20210101 上传合同元数据关联文本
func (h *innerVCCMetaAttachmentHandler) UploadMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.UploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 获取上传文件；未传 File 时允许通过 TosKey 复用已上传文件。
	formFile, err := c.FormFile("File")
	if err == nil && formFile != nil {
		req.File = formFile
		req.FileName = formFile.Filename
	}
	// if req.File == nil && len(req.TosKey) == 0 {
	// 	vhertz.ErrorResp(c, errors.ErrMissingParam.WithArgs("File/TosKey"))
	// 	return
	// }

	// 从附件中心获取相关数据
	res, err1 := h.attachmentService.UploadAttachment(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// GetProcessFileInfo20210101 获取在线协同合同当前节点最新版本文件信息
func (h *innerVCCMetaAttachmentHandler) GetProcessFileInfo20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	user := h.fetchUserInfoFromCtx(ctx)
	if user == nil || len(user.EmployeeEmail) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CurrentOperator"))
		return
	}
	currentOperator := user.EmployeeEmail

	// 从附件中心获取相关数据
	res, err1 := h.attachmentService.GetProcessFileInfo(ctx, contractNo, currentOperator)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// ViewMetaAttachment20210101 预览合同元数据附件 仅支持浏览器允许的附件类型
func (h *innerVCCMetaAttachmentHandler) ViewMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "ViewMetaAttachment, id=%s, version=%s", downloadID, version)

	userInfo := h.fetchUserInfoFromCtx(ctx)
	if userInfo == nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: 用户信息为空")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("用户信息为空"))
		return
	}

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	if !info.CanView {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前文档不支持预览"))
		return
	}

	c.Data(200, info.ContentType, info.Data)

}

func (h *innerVCCMetaAttachmentHandler) GetViewMetaAttachmentUrl20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "ViewMetaAttachment, id=%s", downloadID)

	userInfo := h.fetchUserInfoFromCtx(ctx)
	if userInfo == nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: 用户信息为空")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("用户信息为空"))
		return
	}

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}
	if !info.CanView {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前文档不支持预览"))
		return
	}

	url, urlErr := h.attachmentService.GetAttachmentUrl(ctx, downloadID, version, true)
	if urlErr != nil {
		logs.CtxError(ctx, "GetViewAttachmentUrlFail, err: %v", urlErr)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("GetViewAttachmentUrlFail"))
		return
	}
	vhertz.DoResponse(ctx, c, url)
}

func (h *innerVCCMetaAttachmentHandler) GetDownloadMetaAttachmentUrl20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "DownloadMetaAttachment, id=%s", downloadID)

	userInfo := h.fetchUserInfoFromCtx(ctx)
	if userInfo == nil {
		logs.CtxError(ctx, "DownloadMetaAttachmentFail, err: 用户信息为空")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("用户信息为空"))
		return
	}

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "DownloadMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	url, urlErr := h.attachmentService.GetAttachmentUrl(ctx, downloadID, version, false)
	if urlErr != nil {
		logs.CtxError(ctx, "GetDownloadAttachmentUrlFail, err: %v", urlErr)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("GetDownloadAttachmentUrlFail"))
		return
	}
	vhertz.DoResponse(ctx, c, url)
}

// ViewMetaAttachmentV120210101 预览合同元数据附件 仅支持浏览器允许的附件类型
func (h *innerVCCMetaAttachmentHandler) MetaAttachmentUrl20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query("Token")

	logs.CtxInfo(ctx, "MetaAttachmentUrl, Token=%s", token)

	claim := &bizmodels.DownloadClaims{}
	pErr := util.ParseClaims(ctx, token, claim)
	if pErr != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前文档不支持预览"))
		return
	}
	cRrr := claim.Valid()
	if cRrr != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(cRrr.Error()))
		return
	}

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, claim.DownloadId, claim.Version)
	if err != nil {
		logs.CtxError(ctx, "MetaAttachmentUrl, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	if claim.IsView {
		c.Data(200, info.ContentType, info.Data)
	} else {
		c.Response.Header.Set("Content-Disposition", "attachment;filename="+info.FileName)
		c.Response.Header.Set("Content-type", "application/octet-stream")
		c.Data(200, "application/octet-stream", info.Data)
	}
}

// GetMetaAttachmentURL20210101 获取合同元数据附件访问链接
func (h *innerVCCMetaAttachmentHandler) GetMetaAttachmentURL20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "GetMetaAttachmentInfo, id=%s", downloadID)

	url, name, err := h.metaService.GetViewURL(ctx, &bizmodels.MetaAttachmentDownloadParam{
		DownloadID: downloadID,
		Version:    version,
	})

	if err != nil {
		logs.CtxError(ctx, "GetViewURLFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, &metaattachmodels.AttachmentURL{
		URL:      url,
		FileName: name,
	})

}

// GetAttachmentPreviewInfo20210101 获取合同元数据附件预览信息
func (h *innerVCCMetaAttachmentHandler) GetAttachmentPreviewInfo20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	userInfo := h.fetchUserInfoFromCtx(ctx)
	if userInfo == nil {
		logs.CtxError(ctx, "GetAttachmentPreviewInfoFail, err: 用户信息为空")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("用户信息为空"))
		return
	}

	logs.CtxInfo(ctx, "GetAttachmentPreviewInfo, id=%s, version=%s, currentOperator=%s, employeeID=%d", downloadID, version, userInfo.EmployeeEmail, userInfo.EmployeeID)

	employee, commonErr := larkc.GetEmployeeByIDWithCache(ctx, strconv.FormatInt(userInfo.EmployeeID, 10))
	if commonErr != nil {
		logs.CtxError(ctx, "GetEmployeeFromCacheByIdFail, EmployeeID=%d, err: %s", userInfo.EmployeeID, commonErr.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("查询当前用户信息失败"))
		return
	}
	if employee == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户信息不存在"))
		return
	}
	if employee.Email != userInfo.EmployeeEmail {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户信息异常"))
		return
	}

	req := &bizmodels.GetAttachmentPreviewInfoReq{
		CurrentOperator: userInfo.EmployeeEmail,
		DownloadID:      downloadID,
		DocVersion:      version,
	}

	resp, err := h.attachmentService.GetAttachmentPreviewInfo(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetAttachmentPreviewInfoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// DownloadMetaAttachmentInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 DownloadMetaAttachment20210101
func (h *innerVCCMetaAttachmentHandler) DownloadMetaAttachmentInner20210101(ctx context.Context, c *app.RequestContext) {
	h.DownloadMetaAttachment20210101(ctx, c)
}

// ViewMetaAttachmentInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 ViewMetaAttachment20210101
func (h *innerVCCMetaAttachmentHandler) ViewMetaAttachmentInner20210101(ctx context.Context, c *app.RequestContext) {
	h.ViewMetaAttachment20210101(ctx, c)
}

// UploadMetaAttachmentInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 UploadMetaAttachment20210101
func (h *innerVCCMetaAttachmentHandler) UploadMetaAttachmentInner20210101(ctx context.Context, c *app.RequestContext) {
	h.UploadMetaAttachment20210101(ctx, c)
}

// GetProcessFileInfoInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 GetProcessFileInfo20210101
func (h *innerVCCMetaAttachmentHandler) GetProcessFileInfoInner20210101(ctx context.Context, c *app.RequestContext) {
	h.GetProcessFileInfo20210101(ctx, c)
}

// GetAttachmentPreviewInfoInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 GetAttachmentPreviewInfo20210101
func (h *innerVCCMetaAttachmentHandler) GetAttachmentPreviewInfoInner20210101(ctx context.Context, c *app.RequestContext) {
	h.GetAttachmentPreviewInfo20210101(ctx, c)
}

// ApplyUploadInfo20210101 获取文件预上传信息
func (h *innerVCCMetaAttachmentHandler) ApplyUploadInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.ApplyUploadInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 获取文件与上传链接信息
	res, err1 := h.attachmentService.ApplyUploadInfo(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// InitMultipartUpload20210101 初始化后端中转分片上传
func (h *innerVCCMetaAttachmentHandler) InitMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.InitMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "InitMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	res, err1 := h.attachmentService.InitMultipartUpload(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "InitMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// UploadMultipartPart20210101 上传单个分片到 TOS
func (h *innerVCCMetaAttachmentHandler) UploadMultipartPart20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.UploadMultipartPartReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadMultipartPartReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	formFile, err := c.FormFile("File")
	if err == nil && formFile != nil {
		req.File = formFile
	}

	res, err1 := h.attachmentService.UploadMultipartPart(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "UploadMultipartPartFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// CompleteMultipartUpload20210101 完成 TOS 分片上传合并
func (h *innerVCCMetaAttachmentHandler) CompleteMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.CompleteMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CompleteMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	res, err1 := h.attachmentService.CompleteMultipartUpload(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "CompleteMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// AbortMultipartUpload20210101 取消 TOS 分片上传
func (h *innerVCCMetaAttachmentHandler) AbortMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.AbortMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AbortMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err1 := h.attachmentService.AbortMultipartUpload(ctx, &req); err1 != nil {
		logs.CtxError(ctx, "AbortMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

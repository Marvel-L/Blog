package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/service/riskclauserole"
	"volc_contract_process/pkg/errors"
)

type openRiskClauseRoleHandler struct {
	base
	service riskclauserole.Service
}

func NewOpenRiskClauseRoleHandler() vhertz.ActionHandler {
	return &openRiskClauseRoleHandler{
		service: riskclauserole.NewService(),
	}
}

// ListRiskClauseRole20210101 查询风险条款记录列表（CRM）
func (h *openRiskClauseRoleHandler) ListRiskClauseRole20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.ListRiskClauseRoleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	resp, err := h.service.List(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// CreateRiskClauseRole20210101 创建风险条款记录
func (h *openRiskClauseRoleHandler) CreateRiskClauseRole20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.CreateRiskClauseRoleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseRoleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseRoleValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.CreateRiskClauseRole(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// UpdateRiskClauseRole20210101 更新风险条款记录（CRM）
func (h *openRiskClauseRoleHandler) UpdateRiskClauseRole20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.UpdateRiskClauseRoleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UpdateRiskClauseRoleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "UpdateRiskClauseRoleValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.UpdateRiskClauseRole(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, "success")
}

// DeleteRiskClauseRole20210101 删除风险条款记录
func (h *openRiskClauseRoleHandler) DeleteRiskClauseRole20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.AuditRiskClauseRoleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "DeleteRiskClauseRoleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "DeleteRiskClauseRoleValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.DeleteRiskClauseRole(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// DeleteRiskClauseRole20210101 关闭风险条款，不参与审批，留痕
func (h *openRiskClauseRoleHandler) CloseRiskClauseRole20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.AuditRiskClauseRoleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CloseRiskClauseRoleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "CloseRiskClauseRoleValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	err := h.service.CloseRiskClauseRole(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// Submit20210101 提交审批接口（CRM）
func (h *openRiskClauseRoleHandler) Submit20210101(ctx context.Context, c *app.RequestContext) {

	var req riskclauserole.SubmitApprovalReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "SubmitApprovalParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "SubmitApprovalValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	approveId, err := h.service.SubmitApproval(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, approveId)
}

// GetApproveViewUrl20210101 获取风险条款审批链接（CRM）
func (h *openRiskClauseRoleHandler) GetApproveViewUrl20210101(ctx context.Context, c *app.RequestContext) {

	approveId := c.Query("ApproveId")

	if len(approveId) == 0 {
		logs.CtxError(ctx, "GetApproveViewUrlFail, approveId is empty")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ApproveId"))
		return
	}

	url, err := h.service.GetApproveViewUrl(ctx, approveId)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, url)
}

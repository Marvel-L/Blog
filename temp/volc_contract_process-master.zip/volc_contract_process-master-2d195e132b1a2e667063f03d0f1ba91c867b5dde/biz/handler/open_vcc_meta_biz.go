package handler

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/volcengine-innersdk-golang/volcengine"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metabasic"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/bizmodels/modelmetaext"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/supply"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/biz/service/support/metaext"
	"volc_contract_process/biz/service/workflow"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/idgenerator"
	"volc_contract_process/pkg/proxy/dkmscli"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
)

// 合同中心对外接口——业务合同场景，用于免审批签章流程
type openVCCMetaBizHandler struct {
	base
	metaService          contractmeta.MetaService
	metaServiceV2        contractmeta.MetaServiceV2
	metaExtService       metaext.Service
	riskEngineService    riskengineservice.RiskEngineService
	supplyService        supply.SupplyService
	opRecordService      cooperationrecord.Service
	salesContractService salescontract.SalesContractService
	bizContractService   service.BizContractService
}

func NewOpenVCCMetaBizHandlerHandler() vhertz.ActionHandler {
	return &openVCCMetaBizHandler{
		metaService:          contractmeta.NewMetaService(),
		metaServiceV2:        contractmeta.NewMetaServiceV2(),
		metaExtService:       metaext.NewService(),
		riskEngineService:    riskengineservice.NewRiskEngineService(),
		supplyService:        supply.NewSupplyService(),
		salesContractService: salescontract.NewSalesContractService(),
		opRecordService:      cooperationrecord.NewService(),
		bizContractService:   service.NewBizContractService(),
	}
}

// CreateBizDraft20210101 创建业务合同草稿
// @Summary 创建业务合同草稿
// @Description  创建业务合同草稿, 创建成功后返回合同号
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@CreateBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:CreateBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractMetaCreateParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=workflow.CreateBizResp} "响应信息"
// @Router /vcc/open-api/meta/Action_CreateBizDraft_Version_20210101 [post]
func (h *openVCCMetaBizHandler) CreateBizDraft20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractMetaCreateParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenContractMetaCreateParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.IsUpdate = false

	// 兼容下老逻辑 产品报价&伙伴合同 有固定bizSource
	bizSource := param.BizSource
	if param.BizSource == 0 {
		switch param.BizScene {
		case _const.BizSceneQuoteContract:
			bizSource = _const.BizSourceQuote
		case _const.BizScenePartnerContract:
			bizSource = _const.BizSourcePartner
		}
	}
	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch bizSource {
	case _const.BizSourceQuote:
		tt = workflow.TaskTypeQuoteCreateOrUpdateDraft
	case _const.BizSourcePartner, _const.BizSourcePartnerAgency, _const.BizSourcePartnerDist,
		_const.BizSourcePartnerAgencyDist, _const.BizSourcePartnerIntegratedDelivery, _const.BizSourcePartnerSolution:
		tt = workflow.TaskTypePartnerCreateOrUpdateDraft
	case _const.BizSourcePartnerQuote:
		tt = workflow.TaskTypePartnerQuoteCreateOrUpdateDraft
	case _const.BizSourceCredit:
		tt = workflow.TaskTypeCreditCreateOrUpdateDraft
	case _const.BizSourceMarket:
		tt = workflow.TaskTypeMarketCreateOrUpdateDraft
	default:
		logs.CtxError(ctx, "OpenContractMetaUpdateUnsupportedBizScene, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizSource[%d]", param.BizSource)))
		return
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &param,
	}

	resp, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizCreateHandlerFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if resp == nil {
		logs.CtxError(ctx, "OpenVCCMetaBizCreateHandlerFail, resp_is_nil")
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// UpdateBizDraft20210101 更新业务合同草稿
// @Summary 更新业务合同草稿
// @Description  更新业务合同草稿, 创建成功后返回合同号
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@UpdateBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:UpdateBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo body string true "合同号"
// @Param - body bizmodels.OpenBizContractMetaCreateParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=workflow.CreateBizResp} "响应信息"
// @Router /vcc/open-api/meta/Action_UpdateBizDraft_Version_20210101 [post]
func (h *openVCCMetaBizHandler) UpdateBizDraft20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractMetaCreateParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenContractMetaCreateParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.IsUpdate = true

	// 兼容下老逻辑 产品报价&伙伴合同 有固定bizSource
	bizSource := param.BizSource
	if param.BizSource == 0 {
		switch param.BizScene {
		case _const.BizSceneQuoteContract:
			bizSource = _const.BizSourceQuote
		case _const.BizScenePartnerContract:
			bizSource = _const.BizSourcePartner
		}
	}
	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch bizSource {
	case _const.BizSourceQuote:
		tt = workflow.TaskTypeQuoteCreateOrUpdateDraft
	case _const.BizSourcePartner, _const.BizSourcePartnerAgency, _const.BizSourcePartnerDist,
		_const.BizSourcePartnerAgencyDist, _const.BizSourcePartnerIntegratedDelivery, _const.BizSourcePartnerSolution:
		tt = workflow.TaskTypePartnerCreateOrUpdateDraft
	case _const.BizSourcePartnerQuote:
		tt = workflow.TaskTypePartnerQuoteCreateOrUpdateDraft
	case _const.BizSourceCredit:
		tt = workflow.TaskTypeCreditCreateOrUpdateDraft
	case _const.BizSourceMarket:
		tt = workflow.TaskTypeMarketCreateOrUpdateDraft
	default:
		logs.CtxError(ctx, "OpenContractMetaUpdateUnsupportedBizScene, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizSource[%d]", param.BizSource)))
		return
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &param,
	}

	resp, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizUpdateHandlerFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// SubmitBizDraft20210101 提交业务合同草稿=>变更为待客户确认
// @Summary 提交业务合同草稿
// @Description  提交业务合同草稿
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@SubmitBizDraft20210101
// @Accept json
// @Param Action query string true "Action-默认值:CreateBizDraft"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractSubmitParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=workflow.BizSubmitResp} "响应信息"
// @Router /vcc/open-api/meta/Action_SubmitBizDraft_Version_20210101 [post]
func (h *openVCCMetaBizHandler) SubmitBizDraft20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractSubmitParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractSubmitParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 兼容下老逻辑 产品报价&伙伴合同 有固定bizSource
	bizSource := param.BizSource
	if param.BizSource == 0 {
		switch param.BizScene {
		case _const.BizSceneQuoteContract:
			bizSource = _const.BizSourceQuote
		case _const.BizScenePartnerContract:
			bizSource = _const.BizSourcePartner
		}
	}
	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch bizSource {
	case _const.BizSourceQuote:
		tt = workflow.TaskTypeQuoteSubmit
	case _const.BizSourcePartner, _const.BizSourcePartnerAgency, _const.BizSourcePartnerDist,
		_const.BizSourcePartnerAgencyDist, _const.BizSourcePartnerIntegratedDelivery, _const.BizSourcePartnerSolution:
		tt = workflow.TaskTypePartnerSubmit
	case _const.BizSourcePartnerQuote:
		tt = workflow.TaskTypePartnerQuoteSubmit
	case _const.BizSourceMarket:
		tt = workflow.TaskTypeMarketSubmitOA
	default:
		logs.CtxError(ctx, "OpenContractMetaBizSubmitUnsupportedBizScene, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizScene[%d]", param.BizScene)))
		return
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &param,
	}

	resp, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizHandlerSubmitDraftFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetContractSignURL20210101 获取签约链接
func (h *openVCCMetaBizHandler) GetContractSignURL20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractGetSignURLParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractGetSignURLParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 放宽校验，支持代付合同与市场大赛合同
	if param.BizScene != _const.BizScenePayOnBehalf && param.BizScene != _const.BizSceneMarket {
		logs.CtxError(ctx, "OpenBizContractGetSignURLParamInvalid, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("BizScene"))
		return
	}

	url, err := h.metaService.QuerySignUrl(ctx, param.ContractNo, strconv.FormatInt(param.AccountID, 10))
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"SignURL": url,
	})
}

// AbandonBizContract20210101 作废合同：仅允许作废草稿和待客户确认（针对未签约）
// @Summary 作废合同
// @Description  作废合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@AbandonBizContract20210101
// @Accept json
// @Param Action query string true "Action-默认值:AbandonBizContract"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractAbandonParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_AbandonBizContract_Version_20210101 [post]
func (h *openVCCMetaBizHandler) AbandonBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractAbandonParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractAbandonParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.AbandonBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "AbandonBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)

}

func (h *openVCCMetaBizHandler) RevokeBizContract20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.OpenBizContractRevokeParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractRevokeParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.RevokeBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "RevokeFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Success": true,
		"Message": "撤销成功",
	})
}

// CustomAuditBizContract20210101 客户确认：接受 or 拒绝
// @Summary 客户确认合同-接受or拒绝
// @Description  客户确认合同-接受or拒绝
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@CustomAuditBizContract20210101
// @Accept json
// @Param Action query string true "Action-默认值:CustomAuditBizContract"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.OpenBizContractCustomerAuditParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_CustomAuditBizContract_Version_20210101 [post]
func (h *openVCCMetaBizHandler) CustomAuditBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.OpenBizContractCustomerAuditParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "OpenBizContractCustomerAuditParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 兼容下老逻辑 产品报价&伙伴合同 有固定bizSource
	bizSource := param.BizSource
	if param.BizSource == 0 {
		switch param.BizScene {
		case _const.BizSceneQuoteContract:
			bizSource = _const.BizSourceQuote
		case _const.BizScenePartnerContract:
			bizSource = _const.BizSourcePartner
		}
	}
	// 匹配事件 => todo 统一封装
	var tt workflow.TaskType
	switch bizSource {
	case _const.BizSourceQuote:
		tt = workflow.TaskTypeQuoteCustomerAudit
	case _const.BizSourcePartner, _const.BizSourcePartnerAgency, _const.BizSourcePartnerDist,
		_const.BizSourcePartnerAgencyDist, _const.BizSourcePartnerIntegratedDelivery, _const.BizSourcePartnerSolution:
		tt = workflow.TaskTypePartnerCustomerAudit
	case _const.BizSourcePartnerQuote:
		tt = workflow.TaskTypePartnerQuoteCustomerAudit
	case _const.BizSourceCredit:
		tt = workflow.TaskTypeCreditCustomerAudit
	case _const.BizSourceMarket:
		tt = workflow.TaskTypeMarketCustomerAudit
	default:
		logs.CtxError(ctx, "OpenContractMetaBizCustomerAuditUnsupportedBizScene, bizScene=%d", param.BizScene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的BizScene[%d]", param.BizScene)))
		return
	}

	task := &workflow.EventContext{
		TaskType:     tt,
		EventExtInfo: &param,
	}

	resp, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizHandlerCustomerAuditFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// DownloadBizContract20210101 下载业务合同
// @Summary 下载业务合同
// @Description  下载业务合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@DownloadBizContract20210101
// @Accept json
// @Param Action query string true "Action-默认值:DownloadBizContract"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaBizAttachmentDownloadParam false "请求参数"
// @Success 200  {string} string "字节流"
// @Router /vcc/open-api/meta/Action_DownloadBizContract_Version_20210101 [post]
func (h *openVCCMetaBizHandler) DownloadBizContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaBizAttachmentDownloadParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizAttachmentDownloadParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	fileData, _, filename, err := h.metaService.DownloadBiz(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if len(fileData) == 0 {
		logs.CtxError(ctx, "DownloadBizContractFail, fileDataEmpty")
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", fileData)

}

// GetBizViewURL20210101 获取业务合同文本预览URL
// @Summary 获取业务合同文本预览URL
// @Description  获取业务合同文本预览URL
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetBizViewURL20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetBizViewURL"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaBizAttachmentDownloadParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]string{}{URL=string}} "响应信息"
// @Router /vcc/open-api/meta/Action_GetBizViewURL_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetBizViewURL20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaBizAttachmentDownloadParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizAttachmentDownloadParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	url, _, err := h.metaService.GetViewURLBiz(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp := map[string]interface{}{
		"URL": url,
	}

	vhertz.DoResponse(ctx, c, resp)
}

// GetBizDetail20210101 查询合同详情-GetBizDetail
// @Summary 查询合同详情-GetBizDetail
// @Description  查询合同详情
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetBizDetail20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetBizDetail"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaBizDetailParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.ContractMetaInfo} "响应信息"
// @Router /vcc/open-api/meta/Action_GetBizDetail_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetBizDetail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaBizDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizDetailParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 开放接口默认为管理员，可查询合同信息
	param.IsManager = true

	resp, err := h.metaService.BizDetail(ctx, &param)
	if err != nil {
		logs.CtxWarn(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetMetaDetail20210101 查询合同详情-GetMetaDetail
// @Summary 查询合同详情GetMetaDetail
// @Description  查询合同详情
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetMetaDetail20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetMetaDetail"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaDetailReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.ContractMetaInfo} "响应信息"
// @Router /vcc/open-api/meta/Action_GetMetaDetail_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetMetaDetail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaDetailReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizDetailParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// open 接口默认为管理员 可查询合同内容
	param.IsManager = true

	resp, err := h.metaService.MetaDetail(ctx, &param)
	if err != nil {
		logs.CtxWarn(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetCoStatus20210101 查询合同状态&额外信息
// @Summary 查询合同状态&额外信息
// @Description  查询合同状态&额外信息
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetCoStatus20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetCoStatus"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaCoStatusParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.MetaCoStatusInfo} "响应信息"
// @Router /vcc/open-api/meta/Action_GetCoStatus_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetCoStatus20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.MetaCoStatusParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizDetailParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.metaService.GetCoStatus(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// ListMeta20210101 查询合同列表
// @Summary 查询合同列表
// @Description  查询合同列表
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@ListMeta20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListMeta"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaListParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.MetaListResp} "响应信息"
// @Router /vcc/open-api/meta/Action_ListMeta_Version_20210101 [get]
func (h *openVCCMetaBizHandler) ListMeta20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}
	param.IsManager = true

	ret, err := h.metaService.ListMeta(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// ListSalesMeta20210101 查询销售合同列表
// @Summary 查询销售合同列表
// @Description  查询销售合同列表
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@ListSalesMeta20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListSalesMeta"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.SalesMetaListParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.MetaListResp} "响应信息"
// @Router /vcc/open-api/meta/Action_ListSalesMeta_Version_20210101 [get]
func (h *openVCCMetaBizHandler) ListSalesMeta20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.SalesMetaListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}
	param.IsManager = true

	ret, err := h.metaService.ListMeta(ctx, param.ConvertMetaListParam())
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// DownloadContractMeta20210101 下载业务合同
// @Summary 下载业务合同
// @Description  下载业务合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@DownloadContractMeta20210101
// @Accept json
// @Param Action query string true "Action-默认值:DownloadContractMeta"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaAttachmentDownloadParam false "请求参数"
// @Success 200  {string}  string "字节流"
// @Router /vcc/open-api/meta/Action_DownloadContractMeta_Version_20210101 [get]
func (h *openVCCMetaBizHandler) DownloadContractMeta20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaAttachmentDownloadParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaDownloadAttachmentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	fileData, _, filename, err := h.metaService.Download(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if len(fileData) == 0 {
		logs.CtxError(ctx, "DownloadBizContractFail, fileDataEmpty")
		vhertz.ErrorResp(ctx, c, nil)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", fileData)

}

// GetMetaViewUrl20210101 获取合同中心预览链接
// @Summary 获取合同中心预览链接
// @Description  获取合同中心预览链接
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetMetaViewUrl20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetMetaViewUrl"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MetaAttachmentDownloadParam false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]string{}{URL=string}} "响应信息"
// @Router /vcc/open-api/meta/Action_GetMetaViewUrl_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetMetaViewUrl20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaAttachmentDownloadParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizAttachmentDownloadParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	url, _, err := h.metaService.GetViewURL(ctx, &param)
	if err != nil {
		logs.CtxWarn(ctx, "DownloadBizContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp := map[string]interface{}{
		"URL": url,
	}

	vhertz.DoResponse(ctx, c, resp)
}

// GetSupplyContractList20210101 根据原合同号查询补充协议相关合同列表
// @Summary 根据原合同号查询补充协议相关合同列表
// @Description  根据原合同号查询补充协议相关合同列表
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetSupplyContractList20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetSupplyContractList"
// @Param Version query string true "Version-默认值:20210101"
// @Param FromContractNo query string true "原合同号，示例：CT00001"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.SupplyContractListResp} "响应信息"
// @Router /vcc/open-api/meta/Action_GetSupplyContractList_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetSupplyContractList20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.GetSupplyContractListReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizAttachmentDownloadParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if param.FromContractNo == "" {
		logs.CtxError(ctx, "GetSupplyContractListParamMissing")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("FromContractNo"))
		return
	}

	resp, err := h.metaService.GetSupplyContractList(ctx, param.FromContractNo, param.NeedSupplyRelease)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// IsMeetSupplyCondition20210101 判断合同是否符合发起补充协议条件
// @Summary 判断合同是否符合发起补充协议条件
// @Description  判断合同是否符合发起补充协议条件
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@IsMeetSupplyCondition20210101
// @Accept json
// @Param Action query string true "Action-默认值:IsMeetSupplyCondition"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.IsMeetSupplyConditionReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=modelsupply.IsMeetSupplyConditionResp} "响应信息"
// @Router /vcc/open-api/meta/Action_IsMeetSupplyCondition_Version_20210101 [get]
func (h *openVCCMetaBizHandler) IsMeetSupplyCondition20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.IsMeetSupplyConditionReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "MetaBizAttachmentDownloadParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "IsMeetSupplyConditionParamValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.supplyService.IsMeetSupplyCondition(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// UpdateFinance20210101 更新finance信息
// @Summary 更新finance信息
// @Description  更新finance信息
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@UpdateFinance20210101
// @Accept json
// @Param Action query string true "Action-默认值:UpdateFinance"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo query string true "合同号，示例：CT00001,CT00002"
// @Param Finance query string true "Finance"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_UpdateFinance_Version_20210101 [post]
func (h *openVCCMetaBizHandler) UpdateFinance20210101(ctx context.Context, c *app.RequestContext) {

	contractNoStr, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	contractNoList := strings.Split(contractNoStr, ",")

	finance, ok := c.GetQuery("Finance")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Finance"))
		return
	}

	for _, contractNo := range contractNoList {
		meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
		if err != nil {
			logs.CtxError(ctx, "合同查询失败，contractNo[%v] error:%v", contractNo, err)
			vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
			return
		}
		if meta == nil {
			vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "[%v]此合同不存在", contractNo)))
			return
		}
		err = dal.NewContractMetaDao().UpdateByMap(ctx, nil, int64(meta.Id), map[string]interface{}{"finance": finance})
		if err != nil {
			vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
			return
		}
	}

	vhertz.DoResponse(ctx, c, nil)
}

// SyncOaSalesContract20210101 同步销售合同
// @Summary 同步销售合同
// @Description  同步销售合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@SyncOaSalesContract20210101
// @Accept json
// @Param Action query string true "Action-默认值:SyncOaSalesContract"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo query string true "合同号，示例：CT00001"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_SyncOaSalesContract_Version_20210101 [post]
func (h *openVCCMetaBizHandler) SyncOaSalesContract20210101(ctx context.Context, c *app.RequestContext) {

	ContractNo := c.Query("ContractNo")

	if len(ContractNo) == 0 {
		logs.CtxError(ctx, "SyncContractParamMissing")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	err := h.salesContractService.SyncContractByNo(ctx, ContractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// GetInProcessProduct20210101 根据商品查询在履约的合同
// @Summary 根据商品查询在履约的合同
// @Description  根据商品查询在履约的合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetInProcessProduct20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetInProcessProduct"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.GetInProcessProductReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_GetInProcessProduct_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetInProcessProduct20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.GetInProcessProductReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}
	// 预置文件下载标识，用于请求方获取文件
	if len(param.DownLoadId) == 0 {
		param.DownLoadId = idgenerator.GeneratorID("FID")
	}
	// 异步执行导出操作
	if err := h.metaService.GetInProcessProductInfo(ctx, param); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, param.DownLoadId)
}

// QueryLadderQuotationContract20210101 查询阶梯报价合同
// @Summary 查询阶梯报价合同
// @Description  查询阶梯报价合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@QueryLadderQuotationContract20210101
// @Accept json
// @Param Action query string true "Action-默认值:QueryLadderQuotationContract"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.QueryLadderQuotationContractReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.QueryLadderQuotationContractResp} "响应信息"
// @Router /vcc/open-api/meta/Action_QueryLadderQuotationContract_Version_20210101 [get]
func (h *openVCCMetaBizHandler) QueryLadderQuotationContract20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.QueryLadderQuotationContractReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	// 查询重复项
	resp, err := h.metaService.QueryLadderQuotationContractByCache(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// CheckLadderQuoteContractClash20210101 校验是否存在在途的阶梯报价合同
// @Summary 校验是否存在在途的阶梯报价合同
// @Description  校验是否存在在途的阶梯报价合同
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@CheckLadderQuoteContractClash20210101
// @Accept json
// @Param Action query string true "Action-默认值:CheckLadderQuoteContractClash"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.CheckLadderQuoteContractClashReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.CheckLadderQuoteContractClashResp} "响应信息"
// @Router /vcc/open-api/meta/Action_CheckLadderQuoteContractClash_Version_20210101 [get]
func (h *openVCCMetaBizHandler) CheckLadderQuoteContractClash20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.CheckLadderQuoteContractClashReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	// 查询重复项
	resp, err := h.metaService.CheckLadderQuoteContractClash(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// GetFeishuViewUrl20210101 获取飞书合同预览链接
// @Summary 获取飞书合同预览链接
// @Description  获取飞书合同预览链接
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetFeishuViewUrl20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetFeishuViewUrl"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo query string true "合同号"
// @Param Creator query string true "创建人"
// @Success 200  {object}  hertz.CommonResponse{Result=string} "响应信息"
// @Router /vcc/open-api/meta/Action_GetFeishuViewUrl_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetFeishuViewUrl20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	creator := c.Query("Creator")
	// 参数校验
	if len(creator) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Creator"))
		return
	}

	// 查询重复项
	viewUrl, err := h.metaService.QueryFeishuViewUrl(ctx, contractNo, creator)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, viewUrl)
}

// PreCheckCreateContractPrice20210101 合同价预校验
// @Summary 合同价预校验
// @Description  合同价预校验
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@PreCheckCreateContractPrice20210101
// @Accept json
// @Param Action query string true "Action-默认值:PreCheckCreateContractPrice"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body modelcommodity.PreCheckCreateContractPriceReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=modelcommodity.PreCheckCreateContractPriceReqResp} "响应信息"
// @Router /vcc/open-api/meta/Action_PreCheckCreateContractPrice_Version_20210101 [get]
func (h *openVCCMetaBizHandler) PreCheckCreateContractPrice20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.PreCheckCreateContractPriceReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 预校验
	resp, err := h.metaServiceV2.PreCheckCreateContractPrice(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// CheckQuoteItemRepeat20210101 合同价重复校验
// @Summary 合同价重复校验
// @Description  合同价重复校验
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@CheckQuoteItemRepeat20210101
// @Accept json
// @Param Action query string true "Action-默认值:CheckQuoteItemRepeatReq"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body modelcommodity.PreCheckCreateContractPriceReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=modelcommodity.CheckQuoteItemRepeatData} "响应信息"
// @Router /vcc/open-api/meta/Action_CheckQuoteItemRepeat_Version_20210101 [get]
func (h *openVCCMetaBizHandler) CheckQuoteItemRepeat20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.CheckQuoteItemRepeatReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	// 查询重复项
	viewUrl, err := h.metaServiceV2.CheckQuoteItemRepeat(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, viewUrl)
}

// CheckContractQuoteItemRepeat20210101 合同价重复校验V2
// @Summary 合同价重复校验V2
// @Description  合同价重复校验V2
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@CheckContractQuoteItemRepeat20210101
// @Accept json
// @Param Action query string true "Action-默认值:CheckQuoteItemRepeatReq"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body modelcommodity.CheckContractQuoteItemRepeatReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=modelcommodity.CheckQuoteItemRepeatData} "响应信息"
// @Router /vcc/open-api/meta/Action_CheckContractQuoteItemRepeat_Version_20210101 [get]
func (h *openVCCMetaBizHandler) CheckContractQuoteItemRepeat20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.CheckContractQuoteItemRepeatReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	// 查询重复项
	repeatData, err := h.metaServiceV2.CheckContractQuoteItemRepeat(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, repeatData)
}

// ClearRelateQuote20210101 清除关联报价单
// @Summary 清除关联报价单
// @Description  清除关联报价单
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@ClearRelateQuote20210101
// @Accept json
// @Param Action query string true "Action-默认值:ClearRelateQuote"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body modelcommodity.ClearRelateQuoteReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=object} "响应信息"
// @Router /vcc/open-api/meta/Action_ClearRelateQuotet_Version_20210101 [post]
func (h *openVCCMetaBizHandler) ClearRelateQuote20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.ClearRelateQuoteReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 参数校验
	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}

	// 查询重复项
	err := h.metaServiceV2.ClearRelateQuote(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}
	vhertz.DoResponse(ctx, c, nil)
}

// GetDepartmentInfo20210101 获取合同归属行业&审批人
// @Summary 获取合同归属行业&审批人
// @Description  获取合同归属行业&审批人
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetDepartmentInfo20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetDepartmentInfo"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.GetDepartmentInfoReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=bizmodels.GetDepartmentInfoResp} "响应信息"
// @Router /vcc/open-api/meta/Action_GetDepartmentInfo_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetDepartmentInfo20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	req := &bizmodels.GetDepartmentInfoReq{
		ContractNo: contractNo,
	}

	// 获取归属行业&审批人信息
	resp, err := h.metaService.GetDepartmentInfo(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// ListOperationRecord20210101 获取合同协作记录
// @Summary 获取合同协作记录
// @Description  获取合同协作记录
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@ListOperationRecord20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListOperationRecord"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo query string true "合同号"
// @Success 200  {object}  hertz.CommonResponse{} "响应信息"
// @Router /vcc/open-api/meta/Action_ListOperationRecord_Version_20210101 [get]
func (h *openVCCMetaBizHandler) ListOperationRecord20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	// 查询重复项
	opRecords, err := h.opRecordService.ListByContractNo(ctx, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"List": opRecords,
	})
}

// NeedSubjectChangeAgreement20210101 是否需要发起主体变更协议
// @Summary 是否需要发起主体变更协议
// @Description  是否需要发起主体变更协议
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@NeedSubjectChangeAgreement20210101
// @Accept json
// @Param Action query string true "Action-默认值:NeedSubjectChangeAgreement"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body contractmeta.NeedSubjectChangeAgreementReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]object{List=[]*NeedSubjectChangeAgreementItemp} "响应信息"
// @Router /vcc/open-api/meta/Action_NeedSubjectChangeAgreement_Version_20210101 [get]
func (h *openVCCMetaBizHandler) NeedSubjectChangeAgreement20210101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.NeedSubjectChangeAgreementReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "NeedSubjectChangeAgreementReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "NeedSubjectChangeAgreementReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 查询重复项
	res, err := h.metaServiceV2.NeedSubjectChangeAgreement(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"List": res,
	})
}

// GetEffectiveSubjectList20210101 获取可使用我方主体列表
// @Summary 是否需要发起主体变更协议
// @Description  是否需要发起主体变更协议
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@GetEffectiveSubjectList20210101
// @Accept json
// @Param Action query string true "Action-默认值:GetEffectiveSubjectList"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body contractmeta.GetEffectiveSubjectMapReq false "请求参数"
// @Success 200  {object}  hertz.CommonResponse{Result=map[string]*bizmodels.TradePartyInfoDetail} "响应信息"
// @Router /vcc/open-api/meta/Action_GetEffectiveSubjectList_Version_20210101 [get]
func (h *openVCCMetaBizHandler) GetEffectiveSubjectMap20210101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.GetEffectiveSubjectMapReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 查询重复项
	res, err := h.metaServiceV2.GetEffectiveSubjectMap(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// CheckCurrencyAndExchangeRate20210101 校验币种、汇率信息是否一致
func (h *openVCCMetaBizHandler) CheckCurrencyAndExchangeRate20210101(ctx context.Context, c *app.RequestContext) {

	var param metabasic.CheckCurrencyAndExchangeRateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 查询重复项
	res, err := basicinfo.CheckCurrencyAndExchangeRate(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}
	vhertz.DoResponse(ctx, c, res)
}

// SubmitComplianceCheck 提交合规审查
// @Summary 提交合规审查
// @Description 提交合规审查
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/meta@SubmitComplianceCheck
// @Accept json
// @Param Action query string true "Action-默认值:SubmitComplianceCheck"
// @Param Version query string true "Version-默认值:20210101"
// @Param ContractNo body string true "合同号"
// @Success 200  {object}  hertz.CommonResponse{Result=riskenginecli.RiskEngineResp} "响应信息"
// @Router /vcc/open-api/meta/Action_SubmitComplianceCheck_Version_20210101 [post]
func (h *openVCCMetaBizHandler) SubmitComplianceCheck20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.SubmitComplianceCheckReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetEffectiveSubjectMapReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	resp, err := h.riskEngineService.Submit(ctx, param.ContractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// GetMetaExt20210101 获取合同附加信息
func (h *openVCCMetaBizHandler) GetMetaExt20210101(ctx context.Context, c *app.RequestContext) {

	var param modelmetaext.GetMetaExtReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetMetaExtReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "GetMetaExtReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	metaDB, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, param.ContractNo)
	if err != nil {
		logs.CtxError(ctx, "GetMetaExt_FindLastByNoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("查询合同信息失败"))
		return
	}
	if metaDB == nil {
		logs.CtxError(ctx, "GetMetaExt_meta_is_nil")
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("meta is nil"))
		return
	}
	resp, err := h.metaExtService.GetMetaExtMap(ctx, nil, int(metaDB.Id), param.AttrKeys)
	if err != nil {
		logs.CtxError(ctx, "GetMetaExt_GetMetaExtMapFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("GetMetaExtMapFail"))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// ExistPartyMD20210101 认证是否成功
// Audit20210101 认证是否成功
// @Summary 认证是否成功
// @Description  外部接口-合同审核
// @Tags 合同相关接口-控制台
// @ID /vcp/open-api/contract_process@ExistPartyMD20210101
// @Accept json
// @Param Action query string true "Action-默认值:ExistPartyMD"
// @Param Version query string true "Version-默认值:20210101"
// @Param - body bizmodels.MdPartyExistParam false "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=map[string]object{Exist=bool,RegistCountry=string,CustomerName=string,DocumentCode=string,IdentityType=int,CertificateType=int}} "响应信息"
// @Router /vcp/open-api/contract_process/Action_ExistPartyMD_Version_20210101 [get]
func (h *openVCCMetaBizHandler) ExistPartyMD20210101(ctx context.Context, c *app.RequestContext) { // ignore_security_alert IDOR

	var param bizmodels.MdPartyExistParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDownloadReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	exist, err := h.bizContractService.ExistPartyMD(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	verify, err1 := innerapiaccountcli.GetVerification(ctx, param.AccountID)
	if err1 != nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取账号信息失败"))
		return
	}
	if verify == nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, verify is nil")
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("获取账号信息失败"))
		return
	}

	var ret = map[string]interface{}{
		"Exist":           exist,
		"RegistCountry":   volcengine.StringValue(verify.CountryCodeTwo),
		"CustomerName":    volcengine.StringValue(verify.VerifyName),
		"IdentityType":    volcengine.StringValue(verify.IdentityType),    // 认证类型：个人-1 企业-2
		"CertificateType": volcengine.StringValue(verify.CertificateType), // 证件类型：身份证-1
		"DocumentCode":    volcengine.StringValue(verify.CertificateCode),
	}

	retBody, _ := json.Marshal(ret)
	dkmscli.CtxInfo(ctx, "ExistPartyMD，响应数据 => %s", string(retBody))

	vhertz.DoResponse(ctx, c, ret)
}

package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/service/support/reviewrule"
	"volc_contract_process/pkg/errors"
)

type openRiviewRuleHandler struct {
	base
	service reviewrule.Service
}

func NewOpenRiviewRuleHandler() vhertz.ActionHandler {
	return &openRiviewRuleHandler{
		service: reviewrule.NewService(),
	}
}

func (h *openRiviewRuleHandler) ListReviewRule20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListReviewRuleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListReviewRuleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.ListReviewRule(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *openRiviewRuleHandler) ListSalesDepartment20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListSalesDepartmentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.ListSalesDepartment(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *openRiviewRuleHandler) ListSalesDepartmentInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListSalesDepartmentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.ListSalesDepartmentInfo(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

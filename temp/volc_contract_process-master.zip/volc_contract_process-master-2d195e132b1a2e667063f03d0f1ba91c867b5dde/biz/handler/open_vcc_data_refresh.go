package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/quoterefresh"
	"volc_contract_process/pkg/errors"
)

type openVCCDataRefreshHandler struct {
	base
	quoteRefreshService quoterefresh.Service
}

// NewOpenVCCDataRefreshHandler 创建数据刷数 OpenAPI handler
func NewOpenVCCDataRefreshHandler() vhertz.ActionHandler {
	return &openVCCDataRefreshHandler{
		quoteRefreshService: quoterefresh.NewService(),
	}
}

// QuoteRefreshNotify20210101 报价刷数通知
// @Summary 报价刷数通知
// @Description 报价刷数审批通过后通知合同系统刷新合同侧代金券配置
// @Tags open-api接口中心鉴权
// @ID /vcc/open-api/data_refresh@QuoteRefreshNotify20210101
// @Accept json
// @Param Action query string true "Action-默认值:QuoteRefreshNotify"
// @Param Version query string true "Version-默认值:20210101"
// @Param body bizmodels.QuoteRefreshNotifyReq true "请求体"
// @Success 200 {object} vhertz.CommonResponse{Result=bizmodels.QuoteRefreshNotifyResp} "响应信息"
// @Router /vcc/open-api/data_refresh/Action_QuoteRefreshNotify_Version_20210101 [post]
func (h *openVCCDataRefreshHandler) QuoteRefreshNotify20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.QuoteRefreshNotifyReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "QuoteRefreshNotifyReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "QuoteRefreshNotifyReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.quoteRefreshService.QuoteRefreshNotify(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "QuoteRefreshNotifyFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

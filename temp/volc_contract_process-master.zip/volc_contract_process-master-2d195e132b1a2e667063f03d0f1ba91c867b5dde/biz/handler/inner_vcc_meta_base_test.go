package handler

import (
	"context"
	stderrors "errors"
	"testing"
	"time"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/feishuservice"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type fakeFeishuContractService struct {
	feishuservice.FeishuContractService
	syncFn func(context.Context, []string) errors.APIError
}

func (f *fakeFeishuContractService) SyncContract(ctx context.Context, contractNoList []string) errors.APIError {
	if f.syncFn != nil {
		return f.syncFn(ctx, contractNoList)
	}
	return nil
}

func TestNewInnerVCCMetaBaseHandler(t *testing.T) {
	mockey.PatchConvey("创建 meta base handler", t, func() {
		convey.So(NewInnerVCCMetaBaseHandler(), convey.ShouldNotBeNil)
	})
}

func TestInnerVCCMetaBaseHandlerSyncContract20210101(t *testing.T) {
	t.Run("绑定失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
			(&innerVCCMetaBaseHandler{feishuContractService: &fakeFeishuContractService{}}).SyncContract20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("空合同号列表直接返回提示", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			(&innerVCCMetaBaseHandler{feishuContractService: &fakeFeishuContractService{}}).SyncContract20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.body, convey.ShouldEqual, "传入合同号为空")
		})
	})
	t.Run("有登录态时异步同步并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := make(chan []string, 1)
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				contractNos := obj.(*[]string)
				*contractNos = []string{"C-1"}
				return nil
			}).Build()
			h := &innerVCCMetaBaseHandler{feishuContractService: &fakeFeishuContractService{syncFn: func(ctx context.Context, contractNoList []string) errors.APIError {
				called <- contractNoList
				return nil
			}}}
			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{EmployeeEmail: "op@example.com", EmployeeID: 1})
			h.SyncContract20210101(ctx, &app.RequestContext{})
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			select {
			case got := <-called:
				convey.So(got, convey.ShouldResemble, []string{"C-1"})
			case <-time.After(time.Second):
				t.Fatal("SyncContract not called")
			}
		})
	})
}

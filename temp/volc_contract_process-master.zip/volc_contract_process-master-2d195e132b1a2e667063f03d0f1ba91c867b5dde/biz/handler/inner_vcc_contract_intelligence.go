package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/contractintelligence"
	"volc_contract_process/pkg/errors"
)

type innerVCCContractIntelligenceHandler struct {
	base
	service contractintelligence.Service
}

func NewInnerVCCContractIntelligenceHandler() vhertz.ActionHandler {
	return &innerVCCContractIntelligenceHandler{
		service: contractintelligence.NewService(),
	}
}

// SubmitAIAuditFeedback20210101 提交合同智能反馈
func (h *innerVCCContractIntelligenceHandler) SubmitAIAuditFeedback20210101(ctx context.Context, c *app.RequestContext) {
	var req bizmodels.SubmitContractIntelligenceFeedbackReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "SubmitContractIntelligenceFeedbackParamBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "SubmitContractIntelligenceFeedbackValidateFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if err := h.service.Submit(ctx, &req); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, nil)
}

// GetAIAuditReport20210101 查询合同智能审核报告
func (h *innerVCCContractIntelligenceHandler) GetAIAuditReport20210101(ctx context.Context, c *app.RequestContext) {
	var req bizmodels.GetAIAuditReportReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetAIAuditReportParamBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "GetAIAuditReportValidateFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.service.GetAIAuditReport(ctx, &req)
	if err != nil {
		logs.CtxError(ctx, "GetAIAuditReportFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

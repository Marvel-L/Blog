package handler

import (
	"context"
	stderrors "errors"
	"testing"

	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/pkg/errors"
)

type fakeOpenMetaTemplateService struct {
	template.Service
	replaceFn  func(context.Context, *bizmodels.TemplateReplaceReq) (*bizmodels.BuildReplaceMapResp, errors.APIError)
	templateFn func(context.Context, *bizmodels.TemplateReplaceReq) (*templateclient.FillFileData, errors.APIError)
}

func (f *fakeOpenMetaTemplateService) GetTemplateReplaceMap(ctx context.Context, req *bizmodels.TemplateReplaceReq) (*bizmodels.BuildReplaceMapResp, errors.APIError) {
	if f.replaceFn != nil {
		return f.replaceFn(ctx, req)
	}
	return &bizmodels.BuildReplaceMapResp{TemplateTextParams: map[string]interface{}{"k": "v"}}, nil
}

func (f *fakeOpenMetaTemplateService) GetContractTemplate(ctx context.Context, req *bizmodels.TemplateReplaceReq) (*templateclient.FillFileData, errors.APIError) {
	if f.templateFn != nil {
		return f.templateFn(ctx, req)
	}
	return &templateclient.FillFileData{}, nil
}

func (f *fakeOpenMetaTemplateService) BuildTemplateInfo(ctx context.Context, templateKey string, metaContract *model.ContractMetaDB, extMap, templateExt map[string]string) (*bizmodels.TemplateInfo, error) {
	return nil, nil
}

func (f *fakeOpenMetaTemplateService) ListCertificationTemplate(ctx context.Context, req *templateclient.ListTemplateReq) ([]*templateclient.VolcTemplate, errors.APIError) {
	return nil, nil
}

func (f *fakeOpenMetaTemplateService) DownLoadCertificationTemplate(ctx context.Context, tplKey string, accountID uint64) ([]byte, string, errors.APIError) {
	return nil, "", nil
}

func (f *fakeOpenMetaTemplateService) IsAppendSeedanceGuaranteeAppend(ctx context.Context, accountIDs string, bizInfo *bizmodels.QuoteBizInfo) (bool, error) {
	return false, nil
}

func TestNewOpenVCCMetaTemplateHandler(t *testing.T) {
	mockey.PatchConvey("创建 open 模板 handler", t, func() {
		convey.So(NewOpenVCCMetaTemplateHandler(), convey.ShouldNotBeNil)
	})
}

func TestOpenVCCMetaTemplateHandlerGetTemplateReplaceMap20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&openVCCMetaTemplateHandler{templateService: &fakeOpenMetaTemplateService{}}).GetTemplateReplaceMap20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("svc")
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&openVCCMetaTemplateHandler{templateService: &fakeOpenMetaTemplateService{replaceFn: func(ctx context.Context, req *bizmodels.TemplateReplaceReq) (*bizmodels.BuildReplaceMapResp, errors.APIError) {
				return nil, serviceErr
			}}}).GetTemplateReplaceMap20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功返回模板替换参数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := &bizmodels.BuildReplaceMapResp{TemplateTextParams: map[string]interface{}{"name": "demo"}}
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&openVCCMetaTemplateHandler{templateService: &fakeOpenMetaTemplateService{replaceFn: func(ctx context.Context, req *bizmodels.TemplateReplaceReq) (*bizmodels.BuildReplaceMapResp, errors.APIError) {
				return expected, nil
			}}}).GetTemplateReplaceMap20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

func TestOpenVCCMetaTemplateHandlerGetContractTemplate20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&openVCCMetaTemplateHandler{templateService: &fakeOpenMetaTemplateService{}}).GetContractTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功返回模板文件数据", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := &templateclient.FillFileData{}
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&openVCCMetaTemplateHandler{templateService: &fakeOpenMetaTemplateService{templateFn: func(ctx context.Context, req *bizmodels.TemplateReplaceReq) (*templateclient.FillFileData, errors.APIError) {
				return expected, nil
			}}}).GetContractTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

var _ template.Service = (*fakeOpenMetaTemplateService)(nil)

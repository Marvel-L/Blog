package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/lang/strings"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/comment"
	"volc_contract_process/pkg/errors"
)

// 评论模块
type openCommentHandler struct {
	base
	commentService comment.CommentService
}

func NewOpenCommentHandler() vhertz.ActionHandler {
	return &openCommentHandler{
		commentService: comment.NewCommentService(),
	}
}

// PublishComment20210101 发布评论
// @Summary 发布评论
// @Description 发布评论
// @Tags 评论相关接口
// @ID //vcc/open-api/comment@PublishComment20210101
// @Accept json
// @Param Action query string true "Action-默认值:PublishComment"
// @Param Version query string true "Version-默认值:20210101"
// @Param body bizmodels.PublishCommentReq true "请求体"
// @Success 200 {object} bizmodels.PublishCommentResp "响应体"
// @Router /vcc/open-api/comment/Action_PublishComment_Version_20210101 [post]
func (h *openCommentHandler) PublishComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.PublishCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "PublishCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	resp, err := h.commentService.PublishComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// DeleteComment20210101 删除评论
// @Summary 删除评论
// @Description 删除评论
// @Tags 评论相关接口
// @ID /vcc/open-api/comment@DeleteComment20210101
// @Accept json
// @Param Action query string true "Action-默认值:DeleteComment"
// @Param Version query string true "Version-默认值:20210101"
// @Param body bizmodels.DeleteCommentReq true "请求体"
// @Success 200 {object} bizmodels.DeleteCommentResp "响应体"
// @Router /vcc/open-api/comment/Action_DeleteComment_Version_20210101 [post]
func (h *openCommentHandler) DeleteComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.DeleteCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "DeleteCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if strings.IsEmpty(param.CommentID) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CommentID"))
		return
	}

	if strings.IsEmpty(param.Operator) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Operator"))
		return
	}

	err := h.commentService.DeleteComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ListComment20210101 查询评论
// @Summary 查询评论
// @Description 查询评论
// @Tags 评论相关接口
// @ID /vcc/open-api/comment@ListComment20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListComment"
// @Param Version query string true "Version-默认值:20210101"
// @Param body bizmodels.ListCommentReq true "请求体"
// @Success 200 {object} bizmodels.ListCommentResp "响应体"
// @Router /vcc/open-api/comment/Action_ListComment_Version_20210101 [get]
func (h *openCommentHandler) ListComment20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.ListCommentReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ListCommentReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if param.CommentScene <= 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CommentScene"))
		return
	}

	if strings.IsEmpty(param.RelatedID) {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("RelatedID"))
		return
	}

	resp, err := h.commentService.ListComment(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

package handler

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"strconv"
	"time"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/service/feishuapproval"
	"volc_contract_process/biz/service/feishuapproval/feishumodel"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/riskenginecli"
)

type callBackHandler struct {
	base
}

func NewCallBackHandler() vhertz.ActionHandler {
	return &callBackHandler{}
}

func (h *callBackHandler) ApproveCallBack20210101(ctx context.Context, c *app.RequestContext) {
	var req feishumodel.ApprovalEventRequest
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ApproveCallBackParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	err := feishuapproval.ForwardDeferApprovalCallbackData(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, "success")
}

func (h *callBackHandler) RiskEngineCallBack20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "RiskEngineCallBack20210101_start")
	riskEngineConf, err := riskenginecli.GetRiskEngineConf(ctx)
	if riskEngineConf == nil || err != nil {
		logs.CtxError(ctx, "GetRiskEngineConfFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs("GetRiskEngineConfFail"))
		return
	}

	reqBody, err := c.Request.BodyE()
	if err != nil {
		logs.CtxError(ctx, "RiskEngineCallBack20210101 Parse ReqBody Fail, err :%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}

	timestampStr := c.Query("timestamp")
	sign := c.Query("sign")

	if len(timestampStr) == 0 || len(sign) == 0 {
		logs.CtxError(ctx, "RiskEngineCallBack20210101 Timestamp/Sign Empty, err :%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("Timestamp/Sign Empty"))
		return
	}

	timestamp, err := strconv.ParseInt(timestampStr, 10, 64)
	if err != nil {
		logs.CtxError(ctx, "RiskEngineCallBack20210101 Parse Timestamp Fail, err :%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}
	if time.Now().UnixMilli()-timestamp > 5*60*1000 { //时间戳5分钟内有效
		logs.CtxInfo(ctx, "RiskEngineCallBack20210101 Timestamp Expire, timestamp :%v", timestamp)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("Timestamp Expire"))
		return
	}
	reqBodyJsonStr := string(reqBody)
	signStr := reqBodyJsonStr + timestampStr + riskEngineConf.Sec

	h5 := md5.New()
	h5.Write([]byte(signStr))
	expectedSign := hex.EncodeToString(h5.Sum(nil))

	if sign != expectedSign {
		logs.CtxError(ctx, "RiskEngineCallBack20210101 Sign Not Match")
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("Invalid Sign"))
		return
	}

	var req riskengineservice.ComplianceReviewCallbackRequest
	if err = binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "RiskEngineCallBackParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err = riskengineservice.NewRiskEngineService().RiskEngineCallback(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "riskengineservice.RiskEngineCallback Fail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	logs.CtxInfo(ctx, "RiskEngineCallBack20210101 Success")

	c.JSON(200, map[string]interface{}{
		"status": "0",
		"msg":    "success",
	})
}

package handler

import (
	"context"
	"fmt"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/cronservice"
	"volc_contract_process/biz/service/larkservice"
	"volc_contract_process/biz/service/reviewerremind"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type innerPreContractResponseRecorder struct {
	errorResp vhertz.APIError
	result    interface{}
}

func newInnerPreContractResponseRecorder() *innerPreContractResponseRecorder {
	recorder := &innerPreContractResponseRecorder{}
	mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
		recorder.errorResp = err
	}).Build()
	mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
		recorder.result = result
	}).Build()
	return recorder
}

func mockInnerPreContractGetQuery(values map[string]string, exists map[string]bool) {
	mockey.Mock((*app.RequestContext).GetQuery).To(func(key string) (string, bool) {
		if exists != nil {
			return values[key], exists[key]
		}
		v, ok := values[key]
		return v, ok
	}).Build()
}

func TestNewInnerPreContractHandler(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := NewInnerPreContractHandler()

			realHandler, ok := h.(*innerPreContractHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(realHandler.service, convey.ShouldNotBeNil)
			convey.So(realHandler.opRecordService, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerPreContractHandler_JoinOrCreateGroupChat20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			called := false
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(larkservice.JoinOrCreateGroupChat).To(func(ctx context.Context, tx *gorm.DB, req *larkservice.JoinOrCreateGroupChatReq) (*larkservice.JoinOrCreateGroupChatResp, error) {
				called = true
				return nil, nil
			}).Build()

			h := &innerPreContractHandler{}
			h.JoinOrCreateGroupChat20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(recorder.result, convey.ShouldBeNil)
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*larkservice.JoinOrCreateGroupChatReq)
				req.PreContractNo = "PC-001"
				return nil
			}).Build()
			mockey.Mock(larkservice.JoinOrCreateGroupChat).Return(nil, fmt.Errorf("join fail")).Build()

			h := &innerPreContractHandler{}
			h.JoinOrCreateGroupChat20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &larkservice.JoinOrCreateGroupChatResp{OpenChatID: "oc_123"}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(larkservice.JoinOrCreateGroupChat).Return(expected, nil).Build()

			h := &innerPreContractHandler{}
			h.JoinOrCreateGroupChat20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_ListUrgeNotifyUserList20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.ListUrgeNotifyUserList20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case execute fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrorCommon.WithArgs("list urge fail")
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.ListUrgeNotifyUserListReq).Execute).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.ListUrgeNotifyUserList20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := []*bizmodels.UrgeNotifyInfo{{Email: "a@test.com", Name: "name"}}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.ListUrgeNotifyUserListReq).Execute).Return(expected, nil).Build()

			h := &innerPreContractHandler{}
			h.ListUrgeNotifyUserList20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_SendUrgeNotify20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.SendUrgeNotify20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case execute fail with header operator", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@test.com")
			serviceErr := errors.ErrorCommon.WithArgs("urge fail")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.SendUrgeNotifyReq)
				req.CurrentOperator = "body@test.com"
				return nil
			}).Build()
			mockey.Mock((*salescontract.SendUrgeNotifyReq).Execute).To(func(req *salescontract.SendUrgeNotifyReq, ctx context.Context) (map[string]bool, errors.APIError) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "header@test.com")
				return nil, serviceErr
			}).Build()

			h := &innerPreContractHandler{}
			h.SendUrgeNotify20210101(ctx, &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := map[string]bool{"a@test.com": true}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.SendUrgeNotifyReq).Execute).Return(expected, nil).Build()

			h := &innerPreContractHandler{}
			h.SendUrgeNotify20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_OverdueReviewRemind20210101(t *testing.T) {
	t.Run("case token missing", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{}, map[string]bool{"token": false})

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "参数非法")
		})
	})
	t.Run("case config nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "token"}, nil)
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "config == nil")
		})
	})
	t.Run("case cron config nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "token"}, nil)
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{}).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "config.CronConf == nil")
		})
	})
	t.Run("case token not match", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "bad-token"}, nil)
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{CronConf: &conf.CronConf{HttpCallToken: "good-token"}}).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "token not match")
		})
	})
	t.Run("case notifier nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			oldNotifier := cronservice.ReviewerRemindAutoNotifier
			defer func() { cronservice.ReviewerRemindAutoNotifier = oldNotifier }()
			cronservice.ReviewerRemindAutoNotifier = nil
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "token"}, nil)
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{CronConf: &conf.CronConf{HttpCallToken: "token"}}).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "ReviewerRemindAutoNotifier == nil")
		})
	})
	t.Run("case run fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			oldNotifier := cronservice.ReviewerRemindAutoNotifier
			defer func() { cronservice.ReviewerRemindAutoNotifier = oldNotifier }()
			cronservice.ReviewerRemindAutoNotifier = &reviewerremind.AutoNotifier{}
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "token"}, nil)
			mockey.Mock((*app.RequestContext).DefaultQuery).Return("PC-001").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{CronConf: &conf.CronConf{HttpCallToken: "token"}}).Build()
			mockey.Mock((*reviewerremind.AutoNotifier).RunWithContext).Return(fmt.Errorf("run fail")).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "run fail")
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			oldNotifier := cronservice.ReviewerRemindAutoNotifier
			defer func() { cronservice.ReviewerRemindAutoNotifier = oldNotifier }()
			cronservice.ReviewerRemindAutoNotifier = &reviewerremind.AutoNotifier{}
			c := &app.RequestContext{}
			mockInnerPreContractGetQuery(map[string]string{"token": "token"}, nil)
			mockey.Mock((*app.RequestContext).DefaultQuery).Return("PC-001").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{CronConf: &conf.CronConf{HttpCallToken: "token"}}).Build()
			mockey.Mock((*reviewerremind.AutoNotifier).RunWithContext).Return(nil).Build()

			h := &innerPreContractHandler{}
			h.OverdueReviewRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "success")
		})
	})
}

func Test_innerPreContractHandler_GetPreContractReviewer20210101(t *testing.T) {
	t.Run("case missing pre contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{}, map[string]bool{"PreContractNo": false})

			h := &innerPreContractHandler{}
			h.GetPreContractReviewer20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("PreContractNo"))
		})
	})
	t.Run("case dao fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PC-001"}, nil)
			dao := dal.NewPreContractReviewerDao()
			mockey.Mock(mockey.GetMethod(dao, "FindReviewersByNo")).Return(nil, fmt.Errorf("dao fail")).Build()

			h := &innerPreContractHandler{}
			h.GetPreContractReviewer20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("case success without reviewer name", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PC-001", "WithReviewerName": "false"}, nil)
			dbList := model.PreContractReviewerDBList{{PreContractNo: "PC-001", Reviewer: "a@test.com"}}
			dao := dal.NewPreContractReviewerDao()
			mockey.Mock(mockey.GetMethod(dao, "FindReviewersByNo")).Return(dbList, nil).Build()

			h := &innerPreContractHandler{}
			h.GetPreContractReviewer20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			ret := recorder.result.(map[string]interface{})
			convey.So(ret["Reviewer"], convey.ShouldResemble, dbList.GenResp())
		})
	})
	t.Run("case success with reviewer name fill fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PC-001", "WithReviewerName": "true"}, nil)
			dbList := model.PreContractReviewerDBList{{PreContractNo: "PC-001", Reviewer: "a@test.com"}}
			dao := dal.NewPreContractReviewerDao()
			mockey.Mock(mockey.GetMethod(dao, "FindReviewersByNo")).Return(dbList, nil).Build()
			mockey.Mock(salescontract.FillReviewerName).Return(fmt.Errorf("fill fail")).Build()

			h := &innerPreContractHandler{}
			h.GetPreContractReviewer20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerPreContractHandler_withReviewerName(t *testing.T) {
	t.Run("case query missing", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockInnerPreContractGetQuery(map[string]string{}, map[string]bool{"WithReviewerName": false})

			h := &innerPreContractHandler{}
			convey.So(h.withReviewerName(context.Background(), &app.RequestContext{}), convey.ShouldBeFalse)
		})
	})
	t.Run("case query false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockInnerPreContractGetQuery(map[string]string{"WithReviewerName": "false"}, nil)

			h := &innerPreContractHandler{}
			convey.So(h.withReviewerName(context.Background(), &app.RequestContext{}), convey.ShouldBeFalse)
		})
	})
	t.Run("case query true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockInnerPreContractGetQuery(map[string]string{"WithReviewerName": "true"}, nil)

			h := &innerPreContractHandler{}
			convey.So(h.withReviewerName(context.Background(), &app.RequestContext{}), convey.ShouldBeTrue)
		})
	})
}

func Test_innerPreContractHandler_ListSendBackTargetNodes20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.ListSendBackTargetNodes20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrRequestInvalid.WithArgs("query failed")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.ListSendBackTargetNodesReq)
				req.PreContractNo = "PCN-001"
				return nil
			}).Build()
			mockey.Mock((*salescontract.ListSendBackTargetNodesReq).ListSendBackTargetNodes).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.ListSendBackTargetNodes20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &salescontract.ListSendBackTargetNodesResp{Nodes: []*salescontract.SendBackTargetNode{{ContractStatus: 10, NodeName: "节点一"}}}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.ListSendBackTargetNodesReq).ListSendBackTargetNodes).Return(expected, nil).Build()

			h := &innerPreContractHandler{}
			h.ListSendBackTargetNodes20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_GetOperationRecord20210101(t *testing.T) {
	t.Run("case missing pre contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{}, map[string]bool{"PreContractNo": false})

			h := &innerPreContractHandler{}
			h.GetOperationRecord20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("PreContractNo"))
		})
	})
	t.Run("case service fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PCN-001"}, nil)
			opRecordService := cooperationrecord.NewService()
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return(nil, fmt.Errorf("db error")).Build()

			h := &innerPreContractHandler{opRecordService: opRecordService}
			h.GetOperationRecord20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(recorder.result, convey.ShouldBeNil)
		})
	})
	t.Run("case success without reviewer name", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PCN-002", "WithReviewerName": "false"}, nil)
			opRecordService := cooperationrecord.NewService()
			records := []*bizmodels.CooperationRecord{{Operator: "a@b.com"}}
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return(records, nil).Build()

			h := &innerPreContractHandler{opRecordService: opRecordService}
			h.GetOperationRecord20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			ret := recorder.result.(map[string]interface{})
			convey.So(ret["OperationRecord"], convey.ShouldResemble, records)
		})
	})
	t.Run("case success with reviewer name fill fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockInnerPreContractGetQuery(map[string]string{"PreContractNo": "PCN-003", "WithReviewerName": "true"}, nil)
			opRecordService := cooperationrecord.NewService()
			records := []*bizmodels.CooperationRecord{{Operator: "b@b.com"}}
			mockey.Mock(mockey.GetMethod(opRecordService, "ListByContractNo")).Return(records, nil).Build()
			mockey.Mock(salescontract.FillReviewerRecordName).Return(fmt.Errorf("fill name error")).Build()

			h := &innerPreContractHandler{opRecordService: opRecordService}
			h.GetOperationRecord20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerPreContractHandler_CreateOrUpdatePreContract20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case invalid operation", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(salescontract.ValidateEditOperation).Return(false).Build()

			h := &innerPreContractHandler{}
			h.CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("case execute fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrorCommon.WithArgs("execute fail")
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(salescontract.ValidateEditOperation).Return(true).Build()
			mockey.Mock(basicinfo.FixDepartmentWhenSave).Return().Build()
			mockey.Mock((*salescontract.CreateOrUpdateReq).Execute).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.CreateOrUpdatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &salescontract.CreateOrUpdateResp{PreContractNo: "PC-001"}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@test.com")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.CreateOrUpdateReq)
				req.CurrentOperator = "body@test.com"
				return nil
			}).Build()
			mockey.Mock(salescontract.ValidateEditOperation).Return(true).Build()
			mockey.Mock(basicinfo.FixDepartmentWhenSave).Return().Build()
			mockey.Mock((*salescontract.CreateOrUpdateReq).Execute).To(func(req *salescontract.CreateOrUpdateReq, ctx context.Context) (*salescontract.CreateOrUpdateResp, errors.APIError) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "header@test.com")
				return expected, nil
			}).Build()

			h := &innerPreContractHandler{}
			h.CreateOrUpdatePreContract20210101(ctx, &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_OperatePreContract20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.OperatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case invalid operation", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(salescontract.ValidateOperation).Return(false).Build()

			h := &innerPreContractHandler{}
			h.OperatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("case execute fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrorCommon.WithArgs("operate fail")
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(salescontract.ValidateOperation).Return(true).Build()
			mockey.Mock((*salescontract.OperateContractReq).Execute).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.OperatePreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &salescontract.OperateContractResp{}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@test.com")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.OperateContractReq)
				req.CurrentOperator = "body@test.com"
				return nil
			}).Build()
			mockey.Mock(salescontract.ValidateOperation).Return(true).Build()
			mockey.Mock((*salescontract.OperateContractReq).Execute).To(func(req *salescontract.OperateContractReq, ctx context.Context) (*salescontract.OperateContractResp, errors.APIError) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "header@test.com")
				return expected, nil
			}).Build()

			h := &innerPreContractHandler{}
			h.OperatePreContract20210101(ctx, &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_GetPreContract20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.GetPreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case execute fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrorCommon.WithArgs("get fail")
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.GetPreContractReq).Execute).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.GetPreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("case success with employee header", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &bizmodels.PreSalesContract{PreContractNo: "PC-001"}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeFlag, "1")
			ctx = context.WithValue(ctx, _const.CtxEmployeeEmail, "header@test.com")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.GetPreContractReq)
				req.CurrentOperator = "body@test.com"
				return nil
			}).Build()
			mockey.Mock((*salescontract.GetPreContractReq).Execute).To(func(req *salescontract.GetPreContractReq, ctx context.Context) (*bizmodels.PreSalesContract, errors.APIError) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "header@test.com")
				return expected, nil
			}).Build()

			h := &innerPreContractHandler{}
			h.GetPreContract20210101(ctx, &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			ret := recorder.result.(map[string]interface{})
			convey.So(ret["PreSalesContract"], convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_ListPreContract20210101(t *testing.T) {
	t.Run("case bind fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			h := &innerPreContractHandler{}
			h.ListPreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})
	t.Run("case execute fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			serviceErr := errors.ErrorCommon.WithArgs("list fail")
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*salescontract.ListPreContractReq).Execute).Return(nil, serviceErr).Build()

			h := &innerPreContractHandler{}
			h.ListPreContract20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("case success with header operator", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &salescontract.ListPreContractResp{Total: 1, Limit: 10, Offset: 0}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@test.com")
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*salescontract.ListPreContractReq)
				req.CurrentOperator = "body@test.com"
				return nil
			}).Build()
			mockey.Mock((*salescontract.ListPreContractReq).Execute).To(func(req *salescontract.ListPreContractReq, ctx context.Context) (*salescontract.ListPreContractResp, errors.APIError) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "header@test.com")
				return expected, nil
			}).Build()

			h := &innerPreContractHandler{}
			h.ListPreContract20210101(ctx, &app.RequestContext{})

			convey.So(recorder.errorResp, convey.ShouldBeNil)
			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerPreContractHandler_CreateOrUpdatePreContractInner20210101(t *testing.T) {
	t.Run("case forward success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := newInnerPreContractResponseRecorder()
			expected := &salescontract.CreateOrUpdateResp{PreContractNo: "PC-001"}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(salescontract.ValidateEditOperation).Return(true).Build()
			mockey.Mock(basicinfo.FixDepartmentWhenSave).Return().Build()
			mockey.Mock((*salescontract.CreateOrUpdateReq).Execute).Return(expected, nil).Build()

			h := &innerPreContractHandler{}
			h.CreateOrUpdatePreContractInner20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.result, convey.ShouldResemble, expected)
		})
	})
}

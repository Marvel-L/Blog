package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelbusinessmodeclause"
	"volc_contract_process/biz/service/businessmodeclause"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——商务模式条款摘要处理
type innerVCCBusinessModeClauseHandler struct {
	base
	clauseService businessmodeclause.Service
}

func NewInnerVCCBusinessModeClauseHandler() vhertz.ActionHandler {
	return &innerVCCBusinessModeClauseHandler{
		clauseService: businessmodeclause.NewService(),
	}
}

// EditBusinessModeClauses20210101 编辑商务模式条款摘要
func (h *innerVCCBusinessModeClauseHandler) EditBusinessModeClauses20210101(ctx context.Context, c *app.RequestContext) {

	var req modelbusinessmodeclause.EditBusinessModeClausesReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "EditBusinessModeClausesReqBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "EditBusinessModeClausesReqValidateFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if err := h.clauseService.EditBusinessModeClauses(ctx, nil, req.ContractNo, req.BusinessModeClauses, req.CurrentOperator); err != nil {
		if apiErr, ok := err.(vhertz.APIError); ok {
			vhertz.ErrorResp(ctx, c, apiErr)
			return
		}
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

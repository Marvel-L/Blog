package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/service/support/reviewrule"
	"volc_contract_process/pkg/errors"
)

type innerRiviewRuleHandler struct {
	base
	service reviewrule.Service
}

func NewInnerRiviewRuleHandler() vhertz.ActionHandler {
	return &innerRiviewRuleHandler{
		service: reviewrule.NewService(),
	}
}

func (h *innerRiviewRuleHandler) ListReviewRule20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListReviewRuleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListReviewRuleParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}
	resp, err := h.service.ListReviewRule(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) GetReviewRuleDetail20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.GetReviewRuleDetailReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}
	resp, err := h.service.GetReviewRuleDetail(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) CreateOrUpdateReviewRule20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.CreateOrUpdateReviewRuleReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}
	resp, err := h.service.CreateOrUpdateReviewRuleData(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) UpdateReviewRuleStatus20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.UpdateReviewRuleStatusReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
		return
	}
	err := h.service.UpdateReviewRuleStatus(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, nil)
}

func (h *innerRiviewRuleHandler) ListSalesDepartment20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListSalesDepartmentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.ListSalesDepartment(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) ListSalesDepartmentInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.ListSalesDepartmentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.ListSalesDepartmentInfo(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) GetLarkChatInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelreviewrule.GetLarkChatInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateRiskClauseTemplateParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.service.GetLarkChatInfo(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) GetReviewRuleStatusEnums20210101(ctx context.Context, c *app.RequestContext) {
	resp, err := h.service.GetReviewRuleStatusEnums(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) GetReviewerRoleEnums20210101(ctx context.Context, c *app.RequestContext) {

	resp, err := h.service.GetReviewerRoleEnums(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerRiviewRuleHandler) GetAssigneePriorityEnums20210101(ctx context.Context, c *app.RequestContext) {
	resp, err := h.service.GetAssigneePriorityEnums(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// ListReviewRuleInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 ListReviewRule20210101
func (h *innerRiviewRuleHandler) ListReviewRuleInner20210101(ctx context.Context, c *app.RequestContext) {
	h.ListReviewRule20210101(ctx, c)
}

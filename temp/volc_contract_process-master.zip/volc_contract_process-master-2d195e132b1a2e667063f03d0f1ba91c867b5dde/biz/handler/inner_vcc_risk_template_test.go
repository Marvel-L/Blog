package handler

import (
	"context"
	stderrors "errors"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/riskclausetpl"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type fakeRiskClauseTplService struct {
	createFn      func(context.Context, *riskclausetpl.CreateRiskClauseTemplateReq) error
	updateFn      func(context.Context, *riskclausetpl.UpdateRiskClauseTemplateReq) error
	listFn        func(context.Context, *riskclausetpl.ListRiskClauseTemplateReq) (*riskclausetpl.ListRiskClauseTemplateResp, error)
	listHistoryFn func(context.Context, *riskclausetpl.ListRiskClauseTemplateHistoryReq) (*riskclausetpl.ListRiskClauseTemplateResp, error)
	auditFn       func(context.Context, *riskclausetpl.AuditRiskClauseTemplateReq) error
}

func (f *fakeRiskClauseTplService) CreateRiskClauseTemplate(ctx context.Context, req *riskclausetpl.CreateRiskClauseTemplateReq) error {
	if f.createFn != nil {
		return f.createFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseTplService) UpdateRiskClauseTemplate(ctx context.Context, req *riskclausetpl.UpdateRiskClauseTemplateReq) error {
	if f.updateFn != nil {
		return f.updateFn(ctx, req)
	}
	return nil
}

func (f *fakeRiskClauseTplService) List(ctx context.Context, req *riskclausetpl.ListRiskClauseTemplateReq) (*riskclausetpl.ListRiskClauseTemplateResp, error) {
	if f.listFn != nil {
		return f.listFn(ctx, req)
	}
	return nil, nil
}

func (f *fakeRiskClauseTplService) ListHistory(ctx context.Context, req *riskclausetpl.ListRiskClauseTemplateHistoryReq) (*riskclausetpl.ListRiskClauseTemplateResp, error) {
	if f.listHistoryFn != nil {
		return f.listHistoryFn(ctx, req)
	}
	return nil, nil
}

func (f *fakeRiskClauseTplService) AuditRiskClauseTemplate(ctx context.Context, req *riskclausetpl.AuditRiskClauseTemplateReq) error {
	if f.auditFn != nil {
		return f.auditFn(ctx, req)
	}
	return nil
}

type riskClauseTplRespRecorder struct {
	errorCalled bool
	doCalled    bool
	err         vhertz.APIError
	body        interface{}
}

func mockRiskClauseTplResp() *riskClauseTplRespRecorder {
	recorder := &riskClauseTplRespRecorder{}
	mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
		recorder.errorCalled = true
		recorder.err = err
	}).Build()
	mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
		recorder.doCalled = true
		recorder.body = result
	}).Build()
	return recorder
}

func TestNewRiskClauseTplHandler(t *testing.T) {
	mockey.PatchConvey("创建 handler 时应初始化 service", t, func() {
		h := NewRiskClauseTplHandler()
		convey.So(h, convey.ShouldNotBeNil)
	})
}

func TestInnerRiskClauseTplHandlerCreateRiskClauseTemplate20210101(t *testing.T) {
	t.Run("参数绑定失败时返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind fail")).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{}}
			h.CreateRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(recorder.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("校验失败时返回缺参错误且不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.CreateRiskClauseTemplateReq)
				req.RiskClauseType = 1
				return nil
			}).Build()

			called := false
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				createFn: func(ctx context.Context, req *riskclausetpl.CreateRiskClauseTemplateReq) error {
					called = true
					return nil
				},
			}}

			h.CreateRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(called, convey.ShouldBeFalse)
			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("成功时使用上下文操作人覆盖入参并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.CreateRiskClauseTemplateReq)
				req.CurrentOperator = "origin@example.com"
				req.RiskClauseType = 1
				req.Description = "风险条款"
				req.RiskLevel = "P1"
				return nil
			}).Build()

			var capturedOperator string
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				createFn: func(ctx context.Context, req *riskclausetpl.CreateRiskClauseTemplateReq) error {
					capturedOperator = req.CurrentOperator
					return nil
				},
			}}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@example.com")

			h.CreateRiskClauseTemplate20210101(ctx, &app.RequestContext{})

			convey.So(capturedOperator, convey.ShouldEqual, "header@example.com")
			convey.So(recorder.errorCalled, convey.ShouldBeFalse)
			convey.So(recorder.doCalled, convey.ShouldBeTrue)
			convey.So(recorder.body, convey.ShouldBeNil)
		})
	})
}

func TestInnerRiskClauseTplHandlerUpdateRiskClauseTemplate20210101(t *testing.T) {
	t.Run("参数校验失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{}}
			h.UpdateRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(recorder.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("service 返回错误时包装为通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.UpdateRiskClauseTemplateReq)
				req.ID = 10
				req.Description = "更新条款"
				req.RiskLevel = "P2"
				return nil
			}).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				updateFn: func(ctx context.Context, req *riskclausetpl.UpdateRiskClauseTemplateReq) error {
					return stderrors.New("update fail")
				},
			}}

			h.UpdateRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrCommon.GetCode())
			convey.So(recorder.err.GetArgs()[0], convey.ShouldEqual, "update fail")
			convey.So(recorder.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时保留请求操作人并返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.UpdateRiskClauseTemplateReq)
				req.CurrentOperator = "req@example.com"
				req.ID = 10
				req.Description = "更新条款"
				req.RiskLevel = "P2"
				return nil
			}).Build()

			var capturedOperator string
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				updateFn: func(ctx context.Context, req *riskclausetpl.UpdateRiskClauseTemplateReq) error {
					capturedOperator = req.CurrentOperator
					return nil
				},
			}}

			h.UpdateRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedOperator, convey.ShouldEqual, "req@example.com")
			convey.So(recorder.errorCalled, convey.ShouldBeFalse)
			convey.So(recorder.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestInnerRiskClauseTplHandlerAuditRiskClauseTemplate20210101(t *testing.T) {
	t.Run("OperateType 非法时返回校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.AuditRiskClauseTemplateReq)
				req.RiskClauseId = 99
				req.OperateType = 2
				return nil
			}).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{}}
			h.AuditRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("成功时传递模板 ID 和操作类型", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.AuditRiskClauseTemplateReq)
				req.RiskClauseId = 99
				req.OperateType = 1
				return nil
			}).Build()

			var capturedID int
			var capturedOperateType int
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				auditFn: func(ctx context.Context, req *riskclausetpl.AuditRiskClauseTemplateReq) error {
					capturedID = req.RiskClauseId
					capturedOperateType = req.OperateType
					return nil
				},
			}}

			h.AuditRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedID, convey.ShouldEqual, 99)
			convey.So(capturedOperateType, convey.ShouldEqual, 1)
			convey.So(recorder.errorCalled, convey.ShouldBeFalse)
			convey.So(recorder.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestInnerRiskClauseTplHandlerListRiskClauseTemplate20210101(t *testing.T) {
	t.Run("参数绑定失败时返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind fail")).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{}}
			h.ListRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(recorder.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("service 返回错误时包装为通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				listFn: func(ctx context.Context, req *riskclausetpl.ListRiskClauseTemplateReq) (*riskclausetpl.ListRiskClauseTemplateResp, error) {
					return nil, stderrors.New("list fail")
				},
			}}

			h.ListRiskClauseTemplate20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrCommon.GetCode())
			convey.So(recorder.err.GetArgs()[0], convey.ShouldEqual, "list fail")
		})
	})

	t.Run("成功时返回列表响应并覆盖操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.ListRiskClauseTemplateReq)
				req.CurrentOperator = "origin@example.com"
				req.Limit = 20
				req.Offset = 5
				return nil
			}).Build()
			expected := &riskclausetpl.ListRiskClauseTemplateResp{Total: 2, Limit: 20, Offset: 5}
			var capturedOperator string
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				listFn: func(ctx context.Context, req *riskclausetpl.ListRiskClauseTemplateReq) (*riskclausetpl.ListRiskClauseTemplateResp, error) {
					capturedOperator = req.CurrentOperator
					return expected, nil
				},
			}}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@example.com")

			h.ListRiskClauseTemplate20210101(ctx, &app.RequestContext{})

			convey.So(capturedOperator, convey.ShouldEqual, "header@example.com")
			convey.So(recorder.errorCalled, convey.ShouldBeFalse)
			convey.So(recorder.body, convey.ShouldEqual, expected)
		})
	})
}

func TestInnerRiskClauseTplHandlerListRiskClauseTemplateHistory20210101(t *testing.T) {
	t.Run("缺少 ClauseNo 时返回校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{}}
			h.ListRiskClauseTemplateHistory20210101(context.Background(), &app.RequestContext{})

			convey.So(recorder.errorCalled, convey.ShouldBeTrue)
			convey.So(recorder.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(recorder.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时返回历史列表响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			recorder := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*riskclausetpl.ListRiskClauseTemplateHistoryReq)
				req.CurrentOperator = "req@example.com"
				req.ClauseNo = "RC-001"
				return nil
			}).Build()
			expected := &riskclausetpl.ListRiskClauseTemplateResp{Total: 1}
			var capturedClauseNo string
			h := &innerRiskClauseTplHandler{service: &fakeRiskClauseTplService{
				listHistoryFn: func(ctx context.Context, req *riskclausetpl.ListRiskClauseTemplateHistoryReq) (*riskclausetpl.ListRiskClauseTemplateResp, error) {
					capturedClauseNo = req.ClauseNo
					return expected, nil
				},
			}}

			h.ListRiskClauseTemplateHistory20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedClauseNo, convey.ShouldEqual, "RC-001")
			convey.So(recorder.errorCalled, convey.ShouldBeFalse)
			convey.So(recorder.body, convey.ShouldEqual, expected)
		})
	})
}

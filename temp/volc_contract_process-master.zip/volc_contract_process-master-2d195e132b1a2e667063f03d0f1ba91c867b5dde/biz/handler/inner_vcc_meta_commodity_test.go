package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/errors"
)

type fakeInnerMetaCommodityService struct {
	metacommodity.Service
	createOrUpdateFn func(context.Context, modelcommodity.UpdateManageInfoReq) errors.APIError
	listFn           func(context.Context, *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError)
	getManageFn      func(context.Context, *modelcommodity.GetManageReq) (*bizmodels.ManageInfo, errors.APIError)
	exportFn         func(context.Context, *modelcommodity.ListCommodityReq) errors.APIError
}

func (f *fakeInnerMetaCommodityService) CreateOrUpdateManageInfo(ctx context.Context, req modelcommodity.UpdateManageInfoReq) errors.APIError {
	if f.createOrUpdateFn != nil {
		return f.createOrUpdateFn(ctx, req)
	}
	return nil
}

func (f *fakeInnerMetaCommodityService) ListCommodity(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
	if f.listFn != nil {
		return f.listFn(ctx, req)
	}
	return &modelcommodity.CommodityListResp{Total: 1}, nil
}

func (f *fakeInnerMetaCommodityService) GetManageByNo(ctx context.Context, req *modelcommodity.GetManageReq) (*bizmodels.ManageInfo, errors.APIError) {
	if f.getManageFn != nil {
		return f.getManageFn(ctx, req)
	}
	return &bizmodels.ManageInfo{PaymentType: "pay"}, nil
}

func (f *fakeInnerMetaCommodityService) Export(ctx context.Context, req *modelcommodity.ListCommodityReq) errors.APIError {
	if f.exportFn != nil {
		return f.exportFn(ctx, req)
	}
	return nil
}

func (f *fakeInnerMetaCommodityService) ClearQuoteManageInfo(ctx context.Context, tx *gorm.DB, req *modelcommodity.ClearRelateQuoteReq, meta *model.ContractMetaDB) errors.APIError {
	return nil
}

func (f *fakeInnerMetaCommodityService) ValidateExternalCommodity(ctx context.Context, tx *gorm.DB, metaDB *model.ContractMetaDB) errors.APIError {
	return nil
}

func TestNewInnerVCCMetaCommodityHandler(t *testing.T) {
	mockey.PatchConvey("创建 handler 时初始化 service", t, func() {
		convey.So(NewInnerVCCMetaCommodityHandler(), convey.ShouldNotBeNil)
	})
}

func TestInnerVCCMetaCommodityHandlerCreateOrUpdateManageInfo20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			serviceErr := errors.ErrorCommon.WithArgs("svc")

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{createOrUpdateFn: func(ctx context.Context, req modelcommodity.UpdateManageInfoReq) errors.APIError {
				return serviceErr
			}}}).CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功时返回合同号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.UpdateManageInfoReq)
				req.ContractNo = "C-1"
				return nil
			}).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldEqual, "C-1")
		})
	})
}

func TestInnerVCCMetaCommodityHandlerList20210101(t *testing.T) {
	t.Run("校验失败时不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			called := false

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{listFn: func(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
				called = true
				return nil, nil
			}}}).List20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("成功时内部接口默认请求总数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var needTotal bool
			expected := &modelcommodity.CommodityListResp{Total: 2}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelcommodity.ListCommodityReq).ContractNo = "C-1"
				return nil
			}).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{listFn: func(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
				needTotal = req.NeedTotal
				return expected, nil
			}}}).List20210101(context.Background(), &app.RequestContext{})

			convey.So(needTotal, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

func TestInnerVCCMetaCommodityHandlerListCommodity20210101(t *testing.T) {
	mockey.PatchConvey("复用 List", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
			obj.(*modelcommodity.ListCommodityReq).ContractNo = "C-1"
			return nil
		}).Build()

		(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).ListCommodity20210101(context.Background(), &app.RequestContext{})

		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerVCCMetaCommodityHandlerExport20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).Export20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功返回导出成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelcommodity.ListCommodityReq).ContractNo = "C-1"
				return nil
			}).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).Export20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldEqual, "导出成功")
		})
	})
}

func TestInnerVCCMetaCommodityHandlerExportMeta20210101(t *testing.T) {
	mockey.PatchConvey("复用 Export", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
			obj.(*modelcommodity.ListCommodityReq).ContractNo = "C-1"
			return nil
		}).Build()

		(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).ExportMeta20210101(context.Background(), &app.RequestContext{})

		convey.So(rec.body, convey.ShouldEqual, "导出成功")
	})
}

func TestInnerVCCMetaCommodityHandlerGetManageInfo20210101(t *testing.T) {
	t.Run("校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{}}).GetManageInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
		})
	})
	t.Run("成功返回管理信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := &bizmodels.ManageInfo{PaymentType: "pay"}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelcommodity.GetManageReq).ContractNo = "C-1"
				return nil
			}).Build()

			(&innerVCCMetaCommodityHandler{commodityService: &fakeInnerMetaCommodityService{getManageFn: func(ctx context.Context, req *modelcommodity.GetManageReq) (*bizmodels.ManageInfo, errors.APIError) {
				return expected, nil
			}}}).GetManageInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

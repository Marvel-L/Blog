package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/vcp_clients/vclient/jwt_permission"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"code.byted.org/videoarch/cloud_gopkg/quote_client"
	"context"
	conmmonerror "errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/goccy/go-json"
	"github.com/smartystreets/goconvey/convey"
	"net/http"
	"strconv"
	"strings"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelinnertool"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/contractsettlement"
	"volc_contract_process/biz/service/datarefresh"
	"volc_contract_process/biz/service/masterdata"
	"volc_contract_process/biz/service/mqconsumer"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/support/metaattachment"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/biz/service/support/metaext"
	"volc_contract_process/biz/service/support/metasync"
	"volc_contract_process/biz/service/support/metatradeparty"
	"volc_contract_process/cronjob"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/proxy/starlingcli"
)

func Test_innerToolHandler_RefreshTosData20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).RefreshTosData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).RefreshTosData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(conmmonerror.New("bind fail")).Build()

			(&innerToolHandler{}).RefreshTosData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service 返回错误时透传响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			fixDataService := metasync.NewFixDataService()
			serviceErr := conmmonerror.New("refresh tos failed")
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshTosData")).Return(nil, serviceErr).Build()

			(&innerToolHandler{}).RefreshTosData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldEqual, serviceErr)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			fixDataService := metasync.NewFixDataService()
			refreshTosDataMethod := mockey.GetMethod(fixDataService, "RefreshTosData")

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(refreshTosDataMethod).Return(&metasync.RefreshTosDataResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			v.RefreshTosData20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, &metasync.RefreshTosDataResp{})
		})
	})
}

func Test_innerToolHandler_ContractFileMigrate20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattachment.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			var errorResp vhertz.APIError
			var doResponse interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			mockey.Mock(metaattachment.NewService).Return(attachmentService).Build()
			mockContractFileMigrate := mockey.GetMethod(attachmentService, "ContractFileMigrate")
			mockey.Mock(mockContractFileMigrate).Return([]string{"mockContractFileMigrate"}, nil).Build()

			// Act
			v := &innerToolHandler{}
			v.ContractFileMigrate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldBeNil)
			convey.So(doResponse, convey.ShouldResemble, map[string]interface{}{"errMsg": []string{"mockContractFileMigrate"}})
		})
	})
	t.Run("case GetGlobalConf = nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattachment.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			var errorResp vhertz.APIError
			var doResponse interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			mockey.Mock(metaattachment.NewService).Return(attachmentService).Build()
			mockContractFileMigrate := mockey.GetMethod(attachmentService, "ContractFileMigrate")
			mockey.Mock(mockContractFileMigrate).Return([]string{"mockContractFileMigrate"}, nil).Build()

			// Act
			v := &innerToolHandler{}
			v.ContractFileMigrate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldBeNil)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ProductsApp.Auths Contains fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattachment.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("1234561").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			var errorResp vhertz.APIError
			var doResponse interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			mockey.Mock(metaattachment.NewService).Return(attachmentService).Build()
			mockContractFileMigrate := mockey.GetMethod(attachmentService, "ContractFileMigrate")
			mockey.Mock(mockContractFileMigrate).Return([]string{"mockContractFileMigrate"}, nil).Build()

			// Act
			v := &innerToolHandler{}
			v.ContractFileMigrate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldBeNil)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidate fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattachment.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			var errorResp vhertz.APIError
			var doResponse interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()

			mockey.Mock(metaattachment.NewService).Return(attachmentService).Build()
			mockContractFileMigrate := mockey.GetMethod(attachmentService, "ContractFileMigrate")
			mockey.Mock(mockContractFileMigrate).Return([]string{"mockContractFileMigrate"}, nil).Build()

			// Act
			v := &innerToolHandler{}
			v.ContractFileMigrate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
	t.Run("case ContractFileMigrate fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			attachmentService := metaattachment.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			var errorResp vhertz.APIError
			var doResponse interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponse = result
				return // Add your code
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			mockey.Mock(metaattachment.NewService).Return(attachmentService).Build()
			mockContractFileMigrate := mockey.GetMethod(attachmentService, "ContractFileMigrate")
			mockey.Mock(mockContractFileMigrate).Return([]string{"mockContractFileMigrate"}, fmt.Errorf("mockContractFileMigrateFail")).Build()

			// Act
			v := &innerToolHandler{}
			v.ContractFileMigrate20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(errorResp, convey.ShouldResemble, errors.ErrorCommon.WithArgs("mockContractFileMigrateFail"))
			convey.So(doResponse, convey.ShouldBeNil)
		})
	})
}

func Test_innerToolHandler_FixCooperationApproveFileVersion20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			extService := metaext.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metaext.NewService).Return(extService).Build()
			mockFixCooperationApproveFileVersion := mockey.GetMethod(extService, "FixCooperationApproveFileVersion")
			mockey.Mock(mockFixCooperationApproveFileVersion).Return(nil).Build()

			// Act
			v := &innerToolHandler{}
			v.FixCooperationApproveFileVersion20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case GetGlobalConf = nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			extService := metaext.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metaext.NewService).Return(extService).Build()
			mockFixCooperationApproveFileVersion := mockey.GetMethod(extService, "FixCooperationApproveFileVersion")
			mockey.Mock(mockFixCooperationApproveFileVersion).Return(nil).Build()

			// Act
			v := &innerToolHandler{}
			v.FixCooperationApproveFileVersion20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case ProductsApp.Auths Contains fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.FixCooperationApproveFileVersion20210101(context.Background(), c)

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			extService := metaext.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(metaext.NewService).Return(extService).Build()
			mockFixCooperationApproveFileVersion := mockey.GetMethod(extService, "FixCooperationApproveFileVersion")
			mockey.Mock(mockFixCooperationApproveFileVersion).Return(nil).Build()

			// Act
			v := &innerToolHandler{}
			v.FixCooperationApproveFileVersion20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ParamParseFail\",\"Message\":\"参数解析错误\"}}}")
		})
	})
	t.Run("case FixCooperationApproveFileVersionFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			extService := metaext.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123456").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123456",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metaext.NewService).Return(extService).Build()
			mockFixCooperationApproveFileVersion := mockey.GetMethod(extService, "FixCooperationApproveFileVersion")
			mockey.Mock(mockFixCooperationApproveFileVersion).Return(fmt.Errorf("FixCooperationApproveFileVersionFail")).Build()

			// Act
			v := &innerToolHandler{}
			v.FixCooperationApproveFileVersion20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ErrorCommon\",\"Message\":\"FixCooperationApproveFileVersionFail\"}}}")
		})
	})
}

func Test_innerToolHandler_RefreshHistoryBasicInfoTotal20210101(t *testing.T) {
	t.Run("case config nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			c := &app.RequestContext{}
			var resFlag string
			mockey.Mock((*app.RequestContext).Query).Return("xxx").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				resFlag = "configNil"
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// Act
			v := &innerToolHandler{}
			v.RefreshHistoryBasicInfoTotal20210101(context.Background(), c)

			// Assert
			convey.So(resFlag, convey.ShouldEqual, "configNil")
		})
	})
	t.Run("case authFail#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			c := &app.RequestContext{}
			var resFlag string
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock((*app.RequestContext).Query).Return("xxx").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "",
				},
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				resFlag = "authFail"
			}).Build()

			// Act
			v := &innerToolHandler{}
			v.RefreshHistoryBasicInfoTotal20210101(context.Background(), c)

			// Assert
			convey.So(resFlag, convey.ShouldEqual, "authFail")
		})
	})
	t.Run("case bindFail#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			c := &app.RequestContext{}
			var resFlag string
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock((*app.RequestContext).Query).Return("xxx").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "xxx",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("")).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				resFlag = "bindFail"
			}).Build()

			// Act
			v := &innerToolHandler{}
			v.RefreshHistoryBasicInfoTotal20210101(context.Background(), c)

			// Assert
			convey.So(resFlag, convey.ShouldEqual, "bindFail")
		})
	})
	t.Run("case RefreshBasicInfoFail#3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			c := &app.RequestContext{}
			var resFlag string
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock((*app.RequestContext).Query).Return("xxx").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "xxx",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			service := metasync.NewFixDataService()
			mockey.Mock(metasync.NewFixDataService).Return(service).Build()
			methodRefreshBasicInfo := mockey.GetMethod(service, "RefreshBasicInfo")
			mockey.Mock(methodRefreshBasicInfo).Return(nil, fmt.Errorf("")).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				resFlag = "RefreshBasicInfoFail"
			}).Build()

			// Act
			v := &innerToolHandler{}
			v.RefreshHistoryBasicInfoTotal20210101(context.Background(), c)

			// Assert
			convey.So(resFlag, convey.ShouldEqual, "RefreshBasicInfoFail")
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			resp := &metasync.RefreshBasicInfoResp{ErrMsg: "ok", Info: "done", UpdatedCnt: 1}
			var captured interface{}
			service := metasync.NewFixDataService()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(service).Build()
			mockey.Mock(mockey.GetMethod(service, "RefreshBasicInfo")).Return(resp, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				captured = result
			}).Build()

			(&innerToolHandler{}).RefreshHistoryBasicInfoTotal20210101(context.Background(), c)

			convey.So(captured, convey.ShouldResemble, resp)
		})
	})
}

func Test_innerToolHandler_RefreshSealPricingData20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshSealPricingData")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshSealPricingData20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{\"ErrMsg\":\"\",\"BeginID\":0}}")
		})
	})
	t.Run("case GetGlobalConf == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshSealPricingData")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshSealPricingData20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case token error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshSealPricingData20210101(context.Background(), c)

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshSealPricingData")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshSealPricingData20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ParamParseFail\",\"Message\":\"参数解析错误\"}}}")
		})
	})
	t.Run("case RefreshSealPricingDataFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshSealPricingData")).
				Return(&metasync.CommonRefreshResp{}, fmt.Errorf("RefreshSealPricingDataFail")).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshSealPricingData20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{}}")
		})
	})
}

func Test_innerToolHandler_RefreshAccountID20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshAccountID")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshAccountID20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{\"ErrMsg\":\"\",\"BeginID\":0}}")
		})
	})
	t.Run("case GetGlobalConf == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshAccountID")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshAccountID20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case token error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshAccountID20210101(context.Background(), c)

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshAccountID")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshAccountID20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ParamParseFail\",\"Message\":\"参数解析错误\"}}}")
		})
	})
	t.Run("case RefreshSealPricingDataFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshAccountID")).
				Return(&metasync.CommonRefreshResp{}, fmt.Errorf("RefreshSealPricingDataFail")).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshAccountID20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{}}")
		})
	})
}

func Test_innerToolHandler_RefreshCooperationStatusChangeTime20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshCooperationStatusChangeTime")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshCooperationStatusChangeTime20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{\"ErrMsg\":\"\",\"BeginID\":0}}")
		})
	})
	t.Run("case GetGlobalConf == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshCooperationStatusChangeTime")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshCooperationStatusChangeTime20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case token error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshCooperationStatusChangeTime20210101(context.Background(), c)

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshCooperationStatusChangeTime")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshCooperationStatusChangeTime20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ParamParseFail\",\"Message\":\"参数解析错误\"}}}")
		})
	})
	t.Run("case RefreshSealPricingDataFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshCooperationStatusChangeTime")).
				Return(&metasync.CommonRefreshResp{}, fmt.Errorf("RefreshSealPricingDataFail")).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshCooperationStatusChangeTime20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{}}")
		})
	})
}

func Test_innerToolHandler_RefreshRelateQuoteScene20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshRelateQuoteScene")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshRelateQuoteScene20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{\"ErrMsg\":\"\",\"BeginID\":0}}")
		})
	})
	t.Run("case GetGlobalConf == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshRelateQuoteScene")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshRelateQuoteScene20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"}}")
		})
	})
	t.Run("case token error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshRelateQuoteScene20210101(context.Background(), c)

			// Assert
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("BindAndValidateFail")).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshRelateQuoteScene")).
				Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshRelateQuoteScene20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\",\"Error\":{\"Code\":\"ParamParseFail\",\"Message\":\"参数解析错误\"}}}")
		})
	})
	t.Run("case RefreshSealPricingDataFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("123123").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "123123",
				},
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshRelateQuoteScene")).
				Return(&metasync.CommonRefreshResp{}, fmt.Errorf("RefreshRelateQuoteSceneFail")).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshRelateQuoteScene20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "{\"ResponseMetadata\":{\"RequestId\":\"\"},\"Result\":{}}")
		})
	})
}

func Test_innerToolHandler_MultiQuote20210101(t *testing.T) {

	metaService := contractmeta.NewMetaService()
	metaSyncService := metasync.NewFixDataService()
	h := &innerToolHandler{
		base:        base{},
		metaService: metaService,
	}

	mockey.PatchConvey("Test with valid token and successful param binding", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(mockey.GetMethod(metaSyncService, "MultiQuote")).Return(nil).Build()

		h.MultiQuote20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "success")
	})

	mockey.PatchConvey("Test with invalid token", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "invalid_token"}}).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(strings.Contains).Return(false).Build()
		h.MultiQuote20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldEqual, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test with nil global config", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		h.MultiQuote20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldEqual, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test with param binding failure", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("param bind error")).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		h.MultiQuote20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test with MultiQuote failure", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(mockey.GetMethod(metaSyncService, "MultiQuote")).Return(errors.ErrorCommon.WithArgs("multi quote error")).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		h.MultiQuote20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ErrorCommon","Message":"multi quote error"}`)
	})
}

func Test_innerToolHandler_QueryContractByIdentifier20210101(t *testing.T) {

	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		c.Set("Identifier", "test_identifier")
		c.Set("Scene", "1")
		metaService := contractmeta.NewMetaService()
		bizContractDao := dal.NewBizContractDao()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		mockey.Mock(dal.NewBizContractDao).Return(bizContractDao).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h.QueryContractByIdentifier20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test FindByIdentifier failed", t, func() {
		c := &app.RequestContext{}
		c.Set("Identifier", "test_identifier")
		c.Set("Scene", "1")
		metaService := contractmeta.NewMetaService()
		bizContractDao := dal.NewBizContractDao()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		mockey.Mock(dal.NewBizContractDao).Return(bizContractDao).Build()
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(mockey.GetMethod(bizContractDao, "FindByIdentifier")).Return(nil, fmt.Errorf("database error")).Build()
		h.QueryContractByIdentifier20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test contractDB is nil", t, func() {
		c := &app.RequestContext{}
		c.Set("Identifier", "test_identifier")
		c.Set("Scene", "1")
		metaService := contractmeta.NewMetaService()
		bizContractDao := dal.NewBizContractDao()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		mockey.Mock(dal.NewBizContractDao).Return(bizContractDao).Build()
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(mockey.GetMethod(bizContractDao, "FindByIdentifier")).Return(nil, nil).Build()
		h.QueryContractByIdentifier20210101(context.Background(), c)
		expectedResponse := map[string]interface{}{
			"Message":    "Success",
			"ContractNo": "",
		}
		expectedStr, _ := json.Marshal(expectedResponse)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedStr))
	})

	mockey.PatchConvey("Test FindByIdentifier success", t, func() {
		c := &app.RequestContext{}
		c.Set("Identifier", "test_identifier")
		c.Set("Scene", "1")
		metaService := contractmeta.NewMetaService()
		bizContractDao := dal.NewBizContractDao()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		mockey.Mock(dal.NewBizContractDao).Return(bizContractDao).Build()
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		expectedContractDB := &model.BizContractDB{
			ContractNo: "test_contract_no",
		}
		mockey.Mock(mockey.GetMethod(bizContractDao, "FindByIdentifier")).Return(expectedContractDB, nil).Build()
		h.QueryContractByIdentifier20210101(context.Background(), c)
		expectedResponse := map[string]interface{}{
			"Message":    "Success",
			"ContractNo": "test_contract_no",
		}
		expectedStr, _ := json.Marshal(expectedResponse)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedStr))
	})
}

func Test_innerToolHandler_CreateTPMD20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h := &innerToolHandler{}
		h.CreateTPMD20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.MetaCreateReq{
			AccountID:    123,
			CardNo:       "456",
			DocumentType: "789",
			Country:      "CN",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(fmt.Errorf("validation error")).Build()
		h := &innerToolHandler{}
		h.CreateTPMD20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `Unknown internal error: validation error`)
	})

	mockey.PatchConvey("Test GetMdPartyInfo failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.MetaCreateReq{
			AccountID:    123,
			CardNo:       "456",
			DocumentType: "789",
			Country:      "CN",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(masterdata.GetMdPartyInfo).Return(nil, fmt.Errorf("get md party info error")).Build()
		h := &innerToolHandler{}
		h.CreateTPMD20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `get md party info error`)
	})

	mockey.PatchConvey("Test GetMdPartyInfo success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.MetaCreateReq{
			AccountID:    123,
			CardNo:       "456",
			DocumentType: "789",
			Country:      "CN",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		expectedMdPartyInfo := &model.MdPartyInfoDB{
			AccountID:      123,
			IdentityStatus: 1,
			MdmCode:        "mdm123",
			SubjectType:    "subject123",
			CardType:       "card123",
			IdentName:      "name123",
			IdentNo:        "no123",
			Manually:       1,
		}
		mockey.Mock(masterdata.GetMdPartyInfo).Return(expectedMdPartyInfo, nil).Build()
		h := &innerToolHandler{}
		h.CreateTPMD20210101(context.Background(), c)
		expectedBody, _ := json.Marshal(expectedMdPartyInfo)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, string(expectedBody))
	})
}

func Test_innerToolHandler_HttpOAMsg20210101(t *testing.T) {

	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h := &innerToolHandler{}
		h.HttpOAMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock((*bizmodels.ToolHttpMqMsgReq).Validate).Return(fmt.Errorf("validation error")).Build()
		h := &innerToolHandler{}
		h.HttpOAMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test environment is production", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(true).Build()
		mockey.Mock((*bizmodels.ToolHttpMqMsgReq).Validate).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpOAMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerHttpMsg failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpMqMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerHttpMsg).Return(fmt.Errorf("mq error")).Build()
		h := &innerToolHandler{}
		h.HttpOAMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpMqMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerHttpMsg).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpOAMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_HttpFeishuMsg20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h := &innerToolHandler{}
		h.HttpFeishuMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock((*bizmodels.ToolHttpFeishuMqMsgReq).Validate).Return(fmt.Errorf("validation error")).Build()
		h := &innerToolHandler{}
		h.HttpFeishuMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test env check failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(true).Build()
		mockey.Mock((*bizmodels.ToolHttpFeishuMqMsgReq).Validate).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpFeishuMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerFeishuHttpMsg failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpFeishuMqMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerFeishuHttpMsg).Return(fmt.Errorf("mq error")).Build()
		h := &innerToolHandler{}
		h.HttpFeishuMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpFeishuMqMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerFeishuHttpMsg).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpFeishuMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_HttpAccountChangInnerEBMsg20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h := &innerToolHandler{}
		h.HttpAccountChangInnerEBMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock((*bizmodels.ToolHttpAccountChangInnerEBHttpMsgReq).Validate).Return(fmt.Errorf("validation error")).Build()
		h := &innerToolHandler{}
		h.HttpAccountChangInnerEBMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test env check failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(true).Build()
		mockey.Mock((*bizmodels.ToolHttpAccountChangInnerEBHttpMsgReq).Validate).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpAccountChangInnerEBMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerFeishuHttpMsg failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpAccountChangInnerEBHttpMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerAccountChangInnerEBHttpMsg).Return(fmt.Errorf("mq error")).Build()
		h := &innerToolHandler{}
		h.HttpAccountChangInnerEBMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusInternalServerError)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock((*bizmodels.ToolHttpAccountChangInnerEBHttpMsgReq).Validate).Return(nil).Build()
		mockey.Mock(mqconsumer.HandlerAccountChangInnerEBHttpMsg).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpAccountChangInnerEBMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_HttpPerformEventMsg20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		metaService := contractmeta.NewMetaService()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("binding error")).Build()
		h.HttpPerformEventMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test environment is production", t, func() {
		c := &app.RequestContext{}
		metaService := contractmeta.NewMetaService()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(env.IsProduct).Return(true).Build()
		h.HttpPerformEventMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerPerformEventHttpMsg failed", t, func() {
		c := &app.RequestContext{}
		metaService := contractmeta.NewMetaService()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerPerformEventHttpMsg).Return(fmt.Errorf("mq handler error")).Build()
		param := bizmodels.PerformEvent{
			Action:     "test_action",
			BizNO:      "test_bizno",
			ContractNo: "test_contractno",
		}
		body, _ := json.Marshal(param)
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(json.Marshal).Return(body, nil).Build()
		h.HttpPerformEventMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 500)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerPerformEventHttpMsg success", t, func() {
		c := &app.RequestContext{}
		metaService := contractmeta.NewMetaService()
		mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
		h := &innerToolHandler{
			metaService: metaService,
		}
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerPerformEventHttpMsg).Return(nil).Build()
		param := bizmodels.PerformEvent{
			Action:     "test_action",
			BizNO:      "test_bizno",
			ContractNo: "test_contractno",
		}
		body, _ := json.Marshal(param)
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		mockey.Mock(json.Marshal).Return(body, nil).Build()
		h.HttpPerformEventMsg20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_HttpDeferMsg20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate error")).Build()
		h := &innerToolHandler{}
		h.HttpDeferMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpMqDeferMsgReq{}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(fmt.Errorf("param validation error")).Build()
		h := &innerToolHandler{}
		h.HttpDeferMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test env is product", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpMqDeferMsgReq{
			Token:     "123",
			DeferType: "456",
			Body:      "789",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(true).Build()
		h := &innerToolHandler{}
		h.HttpDeferMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerHttpDeferMsg failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpMqDeferMsgReq{
			Token:     "123",
			DeferType: "456",
			Body:      "789",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerHttpDeferMsg).Return(fmt.Errorf("mqconsumer error")).Build()
		h := &innerToolHandler{}
		h.HttpDeferMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpMqDeferMsgReq{
			Token:     "123",
			DeferType: "456",
			Body:      "789",
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerHttpDeferMsg).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpDeferMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_HttpVolcContractEventMsg20210101(t *testing.T) {
	mockey.PatchConvey("Test binding and validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate error")).Build()
		h := &innerToolHandler{}
		h.HttpVolcContractEventMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test param validation failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpVolcContractEventMsgReq{}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(fmt.Errorf("param validation error")).Build()
		h := &innerToolHandler{}
		h.HttpVolcContractEventMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误"}`)
	})

	mockey.PatchConvey("Test env is product", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpVolcContractEventMsgReq{
			Token: "123",
			Body:  `{"ContractNo":"CT123","EventTypes":["ChangeStatus"]}`,
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(true).Build()
		h := &innerToolHandler{}
		h.HttpVolcContractEventMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ParamParseFail","Message":"参数解析错误%!(EXTRA string=env)"}`)
	})

	mockey.PatchConvey("Test mqconsumer.HandlerVolcContractEventHttpMsg failed", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpVolcContractEventMsgReq{
			Token: "123",
			Body:  `{"ContractNo":"CT123","EventTypes":["ChangeStatus"]}`,
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerVolcContractEventHttpMsg).Return(fmt.Errorf("mqconsumer error")).Build()
		h := &innerToolHandler{}
		h.HttpVolcContractEventMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"InternalError","Message":"Unknown internal error: %!v(MISSING)"}`)
	})

	mockey.PatchConvey("Test success", t, func() {
		c := &app.RequestContext{}
		mockey.Mock(binding.BindAndValidate).Return(nil).Build()
		param := bizmodels.ToolHttpVolcContractEventMsgReq{
			Token: "123",
			Body:  `{"ContractNo":"CT123","EventTypes":["ChangeStatus"]}`,
		}
		mockey.Mock(mockey.GetMethod(param, "Validate")).Return(nil).Build()
		mockey.Mock(env.IsProduct).Return(false).Build()
		mockey.Mock(mqconsumer.HandlerVolcContractEventHttpMsg).Return(nil).Build()
		h := &innerToolHandler{}
		h.HttpVolcContractEventMsg20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":0,"Message":"Success"}`)
	})
}

func Test_innerToolHandler_UpdateBizDataByNo20210101(t *testing.T) {
	contractNo := "123456"
	token := _const.MetaToolToken
	wrongToken := "wrong_token"

	mockey.PatchConvey("Test with valid token and contractNo", t, func() {
		metaService := contractmeta.NewMetaService()
		h := &innerToolHandler{
			metaService: metaService,
		}
		c := &app.RequestContext{}
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(mockey.GetMethod(h.metaService, "UpdateBizDataByContractNo")).Return(nil).Build()
		h.UpdateBizDataByNo20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"message":"success"}`)
	})

	mockey.PatchConvey("Test with invalid token", t, func() {
		metaService := contractmeta.NewMetaService()
		h := &innerToolHandler{
			metaService: metaService,
		}
		c := &app.RequestContext{}
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set(_const.HeaderToolToken, wrongToken)
		h.UpdateBizDataByNo20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test with metaService error", t, func() {
		metaService := contractmeta.NewMetaService()
		h := &innerToolHandler{
			metaService: metaService,
		}
		c := &app.RequestContext{}
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(mockey.GetMethod(h.metaService, "UpdateBizDataByContractNo")).Return(errors.ErrorCommon.WithArgs("meta service error")).Build()
		h.UpdateBizDataByNo20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"Code":"ErrorCommon","Message":"meta service error"}`)
	})

	mockey.PatchConvey("Test with missing ContractNo", t, func() {
		metaService := contractmeta.NewMetaService()
		h := &innerToolHandler{
			metaService: metaService,
		}
		c := &app.RequestContext{}
		mockey.Mock(mockey.GetMethod(h.metaService, "UpdateBizDataByContractNo")).Return(errors.ErrMissingParam.WithArgs("ContractNo")).Build()
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		h.UpdateBizDataByNo20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [ContractNo] is missing.`)
	})
}

func Test_innerToolHandler_SyncContractMetaCommodityByVolcContractId20210101(t *testing.T) {
	volcContractId := "123456"
	token := "valid_token"
	commodityService := metacommodity.NewService()

	mockey.PatchConvey("Test with nil config", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set("VolcContractId", volcContractId)
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
		h := &innerToolHandler{}
		h.SyncContractMetaCommodityByVolcContractId20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test with invalid token", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set("VolcContractId", volcContractId)
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
			ProductsApp: conf.ProductsApp{
				Auths: "invalid_1token",
			},
		}).Build()
		mockey.Mock(metacommodity.NewService).Return(commodityService).Build()
		mockey.Mock(mockey.GetMethod(commodityService, "SyncManageInfoById")).Return(nil).Build()
		h := &innerToolHandler{}
		h.SyncContractMetaCommodityByVolcContractId20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test with valid token and successful sync", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set("VolcContractId", volcContractId)
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
			ProductsApp: conf.ProductsApp{
				Auths: "valid_token",
			},
		}).Build()
		mockey.Mock(metacommodity.NewService).Return(commodityService).Build()
		mockey.Mock(mockey.GetMethod(commodityService, "SyncManageInfoById")).Return(nil).Build()
		h := &innerToolHandler{}
		h.SyncContractMetaCommodityByVolcContractId20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""},"Result":{"LastID":null}}`)
	})
}

func Test_innerToolHandler_BindQuoteContract20210101(t *testing.T) {
	contractNo, quoteNo := "12345", "67890"
	token := "valid_token"

	metaService := contractmeta.NewMetaService()
	metaDao := dal.NewContractMetaDao()
	mockey.Mock(contractmeta.NewMetaService).Return(metaService).Build()
	mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
	h := &innerToolHandler{
		metaService: metaService,
	}
	mockey.PatchConvey("Test GetGlobalConf is nil", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

		h.BindQuoteContract20210101(context.Background(), c)

		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test invalid token", t, func() {
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, token)
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "invalid1_token"}}).Build()
		h.BindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})

	mockey.PatchConvey("Test valid token", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()

		mockey.PatchConvey("Test missing ContractNo", func() {
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, token)
			h.BindQuoteContract20210101(context.Background(), c)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [ContractNo] is missing.`)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test missing QuoteNo", func() {
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, token)
			c.QueryArgs().Set("ContractNo", contractNo)
			h.BindQuoteContract20210101(context.Background(), c)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [QuoteNo] is missing.`)
			convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
		})

		mockey.PatchConvey("Test valid ContractNo and QuoteNo", func() {
			mockey.PatchConvey("Test FindByNo error", func() {
				c := &app.RequestContext{}
				c.QueryArgs().Set(_const.HeaderToolToken, token)
				c.QueryArgs().Set("ContractNo", contractNo)
				c.QueryArgs().Set("QuoteNo", quoteNo)
				mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, fmt.Errorf("database error")).Build()
				h.BindQuoteContract20210101(context.Background(), c)
				convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [database error] is missing.`)
				convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			})

			mockey.PatchConvey("Test meta not found", func() {
				c := &app.RequestContext{}
				c.QueryArgs().Set(_const.HeaderToolToken, token)
				c.QueryArgs().Set("ContractNo", contractNo)
				c.QueryArgs().Set("QuoteNo", quoteNo)
				mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, nil).Build()
				h.BindQuoteContract20210101(context.Background(), c)
				convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [合同不存在] is missing.`)
				convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			})

			mockey.PatchConvey("Test BindQuoteContract success", func() {
				c := &app.RequestContext{}
				c.QueryArgs().Set(_const.HeaderToolToken, token)
				c.QueryArgs().Set("ContractNo", contractNo)
				c.QueryArgs().Set("QuoteNo", quoteNo)
				mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{}, nil).Build()
				mockey.Mock(quotecli.BindQuoteContract).Return(&quote_client.QuoteContract{}, nil).Build()
				h.BindQuoteContract20210101(context.Background(), c)
				convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ContractCode":"","ContractStatus":"","QuoteID":0},"Success":true}`)
				convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusOK)
			})

			mockey.PatchConvey("Test BindQuoteContract fail", func() {
				c := &app.RequestContext{}
				c.QueryArgs().Set(_const.HeaderToolToken, token)
				c.QueryArgs().Set("ContractNo", contractNo)
				c.QueryArgs().Set("QuoteNo", quoteNo)
				mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{}, nil).Build()
				mockey.Mock(quotecli.BindQuoteContract).Return(nil, fmt.Errorf("bind error")).Build()
				h.BindQuoteContract20210101(context.Background(), c)
				convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [BindQuoteContractFail] is missing.`)
				convey.So(c.Response.StatusCode(), convey.ShouldEqual, http.StatusBadRequest)
			})
		})
	})
}

func Test_innerToolHandler_UnbindQuoteContract20210101(t *testing.T) {
	contractNo, quoteNo := "123456", "789012"
	mockey.PatchConvey("Test GetGlobalConf is nil", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
		c := &app.RequestContext{}
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})
	mockey.PatchConvey("Test Token Invalid", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "invalid_token")
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
	})
	mockey.PatchConvey("Test Missing ContractNo", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [ContractNo] is missing.`)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
	})
	mockey.PatchConvey("Test Missing QuoteNo", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		c.QueryArgs().Set("ContractNo", contractNo)
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [QuoteNo] is missing.`)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
	})
	mockey.PatchConvey("Test FindByNo Failed", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, fmt.Errorf("find by no failed")).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set("QuoteNo", quoteNo)
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [find by no failed] is missing.`)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
	})
	mockey.PatchConvey("Test FindByNo Not Found", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(nil, nil).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set("QuoteNo", quoteNo)
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [合同不存在] is missing.`)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
	})
	mockey.PatchConvey("Test UnbindQuoteContract Failed", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{}, nil).Build()
		mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, fmt.Errorf("unbind quote contract failed")).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set("QuoteNo", quoteNo)
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [UnbindQuoteContractFail] is missing.`)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 400)
	})
	mockey.PatchConvey("Test UnbindQuoteContract Success", t, func() {
		metaDao := dal.NewContractMetaDao()
		mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid_token"}}).Build()
		mockey.Mock(mockey.GetMethod(metaDao, "FindByNo")).Return(&model.ContractMetaDB{}, nil).Build()
		mockey.Mock(quotecli.UnbindQuoteContract).Return(&quote_client.QuoteContract{}, nil).Build()
		c := &app.RequestContext{}
		c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
		c.QueryArgs().Set("ContractNo", contractNo)
		c.QueryArgs().Set("QuoteNo", quoteNo)
		h := &innerToolHandler{}
		h.UnbindQuoteContract20210101(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Success":true`)
	})
}

func Test_innerToolHandler_Archived20210101(t *testing.T) {
	t.Run("token 校验失败时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(false).Build()

			(&innerToolHandler{}).Archived20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("缺少 ContractNo 时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).Archived20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("缺少 FileTime 时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-001")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).Archived20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"FileTime"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("FileTime 格式错误时返回 NotFound 错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-001")
			c.QueryArgs().Set("FileTime", "bad-time")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).Archived20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrNotFound.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"格式化归档时间失败"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("归档 service 返回错误时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			metaService := contractmeta.NewMetaService()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-001")
			c.QueryArgs().Set("FileTime", "2024-01-02 03:04:05")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(mockey.GetMethod(metaService, "ArchivedContract")).Return(fmt.Errorf("archive failed")).Build()

			(&innerToolHandler{metaService: metaService}).Archived20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"archive failed"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("归档成功时透传合同号和归档时间", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			metaService := contractmeta.NewMetaService()
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-001")
			c.QueryArgs().Set("FileTime", "2024-01-02 03:04:05")
			expectedFileTime, _ := time.ParseInLocation(model.DBDateFormatTpl, "2024-01-02 03:04:05", time.Local)
			var capturedContractNo string
			var capturedFileTime time.Time
			mockey.Mock(mockey.GetMethod(metaService, "ArchivedContract")).To(func(ctx context.Context, contractNo string, fileTime time.Time) error {
				capturedContractNo = contractNo
				capturedFileTime = fileTime
				return nil
			}).Build()

			ctx := context.WithValue(context.Background(), _const.CtxLogID, "log-archived")
			(&innerToolHandler{metaService: metaService}).Archived20210101(ctx, c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(capturedContractNo, convey.ShouldEqual, "CN-001")
			convey.So(capturedFileTime.Equal(expectedFileTime), convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"logId": "log-archived"})
		})
	})
}

func Test_innerToolHandler_OAArchived20210101(t *testing.T) {
	t.Run("token 校验失败时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(false).Build()

			(&innerToolHandler{}).OAArchived20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("缺少 ContractNo 时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).OAArchived20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("ContractNo 为空时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).OAArchived20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("OA 归档 service 返回错误时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			salesContractService := salescontract.NewSalesContractService()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-OA-001")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(salescontract.NewSalesContractService).Return(salesContractService).Build()
			mockey.Mock(mockey.GetMethod(salesContractService, "ContractArchived")).Return(errors.ErrInternalError.WithArgs("oa failed")).Build()

			(&innerToolHandler{}).OAArchived20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{errors.ErrInternalError.WithArgs("oa failed").Error()})
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("OA 归档成功时写入 mock 上下文并返回 logId", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			salesContractService := salescontract.NewSalesContractService()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-OA-002")
			var capturedContractNo string
			var capturedUseMock interface{}
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(salescontract.NewSalesContractService).Return(salesContractService).Build()
			mockey.Mock(mockey.GetMethod(salesContractService, "ContractArchived")).To(func(ctx context.Context, contractNo string) errors.APIError {
				capturedContractNo = contractNo
				capturedUseMock = ctx.Value(_const.CtxVCPUseMock)
				return nil
			}).Build()

			ctx := context.WithValue(context.Background(), _const.CtxLogID, "log-oa")
			(&innerToolHandler{}).OAArchived20210101(ctx, c)

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(capturedContractNo, convey.ShouldEqual, "CN-OA-002")
			convey.So(capturedUseMock, convey.ShouldEqual, "true")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"logId": "log-oa"})
		})
	})
}

func Test_innerToolHandler_OASigned20210101(t *testing.T) {
	t.Run("token 校验失败时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(false).Build()

			(&innerToolHandler{}).OASigned20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
			convey.So(rec.errorCalled, convey.ShouldBeFalse)
		})
	})
	t.Run("缺少 ContractNo 时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).OASigned20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("ContractNo 为空时返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()

			(&innerToolHandler{}).OASigned20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.err.GetArgs(), convey.ShouldResemble, []interface{}{"ContractNo"})
		})
	})
	t.Run("签署 service 返回错误时返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			salesContractService := salescontract.NewSalesContractService()
			c := &app.RequestContext{}
			c.QueryArgs().Set("ContractNo", "CN-SIGN-001")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(salescontract.NewSalesContractService).Return(salesContractService).Build()
			mockey.Mock(mockey.GetMethod(salesContractService, "ContractSigned")).Return(errors.ErrInternalError.WithArgs("signed failed")).Build()

			(&innerToolHandler{}).OASigned20210101(context.Background(), c)

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			salesContractService := salescontract.NewSalesContractService()
			// Arrange
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock((*app.RequestContext).GetQuery).To(func(key string) (string, bool) { return "CN-SIGN-002", true }).Build()
			mockey.Mock(salescontract.NewSalesContractService).Return(salesContractService).Build()
			mockey.Mock(mockey.GetMethod(salesContractService, "ContractSigned")).Return(nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.OASigned20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"logId": nil})
		})
	})
}

func Test_innerToolHandler_FixProductDeploymentType20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).FixProductDeploymentType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).FixProductDeploymentType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("offset 非法时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "1"
				case "Offset":
					return "0"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).FixProductDeploymentType20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			metasyncService := metasync.NewService()
			// Arrange
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "20"
				}
				return ""
			}).Build()
			mockey.Mock(metasync.NewService).Return(metasyncService).Build()
			mockey.Mock(mockey.GetMethod(metasyncService, "FixProductDeploymentType")).Return(int64(88)).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.FixProductDeploymentType20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"LastID": int64(88)})
		})
	})
}

func Test_innerToolHandler_FixMetaProductByCommodity20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).FixMetaProductByCommodity20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("bad-token").Build()

			(&innerToolHandler{}).FixMetaProductByCommodity20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("offset 非法时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "1"
				case "Offset":
					return "0"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).FixMetaProductByCommodity20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			fixCommodityService := metacommodity.NewFixDataService()
			// Arrange
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "20"
				}
				return ""
			}).Build()
			mockey.Mock(metacommodity.NewFixDataService).Return(fixCommodityService).Build()
			mockey.Mock(mockey.GetMethod(fixCommodityService, "FixMetaProductByCommodity")).Return(int64(88)).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.FixMetaProductByCommodity20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"LastID": int64(88)})
		})
	})
}

func Test_innerToolHandler_ChangeProcessFeishuToOA20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).ChangeProcessFeishuToOA20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).ChangeProcessFeishuToOA20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("合同列表为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				if key == _const.HeaderToolToken {
					return "valid-token"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).ChangeProcessFeishuToOA20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("service 错误时聚合返回内部错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			metasyncService := metasync.NewService()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "ContractNoList":
					return "C-1,C-2"
				}
				return ""
			}).Build()
			mockey.Mock(metasync.NewService).Return(metasyncService).Build()
			mockey.Mock(mockey.GetMethod(metasyncService, "ChangeProcessFeishuToOA")).Return(errors.ErrorCommon.WithArgs("change failed")).Build()

			(&innerToolHandler{}).ChangeProcessFeishuToOA20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			metasyncService := metasync.NewService()
			// Arrange
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "ContractNoList":
					return "C-1,C-2"
				}
				return ""
			}).Build()
			mockey.Mock(mockey.GetMethod(metasyncService, "ChangeProcessFeishuToOA")).Return(nil).Build()
			mockey.Mock(metasync.NewService).Return(metasyncService).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.ChangeProcessFeishuToOA20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldEqual, "success")
		})
	})
}

func Test_innerToolHandler_FixContractSettlementLine20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).FixContractSettlementLine20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).FixContractSettlementLine20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("ContractNo 为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				if key == _const.HeaderToolToken {
					return "valid-token"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).FixContractSettlementLine20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			settlementService := contractsettlement.NewSettlementService()
			serviceErr := conmmonerror.New("settlement failed")
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "ContractNo":
					return "C-1"
				}
				return ""
			}).Build()
			mockey.Mock(contractsettlement.NewSettlementService).Return(settlementService).Build()
			mockey.Mock(mockey.GetMethod(settlementService, "FixContractSettlementLine")).Return(serviceErr).Build()

			(&innerToolHandler{}).FixContractSettlementLine20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldEqual, serviceErr)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			settlementService := contractsettlement.NewSettlementService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "ContractNo":
					return "C-1"
				}
				return ""
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(mockey.GetMethod(settlementService, "FixContractSettlementLine")).Return(nil).Build()
			mockey.Mock(contractsettlement.NewSettlementService).Return(settlementService).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.FixContractSettlementLine20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldEqual, "success")
		})
	})
}

func Test_innerToolHandler_QueryEventRules20210101(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(conf.GetEventRules).Return(map[string][]*conf.RuleInfo{"": {{}}}).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.QueryEventRules20210101(context.Background(), c)

			// Assert
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"":[{"MatchResultType":"","Details":null}]}`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_innerToolHandler_FixTradePartyInfo20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).FixTradePartyInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).FixTradePartyInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("offset 非法时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "1"
				case "Offset":
					return "0"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).FixTradePartyInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			tradePartyService := metatradeparty.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "20"
				}
				return ""
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"},
			}).Build()
			mockey.Mock(metatradeparty.NewService).Return(tradePartyService).Build()
			mockey.Mock(mockey.GetMethod(tradePartyService, "FixTradePartyInfo")).Return(int64(88)).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.FixTradePartyInfo20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"LastID": int64(88)})
		})
	})
}

func Test_innerToolHandler_RefreshHistoryProjectInfo20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).RefreshHistoryProjectInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).RefreshHistoryProjectInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(conmmonerror.New("bind fail")).Build()

			(&innerToolHandler{}).RefreshHistoryProjectInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service 返回错误时透传响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			fixDataService := metasync.NewFixDataService()
			serviceErr := conmmonerror.New("project failed")
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshProjectInfo")).Return(nil, serviceErr).Build()

			(&innerToolHandler{}).RefreshHistoryProjectInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldEqual, serviceErr)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			fixDataService := metasync.NewFixDataService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(metasync.NewFixDataService).Return(fixDataService).Build()
			mockey.Mock(mockey.GetMethod(fixDataService, "RefreshProjectInfo")).Return(&metasync.CommonRefreshResp{}, nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.RefreshHistoryProjectInfo20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, &metasync.CommonRefreshResp{})
		})
	})
}

func Test_innerToolHandler_MigrateOpportunityData20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).MigrateOpportunityData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).MigrateOpportunityData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("offset 非法时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "1"
				case "Offset":
					return "0"
				}
				return ""
			}).Build()

			(&innerToolHandler{}).MigrateOpportunityData20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			tradePartyService := metatradeparty.NewService()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "20"
				}
				return ""
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(mockey.GetMethod(tradePartyService, "MigrateOpportunityData")).Return(int64(88)).Build()
			mockey.Mock(metatradeparty.NewService).Return(tradePartyService).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.MigrateOpportunityData20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"LastID": int64(88)})
		})
	})
}

func Test_innerToolHandler_GenJwtToken20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).GenJwtToken20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 无效时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()

			(&innerToolHandler{}).GenJwtToken20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			// Arrange
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "AppID":
					return "app-id"
				case "Secret":
					return "secret"
				}
				return ""
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(jwt_permission.NewClient).Return(&jwt_permission.Client{}, nil).Build()
			mockey.Mock((*jwt_permission.Client).GenerateToken).Return("GenerateToken", nil).Build()

			// Act
			v := &innerToolHandler{}
			c := &app.RequestContext{}
			v.GenJwtToken20210101(context.Background(), c)

			// Assert
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"Token": "GenerateToken"})
		})
	})
}

func Test_innerToolHandler_Cronjob20210101(t *testing.T) {
	h := &innerToolHandler{}

	mockey.PatchConvey("Test_innerToolHandler_Cronjob20210101", t, func() {
		// 为此块中的所有测试用例提供通用模拟。
		mockey.Mock(logs.CtxError).Return().Build()

		mockey.PatchConvey("成功: CronjobKey为PullUnarchivedContract", func() {
			// 场景描述:
			// 构造数据: 提供有效的token、CronjobKey="PullUnarchivedContract"以及一个有效的Days参数。
			// 逻辑链路:
			// 1. 成功获取全局配置。
			// 2. Token验证通过。
			// 3. Days参数解析成功。
			// 4. switch case匹配到"PullUnarchivedContract"。
			// 5. 调用cronjob.PullUnarchivedContract。
			// 6. 最终调用vhertz.DoResponse(c, nil)成功返回。
			c := &app.RequestContext{}
			var pullCalled bool
			var responseCalled bool

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "CronjobKey":
					return "PullUnarchivedContract"
				case "Days":
					return "30" // 必须是有效的整数
				}
				return ""
			}).Build()
			mockey.Mock(cronjob.PullUnarchivedContract).To(func(scene int) {
				pullCalled = true
				convey.So(scene, convey.ShouldEqual, _const.BizSceneSalesContract)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(pullCalled, convey.ShouldBeTrue)
			convey.So(responseCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("成功: CronjobKey为ContractExpiredBeforeDays", func() {
			// 场景描述:
			// 构造数据: 提供有效的token、CronjobKey="ContractExpiredBeforeDays"以及Days="30"。
			// 逻辑链路:
			// 1. 成功获取全局配置。
			// 2. Token验证通过。
			// 3. Days参数解析为30。
			// 4. switch case匹配到"ContractExpiredBeforeDays"。
			// 5. 调用cronjob.ContractExpiredBeforeDays并传入30。
			// 6. 最终调用vhertz.DoResponse(c, nil)成功返回。
			c := &app.RequestContext{}
			var expiredCalled bool
			var responseCalled bool
			daysToTest := 30

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "CronjobKey":
					return "ContractExpiredBeforeDays"
				case "Days":
					return strconv.Itoa(daysToTest)
				}
				return ""
			}).Build()
			mockey.Mock(cronjob.ContractExpiredBeforeDays).To(func(days int) {
				expiredCalled = true
				convey.So(days, convey.ShouldEqual, daysToTest)
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(expiredCalled, convey.ShouldBeTrue)
			convey.So(responseCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("失败: GetGlobalConf返回nil", func() {
			// 场景描述:
			// 构造数据: 无。
			// 逻辑链路:
			// 1. conf.GetGlobalConf返回nil。
			// 2. 函数提前返回，并调用vhertz.DoResponse(c, nil)。
			c := &app.RequestContext{}
			var responseCalled bool

			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock((*app.RequestContext).Query).Return("any_token").Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(responseCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("失败: 无效的token", func() {
			// 场景描述:
			// 构造数据: 提供一个无效的token。
			// 逻辑链路:
			// 1. 成功获取全局配置。
			// 2. Token验证失败，因为提供的token不在配置的Auths列表中。
			// 3. 函数提前返回，并调用vhertz.DoResponse(c, nil)。
			c := &app.RequestContext{}
			var responseCalled bool

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token_only",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				if key == _const.HeaderToolToken {
					return "invalid_token"
				}
				return "any_value"
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(responseCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("失败: Days参数不是有效的整数", func() {
			// 场景描述:
			// 构造数据: Days参数为非数字字符串 "abc"。
			// 逻辑链路:
			// 1. Token验证通过。
			// 2. 尝试将 "abc" 解析为int64时失败。
			// 3. 函数调用vhertz.ErrorResp返回参数解析错误。
			c := &app.RequestContext{}
			var capturedError errors.APIError

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "CronjobKey":
					return "ContractExpiredBeforeDays"
				case "Days":
					return "abc" // 无效整数
				}
				return ""
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})

		mockey.PatchConvey("静默成功: 未知的CronjobKey不触发任何cronjob但成功响应", func() {
			// 场景描述:
			// 构造数据: 提供一个未在switch case中定义的CronjobKey。
			// 逻辑链路:
			// 1. 所有前置检查均通过。
			// 2. switch case中没有匹配的项，不执行任何cronjob调用。
			// 3. 函数继续执行并调用vhertz.DoResponse(c, nil)。
			c := &app.RequestContext{}
			var pullCalled, expiredCalled, responseCalled bool

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "CronjobKey":
					return "UnknownKey"
				case "Days":
					return "10"
				}
				return ""
			}).Build()
			mockey.Mock(cronjob.PullUnarchivedContract).To(func(scene int) {
				pullCalled = true
			}).Build()
			mockey.Mock(cronjob.ContractExpiredBeforeDays).To(func(days int) {
				expiredCalled = true
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			// 调用目标函数。
			h.Cronjob20210101(context.Background(), c)

			// 断言。
			convey.So(pullCalled, convey.ShouldBeFalse)
			convey.So(expiredCalled, convey.ShouldBeFalse)
			convey.So(responseCalled, convey.ShouldBeTrue)
		})
	})
}

func Test_innerToolHandler_UpdateContractTextByContractNo20210101(t *testing.T) {
	dataRefreshService := datarefresh.NewDataRefreshService()
	h := &innerToolHandler{}
	c := &app.RequestContext{}
	UpdateContractTextMethod := mockey.GetMethod(dataRefreshService, "UpdateContractText")

	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("Success: all contracts updated successfully", t, func() {
			// 场景描述：
			// 模拟一个包含两个合同号的请求，所有合同文本都成功更新。
			// 构造数据：
			// - contractNoList 查询参数为 "C001,C002"
			// 逻辑链路：
			// 1. Mock c.Query("contractNoList") 返回 "C001,C002"。
			// 2. Mock datarefresh.NewDataRefreshService 以返回一个 mock service 实例。
			// 3. Mock UpdateContractText 方法，使其对 "C001" 和 "C002" 都返回 nil（表示成功）。
			// 4. 函数将遍历所有合同号，由于全部成功，最终会调用 vhertz.DoResponse 返回成功消息。
			// 5. 断言 vhertz.DoResponse 被调用，且响应内容为成功消息。

			mockey.Mock((*app.RequestContext).Query).Return("C001,C002").Build()
			mockey.Mock(UpdateContractTextMethod).Return(nil).Build()

			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h.UpdateContractTextByContractNo20210101(context.Background(), c)

			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{
				"message": "所有合同文本更新成功",
			})
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("Partial Failure: some contracts fail to update", t, func() {
			// 场景描述：
			// 模拟一个包含三个合同号的请求，其中部分合同文本更新失败。
			// 构造数据：
			// - contractNoList 查询参数为 "C001,C002,C003"
			// - 更新 "C001" 成功，更新 "C002", "C003" 失败。
			// 逻辑链路：
			// 1. Mock c.Query("contractNoList") 返回 "C001,C002,C003"。
			// 2. Mock datarefresh.NewDataRefreshService 以返回一个 mock service 实例。
			// 3. Mock UpdateContractText 方法，使其对 "C001" 返回 nil，对 "C002" 和 "C003" 返回一个错误。
			// 4. 函数将遍历所有合同号，并将失败的合同号 "C002", "C003" 添加到 failedContracts 列表。
			// 5. 循环结束后，由于 failedContracts 不为空，将调用 vhertz.DoResponse 返回包含失败信息的错误。
			// 6. 断言 vhertz.DoResponse 被调用，且响应的错误码和参数符合预期。
			mockErr := conmmonerror.New("update failed")
			mockey.Mock((*app.RequestContext).Query).Return("C001,C002,C003").Build()
			mockey.Mock(UpdateContractTextMethod).
				When(func(ctx context.Context, contractNo string) bool {
					return contractNo == "C001"
				}).Return(nil).
				When(func(ctx context.Context, contractNo string) bool {
					return contractNo == "C002" || contractNo == "C003"
				}).Return(mockErr).Build()

			mockey.Mock(larkc.Warning).Build()

			h.UpdateContractTextByContractNo20210101(context.Background(), c)

		})

	})

	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("Total Failure: all contracts fail to update", t, func() {
			// 场景描述：
			// 模拟一个包含两个合同号的请求，所有合同文本更新都失败。
			// 构造数据：
			// - contractNoList 查询参数为 "C001,C002"。
			// - 更新 "C001", "C002" 均失败。
			// 逻辑链路：
			// 1. Mock c.Query("contractNoList") 返回 "C001,C002"。
			// 2. Mock datarefresh.NewDataRefreshService 以返回一个 mock service 实例。
			// 3. Mock UpdateContractText 方法，使其对所有调用都返回一个错误。
			// 4. 函数将遍历所有合同号，并将 "C001", "C002" 添加到 failedContracts 列表。
			// 5. 循环结束后，由于 failedContracts 不为空，将调用 vhertz.DoResponse 返回包含所有失败合同号的错误。
			// 6. 断言 vhertz.DoResponse 被调用，且响应的错误码和参数符合预期。

			mockErr := conmmonerror.New("update failed")
			mockey.Mock((*app.RequestContext).Query).Return("C001,C002").Build()
			mockey.Mock(UpdateContractTextMethod).Return(mockErr).Build()

			mockey.Mock(larkc.Warning).Build()

			h.UpdateContractTextByContractNo20210101(context.Background(), c)

		})
	})

	t.Run("case #4", func(t *testing.T) {
		mockey.PatchConvey("Failure: missing contractNoList query parameter", t, func() {
			// 场景描述：
			// 模拟一个缺少 contractNoList 查询参数的请求。
			// 构造数据：
			// - contractNoList 查询参数为空字符串。
			// 逻辑链路：
			// 1. Mock c.Query("contractNoList") 返回 ""。
			// 2. 函数在检查参数时发现 contractNoList 为空，直接调用 vhertz.ErrorResp 返回参数缺失错误。
			// 3. 断言 vhertz.ErrorResp 被调用，且响应的错误码和参数符合预期。
			mockey.Mock((*app.RequestContext).Query).Return("").Build()

			var capturedError errors.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.UpdateContractTextByContractNo20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(capturedError.GetArgs(), convey.ShouldResemble, []interface{}{"invalid contractNoList"})
		})
	})
}

func Test_innerToolHandler_RefreshQuoteItems20210101(t *testing.T) {
	h := &innerToolHandler{}
	c := &app.RequestContext{}

	refreshService := datarefresh.NewDataRefreshService()
	RefreshQuoteItemsFromQuoteIDMethod := mockey.GetMethod(refreshService, "RefreshQuoteItemsFromQuoteID")

	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("Success: all quote items refreshed", t, func() {
			contractNoList := "contract1,contract2"
			forceRefresh := "false"

			mockey.Mock(mockey.GetMethod(c, "Query")).To(func(c *app.RequestContext, key string) string {
				switch key {
				case "contractNoList":
					return contractNoList
				case "forceRefresh":
					return forceRefresh
				default:
					return ""
				}
			}).Build()

			mockey.Mock(RefreshQuoteItemsFromQuoteIDMethod).Return(nil).Build()

			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h.RefreshQuoteItems20210101(context.Background(), c)

			convey.So(capturedResult, convey.ShouldResemble, map[string]interface{}{
				"message": "success",
			})
		})
	})

	t.Run("case #2", func(t *testing.T) {
		mockey.PatchConvey("Success: all quote items refreshed", t, func() {
			contractNoList := ""
			forceRefresh := "false"

			mockey.Mock(mockey.GetMethod(c, "Query")).To(func(c *app.RequestContext, key string) string {
				switch key {
				case "contractNoList":
					return contractNoList
				case "forceRefresh":
					return forceRefresh
				default:
					return ""
				}
			}).Build()

			mockey.Mock(RefreshQuoteItemsFromQuoteIDMethod).Return(nil).Build()

			var capturedError errors.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.RefreshQuoteItems20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(capturedError.GetArgs(), convey.ShouldResemble, []interface{}{"invalid contractNoList"})

		})
	})

	t.Run("case #3", func(t *testing.T) {
		mockey.PatchConvey("RefreshQuoteItemsFromQuoteID err", t, func() {
			contractNoList := "contract1,contract2"
			forceRefresh := "false"
			mockErr := conmmonerror.New("update failed")

			mockey.Mock(mockey.GetMethod(c, "Query")).To(func(c *app.RequestContext, key string) string {
				switch key {
				case "contractNoList":
					return contractNoList
				case "forceRefresh":
					return forceRefresh
				default:
					return ""
				}
			}).Build()

			mockey.Mock(RefreshQuoteItemsFromQuoteIDMethod).Return(mockErr).Build()

			mockey.Mock(larkc.Warning).Build()

			h.RefreshQuoteItems20210101(context.Background(), c)

		})
	})

}

type Mock_DataRefreshService_EncryptMdPartyInfoDB20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_EncryptMdPartyInfoDB20210101(t *testing.T) {
	t.Run("Successful Scenario - Data encryption completes successfully", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - Data encryption completes successfully", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_EncryptMdPartyInfoDB20210101{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("1").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()

			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptMdPartyInfoDB20210101).EncryptMdPartyInfoDB).Return(nil).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.EncryptMdPartyInfoDB20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Invalid startID parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid startID parameter", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.EncryptMdPartyInfoDB20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Invalid batchSize parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid batchSize parameter", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("1").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.EncryptMdPartyInfoDB20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Data encryption service fails", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Data encryption service fails", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_EncryptMdPartyInfoDB20210101{}
			serviceErr := conmmonerror.New("database connection failed")

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("1").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()

			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptMdPartyInfoDB20210101).EncryptMdPartyInfoDB).Return(serviceErr).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceErr.Error()))
			}).Build()

			h.EncryptMdPartyInfoDB20210101(context.Background(), c)
		})
	})
}

type Mock_DataRefreshService_CheckMdPartyInfoDBConsistency20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_CheckMdPartyInfoDBConsistency20210101(t *testing.T) {
	h := &innerToolHandler{}
	c := &app.RequestContext{}

	t.Run("Success Scenario", func(t *testing.T) {
		mockey.PatchConvey("should successfully check consistency when params are valid", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("123").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(&Mock_DataRefreshService_CheckMdPartyInfoDBConsistency20210101{}).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckMdPartyInfoDBConsistency20210101).CheckMdPartyInfoDBConsistency).Return(nil).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.CheckMdPartyInfoDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario – Invalid startID", func(t *testing.T) {
		mockey.PatchConvey("should return param parse error for invalid startID", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.CheckMdPartyInfoDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario – Invalid batchSize", func(t *testing.T) {
		mockey.PatchConvey("should return param parse error for invalid batchSize", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("123").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.CheckMdPartyInfoDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario – Service returns error", func(t *testing.T) {
		mockey.PatchConvey("should handle service layer error and send notification", t, func() {
			serviceErr := conmmonerror.New("database connection error")
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("123").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(&Mock_DataRefreshService_CheckMdPartyInfoDBConsistency20210101{}).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckMdPartyInfoDBConsistency20210101).CheckMdPartyInfoDBConsistency).Return(serviceErr).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceErr.Error()))
			}).Build()

			h.CheckMdPartyInfoDBConsistency20210101(context.Background(), c)

		})
	})
}

type Mock_DataRefreshService_EncryptContractTradePartyDB20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_EncryptContractTradePartyDB20210101(t *testing.T) {
	h := &innerToolHandler{}
	c := &app.RequestContext{}

	t.Run("Successful Scenario - data encryption completes", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - data encryption completes", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockService := &Mock_DataRefreshService_EncryptContractTradePartyDB20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptContractTradePartyDB20210101).EncryptContractTradePartyDB).Return(nil).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.EncryptContractTradePartyDB20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - invalid startID parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - invalid startID parameter", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.EncryptContractTradePartyDB20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - invalid batchSize parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - invalid batchSize parameter", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.EncryptContractTradePartyDB20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - data encryption service fails", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - data encryption service fails", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockService := &Mock_DataRefreshService_EncryptContractTradePartyDB20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()

			serviceError := conmmonerror.New("internal service failure")
			mockey.Mock((*Mock_DataRefreshService_EncryptContractTradePartyDB20210101).EncryptContractTradePartyDB).Return(serviceError).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceError.Error()))
			}).Build()

			h.EncryptContractTradePartyDB20210101(context.Background(), c)
		})
	})
}

type Mock_DataRefreshService_CheckEncryptContractTradePartyDBConsistency20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_CheckEncryptContractTradePartyDBConsistency20210101(t *testing.T) {
	t.Run("Successful Scenario", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_CheckEncryptContractTradePartyDBConsistency20210101{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckEncryptContractTradePartyDBConsistency20210101).CheckContractTradePartyDBConsistency).Return(nil).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.CheckEncryptContractTradePartyDBConsistency20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Invalid startID", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid startID", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.CheckEncryptContractTradePartyDBConsistency20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Invalid batchSize", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid batchSize", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.CheckEncryptContractTradePartyDBConsistency20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Service returns error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Service returns error", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			testErr := conmmonerror.New("service consistency check failed")
			mockService := &Mock_DataRefreshService_CheckEncryptContractTradePartyDBConsistency20210101{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckEncryptContractTradePartyDBConsistency20210101).CheckContractTradePartyDBConsistency).Return(testErr).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(testErr.Error()))
			}).Build()

			h.CheckEncryptContractTradePartyDBConsistency20210101(context.Background(), c)
		})
	})
}

type Mock_DataRefreshService_CheckContractMetaDBConsistency20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_CheckContractMetaDBConsistency20210101(t *testing.T) {
	h := &innerToolHandler{}
	c := &app.RequestContext{}

	t.Run("Successful Scenario", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("12345").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()

			mockService := &Mock_DataRefreshService_CheckContractMetaDBConsistency20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckContractMetaDBConsistency20210101).CheckContractMetaDBConsistency).Return(nil).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.CheckContractMetaDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - Invalid startID", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid startID", t, func() {

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.CheckContractMetaDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - Invalid batchSize", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid batchSize", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.CheckContractMetaDBConsistency20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - Service Call Fails", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Service Call Fails", t, func() {
			serviceErr := conmmonerror.New("internal service error")

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("12345").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()

			mockService := &Mock_DataRefreshService_CheckContractMetaDBConsistency20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_CheckContractMetaDBConsistency20210101).CheckContractMetaDBConsistency).Return(serviceErr).Build()

			mockey.Mock(larkc.Warning).Return().Build()

			h.CheckContractMetaDBConsistency20210101(context.Background(), c)

		})
	})
}

// All comments and test scenario descriptions must be in english.
// Mock_DataRefreshService_EncryptContractMetaDB20210101 is a mock for the DataRefreshService interface.
type Mock_DataRefreshService_EncryptContractMetaDB20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_EncryptContractMetaDB20210101(t *testing.T) {
	t.Run("Successful Scenario", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_EncryptContractMetaDB20210101{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("12345").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptContractMetaDB20210101).EncryptContractMetaDB).Return(nil).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.EncryptContractMetaDB20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - Invalid startID", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid startID", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("invalid-id").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h.EncryptContractMetaDB20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - Invalid batchSize", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid batchSize", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid-size").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h.EncryptContractMetaDB20210101(context.Background(), c)

		})
	})

	t.Run("Failure Scenario - DataRefreshService returns error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - DataRefreshService returns error", t, func() {
			c := &app.RequestContext{}
			h := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_EncryptContractMetaDB20210101{}
			serviceError := conmmonerror.New("database operation failed")

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "startID" }).Return("12345").
				When(func(key string) bool { return key == "batchSize" }).Return("100").
				Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptContractMetaDB20210101).EncryptContractMetaDB).Return(serviceError).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceError.Error()))
			}).Build()

			h.EncryptContractMetaDB20210101(context.Background(), c)

		})
	})
}

func Test_innerToolHandler_EncryptContractMetaByID20210101(t *testing.T) {
	h := &innerToolHandler{}

	t.Run("Success case with a valid ID", func(t *testing.T) {
		mockey.PatchConvey("should return success when id is valid and service call succeeds", t, func() {
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(&datarefresh.DataRefreshServiceImpl{}).Build()
			mockey.Mock(mockey.GetMethod(&datarefresh.DataRefreshServiceImpl{}, "EncryptContractMetaDBByID")).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				respMap, ok := result.(map[string]interface{})
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(respMap["message"], convey.ShouldEqual, "success")
			}).Build()

			h.EncryptContractMetaByID20210101(context.Background(), c)
		})
	})

	t.Run("Failure case with an invalid ID", func(t *testing.T) {
		mockey.PatchConvey("should return parameter parse error when id is not a valid integer", t, func() {
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("invalid-id").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
				convey.So(err.GetArgs(), convey.ShouldResemble, []interface{}{"invalid id"})
			}).Build()

			h.EncryptContractMetaByID20210101(context.Background(), c)
		})
	})

	t.Run("Failure case with a service error", func(t *testing.T) {
		mockey.PatchConvey("should return internal error when the service call fails", t, func() {
			c := &app.RequestContext{}
			serviceErr := conmmonerror.New("database connection failed")

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(&datarefresh.DataRefreshServiceImpl{}).Build()
			mockey.Mock(mockey.GetMethod(&datarefresh.DataRefreshServiceImpl{}, "EncryptContractMetaDBByID")).Return(serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs(), convey.ShouldResemble, []interface{}{serviceErr.Error()})
			}).Build()

			h.EncryptContractMetaByID20210101(context.Background(), c)

		})
	})
}

// All comments and test scenario descriptions must be in english.
// Mock_DataRefreshService_EncryptMdPartyInfoByID20210101 is a mock for the DataRefreshService interface.
type Mock_DataRefreshService_EncryptMdPartyInfoByID20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_EncryptMdPartyInfoByID20210101(t *testing.T) {
	h := &innerToolHandler{}

	t.Run("Successful Scenario - Data encrypted successfully", func(t *testing.T) {
		mockey.PatchConvey("Successful Scenario - Data encrypted successfully", t, func() {
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()

			mockService := &Mock_DataRefreshService_EncryptMdPartyInfoByID20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptMdPartyInfoByID20210101).EncryptMdPartyInfoByID).Return(nil).Build()

			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				resMap, ok := result.(map[string]interface{})
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(resMap["message"], convey.ShouldEqual, "success")
			}).Build()

			h.EncryptMdPartyInfoByID20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Invalid ID parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Invalid ID parameter", t, func() {
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("not-a-number").Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "invalid id")
			}).Build()

			h.EncryptMdPartyInfoByID20210101(context.Background(), c)
		})
	})

	t.Run("Failure Scenario - Service returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure Scenario - Service returns an error", t, func() {
			c := &app.RequestContext{}
			serviceErr := conmmonerror.New("internal service failure")

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()

			mockService := &Mock_DataRefreshService_EncryptMdPartyInfoByID20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptMdPartyInfoByID20210101).EncryptMdPartyInfoByID).Return(serviceErr).Build()

			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, serviceErr.Error())
			}).Build()

			h.EncryptMdPartyInfoByID20210101(context.Background(), c)
		})
	})
}

// All comments and test scenario descriptions must be in english.
// Mock_DataRefreshService_EncryptContractTradePartyByID20210101 is a mock type for the DataRefreshService interface.
type Mock_DataRefreshService_EncryptContractTradePartyByID20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_EncryptContractTradePartyByID20210101(t *testing.T) {
	t.Run("Successful scenario", func(t *testing.T) {
		mockey.PatchConvey("Successful scenario", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()
			mockService := &Mock_DataRefreshService_EncryptContractTradePartyByID20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptContractTradePartyByID20210101).EncryptContractTradePartyByID).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				resMap, ok := result.(map[string]interface{})
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(resMap["message"], convey.ShouldEqual, "success")
			}).Build()
			h.EncryptContractTradePartyByID20210101(context.Background(), c)

		})
	})

	t.Run("Failure scenario - invalid id parameter", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - invalid id parameter", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			mockey.Mock((*app.RequestContext).Query).Return("invalid-id").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "invalid id")
			}).Build()

			h.EncryptContractTradePartyByID20210101(context.Background(), c)

		})
	})

	t.Run("Failure scenario - data refresh service returns an error", func(t *testing.T) {
		mockey.PatchConvey("Failure scenario - data refresh service returns an error", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}
			serviceErr := conmmonerror.New("internal service error")

			mockey.Mock((*app.RequestContext).Query).Return("12345").Build()
			mockService := &Mock_DataRefreshService_EncryptContractTradePartyByID20210101{}
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_EncryptContractTradePartyByID20210101).EncryptContractTradePartyByID).Return(serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, serviceErr.Error())
			}).Build()

			h.EncryptContractTradePartyByID20210101(context.Background(), c)

		})
	})
}

func Test_innerToolHandler_RefreshRedisIncrByKey20210101(t *testing.T) {
	// Initialize the handler instance to be tested.
	h := &innerToolHandler{}

	mockey.PatchConvey("Test_innerToolHandler_RefresfRedisIncrByKey", t, func() {
		// Common mocks for all test cases in this block.
		mockey.Mock(logs.CtxError).Return().Build()

		mockey.PatchConvey("Success: successfully increments redis key to the target value", func() {
			// 场景描述：
			// 构造数据：提供有效的token, IncrKey, IncrStep。
			// 逻辑链路：
			// 1. 成功获取全局配置。
			// 2. Token验证通过。
			// 3. 参数绑定成功。
			// 4. IncrKey和IncrStep参数有效。
			// 5. Redis IncrByKey被循环调用，计数值从1增加到3，达到目标值。
			// 6. 最终返回成功响应 "success"。
			c := &app.RequestContext{}
			var capturedResult interface{}

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "IncrKey":
					return "test_key"
				case "IncrStep":
					return "3"
				}
				return ""
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(rediscli.IncrByKey).Return(
				mockey.Sequence(int64(1), nil).Then(int64(2), nil).Then(int64(3), nil),
			).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(capturedResult, convey.ShouldEqual, "success")
		})

		mockey.PatchConvey("Failure: GetGlobalConf returns nil", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. conf.GetGlobalConf返回nil。
			// 2. 函数提前返回，并调用vhertz.DoResponse(c, nil)。
			c := &app.RequestContext{}
			var capturedResult interface{}
			var responseCalled bool

			mockey.Mock((*app.RequestContext).Query).Return("any_token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
				responseCalled = true
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(responseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: Invalid token", func() {
			// 场景描述：
			// 构造数据：提供一个无效的token。
			// 逻辑链路：
			// 1. 成功获取全局配置。
			// 2. Token验证失败，因为提供的token不在配置的Auths列表中。
			// 3. 函数提前返回，并调用vhertz.DoResponse(c, nil)。
			c := &app.RequestContext{}
			var capturedResult interface{}
			var responseCalled bool

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token_only",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid_token").Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
				responseCalled = true
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(responseCalled, convey.ShouldBeTrue)
			convey.So(capturedResult, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: Parameter binding fails", func() {
			// 场景描述：
			// 构造数据：无。
			// 逻辑链路：
			// 1. Token验证通过。
			// 2. binding.BindAndValidate返回错误。
			// 3. 函数调用vhertz.ErrorResp返回参数解析错误。
			c := &app.RequestContext{}
			var capturedError errors.APIError

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid_token").Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind error")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})

		mockey.PatchConvey("Failure: Missing IncrKey or IncrStep parameter", func() {
			// 场景描述：
			// 构造数据：请求中缺少IncrKey参数。
			// 逻辑链路：
			// 1. Token验证和参数绑定均成功。
			// 2. 检查发现IncrKey为空字符串。
			// 3. 函数调用vhertz.ErrorResp返回缺少参数错误。
			c := &app.RequestContext{}
			var capturedError errors.APIError

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "IncrKey":
					return "" // Missing IncrKey
				case "IncrStep":
					return "3"
				}
				return ""
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(capturedError.Error(), convey.ShouldContainSubstring, "IncrKey||IncrStep")
		})

		mockey.PatchConvey("Failure: IncrStep is not a valid number", func() {
			// 场景描述：
			// 构造数据：IncrStep参数为非数字字符串 "abc"。
			// 逻辑链路：
			// 1. Token验证和参数绑定均成功。
			// 2. 尝试将 "abc" 解析为uint64时失败。
			// 3. 函数调用vhertz.ErrorResp返回缺少参数错误。
			c := &app.RequestContext{}
			var capturedError errors.APIError

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "IncrKey":
					return "test_key"
				case "IncrStep":
					return "abc" // Invalid number
				}
				return ""
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(capturedError.Error(), convey.ShouldContainSubstring, "IncrStep")
		})

		mockey.PatchConvey("Failure: rediscli.IncrByKey returns an error", func() {
			// 场景描述：
			// 构造数据：所有参数有效。
			// 逻辑链路：
			// 1. 所有前置检查均通过，进入循环。
			// 2. 第一次调用rediscli.IncrByKey时返回错误。
			// 3. 函数调用vhertz.DoResponse并传递Redis返回的错误。
			c := &app.RequestContext{}
			redisErr := fmt.Errorf("redis connection failed")
			var capturedResult interface{}

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid_token"
				case "IncrKey":
					return "test_key"
				case "IncrStep":
					return "3"
				}
				return ""
			}).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(rediscli.IncrByKey).Return(int64(0), redisErr).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			// Call the target function.
			h.RefreshRedisIncrByKey20210101(context.Background(), c)

			// Assertions.
			convey.So(capturedResult, convey.ShouldNotBeNil)
			convey.So(capturedResult, convey.ShouldEqual, redisErr)
		})
	})
}

func Test_innerToolHandler_RefreshSupplyContractBusinessType20210101(t *testing.T) {
	mockey.PatchConvey("Test_innerToolHandler_RefreshSupplyContractBusinessType20210101", t, func() {
		h := &innerToolHandler{}
		c := &app.RequestContext{}

		// Mock common dependencies that are called in almost all scenarios.
		mockey.Mock(logs.CtxError).Return().Build()

		mockey.PatchConvey("Success Case", func() {
			// 场景描述：
			// 这是一个成功的场景，所有依赖项都按预期工作。
			// 构造数据：
			// - 配置信息有效，且包含一个合法的 token。
			// - 请求查询参数中包含该合法 token。
			// - 请求体参数绑定成功。
			// - metasync 服务调用成功，并返回一个有效的响应。
			// 逻辑链路：
			// 1. conf.GetGlobalConf 返回有效的配置。
			// 2. c.Query 返回合法的 token，鉴权通过。
			// 3. binding.BindAndValidate 成功解析参数。
			// 4. metasync.NewFixDataService().RefreshSupplyContractBusinessType 调用成功。
			// 5. vhertz.DoResponse 被调用，并传入服务的成功响应。

			mockResp := &metasync.CommonRefreshResp{BeginID: 1, ErrMsg: "success"}
			var capturedResp interface{}

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool {
				return key == _const.HeaderToolToken
			}).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()

			// NOTE: Mocking NewFixDataService to inject a mock service.
			// This allows us to control the behavior of RefreshSupplyContractBusinessType for unit testing.
			service := metasync.NewFixDataService()
			mockey.Mock(metasync.NewFixDataService).Return(service).Build()
			mockey.Mock(mockey.GetMethod(service, "RefreshSupplyContractBusinessType")).Return(mockResp, nil).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.RefreshSupplyContractBusinessType20210101(context.Background(), c)

			convey.So(capturedResp, convey.ShouldResemble, mockResp)
		})

		mockey.PatchConvey("Failure Case: GetGlobalConf returns nil", func() {
			// 场景描述：
			// 测试获取全局配置失败的场景。
			// 构造数据：
			// - conf.GetGlobalConf 返回 nil。
			// 逻辑链路：
			// 1. conf.GetGlobalConf 返回 nil。
			// 2. 函数应立即调用 vhertz.DoResponse(c, nil) 并返回。
			var responseCalled bool
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.RefreshSupplyContractBusinessType20210101(context.Background(), c)

			convey.So(responseCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("Failure Case: Invalid Token", func() {
			// 场景描述：
			// 测试提供了无效 token 的场景。
			// 构造数据：
			// - conf.GetGlobalConf 返回有效配置。
			// - c.Query 返回一个不在配置列表中的 token。
			// 逻辑链路：
			// 1. conf.GetGlobalConf 返回有效配置。
			// 2. c.Query 返回无效 token，鉴权失败。
			// 3. logs.CtxError 被调用以记录错误。
			// 4. vhertz.DoResponse(c, nil) 被调用，函数返回。
			var responseCalled, logCalled bool
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {
				logCalled = true
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				responseCalled = true
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.RefreshSupplyContractBusinessType20210101(context.Background(), c)

			convey.So(responseCalled, convey.ShouldBeTrue)
			convey.So(logCalled, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("Failure Case: Parameter Binding Fails", func() {
			// 场景描述：
			// 测试请求参数绑定失败的场景。
			// 构造数据：
			// - 鉴权通过。
			// - binding.BindAndValidate 返回一个错误。
			// 逻辑链路：
			// 1. 鉴权成功。
			// 2. binding.BindAndValidate 返回错误。
			// 3. logs.CtxError 被调用。
			// 4. vhertz.ErrorResp 被调用，并传入 ErrParamParseFail。
			var capturedError vhertz.APIError
			bindErr := fmt.Errorf("bind and validate error")

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(bindErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.RefreshSupplyContractBusinessType20210101(context.Background(), c)

			convey.So(capturedError, convey.ShouldEqual, errors.ErrParamParseFail)
		})

		mockey.PatchConvey("Failure Case: Service Call Fails", func() {
			// 场景描述：
			// 测试 metasync 服务调用失败的场景。
			// 构造数据：
			// - 鉴权和参数绑定都成功。
			// - metasync.RefreshSupplyContractBusinessType 返回一个错误。
			// 逻辑链路：
			// 1. 鉴权和参数绑定成功。
			// 2. metasync.NewFixDataService().RefreshSupplyContractBusinessType 调用返回错误。
			// 3. logs.CtxError 被调用。
			// 4. vhertz.DoResponse 被调用，并传入服务返回的错误。
			serviceErr := errors.NewErr("ServiceError", "something went wrong", http.StatusInternalServerError)
			var capturedResp interface{}

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{Auths: "valid-token"},
			}).Build()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			service := metasync.NewFixDataService()
			mockey.Mock(metasync.NewFixDataService).Return(service).Build()
			mockey.Mock(mockey.GetMethod(service, "RefreshSupplyContractBusinessType")).Return(nil, serviceErr).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.RefreshSupplyContractBusinessType20210101(context.Background(), c)

			convey.So(capturedResp, convey.ShouldEqual, serviceErr)
		})
	})
}

func Test_innerToolHandler_FillMainContractNo20210101(t *testing.T) {
	t.Run("invalid startID returns error", func(t *testing.T) {
		mockey.PatchConvey("invalid startID returns error", t, func() {
			// Mock query to return invalid startID and valid batchSize
			mockey.MockUnsafe((*app.RequestContext).Query).
				When(func(k string) bool { return k == "startID" }).Return("abc").
				When(func(k string) bool { return k == "batchSize" }).Return("10").
				Build()

			hdl := &innerToolHandler{}
			ctx := &app.RequestContext{}
			hdl.FillMainContractNo20210101(context.Background(), ctx)
		})
	})

	t.Run("invalid batchSize returns error", func(t *testing.T) {
		mockey.PatchConvey("invalid batchSize returns error", t, func() {
			// Mock query to return valid startID and invalid batchSize
			mockey.MockUnsafe((*app.RequestContext).Query).
				When(func(k string) bool { return k == "startID" }).Return("123").
				When(func(k string) bool { return k == "batchSize" }).Return("xyz").
				Build()
			// Mock error response
			hdl := &innerToolHandler{}
			ctx := &app.RequestContext{}
			hdl.FillMainContractNo20210101(context.Background(), ctx)

		})
	})

	t.Run("service returns error path", func(t *testing.T) {
		mockey.PatchConvey("service returns error path", t, func() {
			// Mock query to return valid values
			mockey.MockUnsafe((*app.RequestContext).Query).
				When(func(k string) bool { return k == "startID" }).Return("100").
				When(func(k string) bool { return k == "batchSize" }).Return("20").
				Build()
			// Mock underlying service method to return error
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).FillMainContractNo).Return(conmmonerror.New("boom")).Build()
			// Mock lark warning and error response
			mockey.MockUnsafe(larkc.Warning).Return().Build()
			mockey.MockUnsafe(vhertz.ErrorResp).Return().Build()

			hdl := &innerToolHandler{}
			ctx := &app.RequestContext{}
			hdl.FillMainContractNo20210101(context.Background(), ctx)
		})
	})

	t.Run("successful fill returns response", func(t *testing.T) {
		mockey.PatchConvey("successful fill returns response", t, func() {
			// Mock query to return valid values
			mockey.MockUnsafe((*app.RequestContext).Query).
				When(func(k string) bool { return k == "startID" }).Return("200").
				When(func(k string) bool { return k == "batchSize" }).Return("30").
				Build()
			// Mock underlying service method to return nil (success)
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).FillMainContractNo).Return(nil).Build()
			// Mock lark warning and success response
			mockey.MockUnsafe(larkc.Warning).Return().Build()
			mockey.MockUnsafe(vhertz.DoResponse).Return().Build()

			hdl := &innerToolHandler{}
			ctx := &app.RequestContext{}
			hdl.FillMainContractNo20210101(context.Background(), ctx)
		})
	})
}

func Test_innerToolHandler_FillDeploymentTypeForPartnerQuote20210101(t *testing.T) {
	t.Run("数据刷新服务返回错误时走错误分支", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 捕获DoResponse的出参，方便断言错误分支是否将err透传到响应函数
			var capturedResult interface{}
			var capturedTitle string
			var capturedContent string

			// 打桩：数据刷新服务返回错误
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).FillDeploymentTypeForPartnerQuote).Return(conmmonerror.New("mock error")).Build()
			// 打桩：告警函数，记录告警内容并避免真实外部调用（变参签名需一致）
			mockey.MockUnsafe(larkc.Warning).To(func(title string, content string, _ ...context.Context) {
				capturedTitle = title
				capturedContent = content
			}).Build()
			// 打桩：响应函数，记录响应入参
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerToolHandler{}
			rc := &app.RequestContext{}
			h.FillDeploymentTypeForPartnerQuote20210101(context.Background(), rc)

			// 断言走错误分支
			convey.So(capturedResult, convey.ShouldNotBeNil)
			if capturedResult != nil {
				errVal, _ := capturedResult.(error)
				convey.So(errVal.Error(), convey.ShouldContainSubstring, "mock error")
			}
			convey.So(capturedTitle, convey.ShouldEqual, "更新伙伴报价合同部署方式失败")
			convey.So(capturedContent, convey.ShouldContainSubstring, "mock error")
		})
	})

	t.Run("数据刷新服务成功返回时走成功分支", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 捕获DoResponse的出参，方便断言成功分支是否返回nil
			var capturedResult interface{}
			var capturedTitle string
			var capturedContent string

			// 打桩：数据刷新服务成功
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).FillDeploymentTypeForPartnerQuote).Return(nil).Build()
			// 打桩：告警函数，记录告警内容并避免真实外部调用（变参签名需一致）
			mockey.MockUnsafe(larkc.Warning).To(func(title string, content string, _ ...context.Context) {
				capturedTitle = title
				capturedContent = content
			}).Build()
			// 打桩：响应函数，记录响应入参
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerToolHandler{}
			rc := &app.RequestContext{}
			h.FillDeploymentTypeForPartnerQuote20210101(context.Background(), rc)

			// 断言走成功分支
			convey.So(capturedResult, convey.ShouldBeNil)
			convey.So(capturedTitle, convey.ShouldEqual, "更新伙伴报价合同部署方式完成")
			convey.So(capturedContent, convey.ShouldEqual, "更新伙伴报价合同部署方式完成")
		})
	})
}

func Test_innerToolHandler_ChangeContractOwner20210101(t *testing.T) {
	t.Run("绑定失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 绑定失败
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, _ interface{}) error {
				return conmmonerror.New("bind fail")
			}).Build()

			// 捕获错误响应
			respCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				respCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(respCalled, convey.ShouldBeTrue)
		})
	})

	t.Run("校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 构造无效的请求（缺少必填字段）
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelinnertool.ChangeContractOwnerReq)
				*req = modelinnertool.ChangeContractOwnerReq{
					ContractNo:             "",    // 触发缺少参数错误
					ChangeOperator:         false, // 不选择任何变更类型
					ChangeCreator:          false,
					ChangeContractReviewer: false,
				}
				return nil
			}).Build()

			// 捕获错误响应
			respCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				respCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(respCalled, convey.ShouldBeTrue)
		})
	})

	t.Run("白名单配置为空返回显式拒绝错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 构造有效的请求
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelinnertool.ChangeContractOwnerReq)
				*req = modelinnertool.ChangeContractOwnerReq{
					ContractNo:     "C123",
					ChangeOperator: true,
					NewOperator: &modelinnertool.ChangeOwnerUserInfo{
						JobID: "J001",
					},
					CurrentOperator: "allowed@example.com",
				}
				return nil
			}).Build()

			// 配置为空
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(_ context.Context) *conf.GlobalConf {
				return nil
			}).Build()

			// 捕获错误响应
			respCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				respCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(respCalled, convey.ShouldBeTrue)
		})
	})

	t.Run("操作人不在白名单返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 构造有效的请求但操作人不在白名单
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelinnertool.ChangeContractOwnerReq)
				*req = modelinnertool.ChangeContractOwnerReq{
					ContractNo:     "C123",
					ChangeOperator: true,
					NewOperator: &modelinnertool.ChangeOwnerUserInfo{
						JobID: "J001",
					},
					CurrentOperator: "notallowed@example.com",
				}
				return nil
			}).Build()

			// 白名单配置非空但不包含当前操作人
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(_ context.Context) *conf.GlobalConf {
				return &conf.GlobalConf{
					ToolConf: &conf.ToolConf{
						ContractOwnerChangerAllowedUsers: []string{"allowed@example.com"},
					},
				}
			}).Build()

			// 捕获错误响应
			respCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				respCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(respCalled, convey.ShouldBeTrue)
		})
	})

	t.Run("数据刷新服务返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 构造有效的请求且操作人在白名单内
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelinnertool.ChangeContractOwnerReq)
				*req = modelinnertool.ChangeContractOwnerReq{
					ContractNo:     "C999",
					ChangeOperator: true,
					NewOperator: &modelinnertool.ChangeOwnerUserInfo{
						JobID: "JJJJ",
					},
					CurrentOperator: "john@example.com",
				}
				return nil
			}).Build()

			mockey.MockUnsafe(conf.GetGlobalConf).To(func(_ context.Context) *conf.GlobalConf {
				return &conf.GlobalConf{
					ToolConf: &conf.ToolConf{
						ContractOwnerChangerAllowedUsers: []string{"john@example.com"},
					},
				}
			}).Build()

			// 数据刷新服务返回错误
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).ChangeContractOwner).Return(errors.ErrorExplicitDeny.WithArgs("bad")).Build()

			// 捕获错误响应
			respCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				respCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(respCalled, convey.ShouldBeTrue)
		})
	})

	t.Run("成功返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerToolHandler{}
			c := &app.RequestContext{}

			// 构造有效请求
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelinnertool.ChangeContractOwnerReq)
				*req = modelinnertool.ChangeContractOwnerReq{
					ContractNo:     "C1000",
					ChangeOperator: true,
					NewOperator: &modelinnertool.ChangeOwnerUserInfo{
						JobID: "JOB1000",
					},
					CurrentOperator: "ok@example.com",
				}
				return nil
			}).Build()

			// 白名单包含当前操作人
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(_ context.Context) *conf.GlobalConf {
				return &conf.GlobalConf{
					ToolConf: &conf.ToolConf{
						ContractOwnerChangerAllowedUsers: []string{"ok@example.com"},
					},
				}
			}).Build()

			// 数据刷新服务成功
			mockey.Mock((*datarefresh.DataRefreshServiceImpl).ChangeContractOwner).Return(nil).Build()

			// 捕获成功响应
			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doRespCalled = true
			}).Build()

			h.ChangeContractOwner20210101(context.Background(), c)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})
	})
}

func Test_innerToolHandler_FillRiskClauseTplReviewer20210101(t *testing.T) {
	mockey.PatchConvey("Test_innerToolHandler_FillRiskClauseTplReviewer20210101", t, func() {
		mockey.PatchConvey("缺少RefreshType时应返回缺参错误", func() {
			c := &app.RequestContext{}
			handler := &innerToolHandler{}

			var gotErr vhertz.APIError
			var errorRespCalled bool
			var doRespCalled bool
			var warningCalled bool

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case "SheetURL":
					return "mock-sheet-url"
				case "Header":
					return "mock-header"
				case "RefreshType":
					return ""
				default:
					return ""
				}
			}).Build()
			mockey.MockUnsafe(datarefresh.NewDataRefreshService).To(func() datarefresh.DataRefreshService {
				panic("缺少RefreshType时不应调用刷新服务")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				gotErr = err
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()
			mockey.MockUnsafe(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {
				warningCalled = true
			}).Build()

			handler.FillRiskClauseTplReviewer20210101(context.Background(), c)

			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doRespCalled, convey.ShouldBeFalse)
			convey.So(warningCalled, convey.ShouldBeFalse)
			convey.So(gotErr, convey.ShouldNotBeNil)
			convey.So(gotErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(len(gotErr.GetArgs()), convey.ShouldEqual, 1)
			convey.So(gotErr.GetArgs()[0], convey.ShouldEqual, "RefreshType")
		})

		mockey.PatchConvey("服务返回错误时应返回错误响应", func() {
			c := &app.RequestContext{}
			handler := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_FillRiskClauseTplReviewer20210101{}
			serviceErr := conmmonerror.New("模拟服务失败")

			var gotResp interface{}
			var errorRespCalled bool
			var warningCalled bool
			var warningTitle string
			var warningContent string

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case "SheetURL":
					return "mock-sheet-url"
				case "Header":
					return "mock-header"
				case "RefreshType":
					return "mock-refresh-type"
				default:
					return ""
				}
			}).Build()
			mockey.MockUnsafe(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_FillRiskClauseTplReviewer20210101).FillRiskClauseTplReviewer).Return(serviceErr).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				gotResp = result
			}).Build()
			mockey.MockUnsafe(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {
				warningCalled = true
				warningTitle = title
				warningContent = content
			}).Build()

			handler.FillRiskClauseTplReviewer20210101(context.Background(), c)

			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(warningCalled, convey.ShouldBeTrue)
			convey.So(warningTitle, convey.ShouldEqual, "更新风险条款审批人失败")
			convey.So(warningContent, convey.ShouldContainSubstring, "模拟服务失败")
			convey.So(gotResp, convey.ShouldNotBeNil)

			respErr, ok := gotResp.(error)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(respErr.Error(), convey.ShouldContainSubstring, "模拟服务失败")
		})

		mockey.PatchConvey("服务执行成功时应返回成功响应", func() {
			c := &app.RequestContext{}
			handler := &innerToolHandler{}
			mockService := &Mock_DataRefreshService_FillRiskClauseTplReviewer20210101{}

			var gotResp interface{}
			var errorRespCalled bool
			var warningCalled bool
			var warningTitle string
			var warningContent string

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case "SheetURL":
					return "mock-sheet-url"
				case "Header":
					return "mock-header"
				case "RefreshType":
					return "mock-refresh-type"
				default:
					return ""
				}
			}).Build()
			mockey.MockUnsafe(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_FillRiskClauseTplReviewer20210101).FillRiskClauseTplReviewer).Return((error)(nil)).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				gotResp = result
			}).Build()
			mockey.MockUnsafe(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {
				warningCalled = true
				warningTitle = title
				warningContent = content
			}).Build()

			handler.FillRiskClauseTplReviewer20210101(context.Background(), c)

			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(warningCalled, convey.ShouldBeTrue)
			convey.So(warningTitle, convey.ShouldEqual, "更新风险条款审批人完成")
			convey.So(warningContent, convey.ShouldEqual, "更新风险条款审批人完成")
			convey.So(gotResp, convey.ShouldBeNil)
		})
	})
}

type Mock_DataRefreshService_FillRiskClauseTplReviewer20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_RefreshHistorySupplyContractFile20210101(t *testing.T) {
	handler := &innerToolHandler{}

	mockey.PatchConvey("测试 innerToolHandler.RefreshHistorySupplyContractFile20210101", t, func() {
		mockey.PatchConvey("场景：全局配置为空时直接返回空响应", func() {
			// 场景描述：
			// 当读取到的全局配置为空时，函数应直接走空响应返回分支。
			// 构造数据：
			// 1. 请求上下文使用零值即可。
			// 2. 请求 token 任意。
			// 3. conf.GetGlobalConf 返回 nil。
			// 逻辑链路：
			// 1. 读取请求 token。
			// 2. 获取配置返回 nil。
			// 3. 调用 DoResponse(c, nil) 并返回。

			c := &app.RequestContext{}
			tokenValue := "any-token"

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(rc *app.RequestContext, key string) string {
				convey.So(rc, convey.ShouldEqual, c)
				convey.So(key, convey.ShouldEqual, _const.HeaderToolToken)
				return tokenValue
			}).Build()
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(ctx context.Context) *conf.GlobalConf {
				convey.So(ctx, convey.ShouldNotBeNil)
				return nil
			}).Build()

			var doResponseResults []interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(rc, convey.ShouldEqual, c)
				doResponseResults = append(doResponseResults, result)
			}).Build()

			handler.RefreshHistorySupplyContractFile20210101(context.Background(), c)

			convey.So(doResponseResults, convey.ShouldHaveLength, 1)
			convey.So(doResponseResults[0], convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：鉴权令牌不匹配时返回空响应", func() {
			// 场景描述：
			// 当全局配置存在，但配置中的 Auths 不包含当前 token 时，应返回空响应。
			// 构造数据：
			// 1. 配置中仅包含其他 token。
			// 2. 当前请求 token 为未授权 token。
			// 逻辑链路：
			// 1. 读取请求 token。
			// 2. 获取到非空配置。
			// 3. strings.Contains 判断失败。
			// 4. 调用 DoResponse(c, nil) 并返回。

			c := &app.RequestContext{}
			tokenValue := "invalid-token"
			cfg := &conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token-a,valid-token-b",
				},
			}

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(rc *app.RequestContext, key string) string {
				convey.So(rc, convey.ShouldEqual, c)
				convey.So(key, convey.ShouldEqual, _const.HeaderToolToken)
				return tokenValue
			}).Build()
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(ctx context.Context) *conf.GlobalConf {
				convey.So(ctx, convey.ShouldNotBeNil)
				return cfg
			}).Build()

			var doResponseResults []interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(rc, convey.ShouldEqual, c)
				doResponseResults = append(doResponseResults, result)
			}).Build()

			handler.RefreshHistorySupplyContractFile20210101(context.Background(), c)

			convey.So(doResponseResults, convey.ShouldHaveLength, 1)
			convey.So(doResponseResults[0], convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：参数绑定失败时返回参数解析错误", func() {
			// 场景描述：
			// 当 token 校验通过后，若请求参数绑定失败，应返回统一的参数解析错误。
			// 构造数据：
			// 1. 配置中的 Auths 包含当前 token。
			// 2. BindAndValidate 返回普通错误。
			// 逻辑链路：
			// 1. 读取请求 token 并通过鉴权。
			// 2. 绑定参数失败。
			// 3. 调用 ErrorResp(c, ErrParamParseFail)。
			// 4. 不应调用 DoResponse。

			c := &app.RequestContext{}
			tokenValue := "valid-token"
			cfg := &conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "prefix-valid-token-suffix",
				},
			}
			bindErr := conmmonerror.New("bind fail")

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(rc *app.RequestContext, key string) string {
				convey.So(rc, convey.ShouldEqual, c)
				convey.So(key, convey.ShouldEqual, _const.HeaderToolToken)
				return tokenValue
			}).Build()
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(ctx context.Context) *conf.GlobalConf {
				convey.So(ctx, convey.ShouldNotBeNil)
				return cfg
			}).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				convey.So(rc, convey.ShouldEqual, c)
				_, ok := obj.(*datarefresh.CommonRefreshReq)
				convey.So(ok, convey.ShouldBeTrue)
				return bindErr
			}).Build()

			var doResponseResults []interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doResponseResults = append(doResponseResults, result)
			}).Build()

			var capturedErr vhertz.APIError
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(rc, convey.ShouldEqual, c)
				capturedErr = err
			}).Build()

			handler.RefreshHistorySupplyContractFile20210101(context.Background(), c)

			convey.So(doResponseResults, convey.ShouldBeEmpty)
			convey.So(capturedErr, convey.ShouldEqual, errors.ErrParamParseFail)
		})

		mockey.PatchConvey("场景：刷新服务返回错误时透传错误对象", func() {
			// 场景描述：
			// 当参数绑定成功，但数据刷新服务返回错误时，应将该错误对象通过 DoResponse 透传。
			// 构造数据：
			// 1. 配置鉴权通过。
			// 2. BindAndValidate 成功，并填充请求参数。
			// 3. RefreshHistorySupplyContractFile 返回 error。
			// 逻辑链路：
			// 1. 读取 token 并通过鉴权。
			// 2. 绑定成功，得到请求参数。
			// 3. 创建刷新服务并调用刷新方法。
			// 4. 服务报错后，DoResponse(c, err) 返回。

			c := &app.RequestContext{}
			tokenValue := "valid-token"
			cfg := &conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}
			serviceErr := conmmonerror.New("service failure")
			mockSvc := &Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101{}
			var capturedReq *datarefresh.CommonRefreshReq

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(rc *app.RequestContext, key string) string {
				convey.So(rc, convey.ShouldEqual, c)
				convey.So(key, convey.ShouldEqual, _const.HeaderToolToken)
				return tokenValue
			}).Build()
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(ctx context.Context) *conf.GlobalConf {
				convey.So(ctx, convey.ShouldNotBeNil)
				return cfg
			}).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				convey.So(rc, convey.ShouldEqual, c)
				req := obj.(*datarefresh.CommonRefreshReq)
				req.ContractNo = "CN-001"
				req.ContractNoList = "CN-001,CN-002"
				req.StartID = 11
				req.Limit = 22
				return nil
			}).Build()
			mockey.MockUnsafe(datarefresh.NewDataRefreshService).To(func() datarefresh.DataRefreshService {
				return mockSvc
			}).Build()
			mockey.MockUnsafe((*Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101).RefreshHistorySupplyContractFile).To(
				func(_ *Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101, ctx context.Context, req *datarefresh.CommonRefreshReq) (*datarefresh.CommonRefreshResp, error) {
					convey.So(ctx, convey.ShouldNotBeNil)
					capturedReq = req
					return nil, serviceErr
				},
			).Build()

			var doResponseResults []interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(rc, convey.ShouldEqual, c)
				doResponseResults = append(doResponseResults, result)
			}).Build()

			handler.RefreshHistorySupplyContractFile20210101(context.Background(), c)

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN-001")
			convey.So(capturedReq.ContractNoList, convey.ShouldEqual, "CN-001,CN-002")
			convey.So(capturedReq.StartID, convey.ShouldEqual, int64(11))
			convey.So(capturedReq.Limit, convey.ShouldEqual, int64(22))
			convey.So(doResponseResults, convey.ShouldHaveLength, 1)
			convey.So(doResponseResults[0], convey.ShouldEqual, serviceErr)
		})

		mockey.PatchConvey("场景：刷新服务成功时返回业务结果", func() {
			// 场景描述：
			// 当鉴权、参数绑定及服务调用都成功时，应返回刷新服务的响应结果。
			// 构造数据：
			// 1. 配置鉴权通过。
			// 2. BindAndValidate 成功填充请求参数。
			// 3. 刷新服务返回正常响应对象。
			// 逻辑链路：
			// 1. 读取 token 并通过鉴权。
			// 2. 绑定成功得到参数。
			// 3. 调用刷新服务返回 resp。
			// 4. DoResponse(c, resp) 返回成功结果。

			c := &app.RequestContext{}
			tokenValue := "valid-token"
			cfg := &conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid-token",
				},
			}
			mockSvc := &Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101{}
			expectedResp := &datarefresh.CommonRefreshResp{
				ErrMsg:  "ok",
				BeginID: 123,
			}
			var capturedReq *datarefresh.CommonRefreshReq

			mockey.MockUnsafe((*app.RequestContext).Query).To(func(rc *app.RequestContext, key string) string {
				convey.So(rc, convey.ShouldEqual, c)
				convey.So(key, convey.ShouldEqual, _const.HeaderToolToken)
				return tokenValue
			}).Build()
			mockey.MockUnsafe(conf.GetGlobalConf).To(func(ctx context.Context) *conf.GlobalConf {
				convey.So(ctx, convey.ShouldNotBeNil)
				return cfg
			}).Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				convey.So(rc, convey.ShouldEqual, c)
				req := obj.(*datarefresh.CommonRefreshReq)
				req.ContractNo = "CN-888"
				req.Limit = 5
				return nil
			}).Build()
			mockey.MockUnsafe(datarefresh.NewDataRefreshService).To(func() datarefresh.DataRefreshService {
				return mockSvc
			}).Build()
			mockey.MockUnsafe((*Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101).RefreshHistorySupplyContractFile).To(
				func(_ *Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101, ctx context.Context, req *datarefresh.CommonRefreshReq) (*datarefresh.CommonRefreshResp, error) {
					convey.So(ctx, convey.ShouldNotBeNil)
					capturedReq = req
					return expectedResp, nil
				},
			).Build()

			var doResponseResults []interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(rc, convey.ShouldEqual, c)
				doResponseResults = append(doResponseResults, result)
			}).Build()

			handler.RefreshHistorySupplyContractFile20210101(context.Background(), c)

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN-888")
			convey.So(capturedReq.Limit, convey.ShouldEqual, int64(5))
			convey.So(doResponseResults, convey.ShouldHaveLength, 1)
			convey.So(doResponseResults[0], convey.ShouldEqual, expectedResp)
		})
	})
}

type Mock_DataRefreshService_RefreshHistorySupplyContractFile20210101 struct {
	datarefresh.DataRefreshService
}

func intPtr(v int) *int {
	return &v
}

type Mock_DataRefreshService_AddOtherPartyAccount20210101 struct {
	datarefresh.DataRefreshService
}

func TestNewInnerToolHandler(t *testing.T) {
	mockey.PatchConvey("创建 inner tool handler", t, func() {
		convey.So(NewInnerToolHandler(), convey.ShouldNotBeNil)
	})
}

func Test_innerToolHandler_checkToken(t *testing.T) {
	t.Run("配置为空时返回 false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			ok := (&innerToolHandler{}).checkToken(context.Background(), &app.RequestContext{})

			convey.So(ok, convey.ShouldBeFalse)
		})
	})
	t.Run("token 不在白名单时返回 false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*app.RequestContext).Query).Return("invalid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()

			ok := (&innerToolHandler{}).checkToken(context.Background(), &app.RequestContext{})

			convey.So(ok, convey.ShouldBeFalse)
		})
	})
	t.Run("token 在白名单时返回 true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()

			ok := (&innerToolHandler{}).checkToken(context.Background(), &app.RequestContext{})

			convey.So(ok, convey.ShouldBeTrue)
		})
	})
}

func Test_innerToolHandler_AddOtherPartyAccount20210101(t *testing.T) {
	t.Run("token 校验失败时直接返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(false).Build()

			(&innerToolHandler{}).AddOtherPartyAccount20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(binding.BindAndValidate).Return(conmmonerror.New("bind")).Build()

			(&innerToolHandler{}).AddOtherPartyAccount20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("校验失败不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockService := &Mock_DataRefreshService_AddOtherPartyAccount20210101{}
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_AddOtherPartyAccount20210101).AddOtherPartyAccount).To(func(ctx context.Context, req *bizmodels.ToolAddOtherPartyAccountReq) errors.APIError {
				called = true
				return nil
			}).Build()

			(&innerToolHandler{}).AddOtherPartyAccount20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockService := &Mock_DataRefreshService_AddOtherPartyAccount20210101{}
			serviceErr := errors.ErrorCommon.WithArgs("svc")
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.ToolAddOtherPartyAccountReq)
				req.ContractNo = "C-1"
				req.PartyNumber = "P-1"
				req.AccountID = "100"
				req.SealAccountID = "SA-1"
				req.IsSealed = intPtr(1)
				req.IsPricing = intPtr(0)
				return nil
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_AddOtherPartyAccount20210101).AddOtherPartyAccount).Return(serviceErr).Build()

			(&innerToolHandler{}).AddOtherPartyAccount20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功时返回 Success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockService := &Mock_DataRefreshService_AddOtherPartyAccount20210101{}
			var capturedReq *bizmodels.ToolAddOtherPartyAccountReq
			mockey.Mock((*innerToolHandler).checkToken).Return(true).Build()
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.ToolAddOtherPartyAccountReq)
				req.ContractNo = "C-1"
				req.PartyNumber = "P-1"
				req.AccountID = "100"
				req.SealAccountID = "SA-1"
				req.IsSealed = intPtr(1)
				req.IsPricing = intPtr(0)
				return nil
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_AddOtherPartyAccount20210101).AddOtherPartyAccount).To(func(ctx context.Context, req *bizmodels.ToolAddOtherPartyAccountReq) errors.APIError {
				capturedReq = req
				return nil
			}).Build()

			(&innerToolHandler{}).AddOtherPartyAccount20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "C-1")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"Message": "Success"})
		})
	})
}

func Test_innerToolHandler_FixBelongingDepartment20210101(t *testing.T) {
	t.Run("配置为空时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*app.RequestContext).Query).Return("valid-token").Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()

			(&innerToolHandler{}).FixBelongingDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("token 不在白名单时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				if key == _const.HeaderToolToken {
					return "invalid-token"
				}
				return ""
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()

			(&innerToolHandler{}).FixBelongingDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("offset 非法时不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "0"
				default:
					return ""
				}
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()

			(&innerToolHandler{}).FixBelongingDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
	t.Run("成功返回 LastID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			service := metasync.NewService()
			var startID int64
			var offset int
			mockey.Mock((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
				switch key {
				case _const.HeaderToolToken:
					return "valid-token"
				case "StartID":
					return "10"
				case "Offset":
					return "20"
				default:
					return ""
				}
			}).Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{ProductsApp: conf.ProductsApp{Auths: "valid-token"}}).Build()
			mockey.Mock(metasync.NewService).Return(service).Build()
			mockey.Mock(mockey.GetMethod(service, "FixBelongingDepartment")).To(func(ctx context.Context, s int64, o int) int64 {
				startID = s
				offset = o
				return 88
			}).Build()

			(&innerToolHandler{}).FixBelongingDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(startID, convey.ShouldEqual, 10)
			convey.So(offset, convey.ShouldEqual, 20)
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"LastID": int64(88)})
		})
	})
}

func Test_innerToolHandler_TestGenCRMDetailURL20210101(t *testing.T) {
	mockey.PatchConvey("成功返回 CRM 详情链接", t, func() {
		rec := mockRiskClauseTplResp()
		var contractNo string
		mockey.Mock((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
			if key == "ContractNo" {
				return "C-1"
			}
			return ""
		}).Build()
		mockey.Mock(larkc.GenCRMDetailURL).To(func(ctx context.Context, no string) string {
			contractNo = no
			return "https://crm.example/detail/C-1"
		}).Build()

		(&innerToolHandler{}).TestGenCRMDetailURL20210101(context.Background(), &app.RequestContext{})

		convey.So(contractNo, convey.ShouldEqual, "C-1")
		convey.So(rec.body, convey.ShouldEqual, "https://crm.example/detail/C-1")
	})
}

func Test_innerToolHandler_RefreshCouponAppendConfig20210101(t *testing.T) {
	t.Run("case config nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var response interface{}
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("valid_token").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})

			convey.So(response, convey.ShouldBeNil)
		})
	})

	t.Run("case token invalid", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var response interface{}
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("invalid_token").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})

			convey.So(response, convey.ShouldBeNil)
		})
	})

	t.Run("case invalid startID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("valid_token").
				When(func(key string) bool { return key == "startID" }).Return("invalid").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid startID"))
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("case invalid batchSize", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("valid_token").
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("invalid").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("case service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockService := &Mock_DataRefreshService_RefreshCouponAppendConfig20210101{}
			serviceErr := conmmonerror.New("refresh failed")

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("valid_token").
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_RefreshCouponAppendConfig20210101).RefreshCouponAppendConfig).
				Return(serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceErr.Error()))
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockService := &Mock_DataRefreshService_RefreshCouponAppendConfig20210101{}
			var gotStartID int64
			var gotBatchSize int
			var response interface{}

			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == _const.HeaderToolToken }).Return("valid_token").
				When(func(key string) bool { return key == "startID" }).Return("100").
				When(func(key string) bool { return key == "batchSize" }).Return("10").
				Build()
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_RefreshCouponAppendConfig20210101).RefreshCouponAppendConfig).
				To(func(_ *Mock_DataRefreshService_RefreshCouponAppendConfig20210101, _ context.Context, startID int64, batchSize int) error {
					gotStartID = startID
					gotBatchSize = batchSize
					return nil
				}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfig20210101(context.Background(), &app.RequestContext{})

			convey.So(gotStartID, convey.ShouldEqual, int64(100))
			convey.So(gotBatchSize, convey.ShouldEqual, 10)
			convey.So(response, convey.ShouldResemble, map[string]interface{}{
				"message": "success",
			})
		})
	})
}

type Mock_DataRefreshService_RefreshCouponAppendConfig20210101 struct {
	datarefresh.DataRefreshService
}

func Test_innerToolHandler_RefreshCouponAppendConfigByContractNo20210101(t *testing.T) {
	t.Run("case_config_nil", func(t *testing.T) {
		mockey.PatchConvey("case_config_nil", t, func() {
			var response interface{}
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")

			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfigByContractNo20210101(context.Background(), c)

			convey.So(response, convey.ShouldBeNil)
		})
	})

	t.Run("case_token_invalid", func(t *testing.T) {
		mockey.PatchConvey("case_token_invalid", t, func() {
			var response interface{}
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, "invalid_token")

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfigByContractNo20210101(context.Background(), c)

			convey.So(response, convey.ShouldBeNil)
		})
	})

	t.Run("case missing contractNo", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrParamParseFail.WithArgs("invalid contractNo"))
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfigByContractNo20210101(context.Background(), c)
		})
	})

	t.Run("case service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockService := &Mock_DataRefreshService_RefreshCouponAppendConfig20210101{}
			serviceErr := conmmonerror.New("refresh failed")
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
			c.QueryArgs().Set("contractNo", "CN-001")

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_RefreshCouponAppendConfig20210101).RefreshCouponAppendConfigByContractNo).
				Return(serviceErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs(serviceErr.Error()))
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfigByContractNo20210101(context.Background(), c)
		})
	})

	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockService := &Mock_DataRefreshService_RefreshCouponAppendConfig20210101{}
			var gotContractNo string
			var response interface{}
			c := &app.RequestContext{}
			c.QueryArgs().Set(_const.HeaderToolToken, "valid_token")
			c.QueryArgs().Set("ContractNo", " CN-001 ")

			mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{
				ProductsApp: conf.ProductsApp{
					Auths: "valid_token",
				},
			}).Build()
			mockey.Mock(datarefresh.NewDataRefreshService).Return(mockService).Build()
			mockey.Mock((*Mock_DataRefreshService_RefreshCouponAppendConfig20210101).RefreshCouponAppendConfigByContractNo).
				To(func(_ *Mock_DataRefreshService_RefreshCouponAppendConfig20210101, _ context.Context, contractNo string) error {
					gotContractNo = contractNo
					return nil
				}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				response = result
			}).Build()

			h := &innerToolHandler{}
			h.RefreshCouponAppendConfigByContractNo20210101(context.Background(), c)

			convey.So(gotContractNo, convey.ShouldEqual, "CN-001")
			convey.So(response, convey.ShouldResemble, map[string]interface{}{
				"message":    "success",
				"contractNo": "CN-001",
			})
		})
	})
}

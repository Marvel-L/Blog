package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/contractsettlement"
	"volc_contract_process/pkg/errors"
)

type innerTOPSettlementHandler struct {
	base
	settlementService contractsettlement.SettlementService
}

func NewInnerTOPSettlementHandler() vhertz.ActionHandler {
	return &innerTOPSettlementHandler{
		settlementService: contractsettlement.NewSettlementService(),
	}
}

// GetSettlementInfo20200101 查询合同结算信息
func (h *innerTOPSettlementHandler) GetSettlementInfo20200101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	if len(contractNo) == 0 {
		logs.CtxError(ctx, "GetSettlementInfoParamMissing, param=contractNo")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		logs.CtxError(ctx, "GetSettlementInfo_FindLastByNoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("FindMetaFail"))
		return
	}
	if meta == nil {
		logs.CtxError(ctx, "GetSettlementInfo_ContractMetaIsNil, ContractNo: %s", contractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("MetaIsNil"))
		return
	}

	info, err := h.settlementService.BuildSettlementInfo(ctx, meta)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("BuildSettlementInfoFail"))
		return
	}

	vhertz.DoResponse(ctx, c, info)
}

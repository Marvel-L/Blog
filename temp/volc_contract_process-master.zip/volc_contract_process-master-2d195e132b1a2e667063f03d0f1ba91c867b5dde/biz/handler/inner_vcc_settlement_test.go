package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelsettlement"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractsettlement"
	"volc_contract_process/pkg/errors"
)

type fakeSettlementService struct {
	contractsettlement.SettlementService
	submitFn   func(context.Context, modelsettlement.SubmitSettlementReq) (*modelsettlement.SubmitSettlementResp, errors.APIError)
	balanceFn  func(context.Context, modelsettlement.ListBalanceForCreditReq) ([]*bizmodels.BalanceForCreditData, errors.APIError)
	templateFn func(context.Context, modelsettlement.GetSettlementTemplateReq) (*modelsettlement.GetSettlementTemplateResp, error)
}

func (f *fakeSettlementService) SubmitContractSettlementV1(ctx context.Context, req modelsettlement.SubmitSettlementReq) (*modelsettlement.SubmitSettlementResp, errors.APIError) {
	if f.submitFn != nil {
		return f.submitFn(ctx, req)
	}
	return &modelsettlement.SubmitSettlementResp{ContractNo: req.ContractNo}, nil
}
func (f *fakeSettlementService) SaveSettlementLines(ctx context.Context, tx *gorm.DB, meta *model.ContractMetaDB, settlementLines bizmodels.SettlementLines) (insertSettlementList, updateSettlementList, deleteSettlementList []*model.ContractSettlementDB, err error) {
	return nil, nil, nil, nil
}
func (f *fakeSettlementService) ListBalanceForCredit(ctx context.Context, req modelsettlement.ListBalanceForCreditReq) ([]*bizmodels.BalanceForCreditData, errors.APIError) {
	if f.balanceFn != nil {
		return f.balanceFn(ctx, req)
	}
	return []*bizmodels.BalanceForCreditData{{AccountID: 100}}, nil
}
func (f *fakeSettlementService) GetSettlementTemplate(ctx context.Context, quoteBizInfo *bizmodels.QuoteBizInfo) ([]string, error) {
	return nil, nil
}
func (f *fakeSettlementService) GetNoCreditAndPeriodSettlementTemplate(ctx context.Context, req modelsettlement.GetSettlementTemplateReq) (*modelsettlement.GetSettlementTemplateResp, error) {
	if f.templateFn != nil {
		return f.templateFn(ctx, req)
	}
	return &modelsettlement.GetSettlementTemplateResp{}, nil
}
func (f *fakeSettlementService) FixContractSettlementLine(ctx context.Context, contractNo string) error {
	return nil
}
func (f *fakeSettlementService) BuildSettlementInfo(ctx context.Context, meta *model.ContractMetaDB) (*bizmodels.SettlementInfo, errors.APIError) {
	return nil, nil
}
func (f *fakeSettlementService) BuildQuoteSettlementInfo(ctx context.Context, quoteInfo *bizmodels.QuoteBizInfo, metaDB *model.ContractMetaDB) (*bizmodels.SettlementInfo, errors.APIError) {
	return nil, nil
}

func TestNewInnerVCCSettlementHandler(t *testing.T) {
	mockey.PatchConvey("创建结算 handler", t, func() { convey.So(NewInnerVCCSettlementHandler(), convey.ShouldNotBeNil) })
}

func TestInnerVCCSettlementHandlerSubmitContractSettlement20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
			(&innerVCCSettlementHandler{settlementService: &fakeSettlementService{}}).SubmitContractSettlement20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功返回提交结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsettlement.SubmitSettlementReq).ContractNo = "C-1"
				return nil
			}).Build()
			(&innerVCCSettlementHandler{settlementService: &fakeSettlementService{}}).SubmitContractSettlement20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestInnerVCCSettlementHandlerListBalanceForCredit20210101(t *testing.T) {
	mockey.PatchConvey("成功返回余额信息", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
		(&innerVCCSettlementHandler{settlementService: &fakeSettlementService{}}).ListBalanceForCredit20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerVCCSettlementHandlerListNoCreditAndPeriodSettlementTemplate20210101(t *testing.T) {
	mockey.PatchConvey("service错误包装为内部错误", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
		(&innerVCCSettlementHandler{settlementService: &fakeSettlementService{templateFn: func(ctx context.Context, req modelsettlement.GetSettlementTemplateReq) (*modelsettlement.GetSettlementTemplateResp, error) {
			return nil, stderrors.New("template")
		}}}).ListNoCreditAndPeriodSettlementTemplate20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.errorCalled, convey.ShouldBeTrue)
		convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
	})
}

package handler

import (
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/support/metacommodity"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	hertz_ext_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

// MockContractMetaDao is a mock for the dal.ContractMetaDao interface.
type MockContractMetaDao struct {
	dal.ContractMetaDao
}

// MockCommodityService is a mock for the metacommodity.Service interface.
type MockCommodityService struct {
	metacommodity.Service
}

type fakeInnerTOPCommodityService struct {
	metacommodity.Service
	listForInvoiceFn func(context.Context, string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, pkg_errors.APIError)
	getInvoiceFn     func(context.Context, *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, pkg_errors.APIError)
	buildManageFn    func(context.Context, *gorm.DB, int64, bool, string) (*bizmodels.ManageInfo, error)
}

func (f *fakeInnerTOPCommodityService) ListContractForInvoiceProject(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, pkg_errors.APIError) {
	return f.listForInvoiceFn(ctx, invoiceProject)
}

func (f *fakeInnerTOPCommodityService) GetInvoiceByContractAndProduct(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, pkg_errors.APIError) {
	return f.getInvoiceFn(ctx, req)
}

func (f *fakeInnerTOPCommodityService) BuildManageInfo(ctx context.Context, tx *gorm.DB, volcContractId int64, needCommodity bool, relateQuoteNo string) (*bizmodels.ManageInfo, error) {
	return f.buildManageFn(ctx, tx, volcContractId, needCommodity, relateQuoteNo)
}

type fakeInnerTOPCommodityContractMetaDao struct {
	dal.ContractMetaDao
	findLastByNoFn func(context.Context, *gorm.DB, string) (*model.ContractMetaDB, error)
}

func (f *fakeInnerTOPCommodityContractMetaDao) FindLastByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	return f.findLastByNoFn(ctx, tx, contractNo)
}

func Test_innerTOPCommodityHandler_GetManageInfo20200101_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestinnerTOPCommodityHandler_GetManageInfo20200101", t, func() {
		h := &innerTOPCommodityHandler{
			commodityService: &MockCommodityService{},
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("success", func() {
			// 场景描述：
			// 模拟成功获取管理信息的完整流程。
			// 构造数据：
			// - mockReq: 一个有效的 GetManageInfoReq 请求。
			// - mockMeta: 一个有效的 ContractMetaDB 数据库记录。
			// - mockInfo: 一个有效的 ManageInfo 业务模型。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 成功绑定请求参数。
			// 2. dal.NewContractMetaDao().FindLastByNo 成功找到并返回合同元数据。
			// 3. h.commodityService.BuildManageInfo 成功构建并返回管理信息。
			// 4. vhertz.DoResponse 被调用以返回成功响应。

			mockReq := modelcommodity.GetManageInfoReq{
				ContractNo:    "TEST_CONTRACT_NO",
				NeedCommodity: true,
			}
			mockMeta := &model.ContractMetaDB{
				BaseDB:        model.BaseDB{Id: 1},
				RelateQuoteNo: "TEST_QUOTE_NO",
			}
			mockInfo := &bizmodels.ManageInfo{
				PaymentType: "Cash",
			}

			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p, ok := obj.(*modelcommodity.GetManageInfoReq)
				if ok {
					*p = mockReq
				}
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(mockMeta, nil).Build()
			mockey.Mock((*MockCommodityService).BuildManageInfo).Return(mockInfo, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, mockInfo)
			}).Build()

			h.GetManageInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("bind and validate fail", func() {
			// 场景描述：
			// 模拟请求参数绑定失败的场景。
			// 构造数据：
			// - bindErr: 一个表示绑定失败的错误。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 返回错误。
			// 2. 函数应记录错误日志。
			// 3. vhertz.ErrorResp 被调用以返回参数解析失败的错误响应。
			// 4. 函数提前返回。

			bindErr := errors.New("bind error")
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(bindErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, pkg_errors.ErrParamParseFail)
			}).Build()

			h.GetManageInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("find last by no fail", func() {
			// 场景描述：
			// 模拟数据库查询合同元数据失败的场景。
			// 构造数据：
			// - dbErr: 一个表示数据库查询失败的错误。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 成功。
			// 2. dal.NewContractMetaDao().FindLastByNo 返回错误。
			// 3. 函数应记录错误日志。
			// 4. vhertz.ErrorResp 被调用以返回通用错误响应。
			// 5. 函数提前返回。

			dbErr := errors.New("db error")
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, dbErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, "ErrorCommon")
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "FindMetaFail")
			}).Build()

			h.GetManageInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("contract meta is nil", func() {
			// 场景描述：
			// 模拟未找到合同元数据的场景。
			// 构造数据：
			// - FindLastByNo 返回 (nil, nil)。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 成功。
			// 2. dal.NewContractMetaDao().FindLastByNo 返回 (nil, nil)，表示记录不存在。
			// 3. 函数应记录错误日志。
			// 4. vhertz.ErrorResp 被调用以返回元数据为空的错误响应。
			// 5. 函数提前返回。

			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, "ErrorCommon")
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "MetaIsNil")
			}).Build()

			h.GetManageInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("build manage info fail", func() {
			// 场景描述：
			// 模拟构建管理信息失败的场景。
			// 构造数据：
			// - mockMeta: 一个有效的 ContractMetaDB 数据库记录。
			// - buildErr: 一个表示构建失败的错误。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 成功。
			// 2. dal.NewContractMetaDao().FindLastByNo 成功找到并返回合同元数据。
			// 3. h.commodityService.BuildManageInfo 返回错误。
			// 4. vhertz.ErrorResp 被调用以返回构建失败的错误响应。
			// 5. 函数提前返回。

			mockMeta := &model.ContractMetaDB{
				BaseDB:        model.BaseDB{Id: 1},
				RelateQuoteNo: "TEST_QUOTE_NO",
			}
			buildErr := errors.New("build error")
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(mockMeta, nil).Build()
			mockey.Mock((*MockCommodityService).BuildManageInfo).Return(nil, buildErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, "ErrorCommon")
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "BuildManageInfoFail")
			}).Build()

			h.GetManageInfo20200101(context.Background(), c)
		})
	})
}

func Test_innerTOPCommodityHandler_ListContractForInvoiceProject20200101_BitsUTGen(t *testing.T) {
	// MockCommodityService is a mock type for the metacommodity.Service interface.
	type MockCommodityService struct {
		metacommodity.Service
	}

	mockey.PatchConvey("Test innerTOPCommodityHandler ListContractForInvoiceProject20200101", t, func() {
		// Common setup for all test cases
		h := &innerTOPCommodityHandler{
			commodityService: &MockCommodityService{},
		}
		c := &app.RequestContext{}

		mockey.PatchConvey("should return missing parameter error when InvoiceProject is empty", func() {
			// 场景描述：
			// 构造数据：构造一个 app.RequestContext，并 mock 其 Query 方法返回一个空字符串。
			// 逻辑链路：
			// 1. 函数调用 c.Query("InvoiceProject")，返回空字符串。
			// 2. 代码进入 if len(invoiceProject) == 0 分支，判断为 true。
			// 3. 调用 vhertz.ErrorResp，并传入 pkg_errors.ErrMissingParam 错误。
			// 4. 函数返回。

			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool {
				return key == "InvoiceProject"
			}).Return("").Build()

			var capturedError vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), c)

			convey.So(capturedError, convey.ShouldNotBeNil)
			convey.So(capturedError.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
			convey.So(capturedError.GetArgs(), convey.ShouldResemble, []interface{}{"InvoiceProject"})
		})

		mockey.PatchConvey("should return error when commodityService.ListContractForInvoiceProject fails", func() {
			// 场景描述：
			// 构造数据：构造 app.RequestContext，Query 返回有效值 "test-project"。mock commodityService 返回一个自定义错误。
			// 逻辑链路：
			// 1. 函数调用 c.Query("InvoiceProject")，返回 "test-project"。
			// 2. if len(invoiceProject) == 0 检查不通过。
			// 3. 调用 h.commodityService.ListContractForInvoiceProject，返回一个预设的错误。
			// 4. 代码进入 if err != nil 分支，判断为 true。
			// 5. 调用 vhertz.ErrorResp，并传入从 service 返回的错误。
			// 6. 函数返回。

			invoiceProject := "test-project"
			serviceErr := pkg_errors.NewErr("ServiceError", "service failed", 500)

			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool {
				return key == "InvoiceProject"
			}).Return(invoiceProject).Build()
			mockey.Mock((*MockCommodityService).ListContractForInvoiceProject).Return(nil, serviceErr).Build()

			var capturedError vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), c)

			convey.So(capturedError, convey.ShouldEqual, serviceErr)
		})

		mockey.PatchConvey("should succeed and call DoResponse with the correct response", func() {
			// 场景描述：
			// 构造数据：构造 app.RequestContext，Query 返回有效值 "test-project"。mock commodityService 返回成功结果。
			// 逻辑链路：
			// 1. 函数调用 c.Query("InvoiceProject")，返回 "test-project"。
			// 2. if len(invoiceProject) == 0 检查不通过。
			// 3. 调用 h.commodityService.ListContractForInvoiceProject，返回成功的响应和 nil 错误。
			// 4. if err != nil 检查不通过。
			// 5. 调用 vhertz.DoResponse，并传入从 service 返回的响应。
			// 6. 函数返回。

			invoiceProject := "test-project"
			expectedResp := &modelcommodity.OpenMetaListForInvoiceProjectResp{
				List: []*modelcommodity.MetaContractInfo{},
			}

			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool {
				return key == "InvoiceProject"
			}).Return(invoiceProject).Build()
			mockey.Mock((*MockCommodityService).ListContractForInvoiceProject).When(func(innerCtx context.Context, proj string) bool {
				return proj == invoiceProject
			}).Return(expectedResp, nil).Build()

			var capturedResp interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), c)

			convey.So(capturedResp, convey.ShouldEqual, expectedResp)
		})
	})
}

func Test_innerTOPCommodityHandler_GetInvoiceByContractAndProduct20200101_BitsUTGen(t *testing.T) {
	// MockCommodityService is a mock type for the metacommodity.Service interface.
	type MockCommodityService struct {
		metacommodity.Service
	}

	mockey.PatchConvey("Test GetInvoiceByContractAndProduct20200101", t, func() {
		// Initialize the handler with the mock service.
		h := &innerTOPCommodityHandler{
			commodityService: &MockCommodityService{},
		}
		// Create a dummy app.RequestContext for the handler.
		c := &app.RequestContext{}

		mockey.PatchConvey("should return parameter parse error when binding fails", func() {
			// 场景描述：
			// 构造数据：构造一个绑定参数失败的场景。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 方法返回一个错误。
			// 2. 函数将捕获此错误，并调用 vhertz.ErrorResp 返回参数解析失败的错误。
			// 3. commodityService.GetInvoiceByContractAndProduct 不会被调用。
			// 4. vhertz.DoResponse 不会被调用。

			// Mock the binding function to return an error.
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind failed")).Build()

			// Mock the error response function to verify it's called with the correct error.
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, pkg_errors.ErrParamParseFail)
			}).Build()

			// Call the target function.
			h.GetInvoiceByContractAndProduct20200101(context.Background(), c)
		})

		mockey.PatchConvey("should return service error when commodity service fails", func() {
			// 场景描述：
			// 构造数据：构造一个底层服务调用失败的场景。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 方法成功返回 nil。
			// 2. commodityService.GetInvoiceByContractAndProduct 方法返回一个自定义的 API 错误。
			// 3. 函数将捕获此错误，并调用 vhertz.ErrorResp 返回该错误。
			// 4. vhertz.DoResponse 不会被调用。

			// Prepare a mock error from the service.
			mockServiceErr := pkg_errors.ErrInternalDefError

			// Mock the binding function to succeed.
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()

			// Mock the commodity service to return an error.
			mockey.Mock((*MockCommodityService).GetInvoiceByContractAndProduct).Return(nil, mockServiceErr).Build()

			// Mock the error response function to verify it's called with the service error.
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldResemble, mockServiceErr)
			}).Build()

			// Call the target function.
			h.GetInvoiceByContractAndProduct20200101(context.Background(), c)
		})

		mockey.PatchConvey("should return success response when everything is ok", func() {
			// 场景描述：
			// 构造数据：构造一个所有调用都成功的 happy path 场景。
			// 逻辑链路：
			// 1. hertz_ext_binding.BindAndValidate 方法成功返回 nil。
			// 2. commodityService.GetInvoiceByContractAndProduct 方法成功返回响应数据和 nil 错误。
			// 3. 函数将调用 vhertz.DoResponse 返回成功的响应数据。
			// 4. vhertz.ErrorResp 不会被调用。

			// Prepare a mock successful response from the service.
			mockResp := &modelcommodity.GetInvoiceByContractAndProductResp{
				InvoiceProjectCode: "PROJ-123",
				TradeProduct:       "PROD-456",
				TaxRatio:           "0.06",
			}

			// Mock the binding function to succeed.
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()

			// Mock the commodity service to return a successful response.
			mockey.Mock((*MockCommodityService).GetInvoiceByContractAndProduct).Return(mockResp, nil).Build()

			// Mock the success response function to verify it's called with the correct data.
			mockey.Mock(vhertz.DoResponse).To(func(ctx *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, mockResp)
			}).Build()

			// Call the target function.
			h.GetInvoiceByContractAndProduct20200101(context.Background(), c)
		})
	})
}

func TestNewInnerTOPCommodityHandler_BitsUTGen(t *testing.T) {
	// Mock struct for the metacommodity.Service interface.
	// It's used to isolate the handler from the actual service implementation during testing.
	type mockCommodityService struct {
		metacommodity.Service
	}

	mockey.PatchConvey("TestNewInnerTOPCommodityHandler", t, func() {
		mockey.PatchConvey("should correctly initialize and return an innerTOPCommodityHandler", func() {
			// 场景描述:
			// 验证 NewInnerTOPCommodityHandler 函数是否能成功创建一个 handler 实例，并正确初始化其依赖的 service。
			// 构造数据:
			// - 创建一个 metacommodity.Service 接口的 mock 实现实例。
			// 逻辑链路:
			// 1. Mock `metacommodity.NewService()` 函数，使其在被调用时返回预先定义的 mock service 实例。
			// 2. 调用目标函数 `NewInnerTOPCommodityHandler()`。
			// 3. 断言返回的结果不为 nil。
			// 4. 断言返回结果的底层具体类型是 `*innerTOPCommodityHandler`。
			// 5. 断言 handler 实例中的 `commodityService` 字段确实是被 mock 的 service 实例，确保依赖注入正确。

			mockSvc := &mockCommodityService{}
			mockey.Mock(metacommodity.NewService).Return(mockSvc).Build()

			// 调用目标函数
			handler := NewInnerTOPCommodityHandler()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			concreteHandler, ok := handler.(*innerTOPCommodityHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(concreteHandler.commodityService, convey.ShouldEqual, mockSvc)
		})
	})
}

func Test_innerTOPCommodityHandler_ListContractForInvoiceProject20200101(t *testing.T) {
	t.Run("InvoiceProject为空返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{}}
			mockey.Mock((*app.RequestContext).Query).Return("").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "InvoiceProject")
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("service返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedErr := pkg_errors.ErrInternalError
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{listForInvoiceFn: func(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, pkg_errors.APIError) {
				convey.So(invoiceProject, convey.ShouldEqual, "project-1")
				return nil, expectedErr
			}}}
			mockey.Mock((*app.RequestContext).Query).Return("project-1").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, expectedErr)
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("service成功时返回合同列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedResp := &modelcommodity.OpenMetaListForInvoiceProjectResp{List: []*modelcommodity.MetaContractInfo{{ContractNo: "CNO-1", Version: 1}}}
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{listForInvoiceFn: func(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, pkg_errors.APIError) {
				convey.So(invoiceProject, convey.ShouldEqual, "project-2")
				return expectedResp, nil
			}}}
			mockey.Mock((*app.RequestContext).Query).Return("project-2").Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, expectedResp)
			}).Build()

			h.ListContractForInvoiceProject20200101(context.Background(), &app.RequestContext{})
		})
	})
}

func Test_innerTOPCommodityHandler_GetInvoiceByContractAndProduct20200101(t *testing.T) {
	t.Run("参数绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.GetInvoiceByContractAndProduct20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("service返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedErr := pkg_errors.ErrInternalError
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{getInvoiceFn: func(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, pkg_errors.APIError) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CNO-2")
				convey.So(req.Product, convey.ShouldEqual, "ecs")
				return nil, expectedErr
			}}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractAndProductReq)
				req.ContractNo = "CNO-2"
				req.ContractVersion = 1
				req.Product = "ecs"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, expectedErr)
			}).Build()

			h.GetInvoiceByContractAndProduct20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("service成功时返回开票项目", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedResp := &modelcommodity.GetInvoiceByContractAndProductResp{InvoiceProjectCode: "IPC-1", TradeProduct: "ecs", TaxRatio: "0.06"}
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{getInvoiceFn: func(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, pkg_errors.APIError) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CNO-3")
				convey.So(req.Product, convey.ShouldEqual, "ecs")
				return expectedResp, nil
			}}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractAndProductReq)
				req.ContractNo = "CNO-3"
				req.ContractVersion = 2
				req.Product = "ecs"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, expectedResp)
			}).Build()

			h.GetInvoiceByContractAndProduct20200101(context.Background(), &app.RequestContext{})
		})
	})
}

func Test_innerTOPCommodityHandler_GetManageInfo20200101(t *testing.T) {
	t.Run("参数绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.GetManageInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("查询合同元数据失败返回FindMetaFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetManageInfoReq)
				req.ContractNo = "CNO-4"
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPCommodityContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				convey.So(contractNo, convey.ShouldEqual, "CNO-4")
				return nil, errors.New("dao failed")
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "FindMetaFail")
			}).Build()

			h.GetManageInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("合同元数据为空返回MetaIsNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetManageInfoReq)
				req.ContractNo = "CNO-5"
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPCommodityContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				convey.So(contractNo, convey.ShouldEqual, "CNO-5")
				return nil, nil
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "MetaIsNil")
			}).Build()

			h.GetManageInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("构建管理信息失败返回BuildManageInfoFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1001}, RelateQuoteNo: "Q-1"}
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{buildManageFn: func(ctx context.Context, tx *gorm.DB, volcContractId int64, needCommodity bool, relateQuoteNo string) (*bizmodels.ManageInfo, error) {
				convey.So(volcContractId, convey.ShouldEqual, int64(1001))
				convey.So(needCommodity, convey.ShouldBeTrue)
				convey.So(relateQuoteNo, convey.ShouldEqual, "Q-1")
				return nil, errors.New("build failed")
			}}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetManageInfoReq)
				req.ContractNo = "CNO-6"
				req.NeedCommodity = true
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPCommodityContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				return meta, nil
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "BuildManageInfoFail")
			}).Build()

			h.GetManageInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("构建管理信息成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1002}, RelateQuoteNo: "Q-2"}
			info := &bizmodels.ManageInfo{PaymentType: "Cash"}
			h := &innerTOPCommodityHandler{commodityService: &fakeInnerTOPCommodityService{buildManageFn: func(ctx context.Context, tx *gorm.DB, volcContractId int64, needCommodity bool, relateQuoteNo string) (*bizmodels.ManageInfo, error) {
				convey.So(volcContractId, convey.ShouldEqual, int64(1002))
				convey.So(needCommodity, convey.ShouldBeFalse)
				convey.So(relateQuoteNo, convey.ShouldEqual, "Q-2")
				return info, nil
			}}}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetManageInfoReq)
				req.ContractNo = "CNO-7"
				req.NeedCommodity = false
				return nil
			}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPCommodityContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				return meta, nil
			}}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, info)
			}).Build()

			h.GetManageInfo20200101(context.Background(), &app.RequestContext{})
		})
	})
}

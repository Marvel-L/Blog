package handler

import (
	"context"
	"errors"
	"sync"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/fresh_seal"
	"volc_contract_process/pkg/const"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/protocol"
	hertz_ext_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

type fakeFreshSealApprovalService struct {
	createFn              func(context.Context, *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError)
	detailFn              func(context.Context, *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError)
	listFn                func(context.Context, *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError)
	batchUpdateExpressFn  func(context.Context, *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError
	listOperationRecordFn func(context.Context, *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError)
	exportFn              func(context.Context, *bizmodels.FreshSealListParam) pkg_errors.APIError
}

func (f *fakeFreshSealApprovalService) CreateApproval(ctx context.Context, param *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError) {
	if f.createFn != nil {
		return f.createFn(ctx, param)
	}
	return nil, nil
}

func (f *fakeFreshSealApprovalService) GetApprovalDetail(ctx context.Context, param *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError) {
	if f.detailFn != nil {
		return f.detailFn(ctx, param)
	}
	return nil, nil
}

func (f *fakeFreshSealApprovalService) GetApprovalList(ctx context.Context, param *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError) {
	if f.listFn != nil {
		return f.listFn(ctx, param)
	}
	return nil, nil
}

func (f *fakeFreshSealApprovalService) BatchUpdateExpressData(ctx context.Context, param *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
	if f.batchUpdateExpressFn != nil {
		return f.batchUpdateExpressFn(ctx, param)
	}
	return nil
}

func (f *fakeFreshSealApprovalService) ListOperationRecord(ctx context.Context, param *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError) {
	if f.listOperationRecordFn != nil {
		return f.listOperationRecordFn(ctx, param)
	}
	return nil, nil
}

func (f *fakeFreshSealApprovalService) Export(ctx context.Context, param *bizmodels.FreshSealListParam) pkg_errors.APIError {
	if f.exportFn != nil {
		return f.exportFn(ctx, param)
	}
	return nil
}

func (f *fakeFreshSealApprovalService) CanApplyFreshSeal(ctx context.Context, archivedStatus int, freshSealApprovalNo string, sealAccountIDs string, accountId string, activeStatus int) (bool, []string) {
	return false, nil
}

func Test_innerFreshSealHandler_ListFreshSeal20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "Limit")
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := pkg_errors.ErrInvalidParam.WithArgs("ServiceFail")
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{listFn: func(ctx context.Context, param *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError) {
				convey.So(param.Limit, convey.ShouldEqual, 10)
				convey.So(param.Offset, convey.ShouldEqual, 0)
				convey.So(param.Status, convey.ShouldEqual, "1")
				return nil, svcErr
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.Limit = 10
				p.Offset = 0
				p.Status = "1"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务成功返回列表响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.FreshSealListResp{Total: 1, Limit: 10, Offset: 0}
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{listFn: func(ctx context.Context, param *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError) {
				convey.So(param.AccountID, convey.ShouldEqual, "100")
				return resp, nil
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.Limit = 10
				p.Offset = 0
				p.AccountID = "100"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})
}

func Test_innerFreshSealHandler_BatchUpdateExpressDataFreshSeal20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "CurrentOperator")
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误并用ctx操作人覆盖请求操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := pkg_errors.ErrInvalidParam.WithArgs("BatchFail")
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{batchUpdateExpressFn: func(ctx context.Context, param *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
				convey.So(param.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				convey.So(param.ExpressDataList, convey.ShouldHaveLength, 1)
				return svcErr
			}}}
			c := &app.RequestContext{}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com")
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealBatchUpdateExpressParam)
				p.CurrentOperator = "request@test.com"
				p.ExpressDataList = []*bizmodels.ExpressData{{ApplyNo: "A1", ExpressCompany: "123", ExpressNo: "E1"}}
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(ctx, c)
		})
	})

	t.Run("服务成功返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{batchUpdateExpressFn: func(ctx context.Context, param *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
				convey.So(param.CurrentOperator, convey.ShouldEqual, "request@test.com")
				return nil
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealBatchUpdateExpressParam)
				p.CurrentOperator = "request@test.com"
				p.ExpressDataList = []*bizmodels.ExpressData{{ApplyNo: "A2", ExpressCompany: "456", ExpressNo: "E2"}}
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})
}

func Test_innerFreshSealHandler_ExportFreshSeal20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ExportFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("异步导出成功立即返回成功响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var wg sync.WaitGroup
			wg.Add(1)
			var capturedOperator string
			var capturedLimit int
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{exportFn: func(ctx context.Context, param *bizmodels.FreshSealListParam) pkg_errors.APIError {
				defer wg.Done()
				capturedOperator = param.CurrentOperator
				capturedLimit = param.Limit
				return nil
			}}}
			c := &app.RequestContext{}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com")
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.CurrentOperator = "request@test.com"
				p.Limit = 10
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.ExportFreshSeal20210101(ctx, c)
			wg.Wait()
			convey.So(capturedOperator, convey.ShouldEqual, "employee@test.com")
			convey.So(capturedLimit, convey.ShouldEqual, 10)
		})
	})

	t.Run("异步导出失败仍返回成功响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var wg sync.WaitGroup
			wg.Add(1)
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{exportFn: func(ctx context.Context, param *bizmodels.FreshSealListParam) pkg_errors.APIError {
				defer wg.Done()
				return pkg_errors.ErrInvalidParam.WithArgs("ExportFail")
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.CurrentOperator = "request@test.com"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.ExportFreshSeal20210101(context.Background(), c)
			wg.Wait()
		})
	})
}

func Test_innerFreshSealHandler_ListOperationRecordFreshSeal20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回缺少ApplyNo", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ApplyNo")
			}).Build()

			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := pkg_errors.ErrInvalidParam.WithArgs("RecordFail")
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{listOperationRecordFn: func(ctx context.Context, param *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError) {
				convey.So(param.ApplyNo, convey.ShouldEqual, "APP-1")
				return nil, svcErr
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListOperationRecordParam)
				p.ApplyNo = "APP-1"
				p.Limit = 10
				p.Offset = 0
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务成功返回操作记录", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &bizmodels.FreshSealListOperationRecordResp{Total: 1, Limit: 10, Offset: 0}
			h := &innerFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{listOperationRecordFn: func(ctx context.Context, param *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError) {
				convey.So(param.ApplyNo, convey.ShouldEqual, "APP-2")
				return resp, nil
			}}}
			c := &app.RequestContext{}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListOperationRecordParam)
				p.ApplyNo = "APP-2"
				p.Limit = 10
				p.Offset = 0
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) CanApplyFreshSeal(ctx context.Context, archivedStatus int, freshSealApprovalNo string, sealAccountIDs string, accountId string, activeStatus int) (bool, []string) {
	return false, nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) CreateApproval(ctx context.Context, param *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError) {
	return nil, nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) GetApprovalList(ctx context.Context, param *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError) {
	return nil, nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) ListOperationRecord(ctx context.Context, param *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError) {
	return nil, nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) Export(ctx context.Context, param *bizmodels.FreshSealListParam) pkg_errors.APIError {
	return nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) BatchUpdateExpressData(ctx context.Context, param *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
	return nil
}

func (m *Mock_FreshSealApprovalService_NewInnerFreshSealHandler) GetApprovalDetail(ctx context.Context, param *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError) {
	var resp bizmodels.FreshSealDetailResp
	return resp, nil
}

func Test_innerFreshSealHandler_BatchUpdateExpressDataFreshSeal20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与请求上下文
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 断言返回错误为参数解析错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回具体错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与请求上下文
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock参数绑定成功，但不填充任何字段，使校验失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()

			// 断言返回错误为缺失CurrentOperator
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "CurrentOperator")
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务调用失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与请求上下文，并设置EmployeeEmail覆盖操作人
			h := &innerFreshSealHandler{freshSealService: fresh_seal.NewFreshSealApprovalService()}
			c := &app.RequestContext{Request: protocol.Request{}}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "override@test.com")

			// mock绑定阶段填充有效参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealBatchUpdateExpressParam)
				p.CurrentOperator = "binding-op"
				p.ExpressDataList = []*bizmodels.ExpressData{
					{
						ApplyNo:        "A1",
						ExpressCompany: "123",
						ExpressNo:      "N1",
						Remark:         "ok",
					},
				}
				return nil
			}).Build()

			// 捕获传入服务的参数，断言操作人被覆盖
			var capturedParam *bizmodels.FreshSealBatchUpdateExpressParam
			svcMethod := mockey.GetMethod(h.freshSealService, "BatchUpdateExpressData")
			mockey.Mock(svcMethod).To(func(ctx context.Context, p *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
				capturedParam = p
				return pkg_errors.ErrInvalidParam.WithArgs("svc_error")
			}).Build()

			// 断言返回错误为服务层返回的错误，同时验证操作人覆盖逻辑
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(capturedParam, convey.ShouldNotBeNil)
				convey.So(capturedParam.CurrentOperator, convey.ShouldEqual, "override@test.com")
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(ctx, c)
		})
	})

	t.Run("调用成功返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与请求上下文
			h := &innerFreshSealHandler{freshSealService: fresh_seal.NewFreshSealApprovalService()}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock绑定阶段填充有效参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealBatchUpdateExpressParam)
				p.CurrentOperator = "op1"
				p.ExpressDataList = []*bizmodels.ExpressData{
					{
						ApplyNo:        "A2",
						ExpressCompany: "456",
						ExpressNo:      "N2",
						Remark:         "remark",
					},
				}
				return nil
			}).Build()

			// mock服务调用成功
			svcMethod := mockey.GetMethod(h.freshSealService, "BatchUpdateExpressData")
			mockey.Mock(svcMethod).Return(nil).Build()

			// 断言正常响应
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.BatchUpdateExpressDataFreshSeal20210101(context.Background(), c)
		})
	})
}

func Test_innerFreshSealHandler_ExportFreshSeal20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_Target{}}
			c := &app.RequestContext{}

			// 绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 断言错误返回
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ExportFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("绑定成功_员工邮箱为空_导出成功_返回成功响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_Target{}}
			c := &app.RequestContext{}

			// 参数绑定成功，同时设置请求操作者
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.FreshSealListParam); ok {
					p.CurrentOperator = "req_op"
				}
				return nil
			}).Build()

			// 导出成功的分支
			var wg sync.WaitGroup
			wg.Add(1)
			var receivedOperator string
			mockey.Mock((*Mock_FreshSealApprovalService_Target).Export).To(func(ms *Mock_FreshSealApprovalService_Target, ctx context.Context, p *bizmodels.FreshSealListParam) pkg_errors.APIError {
				receivedOperator = p.CurrentOperator
				wg.Done()
				return nil
			}).Build()

			// 成功响应
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.ExportFreshSeal20210101(context.Background(), c)
			wg.Wait()

			// 员工邮箱为空时应保留请求中的操作者
			convey.So(receivedOperator, convey.ShouldEqual, "req_op")
		})
	})

	t.Run("绑定成功_员工邮箱非空_导出失败_仍返回成功响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_Target{}}
			c := &app.RequestContext{}

			// 设置员工邮箱，覆盖请求操作者
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com")

			// 参数绑定成功，同时设置请求操作者
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.FreshSealListParam); ok {
					p.CurrentOperator = "req_op"
				}
				return nil
			}).Build()

			// 导出失败分支（错误只记录日志）
			var wg sync.WaitGroup
			wg.Add(1)
			var receivedOperator string
			mockey.Mock((*Mock_FreshSealApprovalService_Target).Export).To(func(ms *Mock_FreshSealApprovalService_Target, ctx context.Context, p *bizmodels.FreshSealListParam) pkg_errors.APIError {
				receivedOperator = p.CurrentOperator
				wg.Done()
				return pkg_errors.NewErr("ExportFail", "export failed", 500)
			}).Build()

			// 仍返回成功响应
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.ExportFreshSeal20210101(ctx, c)
			wg.Wait()

			// 员工邮箱非空时应覆盖为员工邮箱
			convey.So(receivedOperator, convey.ShouldEqual, "employee@test.com")
		})
	})
}

func Test_NewInnerFreshSealHandler_BitsUTGen(t *testing.T) {
	t.Run("成功返回处理器并注入服务", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造mock服务并打桩构造函数，避免真实依赖
			mockSvc := &Mock_FreshSealApprovalService_NewInnerFreshSealHandler{}
			mockey.MockUnsafe(fresh_seal.NewFreshSealApprovalService).Return(mockSvc).Build()

			// 调用目标函数
			h := NewInnerFreshSealHandler()

			// 断言返回非空、类型正确且注入的服务对象为mock
			convey.So(h, convey.ShouldNotBeNil)
			ih, ok := h.(*innerFreshSealHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ih.freshSealService, convey.ShouldNotBeNil)
			svcImpl, svcOk := ih.freshSealService.(*Mock_FreshSealApprovalService_NewInnerFreshSealHandler)
			convey.So(svcOk, convey.ShouldBeTrue)
			convey.So(svcImpl, convey.ShouldEqual, mockSvc)
		})
	})

	t.Run("返回值实现ActionHandler接口方法可调用", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 仍旧打桩服务构造函数，确保依赖可控
			mockey.MockUnsafe(fresh_seal.NewFreshSealApprovalService).Return(&Mock_FreshSealApprovalService_NewInnerFreshSealHandler{}).Build()

			// 获取处理器并断言接口可用
			h := NewInnerFreshSealHandler()
			convey.So(h, convey.ShouldNotBeNil)

			// 调用接口方法，验证实现无异常
			var action vhertz.ActionHandler = h
			action.OnRecover()
			convey.So(action, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerFreshSealHandler_ListOperationRecordFreshSeal20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101{}}
			c := &app.RequestContext{}

			// Mock参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			// 拦截错误响应，断言错误码为参数解析错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			// 调用待测方法
			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回缺少参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101{}}
			c := &app.RequestContext{}

			// Mock参数绑定成功但不赋值，使校验失败（缺少ApplyNo）
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			// 拦截错误响应并断言为缺少参数错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
			}).Build()

			// 调用待测方法
			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务查询失败返回业务错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101{}}
			c := &app.RequestContext{}

			// Mock参数绑定成功并设置为合法参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListOperationRecordParam)
				p.ApplyNo = "A001"
				p.Limit = 10
				p.Offset = 0
				return nil
			}).Build()

			// 构造服务返回错误
			svcErr := pkg_errors.NewErr("CustomErr", "custom error", 500)
			mockey.Mock((*Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101).ListOperationRecord).Return((*bizmodels.FreshSealListOperationRecordResp)(nil), svcErr).Build()

			// 拦截错误响应并断言
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, "CustomErr")
			}).Build()

			// 调用待测方法
			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务查询成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &innerFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101{}}
			c := &app.RequestContext{}

			// Mock参数绑定成功并设置为合法参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListOperationRecordParam)
				p.ApplyNo = "A001"
				p.Limit = 10
				p.Offset = 0
				return nil
			}).Build()

			// 构造服务成功返回
			resp := &bizmodels.FreshSealListOperationRecordResp{
				List:   nil,
				Total:  0,
				Limit:  10,
				Offset: 0,
			}
			mockey.Mock((*Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101).ListOperationRecord).Return(resp, nil).Build()

			// 拦截正常响应并断言
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			// 调用待测方法
			h.ListOperationRecordFreshSeal20210101(context.Background(), c)
		})
	})
}

func Test_innerFreshSealHandler_ListFreshSeal20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败，返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			// 模拟绑定参数失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			// 断言错误响应为参数解析错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数验证失败，返回非法参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFreshSealHandler{}
			c := &app.RequestContext{}
			// 模拟绑定成功但不填充默认值，使Limit为0触发校验失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			// 断言校验失败错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "Limit")
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务查询失败，返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler并注入接口Mock实例
			h := &innerFreshSealHandler{
				freshSealService: &Mock_FreshSealApprovalService_ListFreshSeal20210101{},
			}
			c := &app.RequestContext{}
			_ = context.Background()

			// 模拟绑定成功并填充合法参数，确保通过校验
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.Limit = 10
				p.Offset = 0
				p.Status = "1"
				p.AccountID = "100"
				return nil
			}).Build()

			// 模拟服务返回错误
			mockey.Mock((*Mock_FreshSealApprovalService_ListFreshSeal20210101).GetApprovalList).Return(nil, pkg_errors.ErrInvalidParam.WithArgs("ServiceFail")).Build()

			// 断言错误响应为服务错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ServiceFail")
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("查询成功，返回列表结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler并注入接口Mock实例
			h := &innerFreshSealHandler{
				freshSealService: &Mock_FreshSealApprovalService_ListFreshSeal20210101{},
			}
			c := &app.RequestContext{}
			_ = context.Background()

			// 模拟绑定成功并填充合法参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealListParam)
				p.Limit = 10
				p.Offset = 0
				p.Status = "1,2"
				p.AccountID = "123"
				return nil
			}).Build()

			// 准备服务返回数据
			resp := &bizmodels.FreshSealListResp{
				Total:  0,
				Limit:  10,
				Offset: 0,
			}
			mockey.Mock((*Mock_FreshSealApprovalService_ListFreshSeal20210101).GetApprovalList).Return(resp, nil).Build()

			// 断言DoResponse被调用且返回值正确
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListFreshSeal20210101(context.Background(), c)
		})
	})
}

type Mock_FreshSealApprovalService_ListFreshSeal20210101 struct {
	fresh_seal.FreshSealApprovalService
}

type Mock_FreshSealApprovalService_Target struct {
	fresh_seal.FreshSealApprovalService
}

type Mock_FreshSealApprovalService_ListOperationRecordFreshSeal20210101 struct {
	fresh_seal.FreshSealApprovalService
}

type Mock_FreshSealApprovalService_NewInnerFreshSealHandler struct{}

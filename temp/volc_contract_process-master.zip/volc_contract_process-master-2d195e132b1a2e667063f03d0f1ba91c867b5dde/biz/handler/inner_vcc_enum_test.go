package handler

import (
	"context"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
)

func TestNewInnerVCCEnumHandler(t *testing.T) {
	// 测试NewInnerVCCEnumHandler函数返回值不为空的场景
	t.Run("NewInnerVCCEnumHandlerReturnNotNull", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 运行被测函数
			actionHandlerRet := NewInnerVCCEnumHandler()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 业务函数NewInnerVCCEnumHandler返回一个innerVCCEnumHandler结构体指针，不会返回nil
			convey.So(actionHandlerRet, convey.ShouldResemble, &innerVCCEnumHandler{})
		})
	})
}

func Test_innerVCCEnumHandler_GetSpecialContractTypeEnum20210101(t *testing.T) {
	// 测试GetSpecialContractTypeItem函数返回nil的场景
	t.Run("GetSpecialContractTypeItemReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] len(getSpecialContractTypeItemRet1Mock) == 0
			mockey.Mock(conf.GetSpecialContractTypeItem).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()
			var specialContractTypeDisplayMappingMock map[string]string = nil
			mockey.MockValue(&_const.SpecialContractTypeDisplayMapping).To(specialContractTypeDisplayMappingMock)
			// 构造函数入参
			receiver := &innerVCCEnumHandler{}
			cTest := &app.RequestContext{}
			// 断言值由大模型生成，需要评估是否符合预期值!
			convey.So(func() { receiver.GetSpecialContractTypeEnum20210101(context.Background(), cTest) }, convey.ShouldNotPanic)
		})
	})
}

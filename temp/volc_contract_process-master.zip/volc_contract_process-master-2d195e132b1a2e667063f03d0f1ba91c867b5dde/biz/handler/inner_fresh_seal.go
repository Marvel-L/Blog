package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/fresh_seal"
	"volc_contract_process/pkg/errors"
)

// innerFreshSealHandler 处理鲜章相关的内部接口请求
type innerFreshSealHandler struct {
	base
	// 鲜章申请服务
	freshSealService fresh_seal.FreshSealApprovalService
}

// NewInnerFreshSealHandler 创建鲜章内部接口处理器
func NewInnerFreshSealHandler() vhertz.ActionHandler {
	return &innerFreshSealHandler{
		// 初始化鲜章申请服务
		freshSealService: fresh_seal.NewFreshSealApprovalService(),
	}
}

// ListFreshSeal20210101 内部接口-鲜章申请单列表查询
// @Summary 内部接口-鲜章申请单列表查询
// @Description  该接口用于查询鲜章申请单列表
// @Tags 鲜章相关接口-内部
// @ID /vcc/inner-api/fresh_seal@List20210101
// @Accept json
// @Param Action query string true "Action-默认值:List"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param ContractNo query string false "合同编号"
// @Param AccountID formData int false "客户账号ID"
// @Param Status formData string false "申请单状态，多个参数逗号分割"
// @Param Limit formData int false "每页数量，默认10"
// @Param Offset formData int false "偏移量"
// @Success 200  {object}  vhertz.CommonResponse{Result=bizmodels.FreshSealListResp} "响应信息"
// @Router /vcc/inner-api/fresh_seal/Action_ListFreshSeal_Version_20210101 [get]
func (h *innerFreshSealHandler) ListFreshSeal20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	//验证参数
	if err := param.Validate(ctx); err != nil {
		logs.CtxError(ctx, "FreshSealListQueryFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 调用鲜章申请单列表查询服务
	resp, err := h.freshSealService.GetApprovalList(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "FreshSealListQueryFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// BatchUpdateExpressDataFreshSeal20210101 内部接口-批量更新邮寄信息
// @Summary 内部接口-批量更新邮寄信息
// @Description  该接口用于批量更新鲜章申请单的邮寄信息
// @Tags 鲜章相关接口-内部
// @ID /vcc/inner-api/fresh_seal@BatchUpdateExpressData20210101
// @Accept json
// @Param Action query string true "Action-默认值:BatchUpdateExpressData"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param ExpressDataList body []bizmodels.ExpressData true "邮寄信息列表"
// @Success 200  {object}  vhertz.CommonResponse "响应信息"
// @Router /vcc/inner-api/fresh_seal/Action_BatchUpdateExpressDataFreshSeal_Version_20210101 [post]
func (h *innerFreshSealHandler) BatchUpdateExpressDataFreshSeal20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealBatchUpdateExpressParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealBatchUpdateExpressReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.CurrentOperator = queryOperatorByReqOperator(ctx, param.CurrentOperator)

	// 验证批量更新邮寄信息参数
	if err := param.ValidateBatchUpdateExpress(ctx); err != nil {
		logs.CtxError(ctx, "FreshSealBatchUpdateExpressReqValidateFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	// 调用批量更新邮寄信息服务
	err := h.freshSealService.BatchUpdateExpressData(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "FreshSealBatchUpdateExpressFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ExportFreshSeal20210101 内部接口-鲜章申请单导出
// @Summary 内部接口-鲜章申请单导出
// @Description  该接口用于导出鲜章申请单数据
// @Tags 鲜章相关接口-内部
// @ID /vcc/inner-api/fresh_seal@ListExport20210101
// @Accept json
// @Param Action query string true "Action-默认值:Export"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param ContractNo query string false "合同编号"
// @Param AccountID formData int false "客户账号ID"
// @Param Status formData string false "申请单状态，多个参数逗号分割"
// @Success 200  {object}  vhertz.CommonResponse "响应信息"
// @Router /vcc/inner-api/fresh_seal/Action_ExportFreshSeal_Version_20210101 [get]
func (h *innerFreshSealHandler) ExportFreshSeal20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealExportReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.CurrentOperator = queryOperatorByReqOperator(ctx, param.CurrentOperator)

	// 异步调用鲜章申请单导出服务
	go func() {
		if err := h.freshSealService.Export(ctx, &param); err != nil {
			logs.CtxError(ctx, "FreshSealExportFail, param: %v, err: %s", param, err.Error())
		}
	}()

	// 返回成功响应
	vhertz.DoResponse(ctx, c, nil)
}

// ListOperationRecordFreshSeal20210101 内部接口-鲜章申请单操作记录查询
// @Summary 内部接口-鲜章申请单操作记录查询
// @Description  该接口用于查询鲜章申请单的操作记录
// @Tags 鲜章相关接口-内部
// @ID /vcc/inner-api/fresh_seal@ListOperationRecord20210101
// @Accept json
// @Param Action query string true "Action-默认值:ListOperationRecord"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param ApplyNo query string false "申请单编号"
// @Param Limit query int false "分页大小，默认10"
// @Param Offset query int false "偏移量"
// @Success 200  {object}  vhertz.CommonResponse{Result=bizmodels.FreshSealListOperationRecordResp} "响应信息"
// @Router /vcc/inner-api/fresh_seal/Action_ListOperationRecordFreshSeal_Version_20210101 [get]
func (h *innerFreshSealHandler) ListOperationRecordFreshSeal20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealListOperationRecordParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealListOperationRecordReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 验证批量更新邮寄信息参数
	if err := param.ValidateFreshSealListOperationRecordParam(); err != nil {
		logs.CtxError(ctx, "FreshSealListOperationRecordReqBindFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 调用鲜章申请单操作记录查询服务
	resp, err := h.freshSealService.ListOperationRecord(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "FreshSealListOperationRecordFail, param: %v, err: %s", param, err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

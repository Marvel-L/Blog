package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/errors"
)

type innerTOPCommodityHandler struct {
	base
	commodityService metacommodity.Service
}

func NewInnerTOPCommodityHandler() vhertz.ActionHandler {
	return &innerTOPCommodityHandler{
		commodityService: metacommodity.NewService(),
	}
}

// ListContractForInvoiceProject20200101 查询开票项目关联合同列表
func (h *innerTOPCommodityHandler) ListContractForInvoiceProject20200101(ctx context.Context, c *app.RequestContext) {

	invoiceProject := c.Query("InvoiceProject")
	if len(invoiceProject) == 0 {
		logs.CtxError(ctx, "ListContractForInvoiceProjectParamMissing, param=InvoiceProject")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("InvoiceProject"))
		return
	}

	resp, err := h.commodityService.ListContractForInvoiceProject(ctx, invoiceProject)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetInvoiceByContractAndProduct20200101 查询合同下的开票项目
func (h *innerTOPCommodityHandler) GetInvoiceByContractAndProduct20200101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.GetInvoiceByContractAndProductReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.commodityService.GetInvoiceByContractAndProduct(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetManageInfo20200101 获取合同管理信息
func (h *innerTOPCommodityHandler) GetManageInfo20200101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.GetManageInfoReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetManageInfoParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, param.ContractNo)
	if err != nil {
		logs.CtxError(ctx, "GetManageInfo_FindLastByNoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("FindMetaFail"))
		return
	}
	if meta == nil {
		logs.CtxError(ctx, "GetManageInfo_ContractMetaIsNil, ContractNo: %s", param.ContractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("MetaIsNil"))
		return
	}

	info, err := h.commodityService.BuildManageInfo(ctx, nil, int64(meta.Id), param.NeedCommodity, meta.RelateQuoteNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("BuildManageInfoFail"))
		return
	}

	vhertz.DoResponse(ctx, c, info)
}

package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/pkg/errors"
)

type innerBizContractHandler struct {
	base
	bizContractService service.BizContractService
	metaService        contractmeta.MetaService
}

func NewInnerBizContractHandler() vhertz.ActionHandler {
	return &innerBizContractHandler{
		bizContractService: service.NewBizContractService(),
		metaService:        contractmeta.NewMetaService(),
	}
}

// List20210101 内部接口-合同列表
func (h *innerBizContractHandler) List20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner

	ret, err := h.bizContractService.List(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// ListContractProcess20210101 用于解决 action 命名冲突，内部复用 List20210101
func (h *innerBizContractHandler) ListContractProcess20210101(ctx context.Context, c *app.RequestContext) {
	h.List20210101(ctx, c)
}

// Detail20210101 内部接口-合同详情
func (h *innerBizContractHandler) Detail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDetailReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner
	param.CurrentOperator = queryOperator(ctx)

	bizContract, err := h.bizContractService.Detail(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	fileID := bizContract.FileIdUnsigned
	if bizContract.Status >= _const.BizContractStatusBeEffective {
		fileID = bizContract.FileIdSigned
	}

	url, err := service.Download(ctx, fileID)
	if err != nil {
		logs.CtxError(ctx, "DownloadFileFail, fileID:%s, err:%s", fileID, err.Error())
	}

	bizContract.FileURL = url
	vhertz.DoResponse(ctx, c, bizContract)
}

// Count20210101 内部接口-合同数量
func (h *innerBizContractHandler) Count20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractCountReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner

	ret, err := h.bizContractService.List(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if ret == nil {
		vhertz.DoResponse(ctx, c, 0)
		return
	}

	vhertz.DoResponse(ctx, c, ret.Total)
}

// Download20210101 内部接口-合同下载
func (h *innerBizContractHandler) Download20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractDownloadReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner
	param.CurrentOperator = queryOperator(ctx)

	body, filename, err := h.bizContractService.Download(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+filename)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", body)

}

// Export20210101 内部接口-合同导出
func (h *innerBizContractHandler) Export20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner

	if err := h.bizContractService.Export(ctx, &param); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// Audit20210101 内部接口-合同终止
func (h *innerBizContractHandler) Audit20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.BizContractAuditParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractAuditReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeInner

	h.auditMeta(ctx, c, &param)
}

func (h *innerBizContractHandler) auditMeta(ctx context.Context, c *app.RequestContext, param *bizmodels.BizContractAuditParam) {
	var bizScene int
	// 匹配事件 => todo 统一封装
	switch param.Scene {
	case _const.SceneQuoteContract:
		bizScene = _const.BizSceneQuoteContract
	case _const.SceneCreditContract:
		bizScene = _const.BizSceneCreditContract
	default:
		logs.CtxError(ctx, "openBizContractHandlerAuditMetaUnsupportedBizScene, bizScene=%d", param.Scene)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "不支持的scene[%d]", param.Scene)))
		return
	}

	metaParam := &bizmodels.OpenBizContractAbortParam{
		BizScene:        bizScene,
		ContractNo:      param.ContractNo,
		BizIdentifier:   param.Identifier,
		CurrentOperator: param.CurrentOperator,
	}

	err := contractmeta.NewMetaService().AbortBiz(ctx, metaParam)
	if err != nil {
		logs.CtxError(ctx, "OpenVCCMetaBizHandlerCustomerAuditFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

func (h *innerBizContractHandler) Revoke20210101(ctx context.Context, c *app.RequestContext) {
	var param bizmodels.OpenBizContractRevokeParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "BizContractRevokeReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.metaService.RevokeBiz(ctx, &param)

	if err != nil {
		logs.CtxError(ctx, "RevokeFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Success": true,
		"Message": "撤销成功",
	})
}

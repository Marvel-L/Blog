package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/pkg/errors"
)

type openPreContractHandler struct {
	base
}

func NewOpenPreContractHandler() vhertz.ActionHandler {
	return &openPreContractHandler{}
}

// CreateOrUpdatePreContract20210101 创建或编辑在线合同
func (h *openPreContractHandler) CreateOrUpdatePreContract20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.CreateOrUpdateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetPreContractParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.IsOpenCall = true

	basicinfo.FixDepartmentWhenSave(&req.BasicInfo)

	res, err := req.Execute(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// ListUrgeNotifyUserList20210101 获取可催办人员列表
func (h *openPreContractHandler) ListUrgeNotifyUserList20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.ListUrgeNotifyUserListReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetOperationRecordParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, apiError := req.Execute(ctx)
	if apiError != nil {
		logs.CtxError(ctx, "ListUrgeNotifyUserListFail, err:%v", apiError)
		vhertz.ErrorResp(ctx, c, apiError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// SendUrgeNotifyV220210101 发起催办V2
func (h *openPreContractHandler) SendUrgeNotifyV220210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.SendUrgeNotifyReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetOperationRecordParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	resp, apiError := req.Execute(ctx)
	if apiError != nil {
		logs.CtxError(ctx, "SendUrgeNotifyFail, err:%v", apiError)
		vhertz.ErrorResp(ctx, c, apiError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

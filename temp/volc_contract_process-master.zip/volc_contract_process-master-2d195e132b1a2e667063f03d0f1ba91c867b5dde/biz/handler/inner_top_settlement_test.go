package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractsettlement"
	pkg_errors "volc_contract_process/pkg/errors"

	"gorm.io/gorm"
)

type fakeInnerTOPSettlementContractMetaDao struct {
	dal.ContractMetaDao
	findLastByNoFn func(context.Context, *gorm.DB, string) (*model.ContractMetaDB, error)
}

func (f *fakeInnerTOPSettlementContractMetaDao) FindLastByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	return f.findLastByNoFn(ctx, tx, contractNo)
}

type fakeInnerTOPSettlementService struct {
	contractsettlement.SettlementService
	buildFn func(context.Context, *model.ContractMetaDB) (*bizmodels.SettlementInfo, pkg_errors.APIError)
}

func (f *fakeInnerTOPSettlementService) BuildSettlementInfo(ctx context.Context, meta *model.ContractMetaDB) (*bizmodels.SettlementInfo, pkg_errors.APIError) {
	return f.buildFn(ctx, meta)
}

func Test_innerTOPSettlementHandler_GetSettlementInfo20200101_BitsUTGen(t *testing.T) {
	// MockContractMetaDao is a mock type for the dal.ContractMetaDao interface.
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}
	// MockSettlementService is a mock type for the contractsettlement.SettlementService interface.
	type MockSettlementService struct {
		contractsettlement.SettlementService
	}

	mockey.PatchConvey("Test GetSettlementInfo20200101", t, func() {
		// h is the handler instance under test, with a mock settlement service.
		h := &innerTOPSettlementHandler{
			settlementService: &MockSettlementService{},
		}
		// c is the Hertz request context for the handler.
		c := &app.RequestContext{}

		mockey.PatchConvey("Success", func() {
			// 场景描述：
			// 正常获取结算信息的成功场景。
			// 构造数据：
			// - ContractNo: "valid-contract-no"
			// - dal.FindLastByNo 返回一个有效的 ContractMetaDB 实例。
			// - settlementService.BuildSettlementInfo 返回一个有效的 SettlementInfo 实例。
			// 逻辑链路：
			// 1. c.Query("ContractNo") 返回 "valid-contract-no"。
			// 2. dal.NewContractMetaDao().FindLastByNo 成功找到合同元数据。
			// 3. h.settlementService.BuildSettlementInfo 成功构建结算信息。
			// 4. vhertz.DoResponse 被调用，返回成功的响应。

			contractNo := "valid-contract-no"
			meta := &model.ContractMetaDB{ContractNo: contractNo}
			info := &bizmodels.SettlementInfo{SettlementClause: "Test Clause"}

			mockey.Mock((*app.RequestContext).Query).Return(contractNo).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(meta, nil).Build()
			mockey.Mock((*MockSettlementService).BuildSettlementInfo).Return(info, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, info)
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("Failure: Missing ContractNo", func() {
			// 场景描述：
			// 请求参数中缺少 ContractNo。
			// 构造数据：
			// - ContractNo: "" (空字符串)
			// 逻辑链路：
			// 1. c.Query("ContractNo") 返回空字符串。
			// 2. 函数应立即返回，并调用 vhertz.ErrorResp，错误类型为 ErrMissingParam。

			mockey.Mock((*app.RequestContext).Query).Return("").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("Failure: FindLastByNo returns error", func() {
			// 场景描述：
			// 数据库查询合同元数据时发生错误。
			// 构造数据：
			// - ContractNo: "any-contract-no"
			// - dal.FindLastByNo 返回一个非nil的error。
			// 逻辑链路：
			// 1. c.Query("ContractNo") 返回 "any-contract-no"。
			// 2. dal.NewContractMetaDao().FindLastByNo 返回错误。
			// 3. 函数应调用 vhertz.ErrorResp，错误信息为 "FindMetaFail"。

			contractNo := "any-contract-no"
			dbErr := errors.New("database connection failed")

			mockey.Mock((*app.RequestContext).Query).Return(contractNo).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, dbErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "FindMetaFail")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("Failure: Contract meta not found (is nil)", func() {
			// 场景描述：
			// 数据库中未找到对应的合同元数据。
			// 构造数据：
			// - ContractNo: "not-exist-contract-no"
			// - dal.FindLastByNo 返回 (nil, nil)。
			// 逻辑链路：
			// 1. c.Query("ContractNo") 返回 "not-exist-contract-no"。
			// 2. dal.NewContractMetaDao().FindLastByNo 返回 nil, nil 表示未找到记录。
			// 3. 函数应调用 vhertz.ErrorResp，错误信息为 "MetaIsNil"。

			contractNo := "not-exist-contract-no"

			mockey.Mock((*app.RequestContext).Query).Return(contractNo).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "MetaIsNil")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("Failure: BuildSettlementInfo returns error", func() {
			// 场景描述：
			// 构建结算信息时发生业务逻辑错误。
			// 构造数据：
			// - ContractNo: "valid-contract-no"
			// - dal.FindLastByNo 返回一个有效的 ContractMetaDB 实例。
			// - settlementService.BuildSettlementInfo 返回一个非nil的error。
			// 逻辑链路：
			// 1. c.Query("ContractNo") 返回 "valid-contract-no"。
			// 2. dal.NewContractMetaDao().FindLastByNo 成功找到合同元数据。
			// 3. h.settlementService.BuildSettlementInfo 返回错误。
			// 4. 函数应调用 vhertz.ErrorResp，错误信息为 "BuildSettlementInfoFail"。

			contractNo := "valid-contract-no"
			meta := &model.ContractMetaDB{ContractNo: contractNo}
			buildErr := pkg_errors.NewErr("BuildError", "some business logic error", 400)

			mockey.Mock((*app.RequestContext).Query).Return(contractNo).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(meta, nil).Build()
			mockey.Mock((*MockSettlementService).BuildSettlementInfo).Return(nil, buildErr).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "BuildSettlementInfoFail")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), c)
		})
	})
}

func TestNewInnerTOPSettlementHandler_BitsUTGen(t *testing.T) {
	// mockSettlementService is a mock for the contractsettlement.SettlementService interface.
	type mockSettlementService struct {
		contractsettlement.SettlementService
	}

	mockey.PatchConvey("TestNewInnerTOPSettlementHandler", t, func() {
		mockey.PatchConvey("should successfully create a new innerTOPSettlementHandler", func() {
			// 场景描述:
			// 测试 NewInnerTOPSettlementHandler 构造函数是否能成功创建一个 handler 实例，并正确初始化其依赖的 settlementService。
			// 构造数据:
			// - 创建一个 mock 的 contractsettlement.SettlementService 实例。
			// 逻辑链路:
			// 1. Mock contractsettlement.NewSettlementService() 函数，使其返回预设的 mock service 实例。
			// 2. 调用 NewInnerTOPSettlementHandler() 函数。
			// 3. 断言返回的 handler 不为 nil，并且其具体类型为 *innerTOPSettlementHandler。
			// 4. 断言 handler 内的 settlementService 字段是我们第一步中 mock 的实例，以验证依赖注入是否正确。

			// 准备mock service
			mockSvc := &mockSettlementService{}

			// Mock依赖的service构造函数
			mockey.Mock(contractsettlement.NewSettlementService).
				Return(mockSvc).
				Build()

			// 调用目标函数
			handler := NewInnerTOPSettlementHandler()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			concreteHandler, ok := handler.(*innerTOPSettlementHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(concreteHandler.settlementService, convey.ShouldEqual, mockSvc)
		})
	})
}

func Test_innerTOPSettlementHandler_GetSettlementInfo20200101(t *testing.T) {
	t.Run("ContractNo为空返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPSettlementHandler{settlementService: &fakeInnerTOPSettlementService{}}
			mockey.Mock((*app.RequestContext).Query).Return("").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("查询合同元数据失败返回FindMetaFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPSettlementHandler{settlementService: &fakeInnerTOPSettlementService{}}
			mockey.Mock((*app.RequestContext).Query).Return("contract-1").Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPSettlementContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				convey.So(contractNo, convey.ShouldEqual, "contract-1")
				return nil, errors.New("dao failed")
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "FindMetaFail")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("合同元数据为空返回MetaIsNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerTOPSettlementHandler{settlementService: &fakeInnerTOPSettlementService{}}
			mockey.Mock((*app.RequestContext).Query).Return("contract-2").Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPSettlementContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				convey.So(contractNo, convey.ShouldEqual, "contract-2")
				return nil, nil
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "MetaIsNil")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("构建结算信息失败返回BuildSettlementInfoFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			meta := &model.ContractMetaDB{ContractNo: "contract-3"}
			h := &innerTOPSettlementHandler{settlementService: &fakeInnerTOPSettlementService{buildFn: func(ctx context.Context, gotMeta *model.ContractMetaDB) (*bizmodels.SettlementInfo, pkg_errors.APIError) {
				convey.So(gotMeta, convey.ShouldEqual, meta)
				return nil, pkg_errors.ErrInternalError
			}}}
			mockey.Mock((*app.RequestContext).Query).Return("contract-3").Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPSettlementContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				return meta, nil
			}}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrorCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "BuildSettlementInfoFail")
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("构建结算信息成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			meta := &model.ContractMetaDB{ContractNo: "contract-4"}
			info := &bizmodels.SettlementInfo{SettlementClause: "settlement clause"}
			h := &innerTOPSettlementHandler{settlementService: &fakeInnerTOPSettlementService{buildFn: func(ctx context.Context, gotMeta *model.ContractMetaDB) (*bizmodels.SettlementInfo, pkg_errors.APIError) {
				convey.So(gotMeta, convey.ShouldEqual, meta)
				return info, nil
			}}}
			mockey.Mock((*app.RequestContext).Query).Return("contract-4").Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&fakeInnerTOPSettlementContractMetaDao{findLastByNoFn: func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				return meta, nil
			}}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, info)
			}).Build()

			h.GetSettlementInfo20200101(context.Background(), &app.RequestContext{})
		})
	})
}

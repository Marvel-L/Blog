package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
)

type base struct {
	vhertz.CommonActionHandler
}

func queryOperator(ctx context.Context) string {
	return fetchAuthInfo(ctx).CurrentOperator
}

func fetchAuthInfo(ctx context.Context) *bizmodels.AuthInfo {
	info := ctx.Value(_const.CtxAuthInfo)
	if info == nil {
		return &bizmodels.AuthInfo{}
	}
	authInfo, ok := info.(*bizmodels.AuthInfo)
	if !ok {
		return &bizmodels.AuthInfo{}
	}
	return authInfo
}

func (b base) fetchUserInfoFromCtx(ctx context.Context) *bizmodels.AuthInnerUserInfo {
	if user, ok := ctx.Value(_const.CtxCurrentUser).(*bizmodels.AuthInnerUserInfo); ok {
		if len(user.EmployeeEmail) == 0 {
			logs.CtxWarn(ctx, "fetchUserInfoFromCtxFail, email is empty")
			return nil
		}
		return user
	}
	return nil
}

// 参数中无该参数时 尝试从header中获取
func queryOperatorByReqOperator(ctx context.Context, reqOperator string) string {
	if employeeEmail, ok := ctx.Value(_const.CtxEmployeeEmail).(string); ok && employeeEmail != "" {
		return employeeEmail
	}
	return reqOperator
}

func fetchEmployeeEmail(ctx context.Context) string {
	if employeeEmail, ok := ctx.Value(_const.CtxEmployeeEmail).(string); ok {
		return employeeEmail
	}
	return ""
}

func hasEmployeeHeader(ctx context.Context) bool {
	if employeeFlag, ok := ctx.Value(_const.CtxEmployeeFlag).(string); ok {
		return employeeFlag != ""
	}
	return false
}

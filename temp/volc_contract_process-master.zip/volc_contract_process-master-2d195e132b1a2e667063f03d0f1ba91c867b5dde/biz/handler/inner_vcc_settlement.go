package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelsettlement"
	"volc_contract_process/biz/service/contractsettlement"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——编辑结算信息
type innerVCCSettlementHandler struct {
	base
	settlementService contractsettlement.SettlementService
}

func NewInnerVCCSettlementHandler() vhertz.ActionHandler {
	return &innerVCCSettlementHandler{
		settlementService: contractsettlement.NewSettlementService(),
	}
}

// SubmitContractSettlement20210101 提交合同结算信息
func (h *innerVCCSettlementHandler) SubmitContractSettlement20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsettlement.SubmitSettlementReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "SubmitContractSettlementFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.settlementService.SubmitContractSettlementV1(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// ListBalanceForCredit20210101 查询余额信息
func (h *innerVCCSettlementHandler) ListBalanceForCredit20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsettlement.ListBalanceForCreditReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListBalanceForCreditFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.settlementService.ListBalanceForCredit(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// ListBalanceForCredit20210101 查询余额信息
func (h *innerVCCSettlementHandler) ListNoCreditAndPeriodSettlementTemplate20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsettlement.GetSettlementTemplateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListNoCreditAndPeriodSettlementTemplateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	resp, err := h.settlementService.GetNoCreditAndPeriodSettlementTemplate(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

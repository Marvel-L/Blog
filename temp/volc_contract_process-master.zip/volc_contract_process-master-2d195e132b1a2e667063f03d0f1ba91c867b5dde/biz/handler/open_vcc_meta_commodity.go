package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——合同商品信息
type openVCCMetaCommodityHandler struct {
	base
	commodityService metacommodity.Service
}

func NewOpenVCCMetaCommodityHandler() vhertz.ActionHandler {
	return &openVCCMetaCommodityHandler{
		commodityService: metacommodity.NewService(),
	}
}

// ListContractForInvoiceProject20210101 查询开票项目关联合同列表
func (h *openVCCMetaCommodityHandler) ListContractForInvoiceProject20210101(ctx context.Context, c *app.RequestContext) {

	invoiceProject := c.Query("InvoiceProject")
	if len(invoiceProject) == 0 {
		logs.CtxError(ctx, "ListContractForInvoiceProjectParamMissing, param=InvoiceProject")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("InvoiceProject"))
		return
	}

	resp, err := h.commodityService.ListContractForInvoiceProject(ctx, invoiceProject)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

func (h *openVCCMetaCommodityHandler) GetInvoiceByContractAndProduct20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.GetInvoiceByContractAndProductReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.commodityService.GetInvoiceByContractAndProduct(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetInvoiceByContract20210101 查询合同下所有商品的开票项目
func (h *openVCCMetaCommodityHandler) GetInvoiceByContract20210101(ctx context.Context, c *app.RequestContext) {

	var param modelcommodity.GetInvoiceByContractReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.commodityService.GetInvoiceByContract(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// HasQuoteRelateContract20210101 报价单是否已被使用
func (h *openVCCMetaCommodityHandler) HasQuoteRelateContract20210101(ctx context.Context, c *app.RequestContext) {

	quoteID := c.Query("QuoteID")
	if len(quoteID) == 0 {
		logs.CtxError(ctx, "HasQuoteRelateContractParamMissing, param=QuoteID")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("QuoteID"))
		return
	}

	resp, err := h.commodityService.HasQuoteRelateContract(ctx, quoteID)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// CreateOrUpdateManageInfo20210101 创建&更新合同管理信息
func (h *openVCCMetaCommodityHandler) CreateOrUpdateManageInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.UpdateManageInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.commodityService.CreateOrUpdateManageInfo(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, req.ContractNo)

}

// List20210101 创建&更新合同管理信息
func (h *openVCCMetaCommodityHandler) List20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.ListCommodityReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "ListCommodityReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}

	commodityListResp, err := h.commodityService.ListCommodity(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, commodityListResp)
}

package handler

import (
	"context"
	"strings"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelsthird"
	"volc_contract_process/biz/service/thirdservice"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
)

// 火山合同中心——封装外部第三方接口
type innerVCCThirdHandler struct {
	base
}

func NewInnerVCCThirdHandler() vhertz.ActionHandler {
	return &innerVCCThirdHandler{}
}

// ListVerifyCountry20210101 获取认证国家列表
// 调用认证系统 https://bytedance.larkoffice.com/wiki/I4ZewjGqCia6FgkLbn1cgiRbnPu
func (h *innerVCCThirdHandler) ListVerifyCountry20210101(ctx context.Context, c *app.RequestContext) {

	codes := strings.Split(c.Query("Codes"), ",")

	logs.CtxInfo(ctx, "ListVerifyCountry, params => %v", codes)

	list, err := innerapiaccountcli.ListVerifyCountry(ctx, codes)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, list)
}

// CreateVerifyAccount20210101 创建计收账号
func (h *innerVCCThirdHandler) CreateVerifyAccount20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsthird.CreateVerifyAccountReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateVerifyAccountReqBindFail, InnerPageParam, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	resp, err := thirdservice.NewAccountService().CreateVerifyAccount(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

func (h *innerVCCThirdHandler) ListProductDepartment20210101(ctx context.Context, c *app.RequestContext) {
	var req modelsthird.ListProductDepartmentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListProductDepartmentReqBindFail, InnerPageParam, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := thirdservice.NewProductService().ListDepartment(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerVCCThirdHandler) GetProductLineTree20210101(ctx context.Context, c *app.RequestContext) {

	resp, err := thirdservice.NewProductService().GetProductLineTree(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

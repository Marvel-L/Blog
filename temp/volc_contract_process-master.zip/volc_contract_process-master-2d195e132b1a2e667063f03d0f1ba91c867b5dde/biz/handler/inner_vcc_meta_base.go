package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/service/feishuservice"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——合同商品信息
type innerVCCMetaBaseHandler struct {
	base
	feishuContractService feishuservice.FeishuContractService
}

func NewInnerVCCMetaBaseHandler() vhertz.ActionHandler {
	return &innerVCCMetaBaseHandler{
		feishuContractService: feishuservice.NewFeishuContractService(),
	}
}

// SyncContract20210101 同步销售合同
func (h *innerVCCMetaBaseHandler) SyncContract20210101(ctx context.Context, c *app.RequestContext) {

	contractNoList := make([]string, 0)

	err := binding.BindAndValidate(c, &contractNoList)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}
	if len(contractNoList) == 0 {
		vhertz.DoResponse(ctx, c, "传入合同号为空")
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	go h.feishuContractService.SyncContract(ctx, contractNoList)

	vhertz.DoResponse(ctx, c, nil)
}

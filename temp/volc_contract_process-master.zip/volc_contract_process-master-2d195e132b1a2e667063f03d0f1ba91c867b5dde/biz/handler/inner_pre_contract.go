package handler

import (
	"context"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/common/utils"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/cronservice"
	"volc_contract_process/biz/service/larkservice"
	"volc_contract_process/biz/service/riskclauserole"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/pkg/conf"
	"volc_contract_process/pkg/errors"
)

type innerPreContractHandler struct {
	base
	service         riskclauserole.Service
	opRecordService cooperationrecord.Service
}

func NewInnerPreContractHandler() vhertz.ActionHandler {
	return &innerPreContractHandler{
		service:         riskclauserole.NewService(),
		opRecordService: cooperationrecord.NewService(),
	}
}

// JoinOrCreateGroupChat20210101 飞书拉群
func (h *innerPreContractHandler) JoinOrCreateGroupChat20210101(ctx context.Context, c *app.RequestContext) {

	var req larkservice.JoinOrCreateGroupChatReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "JoinOrCreateGroupChat20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := larkservice.JoinOrCreateGroupChat(ctx, nil, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// ListUrgeNotifyUserList20210101 获取可催办人员列表
func (h *innerPreContractHandler) ListUrgeNotifyUserList20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.ListUrgeNotifyUserListReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetOperationRecordParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, apiError := req.Execute(ctx)
	if apiError != nil {
		logs.CtxError(ctx, "ListUrgeNotifyUserListFail, err:%v", apiError)
		vhertz.ErrorResp(ctx, c, apiError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// SendUrgeNotify20210101 发起催办
func (h *innerPreContractHandler) SendUrgeNotify20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.SendUrgeNotifyReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetOperationRecordParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	resp, apiError := req.Execute(ctx)
	if apiError != nil {
		logs.CtxError(ctx, "SendUrgeNotifyFail, err:%v", apiError)
		vhertz.ErrorResp(ctx, c, apiError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// OverdueReviewRemind20210101 提醒的定时任务
func (h *innerPreContractHandler) OverdueReviewRemind20210101(ctx context.Context, c *app.RequestContext) {
	token, ok := c.GetQuery("token")
	if !ok {
		c.JSON(500, utils.H{
			"message": "参数非法",
		})
		return
	}
	config := conf.GetGlobalConf(ctx)
	// if err != nil {
	//	c.JSON(500, utils.H{
	//		"message": err.Error(),
	//	})
	//	return
	// }
	if config == nil {
		c.JSON(500, utils.H{
			"message": "config == nil",
		})
		return
	}
	if config.CronConf == nil {
		c.JSON(500, utils.H{
			"message": "config.CronConf == nil",
		})
		return
	}
	if token != config.CronConf.HttpCallToken {
		c.JSON(500, utils.H{
			"message": "token not match",
		})
		return
	}
	if cronservice.ReviewerRemindAutoNotifier == nil {
		c.JSON(500, utils.H{
			"message": "ReviewerRemindAutoNotifier == nil",
		})
		return
	}
	// 支持外部入参 只查询指定合同
	contractNos := c.DefaultQuery("ContractNos", "")

	err := cronservice.ReviewerRemindAutoNotifier.RunWithContext(ctx, contractNos)
	if err != nil {
		c.JSON(500, utils.H{
			"message": err.Error(),
		})
		return
	}

	c.JSON(200, utils.H{
		"message": "success",
	})
}

// GetPreContractReviewer20210101 获得在线合同审核人员
func (h *innerPreContractHandler) GetPreContractReviewer20210101(ctx context.Context, c *app.RequestContext) {

	preContractNo, ok := c.GetQuery("PreContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("PreContractNo"))
		return
	}

	reviewerDBList, err := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, nil, preContractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}

	list := reviewerDBList.GenResp()

	if h.withReviewerName(ctx, c) {
		if err = salescontract.FillReviewerName(ctx, list); err != nil {
			// 仅记录错误日志
			logs.CtxWarn(ctx, "fillReviewerNameFail")
		}
	}

	ret := map[string]interface{}{
		"Reviewer": list,
	}

	vhertz.DoResponse(ctx, c, ret)
}

func (h *innerPreContractHandler) withReviewerName(ctx context.Context, c *app.RequestContext) bool {
	v, ok := c.GetQuery("WithReviewerName")
	if !ok {
		return false
	}
	return v == "true"
}

// ListSendBackTargetNodes20210101 获取指定退回可选目标节点
func (h *innerPreContractHandler) ListSendBackTargetNodes20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.ListSendBackTargetNodesReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListSendBackTargetNodesParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, apiError := req.ListSendBackTargetNodes(ctx)
	if apiError != nil {
		logs.CtxError(ctx, "ListSendBackTargetNodesFail, err:%v", apiError)
		vhertz.ErrorResp(ctx, c, apiError)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetOperationRecord20210101 获取合同操作记录
func (h *innerPreContractHandler) GetOperationRecord20210101(ctx context.Context, c *app.RequestContext) {

	preContractNo, ok := c.GetQuery("PreContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("PreContractNo"))
		return
	}
	// 获取审批记录
	opRecords, err := h.opRecordService.ListByContractNo(ctx, preContractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}
	if h.withReviewerName(ctx, c) {
		if err = salescontract.FillReviewerRecordName(ctx, opRecords); err != nil {
			// 仅记录错误日志
			logs.CtxWarn(ctx, "fillReviewerNameFail")
		}
	}

	ret := map[string]interface{}{
		"OperationRecord": opRecords,
	}

	vhertz.DoResponse(ctx, c, ret)
}

// CreateOrUpdatePreContract20210101 创建或编辑在线合同
func (h *innerPreContractHandler) CreateOrUpdatePreContract20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.CreateOrUpdateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetPreContractParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if !salescontract.ValidateEditOperation(req.Operation) {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs("无效操作"))
		return
	}

	basicinfo.FixDepartmentWhenSave(&req.BasicInfo)

	res, err := req.Execute(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// OperatePreContract20210101 操作在线合同
func (h *innerPreContractHandler) OperatePreContract20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.OperateContractReq

	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "OperatePreContractParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	if !salescontract.ValidateOperation(req.Operation) {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs("无此操作"))
		return
	}

	res, err := req.Execute(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// GetPreContract20210101 在线合同详情
func (h *innerPreContractHandler) GetPreContract20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.GetPreContractReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetPreContractParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if hasEmployeeHeader(ctx) {
		headerUser := fetchEmployeeEmail(ctx)
		logs.CtxInfo(ctx, "fetchEmployeeEmail, header=%s", headerUser)
		req.CurrentOperator = headerUser
	}

	contractResp, err := req.Execute(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	ret := map[string]interface{}{
		"PreSalesContract": contractResp,
	}

	vhertz.DoResponse(ctx, c, ret)
}

// ListPreContract20210101 在线合同列表
func (h *innerPreContractHandler) ListPreContract20210101(ctx context.Context, c *app.RequestContext) {

	var req salescontract.ListPreContractReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	req.CurrentOperator = queryOperatorByReqOperator(ctx, req.CurrentOperator)

	ret, err := req.Execute(ctx)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// CreateOrUpdatePreContractInner20210101 用于解决 inner/open action 重复且实现存在差异的问题，内部复用 CreateOrUpdatePreContract20210101
func (h *innerPreContractHandler) CreateOrUpdatePreContractInner20210101(ctx context.Context, c *app.RequestContext) {
	h.CreateOrUpdatePreContract20210101(ctx, c)
}

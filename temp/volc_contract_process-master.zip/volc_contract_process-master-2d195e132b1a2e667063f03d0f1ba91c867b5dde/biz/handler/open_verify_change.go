package handler

import (
	"context"
	"strconv"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/service/support/verifychange"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

// 实名认证变更检查
type openVerifyChangeHandler struct {
	base
	service verifychange.Service
}

func NewOpenVerifyChangeHandler() vhertz.ActionHandler {
	return &openVerifyChangeHandler{
		service: verifychange.NewService(),
	}
}

// AllowVerifyChangeForBizQuoteContract20210101 产品报价合同是否允许实名认证变更
func (h *openVerifyChangeHandler) AllowVerifyChangeForBizQuoteContract20210101(ctx context.Context, c *app.RequestContext) {

	accountID, e := h.queryAccountID(ctx, c)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	resp, e := h.service.CheckForBizQuoteContract(ctx, accountID)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// AllowVerifyChangeForSalesContract20210101 销售合同/在线协同合同是否允许实名认证变更
func (h *openVerifyChangeHandler) AllowVerifyChangeForSalesContract20210101(ctx context.Context, c *app.RequestContext) {

	accountID, e := h.queryAccountID(ctx, c)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	resp, e := h.service.CheckForSalesContract(ctx, accountID)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

func (h *openVerifyChangeHandler) queryAccountID(ctx context.Context, c *app.RequestContext) (int, errors.APIError) {

	accountIDStr := c.Query("AccountID")
	if len(accountIDStr) == 0 {
		return 0, errors.ErrMissingParam.WithArgs("AccountID")
	}

	accountID, err := strconv.ParseInt(accountIDStr, 10, 64)
	if err != nil {
		logs.CtxError(ctx, "parseAccountIDFail, accountIDStr=%s", accountIDStr)
		return 0, errors.ErrInvalidParam.WithArgs("AccountID")
	}

	return int(accountID), nil
}

// GetContractNoList20210101 实名认证变更-查询合同号列表
func (h *openVerifyChangeHandler) GetContractNoList20210101(ctx context.Context, c *app.RequestContext) {

	accountID, e := h.queryAccountID(ctx, c)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}
	// 校验accountID参数
	if len(strconv.Itoa(accountID)) != _const.AccountIDLength {
		// accountID字符长度不符合
		logs.CtxError(ctx, "accountID length invalid: %d", accountID)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("AccountID"))
		return
	}

	resp, e := h.service.GetContractNoList(ctx, accountID)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// HasNonFinalContract20210101 实名认证变更-查询是否有非终态合同
func (h *openVerifyChangeHandler) HasNonFinalContract20210101(ctx context.Context, c *app.RequestContext) {

	accountID, e := h.queryAccountID(ctx, c)
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}
	// 校验accountID参数
	if len(strconv.Itoa(accountID)) != _const.AccountIDLength {
		// accountID字符长度不符合
		logs.CtxError(ctx, "accountID length invalid: %d", accountID)
		vhertz.ErrorResp(ctx, c, errors.ErrInvalidParam.WithArgs("AccountID"))
		return
	}

	resp, e := h.service.GetNonFinalContractList(ctx, &metasupport.GetNonFinalContractListReq{
		AccountID: int64(accountID),
		Limit:     1,
	})
	if e != nil {
		vhertz.ErrorResp(ctx, c, e)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"HasNonFinalContract": len(resp.List) > 0,
	})
}

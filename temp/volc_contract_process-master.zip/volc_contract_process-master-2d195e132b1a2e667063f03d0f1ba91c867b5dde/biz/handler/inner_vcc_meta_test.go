package handler

import (
	"context"
	"crypto/sha256"
	jsonV2 "encoding/json"
	conmmonerror "errors"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strings"
	"testing"
	"time"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metabasic"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/bizmodels/modelsthird"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	audithandler "volc_contract_process/biz/service/auditx/handler"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/coupon"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/quote"
	"volc_contract_process/biz/service/support/cooperationrecord"
	"volc_contract_process/biz/service/workflow"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/c360cli"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/util"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/app/server/render"
	"code.byted.org/middleware/hertz/pkg/protocol"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"code.byted.org/overpass/eps_platform_c360_open_service/kitex_gen/opportunity"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_innerVCMetaHandler_ListExport20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock((*app.RequestContext).Get).Return(nil, false).Build()
			Mock(queryOperator).Return("CurrentOperator").Build()
			Mock(binding.BindAndValidate).Return(nil).Build()
			var errorResp vhertz.APIError
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				return // Add your code
			}).Build()
			mockExport := GetMethod(metaService, "Export")
			Mock(mockExport).Return(nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			v.ListExport20210101(context.Background(), &app.RequestContext{})

			// Assert
			So(errorResp, ShouldBeNil)
		})
	})
	t.Run("case BindAndValidateFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock((*app.RequestContext).Get).Return(nil, false).Build()
			Mock(binding.BindAndValidate).Return(fmt.Errorf("your error")).Build()
			var errorResp vhertz.APIError
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorResp = err
				return // Add your code
			}).Build()
			Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				return // Add your code
			}).Build()
			mockExport := GetMethod(metaService, "Export")
			Mock(mockExport).Return(nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			v.ListExport20210101(context.Background(), &app.RequestContext{})

			// Assert
			So(errorResp, ShouldResemble, errors.ErrParamParseFail)
		})
	})
}

/**
 * @Author: wangzhen.12@bytedance.com
 * @Date: 2024/8/15 16:58
 * @Desc:
 */

func Test_innerVCMetaHandler_adaptInnerListParam(t *testing.T) {
	t.Run("case innerVCMetaHandler_adaptInnerListParam#1", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return fmt.Errorf("")
			}).Build()

			defer UnPatchAll()

			// Act
			v := &innerVCMetaHandler{}
			param := &bizmodels.MetaListParam{}
			err := v.adaptInnerListParam(context.Background(), &app.RequestContext{}, param)

			So(err, ShouldNotBeNil)
		})
	})
	t.Run("case innerVCMetaHandler_adaptInnerListParam#2", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				m, ok := obj.(*bizmodels.InnerPageParam)
				if ok {
					m.Limit = 5
					m.Offset = 6
				}
				return nil
			}).Build()

			defer UnPatchAll()

			// Act
			v := &innerVCMetaHandler{}
			param := &bizmodels.MetaListParam{}
			err := v.adaptInnerListParam(context.Background(), &app.RequestContext{}, param)

			So(err, ShouldBeNil)
			So(param.Limit, ShouldEqual, 5)
		})
	})
	t.Run("默认limit填充为10", func(t *testing.T) {
		PatchConvey("", t, func() {
			Mock(binding.BindAndValidate).Return(nil).Build()

			v := &innerVCMetaHandler{}
			param := &bizmodels.MetaListParam{}
			err := v.adaptInnerListParam(context.Background(), &app.RequestContext{}, param)

			So(err, ShouldBeNil)
			So(param.Limit, ShouldEqual, 10)
		})
	})
}

func Test_innerVCMetaHandler_List(t *testing.T) {
	t.Run("case List#1", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			metaService := contractmeta.NewMetaService()
			listBizMethod := GetMethod(metaService, "ListBiz")
			Mock(listBizMethod).Return(&bizmodels.MetaListResp{
				List: []*bizmodels.ContractMetaItem{
					{
						Status: 12,
					},
				},
			}, nil).Build()

			Mock(vhertz.DoResponse).Return().Build()
			Mock(vhertz.ErrorResp).Return().Build()
			Mock(logs.CtxInfo).Return().Build()
			defer UnPatchAll()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			v.List20210101(context.Background(), &app.RequestContext{})

		})
	})
	t.Run("绑定失败返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			v := &innerVCMetaHandler{}
			v.List20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("分页参数适配失败返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*innerVCMetaHandler).adaptInnerListParam).Return(errors.ErrParamParseFail).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			v := &innerVCMetaHandler{}
			v.List20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("服务失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError

			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*innerVCMetaHandler).adaptInnerListParam).Return(nil).Build()
			Mock(queryOperator).Return("operator@bytedance.com").Build()
			Mock(GetMethod(metaService, "ListBiz")).Return(nil, serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.List20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
	t.Run("从上下文填充员工ID", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			var capturedParam *bizmodels.MetaListParam

			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*innerVCMetaHandler).adaptInnerListParam).Return(nil).Build()
			Mock(queryOperator).Return("operator@bytedance.com").Build()
			Mock(GetMethod(metaService, "ListBiz")).To(func(_ context.Context, param *bizmodels.MetaListParam) (*bizmodels.MetaListResp, errors.APIError) {
				capturedParam = param
				return &bizmodels.MetaListResp{}, nil
			}).Build()
			Mock(vhertz.DoResponse).Return().Build()

			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{EmployeeID: 123, EmployeeEmail: "operator@bytedance.com"})
			v := &innerVCMetaHandler{metaService: metaService}
			v.List20210101(ctx, &app.RequestContext{})

			So(capturedParam.CurrentOperatorUID, ShouldEqual, 123)
			So(capturedParam.SourceType, ShouldEqual, _const.SourceTypeInner)
			So(capturedParam.NeedCalcCooperationRole, ShouldBeTrue)
		})
	})
}

func Test_innerVCMetaHandler_MetaList20210101(t *testing.T) {
	t.Run("转发到List20210101", func(t *testing.T) {
		PatchConvey("", t, func() {
			called := false
			Mock((*innerVCMetaHandler).List20210101).To(func(_ *innerVCMetaHandler, ctx context.Context, c *app.RequestContext) {
				called = true
				So(ctx, ShouldNotBeNil)
				So(c, ShouldNotBeNil)
			}).Build()

			h := &innerVCMetaHandler{}
			h.MetaList20210101(context.Background(), &app.RequestContext{})

			So(called, ShouldBeTrue)
		})
	})
}

func Test_innerVCMetaHandler_Detail20210101(t *testing.T) {
	t.Run("服务成功返回详情", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			resp := &bizmodels.ContractMetaInfo{ContractNo: "CN-DETAIL"}
			var capturedParam *bizmodels.MetaDetailParam
			var capturedResult interface{}

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.MetaDetailParam)
				p.ContractNo = "CN-DETAIL"
				return nil
			}).Build()
			Mock(queryOperator).Return("operator@bytedance.com").Build()
			Mock(GetMethod(metaService, "Detail")).To(func(_ context.Context, param *bizmodels.MetaDetailParam) (*bizmodels.ContractMetaInfo, errors.APIError) {
				capturedParam = param
				return resp, nil
			}).Build()
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerVCMetaHandler{metaService: metaService}
			h.Detail20210101(context.Background(), &app.RequestContext{})

			So(capturedParam, ShouldNotBeNil)
			So(capturedParam.SourceType, ShouldEqual, _const.SourceTypeInner)
			So(capturedParam.CurrentOperator, ShouldEqual, "operator@bytedance.com")
			So(capturedResult, ShouldEqual, resp)
		})
	})

	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.Detail20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})

	t.Run("服务失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError

			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "Detail")).Return(nil, serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{metaService: metaService}
			h.Detail20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
}

func Test_innerVCMetaHandler_MetaDetail20210101(t *testing.T) {
	t.Run("转发到Detail20210101", func(t *testing.T) {
		PatchConvey("", t, func() {
			called := false
			Mock((*innerVCMetaHandler).Detail20210101).To(func(_ *innerVCMetaHandler, ctx context.Context, c *app.RequestContext) {
				called = true
				So(ctx, ShouldNotBeNil)
				So(c, ShouldNotBeNil)
			}).Build()

			h := &innerVCMetaHandler{}
			h.MetaDetail20210101(context.Background(), &app.RequestContext{})

			So(called, ShouldBeTrue)
		})
	})
}

func Test_innerVCMetaHandler_ProcessList20210101(t *testing.T) {
	t.Run("返回空流程定义", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedResult interface{}
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerVCMetaHandler{}
			h.ProcessList20210101(context.Background(), &app.RequestContext{})

			So(capturedResult, ShouldResemble, map[string]interface{}{})
		})
	})
}

func Test_innerVCMetaHandler_RecordList20210101(t *testing.T) {
	t.Run("返回空协作记录列表", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedResult interface{}
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerVCMetaHandler{}
			h.RecordList20210101(context.Background(), &app.RequestContext{})

			So(capturedResult, ShouldResemble, map[string]interface{}{})
		})
	})
}

func Test_DownloadAttachment20210101(t *testing.T) {
	t.Run("绑定失败返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.DownloadAttachment20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("case DownloadAttachment20210101#1 DownloadFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			defer UnPatchAll()
			var retInfo string
			c := &app.RequestContext{}
			metaService := contractmeta.NewMetaService()
			downloadAttachmentMethod := GetMethod(metaService, "Download")
			Mock(downloadAttachmentMethod).Return(nil, "", "", errors.ErrorCommon.WithArgs("error")).Build()
			Mock(logs.CtxError).Return().Build()
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				retInfo = "DownloadFail"
			}).Build()
			// Act
			h := &innerVCMetaHandler{
				metaService: metaService,
			}
			h.DownloadAttachment20210101(context.Background(), c)
			// Assert
			So(retInfo, ShouldEqual, "DownloadFail")
		})
	})
	t.Run("case DownloadAttachment20210101#2 DownloadEmpty", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			defer UnPatchAll()
			var retInfo string
			c := &app.RequestContext{}
			metaService := contractmeta.NewMetaService()
			downloadAttachmentMethod := GetMethod(metaService, "Download")
			Mock(downloadAttachmentMethod).Return(nil, "", "", nil).Build()
			Mock(logs.CtxError).Return().Build()
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				retInfo = "DownloadEmpty"
			}).Build()
			// Act
			h := &innerVCMetaHandler{
				metaService: metaService,
			}
			h.DownloadAttachment20210101(context.Background(), c)
			// Assert
			So(retInfo, ShouldEqual, "DownloadEmpty")
		})
	})
	t.Run("case DownloadAttachment20210101#2 DownloadSuccess", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			defer UnPatchAll()
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}
			metaService := contractmeta.NewMetaService()
			downloadAttachmentMethod := GetMethod(metaService, "Download")
			Mock(downloadAttachmentMethod).Return([]byte("content"), "", "", nil).Build()
			Mock(logs.CtxError).Return().Build()

			methodData := GetMethod(c, "Render")
			Mock(methodData).To(func(code int, r render.Render) {
			})

			// Act
			h := &innerVCMetaHandler{
				metaService: metaService,
			}
			h.DownloadAttachment20210101(context.Background(), c)
			// Assert
			So(c.Response.Header.Get("Content-type"), ShouldEqual, "application/octet-stream")
		})
	})
}

func Test_innerVCMetaHandler_CustomAuditBizContract20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			v := &innerVCMetaHandler{}
			v.CustomAuditBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			Mock(workflow.Process).Return(nil, nil).Build()

			// Act
			v := &innerVCMetaHandler{}
			c := &app.RequestContext{}
			v.CustomAuditBizContract20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `不支持的BizScene[0]`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("报价合同客户确认成功", func(t *testing.T) {
		PatchConvey("", t, func() {
			resp := &workflow.BizSubmitResp{ContractNo: "CN-AUDIT"}
			var capturedTask *workflow.EventContext
			var capturedResult interface{}

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizScene = _const.BizSceneQuoteContract
				return nil
			}).Build()
			Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return resp, nil
			}).Build()
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			v := &innerVCMetaHandler{}
			v.CustomAuditBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedTask.TaskType, ShouldEqual, workflow.TaskTypeQuoteCustomerAudit)
			So(capturedResult, ShouldEqual, resp)
		})
	})
	t.Run("信控合同客户确认服务失败", func(t *testing.T) {
		PatchConvey("", t, func() {
			serviceErr := errors.ErrInternalError
			var capturedTask *workflow.EventContext
			var capturedErr vhertz.APIError

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizScene = _const.BizSceneCreditContract
				return nil
			}).Build()
			Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return nil, serviceErr
			}).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			v := &innerVCMetaHandler{}
			v.CustomAuditBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedTask.TaskType, ShouldEqual, workflow.TaskTypeCreditCustomerAudit)
			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
	t.Run("伙伴合同客户确认匹配伙伴任务", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedTask *workflow.EventContext
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.OpenBizContractCustomerAuditParam)
				p.BizScene = _const.BizScenePartnerContract
				return nil
			}).Build()
			Mock(workflow.Process).To(func(_ context.Context, task *workflow.EventContext) (workflow.Result, errors.APIError) {
				capturedTask = task
				return nil, nil
			}).Build()
			Mock(vhertz.DoResponse).Return().Build()

			v := &innerVCMetaHandler{}
			v.CustomAuditBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedTask.TaskType, ShouldEqual, workflow.TaskTypePartnerCustomerAudit)
		})
	})
}

func Test_innerVCMetaHandler_AbandonBizContract20210101(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "AbandonBiz")).Return(nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.AbandonBizContract20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.AbandonBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("服务失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "AbandonBiz")).Return(serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.AbandonBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
}

func Test_innerVCMetaHandler_RevokeBizContract20210101(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "RevokeBiz")).Return(nil).Build()
			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.RevokeBizContract20210101(context.Background(), c)
			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""},"Result":{"Message":"撤销成功","Success":true}}`)
		})
	})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.RevokeBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("服务失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "RevokeBiz")).Return(serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.RevokeBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
}

func Test_innerVCMetaHandler_AbortBizContract20210101(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "AbortBiz")).Return(nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.AbortBizContract20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.AbortBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("服务失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(metaService, "AbortBiz")).Return(serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.AbortBizContract20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
}

func Test_innerVCMetaHandler_CheckLadderQuoteContractClash20210101(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.CheckLadderQuoteContractClashReq).Validate).Return(nil).Build()
			Mock(GetMethod(metaService, "CheckLadderQuoteContractClash")).Return(&bizmodels.CheckLadderQuoteContractClashResp{}, nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.CheckLadderQuoteContractClash20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `{"Repeat":false,"Message":""}`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("参数校验失败返回校验错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			apiErr := errors.ErrInvalidParam.WithArgs("ContractNo")
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.CheckLadderQuoteContractClashReq).Validate).Return(apiErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, apiErr)
		})
	})
	t.Run("服务失败返回内部错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.CheckLadderQuoteContractClashReq).Validate).Return(nil).Build()
			Mock(GetMethod(metaService, "CheckLadderQuoteContractClash")).Return(nil, errors.ErrInternalError).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.CheckLadderQuoteContractClash20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_innerVCMetaHandler_GetFeishuViewUrl20210101(t *testing.T) {
	t.Run("缺少合同号返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock((*app.RequestContext).Query).Return("").Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.GetFeishuViewUrl20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("缺少创建人返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var callCount int
			var capturedErr vhertz.APIError
			Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				callCount++
				if key == "ContractNo" {
					return "CN-FEISHU"
				}
				return ""
			}).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.GetFeishuViewUrl20210101(context.Background(), &app.RequestContext{})

			So(callCount, ShouldEqual, 2)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			// Arrange
			Mock((*app.RequestContext).Query).Return("QueryValue").Build()
			Mock(GetMethod(metaService, "QueryFeishuViewUrl")).Return("feishuViewUrl", nil).Build()

			// Act
			v := &innerVCMetaHandler{
				metaService: metaService,
			}
			c := &app.RequestContext{}
			v.GetFeishuViewUrl20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `"Result":"feishuViewUrl"`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("服务失败返回内部错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			var capturedErr vhertz.APIError
			Mock((*app.RequestContext).Query).Return("QueryValue").Build()
			Mock(GetMethod(metaService, "QueryFeishuViewUrl")).Return("", fmt.Errorf("query failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{metaService: metaService}
			v.GetFeishuViewUrl20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_innerVCMetaHandler_SearchOpportunity20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.SearchOpportunity20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})
	t.Run("case #1", func(t *testing.T) {
		PatchConvey("", t, func() {
			// Arrange
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(c360cli.SearchOpportunity).Return(map[string][]*opportunity.OpportunityInfoByAccountIdentity{"AccName": {{}}}, nil).Build()

			// Act
			v := &innerVCMetaHandler{}
			c := &app.RequestContext{}
			v.SearchOpportunity20210101(context.Background(), c)

			// Assert
			So(string(c.Response.Body()), ShouldContainSubstring, `"Result":{"AccName":[{}]}`)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
	t.Run("c360查询失败返回内部错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(c360cli.SearchOpportunity).Return(nil, fmt.Errorf("c360 failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()

			v := &innerVCMetaHandler{}
			v.SearchOpportunity20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrInternalError.GetCode())
		})
	})
}

func Test_innerTOPMetaHandler_SearchAccountIndustryByCustomerName20210101(t *testing.T) {
	PatchConvey("success", t, func() {
		h := &innerVCMetaHandler{}
		c := &app.RequestContext{}

		Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
			req := obj.(*modelsthird.SearchAccountIndustryByCustomerNameReq)
			req.CustomerName = "客户A"
			return nil
		}).Build()
		expected := &c360cli.CustomerIndustryInfo{IndustryCKey: "Government", IndustryCDec: "政府"}
		Mock(c360cli.SearchAccountIndustryByCustomerName).To(func(ctx context.Context, customerName string) (*c360cli.CustomerIndustryInfo, error) {
			So(customerName, ShouldEqual, "客户A")
			return expected, nil
		}).Build()

		var capturedResp interface{}
		Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			capturedResp = result
		}).Build()

		h.SearchAccountIndustryByCustomerName20210101(context.Background(), c)

		So(capturedResp, ShouldResemble, expected)
	})

	PatchConvey("bind fail", t, func() {
		h := &innerVCMetaHandler{}
		c := &app.RequestContext{}

		Mock(binding.BindAndValidate).Return(conmmonerror.New("bind fail")).Build()
		Mock(logs.CtxError).Return().Build()

		var capturedErr vhertz.APIError
		Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
			capturedErr = err
		}).Build()

		h.SearchAccountIndustryByCustomerName20210101(context.Background(), c)

		So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
	})

	PatchConvey("missing customer name", t, func() {
		h := &innerVCMetaHandler{}
		c := &app.RequestContext{}

		Mock(binding.BindAndValidate).Return(nil).Build()

		var capturedErr vhertz.APIError
		Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
			capturedErr = err
		}).Build()

		h.SearchAccountIndustryByCustomerName20210101(context.Background(), c)

		So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
	})

	PatchConvey("c360 fail", t, func() {
		h := &innerVCMetaHandler{}
		c := &app.RequestContext{}

		Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
			req := obj.(*modelsthird.SearchAccountIndustryByCustomerNameReq)
			req.CustomerName = "客户A"
			return nil
		}).Build()
		Mock(c360cli.SearchAccountIndustryByCustomerName).Return(nil, conmmonerror.New("c360 fail")).Build()

		var capturedErr vhertz.APIError
		Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
			capturedErr = err
		}).Build()

		h.SearchAccountIndustryByCustomerName20210101(context.Background(), c)

		So(capturedErr, ShouldNotBeNil)
	})
}

func Test_innerVCMetaHandler_ListOperationRecord20210101(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			Mock((*app.RequestContext).Query).Return("ContractNo").Build()
			Mock(GetMethod(opRecordService, "ListByContractNo")).Return([]*bizmodels.CooperationRecord{{}}, nil).Build()

			// Act
			v := &innerVCMetaHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			expectedBody, _ := jsonV2.Marshal([]*bizmodels.CooperationRecord{{}})
			// Assert
			So(string(ctx.Response.Body()), ShouldContainSubstring, string(expectedBody))
		})
	})
	t.Run("case miss ContractNo", func(t *testing.T) {
		PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			Mock((*app.RequestContext).Query).Return("").Build()
			Mock(GetMethod(opRecordService, "ListByContractNo")).Return([]*bizmodels.CooperationRecord{{}}, nil).Build()

			// Act
			v := &innerVCMetaHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			// Assert
			So(string(ctx.Response.Body()), ShouldContainSubstring, "The parameter [ContractNo] is missing.")
		})
	})
	t.Run("case ListByContractNoFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			opRecordService := cooperationrecord.NewService()
			// Arrange
			Mock((*app.RequestContext).Query).Return("ContractNo").Build()
			Mock(GetMethod(opRecordService, "ListByContractNo")).Return(nil, fmt.Errorf("ListByContractNoFail")).Build()

			// Act
			v := &innerVCMetaHandler{
				opRecordService: opRecordService,
			}

			ctx := &app.RequestContext{}
			v.ListOperationRecord20210101(context.Background(), ctx)
			// Assert
			So(string(ctx.Response.Body()), ShouldContainSubstring, `ListByContractNoFail`)
		})
	})
}

func Test_innerVCMetaHandler_GetContractRedirectInfo20210101(t *testing.T) {
	t.Run("缺少合同号返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock((*app.RequestContext).Query).Return("").Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.GetContractRedirectInfo20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("缺少操作人邮箱返回参数错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock((*app.RequestContext).Query).Return("CN-REDIRECT").Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.GetContractRedirectInfo20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("服务成功返回重定向信息", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			resp := &bizmodels.GetContractRedirectInfoResp{ContractRedirectInfo: &bizmodels.ContractRedirectInfo{RedirectPage: "detail"}}
			var capturedReq *bizmodels.GetContractRedirectInfoReq
			var capturedResult interface{}

			Mock((*app.RequestContext).Query).Return("CN-REDIRECT").Build()
			Mock(GetMethod(metaService, "GetContractRedirectInfo")).To(func(_ context.Context, req *bizmodels.GetContractRedirectInfoReq) (*bizmodels.GetContractRedirectInfoResp, errors.APIError) {
				capturedReq = req
				return resp, nil
			}).Build()
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "operator@bytedance.com")
			h := &innerVCMetaHandler{metaService: metaService}
			h.GetContractRedirectInfo20210101(ctx, &app.RequestContext{})

			So(capturedReq.ContractNo, ShouldEqual, "CN-REDIRECT")
			So(capturedReq.OperatorEmail, ShouldEqual, "operator@bytedance.com")
			So(capturedResult, ShouldEqual, resp)
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaService := contractmeta.NewMetaService()
			serviceErr := errors.ErrInternalError
			var capturedErr vhertz.APIError

			Mock((*app.RequestContext).Query).Return("CN-REDIRECT").Build()
			Mock(GetMethod(metaService, "GetContractRedirectInfo")).Return(nil, serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "operator@bytedance.com")
			h := &innerVCMetaHandler{metaService: metaService}
			h.GetContractRedirectInfo20210101(ctx, &app.RequestContext{})

			So(capturedErr, ShouldEqual, serviceErr)
		})
	})
}

func Test_CheckRelateSubjectParty20210101(t *testing.T) {
	PatchConvey("Test CheckRelateSubjectParty20210101", t, func() {
		metaServiceV2 := contractmeta.NewMetaServiceV2()
		// Mock dependencies
		h := &innerVCMetaHandler{
			metaServiceV2: metaServiceV2,
		}
		c := &app.RequestContext{}

		PatchConvey("Test BindAndValidate failed", func() {
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate error")).Build()
			h.CheckRelateSubjectParty20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test param.Validate failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			param := &contractmeta.CheckRelateSubjectPartyReq{}
			Mock(GetMethod(param, "Validate")).Return(errors.ErrorCommon.WithArgs("validate error")).Build()
			h.CheckRelateSubjectParty20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test CheckRelateSubjectParty failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			param := &contractmeta.CheckRelateSubjectPartyReq{}
			Mock(GetMethod(param, "Validate")).Return(nil).Build()
			Mock(GetMethod(h.metaServiceV2, "CheckRelateSubjectParty")).Return(errors.ErrorCommon.WithArgs("check relate subject party error")).Build()
			h.CheckRelateSubjectParty20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
		})

		PatchConvey("Test CheckRelateSubjectParty success", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			param := &contractmeta.CheckRelateSubjectPartyReq{}
			Mock(GetMethod(param, "Validate")).Return(nil).Build()
			Mock(GetMethod(h.metaServiceV2, "CheckRelateSubjectParty")).Return(nil).Build()
			h.CheckRelateSubjectParty20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
		})
	})
}

func Test_CheckRelateSubjectParty_GetEffectiveSubjectMap20210101(t *testing.T) {
	PatchConvey("Test GetEffectiveSubjectMap20210101", t, func() {
		// Mock the app.RequestContext
		c := &app.RequestContext{}
		param := &contractmeta.GetEffectiveSubjectMapReq{}
		metaServiceV2 := contractmeta.NewMetaServiceV2()
		h := &innerVCMetaHandler{
			metaServiceV2: metaServiceV2,
		}

		// Mock the binding.BindAndValidate function
		PatchConvey("Test binding.BindAndValidate failed", func() {
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate failed")).Build()
			h := &innerVCMetaHandler{}
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		// Mock the param.Validate function
		PatchConvey("Test param.Validate failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(param, "Validate")).Return(errors.ErrorCommon.WithArgs("validate failed")).Build()
			h := &innerVCMetaHandler{}
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		// Mock the metaServiceV2.GetEffectiveSubjectMap function
		PatchConvey("Test metaServiceV2.GetEffectiveSubjectMap failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(param, "Validate")).Return(nil).Build()
			Mock(GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(nil, errors.ErrorCommon.WithArgs("get effective subject map failed")).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
		})

		// Mock the metaServiceV2.GetEffectiveSubjectMap function successfully
		PatchConvey("Test metaServiceV2.GetEffectiveSubjectMap success", func() {
			expectedRes := map[string]*bizmodels.TradePartyInfoDetail{
				"account1": {
					AccountID: "account1",
					// Fill in other fields as needed
				},
			}
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(GetMethod(param, "Validate")).Return(nil).Build()
			Mock(GetMethod(h.metaServiceV2, "GetEffectiveSubjectMap")).Return(expectedRes, nil).Build()
			h.GetEffectiveSubjectMap20210101(context.Background(), c)
			expectedBody, _ := jsonV2.Marshal(expectedRes)
			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(c.Response.Body()), ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_CheckCurrencyAndExchangeRate20210101(t *testing.T) {
	PatchConvey("Test CheckCurrencyAndExchangeRate20210101", t, func() {
		// Mock dependencies
		h := &innerVCMetaHandler{}
		c := &app.RequestContext{}

		PatchConvey("Test BindAndValidate failed", func() {
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate error")).Build()
			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
			// Assert that the error response is set
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test param validation failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*metabasic.CheckCurrencyAndExchangeRateReq).Validate).Return(errors.ErrorCommon.WithArgs("validation error")).Build()
			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
			// Assert that the error response is set
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test CheckCurrencyAndExchangeRate failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*metabasic.CheckCurrencyAndExchangeRateReq).Validate).Return(nil).Build()
			Mock(basicinfo.CheckCurrencyAndExchangeRate).Return(nil, errors.ErrorCommon.WithArgs("internal error")).Build()
			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
			// Assert that the error response is set
			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
		})

		PatchConvey("Test CheckCurrencyAndExchangeRate success", func() {
			expectedRes := &metabasic.CheckCurrencyAndExchangeRateResp{}
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*metabasic.CheckCurrencyAndExchangeRateReq).Validate).Return(nil).Build()
			Mock(basicinfo.CheckCurrencyAndExchangeRate).Return(expectedRes, nil).Build()
			h.CheckCurrencyAndExchangeRate20210101(context.Background(), c)
			expectedBody, _ := jsonV2.Marshal(expectedRes)
			// Assert that the response is set correctly
			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(c.Response.Body()), ShouldContainSubstring, string(expectedBody))
		})
	})
}

func Test_innerVCMetaHandler_GetQuoteFormInstanceUrl20210101(t *testing.T) {
	// 测试GetQuoteFormInstanceUrl返回错误的场景
	t.Run("GetQuoteFormInstanceUrlReturnError", func(t *testing.T) {
		PatchConvey("", t, func() {
			quoteService := quote.NewQuoteService()
			Mock((*errors.ErrorStruct).Error).Return("Mocked error return 1").Build()
			Mock(vhertz.ErrorResp).Return().Build()
			Mock((*app.RequestContext).Query).Return("Search result mock data").Build()
			// [目标分支] newQuoteServiceRet1Mock != nil
			Mock(quote.NewQuoteService).Return(quoteService).Build()
			// [目标分支] getQuoteFormInstanceUrlRet2Mock != nil
			Mock(GetMethod(quoteService, "GetQuoteFormInstanceUrl")).Return("https://example.com/quote/form/instance/123", errors.ErrorCommon).Build()
			// 构造函数入参
			cTest := &app.RequestContext{}
			receiver := &innerVCMetaHandler{}
			// 断言值由大模型生成，需要评估是否符合预期值!
			So(func() { receiver.GetQuoteFormInstanceUrl20210101(context.Background(), cTest) }, ShouldNotPanic)
		})
	})
	// 测试GetQuoteFormInstanceUrl返回错误的场景
	t.Run("GetQuoteFormInstanceUrlReturnNil", func(t *testing.T) {
		PatchConvey("", t, func() {
			quoteService := quote.NewQuoteService()
			Mock(vhertz.DoResponse).Return().Build()
			Mock((*app.RequestContext).Query).Return("Search result mock data").Build()
			// [目标分支] newQuoteServiceRet1Mock != nil
			Mock(quote.NewQuoteService).Return(quoteService).Build()
			// [目标分支] getQuoteFormInstanceUrlRet2Mock == nil
			Mock(GetMethod(quoteService, "GetQuoteFormInstanceUrl"), OptUnsafe).Return("https://example.com/quote/form/instance/123", nil).Build()
			// 构造函数入参
			cTest := &app.RequestContext{}
			receiver := &innerVCMetaHandler{}
			// 断言值由大模型生成，需要评估是否符合预期值!
			So(func() { receiver.GetQuoteFormInstanceUrl20210101(context.Background(), cTest) }, ShouldNotPanic)
		})
	})
}

func Test_innerVCMetaHandler_UpdateUrgentInfo20210101(t *testing.T) {
	t.Run("成功场景", func(t *testing.T) {
		PatchConvey("当请求参数有效且服务层执行成功时，应返回成功响应", t, func() {
			// 场景描述:
			// 模拟一个合法的请求，其中参数绑定、校验均成功，且底层服务也成功处理请求。
			// 预期结果是HTTP状态码为200，并返回一个表示操作成功的标准JSON响应。
			// 逻辑链路:
			// 1. Mock binding.BindAndValidate 成功，并填充一个合法的请求体。
			// 2. Mock h.metaServiceV2.UpdateUrgentInfo 成功返回 nil。
			// 3. 调用目标处理函数。
			// 4. 断言响应状态码和响应体内容符合预期。

			// 数据构造
			metaServiceV2 := contractmeta.NewMetaServiceV2()

			// Mock
			Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req, ok := obj.(*metasupport.UpdateUrgentInfoReq)
				if !ok {
					return fmt.Errorf("type assertion failed")
				}
				req.CurrentOperator = "test.operator"
				req.ContractNo = "CN20240101001"
				req.IsUrgent = true
				req.UrgentCode = _const.UrgentCodeSprint
				return nil
			}).Build()
			Mock(GetMethod(metaServiceV2, "UpdateUrgentInfo")).Return(nil).Build()

			// 调用
			h := &innerVCMetaHandler{
				metaServiceV2: metaServiceV2,
			}
			c := &app.RequestContext{}
			h.UpdateUrgentInfo20210101(context.Background(), c)

			// 断言
			So(c.Response.StatusCode(), ShouldEqual, http.StatusOK)
			// DoResponse(c, nil) 结果为nil时，Result字段会因omitempty而被省略
			So(string(c.Response.Body()), ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}`)
			So(string(c.Response.Body()), ShouldNotContainSubstring, `"Error"`)
		})
	})

	t.Run("失败场景 - 参数绑定失败", func(t *testing.T) {
		PatchConvey("当参数绑定失败时，应返回参数解析错误", t, func() {
			// 场景描述:
			// 模拟请求绑定和校验失败的场景。
			// 预期结果是HTTP状态码为400，并返回参数解析失败的错误信息。
			// 逻辑链路:
			// 1. Mock binding.BindAndValidate 返回一个错误。
			// 2. 调用目标处理函数。
			// 3. 断言响应状态码和响应体中的错误码符合预期。

			// Mock
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()

			// 调用
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}
			h.UpdateUrgentInfo20210101(context.Background(), c)

			// 断言
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("失败场景 - 参数校验失败", func(t *testing.T) {
		PatchConvey("当业务参数校验失败时，应返回参数校验错误", t, func() {
			// 场景描述:
			// 模拟请求绑定成功，但业务逻辑校验（如必填字段为空）失败的场景。
			// 预期结果是HTTP状态码为400，并返回参数解析失败的错误信息。
			// 逻辑链路:
			// 1. Mock binding.BindAndValidate 成功，但填充一个不合法的请求体（ContractNo为空）。
			// 2. 调用目标处理函数，此时 param.Validate() 会失败。
			// 3. 断言响应状态码和响应体中的错误码符合预期。

			// Mock
			Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req, ok := obj.(*metasupport.UpdateUrgentInfoReq)
				if !ok {
					return fmt.Errorf("type assertion failed")
				}
				req.CurrentOperator = "test.operator"
				req.ContractNo = "" // 使 param.Validate() 失败
				return nil
			}).Build()

			// 调用
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}
			h.UpdateUrgentInfo20210101(context.Background(), c)

			// 断言
			So(c.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"MissingParam"`)
		})
	})

	t.Run("失败场景 - 服务层返回错误", func(t *testing.T) {
		PatchConvey("当服务层更新操作失败时，应返回内部错误", t, func() {
			// 场景描述:
			// 模拟参数和校验均通过，但底层服务（如数据库操作）执行失败的场景。
			// 预期结果是HTTP状态码为500，并返回内部错误的错误信息。
			// 逻辑链路:
			// 1. Mock binding.BindAndValidate 成功。
			// 2. Mock h.metaServiceV2.UpdateUrgentInfo 返回一个错误。
			// 3. 调用目标处理函数。
			// 4. 断言响应状态码和响应体中的错误码符合预期。

			// 数据构造
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			internalErr := fmt.Errorf("database connection failed")

			// Mock
			Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req, ok := obj.(*metasupport.UpdateUrgentInfoReq)
				if !ok {
					return fmt.Errorf("type assertion failed")
				}
				req.CurrentOperator = "test.operator"
				req.ContractNo = "CN20240101001"
				return nil
			}).Build()
			Mock(GetMethod(metaServiceV2, "UpdateUrgentInfo")).Return(internalErr).Build()

			// 调用
			h := &innerVCMetaHandler{
				metaServiceV2: metaServiceV2,
			}
			c := &app.RequestContext{}
			h.UpdateUrgentInfo20210101(context.Background(), c)

			// 断言
			So(c.Response.StatusCode(), ShouldEqual, http.StatusInternalServerError)
			So(string(c.Response.Body()), ShouldContainSubstring, `"Code":"`+errors.ErrInternalError.GetCode()+`"`)
		})
	})

	t.Run("成功场景 - 从上下文覆盖当前操作人", func(t *testing.T) {
		PatchConvey("当上下文存在内部用户信息时，应写入EmployeeEmail", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			var capturedParam *metasupport.UpdateUrgentInfoReq
			Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*metasupport.UpdateUrgentInfoReq)
				req.ContractNo = "CN20240101002"
				req.CurrentOperator = "request.operator@bytedance.com"
				return nil
			}).Build()
			Mock(GetMethod(metaServiceV2, "UpdateUrgentInfo")).To(func(_ context.Context, req *metasupport.UpdateUrgentInfoReq) error {
				capturedParam = req
				return nil
			}).Build()
			Mock(vhertz.DoResponse).Return().Build()

			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{EmployeeEmail: "ctx.operator@bytedance.com"})
			h := &innerVCMetaHandler{metaServiceV2: metaServiceV2}
			h.UpdateUrgentInfo20210101(ctx, &app.RequestContext{})

			So(capturedParam.CurrentOperator, ShouldEqual, "ctx.operator@bytedance.com")
		})
	})
}

func Test_innerVCMetaHandler_GetUrgentInfo20210101(t *testing.T) {
	// 准备通用测试对象
	h := &innerVCMetaHandler{
		metaServiceV2: contractmeta.NewMetaServiceV2(),
	}

	t.Run("成功场景-获取加急信息成功", func(t *testing.T) {
		PatchConvey("当参数绑定、校验和Service层调用均成功时，应返回加急信息", t, func() {
			// Arrange: 构造数据和Mock依赖
			// 场景描述:
			// - 参数绑定和校验成功
			// - 上下文包含有效的用户信息
			// - metaServiceV2.GetUrgentInfo 成功返回数据
			// 逻辑链路:
			// 1. binding.BindAndValidate 成功，并填充 ContractNo
			// 2. h.fetchUserInfoFromCtx 成功，返回用户信息
			// 3. param.Validate 成功
			// 4. h.metaServiceV2.GetUrgentInfo 成功
			// 5. vhertz.DoResponse 被调用并返回结果

			// 数据构造
			c := &app.RequestContext{}
			ctx := context.Background()
			userInfo := &bizmodels.AuthInnerUserInfo{EmployeeEmail: "test.operator@example.com"}
			ctxWithUser := context.WithValue(ctx, _const.CtxCurrentUser, userInfo)
			expectedUrgentInfo := &bizmodels.UrgentInfo{
				Operator:   "test.operator@example.com",
				UrgentCode: "URGENT_CODE_01",
				UrgentName: "紧急类型01",
			}
			var capturedResult interface{}
			var capturedGetUrgentInfoReq *metasupport.GetUrgentInfoReq

			// Mock
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*metasupport.GetUrgentInfoReq); ok {
					p.ContractNo = "CN20231024001"
				}
				return nil
			}).Build()
			Mock(GetMethod(h.metaServiceV2, "GetUrgentInfo")).To(func(ctx context.Context, req *metasupport.GetUrgentInfoReq) (*bizmodels.UrgentInfo, error) {
				capturedGetUrgentInfoReq = req
				return expectedUrgentInfo, nil
			}).Build()
			Mock(vhertz.ErrorResp).Return().Build()
			Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			// Act: 调用目标函数
			h.GetUrgentInfo20210101(ctxWithUser, c)

			// Assert: 断言结果
			So(capturedResult, ShouldNotBeNil)
			resultInfo, ok := capturedResult.(*bizmodels.UrgentInfo)
			So(ok, ShouldBeTrue)
			So(resultInfo.UrgentCode, ShouldEqual, "URGENT_CODE_01")
			So(capturedGetUrgentInfoReq, ShouldNotBeNil)
			So(capturedGetUrgentInfoReq.CurrentOperator, ShouldEqual, "test.operator@example.com")
			So(capturedGetUrgentInfoReq.ContractNo, ShouldEqual, "CN20231024001")
		})
	})

	t.Run("失败场景-参数绑定失败", func(t *testing.T) {
		PatchConvey("当 binding.BindAndValidate 失败时，应返回参数解析错误", t, func() {
			// Arrange: 构造数据和Mock依赖
			var capturedError errors.APIError
			bindErr := conmmonerror.New("binding failed")

			Mock(binding.BindAndValidate).Return(bindErr).Build()
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// Act: 调用目标函数
			h.GetUrgentInfo20210101(context.Background(), &app.RequestContext{})

			// Assert: 断言结果
			So(capturedError, ShouldNotBeNil)
			So(capturedError.Error(), ShouldContainSubstring, errors.ErrParamParseFail.Error())
		})
	})

	t.Run("失败场景-参数校验失败", func(t *testing.T) {
		PatchConvey("当 param.Validate 失败时，应返回参数缺失错误", t, func() {
			// Arrange: 构造数据和Mock依赖
			var capturedError errors.APIError

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				// 模拟绑定成功，但缺少 ContractNo 导致后续校验失败
				if p, ok := obj.(*metasupport.GetUrgentInfoReq); ok {
					p.ContractNo = ""
					p.CurrentOperator = "test.operator@example.com"
				}
				return nil
			}).Build()
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()
			Mock(multienv.I18nFormatMapper).Return(map[string]string{}).Build()

			// Act: 调用目标函数
			h.GetUrgentInfo20210101(context.Background(), &app.RequestContext{})

			// Assert: 断言结果
			So(capturedError, ShouldNotBeNil)
			So(capturedError.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
			So(capturedError.GetMessage(context.Background(), nil), ShouldContainSubstring, "is missing")
		})
	})

	t.Run("失败场景-Service层调用失败", func(t *testing.T) {
		PatchConvey("当 metaServiceV2.GetUrgentInfo 失败时，应返回内部错误", t, func() {
			// Arrange: 构造数据和Mock依赖
			var capturedError errors.APIError
			serviceErr := conmmonerror.New("internal service error")

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*metasupport.GetUrgentInfoReq); ok {
					p.ContractNo = "CN20231024001"
					p.CurrentOperator = "test.operator@example.com"
				}
				return nil
			}).Build()
			Mock(GetMethod(h.metaServiceV2, "GetUrgentInfo")).Return(nil, serviceErr).Build()
			Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedError = err
			}).Build()

			// Act: 调用目标函数
			h.GetUrgentInfo20210101(context.Background(), &app.RequestContext{})

			// Assert: 断言结果
			So(capturedError, ShouldNotBeNil)
			So(capturedError.GetCode(), ShouldEqual, errors.ErrInternalError.GetCode())
			So(capturedError.Error(), ShouldContainSubstring, serviceErr.Error())
		})
	})

	t.Run("边缘场景-上下文中无用户信息", func(t *testing.T) {
		PatchConvey("当上下文中无用户信息时，报错", t, func() {
			// Arrange: 构造数据和Mock依赖
			var capturedResult interface{}

			// Mock: 注意此处 RPCContext 返回一个空 context
			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*metasupport.GetUrgentInfoReq); ok {
					p.ContractNo = "CN20231024002"
				}
				return nil
			}).Build()
			Mock(vhertz.ErrorResp).Return().Build()
			Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			// Act: 调用目标函数
			h.GetUrgentInfo20210101(context.Background(), &app.RequestContext{})

			// Assert: 断言结果
			So(capturedResult, ShouldBeNil)
		})
	})
}

func Test_downloadAttachmentCore(t *testing.T) {
	t.Run("失败场景-下载接口返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 构造请求上下文
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}
			ctx := context.Background()

			// 构造metaService实例并Mock Download返回错误
			metaSvc := contractmeta.NewMetaService()
			expectErr := vhertz.NewErrorStruct("DownloadFailCode", "download failed", 500)
			Mock(GetMethod(metaSvc, "Download")).To(func(_ context.Context, _ *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return nil, "", "", expectErr
			}).Build()

			// 捕获错误响应
			var capturedErr vhertz.APIError
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// 执行目标函数
			downloadAttachmentCore(ctx, metaSvc, &bizmodels.MetaAttachmentDownloadParam{
				CurrentOperator: "tester@bytedance.com",
				DownloadID:      "file_001",
			}, c)

			// 断言
			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, "DownloadFailCode")
			So(capturedErr.GetMessage(context.Background(), c), ShouldContainSubstring, "download failed")
		})
	})

	t.Run("失败场景-返回空文件数据", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 构造请求上下文
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}
			ctx := context.Background()

			// 构造metaService实例并Mock Download返回空文件数据
			metaSvc := contractmeta.NewMetaService()
			Mock(GetMethod(metaSvc, "Download")).To(func(_ context.Context, _ *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return []byte{}, "", "empty.txt", nil
			}).Build()

			// 捕获ErrorResp入参和是否调用Data、Header.Set
			var capturedErr vhertz.APIError
			var headerSetCalled int
			var dataCalled int

			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			Mock((*protocol.ResponseHeader).Set).To(func(_ *protocol.ResponseHeader, _ string, _ string) {
				headerSetCalled++
			}).Build()
			Mock((*app.RequestContext).Data).To(func(_ *app.RequestContext, _ int, _ string, _ []byte) {
				dataCalled++
			}).Build()

			// 执行目标函数
			downloadAttachmentCore(ctx, metaSvc, &bizmodels.MetaAttachmentDownloadParam{
				CurrentOperator: "tester@bytedance.com",
				DownloadID:      "file_002",
			}, c)

			// 断言：应传入nil错误，且不会设置Header或调用Data
			So(capturedErr, ShouldBeNil)
			So(headerSetCalled, ShouldEqual, 0)
			So(dataCalled, ShouldEqual, 0)
		})
	})

	t.Run("成功场景-设置下载响应头并写入文件数据", func(t *testing.T) {
		PatchConvey("", t, func() {
			c := &app.RequestContext{Response: protocol.Response{Header: protocol.ResponseHeader{}}}
			ctx := context.Background()
			metaSvc := contractmeta.NewMetaService()
			var dataCalled bool
			Mock(GetMethod(metaSvc, "Download")).To(func(_ context.Context, _ *bizmodels.MetaAttachmentDownloadParam) ([]byte, string, string, errors.APIError) {
				return []byte("file-content"), "", "contract.pdf", nil
			}).Build()
			Mock((*app.RequestContext).Data).To(func(_ *app.RequestContext, code int, contentType string, data []byte) {
				dataCalled = true
				So(code, ShouldEqual, 200)
				So(contentType, ShouldEqual, "application/octet-stream")
				So(string(data), ShouldEqual, "file-content")
			}).Build()

			downloadAttachmentCore(ctx, metaSvc, &bizmodels.MetaAttachmentDownloadParam{DownloadID: "file_003"}, c)

			So(c.Response.Header.Get("Content-Disposition"), ShouldEqual, "attachment;filename=contract.pdf")
			So(c.Response.Header.Get("Content-type"), ShouldEqual, "application/octet-stream")
			So(dataCalled, ShouldBeTrue)
		})
	})

}

type Mock_MetaService_downloadAttachmentCore struct {
	contractmeta.MetaService
}

func Test_innerVCMetaHandler_handleMultiFileDownload(t *testing.T) {
	t.Run("合同号存在-查询元数据失败-返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			ctx := context.Background()
			h := &innerVCMetaHandler{
				metaService: contractmeta.NewMetaService(),
			}
			param := &bizmodels.MetaBatchAttachmentDownloadParam{
				ContractNo: "CN001",
			}
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}

			var capturedErr vhertz.APIError

			// 拦截错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// mock dao方法返回错误
			daoInst := dal.NewContractMetaDao()
			Mock(GetMethod(daoInst, "FindLastByNo")).To(func(_ context.Context, _ *gorm.DB, _ string) (*model.ContractMetaDB, error) {
				return nil, conmmonerror.New("db error")
			}).Build()

			h.handleMultiFileDownload(ctx, param, c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("合同号存在-未查询到元数据-返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			ctx := context.Background()
			h := &innerVCMetaHandler{
				metaService: contractmeta.NewMetaService(),
			}
			param := &bizmodels.MetaBatchAttachmentDownloadParam{
				ContractNo: "CN-NOT-FOUND",
			}
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}

			var capturedErr vhertz.APIError

			// 拦截错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			// mock dao方法返回nil元数据
			daoInst := dal.NewContractMetaDao()
			Mock(GetMethod(daoInst, "FindLastByNo")).To(func(_ context.Context, _ *gorm.DB, _ string) (*model.ContractMetaDB, error) {
				return nil, nil
			}).Build()

			h.handleMultiFileDownload(ctx, param, c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("合同号为空-批量下载服务返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			ctx := context.Background()
			// 使用真实服务实例，然后对其方法进行GetMethod打桩
			ms := contractmeta.NewMetaService()
			h := &innerVCMetaHandler{
				metaService: ms,
			}
			param := &bizmodels.MetaBatchAttachmentDownloadParam{
				ContractNo: "",
			}
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}

			var setHeaders [][2]string
			var capturedStatus int
			var capturedWriter io.Writer
			var capturedZipFileName string
			var capturedErrorResp vhertz.APIError

			// 拦截响应头设置
			MockUnsafe((*protocol.ResponseHeader).Set).To(func(_ *protocol.ResponseHeader, key, value string) {
				setHeaders = append(setHeaders, [2]string{key, value})
			}).Build()
			// 拦截状态码设置
			MockUnsafe((*app.RequestContext).SetStatusCode).To(func(_ *app.RequestContext, statusCode int) {
				capturedStatus = statusCode
			}).Build()
			// 拦截批量下载，模拟错误返回，记录writer和文件名
			Mock(GetMethod(ms, "BatchDownload")).To(func(_ context.Context, _ *bizmodels.MetaBatchAttachmentDownloadParam, w io.Writer, zipFileName string) (string, errors.APIError) {
				capturedWriter = w
				capturedZipFileName = zipFileName
				return "", errors.ErrParamParseFail
			}).Build()
			// 拦截错误响应避免真实输出
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErrorResp = err
			}).Build()

			h.handleMultiFileDownload(ctx, param, c)

			// 断言响应头、状态码、文件名等
			So(capturedStatus, ShouldEqual, 200)
			So(capturedWriter, ShouldNotBeNil)

			expectedFilename := fmt.Sprintf(contractmeta.BatchDownloadFilenameFormat, "", "")
			So(capturedZipFileName, ShouldEqual, expectedFilename)

			// 响应头应包含三项设置
			So(len(setHeaders) >= 3, ShouldBeTrue)
			var hasDisposition, hasContentType, hasTransferEncoding bool
			for _, kv := range setHeaders {
				if kv[0] == "Content-Disposition" && kv[1] == ("attachment;filename="+expectedFilename) {
					hasDisposition = true
				}
				if kv[0] == "Content-type" && kv[1] == "application/zip" {
					hasContentType = true
				}
				if kv[0] == "Transfer-Encoding" && kv[1] == "chunked" {
					hasTransferEncoding = true
				}
			}
			So(hasDisposition, ShouldBeTrue)
			So(hasContentType, ShouldBeTrue)
			So(hasTransferEncoding, ShouldBeTrue)

			// 流式错误情况下不应调用ErrorResp
			So(capturedErrorResp, ShouldBeNil)
		})
	})

	t.Run("合同号存在-元数据存在-批量下载服务成功", func(t *testing.T) {
		PatchConvey("", t, func() {
			ctx := context.Background()
			ms := contractmeta.NewMetaService()
			h := &innerVCMetaHandler{
				metaService: ms,
			}
			// 合同号和名称包含需要清洗的字符
			rawContractNo := "CN/001"
			rawContractName := "Name\"Test\\Slash/End"
			param := &bizmodels.MetaBatchAttachmentDownloadParam{
				ContractNo: rawContractNo,
			}
			c := &app.RequestContext{
				Response: protocol.Response{
					Header: protocol.ResponseHeader{},
				},
			}

			var setHeaders [][2]string
			var capturedStatus int
			var capturedWriter io.Writer
			var capturedZipFileName string

			// 拦截响应头设置
			MockUnsafe((*protocol.ResponseHeader).Set).To(func(_ *protocol.ResponseHeader, key, value string) {
				setHeaders = append(setHeaders, [2]string{key, value})
			}).Build()
			// 拦截状态码设置
			MockUnsafe((*app.RequestContext).SetStatusCode).To(func(_ *app.RequestContext, statusCode int) {
				capturedStatus = statusCode
			}).Build()
			// mock dao方法返回有效元数据
			daoInst := dal.NewContractMetaDao()
			Mock(GetMethod(daoInst, "FindLastByNo")).To(func(_ context.Context, _ *gorm.DB, _ string) (*model.ContractMetaDB, error) {
				return &model.ContractMetaDB{ContractName: rawContractName}, nil
			}).Build()
			// 拦截批量下载，模拟成功
			Mock(GetMethod(ms, "BatchDownload")).To(func(_ context.Context, _ *bizmodels.MetaBatchAttachmentDownloadParam, w io.Writer, zipFileName string) (string, errors.APIError) {
				capturedWriter = w
				capturedZipFileName = zipFileName
				return "", nil
			}).Build()

			h.handleMultiFileDownload(ctx, param, c)

			So(capturedStatus, ShouldEqual, 200)
			So(capturedWriter, ShouldNotBeNil)

			sanitizedNo := util.SanitizeString(rawContractNo)
			sanitizedName := util.SanitizeString(rawContractName)
			expectedFilename := fmt.Sprintf(contractmeta.BatchDownloadFilenameFormat, sanitizedNo, sanitizedName)
			So(capturedZipFileName, ShouldEqual, expectedFilename)

			// 响应头应包含三项设置
			So(len(setHeaders) >= 3, ShouldBeTrue)
			var hasDisposition, hasContentType, hasTransferEncoding bool
			for _, kv := range setHeaders {
				if kv[0] == "Content-Disposition" && kv[1] == ("attachment;filename="+expectedFilename) {
					hasDisposition = true
				}
				if kv[0] == "Content-type" && kv[1] == "application/zip" {
					hasContentType = true
				}
				if kv[0] == "Transfer-Encoding" && kv[1] == "chunked" {
					hasTransferEncoding = true
				}
			}
			So(hasDisposition, ShouldBeTrue)
			So(hasContentType, ShouldBeTrue)
			So(hasTransferEncoding, ShouldBeTrue)
		})
	})
}

type Mock_MetaService_handleMultiFileDownload struct {
	contractmeta.MetaService
}

type Mock_ContractMetaDao_handleMultiFileDownload struct {
	dal.ContractMetaDao
}

func Test_innerVCMetaHandler_releaseDownloadLocks(t *testing.T) {
	t.Run("正常释放锁并打印日志", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 标记Unlock是否被调用
			unlockCalled := false

			// 避免真实调用Redis客户端
			MockUnsafe((*rediscli.RedisLock).Unlock).To(func(_ *rediscli.RedisLock) {
				unlockCalled = true
			}).Build()

			// 避免日志内部defaultLogger未初始化导致panic
			MockUnsafe(logs.CtxInfo).Return().Build()

			h := &innerVCMetaHandler{}
			ctx := context.Background()
			redisLock := &rediscli.RedisLock{
				LockKey: "test-lock-key",
				Value:   "test-value",
			}

			h.releaseDownloadLocks(ctx, redisLock, "test-lock-key")

			So(unlockCalled, ShouldBeTrue)
		})
	})
}

func Test_innerVCMetaHandler_acquireDownloadLocks(t *testing.T) {
	t.Run("成功获取锁-返回锁对象、正确的锁Key和true", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 模拟logid返回
			MockUnsafe(logid.GetLogIDFromCtx).Return("log-123", true).Build()
			// 模拟加锁成功
			Mock((*rediscli.RedisLock).Lock).Return(nil).Build()

			h := &innerVCMetaHandler{}
			ctx := context.Background()
			operator := "operatorA"
			contractNo := "contract001"
			downloadIDs := []string{"id2", "id1", "id3"}

			// 计算期望的锁Key（按照函数中的排序与哈希规则）
			idsCopy := append([]string(nil), downloadIDs...)
			sort.Strings(idsCopy)
			raw := strings.Join(idsCopy, ",")
			sum := sha256.Sum256([]byte(raw))
			expectKey := fmt.Sprintf("vcp:contractmeta:batch_download:%s:%s:%x", operator, contractNo, sum)

			lock, key, ok := h.acquireDownloadLocks(ctx, operator, contractNo, downloadIDs)

			So(ok, ShouldBeTrue)
			So(lock, ShouldNotBeNil)
			So(key, ShouldEqual, expectKey)
			So(lock.LockKey, ShouldEqual, expectKey)
			So(lock.Timeout, ShouldEqual, 5*time.Minute)
			So(strings.HasPrefix(lock.Value, "log-123_"), ShouldBeTrue)
		})
	})

	t.Run("获取锁失败-返回nil、空Key和false", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 模拟logid返回
			MockUnsafe(logid.GetLogIDFromCtx).Return("log-456", true).Build()
			// 模拟加锁失败
			Mock((*rediscli.RedisLock).Lock).Return(conmmonerror.New("lock failed")).Build()

			h := &innerVCMetaHandler{}
			ctx := context.Background()
			operator := "operatorB"
			contractNo := "contractXYZ"
			downloadIDs := []string{"b", "a"}

			lock, key, ok := h.acquireDownloadLocks(ctx, operator, contractNo, downloadIDs)

			So(ok, ShouldBeFalse)
			So(lock, ShouldBeNil)
			So(key, ShouldEqual, "")
		})
	})
}

func Test_innerVCMetaHandler_BatchDownloadMetaAttachment20210101(t *testing.T) {
	t.Run("绑定失败-返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var capturedErr vhertz.APIError

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 绑定失败
			MockUnsafe(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			// 捕获错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("下载ID为空-返回暂无可下载文件错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var capturedErr vhertz.APIError

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 参数绑定成功，但DownloadIDs为空
			MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MetaBatchAttachmentDownloadParam); ok {
					p.CurrentOperator = ""
					p.DownloadIDs = ""
					p.ContractNo = ""
				}
				return nil
			}).Build()
			// 捕获错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrNoDownloadableFiles.GetCode())
		})
	})

	t.Run("文件数量校验失败-返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var capturedErr vhertz.APIError

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 参数绑定成功，多个下载ID
			MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MetaBatchAttachmentDownloadParam); ok {
					p.CurrentOperator = "op-limit"
					p.DownloadIDs = "id1,id2"
					p.ContractNo = "CN-LIMIT"
				}
				return nil
			}).Build()
			// 文件数量校验失败
			Mock(contractmeta.ValidateBatchDownloadFileCount).Return(errors.ErrInvalidParam.WithArgs("limit exceeded")).Build()
			// 捕获错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrInvalidParam.GetCode())
		})
	})

	t.Run("获取分布式锁失败-返回正在下载请稍后错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var capturedErr vhertz.APIError

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 参数绑定成功，多个下载ID
			MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MetaBatchAttachmentDownloadParam); ok {
					p.CurrentOperator = "op-lock-fail"
					p.DownloadIDs = "id1,id2"
					p.ContractNo = "CN001"
				}
				return nil
			}).Build()
			// 文件数量校验通过
			Mock(contractmeta.ValidateBatchDownloadFileCount).Return(nil).Build()
			// 获取锁失败
			Mock((*innerVCMetaHandler).acquireDownloadLocks).Return((*rediscli.RedisLock)(nil), "", false).Build()
			// i18n文案
			Mock(i18nfmt.Sprintf).Return("正在下载请稍后").Build()
			// 捕获错误响应
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})

	t.Run("单文件下载-调用downloadAttachmentCore并释放锁", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var releaseCalled bool
			var capturedParam *bizmodels.MetaAttachmentDownloadParam

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 参数绑定成功，单个下载ID
			MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MetaBatchAttachmentDownloadParam); ok {
					p.CurrentOperator = "patched-op"
					p.DownloadIDs = "single-id"
					p.ContractNo = "CN001"
				}
				return nil
			}).Build()
			// 文件数量校验通过
			Mock(contractmeta.ValidateBatchDownloadFileCount).Return(nil).Build()
			// 获取锁成功
			Mock((*innerVCMetaHandler).acquireDownloadLocks).Return(&rediscli.RedisLock{}, "lock-key", true).Build()
			// 释放锁标记
			Mock((*innerVCMetaHandler).releaseDownloadLocks).To(func(_ *innerVCMetaHandler, _ context.Context, _ *rediscli.RedisLock, _ string) {
				releaseCalled = true
			}).Build()
			// 拦截单文件下载核心逻辑并捕获参数
			Mock(downloadAttachmentCore).To(func(_ context.Context, _ contractmeta.MetaService, param *bizmodels.MetaAttachmentDownloadParam, _ *app.RequestContext) {
				capturedParam = param
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(releaseCalled, ShouldBeTrue)
			So(capturedParam, ShouldNotBeNil)
			So(capturedParam.DownloadID, ShouldEqual, "single-id")
			So(capturedParam.CurrentOperator, ShouldEqual, "patched-op")
		})
	})

	t.Run("多文件下载-调用handleMultiFileDownload并释放锁", func(t *testing.T) {
		PatchConvey("", t, func() {
			h := &innerVCMetaHandler{}
			c := &app.RequestContext{}

			var releaseCalled bool
			var capturedParam *bizmodels.MetaBatchAttachmentDownloadParam

			// 操作人查询
			MockUnsafe(queryOperator).Return("operator@example.com").Build()
			// 参数绑定成功，多个下载ID
			MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*bizmodels.MetaBatchAttachmentDownloadParam); ok {
					p.CurrentOperator = "multi-op"
					p.DownloadIDs = "id1,id2"
					p.ContractNo = "CN002"
				}
				return nil
			}).Build()
			// 文件数量校验通过
			Mock(contractmeta.ValidateBatchDownloadFileCount).Return(nil).Build()
			// 获取锁成功
			Mock((*innerVCMetaHandler).acquireDownloadLocks).Return(&rediscli.RedisLock{}, "lock-key", true).Build()
			// 释放锁标记
			Mock((*innerVCMetaHandler).releaseDownloadLocks).To(func(_ *innerVCMetaHandler, _ context.Context, _ *rediscli.RedisLock, _ string) {
				releaseCalled = true
			}).Build()
			// 拦截多文件下载处理并捕获参数
			Mock((*innerVCMetaHandler).handleMultiFileDownload).To(func(_ *innerVCMetaHandler, _ context.Context, param *bizmodels.MetaBatchAttachmentDownloadParam, _ *app.RequestContext) {
				capturedParam = param
			}).Build()

			h.BatchDownloadMetaAttachment20210101(context.Background(), c)

			So(releaseCalled, ShouldBeTrue)
			So(capturedParam, ShouldNotBeNil)
			So(capturedParam.CurrentOperator, ShouldEqual, "multi-op")
			So(capturedParam.DownloadIDs, ShouldEqual, "id1,id2")
			So(capturedParam.ContractNo, ShouldEqual, "CN002")
		})
	})
}

func Test_innerVCMetaHandler_EditExternalCommodityList20210101(t *testing.T) {
	t.Run("解析参数失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 构造上下文
			c := &app.RequestContext{}
			h := &innerVCMetaHandler{}

			// 标记ErrorResp是否被调用
			errorRespCalled := false
			MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			// BindAndValidate返回错误
			MockUnsafe(binding.BindAndValidate).Return(conmmonerror.New("mock bind err")).Build()
			// 防止真实响应
			MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {}).Build()

			h.EditExternalCommodityList20210101(context.Background(), c)

			So(errorRespCalled, ShouldBeTrue)
		})
	})

	t.Run("校验参数失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			c := &app.RequestContext{}
			h := &innerVCMetaHandler{}

			errorRespCalled := false
			MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			// 让BindAndValidate成功，但填充非法参数以触发Validate失败
			MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*modelcommodity.EditExternalCommodityListReq)
				p.ContractNo = ""
				p.CommodityList = nil
				return nil
			}).Build()
			MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {}).Build()

			h.EditExternalCommodityList20210101(context.Background(), c)

			So(errorRespCalled, ShouldBeTrue)
		})
	})

	t.Run("业务处理失败返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			c := &app.RequestContext{}
			h := &innerVCMetaHandler{}

			errorRespCalled := false
			MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {}).Build()
			// 参数绑定成功且合法
			MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*modelcommodity.EditExternalCommodityListReq)
				p.ContractNo = "C123"
				p.CommodityList = bizmodels.ExternalProductInfoList{
					&bizmodels.ExternalProductInfo{RelateQuoteItemID: "Q1", GroupID: 1},
				}
				return nil
			}).Build()
			// 业务处理返回错误
			Mock(audithandler.EditExternalCommodityList).Return(errors.NewErr("MockErr", "mock fail", 500)).Build()

			h.EditExternalCommodityList20210101(context.Background(), c)

			So(errorRespCalled, ShouldBeTrue)
		})
	})

	t.Run("成功返回响应", func(t *testing.T) {
		PatchConvey("", t, func() {
			c := &app.RequestContext{}
			h := &innerVCMetaHandler{}

			errorRespCalled := false
			doResponseCalled := false
			MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()
			MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()
			// 参数绑定成功且合法
			MockUnsafe(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*modelcommodity.EditExternalCommodityListReq)
				p.ContractNo = "C456"
				p.CommodityList = bizmodels.ExternalProductInfoList{
					&bizmodels.ExternalProductInfo{RelateQuoteItemID: "Q2", GroupID: 2},
				}
				return nil
			}).Build()
			// 业务处理成功
			Mock(audithandler.EditExternalCommodityList).Return(nil).Build()

			h.EditExternalCommodityList20210101(context.Background(), c)

			So(doResponseCalled, ShouldBeTrue)
			So(errorRespCalled, ShouldBeFalse)
		})
	})
}

func Test_innerVCMetaHandler_ExportCouponConfig20210101(t *testing.T) {
	t.Run("绑定失败返回参数解析错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(conmmonerror.New("bind failed")).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.ExportCouponConfig20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, errors.ErrParamParseFail)
		})
	})

	t.Run("校验失败返回校验错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &innerVCMetaHandler{}
			h.ExportCouponConfig20210101(context.Background(), &app.RequestContext{})

			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("成功返回并异步调用导出服务", func(t *testing.T) {
		PatchConvey("", t, func() {
			couponRuleService := coupon.NewCouponRuleService()
			called := make(chan *metasupport.ExportCouponConfigReq, 1)
			var capturedResult interface{}

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*metasupport.ExportCouponConfigReq)
				req.ContractNo = "CN-COUPON"
				return nil
			}).Build()
			Mock(queryOperator).Return("coupon.operator@bytedance.com").Build()
			Mock(GetMethod(couponRuleService, "ExportCouponRule")).To(func(_ context.Context, req *metasupport.ExportCouponConfigReq) errors.APIError {
				called <- req
				return nil
			}).Build()
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerVCMetaHandler{couponRuleService: couponRuleService}
			h.ExportCouponConfig20210101(context.Background(), &app.RequestContext{})

			So(capturedResult, ShouldEqual, "success")
			select {
			case req := <-called:
				So(req.ContractNo, ShouldEqual, "CN-COUPON")
				So(req.CurrentOperator, ShouldEqual, "coupon.operator@bytedance.com")
			case <-time.After(time.Second):
				So("ExportCouponRule not called", ShouldEqual, "called")
			}
		})
	})

	t.Run("异步导出失败仅记录日志仍同步返回成功", func(t *testing.T) {
		PatchConvey("", t, func() {
			couponRuleService := coupon.NewCouponRuleService()
			called := make(chan struct{}, 1)
			var capturedResult interface{}

			Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*metasupport.ExportCouponConfigReq)
				req.ContractNo = "CN-COUPON-ERR"
				req.CurrentOperator = "req.operator@bytedance.com"
				return nil
			}).Build()
			Mock(GetMethod(couponRuleService, "ExportCouponRule")).To(func(_ context.Context, req *metasupport.ExportCouponConfigReq) errors.APIError {
				called <- struct{}{}
				return errors.ErrInternalError
			}).Build()
			Mock(logs.CtxError).Return().Build()
			Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResult = result
			}).Build()

			h := &innerVCMetaHandler{couponRuleService: couponRuleService}
			h.ExportCouponConfig20210101(context.Background(), &app.RequestContext{})

			So(capturedResult, ShouldEqual, "success")
			select {
			case <-called:
				So(true, ShouldBeTrue)
			case <-time.After(time.Second):
				So("ExportCouponRule not called", ShouldEqual, "called")
			}
		})
	})
}

func Test_innerVCMetaHandler_CustomAuditBizContractInner20210101(t *testing.T) {
	t.Run("转发到CustomAuditBizContract20210101", func(t *testing.T) {
		PatchConvey("", t, func() {
			called := false
			Mock((*innerVCMetaHandler).CustomAuditBizContract20210101).To(func(_ *innerVCMetaHandler, ctx context.Context, c *app.RequestContext) {
				called = true
				So(ctx, ShouldNotBeNil)
				So(c, ShouldNotBeNil)
			}).Build()

			h := &innerVCMetaHandler{}
			h.CustomAuditBizContractInner20210101(context.Background(), &app.RequestContext{})

			So(called, ShouldBeTrue)
		})
	})
}

func Test_innerVCMetaHandler_CheckLadderQuoteContractClashInner20210101(t *testing.T) {
	t.Run("转发到CheckLadderQuoteContractClash20210101", func(t *testing.T) {
		PatchConvey("", t, func() {
			called := false
			Mock((*innerVCMetaHandler).CheckLadderQuoteContractClash20210101).To(func(_ *innerVCMetaHandler, ctx context.Context, c *app.RequestContext) {
				called = true
				So(ctx, ShouldNotBeNil)
				So(c, ShouldNotBeNil)
			}).Build()

			h := &innerVCMetaHandler{}
			h.CheckLadderQuoteContractClashInner20210101(context.Background(), &app.RequestContext{})

			So(called, ShouldBeTrue)
		})
	})
}

func Test_NewInnerVCMetaHandler(t *testing.T) {
	t.Run("新建处理器成功并检查字段非空", func(t *testing.T) {
		PatchConvey("", t, func() {
			// 直接调用目标函数
			h := NewInnerVCMetaHandler()

			// 基本断言：返回不为空
			So(h, ShouldNotBeNil)

			// 断言返回值为具体类型并检查内部字段
			impl, ok := h.(*innerVCMetaHandler)
			So(ok, ShouldBeTrue)
			So(impl, ShouldNotBeNil)
			So(impl.metaService, ShouldNotBeNil)
			So(impl.metaServiceV2, ShouldNotBeNil)
			So(impl.opRecordService, ShouldNotBeNil)
			So(impl.couponRuleService, ShouldNotBeNil)

			// 断言返回值实现vhertz.ActionHandler接口（冗余但确保接口一致性）
			_, ok2 := h.(vhertz.ActionHandler)
			So(ok2, ShouldBeTrue)
		})
	})
}

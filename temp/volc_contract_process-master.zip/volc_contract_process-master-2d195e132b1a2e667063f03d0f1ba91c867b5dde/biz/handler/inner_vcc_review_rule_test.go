package handler

import (
	"context"
	stderrors "errors"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/support/reviewrule"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type fakeReviewRuleService struct {
	reviewrule.Service
	listFn                    func(context.Context, *modelreviewrule.ListReviewRuleReq) (*modelreviewrule.ListReviewRuleResponse, error)
	detailFn                  func(context.Context, *modelreviewrule.GetReviewRuleDetailReq) (*modelreviewrule.GetReviewRuleDetailResponse, error)
	createOrUpdateFn          func(context.Context, *modelreviewrule.CreateOrUpdateReviewRuleReq) (string, error)
	updateStatusFn            func(context.Context, *modelreviewrule.UpdateReviewRuleStatusReq) error
	listSalesDepartmentFn     func(context.Context, *modelreviewrule.ListSalesDepartmentReq) (*modelreviewrule.ListSalesDepartmentResponse, error)
	listSalesDepartmentInfoFn func(context.Context, *modelreviewrule.ListSalesDepartmentReq) (*modelreviewrule.ListSalesDepartmentInfoResponse, error)
	getLarkChatInfoFn         func(context.Context, *modelreviewrule.GetLarkChatInfoReq) (*modelreviewrule.GetLarkChatInfoResponse, error)
	statusEnumsFn             func(context.Context) ([]modelreviewrule.CommonEnumItem, error)
	reviewerRoleEnumsFn       func(context.Context) ([]modelreviewrule.CommonEnumItem, error)
	assigneePriorityEnumsFn   func(context.Context) ([]modelreviewrule.CommonEnumItem, error)
}

func (f *fakeReviewRuleService) GetReviewerRoles(ctx context.Context, email string, ruleId []string) (map[string][]int, error) {
	return nil, nil
}
func (f *fakeReviewRuleService) ListReviewRuleByRuleIds(ctx context.Context, salesDepartmentList []string, withReviewer bool) (map[string]*model.ReviewRule, error) {
	return nil, nil
}
func (f *fakeReviewRuleService) GetPrimaryReviewers(ctx context.Context, salesDepartment string) (map[int][]*model.ReviewRuleReviewer, error) {
	return nil, nil
}
func (f *fakeReviewRuleService) GetReviewerAllSalesDepartmentsAndRoles(ctx context.Context, email string) ([]*reviewrule.ReviewerRoleInfo, error) {
	return nil, nil
}
func (f *fakeReviewRuleService) ListByEmployeeEmail(ctx context.Context, tx *gorm.DB, employeeEmail string, withReviewers bool) (model.ReviewRuleReviewerList, model.ReviewRuleList, error) {
	return nil, nil, nil
}
func (f *fakeReviewRuleService) GetRelatedReviewers(ctx context.Context, email string, ruleId string) (map[int]map[string]struct{}, error) {
	return nil, nil
}
func (f *fakeReviewRuleService) FillReviewers(ctx context.Context, tx *gorm.DB, reviewRules []*model.ReviewRule) error {
	return nil
}
func (f *fakeReviewRuleService) ListReviewRule(ctx context.Context, req *modelreviewrule.ListReviewRuleReq) (*modelreviewrule.ListReviewRuleResponse, error) {
	if f.listFn != nil {
		return f.listFn(ctx, req)
	}
	return &modelreviewrule.ListReviewRuleResponse{}, nil
}
func (f *fakeReviewRuleService) GetReviewRuleDetail(ctx context.Context, req *modelreviewrule.GetReviewRuleDetailReq) (*modelreviewrule.GetReviewRuleDetailResponse, error) {
	if f.detailFn != nil {
		return f.detailFn(ctx, req)
	}
	return &modelreviewrule.GetReviewRuleDetailResponse{}, nil
}
func (f *fakeReviewRuleService) CreateOrUpdateReviewRuleData(ctx context.Context, req *modelreviewrule.CreateOrUpdateReviewRuleReq) (string, error) {
	if f.createOrUpdateFn != nil {
		return f.createOrUpdateFn(ctx, req)
	}
	return "REV-001", nil
}
func (f *fakeReviewRuleService) UpdateReviewRuleStatus(ctx context.Context, req *modelreviewrule.UpdateReviewRuleStatusReq) error {
	if f.updateStatusFn != nil {
		return f.updateStatusFn(ctx, req)
	}
	return nil
}
func (f *fakeReviewRuleService) ListSalesDepartment(ctx context.Context, req *modelreviewrule.ListSalesDepartmentReq) (*modelreviewrule.ListSalesDepartmentResponse, error) {
	if f.listSalesDepartmentFn != nil {
		return f.listSalesDepartmentFn(ctx, req)
	}
	return &modelreviewrule.ListSalesDepartmentResponse{List: []string{"行业"}}, nil
}
func (f *fakeReviewRuleService) ListSalesDepartmentInfo(ctx context.Context, req *modelreviewrule.ListSalesDepartmentReq) (*modelreviewrule.ListSalesDepartmentInfoResponse, error) {
	if f.listSalesDepartmentInfoFn != nil {
		return f.listSalesDepartmentInfoFn(ctx, req)
	}
	return &modelreviewrule.ListSalesDepartmentInfoResponse{}, nil
}
func (f *fakeReviewRuleService) GetLarkChatInfo(ctx context.Context, req *modelreviewrule.GetLarkChatInfoReq) (*modelreviewrule.GetLarkChatInfoResponse, error) {
	if f.getLarkChatInfoFn != nil {
		return f.getLarkChatInfoFn(ctx, req)
	}
	return &modelreviewrule.GetLarkChatInfoResponse{LarkChatID: req.LarkChatID}, nil
}
func (f *fakeReviewRuleService) GetReviewRuleStatusEnums(ctx context.Context) ([]modelreviewrule.CommonEnumItem, error) {
	if f.statusEnumsFn != nil {
		return f.statusEnumsFn(ctx)
	}
	return []modelreviewrule.CommonEnumItem{{Key: 1, Name: "启用"}}, nil
}
func (f *fakeReviewRuleService) GetReviewerRoleEnums(ctx context.Context) ([]modelreviewrule.CommonEnumItem, error) {
	if f.reviewerRoleEnumsFn != nil {
		return f.reviewerRoleEnumsFn(ctx)
	}
	return []modelreviewrule.CommonEnumItem{{Key: 1, Name: "销售运营"}}, nil
}
func (f *fakeReviewRuleService) GetAssigneePriorityEnums(ctx context.Context) ([]modelreviewrule.CommonEnumItem, error) {
	if f.assigneePriorityEnumsFn != nil {
		return f.assigneePriorityEnumsFn(ctx)
	}
	return []modelreviewrule.CommonEnumItem{{Key: 1, Name: "审批人"}}, nil
}

func mockReviewRuleBind(fill func(interface{})) {
	mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
		if fill != nil {
			fill(obj)
		}
		return nil
	}).Build()
}

func validReviewRuleRoles() []*modelreviewrule.ReviewerRolesItem {
	return []*modelreviewrule.ReviewerRolesItem{
		{ReviewerRole: _const.ReviewerRoleSalesOp, AssigneePriorities: []*modelreviewrule.AssigneePriorityItem{{AssigneePriority: _const.AssigneePriorityPrimary, Reviewers: []*modelreviewrule.ReviewerRolesReviewer{{EmployeeEmail: "a@example.com"}}}}},
		{ReviewerRole: _const.ReviewerRoleFinanceAR, AssigneePriorities: []*modelreviewrule.AssigneePriorityItem{{AssigneePriority: _const.AssigneePriorityPrimary, Reviewers: []*modelreviewrule.ReviewerRolesReviewer{{EmployeeEmail: "b@example.com"}}}}},
		{ReviewerRole: _const.ReviewerRoleFinanceBP, AssigneePriorities: []*modelreviewrule.AssigneePriorityItem{{AssigneePriority: _const.AssigneePriorityPrimary, Reviewers: []*modelreviewrule.ReviewerRolesReviewer{{EmployeeEmail: "c@example.com"}}}}},
		{ReviewerRole: _const.ReviewerRoleTaxBP, AssigneePriorities: []*modelreviewrule.AssigneePriorityItem{{AssigneePriority: _const.AssigneePriorityPrimary, Reviewers: []*modelreviewrule.ReviewerRolesReviewer{{EmployeeEmail: "d@example.com"}}}}},
		{ReviewerRole: _const.ReviewerRoleLegalBP, AssigneePriorities: []*modelreviewrule.AssigneePriorityItem{{AssigneePriority: _const.AssigneePriorityPrimary, Reviewers: []*modelreviewrule.ReviewerRolesReviewer{{EmployeeEmail: "e@example.com"}}}}},
	}
}

func TestNewInnerRiviewRuleHandler(t *testing.T) {
	mockey.PatchConvey("创建 handler", t, func() {
		convey.So(NewInnerRiviewRuleHandler(), convey.ShouldNotBeNil)
	})
}

func TestInnerRiviewRuleHandlerListReviewRule20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("成功返回列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.ListReviewRuleReq).Status = "1" })
			expected := &modelreviewrule.ListReviewRuleResponse{Total: 1}
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{listFn: func(ctx context.Context, req *modelreviewrule.ListReviewRuleReq) (*modelreviewrule.ListReviewRuleResponse, error) {
				return expected, nil
			}}}).ListReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.body, convey.ShouldEqual, expected)
		})
	})
}

func TestInnerRiviewRuleHandlerGetReviewRuleDetail20210101(t *testing.T) {
	t.Run("校验失败不调用服务", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(nil)
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).GetReviewRuleDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
		})
	})
	t.Run("成功返回详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.GetReviewRuleDetailReq).RuleID = "REV-001" })
			expected := &modelreviewrule.GetReviewRuleDetailResponse{RuleID: "REV-001"}
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{detailFn: func(ctx context.Context, req *modelreviewrule.GetReviewRuleDetailReq) (*modelreviewrule.GetReviewRuleDetailResponse, error) {
				return expected, nil
			}}}).GetReviewRuleDetail20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.body, convey.ShouldEqual, expected)
		})
	})
}

func TestInnerRiviewRuleHandlerCreateOrUpdateReviewRule20210101(t *testing.T) {
	t.Run("校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(nil)
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).CreateOrUpdateReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
		})
	})
	t.Run("成功返回规则ID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) {
				req := obj.(*modelreviewrule.CreateOrUpdateReviewRuleReq)
				req.SalesDepartment = "行业"
				req.ReviewerRoles = validReviewRuleRoles()
			})
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).CreateOrUpdateReviewRule20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.body, convey.ShouldEqual, "REV-001")
		})
	})
}

func TestInnerRiviewRuleHandlerUpdateReviewRuleStatus20210101(t *testing.T) {
	t.Run("service错误返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) { req := obj.(*modelreviewrule.UpdateReviewRuleStatusReq); req.Status = 1 })
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{updateStatusFn: func(ctx context.Context, req *modelreviewrule.UpdateReviewRuleStatusReq) error {
				return stderrors.New("svc")
			}}}).UpdateReviewRuleStatus20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrCommon.GetCode())
		})
	})
	t.Run("成功返回空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.UpdateReviewRuleStatusReq).Status = 1 })
			(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).UpdateReviewRuleStatus20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}

func TestInnerRiviewRuleHandlerListSalesDepartment20210101(t *testing.T) {
	mockey.PatchConvey("成功返回销售行业", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(nil)
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListSalesDepartment20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerListSalesDepartmentInfo20210101(t *testing.T) {
	mockey.PatchConvey("成功返回销售行业详情", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(nil)
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListSalesDepartmentInfo20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerGetLarkChatInfo20210101(t *testing.T) {
	mockey.PatchConvey("成功返回飞书群信息", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.GetLarkChatInfoReq).LarkChatID = "chat" })
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).GetLarkChatInfo20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerGetReviewRuleStatusEnums20210101(t *testing.T) {
	mockey.PatchConvey("成功返回规则状态枚举", t, func() {
		rec := mockRiskClauseTplResp()
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).GetReviewRuleStatusEnums20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerGetReviewerRoleEnums20210101(t *testing.T) {
	mockey.PatchConvey("成功返回审批角色枚举", t, func() {
		rec := mockRiskClauseTplResp()
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).GetReviewerRoleEnums20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerGetAssigneePriorityEnums20210101(t *testing.T) {
	mockey.PatchConvey("成功返回分配优先级枚举", t, func() {
		rec := mockRiskClauseTplResp()
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).GetAssigneePriorityEnums20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerRiviewRuleHandlerListReviewRuleInner20210101(t *testing.T) {
	mockey.PatchConvey("复用 ListReviewRule", t, func() {
		rec := mockRiskClauseTplResp()
		mockReviewRuleBind(func(obj interface{}) { obj.(*modelreviewrule.ListReviewRuleReq).Status = "1" })
		(&innerRiviewRuleHandler{service: &fakeReviewRuleService{}}).ListReviewRuleInner20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

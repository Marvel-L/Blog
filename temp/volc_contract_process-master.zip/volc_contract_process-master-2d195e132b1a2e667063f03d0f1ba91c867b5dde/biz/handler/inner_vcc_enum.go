package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
)

// 合同中心对外接口——业务合同场景，用于免审批签章流程
type innerVCCEnumHandler struct {
	base
}

func NewInnerVCCEnumHandler() vhertz.ActionHandler {
	return &innerVCCEnumHandler{}
}

func (h *innerVCCEnumHandler) GetSpecialContractTypeEnum20210101(ctx context.Context, c *app.RequestContext) {
	// 获取特殊合同类型配置
	typeMap := conf.GetSpecialContractTypeItem(ctx)
	// 若 tcc 中未配置或获取失败时，使用默认配置
	if len(typeMap) == 0 {
		logs.CtxWarn(ctx, "special contract type config is empty")
		typeMap = _const.SpecialContractTypeDisplayMapping
	}
	vhertz.DoResponse(ctx, c, typeMap)
}

package handler

import (
	"context"
	_const "volc_contract_process/pkg/const"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/fresh_seal"
	"volc_contract_process/pkg/errors"
)

// openFreshSealHandler 处理鲜章相关的外部接口请求
type openFreshSealHandler struct {
	base
	// 鲜章申请服务
	freshSealService fresh_seal.FreshSealApprovalService
}

// NewOpenFreshSealHandler 创建鲜章外部接口处理器
func NewOpenFreshSealHandler() vhertz.ActionHandler {
	return &openFreshSealHandler{
		// 初始化鲜章申请服务
		freshSealService: fresh_seal.NewFreshSealApprovalService(),
	}
}

// CreateFreshSeal20210101 外部接口-鲜章申请创建
// @Summary 外部接口-鲜章申请创建
// @Description  该接口用于提交鲜章申请
// @Tags 鲜章相关接口-控制台
// @ID /vcp/open-api/fresh_seal@Create20210101
// @Accept json
// @Param Action query string true "Action-默认值:Create"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param - body bizmodels.FreshSealCreateParam true "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=bizmodels.FreshSealCreateResp} "响应信息"
// @Router /vcp/open-api/fresh_seal/Action_CreateFreshSeal_Version_20210101 [post]
func (h *openFreshSealHandler) CreateFreshSeal20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealCreateParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealCreateReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.AccountId = c.Request.Header.Get(_const.HeaderAccountID)
	// 验证参数
	if err := param.ValidateCreate(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	var (
		resp *bizmodels.FreshSealCreateResp
		err  errors.APIError
	)

	// 调用鲜章申请服务-创建申请单
	resp, err = h.freshSealService.CreateApproval(ctx, &param)

	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// FreshSealDetail20210101 外部接口-鲜章申请详情查询
// @Summary 外部接口-鲜章申请详情查询
// @Description  该接口用于查询鲜章申请详情
// @Tags 鲜章相关接口-控制台
// @ID /vcp/open-api/fresh_seal@Fresh20210101
// @Accept json
// @Param Action query string true "Action-默认值:Fresh"
// @Param Version query string true "Version-默认值:2021-01-01"
// @Param - body bizmodels.FreshSealDetailParam true "请求参数"
// @Success 200  {object}  vhertz.CommonResponse{Result=bizmodels.FreshSealDetailResp} "响应信息"
// @Router /vcp/open-api/fresh_seal/Action_FreshSealDetail_Version_20210101 [get]
func (h *openFreshSealHandler) FreshSealDetail20210101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.FreshSealDetailParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "FreshSealDetailReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.AccountId = c.Request.Header.Get(_const.HeaderAccountID)
	// 验证参数
	if err := param.ValidateDetail(); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 调用鲜章申请详情查询服务
	resp, err := h.freshSealService.GetApprovalDetail(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

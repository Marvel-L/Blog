package handler

import (
	"context"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestPing(t *testing.T) {
	mockey.PatchConvey("返回 pong", t, func() {
		c := &app.RequestContext{}
		Ping(context.Background(), c)
		convey.So(c.Response.StatusCode(), convey.ShouldEqual, 200)
		convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "pong")
	})
}

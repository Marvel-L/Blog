package handler

import (
	"context"
	"fmt"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	contractservice "volc_contract_process/biz/service"
	"volc_contract_process/biz/service/contractmeta"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func Test_innerBizContractHandler_List20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedErr vhertz.APIError
			var capturedResp interface{}
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(capturedResp, convey.ShouldBeNil)
		})
	})

	t.Run("服务返回错误时透传错误响应并设置内部来源", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			serviceErr := errors.ErrorCommon.WithArgs("list failed")
			var capturedReq *bizmodels.BizContractListParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.BizContractListParam)
				req.CurrentOperator = "operator@example.com"
				req.Scene = _const.SceneQuoteContract
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "List")).To(
				func(_ context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
					capturedReq = param
					return nil, serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务成功时返回列表结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			expectedResp := &bizmodels.BizContractListResp{Total: 2, Limit: 10, Offset: 0}
			var capturedResp interface{}
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "List")).Return(expectedResp, nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldBeNil)
			convey.So(capturedResp, convey.ShouldResemble, expectedResp)
		})
	})
}

func Test_innerBizContractHandler_ListContractProcess20210101(t *testing.T) {
	t.Run("复用List20210101并透传ctx和请求上下文", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}
			ctx := context.WithValue(context.Background(), "trace", "list-contract-process")
			c := &app.RequestContext{}
			called := false

			mockey.Mock(mockey.GetMethod(h, "List20210101")).To(func(gotCtx context.Context, gotC *app.RequestContext) {
				called = true
				convey.So(gotCtx, convey.ShouldEqual, ctx)
				convey.So(gotC, convey.ShouldEqual, c)
			}).Build()

			h.ListContractProcess20210101(ctx, c)

			convey.So(called, convey.ShouldBeTrue)
		})
	})
}

func Test_innerBizContractHandler_Detail20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Detail20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			serviceErr := errors.ErrorCommon.WithArgs("detail failed")
			var capturedReq *bizmodels.BizContractDetailParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.BizContractDetailParam)
				req.ContractNo = "CN20240617001"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Detail")).To(
				func(_ context.Context, param *bizmodels.BizContractDetailParam) (*bizmodels.BizContract, errors.APIError) {
					capturedReq = param
					return nil, serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Detail20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("未生效合同时使用未签署文件下载地址", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			contractResp := &bizmodels.BizContract{ContractNo: "CN20240617002", Status: _const.BizContractStatusBeEffective - 1, FileIdUnsigned: "unsigned-file", FileIdSigned: "signed-file"}
			var capturedResp interface{}
			var capturedFileID string
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Detail")).Return(contractResp, nil).Build()
			mockey.Mock(contractservice.Download).To(func(_ context.Context, fileID string) (string, errors.APIError) {
				capturedFileID = fileID
				return "https://example.com/unsigned", nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Detail20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedFileID, convey.ShouldEqual, "unsigned-file")
			convey.So(capturedResp, convey.ShouldResemble, contractResp)
			convey.So(contractResp.FileURL, convey.ShouldEqual, "https://example.com/unsigned")
		})
	})

	t.Run("已生效合同时使用已签署文件下载地址且下载失败仍返回详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			contractResp := &bizmodels.BizContract{ContractNo: "CN20240617003", Status: _const.BizContractStatusBeEffective, FileIdUnsigned: "unsigned-file", FileIdSigned: "signed-file"}
			var capturedResp interface{}
			var capturedFileID string
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Detail")).Return(contractResp, nil).Build()
			mockey.Mock(contractservice.Download).To(func(_ context.Context, fileID string) (string, errors.APIError) {
				capturedFileID = fileID
				return "", errors.ErrorCommon.WithArgs("download failed")
			}).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Detail20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedFileID, convey.ShouldEqual, "signed-file")
			convey.So(capturedResp, convey.ShouldResemble, contractResp)
			convey.So(contractResp.FileURL, convey.ShouldEqual, "")
		})
	})
}

func Test_innerBizContractHandler_Count20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Count20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			serviceErr := errors.ErrorCommon.WithArgs("count failed")
			var capturedReq *bizmodels.BizContractListParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "List")).To(
				func(_ context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {
					capturedReq = param
					return nil, serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Count20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务返回nil时响应0", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedResp interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "List")).Return(nil, nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Count20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedResp, convey.ShouldEqual, 0)
		})
	})

	t.Run("服务成功时响应Total", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedResp interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "List")).Return(&bizmodels.BizContractListResp{Total: 7}, nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Count20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedResp, convey.ShouldEqual, 7)
		})
	})
}

func Test_innerBizContractHandler_Download20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.Download20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			serviceErr := errors.ErrorCommon.WithArgs("download failed")
			var capturedReq *bizmodels.BizContractDetailParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Download")).To(
				func(_ context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError) {
					capturedReq = param
					return nil, "", serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.Download20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务成功时写入下载响应头和二进制内容", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}
			c := &app.RequestContext{}

			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Download")).Return([]byte("contract-bytes"), "contract.docx", nil).Build()
			mockey.Mock(vhertz.ErrorResp).Return().Build()

			h.Download20210101(context.Background(), c)

			convey.So(c.Response.Header.Get("Content-Disposition"), convey.ShouldEqual, "attachment;filename=contract.docx")
			convey.So(c.Response.Header.Get("Content-type"), convey.ShouldEqual, "application/octet-stream")
			convey.So(string(c.Response.Body()), convey.ShouldEqual, "contract-bytes")
		})
	})
}

func Test_innerBizContractHandler_Export20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Export20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			serviceErr := errors.ErrorCommon.WithArgs("export failed")
			var capturedReq *bizmodels.BizContractListParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Export")).To(
				func(_ context.Context, param *bizmodels.BizContractListParam) errors.APIError {
					capturedReq = param
					return serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Export20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务成功时返回空成功响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			bizSvc := contractservice.NewBizContractService()
			h := &innerBizContractHandler{bizContractService: bizSvc}

			var capturedResp interface{} = "not-called"
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(bizSvc, "Export")).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Export20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldBeNil)
			convey.So(capturedResp, convey.ShouldBeNil)
		})
	})
}

func Test_innerBizContractHandler_Audit20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.Audit20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("参数绑定成功时调用auditMeta并传入内部来源", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}
			ctx := context.Background()
			c := &app.RequestContext{}
			var capturedParam *bizmodels.BizContractAuditParam
			called := false

			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.BizContractAuditParam)
				req.Scene = _const.SceneQuoteContract
				req.ContractNo = "CN20240617004"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(h, "auditMeta")).To(func(gotCtx context.Context, gotC *app.RequestContext, param *bizmodels.BizContractAuditParam) {
				called = true
				convey.So(gotCtx, convey.ShouldEqual, ctx)
				convey.So(gotC, convey.ShouldEqual, c)
				capturedParam = param
			}).Build()

			h.Audit20210101(ctx, c)

			convey.So(called, convey.ShouldBeTrue)
			convey.So(capturedParam.SourceType, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(capturedParam.ContractNo, convey.ShouldEqual, "CN20240617004")
		})
	})
}

func Test_innerBizContractHandler_auditMeta(t *testing.T) {
	t.Run("不支持的Scene返回错误且不调用服务", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}
			var capturedErr vhertz.APIError
			var capturedResp interface{}
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.auditMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractAuditParam{Scene: 999})

			convey.So(capturedErr, convey.ShouldNotBeNil)
			convey.So(capturedResp, convey.ShouldBeNil)
		})
	})

	t.Run("产品报价合同场景映射BizScene并透传AbortBiz错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}
			metaSvc := contractmeta.NewMetaService()
			serviceErr := errors.ErrorCommon.WithArgs("abort failed")
			var capturedReq *bizmodels.OpenBizContractAbortParam
			var capturedErr vhertz.APIError
			mockey.Mock(mockey.GetMethod(metaSvc, "AbortBiz")).To(
				func(_ context.Context, param *bizmodels.OpenBizContractAbortParam) errors.APIError {
					capturedReq = param
					return serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.auditMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractAuditParam{
				Scene:           _const.SceneQuoteContract,
				ContractNo:      "CN20240617005",
				ContractVersion: 3,
				Identifier:      "quote-001",
				CurrentOperator: "operator@example.com",
			})

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.BizScene, convey.ShouldEqual, _const.BizSceneQuoteContract)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN20240617005")
			convey.So(capturedReq.BizIdentifier, convey.ShouldEqual, "quote-001")
			convey.So(capturedReq.CurrentOperator, convey.ShouldEqual, "operator@example.com")
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("信控合同场景映射BizScene并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerBizContractHandler{}
			metaSvc := contractmeta.NewMetaService()
			var capturedReq *bizmodels.OpenBizContractAbortParam
			var capturedResp interface{} = "not-called"
			var capturedErr vhertz.APIError
			mockey.Mock(mockey.GetMethod(metaSvc, "AbortBiz")).To(
				func(_ context.Context, param *bizmodels.OpenBizContractAbortParam) errors.APIError {
					capturedReq = param
					return nil
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.auditMeta(context.Background(), &app.RequestContext{}, &bizmodels.BizContractAuditParam{
				Scene:           _const.SceneCreditContract,
				ContractNo:      "CN20240617006",
				ContractVersion: 4,
				Identifier:      "credit-001",
				CurrentOperator: "operator@example.com",
			})

			convey.So(capturedErr, convey.ShouldBeNil)
			convey.So(capturedReq.BizScene, convey.ShouldEqual, _const.BizSceneCreditContract)
			convey.So(capturedResp, convey.ShouldBeNil)
		})
	})
}

func Test_innerBizContractHandler_Revoke20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaSvc := contractmeta.NewMetaService()
			h := &innerBizContractHandler{metaService: metaSvc}

			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Revoke20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaSvc := contractmeta.NewMetaService()
			h := &innerBizContractHandler{metaService: metaSvc}

			serviceErr := errors.ErrorCommon.WithArgs("revoke failed")
			var capturedReq *bizmodels.OpenBizContractRevokeParam
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.OpenBizContractRevokeParam)
				req.ContractNo = "CN20240617007"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(metaSvc, "RevokeBiz")).To(
				func(_ context.Context, param *bizmodels.OpenBizContractRevokeParam) errors.APIError {
					capturedReq = param
					return serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.Revoke20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN20240617007")
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务成功时返回撤销成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaSvc := contractmeta.NewMetaService()
			h := &innerBizContractHandler{metaService: metaSvc}

			var capturedResp interface{}
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(metaSvc, "RevokeBiz")).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.Revoke20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldBeNil)
			convey.So(capturedResp, convey.ShouldResemble, map[string]interface{}{
				"Success": true,
				"Message": "撤销成功",
			})
		})
	})
}

package handler

import (
	"context"
	"strconv"
	"time"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	gopkglogs "code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"code.byted.org/volcengine/volc-bypass-golang/v2/logs"

	"code.byted.org/middleware/hertz/pkg/app"
	faasmodel "volc_contract_process/biz/bizmodels/faas"
	"volc_contract_process/biz/service/notify"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/cronjob"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

const (
	defaultCronJobLoopcountLimit = 500
)

type innerCronJobReq struct {
	LoopcountLimit int    `json:"LoopcountLimit" form:"LoopcountLimit" query:"LoopcountLimit"`
	ContractNoList string `json:"ContractNoList" form:"ContractNoList" query:"ContractNoList"`
}

type compliancePeriodicScreenRemindReq struct {
	UpdateTime     string `json:"UpdateTime" form:"UpdateTime" query:"UpdateTime"`
	ContractNoList string `json:"ContractNoList" form:"ContractNoList" query:"ContractNoList"`
}

type innerFaaSNotifyHandler struct {
	base
	riskEngineService riskengineservice.RiskEngineService
}

func NewInnerFaaSNotifyHandler() vhertz.ActionHandler {
	return &innerFaaSNotifyHandler{
		riskEngineService: riskengineservice.NewRiskEngineService(),
	}
}

// ContractEffectedToExpiredCronJob20210101 刷新合同生效/失效状态
func (h *innerFaaSNotifyHandler) ContractEffectedToExpiredCronJob20210101(ctx context.Context, c *app.RequestContext) {

	var req innerCronJobReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		gopkglogs.CtxError(ctx, "ContractEffectedToExpiredCronJobReqBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	var args []string
	if req.LoopcountLimit > 0 {
		args = []string{"", strconv.Itoa(req.LoopcountLimit)}
	}
	gopkglogs.CtxInfo(ctx, "ContractEffectedToExpiredCronJobHTTPStart, args:%v", args)
	go cronjob.DefaultHandler.ContractEffectedToExpiredCronJob(args)
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"TaskName": "ContractEffectedToExpiredCronJob",
		"Args":     args,
		"Message":  "success",
	})
}

// ContractSyncBasicInfo20210101 同步 OA 合同基础信息
func (h *innerFaaSNotifyHandler) ContractSyncBasicInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req innerCronJobReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		gopkglogs.CtxError(ctx, "ContractSyncBasicInfoReqBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	var args []string
	if req.LoopcountLimit > 0 || req.ContractNoList != "" {
		loopcountLimit := req.LoopcountLimit
		if loopcountLimit <= 0 {
			loopcountLimit = defaultCronJobLoopcountLimit
		}
		args = []string{strconv.Itoa(loopcountLimit)}
		if req.ContractNoList != "" {
			args = append(args, req.ContractNoList)
		}
	}
	gopkglogs.CtxInfo(ctx, "ContractSyncBasicInfoHTTPStart, args:%v", args)
	go cronjob.DefaultHandler.ContractSyncBasicInfo(args)
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"TaskName": "ContractSyncBasicInfo",
		"Args":     args,
		"Message":  "success",
	})
}

// ContractFeishuSyncBasicInfo20210101 同步飞书合同基础信息
func (h *innerFaaSNotifyHandler) ContractFeishuSyncBasicInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req innerCronJobReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		gopkglogs.CtxError(ctx, "ContractFeishuSyncBasicInfoReqBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	var args []string
	if req.LoopcountLimit > 0 || req.ContractNoList != "" {
		if req.ContractNoList != "" {
			args = append(args, req.ContractNoList)
		} else {
			args = append(args, "")
		}
		if req.LoopcountLimit > 0 {
			args = append(args, strconv.Itoa(req.LoopcountLimit))
		}
	}
	gopkglogs.CtxInfo(ctx, "ContractFeishuSyncBasicInfoHTTPStart, args:%v", args)
	go cronjob.DefaultHandler.ContractFeishuSyncBasicInfo(args)
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"TaskName": "ContractFeishuSyncBasicInfo",
		"Args":     args,
		"Message":  "success",
	})
}

// CompliancePeriodicScreenRemind20210101 合规定期审查提醒入口
func (h *innerFaaSNotifyHandler) CompliancePeriodicScreenRemind20210101(ctx context.Context, c *app.RequestContext) {
	var req compliancePeriodicScreenRemindReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		gopkglogs.CtxError(ctx, "CompliancePeriodicScreenRemindReqBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	gopkglogs.CtxInfo(ctx, "CompliancePeriodicScreenRemindHTTPStart, updateTime:%s, contractNoList:%s", req.UpdateTime, req.ContractNoList)

	if apiErr := h.riskEngineService.HandleCompliancePeriodicScreenOrder(ctx, &riskengineservice.CompliancePeriodicScreenOrderReq{
		UpdateTime:     req.UpdateTime,
		ContractNoList: req.ContractNoList,
	}); apiErr != nil {
		gopkglogs.CtxError(ctx, "CompliancePeriodicScreenRemindFail, err:%s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"TaskName":       "CompliancePeriodicScreenRemind",
		"UpdateTime":     req.UpdateTime,
		"ContractNoList": req.ContractNoList,
		"Message":        "success",
	})
}

func (h *innerFaaSNotifyHandler) FreshSealApprovalUnmailedDailyReminder20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "FreshSealApprovalUnmailedDailyReminder Start")
	notify.SendMsgV2(ctx, notify.MsgEventFreshSealApprovalUnmailedDailyReminder, &notify.MsgContext{})
	logs.CtxInfo(ctx, "FreshSealApprovalUnmailedDailyReminder End")
}

// SendLongTimeNotArchivedNotify20250101 合同长时间未归档提醒入口
func (h *innerFaaSNotifyHandler) SendLongTimeNotArchivedNotify20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "SendLongTimeNotArchivedNotify20210101 Start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "SendLongTimeNotArchivedNotify20210101 BindAndValidate error: %v", err)

		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	ext := notify.MsgContextExtLongTimeNotArchived{
		ContractNoList: param.ContractNos,
	}

	notify.SendMsgV2(ctx, notify.MsgEventContractLongTimeNotArchived, &notify.MsgContext{ExtInfo: ext, CreatorID: param.CreatorID})

	logs.CtxInfo(ctx, "SendLongTimeNotArchivedNotify20210101 end")

	vhertz.DoResponse(ctx, c, map[string]string{"message": "success"})
}

// SendLongTimeNotApprovalNotify20250101 合同长时间未审批提醒入口（飞书合同）
func (h *innerFaaSNotifyHandler) SendLongTimeNotApprovalNotify20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "SendLongTimeNotApprovalNotify20210101 start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "SendLongTimeNotApprovalNotify20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	ext := notify.MsgContextExtLongTimeNotArchived{
		ContractNoList: param.ContractNos,
	}
	notify.SendMsgV2(ctx, notify.MsgEventContractLongTimeNotApproval, &notify.MsgContext{ExtInfo: ext, CreatorID: param.CreatorID})
	logs.CtxInfo(ctx, "SendLongTimeNotApprovalNotify20210101 end")

	vhertz.DoResponse(ctx, c, map[string]string{"message": "success"})
}

// ContractReviewSummaryRemind20210101 合同审核汇总提醒入口（HTTP触发，不依赖cron）
func (h *innerFaaSNotifyHandler) ContractReviewSummaryRemind20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "ContractReviewSummaryRemind20210101 start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ContractReviewSummaryRemind20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 直接调用notify.SendMsgV2发送消息
	msgCtx := &notify.MsgContext{
		ExtInfo: notify.MsgContextExtContractReviewSummaryRemind{
			ContractNoList: param.ContractNos, // 空列表表示由消息构建器自动查询
		},
	}
	notify.SendMsgV2(ctx, notify.MsgEventContractReviewSummaryRemind, msgCtx)
	logs.CtxInfo(ctx, "ContractReviewSummaryRemind20210101 end")
	vhertz.DoResponse(ctx, c, map[string]interface{}{"message": "success"})
}

// ContractReviewFullProcessRemind20210101 合同全流程待审核汇总提醒入口（HTTP触发，不依赖cron）
func (h *innerFaaSNotifyHandler) ContractReviewFullProcessRemind20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "ContractReviewFullProcessRemind20210101 start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ContractReviewFullProcessRemind20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 直接调用notify.SendMsgV2发送消息
	msgCtx := &notify.MsgContext{
		ExtInfo: notify.MsgContextExtContractReviewSummaryRemind{
			ContractNoList: param.ContractNos, // 空列表表示由消息构建器自动查询
		},
	}
	notify.SendMsgV2(ctx, notify.MsgEventContractReviewFullProcessRemind, msgCtx)
	logs.CtxInfo(ctx, "ContractReviewFullProcessRemind20210101 end")
	vhertz.DoResponse(ctx, c, map[string]interface{}{"message": "success"})
}

// ContractSalesOpExpireRemind20210101 合同即将到期提醒（销售）
func (h *innerFaaSNotifyHandler) ContractSalesOpExpireRemind20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "ContractSalesOpExpireRemind20210101 start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ContractSalesOpExpireRemind20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	pDate, _ := time.ParseInLocation(util.DateFormatTpl, param.PDate, time.Local)
	// 直接调用notify.SendMsgV2发送消息
	msgCtx := &notify.MsgContext{
		ExtInfo: notify.MsgContextExtExpireRemind{
			ContractNoList: param.ContractNos, // 空列表表示由消息构建器自动查询
			PDate:          pDate,
		},
	}
	notify.SendMsgV2(ctx, notify.MsgEventSalesOpExpireRemind, msgCtx)
	logs.CtxInfo(ctx, "ContractSalesOpExpireRemind20210101 end")
	vhertz.DoResponse(ctx, c, map[string]interface{}{"message": "success"})
}

// ContractCustomerExpireRemind20210101 合同即将到期提醒（客户）
func (h *innerFaaSNotifyHandler) ContractCustomerExpireRemind20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "ContractsustomerExpireRemind20210101 start")
	var param faasmodel.NotifyParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "ContractsustomerExpireRemind20210101 BindAndValidate error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	pDate, _ := time.ParseInLocation(util.DateFormatTpl, param.PDate, time.Local)
	// 直接调用notify.SendMsgV2发送消息
	msgCtx := &notify.MsgContext{
		ExtInfo: notify.MsgContextExtExpireRemind{
			ContractNoList: param.ContractNos, // 空列表表示由消息构建器自动查询
			PDate:          pDate,
		},
	}
	notify.SendMsgV2(ctx, notify.MsgEventCustomerExpireRemind, msgCtx)
	logs.CtxInfo(ctx, "ContractsustomerExpireRemind20210101 end")
	vhertz.DoResponse(ctx, c, map[string]interface{}{"message": "success"})
}

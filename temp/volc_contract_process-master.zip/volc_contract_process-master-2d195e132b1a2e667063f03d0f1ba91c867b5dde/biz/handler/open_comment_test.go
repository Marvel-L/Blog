package handler

import (
	"context"
	"fmt"
	"net/http"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/comment"
	"volc_contract_process/pkg/errors"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
)

func Test_openCommentHandler_PublishComment20210101(t *testing.T) {
	PatchConvey("Test PublishComment20210101", t, func() {
		// Mock dependencies
		commentService := comment.NewCommentService()
		handler := &openCommentHandler{
			commentService: commentService,
		}
		mockCtx := &app.RequestContext{}

		PatchConvey("Test BindAndValidate failed", func() {
			Mock(binding.BindAndValidate).Return(fmt.Errorf("bind and validate failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test Validate failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(errors.ErrorCommon.WithArgs("validation failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test PublishComment failed", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(nil).Build()
			Mock(GetMethod(commentService, "PublishComment")).Return(nil, errors.ErrorCommon.WithArgs("publish comment failed")).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusBadRequest)
		})

		PatchConvey("Test PublishComment success", func() {
			Mock(binding.BindAndValidate).Return(nil).Build()
			Mock((*bizmodels.PublishCommentReq).Validate).Return(nil).Build()
			expectedResp := &bizmodels.PublishCommentResp{CommentID: "123"}
			Mock(GetMethod(commentService, "PublishComment")).Return(expectedResp, nil).Build()
			handler.PublishComment20210101(context.Background(), mockCtx)
			So(mockCtx.Response.StatusCode(), ShouldEqual, http.StatusOK)
			So(string(mockCtx.Response.Body()), ShouldContainSubstring, `{"CommentID":"123"}`)
		})
	})
}

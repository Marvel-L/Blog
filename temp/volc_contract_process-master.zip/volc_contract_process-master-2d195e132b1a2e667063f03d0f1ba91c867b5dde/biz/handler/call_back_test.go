package handler

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"errors"
	"strconv"
	"testing"
	"time"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	hertz_ext_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/protocol"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/pkg/conf"
	pkg_errors "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/riskenginecli"
)

func Test_callBackHandler_RiskEngineCallBack20210101(t *testing.T) {
	t.Run("case1 未命中人审", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"1\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("未命中人审，调用无异常", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			// mockErrorResp := mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
			//	convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
			//	convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "service error")
			// }).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "success")
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})
	})

	t.Run("case2 命中人审", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"0\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("命中人审，调用无异常", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			// mockErrorResp := mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
			//	convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
			//	convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "service error")
			// }).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "success")
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})
	})

	t.Run("case3 解析配置错误", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"0\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("解析配置返回err", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, errors.New("test_error1")).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "GetRiskEngineConfFail")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})

		mockey.PatchConvey("解析配置返回nil", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(nil, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "GetRiskEngineConfFail")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})
	})

	t.Run("case4 解析body错误", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"0\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("命中人审，调用无异常", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, errors.New("test_error2")).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "test_error2")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})

	})

	t.Run("case5 时间戳/sign为空", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"0\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("时间戳为空", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return("").
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "Timestamp/Sign Empty")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})

		mockey.PatchConvey("sign为空", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return("").
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "Timestamp/Sign Empty")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})

	})

	t.Run("case6 时间戳解析错误", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host:  "test-host",
			Sec:   "test-secret",
			Icode: "test-icode",
		}

		reqBodyStr := "{\n    \"icode\":\"1001\",\n    \"orderNo\":\"CP20200824000041\",\n    \"outOrderNo\":\"外部单据号，调用合规机审时传递的内容\",\n    \"outOrderType\":\"外部单据类型，调用合规机审时传递的内容\",\n    \"isHit\":\"0\",\n    \"isTransaction\":\"0\",\n    \"checkDetails\":[\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"1\",\n            \"name\":\"test\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN\"\n        },\n        {\n            \"partnerIcode\":\"1001\",\n            \"sid\":\"2\",\n            \"name\":\"test2\",\n            \"isHit\":\"0\",\n            \"isTransaction\":\"1\",\n            \"hitSource\":\"DOW_OFAC/OFAC_SDN/SCO\"\n        }\n    ]\n}"
		reqBodyBytes := []byte(reqBodyStr)

		h := &callBackHandler{}

		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		ctx := context.Background()
		c := &app.RequestContext{
			Request: protocol.Request{},
		}
		c.Set("dummy_context_for_test", ctx)

		riskEngineService := riskengineservice.NewRiskEngineService()

		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("时间戳解析错误", t, func() {

			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return("not a number").
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(nil).Build()
			// mockey.Mock(strconv.ParseInt).Return(0, errors.New("test_error3")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "invalid syntax")
			}).Build()

			// mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
			//	convey.So(result, convey.ShouldEqual, "success")
			// }).Build()

			h.RiskEngineCallBack20210101(context.Background(), &app.RequestContext{})

		})

	})

	t.Run("case7 时间戳失效", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host: "test-host", Sec: "test-secret", Icode: "test-icode",
		}
		reqBodyBytes := []byte("test body")
		h := &callBackHandler{}
		ctx := context.Background()
		c := &app.RequestContext{Request: protocol.Request{}}
		c.Set("dummy_context_for_test", ctx)
		expiredTimestamp := time.Now().UnixMilli() - 6*60*1000 // 6 minutes ago
		expiredTimestampStr := strconv.FormatInt(expiredTimestamp, 10)

		mockey.PatchConvey("时间戳过期", t, func() {
			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(expiredTimestampStr).
				When(func(key string) bool { return key == "sign" }).Return("any-sign").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "Timestamp Expire")
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), c)
		})
	})

	t.Run("case8 签名不匹配", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host: "test-host", Sec: "test-secret", Icode: "test-icode",
		}
		reqBodyStr := "test body"
		reqBodyBytes := []byte(reqBodyStr)
		h := &callBackHandler{}
		ctx := context.Background()
		c := &app.RequestContext{Request: protocol.Request{}}
		c.Set("dummy_context_for_test", ctx)
		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)

		mockey.PatchConvey("签名不匹配", t, func() {
			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return("invalid-sign").
				Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInvalidParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "Invalid Sign")
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), c)
		})
	})

	t.Run("case9 参数绑定错误", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host: "test-host", Sec: "test-secret", Icode: "test-icode",
		}
		reqBodyStr := "test body"
		reqBodyBytes := []byte(reqBodyStr)
		h := &callBackHandler{}
		ctx := context.Background()
		c := &app.RequestContext{Request: protocol.Request{}}
		c.Set("dummy_context_for_test", ctx)
		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)
		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))

		mockey.PatchConvey("参数绑定失败", t, func() {
			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), c)
		})
	})

	t.Run("case10 调用服务失败", func(t *testing.T) {
		riskEngineConf := &conf.RiskEngine{
			Host: "test-host", Sec: "test-secret", Icode: "test-icode",
		}
		reqBodyStr := "test body"
		reqBodyBytes := []byte(reqBodyStr)
		h := &callBackHandler{}
		ctx := context.Background()
		c := &app.RequestContext{Request: protocol.Request{}}
		c.Set("dummy_context_for_test", ctx)
		timestamp := time.Now().UnixMilli()
		timestampStr := strconv.FormatInt(timestamp, 10)
		signStr := reqBodyStr + timestampStr + riskEngineConf.Sec
		h5 := md5.New()
		h5.Write([]byte(signStr))
		expectedSign := hex.EncodeToString(h5.Sum(nil))
		riskEngineService := riskengineservice.NewRiskEngineService()
		RiskEngineCallbackMethod := mockey.GetMethod(riskEngineService, "RiskEngineCallback")

		mockey.PatchConvey("service调用失败", t, func() {
			mockey.Mock(riskenginecli.GetRiskEngineConf).Return(riskEngineConf, nil).Build()
			mockey.Mock((*protocol.Request).BodyE).Return(reqBodyBytes, nil).Build()
			mockey.Mock((*app.RequestContext).Query).
				When(func(key string) bool { return key == "timestamp" }).Return(timestampStr).
				When(func(key string) bool { return key == "sign" }).Return(expectedSign).
				Build()
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(RiskEngineCallbackMethod).Return(pkg_errors.ErrorCommon.WithArgs("service error")).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrInternalError.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "service error")
			}).Build()

			h.RiskEngineCallBack20210101(context.Background(), c)
		})
	})

}

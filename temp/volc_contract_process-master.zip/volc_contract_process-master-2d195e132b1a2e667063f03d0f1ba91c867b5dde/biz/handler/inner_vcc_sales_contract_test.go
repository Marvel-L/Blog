package handler

import (
	"context"
	stderrors "errors"
	"mime/multipart"
	"testing"

	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelsalescontract"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractsettlement/settlementnotify"
	"volc_contract_process/biz/service/salescontract"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/contractperform"
	"volc_contract_process/pkg/proxy/oacli"
	"volc_contract_process/pkg/proxy/rediscli"
)

type fakeSalesContractService struct {
	salescontract.SalesContractService
	createFn     func(context.Context, modelsalescontract.CreateOrUpdateReq) (string, errors.APIError)
	submitFn     func(context.Context, *modelsalescontract.SubmitReq) (*modelsalescontract.SubmitResp, errors.APIError)
	updateAcctFn func(context.Context, *modelsalescontract.UpdateAccountIDReq) errors.APIError
	uploadFn     func(context.Context, *modelsalescontract.UploadReq) (string, errors.APIError)
	syncFn       func(context.Context, []string)
	subjectFn    func(context.Context, *modelsalescontract.ListSubjectOfContractReq) ([]*salescontract.SubjectInfo, errors.APIError)
	productFn    func(context.Context, *modelsalescontract.ListProductOfContractReq) ([]*bizmodels.ProductInformation, errors.APIError)
	editBasicFn  func(context.Context, *modelsalescontract.EditBasicInfoReq) errors.APIError
	performFn    func(context.Context, *gorm.DB, string, bool) errors.APIError
	settlementFn func(context.Context, *gorm.DB, string) errors.APIError
}

func (f *fakeSalesContractService) CreateOrUpdate(ctx context.Context, req modelsalescontract.CreateOrUpdateReq) (string, errors.APIError) {
	if f.createFn != nil {
		return f.createFn(ctx, req)
	}
	return "C-1", nil
}
func (f *fakeSalesContractService) Submit(ctx context.Context, req *modelsalescontract.SubmitReq) (*modelsalescontract.SubmitResp, errors.APIError) {
	if f.submitFn != nil {
		return f.submitFn(ctx, req)
	}
	return &modelsalescontract.SubmitResp{ContractNo: req.ContractNo}, nil
}
func (f *fakeSalesContractService) UpdateAccountID(ctx context.Context, req *modelsalescontract.UpdateAccountIDReq) errors.APIError {
	if f.updateAcctFn != nil {
		return f.updateAcctFn(ctx, req)
	}
	return nil
}
func (f *fakeSalesContractService) Upload(ctx context.Context, req *modelsalescontract.UploadReq) (string, errors.APIError) {
	if f.uploadFn != nil {
		return f.uploadFn(ctx, req)
	}
	return "download-1", nil
}
func (f *fakeSalesContractService) SyncContract(ctx context.Context, contractNoList []string) {
	if f.syncFn != nil {
		f.syncFn(ctx, contractNoList)
	}
}
func (f *fakeSalesContractService) ListSubjectOfContract(ctx context.Context, req *modelsalescontract.ListSubjectOfContractReq) ([]*salescontract.SubjectInfo, errors.APIError) {
	if f.subjectFn != nil {
		return f.subjectFn(ctx, req)
	}
	return []*salescontract.SubjectInfo{{SubjectNo: "S-1"}}, nil
}
func (f *fakeSalesContractService) ListProductOfContract(ctx context.Context, req *modelsalescontract.ListProductOfContractReq) ([]*bizmodels.ProductInformation, errors.APIError) {
	if f.productFn != nil {
		return f.productFn(ctx, req)
	}
	return []*bizmodels.ProductInformation{{}}, nil
}
func (f *fakeSalesContractService) EditBasicInfo(ctx context.Context, req *modelsalescontract.EditBasicInfoReq) errors.APIError {
	if f.editBasicFn != nil {
		return f.editBasicFn(ctx, req)
	}
	return nil
}
func (f *fakeSalesContractService) SyncContractPerform(ctx context.Context, tx *gorm.DB, contractNo string, isContinue bool) errors.APIError {
	if f.performFn != nil {
		return f.performFn(ctx, tx, contractNo, isContinue)
	}
	return nil
}
func (f *fakeSalesContractService) SyncSettlementTerm(ctx context.Context, tx *gorm.DB, contractNo string) errors.APIError {
	if f.settlementFn != nil {
		return f.settlementFn(ctx, tx, contractNo)
	}
	return nil
}

func salesContractUserCtx() context.Context {
	return context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{EmployeeEmail: "op@example.com", EmployeeID: 100})
}

func mockBindError() {
	mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind")).Build()
}

func mockSalesContractGetQuery(values map[string]string) {
	mockey.MockUnsafe((*app.RequestContext).GetQuery).To(func(c *app.RequestContext, key string) (string, bool) {
		val, ok := values[key]
		return val, ok
	}).Build()
}

func TestNewInnerVCCSalesContractHandler(t *testing.T) {
	mockey.PatchConvey("创建销售合同 handler", t, func() { convey.So(NewInnerVCCSalesContractHandler(), convey.ShouldNotBeNil) })
}

func TestInnerVCCSalesContractHandlerCreateOrUpdate20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()
			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).CreateOrUpdate20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.CreateOrUpdateReq).BasicInfo = &bizmodels.BasicInfo{}
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{createFn: func(ctx context.Context, req modelsalescontract.CreateOrUpdateReq) (string, errors.APIError) {
				called = true
				return "", nil
			}}}).CreateOrUpdate20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("svc")
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.CreateOrUpdateReq).BasicInfo = &bizmodels.BasicInfo{}
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{createFn: func(ctx context.Context, req modelsalescontract.CreateOrUpdateReq) (string, errors.APIError) {
				return "", serviceErr
			}}}).CreateOrUpdate20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功时写入内部来源和当前操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelsalescontract.CreateOrUpdateReq)
				req.BasicInfo = &bizmodels.BasicInfo{Department: "生态"}
				return nil
			}).Build()
			var source _const.SourceType
			var operator string
			var department string
			h := &innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{createFn: func(ctx context.Context, req modelsalescontract.CreateOrUpdateReq) (string, errors.APIError) {
				source = req.SourceType
				operator = req.CurrentOperator
				department = req.BasicInfo.Department
				return "C-1", nil
			}}}
			h.CreateOrUpdate20210101(salesContractUserCtx(), &app.RequestContext{})
			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(department, convey.ShouldEqual, "")
			convey.So(rec.body, convey.ShouldEqual, "C-1")
		})
	})
}

func TestInnerVCCSalesContractHandlerSubmit20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).Submit20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{submitFn: func(ctx context.Context, req *modelsalescontract.SubmitReq) (*modelsalescontract.SubmitResp, errors.APIError) {
				called = true
				return nil, nil
			}}}).Submit20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("submit")
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{submitFn: func(ctx context.Context, req *modelsalescontract.SubmitReq) (*modelsalescontract.SubmitResp, errors.APIError) {
				return nil, serviceErr
			}}}).Submit20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功提交时设置内部来源", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var source _const.SourceType
			var operator string
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.SubmitReq).ContractNo = "C-1"
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{submitFn: func(ctx context.Context, req *modelsalescontract.SubmitReq) (*modelsalescontract.SubmitResp, errors.APIError) {
				source = req.SourceType
				operator = req.CurrentOperator
				return &modelsalescontract.SubmitResp{ContractNo: req.ContractNo}, nil
			}}}).Submit20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(rec.doCalled, convey.ShouldBeTrue)
		})
	})
}

func TestInnerVCCSalesContractHandlerSubmitSalesContract20210101(t *testing.T) {
	mockey.PatchConvey("复用 Submit", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
			obj.(*modelsalescontract.SubmitReq).ContractNo = "C-1"
			return nil
		}).Build()
		(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).SubmitSalesContract20210101(salesContractUserCtx(), &app.RequestContext{})
		convey.So(rec.doCalled, convey.ShouldBeTrue)
	})
}

func TestInnerVCCSalesContractHandlerDelete20210101(t *testing.T) {
	t.Run("缺少合同号返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()

			(&innerVCCSalesContractHandler{}).Delete20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录不查询合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).To(func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				called = true
				return nil, nil
			}).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("查询合同失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, stderrors.New("db")).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("合同不存在返回未找到", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrContractNotFound.GetCode())
		})
	})
	t.Run("非草稿合同不能删除", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Status: _const.SalesContractNew}, ContractNo: "C-1"}, nil).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("删除失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Status: _const.SalesContractUnSubmit}, ContractNo: "C-1", Version: 3}, nil).Build()
			mockey.Mock((*MockContractMetaDao).DeleteByNo).Return(stderrors.New("delete")).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("草稿合同删除成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var deletedContractNo string
			var deletedVersion int
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Status: _const.SalesContractUnSubmit}, ContractNo: "C-1", Version: 3}, nil).Build()
			mockey.Mock((*MockContractMetaDao).DeleteByNo).To(func(ctx context.Context, tx *gorm.DB, contractNo string, version int) error {
				deletedContractNo = contractNo
				deletedVersion = version
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{}).Delete20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(deletedContractNo, convey.ShouldEqual, "C-1")
			convey.So(deletedVersion, convey.ShouldEqual, 3)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}

func TestInnerVCCSalesContractHandlerSupply20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{}).Supply20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录时不调用 OA", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			(&innerVCCSalesContractHandler{}).Supply20210101(context.Background(), &app.RequestContext{})
			convey.So(rec.errorCalled, convey.ShouldBeTrue)
		})
	})
	t.Run("OA 授权失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.SupplyReq).ContractNo = "C-1"
				return nil
			}).Build()
			mockey.MockUnsafe(oacli.GrantOAContract).Return(nil, stderrors.New("grant")).Build()

			(&innerVCCSalesContractHandler{}).Supply20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("OA 查询失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.SupplyReq).ContractNo = "C-1"
				return nil
			}).Build()
			mockey.MockUnsafe(oacli.GrantOAContract).Return(nil, nil).Build()
			mockey.MockUnsafe(oacli.SmallQueryContract).Return(nil, stderrors.New("query")).Build()

			(&innerVCCSalesContractHandler{}).Supply20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("OA 授权和查询成功后返回链接", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var grantContractNo string
			var grantEmployeeCode string
			var queryContractNo string
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				obj.(*modelsalescontract.SupplyReq).ContractNo = "C-1"
				return nil
			}).Build()
			mockey.MockUnsafe(oacli.GrantOAContract).To(func(ctx context.Context, contractNo string, employeeCode string) (*oacli.GrantContractResp, error) {
				grantContractNo = contractNo
				grantEmployeeCode = employeeCode
				return nil, nil
			}).Build()
			mockey.MockUnsafe(oacli.SmallQueryContract).To(func(ctx context.Context, contractNo string, needFile bool) (*oacli.QuerySalesContractSmallData, error) {
				queryContractNo = contractNo
				return &oacli.QuerySalesContractSmallData{DetailUrl: "https://oa.example"}, nil
			}).Build()

			(&innerVCCSalesContractHandler{}).Supply20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(grantContractNo, convey.ShouldEqual, "C-1")
			convey.So(grantEmployeeCode, convey.ShouldEqual, "100")
			convey.So(queryContractNo, convey.ShouldEqual, "C-1")
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, map[string]string{"Url": "https://oa.example"})
		})
	})
}

func TestInnerVCCSalesContractHandlerUpload20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).Upload20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("缺少文件返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).Upload20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录不调用上传服务", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe((*app.RequestContext).FormFile).Return(&multipart.FileHeader{Filename: "contract.pdf", Size: 10}, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{uploadFn: func(ctx context.Context, req *modelsalescontract.UploadReq) (string, errors.APIError) {
				called = true
				return "", nil
			}}}).Upload20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误包装为通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe((*app.RequestContext).FormFile).Return(&multipart.FileHeader{Filename: "contract.pdf", Size: 10}, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{uploadFn: func(ctx context.Context, req *modelsalescontract.UploadReq) (string, errors.APIError) {
				return "", errors.ErrorCommon.WithArgs("upload")
			}}}).Upload20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("成功上传返回 downloadID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var source _const.SourceType
			var operator string
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe((*app.RequestContext).FormFile).Return(&multipart.FileHeader{Filename: "contract.pdf", Size: 10}, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{uploadFn: func(ctx context.Context, req *modelsalescontract.UploadReq) (string, errors.APIError) {
				source = req.SourceType
				operator = req.CurrentOperator
				return "download-1", nil
			}}}).Upload20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"downloadID": "download-1"})
		})
	})
}

func TestInnerVCCSalesContractHandlerChange20210101(t *testing.T) {
	t.Run("缺少 ContractNo 返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()

			(&innerVCCSalesContractHandler{}).Change20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("缺少 Creator 返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})

			(&innerVCCSalesContractHandler{}).Change20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1", "Creator": "creator@example.com"})

			(&innerVCCSalesContractHandler{}).Change20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("OA 授权失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1", "Creator": "creator@example.com"})
			mockey.MockUnsafe(oacli.GrantOAContract).Return(nil, stderrors.New("grant")).Build()

			(&innerVCCSalesContractHandler{}).Change20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("OA 查询失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1", "Creator": "creator@example.com"})
			mockey.MockUnsafe(oacli.GrantOAContract).Return(nil, nil).Build()
			mockey.MockUnsafe(oacli.SmallQueryContract).Return(nil, stderrors.New("query")).Build()

			(&innerVCCSalesContractHandler{}).Change20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("成功返回 OA 链接和通知标记", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var checkedCreator string
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1", "Creator": "creator@example.com"})
			mockey.MockUnsafe(oacli.GrantOAContract).Return(nil, nil).Build()
			mockey.MockUnsafe(oacli.SmallQueryContract).Return(&oacli.QuerySalesContractSmallData{DetailUrl: "https://oa.example/change"}, nil).Build()
			mockey.MockUnsafe(rediscli.NeedContractChangeNotify).To(func(ctx context.Context, currentOperator string) bool {
				checkedCreator = currentOperator
				return true
			}).Build()

			(&innerVCCSalesContractHandler{}).Change20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(checkedCreator, convey.ShouldEqual, "creator@example.com")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"Url": "https://oa.example/change", "NeedNotify": true})
		})
	})
}

func TestInnerVCCSalesContractHandlerUpdateAccountID20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).UpdateAccountID20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{updateAcctFn: func(ctx context.Context, req *modelsalescontract.UpdateAccountIDReq) errors.APIError {
				called = true
				return nil
			}}}).UpdateAccountID20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误包装请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
			h := &innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{updateAcctFn: func(ctx context.Context, req *modelsalescontract.UpdateAccountIDReq) errors.APIError {
				return errors.ErrorCommon.WithArgs("svc")
			}}}

			h.UpdateAccountID20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("成功时写入内部来源和操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var source _const.SourceType
			var operator string
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			h := &innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{updateAcctFn: func(ctx context.Context, req *modelsalescontract.UpdateAccountIDReq) errors.APIError {
				source = req.SourceType
				operator = req.CurrentOperator
				return nil
			}}}
			h.UpdateAccountID20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}

func TestInnerVCCSalesContractHandlerListSubjectOfContract20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).ListSubjectOfContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{subjectFn: func(ctx context.Context, req *modelsalescontract.ListSubjectOfContractReq) ([]*salescontract.SubjectInfo, errors.APIError) {
				called = true
				return nil, nil
			}}}).ListSubjectOfContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误包装请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{subjectFn: func(ctx context.Context, req *modelsalescontract.ListSubjectOfContractReq) ([]*salescontract.SubjectInfo, errors.APIError) {
				return nil, errors.ErrorCommon.WithArgs("subject")
			}}}).ListSubjectOfContract20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("成功返回主体列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var source _const.SourceType
			var operator string
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{subjectFn: func(ctx context.Context, req *modelsalescontract.ListSubjectOfContractReq) ([]*salescontract.SubjectInfo, errors.APIError) {
				source = req.SourceType
				operator = req.CurrentOperator
				return []*salescontract.SubjectInfo{{SubjectNo: "S-1"}}, nil
			}}}).ListSubjectOfContract20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"SubjectInfoList": []*salescontract.SubjectInfo{{SubjectNo: "S-1"}}})
		})
	})
}

func TestInnerVCCSalesContractHandlerSyncContract20210101(t *testing.T) {
	t.Run("绑定失败返回请求非法", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).SyncContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrRequestInvalid.GetCode())
		})
	})
	t.Run("空列表直接返回提示", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).SyncContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.body, convey.ShouldEqual, "传入合同号为空")
		})
	})
	t.Run("未登录不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				list := obj.(*[]string)
				*list = []string{"C-1"}
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{syncFn: func(ctx context.Context, contractNoList []string) {
				called = true
			}}}).SyncContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("成功同步合同列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotList []string
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				list := obj.(*[]string)
				*list = []string{"C-1", "C-2"}
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{syncFn: func(ctx context.Context, contractNoList []string) {
				gotList = contractNoList
			}}}).SyncContract20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(gotList, convey.ShouldResemble, []string{"C-1", "C-2"})
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}

func TestInnerVCCSalesContractHandlerSyncSalesContract20210101(t *testing.T) {
	mockey.PatchConvey("复用 SyncContract", t, func() {
		rec := mockRiskClauseTplResp()
		mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()
		(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).SyncSalesContract20210101(context.Background(), &app.RequestContext{})
		convey.So(rec.body, convey.ShouldEqual, "传入合同号为空")
	})
}

func TestInnerVCCSalesContractHandlerListProductOfContract20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).ListProductOfContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("未登录不调用 service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{productFn: func(ctx context.Context, req *modelsalescontract.ListProductOfContractReq) ([]*bizmodels.ProductInformation, errors.APIError) {
				called = true
				return nil, nil
			}}}).ListProductOfContract20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("service 错误透传", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("product")
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{productFn: func(ctx context.Context, req *modelsalescontract.ListProductOfContractReq) ([]*bizmodels.ProductInformation, errors.APIError) {
				return nil, serviceErr
			}}}).ListProductOfContract20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功返回商品列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var source _const.SourceType
			var operator string
			products := []*bizmodels.ProductInformation{{}}
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{productFn: func(ctx context.Context, req *modelsalescontract.ListProductOfContractReq) ([]*bizmodels.ProductInformation, errors.APIError) {
				source = req.SourceType
				operator = req.CurrentOperator
				return products, nil
			}}}).ListProductOfContract20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(source, convey.ShouldEqual, _const.SourceTypeInner)
			convey.So(operator, convey.ShouldEqual, "op@example.com")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"ProductInformationList": products})
		})
	})
}

func TestInnerVCCSalesContractHandlerContractPerform20210101(t *testing.T) {
	t.Run("缺少合同号返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()

			(&innerVCCSalesContractHandler{}).ContractPerform20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录不查询合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).To(func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				called = true
				return nil, nil
			}).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).ContractPerform20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("查询合同失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, stderrors.New("db")).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).ContractPerform20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("合同不存在返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).ContractPerform20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("履约同步失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("perform")
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{ContractNo: "C-1"}, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{performFn: func(ctx context.Context, tx *gorm.DB, contractNo string, isContinue bool) errors.APIError {
				return serviceErr
			}}}).ContractPerform20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功同步履约返回 success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotContractNo string
			var gotContinue bool
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{ContractNo: "C-1"}, nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{performFn: func(ctx context.Context, tx *gorm.DB, contractNo string, isContinue bool) errors.APIError {
				gotContractNo = contractNo
				gotContinue = isContinue
				return nil
			}}}).ContractPerform20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(gotContractNo, convey.ShouldEqual, "C-1")
			convey.So(gotContinue, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"message": "success"})
		})
	})
}

func TestInnerVCCSalesContractHandlerSyncSettlementTerm20210101(t *testing.T) {
	t.Run("缺少合同号返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录不查询合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).To(func(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
				called = true
				return nil, nil
			}).Build()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("查询合同失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, stderrors.New("db")).Build()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("合同不存在返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(nil, nil).Build()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("结算同步失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{ContractNo: "C-1"}, nil).Build()
			mockey.MockUnsafe(contractperform.SyncSettlementTerm).Return(nil, stderrors.New("sync")).Build()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("成功同步结算条款", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			metaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindLastByNo).Return(&model.ContractMetaDB{ContractNo: "C-1"}, nil).Build()
			mockey.MockUnsafe(contractperform.SyncSettlementTerm).Return(nil, nil).Build()

			(&innerVCCSalesContractHandler{}).SyncSettlementTerm20210101(salesContractUserCtx(), &app.RequestContext{})

			body := rec.body.(map[string]interface{})
			convey.So(body["message"], convey.ShouldEqual, "success")
			convey.So(body["resp"], convey.ShouldBeNil)
		})
	})
}

func TestInnerVCCSalesContractHandlerSyncReceivableSettlement20210101(t *testing.T) {
	t.Run("缺少合同号返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()

			(&innerVCCSalesContractHandler{}).SyncReceivableSettlement20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("未登录不发送通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			mockey.MockUnsafe(settlementnotify.NotifyByContractNo).To(func(ctx context.Context, contractNo string) error {
				called = true
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{}).SyncReceivableSettlement20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("通知失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			mockey.MockUnsafe(settlementnotify.NotifyByContractNo).Return(stderrors.New("notify")).Build()

			(&innerVCCSalesContractHandler{}).SyncReceivableSettlement20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("通知成功返回 success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			var gotContractNo string
			mockSalesContractGetQuery(map[string]string{"ContractNo": "C-1"})
			mockey.MockUnsafe(settlementnotify.NotifyByContractNo).To(func(ctx context.Context, contractNo string) error {
				gotContractNo = contractNo
				return nil
			}).Build()

			(&innerVCCSalesContractHandler{}).SyncReceivableSettlement20210101(salesContractUserCtx(), &app.RequestContext{})

			convey.So(gotContractNo, convey.ShouldEqual, "C-1")
			convey.So(rec.body, convey.ShouldResemble, map[string]interface{}{"message": "success"})
		})
	})
}

func TestInnerVCCSalesContractHandlerEditBasicInfo20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockBindError()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{}}).EditBasicInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service 错误透传", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("edit")
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{editBasicFn: func(ctx context.Context, req *modelsalescontract.EditBasicInfoReq) errors.APIError {
				return serviceErr
			}}}).EditBasicInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.err, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("成功编辑基础信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			called := false
			mockey.MockUnsafe(binding.BindAndValidate).Return(nil).Build()

			(&innerVCCSalesContractHandler{salesContractService: &fakeSalesContractService{editBasicFn: func(ctx context.Context, req *modelsalescontract.EditBasicInfoReq) errors.APIError {
				called = true
				return nil
			}}}).EditBasicInfo20210101(context.Background(), &app.RequestContext{})

			convey.So(called, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}

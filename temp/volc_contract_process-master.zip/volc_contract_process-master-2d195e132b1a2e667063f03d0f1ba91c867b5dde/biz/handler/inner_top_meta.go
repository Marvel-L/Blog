package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/service/contractmeta"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type innerTOPMetaHandler struct {
	base
	metaService   contractmeta.MetaService
	metaServiceV2 contractmeta.MetaServiceV2
}

func NewInnerTOPMetaHandler() vhertz.ActionHandler {
	return &innerTOPMetaHandler{
		metaService:   contractmeta.NewMetaService(),
		metaServiceV2: contractmeta.NewMetaServiceV2(),
	}
}

// GetMetaSimpleInfo20200101 查询合同信息，返回数据较单一
func (h *innerTOPMetaHandler) GetMetaSimpleInfo20200101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaDetailReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetMetaSimpleInfoParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := h.metaService.MetaSimpleInfo(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)

}

// GetFeishuViewUrl20200101 获取飞书查看链接
func (h *innerTOPMetaHandler) GetFeishuViewUrl20200101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	// 参数校验
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	creator := c.Query("Creator")
	// 参数校验
	if len(creator) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Creator"))
		return
	}

	// 查询重复项
	viewUrl, err := h.metaService.QueryFeishuViewUrl(ctx, contractNo, creator)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"ViewUrl": viewUrl,
	})
}

// NeedSubjectChangeAgreement20200101 是否需要发起主体变更协议
func (h *innerTOPMetaHandler) NeedSubjectChangeAgreement20200101(ctx context.Context, c *app.RequestContext) {

	var param contractmeta.NeedSubjectChangeAgreementReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "NeedSubjectChangeAgreementReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "NeedSubjectChangeAgreementReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 查询重复项
	res, err := h.metaServiceV2.NeedSubjectChangeAgreement(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"List": res,
	})
}

// ListContractMeta20200101 查询合同元数据列表
func (h *innerTOPMetaHandler) ListContractMeta20200101(ctx context.Context, c *app.RequestContext) {

	var param bizmodels.MetaListParam
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "VCCMetaListReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	param.SourceType = _const.SourceTypeOpen
	if len(param.CurrentOperator) == 0 {
		param.CurrentOperator = queryOperator(ctx)
	}
	param.IsManager = true

	ret, err := h.metaService.ListMeta(ctx, &param)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, ret)
}

// UpdateExpireRemindInfo20200101 更新合同即将到期提醒信息
func (h *innerTOPMetaHandler) UpdateExpireRemindInfo20200101(ctx context.Context, c *app.RequestContext) {

	var param metasupport.UpdateExpireRemindReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "UpdateExpireRemindReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if apiErr := param.Validate(); apiErr != nil {
		logs.CtxError(ctx, "UpdateExpireRemindReqValidateFail, err: %s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}
	// 更新合同即将到期提醒信息
	err := h.metaServiceV2.UpdateExpireRemindInfo(ctx, &param)
	if err != nil {
		if apiErr, ok := err.(vhertz.APIError); ok {
			vhertz.ErrorResp(ctx, c, apiErr)
			return
		}
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"ContractNo": param.ContractNo,
	})
}

// GetExpireRemindInfo20200101 获取合同即将到期提醒信息
func (h *innerTOPMetaHandler) GetExpireRemindInfo20200101(ctx context.Context, c *app.RequestContext) {

	var param metasupport.GetExpireRemindReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "GetExpireRemindReqBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if apiErr := param.Validate(); apiErr != nil {
		logs.CtxError(ctx, "GetExpireRemindReqValidateFail, err: %s", apiErr.Error())
		vhertz.ErrorResp(ctx, c, apiErr)
		return
	}
	// 更新合同即将到期提醒信息
	expireRemindInfo, err := h.metaServiceV2.GetExpireRemindInfo(ctx, &param)
	if err != nil {
		if apiErr, ok := err.(vhertz.APIError); ok {
			vhertz.ErrorResp(ctx, c, apiErr)
			return
		}
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, expireRemindInfo)
}

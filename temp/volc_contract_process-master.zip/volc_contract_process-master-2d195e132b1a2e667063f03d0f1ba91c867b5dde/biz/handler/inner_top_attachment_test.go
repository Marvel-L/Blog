package handler

import (
	"context"
	"testing"
	"volc_contract_process/biz/bizmodels"
	bizmodels_metaattach "volc_contract_process/biz/bizmodels/metaattach"
	service_metaattach "volc_contract_process/biz/service/metaattach"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

type fakeInnerTOPAttachmentService struct {
	service_metaattach.AttachmentService
	getPreviewFn func(context.Context, *bizmodels.GetAttachmentPreviewInfoReq) (*bizmodels_metaattach.GetAttachmentPreviewInfoResp, pkg_errors.APIError)
}

func (f *fakeInnerTOPAttachmentService) GetAttachmentPreviewInfo(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*bizmodels_metaattach.GetAttachmentPreviewInfoResp, pkg_errors.APIError) {
	return f.getPreviewFn(ctx, req)
}

func Test_innerTOPAttachmentHandler_GetAttachmentPreviewInfo20200101_BitsUTGen(t *testing.T) {
	// MockAttachmentService is a mock type for the AttachmentService interface.
	type MockAttachmentService struct {
		service_metaattach.AttachmentService
	}

	mockey.PatchConvey("Test GetAttachmentPreviewInfo20200101", t, func() {
		// Initialize the handler with a mocked service.
		h := &innerTOPAttachmentHandler{
			attachmentService: &MockAttachmentService{},
		}
		// Initialize the Hertz request context.
		c := &app.RequestContext{}

		mockey.PatchConvey("成功获取附件预览信息", func() {
			// 场景描述：
			// 构造数据：构造一个hertz请求上下文，并使其Query方法按顺序返回有效的DownloadID, DocVersion, 和 CurrentOperator。
			// 逻辑链路：
			// 1. Mock c.Query() 方法以返回预设的测试参数。
			// 2. Mock attachmentService.GetAttachmentPreviewInfo 方法，使其返回成功的预览信息和 nil 错误。
			// 3. Mock vhertz.DoResponse 方法以验证成功分支被执行且响应数据正确。
			// 4. 调用目标函数 GetAttachmentPreviewInfo20200101。
			// 5. 在 DoResponse 的 mock 实现中进行断言。

			mockey.Mock((*app.RequestContext).Query).Return(
				mockey.Sequence("test-download-id").Then("v1.0").Then("test-operator"),
			).Build()

			expectedResp := &bizmodels_metaattach.GetAttachmentPreviewInfoResp{
				AttachName: "test_attachment.pdf",
				CanPreview: true,
				PreviewURL: "https://example.com/preview/test_attachment.pdf",
			}
			mockey.Mock((*MockAttachmentService).GetAttachmentPreviewInfo).Return(expectedResp, nil).Build()

			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, expectedResp)
			}).Build()

			h.GetAttachmentPreviewInfo20200101(context.Background(), c)
		})

		mockey.PatchConvey("获取附件预览信息失败", func() {
			// 场景描述：
			// 构造数据：构造一个hertz请求上下文，并使其Query方法按顺序返回有效的DownloadID, DocVersion, 和 CurrentOperator。
			// 逻辑链路：
			// 1. Mock c.Query() 方法以返回预设的测试参数。
			// 2. Mock attachmentService.GetAttachmentPreviewInfo 方法，使其返回 nil 和一个 APIError。
			// 3. Mock vhertz.ErrorResp 方法以验证错误处理分支被执行且错误信息正确。
			// 4. 调用目标函数 GetAttachmentPreviewInfo20200101。
			// 5. 在 ErrorResp 的 mock 实现中进行断言。

			mockey.Mock((*app.RequestContext).Query).Return(
				mockey.Sequence("test-download-id-fail").Then("v1.1").Then("test-operator-fail"),
			).Build()

			mockErr := vhertz.NewErrorStruct("ServiceError", "internal service error", 500)
			mockey.Mock((*MockAttachmentService).GetAttachmentPreviewInfo).Return(nil, pkg_errors.APIError(mockErr)).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, mockErr)
			}).Build()

			h.GetAttachmentPreviewInfo20200101(context.Background(), c)
		})
	})
}

func Test_NewInnerTOPAttachmentHandler_BitsUTGen(t *testing.T) {
	// MockAttachmentService is a mock implementation for the metaattach.AttachmentService interface.
	type MockAttachmentService struct {
		service_metaattach.AttachmentService
	}

	mockey.PatchConvey("Test NewInnerTOPAttachmentHandler", t, func() {
		mockey.PatchConvey("should return a new innerTOPAttachmentHandler successfully", func() {
			// 场景描述：
			// 测试 NewInnerTOPAttachmentHandler 函数能否成功创建一个 handler 实例。
			// 构造数据：
			// 无需构造特定输入数据。
			// 逻辑链路：
			// 1. Mock metaattach.NewAttachmentService 函数，使其返回一个自定义的 mock service 实例。
			// 2. 调用目标函数 NewInnerTOPAttachmentHandler。
			// 3. 断言返回的 handler 不为 nil。
			// 4. 断言返回的 handler 是 *innerTOPAttachmentHandler 类型。
			// 5. 断言 handler 内部的 attachmentService 字段被正确设置为 mock service 实例。

			mockService := &MockAttachmentService{}
			mockey.Mock(service_metaattach.NewAttachmentService).Return(mockService).Build()

			// 调用目标函数
			handler := NewInnerTOPAttachmentHandler()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			h, ok := handler.(*innerTOPAttachmentHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(h.attachmentService, convey.ShouldEqual, mockService)
		})
	})
}

func Test_innerTOPAttachmentHandler_GetAttachmentPreviewInfo20200101(t *testing.T) {
	t.Run("service返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedErr := pkg_errors.ErrInternalError
			h := &innerTOPAttachmentHandler{attachmentService: &fakeInnerTOPAttachmentService{getPreviewFn: func(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*bizmodels_metaattach.GetAttachmentPreviewInfoResp, pkg_errors.APIError) {
				convey.So(req.DownloadID, convey.ShouldEqual, "download-1")
				convey.So(req.DocVersion, convey.ShouldEqual, "v1")
				convey.So(req.CurrentOperator, convey.ShouldEqual, "operator-1")
				return nil, expectedErr
			}}}
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case "DownloadID":
					return "download-1"
				case "DocVersion":
					return "v1"
				case "CurrentOperator":
					return "operator-1"
				default:
					return ""
				}
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, expectedErr)
			}).Build()

			h.GetAttachmentPreviewInfo20200101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("service成功时返回预览信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedResp := &bizmodels_metaattach.GetAttachmentPreviewInfoResp{
				AttachName: "contract.pdf",
				CanPreview: true,
				PreviewURL: "https://example.com/preview",
			}
			h := &innerTOPAttachmentHandler{attachmentService: &fakeInnerTOPAttachmentService{getPreviewFn: func(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*bizmodels_metaattach.GetAttachmentPreviewInfoResp, pkg_errors.APIError) {
				convey.So(req.DownloadID, convey.ShouldEqual, "download-2")
				convey.So(req.DocVersion, convey.ShouldEqual, "v2")
				convey.So(req.CurrentOperator, convey.ShouldEqual, "operator-2")
				return expectedResp, nil
			}}}
			mockey.Mock((*app.RequestContext).Query).To(func(_ *app.RequestContext, key string) string {
				switch key {
				case "DownloadID":
					return "download-2"
				case "DocVersion":
					return "v2"
				case "CurrentOperator":
					return "operator-2"
				default:
					return ""
				}
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, expectedResp)
			}).Build()

			h.GetAttachmentPreviewInfo20200101(context.Background(), &app.RequestContext{})
		})
	})
}

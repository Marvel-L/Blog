package handler

import (
	"context"
	"fmt"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/products_sdk/products_client"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelsthird"
	"volc_contract_process/biz/service/thirdservice"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/innerapiaccountcli"
)

func TestNewInnerVCCThirdHandler(t *testing.T) {
	mockey.PatchConvey("创建第三方接口 handler", t, func() {
		convey.So(NewInnerVCCThirdHandler(), convey.ShouldNotBeNil)
	})
}

func Test_innerVCCThirdHandler_ListVerifyCountry20210101(t *testing.T) {

	// Arrange
	v2 := &innerVCCThirdHandler{}
	type args struct {
		c *app.RequestContext
	}
	tests := []struct {
		name  string
		args  args
		mocks func()
	}{
		{
			name: "case #1",
			args: args{
				c: &app.RequestContext{},
			},
			mocks: func() {
				mockey.Mock(logs.CtxInfo).Return().Build()
				mockey.Mock((*app.RequestContext).Query).Return("").Build()
				mockey.Mock(vhertz.ErrorResp).Return().Build()
				mockey.Mock(innerapiaccountcli.ListVerifyCountry).Return(nil, errors.ErrorCommon).Build()
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				v2.ListVerifyCountry20210101(
					context.Background(), tt.args.c,
				)

				// Assert
				convey.So("your code", convey.ShouldEqual, "your code")
			})
		})
	}
}

func Test_innerVCCThirdHandler_CreateVerifyAccount20210101(t *testing.T) {
	t.Run("case bindFail#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			var err vhertz.APIError
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(c *app.RequestContext, inputerr vhertz.APIError) {
				err = inputerr
			}).Build()

			// Act
			h := &innerVCCThirdHandler{}
			h.CreateVerifyAccount20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case fetchUserInfoFromCtxFail#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			var err vhertz.APIError
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(c *app.RequestContext, inputerr vhertz.APIError) {
				err = inputerr
			}).Build()

			// Act
			h := &innerVCCThirdHandler{}
			h.CreateVerifyAccount20210101(context.Background(), &app.RequestContext{})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	t.Run("case callCreateVerifyAccountFail#3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			var err vhertz.APIError
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(c *app.RequestContext, inputerr vhertz.APIError) {
				err = inputerr
			}).Build()

			service := thirdservice.NewAccountService()
			methodCreateVerifyAccount := mockey.GetMethod(service, "CreateVerifyAccount")
			mockey.Mock(methodCreateVerifyAccount).Return(nil, errors.ErrorCommon).Build()

			// Act
			h := &innerVCCThirdHandler{}
			c := &app.RequestContext{}
			ctx := context.WithValue(context.Background(), _const.CtxCurrentUser, &bizmodels.AuthInnerUserInfo{
				EmployeeEmail: "zs",
			})
			h.CreateVerifyAccount20210101(ctx, c)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
}

func TestInnerVCCThirdHandlerListProductDepartment20210101(t *testing.T) {
	t.Run("绑定失败返回参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()

			(&innerVCCThirdHandler{}).ListProductDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("service 错误时透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			serviceErr := errors.ErrorCommon.WithArgs("list department")
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelsthird.ListProductDepartmentReq)
				req.DepartmentName = "产品"
				req.DepartmentCode = "PD"
				return nil
			}).Build()
			service := thirdservice.NewProductService()
			methodListDepartment := mockey.GetMethod(service, "ListDepartment")
			mockey.Mock(methodListDepartment).To(func(ctx context.Context, req *modelsthird.ListProductDepartmentReq) (*products_client.ListDepartmentsResult, errors.APIError) {
				convey.So(req.DepartmentName, convey.ShouldEqual, "产品")
				convey.So(req.DepartmentCode, convey.ShouldEqual, "PD")
				return nil, serviceErr
			}).Build()

			(&innerVCCThirdHandler{}).ListProductDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err, convey.ShouldResemble, serviceErr)
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时返回产品线部门列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockRiskClauseTplResp()
			expected := &products_client.ListDepartmentsResult{
				List: []products_client.DepartmentResp{{ID: 1, Name: "产品线", Code: "PD"}},
			}
			mockey.MockUnsafe(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*modelsthird.ListProductDepartmentReq)
				req.DepartmentName = "产品线"
				req.DepartmentCode = "PD"
				return nil
			}).Build()
			service := thirdservice.NewProductService()
			methodListDepartment := mockey.GetMethod(service, "ListDepartment")
			mockey.Mock(methodListDepartment).To(func(ctx context.Context, req *modelsthird.ListProductDepartmentReq) (*products_client.ListDepartmentsResult, errors.APIError) {
				convey.So(req.DepartmentName, convey.ShouldEqual, "产品线")
				convey.So(req.DepartmentCode, convey.ShouldEqual, "PD")
				return expected, nil
			}).Build()

			(&innerVCCThirdHandler{}).ListProductDepartment20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, expected)
		})
	})
}

func Test_innerVCCThirdHandler_GetProductLineTree20210101_BitsUTGen(t *testing.T) {
	t.Run("case error#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock service method to return error
			service := thirdservice.NewProductService()
			methodGetProductLineTree := mockey.GetMethod(service, "GetProductLineTree")
			mockey.Mock(methodGetProductLineTree).Return(nil, errors.ErrorCommon).Build()

			// Capture ErrorResp call
			var receivedErr vhertz.APIError
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				receivedErr = e
			}).Build()

			// Ensure DoResponse is not called on error branch
			doRespCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(c *app.RequestContext, r interface{}) {
				doRespCalled = true
			}).Build()

			h := &innerVCCThirdHandler{}
			c := &app.RequestContext{}
			h.GetProductLineTree20210101(context.Background(), c)

			convey.So(receivedErr, convey.ShouldNotBeNil)
			convey.So(doRespCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("case success#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Prepare expected result
			expected := []modelsthird.ProductLineData{
				{ID: 1, Name: "A", Level: 0},
				{ID: 2, Name: "B", Level: 1, ChildProduct: []modelsthird.ProductLineData{
					{ID: 3, Name: "C", Level: 2},
				}},
			}

			// Mock service method to return success
			service := thirdservice.NewProductService()
			methodGetProductLineTree := mockey.GetMethod(service, "GetProductLineTree")
			mockey.Mock(methodGetProductLineTree).Return(expected, nil).Build()

			// Capture DoResponse result
			var captured interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(c *app.RequestContext, r interface{}) {
				captured = r
			}).Build()

			// Ensure ErrorResp is not called
			errorCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c *app.RequestContext, e vhertz.APIError) {
				errorCalled = true
			}).Build()

			h := &innerVCCThirdHandler{}
			c := &app.RequestContext{}
			h.GetProductLineTree20210101(context.Background(), c)

			convey.So(errorCalled, convey.ShouldBeFalse)
			convey.So(captured, convey.ShouldResemble, expected)
		})
	})
}

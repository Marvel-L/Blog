package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"fmt"
	"github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/quoterefresh"
	"volc_contract_process/pkg/errors"
)

type fakeOpenVCCDataRefreshService struct {
	quoterefresh.Service
	quoteRefreshNotifyFn func(context.Context, *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError)
}

func (f *fakeOpenVCCDataRefreshService) QuoteRefreshNotify(ctx context.Context, req *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
	return f.quoteRefreshNotifyFn(ctx, req)
}

func Test_openVCCDataRefreshHandler_QuoteRefreshNotify20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError

			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &openVCCDataRefreshHandler{}
			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("参数校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError

			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote_1"
				req.RefreshApprovalID = ""
				req.ContractNo = "contract_1"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h := &openVCCDataRefreshHandler{}
			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})

	t.Run("服务返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			var capturedReq *bizmodels.QuoteRefreshNotifyReq

			service := quoterefresh.NewService()
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote_2"
				req.RefreshApprovalID = "approval_2"
				req.ContractNo = "contract_2"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(mockey.GetMethod(service, "QuoteRefreshNotify")).To(func(ctx context.Context, req *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
				capturedReq = req
				return nil, errors.ErrInternalError
			}).Build()

			h := &openVCCDataRefreshHandler{quoteRefreshService: service}
			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldNotBeNil)
			So(capturedReq, ShouldNotBeNil)
			So(capturedReq.RefreshApprovalID, ShouldEqual, "approval_2")
		})
	})

	t.Run("成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedReq *bizmodels.QuoteRefreshNotifyReq
			var capturedResp interface{}

			service := quoterefresh.NewService()
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote_3"
				req.RefreshApprovalID = "approval_3"
				req.ContractNo = "contract_3"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()
			mockey.Mock(mockey.GetMethod(service, "QuoteRefreshNotify")).To(func(ctx context.Context, req *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
				capturedReq = req
				return &bizmodels.QuoteRefreshNotifyResp{
					IsContractAccepted: true,
					Reason:             "已接收，正在处理",
				}, nil
			}).Build()

			h := &openVCCDataRefreshHandler{quoteRefreshService: service}
			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedReq, ShouldNotBeNil)
			So(capturedReq.ContractNo, ShouldEqual, "contract_3")
			So(capturedResp, ShouldResemble, &bizmodels.QuoteRefreshNotifyResp{
				IsContractAccepted: true,
				Reason:             "已接收，正在处理",
			})
		})
	})
}

func Test_openVCCDataRefreshHandler_QuoteRefreshNotify20210101(t *testing.T) {
	t.Run("参数绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			h := &openVCCDataRefreshHandler{quoteRefreshService: &fakeOpenVCCDataRefreshService{}}
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind fail")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})

	t.Run("参数校验失败返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			h := &openVCCDataRefreshHandler{quoteRefreshService: &fakeOpenVCCDataRefreshService{quoteRefreshNotifyFn: func(context.Context, *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
				panic("service should not be called")
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote-1"
				req.RefreshApprovalID = ""
				req.ContractNo = "contract-1"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldNotBeNil)
			So(capturedErr.GetCode(), ShouldEqual, errors.ErrMissingParam.GetCode())
			So(capturedErr.GetArgs()[0], ShouldEqual, "RefreshApprovalID")
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			var capturedReq *bizmodels.QuoteRefreshNotifyReq
			expectedErr := errors.ErrInternalError
			h := &openVCCDataRefreshHandler{quoteRefreshService: &fakeOpenVCCDataRefreshService{quoteRefreshNotifyFn: func(ctx context.Context, req *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
				capturedReq = req
				return nil, expectedErr
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote-2"
				req.RefreshApprovalID = "approval-2"
				req.ContractNo = "contract-2"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()

			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedErr, ShouldEqual, expectedErr)
			So(capturedReq, ShouldNotBeNil)
			So(capturedReq.ContractNo, ShouldEqual, "contract-2")
		})
	})

	t.Run("服务成功时返回通知响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedResp interface{}
			expectedResp := &bizmodels.QuoteRefreshNotifyResp{IsContractAccepted: true, Reason: "已接收"}
			h := &openVCCDataRefreshHandler{quoteRefreshService: &fakeOpenVCCDataRefreshService{quoteRefreshNotifyFn: func(ctx context.Context, req *bizmodels.QuoteRefreshNotifyReq) (*bizmodels.QuoteRefreshNotifyResp, errors.APIError) {
				So(req.QuoteID, ShouldEqual, "quote-3")
				So(req.RefreshApprovalID, ShouldEqual, "approval-3")
				So(req.ContractNo, ShouldEqual, "contract-3")
				return expectedResp, nil
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(c *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.QuoteRefreshNotifyReq)
				req.QuoteID = "quote-3"
				req.RefreshApprovalID = "approval-3"
				req.ContractNo = "contract-3"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.QuoteRefreshNotify20210101(context.Background(), &app.RequestContext{})

			So(capturedResp, ShouldResemble, expectedResp)
		})
	})
}

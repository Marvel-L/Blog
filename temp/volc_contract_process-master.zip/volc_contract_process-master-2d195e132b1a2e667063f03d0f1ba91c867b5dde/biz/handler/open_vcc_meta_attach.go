package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——合同附件处理
type openVCCMetaAttachmentHandler struct {
	base
	attachmentService metaattach.AttachmentService
	metaService       contractmeta.MetaService
}

func NewOpenVCCMetaAttachmentHandler() vhertz.ActionHandler {
	return &openVCCMetaAttachmentHandler{
		attachmentService: metaattach.NewAttachmentService(),
		metaService:       contractmeta.NewMetaService(),
	}
}

// DownloadMetaAttachment20210101 下载合同元数据附件
func (h *openVCCMetaAttachmentHandler) DownloadMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "DownloadMetaAttachment, id=%s, version=%s", downloadID, version)

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	c.Response.Header.Set("Content-Disposition", "attachment;filename="+info.FileName)
	c.Response.Header.Set("Content-type", "application/octet-stream")
	c.Data(200, "application/octet-stream", info.Data)

}

// ViewMetaAttachment20210101 预览合同元数据附件 仅支持浏览器允许的附件类型
func (h *openVCCMetaAttachmentHandler) ViewMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "ViewMetaAttachment, id=%s, version=%s", downloadID, version)

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	if info == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("获取文档数据失败"))
		return
	}

	if !info.CanView {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前文档不支持预览"))
		return
	}

	c.Data(200, info.ContentType, info.Data)

}

// GetMetaAttachmentInfo20210101 获取合同元数据附件原始信息
func (h *openVCCMetaAttachmentHandler) GetMetaAttachmentInfo20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "GetMetaAttachmentInfo, id=%s, version=%s", downloadID, version)

	// 从附件中心获取相关数据
	info, err := h.attachmentService.GetAttachmentDataInfo(ctx, downloadID, version)
	if err != nil {
		logs.CtxError(ctx, "GetMetaAttachmentInfoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, info)

}

// UploadMetaAttachment20210101 上传合同附件
func (h *openVCCMetaAttachmentHandler) UploadMetaAttachment20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.UploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	req.SourceType = _const.SourceTypeOpen
	formFile, err := c.FormFile("File")
	if err == nil && formFile != nil {
		req.File = formFile
		req.FileName = formFile.Filename
	}
	// if req.File == nil && len(req.TosKey) == 0 {
	// 	vhertz.ErrorResp(c, errors.ErrMissingParam.WithArgs("File/TosKey"))
	// 	return
	// }

	// 从附件中心获取相关数据
	res, err1 := h.attachmentService.UploadAttachment(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// InitMultipartUpload20210101 初始化后端中转分片上传
func (h *openVCCMetaAttachmentHandler) InitMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.InitMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "InitMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	res, err1 := h.attachmentService.InitMultipartUpload(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "InitMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// UploadMultipartPart20210101 上传单个分片到 TOS
func (h *openVCCMetaAttachmentHandler) UploadMultipartPart20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.UploadMultipartPartReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadMultipartPartReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	formFile, err := c.FormFile("File")
	if err == nil && formFile != nil {
		req.File = formFile
	}

	res, err1 := h.attachmentService.UploadMultipartPart(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "UploadMultipartPartFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// CompleteMultipartUpload20210101 完成 TOS 分片上传合并
func (h *openVCCMetaAttachmentHandler) CompleteMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.CompleteMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CompleteMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	res, err1 := h.attachmentService.CompleteMultipartUpload(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "CompleteMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// AbortMultipartUpload20210101 取消 TOS 分片上传
func (h *openVCCMetaAttachmentHandler) AbortMultipartUpload20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.AbortMultipartUploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AbortMultipartUploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err1 := h.attachmentService.AbortMultipartUpload(ctx, &req); err1 != nil {
		logs.CtxError(ctx, "AbortMultipartUploadFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ApplyUploadInfo20210101 获取文件预上传信息
func (h *openVCCMetaAttachmentHandler) ApplyUploadInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req metaattachmodels.ApplyUploadInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	// 获取文件与上传链接信息
	res, err1 := h.attachmentService.ApplyUploadInfo(ctx, &req)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// GetMetaAttachmentURL20210101 获取合同元数据附件访问链接
func (h *openVCCMetaAttachmentHandler) GetMetaAttachmentURL20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")

	logs.CtxInfo(ctx, "GetMetaAttachmentInfo, id=%s", downloadID)

	url, name, err := h.metaService.GetViewURL(ctx, &bizmodels.MetaAttachmentDownloadParam{
		DownloadID: downloadID,
		Version:    version,
	})

	if err != nil {
		logs.CtxError(ctx, "GetViewURLFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, &metaattachmodels.AttachmentURL{
		URL:      url,
		FileName: name,
	})

}

// GetProcessFileInfo20210101 获取在线协同合同当前节点最新版本文件信息
func (h *openVCCMetaAttachmentHandler) GetProcessFileInfo20210101(ctx context.Context, c *app.RequestContext) {

	contractNo := c.Query("ContractNo")
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	currentOperator := c.Query("CurrentOperator")
	if currentOperator == "" {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("CurrentOperator"))
		return
	}
	// 从附件中心获取相关数据
	res, err1 := h.attachmentService.GetProcessFileInfo(ctx, contractNo, currentOperator)
	if err1 != nil {
		logs.CtxError(ctx, "ViewMetaAttachmentFail, err: %s", err1.Error())
		vhertz.ErrorResp(ctx, c, err1)
		return
	}

	vhertz.DoResponse(ctx, c, res)
}

// GetAttachmentPreviewInfo20210101 获取合同元数据附件预览信息
func (h *openVCCMetaAttachmentHandler) GetAttachmentPreviewInfo20210101(ctx context.Context, c *app.RequestContext) {

	downloadID := c.Query("DownloadID")
	version := c.Query("DocVersion")
	currentOperator := c.Query("CurrentOperator")

	logs.CtxInfo(ctx, "GetAttachmentPreviewInfo, id=%s, version=%s, currentOperator=%s", downloadID, version, currentOperator)

	req := &bizmodels.GetAttachmentPreviewInfoReq{
		CurrentOperator: currentOperator,
		DownloadID:      downloadID,
		DocVersion:      version,
	}

	resp, err := h.attachmentService.GetAttachmentPreviewInfo(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetAttachmentPreviewInfoFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

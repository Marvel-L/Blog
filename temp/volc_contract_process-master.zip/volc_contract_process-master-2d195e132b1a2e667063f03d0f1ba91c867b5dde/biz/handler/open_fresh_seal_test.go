package handler

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/fresh_seal"
	"volc_contract_process/pkg/const"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz/pkg/protocol"
	hertz_ext_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_openFreshSealHandler_CreateFreshSeal20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "AccountId")
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误并使用Header账号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := pkg_errors.ErrValidateParamErr.WithArgs("create fail")
			h := &openFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{createFn: func(ctx context.Context, param *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError) {
				convey.So(param.AccountId, convey.ShouldEqual, "acc-001")
				convey.So(param.ContractNoList, convey.ShouldEqual, "C1,C2")
				return nil, svcErr
			}}}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealCreateParam)
				*p = bizmodels.FreshSealCreateParam{
					CopyCount:      1,
					ContactName:    "张三",
					ContactPhone:   "12345678901",
					AddressInfo:    bizmodels.AddressInfo{Province: "省", City: "市", Region: "区", Address: "详细地址"},
					ApplyReason:    []bizmodels.Reason{{Code: "R1", Message: "原因"}},
					ContractNoList: "C1,C2",
					BizScene:       _const.BizSceneQuoteContract,
				}
				return nil
			}).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-001").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("创建成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expected := &bizmodels.FreshSealCreateResp{ApplyNo: "APP-2021-0001"}
			h := &openFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{createFn: func(ctx context.Context, param *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError) {
				convey.So(param.AccountId, convey.ShouldEqual, "acc-002")
				return expected, nil
			}}}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealCreateParam)
				*p = bizmodels.FreshSealCreateParam{
					CopyCount:      2,
					ContactName:    "李四",
					ContactPhone:   "19876543210",
					AddressInfo:    bizmodels.AddressInfo{Province: "省", City: "市", Region: "区", Address: "某大道100号"},
					ApplyReason:    []bizmodels.Reason{{Code: "R2", Message: "测试原因"}},
					ContractNoList: "C100",
					BizScene:       _const.BizSceneTransactionContract,
				}
				return nil
			}).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-002").Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, expected)
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})
}

func Test_openFreshSealHandler_FreshSealDetail20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回缺少账号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openFreshSealHandler{}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealDetailParam)
				p.ApplyNo = "APP-1"
				p.ContractNo = "C1"
				return nil
			}).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "AccountId")
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误并使用Header账号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := pkg_errors.ErrParamParseFail
			h := &openFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{detailFn: func(ctx context.Context, param *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError) {
				convey.So(param.AccountId, convey.ShouldEqual, "acc-123")
				convey.So(param.ApplyNo, convey.ShouldEqual, "APP-1")
				return nil, svcErr
			}}}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealDetailParam)
				p.ApplyNo = "APP-1"
				p.ContractNo = "C1"
				return nil
			}).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-123").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("查询成功返回详情", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			info := &bizmodels.FreshSealApplyInfo{ApplyId: "APP-2", AccountId: "acc-456"}
			resp := bizmodels.FreshSealDetailResp(info)
			h := &openFreshSealHandler{freshSealService: &fakeFreshSealApprovalService{detailFn: func(ctx context.Context, param *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError) {
				convey.So(param.ContractNo, convey.ShouldEqual, "C2")
				return resp, nil
			}}}
			c := &app.RequestContext{Request: protocol.Request{}}
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealDetailParam)
				p.ApplyNo = "APP-2"
				p.ContractNo = "C2"
				return nil
			}).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-456").Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})
}

func (d *dummyFreshSealApprovalService) CanApplyFreshSeal(ctx context.Context, archivedStatus int, freshSealApprovalNo string, sealAccountIDs string, accountId string, activeStatus int) (bool, []string) {
	return false, nil
}

func (d *dummyFreshSealApprovalService) ListOperationRecord(ctx context.Context, param *bizmodels.FreshSealListOperationRecordParam) (*bizmodels.FreshSealListOperationRecordResp, pkg_errors.APIError) {
	return nil, nil
}

func (d *dummyFreshSealApprovalService) GetApprovalDetail(ctx context.Context, param *bizmodels.FreshSealDetailParam) (bizmodels.FreshSealDetailResp, pkg_errors.APIError) {
	var resp bizmodels.FreshSealDetailResp
	return resp, nil
}

func (d *dummyFreshSealApprovalService) CreateApproval(ctx context.Context, param *bizmodels.FreshSealCreateParam) (*bizmodels.FreshSealCreateResp, pkg_errors.APIError) {
	return nil, nil
}

func (d *dummyFreshSealApprovalService) GetApprovalList(ctx context.Context, param *bizmodels.FreshSealListParam) (*bizmodels.FreshSealListResp, pkg_errors.APIError) {
	return nil, nil
}

func (d *dummyFreshSealApprovalService) Export(ctx context.Context, param *bizmodels.FreshSealListParam) pkg_errors.APIError {
	return nil
}

func (d *dummyFreshSealApprovalService) BatchUpdateExpressData(ctx context.Context, param *bizmodels.FreshSealBatchUpdateExpressParam) pkg_errors.APIError {
	return nil
}

func Test_NewOpenFreshSealHandler_BitsUTGen(t *testing.T) {
	t.Run("返回的处理器类型与字段初始化正确", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 通过打桩返回自定义的鲜章服务实例，验证字段初始化是否正确
			mockSvc := &dummyFreshSealApprovalService{}
			mockey.Mock(fresh_seal.NewFreshSealApprovalService).Return(mockSvc).Build()

			h := NewOpenFreshSealHandler()

			// 使用别名类型，确保返回值满足接口约束
			var _ vhertz.ActionHandler = h

			convey.So(h, convey.ShouldNotBeNil)

			impl, ok := h.(*openFreshSealHandler)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(impl.freshSealService, convey.ShouldEqual, mockSvc)
		})
	})
}

func Test_openFreshSealHandler_FreshSealDetail20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_FreshSealDetail20210101{}}
			c := &app.RequestContext{Request: protocol.Request{Header: protocol.RequestHeader{}}}

			// 参数绑定失败，触发错误返回
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_FreshSealDetail20210101{}}
			c := &app.RequestContext{Request: protocol.Request{Header: protocol.RequestHeader{}}}

			// 参数绑定成功但未设置必要字段，且Header为空，触发校验失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("").Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "AccountId")
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("服务调用失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			mockSvc := &Mock_FreshSealApprovalService_FreshSealDetail20210101{}
			h := &openFreshSealHandler{freshSealService: mockSvc}
			c := &app.RequestContext{Request: protocol.Request{Header: protocol.RequestHeader{}}}

			// 参数绑定成功并填充必要字段
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealDetailParam)
				p.ApplyNo = "apply-no"
				p.ContractNo = "contract-no"
				return nil
			}).Build()

			// Header返回有效账号ID
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-123").Build()

			// 服务返回错误
			mockey.Mock((*Mock_FreshSealApprovalService_FreshSealDetail20210101).GetApprovalDetail).Return(nil, pkg_errors.ErrParamParseFail).Build()

			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})

	t.Run("成功返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造handler与上下文
			mockSvc := &Mock_FreshSealApprovalService_FreshSealDetail20210101{}
			h := &openFreshSealHandler{freshSealService: mockSvc}
			c := &app.RequestContext{Request: protocol.Request{Header: protocol.RequestHeader{}}}

			// 参数绑定成功并填充必要字段
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealDetailParam)
				p.ApplyNo = "apply-no"
				p.ContractNo = "contract-no"
				return nil
			}).Build()

			// Header返回有效账号ID
			mockey.Mock((*protocol.RequestHeader).Get).When(func(key string) bool {
				return key == _const.HeaderAccountID
			}).Return("acc-123").Build()

			// 服务返回成功结果（nil指针也视为正常返回）
			var svcResp bizmodels.FreshSealDetailResp = nil
			mockey.Mock((*Mock_FreshSealApprovalService_FreshSealDetail20210101).GetApprovalDetail).Return(svcResp, nil).Build()

			// 校验DoResponse被调用
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, svcResp)
			}).Build()

			h.FreshSealDetail20210101(context.Background(), c)
		})
	})
}

func Test_openFreshSealHandler_CreateFreshSeal20210101_BitsUTGen(t *testing.T) {
	t.Run("参数绑定失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_CreateFreshSeal20210101{}}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock 参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			// 断言错误响应为参数解析错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("参数校验失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_CreateFreshSeal20210101{}}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock 参数绑定成功，但不填充字段
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()
			// header获取AccountId为空
			mockey.Mock((*protocol.RequestHeader).Get).Return("").Build()
			// 断言错误响应为缺少AccountId
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "AccountId")
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("服务创建审批失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_CreateFreshSeal20210101{}}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock 参数绑定成功并填充有效参数（除AccountId外）
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealCreateParam)
				*p = bizmodels.FreshSealCreateParam{
					CopyCount:    1,
					ContactName:  "张三",
					ContactPhone: "12345678901",
					AddressInfo: bizmodels.AddressInfo{
						Province: "省",
						City:     "市",
						Region:   "区",
						Address:  "详细地址",
					},
					ApplyReason:    []bizmodels.Reason{{Code: "R1", Message: "原因描述"}},
					ContractNoList: "C1,C2",
					BizScene:       _const.BizSceneQuoteContract,
				}
				return nil
			}).Build()
			// header返回非空AccountId
			mockey.Mock((*protocol.RequestHeader).Get).Return("acc-001").Build()
			// 服务层返回错误
			mockey.Mock((*Mock_FreshSealApprovalService_CreateFreshSeal20210101).CreateApproval).Return(nil, pkg_errors.ErrValidateParamErr.WithArgs("service error")).Build()
			// 断言错误响应为服务层错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrValidateParamErr.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldContainSubstring, "service error")
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})

	t.Run("创建成功返回响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化handler与上下文
			h := &openFreshSealHandler{freshSealService: &Mock_FreshSealApprovalService_CreateFreshSeal20210101{}}
			c := &app.RequestContext{Request: protocol.Request{}}

			// mock 参数绑定成功并填充有效参数（除AccountId外）
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				p := obj.(*bizmodels.FreshSealCreateParam)
				*p = bizmodels.FreshSealCreateParam{
					CopyCount:    2,
					ContactName:  "李四",
					ContactPhone: "19876543210",
					AddressInfo: bizmodels.AddressInfo{
						Province: "省",
						City:     "市",
						Region:   "区",
						Address:  "某大道100号",
					},
					ApplyReason:    []bizmodels.Reason{{Code: "R2", Message: "测试原因"}},
					ContractNoList: "C100",
					BizScene:       _const.BizSceneTransactionContract,
				}
				return nil
			}).Build()
			// header返回非空AccountId
			mockey.Mock((*protocol.RequestHeader).Get).Return("acc-002").Build()
			// 服务层返回成功
			expectedResp := &bizmodels.FreshSealCreateResp{ApplyNo: "APP-2021-0001"}
			mockey.Mock((*Mock_FreshSealApprovalService_CreateFreshSeal20210101).CreateApproval).Return(expectedResp, nil).Build()
			// 断言DoResponse拿到正确结果
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				resp, ok := result.(*bizmodels.FreshSealCreateResp)
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(resp.ApplyNo, convey.ShouldEqual, "APP-2021-0001")
			}).Build()

			h.CreateFreshSeal20210101(context.Background(), c)
		})
	})
}

type Mock_FreshSealApprovalService_CreateFreshSeal20210101 struct {
	fresh_seal.FreshSealApprovalService
}

type dummyFreshSealApprovalService struct{}

type Mock_FreshSealApprovalService_FreshSealDetail20210101 struct {
	fresh_seal.FreshSealApprovalService
}

package handler

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"volc_contract_process/biz/bizmodels/modelinnertool"
	"volc_contract_process/biz/service/datarefresh"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/util"

	"code.byted.org/eps-platform/vcp_clients/vclient/jwt_permission"

	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractsettlement"
	"volc_contract_process/biz/service/masterdata"
	"volc_contract_process/biz/service/salescontract"
	"volc_contract_process/biz/service/support/metaattachment"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/biz/service/support/metaext"
	"volc_contract_process/biz/service/support/metasync"
	"volc_contract_process/biz/service/support/metatradeparty"
	"volc_contract_process/cronjob"
	"volc_contract_process/pkg/conf"
	"volc_contract_process/pkg/proxy/quotecli"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"volc_contract_process/biz/service/contractmeta"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/mqconsumer"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/errors"
)

// 内部工具类
type innerToolHandler struct {
	base
	metaService contractmeta.MetaService
}

func NewInnerToolHandler() vhertz.ActionHandler {
	return &innerToolHandler{
		metaService: contractmeta.NewMetaService(),
	}
}

// QueryContractByIdentifier20210101 根据唯一标识查询
func (h *innerToolHandler) QueryContractByIdentifier20210101(ctx context.Context, c *app.RequestContext) {

	var req bizmodels.ToolQueryContractByIdentReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "QueryFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	contractDB, err := dal.NewBizContractDao().FindByIdentifier(ctx, nil, req.Identifier, req.Scene)
	if err != nil {
		logs.CtxError(ctx, "QueryFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if contractDB == nil {
		vhertz.DoResponse(ctx, c, map[string]interface{}{
			"Message":    "Success",
			"ContractNo": "",
		})
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message":    "Success",
		"ContractNo": contractDB.ContractNo,
	})

}

func (h *innerToolHandler) CreateTPMD20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.MetaCreateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "CreateTPMDFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		logs.CtxError(ctx, "CreateTPMDFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	mdPartyInfo, err := masterdata.GetMdPartyInfo(ctx, param.AccountID, param.CardNo, param.DocumentType, param.Country)
	if err != nil {
		logs.CtxError(ctx, "CreateTPMDFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message":     "Success",
		"mdPartyInfo": mdPartyInfo,
	})
}

// HttpOAMsg20210101 http发送消息
func (h *innerToolHandler) HttpOAMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.ToolHttpMqMsgReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpOAMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	now := time.Now().Format("2006-01-02 15:04:05")
	param.EventTime = now

	req := map[string]interface{}{
		"event_time":  param.EventTime,
		"event_type":  param.EventType,
		"biz_key":     param.BizKey,
		"status_code": param.StatusCode,
	}

	body, _ := json.Marshal(req)
	if err := mqconsumer.HandlerHttpMsg(ctx, string(body)); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// HttpFeishuMsg20210101 http发送消息
func (h *innerToolHandler) HttpFeishuMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.ToolHttpFeishuMqMsgReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpOAMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	req := map[string]interface{}{
		"eventType":  param.EventType,
		"eventToken": param.EventToken,
		"events":     param.Events,
	}

	body, _ := json.Marshal(req)
	if err := mqconsumer.HandlerFeishuHttpMsg(ctx, string(body)); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// HandlerAccountChangInnerEBHttpMsg20210101 http发送账号实名认证变更消息
func (h *innerToolHandler) HttpAccountChangInnerEBMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.ToolHttpAccountChangInnerEBHttpMsgReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpOAMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	if err := mqconsumer.HandlerAccountChangInnerEBHttpMsg(ctx, &bizmodels.AccountChangeInnerEBMsg{
		IsTools: true,
		Detail: bizmodels.AccountChangeInnerEBMsgDetail{
			AccountID: param.AccountID,
		},
	}); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// HttpPerformEventMsg20210101 http发送履约事件消息
func (h *innerToolHandler) HttpPerformEventMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.PerformEvent
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpOAMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	body, _ := json.Marshal(param)
	if err := mqconsumer.HandlerPerformEventHttpMsg(ctx, string(body)); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// HttpDeferMsg20210101 http发送消息
func (h *innerToolHandler) HttpDeferMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.ToolHttpMqDeferMsgReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpOAMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	req := map[string]interface{}{
		"defer_type": param.DeferType,
		"body":       param.Body,
	}

	body, _ := json.Marshal(req)
	if err := mqconsumer.HandlerHttpDeferMsg(ctx, string(body)); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// HttpVolcContractEventMsg20210101 http手动承接合同事件消息
func (h *innerToolHandler) HttpVolcContractEventMsg20210101(ctx context.Context, c *app.RequestContext) {

	// 参数解析
	var param bizmodels.ToolHttpVolcContractEventMsgReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "HttpVolcContractEventMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := param.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if env.IsProduct() {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("env"))
		return
	}

	if err := mqconsumer.HandlerVolcContractEventHttpMsg(ctx, param.Body); err != nil {
		logs.CtxError(ctx, "HttpVolcContractEventMsgFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
		"Code":    0,
	})

}

// 刷新报价项工具
func (h *innerToolHandler) RefreshQuoteItems20210101(ctx context.Context, c *app.RequestContext) {

	contractNoListStr := c.Query("contractNoList")
	if len(contractNoListStr) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("invalid contractNoList"))
		return
	}
	contractNoList := strings.Split(contractNoListStr, ",")

	forceRefreshStr := c.Query("forceRefresh")
	forceRefresh, _ := strconv.ParseBool(forceRefreshStr)

	var failedContracts []string
	for _, contractNo := range contractNoList {
		err := datarefresh.NewDataRefreshService().RefreshQuoteItemsFromQuoteID(ctx, contractNo, forceRefresh)
		if err != nil {
			logs.CtxError(ctx, "RefreshFromQuoteID Fail, contractNo: %s, err: %s", contractNo, err.Error())
			failedContracts = append(failedContracts, contractNo)
		}
	}
	if len(failedContracts) > 0 {
		larkc.Warning("部分合同报价数据刷新失败", strings.Join(failedContracts, ","))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) UpdateContractTextByContractNo20210101(ctx context.Context, c *app.RequestContext) {
	contractNoListStr := c.Query("contractNoList")
	if len(contractNoListStr) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("invalid contractNoList"))
		return
	}
	contractNoList := strings.Split(contractNoListStr, ",")

	var failedContracts []string
	for _, contractNo := range contractNoList {
		err := datarefresh.NewDataRefreshService().UpdateContractText(ctx, contractNo)
		if err != nil {
			logs.CtxError(ctx, "UpdateContractTextFail, contractNo: %s, err: %s", contractNo, err.Error())
			failedContracts = append(failedContracts, contractNo)
		}
	}
	if len(failedContracts) > 0 {
		larkc.Warning("部分合同文本更新失败", strings.Join(failedContracts, ","))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "所有合同文本更新成功",
	})
}

func (h *innerToolHandler) EncryptMdPartyInfoDB20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptMdPartyInfoDB20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseUint(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().EncryptMdPartyInfoDB(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "EncryptMdPartyInfoDBFail, err: %+v", err)
		larkc.Warning("md数据加密更新失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	larkc.Warning("主数据加密完成", "主数据加密完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) EncryptMdPartyInfoByID20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptMdPartyInfoByID20210101_start")
	id := c.Query("id")
	idUint64, err := strconv.ParseUint(id, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid id"))
		return
	}
	err = datarefresh.NewDataRefreshService().EncryptMdPartyInfoByID(ctx, idUint64)
	if err != nil {
		logs.CtxError(ctx, "EncryptMdPartyInfoByIDFail, err: %+v", err)
		larkc.Warning("md数据加密更新失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) CheckMdPartyInfoDBConsistency20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "CheckMdPartyInfoDBConsistency20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseUint(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().CheckMdPartyInfoDBConsistency(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "CheckMdPartyInfoDBConsistencyFail, err: %+v", err)
		larkc.Warning("md数据一致性检验失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	larkc.Warning("md数据一致性检验完成", "md数据一致性检验完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})

}

func (h *innerToolHandler) EncryptContractTradePartyDB20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptContractTradePartyDB20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseUint(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().EncryptContractTradePartyDB(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "EncryptContractTradePartyDBFail, err: %+v", err)
		larkc.Warning("交易双方信息加密更新失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	larkc.Warning("交易双方信息加密完成", "交易双方信息加密完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) EncryptContractTradePartyByID20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptContractTradePartyByID20210101_start")
	id := c.Query("id")
	idUint64, err := strconv.ParseUint(id, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid id"))
		return
	}
	err = datarefresh.NewDataRefreshService().EncryptContractTradePartyByID(ctx, idUint64)
	if err != nil {
		logs.CtxError(ctx, "EncryptContractTradePartyByIDFail, err: %+v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) CheckEncryptContractTradePartyDBConsistency20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "CheckEncryptContractTradePartyDBConsistency20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseUint(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().CheckContractTradePartyDBConsistency(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "CheckContractTradePartyDBConsistencyFail, err: %+v", err)
		larkc.Warning("交易双方信息一致性检验失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	larkc.Warning("交易双方信息一致性检验完成", "交易双方信息一致性检验完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})

}

func (h *innerToolHandler) EncryptContractMetaDB20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptContractMetaDB20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseInt(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().EncryptContractMetaDB(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "EncryptContractMetaDBFail, err: %+v", err)
		larkc.Warning("合同元数据加密更新失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	larkc.Warning("合同元数据加密完成", "合同元数据加密完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) EncryptContractMetaByID20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "EncryptContractMetaByID20210101_start")
	idStr := c.Query("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		logs.CtxError(ctx, "EncryptContractMetaByID20210101 ParseInt err, id: %s, err: %+v", id, err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid id"))
		return
	}
	err = datarefresh.NewDataRefreshService().EncryptContractMetaDBByID(ctx, id)
	if err != nil {
		logs.CtxError(ctx, "EncryptContractMetaByID20210101 EncryptContractMetaDBByID err, id: %d, err: %+v", id, err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerToolHandler) CheckContractMetaDBConsistency20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "CheckContractMetaDBConsistency20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseInt(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().CheckContractMetaDBConsistency(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "CheckMdPartyInfoDBConsistencyFail, err: %+v", err)
		larkc.Warning("合同元数据一致性检验失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	larkc.Warning("合同元数据一致性检验完成", "合同元数据一致性检验完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})

}

func (h *innerToolHandler) FillMainContractNo20210101(ctx context.Context, c *app.RequestContext) {
	logs.CtxInfo(ctx, "FillMainContractNo20210101_start")

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseInt(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().FillMainContractNo(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "FillMainContractNo20210101 err: %+v", err)
		larkc.Warning("填充主合同号失败", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	larkc.Warning("填充主合同号完成", "填充主合同号完成")
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

// UpdateBizDataByNo20210101 同步报价单信息
func (h *innerToolHandler) UpdateBizDataByNo20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)
	if token != _const.MetaToolToken {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	contractNo := c.Query("ContractNo")

	err := h.metaService.UpdateBizDataByContractNo(ctx, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})

}

// SyncContractMetaCommodity20210101 同步报价单信息
func (h *innerToolHandler) SyncContractMetaCommodityByVolcContractId20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "SyncContractMetaCommodityTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	volcContractId := c.Query("VolcContractId")

	contractId, _ := strconv.ParseInt(volcContractId, 10, 64)

	lastID := metacommodity.NewService().SyncManageInfoById(ctx, contractId)

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})

}

// BindQuoteContract20210101 解绑报价单
func (h *innerToolHandler) BindQuoteContract20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "BindQuoteContractTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	quoteNo, ok := c.GetQuery("QuoteNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("QuoteNo"))
		return
	}

	meta, err := dal.NewContractMetaDao().FindByNo(ctx, nil, contractNo, 1)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs(err.Error()))
		return
	}
	if meta == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("合同不存在"))
		return
	}

	logs.CtxInfo(ctx, "BindQuoteContractRequestIn, ContractNo=%s, quoteNo=%s", contractNo, quoteNo)
	contract, err := quotecli.BindQuoteContract(ctx, quoteNo, contractNo)
	if err != nil {
		logs.CtxError(ctx, "BindQuoteContractFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("BindQuoteContractFail"))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Success": true,
		"Result":  contract,
	})
}

// AddOtherPartyAccount20210101 给指定对方主体补充账号信息，并可选标记为副签约主体
func (h *innerToolHandler) AddOtherPartyAccount20210101(ctx context.Context, c *app.RequestContext) {

	if !h.checkToken(ctx, c) {
		logs.CtxError(ctx, "AddOtherPartyAccountTokenInvalid")
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	var req bizmodels.ToolAddOtherPartyAccountReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "AddOtherPartyAccountBindFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(ctx); err != nil {
		logs.CtxError(ctx, "AddOtherPartyAccountValidateFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	if err := datarefresh.NewDataRefreshService().AddOtherPartyAccount(ctx, &req); err != nil {
		logs.CtxError(ctx, "AddOtherPartyAccountFail, req:%+v, err:%v", req, err)
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Message": "Success",
	})
}

// UnbindQuoteContract20210101 解绑报价单
func (h *innerToolHandler) UnbindQuoteContract20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "UnbindQuoteContractTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	quoteNo, ok := c.GetQuery("QuoteNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("QuoteNo"))
		return
	}

	meta, err := dal.NewContractMetaDao().FindByNo(ctx, nil, contractNo, 1)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs(err.Error()))
		return
	}
	if meta == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("合同不存在"))
		return
	}

	logs.CtxInfo(ctx, "UnbindQuoteContractRequestIn, contractNo=%s, quoteNo=%s", contractNo, quoteNo)
	contract, err := quotecli.UnbindQuoteContract(ctx, quoteNo, contractNo)
	if err != nil {
		logs.CtxError(ctx, "UnbindQuoteContractFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("UnbindQuoteContractFail"))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Success": true,
		"Result":  contract,
	})
}

func (h *innerToolHandler) checkToken(ctx context.Context, c *app.RequestContext) bool {
	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		return false
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		return false
	}

	return true
}

// Archived20210101 自动配价
func (h *innerToolHandler) Archived20210101(ctx context.Context, c *app.RequestContext) {

	if !h.checkToken(ctx, c) {
		logs.CtxError(ctx, "ArchivedDiffTokenInvalid")
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	fileTime, ok := c.GetQuery("FileTime")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("FileTime"))
		return
	}
	fileDate, err := time.ParseInLocation(model.DBDateFormatTpl, fileTime, time.Local)
	if err != nil {
		logs.CtxError(ctx, "ParseFileTimeFail, error: %v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrNotFound.WithArgs("格式化归档时间失败"))
		return
	}

	err = h.metaService.ArchivedContract(ctx, contractNo, fileDate)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"logId": ctx.Value(_const.CtxLogID),
	})
}

// OAArchived20210101 OA合同归档
func (h *innerToolHandler) OAArchived20210101(ctx context.Context, c *app.RequestContext) {

	if !h.checkToken(ctx, c) {
		logs.CtxError(ctx, "OAArchivedTokenInvalid")
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	ctx = context.WithValue(ctx, _const.CtxVCPUseMock, "true")
	err := salescontract.NewSalesContractService().ContractArchived(ctx, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"logId": ctx.Value(_const.CtxLogID),
	})
}

// OAArchived20210101 OA合同归档
func (h *innerToolHandler) OASigned20210101(ctx context.Context, c *app.RequestContext) {

	if !h.checkToken(ctx, c) {
		logs.CtxError(ctx, "OAArchivedTokenInvalid")
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	if len(contractNo) == 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	ctx = context.WithValue(ctx, _const.CtxVCPUseMock, "true")
	err := salescontract.NewSalesContractService().ContractSigned(ctx, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"logId": ctx.Value(_const.CtxLogID),
	})
}

// FixProductDeploymentType20210101 修复商品部署方式
func (h *innerToolHandler) FixProductDeploymentType20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("StartID")
	offsetStr := c.Query("Offset")

	startID, _ := strconv.ParseInt(startIDStr, 10, 64)
	offset, _ := strconv.ParseInt(offsetStr, 10, 64)
	if offset == 0 || offset > 500 {
		logs.CtxError(ctx, "invalidID, start=%d, offset=%d", startID, offset)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	lastID := metasync.NewService().FixProductDeploymentType(ctx, startID, int(offset))

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})

}

// FixMetaProductByCommodity20210101 修复product字段
func (h *innerToolHandler) FixMetaProductByCommodity20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("StartID")
	offsetStr := c.Query("Offset")

	startID, _ := strconv.ParseInt(startIDStr, 10, 64)
	offset, _ := strconv.ParseInt(offsetStr, 10, 64)
	if offset == 0 || offset > 500 {
		logs.CtxError(ctx, "invalidID, start=%d, offset=%d", startID, offset)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	lastID := metacommodity.NewFixDataService().FixMetaProductByCommodity(ctx, nil, startID, int(offset))
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})
}

// ChangeProcessFeishuToOA20210101 对接飞书合同上线后 飞书流程 迁移 OA流程
func (h *innerToolHandler) ChangeProcessFeishuToOA20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	ContractNoList := c.Query("ContractNoList")

	if len(ContractNoList) == 0 {
		logs.CtxError(ctx, "ContractNoListIsEmpty, ContractNoList=%s", ContractNoList)
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	contractNos := strings.Split(ContractNoList, ",")
	var errArr []string
	for _, contractNo := range contractNos {
		err := metasync.NewService().ChangeProcessFeishuToOA(ctx, contractNo)
		if err != nil {
			logs.CtxError(ctx, "ChangeProcessFeishuToOAError, contractNo=%s, err=%s", contractNo, err)
			errArr = append(errArr, err.Error())
		}
	}
	if len(errArr) > 0 {
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(strings.Join(errArr, "\n")))
		return
	}
	vhertz.DoResponse(ctx, c, "success")
}

func (h *innerToolHandler) FixContractSettlementLine20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	ContractNo := c.Query("ContractNo")
	if len(ContractNo) == 0 {
		logs.CtxError(ctx, "FixContractSettlementLineFail, ContractNo=%s", ContractNo)
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	err := contractsettlement.NewSettlementService().FixContractSettlementLine(ctx, ContractNo)
	if err != nil {
		logs.CtxError(ctx, "FixContractSettlementLineFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, "success")
}

func (h *innerToolHandler) QueryEventRules20210101(ctx context.Context, c *app.RequestContext) {
	rules := conf.GetEventRules(ctx)
	vhertz.DoResponse(ctx, c, rules)
}

// FixTradePartyInfo20210101 修复交易双方信息
func (h *innerToolHandler) FixTradePartyInfo20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("StartID")
	offsetStr := c.Query("Offset")

	startID, _ := strconv.ParseInt(startIDStr, 10, 64)
	offset, _ := strconv.ParseInt(offsetStr, 10, 64)
	if offset == 0 || offset > 500 {
		logs.CtxError(ctx, "invalidID, start=%d, offset=%d", startID, offset)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	lastID := metatradeparty.NewService().FixTradePartyInfo(ctx, startID, int(offset))

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})

}

// RefreshHistoryBasicInfoTotal20210101 刷新历史数据中的收入金额，上线后该接口可删除
func (h *innerToolHandler) RefreshHistoryBasicInfoTotal20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshHistoryBasicInfoTotalTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.RefreshBasicInfoReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshHistoryBasicInfoTotalParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshBasicInfo(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshHistoryBasicInfoDepartmentFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// RefreshSupplyContractBusinessType20210101 刷新历史数据中的业务类型
func (h *innerToolHandler) RefreshSupplyContractBusinessType20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshSupplyContractBusinessTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshSupplyContractBusinessTypeParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshSupplyContractBusinessType(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshSupplyContractBusinessTypeFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// RefreshHistoryProjectInfo20210101 刷新历史数据中的项目信息，上线后该接口可删除
func (h *innerToolHandler) RefreshHistoryProjectInfo20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshHistoryProjectInfoTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshHistoryProjectInfoParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshProjectInfo(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshHistoryProjectInfoFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// RefreshSealPricingData20210101 刷新历史数据中的签约配价信息，上线后该接口可删除
func (h *innerToolHandler) RefreshSealPricingData20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshSealPricingDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshSealPricingDataParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshSealPricingData(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshSealPricingDataFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// RefreshAccountID20210101 刷新签约配价账号信息，上线后该接口可删除
func (h *innerToolHandler) RefreshAccountID20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshAccountIDTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshAccountIDParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshAccountID(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshAccountIDFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// MultiQuote20210101 更换报价单工具接口
func (h *innerToolHandler) RefreshCooperationStatusChangeTime20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshAccountIDTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshAccountIDParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshCooperationStatusChangeTime(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshAccountIDFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// RefreshHistorySupplyContractFile20210101 刷新历史飞书补充协议的合同文件，上线后该接口可删除
func (h *innerToolHandler) RefreshHistorySupplyContractFile20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshHistorySupplyContractFileTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	var param datarefresh.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshHistorySupplyContractFileParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := datarefresh.NewDataRefreshService().RefreshHistorySupplyContractFile(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshHistorySupplyContractFileFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

// MultiQuote20210101 更换报价单工具接口
func (h *innerToolHandler) MultiQuote20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshAccountIDTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.MultiQuoteReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshAccountIDParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := metasync.NewFixDataService().MultiQuote(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshAccountIDFail, err=%v", err)
		vhertz.ErrorResp(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, "success")
}

// RefreshCouponAppendConfig20210101 历史合同"是否推送代金券附录"字段刷数工具接口
//   - 捞取现有包含合同维度"是否推送代金券附录"字段的合同；
//   - 将合同维度值赋值给"返券方式 != 其他"的返券规则维度字段，"返券方式 = 其他"的返券规则维度字段刷为"否"；
//   - 若合同维度值为空，则合同维度刷成"否"，每条返券规则维度也刷为"否"。
func (h *innerToolHandler) RefreshCouponAppendConfig20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshCouponAppendConfigTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("startID")
	batchSizeStr := c.Query("batchSize")

	startID, err := strconv.ParseInt(startIDStr, 10, 64)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid startID"))
		return
	}
	batchSize, err := strconv.Atoi(batchSizeStr)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid batchSize"))
		return
	}

	err = datarefresh.NewDataRefreshService().RefreshCouponAppendConfig(ctx, startID, batchSize)
	if err != nil {
		logs.CtxError(ctx, "RefreshCouponAppendConfigFail, err=%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

// RefreshCouponAppendConfigByContractNo20210101 指定单个合同刷"是否推送代金券附录"字段工具接口
func (h *innerToolHandler) RefreshCouponAppendConfigByContractNo20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshCouponAppendConfigByContractNoTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	contractNo := strings.TrimSpace(c.Query("contractNo"))
	if contractNo == "" {
		contractNo = strings.TrimSpace(c.Query("ContractNo"))
	}
	if contractNo == "" {
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs("invalid contractNo"))
		return
	}

	if err := datarefresh.NewDataRefreshService().RefreshCouponAppendConfigByContractNo(ctx, contractNo); err != nil {
		logs.CtxError(ctx, "RefreshCouponAppendConfigByContractNoFail, contractNo=%s, err=%v", contractNo, err)
		vhertz.ErrorResp(ctx, c, errors.ErrInternalError.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message":    "success",
		"contractNo": contractNo,
	})
}

// FixProductDeploymentType20210101 修复商品部署方式
func (h *innerToolHandler) MigrateOpportunityData20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("StartID")
	offsetStr := c.Query("Offset")

	startID, _ := strconv.ParseInt(startIDStr, 10, 64)
	offset, _ := strconv.ParseInt(offsetStr, 10, 64)
	if offset == 0 || offset > 1000 {
		logs.CtxError(ctx, "invalidID, start=%d, offset=%d", startID, offset)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	lastID := metatradeparty.NewService().MigrateOpportunityData(ctx, startID, int(offset))

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})

}

func (h *innerToolHandler) GenJwtToken20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "FixProductDeploymentTypeTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	appID := c.Query("AppID")
	secret := c.Query("Secret")

	client, _ := jwt_permission.NewClient(appID, secret, 24*time.Hour)
	resp, _ := client.GenerateToken("")

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Token": resp,
	})
}

// RefreshTosData20210101 刷新TOS阶梯报价相关数据，上线后该接口可删除
func (h *innerToolHandler) RefreshTosData20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshTosDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.RefreshTosDataReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshTosDataBindParamFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshTosData(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshTosDataFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// RefreshTosData20210101 刷新TOS阶梯报价相关数据，上线后该接口可删除
func (h *innerToolHandler) Cronjob20210101(ctx context.Context, c *app.RequestContext) {

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	token := c.Query(_const.HeaderToolToken)
	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshTosDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	cronjobKey := c.Query("CronjobKey")
	daysStr := c.Query("Days")
	var days int64
	var err error
	if cronjobKey == "ContractExpiredBeforeDays" {
		days, err = strconv.ParseInt(daysStr, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "RiskEngineCallBack20210101 Parse Timestamp Fail, err :%v", err)
			vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail.WithArgs(err.Error()))
			return
		}
	}

	switch cronjobKey {
	case "PullUnarchivedContract":
		cronjob.PullUnarchivedContract(_const.BizSceneSalesContract)
	case "ContractExpiredBeforeDays":
		cronjob.ContractExpiredBeforeDays(int(days))
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ContractFileMigrate20210101 合同关联合同文本迁移文件管理系统
func (h *innerToolHandler) ContractFileMigrate20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshTosDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	// 参数解析
	var param metaattachmodels.ContractFileMigrateReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshTosDataBindParamFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	errMsg, err := metaattachment.NewService().ContractFileMigrate(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshTosDataFail, err=%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"errMsg": errMsg,
	})
}

// FixCooperationApproveFileVersion20210101 修复协同合同的审批文件版本号
func (h *innerToolHandler) FixCooperationApproveFileVersion20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshTosDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}
	// 参数解析
	var param metaext.FixCooperationApproveFileVersionReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshTosDataBindParamFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := metaext.NewService().FixCooperationApproveFileVersion(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshTosDataFail, err=%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}
	vhertz.DoResponse(ctx, c, nil)
}

// FixBelongingDepartment20210101 历史数据一级产品线刷新
func (h *innerToolHandler) FixBelongingDepartment20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshTosDataTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	startIDStr := c.Query("StartID")
	offsetStr := c.Query("Offset")

	startID, _ := strconv.ParseInt(startIDStr, 10, 64)
	offset, _ := strconv.ParseInt(offsetStr, 10, 64)
	if offset == 0 || offset > 1000 {
		logs.CtxError(ctx, "invalidID, start=%d, offset=%d", startID, offset)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	lastID := metasync.NewService().FixBelongingDepartment(ctx, startID, int(offset))

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"LastID": lastID,
	})
}

// RefreshRelateQuoteScene20210101 清洗关联报价单场景
func (h *innerToolHandler) RefreshRelateQuoteScene20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshRelateQuoteSceneTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshRelateQuoteSceneParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	resp, err := metasync.NewFixDataService().RefreshRelateQuoteScene(ctx, &param)
	if err != nil {
		logs.CtxError(ctx, "RefreshRelateQuoteSceneFail, err=%v", err)
		vhertz.DoResponse(ctx, c, err)
		return
	}
	vhertz.DoResponse(ctx, c, resp)
}

func (h *innerToolHandler) RefreshRedisIncrByKey20210101(ctx context.Context, c *app.RequestContext) {

	token := c.Query(_const.HeaderToolToken)

	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	if !strings.Contains(cfg.ProductsApp.Auths, token) {
		logs.CtxError(ctx, "RefreshRelateQuoteSceneTokenInvalid, token=%s", token)
		vhertz.DoResponse(ctx, c, nil)
		return
	}

	// 参数解析
	var param metasync.CommonRefreshReq
	if err := binding.BindAndValidate(c, &param); err != nil {
		logs.CtxError(ctx, "RefreshRelateQuoteSceneParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	incrKey := c.Query("IncrKey")
	incrStep := c.Query("IncrStep")
	if len(incrKey) == 0 || len(incrStep) == 0 {
		logs.CtxError(ctx, "RefresfRedisIncrByKeyParamBindFail, incrStep or IncrStep is nil")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("IncrKey||IncrStep"))
		return
	}
	incrStepNum, err := strconv.ParseUint(incrStep, 10, 64)
	if err != nil {
		logs.CtxError(ctx, "RefresfRedisIncrByKeyParamBindFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("IncrStep"))
		return
	}
	for {
		val, err := rediscli.IncrByKey(ctx, incrKey)
		if err != nil {
			logs.CtxError(ctx, "RefresfRedisIncrByKeyFail, err=%v", err)
			vhertz.DoResponse(ctx, c, err)
			return
		}
		if val >= int64(incrStepNum) {
			break
		}
	}
	vhertz.DoResponse(ctx, c, "success")
}

// FillDeploymentTypeForPartnerQuote20210101 数据订正接口——更新伙伴报价合同部署方式
func (h *innerToolHandler) FillDeploymentTypeForPartnerQuote20210101(ctx context.Context, c *app.RequestContext) {

	err := datarefresh.NewDataRefreshService().FillDeploymentTypeForPartnerQuote(ctx)
	if err != nil {
		logs.CtxError(ctx, "FillDeploymentTypeForPartnerQuote20210101 fail, err=%s", err.Error())
		larkc.Warning("更新伙伴报价合同部署方式失败", err.Error())
		vhertz.DoResponse(ctx, c, err)
		return
	}
	larkc.Warning("更新伙伴报价合同部署方式完成", "更新伙伴报价合同部署方式完成")
	vhertz.DoResponse(ctx, c, nil)
}

// ChangeContractOwner 修改合同执行人/创建人/审批人
func (h *innerToolHandler) ChangeContractOwner20210101(ctx context.Context, c *app.RequestContext) {

	var req modelinnertool.ChangeContractOwnerReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ChangeContractOwnerBindFail, err:%s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	if err := req.Validate(ctx); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	// 运维工具操作权限仅对白名单内用户开放
	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil || cfg.ToolConf == nil || len(cfg.ToolConf.ContractOwnerChangerAllowedUsers) == 0 {
		logs.CtxError(ctx, "ChangeContractOwnerForbidden, config or whitelist empty")
		vhertz.ErrorResp(ctx, c, errors.ErrorExplicitDeny.WithArgs("operate user not allowed"))
		return
	}

	if !util.StringIn(req.CurrentOperator, cfg.ToolConf.ContractOwnerChangerAllowedUsers) {
		logs.CtxError(ctx, "ChangeContractOwnerForbidden, email=%s", req.CurrentOperator)
		vhertz.ErrorResp(ctx, c, errors.ErrorExplicitDeny.WithArgs("操作人不在白名单内"))
		return
	}

	if err := datarefresh.NewDataRefreshService().ChangeContractOwner(ctx, &req); err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"Result": "success",
	})
}

// FillRiskClauseTplReviewer20210101 数据订正接口——更新风险条款审批人
func (h *innerToolHandler) FillRiskClauseTplReviewer20210101(ctx context.Context, c *app.RequestContext) {

	sheetURL := c.Query("SheetURL")
	header := c.Query("Header")
	refreshType := c.Query("RefreshType")
	if len(refreshType) == 0 {
		logs.CtxError(ctx, "FillRiskClauseTplReviewer20210101 fail, RefreshType is nil")
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("RefreshType"))
		return
	}

	err := datarefresh.NewDataRefreshService().FillRiskClauseTplReviewer(ctx, refreshType, sheetURL, header)
	if err != nil {
		logs.CtxError(ctx, "FillRiskClauseTplReviewer20210101 fail, err=%s", err.Error())
		larkc.Warning("更新风险条款审批人失败", err.Error())
		vhertz.DoResponse(ctx, c, err)
		return
	}
	larkc.Warning("更新风险条款审批人完成", "更新风险条款审批人完成")
	vhertz.DoResponse(ctx, c, nil)
}

func (h *innerToolHandler) TestGenCRMDetailURL20210101(ctx context.Context, c *app.RequestContext) {
	contractNo := c.Query("ContractNo")
	url := larkc.GenCRMDetailURL(ctx, contractNo)
	vhertz.DoResponse(ctx, c, url)
}

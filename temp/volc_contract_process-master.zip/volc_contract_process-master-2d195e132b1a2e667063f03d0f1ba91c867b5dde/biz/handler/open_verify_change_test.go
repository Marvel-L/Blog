package handler

import (
	"context"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/metasupport"
	"volc_contract_process/biz/service/support/verifychange"
	"volc_contract_process/pkg/errors"
)

func Test_openVerifyChangeHandler_HasNonFinalContract20210101(t *testing.T) {
	mockey.PatchConvey("Test_openVerifyChangeHandler_HasNonFinalContract20210101", t, func() {
		// Initialize the handler with a mock service
		service := verifychange.NewService()
		h := &openVerifyChangeHandler{
			service: service,
		}

		mockey.PatchConvey("当AccountID参数缺失时，应返回参数缺失错误", func() {
			// 场景描述：
			// 构造数据：构造一个不带"AccountID"查询参数的hertz请求上下文。
			// 逻辑链路：
			// 1. 函数进入后，调用h.queryAccountID方法。
			// 2. h.queryAccountID因找不到"AccountID"参数而返回一个ErrMissingParam错误。
			// 3. 函数捕获到错误，调用vhertz.ErrorResp返回错误响应。
			c := &app.RequestContext{}

			h.HasNonFinalContract20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, "The parameter [AccountID] is missing.")
		})

		mockey.PatchConvey("当AccountID参数格式无效（非数字）时，应返回参数无效错误", func() {
			// 场景描述：
			// 构造数据：构造一个"AccountID"为"not-a-number"的hertz请求上下文。
			// 逻辑链路：
			// 1. 函数进入后，调用h.queryAccountID方法。
			// 2. h.queryAccountID在尝试将"not-a-number"解析为整数时失败，返回一个ErrInvalidParam错误。
			// 3. 函数捕获到错误，调用vhertz.ErrorResp返回错误响应。
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("AccountID", "not-a-number")

			h.HasNonFinalContract20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [AccountID] is invalid.`)
		})

		mockey.PatchConvey("当AccountID参数长度不等于10时，应返回参数无效错误", func() {
			// 场景描述：
			// 构造数据：构造一个"AccountID"为"12345"（长度不为10）的hertz请求上下文。
			// 逻辑链路：
			// 1. h.queryAccountID成功解析出AccountID。
			// 2. 函数检查AccountID的字符串长度，发现不等于常量accountIDLength(10)。
			// 3. 函数记录错误日志并调用vhertz.ErrorResp返回ErrInvalidParam错误。
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("AccountID", "12345")

			h.HasNonFinalContract20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [AccountID] is invalid.`)
		})

		mockey.PatchConvey("当service.GetNonFinalContractList调用失败时，应透传错误", func() {
			// 场景描述：
			// 构造数据：构造合法的"AccountID"，并Mock service层返回一个自定义错误。
			// 逻辑链路：
			// 1. 参数校验通过。
			// 2. 调用h.service.GetNonFinalContractList方法。
			// 3. Mock的service方法返回一个错误。
			// 4. 函数捕获到service错误，调用vhertz.ErrorResp返回该错误。
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("AccountID", "1234567890")
			serviceErr := errors.NewErr("SERVICE_UNAVAILABLE", "service is down", 500)

			mockey.Mock(mockey.GetMethod(h.service, "GetNonFinalContractList")).Return(nil, serviceErr).Build()
			h.HasNonFinalContract20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `service is down`)
		})

		mockey.PatchConvey("当存在未终态合同时，应返回HasNonFinalContract为true", func() {
			// 场景描述：
			// 构造数据：构造合法的"AccountID"，并Mock service层返回一个包含一个合同数据的列表。
			// 逻辑链路：
			// 1. 参数校验通过。
			// 2. 调用h.service.GetNonFinalContractList方法。
			// 3. Mock的service方法返回成功，且响应的List长度大于0。
			// 4. 函数根据List长度计算出HasNonFinalContract为true。
			// 5. 调用vhertz.DoResponse返回成功响应。
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("AccountID", "1234567890")
			serviceResp := &metasupport.GetNonFinalContractListResp{
				List: []*metasupport.ContractData{{ContractNo: "CT-1"}},
			}

			mockey.Mock(mockey.GetMethod(h.service, "GetNonFinalContractList")).Return(serviceResp, nil).Build()

			h.HasNonFinalContract20210101(context.Background(), c)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"HasNonFinalContract":true}`)
		})

		mockey.PatchConvey("当不存在未终态合同时，应返回HasNonFinalContract为false", func() {
			// 场景描述：
			// 构造数据：构造合法的"AccountID"，并Mock service层返回一个空的合同数据列表。
			// 逻辑链路：
			// 1. 参数校验通过。
			// 2. 调用h.service.GetNonFinalContractList方法。
			// 3. Mock的service方法返回成功，且响应的List长度为0。
			// 4. 函数根据List长度计算出HasNonFinalContract为false。
			// 5. 调用vhertz.DoResponse返回成功响应。
			c := &app.RequestContext{}
			c.Request.URI().QueryArgs().Set("AccountID", "1234567890")
			serviceResp := &metasupport.GetNonFinalContractListResp{
				List: []*metasupport.ContractData{},
			}

			mockey.Mock(mockey.GetMethod(h.service, "GetNonFinalContractList")).Return(serviceResp, nil).Build()

			h.HasNonFinalContract20210101(context.Background(), c)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"HasNonFinalContract":false}`)
		})
	})
}

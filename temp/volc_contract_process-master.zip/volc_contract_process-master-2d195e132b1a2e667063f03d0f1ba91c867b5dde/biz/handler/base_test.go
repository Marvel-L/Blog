package handler

import (
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
)

func TestBaseHelpers(t *testing.T) {
	t.Run("queryOperator", func(t *testing.T) {
		mockey.PatchConvey("queryOperator", t, func() {
			convey.So(queryOperator(context.Background()), convey.ShouldEqual, "")

			ctx := context.WithValue(context.Background(), _const.CtxAuthInfo, &bizmodels.AuthInfo{
				CurrentOperator: "tester@example.com",
			})
			convey.So(queryOperator(ctx), convey.ShouldEqual, "tester@example.com")
		})
	})

	t.Run("fetchAuthInfo", func(t *testing.T) {
		mockey.PatchConvey("fetchAuthInfo", t, func() {
			convey.So(fetchAuthInfo(context.Background()), convey.ShouldResemble, &bizmodels.AuthInfo{})

			wrongTypeCtx := context.WithValue(context.Background(), _const.CtxAuthInfo, "invalid")
			convey.So(fetchAuthInfo(wrongTypeCtx), convey.ShouldResemble, &bizmodels.AuthInfo{})

			expected := &bizmodels.AuthInfo{CurrentOperator: "tester@example.com"}
			validCtx := context.WithValue(context.Background(), _const.CtxAuthInfo, expected)
			convey.So(fetchAuthInfo(validCtx), convey.ShouldEqual, expected)
		})
	})

	t.Run("queryOperatorByReqOperator", func(t *testing.T) {
		mockey.PatchConvey("queryOperatorByReqOperator", t, func() {
			reqOperator := "req@example.com"

			convey.So(queryOperatorByReqOperator(context.Background(), reqOperator), convey.ShouldEqual, reqOperator)

			emptyHeaderCtx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "")
			convey.So(queryOperatorByReqOperator(emptyHeaderCtx, reqOperator), convey.ShouldEqual, reqOperator)

			headerCtx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "header@example.com")
			convey.So(queryOperatorByReqOperator(headerCtx, reqOperator), convey.ShouldEqual, "header@example.com")
		})
	})

	t.Run("fetchEmployeeEmail", func(t *testing.T) {
		mockey.PatchConvey("fetchEmployeeEmail", t, func() {
			convey.So(fetchEmployeeEmail(context.Background()), convey.ShouldEqual, "")

			invalidCtx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, 123)
			convey.So(fetchEmployeeEmail(invalidCtx), convey.ShouldEqual, "")

			validCtx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "tester@example.com")
			convey.So(fetchEmployeeEmail(validCtx), convey.ShouldEqual, "tester@example.com")
		})
	})

	t.Run("hasEmployeeHeader", func(t *testing.T) {
		mockey.PatchConvey("hasEmployeeHeader", t, func() {
			convey.So(hasEmployeeHeader(context.Background()), convey.ShouldBeFalse)

			emptyCtx := context.WithValue(context.Background(), _const.CtxEmployeeFlag, "")
			convey.So(hasEmployeeHeader(emptyCtx), convey.ShouldBeFalse)

			validCtx := context.WithValue(context.Background(), _const.CtxEmployeeFlag, "1")
			convey.So(hasEmployeeHeader(validCtx), convey.ShouldBeTrue)
		})
	})
}



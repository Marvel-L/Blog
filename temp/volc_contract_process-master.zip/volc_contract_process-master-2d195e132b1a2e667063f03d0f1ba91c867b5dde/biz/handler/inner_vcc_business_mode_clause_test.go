package handler

import (
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelbusinessmodeclause"
	"volc_contract_process/biz/service/businessmodeclause"
	"volc_contract_process/pkg/errors"
)

func Test_innerVCCBusinessModeClauseHandler_EditBusinessModeClauses20210101(t *testing.T) {
	t.Run("case BindAndValidate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			clauseService := businessmodeclause.NewService()

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return fmt.Errorf("bind error")
			}).Build()

			h := &innerVCCBusinessModeClauseHandler{
				clauseService: clauseService,
			}
			h.EditBusinessModeClauses20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case Validate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			clauseService := businessmodeclause.NewService()

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				req := obj.(*modelbusinessmodeclause.EditBusinessModeClausesReq)
				req.ContractNo = "CN001"
				return nil
			}).Build()

			h := &innerVCCBusinessModeClauseHandler{
				clauseService: clauseService,
			}
			h.EditBusinessModeClauses20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [CurrentOperator] is missing.`)
		})
	})

	t.Run("case EditBusinessModeClauses Return APIError", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			clauseService := businessmodeclause.NewService()

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				req := obj.(*modelbusinessmodeclause.EditBusinessModeClausesReq)
				req.ContractNo = "CN001"
				req.CurrentOperator = "tester"
				req.BusinessModeClauses = []*bizmodels.BusinessModeClause{{Id: 1, BusinessMode: "mode-a", ClauseSummary: "summary-a"}}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(clauseService, "EditBusinessModeClauses")).
				Return(errors.ErrMissingParam.WithArgs("ContractNo")).Build()

			h := &innerVCCBusinessModeClauseHandler{
				clauseService: clauseService,
			}
			h.EditBusinessModeClauses20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `The parameter [ContractNo] is missing.`)
		})
	})

	t.Run("case EditBusinessModeClauses Return Error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			clauseService := businessmodeclause.NewService()

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				req := obj.(*modelbusinessmodeclause.EditBusinessModeClausesReq)
				req.ContractNo = "CN001"
				req.CurrentOperator = "tester"
				req.BusinessModeClauses = []*bizmodels.BusinessModeClause{{Id: 1, BusinessMode: "mode-a", ClauseSummary: "summary-a"}}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(clauseService, "EditBusinessModeClauses")).
				Return(fmt.Errorf("service down")).Build()

			h := &innerVCCBusinessModeClauseHandler{
				clauseService: clauseService,
			}
			h.EditBusinessModeClauses20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"InternalError"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `service down`)
		})
	})

	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			clauseService := businessmodeclause.NewService()

			mockey.Mock(binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				req := obj.(*modelbusinessmodeclause.EditBusinessModeClausesReq)
				req.ContractNo = "CN001"
				req.CurrentOperator = "tester"
				req.BusinessModeClauses = []*bizmodels.BusinessModeClause{{Id: 1, BusinessMode: "mode-a", ClauseSummary: "summary-a"}}
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(clauseService, "EditBusinessModeClauses")).Return(nil).Build()

			h := &innerVCCBusinessModeClauseHandler{
				clauseService: clauseService,
			}
			h.EditBusinessModeClauses20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `{"ResponseMetadata":{"RequestId":""}}`)
		})
	})
}

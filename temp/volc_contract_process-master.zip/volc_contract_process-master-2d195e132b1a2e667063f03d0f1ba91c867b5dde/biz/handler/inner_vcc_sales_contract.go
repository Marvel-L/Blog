package handler

import (
	"context"
	"strconv"

	"volc_contract_process/pkg/preload"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelsalescontract"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/contractsettlement/settlementnotify"
	"volc_contract_process/biz/service/salescontract"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/contractperform"
	"volc_contract_process/pkg/proxy/oacli"
	"volc_contract_process/pkg/proxy/rediscli"
)

// 火山合同中心——合同商品信息
type innerVCCSalesContractHandler struct {
	base
	salesContractService salescontract.SalesContractService
}

func NewInnerVCCSalesContractHandler() vhertz.ActionHandler {
	return &innerVCCSalesContractHandler{
		salesContractService: salescontract.NewSalesContractService(),
	}
}

// CreateOrUpdate20210101 创建销售合同
func (h *innerVCCSalesContractHandler) CreateOrUpdate20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.CreateOrUpdateReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "CreateOrUpdateReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	// 修改basic_info.Department
	req.BasicInfo.DepartmentId = preload.ReviewRuleName2ID(req.BasicInfo.Department)
	req.BasicInfo.Department = ""

	resp, err := h.salesContractService.CreateOrUpdate(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// Submit20210101 提交销售合同至 OA 合同中心
func (h *innerVCCSalesContractHandler) Submit20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.SubmitReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "SubmitReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	resp, err := h.salesContractService.Submit(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, resp)
}

// SubmitSalesContract20210101 用于解决 action 命名冲突，内部复用 Submit20210101
func (h *innerVCCSalesContractHandler) SubmitSalesContract20210101(ctx context.Context, c *app.RequestContext) {
	h.Submit20210101(ctx, c)
}

// Delete20210101 删除草稿状态的销售合同
func (h *innerVCCSalesContractHandler) Delete20210101(ctx context.Context, c *app.RequestContext) {

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	contract, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs("合同不存在"))
		return
	}
	if contract == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrContractNotFound.WithArgs("合同记录不存在"))
		return
	}
	if contract.Status != _const.SalesContractUnSubmit {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs("非草稿合同不能删除"))
		return
	}

	err = dal.NewContractMetaDao().DeleteByNo(ctx, nil, contractNo, contract.Version)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs("数据库错误"))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// Supply20210101 提交补充协议
func (h *innerVCCSalesContractHandler) Supply20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.SupplyReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "SupplyReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	_, err := oacli.GrantOAContract(ctx, req.ContractNo, strconv.Itoa(int(authInnerUserInfo.EmployeeID)))
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}
	res, err := oacli.SmallQueryContract(ctx, req.ContractNo, false)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]string{
		"Url": res.DetailUrl,
	})
}

// Upload20210101 上传文件
func (h *innerVCCSalesContractHandler) Upload20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.UploadReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UploadReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	// 获取合上传文件
	formFile, err := c.FormFile("File")
	if err != nil || formFile == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("File"))
		return
	}
	req.File = formFile

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	downloadID, err := h.salesContractService.Upload(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"downloadID": downloadID,
	})
}

// Change20210101 修改合同 - 返回链接跳转至 OA 合同中心进行修改
func (h *innerVCCSalesContractHandler) Change20210101(ctx context.Context, c *app.RequestContext) {

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	creator, ok := c.GetQuery("Creator")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("Creator"))
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	_, err := oacli.GrantOAContract(ctx, contractNo, strconv.Itoa(int(authInnerUserInfo.EmployeeID)))
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}
	res, err := oacli.SmallQueryContract(ctx, contractNo, false)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}
	// 是否需要合同变更弹窗
	needNotify := rediscli.NeedContractChangeNotify(ctx, creator)

	ret := map[string]interface{}{
		"Url":        res.DetailUrl,
		"NeedNotify": needNotify,
	}

	vhertz.DoResponse(ctx, c, ret)
}

// UpdateAccountID20210101 关联 accountID
func (h *innerVCCSalesContractHandler) UpdateAccountID20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.UpdateAccountIDReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "UpdateAccountIdReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	err := h.salesContractService.UpdateAccountID(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

// ListSubjectOfContract20210101 返回合同主体编号
func (h *innerVCCSalesContractHandler) ListSubjectOfContract20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.ListSubjectOfContractReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListSubjectOfContractReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	ret, err := h.salesContractService.ListSubjectOfContract(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"SubjectInfoList": ret,
	})
}

// SyncContract20210101 同步销售合同
func (h *innerVCCSalesContractHandler) SyncContract20210101(ctx context.Context, c *app.RequestContext) {

	contractNoList := make([]string, 0)

	err := binding.BindAndValidate(c, &contractNoList)
	if err != nil {
		vhertz.ErrorResp(ctx, c, errors.ErrRequestInvalid.WithArgs(err))
		return
	}
	if len(contractNoList) == 0 {
		vhertz.DoResponse(ctx, c, "传入合同号为空")
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	h.salesContractService.SyncContract(ctx, contractNoList)

	vhertz.DoResponse(ctx, c, nil)
}

// SyncSalesContract20210101 用于解决 action 命名冲突，内部复用 SyncContract20210101
func (h *innerVCCSalesContractHandler) SyncSalesContract20210101(ctx context.Context, c *app.RequestContext) {
	h.SyncContract20210101(ctx, c)
}

// SyncContract20210101 同步销售合同
func (h *innerVCCSalesContractHandler) ListProductOfContract20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.ListProductOfContractReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "ListProductOfContractFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}
	req.SourceType = _const.SourceTypeInner
	req.CurrentOperator = authInnerUserInfo.EmployeeEmail

	ret, err := h.salesContractService.ListProductOfContract(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"ProductInformationList": ret,
	})
}

func (h *innerVCCSalesContractHandler) ContractPerform20210101(ctx context.Context, c *app.RequestContext) {

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		logs.CtxError(ctx, "AutoPricing_FindContractMetaFail, contractNo:%s", contractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}
	if meta == nil {
		logs.CtxError(ctx, "AutoPricing_FindContractMetaFail, contractNo:%s", contractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("合同不存在"))
		return
	}

	errA := h.salesContractService.SyncContractPerform(ctx, nil, contractNo, true)
	if errA != nil {
		logs.CtxError(ctx, "AutoPricingFail, err:%v", errA)
		vhertz.ErrorResp(ctx, c, errA)
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

func (h *innerVCCSalesContractHandler) SyncSettlementTerm20210101(ctx context.Context, c *app.RequestContext) {

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	meta, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		logs.CtxError(ctx, "AutoPricing_FindContractMetaFail, contractNo:%s", contractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}
	if meta == nil {
		logs.CtxError(ctx, "AutoPricing_FindContractMetaFail, contractNo:%s", contractNo)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("合同不存在"))
		return
	}

	resp, errA := contractperform.SyncSettlementTerm(ctx, nil, meta)
	if errA != nil {
		logs.CtxError(ctx, "AutoPricingFail, err:%v", errA)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(errA.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
		"resp":    resp,
	})
}

func (h *innerVCCSalesContractHandler) SyncReceivableSettlement20210101(ctx context.Context, c *app.RequestContext) {

	contractNo, ok := c.GetQuery("ContractNo")
	if !ok {
		vhertz.ErrorResp(ctx, c, errors.ErrMissingParam.WithArgs("ContractNo"))
		return
	}
	authInnerUserInfo := h.fetchUserInfoFromCtx(ctx)
	if authInnerUserInfo == nil {
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs("当前用户未登录"))
		return
	}

	err := settlementnotify.NotifyByContractNo(ctx, contractNo)
	if err != nil {
		logs.CtxError(ctx, "AutoPricingFail, err:%v", err)
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}

	vhertz.DoResponse(ctx, c, map[string]interface{}{
		"message": "success",
	})
}

// EditBasicInfo20210101 编辑合同基础信息
func (h *innerVCCSalesContractHandler) EditBasicInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelsalescontract.EditBasicInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "EditBasicInfoReqParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	err := h.salesContractService.EditBasicInfo(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, nil)
}

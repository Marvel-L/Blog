package handler

import (
	"context"
	errors "errors"
	"testing"
	"volc_contract_process/biz/service/riskclauserole"
	_const "volc_contract_process/pkg/const"
	pkg_errors "volc_contract_process/pkg/errors"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	middleware_hertz_pkg_app "code.byted.org/middleware/hertz/pkg/app"
	hertz_ext_v2_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

// 接口Mock结构体：用于mock riskclauserole.Service 的 List 方法
type Mock_Service_ListRiskClauseRole20210101 struct {
	riskclauserole.Service
}

type fakeInnerRiskClauseRoleService struct {
	riskclauserole.Service
	listFn              func(context.Context, *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error)
	createFn            func(context.Context, *riskclauserole.CreateRiskClauseRoleReq) error
	updateFn            func(context.Context, *riskclauserole.UpdateRiskClauseRoleReq) error
	deleteFn            func(context.Context, *riskclauserole.AuditRiskClauseRoleReq) error
	closeFn             func(context.Context, *riskclauserole.AuditRiskClauseRoleReq) error
	submitFn            func(context.Context, *riskclauserole.SubmitApprovalReq) (string, error)
	getApproveViewUrlFn func(context.Context, string) (string, error)
}

func (f *fakeInnerRiskClauseRoleService) List(ctx context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
	return f.listFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) CreateRiskClauseRole(ctx context.Context, req *riskclauserole.CreateRiskClauseRoleReq) error {
	return f.createFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) UpdateRiskClauseRole(ctx context.Context, req *riskclauserole.UpdateRiskClauseRoleReq) error {
	return f.updateFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) DeleteRiskClauseRole(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
	return f.deleteFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) CloseRiskClauseRole(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
	return f.closeFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) SubmitApproval(ctx context.Context, req *riskclauserole.SubmitApprovalReq) (string, error) {
	return f.submitFn(ctx, req)
}

func (f *fakeInnerRiskClauseRoleService) GetApproveViewUrl(ctx context.Context, approveId string) (string, error) {
	return f.getApproveViewUrlFn(ctx, approveId)
}

func fillValidCreateRiskClauseRoleReq(req *riskclauserole.CreateRiskClauseRoleReq) {
	req.CurrentOperator = "origin-operator"
	req.ContractNo = "CNO-create"
	req.RiskClauseType = 1
	req.ContractClauseNo = "clause-create"
	req.RiskLevel = "P1"
	req.Reviewer = "reviewer@example.com"
	req.ContractClauseDescription = "desc"
	req.ContractClauseAnalysis = "analysis"
}

func fillValidUpdateRiskClauseRoleReq(req *riskclauserole.UpdateRiskClauseRoleReq) {
	req.CurrentOperator = "origin-operator"
	req.RiskRoleID = 12
	req.RiskClauseType = 1
	req.ContractClauseNo = "clause-update"
	req.RiskLevel = "P1"
	req.ContractClauseDescription = "desc"
	req.ContractClauseAnalysis = "analysis"
}

func fillValidAuditRiskClauseRoleReq(req *riskclauserole.AuditRiskClauseRoleReq) {
	req.CurrentOperator = "origin-operator"
	req.ContractNo = "CNO-audit"
	req.RiskRoleID = 15
	req.Limit = 10
	req.Offset = 0
}

func Test_innerRiskClauseRoleHandler_ListRiskClauseRole20210101_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_innerRiskClauseRoleHandler_ListRiskClauseRole20210101", t, func() {
		mockey.PatchConvey("场景：参数绑定失败，返回参数解析错误", func() {
			h := &innerRiskClauseRoleHandler{
				service: &Mock_Service_ListRiskClauseRole20210101{},
			}
			rc := &middleware_hertz_pkg_app.RequestContext{}
			ctx := context.Background()

			// 模拟绑定参数失败
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 断言错误响应为参数解析错误
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c context.Context, rctx *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ListRiskClauseRole20210101(ctx, rc)
		})

		mockey.PatchConvey("场景：绑定成功且从上下文覆盖操作人，服务返回错误", func() {
			h := &innerRiskClauseRoleHandler{
				service: &Mock_Service_ListRiskClauseRole20210101{},
			}
			rc := &middleware_hertz_pkg_app.RequestContext{}
			ctx := context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com")

			// 记录传入到Service的操作人
			var capturedOperator string

			// 模拟绑定成功并填充请求
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(rctx *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.ListRiskClauseRoleReq)
				req.CurrentOperator = "origin-operator"
				req.ContractNo = "CNO123"
				req.RiskClauseType = 1
				req.Limit = 10
				req.Offset = 0
				return nil
			}).Build()

			// 模拟Service返回错误，并验证操作人已被上下文覆盖
			mockey.Mock((*Mock_Service_ListRiskClauseRole20210101).List).To(func(c context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
				capturedOperator = req.CurrentOperator
				return nil, errors.New("svc error")
			}).Build()

			// 拦截错误响应，验证为ErrCommon.WithArgs，并校验args内容
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(c context.Context, rctx *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(capturedOperator, convey.ShouldEqual, "employee@test.com")
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(len(err.GetArgs()) > 0, convey.ShouldBeTrue)
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "svc error")
			}).Build()

			h.ListRiskClauseRole20210101(ctx, rc)
		})

		mockey.PatchConvey("场景：绑定成功且无上下文覆盖，服务返回成功响应", func() {
			h := &innerRiskClauseRoleHandler{
				service: &Mock_Service_ListRiskClauseRole20210101{},
			}
			rc := &middleware_hertz_pkg_app.RequestContext{}
			ctx := context.Background()

			// 记录传入到Service的操作人
			var capturedOperator string

			// 模拟绑定成功并填充请求
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(rctx *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.ListRiskClauseRoleReq)
				req.CurrentOperator = "keep-operator"
				req.ContractNo = "CNO456"
				req.RiskClauseType = 2
				req.Limit = 20
				req.Offset = 5
				return nil
			}).Build()

			// 准备服务返回数据，并校验操作人未被覆盖
			resp := &riskclauserole.ListRiskClauseRoleResp{
				Total:  3,
				Limit:  20,
				Offset: 5,
			}
			mockey.Mock((*Mock_Service_ListRiskClauseRole20210101).List).To(func(c context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
				capturedOperator = req.CurrentOperator
				return resp, nil
			}).Build()

			// 断言DoResponse被调用且返回值正确
			mockey.MockUnsafe(vhertz.DoResponse).To(func(c context.Context, rctx *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(capturedOperator, convey.ShouldEqual, "keep-operator")
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListRiskClauseRole20210101(ctx, rc)
		})
	})
}

func Test_innerRiskClauseRoleHandler_ListRiskClauseRole20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			called := false
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				called = true
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.ListRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})

			convey.So(called, convey.ShouldBeTrue)
		})
	})

	t.Run("service失败返回通用错误并透传ctx操作人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			called := false
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{listFn: func(ctx context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				called = true
				return nil, errors.New("list failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.ListRiskClauseRoleReq)
				req.CurrentOperator = "origin-operator"
				req.ContractNo = "CNO-list"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "list failed")
			}).Build()

			h.ListRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})

			convey.So(called, convey.ShouldBeTrue)
		})
	})

	t.Run("service成功返回列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &riskclauserole.ListRiskClauseRoleResp{Total: 1, Limit: 10}
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{listFn: func(ctx context.Context, req *riskclauserole.ListRiskClauseRoleReq) (*riskclauserole.ListRiskClauseRoleResp, error) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "origin-operator")
				return resp, nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.ListRiskClauseRoleReq)
				req.CurrentOperator = "origin-operator"
				req.ContractNo = "CNO-list"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_CreateRiskClauseRole20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.CreateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("参数校验失败不调用service", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{createFn: func(context.Context, *riskclauserole.CreateRiskClauseRoleReq) error {
				panic("service should not be called")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.CreateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{createFn: func(ctx context.Context, req *riskclauserole.CreateRiskClauseRoleReq) error {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				return errors.New("create failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidCreateRiskClauseRoleReq(obj.(*riskclauserole.CreateRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "create failed")
			}).Build()

			h.CreateRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{createFn: func(ctx context.Context, req *riskclauserole.CreateRiskClauseRoleReq) error {
				convey.So(req.ContractNo, convey.ShouldEqual, "CNO-create")
				return nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidCreateRiskClauseRoleReq(obj.(*riskclauserole.CreateRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.CreateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_UpdateRiskClauseRole20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.UpdateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("参数校验失败返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ID")
			}).Build()

			h.UpdateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{updateFn: func(ctx context.Context, req *riskclauserole.UpdateRiskClauseRoleReq) error {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				return errors.New("update failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidUpdateRiskClauseRoleReq(obj.(*riskclauserole.UpdateRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "update failed")
			}).Build()

			h.UpdateRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{updateFn: func(ctx context.Context, req *riskclauserole.UpdateRiskClauseRoleReq) error {
				convey.So(req.RiskRoleID, convey.ShouldEqual, 12)
				return nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidUpdateRiskClauseRoleReq(obj.(*riskclauserole.UpdateRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "success")
			}).Build()

			h.UpdateRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_DeleteRiskClauseRole20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.DeleteRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("参数校验失败返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.DeleteRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{deleteFn: func(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				return errors.New("delete failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidAuditRiskClauseRoleReq(obj.(*riskclauserole.AuditRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "delete failed")
			}).Build()

			h.DeleteRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{deleteFn: func(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
				convey.So(req.RiskRoleID, convey.ShouldEqual, 15)
				return nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidAuditRiskClauseRoleReq(obj.(*riskclauserole.AuditRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.DeleteRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_CloseRiskClauseRole20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.CloseRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("参数校验失败返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.CloseRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{closeFn: func(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				return errors.New("close failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidAuditRiskClauseRoleReq(obj.(*riskclauserole.AuditRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "close failed")
			}).Build()

			h.CloseRiskClauseRole20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{closeFn: func(ctx context.Context, req *riskclauserole.AuditRiskClauseRoleReq) error {
				convey.So(req.RiskRoleID, convey.ShouldEqual, 15)
				return nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				fillValidAuditRiskClauseRoleReq(obj.(*riskclauserole.AuditRiskClauseRoleReq))
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldBeNil)
			}).Build()

			h.CloseRiskClauseRole20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_Submit20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(errors.New("bind error")).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrParamParseFail.GetCode())
			}).Build()

			h.Submit20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("参数校验失败返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).Return(nil).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ContractNo")
			}).Build()

			h.Submit20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{submitFn: func(ctx context.Context, req *riskclauserole.SubmitApprovalReq) (string, error) {
				convey.So(req.CurrentOperator, convey.ShouldEqual, "employee@test.com")
				return "", errors.New("submit failed")
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.SubmitApprovalReq)
				req.CurrentOperator = "origin-operator"
				req.ContractNo = "CNO-submit"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "submit failed")
			}).Build()

			h.Submit20210101(context.WithValue(context.Background(), _const.CtxEmployeeEmail, "employee@test.com"), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回审批ID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{submitFn: func(ctx context.Context, req *riskclauserole.SubmitApprovalReq) (string, error) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CNO-submit")
				return "approve-1", nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.SubmitApprovalReq)
				req.CurrentOperator = "origin-operator"
				req.ContractNo = "CNO-submit"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "approve-1")
			}).Build()

			h.Submit20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_SubmitRiskApproval20210101(t *testing.T) {
	t.Run("复用Submit接口成功返回审批ID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{submitFn: func(ctx context.Context, req *riskclauserole.SubmitApprovalReq) (string, error) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CNO-submit-risk")
				return "approve-risk", nil
			}}}
			mockey.MockUnsafe(hertz_ext_v2_binding.BindAndValidate).To(func(c *middleware_hertz_pkg_app.RequestContext, obj interface{}) error {
				req := obj.(*riskclauserole.SubmitApprovalReq)
				req.ContractNo = "CNO-submit-risk"
				return nil
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "approve-risk")
			}).Build()

			h.SubmitRiskApproval20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

func Test_innerRiskClauseRoleHandler_GetApproveViewUrl20210101(t *testing.T) {
	t.Run("ApproveId为空返回缺参", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{}}
			mockey.Mock((*middleware_hertz_pkg_app.RequestContext).Query).Return("").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "ApproveId")
			}).Build()

			h.GetApproveViewUrl20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{getApproveViewUrlFn: func(ctx context.Context, approveId string) (string, error) {
				convey.So(approveId, convey.ShouldEqual, "approve-1")
				return "", errors.New("url failed")
			}}}
			mockey.Mock((*middleware_hertz_pkg_app.RequestContext).Query).Return("approve-1").Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, pkg_errors.ErrCommon.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "url failed")
			}).Build()

			h.GetApproveViewUrl20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})

	t.Run("service成功返回审批链接", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerRiskClauseRoleHandler{service: &fakeInnerRiskClauseRoleService{getApproveViewUrlFn: func(ctx context.Context, approveId string) (string, error) {
				convey.So(approveId, convey.ShouldEqual, "approve-2")
				return "https://approve.example.com", nil
			}}}
			mockey.Mock((*middleware_hertz_pkg_app.RequestContext).Query).Return("approve-2").Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *middleware_hertz_pkg_app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "https://approve.example.com")
			}).Build()

			h.GetApproveViewUrl20210101(context.Background(), &middleware_hertz_pkg_app.RequestContext{})
		})
	})
}

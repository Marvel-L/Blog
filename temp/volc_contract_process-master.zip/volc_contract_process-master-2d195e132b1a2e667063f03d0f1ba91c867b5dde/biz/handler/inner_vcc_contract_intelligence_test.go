package handler

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/contractintelligence"
	"volc_contract_process/pkg/errors"
	stderrors "errors"
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
)

type contractIntelligenceRespRecorder struct {
	errorCalled bool
	err         vhertz.APIError
	doCalled    bool
	body        interface{}
}

type contractIntelligenceServiceStub struct {
	submitFunc           func(ctx context.Context, req *bizmodels.SubmitContractIntelligenceFeedbackReq) error
	getAIAuditReportFunc func(ctx context.Context, req *bizmodels.GetAIAuditReportReq) (*bizmodels.GetAIAuditReportResp, error)
}

func (s *contractIntelligenceServiceStub) Submit(ctx context.Context, req *bizmodels.SubmitContractIntelligenceFeedbackReq) error {
	if s.submitFunc != nil {
		return s.submitFunc(ctx, req)
	}
	return nil
}

func (s *contractIntelligenceServiceStub) GetAIAuditReport(ctx context.Context, req *bizmodels.GetAIAuditReportReq) (*bizmodels.GetAIAuditReportResp, error) {
	if s.getAIAuditReportFunc != nil {
		return s.getAIAuditReportFunc(ctx, req)
	}
	return nil, nil
}

func mockContractIntelligenceResp() *contractIntelligenceRespRecorder {
	rec := &contractIntelligenceRespRecorder{}
	mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
		rec.errorCalled = true
		rec.err = err
	}).Build()
	mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, body interface{}) {
		rec.doCalled = true
		rec.body = body
	}).Build()
	return rec
}

func TestNewInnerVCCContractIntelligenceHandler(t *testing.T) {
	mockey.PatchConvey("创建合同智能 handler", t, func() {
		handler := NewInnerVCCContractIntelligenceHandler()
		convey.So(handler, convey.ShouldNotBeNil)
		convey.So(handler, convey.ShouldHaveSameTypeAs, &innerVCCContractIntelligenceHandler{})
	})
}


func TestInnerVCCContractIntelligenceHandlerSubmitAIAuditFeedback20210101(t *testing.T) {
	t.Run("绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind failed")).Build()

			handler := &innerVCCContractIntelligenceHandler{}
			handler.SubmitAIAuditFeedback20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("校验失败返回业务校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.SubmitContractIntelligenceFeedbackReq)
				req.CurrentOperator = "tester@example.com"
				return nil
			}).Build()

			handler := &innerVCCContractIntelligenceHandler{}
			handler.SubmitAIAuditFeedback20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("service 失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.SubmitContractIntelligenceFeedbackReq)
				*req = bizmodels.SubmitContractIntelligenceFeedbackReq{
					CurrentOperator:    "tester@example.com",
					ContractNo:         "CN001",
					ContractName:       "智能合同",
					InOutType:          "In",
					ContractSubmitTime: "2026-09-21 00:00:00",
					FeedbackItems: []*bizmodels.FeedbackItemReq{
						{FeedbackContent: "建议补充付款条款", AttachmentID: "att-1"},
					},
				}
				return nil
			}).Build()

			serviceErr := stderrors.New("submit failed")
			handler := &innerVCCContractIntelligenceHandler{
				service: &contractIntelligenceServiceStub{
					submitFunc: func(ctx context.Context, req *bizmodels.SubmitContractIntelligenceFeedbackReq) error {
						convey.So(req.ContractNo, convey.ShouldEqual, "CN001")
						convey.So(req.FeedbackItems, convey.ShouldHaveLength, 1)
						return serviceErr
					},
				},
			}

			handler.SubmitAIAuditFeedback20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrCommon.GetCode())
			convey.So(rec.err.Error(), convey.ShouldContainSubstring, serviceErr.Error())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时返回空响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.SubmitContractIntelligenceFeedbackReq)
				*req = bizmodels.SubmitContractIntelligenceFeedbackReq{
					CurrentOperator:    "tester@example.com",
					ContractNo:         "CN002",
					ContractName:       "智能合同二",
					InOutType:          "Out",
					ContractSubmitTime: "2026-09-21 00:00:00",
					FeedbackItems: []*bizmodels.FeedbackItemReq{
						{FeedbackContent: "建议补充生效条件", AttachmentID: "att-2"},
					},
				}
				return nil
			}).Build()

			handler := &innerVCCContractIntelligenceHandler{
				service: &contractIntelligenceServiceStub{
					submitFunc: func(ctx context.Context, req *bizmodels.SubmitContractIntelligenceFeedbackReq) error {
						convey.So(req.ContractName, convey.ShouldEqual, "智能合同二")
						convey.So(req.InOutType, convey.ShouldEqual, "Out")
						return nil
					},
				},
			}

			handler.SubmitAIAuditFeedback20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldBeNil)
		})
	})
}


func TestInnerVCCContractIntelligenceHandlerGetAIAuditReport20210101(t *testing.T) {
	t.Run("绑定失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).Return(stderrors.New("bind failed")).Build()

			handler := &innerVCCContractIntelligenceHandler{}
			handler.GetAIAuditReport20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("校验失败返回业务校验错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.GetAIAuditReportReq)
				req.CurrentOperator = "tester@example.com"
				return nil
			}).Build()

			handler := &innerVCCContractIntelligenceHandler{}
			handler.GetAIAuditReport20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("service 失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.GetAIAuditReportReq)
				req.CurrentOperator = "tester@example.com"
				req.ContractNo = "CN003"
				return nil
			}).Build()

			serviceErr := stderrors.New("query report failed")
			handler := &innerVCCContractIntelligenceHandler{
				service: &contractIntelligenceServiceStub{
					getAIAuditReportFunc: func(ctx context.Context, req *bizmodels.GetAIAuditReportReq) (*bizmodels.GetAIAuditReportResp, error) {
						convey.So(req.ContractNo, convey.ShouldEqual, "CN003")
						return nil, serviceErr
					},
				},
			}

			handler.GetAIAuditReport20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeTrue)
			convey.So(rec.err.GetCode(), convey.ShouldEqual, errors.ErrCommon.GetCode())
			convey.So(rec.err.Error(), convey.ShouldContainSubstring, serviceErr.Error())
			convey.So(rec.doCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("成功时返回审核报告", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			rec := mockContractIntelligenceResp()
			mockey.MockUnsafe(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*bizmodels.GetAIAuditReportReq)
				req.CurrentOperator = "tester@example.com"
				req.ContractNo = "CN004"
				return nil
			}).Build()

			expectedResp := &bizmodels.GetAIAuditReportResp{
				ContractNo:     "CN004",
				Visible:        true,
				AuditTaskState: "done",
				ReportURL:      "https://report.example.com/CN004",
			}
			handler := &innerVCCContractIntelligenceHandler{
				service: &contractIntelligenceServiceStub{
					getAIAuditReportFunc: func(ctx context.Context, req *bizmodels.GetAIAuditReportReq) (*bizmodels.GetAIAuditReportResp, error) {
						convey.So(req.CurrentOperator, convey.ShouldEqual, "tester@example.com")
						return expectedResp, nil
					},
				},
			}

			handler.GetAIAuditReport20210101(context.Background(), &app.RequestContext{})

			convey.So(rec.errorCalled, convey.ShouldBeFalse)
			convey.So(rec.doCalled, convey.ShouldBeTrue)
			convey.So(rec.body, convey.ShouldResemble, expectedResp)
		})
	})
}


var _ contractintelligence.Service = (*contractIntelligenceServiceStub)(nil)



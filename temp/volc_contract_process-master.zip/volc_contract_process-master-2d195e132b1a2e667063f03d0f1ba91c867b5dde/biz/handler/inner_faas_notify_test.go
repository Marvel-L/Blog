package handler

import (
	"context"
	"errors"
	"net/http"
	"reflect"
	"testing"
	"time"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	hertz_ext_binding "code.byted.org/middleware/hertz_ext/v2/binding"
	v2_logs "code.byted.org/volcengine/volc-bypass-golang/v2/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	faasmodel "volc_contract_process/biz/bizmodels/faas"
	"volc_contract_process/biz/service/notify"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/cronjob"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

func Test_innerFaaSNotifyHandler_FreshSealApprovalUnmailedDailyReminder20210101(t *testing.T) {
	t.Run("触发鲜章未邮寄提醒", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()

			h.FreshSealApprovalUnmailedDailyReminder20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventFreshSealApprovalUnmailedDailyReminder)
			convey.So(capturedMsgCtx, convey.ShouldNotBeNil)
		})
	})
}

func Test_innerFaaSNotifyHandler_SendLongTimeNotArchivedNotify20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.SendLongTimeNotArchivedNotify20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送长时间未归档通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN001,CN002"
				p.CreatorID = 1001
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]string{"message": "success"})
			}).Build()

			h.SendLongTimeNotArchivedNotify20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventContractLongTimeNotArchived)
			convey.So(capturedMsgCtx, convey.ShouldNotBeNil)
			convey.So(capturedMsgCtx.CreatorID, convey.ShouldEqual, int64(1001))
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtLongTimeNotArchived)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN001,CN002")
		})
	})
}

func Test_innerFaaSNotifyHandler_SendLongTimeNotApprovalNotify20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.SendLongTimeNotApprovalNotify20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送长时间未审批通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN003,CN004"
				p.CreatorID = 1002
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]string{"message": "success"})
			}).Build()

			h.SendLongTimeNotApprovalNotify20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventContractLongTimeNotApproval)
			convey.So(capturedMsgCtx.CreatorID, convey.ShouldEqual, int64(1002))
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtLongTimeNotArchived)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN003,CN004")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractReviewSummaryRemind20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.ContractReviewSummaryRemind20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送合同审核汇总提醒", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN005"
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]interface{}{"message": "success"})
			}).Build()

			h.ContractReviewSummaryRemind20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventContractReviewSummaryRemind)
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtContractReviewSummaryRemind)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN005")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractReviewFullProcessRemind20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.ContractReviewFullProcessRemind20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送合同全流程待审核提醒", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN006"
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]interface{}{"message": "success"})
			}).Build()

			h.ContractReviewFullProcessRemind20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventContractReviewFullProcessRemind)
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtContractReviewSummaryRemind)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN006")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractSalesOpExpireRemind20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.ContractSalesOpExpireRemind20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送销售合同到期提醒", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN007"
				p.PDate = "2026-03-10"
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]interface{}{"message": "success"})
			}).Build()

			h.ContractSalesOpExpireRemind20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventSalesOpExpireRemind)
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtExpireRemind)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN007")
			convey.So(ext.PDate.Format(util.DateFormatTpl), convey.ShouldEqual, "2026-03-10")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractCustomerExpireRemind20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				t.Fatal("bind失败时不应发送通知")
			}).Build()
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errorsV2.ErrParamParseFail.GetCode())
			}).Build()

			h.ContractCustomerExpireRemind20210101(context.Background(), c)
		})
	})

	t.Run("bind成功发送客户合同到期提醒", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				p := obj.(*faasmodel.NotifyParam)
				p.ContractNos = "CN008"
				p.PDate = "2026-03-11"
				return nil
			}).Build()
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, rc *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldResemble, map[string]interface{}{"message": "success"})
			}).Build()

			h.ContractCustomerExpireRemind20210101(context.Background(), c)

			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventCustomerExpireRemind)
			ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtExpireRemind)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(ext.ContractNoList, convey.ShouldEqual, "CN008")
			convey.So(ext.PDate.Format(util.DateFormatTpl), convey.ShouldEqual, "2026-03-11")
		})
	})
}

func Test_innerFaaSNotifyHandler_FreshSealApprovalUnmailedDailyReminder20210101_BitsUTGen(t *testing.T) {
	t.Run("Keys为空，正常触发通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩外部依赖，避免真实发送以及日志输出
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(notify.SendMsgV2).Return().Build()

			// 构造上下文为空Keys的请求
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// 调用目标方法
			h.FreshSealApprovalUnmailedDailyReminder20210101(context.Background(), c)

			// 断言流程执行完毕
			convey.So(true, convey.ShouldBeTrue)
		})
	})

	t.Run("Keys包含普通键，正常触发通知", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 打桩外部依赖
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(notify.SendMsgV2).Return().Build()

			// 构造包含普通键的请求，覆盖RPCContext中Keys不为空的路径
			c := &app.RequestContext{
				Keys: map[string]interface{}{
					"foo": "bar",
				},
			}
			h := &innerFaaSNotifyHandler{}

			// 调用目标方法
			h.FreshSealApprovalUnmailedDailyReminder20210101(context.Background(), c)

			// 断言流程执行完毕
			convey.So(true, convey.ShouldBeTrue)
		})
	})
}

func Test_innerFaaSNotifyHandler_SendLongTimeNotApprovalNotify20210101_BitsUTGen(t *testing.T) {
	t.Run("参数解析失败返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与处理器
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// 记录函数调用标记
			errorRespCalled := false
			doResponseCalled := false
			sendMsgCalled := false

			// 打桩日志函数，避免实际打印
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 打桩参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 打桩错误响应
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			// 打桩消息发送，不应被调用
			mockey.Mock(notify.SendMsgV2).To(func(_ context.Context, _ int, _ *notify.MsgContext) {
				sendMsgCalled = true
			}).Build()

			// 打桩正常响应，不应被调用
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doResponseCalled = true
			}).Build()

			// 调用待测方法
			h.SendLongTimeNotApprovalNotify20210101(context.Background(), c)

			// 断言分支行为
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(sendMsgCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("参数解析成功发送消息并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与处理器
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// 记录函数调用及入参透传
			errorRespCalled := false
			doResponseCalled := false
			sendMsgCalled := false
			capturedNos := ""

			// 打桩日志函数，避免实际打印
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 打桩参数绑定成功，同时设置请求数据
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				// 通过反射写入匿名结构体字段
				v := reflect.ValueOf(obj)
				if v.Kind() == reflect.Ptr {
					v = v.Elem()
				}
				f := v.FieldByName("ContractNos")
				if f.IsValid() && f.CanSet() {
					f.SetString("abc,def")
				}
				return nil
			}).Build()

			// 打桩错误响应，不应被调用
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, _ vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			// 打桩消息发送，校验扩展字段与事件ID
			mockey.Mock(notify.SendMsgV2).To(func(_ context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
				if msgCtx != nil {
					if ext, ok := msgCtx.ExtInfo.(notify.MsgContextExtLongTimeNotArchived); ok {
						capturedNos = ext.ContractNoList
					}
				}
				convey.So(event, convey.ShouldEqual, notify.MsgEventContractLongTimeNotApproval)
			}).Build()

			// 打桩正常响应
			mockey.MockUnsafe(vhertz.DoResponse).To(func(_ *app.RequestContext, _ interface{}) {
				doResponseCalled = true
			}).Build()

			// 调用待测方法
			h.SendLongTimeNotApprovalNotify20210101(context.Background(), c)

			// 断言分支行为与参数透传
			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(sendMsgCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedNos, convey.ShouldEqual, "abc,def")
		})
	})
}

func Test_innerFaaSNotifyHandler_SendLongTimeNotArchivedNotify20210101_BitsUTGen(t *testing.T) {
	t.Run("绑定失败返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求上下文
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// mock日志打印，避免外部依赖
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// mock参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind fail")).Build()

			// 记录是否进入错误响应分支
			errorRespCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, e vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			// 记录是否误调用成功分支及消息发送
			doResponseCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()
			notifyCalled := false
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				notifyCalled = true
			}).Build()

			// 调用待测方法
			h.SendLongTimeNotArchivedNotify20210101(context.Background(), c)

			// 断言只调用错误响应
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(notifyCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("绑定成功发送消息并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造请求上下文
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// mock日志打印，避免外部依赖
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// mock参数绑定成功并填充入参
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				// 通过反射设置匿名入参结构体的ContractNos字段
				v := reflect.ValueOf(obj)
				if v.Kind() == reflect.Ptr && v.Elem().Kind() == reflect.Struct {
					field := v.Elem().FieldByName("ContractNos")
					if field.IsValid() && field.CanSet() && field.Kind() == reflect.String {
						field.SetString("NO123,NO456")
					}
				}
				return nil
			}).Build()

			// 记录成功响应与消息发送内容
			successCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				successCalled = true
			}).Build()

			errorRespCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, e vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			sentEvent := 0
			extList := ""
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sentEvent = event
				if msgCtx != nil && msgCtx.ExtInfo != nil {
					if ext, ok := msgCtx.ExtInfo.(notify.MsgContextExtLongTimeNotArchived); ok {
						extList = ext.ContractNoList
					}
				}
			}).Build()

			// 调用待测方法
			h.SendLongTimeNotArchivedNotify20210101(context.Background(), c)

			// 断言成功流程
			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(successCalled, convey.ShouldBeTrue)
			convey.So(sentEvent, convey.ShouldEqual, notify.MsgEventContractLongTimeNotArchived)
			convey.So(extList, convey.ShouldEqual, "NO123,NO456")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractReviewFullProcessRemind20210101_BitsUTGen(t *testing.T) {
	t.Run("参数校验失败返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟日志函数，避免实际输出
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 模拟参数绑定校验失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 记录错误响应调用
			errorRespCalled := 0
			gotHttpStatus := 0
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, api vhertz.APIError) {
				errorRespCalled++
				if api != nil {
					gotHttpStatus = api.HttpStatus()
				}
			}).Build()

			// 这些在参数失败分支不应被调用
			sendCalled := 0
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendCalled++
			}).Build()
			doRespCalled := 0
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled++
			}).Build()

			h := &innerFaaSNotifyHandler{}
			rc := &app.RequestContext{}

			h.ContractReviewFullProcessRemind20210101(context.Background(), rc)

			// 断言：错误响应被调用，成功响应和发送消息未调用
			convey.So(errorRespCalled, convey.ShouldEqual, 1)
			convey.So(gotHttpStatus, convey.ShouldEqual, http.StatusBadRequest)
			convey.So(sendCalled, convey.ShouldEqual, 0)
			convey.So(doRespCalled, convey.ShouldEqual, 0)
		})
	})

	t.Run("校验成功发送消息并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟日志函数
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 模拟参数绑定校验成功，并填充参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*faasmodel.NotifyParam); ok && p != nil {
					p.ContractNos = "NO-001,NO-002"
					p.CreatorID = 12345
				}
				return nil
			}).Build()

			// 捕获发送消息事件与上下文
			sendCalled := 0
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendCalled++
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()

			// 捕获成功响应
			doRespCalled := 0
			var respResult interface{}
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled++
				respResult = result
			}).Build()

			// 错误响应不应被调用
			errorRespCalled := 0
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, api vhertz.APIError) {
				errorRespCalled++
			}).Build()

			h := &innerFaaSNotifyHandler{}
			rc := &app.RequestContext{}

			h.ContractReviewFullProcessRemind20210101(context.Background(), rc)

			// 断言：消息发送与成功响应被调用，错误响应未调用
			convey.So(sendCalled, convey.ShouldEqual, 1)
			convey.So(doRespCalled, convey.ShouldEqual, 1)
			convey.So(errorRespCalled, convey.ShouldEqual, 0)

			// 断言事件类型与消息扩展信息
			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventContractReviewFullProcessRemind)
			convey.So(capturedMsgCtx, convey.ShouldNotBeNil)
			if capturedMsgCtx != nil {
				if ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtContractReviewSummaryRemind); ok {
					convey.So(ext.ContractNoList, convey.ShouldEqual, "NO-001,NO-002")
				} else {
					convey.So(ok, convey.ShouldBeTrue)
				}
			}

			// 断言返回内容命中“success”字样
			if m, ok := respResult.(map[string]interface{}); ok {
				convey.So(m["message"], convey.ShouldEqual, "success")
			} else {
				convey.So(ok, convey.ShouldBeTrue)
			}
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractReviewSummaryRemind20210101_BitsUTGen(t *testing.T) {
	t.Run("参数解析失败时应返回错误响应并中断", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 标记变量
			errorRespCalled := false
			errorRespCode := ""
			sendMsgCalled := false
			doRespCalled := false

			// 构造请求上下文
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// Mock日志函数（无返回值）
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// Mock参数绑定失败
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// Mock发送消息，校验不会执行
			mockey.Mock(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
			}).Build()

			// Mock错误响应
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
				errorRespCode = err.GetCode()
			}).Build()

			// Mock成功响应，校验不会执行
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			// 执行目标方法
			h.ContractReviewSummaryRemind20210101(context.Background(), c)

			// 断言分支行为
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(errorRespCode, convey.ShouldEqual, "ParamParseFail")
			convey.So(sendMsgCalled, convey.ShouldBeFalse)
			convey.So(doRespCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("参数解析成功时应发送提醒并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 标记变量
			sendMsgCalled := false
			eventOK := false
			extOK := false
			doRespCalled := false
			respMsg := ""

			// 构造请求上下文
			c := &app.RequestContext{}
			h := &innerFaaSNotifyHandler{}

			// Mock日志函数（无返回值）
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// Mock参数绑定成功并写入参数
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(rc *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*faasmodel.NotifyParam); ok {
					p.ContractNos = "C001,C002"
					p.CreatorID = 123
				}
				return nil
			}).Build()

			// Mock发送消息，校验事件与扩展信息
			mockey.Mock(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
				if event == notify.MsgEventContractReviewSummaryRemind {
					eventOK = true
				}
				if ext, ok := msgCtx.ExtInfo.(notify.MsgContextExtContractReviewSummaryRemind); ok {
					extOK = (ext.ContractNoList == "C001,C002")
				}
			}).Build()

			// Mock成功响应，校验返回内容
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doRespCalled = true
				if m, ok := result.(map[string]interface{}); ok {
					if v, ok2 := m["message"]; ok2 {
						if s, ok3 := v.(string); ok3 {
							respMsg = s
						}
					}
				}
			}).Build()

			// 执行目标方法
			h.ContractReviewSummaryRemind20210101(context.Background(), c)

			// 断言分支行为
			convey.So(sendMsgCalled, convey.ShouldBeTrue)
			convey.So(eventOK, convey.ShouldBeTrue)
			convey.So(extOK, convey.ShouldBeTrue)
			convey.So(doRespCalled, convey.ShouldBeTrue)
			convey.So(respMsg, convey.ShouldEqual, "success")
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractSalesOpExpireRemind20210101_BitsUTGen(t *testing.T) {
	t.Run("参数解析失败，返回错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造被测对象与上下文
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}

			// 打桩日志相关函数，避免副作用
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// BindAndValidate返回错误，触发错误分支
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				return errors.New("bind error")
			}).Build()

			// 记录ErrorResp是否被调用
			errorRespCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			// 记录DoResponse是否被调用（错误分支不应调用）
			doResponseCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()

			// 记录SendMsgV2是否被调用（错误分支不应调用）
			sendMsgCalled := false
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
			}).Build()

			// 执行被测方法
			h.ContractSalesOpExpireRemind20210101(context.Background(), c)

			// 断言分支效果
			convey.So(errorRespCalled, convey.ShouldBeTrue)
			convey.So(doResponseCalled, convey.ShouldBeFalse)
			convey.So(sendMsgCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("参数解析成功，发送提醒并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造被测对象与上下文
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}

			// 打桩日志相关函数，避免副作用
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// BindAndValidate返回成功，并填充参数
			testPDate := "2026-03-10"
			testContractNos := "NO001,NO002"
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).To(func(ctx *app.RequestContext, obj interface{}) error {
				if p, ok := obj.(*faasmodel.NotifyParam); ok {
					p.PDate = testPDate
					p.ContractNos = testContractNos
				}
				return nil
			}).Build()

			// 记录ErrorResp是否被调用（成功分支不应调用）
			errorRespCalled := false
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, rc *app.RequestContext, err vhertz.APIError) {
				errorRespCalled = true
			}).Build()

			// 记录DoResponse是否被调用（成功分支应调用）
			doResponseCalled := false
			mockey.MockUnsafe(vhertz.DoResponse).To(func(rc *app.RequestContext, result interface{}) {
				doResponseCalled = true
			}).Build()

			// 捕获SendMsgV2的入参，验证ExtInfo内容
			var capturedEvent int
			var capturedMsgCtx *notify.MsgContext
			mockey.MockUnsafe(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				capturedEvent = event
				capturedMsgCtx = msgCtx
			}).Build()

			// 执行被测方法
			h.ContractSalesOpExpireRemind20210101(context.Background(), c)

			// 断言成功分支效果
			convey.So(errorRespCalled, convey.ShouldBeFalse)
			convey.So(doResponseCalled, convey.ShouldBeTrue)
			convey.So(capturedMsgCtx, convey.ShouldNotBeNil)
			convey.So(capturedEvent, convey.ShouldEqual, notify.MsgEventSalesOpExpireRemind)

			// 验证ExtInfo内容
			parsedDate, _ := time.ParseInLocation(util.DateFormatTpl, testPDate, time.Local)
			if capturedMsgCtx != nil {
				if ext, ok := capturedMsgCtx.ExtInfo.(notify.MsgContextExtExpireRemind); ok {
					convey.So(ext.ContractNoList, convey.ShouldEqual, testContractNos)
					convey.So(ext.PDate.Equal(parsedDate), convey.ShouldBeTrue)
				} else {
					convey.So(ok, convey.ShouldBeTrue) // 类型断言必须成功
				}
			}
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractCustomerExpireRemind20210101_BitsUTGen(t *testing.T) {
	t.Run("参数解析失败时返回错误响应并终止", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 标记位用于校验分支行为
			errRespCalled := false
			doRespCalled := false
			sendMsgCalled := false

			// 日志相关函数打桩为无副作用
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 参数绑定返回错误，触发错误响应分支
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			// 错误响应打桩，记录调用
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errRespCalled = true
			}).Build()

			// 成功响应打桩，记录调用（该场景不应触发）
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			// 发送消息打桩，记录调用（该场景不应触发）
			mockey.Mock(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
			}).Build()

			// 构造请求上下文与handler
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}

			// 调用目标方法
			h.ContractCustomerExpireRemind20210101(context.Background(), c)

			// 断言分支行为
			convey.So(errRespCalled, convey.ShouldBeTrue)
			convey.So(doRespCalled, convey.ShouldBeFalse)
			convey.So(sendMsgCalled, convey.ShouldBeFalse)
		})
	})

	t.Run("参数解析成功时发送消息并返回成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 标记位用于校验分支行为
			errRespCalled := false
			doRespCalled := false
			sendMsgCalled := false

			// 日志相关函数打桩为无副作用
			mockey.MockUnsafe(v2_logs.CtxInfo).Return().Build()
			mockey.MockUnsafe(v2_logs.CtxError).Return().Build()

			// 参数绑定成功
			mockey.MockUnsafe(hertz_ext_binding.BindAndValidate).Return(nil).Build()

			// 错误响应打桩（该场景不应触发）
			mockey.MockUnsafe(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) {
				errRespCalled = true
			}).Build()

			// 成功响应打桩，记录调用
			mockey.MockUnsafe(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) {
				doRespCalled = true
			}).Build()

			// 发送消息打桩，记录调用
			mockey.Mock(notify.SendMsgV2).To(func(ctx context.Context, event int, msgCtx *notify.MsgContext) {
				sendMsgCalled = true
			}).Build()

			// 构造请求上下文与handler
			h := &innerFaaSNotifyHandler{}
			c := &app.RequestContext{}

			// 调用目标方法
			h.ContractCustomerExpireRemind20210101(context.Background(), c)

			// 断言分支行为
			convey.So(errRespCalled, convey.ShouldBeFalse)
			convey.So(sendMsgCalled, convey.ShouldBeTrue)
			convey.So(doRespCalled, convey.ShouldBeTrue)
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractEffectedToExpiredCronJob20210101(t *testing.T) {
	t.Run("case BindAndValidate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			(&innerFaaSNotifyHandler{}).ContractEffectedToExpiredCronJob20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			gotArgsCh := make(chan []string, 1)
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*innerCronJobReq)
				req.LoopcountLimit = 20
				return nil
			}).Build()
			mockey.Mock((*cronjob.CronJob).ContractEffectedToExpiredCronJob).To(func(_ *cronjob.CronJob, args []string) {
				gotArgsCh <- args
			}).Build()

			(&innerFaaSNotifyHandler{}).ContractEffectedToExpiredCronJob20210101(context.Background(), c)

			select {
			case gotArgs := <-gotArgsCh:
				convey.So(gotArgs, convey.ShouldResemble, []string{"", "20"})
			case <-time.After(time.Second):
				t.Fatal("wait ContractEffectedToExpiredCronJob timeout")
			}
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"TaskName":"ContractEffectedToExpiredCronJob"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Message":"success"`)
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractSyncBasicInfo20210101(t *testing.T) {
	t.Run("case BindAndValidate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			(&innerFaaSNotifyHandler{}).ContractSyncBasicInfo20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case success with contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			gotArgsCh := make(chan []string, 1)
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*innerCronJobReq)
				req.ContractNoList = "CT202607100001"
				return nil
			}).Build()
			mockey.Mock((*cronjob.CronJob).ContractSyncBasicInfo).To(func(_ *cronjob.CronJob, args []string) {
				gotArgsCh <- args
			}).Build()

			(&innerFaaSNotifyHandler{}).ContractSyncBasicInfo20210101(context.Background(), c)

			select {
			case gotArgs := <-gotArgsCh:
				convey.So(gotArgs, convey.ShouldResemble, []string{"500", "CT202607100001"})
			case <-time.After(time.Second):
				t.Fatal("wait ContractSyncBasicInfo timeout")
			}
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"TaskName":"ContractSyncBasicInfo"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Message":"success"`)
		})
	})

	t.Run("case success with limit and contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			gotArgsCh := make(chan []string, 1)
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*innerCronJobReq)
				req.LoopcountLimit = 30
				req.ContractNoList = "CT202607100001"
				return nil
			}).Build()
			mockey.Mock((*cronjob.CronJob).ContractSyncBasicInfo).To(func(_ *cronjob.CronJob, args []string) {
				gotArgsCh <- args
			}).Build()

			(&innerFaaSNotifyHandler{}).ContractSyncBasicInfo20210101(context.Background(), c)

			select {
			case gotArgs := <-gotArgsCh:
				convey.So(gotArgs, convey.ShouldResemble, []string{"30", "CT202607100001"})
			case <-time.After(time.Second):
				t.Fatal("wait ContractSyncBasicInfo timeout")
			}
		})
	})
}

func Test_innerFaaSNotifyHandler_ContractFeishuSyncBasicInfo20210101(t *testing.T) {
	t.Run("case BindAndValidate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			(&innerFaaSNotifyHandler{}).ContractFeishuSyncBasicInfo20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case success with limit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			gotArgsCh := make(chan []string, 1)
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*innerCronJobReq)
				req.LoopcountLimit = 40
				return nil
			}).Build()
			mockey.Mock((*cronjob.CronJob).ContractFeishuSyncBasicInfo).To(func(_ *cronjob.CronJob, args []string) {
				gotArgsCh <- args
			}).Build()

			(&innerFaaSNotifyHandler{}).ContractFeishuSyncBasicInfo20210101(context.Background(), c)

			select {
			case gotArgs := <-gotArgsCh:
				convey.So(gotArgs, convey.ShouldResemble, []string{"", "40"})
			case <-time.After(time.Second):
				t.Fatal("wait ContractFeishuSyncBasicInfo timeout")
			}
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"TaskName":"ContractFeishuSyncBasicInfo"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Message":"success"`)
		})
	})

	t.Run("case success with limit and contract no", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			gotArgsCh := make(chan []string, 1)
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*innerCronJobReq)
				req.LoopcountLimit = 50
				req.ContractNoList = "CT202607100001"
				return nil
			}).Build()
			mockey.Mock((*cronjob.CronJob).ContractFeishuSyncBasicInfo).To(func(_ *cronjob.CronJob, args []string) {
				gotArgsCh <- args
			}).Build()

			(&innerFaaSNotifyHandler{}).ContractFeishuSyncBasicInfo20210101(context.Background(), c)

			select {
			case gotArgs := <-gotArgsCh:
				convey.So(gotArgs, convey.ShouldResemble, []string{"CT202607100001", "50"})
			case <-time.After(time.Second):
				t.Fatal("wait ContractFeishuSyncBasicInfo timeout")
			}
		})
	})
}

func Test_innerFaaSNotifyHandler_CompliancePeriodicScreenRemind20210101(t *testing.T) {
	t.Run("case BindAndValidate Fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockey.Mock(hertz_ext_binding.BindAndValidate).Return(errors.New("bind error")).Build()

			(&innerFaaSNotifyHandler{}).CompliancePeriodicScreenRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case invalid UpdateTime", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			svc := riskengineservice.NewRiskEngineService()
			h := &innerFaaSNotifyHandler{riskEngineService: svc}
			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*compliancePeriodicScreenRemindReq)
				req.UpdateTime = "2026081x"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "HandleCompliancePeriodicScreenOrder")).Return(errorsV2.ErrParamParseFail).Build()

			h.CompliancePeriodicScreenRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ParamParseFail"`)
		})
	})

	t.Run("case service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			svc := riskengineservice.NewRiskEngineService()
			h := &innerFaaSNotifyHandler{riskEngineService: svc}

			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*compliancePeriodicScreenRemindReq)
				req.UpdateTime = "20260810"
				req.ContractNoList = "CN123,CN456"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "HandleCompliancePeriodicScreenOrder")).Return(errorsV2.ErrorCommon.WithArgs("service error")).Build()

			h.CompliancePeriodicScreenRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Code":"ErrorCommon"`)
		})
	})

	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			svc := riskengineservice.NewRiskEngineService()
			h := &innerFaaSNotifyHandler{riskEngineService: svc}

			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*compliancePeriodicScreenRemindReq)
				req.UpdateTime = "20260810"
				req.ContractNoList = "CN123,CN456"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "HandleCompliancePeriodicScreenOrder")).To(func(ctx context.Context, req *riskengineservice.CompliancePeriodicScreenOrderReq) errorsV2.APIError {
				convey.So(req.UpdateTime, convey.ShouldEqual, "20260810")
				convey.So(req.ContractNoList, convey.ShouldEqual, "CN123,CN456")
				return nil
			}).Build()

			h.CompliancePeriodicScreenRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"TaskName":"CompliancePeriodicScreenRemind"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"UpdateTime":"20260810"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"ContractNoList":"CN123,CN456"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Message":"success"`)
		})
	})

	t.Run("case success with empty UpdateTime", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			svc := riskengineservice.NewRiskEngineService()
			h := &innerFaaSNotifyHandler{riskEngineService: svc}

			mockey.Mock(hertz_ext_binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*compliancePeriodicScreenRemindReq)
				req.ContractNoList = "CN123"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "HandleCompliancePeriodicScreenOrder")).To(func(ctx context.Context, req *riskengineservice.CompliancePeriodicScreenOrderReq) errorsV2.APIError {
				convey.So(req.UpdateTime, convey.ShouldEqual, "")
				convey.So(req.ContractNoList, convey.ShouldEqual, "CN123")
				return nil
			}).Build()

			h.CompliancePeriodicScreenRemind20210101(context.Background(), c)

			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"TaskName":"CompliancePeriodicScreenRemind"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"ContractNoList":"CN123"`)
			convey.So(string(c.Response.Body()), convey.ShouldContainSubstring, `"Message":"success"`)
		})
	})
}

package handler

import (
	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"context"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/errors"
)

// 火山合同中心——合同附件处理
type innerVCCMetaCommodityHandler struct {
	base
	commodityService metacommodity.Service
}

func NewInnerVCCMetaCommodityHandler() vhertz.ActionHandler {
	return &innerVCCMetaCommodityHandler{
		commodityService: metacommodity.NewService(),
	}
}

// CreateOrUpdateManageInfo20210101 创建&更新合同管理信息
func (h *innerVCCMetaCommodityHandler) CreateOrUpdateManageInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.UpdateManageInfoReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}

	var err = h.commodityService.CreateOrUpdateManageInfo(ctx, req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, req.ContractNo)

}

// ListCommodity20210101 创建&更新合同管理信息
func (h *innerVCCMetaCommodityHandler) List20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.ListCommodityReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "ListCommodityReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}
	// 内部请求默认返回商品行总数
	req.NeedTotal = true

	commodityListResp, err := h.commodityService.ListCommodity(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, commodityListResp)
}

// ListCommodity20210101 用于解决 action 命名冲突，内部复用 List20210101
func (h *innerVCCMetaCommodityHandler) ListCommodity20210101(ctx context.Context, c *app.RequestContext) {
	h.List20210101(ctx, c)
}

// ListCommodity20210101 创建&更新合同管理信息
func (h *innerVCCMetaCommodityHandler) Export20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.ListCommodityReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductParamParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "ListCommodityReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}
	err := h.commodityService.Export(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, "导出成功")
}

// ExportMeta20210101 用于解决 action 命名冲突，内部复用 ExportMeta20210101
func (h *innerVCCMetaCommodityHandler) ExportMeta20210101(ctx context.Context, c *app.RequestContext) {
	h.Export20210101(ctx, c)
}

func (h *innerVCCMetaCommodityHandler) GetManageInfo20210101(ctx context.Context, c *app.RequestContext) {

	var req modelcommodity.GetManageReq
	if err := binding.BindAndValidate(c, &req); err != nil {
		logs.CtxError(ctx, "GetManageInfoParseFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrParamParseFail)
		return
	}
	if err := req.Validate(); err != nil {
		logs.CtxError(ctx, "GetManageReqValidateFail, err: %s", err.Error())
		vhertz.ErrorResp(ctx, c, errors.ErrorCommon.WithArgs(err.Error()))
		return
	}

	commodityListResp, err := h.commodityService.GetManageByNo(ctx, &req)
	if err != nil {
		vhertz.ErrorResp(ctx, c, err)
		return
	}

	vhertz.DoResponse(ctx, c, commodityListResp)
}

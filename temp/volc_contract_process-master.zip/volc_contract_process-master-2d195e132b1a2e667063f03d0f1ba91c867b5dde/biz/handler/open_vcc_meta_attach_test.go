package handler

import (
	"context"
	"fmt"
	"mime/multipart"
	"testing"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type fakeOpenVCCMetaAttachmentService struct {
	metaattach.AttachmentService
	getAttachmentDataInfoFn    func(context.Context, string, string) (*metaattachmodels.AttachmentDataInfo, errors.APIError)
	uploadAttachmentFn         func(context.Context, *metaattachmodels.UploadReq) (*metaattachmodels.UploadResp, errors.APIError)
	getProcessFileInfoFn       func(context.Context, string, string) (*metaattachmodels.GetProcessFileInfoResp, errors.APIError)
	getAttachmentPreviewInfoFn func(context.Context, *bizmodels.GetAttachmentPreviewInfoReq) (*metaattachmodels.GetAttachmentPreviewInfoResp, errors.APIError)
	applyUploadInfoFn          func(context.Context, *metaattachmodels.ApplyUploadInfoReq) (*metaattachmodels.PreSingedPostFormData, errors.APIError)
	initMultipartUploadFn      func(context.Context, *metaattachmodels.InitMultipartUploadReq) (*metaattachmodels.InitMultipartUploadResp, errors.APIError)
	uploadMultipartPartFn      func(context.Context, *metaattachmodels.UploadMultipartPartReq) (*metaattachmodels.UploadMultipartPartResp, errors.APIError)
	completeMultipartUploadFn  func(context.Context, *metaattachmodels.CompleteMultipartUploadReq) (*metaattachmodels.CompleteMultipartUploadResp, errors.APIError)
	abortMultipartUploadFn     func(context.Context, *metaattachmodels.AbortMultipartUploadReq) errors.APIError
}

func (f *fakeOpenVCCMetaAttachmentService) GetAttachmentDataInfo(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
	return f.getAttachmentDataInfoFn(ctx, downloadID, version)
}

func (f *fakeOpenVCCMetaAttachmentService) UploadAttachment(ctx context.Context, req *metaattachmodels.UploadReq) (*metaattachmodels.UploadResp, errors.APIError) {
	return f.uploadAttachmentFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) GetProcessFileInfo(ctx context.Context, contractNo, currentOperator string) (*metaattachmodels.GetProcessFileInfoResp, errors.APIError) {
	return f.getProcessFileInfoFn(ctx, contractNo, currentOperator)
}

func (f *fakeOpenVCCMetaAttachmentService) GetAttachmentPreviewInfo(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*metaattachmodels.GetAttachmentPreviewInfoResp, errors.APIError) {
	return f.getAttachmentPreviewInfoFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) ApplyUploadInfo(ctx context.Context, req *metaattachmodels.ApplyUploadInfoReq) (*metaattachmodels.PreSingedPostFormData, errors.APIError) {
	return f.applyUploadInfoFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) InitMultipartUpload(ctx context.Context, req *metaattachmodels.InitMultipartUploadReq) (*metaattachmodels.InitMultipartUploadResp, errors.APIError) {
	return f.initMultipartUploadFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) UploadMultipartPart(ctx context.Context, req *metaattachmodels.UploadMultipartPartReq) (*metaattachmodels.UploadMultipartPartResp, errors.APIError) {
	return f.uploadMultipartPartFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) CompleteMultipartUpload(ctx context.Context, req *metaattachmodels.CompleteMultipartUploadReq) (*metaattachmodels.CompleteMultipartUploadResp, errors.APIError) {
	return f.completeMultipartUploadFn(ctx, req)
}

func (f *fakeOpenVCCMetaAttachmentService) AbortMultipartUpload(ctx context.Context, req *metaattachmodels.AbortMultipartUploadReq) errors.APIError {
	return f.abortMultipartUploadFn(ctx, req)
}

type fakeOpenVCCMetaAttachmentMetaService struct {
	contractmeta.MetaService
	getViewURLFn func(context.Context, *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError)
}

func (f *fakeOpenVCCMetaAttachmentMetaService) GetViewURL(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
	return f.getViewURLFn(ctx, param)
}

func mockOpenVCCMetaAttachmentQuery(values map[string]string) {
	mockey.Mock((*app.RequestContext).Query).To(func(c *app.RequestContext, key string) string {
		return values[key]
	}).Build()
}

func TestNewOpenVCCMetaAttachmentHandler(t *testing.T) {
	mockey.PatchConvey("constructor initializes services", t, func() {
		h := NewOpenVCCMetaAttachmentHandler()
		convey.So(h, convey.ShouldNotBeNil)
		handler, ok := h.(*openVCCMetaAttachmentHandler)
		convey.So(ok, convey.ShouldBeTrue)
		convey.So(handler.attachmentService, convey.ShouldNotBeNil)
		convey.So(handler.metaService, convey.ShouldNotBeNil)
	})
}

func Test_openVCCMetaAttachmentHandler_DownloadMetaAttachment20210101(t *testing.T) {
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-1", "DocVersion": "v1"})
			serviceErr := errors.ErrorCommon.WithArgs("download failed")
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				convey.So(downloadID, convey.ShouldEqual, "D-1")
				convey.So(version, convey.ShouldEqual, "v1")
				return nil, serviceErr
			}}}
			h.DownloadMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("nil info", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-1", "DocVersion": "v1"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return nil, nil
			}}}
			h.DownloadMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-1", "DocVersion": "v1"})
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return &metaattachmodels.AttachmentDataInfo{FileName: "contract.docx", Data: []byte("file-data")}, nil
			}}}
			h.DownloadMetaAttachment20210101(context.Background(), c)
			convey.So(c.Response.Header.Get("Content-Disposition"), convey.ShouldEqual, "attachment;filename=contract.docx")
			convey.So(c.Response.Header.Get("Content-type"), convey.ShouldEqual, "application/octet-stream")
			convey.So(c.Response.Body(), convey.ShouldResemble, []byte("file-data"))
		})
	})
}

func Test_openVCCMetaAttachmentHandler_ViewMetaAttachment20210101(t *testing.T) {
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("view failed")
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-2", "DocVersion": "v2"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return nil, serviceErr
			}}}
			h.ViewMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("nil info", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-2", "DocVersion": "v2"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return nil, nil
			}}}
			h.ViewMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("cannot view", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-2", "DocVersion": "v2"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return &metaattachmodels.AttachmentDataInfo{CanView: false}, nil
			}}}
			h.ViewMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			c := &app.RequestContext{}
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-2", "DocVersion": "v2"})
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return &metaattachmodels.AttachmentDataInfo{CanView: true, ContentType: "application/pdf", Data: []byte("preview")}, nil
			}}}
			h.ViewMetaAttachment20210101(context.Background(), c)
			convey.So(c.Response.Header.Get("Content-Type"), convey.ShouldEqual, "application/pdf")
			convey.So(c.Response.Body(), convey.ShouldResemble, []byte("preview"))
		})
	})
}

func Test_openVCCMetaAttachmentHandler_GetMetaAttachmentInfo20210101(t *testing.T) {
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("info failed")
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-3", "DocVersion": "v3"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				convey.So(downloadID, convey.ShouldEqual, "D-3")
				convey.So(version, convey.ShouldEqual, "v3")
				return nil, serviceErr
			}}}
			h.GetMetaAttachmentInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.AttachmentDataInfo{FileName: "raw.txt", CanView: true}
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-3", "DocVersion": "v3"})
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentDataInfoFn: func(ctx context.Context, downloadID, version string) (*metaattachmodels.AttachmentDataInfo, errors.APIError) {
				return resp, nil
			}}}
			h.GetMetaAttachmentInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_UploadMetaAttachment20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service success with form file", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			formFile := &multipart.FileHeader{Filename: "upload.pdf", Size: 10}
			resp := &metaattachmodels.UploadResp{FileID: "FID-1", FileName: "upload.pdf"}
			var capturedReq *metaattachmodels.UploadReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(formFile, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{uploadAttachmentFn: func(ctx context.Context, req *metaattachmodels.UploadReq) (*metaattachmodels.UploadResp, errors.APIError) {
				capturedReq = req
				return resp, nil
			}}}
			h.UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedReq.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
			convey.So(capturedReq.File, convey.ShouldResemble, formFile)
			convey.So(capturedReq.FileName, convey.ShouldEqual, "upload.pdf")
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("upload failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(nil, fmt.Errorf("no file")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{uploadAttachmentFn: func(ctx context.Context, req *metaattachmodels.UploadReq) (*metaattachmodels.UploadResp, errors.APIError) {
				convey.So(req.SourceType, convey.ShouldEqual, _const.SourceTypeOpen)
				return nil, serviceErr
			}}}
			h.UploadMetaAttachment20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_InitMultipartUpload20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).InitMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("init failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{initMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.InitMultipartUploadReq) (*metaattachmodels.InitMultipartUploadResp, errors.APIError) {
				return nil, serviceErr
			}}}
			h.InitMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.InitMultipartUploadResp{TosKey: "contract/file.docx", UploadID: "upload-id"}
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{initMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.InitMultipartUploadReq) (*metaattachmodels.InitMultipartUploadResp, errors.APIError) {
				return resp, nil
			}}}
			h.InitMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_UploadMultipartPart20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).UploadMultipartPart20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("upload part failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(nil, fmt.Errorf("no part file")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{uploadMultipartPartFn: func(ctx context.Context, req *metaattachmodels.UploadMultipartPartReq) (*metaattachmodels.UploadMultipartPartResp, errors.APIError) {
				convey.So(req.File, convey.ShouldBeNil)
				return nil, serviceErr
			}}}
			h.UploadMultipartPart20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			formFile := &multipart.FileHeader{Filename: "part", Size: 10}
			resp := &metaattachmodels.UploadMultipartPartResp{ETag: "etag-1"}
			var capturedReq *metaattachmodels.UploadMultipartPartReq
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock((*app.RequestContext).FormFile).Return(formFile, nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{uploadMultipartPartFn: func(ctx context.Context, req *metaattachmodels.UploadMultipartPartReq) (*metaattachmodels.UploadMultipartPartResp, errors.APIError) {
				capturedReq = req
				return resp, nil
			}}}
			h.UploadMultipartPart20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedReq.File, convey.ShouldResemble, formFile)
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_CompleteMultipartUpload20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("complete failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{completeMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.CompleteMultipartUploadReq) (*metaattachmodels.CompleteMultipartUploadResp, errors.APIError) {
				return nil, serviceErr
			}}}
			h.CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.CompleteMultipartUploadResp{TosKey: "contract/file.docx"}
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{completeMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.CompleteMultipartUploadReq) (*metaattachmodels.CompleteMultipartUploadResp, errors.APIError) {
				return resp, nil
			}}}
			h.CompleteMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_AbortMultipartUpload20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("abort failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{abortMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.AbortMultipartUploadReq) errors.APIError {
				return serviceErr
			}}}
			h.AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedResult interface{} = "not-called"
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{abortMultipartUploadFn: func(ctx context.Context, req *metaattachmodels.AbortMultipartUploadReq) errors.APIError {
				return nil
			}}}
			h.AbortMultipartUpload20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldBeNil)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_ApplyUploadInfo20210101(t *testing.T) {
	t.Run("bind error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("apply failed")
			var capturedErr vhertz.APIError
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{applyUploadInfoFn: func(ctx context.Context, req *metaattachmodels.ApplyUploadInfoReq) (*metaattachmodels.PreSingedPostFormData, errors.APIError) {
				return nil, serviceErr
			}}}
			h.ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.PreSingedPostFormData{Key: "contract/file.docx", Addr: "bucket.example.com"}
			var capturedResult interface{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{applyUploadInfoFn: func(ctx context.Context, req *metaattachmodels.ApplyUploadInfoReq) (*metaattachmodels.PreSingedPostFormData, errors.APIError) {
				return resp, nil
			}}}
			h.ApplyUploadInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_GetMetaAttachmentURL20210101(t *testing.T) {
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("url failed")
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-4", "DocVersion": "v4"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{metaService: &fakeOpenVCCMetaAttachmentMetaService{getViewURLFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
				convey.So(param.DownloadID, convey.ShouldEqual, "D-4")
				convey.So(param.Version, convey.ShouldEqual, "v4")
				return "", "", serviceErr
			}}}
			h.GetMetaAttachmentURL20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-4", "DocVersion": "v4"})
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{metaService: &fakeOpenVCCMetaAttachmentMetaService{getViewURLFn: func(ctx context.Context, param *bizmodels.MetaAttachmentDownloadParam) (string, string, errors.APIError) {
				return "https://example.com/file", "file.docx", nil
			}}}
			h.GetMetaAttachmentURL20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, &metaattachmodels.AttachmentURL{URL: "https://example.com/file", FileName: "file.docx"})
		})
	})
}

func Test_openVCCMetaAttachmentHandler_GetProcessFileInfo20210101(t *testing.T) {
	t.Run("missing ContractNo", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"CurrentOperator": "operator"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("missing CurrentOperator", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockOpenVCCMetaAttachmentQuery(map[string]string{"ContractNo": "CN-1"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			(&openVCCMetaAttachmentHandler{}).GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
		})
	})
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("process failed")
			mockOpenVCCMetaAttachmentQuery(map[string]string{"ContractNo": "CN-1", "CurrentOperator": "operator"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getProcessFileInfoFn: func(ctx context.Context, contractNo, currentOperator string) (*metaattachmodels.GetProcessFileInfoResp, errors.APIError) {
				convey.So(contractNo, convey.ShouldEqual, "CN-1")
				convey.So(currentOperator, convey.ShouldEqual, "operator")
				return nil, serviceErr
			}}}
			h.GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.GetProcessFileInfoResp{}
			mockOpenVCCMetaAttachmentQuery(map[string]string{"ContractNo": "CN-1", "CurrentOperator": "operator"})
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getProcessFileInfoFn: func(ctx context.Context, contractNo, currentOperator string) (*metaattachmodels.GetProcessFileInfoResp, errors.APIError) {
				return resp, nil
			}}}
			h.GetProcessFileInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

func Test_openVCCMetaAttachmentHandler_GetAttachmentPreviewInfo20210101(t *testing.T) {
	t.Run("service error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			serviceErr := errors.ErrorCommon.WithArgs("preview failed")
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-5", "DocVersion": "v5", "CurrentOperator": "operator"})
			var capturedErr vhertz.APIError
			mockey.Mock(vhertz.ErrorResp).To(func(ctx context.Context, c *app.RequestContext, err vhertz.APIError) { capturedErr = err }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentPreviewInfoFn: func(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*metaattachmodels.GetAttachmentPreviewInfoResp, errors.APIError) {
				convey.So(req.DownloadID, convey.ShouldEqual, "D-5")
				convey.So(req.DocVersion, convey.ShouldEqual, "v5")
				convey.So(req.CurrentOperator, convey.ShouldEqual, "operator")
				return nil, serviceErr
			}}}
			h.GetAttachmentPreviewInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})
	t.Run("success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &metaattachmodels.GetAttachmentPreviewInfoResp{AttachName: "preview.pdf", CanPreview: true, PreviewURL: "https://example.com/preview"}
			mockOpenVCCMetaAttachmentQuery(map[string]string{"DownloadID": "D-5", "DocVersion": "v5", "CurrentOperator": "operator"})
			var capturedResult interface{}
			mockey.Mock(vhertz.DoResponse).To(func(ctx context.Context, c *app.RequestContext, result interface{}) { capturedResult = result }).Build()
			h := &openVCCMetaAttachmentHandler{attachmentService: &fakeOpenVCCMetaAttachmentService{getAttachmentPreviewInfoFn: func(ctx context.Context, req *bizmodels.GetAttachmentPreviewInfoReq) (*metaattachmodels.GetAttachmentPreviewInfoResp, errors.APIError) {
				return resp, nil
			}}}
			h.GetAttachmentPreviewInfo20210101(context.Background(), &app.RequestContext{})
			convey.So(capturedResult, convey.ShouldResemble, resp)
		})
	})
}

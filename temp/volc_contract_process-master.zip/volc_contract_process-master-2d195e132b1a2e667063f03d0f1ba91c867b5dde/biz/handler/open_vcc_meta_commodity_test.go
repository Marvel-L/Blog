package handler

import (
	"context"
	"fmt"
	"testing"
	"volc_contract_process/biz/bizmodels"

	vhertz "code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"code.byted.org/middleware/hertz/pkg/app"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/errors"
)

type fakeOpenVCCMetaCommodityService struct {
	metacommodity.Service
	listContractForInvoiceProjectFn  func(context.Context, string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, errors.APIError)
	getInvoiceByContractAndProductFn func(context.Context, *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, errors.APIError)
	hasQuoteRelateContractFn         func(context.Context, string) (*modelcommodity.HasQuoteRelateContractResp, errors.APIError)
	createOrUpdateManageInfoFn       func(context.Context, modelcommodity.UpdateManageInfoReq) errors.APIError
	listCommodityFn                  func(context.Context, *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError)
}

func (f *fakeOpenVCCMetaCommodityService) ListContractForInvoiceProject(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, errors.APIError) {
	if f.listContractForInvoiceProjectFn != nil {
		return f.listContractForInvoiceProjectFn(ctx, invoiceProject)
	}
	return nil, nil
}

func (f *fakeOpenVCCMetaCommodityService) GetInvoiceByContractAndProduct(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, errors.APIError) {
	if f.getInvoiceByContractAndProductFn != nil {
		return f.getInvoiceByContractAndProductFn(ctx, req)
	}
	return nil, nil
}

func (f *fakeOpenVCCMetaCommodityService) HasQuoteRelateContract(ctx context.Context, quoteID string) (*modelcommodity.HasQuoteRelateContractResp, errors.APIError) {
	if f.hasQuoteRelateContractFn != nil {
		return f.hasQuoteRelateContractFn(ctx, quoteID)
	}
	return nil, nil
}

func (f *fakeOpenVCCMetaCommodityService) CreateOrUpdateManageInfo(ctx context.Context, req modelcommodity.UpdateManageInfoReq) errors.APIError {
	if f.createOrUpdateManageInfoFn != nil {
		return f.createOrUpdateManageInfoFn(ctx, req)
	}
	return nil
}

func (f *fakeOpenVCCMetaCommodityService) ListCommodity(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
	if f.listCommodityFn != nil {
		return f.listCommodityFn(ctx, req)
	}
	return nil, nil
}

func Test_openVCCMetaCommodityHandler_ListContractForInvoiceProject20210101(t *testing.T) {
	t.Run("缺少InvoiceProject返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "InvoiceProject" }).Return("").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "InvoiceProject")
			}).Build()

			h.ListContractForInvoiceProject20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := errors.ErrorCommon.WithArgs("list failed")
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{listContractForInvoiceProjectFn: func(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, errors.APIError) {
				convey.So(invoiceProject, convey.ShouldEqual, "INV-001")
				return nil, svcErr
			}}}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "InvoiceProject" }).Return("INV-001").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.ListContractForInvoiceProject20210101(context.Background(), c)
		})
	})

	t.Run("服务成功返回合同列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.OpenMetaListForInvoiceProjectResp{List: []*modelcommodity.MetaContractInfo{{ContractNo: "CN1", Version: 1}}}
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{listContractForInvoiceProjectFn: func(ctx context.Context, invoiceProject string) (*modelcommodity.OpenMetaListForInvoiceProjectResp, errors.APIError) {
				return resp, nil
			}}}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "InvoiceProject" }).Return("INV-002").Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.ListContractForInvoiceProject20210101(context.Background(), c)
		})
	})
}

func Test_openVCCMetaCommodityHandler_GetInvoiceByContractAndProduct20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			}).Build()

			h.GetInvoiceByContractAndProduct20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := errors.ErrMissingParam.WithArgs("Product")
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{getInvoiceByContractAndProductFn: func(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, errors.APIError) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CN2026")
				convey.So(req.Product, convey.ShouldEqual, "ECS")
				return nil, svcErr
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractAndProductReq)
				req.ContractNo = "CN2026"
				req.Product = "ECS"
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.GetInvoiceByContractAndProduct20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务成功返回开票项目", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.GetInvoiceByContractAndProductResp{InvoiceProjectCode: "IP-1", TradeProduct: "ECS"}
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{getInvoiceByContractAndProductFn: func(ctx context.Context, req *modelcommodity.GetInvoiceByContractAndProductReq) (*modelcommodity.GetInvoiceByContractAndProductResp, errors.APIError) {
				return resp, nil
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractAndProductReq)
				req.ContractNo = "CN2026"
				req.Product = "ECS"
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.GetInvoiceByContractAndProduct20210101(context.Background(), &app.RequestContext{})
		})
	})
}

func Test_openVCCMetaCommodityHandler_HasQuoteRelateContract20210101(t *testing.T) {
	t.Run("缺少QuoteID返回缺参错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "QuoteID" }).Return("").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrMissingParam.GetCode())
				convey.So(err.GetArgs()[0], convey.ShouldEqual, "QuoteID")
			}).Build()

			h.HasQuoteRelateContract20210101(context.Background(), c)
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := errors.ErrorCommon.WithArgs("quote failed")
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{hasQuoteRelateContractFn: func(ctx context.Context, quoteID string) (*modelcommodity.HasQuoteRelateContractResp, errors.APIError) {
				convey.So(quoteID, convey.ShouldEqual, "Q-1")
				return nil, svcErr
			}}}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "QuoteID" }).Return("Q-1").Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.HasQuoteRelateContract20210101(context.Background(), c)
		})
	})

	t.Run("服务成功返回关联结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.HasQuoteRelateContractResp{Related: true}
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{hasQuoteRelateContractFn: func(ctx context.Context, quoteID string) (*modelcommodity.HasQuoteRelateContractResp, errors.APIError) {
				return resp, nil
			}}}
			c := &app.RequestContext{}
			mockey.Mock((*app.RequestContext).Query).When(func(key string) bool { return key == "QuoteID" }).Return("Q-2").Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.HasQuoteRelateContract20210101(context.Background(), c)
		})
	})
}

func Test_openVCCMetaCommodityHandler_CreateOrUpdateManageInfo20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			}).Build()

			h.CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := errors.ErrorCommon.WithArgs("save failed")
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{createOrUpdateManageInfoFn: func(ctx context.Context, req modelcommodity.UpdateManageInfoReq) errors.APIError {
				convey.So(req.ContractNo, convey.ShouldEqual, "CN-MANAGE")
				convey.So(req.ManageInfo, convey.ShouldNotBeNil)
				return svcErr
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.UpdateManageInfoReq)
				req.ContractNo = "CN-MANAGE"
				req.ManageInfo = &bizmodels.ManageInfo{}
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务成功返回合同号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{createOrUpdateManageInfoFn: func(ctx context.Context, req modelcommodity.UpdateManageInfoReq) errors.APIError {
				convey.So(req.ContractNo, convey.ShouldEqual, "CN-SUCCESS")
				return nil
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.UpdateManageInfoReq)
				req.ContractNo = "CN-SUCCESS"
				req.ManageInfo = &bizmodels.ManageInfo{}
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, "CN-SUCCESS")
			}).Build()

			h.CreateOrUpdateManageInfo20210101(context.Background(), &app.RequestContext{})
		})
	})
}

func Test_openVCCMetaCommodityHandler_List20210101(t *testing.T) {
	t.Run("bind失败返回参数解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrParamParseFail.GetCode())
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("参数校验失败返回通用错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			h := &openVCCMetaCommodityHandler{}
			mockey.Mock(binding.BindAndValidate).Return(nil).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrorCommon.GetCode())
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务失败透传错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svcErr := errors.ErrorCommon.WithArgs("list commodity failed")
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{listCommodityFn: func(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CN-LIST")
				convey.So(req.Limit, convey.ShouldEqual, 10)
				return nil, svcErr
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.ListCommodityReq)
				req.ContractNo = "CN-LIST"
				req.Limit = 10
				req.Offset = 0
				return nil
			}).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				convey.So(err, convey.ShouldEqual, svcErr)
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})
		})
	})

	t.Run("服务成功返回商品列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			resp := &modelcommodity.CommodityListResp{Map: map[string][]*bizmodels.ProductInfo{}, Total: 0, Limit: 10, Offset: 0}
			h := &openVCCMetaCommodityHandler{commodityService: &fakeOpenVCCMetaCommodityService{listCommodityFn: func(ctx context.Context, req *modelcommodity.ListCommodityReq) (*modelcommodity.CommodityListResp, errors.APIError) {
				convey.So(req.ContractNo, convey.ShouldEqual, "CN-LIST-SUCCESS")
				return resp, nil
			}}}
			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.ListCommodityReq)
				req.ContractNo = "CN-LIST-SUCCESS"
				req.Limit = 10
				req.Offset = 0
				return nil
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				convey.So(result, convey.ShouldEqual, resp)
			}).Build()

			h.List20210101(context.Background(), &app.RequestContext{})
		})
	})
}

func Test_openVCCMetaCommodityHandler_GetInvoiceByContract20210101(t *testing.T) {
	t.Run("参数绑定失败时返回解析错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := metacommodity.NewService()
			h := &openVCCMetaCommodityHandler{
				commodityService: svc,
			}

			var capturedErr vhertz.APIError
			var capturedResp interface{}

			mockey.Mock(binding.BindAndValidate).Return(fmt.Errorf("bind failed")).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.GetInvoiceByContract20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldResemble, errors.ErrParamParseFail)
			convey.So(capturedResp, convey.ShouldBeNil)
		})
	})

	t.Run("服务返回错误时透传错误响应", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := metacommodity.NewService()
			h := &openVCCMetaCommodityHandler{
				commodityService: svc,
			}

			var capturedErr vhertz.APIError
			var capturedReq *modelcommodity.GetInvoiceByContractReq
			serviceErr := errors.ErrorCommon.WithArgs("query failed")

			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractReq)
				req.ContractNo = "CN20240613001"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "GetInvoiceByContract")).To(
				func(_ context.Context, req *modelcommodity.GetInvoiceByContractReq) (modelcommodity.GetInvoiceByContractResp, errors.APIError) {
					capturedReq = req
					return nil, serviceErr
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).Return().Build()

			h.GetInvoiceByContract20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN20240613001")
			convey.So(capturedErr, convey.ShouldResemble, serviceErr)
		})
	})

	t.Run("服务成功时返回开票项目信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			svc := metacommodity.NewService()
			h := &openVCCMetaCommodityHandler{
				commodityService: svc,
			}

			var capturedReq *modelcommodity.GetInvoiceByContractReq
			var capturedErr vhertz.APIError
			var capturedResp interface{}
			expectedResp := modelcommodity.GetInvoiceByContractResp{
				"PROD001": {
					InvoiceProjectCode: "INV001",
					TradeProduct:       "PROD001",
					TaxRatio:           "0.06",
				},
			}

			mockey.Mock(binding.BindAndValidate).To(func(_ *app.RequestContext, obj interface{}) error {
				req := obj.(*modelcommodity.GetInvoiceByContractReq)
				req.ContractNo = "CN20240613002"
				return nil
			}).Build()
			mockey.Mock(mockey.GetMethod(svc, "GetInvoiceByContract")).To(
				func(_ context.Context, req *modelcommodity.GetInvoiceByContractReq) (modelcommodity.GetInvoiceByContractResp, errors.APIError) {
					capturedReq = req
					return expectedResp, nil
				},
			).Build()
			mockey.Mock(vhertz.ErrorResp).To(func(_ context.Context, _ *app.RequestContext, err vhertz.APIError) {
				capturedErr = err
			}).Build()
			mockey.Mock(vhertz.DoResponse).To(func(_ context.Context, _ *app.RequestContext, result interface{}) {
				capturedResp = result
			}).Build()

			h.GetInvoiceByContract20210101(context.Background(), &app.RequestContext{})

			convey.So(capturedErr, convey.ShouldBeNil)
			convey.So(capturedReq, convey.ShouldNotBeNil)
			convey.So(capturedReq.ContractNo, convey.ShouldEqual, "CN20240613002")
			convey.So(capturedResp, convey.ShouldResemble, expectedResp)
		})
	})
}

package service

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"io/ioutil"
	"strconv"
	"volc_contract_process/pkg/proxy/accountcli"

	"code.byted.org/videoarch/cloud_gopkg/trade_export_client"

	"volc_contract_process/biz/service/masterdata"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/workflow"
	"volc_contract_process/pkg/proxy/exportcli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"

	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/idgenerator"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type BizContractService interface {
	List(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError)
	Detail(ctx context.Context, param *bizmodels.BizContractDetailParam) (*bizmodels.BizContract, errors.APIError)
	Download(ctx context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError)
	Export(ctx context.Context, param *bizmodels.BizContractListParam) errors.APIError
	ESignCallback(ctx context.Context, param *bizmodels.ESignCallbackReq) errors.APIError
	ExistPartyMD(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError)
}

type bizContractServiceImpl struct {
	bizContractDao     dal.BizContractDao
	retryTaskDao       dal.CommonRetryTaskDao
	operationRecordDao dal.CommonOperationRecordDao
	mdPartyDao         dal.MdPartyInfoDao
}

func NewBizContractService() BizContractService {
	return &bizContractServiceImpl{
		bizContractDao:     dal.NewBizContractDao(),
		retryTaskDao:       dal.NewCommonRetryTaskDao(),
		operationRecordDao: dal.NewCommonOperationRecordDao(),
		mdPartyDao:         dal.NewMdPartyInfoDao(),
	}
}

// List 列表查询
func (s *bizContractServiceImpl) List(ctx context.Context, param *bizmodels.BizContractListParam) (*bizmodels.BizContractListResp, errors.APIError) {

	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "bizContractServiceImpl_ListFail, err: %s", err.Error())
		return nil, err
	}

	req, err := s.buildQueryListReq(ctx, param)
	if err != nil {
		logs.CtxError(ctx, "buildQueryListReqFail, err: %s", err.Error())
		return nil, err
	}

	list, total, err2 := s.bizContractDao.List(ctx, nil, req)
	if err2 != nil {
		return nil, errors.ErrInternalError.WithArgs(err)
	}

	if len(list) == 0 {
		return nil, nil
	}

	retList := list.GenResp()
	var StatusDescMethod = multienv.GetGenStatusDescMethod(param.SourceType)
	for _, contract := range retList {
		contract.StatusDesc = StatusDescMethod(ctx, contract.Status)
		account, err := accountcli.GetAccountAndVerifyFromCache(ctx, contract.AccountID)
		if err != nil {
			logs.CtxError(ctx, "get accountID[%v] info has err:%v", contract.AccountID, err)
			continue
		}
		contract.Identity = account.AccountName
		contract.CustomerName = account.VerifyName
		contract.CreateSource = int(account.CreateSource)
	}

	return &bizmodels.BizContractListResp{
		List:   retList,
		Total:  total,
		Limit:  param.Limit,
		Offset: param.Offset,
	}, nil

}

func (s *bizContractServiceImpl) buildQueryListReq(ctx context.Context, param *bizmodels.BizContractListParam) (*model.BizContractReq, errors.APIError) {
	logs.CtxInfo(ctx, "buildQueryListReq, param:%+v", param)
	ret := &model.BizContractReq{
		SourceType:      param.SourceType,
		CurrentOperator: param.CurrentOperator,
		Status:          param.Status,
		Identifier:      param.Identifier,
		ContractNo:      param.ContractNo,
		CreateTimeBegin: param.CreateTimeBegin,
		CreateTimeEnd:   param.CreateTimeEnd,
		ValidityBegin:   param.ValidityBegin,
		ValidityEnd:     param.ValidityEnd,
		AccountID:       param.AccountID,
		OrderBy:         param.OrderBy,
		Scene:           param.Scene,
		Limit:           param.Limit,
		Offset:          param.Offset,
		IsManager:       true,
		NeedTotal:       true,
	}

	if param.SourceType == _const.SourceTypeOpen {
		// 外部客户 仅允许查看自己相关的合同
		if ret.AccountID == 0 { // 严格判断 且应该与鉴权配合
			return nil, errors.ErrInternalError.WithArgs("无客户ID")
		}
	}

	return ret, nil
}

func (s *bizContractServiceImpl) Detail(ctx context.Context, param *bizmodels.BizContractDetailParam) (*bizmodels.BizContract, errors.APIError) {

	bizContract, err := s.queryAccessibleContract(ctx, param)
	if bizContract == nil || err != nil {
		return nil, errors.ErrorCommon.WithArgs("查询合同信息失败")
	}

	// 查询操作记录
	recordList, err2 := s.operationRecordDao.ListOperationRecordByIdentNo(ctx, nil, bizContract.Identifier, bizContract.Scene)
	if err2 != nil {
		return nil, errors.ErrInternalError.WithArgs("查询操作记录失败")
	}

	ret := bizContract.GenResp()

	if len(recordList) > 0 {
		ret.OpRecordList = recordList.GenResp()
	}
	method := multienv.GetGenStatusDescMethod(param.SourceType)
	ret.StatusDesc = method(ctx, ret.Status)
	account, accountErr := accountcli.GetAccountAndVerifyFromCache(ctx, ret.AccountID)
	if accountErr != nil {
		logs.Error("get accountID[%v] info has err:%v", ret.AccountID, accountErr)
		return nil, errors.ErrGetAccountFail.WithArgs(ret.AccountID)
	}
	ret.Identity = account.AccountName
	ret.CustomerName = account.VerifyName
	ret.CreateSource = int(account.CreateSource)
	return ret, nil
}

func (s *bizContractServiceImpl) queryAccessibleContract(ctx context.Context, param *bizmodels.BizContractDetailParam) (*model.BizContractDB, errors.APIError) {

	if err := param.Validate(); err != nil {
		logs.CtxError(ctx, "bizContractServiceImpl_DetailValidateFail, err: %s", err.Error())
		return nil, err
	}

	bizContract, err := s.bizContractDao.FindByContractNo(ctx, nil, param.ContractNo)
	if err != nil {
		logs.CtxError(ctx, "FindByIdentifierFail, contractNo:%s, err: %s", param.ContractNo, err.Error())
		return nil, errors.ErrInternalError.WithArgs("查询失败")
	}
	if bizContract == nil {
		return nil, nil
	}

	if param.SourceType == _const.SourceTypeOpen && bizContract.AccountID != param.AccountID {
		return nil, errors.ErrInternalError.WithArgs("无权限")
	}
	return bizContract, nil
}

func (s *bizContractServiceImpl) Download(ctx context.Context, param *bizmodels.BizContractDetailParam) ([]byte, string, errors.APIError) {

	bizContract, err := s.queryAccessibleContract(ctx, param)
	if bizContract == nil || err != nil {
		return nil, "", err
	}

	// 判断合同状态
	if !util.IntIn(bizContract.Status, []int{_const.BizContractStatusToBeConfirm, _const.BizContractStatusBeEffective, _const.BizContractStatusInForce, _const.BizContractStatusExpired}) {
		logs.CtxError(ctx, "ContractDownloadStatusValidateFail, Identifier:%s, Scene:%s, Status:%s", bizContract.Identifier, bizContract.Scene, bizContract.Status)
		return nil, "", errors.ErrValidate
	}

	fileId := bizContract.FileIdUnsigned
	if bizContract.Status >= _const.BizContractStatusBeEffective {
		fileId = bizContract.FileIdSigned
	}

	if len(fileId) == 0 {
		logs.CtxError(ctx, "ContractDownloadFail, fileIdNotExist Identifier:%s, Scene:%s, Status:%s", bizContract.Identifier, bizContract.Scene, bizContract.Status)
		return nil, "", errors.ErrValidate
	}

	ret, filename, err2 := DownloadBody(ctx, fileId)
	if err != nil {
		return nil, "", err2
	}

	return ret, filename, nil

}

func (s *bizContractServiceImpl) Export(ctx context.Context, param *bizmodels.BizContractListParam) errors.APIError {

	if param.SourceType == _const.SourceTypeOpen {
		return errors.ErrExportErr.WithArgs("不支持的操作")
	}

	// 限制最大可导出条数
	param.Limit = 1000

	list, err := s.List(ctx, param)
	if err != nil {
		return err
	}

	if list == nil || list.Total == 0 {
		logs.CtxError(ctx, "ExportContractListFail, list is empty")
		return errors.ErrExportNoRecord
	}

	if err = s.uploadWithCreateTask(ctx, param, list.List); err != nil {
		return err
	}

	return nil
}

func (s *bizContractServiceImpl) uploadWithCreateTask(ctx context.Context, param *bizmodels.BizContractListParam, list []*bizmodels.BizContract) errors.APIError {

	fileID, err := idgenerator.GeneratorID("")
	if err != nil {
		logs.CtxError(ctx, "GeneratorIDFail, error: ", err)
		return errors.ErrExportErr.WithArgs("生成文件编号失败")
	}

	// 创建一个临时文件用于存储数据
	tempFile, err := ioutil.TempFile("", i18nfmt.Sprintf(ctx, "temp_%v.csv", fileID))
	if err != nil {
		logs.CtxError(ctx, "uploadWithCreateTask-createTempFileFail, err: %v", err.Error())
		return errors.ErrExportErr.WithArgs("生成文件失败")
	}

	var content [][]string

	header := []string{"合同编号", "报价单号", "账号ID", "用户名", "客户名称", "价格有效期", "创建人", "创建时间", "完成时间", "备注", "状态"}
	content = append(content, header)

	operatorMap := map[string]string{}
	accountMap := map[int64]*accountcli.AccountAndVerifyInfo{}

	for _, contract := range list {

		account, ok := accountMap[contract.AccountID]
		if !ok {
			accountInfo, err := accountcli.GetAccountAndVerifyFromCache(ctx, contract.AccountID)
			if err != nil {
				logs.CtxError(ctx, "get account [%v] err: %v", contract.AccountID, err)
			} else {
				account = accountInfo
				accountMap[contract.AccountID] = account
			}
		}

		if account == nil {
			return errors.ErrExportErr.WithArgs("查询用户信息失败")
		}

		operator, ok := operatorMap[contract.Creator]
		if !ok {
			employees, err := larkc.GetEmployeeByMail(context.Background(), contract.Creator)
			if err != nil {
				logs.CtxError(ctx, "get employee [%v] err: %v", contract.AccountID, err)
			} else {
				operator = employees[0].Name
				operatorMap[contract.Creator] = operator
			}
		}

		// "合同编号", "报价单号", "账号ID", "用户名", "客户名称", "价格有效期", "创建人", "创建时间", "完成时间", "备注", "状态"
		line := []string{
			contract.ContractNo,
			contract.Identifier,
			strconv.FormatInt(contract.AccountID, 10),
			account.AccountName,
			account.VerifyName,
			contract.ValidityBegin + " - " + contract.ValidityEnd,
			operator,
			contract.CreateTime,
			contract.FinishTime,
			contract.Remark,
			multienv.GetInnerStatusDesc(ctx, contract.Status),
		}

		content = append(content, line)
	}

	ioW := bytes.NewBufferString("\xEF\xBB\xBF")
	w := csv.NewWriter(ioW)

	err = w.WriteAll(content)
	if err != nil {
		logs.CtxError(ctx, "csv write content err: %v", err)
		return errors.ErrExportErr.WithArgs("生成文件失败")
	}

	_, err = tempFile.Write(ioW.Bytes())
	if err != nil {
		logs.CtxError(ctx, "temp file write fail: %v", err)
		return errors.ErrExportErr.WithArgs("生成文件失败")
	}

	// 新建一个导出任务
	fileName := i18nfmt.Sprintf(ctx, "contract_%v.csv", fileID)
	opType := trade_export_client.OperatorTypeInner
	if param.SourceType == _const.SourceTypeOpen {
		opType = trade_export_client.OperatorTypeOuter
	}
	logs.CtxInfo(ctx, "CreateExportTask, opType:%v, Operator:%v, fileName:%v", opType, param.CurrentOperator, fileName)
	_ = exportcli.UploadWithCreateTask(ctx, tempFile, param.CurrentOperator, param.Extra, fileName)

	return nil
}

// ESignCallback 电子签合同状态变更回调
func (s *bizContractServiceImpl) ESignCallback(ctx context.Context, param *bizmodels.ESignCallbackReq) errors.APIError {
	paramBody, _ := json.Marshal(param)
	logs.CtxInfo(ctx, "ESignCallbackIn, body:%s", string(paramBody))

	event := param.Convert()

	task := &workflow.EventContext{
		TaskType:     workflow.TaskTypeESignStatusCallback,
		EventExtInfo: event,
	}

	_, err := workflow.Process(ctx, task)
	if err != nil {
		logs.CtxError(ctx, "eSignCallbackByContractV2Fail, contractNo=%s, err=%s", event.ContractNo, err.Error())
		return err
	}

	return nil
}

// ExistPartyMD 判定是否不需要传递额外参数即可获取主数据
func (s *bizContractServiceImpl) ExistPartyMD(ctx context.Context, param *bizmodels.MdPartyExistParam) (bool, errors.APIError) {
	if param.SourceType == _const.SourceTypeInner {
		return false, errors.ErrExportErr.WithArgs("不支持的操作")
	}
	_, err := masterdata.GetMdPartyInfo(ctx, param.AccountID, "", "", "")
	if err != nil {
		return false, nil
	}

	return true, nil
}

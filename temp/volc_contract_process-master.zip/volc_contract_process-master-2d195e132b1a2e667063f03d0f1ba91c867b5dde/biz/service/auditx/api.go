package auditx

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"strconv"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/auditx/handler"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/salesforcecli"
	"volc_contract_process/pkg/recovery"
	utils "volc_contract_process/pkg/util"
)

// engine 审批引擎
type engine struct {
	statusHandleMappings     map[int]map[int]handler.StatusOpHandler // 3层级结构：审批流状态 => 操作 => 处理器
	statusReviewTypeMappings map[int]int                             // key=审批流程状态, value=review_type
}

func Handle(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if _instance == nil {
		return i18nfmt.New(ctx, "审批引擎尚未初始化")
	}
	if err := _instance.Handle(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (e *engine) matchReviewerStatusOpConf(ctx context.Context, pc *auditmodel.ProcessCtx) (handler.StatusOpHandler, *modelcooperation.ReviewerStatusOpConf, error) {
	if pc == nil || pc.ContractInfo == nil {
		return nil, nil, i18nfmt.New(ctx, "参数异常")
	}

	meta := pc.ContractInfo

	statusDesc := _const.GenStatusDesc(meta.CooperationStatus)
	opDesc := _const.GenOperateDesc(pc.OperationState)

	logs.CtxInfo(ctx, "audit.HandleIn, contractState:%s, opState:%s, operator:%s", statusDesc, opDesc, pc.CurrentOperator)

	// 选择处理器
	h := e.selectHandler(meta.CooperationStatus, pc.OperationState)
	if h == nil {
		logs.CtxWarn(ctx, "no_valid_handler_defined, contractState:%s, opState:%s, contractNo:%v", statusDesc, opDesc, meta.ContractNo)
		return nil, nil, errorsV2.ErrCommon.WithArgs(i18nfmt.Errorf(ctx, "当前合同状态[%s]不允许此操作[%s]", statusDesc, opDesc))
	}

	// 获取审批流转配置
	statusOpConf := handler.GetValidReviewerType(meta.CooperationStatus, pc.OperationState, pc.ApprovalKey)
	if statusOpConf == nil {
		logs.CtxInfo(ctx, "audit.HandleNoStatusMapError, operator:%s, contractState:%s, opState:%s, approvalKey:%s", pc.CurrentOperator, statusDesc, opDesc, pc.ApprovalKey)
		// 存在2种情况：1.权限配置未定义 2.当前流程节点不允许该操作
		return nil, nil, i18nfmt.New(ctx, "权限配置未定义")
	}

	return h, statusOpConf, nil
}

func (e *engine) Handle(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	h, statusOpConf, err := e.matchReviewerStatusOpConf(ctx, pc)
	if err != nil {
		return err
	}

	pc.ReviewerStatusOpConf = statusOpConf

	meta := pc.ContractInfo

	// 补全reviewer info
	if err = e.fillReviewers(ctx, pc.GetTx(), meta); err != nil {
		return err
	}

	// 若需要检查操作角色权限
	if !statusOpConf.IgnoreRolePermCheck {
		pass, err := e.checkPerm(ctx, pc, statusOpConf)
		if err != nil || !pass {
			logs.CtxError(ctx, "checkPermFail, no:%v, 操作人:%s, 合同协同状态:%v, 操作:%v, err:%v", meta.ContractNo,
				pc.CurrentOperator, meta.CooperationStatus, pc.OperationState, err) // 注意NPE
			return i18nfmt.New(ctx, "用户无权限")
		}
	}

	// 执行前校验
	if err = h.Validate(ctx, pc); err != nil {
		logs.CtxInfo(ctx, "audit.HandleValidateFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	// 执行操作
	if err = h.Process(ctx, pc); err != nil {
		logs.CtxInfo(ctx, "audit.HandleProcessFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	// 当操作类型符合审核通过条件时，存储合同关联文件最新版本信息
	if err := h.SaveProcessFileNestVersion(ctx, pc); err != nil {
		logs.CtxInfo(ctx, "audit.HandleSaveProcessFileNestVersionFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	// 若需要 修改审批操作表状态
	if !statusOpConf.IgnoreUpdateReviewerStatus {
		param := &model.UpdateReviewerStatusReq{
			Reviewer:       pc.CurrentOperator,
			PreContractNO:  meta.ContractNo,
			ReviewerType:   statusOpConf.ReviewerType,
			ContractStatus: meta.CooperationStatus,
			// 以下字段为更新字段
			Status:           statusOpConf.NewStatusOnSuccess,
			SkipReturnReview: pc.SkipReturnReview,
		}
		err = dal.UpdateReviewerStatus(ctx, pc.GetTx(), param)
		if err != nil {
			logs.CtxInfo(ctx, "audit.HandleUpdateReviewerStatusFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
			return err
		}
	}

	// 判断是否触发合同协同状态变更
	if !statusOpConf.IgnoreUpdatePreContractStatus {
		hitChangeContractStatus, err := h.HitStateChangeCondition(ctx, pc)
		if err != nil {
			logs.CtxInfo(ctx, "audit.HandleCheckStatusChangeCondFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
			return err
		}
		if hitChangeContractStatus {
			if err := h.SaveStatusChangeFileVersion(ctx, pc); err != nil {
				logs.CtxError(ctx, "audit.HandleSaveStatusChangeFileVersionFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
				return err
			}
			err = e.changeContractStatus(ctx, h.GetStatusOpConfKey(ctx, pc), pc)
			if err != nil {
				logs.CtxInfo(ctx, "audit.HandleChangeStatusFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
				return err
			}
		}
	}

	// 创建操作记录
	if err = e.createOperateRecord(ctx, pc); err != nil {
		return err
	}

	// 操作后处理逻辑
	if err = h.PostProcess(ctx, pc); err != nil {
		logs.CtxInfo(ctx, "audit.HandlePostProcessFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	logs.CtxInfo(ctx, "audit.HandleOutSuccess, operator:%s", pc.CurrentOperator)
	return nil
}

func (e *engine) fillReviewers(ctx context.Context, tx *gorm.DB, meta *model.ContractMeta) error {
	if len(meta.Reviewers) > 0 {
		return nil
	}
	reviewerDBList, err := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, tx, meta.ContractNo)
	if err != nil {
		return err
	}
	if len(reviewerDBList) > 0 {
		allReviewerList := reviewerDBList.GenResp()
		logs.CtxInfo(ctx, "audit.fillReviewers_reviewerInfo => %s", e.buildReviewersLogInfo(allReviewerList))
		meta.Reviewers = allReviewerList
	}
	return nil
}

func (e *engine) buildReviewersLogInfo(list bizmodels.PreContractReviewerList) string {
	if len(list) == 0 {
		return ""
	}
	buf := bytes.Buffer{}
	for _, r := range list {
		buf.WriteString(fmt.Sprintf("%s_type(%d)_status(%d)||", r.Reviewer, r.ReviewerType, r.Status))
	}
	return buf.String()
}

// 修改合同协同状态
func (e *engine) changeContractStatus(ctx context.Context, approvalStatusKey string, pc *auditmodel.ProcessCtx) error {
	meta := pc.ContractInfo
	newStatus, err := e.resolveContractNewStatus(ctx, approvalStatusKey, pc)
	if err != nil {
		return err
	}

	if err := dal.NewContractMetaDao().UpdateCooperationStatus(ctx, pc.GetTx(), meta.ContractNo, meta.CooperationStatus, newStatus); err != nil {
		return i18nfmt.New(ctx, "更新合同协同状态失败")
	}

	// 软删当前节点加签审核人
	if err := dal.NewPreContractReviewerDao().SoftDeleteCountersignReviewer(ctx, pc.GetTx(), meta.ContractNo, newStatus); err != nil {
		logs.CtxError(ctx, "audit.HandleSoftDeleteCountersignReviewerFail, operator:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	// 状态变更信息塞入上下文
	pc.StatusChanged = true
	pc.StatusChangedValue = newStatus

	// 调整下一节点的审批人
	if err := handler.InitReviewersAfterStatusChanged(ctx, pc); err != nil {
		return err
	}

	// 新状态是否需要重置节点审批状态
	reviewerType, exist := e.statusReviewTypeMappings[newStatus]
	if !exist {
		// 无需重置 仅日志提示
		logs.CtxInfo(ctx, "当前节点[%s]未配置需要重置的审批角色", _const.GenStatusDesc(newStatus))
		// return nil
	} else {
		// 重置 需要指定合同节点限制
		skipReturnReviewNoAuditEmails := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)
		pc.SkipReturnReviewNoAuditEmails = skipReturnReviewNoAuditEmails
		param := &model.ResetReviewerStatusByReviewerTypeReq{
			PreContractNO:                 meta.ContractNo,
			ReviewerType:                  reviewerType,
			ContractStatus:                newStatus,
			SkipReturnReviewNoAuditEmails: skipReturnReviewNoAuditEmails,
		}
		if err := dal.ResetReviewerStatusByReviewerType(ctx, pc.GetTx(), param); err != nil {
			return i18nfmt.New(ctx, "重置操作人员状态失败")
		}
	}

	// CRM回调
	go e.notifyCRM(ctx, pc, newStatus)

	return nil
}

func (e *engine) resolveContractNewStatus(ctx context.Context, approvalStatusKey string, pc *auditmodel.ProcessCtx) (int, error) {
	if pc.IsSpecifiedSendBack() {
		if err := e.validateSpecifiedSendBackTarget(ctx, pc); err != nil {
			return 0, err
		}
		return pc.SendBackTargetStatus, nil
	}

	newStatus, ok := pc.ReviewerStatusOpConf.ContractNewStatusMapOnSuccess[approvalStatusKey]
	if !ok {
		return 0, i18nfmt.New(ctx, "合同协同状态变更配置错误")
	}
	return newStatus, nil
}

func (e *engine) validateSpecifiedSendBackTarget(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	target := pc.SendBackTargetStatus
	if target == 0 {
		return i18nfmt.New(ctx, "请选择退回节点")
	}
	if !utils.IntIn(target, pc.ReviewerStatusOpConf.SpecifiedSendBackTargetStatuses) {
		return i18nfmt.New(ctx, "无效的退回节点")
	}
	if _, ok := e.statusReviewTypeMappings[target]; !ok {
		return i18nfmt.New(ctx, "退回节点审批角色配置错误")
	}
	if target == pc.ContractInfo.CooperationStatus {
		return i18nfmt.New(ctx, "不能退回至当前节点")
	}
	return nil
}

// 返回值为需要跳过的列表
func (e *engine) fetchSkipReturnReviewNoAuditEmails(ctx context.Context, pc *auditmodel.ProcessCtx, newStatus int, reviewerType int) []string {

	if pc.PreContractVO.CooperationStatus != _const.PreSalesContractChange {
		return nil
	}

	var (
		skipReturnReviewNoAuditEmails []string // 返稿场景不需要重新审核的人员列表
		hasAuditEmail                 bool     //
	)

	for _, reviewer := range pc.ContractInfo.Reviewers {
		if reviewer.ReviewerType == reviewerType &&
			reviewer.ContractStatus == newStatus &&
			reviewer.ReviewerSource == 0 {
			if reviewer.SkipReturnReview == _const.SkipReturnReviewTypeSkipAudit {
				// 审核通过无异议
				skipReturnReviewNoAuditEmails = append(skipReturnReviewNoAuditEmails, reviewer.Reviewer)
			} else {
				// 两种情况
				// 修改/确认后重审
				// 历史数据 兼容，需要重审
				hasAuditEmail = true
			}
		}
	}

	if !hasAuditEmail {
		// 全部选择了「审核通过无异议」，则需要全员重审
		return nil
	}
	return skipReturnReviewNoAuditEmails
}

// 回调CRM
func (e *engine) notifyCRM(ctx context.Context, pc *auditmodel.ProcessCtx, newStatus int) error {
	ctx = utils.CopyContext(ctx)
	meta := pc.ContractInfo

	defer recovery.DefaultRecovery(ctx, "notifyCRM")()

	logs.CtxInfo(ctx, "prepare_notify_CRM, contractNo: %s, newStatus: %d", meta.ContractNo, newStatus)
	// 回调CRM
	req := &salesforcecli.PreContractCallbackReq{
		ContractNo:            meta.ContractNo,
		Status:                strconv.Itoa(newStatus),
		ComplianceCheckResult: e.calcComplianceCheckResult(ctx, pc),
	}

	// 草稿提交在线协同时，合同号由 PCT 变更为 CT，先同步 CRM 合同号，再同步合同状态
	if pc.OperationState == _const.OperationSubmitPreContract &&
		pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractDraft {
		if err := salesforcecli.PreContractContractNoCallbackV2(ctx, meta.PreContractNo, meta.ContractNo); err != nil {
			logs.CtxWarn(ctx, "合同号重置失败, PreContractNo:%s, ContractNo:%s, err:%s", meta.PreContractNo, meta.ContractNo, err.Error())
		}
	}
	// 使用 CT 合同号同步合同状态
	if err := salesforcecli.PreContractStatusCallbackV2(ctx, meta.ContractNo, req); err != nil {
		logs.CtxWarn(ctx, "重置失败, err:%s", err.Error())
	}

	logs.CtxInfo(ctx, "notify_CRM_success, contractNo: %s, newStatus: %d", meta.ContractNo, newStatus)
	return nil
}

func (e *engine) calcComplianceCheckResult(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	// 若为合规审查合同，且操作状态为审核通过，需同步给 CRM
	if pc.ContractInfo.CooperationStatus == _const.PreSalesContractComplianceCheck {
		if pc.OperationState == _const.OperationReviewPass {
			return "Approved"
		} else {
			return "Rejected"
		}
	}
	return ""
}

func (e *engine) checkPerm(ctx context.Context, pc *auditmodel.ProcessCtx, statusOpConf *modelcooperation.ReviewerStatusOpConf) (bool, error) {
	if statusOpConf.AllowSystemCalls && pc.CurrentOperator == _const.OperationSystem {
		logs.CtxInfo(ctx, "audit.CheckPermBySystem, operator is System ignore.")
		return true, nil
	}
	return perm.CheckOpPerm(ctx, pc, statusOpConf.ReviewerType)
}

func (e *engine) createOperateRecord(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	var records []*model.ContractOperationRecordDB
	// 创建操作记录
	record := &model.ContractOperationRecordDB{
		PreContractNo:          pc.ContractInfo.ContractNo,
		Operator:               pc.CurrentOperator,
		Operation:              pc.OperationState,
		SecondaryOperationType: pc.SecondaryOperationType,
		SkipReturnReview:       pc.SkipReturnReview,
		SendBackTargetStatus:   pc.SendBackTargetStatus,
		ContractStatus:         pc.ContractInfo.CooperationStatus,
		Remark:                 pc.Remark,
		Extra:                  pc.Extra,
	}
	if len(pc.RecordVersions) > 0 {
		recordVersionsData, _ := json.Marshal(pc.RecordVersions)
		record.RelatedFileVersion = string(recordVersionsData)
	}
	// 存储富文本信息
	richTextDB := model.ConvertRichTextDB(pc.Comment)
	if err := dal.NewRichTextDao().Create(ctx, pc.GetTx(), richTextDB); err != nil {
		logs.CtxError(ctx, "createRichTextFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "存储富文本信息失败")
	}
	// 富文本信息ID关联，不存在时为空
	if richTextDB != nil {
		record.CommentID = int(richTextDB.Id)
	}
	records = append(records, record)
	records = append(records, e.fillSkipNodeOpRecord(ctx, record, pc)...)

	if err := dal.NewContractOperationRecordDao().BatchCreate(ctx, pc.GetTx(), records); err != nil {
		logs.CtxError(ctx, "createOpRecordFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "创建操作记录失败")
	}

	return nil
}

func (e *engine) fillSkipNodeOpRecord(ctx context.Context, record *model.ContractOperationRecordDB, pc *auditmodel.ProcessCtx) []*model.ContractOperationRecordDB {
	var (
		res []*model.ContractOperationRecordDB
		// 当前合同状态
		currentStatus = pc.ContractInfo.CooperationStatus
		// 变更后合同状态
		newStatus = pc.StatusChangedValue
		// map[状态]审核人列表
		reviewerMap = map[int]bizmodels.PreContractReviewerList{}
	)
	if pc.ContractInfo.CooperationStatus == _const.PreSalesContractComplianceCheck {
		currentStatus = pc.ContractInfo.PreCooperationStatus
	}
	// 仅合同状态正向流转，且触发合同状态变更时，进行操作记录补齐
	if !pc.StatusChanged || !utils.IntIn(pc.OperationState, _const.ReviewPassOperationList) {
		return res
	}
	for _, viewer := range pc.ContractInfo.Reviewers {
		reviewerMap[viewer.ContractStatus] = append(reviewerMap[viewer.ContractStatus], viewer)
	}
	for {
		// 存在流转配置，且变更后状态非正常流转状态时，构建被跳过审核节点的协作记录
		if stateConf, ok := _const.CooperationStateCircultionConf[currentStatus]; ok && !utils.IntIn(newStatus, stateConf.CanEnterState) {
			logs.CtxInfo(ctx, "fillSkipNodeOpRecord, currentStatus:%d, newStatus:%d, nextStatus:%d", currentStatus, newStatus, stateConf.DefaultState)
			// 正常流转不补充自动跳过协作记录
			for _, reviewer := range reviewerMap[stateConf.DefaultState] {
				res = append(res, &model.ContractOperationRecordDB{
					PreContractNo:  record.PreContractNo,
					Operator:       reviewer.Reviewer,
					Operation:      _const.OperationAutomaticallySkip,
					ContractStatus: stateConf.DefaultState,
				})
			}
			currentStatus = stateConf.DefaultState
		} else {
			logs.CtxInfo(ctx, "fillSkipNodeOpRecord_break, currentStatus:%d, newStatus:%d", currentStatus, newStatus)
			break
		}
	}
	return res
}

func (e *engine) selectHandler(contractState int, opState int) handler.StatusOpHandler {
	m := e.statusHandleMappings[contractState]
	if len(m) == 0 {
		return nil
	}
	return m[opState]
}

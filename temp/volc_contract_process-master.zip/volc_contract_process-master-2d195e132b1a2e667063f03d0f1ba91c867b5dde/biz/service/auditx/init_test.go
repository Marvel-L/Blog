package auditx

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"testing"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/auditx/handler"
	"volc_contract_process/pkg/const"
)

type mockMultiStatusOpHandler struct {
	handler.MultiStatusOpHandler
}

func (m *mockMultiStatusOpHandler) SupportStatus() []int {
	logs.CtxInfo(context.Background(), "SupportStatus:%v", []int{})
	return []int{}
}

func (m *mockMultiStatusOpHandler) CurrentOp() int {
	logs.CtxInfo(context.Background(), "CurrentOp")
	return 0
}

func Test_getStatusReviewTypeMappings_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_getStatusReviewTypeMappings", t, func() {
		mockey.PatchConvey("should return correct status to review type mappings", func() {
			// 场景描述：
			// 本测试旨在验证 `getStatusReviewTypeMappings` 函数是否能返回预期的、硬编码的合同状态到审核人类型的映射关系。
			// 构造数据：
			// 无需构造特殊数据，函数内部返回一个静态map。
			// 逻辑链路：
			// 1. 调用 `getStatusReviewTypeMappings` 函数。
			// 2. 定义一个包含所有预期键值对的 `expected` map。
			// 3. 断言函数返回的 map 与 `expected` map完全一致。

			// 调用目标函数
			actualMappings := getStatusReviewTypeMappings()

			// 准备预期结果
			expectedMappings := map[int]int{
				_const.PreSalesContractDraft:                             _const.ReviewerTypeSalesperson,
				_const.PreSalesContractSendBack:                          _const.ReviewerTypeSalesperson,
				_const.PreSalesContractSolutionReview:                    _const.ReviewerTypeSolutionReviewer,
				_const.PreSalesContractSalesOperationReview:              _const.ReviewerTypeSalesOperation,
				_const.PreSalesContractFinanceTaxationLegalReview:        _const.ReviewerTypeFinanceTaxationLegalReviewer,
				_const.PreSalesContractCustomerConfirm:                   _const.ReviewerTypeSalesperson,
				_const.PreSalesContractChange:                            _const.ReviewerTypeSalesperson,
				_const.PreSalesContractSalesOperationCompleteInformation: _const.ReviewerTypeSalesOperation,
				_const.PreSalesContractFinanceTaxationLegalSignReview:    _const.ReviewerTypeFinanceTaxationLegalReviewer,
				_const.PreSalesContractRiskReview:                        _const.ReviewerTypeSalesOperation,
			}

			// 断言
			convey.So(actualMappings, convey.ShouldResemble, expectedMappings)
		})
	})
}

func Test_Graph_String_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test Graph.String", t, func() {
		mockey.PatchConvey("场景: 图的边列表为nil", func() {
			// 场景描述：
			// 构造数据：创建一个Graph实例，其Edges字段为nil。
			// 逻辑链路：
			// 1. 调用String()方法。
			// 2. for-range循环在nil切片上不会执行。
			// 3. strings.Join接收一个空切片，返回一个空字符串。
			g := &Graph{
				Edges: nil,
			}

			// 调用
			result := g.String()

			// 断言
			convey.So(result, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("场景: 图的边列表为空切片", func() {
			// 场景描述：
			// 构造数据：创建一个Graph实例，其Edges字段为一个空切片。
			// 逻辑链路：
			// 1. 调用String()方法。
			// 2. for-range循环在空切片上不会执行。
			// 3. strings.Join接收一个空切片，返回一个空字符串。
			g := &Graph{
				Edges: []*Edge{},
			}

			// 调用
			result := g.String()

			// 断言
			convey.So(result, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("场景: 图包含一条边", func() {
			// 场景描述：
			// 构造数据：创建一个Graph实例，包含一个起始节点、一个结束节点和一条连接它们的边。
			// 逻辑链路：
			// 1. 调用String()方法。
			// 2. for-range循环执行一次。
			// 3. fmt.Sprintf根据格式化字符串生成边的描述。
			// 4. strings.Join由于列表只有一个元素，直接返回该元素。
			nodeFrom := &Node{Name: "StartState", Value: 1}
			nodeTo := &Node{Name: "EndState", Value: 2}
			g := &Graph{
				Nodes: []*Node{nodeFrom, nodeTo},
				Edges: []*Edge{
					{
						EdgeName: "SubmitApplication",
						OpName:   "Submit",
						From:     nodeFrom,
						To:       nodeTo,
					},
				},
			}

			// 调用
			result := g.String()

			// 断言
			expected := fmt.Sprintf("%-40s: %-10s --- %-10s --> %-10s", "SubmitApplication", "StartState", "Submit", "EndState")
			convey.So(result, convey.ShouldEqual, expected)
		})

		mockey.PatchConvey("场景: 图包含多条边", func() {
			// 场景描述：
			// 构造数据：创建一个Graph实例，包含多个节点和多条边。
			// 逻辑链路：
			// 1. 调用String()方法。
			// 2. for-range循环执行多次，每次都将格式化后的字符串添加到列表中。
			// 3. strings.Join使用换行符将列表中的所有字符串连接起来。
			nodeA := &Node{Name: "StateA", Value: 1}
			nodeB := &Node{Name: "StateB", Value: 2}
			nodeC := &Node{Name: "StateC", Value: 3}
			edge1 := &Edge{
				EdgeName: "TransitionAtoB",
				OpName:   "Approve",
				From:     nodeA,
				To:       nodeB,
			}
			edge2 := &Edge{
				EdgeName: "TransitionBtoC",
				OpName:   "Finalize",
				From:     nodeB,
				To:       nodeC,
			}
			g := &Graph{
				Nodes: []*Node{nodeA, nodeB, nodeC},
				Edges: []*Edge{edge1, edge2},
			}

			// 调用
			result := g.String()

			// 断言
			line1 := fmt.Sprintf("%-40s: %-10s --- %-10s --> %-10s", edge1.EdgeName, edge1.From.Name, edge1.OpName, edge1.To.Name)
			line2 := fmt.Sprintf("%-40s: %-10s --- %-10s --> %-10s", edge2.EdgeName, edge2.From.Name, edge2.OpName, edge2.To.Name)
			expected := strings.Join([]string{line1, line2}, "\n")
			convey.So(result, convey.ShouldEqual, expected)
		})
	})
}

func TestGetGraph(t *testing.T) {
	// 测试handler.GetValidReviewerType返回nil的场景
	t.Run("GetValidReviewerTypeReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] getValidReviewerTypeRet1Mock == nil
			mockey.Mock(handler.GetValidReviewerType).Return(nil).Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			// [目标分支] len(_instanceMock.statusHandleMappings) > 0 && len(_instanceMock.statusHandleMappings[0]) > 0
			var _instanceMock *engine = &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					0: map[int]handler.StatusOpHandler{10: &mockStatusOpHandler{}},
				},
			}
			mockey.MockValue(&_instance).To(_instanceMock)
			// 运行被测函数
			got1 := GetGraph()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 由于mock了handler.GetValidReviewerType返回nil，在函数中会跳过创建Edge的逻辑，所以Edges切片长度为0
			convey.So(len((*got1).Edges), convey.ShouldEqual, 0)
			// 根据代码逻辑，会遍历_instanceMock.statusHandleMappings，即使handler.GetValidReviewerType返回nil，也会创建一个Node，所以Nodes切片长度为1
			convey.So(len((*got1).Nodes), convey.ShouldEqual, 1)
			// 函数GetGraph会创建并返回一个Graph对象，即使在handler.GetValidReviewerType返回nil的情况下，也会创建Graph对象，不会返回nil
			convey.So(got1, convey.ShouldNotBeNil)
		})
	})
	// 测试handler.GetValidReviewerType返回有效数据且_instance.statusHandleMappings有元素的场景
	t.Run("ValidReviewerTypeAndStatusHandleMappings", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] len(getValidReviewerTypeRet1Mock.ContractNewStatusMapOnSuccess) > 0 && getValidReviewerTypeRet1Mock.IgnoreUpdatePreContractStatus == true
			mockey.Mock(handler.GetValidReviewerType).Return(&modelcooperation.ReviewerStatusOpConf{
				IgnoreUpdatePreContractStatus: true,
				ContractNewStatusMapOnSuccess: map[string]int{"test": 10},
			}).Build()
			mockey.Mock(_const.GenOperateDesc).Return("Operation successful").Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			// [目标分支] len(_instanceMock.statusHandleMappings) > 0 && len(_instanceMock.statusHandleMappings[0]) > 0
			var _instanceMock *engine = &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					0: map[int]handler.StatusOpHandler{10: &mockStatusOpHandler{}},
				},
			}
			mockey.MockValue(&_instance).To(_instanceMock)
			// 运行被测函数
			got1 := GetGraph()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 根据测试环境的设置，函数会正常执行，不会返回nil值，因此got1不会为nil
			convey.So(got1, convey.ShouldNotBeNil)
			// 根据测试环境的设置，_instanceMock.statusHandleMappings中有一个元素，并且handler.GetValidReviewerType返回的ContractNewStatusMapOnSuccess有一个元素，所以会生成一条边
			convey.So(len(got1.Edges), convey.ShouldEqual, 1)
			// 根据测试环境的设置，_instanceMock.statusHandleMappings中有一个元素，并且handler.GetValidReviewerType返回的ContractNewStatusMapOnSuccess有一个元素，所以会生成一个节点
			convey.So(len(got1.Nodes), convey.ShouldEqual, 1)
		})
	})
	// 测试输入有效的状态处理映射和有效审核人类型信息的场景
	t.Run("GetGraphWithValidStatusMappings", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] getValidReviewerTypeRet1Mock.IgnoreUpdatePreContractStatus == true && len(getValidReviewerTypeRet1Mock.ContractNewStatusMapOnSuccess) > 0
			mockey.Mock(handler.GetValidReviewerType).Return(&modelcooperation.ReviewerStatusOpConf{
				IgnoreUpdatePreContractStatus: false,
				ContractNewStatusMapOnSuccess: map[string]int{"test": 10},
			}).Build()
			mockey.Mock(_const.GenOperateDesc).Return("Operation successful").Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			// [目标分支] len(_instanceMock.statusHandleMappings) > 0 && len(_instanceMock.statusHandleMappings[0]) > 0
			var _instanceMock *engine = &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					0: map[int]handler.StatusOpHandler{10: &mockStatusOpHandler{}},
				},
			}
			mockey.MockValue(&_instance).To(_instanceMock)
			// 运行被测函数
			got1 := GetGraph()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 根据测试代码，已对相关函数进行mock，且_instanceMock.statusHandleMappings有值，函数会正常创建Graph对象并返回，所以返回值不为nil
			convey.So(got1, convey.ShouldNotBeNil)
			// 在测试环境下，_instanceMock.statusHandleMappings中有一个元素，且handler.GetValidReviewerType返回的ContractNewStatusMapOnSuccess有值，会创建一条边，所以边的数量为1
			convey.So(len(got1.Edges), convey.ShouldEqual, 1)
			// 函数中会根据fromStatus和ContractNewStatusMapOnSuccess中的值创建节点，这里fromStatus为0，ContractNewStatusMapOnSuccess中有一个值为10，所以会创建两个节点
			convey.So(len(got1.Nodes), convey.ShouldEqual, 1)
		})
	})
}

func TestInit_BitsUTGen(t *testing.T) {

	resetGlobals := func() {
		once = sync.Once{}
		_instance = nil
	}

	mockey.PatchConvey("Test Init", t, func() {
		mockey.PatchConvey("success case: initialization with valid handlers", func() {
			resetGlobals()

			mockH1 := &mockStatusOpHandler{}
			mockMultiH1 := &mockMultiStatusOpHandler{}

			mockey.Mock(handler.AllHandlers).Return([]handler.StatusOpHandler{
				mockH1,
				mockMultiH1,
			}).Build()

			mockey.Mock((*mockStatusOpHandler).CurrentStatus).Return(1).Build()

			mockey.Mock((*mockMultiStatusOpHandler).SupportStatus).Return([]int{2, 3}).Build()

			mockey.Mock((*mockStatusOpHandler).CurrentOp).Return(10).Build()
			mockey.Mock((*mockMultiStatusOpHandler).CurrentOp).Return(20).Build()

			mockey.Mock(GetGraph).Return(&Graph{}).Build()
			mockey.Mock((*Graph).String).Return("mock graph string").Build()
			mockey.Mock(logs.Info).Return().Build()

			err := Init()

			convey.So(err, convey.ShouldBeNil)
			convey.So(_instance, convey.ShouldNotBeNil)
			convey.So(_instance.statusHandleMappings, convey.ShouldNotBeEmpty)

			convey.So(_instance.statusHandleMappings[1][10], convey.ShouldEqual, mockH1)
			convey.So(_instance.statusHandleMappings[2][20], convey.ShouldEqual, mockMultiH1)
			convey.So(_instance.statusHandleMappings[3][20], convey.ShouldEqual, mockMultiH1)
		})

		mockey.PatchConvey("failure case: initialization with duplicate handlers", func() {
			resetGlobals()

			mockH1 := &mockStatusOpHandler{}
			mockH2 := &mockStatusOpHandler{}

			mockey.Mock(handler.AllHandlers).Return([]handler.StatusOpHandler{
				mockH1,
				mockH2,
			}).Build()

			mockey.Mock((*mockStatusOpHandler).CurrentStatus).Return(1).Build()
			mockey.Mock((*mockStatusOpHandler).CurrentOp).Return(10).Build()

			mockey.Mock(logs.Errorf).Return().Build()

			err := Init()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "审批引擎初始化失败")
			convey.So(_instance, convey.ShouldBeNil)
		})
	})
}

func Test_register_BitsUTGen(t *testing.T) {
	// MockStatusOpHandler is a mock for the handler.StatusOpHandler interface.
	// It's used to test scenarios with single-status handlers.
	type MockStatusOpHandler struct {
		handler.StatusOpHandler
	}

	// MockMultiStatusOpHandler is a mock for the handler.MultiStatusOpHandler interface.
	// It's used to test scenarios with multi-status handlers.
	type MockMultiStatusOpHandler struct {
		handler.MultiStatusOpHandler
	}

	mockey.PatchConvey("Test register", t, func() {
		mockey.PatchConvey("Scenario: Register a simple handler (not MultiStatusOpHandler) successfully", func() {
			// 场景描述：
			// 测试当注册一个普通的、非多状态的处理器时，能够成功注册。
			// 构造数据：
			// - mappings: 一个空的映射表。
			// - h: 一个实现了 StatusOpHandler 接口的 mock 处理器。
			// 逻辑链路：
			// 1. 对 h 进行类型断言，判断其是否为 MultiStatusOpHandler，结果为 false。
			// 2. 进入 else 分支，调用 h.CurrentStatus() 获取当前状态。
			// 3. 检查 mappings 中是否存在该状态的映射，如果不存在，则创建一个新的。
			// 4. 调用 h.CurrentOp() 获取操作码，检查是否存在重复处理器，结果为 false。
			// 5. 将处理器 h 注册到 mappings[status][op] 中。
			// 6. 函数返回 nil。

			mappings := make(map[int]map[int]handler.StatusOpHandler)
			var h handler.StatusOpHandler = &MockStatusOpHandler{}

			mockey.Mock((*MockStatusOpHandler).CurrentStatus).Return(10).Build()
			mockey.Mock((*MockStatusOpHandler).CurrentOp).Return(1).Build()

			err := register(mappings, h)

			convey.So(err, convey.ShouldBeNil)
			convey.So(mappings[10][1], convey.ShouldEqual, h)
		})

		mockey.PatchConvey("Scenario: Registering a simple handler fails due to duplication", func() {
			// 场景描述：
			// 测试当注册一个普通处理器时，如果目标 status 和 op 已被注册，则会返回错误。
			// 构造数据：
			// - mappings: 预先包含一个针对特定 status 和 op 的处理器。
			// - h: 一个新的 mock 处理器，其 status 和 op 与已存在的处理器相同。
			// 逻辑链路：
			// 1. 类型断言为 MultiStatusOpHandler 失败。
			// 2. 调用 h.CurrentStatus() 和 h.CurrentOp() 获取状态和操作。
			// 3. 在 mappings 中检查，发现 status 和 op 的组合已存在。
			// 4. 返回一个 "duplicate handler" 错误。

			existingHandler := &MockStatusOpHandler{}
			mappings := map[int]map[int]handler.StatusOpHandler{
				10: {1: existingHandler},
			}
			var h handler.StatusOpHandler = &MockStatusOpHandler{}

			mockey.Mock((*MockStatusOpHandler).CurrentStatus).Return(10).Build()
			mockey.Mock((*MockStatusOpHandler).CurrentOp).Return(1).Build()

			err := register(mappings, h)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "duplicate handler, status:10, op:1")
			convey.So(mappings[10][1], convey.ShouldEqual, existingHandler) // 确保原有处理器未被覆盖
		})

		mockey.PatchConvey("Scenario: Register a multi-status handler successfully", func() {
			// 场景描述：
			// 测试当注册一个多状态处理器时，能够成功为所有支持的状态注册该处理器。
			// 构造数据：
			// - mappings: 一个空的映射表。
			// - h: 一个实现了 MultiStatusOpHandler 接口的 mock 处理器。
			// 逻辑链路：
			// 1. 对 h 进行类型断言，判断其是否为 MultiStatusOpHandler，结果为 true。
			// 2. 调用 h.SupportStatus() 获取一个状态列表。
			// 3. 遍历状态列表，对每个状态执行注册逻辑。
			// 4. 调用 h.CurrentOp() 获取操作码。
			// 5. 对于每个状态，检查 mappings 中是否存在重复处理器，结果为 false。
			// 6. 将处理器 h 注册到所有支持的状态和操作码下。
			// 7. 函数返回 nil。

			mappings := make(map[int]map[int]handler.StatusOpHandler)
			var h handler.StatusOpHandler = &MockMultiStatusOpHandler{}

			mockey.Mock((*MockMultiStatusOpHandler).SupportStatus).Return([]int{20, 30}).Build()
			mockey.Mock((*MockMultiStatusOpHandler).CurrentOp).Return(2).Build()

			err := register(mappings, h)

			convey.So(err, convey.ShouldBeNil)
			convey.So(mappings[20][2], convey.ShouldEqual, h)
			convey.So(mappings[30][2], convey.ShouldEqual, h)
		})

		mockey.PatchConvey("Scenario: Registering a multi-status handler fails due to duplication", func() {
			// 场景描述：
			// 测试当注册一个多状态处理器时，如果其支持的某个 status 和 op 已被注册，则会返回错误。
			// 构造数据：
			// - mappings: 预先包含一个处理器，其 status 和 op 与新处理器支持的其中一个状态组合冲突。
			// - h: 一个新的多状态 mock 处理器。
			// 逻辑链路：
			// 1. 类型断言为 MultiStatusOpHandler 成功。
			// 2. 调用 h.SupportStatus() 获取状态列表 [20, 30]。
			// 3. 遍历列表，第一个状态 20 注册成功。
			// 4. 第二个状态 30 检查时，发现 status 和 op 的组合已存在。
			// 5. 返回一个 "duplicate handler" 错误，循环终止。

			existingHandler := &MockStatusOpHandler{}
			mappings := map[int]map[int]handler.StatusOpHandler{
				30: {2: existingHandler},
			}
			var h handler.StatusOpHandler = &MockMultiStatusOpHandler{}

			mockey.Mock((*MockMultiStatusOpHandler).SupportStatus).Return([]int{20, 30}).Build()
			mockey.Mock((*MockMultiStatusOpHandler).CurrentOp).Return(2).Build()

			err := register(mappings, h)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "duplicate handler, status:30, op:2")
			convey.So(mappings[20][2], convey.ShouldEqual, h)               // 检查不冲突的状态是否已注册
			convey.So(mappings[30][2], convey.ShouldEqual, existingHandler) // 检查冲突的状态是否未被覆盖
		})

		mockey.PatchConvey("Scenario: Register a handler when status mapping is nil", func() {
			// 场景描述：
			// 测试当注册处理器到一个新的 status 时，能够正确初始化内部的 map。
			// 构造数据：
			// - mappings: 一个空的映射表。
			// - h: 一个普通的 mock 处理器。
			// 逻辑链路：
			// 1. 类型断言失败。
			// 2. 获取 status 和 op。
			// 3. 在 mappings 中查找 status 对应的 map，得到 nil。
			// 4. 进入 `if statusMapping == nil` 分支，初始化一个新的 map。
			// 5. 成功注册处理器。
			// 6. 函数返回 nil。

			mappings := make(map[int]map[int]handler.StatusOpHandler)
			var h handler.StatusOpHandler = &MockStatusOpHandler{}

			mockey.Mock((*MockStatusOpHandler).CurrentStatus).Return(100).Build()
			mockey.Mock((*MockStatusOpHandler).CurrentOp).Return(10).Build()

			err := register(mappings, h)

			convey.So(err, convey.ShouldBeNil)
			convey.So(mappings[100], convey.ShouldNotBeNil)
			convey.So(mappings[100][10], convey.ShouldEqual, h)
		})
	})
}

func TestInit(t *testing.T) {
	Init()
}

// MockStatusOpHandler is a mock for the handler.StatusOpHandler interface.
// It's used to test scenarios with single-status handlers.
type mockStatusOpHandler struct {
	handler.StatusOpHandler
}

func (m *mockStatusOpHandler) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "Process")
	return nil
}

func (m *mockStatusOpHandler) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	logs.CtxInfo(ctx, "HitStateChangeCondition")
	return false, nil
}

func (m *mockStatusOpHandler) SaveProcessFileNestVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "SaveProcessFileNestVersion")
	return nil
}

func (m *mockStatusOpHandler) CurrentStatus() int {
	logs.CtxInfo(context.Background(), "CurrentStatus:%d", 0)
	return 0
}

func (m *mockStatusOpHandler) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "PostProcess")
	return nil
}

func (m *mockStatusOpHandler) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "Validate")
	return nil
}

func (m *mockStatusOpHandler) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	logs.CtxInfo(ctx, "GetStatusOpConfKey")
	return ""
}

func (m *mockStatusOpHandler) SaveStatusChangeFileVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "SaveStatusChangeFileVersion")
	return nil
}

func (m *mockStatusOpHandler) CurrentOp() int {
	logs.CtxInfo(context.Background(), "CurrentOp")
	return 0
}

package handler

import (
	"context"
	"strings"
	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	utils "volc_contract_process/pkg/util"
)

func newHandlerSolutionReviewPass() StatusOpHandler {
	return &handlerSolutionReviewPass{}
}

// 解决方案审核(101) --- 通过(2) --> 财税法交付专业审核(4)
type handlerSolutionReviewPass struct {
	handlerCommon
}

func (h handlerSolutionReviewPass) CurrentStatus() int {
	return _const.PreSalesContractSolutionReview
}

func (h handlerSolutionReviewPass) CurrentOp() int {
	return _const.OperationReviewPass
}

func (h handlerSolutionReviewPass) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h handlerSolutionReviewPass) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h handlerSolutionReviewPass) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

func (h handlerSolutionReviewPass) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.reviewPassSendReviewedMessage(ctx, pc); err != nil {
		logs.CtxError(ctx, "SendReviewedMessageFail, err:%s", err.Error())
		return err
	}
	if pc.StatusChanged {
		// 发送飞书消息
		multiCtx := context.Background()
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeFinanceTaxationLegalReviewer, pc.StatusChangedValue),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	}
	return nil
}

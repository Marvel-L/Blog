package handler

import (
	"context"
	"strings"
	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	utils "volc_contract_process/pkg/util"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerFTLReviewPass() StatusOpHandler {
	return &handlerFTLReviewPass{}
}

// 财税法交付专业审核(4) --- 审核通过(2) --> 销售确认中(5)
type handlerFTLReviewPass struct {
	handlerCommon
}

func (h *handlerFTLReviewPass) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalReview
}

func (h *handlerFTLReviewPass) CurrentOp() int {
	return _const.OperationReviewPass
}

func (h *handlerFTLReviewPass) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if !_const.IsValidSkipReturnReviewType(pc.SkipReturnReview) {
		return i18nfmt.New(ctx, "SkipReturnReview字段异常")
	}
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h *handlerFTLReviewPass) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	return nil
}

func (h *handlerFTLReviewPass) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

func (h *handlerFTLReviewPass) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.reviewPassSendReviewedMessage(ctx, pc); err != nil {
		logs.CtxError(ctx, "SendReviewedMessageFail, err:%s", err.Error())
		return err
	}
	if pc.StatusChanged {
		// 发送飞书消息，给销售的消息，国内需要去掉
		multiCtx := context.Background()
		if multienv.IsBytePlus() {
			larkc.BatchSendMessageToEmailIgnore(ctx,
				h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson, pc.StatusChangedValue),
				larkc.MsgTypeInteractive,
				larkc.NewCommonMessageCardBuilder().
					SetTitleColor(larkc.TitleColorWathet).
					SetTitle(multienv.I18nFormat(multiCtx, "合同待确认提醒")).
					SetContent(i18nfmt.Sprintf(multiCtx, "%s 提交的合同已完成我方内部协商审核，待您与客户确认，请您及时前往后台进行操作", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
					AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
					AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
					AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
					AddAction(multienv.I18nFormat(multiCtx, "查看详情"), larkc.GenCRMDetailURL(ctx, pc.PreContractVO.ContractNo)).
					BuildJSONString())
		}
		// 新增 合同创建人 发送飞书消息提醒 默认取 销售运营完善信息节点 主审核人
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers,
				_const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationCompleteInformation),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "财税法交付专业审核完成提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同已完成“财税法交付专业审核”，目前待发起人确认审核意见并反馈。", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "查看详情"), larkc.GenReviewURL(ctx, pc.PreContractVO.ContractNo)).
				BuildJSONString())
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeFTLReviewPass, pc)
	}
	return nil
}

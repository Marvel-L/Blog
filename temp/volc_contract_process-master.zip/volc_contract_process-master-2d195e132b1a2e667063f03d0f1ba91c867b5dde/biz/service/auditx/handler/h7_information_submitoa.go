package handler

import (
	"context"
	"time"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/support/metacommodity"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/quotecli"

	"code.byted.org/gopkg/logs"
)

func newHandlerInformationSubmitOA() StatusOpHandler {
	return &handlerInformationSubmitOA{}
}

// 销售运营完善信息(7) --- 提交OA(13) --> 提交OA(8)
type handlerInformationSubmitOA struct {
	handlerCommon
}

func (h *handlerInformationSubmitOA) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationCompleteInformation
}

func (h *handlerInformationSubmitOA) CurrentOp() int {
	return _const.OperationSubmitOA
}

func (h *handlerInformationSubmitOA) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 海外 或者 非海外使用模板的合同, 允许提交飞书
	if !env.IsBytePlus() && pc.ApprovalKey != _const.ApprovalKeyCooperationQuote {
		return errorsV2.ErrCommon.WithArgs("国内暂不支持此操作")
	}
	// “关联报价单场景 = 未完成报价审批”，不允许操作提交飞书合同
	if pc.ContractInfo.RelateQuoteScene == _const.RelateQuoteSceneNoCompleted {
		return errorsV2.ErrInternalError.WithArgs("关联报价单场景 = 未完成报价审批，不允许操作提交飞书合同")
	}
	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}

	// 校验返券规则有效期与返券周期
	err := h.commonCheckValidityAndRebatePeriod(ctx, pc)
	if err != nil {
		logs.CtxError(ctx, "校验返券规则有效期与返券周期失败，ContractNo：%s， err：%v", pc.ContractInfo.ContractNo, err)
		return err
	}

	// 校验返券规则有效期与合同有效期
	if err := h.checkAndCorrectCouponValiditySubset(ctx, pc); err != nil {
		logs.CtxError(ctx, "校验返券规则有效期与合同有效期交集失败，ContractNo：%s， err：%v", pc.ContractInfo.ContractNo, err)
		return err
	}

	// 绑定报价单场景 校验合同有效期与报价单有效期
	// 校验账号ID CRM侧在“定稿”时校验必填，合同侧在“销售运营完善信息”时校验必填。
	contractInfo := pc.ContractInfo
	contractVO := pc.PreContractVO

	// 校验是否项目制必填 & 且要求与报价单保持一致
	if len(contractInfo.BasicInfo.WhetherProject) == 0 {
		return errorsV2.ErrMissingParam.WithArgs("WhetherProject")
	}

	// 关联报价单场景
	if contractInfo.NeedRelateQuoteNo() {
		if contractInfo.RelateQuoteNo == "" {
			return errorsV2.ErrQuoteCommon.WithArgs("当前合同必须关联报价单")
		}
		for _, otherParty := range contractInfo.TradePartyInfo.OtherParty {
			// 仅校验主签约主体账号
			if otherParty.IsDeputyParty() {
				continue
			}
			if len(otherParty.AccountID) == 0 {
				return i18nfmt.New(ctx, "合同账号ID缺失")
			}
		}
		info, err := quotecli.GetQuoteInfo(ctx, contractInfo.RelateQuoteNo)
		if err != nil {
			return i18nfmt.New(ctx, "查询报价单失败")
		}
		if info == nil {
			return i18nfmt.Errorf(ctx, "关联的报价单[%s]不存在", contractInfo.RelateQuoteNo)
		}
		// 指定合同有效期
		if err := validateUsefulLifeType(ctx, pc.PreContractVO, info, contractInfo.BasicInfo, contractInfo.ManageInfo); err != nil {
			logs.CtxError(ctx, "校验合同有效期类型信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
			return err
		}
		// 检验账号分组信息
		if err := validateAccountAssociationInfo(ctx, contractInfo.ManageInfo, contractInfo.TradePartyInfo); err != nil {
			logs.CtxError(ctx, "校验账号ID分组信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
			return err
		}
		if contractInfo.BasicInfo.WhetherProject != contractInfo.ManageInfo.WhetherProject {
			return errorsV2.ErrCommon.WithArgs("合同是否项目制标识需与报价单保持一致")
		}
	}
	if err := contractInfo.BasicInfo.ValidateContractPeriod(ctx, _const.SalesContractUnSubmit); err != nil {
		logs.CtxError(ctx, "校验合同有效期类型信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateTradePartyInfo(ctx, contractInfo.BasicInfo, contractInfo.TradePartyInfo); err != nil {
		logs.CtxError(ctx, "校验交易对方信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateRiskClauseRole(ctx, pc.GetTx(), contractInfo.ContractNo); err != nil {
		logs.CtxError(ctx, "校验风险条款条目信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateProjectInfo(ctx, pc.ContractInfo); err != nil {
		logs.CtxError(ctx, "校验项目信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateTermChangeDetail(ctx, pc.GetTx(), pc.PreContractVO); err != nil {
		logs.CtxError(ctx, "校验条款变更详情失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := contractInfo.ManageInfo.ValidateExternalCommodity(ctx); err != nil {
		logs.CtxError(ctx, "校验外部商品信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := metacommodity.ValidateInvoiceTaxRateForManageInfo(ctx, contractInfo.ManageInfo, contractInfo.RelateQuoteNo); err != nil {
		logs.CtxError(ctx, "校验开票项税率失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateManageInfo(ctx, contractInfo, contractInfo.ManageInfo); err != nil {
		logs.CtxError(ctx, "校验管理信息信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateMetaExt(ctx, contractInfo, contractVO, pc.Ext); err != nil {
		logs.CtxError(ctx, "校验合同附加信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}

	// 校验账号关联我方主体
	if err := h.getMetaServiceV2(ctx).CheckRelateSubjectParty(ctx, &contractmeta.CheckRelateSubjectPartyReq{
		BizSource:           _const.BizSourceCooperation,
		CooperationStatus:   contractInfo.CooperationStatus,
		SpecialContractType: contractInfo.BasicInfo.SpecialContractType,
		BusinessType:        contractInfo.BasicInfo.BusinessType,
		TradePartyInfo:      contractInfo.TradePartyInfo,
	}); err != nil {
		logs.CtxError(ctx, "CheckRelateSubjectPartyFail, err:%v", err)
		return err
	}

	if err := validateAccountIdRequired(ctx, contractInfo); err != nil {
		logs.CtxError(ctx, "账号ID必填校验失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}

	if (contractVO.InOutType == _const.BizInOutTypeIn || contractVO.InOutType == _const.BizInOutTypeInAndOut) &&
		contractVO.BizSource != _const.BizSourceQuote {
		// 自采平台，无结算条款记录行
		if contractInfo.Initiator != _const.InitiatorSelfPurchase {
			settlementLines, err := dal.NewContractSettlementDao().ListContractSettlementByContractID(ctx, pc.GetTx(), int(contractVO.Id))
			if err != nil {
				return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListContractSettlementByContractID_Fail:%v", err))
			}
			if len(settlementLines) == 0 {
				return i18nfmt.New(ctx, "当合同收支类型为“收入类” / “既收又支”时，结算条款模块必填")
			}
		}
	}
	return h.IsReverseContract(ctx, pc.PreContractVO)
}

func (h *handlerInformationSubmitOA) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	pc.PreContractVO.SubmitTime = time.Now()
	// pc.ContractInfo.SubmitTime = time.Now()
	// 提交合规审查
	if err := h.SubmitComplianceCheck(ctx, pc); err != nil {
		return err
	}
	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		logs.CtxError(ctx, "UpdateContractDataFail, err:%s", err.Error())
		return errorsV2.ErrCommon.WithArgs(err.Error())
	}
	return nil
}

func (h *handlerInformationSubmitOA) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerInformationSubmitOA) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.StatusChangedValue != _const.PreSalesContractComplianceCheck {
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeInformationPass, pc)
		// 若变更后状态非合规审查中，需提交OA
		return h.SendSubmitOaMsg(ctx, pc)
	}
	return nil
}

// GetStatusOpConfKey 获取状态操作配置键
// 实现逻辑：
//  1. 当流程上下文缺少合规审查信息时，返回默认状态配置键
//  2. 当交易未被拒绝时，返回合规审查状态配置键
//  3. 其他情况返回默认状态配置键
//
// 参数：
//   - ctx 上下文对象
//   - pc 流程上下文对象
//
// 返回值：
//   - 状态配置键字符串
func (h *handlerInformationSubmitOA) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	// 兜底逻辑，流转至默认状态
	if pc.ComplianceCheckInfo == nil {
		return _const.ApprovalStatusKeyDefault
	}
	// 命中人审时，默认流转至合规审查中
	if pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction {
		return _const.ApprovalStatusKeyComplianceCheck
	}
	// 未命中人审时，流转至默认状态，根据配置处理
	return _const.ApprovalStatusKeyDefault
}

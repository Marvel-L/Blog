package handler

import (
	"context"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_handlerSalesReviewWithdraw_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_Validate", t, func() {
		h := &handlerSalesReviewWithdraw{}
		ctx := context.Background()

		mockey.PatchConvey("场景：撤回原因为空，校验不通过", func() {
			// 场景描述：当撤回原因(pc.Comment)为空时，函数应返回错误。
			// 构造数据：
			// - pc: 一个 auditmodel.ProcessCtx 实例。
			// - pc.Comment: 一个 bizmodels.RichTextInfo 实例。
			// 逻辑链路：
			// 1. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 true。
			// 2. 调用 Validate 方法。
			// 3. 函数进入第一个if分支，返回 "撤回原因不可为空" 错误。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "撤回原因不可为空")
		})

		mockey.PatchConvey("场景：审核未通过，不可撤回", func() {
			// 场景描述：当前操作员的审核状态不为“通过”，此时不允许撤回，函数应返回错误。
			// 构造数据：
			// - pc.Comment: 不为空。
			// - pc.ContractInfo.Reviewers: 包含一个审核人，其信息与当前操作员匹配，且状态不为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false。
			// 2. for循环遍历 Reviewers。
			// 3. 在循环中，if 条件（reviewer.Reviewer == pc.CurrentOperator && ... && reviewer.Status != _const.ReviewStatusReviewPass）为 true。
			// 4. 函数进入if分支，返回 "审核未通过，不可撤回" 错误。
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.operator",
				Comment:         &bizmodels.RichTextInfo{Richtext: "some comment"},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test.operator",
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							Status:         _const.ReviewStatusUnreviewed, // 重点：状态不是“通过”
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核未通过，不可撤回")
		})

		mockey.PatchConvey("场景：校验通过 - 审核已通过，可以撤回", func() {
			// 场景描述：当前操作员的审核状态为“通过”，可以撤回，函数应返回 nil。
			// 构造数据：
			// - pc.Comment: 不为空。
			// - pc.ContractInfo.Reviewers: 包含一个审核人，其信息与当前操作员匹配，且状态为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false。
			// 2. for循环遍历 Reviewers。
			// 3. 在循环中，if 条件中的 reviewer.Status != _const.ReviewStatusReviewPass 为 false，导致整个if条件为 false。
			// 4. 循环结束，未进入任何错误返回分支。
			// 5. 函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.operator",
				Comment:         &bizmodels.RichTextInfo{Richtext: "some comment"},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test.operator",
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							Status:         _const.ReviewStatusReviewPass, // 重点：状态是“通过”
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：校验通过 - 没有匹配的审核人", func() {
			// 场景描述：审核人列表中没有需要校验的审核人，函数应返回 nil。
			// 构造数据：
			// - pc.Comment: 不为空。
			// - pc.ContractInfo.Reviewers: 包含的审核人均不满足if判断的全部条件。
			// 逻辑链路：
			// 1. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false。
			// 2. for循环遍历 Reviewers。
			// 3. 循环中，所有审核人的if条件均为 false。
			// 4. 循环结束，未进入任何错误返回分支。
			// 5. 函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.operator",
				Comment:         &bizmodels.RichTextInfo{Richtext: "some comment"},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{ // 审核员不匹配
							Reviewer:       "other.operator",
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							Status:         _const.ReviewStatusUnreviewed,
						},
						{ // 合同状态不匹配
							Reviewer:       "test.operator",
							ContractStatus: _const.PreSalesContractCustomerConfirm,
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							Status:         _const.ReviewStatusUnreviewed,
						},
						{ // 审核员类型不匹配
							Reviewer:       "test.operator",
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							Status:         _const.ReviewStatusUnreviewed,
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：校验通过 - 审核人列表为空", func() {
			// 场景描述：合同没有审核人列表，函数应返回 nil。
			// 构造数据：
			// - pc.Comment: 不为空。
			// - pc.ContractInfo.Reviewers: 为空列表。
			// 逻辑链路：
			// 1. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false。
			// 2. for循环不执行。
			// 3. 函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.operator",
				Comment:         &bizmodels.RichTextInfo{Richtext: "some comment"},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewWithdraw_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_PostProcess", t, func() {
		mockey.PatchConvey("正常场景: 函数直接返回nil", func() {
			// 场景描述:
			// PostProcess函数当前实现为空, 逻辑上直接返回nil。
			// 构造数据:
			// - h: 一个空的handlerSalesReviewWithdraw实例。
			// - ctx: 一个空的context.Context。
			// - pc: 一个空的auditmodel.ProcessCtx。
			// 逻辑链路:
			// 1. 调用PostProcess方法。
			// 2. 断言返回的error为nil。

			// 准备数据
			h := &handlerSalesReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerSalesReviewWithdraw_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSalesReviewWithdraw", t, func() {
		mockey.PatchConvey("正常调用", func() {
			// 场景描述:
			// 正常调用 newHandlerSalesReviewWithdraw 函数
			// 构造数据:
			// 无
			// 逻辑链路:
			// 1. 调用 newHandlerSalesReviewWithdraw 函数
			// 2. 断言返回的实例不为nil
			// 3. 断言返回的实例类型为*handlerSalesReviewWithdraw

			// 调用目标函数
			handler := newHandlerSalesReviewWithdraw()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewWithdraw{})
		})
	})
}

func Test_handlerSalesReviewWithdraw_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 构造数据: 无特殊构造。
			// 逻辑链路:
			// 1. 创建一个 handlerSalesReviewWithdraw 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回的状态等于预期的常量 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewWithdraw{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_handlerSalesReviewWithdraw_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewWithdraw", func() {
			// 场景描述：
			// 测试 handlerSalesReviewWithdraw 的 CurrentOp 方法是否正确返回预期的操作类型常量。
			// 构造数据：
			// 初始化一个 handlerSalesReviewWithdraw 实例。
			// 逻辑链路：
			// 1. 创建 handlerSalesReviewWithdraw 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationReviewWithdraw。

			h := &handlerSalesReviewWithdraw{}

			op := h.CurrentOp()

			convey.So(op, convey.ShouldEqual, _const.OperationReviewWithdraw)
		})
	})
}

func Test_handlerSalesReviewWithdraw_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_Process", t, func() {
		mockey.PatchConvey("Normal case", func() {
			// 场景描述：
			// 这是一个正常的处理流程，函数直接返回nil
			// 构造数据：
			// - 初始化 handlerSalesReviewWithdraw
			// - 初始化 context
			// - 初始化 ProcessCtx
			// 逻辑链路：
			// 1. 调用 Process 方法
			// 2. 断言返回的 error 为 nil

			h := &handlerSalesReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewWithdraw_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdraw_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数直接返回 (false, nil)，不依赖任何输入参数或外部调用。
			// 构造数据：
			// - h: 一个空的 handlerSalesReviewWithdraw 实例。
			// - ctx: context.Background()。
			// - pc: 一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的 error 为 nil。
			h := &handlerSalesReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			got, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

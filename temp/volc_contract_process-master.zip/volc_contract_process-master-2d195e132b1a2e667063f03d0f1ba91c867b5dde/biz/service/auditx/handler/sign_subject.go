package handler

// NeedCheckRelateSubjectPartyByTradePartyChange 校验关联主体前置条件判断，交易方信息是否发生变化
//func NeedCheckRelateSubjectPartyByTradePartyChange(old, new *bizmodels.TradePartyInfo) bool {
//	oldAccountSet := old.GetSealPartyAccounts()
//	newAccountSet := new.GetSealPartyAccounts()
//	oldNumSet := old.GetSubjectPartyNumber()
//	newNumSet := new.GetSubjectPartyNumber()
//	// 交易双方信息中的我方主体发生变化，或者签约对方主体账号发生变化时，需要校验
//	if !utils.EqualStringSet(oldAccountSet, newAccountSet) || !utils.EqualStringSet(oldNumSet, newNumSet) {
//		return true
//	}
//	return false
//}

// GetEffectiveSubjectMap 获取可签约的我方主体信息，存在账号对应主体为空的场景，需注意
// 使用时需注意，查询审批通过的签约主体时，若不存在签约主体，需返回空，不可返回默认我方主体
//func GetEffectiveSubjectMap(ctx context.Context, req *auditmodel.GetEffectiveSubjectMapReq) (map[string]*bizmodels.TradePartyInfoDetail, errors.APIError) {
//	var (
//		res = map[string]*bizmodels.TradePartyInfoDetail{}
//		err errors.APIError
//	)
//	if shouldQuerySubject(req.BusinessType) {
//		// 查询签约主体管理服务（复用现有工程中的查询方式）
//		res, err = QuerySignSubjectMap(ctx, req.SpecialContractType, req.AccountIDs)
//		if err != nil {
//			return nil, err
//		}
//	} else {
//		// 非直销场景使用默认主体（与现有环境判断逻辑一致）
//		for _, accountID := range req.AccountIDs {
//			res[accountID] = GetDefaultSubject()
//		}
//	}
//	return res, nil
//}

// CheckRelateSubjectParty 校验关联主体与我方主体关系
//func CheckRelateSubjectParty(ctx context.Context, req *auditmodel.CheckRelateSubjectPartyReq) errors.APIError {
//	logs.CtxInfo(ctx, "CheckRelateSubjectParty, req:%s", utils.ToJSON(req))
//	if IsDisableSignSubjectCheck(ctx) {
//		logs.CtxInfo(ctx, "skip subject check, BizSource:%v", req.BizSource)
//		return nil
//	}
//	// 前置条件校验，伙伴入驻、伙伴报价 不需要校验
//	if !needCheckSubject(req) {
//		logs.CtxInfo(ctx, "skip subject check, BizSource:%v", req.BizSource)
//		return nil
//	}
//
//	// 获取需要校验的账号ID（与合同参数中的签约主体信息关联）
//	// “是否需要签约 = 是”的主体不存在“客户自助注册”的账号ID时，不需要校验
//	checkAccounts, err := getSealPartySaleCreateAccountIDs(ctx, req.TradePartyInfo)
//	if err != nil {
//		return err
//	}
//	if len(checkAccounts) == 0 {
//		logs.CtxInfo(ctx, "no need check subject, BizSource:%v, accountIDs:%v", req.BizSource)
//		return nil
//	}
//
//	// 我方主体信息构建
//	expectedSubjectMap, err := GetEffectiveSubjectMap(ctx, &auditmodel.GetEffectiveSubjectMapReq{
//		BusinessType:        req.BusinessType,
//		SpecialContractType: req.SpecialContractType,
//		AccountIDs:          checkAccounts,
//	})
//	if err != nil {
//		return err
//	}
//	logs.CtxInfo(ctx, "GetEffectiveSubjectMap, expectedSubjectMap:%s", utils.ToJSON(expectedSubjectMap))
//	// 主体对比校验（与合同参数中的主体信息对比）
//	if util.StringIn(_const.SpecialContractTypeSubjectChangeAgreement, strings.Split(req.SpecialContractType, ",")) {
//		err = checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//	} else {
//		err = checkSubjectCommon(ctx, req, expectedSubjectMap)
//	}
//	if err != nil {
//		logs.CtxError(ctx, "checkSubjectFail, err:%v", err)
//		return err
//	}
//	logs.CtxInfo(ctx, "CheckRelateSubjectParty success")
//	return nil
//}

// checkSubjectWithSubjectChangeAgreement 校验关联主体与我方主体关系-我方主体变更协议
//func checkSubjectWithSubjectChangeAgreement(ctx context.Context, req *auditmodel.CheckRelateSubjectPartyReq,
//	expectedSubjectMap map[string]*bizmodels.TradePartyInfoDetail) errors.APIError {
//	logs.CtxInfo(ctx, "checkSubjectWithSubjectChangeAgreement, req:%s", utils.ToJSON(req))
//	for accountID, expectedSubject := range expectedSubjectMap {
//		var include bool
//		if expectedSubject == nil {
//			content := i18nfmt.Sprintf(ctx, "我方主体变更协议，账号【%s】不存在审批通过的签约主体", accountID)
//			logs.CtxError(ctx, content)
//			return errors.ErrCommon.WithArgs(content)
//		}
//		for _, party := range req.TradePartyInfo.Subject {
//			if party.PartyNumber == expectedSubject.PartyNumber {
//				include = true
//				break
//			}
//		}
//		if !include {
//			return errors.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx,
//				"我方主体变更协议的“我方”必须包含[%s]",
//				expectedSubject.PartyName,
//			))
//		}
//	}
//	return nil
//}

// checkSubjectCommon 校验关联主体与我方主体关系-通用
//func checkSubjectCommon(ctx context.Context, req *auditmodel.CheckRelateSubjectPartyReq,
//	expectedSubjectMap map[string]*bizmodels.TradePartyInfoDetail) errors.APIError {
//	logs.CtxInfo(ctx, "checkSubjectCommon, req:%s", utils.ToJSON(req))
//	for _, party := range req.TradePartyInfo.Subject {
//		for accountID, expectedSubject := range expectedSubjectMap {
//			if party.PartyNumber != expectedSubject.PartyNumber {
//				return errors.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx,
//					"%s当前仅可使用[%s]作为我方主体签约",
//					accountID, expectedSubject.PartyName,
//				))
//			}
//		}
//	}
//	return nil
//}

// getSealPartySaleCreateAccountIDs 获取需要校验的账号ID
//func getSealPartySaleCreateAccountIDs(ctx context.Context, tradePartyInfo *bizmodels.TradePartyInfo) ([]string, errors.APIError) {
//	var res []string
//	// 获取需要校验的账号ID（与合同参数中的签约主体信息关联）
//	// “是否需要签约 = 是”的主体不存在“客户自助注册”的账号ID时，不需要校验
//	checkAccounts := tradePartyInfo.GetSealPartyAccounts()
//	if len(checkAccounts) == 0 {
//		return res, nil
//	}
//	accountInfos, err := accountcli.GetAccountAndVerifyListFromCache(ctx, util.StringSetToList(checkAccounts))
//	if err != nil {
//		logs.CtxError(ctx, "GetAccountInfoListFromCacheFail, err:%v", err)
//		return res, errors.ErrCommon.WithArgs("查询账号信息失败")
//	}
//	for _, accountInfo := range accountInfos {
//		if accountInfo.CreateSource != _const.PassportCreateSourceSale {
//			res = append(res, fmt.Sprintf("%d", accountInfo.AccountID))
//		}
//	}
//	return res, nil
//}

// QuerySignSubjectMap 查询签约主体管理服务 获取可签约的我方主体信息
// 使用时需注意，查询审批通过的签约主体时，若不存在签约主体，需返回空，不可返回默认我方主体
//func QuerySignSubjectMap(ctx context.Context, specialContractType string, checkAccounts []string) (map[string]*bizmodels.TradePartyInfoDetail, errors.APIError) {
//	var (
//		res               = map[string]*bizmodels.TradePartyInfoDetail{}
//		subjectNos        []string
//		subjectMetaMap    = map[string]*site_metadata_models.SubjectMetaData{}
//		changeApprovalMap = map[string]*volc_sign_subject_models.ChangeApprovalItemDTO{}
//	)
//	// 查询账号的指定签约主体
//	changeApprovals, err := signsubjectcli.ListChangeApproval(ctx, checkAccounts, getSubjectStatus(specialContractType))
//	if err != nil {
//		logs.CtxError(ctx, "QueryAvailableSubjectsFail, accounts:%v, err:%v", checkAccounts, err)
//		return nil, errors.ErrCommon.WithArgs("查询可用主体失败")
//	}
//	// 构建签约主体 Map
//	for _, changeApproval := range changeApprovals {
//		changeApprovalMap[strconv.Itoa(int(changeApproval.AccountID))] = changeApproval
//		subjectNos = append(subjectNos, changeApproval.SubjectNO)
//	}
//	// 查询交易主数据
//	subjectMetaDatas, err := ListSubjectMetaDatas(ctx, subjectNos)
//	if err != nil {
//		logs.CtxError(ctx, "QueryAvailableSubjectsFail, subjectNos:%s, err:%v", strings.Join(subjectNos, ","), err)
//		return nil, errors.ErrCommon.WithArgs("查询可用主体失败")
//	}
//	// 构建交易主数据 Map
//	for _, subjectMeta := range subjectMetaDatas {
//		subjectMetaMap[subjectMeta.SubjectCode] = subjectMeta
//	}
//	for _, accountID := range checkAccounts {
//		if approve, ok := changeApprovalMap[accountID]; ok {
//			subjectMeta := subjectMetaMap[approve.SubjectNO]
//			if subjectMeta == nil {
//				logs.CtxError(ctx, "QueryAvailableSubjectsFail, subjectMeta is nil, subjectNo:%s", approve.SubjectNO)
//				return nil, errors.ErrCommon.WithArgs("查询可用主体失败")
//			}
//			res[accountID] = &bizmodels.TradePartyInfoDetail{
//				SubjectNo:        approve.SubjectNO,
//				PartyName:        subjectMeta.SubjectFullName,
//				PartyNumber:      subjectMeta.MdcpCode,
//				LegalPartyNumber: subjectMeta.MdapCode,
//				Country:          subjectMeta.Country,
//				Signer:           subjectMeta.SubjectFullName,
//			}
//		} else if util.StringIn(_const.SpecialContractTypeSubjectChangeAgreement, strings.Split(specialContractType, ",")) {
//			// 主体变更协议要求 签约主体协议一定要返回值
//			res[accountID] = nil
//		} else {
//			res[accountID] = GetDefaultSubject()
//		}
//	}
//	return res, nil
//}

// ListSubjectMetaDatas 查询交易主数据，仅关注生效中的数据
//func ListSubjectMetaDatas(ctx context.Context, subjectNos []string) ([]*site_metadata_models.SubjectMetaData, error) {
//	if len(subjectNos) == 0 {
//		return nil, nil
//	}
//	subjectMetaDatas, err := subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache(ctx, subjectNos)
//	if err == nil {
//		return subjectMetaDatas, nil
//	} else {
//		logs.CtxError(ctx, "ListSubjectMetaDatasFail, subjectNos:%v, err:%v", subjectNos, err)
//		// 查询交易主数据系统失败时，降级访问本地缓存
//		if subjectMetas, err := getSubjectMetaBySubjectNoFromLocalCache(ctx, subjectNos); err != nil {
//			logs.CtxError(ctx, "getSubjectMetaBySubjectNoFromLocalCacheFail, err:%v", err)
//			return nil, err
//		} else {
//			return subjectMetas, nil
//		}
//	}
//}

// getSubjectMetaBySubjectNoFromLocalCache 兜底策略, 访问本地 preload cache 获取交易主数据
//func getSubjectMetaBySubjectNoFromLocalCache(ctx context.Context, subjectNos []string) ([]*site_metadata_models.SubjectMetaData, error) {
//	var res []*site_metadata_models.SubjectMetaData
//	// 兜底策略 访问本地 preload cache
//	for _, subjectNo := range subjectNos {
//		data := preload.SubjectMetaNo2Data(subjectNo)
//		if data == nil {
//			content := i18nfmt.Sprintf(ctx, "本地缓存无此数据，subjectNo: %s", subjectNo)
//			logs.CtxError(ctx, content)
//			larkc.Warning("通过本地缓存获取交易元数据信息失败", content)
//			return nil, fmt.Errorf("GetSubjectMetaDataFromCacheFail")
//		} else {
//			res = append(res, data)
//		}
//	}
//	return res, nil
//}

// needCheckSubject 是否需要检验
//func needCheckSubject(req *auditmodel.CheckRelateSubjectPartyReq) bool {
//	// 伙伴入驻、伙伴报价 不需要校验
//	if util.IntIn(req.BizSource, []int{
//		_const.BizSourcePartner,
//		_const.BizSourcePartnerQuote,
//	}) {
//		return false
//	}
//	// 在线协同，且协商状态为草稿时，不需要校验
//	if req.BizSource == _const.BizSourceCooperation &&
//		util.IntIn(req.CooperationStatus, []int{
//			_const.PreSalesContractDraft,
//			_const.PreSalesContractNotCreated,
//		}) {
//		return false
//	}
//	return true
//}

// getSubjectStatus 获取签约主体管理服务的主体状态
//func getSubjectStatus(specialContractType string) []int32 {
//	if util.StringIn(_const.SpecialContractTypeSubjectChangeAgreement, strings.Split(specialContractType, ",")) {
//		return []int32{signsubjectcli.ChangeApprovalItemPass, signsubjectcli.ChangeApprovalItemChangeAgreementSigned}
//	}
//	return []int32{signsubjectcli.ChangeApprovalItemInForce}
//}

// shouldQuerySubject 是否需要查询签约主体管理服务 （直销、代销、分销、空值）
//func shouldQuerySubject(businessType int) bool {
//	return util.IntIn(businessType, []int{
//		_const.BusinessTypeDirectSelling,
//		_const.BusinessTypeProxy,
//		_const.BusinessTypeBPDistribution,
//		_const.BusinessTypeSLV,
//		_const.BusinessTypePartnerStandardDiscount,
//		0, // 空值处理
//	})
//}

//func GetDefaultSubject() *bizmodels.TradePartyInfoDetail {
//	info := multienv.GetSubjectInfo()
//	return &bizmodels.TradePartyInfoDetail{
//		SubjectNo:        info.SubjectNo,
//		PartyName:        info.AccountName,
//		PartyNumber:      info.CPMdmCode,
//		LegalPartyNumber: info.APMdmCode,
//		Country:          info.Country,
//		Signer:           info.Signer,
//	}
//}

//func IsDisableSignSubjectCheck(ctx context.Context) bool {
//	config := conf.GetGlobalConf(ctx)
//	if config == nil {
//		logs.CtxError(ctx, "configLoader尚未初始化")
//		return false
//	}
//	logs.CtxInfo(ctx, "IsOpenSignSubjectCheck SwitchConfig.DisableSignSubjectCheck=%v", config.SwitchConfig.DisableSignSubjectCheck)
//	// 开关逻辑，若开关关闭，以外部入参为准
//	return config.SwitchConfig.DisableSignSubjectCheck
//}

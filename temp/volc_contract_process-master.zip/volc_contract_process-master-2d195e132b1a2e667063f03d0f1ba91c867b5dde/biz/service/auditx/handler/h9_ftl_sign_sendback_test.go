package handler

import (
	"code.byted.org/gopkg/env"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"strings"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerFTLSignSendBack_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignSendBack_PostProcess", t, func() {
		// 准备测试对象和上下文
		h := &handlerFTLSignSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("正常流程-成功发送飞书消息", func() {
			// 场景描述：
			// 测试 PostProcess 方法的正常执行逻辑，该方法应根据合同信息构建并发送飞书卡片消息。
			// 构造数据：
			// - ProcessCtx 包含一个 ContractInfo 实例，其中填充了合同号、名称、客户名和审批人列表。
			// - 审批人列表包含一个销售运营(SalesOperation)和一个销售(Salesperson)。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 返回销售运营邮箱列表作为消息接收者。
			// 2. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 返回销售邮箱列表，用于消息内容中的 @ 提醒。
			// 3. Mock 国际化和环境相关函数 (multienv.I18nFormat, i18nfmt.Sprintf, env.IsProduct, env.PSM) 以返回固定值，确保消息内容的可预测性。
			// 4. Mock larkc.GenEditURL 返回一个固定的合同详情链接。
			// 5. Mock 最终的飞书消息发送函数 larkc.BatchSendMessageToEmailIgnore，不执行实际发送。
			// 6. 调用 PostProcess 方法。
			// 7. 断言方法返回 nil，表示没有错误发生。

			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSalesOperationCompleteInformation,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-20231026-001",
					ContractName:   "年度合作协议",
					OtherPartyName: "火山引擎客户",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales.op@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationCompleteInformation},
						{Reviewer: "sales.person@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
			}

			// Mock 依赖
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"sales.op@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"sales.person@example.com"}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock(larkc.GenEditURL).Return("http://contract.example.com/edit/CN-20231026-001").Build()

			// Mock 消息卡片标题中的环境判断，以获得确定的标题
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(env.PSM).Return("test").Build()

			// Mock 最终的发送函数，不执行实际发送
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
				// 在这里可以对传入的参数进行一些基本断言，验证逻辑正确性
				convey.So(emailList, convey.ShouldResemble, []string{"sales.op@example.com"})
				convey.So(msgType, convey.ShouldEqual, larkc.MsgTypeInteractive)
				convey.So(content, convey.ShouldNotBeEmpty)
				convey.So(content, convey.ShouldContainSubstring, "CN-20231026-001")
				convey.So(content, convey.ShouldContainSubstring, "年度合作协议")
				convey.So(content, convey.ShouldContainSubstring, "火山引擎客户")
				// FIX: The original assertion failed because json.Marshal escapes '<' and '>'.
				// The fix is to check for the content of the tag without the angle brackets.
				convey.So(content, convey.ShouldContainSubstring, "at email=sales.person@example.com")
				convey.So(content, convey.ShouldContainSubstring, "http://contract.example.com/edit/CN-20231026-001")
			}).Build()

			// 执行被测函数
			err := h.PostProcess(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("异常流程-无有效接收人", func() {
			// 场景描述：
			// 测试当没有找到符合条件的审批人时，函数的行为。预期函数仍然正常返回，因为消息发送是忽略错误的。
			// 构造数据：
			// - ProcessCtx 的 ContractInfo 为空或审批人列表为空。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 返回一个空切片。
			// 2. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 返回一个空切片。
			// 3. Mock 其他依赖项以确保函数能完整执行。
			// 4. Mock larkc.BatchSendMessageToEmailIgnore，断言其接收到的邮箱列表为空。
			// 5. 调用 PostProcess 方法。
			// 6. 断言方法返回 nil。

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-20231026-002",
					ContractName:   "无审批人合同",
					OtherPartyName: "测试客户",
					Reviewers:      bizmodels.PreContractReviewerList{}, // 空审批人列表
				},
			}

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.GenEditURL).Return("http://contract.example.com/edit/CN-20231026-002").Build()
			mockey.Mock(env.IsProduct).Return(true).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
				// 预期调用时 emailList 为空
				convey.So(len(emailList), convey.ShouldEqual, 0)
				// 虽然 emailList 为空，但 StringListFormat 和 Join 后的字符串是 ""，所以消息内容依然会生成
				convey.So(content, convey.ShouldNotBeEmpty)
				convey.So(strings.Contains(content, "<at"), convey.ShouldBeFalse) // 确保没有 at 任何人
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非已退回状态时不通知C360", func() {
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractCustomerConfirm,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("清理退回状态失败时直接返回", func() {
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

// LarkMdAtEmail is a helper function from the original package used in the test.
// We include it here to avoid mocking it, as it's a simple pure function.
func (h *handlerCommon) LarkMdAtEmail(email string) string {
	return larkc.LarkMdAtEmail(email)
}

// StringListFormat is another helper used implicitly.
// We are using the real implementation from the utils package.
func (h *handlerCommon) StringListFormat(list []string, f func(string) string) []string {
	return utils.StringListFormat(list, f)
}

func Test_handlerFTLSignSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerFTLSignSendBack Validate", t, func() {
		// 待测函数实例
		h := &handlerFTLSignSendBack{}
		// 上下文
		ctx := context.Background()

		mockey.PatchConvey("场景：前置审批人检查失败", func() {
			// 场景描述：
			// 构造数据：构造一个空的ProcessCtx
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回一个错误。
			// 2. 调用 Validate 函数。
			// 3. 断言返回的错误是 h.commonCheckReviewerPass 返回的错误。

			// 准备数据
			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check reviewer pass failed")

			// Mock
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("场景：前置审批人检查通过，但审核意见为空", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其Comment字段不为nil。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回 nil。
			// 2. Mock pc.Comment.IsEmpty 返回 true。
			// 3. Mock i18nfmt.Errorf 返回一个特定的错误。
			// 4. 调用 Validate 函数。
			// 5. 断言返回的错误是“审核意见不可为空”。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			expectedErr := errors.New("审核意见不可为空")

			// Mock
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.Errorf).Return(expectedErr).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("场景：校验成功", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其Comment字段不为nil。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回 nil。
			// 2. Mock pc.Comment.IsEmpty 返回 false。
			// 3. 调用 Validate 函数。
			// 4. 断言返回的错误为 nil。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}

			// Mock
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should return true and nil", func() {
			// 场景描述：
			// 目标函数直接返回 true 和 nil，无任何依赖和逻辑判断。
			// 构造数据：
			// - h: 一个空的 handlerFTLSignSendBack 实例。
			// - ctx: context.Background()。
			// - pc: 一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用目标函数。
			// 2. 断言返回值是否为 true 和 nil。
			h := &handlerFTLSignSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerFTLSignSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignSendBack_Process", t, func() {
		mockey.PatchConvey("should return nil when process is called", func() {
			// 场景描述:
			// 这是一个简单场景，测试handlerFTLSignSendBack的Process方法。
			// 构造数据:
			// - 创建一个handlerFTLSignSendBack实例。
			// - 创建一个空的ProcessCtx实例。
			// 逻辑链路:
			// 1. 调用Process方法。
			// 2. 由于该方法目前直接返回nil，预期结果是无错误返回。

			// 准备数据
			h := &handlerFTLSignSendBack{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignSendBack_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 测试 CurrentOp 方法是否返回正确的操作类型。
			// 构造数据:
			// 初始化一个 handlerFTLSignSendBack 实例。
			// 逻辑链路:
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否等于预期的 _const.OperationSendBack。
			h := &handlerFTLSignSendBack{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerFTLSignSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("正常case: 应返回财税法签约审核状态", func() {
			// 场景描述：
			// 验证当调用 CurrentStatus 方法时，它总是返回预定义的“财税法签约审核”状态码。
			// 构造数据：
			// 初始化一个 handlerFTLSignSendBack 结构体实例。
			// 逻辑链路：
			// 1. 创建 handlerFTLSignSendBack 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值是否等于 _const.PreSalesContractFinanceTaxationLegalSignReview。

			// 数据准备
			h := &handlerFTLSignSendBack{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		})
	})
}

func Test_newHandlerFTLSignSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerFTLSignSendBack", t, func() {
		mockey.PatchConvey("正常情况：成功返回handlerFTLSignSendBack实例", func() {
			// 场景描述：
			// 本测试用例用于验证构造函数 newHandlerFTLSignSendBack 的正确性。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerFTLSignSendBack()。
			// 2. 断言返回的结果不为 nil。
			// 3. 断言返回的结果的类型是 *handlerFTLSignSendBack。

			// 调用
			result := newHandlerFTLSignSendBack()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldHaveSameTypeAs, &handlerFTLSignSendBack{})
		})
	})
}

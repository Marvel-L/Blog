package handler

//
// import (
// 	"context"
// 	"encoding/json"
// 	"errors"
// 	"fmt"
// 	"strings"
// 	"testing"
// 	"time"
//
// 	"code.byted.org/gopkg/logid"
// 	"github.com/bytedance/mockey"
// 	"github.com/smartystreets/goconvey/convey"
// 	"gorm.io/gorm"
//
// 	"volc_contract_process/biz/bizmodels"
// 	"volc_contract_process/biz/bizmodels/modelcommodity"
// 	"volc_contract_process/biz/dal"
// 	"volc_contract_process/biz/dal/model"
// 	"volc_contract_process/biz/service/auditx/auditmodel"
// 	"volc_contract_process/biz/service/contractmeta"
// 	"volc_contract_process/biz/service/metaattach"
// 	"volc_contract_process/biz/service/multienv/i18nfmt"
// 	"volc_contract_process/biz/service/supply"
// 	"volc_contract_process/biz/service/support/metacommodity"
// 	quoteservice "volc_contract_process/biz/service/support/quote"
// 	_const "volc_contract_process/pkg/const"
// 	errorsV2 "volc_contract_process/pkg/errors"
// 	"volc_contract_process/pkg/proxy/larkc"
// 	"volc_contract_process/pkg/proxy/rediscli"
// 	utils "volc_contract_process/pkg/util"
// )
//
// type MockSupplyService struct {
// 	supply.SupplyService
// }
//
// func Test_handlerMultiChangeQuote_Validate_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test handlerMultiChangeQuote.Validate", t, func() {
// 		h := &handlerMultiChangeQuote{}
// 		ctx := context.Background()
//
// 		convey.Convey("非补充协议场景", func() {
// 			// 场景描述:
// 			// 待验证的合同不是补充协议 (SupplySource 为空)。
// 			// 构造数据:
// 			// pc.PreContractVO.SupplySource = ""
// 			// pc.ContractInfo 和 pc.PreContractVO.ContractNo 已设置。
// 			// 逻辑链路:
// 			// 1. validateSupply 函数检测到 SupplySource 为空。
// 			// 2. 将 MainContractNo 设置为当前合同号。
// 			// 3. 函数返回 nil，无错误。
// 			pc := &auditmodel.ProcessCtx{
// 				PreContractVO: &model.ContractMetaDB{
// 					ContractNo:   "C001",
// 					SupplySource: "",
// 				},
// 				ContractInfo: &model.ContractMeta{},
// 			}
//
// 			err := h.Validate(ctx, pc)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "C001")
// 			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "C001")
// 		})
//
// 		convey.Convey("补充协议场景", func() {
// 			convey.Convey("原合同号为空", func() {
// 				// 场景描述:
// 				// 合同是补充协议，但未提供原合同号。
// 				// 构造数据:
// 				// pc.PreContractVO.SupplySource 不为空。
// 				// pc.PreContractVO.FromContractNo 为空。
// 				// 逻辑链路:
// 				// 1. validateSupply 函数检测到 FromContractNo 为空。
// 				// 2. 返回 "原合同号不能为空" 错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "",
// 					},
// 					ContractInfo: &model.ContractMeta{},
// 				}
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "原合同号不能为空")
// 			})
//
// 			convey.Convey("获取补充协议相关合同信息失败", func() {
// 				// 场景描述:
// 				// 调用 metaService.GetSupplyContractList 失败。
// 				// 构造数据:
// 				// pc.PreContractVO.SupplySource 和 FromContractNo 已设置。
// 				// 逻辑链路:
// 				// 1. Mock contractmeta.NewMetaService 返回一个 MockMetaService 实例。
// 				// 2. Mock MockMetaService.GetSupplyContractList 返回一个错误。
// 				// 3. validateSupply 函数捕获错误并返回 "查询补充协议相关合同信息失败" 错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 					},
// 					ContractInfo: &model.ContractMeta{},
// 				}
//
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, errorsV2.ErrCommon.WithArgs("db error")).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
// 			})
//
// 			convey.Convey("补充协议相关合同信息不存在", func() {
// 				// 场景描述:
// 				// 调用 metaService.GetSupplyContractList 成功，但返回的列表为 nil。
// 				// 构造数据:
// 				// pc.PreContractVO.SupplySource 和 FromContractNo 已设置。
// 				// 逻辑链路:
// 				// 1. Mock contractmeta.NewMetaService 返回一个 MockMetaService 实例。
// 				// 2. Mock MockMetaService.GetSupplyContractList 返回 (nil, nil)。
// 				// 3. validateSupply 函数检测到返回列表为 nil，返回 "补充协议相关合同信息不存在" 错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 					},
// 					ContractInfo: &model.ContractMeta{},
// 				}
//
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, nil).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "补充协议相关合同信息不存在")
// 			})
//
// 			convey.Convey("基础校验失败", func() {
// 				// 场景描述:
// 				// supplyService.ValidateBase 基础校验返回错误。
// 				// 构造数据:
// 				// 正常补充协议数据。
// 				// 逻辑链路:
// 				// 1. Mock 依赖的服务（MetaService, SupplyService）以通过前置检查。
// 				// 2. Mock SupplyService.ValidateBase 返回错误。
// 				// 3. validateSupply 函数捕获并返回此错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 					},
// 					ContractInfo: &model.ContractMeta{},
// 				}
//
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
// 					FromContract: &bizmodels.ContractMetaInfo{},
// 				}, nil).Build()
// 				mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
// 				mockey.Mock((*MockSupplyService).ValidateBase).Return(errorsV2.ErrCommon.WithArgs("validate base failed")).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "validate base failed")
// 			})
//
// 			convey.Convey("有效期校验失败", func() {
// 				// 场景描述:
// 				// 在特定状态下，supplyService.ValidateValidityTime 有效期校验返回错误。
// 				// 构造数据:
// 				// pc.ContractInfo.CooperationStatus 处于需要校验有效期的状态。
// 				// pc.OperationState 不是 OperationChangeQuoteNo。
// 				// 逻辑链路:
// 				// 1. Mock 依赖的服务以通过前置检查。
// 				// 2. Mock utils.IntIn 返回 true，进入有效期校验逻辑。
// 				// 3. Mock SupplyService.ValidateValidityTime 返回错误。
// 				// 4. validateSupply 函数捕获并返回此错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 					},
// 					ContractInfo: &model.ContractMeta{
// 						CooperationStatus: _const.PreSalesContractCustomerConfirm,
// 					},
// 					OperationState: _const.OperationReviewPass,
// 				}
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
// 					FromContract: &bizmodels.ContractMetaInfo{},
// 				}, nil).Build()
// 				mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
// 				mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
// 				mockey.Mock(utils.IntIn).Return(true).Build()
// 				mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(errorsV2.ErrCommon.WithArgs("validate time failed")).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "validate time failed")
// 			})
//
// 			convey.Convey("变更报价单场景 - 解析Extra失败", func() {
// 				// 场景描述:
// 				// 操作为变更报价单，但 pc.Extra 中的 JSON 格式无效。
// 				// 构造数据:
// 				// pc.OperationState = OperationChangeQuoteNo。
// 				// pc.Extra = "invalid-json"。
// 				// 逻辑链路:
// 				// 1. Mock MetaService 以通过前置检查。
// 				// 2. json.Unmarshal 解析 pc.Extra 失败。
// 				// 3. validateSupply 函数返回 "解析合同变更信息失败" 错误。
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 					},
// 					ContractInfo:   &model.ContractMeta{},
// 					OperationState: _const.OperationChangeQuoteNo,
// 					Extra:          "invalid-json",
// 				}
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
// 					FromContract: &bizmodels.ContractMetaInfo{},
// 				}, nil).Build()
// 				mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "解析合同变更信息失败")
// 			})
//
// 			convey.Convey("成功场景 - 包含信息填充和有效期校验", func() {
// 				// 场景描述:
// 				// 补充协议校验成功，包括了从原合同填充信息和有效期校验。
// 				// 构造数据:
// 				// 提供完整的补充协议数据和原合同信息。
// 				// pc.ContractInfo.CooperationStatus 处于需要校验有效期的状态。
// 				// 逻辑链路:
// 				// 1. Mock 所有依赖服务均返回成功。
// 				// 2. fillSupplyExtInfoByFromContractInfo 被调用，填充 pc 中的信息。
// 				// 3. ValidateBase 和 ValidateValidityTime 均被调用且成功。
// 				// 4. 函数返回 nil。
// 				// 5. 断言 pc 中的 MainContractNo 和 ProjectInfo 被正确填充。
// 				projectInfoStr := "{}"
// 				manageInfoStr := "{}"
// 				pc := &auditmodel.ProcessCtx{
// 					PreContractVO: &model.ContractMetaDB{
// 						SupplySource:   "some_source",
// 						FromContractNo: "FROM_C001",
// 						ProjectInfo:    projectInfoStr,
// 						ManageInfo:     manageInfoStr,
// 					},
// 					ContractInfo: &model.ContractMeta{
// 						CooperationStatus: _const.PreSalesContractCustomerConfirm,
// 						ProjectInfo:       &bizmodels.ProjectInfo{},
// 						ManageInfo:        &bizmodels.ManageInfo{},
// 					},
// 					OperationState: _const.OperationReviewPass,
// 				}
//
// 				fromContractInfo := &bizmodels.ContractMetaInfo{
// 					MainContractNo: "MAIN_C001",
// 					ProjectInfo: &bizmodels.ProjectInfo{
// 						ProductSolutionEmail: &[]string{"ps@example.com"}[0],
// 					},
// 					ManageInfo: &bizmodels.ManageInfo{
// 						BelongingDepartment: "test_department",
// 					},
// 				}
//
// 				mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
// 				mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
// 					FromContract: fromContractInfo,
// 				}, nil).Build()
// 				mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
// 				mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
// 				mockey.Mock(utils.IntIn).Return(true).Build()
// 				mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(nil).Build()
//
// 				err := h.Validate(ctx, pc)
//
// 				convey.So(err, convey.ShouldBeNil)
// 				convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "MAIN_C001")
// 				convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "MAIN_C001")
//
// 				var updatedProjectInfo bizmodels.ProjectInfo
// 				json.Unmarshal([]byte(pc.PreContractVO.ProjectInfo), &updatedProjectInfo)
// 				convey.So(*updatedProjectInfo.ProductSolutionEmail, convey.ShouldEqual, "ps@example.com")
//
// 				var updatedManageInfo bizmodels.ManageInfo
// 				json.Unmarshal([]byte(pc.PreContractVO.ManageInfo), &updatedManageInfo)
// 				convey.So(updatedManageInfo.BelongingDepartment, convey.ShouldEqual, "test_department")
// 			})
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_SupportStatus_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_SupportStatus", t, func() {
// 		mockey.PatchConvey("should return the correct supported statuses", func() {
// 			// 场景描述:
// 			// 验证 handlerMultiChangeQuote 的 SupportStatus 方法是否返回了预期的状态码列表。
// 			// 构造数据:
// 			// - 无需特殊构造，创建一个空的 handlerMultiChangeQuote 实例即可。
// 			// 逻辑链路:
// 			// 1. 创建一个 handlerMultiChangeQuote 实例。
// 			// 2. 调用 SupportStatus 方法。
// 			// 3. 断言返回的 int 切片与预期的常量值列表完全一致。
//
// 			// 准备数据
// 			h := &handlerMultiChangeQuote{}
//
// 			// 预期结果
// 			expected := []int{
// 				_const.PreSalesContractNotCreated,
// 				_const.PreSalesContractDraft,
// 				_const.PreSalesContractSendBack,
// 				_const.PreSalesContractSalesOperationReview,
// 				_const.PreSalesContractSolutionReview,
// 				_const.PreSalesContractFinanceTaxationLegalReview,
// 				_const.PreSalesContractCustomerConfirm,
// 				_const.PreSalesContractChange,
// 				_const.PreSalesContractSalesOperationCompleteInformation,
// 			}
//
// 			// 调用
// 			result := h.SupportStatus()
//
// 			// 断言
// 			convey.So(result, convey.ShouldResemble, expected)
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_clearTradePartyInfoAccountID_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_clearTradePartyInfoAccountID", t, func() {
// 		h := &handlerMultiChangeQuote{}
//
// 		mockey.PatchConvey("当TradePartyInfo为nil时，应创建新的TradePartyInfo并添加一个空的OtherParty", func() {
// 			// 场景描述：
// 			// 目标函数接收的ProcessCtx参数中，ContractInfo.TradePartyInfo为nil。
// 			// 构造数据：
// 			// ProcessCtx.ContractInfo.TradePartyInfo = nil
// 			// 逻辑链路：
// 			// 1. 函数执行，发现tradePartyInfo为nil。
// 			// 2. 创建一个新的bizmodels.TradePartyInfo实例。
// 			// 3. 接着检查OtherParty长度为0，向其中追加一个新的bizmodels.TradePartyInfoDetail。
// 			// 4. 返回新创建的TradePartyInfo。
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					TradePartyInfo: nil,
// 				},
// 			}
//
// 			result := h.clearTradePartyInfoAccountID(context.Background(), pc)
//
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(len(result.OtherParty), convey.ShouldEqual, 1)
// 			convey.So(result.OtherParty[0], convey.ShouldResemble, &bizmodels.TradePartyInfoDetail{})
// 		})
//
// 		mockey.PatchConvey("当TradePartyInfo不为nil但OtherParty为空时，应添加一个空的OtherParty", func() {
// 			// 场景描述：
// 			// 目标函数接收的ProcessCtx参数中，ContractInfo.TradePartyInfo不为nil，但其OtherParty切片为空。
// 			// 构造数据：
// 			// ProcessCtx.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{}
// 			// 逻辑链路：
// 			// 1. 函数执行，tradePartyInfo不为nil。
// 			// 2. 检查发现len(tradePartyInfo.OtherParty)为0。
// 			// 3. 向OtherParty切片中追加一个新的bizmodels.TradePartyInfoDetail。
// 			// 4. 返回修改后的TradePartyInfo。
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					TradePartyInfo: &bizmodels.TradePartyInfo{
// 						OtherParty: []*bizmodels.TradePartyInfoDetail{},
// 					},
// 				},
// 			}
//
// 			result := h.clearTradePartyInfoAccountID(context.Background(), pc)
//
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(len(result.OtherParty), convey.ShouldEqual, 1)
// 			convey.So(result.OtherParty[0], convey.ShouldResemble, &bizmodels.TradePartyInfoDetail{})
// 		})
//
// 		mockey.PatchConvey("当OtherParty不为空时，应清空所有元素的AccountID", func() {
// 			// 场景描述：
// 			// 目标函数接收的ProcessCtx参数中，ContractInfo.TradePartyInfo.OtherParty包含多个已有AccountID的元素。
// 			// 构造数据：
// 			// ProcessCtx.ContractInfo.TradePartyInfo.OtherParty 包含两个元素，AccountID分别为 "acc1" 和 "acc2"。
// 			// 逻辑链路：
// 			// 1. 函数执行，tradePartyInfo不为nil。
// 			// 2. 检查发现len(tradePartyInfo.OtherParty)不为0。
// 			// 3. 循环遍历OtherParty中的所有元素。
// 			// 4. 将每个元素的AccountID字段置为空字符串。
// 			// 5. 返回修改后的TradePartyInfo。
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					TradePartyInfo: &bizmodels.TradePartyInfo{
// 						OtherParty: []*bizmodels.TradePartyInfoDetail{
// 							{AccountID: "acc1"},
// 							{AccountID: "acc2"},
// 						},
// 					},
// 				},
// 			}
//
// 			result := h.clearTradePartyInfoAccountID(context.Background(), pc)
//
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(len(result.OtherParty), convey.ShouldEqual, 2)
// 			convey.So(result.OtherParty[0].AccountID, convey.ShouldBeEmpty)
// 			convey.So(result.OtherParty[1].AccountID, convey.ShouldBeEmpty)
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_HitStateChangeCondition_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_HitStateChangeCondition", t, func() {
// 		mockey.PatchConvey("should always return false and nil as it is a stub function", func() {
// 			// 场景描述：
// 			// 目标函数 HitStateChangeCondition 目前是一个存根实现，它不执行任何逻辑，总是直接返回 (false, nil)。
// 			// 构造数据：
// 			// - 初始化一个空的 handlerMultiChangeQuote 实例。
// 			// - 创建一个空的 context.Context。
// 			// - 创建一个空的 auditmodel.ProcessCtx 实例。
// 			// 逻辑链路：
// 			// 1. 调用 HitStateChangeCondition 方法。
// 			// 2. 验证返回的布尔值为 false。
// 			// 3. 验证返回的 error 为 nil。
//
// 			// 准备数据
// 			h := &handlerMultiChangeQuote{}
// 			ctx := context.Background()
// 			pc := &auditmodel.ProcessCtx{}
//
// 			// 调用目标函数
// 			hit, err := h.HitStateChangeCondition(ctx, pc)
//
// 			// 断言
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(hit, convey.ShouldBeFalse)
// 		})
// 	})
// }
//
// func Test_ClearContractRepeatQuote_BitsUTGen(t *testing.T) {
// 	type MockMetaServiceV2 struct {
// 		contractmeta.MetaServiceV2
// 	}
// 	mockey.PatchConvey("TestClearContractRepeatQuote", t, func() {
// 		ctx := context.Background()
// 		pc := &auditmodel.ProcessCtx{
// 			CurrentOperator: "test@operator.com",
// 			ContractInfo: &model.ContractMeta{
// 				ContractNo: "CN-TEST-001",
// 			},
// 		}
// 		repeatMsgMap := map[string]map[string]string{
// 			"CN-REPEAT-001": {"123": "repeat info"},
// 		}
// 		mockMetaServiceV2 := &MockMetaServiceV2{}
//
// 		convey.Convey("场景：成功清理", func() {
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).ClearRelateQuote).Return(nil).Build()
//
// 			err := ClearContractRepeatQuote(ctx, pc, repeatMsgMap)
// 			convey.So(err, convey.ShouldBeNil)
// 		})
//
// 		convey.Convey("场景：清理失败", func() {
// 			mockErr := errors.New("clear failed")
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).ClearRelateQuote).Return(mockErr).Build()
// 			mockey.Mock(logid.GetLogIDFromCtx).Return("test-log-id", true).Build()
// 			mockey.Mock(i18nfmt.Sprintf).Return("formatted error message").Build()
// 			mockey.Mock(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {}).Build()
//
// 			err := ClearContractRepeatQuote(ctx, pc, repeatMsgMap)
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err.Error(), convey.ShouldContainSubstring, mockErr.Error())
// 		})
//
// 		convey.Convey("场景：空的重复信息Map", func() {
// 			err := ClearContractRepeatQuote(ctx, pc, map[string]map[string]string{})
// 			convey.So(err, convey.ShouldBeNil)
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_CurrentStatus_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_CurrentStatus", t, func() {
// 		mockey.PatchConvey("should panic when called", func() {
// 			// 场景描述:
// 			// CurrentStatus 方法被设计为不应被调用，其实现会直接引发 panic。本测试旨在验证此行为。
// 			// 构造数据:
// 			// 初始化一个空的 handlerMultiChangeQuote 实例。
// 			// 逻辑链路:
// 			// 1. 创建 handlerMultiChangeQuote 的一个实例。
// 			// 2. 直接调用其 CurrentStatus 方法。
// 			// 3. 使用 convey.ShouldPanicWith断言该调用会引发一个内容为 "unexpected call MultiStatusOpHandler CurrentStatus() method" 的 panic。
//
// 			// 准备数据
// 			h := &handlerMultiChangeQuote{}
//
// 			// 调用并断言
// 			convey.So(func() {
// 				h.CurrentStatus()
// 			}, convey.ShouldPanicWith, "unexpected call MultiStatusOpHandler CurrentStatus() method")
// 		})
// 	})
// }
//
// func Test_newHandlerMultiChangeQuote_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test newHandlerMultiChangeQuote", t, func() {
// 		mockey.PatchConvey("should create a new handler with initialized fields", func() {
// 			// 场景描述:
// 			// 测试 newHandlerMultiChangeQuote 函数能否成功创建一个 MultiStatusOpHandler，并且其内部的依赖被正确初始化。
// 			// 构造数据:
// 			// 无需构造数据，函数没有入参。
// 			// 逻辑链路:
// 			// 1. 调用 newHandlerMultiChangeQuote() 函数。
// 			// 2. 断言返回的 handler 实例不为 nil。
// 			// 3. 断言返回的 handler 实例的具体类型为 *handlerMultiChangeQuote。
// 			// 4. 断言 handler 实例中的 contractDao 字段被 dal.NewContractMetaDao() 的返回值正确初始化。
// 			// 5. 断言 handler 实例中的 quoteService 字段被 quoteservice.NewService() 的返回值正确初始化。
//
// 			// 调用目标函数
// 			handler := newHandlerMultiChangeQuote()
//
// 			// 断言
// 			convey.So(handler, convey.ShouldNotBeNil)
//
// 			// 类型断言以检查内部字段
// 			h, ok := handler.(*handlerMultiChangeQuote)
// 			convey.So(ok, convey.ShouldBeTrue)
// 			convey.So(h, convey.ShouldNotBeNil)
//
// 			// 断言字段是否被正确初始化为单例实例
// 			convey.So(h.contractDao, convey.ShouldEqual, dal.NewContractMetaDao())
// 			convey.So(h.quoteService, convey.ShouldEqual, quoteservice.NewService())
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_Process_BitsUTGen(t *testing.T) {
//
// 	ctx := context.Background()
// 	mockQuoteSvc := &MockQuoteService{}
// 	mockContractDao := &MockContractMetaDao{}
// 	mockMetaCommoditySvc := &MockMetaCommodityService{}
// 	mockMetaSvc := &MockMetaService{}
// 	mockMetaSvcV2 := &MockMetaServiceV2{}
// 	mockAttachmentSvc := &MockMetaAttachService{}
//
// 	h := &handlerMultiChangeQuote{
// 		quoteService: mockQuoteSvc,
// 		contractDao:  mockContractDao,
// 	}
//
// 	mockey.PatchConvey("Test handlerMultiChangeQuote Process", t, func() {
//
// 		mockey.Mock(metacommodity.NewService).Return(mockMetaCommoditySvc).Build()
// 		mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
// 		mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaSvcV2).Build()
// 		mockey.Mock(metaattach.NewAttachmentService).Return(mockAttachmentSvc).Build()
// 		mockey.Mock(quoteservice.NewService).Return(mockQuoteSvc).Build()
//
// 		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
// 			return fmt.Sprintf(format, a...)
// 		}).Build()
//
// 		mockey.PatchConvey("Success Scenarios", func() {
// 			mockey.PatchConvey("Happy path with account ID, no price repeat, with guarantee", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NEW_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}, ContractNo: "CN-001", RelateQuoteNo: "Q_OLD_001", BasicInfo: "{}"},
// 					ContractInfo: &model.ContractMeta{
// 						ContractNo:     "CN-001",
// 						RelateQuoteNo:  "Q_OLD_001",
// 						BasicInfo:      &bizmodels.BasicInfo{BeginTime: "2023-01-01", EndTime: "2023-12-31"},
// 						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{}},
// 						ManageInfo:     &bizmodels.ManageInfo{},
// 						ProjectInfo:    &bizmodels.ProjectInfo{},
// 						SupplyScene:    _const.SupplySceneNew,
// 					},
// 				}
// 				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
//
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(&bizmodels.ManageInfo{QuoteAccountID: "12345", WhetherProject: "N"}, map[string]string{_const.ExtKeyQuoteGuarantee: "guarantee_info"}, nil).Build()
// 				mockey.Mock((*MockQuoteService).GetCreateQuoteReq).Return(&quoteservice.CreateQuoteReq{BizInfo: &bizmodels.QuoteBizInfo{TradeTypeCode: 1, DistributorInfos: "{}"}}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProjectInfo).Return(&bizmodels.ProjectInfo{}).Build()
//
// 				mockey.Mock((*handlerCommon).fillTradePartyInfo).Return(&bizmodels.TradePartyInfo{}, nil).Build()
// 				mockey.Mock((*handlerMultiChangeQuote).checkContractDiscount).Return(&bizmodels.ContractPriceRepeatInfoV1{Repeated: false}, nil).Build()
// 				mockey.Mock((*handlerCommon).checkPreCheckContractDiscount).Return(nil).Build()
//
// 				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
// 				mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
// 				mockey.Mock((*MockQuoteService).ChangeQuoteContract).Return(nil).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldBeNil)
// 				convey.So(pc.PreContractVO.RelateQuoteNo, convey.ShouldEqual, "Q_NEW_001")
// 				convey.So(pc.Remark, convey.ShouldContainSubstring, "更换后报价单号：Q_NEW_001")
// 				convey.So(pc.ContractInfo.BasicInfo.BeginTime, convey.ShouldBeEmpty)
// 				convey.So(pc.ContractInfo.BasicInfo.EndTime, convey.ShouldBeEmpty)
// 				convey.So(pc.ContractInfo.BasicInfo.UsefulLifeType, convey.ShouldEqual, _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME)
// 				convey.So(pc.ContractInfo.BasicInfo.WhetherProject, convey.ShouldEqual, "N")
// 				convey.So(pc.ContractInfo.BasicInfo.BusinessType, convey.ShouldEqual, 1)
// 				convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
// 				convey.So(pc.PreContractVO.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
// 			})
//
// 			mockey.PatchConvey("Happy path with ladder and guarantee quote", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NEW_LADDER_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}, ContractNo: "CN-001", RelateQuoteNo: "Q_OLD_001", BasicInfo: "{}"},
// 					ContractInfo: &model.ContractMeta{
// 						ContractNo:     "CN-001",
// 						RelateQuoteNo:  "Q_OLD_001",
// 						BasicInfo:      &bizmodels.BasicInfo{},
// 						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{}},
// 						ManageInfo:     &bizmodels.ManageInfo{},
// 						ProjectInfo:    &bizmodels.ProjectInfo{},
// 						SupplyScene:    _const.SupplySceneNew,
// 					},
// 				}
// 				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
//
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(&bizmodels.ManageInfo{QuoteAccountID: "12345", QuoteType: _const.QuoteTypeLadderQuote}, map[string]string{_const.ExtKeyQuoteGuarantee: "guarantee_info"}, nil).Build()
// 				mockey.Mock((*MockQuoteService).GetCreateQuoteReq).Return(&quoteservice.CreateQuoteReq{BizInfo: &bizmodels.QuoteBizInfo{TradeTypeCode: 1, DistributorInfos: "{}"}}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProjectInfo).Return(&bizmodels.ProjectInfo{}).Build()
// 				mockey.Mock((*handlerCommon).fillTradePartyInfo).Return(&bizmodels.TradePartyInfo{}, nil).Build()
// 				mockey.Mock((*handlerMultiChangeQuote).checkContractDiscount).Return(&bizmodels.ContractPriceRepeatInfoV1{Repeated: false}, nil).Build()
// 				mockey.Mock((*handlerCommon).checkPreCheckContractDiscount).Return(nil).Build()
// 				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
// 				mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
// 				mockey.Mock((*MockQuoteService).ChangeQuoteContract).Return(nil).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldBeNil)
// 				convey.So(pc.PreContractVO.RelateQuoteNo, convey.ShouldEqual, "Q_NEW_LADDER_001")
// 				expectedType := fmt.Sprintf("%s,%s", _const.SpecialContractTypeGuarantee, _const.SpecialContractTypeLadderQuotation)
// 				convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldEqual, expectedType)
// 			})
//
// 			mockey.PatchConvey("Happy path without account ID", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NEW_002"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}, ContractNo: "CN-002", RelateQuoteNo: "Q_OLD_002", BasicInfo: "{}"},
// 					ContractInfo: &model.ContractMeta{
// 						ContractNo:    "CN-002",
// 						RelateQuoteNo: "Q_OLD_002",
// 						BasicInfo:     &bizmodels.BasicInfo{},
// 						TradePartyInfo: &bizmodels.TradePartyInfo{
// 							OtherParty: []*bizmodels.TradePartyInfoDetail{{PartyName: "Party", AccountID: "111"}},
// 						},
// 						ManageInfo:  &bizmodels.ManageInfo{},
// 						ProjectInfo: &bizmodels.ProjectInfo{},
// 					},
// 				}
// 				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(&bizmodels.ManageInfo{QuoteAccountID: "", WhetherProject: "N"}, map[string]string{}, nil).Build()
// 				mockey.Mock((*MockQuoteService).GetCreateQuoteReq).Return(&quoteservice.CreateQuoteReq{BizInfo: &bizmodels.QuoteBizInfo{}}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProjectInfo).Return(&bizmodels.ProjectInfo{}).Build()
//
// 				mockey.Mock((*handlerMultiChangeQuote).clearTradePartyInfoAccountID).To(func(h *handlerMultiChangeQuote, ctx context.Context, pc *auditmodel.ProcessCtx) *bizmodels.TradePartyInfo {
// 					pc.ContractInfo.TradePartyInfo.OtherParty[0].AccountID = ""
// 					return pc.ContractInfo.TradePartyInfo
// 				}).Build()
//
// 				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
// 				mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
// 				mockey.Mock((*MockQuoteService).ChangeQuoteContract).Return(nil).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldBeNil)
// 				convey.So(pc.PreContractVO.RelateQuoteNo, convey.ShouldEqual, "Q_NEW_002")
// 				convey.So(pc.ContractInfo.TradePartyInfo.OtherParty[0].AccountID, convey.ShouldBeEmpty)
// 			})
// 		})
//
// 		mockey.PatchConvey("Failure Scenarios", func() {
// 			mockey.PatchConvey("Error when Extra is invalid JSON", func() {
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:        "{invalid",
// 					ContractInfo: &model.ContractMeta{},
// 				}
// 				mockey.Mock(i18nfmt.New).Return(errors.New("变更报价单信息为空")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "变更报价单信息为空")
// 			})
//
// 			mockey.PatchConvey("Error when new QuoteID is empty", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: ""}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:        string(extra),
// 					ContractInfo: &model.ContractMeta{},
// 				}
// 				mockey.Mock(i18nfmt.New).Return(errors.New("变更报价单信息为空")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "变更报价单信息为空")
// 			})
//
// 			mockey.PatchConvey("Error when contract has a template", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NEW_003"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{TemplateInfo: "some_template"},
// 					ContractInfo: &model.ContractMeta{
// 						RelateQuoteNo: "Q_OLD_003",
// 					},
// 				}
// 				mockey.Mock(i18nfmt.New).Return(errors.New("合同关联合同模板，不允许更换报价单。")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "不允许更换报价单")
// 			})
//
// 			mockey.PatchConvey("Error when new and old quotes are the same", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_SAME_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{},
// 					ContractInfo: &model.ContractMeta{
// 						RelateQuoteNo: "Q_SAME_001",
// 					},
// 				}
// 				mockey.Mock(i18nfmt.Errorf).Return(errors.New("报价单未变更")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "报价单未变更")
// 			})
//
// 			mockey.PatchConvey("Error when new quote is already related to another contract", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_USED_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{},
// 					ContractInfo: &model.ContractMeta{
// 						RelateQuoteNo: "Q_OLD_004",
// 					},
// 				}
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{
// 					Related:             true,
// 					RelatedContractList: []*modelcommodity.RelateContractInfo{{ContractNo: "CN-999"}},
// 				}, nil).Build()
// 				mockey.Mock(errorsV2.ErrQuoteCommon.WithArgs).Return(errors.New("当前报价单已经被其他合同关联")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "当前报价单已经被其他合同关联")
// 			})
//
// 			mockey.PatchConvey("Error when BuildProductInfosFromQuote fails", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_FAIL_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{},
// 					ContractInfo: &model.ContractMeta{
// 						RelateQuoteNo: "Q_OLD_005",
// 					},
// 				}
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(nil, nil, errors.New("build product info failed")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "build product info failed")
// 			})
//
// 			mockey.PatchConvey("Error when manageInfo from quote is nil", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NIL_MANAGE_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{},
// 					ContractInfo: &model.ContractMeta{
// 						RelateQuoteNo: "Q_OLD_006",
// 					},
// 				}
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(nil, map[string]string{}, nil).Build()
// 				mockey.Mock(i18nfmt.Errorf).Return(errors.New("变更报价单信息解析失败")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "变更报价单信息解析失败")
// 			})
//
// 			mockey.PatchConvey("Error when database update fails", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_NEW_001"}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}, ContractNo: "CN-001", RelateQuoteNo: "Q_OLD_001", BasicInfo: "{}"},
// 					ContractInfo: &model.ContractMeta{
// 						ContractNo:     "CN-001",
// 						RelateQuoteNo:  "Q_OLD_001",
// 						BasicInfo:      &bizmodels.BasicInfo{},
// 						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{}},
// 						ManageInfo:     &bizmodels.ManageInfo{},
// 						ProjectInfo:    &bizmodels.ProjectInfo{},
// 						SupplyScene:    _const.SupplySceneNew,
// 					},
// 				}
// 				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
//
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(&bizmodels.ManageInfo{QuoteAccountID: "12345", WhetherProject: "N"}, map[string]string{}, nil).Build()
// 				mockey.Mock((*MockQuoteService).GetCreateQuoteReq).Return(&quoteservice.CreateQuoteReq{BizInfo: &bizmodels.QuoteBizInfo{DistributorInfos: "{}"}}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProjectInfo).Return(&bizmodels.ProjectInfo{}).Build()
//
// 				mockey.Mock((*handlerCommon).fillTradePartyInfo).Return(&bizmodels.TradePartyInfo{}, nil).Build()
// 				mockey.Mock((*handlerMultiChangeQuote).checkContractDiscount).Return(&bizmodels.ContractPriceRepeatInfoV1{Repeated: false}, nil).Build()
// 				mockey.Mock((*handlerCommon).checkPreCheckContractDiscount).Return(nil).Build()
//
// 				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(errors.New("db update failed")).Build()
// 				mockey.Mock(i18nfmt.Errorf).Return(errors.New("更新交易对方信息失败")).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldNotBeNil)
// 				convey.So(err.Error(), convey.ShouldContainSubstring, "更新交易对方信息失败")
// 			})
// 		})
//
// 		mockey.PatchConvey("Special Logic Scenarios", func() {
// 			mockey.PatchConvey("Contract price is repeated but handled", func() {
// 				changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "Q_REPEAT_001", IgnorePriceRepeatReturn: true}
// 				extra, _ := json.Marshal(changeInfo)
// 				pc := &auditmodel.ProcessCtx{
// 					Extra:         string(extra),
// 					PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}, ContractNo: "CN-001", RelateQuoteNo: "Q_OLD_001", BasicInfo: "{}"},
// 					ContractInfo: &model.ContractMeta{
// 						ContractNo: "CN-001", RelateQuoteNo: "Q_OLD_001", BasicInfo: &bizmodels.BasicInfo{},
// 						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{}},
// 						ManageInfo:     &bizmodels.ManageInfo{ProductLevelMap: map[string][]*bizmodels.ProductInfo{"k": {}}},
// 						ProjectInfo:    &bizmodels.ProjectInfo{}, SupplyScene: _const.SupplySceneNew,
// 						Ext: make(map[string]string),
// 					},
// 				}
// 				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
//
// 				mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProductInfosFromQuote).Return(&bizmodels.ManageInfo{QuoteAccountID: "12345"}, map[string]string{}, nil).Build()
// 				mockey.Mock((*MockQuoteService).GetCreateQuoteReq).Return(&quoteservice.CreateQuoteReq{BizInfo: &bizmodels.QuoteBizInfo{DistributorInfos: "{}"}}, nil).Build()
// 				mockey.Mock((*MockQuoteService).BuildProjectInfo).Return(&bizmodels.ProjectInfo{}).Build()
//
// 				mockey.Mock((*handlerCommon).fillTradePartyInfo).Return(&bizmodels.TradePartyInfo{}, nil).Build()
// 				mockey.Mock((*handlerMultiChangeQuote).checkContractDiscount).Return(&bizmodels.ContractPriceRepeatInfoV1{
// 					Repeated: true,
// 					Msg:      map[string]string{"error": "is repeated"},
// 				}, nil).Build()
// 				mockey.Mock((*handlerCommon).checkPreCheckContractDiscount).Return(nil).Build()
//
// 				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
// 				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
// 				mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
// 				mockey.Mock((*MockQuoteService).ChangeQuoteContract).Return(nil).Build()
//
// 				err := h.Process(ctx, pc)
//
// 				convey.So(err, convey.ShouldBeNil)
// 				convey.So(pc.Remark, convey.ShouldContainSubstring, "更换后报价单号：Q_REPEAT_001")
// 				_, ok := pc.ContractInfo.Ext[_const.ExtKeyContractPriceRepeatInfo]
// 				convey.So(ok, convey.ShouldBeTrue)
// 			})
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_checkContractDiscount_BitsUTGen(t *testing.T) {
// 	// Mock definitions for interfaces
// 	type MockMetaService struct {
// 		contractmeta.MetaService
// 	}
// 	type MockMetaServiceV2 struct {
// 		contractmeta.MetaServiceV2
// 	}
//
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_checkContractDiscount", t, func() {
//
// 		h := &handlerMultiChangeQuote{}
// 		ctx := context.Background()
// 		accountID := "123,456"
// 		pc := &auditmodel.ProcessCtx{
// 			CurrentOperator: "test@operator.com",
// 			ContractInfo: &model.ContractMeta{
// 				ContractNo: "CN-TEST-001",
// 				BasicInfo:  &bizmodels.BasicInfo{},
// 				ManageInfo: &bizmodels.ManageInfo{
// 					WhetherProject: _const.No,
// 					ProductLevelMap: map[string][]*bizmodels.ProductInfo{
// 						"level1": {{ID: 1, TradeProduct: "ECS"}},
// 					},
// 				},
// 				TradePartyInfo: &bizmodels.TradePartyInfo{
// 					EndUserAccountID: "789",
// 				},
// 				BeginTime: time.Now().Add(-24 * time.Hour).Format("2006-01-02 15:04:05"),
// 				EndTime:   time.Now().Add(24 * time.Hour).Format("2006-01-02 15:04:05"),
// 			},
// 		}
// 		changeInfo := bizmodels.ChangeQuoteExtra{
// 			QuoteID:                 "Q-TEST-001",
// 			IgnorePriceRepeatReturn: false,
// 		}
//
// 		mockMetaService := &MockMetaService{}
// 		mockMetaServiceV2 := &MockMetaServiceV2{}
//
// 		mockey.PatchConvey("场景：新合同，无合同价重复", func() {
// 			pc.ContractInfo.SupplyScene = _const.SupplySceneNew
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(&modelcommodity.CheckQuoteItemRepeatData{
// 				Repeat: false,
// 			}, nil).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(result.Repeated, convey.ShouldBeFalse)
// 			convey.So(result.QuoteNo, convey.ShouldEqual, changeInfo.QuoteID)
// 		})
//
// 		mockey.PatchConvey("场景：补充协议，无合同价重复", func() {
// 			pc.ContractInfo.SupplyScene = _const.SupplySceneAdjustPrice
// 			pc.ContractInfo.FromContractNo = "CN-FROM-001"
//
// 			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
// 				ParentContractList: []string{"CN-PARENT-001"},
// 			}, nil).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(&modelcommodity.CheckQuoteItemRepeatData{
// 				Repeat: false,
// 			}, nil).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(result.Repeated, convey.ShouldBeFalse)
// 		})
//
// 		mockey.PatchConvey("场景：补充协议，获取父合同列表失败", func() {
// 			pc.ContractInfo.SupplyScene = _const.SupplySceneAdjustPrice
// 			pc.ContractInfo.FromContractNo = "CN-FROM-001"
// 			mockErr := errorsV2.ErrInternalError.WithArgs("get list failed")
//
// 			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
// 			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, mockErr).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err, convey.ShouldEqual, mockErr)
// 			convey.So(result, convey.ShouldBeNil)
// 		})
//
// 		mockey.PatchConvey("场景：合同价重复校验服务失败", func() {
// 			pc.ContractInfo.SupplyScene = _const.SupplySceneNew
// 			mockErr := errors.New("check repeat service unavailable")
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(nil, mockErr).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			// 修复断言：
// 			// 目标代码中 errorsV2.ErrInternalError.WithArgs("合同价[%s]重复校验失败", changeInfo.QuoteID) 的调用方式
// 			// 不会替换"%s"，而是将其作为字面量传递。因此，最终的错误信息中包含的是 "合同价[%s]重复校验失败"，而不是格式化后的字符串。
// 			// 我们需要断言这个未格式化的字符串存在。
// 			convey.So(err.Error(), convey.ShouldContainSubstring, "合同价[%s]重复校验失败")
// 			convey.So(result, convey.ShouldBeNil)
// 		})
//
// 		mockey.PatchConvey("场景：合同价重复且不忽略返回", func() {
// 			changeInfo.IgnorePriceRepeatReturn = false
// 			repeatData := &modelcommodity.CheckQuoteItemRepeatData{
// 				Repeat:                 true,
// 				CommodityRepeatMsg:     map[string]string{"123": "commodity repeat msg"},
// 				ContractPriceRepeatMsg: map[string]string{"123": "price repeat msg"},
// 			}
// 			commMsg, _ := json.Marshal(repeatData.CommodityRepeatMsg)
// 			priceMsg, _ := json.Marshal(repeatData.ContractPriceRepeatMsg)
// 			expectedErrMsg := strings.Join([]string{string(commMsg), string(priceMsg)}, "\n")
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
// 			convey.So(result, convey.ShouldBeNil)
// 		})
//
// 		mockey.PatchConvey("场景：合同价重复且忽略返回，清理成功", func() {
// 			changeInfo.IgnorePriceRepeatReturn = true
// 			pc.Remark = "" // Reset remark before test
// 			repeatData := &modelcommodity.CheckQuoteItemRepeatData{
// 				Repeat: true,
// 			}
// 			expectedRemark := fmt.Sprintf("更换后报价单号：%s，与现有合同价重复，%v", changeInfo.QuoteID, changeInfo)
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
// 			mockey.Mock(ClearContractRepeatQuote).Return(nil).Build()
// 			mockey.Mock(i18nfmt.Sprintf).Return(expectedRemark).Build()
// 			mockey.Mock(GetCommodityRepeatMsgMap).Return(map[string]map[string]string{}).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(result, convey.ShouldNotBeNil)
// 			convey.So(result.Repeated, convey.ShouldBeTrue)
// 			convey.So(pc.Remark, convey.ShouldEqual, expectedRemark)
// 		})
//
// 		mockey.PatchConvey("场景：合同价重复且忽略返回，但清理失败", func() {
// 			changeInfo.IgnorePriceRepeatReturn = true
// 			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}
// 			mockErr := errorsV2.ErrInternalError.WithArgs("clear failed")
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
// 			mockey.Mock(ClearContractRepeatQuote).Return(mockErr).Build()
// 			mockey.Mock(GetCommodityRepeatMsgMap).Return(map[string]map[string]string{}).Build()
//
// 			result, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err, convey.ShouldEqual, mockErr)
// 			convey.So(result, convey.ShouldBeNil)
// 		})
//
// 		mockey.PatchConvey("场景：是否项目制合同", func() {
// 			pc.ContractInfo.ManageInfo.WhetherProject = _const.Yes
// 			// 恢复为非项目制，避免影响后续测试
// 			defer func() {
// 				pc.ContractInfo.ManageInfo.WhetherProject = _const.No
// 			}()
//
// 			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
// 			// 通过 When 精确匹配 IsProject 参数
// 			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).When(func(ctx context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) bool {
// 				return req.IsProject == _const.TRUE_FLAG_INT_STR
// 			}).Return(&modelcommodity.CheckQuoteItemRepeatData{Repeat: false}, nil).Build()
//
// 			_, err := h.checkContractDiscount(ctx, accountID, pc, changeInfo)
//
// 			convey.So(err, convey.ShouldBeNil)
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_CurrentOp_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_CurrentOp", t, func() {
// 		mockey.PatchConvey("should return the correct operation number", func() {
// 			// 场景描述：
// 			// 测试 CurrentOp 方法是否返回正确的操作码常量。
// 			// 构造数据：
// 			// 创建一个空的 handlerMultiChangeQuote 实例。
// 			// 逻辑链路：
// 			// 1. 初始化 handlerMultiChangeQuote。
// 			// 2. 调用 CurrentOp 方法。
// 			// 3. 断言返回值等于预期的常量 _const.OperationChangeQuoteNo。
//
// 			// 准备数据
// 			h := &handlerMultiChangeQuote{}
//
// 			// 调用
// 			result := h.CurrentOp()
//
// 			// 断言
// 			convey.So(result, convey.ShouldEqual, _const.OperationChangeQuoteNo)
// 		})
// 	})
// }
//
// func Test_handlerMultiChangeQuote_PostProcess_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_handlerMultiChangeQuote_PostProcess", t, func() {
// 		mockey.PatchConvey("success case: should return nil", func() {
// 			// 场景描述：
// 			// 目标函数 PostProcess 当前的实现是空的，直接返回 nil。
// 			// 本测试用例旨在验证该基本行为。
// 			// 构造数据：
// 			// - h: 一个空的 handlerMultiChangeQuote 实例。
// 			// - ctx: 一个背景 context。
// 			// - pc: 一个空的 ProcessCtx 实例。
// 			// 逻辑链路：
// 			// 1. 调用 PostProcess 方法。
// 			// 2. 断言返回的错误为 nil。
//
// 			// 准备数据
// 			h := &handlerMultiChangeQuote{}
// 			ctx := context.Background()
// 			pc := &auditmodel.ProcessCtx{}
//
// 			// 调用目标函数
// 			err := h.PostProcess(ctx, pc)
//
// 			// 断言结果
// 			convey.So(err, convey.ShouldBeNil)
// 		})
// 	})
// }

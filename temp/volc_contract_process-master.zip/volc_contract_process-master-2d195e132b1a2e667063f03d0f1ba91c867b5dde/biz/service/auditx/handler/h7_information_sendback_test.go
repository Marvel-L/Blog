package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerInformationSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerInformationSendBack Process", t, func() {
		h := &handlerInformationSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("未跳过财税法审批时直接返回", func() {
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			called := false
			mockey.Mock((*handlerCommon).updateContractData).To(func(ctx context.Context, pc *auditmodel.ProcessCtx) error {
				called = true
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(called, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("合同信息为空时直接返回", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
			}
			called := false
			mockey.Mock((*handlerCommon).updateContractData).To(func(ctx context.Context, pc *auditmodel.ProcessCtx) error {
				called = true
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(called, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("基础信息为空时直接返回", func() {
			pc := &auditmodel.ProcessCtx{
				ContractInfo:  &model.ContractMeta{},
				PreContractVO: &model.ContractMetaDB{},
			}
			called := false
			mockey.Mock((*handlerCommon).updateContractData).To(func(ctx context.Context, pc *auditmodel.ProcessCtx) error {
				called = true
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(called, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("跳过财税法审批时清除标记并更新合同数据", func() {
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{IsSkipFTL: true},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			called := false
			mockey.Mock((*handlerCommon).updateContractData).To(func(ctx context.Context, pc *auditmodel.ProcessCtx) error {
				called = true
				convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
				convey.So(pc.PreContractVO.BasicInfo, convey.ShouldNotBeBlank)

				var basicInfo bizmodels.BasicInfo
				err := json.Unmarshal([]byte(pc.PreContractVO.BasicInfo), &basicInfo)
				convey.So(err, convey.ShouldBeNil)
				convey.So(basicInfo.IsSkipFTL, convey.ShouldBeFalse)
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(called, convey.ShouldBeTrue)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("序列化基础信息失败时返回错误", func() {
			expectedErr := errors.New("marshal failed")
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{IsSkipFTL: true},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			called := false
			mockey.Mock(json.Marshal).Return(nil, expectedErr).Build()
			mockey.Mock((*handlerCommon).updateContractData).To(func(ctx context.Context, pc *auditmodel.ProcessCtx) error {
				called = true
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(called, convey.ShouldBeFalse)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("更新合同数据失败时返回错误", func() {
			expectedErr := errors.New("update failed")
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{IsSkipFTL: true},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			mockey.Mock((*handlerCommon).updateContractData).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerInformationSendBack_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBack_PostProcess", t, func() {
		mockey.PatchConvey("should send lark message and return nil when process is successful", func() {
			// 场景描述：
			// 测试在正常情况下，PostProcess方法能否成功构建并触发飞书消息的发送，并最终返回nil。
			// 构造数据：
			// - 一个ProcessCtx实例，包含合同信息（如审批人、合同号、合同名、客户名）和状态变更值。
			// - 审批人列表中包含销售人员，以便被getReviewer...方法过滤出来。
			// 逻辑链路：
			// 1. Mock `getReviewerFromPreContractReviewerListWithContractStatus` 方法，使其返回一个预期的销售人员邮箱列表作为消息接收者。
			// 2. Mock `getReviewerFromPreContractReviewerList` 方法，使其返回一个预期的销售人员邮箱列表，用于在消息内容中@相关人员。
			// 3. Mock `multienv.I18nFormat`, `i18nfmt.Sprintf`, `larkc.LarkMdAtEmail`, `larkc.GenCRMDetailURL` 等一系列用于构建消息内容的辅助函数，以确保其输出是稳定和可预测的。
			// 4. Mock `larkc.BatchSendMessageToEmailIgnore` 函数，防止真实的网络调用，并验证其是否被调用。
			// 5. 调用目标方法 `PostProcess`。
			// 6. 断言返回的error为nil，表示方法执行成功。

			// 数据准备
			ctx := context.Background()
			h := &handlerInformationSendBack{}
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.ReviewerTypeSalesperson,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "TEST_CONTRACT_NO_123",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Customer Inc.",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "test.sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson, ContractStatus: _const.ReviewerTypeSalesperson},
						{Reviewer: "test.manager@example.com", ReviewerType: _const.ReviewerTypeManager, ContractStatus: _const.ReviewerTypeSalesperson},
					},
				},
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "PRE_CONTRACT_NO_456",
				},
			}

			// Mock
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"test.sales@example.com"}).
				Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"test.sales@example.com"}).
				Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()
			mockey.Mock(larkc.GenCRMDetailURL).Return("http://fake.crm.com/detail/PRE_CONTRACT_NO_456").Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非已退回状态时不通知C360", func() {
			ctx := context.Background()
			h := &handlerInformationSendBack{}
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractCustomerConfirm,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("清理退回状态失败时直接返回", func() {
			ctx := context.Background()
			h := &handlerInformationSendBack{}
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerInformationSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBack_Validate", t, func() {
		// Arrange: common variables for all tests
		h := &handlerInformationSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("场景：校验成功", func() {
			// 场景描述：
			// 所有校验条件均满足，函数应成功返回 nil。
			// 构造数据：
			// - pc.Comment 不为空
			// - pc.ContractInfo.BasicInfo.IsSkipFTL 为 false
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回 nil，表示通用审批人校验通过。
			// 2. Mock pc.Comment.IsEmpty() 返回 false，表示审批意见不为空。
			// 3. 设置 pc.ContractInfo.BasicInfo.IsSkipFTL 为 false。
			// 4. Validate 函数执行所有检查，无错误，返回 nil。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: false,
					},
				},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：通用审批人校验失败", func() {
			// 场景描述：
			// 内部调用的 h.commonCheckReviewerPass 返回错误，Validate 应直接返回此错误。
			// 构造数据：无特殊构造。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回一个预设的错误。
			// 2. Validate 函数调用 h.commonCheckReviewerPass，接收到错误并立即返回。

			// Arrange
			expectedErr := errors.New("common check failed")
			pc := &auditmodel.ProcessCtx{}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
		})

		mockey.PatchConvey("场景：审核意见为空", func() {
			// 场景描述：
			// 审批意见为空，不满足校验条件，应返回错误。
			// 构造数据：
			// - pc.Comment 为空。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 返回 nil，表示通用审批人校验通过。
			// 2. Mock pc.Comment.IsEmpty() 返回 true，表示审批意见为空。
			// 3. Validate 函数检查到意见为空，调用 i18nfmt.Errorf 生成错误并返回。
			// 4. Mock i18nfmt.Errorf 返回预设的错误。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.Errorf).Return(errors.New("审核意见不可为空")).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("场景：合同已跳过财税法审批时仍允许退回", func() {
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerInformationSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 该函数逻辑非常简单，直接返回true和nil。本测试用例验证了这一基本行为。
			// 构造数据：
			// - h: 一个*handlerInformationSendBack实例。
			// - ctx: 一个空的context。
			// - pc: 一个空的*auditmodel.ProcessCtx实例。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 断言返回值为(true, nil)。

			h := &handlerInformationSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerInformationSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBack_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentOp 方法能否正确返回预设的操作类型常量。
			// 构造数据：
			// 初始化一个 handlerInformationSendBack 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于 _const.OperationSendBack。

			// 准备数据
			h := &handlerInformationSendBack{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerInformationSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("should return the correct status for information send back", func() {
			// 场景描述：
			// 测试 handlerInformationSendBack 的 CurrentStatus 方法能否正确返回其代表的状态码。
			// 构造数据：
			// - 初始化一个 handlerInformationSendBack 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值是否等于常量 _const.PreSalesContractSalesOperationCompleteInformation。

			// 准备数据
			h := &handlerInformationSendBack{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationCompleteInformation)
		})
	})
}

func Test_newHandlerInformationSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerInformationSendBack", t, func() {
		mockey.PatchConvey("正常调用", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerInformationSendBack() 函数。
			// 2. 断言返回的处理器不为 nil。
			// 3. 断言返回的处理器类型为 *handlerInformationSendBack。

			// 调用目标函数
			handler := newHandlerInformationSendBack()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerInformationSendBack{})
		})
	})
}

var basicInfo bizmodels.BasicInfo

package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSalesReviewWithdraw() StatusOpHandler {
	return &handlerSalesReviewWithdraw{}
}

// 销售运营专业审核(3) --- 审核撤回(3) --> 销售运营专业审核(3)
type handlerSalesReviewWithdraw struct {
	handlerCommon
}

func (h *handlerSalesReviewWithdraw) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewWithdraw) CurrentOp() int {
	return _const.OperationReviewWithdraw
}

func (h *handlerSalesReviewWithdraw) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.Comment.IsEmpty() {
		return i18nfmt.New(ctx, "撤回原因不可为空")
	}
	for _, reviewer := range pc.ContractInfo.Reviewers {
		if reviewer.Reviewer == pc.CurrentOperator &&
			reviewer.ContractStatus == _const.PreSalesContractSalesOperationReview &&
			reviewer.ReviewerType == _const.ReviewerTypeSalesOperation &&
			reviewer.Status != _const.ReviewStatusReviewPass {
			return i18nfmt.New(ctx, "审核未通过，不可撤回")
		}
	}
	return nil
}

func (h *handlerSalesReviewWithdraw) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerSalesReviewWithdraw) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerSalesReviewWithdraw) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 当前场景下，不需要清理报价单相关信息
	// if err := h.clearQuoteProductInfos(ctx, pc); err != nil {
	//	return err
	// }
	return nil
}

package handler

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/rediscli"
)

func newHandlerHaveChangeCancel() StatusOpHandler {
	return &handlerHaveChangeCancel{}
}

// 有修改(6) --- 取消有修改(12) --> 销售确认中(5)
type handlerHaveChangeCancel struct {
	handlerCommon
}

func (h *handlerHaveChangeCancel) CurrentStatus() int {
	return _const.PreSalesContractChange
}

func (h *handlerHaveChangeCancel) CurrentOp() int {
	return _const.OperationCancel
}

func (h *handlerHaveChangeCancel) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerHaveChangeCancel) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerHaveChangeCancel) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerHaveChangeCancel) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 恢复文件版本
	fileID := pc.ContractInfo.OnlineContract

	stashVersion, err := rediscli.GetStashFileVersion(ctx, fileID)
	if err != nil {
		logs.CtxError(ctx, "GetStashFileVersionFail, fileID:%s, err:%s", fileID, err.Error())
	}

	if len(stashVersion) > 0 {
		req := &filecli.RollbackVersionReq{
			FileID:      fileID,
			VersionDest: stashVersion,
			Operator:    pc.CurrentOperator,
		}

		logs.CtxInfo(ctx, "PrepareRollbackVersion, fileID:%s, version:%s, operator:%s", req.FileID, req.VersionDest, req.Operator)

		_, err = filecli.RollbackVersion(ctx, req)
		if err != nil {
			logs.CtxError(ctx, "RollbackVersionFail, fileID:%s, err:%s", fileID, err.Error())
		}

	}

	// 移除更换报价单记录
	_ = rediscli.RemoveQuoteChangeInfoFlag(ctx, pc.ContractInfo.ContractNo)

	// 发送飞书消息 取消修改时 状态恢复 依旧是申请人处理 无需提醒
	// larkc.SendTextMessageByEmail(i18nfmt.Sprintf(ctx, _const.ReviewRemind, larkc.GenReviewURL(pc.ContractInfo.ContractNo)),
	//	h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeFinanceTaxationLegalReviewer))

	return nil
}

package handler

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	errorsV2 "volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerFTLSignReviewPass() StatusOpHandler {
	return &handlerFTLSignReviewPass{}
}

// 财税法签约审核(9) --- 审核通过(2) --> 销售确认中(5)
type handlerFTLSignReviewPass struct {
	handlerCommon
}

func (h *handlerFTLSignReviewPass) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalSignReview
}

func (h *handlerFTLSignReviewPass) CurrentOp() int {
	return _const.OperationReviewPass
}

func (h *handlerFTLSignReviewPass) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	// 若此时合同倒签，页面无法填充倒签原因，需补齐倒签信息
	if err := h.IsReverseContract(ctx, pc.PreContractVO); err != nil {
		pc.ContractInfo.ReverseSignInfo = &bizmodels.ReverseSignInfo{
			ReverseSignCode:   "RS008",
			ReverseSignReason: "合同签署的提前计划/安排不足",
		}
		reverseSignInfo, _ := json.Marshal(pc.ContractInfo.ReverseSignInfo)
		pc.PreContractVO.ReverseSignInfo = string(reverseSignInfo)
	}

	return nil
}

func (h *handlerFTLSignReviewPass) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerFTLSignReviewPass) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

func (h *handlerFTLSignReviewPass) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	if err := validateRiskClauseRole(ctx, pc.GetTx(), pc.PreContractNo); err != nil {
		// 存在未审核通过的风险条款
		return _const.ApprovalStatusKeyRiskRoleNotApproved
	}
	return _const.ApprovalStatusKeyDefault
}

func (h *handlerFTLSignReviewPass) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.reviewPassSendReviewedMessage(ctx, pc); err != nil {
		logs.CtxError(ctx, "SendReviewedMessageFail, err:%s", err.Error())
		return err
	}
	// 合同协商状态变更为风险条款审核时，发送飞书消息
	if pc.StatusChanged && pc.StatusChangedValue == _const.PreSalesContractRiskReview {
		// 发送飞书消息
		multiCtx := context.Background()
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, _const.PreSalesContractRiskReview),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同已完成专业审核和签约审核环节，且存在未关闭或未审批通过的风险条款，请尽快前往后台送审风险条款", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	} else if pc.StatusChanged && pc.ReviewerStatusOpConf.ContractNewStatusOnSuccess == _const.PreSalesContractSubmitOA {
		// 审批通过后状态为提交OA时，发送提交OA消息
		pc.PreContractVO.SubmitTime = time.Now()
		// pc.ContractInfo.SubmitTime = time.Now()
		// 更新pre_sales_contract字段
		if err := h.updateContractData(ctx, pc); err != nil {
			logs.CtxError(ctx, "UpdateContractDataFail, err:%s", err.Error())
			return errorsV2.ErrCommon.WithArgs(err.Error())
		}
		return h.SendSubmitOaMsg(ctx, pc)
	}
	return nil
}

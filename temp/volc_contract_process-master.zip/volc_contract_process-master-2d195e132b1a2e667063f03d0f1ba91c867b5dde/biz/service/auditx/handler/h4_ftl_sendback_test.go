package handler

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerFTLReviewSendBack_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewSendBack_PostProcess", t, func() {
		h := &handlerFTLReviewSendBack{}
		ctx := context.Background()

		// Mock the Lark message card builder chain to avoid its internal logic (like checking env).
		mockBuilder := &larkc.CommonMessageCardBuilder{}
		mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return(`{"card":"fake_json_content"}`).Build()

		// Mock i18n and formatting functions to return predictable results.
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v // Pass through original string for simplicity
		}).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()

		// Mock other external dependencies.
		mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review-url").Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
			return fmt.Sprintf("<at email=%s></at>", email)
		}).Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

		mockey.PatchConvey("Scenario: Status changed to PreSalesContractSolutionReview", func() {
			// 场景描述：
			// 当合同被退回，且状态变更为“解决方案审核”时，系统应向解决方案审核人发送飞书提醒。
			// 构造数据：
			// - pc.StatusChangedValue 设置为 _const.PreSalesContractSolutionReview
			// - pc.ContractInfo 包含必要的合同信息
			// 逻辑链路：
			// 1. 函数内的 if 条件 `pc.StatusChangedValue == _const.PreSalesContractSolutionReview` 为 true。
			// 2. `reviewerType` 被设置为 `_const.ReviewerTypeSolutionReviewer`。
			// 3. Mock `getReviewerFromPreContractReviewerListWithContractStatus` 返回解决方案审核人列表。
			// 4. Mock `getReviewerFromPreContractReviewerList` 返回销售人员列表。
			// 5. `larkc.BatchSendMessageToEmailIgnore` 被调用，发送飞书消息。
			// 6. 函数成功返回 nil。
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSolutionReview,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-001",
					ContractName:   "Solution Review Contract",
					OtherPartyName: "Client A",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) bool {
					return reviewerType == _const.ReviewerTypeSolutionReviewer
				}).
				Return([]string{"solution.reviewer@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int) bool {
					return reviewerType == _const.ReviewerTypeSalesperson
				}).
				Return([]string{"sales.person@example.com"}).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Scenario: Status changed to another status (e.g., SalesOperationReview)", func() {
			// 场景描述：
			// 当合同被退回，且状态变更为“销售运营专业审核”时，系统应向销售运营人员发送飞书提醒。
			// 构造数据：
			// - pc.StatusChangedValue 设置为 _const.PreSalesContractSalesOperationReview
			// - pc.ContractInfo 包含必要的合同信息
			// 逻辑链路：
			// 1. 函数内的 if 条件 `pc.StatusChangedValue == _const.PreSalesContractSolutionReview` 为 false。
			// 2. `reviewerType` 使用默认值 `_const.ReviewerTypeSalesOperation`。
			// 3. Mock `getReviewerFromPreContractReviewerListWithContractStatus` 返回销售运营人员列表。
			// 4. Mock `getReviewerFromPreContractReviewerList` 返回销售人员列表。
			// 5. `larkc.BatchSendMessageToEmailIgnore` 被调用，发送飞书消息。
			// 6. 函数成功返回 nil。
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-002",
					ContractName:   "Sales Op Review Contract",
					OtherPartyName: "Client B",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) bool {
					return reviewerType == _const.ReviewerTypeSalesOperation
				}).
				Return([]string{"sales.op@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int) bool {
					return reviewerType == _const.ReviewerTypeSalesperson
				}).
				Return([]string{"another.sales.person@example.com"}).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非已退回状态时不通知C360", func() {
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("清理退回状态失败时直接返回", func() {
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerFTLReviewSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerFTLReviewSendBack Validate", t, func() {
		// 初始化通用变量
		ctx := context.Background()
		h := &handlerFTLReviewSendBack{}

		mockey.PatchConvey("当 h.commonCheckReviewerPass 返回错误时，应直接返回该错误", func() {
			// 场景描述：
			// 构造数据：构造一个 auditmodel.ProcessCtx 实例。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回一个自定义错误。
			// 2. 调用 h.Validate 方法。
			// 3. 断言返回的错误与 Mock 的错误一致。
			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check reviewer pass error")

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("当 h.commonCheckReviewerPass 成功但审核意见为空时，应返回'审核意见不可为空'的错误", func() {
			// 场景描述：
			// 构造数据：构造一个 auditmodel.ProcessCtx 实例，其 Comment 字段不为 nil。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回 nil，表示前置检查通过。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法返回 true，表示审核意见为空。
			// 3. 调用 h.Validate 方法。
			// 4. 断言返回的错误包含 "审核意见不可为空"。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("当所有校验都通过时，应返回 nil", func() {
			// 场景描述：
			// 构造数据：构造一个 auditmodel.ProcessCtx 实例，其 Comment 字段不为 nil。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回 nil，表示前置检查通过。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法返回 false，表示审核意见不为空。
			// 3. 调用 h.Validate 方法。
			// 4. 断言返回的错误为 nil。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should return true and nil", func() {
			// 场景描述：
			// 该函数逻辑非常简单，总是返回 true 和 nil。本测试用例验证这一行为。
			// 构造数据：
			// - 初始化 handlerFTLReviewSendBack 结构体。
			// - 初始化 context.Context。
			// - 初始化 auditmodel.ProcessCtx 结构体。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 true，错误为 nil。

			// 准备数据
			h := &handlerFTLReviewSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			got, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerFTLReviewSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewSendBack_Process", t, func() {
		mockey.PatchConvey("should return nil for the current implementation", func() {
			// 场景描述：
			// 当前Process方法是一个空实现，直接返回nil。本测试旨在验证此行为。
			// 构造数据：
			// - ctx: 一个空的context.Background()
			// - pc: 一个空的auditmodel.ProcessCtx实例
			// 逻辑链路：
			// 1. 初始化handlerFTLReviewSendBack
			// 2. 调用Process方法
			// 3. 断言返回的error为nil

			// 数据准备
			h := &handlerFTLReviewSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewSendBack_CurrentOp", t, func() {
		mockey.PatchConvey("正常返回", func() {
			// 场景描述：
			// 构造数据：创建一个handlerFTLReviewSendBack实例。
			// 逻辑链路：
			// 1. 调用CurrentOp方法。
			// 2. 验证返回值是否等于预期的常量 _const.OperationSendBack。
			h := &handlerFTLReviewSendBack{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerFTLReviewSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个handlerFTLReviewSendBack实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 验证返回值是否为预期的常量。
			h := &handlerFTLReviewSendBack{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalReview)
		})
	})
}

func Test_newHandlerFTLReviewSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLReviewSendBack", t, func() {
		mockey.PatchConvey("should return a non-nil handler instance", func() {
			// 场景描述:
			// 测试 newHandlerFTLReviewSendBack 函数能否成功创建一个非空的 StatusOpHandler 实例。
			// 构造数据:
			// 无特殊构造数据。
			// 逻辑链路:
			// 1. 调用 newHandlerFTLReviewSendBack() 函数。
			// 2. 断言返回的 handler 实例不为 nil。
			// 3. 断言返回的 handler 实例的具体类型是 *handlerFTLReviewSendBack。

			// 调用目标函数
			handler := newHandlerFTLReviewSendBack()

			// 断言结果
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLReviewSendBack{})
		})
	})
}

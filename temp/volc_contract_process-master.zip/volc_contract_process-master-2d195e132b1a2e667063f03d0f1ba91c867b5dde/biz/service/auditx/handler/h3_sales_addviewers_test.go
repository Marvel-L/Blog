package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerSalesReviewAddReviewers_PostProcess_BitsUTGen(t *testing.T) {
	mockDal := &MockPreContractReviewerDao{}

	mockey.PatchConvey("Test_handlerSalesReviewAddReviewers_PostProcess", t, func() {
		h := &handlerSalesReviewAddReviewers{}
		ctx := context.Background()

		mockey.PatchConvey("Scenario: Add Reviewer (加签)", func() {
			mockey.PatchConvey("Case: Happy path for adding a new reviewer", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState:  _const.OperationAddReviewer,
					Extra:           "new.reviewer@example.com",
					CurrentOperator: "current.operator@example.com",
					ContractInfo: &model.ContractMeta{
						ContractNo:        "TEST-CN-001",
						ContractName:      "Test Contract",
						OtherPartyName:    "Client Inc.",
						CooperationStatus: 1,
						BasicInfo: &bizmodels.BasicInfo{
							DepartmentId: "D001",
						},
						Reviewers: bizmodels.PreContractReviewerList{},
					},
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ReviewerType: _const.ReviewerTypeSalesOperation,
					},
				}

				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{
					Reviewer:       "current.operator@example.com",
					ReviewerType:   _const.ReviewerTypeSalesOperation,
					ContractStatus: 1,
					Priority:       10,
				}).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
					{ID: 123, Email: "new.reviewer@example.com"},
				}, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDal).Build()
				mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, nil).Build()
				mockey.Mock(dal.CreatePreContractReviewer).Return(nil).Build()

				mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
				mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
					return fmt.Sprintf(format, a...)
				}).Build()
				mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
				mockey.Mock(larkc.GenReviewURL).Return("http://review.url/TEST-CN-001").Build()
				mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales.person@example.com"}).Build()
				mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType, content string) {}).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: Add an existing reviewer (reactivate)", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState:  _const.OperationAddReviewer,
					Extra:           "existing.reviewer@example.com",
					CurrentOperator: "current.operator@example.com",
					ContractInfo: &model.ContractMeta{
						ContractNo:        "TEST-CN-002",
						ContractName:      "Test Contract",
						OtherPartyName:    "Client Inc.",
						CooperationStatus: 1,
						BasicInfo: &bizmodels.BasicInfo{
							DepartmentId: "D001",
						},
					},
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ReviewerType: _const.ReviewerTypeSalesOperation,
					},
				}
				existingReviewerDB := &model.PreContractReviewerDB{
					BaseDB:         model.BaseDB{Id: 999},
					Reviewer:       "existing.reviewer@example.com",
					ReviewerType:   _const.ReviewerTypeSalesOperation,
					ContractStatus: 1,
				}

				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{
					Reviewer:       "current.operator@example.com",
					ReviewerType:   _const.ReviewerTypeSalesOperation,
					ContractStatus: 1,
					Priority:       10,
				}).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
					{ID: 456, Email: "existing.reviewer@example.com"},
				}, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDal).Build()
				mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{existingReviewerDB}, nil).Build()
				mockey.Mock((*MockPreContractReviewerDao).UpdateByID).Return(nil).Build()

				mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
				mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
					return fmt.Sprintf(format, a...)
				}).Build()
				mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
				mockey.Mock(larkc.GenReviewURL).Return("http://review.url/TEST-CN-002").Build()
				mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales.person@example.com"}).Build()
				mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType, content string) {}).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: countersignReviewer returns an error", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState:  _const.OperationAddReviewer,
					Extra:           "new.reviewer@example.com",
					CurrentOperator: "current.operator@example.com",
					ContractInfo: &model.ContractMeta{
						ContractNo:        "TEST-CN-001",
						CooperationStatus: 1,
						BasicInfo: &bizmodels.BasicInfo{
							DepartmentId: "D001",
						},
					},
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ReviewerType: _const.ReviewerTypeSalesOperation,
					},
				}

				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{{ID: 1, Email: "new.reviewer@example.com"}}, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDal).Build()
				mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, nil).Build()
				mockey.Mock(dal.CreatePreContractReviewer).Return(errors.New("db create error")).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "db create error")
			})
		})

		mockey.PatchConvey("Scenario: Change Reviewer (转办)", func() {
			mockey.PatchConvey("Case: Happy path for changing a reviewer", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState:  _const.OperationChangeReviewer,
					Extra:           "new.reviewer@example.com",
					CurrentOperator: "old.reviewer@example.com",
					PreContractNo:   "TEST-CN-003",
					ContractInfo: &model.ContractMeta{
						ContractNo:     "TEST-CN-003",
						OtherPartyName: "Client Inc.",
						ContractName:   "Test Contract",
						BasicInfo: &bizmodels.BasicInfo{
							DepartmentId: "D001",
						},
					},
				}
				oldReviewerRoles := model.PreContractReviewerDBList{
					{PreContractNo: "TEST-CN-003", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: 1},
					{PreContractNo: "TEST-CN-003", ReviewerType: _const.ReviewerTypeMentioned, ContractStatus: 2},
				}

				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
					{ID: 789, Email: "new.reviewer@example.com"},
				}, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDal).Build()

				mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).When(func(ctx context.Context, tx *gorm.DB, no, email string) bool {
					return email == "old.reviewer@example.com"
				}).Return(oldReviewerRoles, nil).When(func(ctx context.Context, tx *gorm.DB, no, email string) bool {
					return email == "new.reviewer@example.com"
				}).Return(nil, nil).Build()
				mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
					return fmt.Sprintf(format, a...)
				}).Build()
				mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()

				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

				mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType, content string) {}).Build()
				mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
				mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
				mockey.Mock(larkc.GenReviewURL).Return("http://review.url/TEST-CN-003").Build()
				mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales.person@example.com"}).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: changeReviewer returns an error", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState:  _const.OperationChangeReviewer,
					Extra:           "new.reviewer@example.com",
					CurrentOperator: "old.reviewer@example.com",
					ContractInfo: &model.ContractMeta{
						ContractNo: "TEST-CN-004",
					},
				}
				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
					{ID: 789, Email: "new.reviewer@example.com"},
				}, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDal).Build()
				mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(nil, errors.New("db find error")).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "db find error")
			})
		})

		mockey.PatchConvey("Scenario: General Failure", func() {
			mockey.PatchConvey("Case: GetEmployeeByMailsWithCache returns an error", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState: _const.OperationAddReviewer,
					Extra:          "new.reviewer@example.com",
				}
				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, errors.New("lark api error")).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "lark api error")
			})
		})

		mockey.PatchConvey("Scenario: Other Operation State", func() {
			mockey.PatchConvey("Case: OperationState is not Add or Change, should send default message", func() {

				pc := &auditmodel.ProcessCtx{
					OperationState: _const.OperationSubmitPreContract,
					Extra:          "some.person@example.com",
					ContractInfo: &model.ContractMeta{
						ContractNo:        "TEST-CN-005",
						OtherPartyName:    "Client Inc.",
						ContractName:      "Test Contract",
						CooperationStatus: 1,
						Reviewers: bizmodels.PreContractReviewerList{
							{Reviewer: "sales.person@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
						},
						BasicInfo: &bizmodels.BasicInfo{},
					},
				}
				mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
				mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
					{ID: 101, Email: "some.person@example.com"},
				}, nil).Build()

				mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType, content string) {

					convey.So(content, convey.ShouldContainSubstring, "发起的合同待您审核")
				}).Build()
				mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
				mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
					return fmt.Sprintf(format, a...)
				}).Build()
				mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
				mockey.Mock(larkc.GenReviewURL).Return("http://review.url/TEST-CN-005").Build()
				mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).To(func(h *handlerCommon, list bizmodels.PreContractReviewerList, reviewerType int) []string {
					var reviewers []string
					for _, r := range list {
						if r.ReviewerType == reviewerType {
							reviewers = append(reviewers, r.Reviewer)
						}
					}
					return reviewers
				}).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})
		})
	})
}

func Test_handlerSalesReviewAddReviewers_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewAddReviewers_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 的实现是直接返回 (false, nil)，不依赖于任何输入参数或内部状态。
			// 构造数据：
			// - h: 一个 handlerSalesReviewAddReviewers 的实例。
			// - ctx: 一个背景上下文。
			// - pc: 一个 ProcessCtx 的实例。
			// 逻辑链路：
			// 1. 直接调用目标函数。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的错误为 nil。
			h := &handlerSalesReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSalesReviewAddReviewers_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSalesReviewAddReviewers Process", t, func() {
		mockey.PatchConvey("success case: function is empty and should return nil", func() {
			// 场景描述：
			// 目标函数 Process 的实现为空，直接返回 nil。本测试用例旨在验证此行为。
			// 构造数据：
			// - 初始化一个 handlerSalesReviewAddReviewers 实例。
			// - 初始化一个空的 context.Context。
			// - 初始化一个空的 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 直接调用 Process 方法。
			// 2. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerSalesReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewAddReviewers_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewAddReviewers_Validate", t, func() {
		h := &handlerSalesReviewAddReviewers{}
		ctx := context.Background()

		mockey.PatchConvey("场景：成功校验 - 添加新的审批人", func() {
			// 场景描述：
			// 构造数据：pc.Extra中包含一个或多个全新的审批人。
			// 逻辑链路：
			// 1. pc.Extra不为空，校验通过。
			// 2. Mock pc.GetTx() 返回一个 *gorm.DB 实例。
			// 3. Mock perm.GetAllReviewersByType 返回一个空的或者不包含新审批人的列表。
			// 4. 函数检查发现没有已存在的审批人，existReviewers 列表为空。
			// 5. 函数返回nil，表示校验成功。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-2023-001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "another.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功校验 - 添加的审批人已存在但状态为审核通过", func() {
			// 场景描述：
			// 构造数据：pc.Extra中包含一个已存在的审批人，但其状态为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. pc.Extra不为空，校验通过。
			// 2. Mock pc.GetTx() 返回一个 *gorm.DB 实例。
			// 3. Mock perm.GetAllReviewersByType 返回一个包含该审批人的列表，其状态为 ReviewStatusReviewPass。
			// 4. 函数检查时，由于状态为 ReviewStatusReviewPass，不将其加入 existReviewers 列表。
			// 5. existReviewers 列表为空，函数返回nil，表示校验成功。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-2023-002",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：校验失败 - 添加的审批人为空", func() {
			// 场景描述：
			// 构造数据：pc.Extra为空字符串。
			// 逻辑链路：
			// 1. 函数检查到 pc.Extra 长度为0。
			// 2. 立即返回错误 "人员不可为空"。
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景：校验失败 - 添加已存在的审批人", func() {
			// 场景描述：
			// 构造数据：pc.Extra中包含一个已存在的审批人，其状态不为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. pc.Extra不为空，校验通过。
			// 2. Mock pc.GetTx() 返回一个 *gorm.DB 实例。
			// 3. Mock perm.GetAllReviewersByType 返回一个包含该审批人的列表，其状态不为 ReviewStatusReviewPass。
			// 4. 函数检查发现该审批人已存在且状态不满足条件，将其加入 existReviewers 列表。
			// 5. existReviewers 列表不为空，函数返回错误，提示人员已是审核人员。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com,another.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-2023-003",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			// FIX: 原来的断言因为`Error()`方法没有按预期格式化字符串而失败。
			//      修改为使用`ShouldResemble`来精确比较返回的error对象与预期的error对象是否一致。
			expectedErr := errorsV2.ErrCommon.WithArgs("%s已是审核人员", "existing.user@example.com")
			convey.So(err, convey.ShouldResemble, expectedErr)
		})

		mockey.PatchConvey("场景：校验失败 - 获取已有审批人列表时发生错误", func() {
			// 场景描述：
			// 构造数据：pc.Extra不为空。
			// 逻辑链路：
			// 1. pc.Extra不为空，校验通过。
			// 2. Mock pc.GetTx() 返回一个 *gorm.DB 实例。
			// 3. Mock perm.GetAllReviewersByType 返回一个错误。
			// 4. 函数将此错误直接返回。
			pc := &auditmodel.ProcessCtx{
				Extra: "any.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-2023-004",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			dbErr := errors.New("database connection failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, dbErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbErr)
		})
	})
}

func Test_handlerSalesReviewAddReviewers_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewAddReviewers_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationAddReviewer", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否总是返回正确的操作码。
			// 构造数据：
			// - 初始化一个 handlerSalesReviewAddReviewers 实例。
			// 逻辑链路：
			// 1. 创建 handlerSalesReviewAddReviewers 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationAddReviewer。

			// 初始化 handler 实例
			h := &handlerSalesReviewAddReviewers{}

			// 调用目标方法
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationAddReviewer)
		})
	})
}

func Test_handlerSalesReviewAddReviewers_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewAddReviewers_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSalesOperationReview", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法，该方法应始终返回预定义的常量。
			// 构造数据：
			// 创建一个 handlerSalesReviewAddReviewers 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值等于 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewAddReviewers{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewAddReviewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSalesReviewAddReviewers", t, func() {
		mockey.PatchConvey("should return a non-nil handler which is an instance of handlerSalesReviewAddReviewers", func() {
			// 场景描述：
			// 测试 newHandlerSalesReviewAddReviewers 构造函数。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerSalesReviewAddReviewers() 函数。
			// 2. 断言返回的 StatusOpHandler 不为 nil。
			// 3. 断言返回的实例的具体类型是 *handlerSalesReviewAddReviewers。

			// 调用目标函数
			handler := newHandlerSalesReviewAddReviewers()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewAddReviewers{})
		})
	})
}

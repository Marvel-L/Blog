package handler

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
)

func Test_handlerSendBackUpdate_Process_BitsUTGen(t *testing.T) {
	// Mock DAO interfaces
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}
	type MockContractSettlementDao struct {
		dal.ContractSettlementDao
	}
	type MockContractAttachmentDao struct {
		dal.ContractAttachmentDao
	}

	mockey.PatchConvey("Test handlerSendBackUpdate.Process", t, func() {
		// Setup common variables for all test cases
		h := &handlerSendBackUpdate{}
		ctx := context.Background()

		mockey.PatchConvey("happy path: process succeeds", func() {
			// 场景描述：
			// 测试Process方法成功执行的 happy path。
			// 构造数据：
			// - pc.PreContractVO 包含基本的合同信息
			// - pc.ContractInfo 包含待更新的各类信息
			// - pc.AttachmentUpdateList 和 pc.DelExtKeys 包含待处理的数据
			// 逻辑链路：
			// 1. Process方法调用h.updateContractData
			// 2. updateContractData中的所有依赖调用都成功返回
			//    - GetTemplateFileId 返回成功
			//    - CreateOrUpdateAttachment 返回成功
			//    - updatePreContract (及其依赖) 返回成功
			//    - SaveManageInfo 返回成功
			//    - SaveTradePartyInfo 返回成功
			//    - SaveMetaExt 返回成功
			//    - updateContractSettlement (及其依赖) 返回成功
			//    - updateAttachment (及其依赖) 返回成功
			// 3. 最终Process方法返回nil error

			// Data preparation
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB:     model.BaseDB{Id: 1},
					ContractNo: "test-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					SettlementInfo: &bizmodels.SettlementInfo{
						SettlementLines: bizmodels.SettlementLines{
							{
								Id:                         1,
								InvoicingPercent:           "100",
								InvoicingTotal:             "10000",
								PaymentPercent:             "100",
								PaymentTotal:               "10000",
								PaymentMilepostFixedTime:   "2023-01-01",
								InvoicingMilepostFixedTime: "2023-01-01",
							},
						},
					},
					Ext: map[string]string{"key1": "value1"},
				},
				AttachmentUpdateList: []*bizmodels.MetaAttachment{
					{DownloadID: "att-id-1"},
				},
				DelExtKeys: []string{"del-key1"},
			}

			// Mocking dependencies
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			// Mocking dependencies of private method updatePreContract
			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			// Mocking dependencies of private method updateContractSettlement
			mockSettlementDao := &MockContractSettlementDao{}
			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			// Mocking dependencies of private method updateAttachment
			mockAttachmentDao := &MockContractAttachmentDao{}
			mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error path: GetTemplateFileId fails", func() {
			// 场景描述：
			// 模拟GetTemplateFileId函数调用失败，测试Process方法是否能正确处理并返回错误。
			// 构造数据：
			// - 与happy path相同
			// 逻辑链路：
			// 1. Process调用updateContractData
			// 2. updateContractData中的GetTemplateFileId调用返回一个错误
			// 3. Process方法应立即中断并向上抛出此错误

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 1},
				},
			}
			expectedErr := errors.New("get template file id failed")

			mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("error path: SaveManageInfo fails", func() {
			// 场景描述：
			// 模拟SaveManageInfo方法调用失败，测试Process方法是否能正确处理并返回错误。
			// 构造数据：
			// - 与happy path相同
			// 逻辑链路：
			// 1. Process调用updateContractData
			// 2. GetTemplateFileId, CreateOrUpdateAttachment, updatePreContract 成功
			// 3. SaveManageInfo 调用返回一个APIError
			// 4. Process方法应立即中断并向上抛出此错误

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 1},
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			expectedErr := errorsV2.ErrInternalError.WithArgs("save manage info failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*handlerCommon).SaveManageInfo).Return(expectedErr).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "save manage info failed")
		})

		mockey.PatchConvey("error path: updateContractSettlement fails", func() {
			// 场景描述：
			// 模拟私有方法updateContractSettlement的依赖调用失败，测试Process方法是否能正确处理并返回错误。
			// 构造数据：
			// - 与happy path相同
			// 逻辑链路：
			// 1. Process调用updateContractData
			// 2. 前面的所有公共方法和私有方法依赖调用都成功
			// 3. updateContractSettlement 中的 SoftDeleteByContractID 调用返回一个错误
			// 4. Process方法应立即中断并向上抛出此错误

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 1},
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					SettlementInfo: &bizmodels.SettlementInfo{
						SettlementLines: bizmodels.SettlementLines{},
					},
					Ext: map[string]string{},
				},
				AttachmentUpdateList: []*bizmodels.MetaAttachment{},
				DelExtKeys:           []string{},
			}
			expectedErr := errors.New("soft delete settlement failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockSettlementDao := &MockContractSettlementDao{}
			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(expectedErr).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("error path: updateAttachment fails", func() {
			// 场景描述：
			// 模拟私有方法updateAttachment的依赖调用失败，测试Process方法是否能正确处理并返回错误。
			// 构造数据：
			// - 与happy path相同
			// 逻辑链路：
			// 1. Process调用updateContractData
			// 2. 前面的所有公共方法和私有方法依赖调用都成功
			// 3. updateAttachment 中的 UpdateByFileKey 调用返回一个错误
			// 4. Process方法应立即中断并向上抛出此错误

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB:     model.BaseDB{Id: 1},
					ContractNo: "test-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					SettlementInfo: &bizmodels.SettlementInfo{
						SettlementLines: bizmodels.SettlementLines{
							{
								Id:                         1,
								InvoicingPercent:           "100",
								InvoicingTotal:             "10000",
								PaymentPercent:             "100",
								PaymentTotal:               "10000",
								PaymentMilepostFixedTime:   "2023-01-01",
								InvoicingMilepostFixedTime: "2023-01-01",
							},
						},
					},
					Ext: map[string]string{},
				},
				AttachmentUpdateList: []*bizmodels.MetaAttachment{
					{DownloadID: "att-id-1"},
				},
				DelExtKeys: []string{},
			}
			expectedErr := fmt.Errorf("update attachment failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockSettlementDao := &MockContractSettlementDao{}
			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			mockAttachmentDao := &MockContractAttachmentDao{}
			mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(expectedErr).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update attachment failed")
		})
	})
}

func Test_handlerSendBackUpdate_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackUpdate_PostProcess", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述:
			// 目标函数 PostProcess 当前实现为空，直接返回 nil。
			// 本测试用例旨在验证在任何输入下，该函数都能成功执行并返回 nil。
			// 构造数据:
			// - 初始化一个 handlerSendBackUpdate 实例。
			// - 创建一个空的 context.Context。
			// - 创建一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路:
			// 1. 调用 PostProcess 方法。
			// 2. 断言返回的错误为 nil。

			h := &handlerSendBackUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSendBackUpdate_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackUpdate_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 的实现非常简单，直接返回 (false, nil)，没有任何逻辑分支。
			// 本测试用例旨在验证其基本行为。
			// 构造数据：
			// - h: 一个空的 handlerSendBackUpdate 实例。
			// - ctx: 一个背景 context。
			// - pc: 一个空的 ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 预期方法返回 false 和 nil。
			h := &handlerSendBackUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSendBackUpdate_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackUpdate_Validate", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述：
			// handlerSendBackUpdate的Validate方法当前实现为空，直接返回nil。
			// 构造数据：
			// - 一个空的handlerSendBackUpdate实例。
			// - 一个空的ProcessCtx实例。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 方法直接返回nil。
			// 3. 断言返回的error为nil。
			h := &handlerSendBackUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSendBackUpdate_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackUpdate_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试handlerSendBackUpdate的CurrentOp方法能否正确返回预设的操作类型常量。
			// 构造数据：
			// 初始化一个handlerSendBackUpdate实例。
			// 逻辑链路：
			// 1. 创建handlerSendBackUpdate实例。
			// 2. 调用CurrentOp方法。
			// 3. 断言返回值等于_const.OperationSubmitDraft。

			h := &handlerSendBackUpdate{}

			result := h.CurrentOp()

			convey.So(result, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerSendBackUpdate_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackUpdate_CurrentStatus", t, func() {
		mockey.PatchConvey("正常返回", func() {
			// 场景描述:
			// 测试 handlerSendBackUpdate 的 CurrentStatus 方法。
			// 构造数据:
			// - 初始化一个 handlerSendBackUpdate 实例。
			// 逻辑链路:
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值是否等于预期的常量 _const.PreSalesContractSendBack。

			// 准备数据
			h := &handlerSendBackUpdate{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSendBack)
		})
	})
}

func Test_newHandlerSendBackUpdate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSendBackUpdate", t, func() {
		mockey.PatchConvey("正常创建handlerSendBackUpdate实例", func() {
			// 场景描述：
			// 测试 newHandlerSendBackUpdate 函数能否成功创建一个非空的 handlerSendBackUpdate 实例。
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerSendBackUpdate()
			// 2. 断言返回的实例不为nil
			// 3. 断言返回的实例类型为 *handlerSendBackUpdate

			// 调用
			h := newHandlerSendBackUpdate()

			// 断言
			convey.So(h, convey.ShouldNotBeNil)
			convey.So(h, convey.ShouldHaveSameTypeAs, &handlerSendBackUpdate{})
		})
	})
}

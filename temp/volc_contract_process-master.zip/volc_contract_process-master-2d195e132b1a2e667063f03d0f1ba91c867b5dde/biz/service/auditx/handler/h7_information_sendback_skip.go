package handler

import (
	"context"
	"encoding/json"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

func newHandlerInformationSendBackSkip() StatusOpHandler {
	return &handlerInformationSendBackSkip{}
}

// 销售运营完善信息(7) --- 退回(4) --> 销售确认中(5)
type handlerInformationSendBackSkip struct {
	handlerCommon
}

func (h *handlerInformationSendBackSkip) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationCompleteInformation
}

func (h *handlerInformationSendBackSkip) CurrentOp() int {
	return _const.OperationSendBackSkipApproval
}

func (h *handlerInformationSendBackSkip) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	if pc.Comment.IsEmpty() {
		return i18nfmt.Errorf(ctx, "审核意见不可为空")
	}
	if !pc.ContractInfo.BasicInfo.IsSkipFTL {
		return i18nfmt.Errorf(ctx, "此合同未跳过财税法审批，不可执行此操作类型。")
	}
	return nil
}

func (h *handlerInformationSendBackSkip) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 更新BasicInfo中的是否跳过财税法审批节点为false
	pc.ContractInfo.BasicInfo.IsSkipFTL = false
	basicInfoStr, err := json.Marshal(pc.ContractInfo.BasicInfo)
	if err != nil {
		logs.CtxError(ctx, "InformationSendBackSkipFail_BasicMarshal, err:%v", err)
		return err
	}
	pc.PreContractVO.BasicInfo = string(basicInfoStr)

	// 更新基本数据
	if err := h.updateContractData(ctx, pc); err != nil {
		logs.CtxError(ctx, "updateContractDataFail, err:%v", err)
		return err
	}

	return nil
}

func (h *handlerInformationSendBackSkip) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerInformationSendBackSkip) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	h.sendBackNotifyTargetReviewers(ctx, pc)
	h.SendBackNotifyPeerReviewers(ctx, pc)
	return nil
}

package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerDraftUpdate() StatusOpHandler {
	return &handlerDraftUpdate{}
}

// 草稿(1) --- 提交草稿(0) --> 草稿(1)
type handlerDraftUpdate struct {
	handlerCommon
}

func (h *handlerDraftUpdate) CurrentStatus() int {
	return _const.PreSalesContractDraft
}

func (h *handlerDraftUpdate) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerDraftUpdate) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h *handlerDraftUpdate) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerDraftUpdate) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerDraftUpdate) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerFTLSignReviewAddReviewers() StatusOpHandler {
	return &handlerFTLSignReviewAddReviewers{}
}

// 财税法签约审核(9) --- 加签(5) --> 财税法交付专业审核(4)
type handlerFTLSignReviewAddReviewers struct {
	handlerCommon
}

func (h *handlerFTLSignReviewAddReviewers) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalSignReview
}

func (h *handlerFTLSignReviewAddReviewers) CurrentOp() int {
	return _const.OperationAddReviewer
}

func (h *handlerFTLSignReviewAddReviewers) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerFTLSignReviewAddReviewers) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerFTLSignReviewAddReviewers) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerFTLSignReviewAddReviewers) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

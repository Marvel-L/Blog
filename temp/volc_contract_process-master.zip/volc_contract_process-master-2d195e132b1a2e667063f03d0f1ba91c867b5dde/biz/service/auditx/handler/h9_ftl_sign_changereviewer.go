package handler

import (
	"context"
	"volc_contract_process/biz/service/riskclauserole"

	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerFTLSignReviewChangeReviewer() StatusOpHandler {
	return &handlerFTLSignReviewChangeReviewer{}
}

// 财税法签约审核(9) --- 转办(6) --> 财税法交付专业审核(4)
type handlerFTLSignReviewChangeReviewer struct {
	handlerCommon
}

func (h *handlerFTLSignReviewChangeReviewer) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalSignReview
}

func (h *handlerFTLSignReviewChangeReviewer) CurrentOp() int {
	return _const.OperationChangeReviewer
}

func (h *handlerFTLSignReviewChangeReviewer) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerFTLSignReviewChangeReviewer) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 风险条款创建人转办
	return riskclauserole.NewService().ChangeRiskRoleCreator(ctx, pc.ContractInfo.ContractNo, pc.Extra, []string{pc.CurrentOperator})
}

func (h *handlerFTLSignReviewChangeReviewer) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerFTLSignReviewChangeReviewer) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

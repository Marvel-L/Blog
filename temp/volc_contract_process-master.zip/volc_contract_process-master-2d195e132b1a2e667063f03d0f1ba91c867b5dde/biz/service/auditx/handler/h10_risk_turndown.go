package handler

import (
	"context"
	"encoding/json"

	"code.byted.org/fido2/sdk/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

func newHandlerRiskTurnDown() StatusOpHandler {
	return &handlerRiskTurnDown{}
}

// 风险条款审核(10) --- 驳回(18) --> 财税法交付专业审核(4)
type handlerRiskTurnDown struct {
	handlerCommon
}

func (h *handlerRiskTurnDown) CurrentStatus() int {
	return _const.PreSalesContractRiskReview
}

func (h *handlerRiskTurnDown) CurrentOp() int {
	return _const.OperationTurnDown
}

func (h *handlerRiskTurnDown) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.Comment.IsEmpty() {
		return i18nfmt.Errorf(ctx, "审核意见不可为空")
	}
	return nil
}

func (h *handlerRiskTurnDown) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 退回时默认清除是否跳过财税法标识
	pc.ContractInfo.BasicInfo.IsSkipFTL = false
	basicInfoStr, err := json.Marshal(pc.ContractInfo.BasicInfo)
	if err != nil {
		logs.CtxError(ctx, "RiskTurnDownFail_BasicMarshal, err:%v", err)
		return err
	}
	// 更新合同基本信息
	if err := dal.NewContractMetaDao().UpdateFieldsByNo(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, map[string]interface{}{
		"basic_info": string(basicInfoStr),
	}); err != nil {
		logs.CtxError(ctx, "UpdateFieldsByNoFail, err:%v", err)
		return err
	}
	return nil
}

func (h *handlerRiskTurnDown) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerRiskTurnDown) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

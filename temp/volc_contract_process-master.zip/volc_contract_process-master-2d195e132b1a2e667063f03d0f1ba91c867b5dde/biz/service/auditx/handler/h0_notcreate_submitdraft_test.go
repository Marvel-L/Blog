package handler

import (
	"code.byted.org/lang/gg/gptr"
	"context"
	"encoding/json"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/supply"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerNotCreateSubmitDraft_Validate_BitsUTGen(t *testing.T) {
	// Mock interfaces for services
	type MockMetaService struct {
		contractmeta.MetaService
	}
	type MockSupplyService struct {
		supply.SupplyService
	}

	mockey.PatchConvey("Test handlerNotCreateSubmitDraft.Validate", t, func() {
		// Initialize the handler instance
		h := &handlerNotCreateSubmitDraft{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: 非补充协议场景, 校验成功", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.SupplySource 为空字符串, 表示非补充协议
			// 逻辑链路:
			// 1. validateSupply 函数判断 SupplySource 为空
			// 2. 为 pc.PreContractVO.MainContractNo 和 pc.ContractInfo.MainContractNo 赋值
			// 3. 返回 nil, Validate 函数也返回 nil
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo:   "CONTRACT-123",
					SupplySource: "",
				},
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT-123",
				},
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "CONTRACT-123")
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "CONTRACT-123")
		})

		mockey.PatchConvey("场景2: 补充协议场景, 但原合同号为空, 校验失败", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.SupplySource 非空, 但 pc.PreContractVO.FromContractNo 为空
			// 逻辑链路:
			// 1. validateSupply 函数判断 SupplySource 非空
			// 2. 检查 FromContractNo, 发现为空, 返回错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "",
				},
				ContractInfo: &model.ContractMeta{},
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "原合同号不能为空")
		})

		mockey.PatchConvey("场景3: 补充协议场景, 获取补充协议列表失败", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.SupplySource 和 pc.PreContractVO.FromContractNo 均非空
			// 逻辑链路:
			// 1. Mock contractmeta.NewMetaService 返回 mock service
			// 2. Mock GetSupplyContractList 方法返回错误
			// 3. validateSupply 函数调用 GetSupplyContractList 失败, 返回错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{},
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			// The original code used errors.New which returns a standard error, not errors.APIError.
			// Fixed by using errorsV2.ErrCommon which returns an object implementing errors.APIError.
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, errorsV2.ErrCommon.WithArgs("db query failed")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
		})

		mockey.PatchConvey("场景4: 补充协议场景, 获取的补充协议列表为空", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.SupplySource 和 pc.PreContractVO.FromContractNo 均非空
			// 逻辑链路:
			// 1. Mock contractmeta.NewMetaService 返回 mock service
			// 2. Mock GetSupplyContractList 方法返回 (nil, nil)
			// 3. validateSupply 函数判断 supplyContractList 为 nil, 返回错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{},
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "补充协议相关合同信息不存在")
		})

		mockey.PatchConvey("场景5: 补充协议场景, 基础校验失败", func() {
			// 场景描述:
			// 构造数据: 正常补充协议数据
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 成功返回
			// 2. Mock supply.NewSupplyService 返回 mock service
			// 3. Mock supplyService.ValidateBase 返回错误
			// 4. validateSupply 调用 ValidateBase 失败, 返回其错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{},
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{},
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			expectedErr := errorsV2.ErrCommon.WithArgs("base validation failed")
			mockey.Mock((*MockSupplyService).ValidateBase).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景6: 变更报价单场景, 解析 Extra 失败", func() {
			// 场景描述:
			// 构造数据: OperationState 为 OperationChangeQuoteNo, 但 Extra 是无效的 JSON
			// 逻辑链路:
			// 1. GetSupplyContractList 成功
			// 2. json.Unmarshal 解析 Extra 失败, 返回错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo:   &model.ContractMeta{},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          `{invalid json`,
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解析合同变更信息失败")
		})

		mockey.PatchConvey("场景7: 需要校验有效期但校验失败", func() {
			// 场景描述:
			// 构造数据: CooperationStatus 满足校验条件, 且非变更报价单操作
			// 逻辑链路:
			// 1. GetSupplyContractList 成功
			// 2. ValidateBase 成功
			// 3. utils.IntIn 返回 true
			// 4. Mock supplyService.ValidateValidityTime 返回错误
			// 5. validateSupply 调用 ValidateValidityTime 失败, 返回其错误
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
				},
				OperationState: 0, // Not OperationChangeQuoteNo
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{},
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			expectedErr := errorsV2.ErrCommon.WithArgs("validity time validation failed")
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景8: 全流程校验成功 (不校验有效期)", func() {
			// 场景描述:
			// 构造数据: CooperationStatus 不满足有效期校验条件
			// 逻辑链路:
			// 1. GetSupplyContractList 成功
			// 2. ValidateBase 成功
			// 3. utils.IntIn 返回 false, 跳过有效期校验
			// 4. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
				},
				OperationState: 0,
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{},
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景9: 全流程校验成功 (变更报价单)", func() {
			// 场景描述:
			// 构造数据: OperationState 为 OperationChangeQuoteNo
			// 逻辑链路:
			// 1. GetSupplyContractList 成功
			// 2. json.Unmarshal 成功
			// 3. ValidateBase 成功
			// 4. 跳过有效期校验
			// 5. 函数返回 nil
			changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "NEW-QUOTE-789"}
			extraBytes, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          string(extraBytes),
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{},
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景10: 全流程校验成功 (需要校验有效期)", func() {
			// 场景描述:
			// 构造数据: CooperationStatus 满足校验条件, 且非变更报价单操作
			// 逻辑链路:
			// 1. GetSupplyContractList 成功, 并且返回的原合同信息会被填充
			// 2. ValidateBase 成功
			// 3. utils.IntIn 返回 true
			// 4. Mock supplyService.ValidateValidityTime 返回 nil
			// 5. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
					ProjectInfo:    "{}", // empty json to avoid unmarshal error
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: 0,
			}
			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test@example.com"),
					},
				},
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景11: 全流程成功, 但因 RelateQuoteNo 存在而跳过填充补充信息", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.RelateQuoteNo 非空
			// 逻辑链路:
			// 1. GetSupplyContractList 成功, 返回的 FromContract 包含 ManageInfo, ProjectInfo 等
			// 2. 调用 fillSupplyExtInfoByFromContractInfo
			// 3. fillSupplyExtInfoByFromContractInfo 内部因为 RelateQuoteNo 非空, 直接返回 nil
			// 4. 后续校验成功, Validate 返回 nil
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "FROM-CONTRACT-456",
					RelateQuoteNo:  "QUOTE-123",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
				},
			}

			mockMetaService := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			fromContract := &bizmodels.ContractMetaInfo{
				ManageInfo: &bizmodels.ManageInfo{
					BelongingDepartment: "dept1",
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					ProductSolutionEmail: gptr.Of("test@example.com"),
				},
			}
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				FromContract: fromContract,
			}, nil).Build()

			mockSupplyService := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplyService).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(false).Build() // Skip validity time check

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerNotCreateSubmitDraft_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerNotCreateSubmitDraft Process", t, func() {
		// 构造通用测试数据
		ctx := context.Background()
		h := &handlerNotCreateSubmitDraft{}
		pc := &auditmodel.ProcessCtx{
			PreContractVO: &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Id: 1,
				},
				ContractNo: "test-contract-no",
			},
			ContractInfo: &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
				SettlementInfo: &bizmodels.SettlementInfo{
					SettlementLines: bizmodels.SettlementLines{},
				},
				Ext: map[string]string{},
			},
			DelExtKeys:           []string{},
			AttachmentUpdateList: []*bizmodels.MetaAttachment{},
		}
		dummyTx := &gorm.DB{}

		// Mock ProcessCtx.GetTx() 方法，使其返回一个虚拟的 gorm.DB 实例
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(dummyTx).Build()

		convey.Convey("成功场景", func() {
			// 场景描述：所有依赖的函数都成功执行
			// 构造数据：无特殊构造
			// 逻辑链路：
			// 1. GetTemplateFileId 返回一个有效的文件ID且无错误
			// 2. h.CreateOrUpdateAttachment 返回无错误
			// 3. h.updatePreContract 返回无错误
			// 4. h.SaveManageInfo 返回无错误
			// 5. h.SaveTradePartyInfo 返回无错误
			// 6. h.SaveMetaExt 返回无错误
			// 7. h.updateContractSettlement 返回无错误
			// 8. h.updateAttachment 返回无错误
			// 9. 最终 Process 方法应返回 nil

			// Mock依赖
			mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
			mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractSettlement).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateAttachment).Return(nil).Build()

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("失败场景", func() {
			convey.Convey("当 GetTemplateFileId 失败时", func() {
				// 场景描述：获取模板文件ID失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. GetTemplateFileId 返回一个错误
				// 2. Process 方法应立即返回该错误
				expectedErr := errors.New("get template file id failed")
				mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})

			convey.Convey("当 CreateOrUpdateAttachment 失败时", func() {
				// 场景描述：创建或更新附件失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. GetTemplateFileId 成功
				// 2. h.CreateOrUpdateAttachment 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errors.New("create or update attachment failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})

			convey.Convey("当 updatePreContract 失败时", func() {
				// 场景描述：更新预合同信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. GetTemplateFileId 和 CreateOrUpdateAttachment 成功
				// 2. h.updatePreContract 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errors.New("update pre-contract failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})

			convey.Convey("当 SaveManageInfo 失败时", func() {
				// 场景描述：保存管理信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. 前续步骤均成功
				// 2. h.SaveManageInfo 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errorsV2.ErrInternalError.WithArgs("save manage info failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "save manage info failed")
			})

			convey.Convey("当 SaveTradePartyInfo 失败时", func() {
				// 场景描述：保存交易方信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. 前续步骤均成功
				// 2. h.SaveTradePartyInfo 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errorsV2.ErrInternalError.WithArgs("save trade party info failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "save trade party info failed")
			})

			convey.Convey("当 SaveMetaExt 失败时", func() {
				// 场景描述：保存元数据扩展信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. 前续步骤均成功
				// 2. h.SaveMetaExt 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errorsV2.ErrInternalError.WithArgs("save meta ext failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "save meta ext failed")
			})

			convey.Convey("当 updateContractSettlement 失败时", func() {
				// 场景描述：更新合同结算信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. 前续步骤均成功
				// 2. h.updateContractSettlement 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errors.New("update contract settlement failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractSettlement).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})

			convey.Convey("当 updateAttachment 失败时", func() {
				// 场景描述：更新附件信息失败
				// 构造数据：无特殊构造
				// 逻辑链路：
				// 1. 前续步骤均成功
				// 2. h.updateAttachment 返回一个错误
				// 3. Process 方法应立即返回该错误
				expectedErr := errors.New("update attachment failed")
				mockey.Mock(GetTemplateFileId).Return("test-file-id", nil).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractSettlement).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateAttachment).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})
		})
	})
}

func Test_newHandlerNotCreateSubmitDraft_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerNotCreateSubmitDraft", t, func() {
		mockey.PatchConvey("should return a non-nil handler of type *handlerNotCreateSubmitDraft", func() {
			// 场景描述：
			// 正常调用 newHandlerNotCreateSubmitDraft 函数。
			// 构造数据：
			// 无特殊数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerNotCreateSubmitDraft() 函数。
			// 2. 断言返回的 handler 不为 nil。
			// 3. 断言返回的 handler 的具体类型为 *handlerNotCreateSubmitDraft。

			// 调用
			handler := newHandlerNotCreateSubmitDraft()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerNotCreateSubmitDraft{})
		})
	})
}

func Test_handlerNotCreateSubmitDraft_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerNotCreateSubmitDraft_CurrentStatus", t, func() {
		mockey.PatchConvey("正常返回当前状态", func() {
			// 场景描述：
			// 调用 CurrentStatus 方法，期望返回常量 PreSalesContractNotCreated。
			// 构造数据：
			// 初始化一个 handlerNotCreateSubmitDraft 实例。
			// 逻辑链路：
			// 1. 创建 handlerNotCreateSubmitDraft 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值等于 _const.PreSalesContractNotCreated。

			// 数据准备
			h := &handlerNotCreateSubmitDraft{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractNotCreated)
		})
	})
}

func Test_handlerNotCreateSubmitDraft_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerNotCreateSubmitDraft_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerNotCreateSubmitDraft 实例。
			// 逻辑链路：调用 CurrentOp 方法，验证其返回值是否为预期的常量 _const.OperationSubmitDraft。
			h := &handlerNotCreateSubmitDraft{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerNotCreateSubmitDraft_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerNotCreateSubmitDraft_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 目标函数 `HitStateChangeCondition` 总是返回 (true, nil)，与输入参数无关。
			// 构造数据：
			// - h: 一个 `handlerNotCreateSubmitDraft` 的实例。
			// - ctx: 一个 `context.Background()`。
			// - pc: 一个空的 `auditmodel.ProcessCtx` 指针。
			// 逻辑链路：
			// 1. 调用 `HitStateChangeCondition` 方法。
			// 2. 断言返回的布尔值为 true。
			// 3. 断言返回的错误为 nil。

			// 数据准备
			h := &handlerNotCreateSubmitDraft{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerNotCreateSubmitDraft_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerNotCreateSubmitDraft_PostProcess", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 这是一个空函数，直接返回nil。
			// 构造数据：
			// - h: 一个handlerNotCreateSubmitDraft实例
			// - ctx: 一个空的context
			// - pc: 一个空的ProcessCtx实例
			// 逻辑链路：
			// 1. 调用PostProcess方法
			// 2. 断言返回的error为nil
			h := &handlerNotCreateSubmitDraft{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

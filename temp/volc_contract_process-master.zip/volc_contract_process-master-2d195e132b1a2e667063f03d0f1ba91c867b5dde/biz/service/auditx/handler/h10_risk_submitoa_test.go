package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"
	"time"

	"code.byted.org/eps-platform/quote_sdk_go/quote_client"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerRiskSubmitOA_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSubmitOA_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 直接调用 CurrentStatus 方法，期望返回固定的状态值。
			// 构造数据：
			// 无特殊数据构造。
			// 逻辑链路：
			// 1. 创建 handlerRiskSubmitOA 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值等于 _const.PreSalesContractRiskReview。
			h := &handlerRiskSubmitOA{}

			status := h.CurrentStatus()

			convey.So(status, convey.ShouldEqual, _const.PreSalesContractRiskReview)
		})
	})
}

func Test_handlerRiskSubmitOA_Validate(t *testing.T) {
	// 测试输入validateSupply返回错误的场景
	t.Run("ValidateSupplyReturnError", func(t *testing.T) {
		mockey.PatchConvey("当validateSupply返回错误时，函数应立即返回该错误", t, func() {
			// 场景描述:
			// 验证当 h.validateSupply 函数调用返回一个错误时，Validate 函数会立即将此错误向上传递并终止执行。
			// 数据构造:
			// - pc: 一个空的 ProcessCtx 实例即可。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 方法，使其返回一个预设的错误。
			// 2. 调用目标函数 Validate。
			// 3. 断言返回的错误不为 nil，并且错误信息与 Mock 的错误信息一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(fmt.Errorf("mock an error return")).Build()
			// 构造函数入参
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{}
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "mock an error return")
		})
	})

	// 测试"是否项目制"字段缺失的场景
	t.Run("MissingWhetherProject", func(t *testing.T) {
		mockey.PatchConvey("当'是否项目制'字段缺失时，应返回参数缺失错误", t, func() {
			// 场景描述:
			// 验证在补充协议校验通过后，如果合同基本信息中的 "WhetherProject" 字段为空，函数会返回参数缺失的错误。
			// 数据构造:
			// - pc.ContractInfo.BasicInfo.WhetherProject 设置为空字符串。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 方法，使其返回 nil (正常通过)。
			// 2. 构造一个 BasicInfo，其中 WhetherProject 字段为空。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误是 ErrMissingParam，并且错误信息包含 "WhetherProject"。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "", // 关键测试数据：字段为空
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "WhetherProject")
			convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrMissingParam)
		})
	})

	// 测试需要关联报价单但未提供报价单号的场景
	t.Run("NeedRelateQuoteNoButNoQuoteNo", func(t *testing.T) {
		mockey.PatchConvey("当合同必须关联报价单但未提供时，应返回报价单通用错误", t, func() {
			// 场景描述:
			// 验证当合同需要关联报价单 (NeedRelateQuoteNo 返回 true) 但实际上并未提供报价单号 (RelateQuoteNo 为空) 时，函数会返回错误。
			// 数据构造:
			// - pc.ContractInfo.RelateQuoteNo 设置为空字符串。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 方法，使其返回 nil。
			// 2. Mock (*model.ContractMeta).NeedRelateQuoteNo 方法，使其返回 true。
			// 3. 构造一个 ContractInfo，其中 RelateQuoteNo 为空。
			// 4. 调用目标函数 Validate。
			// 5. 断言返回的错误是 ErrQuoteCommon，并且错误信息提示必须关联报价单。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "", // 关键测试数据：报价单号为空
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前合同必须关联报价单")
		})
	})

	// 测试关联报价单时对方主体缺少账号ID的场景
	t.Run("MissingAccountIDInOtherPartyWhenRelatingQuote", func(t *testing.T) {
		mockey.PatchConvey("关联报价单时对方主体缺少账号ID，应返回错误", t, func() {
			// 场景描述:
			// 验证当合同需要关联报价单时，如果任一交易对方 (OtherParty) 的 AccountID 为空，函数会返回错误。
			// 数据构造:
			// - pc.ContractInfo.TradePartyInfo.OtherParty 包含一个 AccountID 为空的元素。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 和 (*model.ContractMeta).NeedRelateQuoteNo 为正常通过。
			// 2. 构造一个 OtherParty 列表，其中一个元素的 AccountID 为空。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误信息为 "合同账号ID缺失"。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("合同账号ID缺失")).When(func(_ context.Context, text string) bool {
				return text == "合同账号ID缺失"
			})

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q123",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{AccountID: ""}, // 关键测试数据：AccountID为空
						},
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同账号ID缺失")
		})
	})

	// 测试查询报价单失败的场景
	t.Run("QuoteInfoQueryError", func(t *testing.T) {
		mockey.PatchConvey("当查询报价单信息失败时，应返回查询失败错误", t, func() {
			// 场景描述:
			// 验证当调用 quotecli.GetQuoteInfo 接口返回错误时，Validate 函数能够捕获该错误并返回一个用户友好的提示。
			// 数据构造:
			// - 无特殊数据构造要求，只需确保流程进入 GetQuoteInfo 调用。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 和 (*model.ContractMeta).NeedRelateQuoteNo 为正常通过。
			// 2. Mock quotecli.GetQuoteInfo 方法，使其返回一个错误。
			// 3. Mock i18nfmt.New 方法，使其在接收到 "查询报价单失败" 时返回一个特定的 error 对象。
			// 4. 调用目标函数 Validate。
			// 5. 断言返回的错误与 i18nfmt.New Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(nil, fmt.Errorf("mock an error return")).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("查询报价单失败")).When(func(_ context.Context, text string) bool {
				return text == "查询报价单失败"
			})
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{AccountID: "test_id"}},
					},
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					RelateQuoteNo: "not empty",
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价单失败")
		})
	})

	// 测试查询到的报价单信息为空的场景
	t.Run("GetQuoteInfoReturnsNil", func(t *testing.T) {
		mockey.PatchConvey("当查询到的报价单不存在时，应返回报价单不存在的错误", t, func() {
			// 场景描述:
			// 验证当 quotecli.GetQuoteInfo 成功返回但结果为 nil (表示报价单不存在) 时，函数能正确处理并返回相应的错误信息。
			// 数据构造:
			// - pc.ContractInfo.RelateQuoteNo 设置一个虚构的报价单号。
			// 逻辑链路:
			// 1. Mock 前置检查正常通过。
			// 2. Mock quotecli.GetQuoteInfo 方法，使其返回 (nil, nil)。
			// 3. Mock i18nfmt.Errorf 方法，使其在格式化 "关联的报价单...不存在" 字符串时返回一个特定的 error 对象。
			// 4. 调用目标函数 Validate。
			// 5. 断言返回的错误与 i18nfmt.Errorf Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(nil, nil).Build() // 关键Mock：返回nil info
			mockey.Mock(i18nfmt.Errorf, mockey.OptUnsafe).Return(errors.New("关联的报价单[Q-NotExist]不存在")).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-NotExist",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{AccountID: "test_id"}},
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "关联的报价单[Q-NotExist]不存在")
		})
	})

	// 测试validateUsefulLifeType函数返回错误的场景
	t.Run("ValidateUsefulLifeTypeReturnError", func(t *testing.T) {
		mockey.PatchConvey("当合同有效期类型校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证在关联报价单的场景下，如果 validateUsefulLifeType 函数校验失败，Validate 函数会返回该错误。
			// 数据构造:
			// - 无特殊数据构造要求，只需保证流程能进入 validateUsefulLifeType 调用。
			// 逻辑链路:
			// 1. Mock 前置检查正常通过。
			// 2. Mock quotecli.GetQuoteInfo 成功返回报价单信息。
			// 3. Mock validateUsefulLifeType 方法，使其返回一个预设的错误。
			// 4. 调用目标函数 Validate。
			// 5. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(nil).Build()
			mockey.Mock(i18nfmt.Errorf, mockey.OptUnsafe).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(&quote_client.QuoteRespSimpleInfo{}, nil).Build()
			mockey.Mock(validateUsefulLifeType).Return(errorsV2.ErrCommon.WithArgs("mock an error return")).Build() // 关键Mock
			// 构造函数入参
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo:  "Test Value",
					TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{AccountID: "test_id"}}},
					ContractNo:     "Test Value",
					ManageInfo:     &bizmodels.ManageInfo{},
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock an error return")
		})
	})

	// 测试validateAccountAssociationInfo函数返回错误的场景
	t.Run("ValidateAccountAssociationInfoError", func(t *testing.T) {
		mockey.PatchConvey("当账号分组信息校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证在关联报价单的场景下，如果 validateAccountAssociationInfo 函数校验失败，Validate 函数会返回该错误。
			// 数据构造:
			// - 无特殊数据构造要求，只需保证流程能进入 validateAccountAssociationInfo 调用。
			// 逻辑链路:
			// 1. Mock 前置检查及 validateUsefulLifeType 正常通过。
			// 2. Mock validateAccountAssociationInfo 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(&quote_client.QuoteRespSimpleInfo{}, nil).Build()
			mockey.Mock(validateUsefulLifeType).Return(nil).Build()
			mockey.Mock(validateAccountAssociationInfo).Return(errors.New("account association error")).Build() // 关键Mock

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo:  "Q123",
					TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{AccountID: "test_id"}}},
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "account association error")
		})
	})

	// 测试"是否项目制"标识与报价单不一致的场景
	t.Run("WhetherProjectMismatch", func(t *testing.T) {
		mockey.PatchConvey("当合同与报价单的'是否项目制'标识不一致时，应返回错误", t, func() {
			// 场景描述:
			// 验证在关联报价单的场景下，如果合同信息和管理信息中的 "WhetherProject" 字段不一致，函数会返回错误。
			// 数据构造:
			// - pc.ContractInfo.BasicInfo.WhetherProject 与 pc.ContractInfo.ManageInfo.WhetherProject 设置为不同的值。
			// 逻辑链路:
			// 1. Mock 前置检查及之前的校验函数全部正常通过。
			// 2. 构造一个 ContractInfo，使其 BasicInfo 和 ManageInfo 中的 WhetherProject 字段不一致。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误信息为 "合同是否项目制标识需与报价单保持一致"。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(&quote_client.QuoteRespSimpleInfo{}, nil).Build()
			mockey.Mock(validateUsefulLifeType).Return(nil).Build()
			mockey.Mock(validateAccountAssociationInfo).Return(nil).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo:  "Q123",
					TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{AccountID: "test_id"}}},
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y", // 关键测试数据
					},
					ManageInfo: &bizmodels.ManageInfo{
						WhetherProject: "N", // 关键测试数据
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同是否项目制标识需与报价单保持一致")
		})
	})

	// 测试ValidateContractPeriod函数返回错误的场景
	t.Run("ValidateContractPeriodReturnError", func(t *testing.T) {
		mockey.PatchConvey("当合同有效期校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 BasicInfo 的 ValidateContractPeriod 方法返回错误，Validate 函数会返回该错误。
			// 数据构造:
			// - 使用不关联报价单的场景以简化 Mock。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).validateSupply 和 (*model.ContractMeta).NeedRelateQuoteNo 为正常通过。
			// 2. Mock (*bizmodels.BasicInfo).ValidateContractPeriod 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build() // 不关联报价单
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(fmt.Errorf("mock an error return")).Build()
			// 构造函数入参
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ContractNo: "Test Value",
				},
			}
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock an error return")
		})
	})

	// 测试 validateTradePartyInfo 函数返回错误的场景
	t.Run("ValidateTradePartyInfoReturnError", func(t *testing.T) {
		mockey.PatchConvey("当交易对方信息校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 validateTradePartyInfo 函数返回错误，Validate 函数会返回该错误。
			// 数据构造:
			// - 使用不关联报价单的场景以简化 Mock。
			// 逻辑链路:
			// 1. Mock 前置检查及 ValidateContractPeriod 正常通过。
			// 2. Mock validateTradePartyInfo 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(fmt.Errorf("mock an error return")).Build()
			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "mock an error return")
		})
	})

	// 测试validateRiskClauseRole函数返回错误的场景
	t.Run("ValidateRiskClauseRoleReturnError", func(t *testing.T) {
		mockey.PatchConvey("当风险条款角色校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 validateRiskClauseRole 函数返回错误，Validate 函数会返回该错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. Mock validateRiskClauseRole 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(fmt.Errorf("mock an error return")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "mock an error return")
		})
	})

	// 测试 validateProjectInfo 函数返回错误的场景
	t.Run("ValidateProjectInfoReturnError", func(t *testing.T) {
		mockey.PatchConvey("当项目信息校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 validateProjectInfo 函数返回错误，Validate 函数会返回该错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. Mock validateProjectInfo 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(fmt.Errorf("mock an error return")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "mock an error return")
		})
	})

	// 测试 validateTermChangeDetail 函数返回错误的场景
	t.Run("ValidateTermChangeDetailError", func(t *testing.T) {
		mockey.PatchConvey("当条款变更详情校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 validateTermChangeDetail 函数返回错误，Validate 函数会返回该错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. Mock validateTermChangeDetail 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(errors.New("term change detail error")).Build() // 关键Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "term change detail error")
		})
	})

	// 测试 ValidateExternalCommodity 函数返回错误的场景
	t.Run("ValidateExternalCommodityError", func(t *testing.T) {
		mockey.PatchConvey("当外部商品信息校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 ManageInfo 的 ValidateExternalCommodity 方法返回错误，Validate 函数会返回该错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. Mock (*bizmodels.ManageInfo).ValidateExternalCommodity 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(errorsV2.ErrCommon.WithArgs("external commodity error")).Build() // 关键Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "external commodity error")
		})
	})

	// 测试 validateAccountIdRequired 函数返回错误的场景
	t.Run("ValidateAccountIdRequiredError", func(t *testing.T) {
		mockey.PatchConvey("当账号ID必填校验失败时，应返回相应错误", t, func() {
			// 场景描述:
			// 验证如果 validateAccountIdRequired 函数返回错误，Validate 函数会返回该错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. Mock validateAccountIdRequired 方法，使其返回一个预设的错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的错误与 Mock 的错误一致。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(errorsV2.ErrCommon.WithArgs("account id required error")).Build() // 关键Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					ContractNo: "C2024001",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "account id required error")
		})
	})

	// 测试结算条款DB查询失败的场景
	t.Run("ListSettlementError", func(t *testing.T) {
		mockey.PatchConvey("当查询结算条款列表失败时，应返回数据库错误", t, func() {
			// 场景描述:
			// 验证在特定条件下（收入类合同、非报价单来源、非自采平台），如果查询结算条款的数据库操作失败，函数会返回错误。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. 构造一个符合结算条款检查条件的 pc 对象。
			// 3. Mock dal.NewContractSettlementDao 以返回一个自定义的 mock DAO 对象。
			// 4. Mock mock DAO 对象的 ListContractSettlementByContractID 方法，使其返回一个错误。
			// 5. 调用目标函数 Validate。
			// 6. 断言返回的错误信息包含 "ListContractSettlementByContractID_Fail"。
			settlementDao := dal.NewContractSettlementDao()
			mockey.Mock(dal.NewContractSettlementDao).Return(settlementDao).Build()
			mockey.Mock(mockey.GetMethod(settlementDao, "ListContractSettlementByContractID")).Return(nil, errors.New("db error")).Build()

			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("ListContractSettlementByContractID_Fail:db error")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					InOutType: _const.BizInOutTypeIn, // 关键测试数据
					BizSource: 0,                     // 关键测试数据
				},
				ContractInfo: &model.ContractMeta{
					Initiator: 0, // 关键测试数据
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListContractSettlementByContractID_Fail")
		})
	})

	// 测试结算条款为空的场景
	t.Run("EmptySettlementLines", func(t *testing.T) {
		mockey.PatchConvey("当收入类合同缺少结算条款时，应返回必填错误", t, func() {
			// 场景描述:
			// 验证在特定条件下，如果查询到的结算条款列表为空，函数会返回错误提示 "结算条款模块必填"。
			// 逻辑链路:
			// 1. Mock 前置所有检查正常通过。
			// 2. 构造一个符合结算条款检查条件的 pc 对象。
			// 3. Mock dal.NewContractSettlementDao 以返回一个 mock DAO 对象。
			// 4. Mock mock DAO 对象的 ListContractSettlementByContractID 方法，使其返回一个空列表。
			// 5. 调用目标函数 Validate。
			// 6. 断言返回的错误信息为 "当合同收支类型为“收入类” / “既收又支”时，结算条款模块必填"。
			settlementDao := dal.NewContractSettlementDao()
			mockey.Mock(dal.NewContractSettlementDao).Return(settlementDao).Build()
			mockey.Mock(mockey.GetMethod(settlementDao, "ListContractSettlementByContractID")).Return([]*model.ContractSettlementDB{}, nil).Build() // 关键Mock

			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("当合同收支类型为“收入类” / “既收又支”时，结算条款模块必填")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					InOutType: _const.BizInOutTypeInAndOut, // 关键测试数据
					BizSource: _const.BizSourceQuote + 1,   // 关键测试数据
				},
				ContractInfo: &model.ContractMeta{
					Initiator: _const.InitiatorSelfPurchase + 1, // 关键测试数据
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款模块必填")
		})
	})

	// 测试IsReverseContract返回错误，应填充倒签信息的场景
	t.Run("IsReverseContractErrorShouldPopulate", func(t *testing.T) {
		mockey.PatchConvey("当IsReverseContract返回错误时，应自动填充倒签信息并继续执行", t, func() {
			// 场景描述:
			// 验证当 IsReverseContract 方法返回错误时，Validate 函数不会中断，而是会为合同补充默认的倒签信息，并最终成功返回。
			// 逻辑链路:
			// 1. Mock 所有前置检查都正常通过。
			// 2. Mock (*handlerCommon).IsReverseContract 方法，使其返回一个错误。
			// 3. 调用目标函数 Validate。
			// 4. 断言最终返回的 err 为 nil。
			// 5. 断言 pc.ContractInfo.ReverseSignInfo 已被填充为预设的默认值。
			// 6. 断言 pc.PreContractVO.ReverseSignInfo 已被填充为对应的 JSON 字符串。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(errors.New("reverse error")).Build() // 关键Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					InOutType: _const.OUT,
				},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldBeNil) // 即使IsReverseContract失败，函数也应该成功
			convey.So(pcTest.ContractInfo.ReverseSignInfo, convey.ShouldNotBeNil)
			convey.So(pcTest.ContractInfo.ReverseSignInfo.ReverseSignCode, convey.ShouldEqual, "RS008")
			convey.So(pcTest.PreContractVO.ReverseSignInfo, convey.ShouldNotBeEmpty)

			var reverseInfo bizmodels.ReverseSignInfo
			jsonErr := json.Unmarshal([]byte(pcTest.PreContractVO.ReverseSignInfo), &reverseInfo)
			convey.So(jsonErr, convey.ShouldBeNil)
			convey.So(reverseInfo.ReverseSignCode, convey.ShouldEqual, "RS008")
		})
	})

	// 测试所有校验均通过的成功场景
	t.Run("Success", func(t *testing.T) {
		mockey.PatchConvey("当所有校验都通过时，函数应返回nil", t, func() {
			// 场景描述:
			// 验证在所有依赖项都正常工作且校验逻辑都通过的情况下，Validate 函数最终返回 nil。
			// 逻辑链路:
			// 1. Mock 所有依赖的函数和方法，使其都返回 nil 或表示成功的值。
			// 2. 构造一个能通过所有检查的 pc 对象。
			// 3. 调用目标函数 Validate。
			// 4. 断言返回的 err 为 nil。
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo, mockey.OptUnsafe).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx, mockey.OptUnsafe).Return(&gorm.DB{}).Build()

			// 构造函数入参
			var receiver *handlerRiskSubmitOA = &handlerRiskSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					InOutType: _const.OUT, // 避免进入结算条款校验
				},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Yes",
					},
					ManageInfo: &bizmodels.ManageInfo{},
				},
			}
			// 运行被测函数
			err := receiver.Validate(ctxTest, pcTest)
			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerRiskSubmitOA_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSubmitOA_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况-无条件返回true", func() {
			// 场景描述：
			// HitStateChangeCondition函数当前实现为无条件返回true和nil。
			// 构造数据：
			// - h: 一个空的handlerRiskSubmitOA实例
			// - ctx: context.Background()
			// - pc: 一个空的auditmodel.ProcessCtx实例
			// 逻辑链路：
			// 1. 调用目标函数。
			// 2. 断言返回值为true和nil。

			h := &handlerRiskSubmitOA{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			got, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerRiskSubmitOA_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSubmitOA_Process", t, func() {
		ctx := context.Background()
		h := &handlerRiskSubmitOA{}

		mockey.PatchConvey("当更新合同数据和发送OA消息都成功时，应返回nil", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，包含PreContractVO和ContractInfo。
			// 逻辑链路：
			// 1. Mock `(h *handlerCommon).updateContractData` 方法返回成功 (nil)。
			// 2. Mock `mqProducer.SendDeferMessage` 方法返回成功 (nil)，这将导致 `(h *handlerCommon).SendSubmitOaMsg` 成功。
			// 3. 调用 `Process` 方法。
			// 4. 断言返回的错误为nil。
			// 5. 断言 `pc.Extra` 被清空。

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "CONT-123",
				},
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONT-123",
				},
				Extra: "initial_extra_data",
			}

			// mockey can mock unexported methods in the same package
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()

			mockey.Mock(mqProducer.SendDeferMessage).To(func(ctx context.Context, deferTime time.Duration, data *bizmodels.DeferMsg) error {
				// Assertions on the message being sent
				convey.So(data.DeferType, convey.ShouldEqual, _const.DeferTypeSalesSubmitOA)
				var detail bizmodels.DeferMsgSubmitOA
				err := json.Unmarshal([]byte(data.Body), &detail)
				convey.So(err, convey.ShouldBeNil)
				convey.So(detail.ContractNo, convey.ShouldEqual, "CONT-123")
				return nil
			}).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.Extra, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("当更新合同数据失败时，应返回错误", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx。
			// 逻辑链路：
			// 1. Mock `(h *handlerCommon).updateContractData` 方法返回一个错误。
			// 2. 调用 `Process` 方法。
			// 3. 断言返回一个非nil的错误，并且错误信息包含原始错误信息。

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "CONT-123",
				},
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONT-123",
				},
			}
			mockErr := errors.New("update contract data failed")

			mockey.Mock((*handlerCommon).updateContractData).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, mockErr.Error())
			convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrCommon)
		})

		mockey.PatchConvey("当发送OA消息失败时，应返回错误", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx。
			// 逻辑链路：
			// 1. Mock `(h *handlerCommon).updateContractData` 方法返回成功 (nil)。
			// 2. Mock `mqProducer.SendDeferMessage` 方法返回一个错误，这将导致 `(h *handlerCommon).SendSubmitOaMsg` 失败。
			// 3. 调用 `Process` 方法。
			// 4. 断言返回一个非nil的错误。

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					ContractNo: "CONT-123",
				},
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONT-123",
				},
				Extra: "initial_extra_data",
			}
			mockErr := errors.New("send defer message failed")

			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock(mqProducer.SendDeferMessage).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SendSubmitOaMsgFail")
			// pc.Extra should still be cleared before the final return
			convey.So(pc.Extra, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("当发送OA消息返回APIError时，应返回该APIError", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx。
			// 逻辑链路：
			// 1. Mock `(h *handlerCommon).updateContractData` 方法返回成功 (nil)。
			// 2. Mock `mqProducer.SendDeferMessage` 方法返回错误，`SendSubmitOaMsg`将返回一个APIError。
			// 3. 调用 `Process` 方法。
			// 4. 断言返回的错误与 `SendSubmitOaMsg` 返回的APIError相同。

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					ContractNo: "CONT-123",
				},
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONT-123",
				},
			}
			apiErr := errorsV2.ErrCommon.WithArgs("SendSubmitOaMsgFail")

			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			// To make SendSubmitOaMsg fail, we mock its dependency
			mockey.Mock(mqProducer.SendDeferMessage).Return(errors.New("mq error")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, apiErr)
		})
	})
}

func Test_handlerRiskSubmitOA_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSubmitOA_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回正确的操作类型常量。
			// 构造数据：
			// - 初始化一个 handlerRiskSubmitOA 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于 _const.OperationSubmitOA。

			// 准备数据
			h := &handlerRiskSubmitOA{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationSubmitOA)
		})
	})
}

func Test_handlerRiskSubmitOA_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerRiskSubmitOA PostProcess", t, func() {

		mockey.PatchConvey("场景2: 非BytePlus环境，正常成功路径", func() {
			// 场景描述:
			// 在非BytePlus环境下，PostProcess 调用 notifyC360 成功发送C360通知。
			// 构造数据:
			// - pc.OperationState 不为 _const.OperationSendBack，以测试常规路径。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false。
			// 2. Mock larkc.GetEmployeeByID 成功返回员工信息。
			// 3. Mock mqProducer.SendC360NotifyMessage 成功发送消息，返回 nil。
			// 4. 调用 PostProcess。
			// 5. 断言返回值为 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:     "test.operator",
					ContractNo:   "CONTRACT-123",
					ContractName: "Test Contract",
				},
				OperationState:     _const.OperationReviewPass,
				StatusChangedValue: _const.PreSalesContractSubmitOA,
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			h := &handlerRiskSubmitOA{}
			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 非BytePlus环境，操作为退回", func() {
			// 场景描述:
			// 在非BytePlus环境下，当操作为“退回”(_const.OperationSendBack)时，发送的C360通知中应包含退回原因和客户名称。
			// 构造数据:
			// - pc.OperationState 设置为 _const.OperationSendBack。
			// - pc.Comment 包含纯文本信息作为退回原因。
			// - pc.ContractInfo 包含客户名称。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false。
			// 2. Mock larkc.GetEmployeeByID 成功返回员工信息。
			// 3. Mock mqProducer.SendC360NotifyMessage，并使用 To 方法捕获其输入参数，断言消息内容正确，然后返回 nil。
			// 4. 调用 PostProcess。
			// 5. 断言返回值为 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:       "test.operator",
					ContractNo:     "CONTRACT-123",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Customer",
				},
				OperationState: _const.OperationSendBack,
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "退回原因文本",
				},
				StatusChangedValue: _const.PreSalesContractSendBack,
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()

			mockey.Mock(mqProducer.SendC360NotifyMessage).To(func(ctx context.Context, deferTime time.Duration, data *bizmodels.C360NotifyMsg) error {
				convey.So(data.EventType, convey.ShouldEqual, _const.C360NotifyEventTypeRiskSubmitOA)
				convey.So(len(data.ContractList), convey.ShouldEqual, 1)
				convey.So(data.ContractList[0].StatusReturnReason, convey.ShouldEqual, "退回原因文本")
				convey.So(data.ContractList[0].CustomerName, convey.ShouldEqual, "Test Customer")
				return nil
			}).Build()

			h := &handlerRiskSubmitOA{}
			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 非BytePlus环境，获取员工信息失败", func() {
			// 场景描述:
			// 当调用 larkc.GetEmployeeByID 获取员工信息失败（返回nil）时，仍然会尝试发送通知，但消息中的操作人邮箱应为空。
			// 构造数据:
			// - 无特殊构造。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false。
			// 2. Mock larkc.GetEmployeeByID 返回 nil, nil，模拟找不到员工的情况。
			// 3. Mock mqProducer.SendC360NotifyMessage，并使用 To 方法捕获输入参数，断言操作人邮箱为空，然后返回 nil。
			// 4. 调用 PostProcess。
			// 5. 断言返回值为 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator: "non.existent.user",
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return(nil, nil).Build()

			mockey.Mock(mqProducer.SendC360NotifyMessage).To(func(ctx context.Context, deferTime time.Duration, data *bizmodels.C360NotifyMsg) error {
				convey.So(len(data.Operator), convey.ShouldEqual, 1)
				convey.So(data.Operator[0], convey.ShouldBeEmpty)
				return nil
			}).Build()

			h := &handlerRiskSubmitOA{}
			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 非BytePlus环境，发送MQ消息失败", func() {
			// 场景描述:
			// 当调用 mqProducer.SendC360NotifyMessage 发送MQ消息失败时，会记录日志并发送飞书告警，但PostProcess本身不向上抛出错误，而是返回nil。
			// 构造数据:
			// - 无特殊构造。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false。
			// 2. Mock larkc.GetEmployeeByID 成功返回员工信息。
			// 3. Mock mqProducer.SendC360NotifyMessage 返回一个错误。
			// 4. Mock utils.ToJSON 以支持告警内容生成。
			// 5. Mock larkc.Warning 以验证告警逻辑被触发。
			// 6. 调用 PostProcess。
			// 7. 断言返回值为 nil (因为PostProcess忽略了notifyC360的错误)。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:   "test.operator",
					ContractNo: "CONTRACT-789",
				},
			}
			sendErr := errors.New("mq send error")

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(sendErr).Build()
			mockey.Mock(utils.ToJSON).Return(`{"key":"value"}`).Build()
			mockey.Mock(larkc.Warning).Return().Build()

			h := &handlerRiskSubmitOA{}
			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerRiskSubmitOA_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerRiskSubmitOA", t, func() {
		mockey.PatchConvey("正常场景: 成功创建一个新的 handlerRiskSubmitOA 实例", func() {
			// 场景描述：
			// 测试 newHandlerRiskSubmitOA 函数是否能成功创建一个新的处理器实例。
			// 构造数据：
			// 无需构造特殊数据。
			// 逻辑链路：
			// 1. 调用 newHandlerRiskSubmitOA()。
			// 2. 断言返回的处理器不为 nil。
			// 3. 断言返回的处理器的具体类型为 *handlerRiskSubmitOA。

			// 调用目标函数
			handler := newHandlerRiskSubmitOA()

			// 断言结果
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerRiskSubmitOA{})
		})
	})
}

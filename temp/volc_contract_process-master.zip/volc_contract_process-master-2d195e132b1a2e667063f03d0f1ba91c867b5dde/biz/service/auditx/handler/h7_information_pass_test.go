package handler

import (
	"code.byted.org/gopkg/env"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/riskenginecli"
)

func Test_handlerInformationPass_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationPass_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 测试 CurrentStatus 方法是否返回正确的状态码。
			// 构造数据:
			// 创建一个 handlerInformationPass 实例。
			// 逻辑链路:
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值等于常量 _const.PreSalesContractSalesOperationCompleteInformation。

			h := &handlerInformationPass{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationCompleteInformation)
		})
	})
}

func Test_newHandlerInformationPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerInformationPass", t, func() {
		mockey.PatchConvey("should return a non-nil handler of type *handlerInformationPass", func() {
			// 场景描述：
			// 这是一个简单的构造函数，没有任何复杂的逻辑。
			// 构造数据：无
			// 逻辑链路：
			// 1. 直接调用 newHandlerInformationPass() 函数。
			// 2. 断言返回的对象不为 nil。
			// 3. 断言返回的对象类型为 *handlerInformationPass。

			// 调用
			handler := newHandlerInformationPass()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerInformationPass{})
		})
	})
}

func Test_handlerInformationPass_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationPass_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewPass", func() {
			// 场景描述：
			// 测试 handlerInformationPass 的 CurrentOp 方法能否正确返回预设的常量值。
			// 构造数据：
			// 初始化一个 handlerInformationPass 实例。
			// 逻辑链路：
			// 1. 创建 handlerInformationPass 实例。
			// 2. 调用其 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationReviewPass。

			h := &handlerInformationPass{}

			result := h.CurrentOp()

			convey.So(result, convey.ShouldEqual, _const.OperationReviewPass)
		})
	})
}

func Test_handlerInformationPass_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationPass_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 这是一个简单的场景，测试handlerInformationPass的HitStateChangeCondition方法。
			// 构造数据：
			// - 初始化一个handlerInformationPass实例。
			// - 初始化一个空的上下文和ProcessCtx。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 断言返回值应为true和nil，因为该函数当前实现是硬编码返回这两个值。

			// 数据准备
			h := &handlerInformationPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标方法
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerInformationPass_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationPass_PostProcess", t, func() {
		h := &handlerInformationPass{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				Reviewers:      bizmodels.PreContractReviewerList{},
				ContractNo:     "TEST-CN-001",
				ContractName:   "Test Contract Name",
				OtherPartyName: "Test Customer",
				Operator:       "test.operator",
			},
		}

		mockey.PatchConvey("success case: sends notifications and returns no error", func() {
			// 场景描述:
			// 正常情况下，函数成功执行，向相关人员发送飞书通知，并通知C360系统。
			// 构造数据:
			// - pc 包含合同基本信息。
			// 逻辑链路:
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 返回一个财税法审核员列表。
			// 2. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 返回一个销售人员列表。
			// 3. Mock larkc.BatchSendMessageToEmailIgnore, 验证其被正确调用。
			// 4. Mock 构建飞书消息卡片所需的依赖函数，如 multienv.I18nFormat 和 larkc.GenReviewURL, env.IsProduct, env.PSM。
			// 5. Mock (*handlerCommon).notifyC360 返回 nil，表示C360通知成功。
			// 6. 调用 PostProcess 函数，预期返回 nil。

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) bool {
					return reviewerType == _const.ReviewerTypeFinanceTaxationLegalReviewer &&
						contractStatus == _const.PreSalesContractFinanceTaxationLegalSignReview
				}).
				Return([]string{"finance.reviewer@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int) bool {
					return reviewerType == _const.ReviewerTypeSalesperson
				}).
				Return([]string{"sales.person@example.com"}).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
				convey.So(emailList, convey.ShouldResemble, []string{"finance.reviewer@example.com"})
				convey.So(msgType, convey.ShouldEqual, larkc.MsgTypeInteractive)
				convey.So(content, convey.ShouldContainSubstring, "TEST-CN-001")
				convey.So(content, convey.ShouldContainSubstring, "Test Contract Name")
				convey.So(content, convey.ShouldContainSubstring, "sales.person@example.com")
			}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review-url/TEST-CN-001").Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(env.PSM).Return("test").Build()

			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case: returns nil even if notifyC360 fails", func() {
			// 场景描述:
			// 测试当内部调用 notifyC360 失败时，PostProcess 依然成功返回。这是因为代码中忽略了 notifyC360 的返回值。
			// 构造数据:
			// - pc 包含合同基本信息。
			// 逻辑链路:
			// 1. Mock getReviewer... 等方法，与成功场景一致。
			// 2. Mock (*handlerCommon).notifyC360 返回一个错误。
			// 3. 调用 PostProcess 函数，预期仍然返回 nil。
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"finance.reviewer@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"sales.person@example.com"}).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review-url/TEST-CN-001").Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(env.PSM).Return("test").Build()

			mockey.Mock((*handlerCommon).notifyC360).Return(errors.New("c360 notification failed")).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerInformationPass_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerInformationPass.Process", t, func() {
		mockey.PatchConvey("正常处理，返回nil", func() {
			// 场景描述：
			// 构造数据：构造一个空的 handlerInformationPass 和 ProcessCtx。
			// 逻辑链路：直接调用 Process 方法，该方法会直接返回 nil。
			// 预期结果：返回的 error 为 nil。
			h := &handlerInformationPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("SubmitComplianceCheck fail", func() {
			// 场景描述：
			// 构造数据：构造一个空的 handlerInformationPass 和 ProcessCtx。
			// 逻辑链路：直接调用 Process 方法，该方法会直接返回 nil。
			// 预期结果：返回的 error 为 nil。
			h := &handlerInformationPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(fmt.Errorf("SubmitComplianceCheckFail")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("updateContractData fail", func() {
			// 场景描述：
			// 构造数据：构造一个空的 handlerInformationPass 和 ProcessCtx。
			// 逻辑链路：直接调用 Process 方法，该方法会直接返回 nil。
			// 预期结果：返回的 error 为 nil。
			h := &handlerInformationPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}
			mockey.Mock((*handlerCommon).updateContractData).Return(fmt.Errorf("updateContractDataFail")).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			err := h.Process(ctx, pc)

			convey.So(err.Error(), convey.ShouldContainSubstring, "updateContractDataFail")
		})
	})
}

func Test_handlerInformationPass_GetStatusOpConfKey(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationPass_GetStatusOpConfKey", t, func() {
		// Initialize the handler instance.
		// As the target function does not rely on any fields of the struct, a simple initialization is sufficient.
		h := &handlerInformationPass{}
		ctx := context.Background()

		mockey.PatchConvey("Scenario 1: pc.ComplianceCheckInfo is nil, should return default key", func() {
			// 场景描述：
			// 这是一个兜底逻辑的场景，当流程上下文中的合规检查信息(ComplianceCheckInfo)为nil时，函数应返回默认的状态配置键。
			// 构造数据：
			// pc *auditmodel.ProcessCtx, 其中 ComplianceCheckInfo 字段为 nil。
			// 逻辑链路：
			// 1. 函数执行，进入第一个if条件 `pc.ComplianceCheckInfo == nil`，判断为true。
			// 2. 函数直接返回 _const.ApprovalStatusKeyDefault。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: nil,
			}

			// 调用目标函数
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言结果是否符合预期
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})

		mockey.PatchConvey("Scenario 2: Compliance check hits human review, should return compliance check key", func() {
			// 场景描述：
			// 当合规检查结果命中人工审核时 (IsTransaction 等于 RejectTransaction)，函数应返回合规审查中的状态配置键。
			// 构造数据：
			// pc *auditmodel.ProcessCtx, 其中 ComplianceCheckInfo.Result.IsTransaction 设置为 _const.RejectTransaction ("0")。
			// 逻辑链路：
			// 1. 函数执行，第一个if条件 `pc.ComplianceCheckInfo == nil` 判断为false。
			// 2. 进入第二个if条件 `pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction`，判断为true。
			// 3. 函数返回 _const.ApprovalStatusKeyComplianceCheck。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: _const.RejectTransaction,
					},
				},
			}

			// 调用目标函数
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言结果是否符合预期
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyComplianceCheck)
		})

		mockey.PatchConvey("Scenario 3: Compliance check does not hit human review, should return default key", func() {
			// 场景描述：
			// 当合规检查结果未命中人工审核时 (IsTransaction 不等于 RejectTransaction)，函数应返回默认的状态配置键。
			// 构造数据：
			// pc *auditmodel.ProcessCtx, 其中 ComplianceCheckInfo.Result.IsTransaction 设置为一个非 _const.RejectTransaction 的值 (例如 "1")。
			// 逻辑链路：
			// 1. 函数执行，第一个if条件 `pc.ComplianceCheckInfo == nil` 判断为false。
			// 2. 进入第二个if条件 `pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction`，判断为false。
			// 3. 函数执行到末尾，返回 _const.ApprovalStatusKeyDefault。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: "1", // Any value other than _const.RejectTransaction
					},
				},
			}

			// 调用目标函数
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言结果是否符合预期
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})
	})
}

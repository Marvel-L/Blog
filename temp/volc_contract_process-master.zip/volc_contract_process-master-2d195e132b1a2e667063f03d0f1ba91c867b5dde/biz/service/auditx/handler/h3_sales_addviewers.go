package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSalesReviewAddReviewers() StatusOpHandler {
	return &handlerSalesReviewAddReviewers{}
}

// 销售运营专业审核(3) --- 加签(5) --> 销售运营专业审核(3)
type handlerSalesReviewAddReviewers struct {
	handlerCommon
}

func (h *handlerSalesReviewAddReviewers) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewAddReviewers) CurrentOp() int {
	return _const.OperationAddReviewer
}

func (h *handlerSalesReviewAddReviewers) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerSalesReviewAddReviewers) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerSalesReviewAddReviewers) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerSalesReviewAddReviewers) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

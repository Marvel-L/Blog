package handler

import (
	"context"
	"encoding/json"
	"time"

	"volc_contract_process/biz/bizmodels"
	mqProducer "volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
)

func newHandlerDraftSubmitOA() StatusOpHandler {
	return &implDraftSubmitOA{
		dao: dal.NewContractMetaDao(),
	}
}

// 草稿(1) --- 提交OA(13) --> 提交OA(8)
type implDraftSubmitOA struct {
	handlerCommon
	dao dal.ContractMetaDao
}

func (h *implDraftSubmitOA) CurrentStatus() int {
	return _const.PreSalesContractDraft
}

func (h *implDraftSubmitOA) CurrentOp() int {
	return _const.OperationSubmitOA
}

func (h *implDraftSubmitOA) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.ContractInfo.Initiator != _const.InitiatorSelfPurchase {
		return errorsV2.ErrCommon.WithArgs("当前状态不允许提交OA")
	}
	subjectTag, otherPartyTag := h.CalcSealedTag(pc)
	for _, party := range pc.ContractInfo.TradePartyInfo.Subject {
		party.Sealed = subjectTag
		if subjectTag == _const.TRUE_FLAG_INT {
			party.SealAccountID = party.AccountID
		}
	}
	for _, party := range pc.ContractInfo.TradePartyInfo.OtherParty {
		party.Sealed = otherPartyTag
		if otherPartyTag == _const.TRUE_FLAG_INT {
			party.SealAccountID = party.AccountID
		}
	}
	tradePartyInfoBody, _ := json.Marshal(pc.ContractInfo.TradePartyInfo)
	pc.PreContractVO.TradePartyInfo = string(tradePartyInfoBody)
	return newHandlerRiskSubmitOA().Validate(ctx, pc)
}

// 仅对自采合同生效：
func (h *implDraftSubmitOA) CalcSealedTag(pc *auditmodel.ProcessCtx) (int, int) {
	if pc.ContractInfo.Initiator != _const.InitiatorSelfPurchase {
		return _const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT
	}
	subjectSealed, otherPartySealed := _const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT
	basicInfo := pc.ContractInfo.BasicInfo
	// 盖章方数量 = 多方盖章 & 先盖章方 = 我方/对方，映射我方是否需要签约 = 是，对方是否需要签约 = 是。
	if basicInfo.WhetherSingleSeal == _const.No {
		subjectSealed, otherPartySealed = _const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT
	} else if basicInfo.WhetherSingleSeal == _const.Yes {
		if basicInfo.SealOrder == _const.OurSide {
			// 盖章方数量 = 单方盖章 & 先盖章方 = 我方，映射我方是否需要签约 = 是，对方是否需要签约 = 否。
			subjectSealed, otherPartySealed = _const.TRUE_FLAG_INT, _const.FALSE_FLAG_INT
		} else if basicInfo.SealOrder == _const.OtherSide {
			// 盖章方数量 = 单方盖章 & 先盖章方 = 对方，映射我方是否需要签约 = 否，对方是否需要签约 = 是。
			subjectSealed, otherPartySealed = _const.FALSE_FLAG_INT, _const.TRUE_FLAG_INT
		}
	}
	return subjectSealed, otherPartySealed
}

func (h *implDraftSubmitOA) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	pc.PreContractVO.SubmitTime = time.Now()
	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		return err
	}
	// // 自采平台，支持直接提交OA
	// return h.SendSubmitOaMsg(ctx, pc)

	data, err := json.Marshal(&bizmodels.DeferMsgSubmitOA{
		ContractNo: pc.PreContractVO.ContractNo,
	})
	if err != nil {
		logs.CtxError(ctx, "SubmitOAReqMarshalFail, err:%s", err.Error())
		return err
	}

	logs.CtxInfo(ctx, "SendDeferMessage, data => %s", string(data))
	if err := mqProducer.SendDeferMessage(ctx, time.Second, &bizmodels.DeferMsg{
		DeferType: _const.DeferTypeSalesSubmitOA,
		Body:      string(data),
	}); err != nil {
		logs.CtxError(ctx, "SendDeferMessageFail, err: %v", err)
		return err
	}

	return nil

	// return mqfunc.SubmitOA(ctx, pc.GetTx(), pc.PreContractVO.PreContractNo, pc.Extra)

}

func getCfg(ctx context.Context) (*conf.DeferRocketMQConf, error) {
	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil {
		return nil, i18nfmt.New(ctx, "conf尚未初始化")
	}
	return cfg.DeferRocketMQConf, nil
}

func (h *implDraftSubmitOA) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *implDraftSubmitOA) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

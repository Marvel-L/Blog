package handler

import (
	"context"

	"volc_contract_process/biz/service/multienv/i18nfmt"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerFTLReviewSendBack() StatusOpHandler {
	return &handlerFTLReviewSendBack{}
}

// 财税法交付专业审核(4) --- 退回(4) --> 销售运营专业审核(3)
type handlerFTLReviewSendBack struct {
	handlerCommon
}

func (h *handlerFTLReviewSendBack) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalReview
}

func (h *handlerFTLReviewSendBack) CurrentOp() int {
	return _const.OperationSendBack
}

func (h *handlerFTLReviewSendBack) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	if pc.Comment.IsEmpty() {
		return i18nfmt.New(ctx, "审核意见不可为空")
	}
	return nil
}

func (h *handlerFTLReviewSendBack) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerFTLReviewSendBack) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerFTLReviewSendBack) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 退回到已退回节点时，清理报价单关联商品信息并仅保留申请人权限。
	if err := h.clearSendBackStatusQuoteAndReviewers(ctx, pc); err != nil {
		return err
	}

	// 退回到销售节点时通知c360
	if pc.StatusChangedValue == _const.PreSalesContractSendBack {
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSalesReviewSendBack, pc)
	}

	// 通知退回目标节点审批人，当前合同已被退回。
	h.sendBackNotifyTargetReviewers(ctx, pc)
	// 通知当前节点其他审批人，当前合同已被退回。
	h.SendBackNotifyPeerReviewers(ctx, pc)
	return nil
}

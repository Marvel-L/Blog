package handler

import (
	"context"

	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerDraftDelete() StatusOpHandler {
	return &handlerDraftDelete{}
}

// 草稿(1) --- 删除草稿(14) --> 未创建(0)
type handlerDraftDelete struct {
	handlerCommon
}

func (h *handlerDraftDelete) CurrentStatus() int {
	return _const.PreSalesContractDraft
}

func (h *handlerDraftDelete) CurrentOp() int {
	return _const.OperationDelete
}

func (h *handlerDraftDelete) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerDraftDelete) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerDraftDelete) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerDraftDelete) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	preContractNo := pc.ContractInfo.ContractNo
	// todo: 这里Version应该传啥
	if err := dal.NewContractMetaDao().DeleteByNo(ctx, pc.GetTx(), preContractNo, 0); err != nil {
		return err
	}
	// if err := dal.DeletePreContractReviewerByNo(ctx, pc.GetTx(), preContractNo); err != nil {
	//	return err
	// }
	// if err := dal.NewContractOperationRecordDao().DeleteByNo(ctx, pc.GetTx(), preContractNo); err != nil {
	//	return err
	// }
	return nil
}

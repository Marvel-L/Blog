package handler

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerRiskSendBack_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSendBack_PostProcess", t, func() {
		mockey.PatchConvey("正常发送飞书通知", func() {
			// 场景描述：
			// 模拟合同已完成前置专业审核，需要通知相关人员进行签约审核的场景。
			// 构造数据：
			// - ProcessCtx 包含合同信息（合同号、名称、对方名称、审核人列表）。
			// - 审核人列表包含一个财税法签约审核人和一个销售人员。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 方法，使其返回财税法审核人的邮箱。
			// 2. Mock larkc.NewCommonMessageCardBuilder 及其链式调用 (SetTitleColor, SetTitle, SetContent, AddField, AddAction, BuildJSONString)，以模拟构建飞书消息卡片。
			// 3. Mock multienv.I18nFormat 和 i18nfmt.Sprintf，以处理国际化文本。
			// 4. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 方法，使其返回销售人员的邮箱，用于消息内容生成。
			// 5. Mock larkc.LarkMdAtEmail 来格式化@信息。
			// 6. Mock larkc.GenReviewURL 来生成审核链接。
			// 7. Mock larkc.BatchSendMessageToEmailIgnore，因为我们不希望在测试中实际发送消息。
			// 8. 调用目标函数 PostProcess。
			// 9. 断言函数执行成功，返回 nil。

			// 数据准备
			h := &handlerRiskSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-2023-001",
					ContractName:   "年度合作协议",
					OtherPartyName: "火山引擎",
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "finance.reviewer@example.com",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
						},
						{
							Reviewer:     "sales.person@example.com",
							ReviewerType: _const.ReviewerTypeSalesperson,
						},
					},
				},
			}

			// Mock
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"finance.reviewer@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"sales.person@example.com"}).Build()

			// Mock a builder to control the chain calls
			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return(`{"msg_type":"interactive","card":{}}`).Build()

			// Mock dependent functions called during the build process
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review/CN-2023-001").Build()

			// Mock the final sending function
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非已退回状态时不通知C360", func() {
			h := &handlerRiskSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractCustomerConfirm,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("清理退回状态失败时直接返回", func() {
			h := &handlerRiskSendBack{}
			ctx := context.Background()
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerRiskSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSendBack_Validate", t, func() {
		h := &handlerRiskSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("场景一：前置审批人检查失败", func() {
			// 场景描述：
			// 调用 Validate 方法，其依赖的 commonCheckReviewerPass 方法返回一个错误。
			// 构造数据：
			// pc 为一个 auditmodel.ProcessCtx 的实例。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回一个预设的 error。
			// 2. 调用 h.Validate(ctx, pc)。
			// 3. 断言返回的 error 不为 nil，并且错误信息包含预设的错误字符串。

			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
		})

		mockey.PatchConvey("场景二：审核意见为空", func() {
			// 场景描述：
			// 调用 Validate 方法，前置审批人检查通过，但审核意见为空。
			// 构造数据：
			// pc 为一个 auditmodel.ProcessCtx 的实例，其 Comment 字段的 IsEmpty() 方法返回 true。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回 nil，表示检查通过。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 true，表示审核意见为空。
			// 3. Mock i18nfmt.Errorf 方法，使其返回一个预设的 error，以验证其被调用。
			// 4. 调用 h.Validate(ctx, pc)。
			// 5. 断言返回的 error 不为 nil，并且错误信息包含 "审核意见不可为空"。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			expectedErr := errors.New("审核意见不可为空")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.Errorf).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("场景三：校验成功", func() {
			// 场景描述：
			// 调用 Validate 方法，所有校验均通过。
			// 构造数据：
			// pc 为一个 auditmodel.ProcessCtx 的实例，其 Comment 字段的 IsEmpty() 方法返回 false。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回 nil，表示检查通过。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false，表示审核意见不为空。
			// 3. 调用 h.Validate(ctx, pc)。
			// 4. 断言返回的 error 为 nil。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerRiskSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerRiskSendBack", t, func() {
		mockey.PatchConvey("正常创建handler", func() {
			// 场景描述：
			// 验证 newHandlerRiskSendBack 函数是否能成功创建一个非空的 handler 实例。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 直接调用 newHandlerRiskSendBack() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerRiskSendBack。

			// 调用目标函数
			handler := newHandlerRiskSendBack()

			// 断言结果
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerRiskSendBack{})
		})
	})
}

func Test_handlerRiskSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerRiskSendBack 实例。
			// 逻辑链路：调用 CurrentStatus 方法，该方法直接返回一个预定义的常量。
			// 期望结果：返回常量 _const.PreSalesContractRiskReview。

			// 构造数据
			h := &handlerRiskSendBack{
				handlerCommon: handlerCommon{
					attachmentService:    nil,
					metaCommodityService: nil,
					metaService:          nil,
					metaServiceV2:        nil,
				},
			}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractRiskReview)
		})
	})
}

func Test_handlerRiskSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerRiskSendBack CurrentOp", t, func() {
		mockey.PatchConvey("当调用CurrentOp时，应返回退回操作码", func() {
			// 场景描述：
			// 本测试用例用于验证 handlerRiskSendBack 的 CurrentOp 方法能否正确返回预定义的操作码。
			// 构造数据：
			// 初始化一个 handlerRiskSendBack 实例。
			// 逻辑链路：
			// 1. 创建 handlerRiskSendBack 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationSendBack。

			// 准备数据
			h := &handlerRiskSendBack{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerRiskSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSendBack_Process", t, func() {
		mockey.PatchConvey("success case: should return nil", func() {
			// 场景描述:
			// 构造数据: 初始化一个空的 handlerRiskSendBack 实例和 ProcessCtx。
			// 逻辑链路:
			// 1. 直接调用 Process 方法。
			// 2. 由于方法体直接返回 nil，预期结果为 nil。
			h := &handlerRiskSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerRiskSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常调用应返回true和nil", func() {
			// 场景描述：
			// 目标函数逻辑非常简单，直接返回 true 和 nil。
			// 构造数据：
			// - 初始化一个 handlerRiskSendBack 实例。
			// - 初始化一个空的 context.Context 和 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回值为 true 和 nil。

			// 数据准备
			h := &handlerRiskSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

// Package handler 审批节点处理
package handler

import (
	"context"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

// StatusOpHandler 状态处理器
type StatusOpHandler interface {
	CurrentStatus() int                                                                   // 该处理器生效审批节点, 比如销售审核流程
	CurrentOp() int                                                                       // 该处理器对应的操作, 比如 退回、撤回、加签...
	Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error                        // 入参校验
	Process(ctx context.Context, pc *auditmodel.ProcessCtx) error                         // 处理
	HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) // 是否命中pre_contract状态变更条件
	GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string             // 匹配合同状态流转配置key
	SaveProcessFileNestVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error      // 保存审核通过是的文件最新版本信息
	SaveStatusChangeFileVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error     // 存储最近一次审核通过的文件版本信息
	PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error                     // 处理后逻辑
}

// MultiStatusOpHandler 状态处理器
type MultiStatusOpHandler interface {
	StatusOpHandler
	SupportStatus() []int // 该处理器生效审批节点, 比如销售审核流程
}

// GetValidReviewerType 获取节点审批角色
func GetValidReviewerType(contractState int, opState int, approvalKey string) *modelcooperation.ReviewerStatusOpConf {
	typeMappings := _const.ReviewerTypeApprovalMappings[approvalKey]
	m := typeMappings[contractState]
	if len(m) == 0 {
		return nil
	}
	return m[opState]
}

func GetWritableReviewerType(contractState int, approvalKey string) ([]int, bool) {
	var t []int
	var exist bool
	// 基于流程Key 查询是否存在对应的读权限配置
	// 不存在时 exist = false，t = nil
	if writePermMap, ok := _const.ReviewerTypeWritePermApprovalMappings[approvalKey]; ok {
		t, exist = writePermMap[contractState]
	}
	return t, exist
}

type filePermUpdateInfo struct {
	FileID                 string
	DeletePermReviewerType *int
	WritePermReviewerType  *int
}

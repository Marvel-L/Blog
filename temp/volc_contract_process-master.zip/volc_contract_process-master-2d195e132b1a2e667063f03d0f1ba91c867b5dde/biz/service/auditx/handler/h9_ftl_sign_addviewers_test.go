package handler

import (
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_newHandlerFTLSignReviewAddReviewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLSignReviewAddReviewers", t, func() {
		mockey.PatchConvey("正常创建handler", func() {
			// 场景描述:
			// 调用 newHandlerFTLSignReviewAddReviewers 函数，期望返回一个非空的、类型正确的处理器实例。
			// 构造数据: 无
			// 逻辑链路:
			// 1. 直接调用 newHandlerFTLSignReviewAddReviewers() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerFTLSignReviewAddReviewers。

			// 调用
			handler := newHandlerFTLSignReviewAddReviewers()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLSignReviewAddReviewers{})
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewAddReviewers_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerFTLSignReviewAddReviewers 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值是否等于预期的常量 PreSalesContractFinanceTaxationLegalSignReview。
			h := &handlerFTLSignReviewAddReviewers{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewAddReviewers_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 该函数没有外部依赖和复杂逻辑，仅返回一个预定义的常量。
			// 构造数据：
			// 初始化一个handlerFTLSignReviewAddReviewers实例。
			// 逻辑链路：
			// 1. 创建handlerFTLSignReviewAddReviewers实例。
			// 2. 调用CurrentOp方法。
			// 3. 断言返回值是否等于预期的_const.OperationAddReviewer。

			h := &handlerFTLSignReviewAddReviewers{}

			result := h.CurrentOp()

			convey.So(result, convey.ShouldEqual, _const.OperationAddReviewer)
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_Validate_BitsUTGen(t *testing.T) {
	h := &handlerFTLSignReviewAddReviewers{}

	mockey.PatchConvey("Test handlerFTLSignReviewAddReviewers.Validate", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("场景1: pc.Extra为空，应返回错误", func() {
			// 场景描述:
			// 待测函数Validate会调用commonValidateUpdateReviewers。当传入的ProcessCtx中Extra字段为空字符串时，commonValidateUpdateReviewers会直接返回错误。
			// 构造数据:
			// pc.Extra设置为空字符串 ""
			// 逻辑链路:
			// 1. h.Validate(ctx, pc) 调用 h.commonValidateUpdateReviewers(ctx, pc)
			// 2. commonValidateUpdateReviewers检查到len(pc.Extra) == 0
			// 3. 返回 "人员不可为空" 错误
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景2: 获取已有审批人失败，应返回错误", func() {
			// 场景描述:
			// 当内部调用perm.GetAllReviewersByType函数返回错误时，该错误应被直接返回。
			// 构造数据:
			// pc.Extra设置为 "user1@example.com"
			// pc.ContractInfo和pc.ReviewerStatusOpConf填充必要字段
			// Mock perm.GetAllReviewersByType返回一个error
			// 逻辑链路:
			// 1. h.Validate(ctx, pc) 调用 h.commonValidateUpdateReviewers(ctx, pc)
			// 2. commonValidateUpdateReviewers 调用 perm.GetAllReviewersByType
			// 3. Mock的perm.GetAllReviewersByType返回一个错误
			// 4. commonValidateUpdateReviewers将此错误向上传递
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-123",
					CooperationStatus: _const.ReviewStatusUnreviewed,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockErr := errors.New("database error")
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, mockErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("场景3: 添加的审批人已存在且未审批通过，应返回错误", func() {
			// 场景描述:
			// 当尝试添加的审批人已经存在于当前合同的审批人列表中，并且其审批状态不是“审核通过”时，应提示用户该人员已是审核人员。
			// 构造数据:
			// pc.Extra设置为 "existing.user@example.com"
			// Mock perm.GetAllReviewersByType返回一个列表，其中包含 "existing.user@example.com"，且其Status不为ReviewStatusReviewPass
			// 逻辑链路:
			// 1. perm.GetAllReviewersByType返回包含一个未通过的审批人
			// 2. commonValidateUpdateReviewers将返回的审批人列表存入map
			// 3. 遍历pc.Extra中的新审批人，在map中找到了"existing.user@example.com"
			// 4. 检查其状态不为ReviewStatusReviewPass，将其加入existReviewers切片
			// 5. existReviewers不为空，返回错误信息
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-123",
					CooperationStatus: _const.ReviewStatusUnreviewed,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing.user@example.com")
		})

		mockey.PatchConvey("场景4: 添加全新的审批人，应校验通过", func() {
			// 场景描述:
			// 当添加的审批人不在现有的审批人列表中时，校验应通过。
			// 构造数据:
			// pc.Extra设置为 "new.user@example.com"
			// Mock perm.GetAllReviewersByType返回一个不包含该用户的列表
			// 逻辑链路:
			// 1. perm.GetAllReviewersByType返回一个不包含新审批人的列表
			// 2. commonValidateUpdateReviewers将返回的审批人列表存入map
			// 3. 遍历pc.Extra中的新审批人，在map中未找到
			// 4. existReviewers为空，函数返回nil
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-123",
					CooperationStatus: _const.ReviewStatusUnreviewed,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 添加的审批人已存在但已审批通过，应校验通过", func() {
			// 场景描述:
			// 当尝试添加的审批人虽然存在，但其审批状态是“审核通过”时，不应被认为是重复添加，校验通过。
			// 构造数据:
			// pc.Extra设置为 "passed.user@example.com"
			// Mock perm.GetAllReviewersByType返回一个列表，其中包含 "passed.user@example.com"，且其Status为ReviewStatusReviewPass
			// 逻辑链路:
			// 1. perm.GetAllReviewersByType返回包含一个已通过的审批人
			// 2. commonValidateUpdateReviewers将返回的审批人列表存入map
			// 3. 遍历pc.Extra中的新审批人，在map中找到了"passed.user@example.com"
			// 4. 检查其状态为ReviewStatusReviewPass，不将其加入existReviewers切片
			// 5. existReviewers为空，函数返回nil
			pc := &auditmodel.ProcessCtx{
				Extra: "passed.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-123",
					CooperationStatus: _const.ReviewStatusUnreviewed,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "passed.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景6: 添加多个审批人，部分已存在，应返回错误", func() {
			// 场景描述:
			// 当添加多个审批人，其中至少有一人已经存在且未审批通过时，应返回错误，并指出所有重复的人员。
			// 构造数据:
			// pc.Extra设置为 "new.user@example.com,existing1@example.com,existing2@example.com"
			// Mock perm.GetAllReviewersByType返回一个列表，其中包含 "existing1@example.com" 和 "existing2@example.com"
			// 逻辑链路:
			// 1. perm.GetAllReviewersByType返回包含两个未通过的审批人
			// 2. commonValidateUpdateReviewers将返回的审批人列表存入map
			// 3. 遍历pc.Extra中的新审批人
			// 4. "existing1@example.com" 和 "existing2@example.com" 被找到并加入existReviewers切片
			// 5. existReviewers不为空，返回包含这两个用户名的错误信息
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com,existing1@example.com,existing2@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-123",
					CooperationStatus: _const.ReviewStatusUnreviewed,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "existing1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewSendBack}},
				{Reviewer: "existing2@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing1@example.com,existing2@example.com")
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewAddReviewers_Process", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述：
			// 这是一个基本的成功场景，因为目标函数体为空，直接返回nil。
			// 构造数据：
			// - h: 一个空的 handlerFTLSignReviewAddReviewers 实例。
			// - ctx: 一个空的 context.Background()。
			// - pc: 一个空的 auditmodel.ProcessCtx 指针。
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 函数直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerFTLSignReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewAddReviewers_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述:
			// 目标函数 `HitStateChangeCondition` 的实现是硬编码返回 (false, nil)。
			// 本测试用例验证函数在任何情况下都返回这个固定的结果。
			// 构造数据:
			// - ctx: 使用 context.Background()
			// - pc: 一个空的 auditmodel.ProcessCtx 实例
			// 逻辑链路:
			// 1. 初始化 handlerFTLSignReviewAddReviewers 实例。
			// 2. 调用 HitStateChangeCondition 方法。
			// 3. 断言返回的布尔值为 false，error 为 nil。

			h := &handlerFTLSignReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLSignReviewAddReviewers_PostProcess_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao 用于 mock dal.PreContractReviewerDao 接口
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test handlerFTLSignReviewAddReviewers PostProcess", t, func() {
		// Arrange
		h := &handlerFTLSignReviewAddReviewers{}
		ctx := context.Background()

		mockey.PatchConvey("场景：成功 - 加签审核人", func() {
			// 场景描述:
			// 模拟一个加签操作，所有依赖的函数都成功返回。
			// 构造数据:
			// pc.OperationState 设置为 OperationAddReviewer
			// pc.Extra 设置为新的审核人邮箱
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 返回当前审核人信息
			// 2. larkc.GetEmployeeByMailsWithCache 成功返回新审核人的员工信息
			// 3. 循环中调用 h.countersignReviewer, 成功返回
			// 4. larkc.BatchSendMessageToEmailIgnore 被调用发送加签通知
			// 5. 整个函数成功返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationAddReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "current.operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CN-001",
					Reviewers:  bizmodels.PreContractReviewerList{},
				},
			}
			mockReviewer := &bizmodels.PreContractReviewer{Reviewer: "current.operator@example.com"}
			mockEmployee := &peopleclient.Employee{Email: "new.reviewer@example.com", ID: 123}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			// 由于 h 是 *handlerFTLSignReviewAddReviewers, 它内嵌了 handlerCommon, 所以可以 mock handlerCommon 的方法
			mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功 - 转办审核人", func() {
			// 场景描述:
			// 模拟一个转办操作，所有依赖的函数都成功返回。
			// 构造数据:
			// pc.OperationState 设置为 OperationChangeReviewer
			// pc.Extra 设置为新的审核人邮箱
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 返回当前审核人信息
			// 2. larkc.GetEmployeeByMailsWithCache 成功返回新审核人的员工信息
			// 3. 循环中调用 h.changeReviewer, 成功返回
			// 4. dal.NewPreContractReviewerDao().DeleteChangedReviewer 成功删除被转办人
			// 5. larkc.BatchSendMessageToEmailIgnore 被调用发送转办通知
			// 6. 整个函数成功返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "current.operator@example.com",
				PreContractNo:   "TEST-CN-002",
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CN-002",
					Reviewers:  bizmodels.PreContractReviewerList{},
				},
			}
			mockEmployee := &peopleclient.Employee{Email: "new.reviewer@example.com", ID: 123}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build() // 转办不一定需要当前审核人
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：失败 - 获取员工信息失败", func() {
			// 场景描述:
			// 模拟获取新审核人信息时发生错误。
			// 构造数据:
			// pc.OperationState 设置为 OperationAddReviewer
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 返回
			// 2. larkc.GetEmployeeByMailsWithCache 返回错误
			// 3. 函数提前返回错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationAddReviewer,
				Extra:          "new.reviewer@example.com",
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, errors.New("lark api error")).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "lark api error")
		})

		mockey.PatchConvey("场景：失败 - 加签操作内部失败", func() {
			// 场景描述:
			// 模拟加签的核心逻辑 h.countersignReviewer 失败。
			// 构造数据:
			// pc.OperationState 设置为 OperationAddReviewer
			// 逻辑链路:
			// 1. 依赖的前置函数都成功返回
			// 2. h.countersignReviewer 返回错误
			// 3. 函数提前返回错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationAddReviewer,
				Extra:          "new.reviewer@example.com",
			}
			mockReviewer := &bizmodels.PreContractReviewer{}
			mockEmployee := &peopleclient.Employee{Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).countersignReviewer).Return(errors.New("countersign failed")).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "countersign failed")
		})

		mockey.PatchConvey("场景：失败 - 转办操作内部失败", func() {
			// 场景描述:
			// 模拟转办的核心逻辑 h.changeReviewer 失败。
			// 构造数据:
			// pc.OperationState 设置为 OperationChangeReviewer
			// 逻辑链路:
			// 1. 依赖的前置函数都成功返回
			// 2. h.changeReviewer 返回错误
			// 3. 函数提前返回错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationChangeReviewer,
				Extra:          "new.reviewer@example.com",
			}
			mockEmployee := &peopleclient.Employee{Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(errors.New("change reviewer failed")).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "change reviewer failed")
		})

		mockey.PatchConvey("场景：成功 - 删除被转办人失败（仅记录日志）", func() {
			// 场景描述:
			// 模拟在转办流程中，删除旧审核人时数据库操作失败。根据代码，该错误只被记录日志，不影响主流程返回。
			// 构造数据:
			// pc.OperationState 设置为 OperationChangeReviewer
			// 逻辑链路:
			// 1. h.changeReviewer 成功
			// 2. dal.NewPreContractReviewerDao().DeleteChangedReviewer 返回错误
			// 3. 函数记录日志后，依然成功返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "current.operator@example.com",
				PreContractNo:   "TEST-CN-003",
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CN-003",
					Reviewers:  bizmodels.PreContractReviewerList{},
				},
			}
			mockEmployee := &peopleclient.Employee{Email: "new.reviewer@example.com"}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("db delete error")).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功 - 其他操作类型", func() {
			// 场景描述:
			// 模拟一个非加签、非转办的操作类型，例如提交草稿。
			// 构造数据:
			// pc.OperationState 设置为一个非加签、非转办的值
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 返回
			// 2. larkc.GetEmployeeByMailsWithCache 成功返回
			// 3. 不会进入加签或转办的 if 分支
			// 4. 发送一个默认的飞书通知
			// 5. 函数成功返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationSubmitDraft,
				Extra:          "some.email@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CN-004",
					Reviewers:  bizmodels.PreContractReviewerList{},
				},
			}
			mockEmployee := &peopleclient.Employee{Email: "some.email@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockEmployee}, nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

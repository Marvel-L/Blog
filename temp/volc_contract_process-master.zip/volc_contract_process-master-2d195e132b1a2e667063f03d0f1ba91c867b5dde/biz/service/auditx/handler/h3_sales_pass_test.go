package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/biz/dal"
	pkg_errors "volc_contract_process/pkg/errors"
)

func Test_handlerSalesReviewPass_PostProcess_BitsUTGen(t *testing.T) {
	h := &handlerSalesReviewPass{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerSalesReviewPass PostProcess", t, func() {
		// 预先 mock 通用函数
		mockBuilder := &larkc.CommonMessageCardBuilder{}
		mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("lark-card-json").Build()

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
		mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
		mockey.Mock(utils.StringListFormat).To(func(list []string, formatFunc func(string) string) []string {
			res := make([]string, len(list))
			for i, s := range list {
				res[i] = formatFunc(s)
			}
			return res
		}).Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

		mockey.PatchConvey("场景1: reviewPassSendReviewedMessage 返回错误", func() {
			// 场景描述：
			// 构造数据：无特殊构造。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 返回一个错误。
			// 2. PostProcess 函数应立即返回这个错误。
			// 3. 后续的逻辑（如 resetFTLNodeReviewers, 发送飞书消息等）不应被执行。
			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("send reviewed message failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("场景2: StatusChanged 为 false", func() {
			// 场景描述：
			// 构造数据：pc.StatusChanged 设置为 false。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 返回 nil。
			// 2. pc.StatusChanged 为 false，if 条件不满足。
			// 3. 函数直接返回 nil，不执行 if 块内的任何逻辑。
			pc := &auditmodel.ProcessCtx{
				StatusChanged: false,
			}
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: resetFTLNodeReviewers 返回错误", func() {
			// 场景描述：
			// 构造数据：pc.StatusChanged 设置为 true。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 返回 nil。
			// 2. pc.StatusChanged 为 true，进入 if 块。
			// 3. h.resetFTLNodeReviewers 返回一个错误。
			// 4. 函数应立即返回这个错误。
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
				ContractInfo:  &model.ContractMeta{},
			}
			expectedErr := errors.New("reset FTL failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("场景4: 成功路径，不需要初始化解决方案节点", func() {
			// 场景描述：
			// 构造数据：pc.StatusChanged 为 true, StatusChangedValue 不是解决方案审核。
			// 逻辑链路：
			// 1. 所有依赖的函数调用都成功。
			// 2. h.needInitSolutionNode 返回 false，因此不调用 h.resetSolutionNodeReviewers。
			// 3. notifyReviewerType 被设置为 ReviewerTypeFinanceTaxationLegalReviewer。
			// 4. 发送飞书消息并通知 C360。
			// 5. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				StatusChanged:      true,
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview, // Not solution review
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C123",
					ContractName:   "Test Contract",
					OtherPartyName: "Client Inc.",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(false).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return([]string{"ftl_reviewer@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 需要初始化解决方案节点，但 resetSolutionNodeReviewers 失败", func() {
			// 场景描述：
			// 构造数据：pc.StatusChanged 为 true。
			// 逻辑链路：
			// 1. h.needInitSolutionNode 返回 true。
			// 2. 接着调用 h.resetSolutionNodeReviewers，但该函数返回一个错误。
			// 3. 函数应立即返回这个错误。
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
				ContractInfo:  &model.ContractMeta{},
			}
			expectedErr := errors.New("reset solution failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(true).Build()
			mockey.Mock((*handlerCommon).resetSolutionNodeReviewers).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("场景6: 成功路径，需要初始化解决方案节点，且状态为解决方案审核", func() {
			// 场景描述：
			// 构造数据：pc.StatusChanged 为 true, StatusChangedValue 是解决方案审核。
			// 逻辑链路：
			// 1. 所有依赖的函数调用都成功。
			// 2. h.needInitSolutionNode 返回 true，h.resetSolutionNodeReviewers 也成功。
			// 3. 因为 StatusChangedValue 是 PreSalesContractSolutionReview，notifyReviewerType 被设置为 ReviewerTypeSolutionReviewer。
			// 4. 发送飞书消息并通知 C360。
			// 5. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				StatusChanged:      true,
				StatusChangedValue: _const.PreSalesContractSolutionReview,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C456",
					ContractName:   "Solution Contract",
					OtherPartyName: "Tech Corp",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(true).Build()
			mockey.Mock((*handlerCommon).resetSolutionNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) bool {
					return reviewerType == _const.ReviewerTypeSolutionReviewer
				}).
				Return([]string{"solution_reviewer@example.com"}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewPass_Validate_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock type for dal.PreContractReviewerDao interface
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerSalesReviewPass_Validate", t, func() {
		h := &handlerSalesReviewPass{}
		ctx := context.Background()

		mockey.PatchConvey("commonCheckReviewerPass returns an error", func() {
			// 场景描述:
			// 构造数据: 无
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回一个错误
			// 2. Validate函数直接返回这个错误

			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("FindReviewersByNoAndEmail returns an error", func() {
			// 场景描述:
			// 构造数据: 构造pc使其包含ContractNo和CurrentOperator
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回nil，流程继续
			// 2. FindReviewersByNoAndEmail返回一个数据库错误
			// 3. Validate函数记录日志并返回这个错误

			pc := &auditmodel.ProcessCtx{
				ContractInfo:    &model.ContractMeta{ContractNo: "test-no"},
				CurrentOperator: "test@example.com",
			}
			dbErr := errors.New("db find failed")
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(nil, dbErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbErr)
		})

		mockey.PatchConvey("Current operator is a non-origin reviewer and returns nil", func() {
			// 场景描述:
			// 构造数据: FindReviewersByNoAndEmail返回一个reviewer列表，其中一个reviewer的ContractStatus是SalesOperationReview且ReviewerSource不是Origin
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回nil
			// 2. FindReviewersByNoAndEmail成功返回一个reviewer列表
			// 3. for循环中，if条件满足，函数直接返回nil

			pc := &auditmodel.ProcessCtx{
				ContractInfo:    &model.ContractMeta{ContractNo: "test-no"},
				CurrentOperator: "test@example.com",
			}
			reviewers := model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeAddReviewers, // Not Origin
				},
			}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(reviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("commonCheckHitMasterReviewerPass returns an error", func() {
			// 场景描述:
			// 构造数据: FindReviewersByNoAndEmail返回的reviewer不满足提前退出的条件
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回nil
			// 2. FindReviewersByNoAndEmail成功返回
			// 3. for循环不满足提前退出的条件
			// 4. commonCheckHitMasterReviewerPass返回一个错误
			// 5. Validate函数记录日志并返回一个包装后的内部错误

			pc := &auditmodel.ProcessCtx{
				ContractInfo:    &model.ContractMeta{ContractNo: "test-no"},
				CurrentOperator: "test@example.com",
			}
			reviewers := model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeOriginReviewers,
				},
			}
			mockDao := &MockPreContractReviewerDao{}
			checkErr := errors.New("check master pass failed")

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(reviewers, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(false, checkErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "查询审核人状态异常，请重试。")
		})

		mockey.PatchConvey("commonCheckHitMasterReviewerPass returns false", func() {
			// 场景描述:
			// 构造数据: FindReviewersByNoAndEmail返回的reviewer不满足提前退出的条件
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回nil
			// 2. FindReviewersByNoAndEmail成功返回
			// 3. for循环不满足提前退出的条件
			// 4. commonCheckHitMasterReviewerPass返回 (false, nil)
			// 5. Validate函数返回一个包含特定信息的内部错误

			pc := &auditmodel.ProcessCtx{
				ContractInfo:    &model.ContractMeta{ContractNo: "test-no"},
				CurrentOperator: "test@example.com",
			}
			reviewers := model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractCustomerConfirm, // Not SalesOperationReview
					ReviewerSource: _const.ReviewGradeOriginReviewers,
				},
			}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(reviewers, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(false, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(pkg_errors.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "当前节点有审批人未通过，请销运同学在该节点其他审批人完成审批后再审批；")
		})

		mockey.PatchConvey("Success path", func() {
			// 场景描述:
			// 构造数据: FindReviewersByNoAndEmail返回一个空的reviewer列表
			// 逻辑链路:
			// 1. commonCheckReviewerPass返回nil
			// 2. FindReviewersByNoAndEmail成功返回空列表
			// 3. for循环不执行
			// 4. commonCheckHitMasterReviewerPass返回 (true, nil)
			// 5. Validate函数成功返回nil

			pc := &auditmodel.ProcessCtx{
				ContractInfo:    &model.ContractMeta{ContractNo: "test-no"},
				CurrentOperator: "test@example.com",
			}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(true, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewPass_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSalesReviewPass HitStateChangeCondition", t, func() {
		// 准备通用变量
		ctx := context.Background()
		h := &handlerSalesReviewPass{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "CN-12345",
				CooperationStatus: 1,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 2,
			},
		}

		mockey.PatchConvey("场景：检查协作者状态成功，且所有人都已通过", func() {
			// 场景描述：
			// 目标函数依赖 dal.IsAllReviewerTypePassed 函数，当其返回 true 和 nil error 时，表示条件命中。
			// 构造数据：
			// - pc.ContractInfo 和 pc.ReviewerStatusOpConf 包含所需字段。
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (true, nil)
			// 5. 函数最终返回 (true, nil)

			mockey.Mock(dal.IsAllReviewerTypePassed).Return(true, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：检查协作者状态成功，但有人未通过", func() {
			// 场景描述：
			// 目标函数依赖 dal.IsAllReviewerTypePassed 函数，当其返回 false 和 nil error 时，表示条件未命中。
			// 构造数据：
			// - pc.ContractInfo 和 pc.ReviewerStatusOpConf 包含所需字段。
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (false, nil)
			// 5. 函数最终返回 (false, nil)

			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：检查协作者状态时发生数据库错误", func() {
			// 场景描述：
			// 目标函数依赖 dal.IsAllReviewerTypePassed 函数，当其返回 error 时，表示检查失败，应将错误向上传递。
			// 构造数据：
			// - pc.ContractInfo 和 pc.ReviewerStatusOpConf 包含所需字段。
			// - 构造一个 error 对象用于 mock。
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (false, error)
			// 5. commonCheckHitContractStatusChange 捕获错误，调用 i18nfmt.New 包装新错误并返回
			// 6. 函数最终返回 (false, error)

			dbErr := errors.New("database error")
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, dbErr).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(hit, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
		})
	})
}

func Test_handlerSalesReviewPass_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPass_Process", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述：
			// 目标函数`Process`的当前实现是直接返回nil。
			// 构造数据：
			// - 初始化一个`handlerSalesReviewPass`实例。
			// - 初始化一个`context.Context`。
			// - 初始化一个`auditmodel.ProcessCtx`实例。
			// 逻辑链路：
			// 1. 调用`Process`方法。
			// 2. 断言返回的error为nil。

			// 数据准备
			h := &handlerSalesReviewPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewPass_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPass_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewPass", func() {
			// 场景描述：
			// 正常调用CurrentOp方法
			// 构造数据：
			// 创建一个handlerSalesReviewPass的实例
			// 逻辑链路：
			// 1. 调用CurrentOp方法
			// 2. 验证返回值是否等于预期的常量_const.OperationReviewPass

			// 数据准备
			h := &handlerSalesReviewPass{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationReviewPass)
		})
	})
}

func Test_handlerSalesReviewPass_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPass_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSalesOperationReview", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回正确的状态常量。
			// 构造数据：
			// - 无需特殊构造数据。
			// 逻辑链路：
			// 1. 创建一个 handlerSalesReviewPass 的实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回的值等于 _const.PreSalesContractSalesOperationReview。

			h := &handlerSalesReviewPass{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSalesReviewPass", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 正常调用 newHandlerSalesReviewPass 函数。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerSalesReviewPass 函数。
			// 2. 断言返回的处理器不为 nil。
			// 3. 断言返回的处理器类型为 *handlerSalesReviewPass。

			// 调用
			h := newHandlerSalesReviewPass()

			// 断言
			convey.So(h, convey.ShouldNotBeNil)
			convey.So(h, convey.ShouldHaveSameTypeAs, &handlerSalesReviewPass{})
		})
	})
}

package handler

import (
	"context"
	"encoding/json"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func newHandlerSalesReviewPassSkip() StatusOpHandler {
	return &handlerSalesReviewPassSkip{}
}

// 销售运营专业审核(3) --- 审核通过(2) --> 财税法交付专业审核(4)
type handlerSalesReviewPassSkip struct {
	handlerCommon
}

func (h *handlerSalesReviewPassSkip) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewPassSkip) CurrentOp() int {
	return _const.OperationSkipApproval
}

func (h *handlerSalesReviewPassSkip) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	// “关联报价单场景 = 未完成报价审批”，不允许跳过
	if pc.ContractInfo.RelateQuoteScene == _const.RelateQuoteSceneNoCompleted {
		return errors.ErrInternalError.WithArgs("关联报价单场景 = 未完成报价审批，不允许跳过")
	}
	currentOperatorReviewers, err := dal.NewPreContractReviewerDao().FindReviewersByNoAndEmail(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, pc.CurrentOperator)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoAndEmailFail 2, email:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}
	for _, reviewer := range currentOperatorReviewers {
		if reviewer.ContractStatus == _const.PreSalesContractSalesOperationReview &&
			reviewer.ReviewerSource != _const.ReviewGradeOriginReviewers {
			return errors.ErrInternalError.WithArgs("加签审核人无法跳过财税法审批。")
		}
	}
	// 主审核人最后审批
	flag, err := h.commonCheckHitMasterReviewerPass(ctx, pc)
	if err != nil {
		logs.CtxError(ctx, "GetNoMasterReviewerTypePassFail, err: %v", err)
		return errors.ErrInternalError.WithArgs("查询审核人状态异常，请重试。")
	}
	if !flag {
		return errors.ErrInternalError.WithArgs("当前节点有审批人未通过，请销运同学在该节点其他审批人完成审批后再审批；")
	}
	return nil
}

func (h *handlerSalesReviewPassSkip) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 更新BasicInfo中的是否跳过财税法审批节点为false
	pc.ContractInfo.BasicInfo.IsSkipFTL = true
	basicInfoStr, err := json.Marshal(pc.ContractInfo.BasicInfo)
	if err != nil {
		logs.CtxError(ctx, "SalesReviewPassSkipFail_BasicMarshal, err:%v", err)
		return err
	}
	pc.PreContractVO.BasicInfo = string(basicInfoStr)
	// 更新pre_sales_contract字段
	if err := dal.NewContractMetaDao().UpdateByMap(ctx, pc.GetTx(), int64(pc.PreContractVO.Id),
		map[string]interface{}{"basic_info": string(basicInfoStr)}); err != nil {
		return err
	}
	// reviewer 状态标记为已跳过 todo：确认下是否需要
	return nil
}

func (h *handlerSalesReviewPassSkip) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

// PostProcess /** 判断当前节点是否已处理完毕 更新状态 发送飞书消息 修改文件权限
func (h *handlerSalesReviewPassSkip) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.reviewPassSendReviewedMessage(ctx, pc); err != nil {
		logs.CtxError(ctx, "SendReviewedMessageFail, err:%s", err.Error())
		return err
	}

	if pc.StatusChanged {
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSalesReviewPass, pc)
		// 销售运营专业审核节点 审批通过时
		// 重新匹配财税法审批人，重新匹配时需要更新“财税法交付专业审核”、“财税法签约审核”的审核人员。
		// reset指定审批节点、指定角色的审批人员列表
		if err := h.resetFTLNodeReviewers(ctx, pc); err != nil {
			return err
		}

		// 如果需要初始化「解决方案审核」，需要临时增加审批人
		if h.needInitSolutionNode(ctx, pc) {
			if err := h.resetSolutionNodeReviewers(ctx, pc); err != nil {
				return err
			}
		}
	}
	return nil
}

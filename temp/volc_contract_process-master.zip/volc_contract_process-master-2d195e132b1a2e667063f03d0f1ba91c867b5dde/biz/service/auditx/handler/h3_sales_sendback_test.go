package handler

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	mqProducer "volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/support/metacommodity"
	quoteservice "volc_contract_process/biz/service/support/quote"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerSalesReviewSendBack_PostProcess_BitsUTGen(t *testing.T) {

	mockey.PatchConvey("Test_handlerSalesReviewSendBack_PostProcess", t, func() {
		ctx := context.Background()
		h := &handlerSalesReviewSendBack{}

		mockey.PatchConvey("happy path: all operations succeed", func() {
			// 场景描述:
			// 构造数据:
			// - ProcessCtx 包含所有需要的信息，包括 ContractInfo, PreContractVO, Comment等
			// - ContractInfo.BasicInfo 使 CalcRequireQuote() 返回 true, 以执行 clearQuoteInfo
			// - Comment 非空
			// 逻辑链路:
			// 1. h.clearQuoteInfo 成功执行，所有内部依赖的DAO、Redis和Service调用都返回成功。
			// 2. dal.NewPreContractReviewerDao().DeleteReviewersByType 成功删除审核员。
			// 3. 飞书消息构建和发送成功。
			// 4. h.notifyC360 成功通知C360系统。
			// 5. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractNo: "PCN12345",
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "退回原因: 信息不完整",
				},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						InOutType: _const.IN,
					},
					ContractNo:     "CN123",
					ContractName:   "测试合同",
					OtherPartyName: "测试对方",
					Operator:       "test.operator",
					RelateQuoteNo:  "QN123",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "salesperson@example.com", ReviewerType: _const.ReviewerTypeSalesperson, ContractStatus: _const.PreSalesContractSendBack},
						{Reviewer: "other@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
					},
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB:     model.BaseDB{Id: 1},
					ContractNo: "CN123",
				},
				OperationState:     _const.OperationSendBack,
				StatusChangedValue: _const.PreSalesContractSendBack,
			}

			// Mocks for clearQuoteInfo
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockContractMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
			mockContractManageDao := &MockContractManageDao{}
			mockey.Mock(dal.NewContractManageDao).Return(mockContractManageDao).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(nil).Build()
			mockContractCommodityDao := &MockContractCommodityDao{}
			mockey.Mock(dal.NewContractCommodityDao).Return(mockContractCommodityDao).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockContractCommodityExternalDao := &MockContractCommodityExternalDao{}
			mockey.Mock(dal.NewContractCommodityExternalDao).Return(mockContractCommodityExternalDao).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()
			mockContractMetaExtDao := &MockContractMetaExtDao{}
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockContractMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(nil).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()
			mockQuoteService := &MockQuoteService{}
			mockey.Mock(quoteservice.NewService).Return(mockQuoteService).Build()
			mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, nil).Build()

			// Mocks for main logic
			mockPreContractReviewerDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Mocks for notifyC360
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "test.operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error path: clearQuoteInfo returns error", func() {
			// 场景描述:
			// 构造数据: 同happy path。
			// 逻辑链路:
			// 1. h.clearQuoteInfo 内部的 dal.UpdateFieldsByNo 调用失败，返回一个db error。
			// 2. h.clearQuoteInfo 捕获错误，并返回一个包装后的 APIError。
			// 3. PostProcess 函数直接返回此错误，后续逻辑不再执行。
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSendBack,
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						InOutType: _const.IN,
					},
					ContractNo: "CN123",
				},
				PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}},
			}
			dbErr := errors.New("database error")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockContractMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			commodityService := metacommodity.NewService()
			h.handlerCommon.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(errorsV2.ErrCommon.WithArgs(dbErr)).Build()
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted
			pc.PreContractVO.RelateQuoteScene = _const.RelateQuoteSceneCompleted

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrCommon)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database error")
		})

		mockey.PatchConvey("error path: DeleteReviewersByType returns error", func() {
			// 场景描述:
			// 构造数据: 同happy path。
			// 逻辑链路:
			// 1. h.clearQuoteInfo 成功执行。
			// 2. dal.NewPreContractReviewerDao().DeleteReviewersByType 调用失败，返回一个db error。
			// 3. PostProcess 函数直接返回此错误，后续逻辑不再执行。
			pc := &auditmodel.ProcessCtx{
				PreContractNo:      "PCN12345",
				StatusChangedValue: _const.PreSalesContractSendBack,
				ContractInfo: &model.ContractMeta{
					BasicInfo: nil, // Skip clearQuoteInfo
				},
			}
			dbErr := errors.New("delete reviewer failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockPreContractReviewerDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(dbErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "delete reviewer failed")
		})

		mockey.PatchConvey("edge case: Comment is empty, use Remark", func() {
			// 场景描述:
			// 构造数据: Comment 为空, Remark 有值。
			// 逻辑链路:
			// 1. 所有前置操作成功。
			// 2. IsEmpty() 返回 true，导致使用 pc.Remark 作为飞书消息内容。
			// 3. 整个函数成功执行并返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractNo: "PCN12345",
				Remark:        "退回备注",
				Comment:       &bizmodels.RichTextInfo{},
				ContractInfo:  &model.ContractMeta{BasicInfo: nil}, // Skip clearQuoteInfo
				PreContractVO: &model.ContractMetaDB{ContractNo: "CN123"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockPreContractReviewerDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(multienv.IsBytePlus).Return(true).Build() // Skip notifyC360
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("edge case: notifyC360 fails, should not return error", func() {
			// 场景描述:
			// 构造数据: 同happy path。
			// 逻辑链路:
			// 1. 所有前置操作成功。
			// 2. h.notifyC360 内部的 mqProducer.SendC360NotifyMessage 调用失败。
			// 3. PostProcess 函数忽略 h.notifyC360 的错误，继续执行并最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractNo: "PCN12345",
				Comment:       &bizmodels.RichTextInfo{RichtextPlainText: "reason"},
				ContractInfo: &model.ContractMeta{
					BasicInfo:      nil, // Skip clearQuoteInfo
					Operator:       "test.operator",
					OtherPartyName: "Test Party",
					ContractNo:     "CN123",
				},
				PreContractVO:  &model.ContractMetaDB{ContractNo: "CN123"},
				OperationState: _const.OperationSendBack,
			}
			mqErr := errors.New("mq send failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockPreContractReviewerDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Mocks for notifyC360 failure
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "test.operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(mqErr).Build()
			mockey.Mock(utils.ToJSON).Return(`{"key":"value"}`).Build()
			mockey.Mock(larkc.Warning).Return().Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSalesReviewSendBack Validate", t, func() {
		// 初始化公共变量
		h := &handlerSalesReviewSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("场景：commonCheckReviewerPass返回错误", func() {
			// 场景描述：
			// 构造数据：构造一个空的ProcessCtx
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 方法返回一个自定义的error。
			// 2. 调用 h.Validate 方法。
			// 3. 断言返回的error不为nil，并且错误信息包含预期的字符串。

			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
		})

		mockey.PatchConvey("场景：审核意见为空", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其Comment字段的IsEmpty方法返回true。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 方法返回nil，表示校验通过。
			// 2. Mock pc.Comment.IsEmpty 方法返回true，表示审核意见为空。
			// 3. 调用 h.Validate 方法。
			// 4. 断言返回的error不为nil，并且错误信息包含"审核意见不可为空"。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("场景：校验成功", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其Comment字段的IsEmpty方法返回false。
			// 逻辑链路：
			// 1. Mock h.commonCheckReviewerPass 方法返回nil，表示校验通过。
			// 2. Mock pc.Comment.IsEmpty 方法返回false，表示审核意见不为空。
			// 3. 调用 h.Validate 方法。
			// 4. 断言返回的error为nil。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewSendBack_Process", t, func() {
		mockey.PatchConvey("normal case", func() {
			// 场景描述：
			// 这是一个正常流程的测试用例。目标函数 Process 的实现当前为空，仅返回 nil。
			// 构造数据：
			// - h: 一个 handlerSalesReviewSendBack 的实例。
			// - ctx: 一个背景上下文。
			// - pc: 一个 auditmodel.ProcessCtx 的实例。
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 预期方法成功执行并返回 nil。
			// 3. 断言返回的 error 为 nil。
			h := &handlerSalesReviewSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述:
			// 目标函数 `HitStateChangeCondition` 的实现非常简单，它总是返回 (true, nil)。
			// 本测试用例旨在验证这一固定行为，确保在任何输入下都返回预期的结果。
			//
			// 构造数据:
			// - 初始化一个 `handlerSalesReviewSendBack` 实例。
			// - 创建一个 background context。
			// - 创建一个空的 `auditmodel.ProcessCtx` 实例，因为函数内部并未使用其字段。
			//
			// 逻辑链路:
			// 1. 调用 `HitStateChangeCondition` 方法。
			// 2. 断言返回的布尔值为 true。
			// 3. 断言返回的 error 为 nil。

			h := &handlerSalesReviewSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerSalesReviewSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewSendBack_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 handlerSalesReviewSendBack 的 CurrentOp 方法能否正确返回操作类型。
			// 构造数据：
			// 创建一个 handlerSalesReviewSendBack 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 校验返回值是否为预期的 _const.OperationSendBack。
			h := &handlerSalesReviewSendBack{}

			op := h.CurrentOp()

			convey.So(op, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerSalesReviewSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSalesOperationReview", func() {
			// 场景描述：
			// 验证 handlerSalesReviewSendBack 的 CurrentStatus 方法能否正确返回其所代表的状态。
			// 构造数据：
			// 创建一个 handlerSalesReviewSendBack 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回的状态码是否为 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewSendBack{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSalesReviewSendBack", t, func() {
		mockey.PatchConvey("should return a non-nil handler of type *handlerSalesReviewSendBack", func() {
			// 场景描述:
			// 测试 newHandlerSalesReviewSendBack 函数能否成功创建一个非空的实例。
			// 构造数据:
			// 无。
			// 逻辑链路:
			// 1. 调用 newHandlerSalesReviewSendBack() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的类型为 *handlerSalesReviewSendBack。

			// 调用目标函数
			handler := newHandlerSalesReviewSendBack()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewSendBack{})
		})
	})
}

package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerInformationUpdate() StatusOpHandler {
	return &handlerInformationUpdate{}
}

// 销售运营完善信息(7) --- 提交草稿(0) --> 销售运营完善信息(7)
type handlerInformationUpdate struct {
	handlerCommon
}

func (h *handlerInformationUpdate) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationCompleteInformation
}

func (h *handlerInformationUpdate) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerInformationUpdate) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}
	// 校验是否允许增加交易对方主体
	if err := h.ValidateDeputyParty(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h *handlerInformationUpdate) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerInformationUpdate) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerInformationUpdate) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

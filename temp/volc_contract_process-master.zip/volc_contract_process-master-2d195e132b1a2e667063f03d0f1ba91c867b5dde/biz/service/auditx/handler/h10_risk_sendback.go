package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

func newHandlerRiskSendBack() StatusOpHandler {
	return &handlerRiskSendBack{}
}

// 销售运营完善信息(7) --- 退回(4) --> 销售确认中(5)
type handlerRiskSendBack struct {
	handlerCommon
}

func (h *handlerRiskSendBack) CurrentStatus() int {
	return _const.PreSalesContractRiskReview
}

func (h *handlerRiskSendBack) CurrentOp() int {
	return _const.OperationSendBack
}

func (h *handlerRiskSendBack) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	if pc.Comment.IsEmpty() {
		return i18nfmt.Errorf(ctx, "审核意见不可为空")
	}
	return nil
}

func (h *handlerRiskSendBack) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerRiskSendBack) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerRiskSendBack) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 退回到已退回节点时，清理报价单关联商品信息并仅保留申请人权限。
	if err := h.clearSendBackStatusQuoteAndReviewers(ctx, pc); err != nil {
		return err
	}

	// 退回到销售节点时通知c360
	if pc.StatusChangedValue == _const.PreSalesContractSendBack {
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSalesReviewSendBack, pc)
	}

	// 通知退回目标节点审批人，当前合同已被退回。
	h.sendBackNotifyTargetReviewers(ctx, pc)
	// 通知当前节点其他审批人，当前合同已被退回。
	h.SendBackNotifyPeerReviewers(ctx, pc)
	return nil
}

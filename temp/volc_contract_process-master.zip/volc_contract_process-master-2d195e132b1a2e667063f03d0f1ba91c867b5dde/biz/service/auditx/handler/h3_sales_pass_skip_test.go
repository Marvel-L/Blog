package handler

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/starlingcli"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/support/metacommodity"
)

func Test_handlerSalesReviewPassSkip_PostProcess_BitsUTGen(t *testing.T) {
	h := &handlerSalesReviewPassSkip{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerSalesReviewPassSkip PostProcess", t, func() {
		mockey.PatchConvey("reviewPassSendReviewedMessage fails", func() {
			// 场景描述:
			// 目标函数首先调用 h.reviewPassSendReviewedMessage, 当此函数返回错误时，PostProcess应直接返回该错误。
			// 构造数据:
			// - pc: 一个空的 ProcessCtx 实例
			// - expectedErr: 一个自定义的错误
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 返回 expectedErr.
			// 2. 调用 h.PostProcess.
			// 3. 断言返回的错误是 expectedErr.
			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("send message failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "send message failed")
		})

		mockey.PatchConvey("StatusChanged is false", func() {
			// 场景描述:
			// reviewPassSendReviewedMessage 成功，但 pc.StatusChanged 为 false.
			// 构造数据:
			// - pc: StatusChanged 设置为 false.
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 返回 nil.
			// 2. 调用 h.PostProcess.
			// 3. 函数应跳过 if pc.StatusChanged{} 代码块，并成功返回 nil.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: false,
			}
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("StatusChanged is true, but resetFTLNodeReviewers fails", func() {
			// 场景描述:
			// reviewPassSendReviewedMessage 成功, pc.StatusChanged 为 true, 但后续调用的 resetFTLNodeReviewers 失败.
			// 构造数据:
			// - pc: StatusChanged 设置为 true.
			// - expectedErr: 一个自定义的错误
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 返回 nil.
			// 2. Mock (*handlerCommon).notifyC360 返回 nil.
			// 3. Mock (*handlerCommon).resetFTLNodeReviewers 返回 expectedErr.
			// 4. 调用 h.PostProcess.
			// 5. 函数应返回 resetFTLNodeReviewers 抛出的错误.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
			}
			expectedErr := errors.New("reset FTL failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "reset FTL failed")
		})

		mockey.PatchConvey("StatusChanged is true, needInitSolutionNode is false", func() {
			// 场景描述:
			// 所有前期调用成功, pc.StatusChanged 为 true, 但 needInitSolutionNode 返回 false.
			// 构造数据:
			// - pc: StatusChanged 设置为 true.
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 返回 nil.
			// 2. Mock (*handlerCommon).notifyC360 返回 nil.
			// 3. Mock (*handlerCommon).resetFTLNodeReviewers 返回 nil.
			// 4. Mock (*handlerCommon).needInitSolutionNode 返回 false.
			// 5. 调用 h.PostProcess.
			// 6. 函数应跳过 resetSolutionNodeReviewers 的调用，并成功返回 nil.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
			}
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(false).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("StatusChanged is true, needInitSolutionNode is true, but resetSolutionNodeReviewers fails", func() {
			// 场景描述:
			// needInitSolutionNode 返回 true, 但后续的 resetSolutionNodeReviewers 调用失败.
			// 构造数据:
			// - pc: StatusChanged 设置为 true.
			// - expectedErr: 一个自定义的错误
			// 逻辑链路:
			// 1. Mock 所有前期调用成功.
			// 2. Mock (*handlerCommon).needInitSolutionNode 返回 true.
			// 3. Mock (*handlerCommon).resetSolutionNodeReviewers 返回 expectedErr.
			// 4. 调用 h.PostProcess.
			// 5. 函数应返回 resetSolutionNodeReviewers 抛出的错误.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
			}
			expectedErr := errors.New("reset solution failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(true).Build()
			mockey.Mock((*handlerCommon).resetSolutionNodeReviewers).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "reset solution failed")
		})

		mockey.PatchConvey("all calls succeed", func() {
			// 场景描述:
			// 所有函数调用均成功，整个 PostProcess 流程完整执行完毕.
			// 构造数据:
			// - pc: StatusChanged 设置为 true, ApprovalKey 设置为 _const.ApprovalKeyDefaultWithSolution 以便 needInitSolutionNode 返回 true.
			// 逻辑链路:
			// 1. Mock 所有被调用的方法均返回成功(nil 或 true).
			// 2. 调用 h.PostProcess.
			// 3. 函数应成功返回 nil.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
				ApprovalKey:   _const.ApprovalKeyDefaultWithSolution, // to make needInitSolutionNode true
			}
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*handlerCommon).resetFTLNodeReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).needInitSolutionNode).Return(true).Build()
			mockey.Mock((*handlerCommon).resetSolutionNodeReviewers).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewPassSkip_Process_BitsUTGen(t *testing.T) {
	// Mock dal.ContractMetaDao interface for mocking its methods
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}

	mockey.PatchConvey("Test_handlerSalesReviewPassSkip_Process", t, func() {
		h := &handlerSalesReviewPassSkip{}
		ctx := context.Background()

		mockey.PatchConvey("成功场景: 更新IsSkipFTL并成功保存到数据库", func() {
			// 场景描述：
			// 正常流程，函数成功更新合同的BasicInfo中的IsSkipFTL为true，并将此变更持久化到数据库。
			// 构造数据：
			// - pc.ContractInfo.BasicInfo.IsSkipFTL 初始化为 false。
			// - pc.PreContractVO.Id 设置为 1。
			// 逻辑链路：
			// 1. pc.ContractInfo.BasicInfo.IsSkipFTL被设置为true。
			// 2. json.Marshal(pc.ContractInfo.BasicInfo) 成功执行。
			// 3. Mock dal.NewContractMetaDao().UpdateByMap 返回 nil，表示数据库更新成功。
			// 4. 函数最终返回 nil。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: false, // Initial value
					},
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeTrue)
			expectedBasicInfo := &bizmodels.BasicInfo{IsSkipFTL: true}
			expectedJSON, _ := json.Marshal(expectedBasicInfo)
			convey.So(pc.PreContractVO.BasicInfo, convey.ShouldEqual, string(expectedJSON))
		})

		mockey.PatchConvey("失败场景: 数据库更新返回错误", func() {
			// 场景描述：
			// 函数在尝试更新数据库时，DAL层返回一个错误，流程中断。
			// 构造数据：
			// - pc的配置与成功场景类似。
			// 逻辑链路：
			// 1. pc.ContractInfo.BasicInfo.IsSkipFTL被设置为true。
			// 2. json.Marshal 成功执行。
			// 3. Mock dal.NewContractMetaDao().UpdateByMap 返回一个预设的错误。
			// 4. 函数捕获到此错误并立即返回。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: false,
					},
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 2,
					},
				},
			}
			dbErr := errors.New("db update failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(dbErr).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db update failed")
		})
	})
}

func Test_handlerSalesReviewPassSkip_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPassSkip_HitStateChangeCondition", t, func() {
		// 构造通用测试数据
		h := &handlerSalesReviewPassSkip{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no",
				CooperationStatus: 1,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 2,
			},
		}

		// Mock pc.GetTx() 方法，使其返回一个 gorm.DB 实例
		// 注意: 由于 commonCheckHitContractStatusChange 内部调用了 dal.IsAllReviewerTypePassed，
		// 而 dal.IsAllReviewerTypePassed 接受一个 *gorm.DB 参数，该参数来自 pc.GetTx()。
		// 虽然我们直接 mock dal.IsAllReviewerTypePassed，但为保证函数调用的完整性，
		// 仍然 mock GetTx 返回一个非 nil 的值。
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

		mockey.PatchConvey("场景：所有审批人都已通过，条件命中", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用 commonCheckHitContractStatusChange，
			// 后者进一步调用 dal.IsAllReviewerTypePassed 来判断当前节点的所有审批人是否都已通过审批。
			// 本场景模拟 dal.IsAllReviewerTypePassed 返回 true，表示所有审批人都已通过。
			// 构造数据：
			// - pc.ContractInfo 包含合同号和协作状态
			// - pc.ReviewerStatusOpConf 包含审批人类型
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (true, nil)
			// 5. 函数最终返回 (true, nil)

			mockey.Mock(dal.IsAllReviewerTypePassed).Return(true, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：部分审批人未通过，条件未命中", func() {
			// 场景描述：
			// 本场景模拟 dal.IsAllReviewerTypePassed 返回 false，表示仍有审批人未完成审批操作。
			// 构造数据：
			// - pc.ContractInfo 包含合同号和协作状态
			// - pc.ReviewerStatusOpConf 包含审批人类型
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (false, nil)
			// 5. 函数最终返回 (false, nil)

			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：检查审批状态时发生数据库错误", func() {
			// 场景描述：
			// 本场景模拟 dal.IsAllReviewerTypePassed 在查询数据库时发生错误。
			// 构造数据：
			// - pc.ContractInfo 包含合同号和协作状态
			// - pc.ReviewerStatusOpConf 包含审批人类型
			// 逻辑链路：
			// 1. 调用 h.HitStateChangeCondition
			// 2. 内部调用 h.commonCheckHitContractStatusChange
			// 3. 内部调用 dal.IsAllReviewerTypePassed
			// 4. Mock dal.IsAllReviewerTypePassed 返回 (false, error)
			// 5. commonCheckHitContractStatusChange 捕获错误，通过 i18nfmt.New 包装后返回
			// 6. 函数最终返回 (false, error)

			dbErr := errors.New("database query failed")
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, dbErr).Build()
			// i18nfmt.New 会被调用，我们不mock它，而是断言它的输出
			mockey.Mock(i18nfmt.New).Return(errors.New("检查节点审批结果失败")).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSalesReviewPassSkip_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPassSkip_CurrentOp", t, func() {
		mockey.PatchConvey("正常case: 应返回 OperationSkipApproval", func() {
			// 场景描述：
			// 该函数没有外部依赖或复杂逻辑，仅返回一个常量。
			// 构造数据：初始化一个 handlerSalesReviewPassSkip 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于常量 _const.OperationSkipApproval。

			// 准备数据
			h := &handlerSalesReviewPassSkip{
				handlerCommon: handlerCommon{
					attachmentService:    (metaattach.AttachmentService)(nil),
					metaCommodityService: (metacommodity.Service)(nil),
					metaService:          (contractmeta.MetaService)(nil),
					metaServiceV2:        (contractmeta.MetaServiceV2)(nil),
				},
			}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationSkipApproval)
		})
	})
}

func Test_handlerSalesReviewPassSkip_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewPassSkip_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerSalesReviewPassSkip 实例。
			// 逻辑链路：调用 CurrentStatus 方法，期望返回预定义的常量 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewPassSkip{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewPassSkip_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSalesReviewPassSkip", t, func() {
		mockey.PatchConvey("正常-成功创建handler", func() {
			// 场景描述:
			// 验证 newHandlerSalesReviewPassSkip 函数是否能成功创建一个非空的 handlerSalesReviewPassSkip 实例。
			// 构造数据:
			// 无特定数据构造。
			// 逻辑链路:
			// 1. 调用 newHandlerSalesReviewPassSkip 函数。
			// 2. 断言返回的对象不为 nil。
			// 3. 断言返回的对象的类型为 *handlerSalesReviewPassSkip。

			// 调用目标函数
			handler := newHandlerSalesReviewPassSkip()

			// 断言结果
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewPassSkip{})
		})
	})
}

func Test_handlerSalesReviewPassSkip_Validate_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	// 初始化 pc，默认 RelateQuoteScene 为会触发新校验逻辑的值
	pc := &auditmodel.ProcessCtx{
		ContractInfo: &model.ContractMeta{
			RelateQuoteScene: _const.RelateQuoteSceneNoCompleted,
		},
		CurrentOperator: "test@example.com",
	}
	h := &handlerSalesReviewPassSkip{handlerCommon{}}

	mockey.PatchConvey("Test Validate", t, func() {
		mockey.PatchConvey("Test commonCheckReviewerPass failed", func() {
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(errorsV2.ErrCommon.WithArgs("common check failed")).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
		})

		// 明确测试新增的校验逻辑
		mockey.PatchConvey("Test fail when RelateQuoteScene is NoCompleted", func() {
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			// 显式设置场景以保证测试的明确性
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneNoCompleted

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "关联报价单场景 = 未完成报价审批，不允许跳过")
		})

		mockey.PatchConvey("Test FindReviewersByNoAndEmail failed", func() {
			// 绕过 RelateQuoteScene 校验以测试后续逻辑
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted

			reviewerDao := dal.NewPreContractReviewerDao()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNoAndEmail")).Return(nil, errorsV2.ErrCommon.WithArgs("find reviewers failed")).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "find reviewers failed")
		})

		mockey.PatchConvey("Test ReviewerSource not origin", func() {
			// 绕过 RelateQuoteScene 校验
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted

			reviewerDao := dal.NewPreContractReviewerDao()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNoAndEmail")).Return(model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeStandApostilleReviewers,
				},
			}, nil).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "加签审核人无法跳过财税法审批。")
		})

		mockey.PatchConvey("Test commonCheckHitMasterReviewerPass failed", func() {
			// 绕过 RelateQuoteScene 校验
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted

			reviewerDao := dal.NewPreContractReviewerDao()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNoAndEmail")).Return(model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeOriginReviewers,
				},
			}, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(false, errorsV2.ErrCommon.WithArgs("check master reviewer failed")).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询审核人状态异常，请重试。")
		})

		mockey.PatchConvey("Test master reviewer not passed", func() {
			// 绕过 RelateQuoteScene 校验
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted

			reviewerDao := dal.NewPreContractReviewerDao()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNoAndEmail")).Return(model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeOriginReviewers,
				},
			}, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(false, nil).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前节点有审批人未通过，请销运同学在该节点其他审批人完成审批后再审批；")
		})

		mockey.PatchConvey("Test all conditions passed", func() {
			reviewerDao := dal.NewPreContractReviewerDao()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNoAndEmail")).Return(model.PreContractReviewerDBList{
				{
					ContractStatus: _const.PreSalesContractSalesOperationReview,
					ReviewerSource: _const.ReviewGradeOriginReviewers,
				},
			}, nil).Build()
			// 成功场景，必须设置 RelateQuoteScene 以通过校验
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted
			mockey.Mock((*handlerCommon).commonCheckHitMasterReviewerPass).Return(true, nil).Build()
			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

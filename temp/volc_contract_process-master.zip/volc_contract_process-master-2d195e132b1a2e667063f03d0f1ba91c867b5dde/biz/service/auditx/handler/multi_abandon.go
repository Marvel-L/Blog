package handler

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"

	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerMultiAbandon() MultiStatusOpHandler {
	return &handlerMultiAbandon{}
}

// 未创建(0) --- 作废合同(15) --> 已废弃，与业务合同中心保持一致(20)
// 草稿(1) --- 作废合同(15) --> 已废弃，与业务合同中心保持一致(20)
// 已退回(2) --- 作废合同(15) --> 已废弃，与业务合同中心保持一致(20)
// 销售确认中(5) --- 作废合同(15) --> 已废弃，与业务合同中心保持一致(20)
type handlerMultiAbandon struct {
	handlerCommon
}

func (h *handlerMultiAbandon) CurrentStatus() int {
	panic("unexpected call MultiStatusOpHandler CurrentStatus() method")
}

func (h *handlerMultiAbandon) SupportStatus() []int {
	return []int{
		_const.PreSalesContractNotCreated,
		_const.PreSalesContractDraft,
		_const.PreSalesContractSendBack,
		_const.PreSalesContractCustomerConfirm,
		_const.PreSalesContractComplianceCheck,
	}
}

func (h *handlerMultiAbandon) CurrentOp() int {
	return _const.OperationAbandon
}

func (h *handlerMultiAbandon) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerMultiAbandon) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerMultiAbandon) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerMultiAbandon) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	info := pc.ContractInfo
	// 解绑报价单
	_, err := quotecli.UnbindQuoteContract(ctx, info.RelateQuoteNo, info.ContractNo)
	if err != nil {
		logs.CtxError(ctx, "multi abandon Unbind quote contract fail, err: %v", err)
		// return err
	}
	// 解除补充关系，清空火山关联版本号
	if err := dal.NewContractMetaDao().UpdateByMap(ctx, pc.GetTx(), int64(pc.PreContractVO.Id),
		map[string]interface{}{"volc_contract_no": ""}); err != nil {
		return err
	}
	// 消息通知
	if err := h.notify(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h *handlerMultiAbandon) notify(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.complianceCheckNotify(ctx, pc); err != nil {
		logs.CtxError(ctx, "complianceCheckNotify failed, err: %v", err)
		return err
	}
	return nil
}

func (h *handlerMultiAbandon) complianceCheckNotify(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.ContractInfo == nil || pc.ContractInfo.CooperationStatus != _const.PreSalesContractComplianceCheck {
		logs.CtxInfo(ctx, "contract cooperation status not compliance check, skip notify")
		return nil
	}
	// 发送飞书消息
	multiCtx := context.Background()
	if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation {
		// 销售运营完善信息，合同创建人，合规审查拒绝通知
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationCompleteInformation),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合规审查结果通知")).
				SetContent(i18nfmt.Sprintf(multiCtx, "你提交的合同已完成合规审查，合规审查结果为“不通过”，合同流程已自动作废”，详情请点击按钮前往后台查看。")).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddAction(multienv.I18nFormat(multiCtx, "查看合同详情"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	}
	// 通知 C360
	if err := h.notifyC360(ctx, _const.C360NotifyEventTypeComplianceCheck, pc); err != nil {
		return err
	}
	return nil
}

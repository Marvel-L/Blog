package handler

import (
	"context"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/support/metacommodity"
	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerSalesReviewWithdrawPreContract() StatusOpHandler {
	return &handlerSalesReviewWithdrawPreContract{}
}

// 销售运营专业审核(3) --- 撤回(8) --> 草稿(1)
type handlerSalesReviewWithdrawPreContract struct {
	handlerCommon
}

func (h *handlerSalesReviewWithdrawPreContract) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewWithdrawPreContract) CurrentOp() int {
	return _const.OperationWithdraw
}

func (h *handlerSalesReviewWithdrawPreContract) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	for _, reviewer := range pc.ContractInfo.Reviewers {
		if reviewer.ReviewerType == _const.ReviewerTypeSalesOperation &&
			reviewer.ContractStatus == _const.PreSalesContractSalesOperationReview &&
			reviewer.Status == _const.ReviewStatusReviewPass {
			return i18nfmt.Errorf(ctx, "合同已被销售运营专业审核，不可撤回")
		}
	}

	return nil
}

func (h *handlerSalesReviewWithdrawPreContract) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerSalesReviewWithdrawPreContract) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerSalesReviewWithdrawPreContract) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	if pc.ContractInfo != nil && pc.ContractInfo.NeedRelateQuoteNo() {
		if err := h.getCommodityService(ctx).ClearQuoteRelatedData(ctx, pc.GetTx(), &metacommodity.ClearQuoteRelatedDataReq{
			Scene:      metacommodity.QuoteCleanupSceneSendBack,
			Meta:       pc.PreContractVO,
			ManageInfo: pc.ContractInfo.ManageInfo,
		}); err != nil {
			return err
		}
	}

	// 撤回成功时 合同回到草稿状态 仅保留申请人权限
	err := dal.NewPreContractReviewerDao().DeleteReviewersByType(ctx, pc.GetTx(), pc.PreContractNo, []int{
		_const.ReviewerTypeFinanceTaxationLegalReviewer,
		_const.ReviewerTypeSalesOperation,
	})
	return err
}

package handler

import (
	"code.byted.org/eps-platform/commercialization_sdk_go/sdk/dto/lite"
	"code.byted.org/eps-platform/quote_sdk_go/quote_client"
	"context"
	"errors"
	"fmt"
	"testing"
	"volc_contract_process/pkg/proxy/innertopcommercializationcli"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"

	"code.byted.org/lang/gg/gptr"
	"github.com/bytedance/mockey"
	. "github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	. "github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/filecli"
)

// 为所有依赖的DAL和Service接口定义Mock结构体
type (
	MockContractAttachmentDao        struct{ dal.ContractAttachmentDao }
	MockContractManageDao            struct{ dal.ContractManageDao }
	MockContractCommodityDao         struct{ dal.ContractCommodityDao }
	MockContractCommodityExternalDao struct {
		dal.ContractCommodityExternalDao
	}
	MockContractTradePartyDao struct{ dal.ContractTradePartyDao }
	MockContractMetaExtDao    struct{ dal.ContractMetaExtDao }
	MockContractSettlementDao struct{ dal.ContractSettlementDao }
	MockTemplateService       struct{ template.Service }
)

func Test_handlerHaveChangeUpdate_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeUpdate_Process", t, func() {
		// 共享的测试数据和变量
		ctx := context.Background()
		h := &handlerHaveChangeUpdate{}
		mockTx := &gorm.DB{}

		// 构造一个包含所有必要信息的ProcessCtx
		pc := &auditmodel.ProcessCtx{
			CurrentOperator: "test.operator@example.com",
			PreContractVO: &model.ContractMetaDB{
				BaseDB:         model.BaseDB{Id: 1},
				ContractNo:     "test-contract-123",
				TemplateInfo:   `{"key":"template_key"}`, // 提供模板信息以触发模板文件生成逻辑
				Creator:        "creator@test.com",
				TradePartyInfo: `{}`, // 确保是合法的JSON字符串
			},
			ContractInfo: &model.ContractMeta{
				ManageInfo: &bizmodels.ManageInfo{
					// 提供商品信息以测试SaveManageInfo中的商品处理逻辑
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{
						"level1": {{TradeProduct: "test_product"}},
					},
					ExternalProductList: bizmodels.ExternalProductInfoList{},
					IsSplitProduct:      false,
				},
				TradePartyInfo: &bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{},
					OtherParty: []*bizmodels.TradePartyInfoDetail{},
				},
				// 提供附加信息以测试SaveMetaExt
				Ext: map[string]string{
					"key1": "value1",
				},
				// 提供结算信息以测试updateContractSettlement
				SettlementInfo: &bizmodels.SettlementInfo{
					SettlementLines: bizmodels.SettlementLines{
						{
							Id:                         1,
							InvoicingPercent:           "100",
							InvoicingTotal:             "1000",
							PaymentPercent:             "100",
							PaymentTotal:               "1000",
							InvoicingMilepostFixedTime: "2023-01-01",
							PaymentMilepostFixedTime:   "2023-01-01",
						},
					},
				},
			},
			// 提供附件更新列表以测试updateAttachment
			AttachmentUpdateList: []*bizmodels.MetaAttachment{
				{DownloadID: "file-key-attach-1", FileName: "attach1"},
			},
			DelExtKeys: []string{"del_key1"}, // 提供要删除的附加信息key
		}

		mockey.PatchConvey("成功场景: 所有数据更新操作均成功", func() {
			// 场景描述:
			// 本测试用例覆盖Process函数成功执行的完整路径。
			// 构造数据:
			// - ProcessCtx被填充了有效数据，以触发updateContractData内的所有主要逻辑分支。
			// - 包括模板信息、管理信息、交易方信息、附加信息、结算条款和附件列表。
			// 逻辑链路:
			// 1. Mock GetTemplateFileId 成功返回新的文件ID。
			// 2. Mock CreateOrUpdateAttachment及其依赖（dal, filecli）成功创建新的附件记录。
			// 3. Mock 所有后续的保存/更新操作（updatePreContract, SaveManageInfo, SaveTradePartyInfo, SaveMetaExt, updateContractSettlement, updateAttachment）及其DAL依赖都成功返回。
			// 4. 最终断言Process函数返回nil，表示流程无错误完成。

			// Mock pc.GetTx() 返回一个模拟的DB事务对象
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()

			// --- Mock GetTemplateFileId ---
			mockey.Mock(GetTemplateFileId).Return("new_file_id_123", nil).Build()

			// --- Mock CreateOrUpdateAttachment 的依赖 ---
			mockAttachmentDao := &MockContractAttachmentDao{}
			mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
			mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build() // 模拟未找到，将触发创建逻辑
			mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{Result: &filecli.GetNewestVersionInfo{Name: "合同文本.docx"}}, nil).Build()
			mockey.Mock((*MockContractAttachmentDao).Create).Return(nil).Build()

			// --- Mock updatePreContract 的依赖 ---
			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			// --- Mock SaveManageInfo 的依赖 ---
			mockManageDao := &MockContractManageDao{}
			mockey.Mock(dal.NewContractManageDao).Return(mockManageDao).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(gptr.Of(model.VolcContractManage{BaseDB: model.BaseDB{Id: 1}}), nil).Build() // 模拟找到已有记录，触发更新
			mockey.Mock((*MockContractManageDao).Update).Return(nil).Build()

			// --- Mock SaveCommodityList (SaveManageInfo的子调用) 的依赖 ---
			mockCommodityDao := &MockContractCommodityDao{}
			mockey.Mock(dal.NewContractCommodityDao).Return(mockCommodityDao).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			// --- Mock SaveExternalCommodityList (SaveManageInfo的子调用) 的依赖 ---
			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()

			// --- Mock SaveTradePartyInfo 的依赖 ---
			mockTradePartyDao := &MockContractTradePartyDao{}
			mockey.Mock(dal.NewContractTradePartyDao).Return(mockTradePartyDao).Build()
			mockey.Mock((*MockContractTradePartyDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock((*MockContractTradePartyDao).BatchCreate).Return(nil).Build()

			// --- Mock SaveMetaExt 的依赖 ---
			mockMetaExtDao := &MockContractMetaExtDao{}
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(nil).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(gptr.Of(model.ContractMetaExt{BaseDB: model.BaseDB{Id: 1}}), nil).Build() // 模拟找到已有记录，触发更新
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(nil).Build()

			// --- Mock updateContractSettlement 的依赖 ---
			mockSettlementDao := &MockContractSettlementDao{}
			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			// --- Mock updateAttachment 的依赖 ---
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: GetTemplateFileId 返回错误", func() {
			// 场景描述:
			// 本测试用例覆盖流程早期步骤失败的场景，即GetTemplateFileId调用失败。
			// 构造数据:
			// - ProcessCtx提供了必要的模板信息以确保会调用GetTemplateFileId。
			// 逻辑链路:
			// 1. Mock `GetTemplateFileId` 强制返回一个错误。
			// 2. Process函数应捕获此错误并立即中断执行，向上返回。
			// 3. 断言返回的错误符合预期，且后续的数据更新操作未被执行。

			expectedErr := errors.New("mock get template file id error")

			// Mock pc.GetTx(), 尽管在此场景下可能不会被调用，但作为良好实践提供
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()

			// Mock GetTemplateFileId，使其返回错误
			mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})
	})
}

func Test_handlerHaveChangeUpdate_PostProcess_BitsUTGen(t *testing.T) {
	t.Run("不更换报价单", func(t *testing.T) {
		mockey.PatchConvey("should return nil successfully", t, func() {
			// 场景描述：
			// 这是一个简单的函数，它不执行任何操作，直接返回 nil。
			// 构造数据：
			// - handlerHaveChangeUpdate 实例
			// - context.Background()
			// - auditmodel.ProcessCtx 实例
			// 逻辑链路：
			// 1. 调用 PostProcess 方法。
			// 2. 函数直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerHaveChangeUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("更换报价单报错", func(t *testing.T) {
		mockey.PatchConvey("更换报价单报错", t, func() {
			// 准备数据
			h := &handlerHaveChangeUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange: true,
				ContractInfo: &model.ContractMeta{
					ContractNo:    "test-contract-123",
					RelateQuoteNo: "test-quote-456",
				},
				RelateQuoteChangeBeforeValue: "old-quote-789",
			}
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockey.Mock(quotecli.ChangeQuoteContract).Return(nil, errors.New("mock change quote contract error")).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock change quote contract error")
		})
	})
	t.Run("更换报价单成功", func(t *testing.T) {
		mockey.PatchConvey("should record and switch quote successfully", t, func() {
			h := &handlerHaveChangeUpdate{}
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange:            true,
				RelateQuoteChangeBeforeValue: "old-quote",
				ContractInfo: &model.ContractMeta{
					ContractNo:    "contract",
					RelateQuoteNo: "new-quote",
				},
			}
			flag := mockey.Mock(rediscli.SetQuoteChangeInfoFlag).To(func(_ context.Context, contractNo string, info *bizmodels.QuoteChangeInfo) error {
				convey.So(contractNo, convey.ShouldEqual, "contract")
				convey.So(info.RelateQuoteNo, convey.ShouldEqual, "new-quote")
				convey.So(info.RelateQuoteChangedBefore, convey.ShouldEqual, "old-quote")
				convey.So(info.RelateQuoteChanged, convey.ShouldBeTrue)
				return nil
			}).Build()
			change := mockey.Mock(quotecli.ChangeQuoteContract).To(func(_ context.Context, oldQuote, newQuote, contractNo string) (*quote_client.QuoteContract, error) {
				convey.So(oldQuote, convey.ShouldEqual, "old-quote")
				convey.So(newQuote, convey.ShouldEqual, "new-quote")
				convey.So(contractNo, convey.ShouldEqual, "contract")
				return nil, nil
			}).Build()

			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(flag.Times(), convey.ShouldEqual, 1)
			convey.So(change.Times(), convey.ShouldEqual, 1)
		})
	})
	t.Run("解绑报价单不重复换绑", func(t *testing.T) {
		mockey.PatchConvey("should skip change quote contract", t, func() {
			h := &handlerHaveChangeUpdate{}
			tx := &gorm.DB{}
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange:            true,
				RelateQuoteChangeBeforeValue: "old-quote",
				ContractInfo:                 &model.ContractMeta{ContractNo: "contract", ManageInfo: &bizmodels.ManageInfo{}, RelateQuoteScene: _const.RelateQuoteSceneNoCompleted},
				PreContractVO:                &model.ContractMetaDB{ContractNo: "contract"},
			}
			pc.SetTX(tx)
			called := false
			mockey.Mock(quotecli.ChangeQuoteContract).To(func(_ context.Context, _, _ string, _ string) (*quote_client.QuoteContract, error) {
				called = true
				return nil, nil
			}).Build()
			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			cleanup := mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).To(func(_ context.Context, actualTx *gorm.DB, req *metacommodity.ClearQuoteRelatedDataReq) error {
				convey.So(actualTx, convey.ShouldEqual, tx)
				convey.So(req.Scene, convey.ShouldEqual, metacommodity.QuoteCleanupSceneApprovedToUnapproved)
				convey.So(req.QuoteNo, convey.ShouldEqual, "old-quote")
				convey.So(req.Meta, convey.ShouldEqual, pc.PreContractVO)
				convey.So(req.ManageInfo, convey.ShouldEqual, pc.ContractInfo.ManageInfo)
				return nil
			}).Build()

			err := h.PostProcess(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(cleanup.Times(), convey.ShouldEqual, 1)
			convey.So(called, convey.ShouldBeFalse)
		})
	})
	t.Run("解绑报价单清理失败", func(t *testing.T) {
		mockey.PatchConvey("should return cleanup error", t, func() {
			expectedErr := errors.New("clear quote failed")
			h := &handlerHaveChangeUpdate{}
			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(expectedErr).Build()

			err := h.PostProcess(context.Background(), &auditmodel.ProcessCtx{
				RelateQuoteChange:            true,
				RelateQuoteChangeBeforeValue: "old-quote",
				ContractInfo:                 &model.ContractMeta{RelateQuoteScene: _const.RelateQuoteSceneNoCompleted},
				PreContractVO:                &model.ContractMetaDB{},
			})

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_handlerHaveChangeUpdate_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerHaveChangeUpdate.HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述:
			// HitStateChangeCondition 函数的实现是直接返回 (false, nil)。
			// 本测试用例旨在验证此固定返回行为。
			// 构造数据:
			// - 初始化一个 handlerHaveChangeUpdate 实例。
			// - 创建一个空的 context.Context。
			// - 创建一个空的 auditmodel.ProcessCtx。
			// 逻辑链路:
			// 1. 调用目标函数 HitStateChangeCondition。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的错误为 nil。
			h := &handlerHaveChangeUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(hit, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeUpdate_Validate_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	h := &handlerHaveChangeUpdate{}

	PatchConvey("Test Validate with RelateQuoteChange true", t, func() {
		PatchConvey("Test validateSupply failed", func() {
			// Arrange: 在每个测试用例内部初始化，保证隔离性
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange: true,
				DelExtKeys:        []string{},
			}
			// Mock: 模拟 validateSupply 返回错误
			Mock((*handlerCommon).validateSupply).Return(fmt.Errorf("validate supply failed")).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert: 验证函数返回了预期的错误
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "validate supply failed")
		})

		PatchConvey("Test validateRequireQuote failed", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange: true,
				DelExtKeys:        []string{},
			}
			// Mock: 模拟 validateSupply 成功, validateRequireQuote 失败
			Mock((*handlerCommon).validateSupply).Return(nil).Build()
			Mock((*handlerCommon).validateRequireQuote).Return(fmt.Errorf("validate require quote failed")).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert: 验证函数返回了预期的错误
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "validate require quote failed")
		})

		PatchConvey("Test validateSupply and validateRequireQuote success", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange: true,
				DelExtKeys:        []string{},
			}
			// Mock: 模拟两个校验函数都成功
			Mock((*handlerCommon).validateSupply).Return(nil).Build()
			Mock((*handlerCommon).validateRequireQuote).Return(nil).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert: 验证函数成功返回，并且 DelExtKeys 被正确填充
			So(err, ShouldBeNil)
			So(pc.DelExtKeys, ShouldResemble, _const.ReplaceQuoteRemoveExtKey)
		})

		PatchConvey("Test validateSupply and validateRequireQuote success with pre-existing DelExtKeys", func() {
			// Arrange: 增加一个 DelExtKeys 初始不为空的场景
			pc := &auditmodel.ProcessCtx{
				RelateQuoteChange: true,
				DelExtKeys:        []string{"existing_key"},
			}
			expectedKeys := append([]string{"existing_key"}, _const.ReplaceQuoteRemoveExtKey...)
			// Mock
			Mock((*handlerCommon).validateSupply).Return(nil).Build()
			Mock((*handlerCommon).validateRequireQuote).Return(nil).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert: 验证函数成功返回，并且新 key 被追加到原有 key 之后
			So(err, ShouldBeNil)
			So(pc.DelExtKeys, ShouldResemble, expectedKeys)
		})
	})

	PatchConvey("Test Validate with RelateQuoteChange false", t, func() {
		// Arrange
		pc := &auditmodel.ProcessCtx{
			RelateQuoteChange: false,
		}

		// Act
		err := h.Validate(ctx, pc)

		// Assert: 验证当 RelateQuoteChange 为 false 时，函数直接成功返回
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with quote unbinding", t, func() {
		pc := &auditmodel.ProcessCtx{
			RelateQuoteChange:            true,
			RelateQuoteChangeBeforeValue: "old-quote",
			ContractInfo: &model.ContractMeta{
				RelateQuoteScene: _const.RelateQuoteSceneNoCompleted,
			},
			DelExtKeys: []string{},
		}

		// 解绑仍需执行补充协议校验；报价单校验不应执行。
		supplyCheck := Mock((*handlerCommon).validateSupply).Return(nil).Build()
		quoteCheck := Mock((*handlerCommon).validateRequireQuote).Return(fmt.Errorf("quote validation should be skipped")).Build()

		err := h.Validate(ctx, pc)

		So(err, ShouldBeNil)
		So(supplyCheck.Times(), ShouldEqual, 1)
		So(quoteCheck.Times(), ShouldEqual, 0)
		So(pc.DelExtKeys, ShouldResemble, _const.ReplaceQuoteRemoveExtKey)
	})
}

func Test_handlerHaveChangeUpdate_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeUpdate_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSubmitDraft", func() {
			// 场景描述：
			// 调用handlerHaveChangeUpdate的CurrentOp方法。
			// 构造数据：
			// 创建一个handlerHaveChangeUpdate的实例。
			// 逻辑链路：
			// 1. 调用CurrentOp()方法。
			// 2. 断言返回值是否为预期的常量_const.OperationSubmitDraft。

			// 创建handlerHaveChangeUpdate实例
			h := &handlerHaveChangeUpdate{}

			// 调用目标方法
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerHaveChangeUpdate_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeUpdate_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractChange status", func() {
			// 场景描述：
			// 测试 handlerHaveChangeUpdate 的 CurrentStatus 方法，验证其是否正确返回预设的合同状态常量。
			// 构造数据：
			// - 初始化一个 handlerHaveChangeUpdate 结构体实例。
			// 逻辑链路：
			// 1. 创建 handlerHaveChangeUpdate 的实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值等于常量 _const.PreSalesContractChange。

			// 准备数据
			h := &handlerHaveChangeUpdate{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractChange)
		})
	})
}

func Test_newHandlerHaveChangeUpdate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerHaveChangeUpdate", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerHaveChangeUpdate()
			// 2. 验证返回的实例不为nil
			// 3. 验证返回的实例类型为*handlerHaveChangeUpdate

			// 调用
			handler := newHandlerHaveChangeUpdate()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerHaveChangeUpdate{})
		})
	})
}

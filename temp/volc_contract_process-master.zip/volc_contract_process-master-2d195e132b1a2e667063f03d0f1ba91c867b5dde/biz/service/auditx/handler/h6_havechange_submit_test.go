package handler

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"testing"

	"code.byted.org/gopkg/env"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/rediscli"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerHaveChangeSubmit_sendMsgToCreator_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_sendMsgToCreator", t, func() {
		ctx := context.Background()
		h := &handlerHaveChangeSubmit{}

		mockey.PatchConvey("正常场景: 成功获取人员信息并发送消息", func() {
			// 场景描述：
			// 构造数据：ProcessCtx包含有效的合同信息，包括创建者和操作者ID。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByEmployeeIDsWithCache 调用成功，返回包含创建者和操作者信息的员工列表。
			// 2. 循环遍历员工列表，成功匹配并获取到创建者和操作者的邮箱。
			// 3. 操作者邮箱不为空，继续执行。
			// 4. 依赖的 multienv.I18nFormat, larkc.GenReviewURL, env.IsProduct, env.PSM 被Mock。
			// 5. 成功构建消息卡片。
			// 6. larkc.SendMessageToEmail 调用成功，函数正常结束。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-001",
					ContractName:   "测试合同",
					OtherPartyName: "测试客户",
				},
			}
			employeeList := []*peopleclient.Employee{
				{ID: 1001, Email: "creator@example.com"},
				{ID: 1002, Email: "operator@example.com"},
			}

			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(employeeList, nil).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v // 简单返回原字符串
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return(fmt.Sprintf("http://review.url/%s", pc.ContractInfo.ContractNo)).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(env.PSM).Return("test-env").Build() // 触发非生产环境的标题"[BOE]"前缀
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()

			h.sendMsgToCreator(ctx, pc)

			// 断言: 确认函数正常执行无panic即可
			convey.So(true, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("异常场景: 获取人员信息失败", func() {
			// 场景描述：
			// 构造数据：ProcessCtx包含有效的合同信息。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByEmployeeIDsWithCache 调用失败，返回一个error。
			// 2. 函数记录警告日志并直接返回，后续的消息发送逻辑不会被执行。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:  "1001",
					Operator: "1002",
				},
			}

			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(nil, errors.New("RPC error")).Build()

			h.sendMsgToCreator(ctx, pc)

			// 断言: 确认函数正常执行无panic即可
			convey.So(true, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("异常场景: 未找到操作者邮箱", func() {
			// 场景描述：
			// 构造数据：ProcessCtx包含有效的合同信息。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByEmployeeIDsWithCache 调用成功，但返回的员工列表中不包含操作者信息。
			// 2. 循环结束后，operatorEmail 字段为空。
			// 3. 函数记录警告日志并直接返回。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:  "1001",
					Operator: "1002",
				},
			}
			// 返回的列表中只有创建者
			employeeList := []*peopleclient.Employee{
				{ID: 1001, Email: "creator@example.com"},
			}

			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(employeeList, nil).Build()

			h.sendMsgToCreator(ctx, pc)

			// 断言: 确认函数正常执行无panic即可
			convey.So(true, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("边界场景: 未找到创建者邮箱但找到了操作者邮箱", func() {
			// 场景描述：
			// 构造数据：ProcessCtx包含有效的合同信息。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByEmployeeIDsWithCache 调用成功，但返回的员工列表中不包含创建者信息。
			// 2. 循环结束后，creatorEmail 为空，但 operatorEmail 有值。
			// 3. 函数继续执行，并调用 larkc.SendMessageToEmail，此时接收人邮箱(creatorEmail)为空字符串。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-002",
					ContractName:   "测试合同2",
					OtherPartyName: "测试客户2",
				},
			}
			// 返回的列表中只有操作者
			employeeList := []*peopleclient.Employee{
				{ID: 1002, Email: "operator@example.com"},
			}

			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(employeeList, nil).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.GenReviewURL).Return(fmt.Sprintf("http://review.url/%s", pc.ContractInfo.ContractNo)).Build()
			mockey.Mock(env.IsProduct).Return(true).Build() // 模拟生产环境
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()

			h.sendMsgToCreator(ctx, pc)

			// 断言: 确认函数正常执行无panic即可
			convey.So(true, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("边界场景: 员工ID为整型，合同中为字符串", func() {
			// 场景描述：
			// 此场景测试代码中的 strconv.Itoa(emp.ID) 是否能正确与字符串类型的合同人员ID匹配。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByEmployeeIDsWithCache 返回的 Employee 结构体中 ID 是 int 类型。
			// 2. 代码通过 strconv.Itoa 转换后与 model.ContractMeta 中的字符串ID进行比较。
			// 3. 比较成功，获取邮箱，正常发送消息。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "2001", // 字符串类型
					Operator:       "2002", // 字符串类型
					ContractNo:     "CONTRACT-003",
					ContractName:   "测试合同3",
					OtherPartyName: "测试客户3",
				},
			}
			employeeList := []*peopleclient.Employee{
				{ID: 2001, Email: "creator2@example.com"},  // 整型
				{ID: 2002, Email: "operator2@example.com"}, // 整型
			}

			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(employeeList, nil).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.GenReviewURL).Return(fmt.Sprintf("http://review.url/%s", pc.ContractInfo.ContractNo)).Build()
			mockey.Mock(env.IsProduct).Return(true).Build()
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()

			h.sendMsgToCreator(ctx, pc)

			// 断言: 确认函数正常执行无panic即可
			convey.So(true, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerHaveChangeSubmit_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerHaveChangeSubmit PostProcess", t, func() {
		// Common setup
		h := &handlerHaveChangeSubmit{}
		ctx := context.Background()

		mockey.PatchConvey("Success path - send notification to reviewers", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其中包含需要通知的审核人、销售以及需要跳过的审核人。
			// 逻辑链路：
			// 1. PostProcess开始执行。
			// 2. 调用h.sendMsgToCreator，模拟飞书消息发送成功。
			// 3. 调用h.notifyC360，模拟通知C360成功。
			// 4. 从合同信息中获取审核人列表。
			// 5. 移除掉跳过返稿审核的人员。
			// 6. 剩余审核人列表不为空，最终调用larkc.BatchSendMessageToEmailIgnore发送批量通知。
			// 7. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "reviewer1@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
						{Reviewer: "skip@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
				StatusChangedValue:            _const.PreSalesContractFinanceTaxationLegalReview,
				SkipReturnReviewNoAuditEmails: []string{"skip@example.com"},
			}

			// Mock for sendMsgToCreator
			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return([]*peopleclient.Employee{
				{ID: 1001, Email: "creator@example.com"},
				{ID: 1002, Email: "operator@example.com"},
			}, nil).Build()
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()

			// Mock for notifyC360
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			// Mock for the final batch message
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType, content string) {
				convey.So(emailList, convey.ShouldResemble, []string{"reviewer1@example.com"})
				convey.So(strings.Contains(content, "Test Contract"), convey.ShouldBeTrue)
			}).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Empty reviewers path - after removing skipped emails", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其中所有符合条件的审核人都被设置为跳过审核。
			// 逻辑链路：
			// 1. PostProcess开始执行。
			// 2. 调用h.sendMsgToCreator 和 h.notifyC360 成功。
			// 3. 获取审核人列表后，经过移除跳过审核人员的逻辑，最终列表为空。
			// 4. 函数在检查到列表为空后提前返回nil。
			// 5. 不会调用larkc.BatchSendMessageToEmailIgnore。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:    "1001",
					Operator:   "1002",
					ContractNo: "CONTRACT-001",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "skip@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
					},
				},
				StatusChangedValue:            _const.PreSalesContractFinanceTaxationLegalReview,
				SkipReturnReviewNoAuditEmails: []string{"skip@example.com"},
			}

			// Mock for sendMsgToCreator & notifyC360
			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return([]*peopleclient.Employee{
				{ID: 1001, Email: "creator@example.com"},
				{ID: 1002, Email: "operator@example.com"},
			}, nil).Build()
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("sendMsgToCreator fails on getting employee info", func() {
			// 场景描述：
			// 构造数据：与成功场景类似。
			// 逻辑链路：
			// 1. PostProcess开始执行。
			// 2. 在h.sendMsgToCreator内部，调用larkc.GetEmployeeByEmployeeIDsWithCache返回错误。
			// 3. 该错误被记录日志，但sendMsgToCreator会直接返回，不影响PostProcess的后续执行。
			// 4. h.notifyC360和后续的批量通知逻辑会正常执行。
			// 5. 函数最终返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "reviewer1@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
					},
				},
				StatusChangedValue:            _const.PreSalesContractFinanceTaxationLegalReview,
				SkipReturnReviewNoAuditEmails: []string{},
			}
			// Mock for sendMsgToCreator fails
			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return(nil, errors.New("lark error")).Build()

			// Mocks for subsequent successful calls
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("notifyC360 fails on sending message", func() {
			// 场景描述：
			// 构造数据：与成功场景类似, pc.OperationState设置为退回，并初始化pc.Comment。
			// 逻辑链路：
			// 1. PostProcess开始执行。
			// 2. h.sendMsgToCreator成功。
			// 3. 在h.notifyC360内部，调用mqProducer.SendC360NotifyMessage返回错误。
			// 4. 该错误被记录并触发larkc.Warning，但notifyC360返回的error被忽略。
			// 5. PostProcess的后续批量通知逻辑会正常执行。
			// 6. 函数最终返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "reviewer1@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
					},
				},
				OperationState: _const.OperationSendBack,
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "return reason",
				},
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			}
			// Mock for sendMsgToCreator
			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).Return([]*peopleclient.Employee{
				{ID: 1001, Email: "creator@example.com"},
				{ID: 1002, Email: "operator@example.com"},
			}, nil).Build()
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()

			// Mock for notifyC360 fails
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(errors.New("mq error")).Build()
			mockey.Mock(utils.ToJSON).Return(`{"key":"value"}`).Build()
			mockey.Mock(larkc.Warning).Return().Build()

			// Mock for the final batch message
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("sendMsgToCreator with empty operator email", func() {
			// 场景描述：
			// 构造数据：获取到的用户信息中，经办人(operator)的邮箱为空。
			// 逻辑链路：
			// 1. 在h.sendMsgToCreator内部，获取到用户信息后发现operatorEmail为空。
			// 2. 记录警告日志后，sendMsgToCreator提前返回。
			// 3. PostProcess继续执行后续逻辑。
			// 4. 函数最终返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Creator:        "1001",
					Operator:       "1002",
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "reviewer1@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview, ReviewerSource: 0},
					},
				},
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			}
			mockey.Mock(larkc.GetEmployeeByEmployeeIDsWithCache).To(func(ctx context.Context, employeeIDs []string) ([]*peopleclient.Employee, error) {
				var emps []*peopleclient.Employee
				for _, idStr := range employeeIDs {
					id, _ := strconv.Atoi(idStr)
					emp := peopleclient.Employee{ID: id, Email: fmt.Sprintf("user%d@example.com", id)}
					if idStr == pc.ContractInfo.Operator {
						emp.Email = "" // Operator email is empty
					}
					emps = append(emps, &emp)
				}
				return emps, nil
			}).Build()
			mockey.Mock(larkc.SendMessageToEmail).Return(nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeSubmit_removeSkipReturnReviewNoAuditEmails_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_removeSkipReturnReviewNoAuditEmails", t, func() {
		h := &handlerHaveChangeSubmit{}

		mockey.PatchConvey("正常场景：skipList为空，应返回原始all列表", func() {
			// 场景描述：
			// 构造数据：all列表包含多个邮箱，skipList为空列表。
			// 逻辑链路：
			// 1. 函数接收到空的skipList。
			// 2. 进入if len(skipList) == 0分支，直接返回原始的all列表。
			all := []string{"test1@example.com", "test2@example.com"}
			skipList := []string{}

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, all)
		})

		mockey.PatchConvey("正常场景：skipList不为空，且与all列表有交集", func() {
			// 场景描述：
			// 构造数据：all列表和skipList都包含元素，并且存在一个共同的邮箱。
			// 逻辑链路：
			// 1. 函数将skipList转换为map。
			// 2. 遍历all列表。
			// 3. "test2@example.com"在map中存在，被跳过。
			// 4. "test1@example.com"和"test3@example.com"不在map中，被添加到结果列表中。
			// 5. 返回过滤后的列表。
			all := []string{"test1@example.com", "test2@example.com", "test3@example.com"}
			skipList := []string{"test2@example.com", "test4@example.com"}
			expected := []string{"test1@example.com", "test3@example.com"}

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("正常场景：skipList不为空，但与all列表没有交集", func() {
			// 场景描述：
			// 构造数据：all列表和skipList都包含元素，但没有共同的邮箱。
			// 逻辑链路：
			// 1. 函数将skipList转换为map。
			// 2. 遍历all列表，发现所有邮箱都不在map中。
			// 3. 所有all列表中的邮箱都被添加到结果列表中。
			// 4. 返回的列表与原始all列表相同。
			all := []string{"test1@example.com", "test2@example.com"}
			skipList := []string{"test3@example.com", "test4@example.com"}

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, all)
		})

		mockey.PatchConvey("边界场景：all列表为空", func() {
			// 场景描述：
			// 构造数据：all列表为空，skipList有元素。
			// 逻辑链路：
			// 1. 函数遍历一个空的all列表。
			// 2. 循环不执行，直接返回一个nil的res列表。
			all := []string{}
			skipList := []string{"test1@example.com"}
			var expected []string

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界场景：all列表和skipList都为空", func() {
			// 场景描述：
			// 构造数据：all列表和skipList都为空。
			// 逻辑链路：
			// 1. 函数接收到空的skipList。
			// 2. 进入if len(skipList) == 0分支，直接返回空的all列表。
			all := []string{}
			skipList := []string{}

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, all)
		})

		mockey.PatchConvey("边界场景：skipList包含all列表的所有元素", func() {
			// 场景描述：
			// 构造数据：skipList包含all列表中的所有邮箱。
			// 逻辑链路：
			// 1. 函数将skipList转换为map。
			// 2. 遍历all列表，发现所有邮箱都在map中。
			// 3. 所有all列表中的邮箱都被跳过。
			// 4. 返回一个nil的res列表。
			all := []string{"test1@example.com", "test2@example.com"}
			skipList := []string{"test1@example.com", "test2@example.com", "test3@example.com"}
			var expected []string

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("特殊场景：列表中包含重复元素", func() {
			// 场景描述：
			// 构造数据：all列表包含重复邮箱，skipList移除其中一个。
			// 逻辑链路：
			// 1. 函数将skipList转换为map。
			// 2. 遍历all列表，其中"test2@example.com"被跳过。
			// 3. 重复的"test1@example.com"和"test3@example.com"都被保留。
			// 4. 返回过滤后的结果，其中保留了原始的重复元素。
			all := []string{"test1@example.com", "test2@example.com", "test1@example.com", "test3@example.com"}
			skipList := []string{"test2@example.com"}
			expected := []string{"test1@example.com", "test1@example.com", "test3@example.com"}

			result := h.removeSkipReturnReviewNoAuditEmails(all, skipList)

			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_handlerHaveChangeSubmit_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_Validate", t, func() {
		mockey.PatchConvey("happy path: always returns nil", func() {
			// 场景描述：
			// 目标函数Validate在客户有修改阶段直接返回nil，不执行任何校验逻辑。
			// 构造数据：
			// - h: 一个handlerHaveChangeSubmit的实例。
			// - ctx: 一个空的context。
			// - pc: 一个auditmodel.ProcessCtx的实例指针。
			// 逻辑链路：
			// 1. 调用h.Validate(ctx, pc)。
			// 2. 函数直接返回nil。
			// 3. 断言返回的error为nil。

			h := &handlerHaveChangeSubmit{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerHaveChangeSubmit_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerHaveChangeSubmit", t, func() {
		mockey.PatchConvey("正常场景-成功创建handler", func() {
			// 场景描述：
			// 调用 newHandlerHaveChangeSubmit 函数，期望返回一个非空的 handlerHaveChangeSubmit 实例。
			// 构造数据：
			// 无特殊数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerHaveChangeSubmit。
			// 2. 断言返回值不为 nil。
			// 3. 断言返回值的类型为 *handlerHaveChangeSubmit。

			// 调用
			handler := newHandlerHaveChangeSubmit()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerHaveChangeSubmit{})
		})
	})
}

func Test_handlerHaveChangeSubmit_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerHaveChangeSubmit CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractChange", func() {
			// 场景描述：
			// 构造数据：创建一个handlerHaveChangeSubmit的实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 验证返回值是否等于预期的常量_const.PreSalesContractChange。

			// 准备数据
			h := &handlerHaveChangeSubmit{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractChange)
		})
	})
}

func Test_handlerHaveChangeSubmit_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造一个handlerHaveChangeSubmit实例，调用其CurrentOp方法。
			// 逻辑链路：
			// 1. 调用CurrentOp方法。
			// 2. 期望返回常量_const.OperationSubmitChange。

			// 数据准备
			h := &handlerHaveChangeSubmit{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitChange)
		})
	})
}

func TestHandlerHaveChangeSubmitQuoteChangeRouting(t *testing.T) {
	for _, tc := range []struct {
		name string
		info *bizmodels.QuoteChangeInfo
		want string
	}{
		{name: "unbinding uses sales operations review", info: &bizmodels.QuoteChangeInfo{RelateQuoteChanged: true, RelateQuoteChangedBefore: "old-quote"}, want: _const.ApprovalStatusKeyMultiChangeQuote},
		{name: "replacement uses sales operations review", info: &bizmodels.QuoteChangeInfo{RelateQuoteChanged: true, RelateQuoteChangedBefore: "old-quote", RelateQuoteNo: "new-quote"}, want: _const.ApprovalStatusKeyMultiChangeQuote},
		{name: "unchanged uses default review", info: &bizmodels.QuoteChangeInfo{}, want: _const.ApprovalStatusKeyDefault},
		{name: "no change flag uses default review", want: _const.ApprovalStatusKeyDefault},
	} {
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				mockey.Mock(rediscli.GetQuoteChangeInfo).To(func(_ context.Context, contractNo string) (*bizmodels.QuoteChangeInfo, error) {
					convey.So(contractNo, convey.ShouldEqual, "contract")
					return tc.info, nil
				}).Build()
				pc := &auditmodel.ProcessCtx{ContractInfo: &model.ContractMeta{ContractNo: "contract"}}

				key := (&handlerHaveChangeSubmit{}).GetStatusOpConfKey(context.Background(), pc)

				convey.So(key, convey.ShouldEqual, tc.want)
			})
		})
	}
}

func Test_handlerHaveChangeSubmit_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述：
			// 这是一个最简单的场景，因为目标函数体为空，直接返回nil。
			// 构造数据：
			// - 初始化一个 handlerHaveChangeSubmit 实例。
			// - 初始化一个空的 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 方法直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerHaveChangeSubmit{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用与断言
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeSubmit_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeSubmit_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 逻辑非常简单，总是返回 (true, nil)。
			// 构造数据：创建一个 handlerHaveChangeSubmit 实例和必要的上下文参数。
			// 逻辑链路：
			// 1. 直接调用 HitStateChangeCondition 方法。
			// 2. 断言返回值符合预期，即 (true, nil)。

			// 准备数据
			h := &handlerHaveChangeSubmit{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

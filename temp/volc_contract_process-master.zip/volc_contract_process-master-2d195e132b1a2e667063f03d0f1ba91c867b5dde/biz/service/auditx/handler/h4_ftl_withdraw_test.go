package handler

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_handlerFTLReviewWithdraw_Validate_BitsUTGen(t *testing.T) {
	h := &handlerFTLReviewWithdraw{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_Validate", t, func() {
		mockey.PatchConvey("Success: comment is provided and reviewer status allows withdrawal", func() {
			// 场景描述：
			// 撤回原因不为空，且当前操作人作为审核人的状态为“审核通过”，满足撤回条件，校验成功。
			// 构造数据：
			// 1. pc.Comment不为空。
			// 2. pc.CurrentOperator为 "test_operator"。
			// 3. pc.ContractInfo.Reviewers 包含一个审核人，该审核人是当前操作人，且状态为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. pc.Comment.IsEmpty() 返回 false，不进入第一个if分支。
			// 2. for循环遍历Reviewers列表。
			// 3. 找到匹配的审核人，但其Status为ReviewStatusReviewPass，不满足 `reviewer.Status != _const.ReviewStatusReviewPass` 条件。
			// 4. 循环正常结束，函数返回nil。
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test_operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test_operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview,
							Status:         _const.ReviewStatusReviewPass,
						},
					},
				},
			}

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: no matching reviewer to block withdrawal", func() {
			// 场景描述：
			// 撤回原因不为空，但审核人列表中没有能够阻止撤回的审核人（例如列表为空），校验成功。
			// 构造数据：
			// 1. pc.Comment不为空。
			// 2. pc.ContractInfo.Reviewers 为空。
			// 逻辑链路：
			// 1. pc.Comment.IsEmpty() 返回 false，不进入第一个if分支。
			// 2. for循环不执行。
			// 3. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				Comment:      &bizmodels.RichTextInfo{},
				ContractInfo: &model.ContractMeta{Reviewers: bizmodels.PreContractReviewerList{}},
			}

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: comment is empty", func() {
			// 场景描述：
			// 撤回原因为空，校验失败。
			// 构造数据：
			// 1. pc.Comment 为空。
			// 逻辑链路：
			// 1. pc.Comment.IsEmpty() 返回 true。
			// 2. 进入第一个if分支，返回错误"撤回原因不可为空"。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("撤回原因不可为空")).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "撤回原因不可为空")
		})

		mockey.PatchConvey("Failure: reviewer has not passed the review", func() {
			// 场景描述：
			// 撤回原因不为空，但当前操作人作为审核人的审核状态不是“通过”，不可撤回，校验失败。
			// 构造数据：
			// 1. pc.Comment不为空。
			// 2. pc.CurrentOperator为 "test_operator"。
			// 3. pc.ContractInfo.Reviewers 包含一个审核人，该审核人是当前操作人，且状态不为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. pc.Comment.IsEmpty() 返回 false，不进入第一个if分支。
			// 2. for循环遍历Reviewers列表。
			// 3. 找到一个审核人，其所有条件都满足if判断。
			// 4. 进入if分支，返回错误"审核未通过，不可撤回"。
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test_operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test_operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview,
							Status:         _const.ReviewStatusReviewSendBack, // Not ReviewStatusReviewPass
						},
					},
				},
			}

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("审核未通过，不可撤回")).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核未通过，不可撤回")
		})
	})
}

func Test_handlerFTLReviewWithdraw_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_PostProcess", t, func() {
		mockey.PatchConvey("正常情况：函数直接返回nil", func() {
			// 场景描述：
			// PostProcess函数当前实现为空，直接返回nil。
			// 构造数据：
			// - h: 一个handlerFTLReviewWithdraw实例
			// - ctx: 一个空的context
			// - pc: 一个空的ProcessCtx实例
			// 逻辑链路：
			// 1. 调用PostProcess方法。
			// 2. 函数应直接返回nil，无任何错误。

			// 准备数据
			h := &handlerFTLReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewWithdraw_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述:
			// 目标函数 HitStateChangeCondition 总是返回 (false, nil)，不依赖于任何输入或内部状态。
			// 构造数据:
			// - h: 一个 handlerFTLReviewWithdraw 的实例。
			// - ctx: 一个 background context。
			// - pc: 一个空的 ProcessCtx 实例。
			// 逻辑链路:
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的错误为 nil。

			// 数据准备
			h := &handlerFTLReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLReviewWithdraw_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述:
			// Process方法被调用，由于方法体为空，直接返回nil。
			// 构造数据:
			// 构造一个空的handlerFTLReviewWithdraw实例。
			// 构造一个空的ProcessCtx实例。
			// 逻辑链路:
			// 1. 调用Process方法。
			// 2. 断言返回的error为nil。

			// 准备数据
			h := &handlerFTLReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewWithdraw_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_CurrentOp", t, func() {
		mockey.PatchConvey("正常case", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回正确的操作类型。
			// 构造数据：
			// 创建一个 handlerFTLReviewWithdraw 实例。
			// 逻辑链路：
			// 1. 创建 handlerFTLReviewWithdraw 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationReviewWithdraw。
			h := &handlerFTLReviewWithdraw{}

			result := h.CurrentOp()

			convey.So(result, convey.ShouldEqual, _const.OperationReviewWithdraw)
		})
	})
}

func Test_handlerFTLReviewWithdraw_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewWithdraw_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试handlerFTLReviewWithdraw的CurrentStatus方法是否能正确返回预设的常量状态值。
			// 构造数据：
			// 创建一个handlerFTLReviewWithdraw的实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 验证返回值是否等于常量 _const.PreSalesContractFinanceTaxationLegalReview。

			// 数据准备
			h := &handlerFTLReviewWithdraw{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalReview)
		})
	})
}

func Test_newHandlerFTLReviewWithdraw_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLReviewWithdraw", t, func() {
		mockey.PatchConvey("正常-成功创建", func() {
			// 场景描述:
			// 测试 newHandlerFTLReviewWithdraw 函数能否成功创建一个非空的 handler 实例。
			// 构造数据:
			// 无需构造特殊数据。
			// 逻辑链路:
			// 1. 调用 newHandlerFTLReviewWithdraw()。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的具体类型是 *handlerFTLReviewWithdraw。

			// 调用目标函数
			handler := newHandlerFTLReviewWithdraw()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLReviewWithdraw{})
		})
	})
}

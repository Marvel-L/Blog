package handler

import (
	"context"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerFTLSignReviewWithdraw() StatusOpHandler {
	return &handlerFTLSignReviewWithdraw{}
}

// 财税法签约审核(9) --- 审核撤回(3) --> 财税法交付专业审核(4)
type handlerFTLSignReviewWithdraw struct {
	handlerCommon
}

func (h *handlerFTLSignReviewWithdraw) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalSignReview
}

func (h *handlerFTLSignReviewWithdraw) CurrentOp() int {
	return _const.OperationReviewWithdraw
}

func (h *handlerFTLSignReviewWithdraw) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	if pc.Comment.IsEmpty() {
		return i18nfmt.New(ctx, "撤回原因不可为空")
	}

	for _, reviewer := range pc.ContractInfo.Reviewers {
		if reviewer.Reviewer == pc.CurrentOperator &&
			reviewer.ReviewerType == _const.ReviewerTypeFinanceTaxationLegalReviewer &&
			reviewer.ContractStatus == _const.PreSalesContractFinanceTaxationLegalSignReview &&
			reviewer.Status != _const.ReviewStatusReviewPass {
			return i18nfmt.New(ctx, "审核未通过，不可撤回")
		}
	}

	return nil
}

func (h *handlerFTLSignReviewWithdraw) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerFTLSignReviewWithdraw) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerFTLSignReviewWithdraw) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

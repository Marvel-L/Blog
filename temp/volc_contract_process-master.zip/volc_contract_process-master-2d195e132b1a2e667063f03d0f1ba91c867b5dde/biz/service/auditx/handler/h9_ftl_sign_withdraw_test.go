package handler

import (
	"context"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_handlerFTLSignReviewWithdraw_Validate_BitsUTGen(t *testing.T) {
	h := &handlerFTLSignReviewWithdraw{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerFTLSignReviewWithdraw Validate", t, func() {
		mockey.PatchConvey("Failure: comment is empty", func() {
			// 场景描述：
			// 当撤回原因为空时，校验应失败。
			// 构造数据：
			// - pc.Comment.IsEmpty() 返回 true
			// 逻辑链路：
			// 1. 调用 Validate 方法
			// 2. pc.Comment.IsEmpty() 返回 true，进入第一个 if 分支
			// 3. 返回 "撤回原因不可为空" 错误
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "撤回原因不可为空")
		})

		mockey.PatchConvey("Failure: review has not passed, cannot withdraw", func() {
			// 场景描述：
			// 当前操作人是财税法审核人，且其审核状态不是“通过”，此时不可撤回。
			// 构造数据：
			// - pc.Comment.IsEmpty() 返回 false
			// - pc.CurrentOperator 设置为 "test.operator"
			// - pc.ContractInfo.Reviewers 列表中包含一个 reviewer，其 Reviewer 与 CurrentOperator 相同，
			//   ReviewerType 为财税法审核人，ContractStatus 为财税法签约审核，且 Status 不为通过。
			// 逻辑链路：
			// 1. 调用 Validate 方法
			// 2. pc.Comment.IsEmpty() 返回 false，跳过第一个 if 分支
			// 3. for 循环遍历 Reviewers
			// 4. 找到一个匹配所有条件的 reviewer，进入 if 分支
			// 5. 返回 "审核未通过，不可撤回" 错误
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test.operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test.operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
							Status:         _const.ReviewStatusReviewSendBack, // 审核未通过
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核未通过，不可撤回")
		})

		mockey.PatchConvey("Success: review has passed, withdrawal is allowed", func() {
			// 场景描述：
			// 当前操作人是财税法审核人，但其审核状态是“通过”，此时可以撤回。
			// 构造数据：
			// - pc.Comment.IsEmpty() 返回 false
			// - pc.CurrentOperator 设置为 "test.operator"
			// - pc.ContractInfo.Reviewers 列表中包含一个 reviewer，其 Reviewer 与 CurrentOperator 相同，
			//   ReviewerType 为财税法审核人，ContractStatus 为财税法签约审核，但 Status 为通过。
			// 逻辑链路：
			// 1. 调用 Validate 方法
			// 2. pc.Comment.IsEmpty() 返回 false，跳过第一个 if 分支
			// 3. for 循环遍历 Reviewers
			// 4. 找到一个 reviewer，但不满足 Status != ReviewStatusReviewPass 的条件，跳过 if 分支
			// 5. 循环结束，返回 nil
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test.operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "test.operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
							Status:         _const.ReviewStatusReviewPass, // 审核已通过
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: no blocking reviewer found", func() {
			// 场景描述：
			// 撤回原因不为空，且 Reviewers 列表中没有满足所有阻止撤回条件的审核人，校验应通过。
			// 构造数据：
			// - pc.Comment.IsEmpty() 返回 false
			// - pc.CurrentOperator 设置为 "test.operator"
			// - pc.ContractInfo.Reviewers 列表不满足 if 条件（操作人不同、角色不同、合同状态不同）。
			// 逻辑链路：
			// 1. 调用 Validate 方法
			// 2. pc.Comment.IsEmpty() 返回 false，跳过第一个 if 分支
			// 3. for 循环遍历 Reviewers
			// 4. 没有找到匹配所有条件的 reviewer，不进入 if 分支
			// 5. 循环结束，返回 nil
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test.operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{ // 操作人不同
							Reviewer:       "other.operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
							Status:         _const.ReviewStatusUnreviewed,
						},
						{ // 审核角色不同
							Reviewer:       "test.operator",
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
							Status:         _const.ReviewStatusUnreviewed,
						},
						{ // 合同节点不同
							Reviewer:       "test.operator",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							Status:         _const.ReviewStatusUnreviewed,
						},
					},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: reviewers list is empty", func() {
			// 场景描述：
			// 撤回原因不为空，且审核人列表为空，校验应通过。
			// 构造数据：
			// - pc.Comment.IsEmpty() 返回 false
			// - pc.ContractInfo.Reviewers 为空
			// 逻辑链路：
			// 1. 调用 Validate 方法
			// 2. pc.Comment.IsEmpty() 返回 false，跳过第一个 if 分支
			// 3. for 循环不执行
			// 4. 返回 nil
			pc := &auditmodel.ProcessCtx{
				Comment:         &bizmodels.RichTextInfo{},
				CurrentOperator: "test.operator",
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{},
				},
			}
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerFTLSignReviewWithdraw_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLSignReviewWithdraw", t, func() {
		mockey.PatchConvey("正常case", func() {
			// 场景描述：
			// 成功创建一个 handlerFTLSignReviewWithdraw 实例。
			// 构造数据：
			// 无
			// 逻辑链路：
			// 1. 调用 newHandlerFTLSignReviewWithdraw 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的底层类型为 *handlerFTLSignReviewWithdraw。

			// 调用
			handler := newHandlerFTLSignReviewWithdraw()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			_, ok := handler.(*handlerFTLSignReviewWithdraw)
			convey.So(ok, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerFTLSignReviewWithdraw_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewWithdraw_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 这是一个简单的getter方法，没有复杂的逻辑。
			// 构造数据：
			// - 初始化一个handlerFTLSignReviewWithdraw实例
			// 逻辑链路：
			// 1. 调用CurrentStatus方法
			// 2. 断言返回值等于预定义的常量
			h := &handlerFTLSignReviewWithdraw{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		})
	})
}

func Test_handlerFTLSignReviewWithdraw_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewWithdraw_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerFTLSignReviewWithdraw 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于常量 _const.OperationReviewWithdraw。
			h := &handlerFTLSignReviewWithdraw{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationReviewWithdraw)
		})
	})
}

func Test_handlerFTLSignReviewWithdraw_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewWithdraw_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述：
			// 目标函数 Process 当前是一个空实现，直接返回 nil。
			// 构造数据：
			// 构造一个空的 handlerFTLSignReviewWithdraw 实例和一个空的 ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 断言返回的 error 为 nil。

			h := &handlerFTLSignReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignReviewWithdraw_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewWithdraw_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况，函数总是返回false和nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 的实现是直接返回 false 和 nil，没有任何条件判断或外部调用。
			// 构造数据：
			// - h: 一个 handlerFTLSignReviewWithdraw 的实例。
			// - ctx: 一个 background context。
			// - pc: 一个空的 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 函数直接返回 hardcode 的值 (false, nil)。
			// 3. 断言返回值符合预期。

			// 数据准备
			h := &handlerFTLSignReviewWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLSignReviewWithdraw_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewWithdraw_PostProcess", t, func() {
		mockey.PatchConvey("正常情况-函数直接返回nil", func() {
			// 场景描述：
			// 目标函数`PostProcess`的实现为空，直接返回nil。
			// 构造数据：
			// 构造一个空的`handlerFTLSignReviewWithdraw`实例和`ProcessCtx`实例。
			// 逻辑链路：
			// 1. 调用`PostProcess`方法。
			// 2. 断言返回的error为nil。
			h := &handlerFTLSignReviewWithdraw{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

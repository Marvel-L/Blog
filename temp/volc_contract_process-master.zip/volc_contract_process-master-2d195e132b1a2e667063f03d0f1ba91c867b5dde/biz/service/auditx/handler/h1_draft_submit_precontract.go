package handler

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"volc_contract_process/biz/service/contractmeta"

	"volc_contract_process/pkg/proxy/feishucli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/oacli"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"
)

func newHandlerDraftSubmitPreContract() StatusOpHandler {
	return &handlerDraftSubmitPreContract{
		dao: dal.NewContractMetaDao(),
	}
}

// 草稿(1) --- 提交在线协同(1) --> 销售运营专业审核(3)
type handlerDraftSubmitPreContract struct {
	handlerCommon
	dao dal.ContractMetaDao
}

func (h *handlerDraftSubmitPreContract) CurrentStatus() int {
	return _const.PreSalesContractDraft
}

func (h *handlerDraftSubmitPreContract) CurrentOp() int {
	return _const.OperationSubmitPreContract
}

func (h *handlerDraftSubmitPreContract) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	if pc.ContractInfo == nil {
		return errorsV2.ErrCommon.WithArgs("合同协同记录不存在")
	}
	meta := pc.ContractInfo
	if meta.BasicInfo == nil || meta.BasicInfo.ContractTemplateType == nil {
		return errorsV2.ErrMissingParam.WithArgs("ContractTemplateType")
	}
	if err := meta.TradePartyInfo.BaseValidate(); err != nil {
		return err
	}
	// 银行账号信息校验，目前仅直连飞书的合同执行此校验
	if meta.BasicInfo.IsFeishu {
		if err := meta.TradePartyInfo.CheckPayTypes(); err != nil {
			return err
		}
	}
	// 关联报价单场景必填校验
	// 需要关联报价单时，关联报价单场景必填
	if meta.CalcRequireQuote() &&
		meta.RelateQuoteScene == _const.RelateQuoteSceneDefault {
		return errorsV2.ErrQuoteCommon.WithArgs("当前合同【关联报价单场景】必填")
	}

	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}

	if err := h.validateRequireQuote(ctx, pc); err != nil {
		return err
	}

	// 校验账号关联我方主体
	if err := h.getMetaServiceV2(ctx).CheckRelateSubjectParty(ctx, &contractmeta.CheckRelateSubjectPartyReq{
		BizSource: _const.BizSourceCooperation,
		// 此字段只用来判断是否需要校验，默认传销售运营专业审核，需要测试即可
		CooperationStatus:   _const.PreSalesContractSalesOperationReview,
		SpecialContractType: meta.BasicInfo.SpecialContractType,
		BusinessType:        meta.BasicInfo.BusinessType,
		TradePartyInfo:      meta.TradePartyInfo,
	}); err != nil {
		logs.CtxError(ctx, "CheckRelateSubjectPartyFail, err:%v", err)
		return err
	}

	return nil
}

func (h *handlerDraftSubmitPreContract) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// CT 合同号不存在时 生成合同号并重置
	if !strings.HasPrefix(pc.ContractInfo.ContractNo, "CT") {
		oaContractInfo, err := h.genOAContractID(ctx)
		if err != nil {
			return err
		}
		if oaContractInfo == nil {
			logs.CtxError(ctx, "OAInitSalesContractFail err: resp is nil")
			return errorsV2.ErrCommon.WithArgs("genOAContractIDFail")
		}
		// 重置
		if err := h.resetPreContractNo(ctx, pc, oaContractInfo); err != nil {
			return err
		}
	}
	// 查询当前销售运营人员信息
	reviewerMappings, err := h.getAndValidateReviewerMappings(ctx, []string{_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp)}, pc.ContractInfo.BasicInfo.DepartmentId, pc.ContractInfo.Operator)
	if err != nil {
		return err
	}
	if len(reviewerMappings) == 0 {
		return errorsV2.ErrCommon.WithArgs("销售运营人员未定义")
	}
	salesOpEmails := reviewerMappings[_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp)]
	if len(salesOpEmails) == 0 {
		return errorsV2.ErrCommon.WithArgs("销售运营人员未定义")
	}
	salesOpEmailList := strings.Split(salesOpEmails, ",")
	employeeMappings, err := larkc.BatchGetEmployees(ctx, salesOpEmailList)
	if err != nil {
		return err
	}
	if len(employeeMappings) == 0 {
		return errorsV2.ErrCommon.WithArgs("查询people数据失败")
	}
	// 定义多个销售运营时，取第一个
	employee := employeeMappings[salesOpEmailList[0]]
	if employee == nil {
		return errorsV2.ErrCommon.WithArgs("查询people数据失败")
	}
	// todo: 这里填写false是正确的么
	user, err := larkc.GetUserIdByEmail(ctx, salesOpEmailList[0], false)
	if err != nil {
		logs.CtxError(ctx, "GetUserIdByEmailFail, email:%s, err:%v", salesOpEmailList[0], err)
		return err
	}
	pc.ContractInfo.Creator = strconv.Itoa(employee.ID)
	pc.ContractInfo.CreatorNew = strconv.Itoa(employee.EmployeeNumber)
	// 填充 basicInfo
	pc.ContractInfo.BasicInfo.CreatorUserId = user.UserID
	pc.ContractInfo.BasicInfo.CreatorNew = strconv.Itoa(employee.EmployeeNumber)
	basicInfoStr, _ := json.Marshal(pc.ContractInfo.BasicInfo)
	// 更新用字段数据更新，重新设置 basicInfo
	pc.PreContractVO.Creator = strconv.Itoa(employee.ID)
	pc.PreContractVO.CreatorNew = strconv.Itoa(employee.EmployeeNumber)
	pc.PreContractVO.BasicInfo = string(basicInfoStr)

	// 提交合规审查
	if err := h.SubmitComplianceCheck(ctx, pc); err != nil {
		return err
	}
	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		return err
	}

	// 创建协同审批条目
	if err := h.updateContractReviewers(ctx, pc); err != nil {
		return err
	}

	return nil
}

// 重置
func (h *handlerDraftSubmitPreContract) resetPreContractNo(ctx context.Context, pc *auditmodel.ProcessCtx,
	oaContractInfo *oacli.InitSalesContractData) error {

	oldNo := pc.ContractInfo.ContractNo
	newNo := oaContractInfo.ContractNumber

	// 重置协同表中的pre_contract_no
	err := dal.NewContractMetaDao().ResetContractNo(ctx, pc.GetTx(), oldNo, newNo, oaContractInfo.ContractId,
		oaContractInfo.CheckCode, oaContractInfo.RequestId, pc.ContractInfo.CooperationStatus)
	if err != nil {
		return err
	}

	// 重置协同管理员表中的pre_contract_no
	err = dal.NewPreContractManagerDao().ChangePreContractNo(ctx, pc.GetTx(), oldNo, newNo)
	if err != nil {
		return err
	}

	// 重置审批记录中的pre_contract_no
	err = dal.NewContractOperationRecordDao().UpdateNo(ctx, pc.GetTx(), oldNo, newNo)
	if err != nil {
		return err
	}

	// 重置协同审批条目中的pre_contract_no
	err = dal.NewPreContractReviewerDao().UpdateNo(ctx, pc.GetTx(), oldNo, newNo)
	if err != nil {
		return err
	}

	// 更新上下文中的参数
	pc.PreContractNo = newNo
	pc.ContractInfo.ContractNo = newNo
	pc.ContractInfo.ContractId = oaContractInfo.ContractId
	pc.ContractInfo.CheckCode = oaContractInfo.CheckCode
	pc.ContractInfo.RequestId = oaContractInfo.ContractId
	pc.PreContractVO.ContractNo = newNo
	pc.PreContractVO.ContractId = oaContractInfo.ContractId
	pc.PreContractVO.CheckCode = oaContractInfo.CheckCode
	pc.PreContractVO.RequestId = oaContractInfo.ContractId
	if pc.ContractInfo.SupplyScene == _const.SupplySceneNew {
		pc.ContractInfo.MainContractNo = newNo
		pc.PreContractVO.MainContractNo = newNo
	}
	return nil
}

func (h *handlerDraftSubmitPreContract) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerDraftSubmitPreContract) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 通知报价系统绑定、解绑合同 出错时 仅提供报报警
	if err := h.handleQuoteChangeWhenSubmit(ctx, pc); err != nil {
		return err
	}

	if pc.StatusChangedValue != _const.PreSalesContractComplianceCheck {
		// 发送飞书消息
		multiCtx := context.Background()
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, pc.StatusChangedValue),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())

		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSubmitPreContract, pc)
	}

	return nil
}

func (h *handlerDraftSubmitPreContract) genOAContractID(ctx context.Context) (*oacli.InitSalesContractData, error) {
	// respData, err := oacli.InitSalesContract(ctx, creator)
	contractNo, err := feishucli.GenerateContractNo(ctx)
	if err != nil {
		logs.CtxError(ctx, "OAInitSalesContractFail err: %v", err)
		return nil, i18nfmt.New(ctx, "OAInitSalesContractFail")
	}
	return &oacli.InitSalesContractData{
		ContractNumber: contractNo,
	}, nil
}

// GetStatusOpConfKey 获取状态操作配置键
// 实现逻辑：
//  1. 当流程上下文缺少合规审查信息时，返回默认状态配置键
//  2. 当交易未被拒绝时，返回合规审查状态配置键
//  3. 其他情况返回默认状态配置键
//
// 参数：
//   - ctx 上下文对象
//   - pc 流程上下文对象
//
// 返回值：
//   - 状态配置键字符串
func (h *handlerDraftSubmitPreContract) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	// 兜底逻辑，流转至默认状态
	if pc.ComplianceCheckInfo == nil {
		return _const.ApprovalStatusKeyDefault
	}
	// 命中人审时，默认流转至合规审查中
	if pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction {
		return _const.ApprovalStatusKeyComplianceCheck
	}
	// 未命中人审时，流转至默认状态，根据配置处理
	return _const.ApprovalStatusKeyDefault
}

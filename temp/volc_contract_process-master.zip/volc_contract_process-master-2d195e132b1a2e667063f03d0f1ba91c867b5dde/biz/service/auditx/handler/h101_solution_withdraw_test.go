package handler

import (
	"context"
	"errors"
	"testing"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/service/auditx/auditmodel"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/const"
)

func Test_handlerSolutionWithdraw_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_PostProcess", t, func() {
		mockey.PatchConvey("正常调用，应返回nil", func() {
			// 场景描述：
			// PostProcess函数当前实现为空，直接返回nil。
			// 构造数据：
			// - 构造一个空的handlerSolutionWithdraw实例。
			// - 构造一个空的上下文context。
			// - 构造一个空的ProcessCtx。
			// 逻辑链路：
			// 1. 调用PostProcess方法。
			// 2. 预期直接返回nil。

			h := handlerSolutionWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionWithdraw_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_HitStateChangeCondition", t, func() {
		// 初始化handler
		h := handlerSolutionWithdraw{}
		// 初始化上下文
		ctx := context.Background()

		mockey.PatchConvey("场景一：所有审批节点均已通过，应返回true", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其中包含必要的合同信息和审批配置。
			// 逻辑链路：
			// 1. 调用h.HitStateChangeCondition
			// 2. 内部调用h.commonCheckHitContractStatusChange
			// 3. Mock dal.IsAllReviewerTypePassed 返回 true 和 nil error，表示所有审批者都已通过。
			// 4. 函数最终返回 true 和 nil error。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}

			// Mocking
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(true, nil).Build()

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景二：部分审批节点未通过，应返回false", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx。
			// 逻辑链路：
			// 1. 调用h.HitStateChangeCondition
			// 2. 内部调用h.commonCheckHitContractStatusChange
			// 3. Mock dal.IsAllReviewerTypePassed 返回 false 和 nil error，表示尚有审批者未完成审批。
			// 4. 函数最终返回 false 和 nil error。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}

			// Mocking
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, nil).Build()

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景三：检查审批节点状态时数据库查询失败，应返回error", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx。
			// 逻辑链路：
			// 1. 调用h.HitStateChangeCondition
			// 2. 内部调用h.commonCheckHitContractStatusChange
			// 3. Mock dal.IsAllReviewerTypePassed 返回 false 和一个数据库错误。
			// 4. h.commonCheckHitContractStatusChange 捕获错误，并包装成一个新的i18n错误。
			// 5. 函数最终返回 false 和该错误。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			dbErr := errors.New("database query error")

			// Mocking
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, dbErr).Build()

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(hit, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
		})
	})
}

func Test_handlerSolutionWithdraw_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_Process", t, func() {
		mockey.PatchConvey("Normal case: should return nil", func() {
			// 场景描述：
			// 目标函数 `handlerSolutionWithdraw.Process` 的实现是空的，直接返回 nil。
			// 构造数据：
			// 构造一个空的 `handlerSolutionWithdraw` 实例和空的 `ProcessCtx`。
			// 逻辑链路：
			// 1. 调用 `Process` 方法。
			// 2. 预期返回 nil。

			// 数据准备
			h := handlerSolutionWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionWithdraw_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_Validate", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述:
			// Validate方法是一个空实现，直接返回nil。
			// 构造数据:
			// 构造一个空的handlerSolutionWithdraw实例和ProcessCtx。
			// 逻辑链路:
			// 1. 调用Validate方法。
			// 2. 断言返回的error为nil。

			// 准备数据
			h := handlerSolutionWithdraw{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionWithdraw_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个空的 handlerSolutionWithdraw 实例。
			// 逻辑链路：直接调用 CurrentOp 方法，该方法应返回固定的常量值。
			h := handlerSolutionWithdraw{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationReviewWithdraw)
		})
	})
}

func Test_handlerSolutionWithdraw_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionWithdraw_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSolutionReview", func() {
			// 场景描述：
			// 该函数逻辑简单，直接返回一个常量值。
			// 构造数据：创建一个空的 handlerSolutionWithdraw 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值等于常量 _const.PreSalesContractSolutionReview。
			h := handlerSolutionWithdraw{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSolutionReview)
		})
	})
}

func Test_newHandlerSolutionWithdraw_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSolutionWithdraw", t, func() {
		mockey.PatchConvey("normal case", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerSolutionWithdraw() 函数
			// 2. 验证返回的 handler 不为 nil
			// 3. 验证返回的 handler 的具体类型是 *handlerSolutionWithdraw

			// 调用
			handler := newHandlerSolutionWithdraw()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSolutionWithdraw{})
		})
	})
}

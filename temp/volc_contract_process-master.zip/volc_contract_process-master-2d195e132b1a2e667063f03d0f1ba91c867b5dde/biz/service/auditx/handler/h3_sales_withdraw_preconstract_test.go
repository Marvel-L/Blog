package handler

import (
	"context"
	"errors"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/support/metacommodity"
	_const "volc_contract_process/pkg/const"
)

func Test_handlerSalesReviewWithdrawPreContract_PostProcess_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock struct for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_PostProcess", t, func() {
		h := &handlerSalesReviewWithdrawPreContract{}
		ctx := context.Background()
		mockTx := &gorm.DB{}

		prepareQuoteCleanup := func(cleanupErr error) *auditmodel.ProcessCtx {
			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(cleanupErr).Build()
			return &auditmodel.ProcessCtx{
				PreContractNo: "test-contract-no",
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneCompleted,
					BasicInfo:        &bizmodels.BasicInfo{},
				},
				PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}},
			}
		}

		mockey.PatchConvey("scenario: successful execution", func() {
			pc := prepareQuoteCleanup(nil)
			mockDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("scenario: clearQuoteInfo fails", func() {
			expectedErr := errors.New("failed to clear quote product infos")
			pc := prepareQuoteCleanup(expectedErr)

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to clear quote product infos")
		})

		mockey.PatchConvey("scenario: DeleteReviewersByType fails", func() {
			expectedErr := errors.New("failed to delete reviewers")
			pc := prepareQuoteCleanup(nil)

			mockDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).When(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType []int, contractStatusList ...int) bool {
				convey.So(preContractNo, convey.ShouldEqual, "test-contract-no")
				convey.So(reviewerType, convey.ShouldResemble, []int{
					_const.ReviewerTypeFinanceTaxationLegalReviewer,
					_const.ReviewerTypeSalesOperation,
				})
				convey.So(contractStatusList, convey.ShouldBeEmpty)
				return true
			}).Return(expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to delete reviewers")
		})
	})
}

func Test_handlerSalesReviewWithdrawPreContract_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_Validate", t, func() {
		h := &handlerSalesReviewWithdrawPreContract{}
		ctx := context.Background()

		mockey.PatchConvey("失败场景：合同已被销售运营专业审核通过，不可撤回", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx，其 ContractInfo.Reviewers 列表中包含一个已由销售运营专业审核通过的审批人记录。
			// 逻辑链路：
			// 1. 函数进入 for 循环，遍历 Reviewers 列表。
			// 2. 循环中的 if 条件（ReviewerType, ContractStatus, Status均匹配）为 true。
			// 3. 调用 i18nfmt.Errorf 生成并返回错误。
			// 4. 断言返回的 error 不为 nil，且错误信息符合预期。

			// 构造数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						&bizmodels.PreContractReviewer{
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							Status:         _const.ReviewStatusReviewPass,
						},
					},
				},
			}

			// Mock i18nfmt.Errorf
			mockey.Mock(i18nfmt.Errorf).Return(errors.New("合同已被销售运营专业审核，不可撤回")).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同已被销售运营专业审核，不可撤回")
		})

		mockey.PatchConvey("成功场景：合同未被销售运营专业审核通过", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx，其 ContractInfo.Reviewers 列表中的审批人记录不满足“已被销售运营专业审核通过”的条件（例如，角色、节点或状态不匹配）。
			// 逻辑链路：
			// 1. 函数进入 for 循环，遍历 Reviewers 列表。
			// 2. 循环中的 if 条件始终为 false。
			// 3. 循环正常结束。
			// 4. 函数返回 nil。
			// 5. 断言返回的 error 为 nil。

			// 构造数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						// 角色不匹配
						&bizmodels.PreContractReviewer{
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							Status:         _const.ReviewStatusReviewPass,
						},
						// 节点不匹配
						&bizmodels.PreContractReviewer{
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview,
							Status:         _const.ReviewStatusReviewPass,
						},
						// 状态不匹配
						&bizmodels.PreContractReviewer{
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							ContractStatus: _const.PreSalesContractSalesOperationReview,
							Status:         _const.ReviewStatusReviewSendBack,
						},
					},
				},
			}

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景：审批人列表为空", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx，其 ContractInfo.Reviewers 列表为空。
			// 逻辑链路：
			// 1. 函数的 for 循环不会执行。
			// 2. 函数直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 构造数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{},
				},
			}

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景：ContractInfo 为 nil", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx，其 ContractInfo 为 nil。
			// 逻辑链路：
			// 1. 函数访问 pc.ContractInfo.Reviewers 时会发生 panic。
			//    (这是一个边缘情况测试，实际代码中 ProcessCtx.ContractInfo 应该总被初始化，但测试可以覆盖此意外情况)
			//    根据函数实现，pc.ContractInfo.Reviewers 是一个 slice，如果 pc.ContractInfo 是 nil，会 panic。
			//    在实际业务中，pc.ContractInfo 应该由上游保证不为nil，此处我们假设其不为nil，但其Reviewers字段为nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Reviewers: nil,
				},
			}

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewWithdrawPreContract_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should return true and nil", func() {
			// 场景描述：
			// 这是一个简单场景，目标函数直接返回 true 和 nil。
			// 构造数据：
			// - 构造一个空的 handlerSalesReviewWithdrawPreContract 实例。
			// - 构造一个空的 context.Context。
			// - 构造一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回值为 true 和 nil。

			// 准备数据
			h := &handlerSalesReviewWithdrawPreContract{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerSalesReviewWithdrawPreContract_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_Process", t, func() {
		mockey.PatchConvey("Normal case: should return nil", func() {
			// 场景描述：
			// 这是一个简单场景，目标函数 `Process` 当前实现为空，直接返回 nil。
			// 构造数据：
			// - h: 一个 `handlerSalesReviewWithdrawPreContract` 实例。
			// - ctx: 一个空的 `context.Context`。
			// - pc: 一个空的 `auditmodel.ProcessCtx` 实例。
			// 逻辑链路：
			// 1. 调用 `Process` 方法。
			// 2. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerSalesReviewWithdrawPreContract{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewWithdrawPreContract_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况：应返回撤回操作码", func() {
			// 场景描述：
			// 本测试用例用于验证 handlerSalesReviewWithdrawPreContract 的 CurrentOp 方法。
			// 构造数据：
			// - 创建一个 handlerSalesReviewWithdrawPreContract 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于常量 _const.OperationWithdraw。

			// 数据准备
			h := &handlerSalesReviewWithdrawPreContract{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationWithdraw)
		})
	})
}

func Test_handlerSalesReviewWithdrawPreContract_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewWithdrawPreContract_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSalesOperationReview", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回预期的状态码。
			// 构造数据：
			// 创建一个 handlerSalesReviewWithdrawPreContract 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值是否等于 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewWithdrawPreContract{}

			// 调用目标函数
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewWithdrawPreContract_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSalesReviewWithdrawPreContract", t, func() {
		mockey.PatchConvey("正常调用，应返回一个handlerSalesReviewWithdrawPreContract实例", func() {
			// 场景描述：
			// 验证 newHandlerSalesReviewWithdrawPreContract 函数是否能正确创建一个 *handlerSalesReviewWithdrawPreContract 实例。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerSalesReviewWithdrawPreContract()。
			// 2. 断言返回的 handler 不为 nil。
			// 3. 断言返回的 handler 的类型为 *handlerSalesReviewWithdrawPreContract。

			// 调用目标函数
			handler := newHandlerSalesReviewWithdrawPreContract()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewWithdrawPreContract{})
		})
	})
}

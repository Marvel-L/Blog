package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerFTLReviewAddReviewers() StatusOpHandler {
	return &handlerFTLReviewAddReviewers{}
}

// 财税法交付专业审核(4) --- 加签(5) --> 财税法审核(4)
type handlerFTLReviewAddReviewers struct {
	handlerCommon
}

func (h *handlerFTLReviewAddReviewers) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalReview
}

func (h *handlerFTLReviewAddReviewers) CurrentOp() int {
	return _const.OperationAddReviewer
}

func (h *handlerFTLReviewAddReviewers) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerFTLReviewAddReviewers) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerFTLReviewAddReviewers) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerFTLReviewAddReviewers) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

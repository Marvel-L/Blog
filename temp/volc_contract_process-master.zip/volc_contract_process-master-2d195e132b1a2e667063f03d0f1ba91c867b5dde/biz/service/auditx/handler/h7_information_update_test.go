package handler

import (
	"code.byted.org/lang/gg/gptr"
	"context"
	"encoding/json"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/supply"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerInformationUpdate_Validate_BitsUTGen(t *testing.T) {
	// Mock 接口定义
	type MockMetaService struct {
		contractmeta.MetaService
	}
	type MockSupplyService struct {
		supply.SupplyService
	}

	mockey.PatchConvey("Test_handlerInformationUpdate_Validate", t, func() {
		// 初始化通用变量
		ctx := context.Background()
		h := &handlerInformationUpdate{}

		mockey.PatchConvey("场景1: 非补充协议场景", func() {
			// 场景描述: PreContractVO.SupplySource 为空，表示非补充协议，直接返回成功。
			// 构造数据: pc.PreContractVO.SupplySource = ""
			// 逻辑链路:
			// 1. validateSupply 函数内 len(contractDB.SupplySource) == 0 条件成立。
			// 2. 设置 MainContractNo。
			// 3. 返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource: "",
					ContractNo:   "test-contract-no",
				},
				ContractInfo: &model.ContractMeta{},
			}
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "test-contract-no")
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "test-contract-no")
		})

		mockey.PatchConvey("场景2: 补充协议场景 - 原合同号为空", func() {
			// 场景描述: PreContractVO.SupplySource 不为空，但 FromContractNo 为空，应返回错误。
			// 构造数据: pc.PreContractVO.SupplySource = "test-source", pc.PreContractVO.FromContractNo = ""
			// 逻辑链路:
			// 1. validateSupply 函数内 len(contractDB.SupplySource) == 0 条件不成立。
			// 2. contractDB.FromContractNo == "" 条件成立，返回错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "",
				},
			}
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "原合同号不能为空")
		})

		mockey.PatchConvey("场景3: 补充协议场景 - GetSupplyContractList 失败", func() {
			// 场景描述: 调用 GetSupplyContractList 接口返回错误。
			// 构造数据: pc.PreContractVO.SupplySource 和 FromContractNo 均有值。
			// 逻辑链路:
			// 1. Mock contractmeta.NewMetaService 返回 MockMetaService 实例。
			// 2. Mock (*MockMetaService).GetSupplyContractList 返回一个 error。
			// 3. validateSupply 函数捕获到错误，并返回包装后的错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
			}
			mockErr := errorsV2.ErrCommon.WithArgs("get supply list failed")

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, mockErr).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
		})

		mockey.PatchConvey("场景4: 补充协议场景 - GetSupplyContractList 返回空", func() {
			// 场景描述: 调用 GetSupplyContractList 接口返回 nil, nil。
			// 构造数据: pc.PreContractVO.SupplySource 和 FromContractNo 均有值。
			// 逻辑链路:
			// 1. Mock contractmeta.NewMetaService 返回 MockMetaService 实例。
			// 2. Mock (*MockMetaService).GetSupplyContractList 返回 (nil, nil)。
			// 3. validateSupply 函数判断 supplyContractList == nil 成立，返回错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, nil).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "补充协议相关合同信息不存在")
		})

		mockey.PatchConvey("场景5: 补充协议场景 - ValidateBase 失败", func() {
			// 场景描述: supplyService.ValidateBase 校验失败。
			// 构造数据: GetSupplyContractList 返回正常数据。
			// 逻辑链路:
			// 1. Mock contractmeta.NewMetaService 和 supply.NewSupplyService。
			// 2. Mock GetSupplyContractList 返回成功。
			// 3. Mock ValidateBase 返回一个 error。
			// 4. validateSupply 函数直接返回 ValidateBase 的错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{
					MainContractNo: "main-contract-no",
					ManageInfo:     &bizmodels.ManageInfo{BelongingDepartment: "dep"},
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("ps@example.com"),
						RelatedResDepartment: gptr.Of("res@example.com"),
						DeliveryStaff:        gptr.Of("delivery@example.com"),
					},
				},
			}
			mockErr := errorsV2.ErrCommon.WithArgs("validate base failed")

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(mockErr).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate base failed")
		})

		mockey.PatchConvey("场景6: 补充协议场景 - ValidateValidityTime 失败", func() {
			// 场景描述: 满足校验有效期条件，但 supplyService.ValidateValidityTime 校验失败。
			// 构造数据: pc.ContractInfo.CooperationStatus 为指定值，OperationState 不为变更报价单。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 和 ValidateBase 成功。
			// 2. Mock utils.IntIn 返回 true。
			// 3. Mock ValidateValidityTime 返回一个 error。
			// 4. validateSupply 函数返回 ValidateValidityTime 的错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationReviewPass,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}
			mockErr := errorsV2.ErrCommon.WithArgs("validate validity time failed")

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(mockErr).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate validity time failed")
		})

		mockey.PatchConvey("场景7: 补充协议场景 - 变更报价单时 Extra 解析失败", func() {
			// 场景描述: 操作为变更报价单，但 Extra 字段为无效 JSON。
			// 构造数据: pc.OperationState = _const.OperationChangeQuoteNo, pc.Extra 为非法 JSON。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 成功。
			// 2. json.Unmarshal 解析 pc.Extra 失败。
			// 3. validateSupply 返回 "解析合同变更信息失败" 错误。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          `{"invalid json`,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解析合同变更信息失败")
		})

		mockey.PatchConvey("场景8: 成功路径 - 正常流程，不校验有效期", func() {
			// 场景描述: 所有校验通过，且不满足校验有效期条件。
			// 构造数据: 正常数据，pc.ContractInfo.CooperationStatus 不在指定范围内。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 和 ValidateBase 成功。
			// 2. Mock utils.IntIn 返回 false。
			// 3. 函数跳过有效期校验，直接返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationReviewPass,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(false).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景9: 成功路径 - 校验有效期通过", func() {
			// 场景描述: 所有校验通过，且满足校验有效期条件，有效期校验也通过。
			// 构造数据: pc.ContractInfo.CooperationStatus 在指定范围内。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList, ValidateBase, ValidateValidityTime 均成功。
			// 2. Mock utils.IntIn 返回 true。
			// 3. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationReviewPass,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(nil).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景10: 成功路径 - 变更报价单场景", func() {
			// 场景描述: 操作为变更报价单，所有校验通过。
			// 构造数据: pc.OperationState = _const.OperationChangeQuoteNo, pc.Extra 为合法 JSON。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 和 ValidateBase 成功。
			// 2. json.Unmarshal 成功。
			// 3. 因 OperationState，跳过有效期校验。
			// 4. 函数返回 nil。
			changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "new-quote-id"}
			extraBytes, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          string(extraBytes),
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(nil).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景10: 失败路径 - 交易对方主体未通过", func() {
			// 场景描述: 操作为变更报价单，所有校验通过。
			// 构造数据: pc.OperationState = _const.OperationChangeQuoteNo, pc.Extra 为合法 JSON。
			// 逻辑链路:
			// 1. Mock GetSupplyContractList 和 ValidateBase 成功。
			// 2. json.Unmarshal 成功。
			// 3. 因 OperationState，跳过有效期校验。
			// 4. 函数返回 nil。
			changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "new-quote-id"}
			extraBytes, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "test-source",
					FromContractNo: "from-contract-no",
				},
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          string(extraBytes),
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-contract-no"},
			}

			mockey.Mock(contractmeta.NewMetaService).Return(&MockMetaService{}).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(&MockSupplyService{}).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			ValidateDeputyPartyMock := mockey.GetMethod(&handlerInformationUpdate{}, "ValidateDeputyParty")
			mockey.Mock(ValidateDeputyPartyMock).Return(errors.New("deputy party error")).Build()

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "deputy party error")
		})
	})
}

// Test_handlerInformationUpdate_Process tests the Process method of handlerInformationUpdate.
func Test_handlerInformationUpdate_Process_BitsUTGen(t *testing.T) {
	// Mock DAO interfaces for mocking DAL calls
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}
	type MockContractSettlementDao struct {
		dal.ContractSettlementDao
	}
	type MockContractAttachmentDao struct {
		dal.ContractAttachmentDao
	}

	// defaultPc is a helper function to create a default ProcessCtx for tests
	defaultPc := func() *auditmodel.ProcessCtx {
		return &auditmodel.ProcessCtx{
			PreContractVO: &model.ContractMetaDB{
				ContractNo: "test-contract-no-123",
				BaseDB:     model.BaseDB{Id: 1},
			},
			ContractInfo: &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
				Ext:            map[string]string{"key1": "val1"},
				SettlementInfo: &bizmodels.SettlementInfo{
					SettlementLines: bizmodels.SettlementLines{
						{
							InvoicingPercent: "100",
							InvoicingTotal:   "10000",
							PaymentPercent:   "100",
							PaymentTotal:     "10000",
						},
					},
				},
			},
			DelExtKeys: []string{"del-key1"},
			AttachmentUpdateList: []*bizmodels.MetaAttachment{
				{DownloadID: "att-download-id-1"},
			},
		}
	}

	mockey.PatchConvey("Test handlerInformationUpdate Process", t, func() {
		h := &handlerInformationUpdate{}
		ctx := context.Background()

		// Mock DAO instances
		mockMetaDao := &MockContractMetaDao{}
		mockSettlementDao := &MockContractSettlementDao{}
		mockAttachmentDao := &MockContractAttachmentDao{}

		mockey.PatchConvey("Success case: all dependent calls succeed", func() {
			// 场景描述:
			// Process函数依赖的updateContractData函数中所有子调用均成功，Process应成功执行并返回nil。
			// 构造数据:
			// 使用默认的ProcessCtx，其中包含合同信息、结算信息和附件更新列表。
			// 逻辑链路:
			// 1. Mock GetTemplateFileId 成功返回新的文件ID。
			// 2. Mock CreateOrUpdateAttachment 成功。
			// 3. Mock h.updatePreContract 内部的 dal.UpdateFieldsByNo 成功。
			// 4. Mock SaveManageInfo, SaveTradePartyInfo, SaveMetaExt 均成功。
			// 5. Mock h.updateContractSettlement 内部的dal调用 (SoftDelete, GenSettlementDB, BatchCreate) 均成功。
			// 6. Mock h.updateAttachment 内部的dal调用 (UpdateByFileKey) 成功。
			// 7. 最终，Process 方法返回 nil。

			pc := defaultPc()

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
			mockey.Mock(json.Marshal).Return([]byte(`{}`), nil).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.ContractFile, convey.ShouldEqual, "new-file-id")
		})

		mockey.PatchConvey("Failure case: GetTemplateFileId fails", func() {
			// 场景描述:
			// 在处理流程的开始，获取模板文件ID时失败，Process应立即中断并返回错误。
			// 构造数据:
			// 使用默认的ProcessCtx。
			// 逻辑链路:
			// 1. Mock GetTemplateFileId 返回一个错误。
			// 2. Process 方法捕获该错误并直接返回，后续流程不再执行。

			pc := defaultPc()
			expectedErr := errors.New("get template file id failed")

			mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "get template file id failed")
		})

		mockey.PatchConvey("Failure case: CreateOrUpdateAttachment fails", func() {
			// 场景描述:
			// 获取模板文件ID成功后，在创建或更新合同文本附件时失败，Process应返回错误。
			// 构造数据:
			// 使用默认的ProcessCtx。
			// 逻辑链路:
			// 1. Mock GetTemplateFileId 成功。
			// 2. Mock CreateOrUpdateAttachment 返回一个错误。
			// 3. Process 方法捕获该错误并直接返回。

			pc := defaultPc()
			expectedErr := errors.New("create or update attachment failed")

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "create or update attachment failed")
		})

		mockey.PatchConvey("Failure case: updatePreContract fails", func() {
			// 场景描述:
			// 在更新合同元数据时，底层的数据库操作失败，Process应返回错误。
			// 构造数据:
			// 使用默认的ProcessCtx。
			// 逻辑链路:
			// 1. 前续步骤（GetTemplateFileId, CreateOrUpdateAttachment）均成功。
			// 2. Mock h.updatePreContract 内部调用的 dal.UpdateFieldsByNo 返回错误。
			// 3. Process 方法捕获该错误并返回。

			pc := defaultPc()
			expectedErr := errors.New("update pre-contract failed")

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update pre-contract failed")
		})

		mockey.PatchConvey("Failure case: SaveManageInfo fails", func() {
			// 场景描述:
			// 在保存合同管理信息时失败，Process应返回错误。
			// 构造数据:
			// 使用默认的ProcessCtx。
			// 逻辑链路:
			// 1. 前续步骤均成功。
			// 2. Mock SaveManageInfo 返回一个APIError。
			// 3. Process 方法捕获该错误并返回。

			pc := defaultPc()
			expectedErr := errorsV2.ErrInternalError.WithArgs("save manage info failed")

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*handlerCommon).SaveManageInfo).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("Failure case: updateContractSettlement fails", func() {
			// 场景描述:
			// 在更新合同结算条款时，底层的数据库操作失败，Process应返回错误。
			// 构造数据:
			// 使用默认的ProcessCtx。
			// 逻辑链路:
			// 1. 前续步骤均成功。
			// 2. Mock h.updateContractSettlement 内部调用的 dal.SoftDeleteByContractID 返回错误。
			// 3. Process 方法捕获该错误并返回。

			pc := defaultPc()
			expectedErr := errors.New("update contract settlement failed")

			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update contract settlement failed")
		})
	})
}

func Test_newHandlerInformationUpdate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerInformationUpdate", t, func() {
		mockey.PatchConvey("正常情况: 成功返回 handlerInformationUpdate 实例", func() {
			// 场景描述：
			// 调用 newHandlerInformationUpdate 函数，验证其返回一个非空的、类型正确的处理器实例。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerInformationUpdate()。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerInformationUpdate。

			// 调用目标函数
			handler := newHandlerInformationUpdate()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerInformationUpdate{})
		})
	})
}

func Test_handlerInformationUpdate_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationUpdate_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况-应返回预设的状态码", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回正确的状态码。
			// 构造数据：
			// 创建一个 handlerInformationUpdate 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值等于常量 _const.PreSalesContractSalesOperationCompleteInformation。

			// 准备数据
			h := &handlerInformationUpdate{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationCompleteInformation)
		})
	})
}

func Test_handlerInformationUpdate_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationUpdate_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回预期的操作码。
			// 构造数据：
			// 创建一个 handlerInformationUpdate 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否等于 _const.OperationSubmitDraft。

			// 构造测试目标
			h := &handlerInformationUpdate{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerInformationUpdate_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationUpdate_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部逻辑直接返回 false 和 nil，无任何依赖和判断。
			// 构造数据：
			// - h: handlerInformationUpdate 实例
			// - ctx: context.Background()
			// - pc: auditmodel.ProcessCtx 实例
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回值为 false 和 nil。

			// 准备数据
			h := &handlerInformationUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerInformationUpdate_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationUpdate_PostProcess", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述：
			// 目标函数 PostProcess 当前实现为空，直接返回 nil。本测试用例旨在验证该函数在任何输入下都返回 nil。
			// 构造数据：
			// - 初始化一个 handlerInformationUpdate 实例。
			// - 初始化一个空的 context.Context。
			// - 初始化一个空的 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 调用 PostProcess 方法。
			// 2. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerInformationUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.PostProcess(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

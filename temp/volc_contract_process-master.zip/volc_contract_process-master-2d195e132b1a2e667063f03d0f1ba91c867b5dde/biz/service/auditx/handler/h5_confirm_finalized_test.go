package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"code.byted.org/eps-platform/quote_sdk_go/quote_client"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerConfirmFinalized_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_CurrentOp", t, func() {
		mockey.PatchConvey("should return the correct operation code for finalized", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回正确的操作码。
			// 构造数据：
			// 初始化一个 handlerConfirmFinalized 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于常量 _const.OperationFinalized。

			// 初始化 handler
			h := &handlerConfirmFinalized{}

			// 调用被测方法
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationFinalized)
		})
	})
}

func Test_handlerConfirmFinalized_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_Validate", t, func() {
		h := &handlerConfirmFinalized{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: validateSupply 返回错误", func() {
			// 场景描述：
			// 构造数据：构造一个空的ProcessCtx
			// 逻辑链路：
			// 1. Mock validateSupply 返回一个错误
			// 2. 调用目标函数 Validate
			// 3. 断言返回的错误不为空且包含指定的错误信息
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{},
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(errors.New("validate supply error")).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate supply error")
		})

		mockey.PatchConvey("场景2: 不需要关联报价单（CalcRequireQuote返回false）", func() {
			// 场景描述：
			// 构造数据：构造ProcessCtx，使其CalcRequireQuote返回false，并包含一个有效的BasicInfo用于后续的validateValidityPeriod校验
			// 逻辑链路：
			// 1. Mock validateSupply 返回nil
			// 2. Mock CalcRequireQuote 返回false，跳过报价单校验逻辑
			// 3. 内部调用validateValidityPeriod，由于BasicInfo有效，校验通过返回nil
			// 4. 调用目标函数 Validate
			// 5. 断言返回的错误为nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
						UsefulLifeNum:      1,
						IndefiniteDateFlag: _const.BizNo,
					},
				},
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 需要关联报价单但RelateQuoteNo为空", func() {
			// 场景描述：
			// 构造数据：构造ProcessCtx，使其CalcRequireQuote返回true，但RelateQuoteNo为空字符串
			// 逻辑链路：
			// 1. Mock validateSupply 返回nil
			// 2. Mock CalcRequireQuote 返回true
			// 3. 由于RelateQuoteNo为空，跳过报价单校验逻辑
			// 4. 内部调用validateValidityPeriod，由于BasicInfo有效，校验通过返回nil
			// 5. 调用目标函数 Validate
			// 6. 断言返回的错误为nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
						UsefulLifeNum:      1,
						IndefiniteDateFlag: _const.BizNo,
					},
					RelateQuoteNo: "",
				},
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 关联报价单场景", func() {
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
						IndefiniteDateFlag: _const.BizNo,
					},
					ManageInfo:    &bizmodels.ManageInfo{},
					RelateQuoteNo: "12345",
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			pc.PreContractVO.RelateQuoteScene = _const.RelateQuoteSceneCompleted
			pc.ContractInfo.RelateQuoteScene = _const.RelateQuoteSceneCompleted
			mockey.PatchConvey("场景4.1: GetQuoteInfo调用失败", func() {
				// 场景描述：
				// 构造数据：同场景4
				// 逻辑链路：
				// 1. Mock quotecli.GetQuoteInfo 返回错误
				// 2. 调用目标函数 Validate
				// 3. 断言返回预期的错误信息
				mockey.Mock(quotecli.GetQuoteInfo).Return(nil, errors.New("get quote info error")).Build()
				mockey.Mock(i18nfmt.New).Return(errors.New("查询报价单失败")).Build()

				err := h.Validate(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价单失败")
			})

			mockey.PatchConvey("场景4.2: 报价单不存在", func() {
				// 场景描述：
				// 构造数据：同场景4
				// 逻辑链路：
				// 1. Mock quotecli.GetQuoteInfo 返回nil, nil 表示报价单不存在
				// 2. 调用目标函数 Validate
				// 3. 断言返回预期的错误信息
				mockey.Mock(quotecli.GetQuoteInfo).Return(nil, nil).Build()
				mockey.Mock(i18nfmt.Errorf).Return(errors.New("关联的报价单[12345]不存在")).Build()

				err := h.Validate(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "关联的报价单[12345]不存在")
			})

			mockey.PatchConvey("场景4.3: 有效期类型为指定时间（SPECIFY_TIME）", func() {
				now := time.Now()
				quoteStartTime := now.AddDate(0, 0, -10)
				quoteEndTime := now.AddDate(0, 0, 10)
				quoteInfo := &quote_client.QuoteRespSimpleInfo{
					PriceValidPeriodStartTime: quoteStartTime,
					PriceValidPeriodEndTime:   quoteEndTime,
				}

				mockey.PatchConvey("场景4.3.1: 合同与报价单有效期类型不一致", func() {
					// 场景描述：
					// 构造数据：合同有效期类型为SPECIFY_TIME，报价单有效期类型为SIGN_TIME
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回报价单信息
					// 2. if contractInfo.ManageInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME 条件为true
					// 3. 返回 "合同有效期类别需要与报价单一致" 错误
					pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期类别需要与报价单一致")
				})

				mockey.PatchConvey("场景4.3.2: 合同截止日期为空", func() {
					// 场景描述：
					// 构造数据：合同有效期截止日期（EndTime）为零值
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回
					// 2. if contractEndTime.IsZero() 条件为true
					// 3. 返回 "合同关联了报价单，合同有效期截止日期不能为空" 错误
					pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.PreContractVO.EndTime = time.Time{}
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期截止日期不能为空")
				})

				mockey.PatchConvey("场景4.3.3: 报价单有效期为空", func() {
					// 场景描述：
					// 构造数据：报价单有效期开始时间（PriceValidPeriodStartTime）为零值
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回，但有效期为空
					// 2. if startTime.IsZero() || endTime.IsZero() 条件为true
					// 3. 返回 "合同关联了报价单，指定有效期不允许有效期为空" 错误
					pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.PreContractVO.EndTime = now
					quoteInfo.PriceValidPeriodStartTime = time.Time{}
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "指定有效期不允许有效期为空")
				})

				mockey.PatchConvey("场景4.3.4: 合同有效期不在报价单有效期内（开始时间过早）", func() {
					// 场景描述：
					// 构造数据：合同开始时间早于报价单有效期开始时间
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回
					// 2. if contractVO.BeginTime.Before(startTime) ... 条件为true
					// 3. 返回 "合同有效期不在报价单有效期范围内" 错误
					pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
					pc.PreContractVO.BeginTime = quoteStartTime.AddDate(0, 0, -1)
					pc.PreContractVO.EndTime = quoteEndTime
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()
					mockey.Mock(i18nfmt.Sprintf).Return("合同有效期不在报价单有效期范围内").Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期不在报价单有效期范围内")
				})
			})

			mockey.PatchConvey("场景4.4: 有效期类型为签订生效（SIGN_TIME）", func() {
				quoteInfo := &quote_client.QuoteRespSimpleInfo{}
				pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME

				mockey.PatchConvey("场景4.4.1: 合同与报价单有效期类型不一致", func() {
					// 场景描述：
					// 构造数据：合同有效期类型为SIGN_TIME，但报价单有效期类型不为SIGN_TIME
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回
					// 2. if contractInfo.ManageInfo.UsefulLifeType != _const.CONTRACT_LIFE_TYPE_SIGN_TIME 条件为true
					// 3. 返回 "关联报价单为指定日期生效，合同需与报价单保持一致" 错误
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME // 报价单为指定日期
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()

					err := h.Validate(ctx, pc)

					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "关联报价单为指定日期生效，合同需与报价单保持一致")
				})

				mockey.PatchConvey("场景4.4.2: 合同有效期单位大于报价单（manageLevel < contractLevel）", func() {
					// 场景描述：
					// 构造数据：合同有效期单位为年，报价单为月，级别更高
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回
					// 2. if manageLevel < contractLevel 条件为true
					// 3. 返回 "合同有效期需小于等于报价单有效期" 错误
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_MONTH
					pc.ContractInfo.BasicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()
					mockey.Mock(i18nfmt.Sprintf).Return("合同有效期需小于等于报价单有效期").Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期需小于等于报价单有效期")
				})

				mockey.PatchConvey("场景4.4.3: 单位相同，合同有效期数值大于报价单", func() {
					// 场景描述：
					// 构造数据：单位相同，但合同有效期数值大于报价单
					// 逻辑链路：
					// 1. Mock quotecli.GetQuoteInfo 成功返回
					// 2. else if manageLevel == contractLevel && contractInfo.ManageInfo.UsefulLifeNum < contractInfo.BasicInfo.UsefulLifeNum 条件为true
					// 3. 返回 "合同有效期需小于等于报价单有效期" 错误
					pc.ContractInfo.ManageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
					pc.ContractInfo.ManageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
					pc.ContractInfo.ManageInfo.UsefulLifeNum = 1
					pc.ContractInfo.BasicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
					pc.ContractInfo.BasicInfo.UsefulLifeNum = 2 // 合同有效期 > 报价单有效期
					mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()
					mockey.Mock(i18nfmt.Sprintf).Return("合同有效期需小于等于报价单有效期").Build()

					err := h.Validate(ctx, pc)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期需小于等于报价单有效期")
				})
			})

			mockey.PatchConvey("场景4.5: 不支持的有效期类型", func() {
				// 场景描述：
				// 构造数据：设置一个不支持的有效期类型
				// 逻辑链路：
				// 1. Mock quotecli.GetQuoteInfo 成功返回
				// 2. 进入最后的 else 分支
				// 3. 返回 "暂不支持的有效期类型" 错误
				pc.ContractInfo.BasicInfo.UsefulLifeType = 99
				mockey.Mock(quotecli.GetQuoteInfo).Return(&quote_client.QuoteRespSimpleInfo{}, nil).Build()

				err := h.Validate(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "暂不支持的有效期类型")
			})
		})

		mockey.PatchConvey("场景5: validateValidityPeriod 校验失败", func() {
			// 场景描述：
			// 构造数据：合同有效期超过5年但未填写长有效期原因
			// 逻辑链路：
			// 1. Mock validateSupply 和 CalcRequireQuote 通过，跳过报价单逻辑
			// 2. 内部调用 validateValidityPeriod
			// 3. if basicInfo.UsefulLifeUnit == _const.USEFUL_LIFE_UNIT_YEAR && basicInfo.UsefulLifeNum > 5 分支为true
			// 4. if len(basicInfo.LongLifeReason) == 0 分支为true
			// 5. 返回 "合同有效期超过五年，长有效期原因不允许为空" 错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
						UsefulLifeNum:      6, // > 5
						LongLifeReason:     "",
						IndefiniteDateFlag: _const.BizNo,
					},
					ContractNo: "test-no",
				},
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期超过五年，长有效期原因不允许为空")
		})

		mockey.PatchConvey("场景6: 所有校验成功", func() {
			// 场景描述：
			// 构造数据：所有校验条件均满足
			// 逻辑链路：
			// 1. Mock validateSupply 返回nil
			// 2. Mock CalcRequireQuote 返回true
			// 3. Mock quotecli.GetQuoteInfo 成功返回有效的报价单信息
			// 4. 所有有效期校验通过
			// 5. 最后的 validateValidityPeriod 校验也通过
			// 6. 最终返回 nil
			now := time.Now()
			quoteStartTime := now.AddDate(0, 0, -10)
			quoteEndTime := now.AddDate(0, 0, 10)

			contractStartTime := quoteStartTime.AddDate(0, 0, 1) // 在范围内
			contractEndTime := quoteEndTime.AddDate(0, 0, -1)    // 在范围内

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
						IndefiniteDateFlag: _const.BizNo,
						BeginTime:          contractStartTime.Format(utils.DateFormatTpl),
						EndTime:            contractEndTime.Format(utils.DateFormatTpl),
					},
					ManageInfo: &bizmodels.ManageInfo{
						UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
					},
					RelateQuoteNo: "12345",
				},
				PreContractVO: &model.ContractMetaDB{
					BeginTime: contractStartTime,
					EndTime:   contractEndTime,
				},
			}
			quoteInfo := &quote_client.QuoteRespSimpleInfo{
				PriceValidPeriodStartTime: quoteStartTime,
				PriceValidPeriodEndTime:   quoteEndTime,
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("场景7: 校验返券规则有效期与合同有效期校验失败", func() {
			// 场景描述：
			// 构造数据：所有校验条件均满足
			// 逻辑链路：
			// 1. Mock validateSupply 返回nil
			// 2. Mock CalcRequireQuote 返回true
			// 3. Mock quotecli.GetQuoteInfo 成功返回有效的报价单信息
			// 4. 所有有效期校验通过
			// 5. 最后的 validateValidityPeriod 校验也通过
			// 6. 最终返回 nil
			now := time.Now()
			quoteStartTime := now.AddDate(0, 0, -10)
			quoteEndTime := now.AddDate(0, 0, 10)

			contractStartTime := quoteStartTime.AddDate(0, 0, 1) // 在范围内
			contractEndTime := quoteEndTime.AddDate(0, 0, -1)    // 在范围内

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
						IndefiniteDateFlag: _const.BizNo,
						BeginTime:          contractStartTime.Format(utils.DateFormatTpl),
						EndTime:            contractEndTime.Format(utils.DateFormatTpl),
					},
					ManageInfo: &bizmodels.ManageInfo{
						UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
					},
					RelateQuoteNo: "12345",
				},
				PreContractVO: &model.ContractMetaDB{
					BeginTime: contractStartTime,
					EndTime:   contractEndTime,
				},
			}
			quoteInfo := &quote_client.QuoteRespSimpleInfo{
				PriceValidPeriodStartTime: quoteStartTime,
				PriceValidPeriodEndTime:   quoteEndTime,
			}
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(quoteInfo, nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(errors.New("校验返券规则有效期与合同有效期校验失败")).Build()
			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "校验返券规则有效期与合同有效期校验失败")
		})
	})
}

func Test_handlerConfirmFinalized_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 这是一个简单场景，目标函数直接返回固定的 true 和 nil。
			// 构造数据：
			// - handlerConfirmFinalized 实例
			// - background context
			// -空的 ProcessCtx
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 验证返回值为 true 和 nil。
			h := &handlerConfirmFinalized{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerConfirmFinalized_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_Process", t, func() {
		// Arrange
		ctx := context.Background()
		h := &handlerConfirmFinalized{}

		mockey.PatchConvey("success case: updateContractData returns no error", func() {
			// 场景描述:
			// 内部调用 h.updateContractData 方法成功，没有返回错误。
			// 构造数据:
			// - pc.Extra 初始有一个非空值
			// 逻辑链路:
			// 1. Mock h.updateContractData 方法返回 nil。
			// 2. 调用目标函数 h.Process。
			// 3. 目标函数将 pc.Extra 设置为空字符串。
			// 4. 目标函数返回 nil。
			// 5. 断言返回的错误为 nil，并且 pc.Extra 被清空。
			pc := &auditmodel.ProcessCtx{
				Extra: "initial_extra_value",
			}
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.Extra, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("failure case: updateContractData returns an error", func() {
			// 场景描述:
			// 内部调用 h.updateContractData 方法失败，返回一个错误。
			// 构造数据:
			// - pc.Extra 初始有一个非空值
			// 逻辑链路:
			// 1. Mock h.updateContractData 方法返回一个预设的 error。
			// 2. 调用目标函数 h.Process。
			// 3. 目标函数应立即返回这个错误，不执行后续逻辑。
			// 4. pc.Extra 的值应保持不变。
			// 5. 断言返回的错误与预设错误一致，并且 pc.Extra 未被修改。
			pc := &auditmodel.ProcessCtx{
				Extra: "initial_extra_value",
			}
			expectedErr := errors.New("mock updateContractData error")
			mockey.Mock((*handlerCommon).updateContractData).Return(expectedErr).Build()

			// Act
			err := h.Process(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(pc.Extra, convey.ShouldEqual, "initial_extra_value")
		})
	})
}

func Test_handlerConfirmFinalized_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractCustomerConfirm", func() {
			// 场景描述：
			// 验证handlerConfirmFinalized的CurrentStatus方法是否正确返回预设的常量状态值。
			// 构造数据：
			// 初始化一个handlerConfirmFinalized实例。
			// 逻辑链路：
			// 1. 创建handlerConfirmFinalized处理器。
			// 2. 调用其CurrentStatus方法。
			// 3. 断言返回值等于_const.PreSalesContractCustomerConfirm。

			// 初始化处理器
			h := &handlerConfirmFinalized{}

			// 调用目标方法
			status := h.CurrentStatus()

			// 断言结果
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractCustomerConfirm)
		})
	})
}

func Test_handlerConfirmFinalized_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmFinalized_PostProcess", t, func() {
		// 构造一个 handler 实例
		h := &handlerConfirmFinalized{}
		ctx := context.Background()
		// 构造 ProcessCtx
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:     "CONTRACT-NO-123",
				ContractName:   "Test Contract",
				OtherPartyName: "Test Customer",
				Operator:       "operator.id",
				Reviewers: bizmodels.PreContractReviewerList{
					&bizmodels.PreContractReviewer{
						Reviewer:       "salesop@example.com",
						ReviewerType:   _const.ReviewerTypeSalesOperation,
						ContractStatus: _const.PreSalesContractSalesOperationCompleteInformation,
						ReviewerSource: 0,
					},
					&bizmodels.PreContractReviewer{
						Reviewer:     "salesperson@example.com",
						ReviewerType: _const.ReviewerTypeSalesperson,
					},
				},
			},
			StatusChangedValue: _const.PreSalesContractSalesOperationCompleteInformation,
		}

		mockey.PatchConvey("happy path: all dependencies succeed", func() {
			// 场景描述：
			// 构造数据：一个包含销售运营和销售人员的合同上下文。
			// 逻辑链路：
			// 1. Mock getReviewer... 系列方法，返回预设的审批人列表。
			// 2. Mock 飞书卡片消息构建过程中依赖的外部函数，如 I18nFormat, Sprintf, GenEditURL 等。
			// 3. Mock 飞书消息发送函数 BatchSendMessageToEmailIgnore，使其不产生实际副作用。
			// 4. Mock C360 通知函数 notifyC360，使其返回成功 (nil)。
			// 5. 调用 PostProcess 函数。
			// 6. 断言函数返回 nil，表示处理成功。

			// Mock a series of dependent functions
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"salesop@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"salesperson@example.com"}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v // Passthrough mock
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				// Replicate original behavior which calls I18nFormat
				format = multienv.I18nFormat(ctx, format)
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()

			mockey.Mock(larkc.GenEditURL).Return("http://fake.url/edit/CONTRACT-NO-123").Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			// Call the target function
			err := h.PostProcess(ctx, pc)

			// Assertions
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("when notifyC360 fails, should still return nil", func() {
			// 场景描述：
			// 构造数据：与 happy path 相同。
			// 逻辑链路：
			// 1. 飞书消息发送相关的 mock 与 happy path 相同。
			// 2. Mock C360 通知函数 notifyC360，使其返回一个错误。
			// 3. 调用 PostProcess 函数。
			// 4. 由于 PostProcess 内部忽略了 notifyC360 的错误，断言函数最终返回 nil。

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"salesop@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"salesperson@example.com"}).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				format = multienv.I18nFormat(ctx, format)
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()

			mockey.Mock(larkc.GenEditURL).Return("http://fake.url/edit/CONTRACT-NO-123").Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Mock notifyC360 to return an error
			mockey.Mock((*handlerCommon).notifyC360).Return(errors.New("c360 notification failed")).Build()

			// Call the target function
			err := h.PostProcess(ctx, pc)

			// Assertions
			// The error from notifyC360 is ignored, so the function should return nil.
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerConfirmFinalized_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerConfirmFinalized", t, func() {
		mockey.PatchConvey("正常返回", func() {
			// 场景描述：
			// 这是一个构造函数，主要测试其是否能成功创建一个非空的实例。
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerConfirmFinalized() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerConfirmFinalized。

			// 调用
			handler := newHandlerConfirmFinalized()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerConfirmFinalized{})
		})
	})
}

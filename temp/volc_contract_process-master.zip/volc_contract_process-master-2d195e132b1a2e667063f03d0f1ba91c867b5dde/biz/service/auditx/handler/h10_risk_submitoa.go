package handler

import (
	"context"
	"encoding/json"
	"time"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/proxy/quotecli"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
)

func newHandlerRiskSubmitOA() StatusOpHandler {
	return &handlerRiskSubmitOA{}
}

// 销售运营完善信息(7) --- 提交OA(13) --> 提交OA(8)
type handlerRiskSubmitOA struct {
	handlerCommon
}

func (h *handlerRiskSubmitOA) CurrentStatus() int {
	return _const.PreSalesContractRiskReview
}

func (h *handlerRiskSubmitOA) CurrentOp() int {
	return _const.OperationSubmitOA
}

func (h *handlerRiskSubmitOA) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}

	// 绑定报价单场景 校验合同有效期与报价单有效期
	// 校验账号ID CRM侧在“定稿”时校验必填，合同侧在“销售运营完善信息”时校验必填。
	contractInfo := pc.ContractInfo
	contractVO := pc.PreContractVO

	// 校验是否项目制必填 & 且要求与报价单保持一致
	if len(contractInfo.BasicInfo.WhetherProject) == 0 {
		return errorsV2.ErrMissingParam.WithArgs("WhetherProject")
	}

	// 关联报价单场景
	if contractInfo.NeedRelateQuoteNo() {
		if contractInfo.RelateQuoteNo == "" {
			return errorsV2.ErrQuoteCommon.WithArgs("当前合同必须关联报价单")
		}
		for _, otherParty := range contractInfo.TradePartyInfo.OtherParty {
			// 仅校验主签约主体账号
			if otherParty.IsDeputyParty() {
				continue
			}
			if len(otherParty.AccountID) == 0 {
				return i18nfmt.New(ctx, "合同账号ID缺失")
			}
		}
		info, err := quotecli.GetQuoteInfo(ctx, contractInfo.RelateQuoteNo)
		if err != nil {
			return i18nfmt.New(ctx, "查询报价单失败")
		}
		if info == nil {
			return i18nfmt.Errorf(ctx, "关联的报价单[%s]不存在", contractInfo.RelateQuoteNo)
		}
		// 指定合同有效期
		if err := validateUsefulLifeType(ctx, pc.PreContractVO, info, contractInfo.BasicInfo, contractInfo.ManageInfo); err != nil {
			logs.CtxError(ctx, "校验合同有效期类型信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
			return err
		}
		// 检验账号分组信息
		if err := validateAccountAssociationInfo(ctx, contractInfo.ManageInfo, contractInfo.TradePartyInfo); err != nil {
			logs.CtxError(ctx, "校验账号ID分组信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
			return err
		}
		if contractInfo.BasicInfo.WhetherProject != contractInfo.ManageInfo.WhetherProject {
			return errorsV2.ErrCommon.WithArgs("合同是否项目制标识需与报价单保持一致")
		}
	}
	if err := contractInfo.BasicInfo.ValidateContractPeriod(ctx, _const.SalesContractUnSubmit); err != nil {
		logs.CtxError(ctx, "校验合同有效期类型信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateTradePartyInfo(ctx, contractInfo.BasicInfo, contractInfo.TradePartyInfo); err != nil {
		logs.CtxError(ctx, "校验交易对方信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateRiskClauseRole(ctx, pc.GetTx(), contractInfo.ContractNo); err != nil {
		logs.CtxError(ctx, "校验风险条款条目信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateProjectInfo(ctx, pc.ContractInfo); err != nil {
		logs.CtxError(ctx, "校验项目信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := validateTermChangeDetail(ctx, pc.GetTx(), pc.PreContractVO); err != nil {
		logs.CtxError(ctx, "校验条款变更详情失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	if err := contractInfo.ManageInfo.ValidateExternalCommodity(ctx); err != nil {
		logs.CtxError(ctx, "校验外部商品信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}

	if err := validateAccountIdRequired(ctx, contractInfo); err != nil {
		logs.CtxError(ctx, "账号ID必填校验失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}

	if (contractVO.InOutType == _const.BizInOutTypeIn || contractVO.InOutType == _const.BizInOutTypeInAndOut) &&
		contractVO.BizSource != _const.BizSourceQuote {
		// 自采平台，无结算条款记录行
		if contractInfo.Initiator != _const.InitiatorSelfPurchase {
			settlementLines, err := dal.NewContractSettlementDao().ListContractSettlementByContractID(ctx, pc.GetTx(), int(contractVO.Id))
			if err != nil {
				return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListContractSettlementByContractID_Fail:%v", err))
			}
			if len(settlementLines) == 0 {
				return i18nfmt.New(ctx, "当合同收支类型为“收入类” / “既收又支”时，结算条款模块必填")
			}
		}
	}
	// 若此时合同倒签，页面无法填充倒签原因，需补齐倒签信息
	if err := h.IsReverseContract(ctx, pc.PreContractVO); err != nil {
		pc.ContractInfo.ReverseSignInfo = &bizmodels.ReverseSignInfo{
			ReverseSignCode:   "RS008",
			ReverseSignReason: "合同签署的提前计划/安排不足",
		}
		reverseSignInfo, _ := json.Marshal(pc.ContractInfo.ReverseSignInfo)
		pc.PreContractVO.ReverseSignInfo = string(reverseSignInfo)
	}
	return nil
}

func (h *handlerRiskSubmitOA) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	pc.PreContractVO.SubmitTime = time.Now()
	// pc.ContractInfo.SubmitTime = time.Now()
	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		logs.CtxError(ctx, "UpdateContractDataFail, err:%s", err.Error())
		return errorsV2.ErrCommon.WithArgs(err.Error())
	}
	// 风险条款审核节点审核通过时，默认未传入文件管理系统token信息，默认清空
	pc.Extra = ""
	return h.SendSubmitOaMsg(ctx, pc)
}

func (h *handlerRiskSubmitOA) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerRiskSubmitOA) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 通知 C360
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeRiskSubmitOA, pc)
	return nil
}

package handler

import (
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"strconv"
	"testing"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	quoteservice "volc_contract_process/biz/service/support/quote"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/feishucli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/oacli"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/proxy/riskenginecli"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerDraftSubmitPreContract_resetPreContractNo_BitsUTGen(t *testing.T) {
	// --- Mock DAO Definitions ---
	type MockContractMetaDao struct{ dal.ContractMetaDao }
	type MockPreContractManagerDao struct{ dal.PreContractManagerDao }
	type MockContractOperationRecordDao struct{ dal.ContractOperationRecordDao }
	type MockPreContractReviewerDao struct{ dal.PreContractReviewerDao }

	mockey.PatchConvey("Test resetPreContractNo", t, func() {
		h := &handlerDraftSubmitPreContract{}
		ctx := context.Background()
		tx := &gorm.DB{}

		// --- Mock DAO Initialization ---
		mockey.Mock(dal.NewContractMetaDao).To(func() dal.ContractMetaDao { return &MockContractMetaDao{} }).Build()
		mockey.Mock(dal.NewPreContractManagerDao).To(func() dal.PreContractManagerDao { return &MockPreContractManagerDao{} }).Build()
		mockey.Mock(dal.NewContractOperationRecordDao).To(func() dal.ContractOperationRecordDao { return &MockContractOperationRecordDao{} }).Build()
		mockey.Mock(dal.NewPreContractReviewerDao).To(func() dal.PreContractReviewerDao { return &MockPreContractReviewerDao{} }).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()

		convey.Convey("Success case (New Supply Scene)", func() {
			// --- Test Data Setup ---
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "OLD-NO-123",
					MainContractNo: "OLD-MAIN-NO",
					SupplyScene:    _const.SupplySceneNew,
				},
				PreContractVO: &model.ContractMetaDB{
					ContractNo:     "OLD-NO-123",
					MainContractNo: "OLD-MAIN-NO",
				},
			}
			oaContractInfo := &oacli.InitSalesContractData{
				ContractNumber: "NEW-NO-456",
				ContractId:     "OA-ID-1",
				CheckCode:      "CHECK-CODE-1",
				RequestId:      "REQ-ID-1",
			}

			// --- Mock DAO Methods ---
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(nil).Build()
			mockey.Mock((*MockPreContractManagerDao).ChangePreContractNo).Return(nil).Build()
			mockey.Mock((*MockContractOperationRecordDao).UpdateNo).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).UpdateNo).Return(nil).Build()

			// --- Execute ---
			err := h.resetPreContractNo(ctx, pc, oaContractInfo)

			// --- Assertions ---
			convey.So(err, convey.ShouldBeNil)
			// Assert all fields in context are updated
			convey.So(pc.PreContractNo, convey.ShouldEqual, "NEW-NO-456")
			convey.So(pc.ContractInfo.ContractNo, convey.ShouldEqual, "NEW-NO-456")
			convey.So(pc.ContractInfo.ContractId, convey.ShouldEqual, "OA-ID-1")
			convey.So(pc.ContractInfo.CheckCode, convey.ShouldEqual, "CHECK-CODE-1")
			convey.So(pc.ContractInfo.RequestId, convey.ShouldEqual, "OA-ID-1") // Note: updated with ContractId
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "NEW-NO-456")
			convey.So(pc.PreContractVO.ContractNo, convey.ShouldEqual, "NEW-NO-456")
			convey.So(pc.PreContractVO.ContractId, convey.ShouldEqual, "OA-ID-1")
			convey.So(pc.PreContractVO.CheckCode, convey.ShouldEqual, "CHECK-CODE-1")
			convey.So(pc.PreContractVO.RequestId, convey.ShouldEqual, "OA-ID-1") // Note: updated with ContractId
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "NEW-NO-456")
		})

		convey.Convey("Success case (Not New Supply Scene)", func() {
			// --- Test Data Setup ---
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "OLD-NO-123",
					MainContractNo: "SHOULD-NOT-CHANGE",
					SupplyScene:    _const.SupplySceneModification, // Not SupplySceneNew
				},
				PreContractVO: &model.ContractMetaDB{
					ContractNo:     "OLD-NO-123",
					MainContractNo: "SHOULD-NOT-CHANGE",
				},
			}
			oaContractInfo := &oacli.InitSalesContractData{
				ContractNumber: "NEW-NO-456",
				ContractId:     "OA-ID-1",
				CheckCode:      "CHECK-CODE-1",
				RequestId:      "REQ-ID-1",
			}
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(nil).Build()
			mockey.Mock((*MockPreContractManagerDao).ChangePreContractNo).Return(nil).Build()
			mockey.Mock((*MockContractOperationRecordDao).UpdateNo).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).UpdateNo).Return(nil).Build()

			err := h.resetPreContractNo(ctx, pc, oaContractInfo)

			convey.So(err, convey.ShouldBeNil)
			// Assert MainContractNo is NOT updated
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "SHOULD-NOT-CHANGE")
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "SHOULD-NOT-CHANGE")
		})

		// --- Failure Cases ---
		basePc := &auditmodel.ProcessCtx{
			ContractInfo:  &model.ContractMeta{ContractNo: "OLD-NO-123"},
			PreContractVO: &model.ContractMetaDB{ContractNo: "OLD-NO-123"},
		}
		baseOaInfo := &oacli.InitSalesContractData{ContractNumber: "NEW-NO-456"}

		convey.Convey("Failure case: ContractMetaDao fails", func() {
			expectedErr := errors.New("db error on meta reset")
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(expectedErr).Build()

			err := h.resetPreContractNo(ctx, basePc, baseOaInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		convey.Convey("Failure case: PreContractManagerDao fails", func() {
			expectedErr := errors.New("db error on manager change")
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(nil).Build()
			mockey.Mock((*MockPreContractManagerDao).ChangePreContractNo).Return(expectedErr).Build()

			err := h.resetPreContractNo(ctx, basePc, baseOaInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		convey.Convey("Failure case: ContractOperationRecordDao fails", func() {
			expectedErr := errors.New("db error on operation record update")
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(nil).Build()
			mockey.Mock((*MockPreContractManagerDao).ChangePreContractNo).Return(nil).Build()
			mockey.Mock((*MockContractOperationRecordDao).UpdateNo).Return(expectedErr).Build()

			err := h.resetPreContractNo(ctx, basePc, baseOaInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		convey.Convey("Failure case: PreContractReviewerDao fails", func() {
			expectedErr := errors.New("db error on reviewer update")
			mockey.Mock((*MockContractMetaDao).ResetContractNo).Return(nil).Build()
			mockey.Mock((*MockPreContractManagerDao).ChangePreContractNo).Return(nil).Build()
			mockey.Mock((*MockContractOperationRecordDao).UpdateNo).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).UpdateNo).Return(expectedErr).Build()

			err := h.resetPreContractNo(ctx, basePc, baseOaInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_handlerDraftSubmitPreContract_Process(t *testing.T) {
	h := &handlerDraftSubmitPreContract{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerDraftSubmitPreContract_Process", t, func() {
		// 公共 mock 数据
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: "DRAFT-12345",
				Operator:   "12345",
				BasicInfo: &bizmodels.BasicInfo{
					DepartmentId: "dep-1",
				},
			},
			PreContractVO: &model.ContractMetaDB{
				ContractNo: "DRAFT-12345",
				BasicInfo:  `{"DepartmentId":"dep-1"}`,
			},
		}
		salesOpEmail := "salesop@example.com"
		employee := &peopleclient.Employee{
			ID:             54321,
			EmployeeNumber: 98765,
		}
		user := &larkc.User{UserID: "user-id-123"}

		mockey.PatchConvey("成功场景 - 需要生成合同号", func() {
			// 场景描述:
			// 当合同号不是以 'CT' 开头时，成功生成新的 OA 合同号，并完成后续所有流程。
			// 数据构造:
			// - pc.ContractInfo.ContractNo = "DRAFT-12345"
			// 逻辑链路:
			// 1. 调用 genOAContractID 生成新合同号.
			// 2. 调用 resetPreContractNo 更新数据库中的合同号.
			// 3. 调用 getAndValidateReviewerMappings 获取销售运营人员.
			// 4. 调用 larkc 获取员工信息.
			// 5. 更新 pc 上下文中的创建人信息.
			// 6. 调用 SubmitComplianceCheck, updateContractData, updateContractReviewers 完成后续流程.
			// 7. 函数成功返回 nil.

			pc.ContractInfo.ContractNo = "DRAFT-12345"
			pc.PreContractVO.ContractNo = "DRAFT-12345"

			newContractNo := "CT-2024-001"
			oaContractInfo := &oacli.InitSalesContractData{
				ContractNumber: newContractNo,
			}

			mockey.Mock((*handlerDraftSubmitPreContract).genOAContractID).Return(oaContractInfo, nil).Build()
			mockey.Mock((*handlerDraftSubmitPreContract).resetPreContractNo).Return(nil).Build()
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(user, nil).Build()
			mockey.Mock(mockey.GetMethod(&h.handlerCommon, "SubmitComplianceCheck")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(&h.handlerCommon, "updateContractData")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(&h.handlerCommon, "updateContractReviewers")).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			// resetPreContractNo mock中已经包含了对pc的修改, 这里断言最终结果
			convey.So(pc.ContractInfo.Creator, convey.ShouldEqual, strconv.Itoa(employee.ID))
			convey.So(pc.ContractInfo.CreatorNew, convey.ShouldEqual, strconv.Itoa(employee.EmployeeNumber))
			convey.So(pc.ContractInfo.BasicInfo.CreatorUserId, convey.ShouldEqual, user.UserID)
			convey.So(pc.PreContractVO.Creator, convey.ShouldEqual, strconv.Itoa(employee.ID))

			// 断言 BasicInfo 更新
			var updatedBasicInfo bizmodels.BasicInfo
			err = json.Unmarshal([]byte(pc.PreContractVO.BasicInfo), &updatedBasicInfo)
			convey.So(err, convey.ShouldBeNil)
			convey.So(updatedBasicInfo.CreatorUserId, convey.ShouldEqual, user.UserID)
			convey.So(updatedBasicInfo.CreatorNew, convey.ShouldEqual, strconv.Itoa(employee.EmployeeNumber))
		})

		mockey.PatchConvey("成功场景 - 无需生成合同号", func() {
			// 场景描述:
			// 当合同号已经是 'CT' 开头时，跳过生成合同号的步骤，并成功完成后续所有流程。
			// 数据构造:
			// - pc.ContractInfo.ContractNo = "CT-12345"
			// 逻辑链路:
			// 1. 跳过 genOAContractID 和 resetPreContractNo.
			// 2. 成功执行后续所有步骤。
			// 3. 函数成功返回 nil.
			pc.ContractInfo.ContractNo = "CT-12345"
			pc.PreContractVO.ContractNo = "CT-12345"

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(user, nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractReviewers).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ContractInfo.Creator, convey.ShouldEqual, strconv.Itoa(employee.ID))
			convey.So(pc.ContractInfo.CreatorNew, convey.ShouldEqual, strconv.Itoa(employee.EmployeeNumber))
		})

		mockey.PatchConvey("失败场景 - 生成合同号失败", func() {
			// 场景描述:
			// 当合同号需要生成，但 genOAContractID 调用失败时，函数应立即返回错误。
			// 逻辑链路:
			// 1. genOAContractID 返回错误。
			// 2. Process 函数中断并返回该错误。
			mockErr := errors.New("genOAContractIDFail")
			mockey.Mock((*handlerDraftSubmitPreContract).genOAContractID).Return(nil, mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 重置合同号失败", func() {
			// 场景描述:
			// 当生成合同号成功，但 resetPreContractNo 调用失败时，函数应返回错误。
			// 逻辑链路:
			// 1. genOAContractID 成功返回。
			// 2. resetPreContractNo 返回错误。
			// 3. Process 函数中断并返回该错误。
			oaContractInfo := &oacli.InitSalesContractData{ContractNumber: "CT-2024-001"}
			mockErr := errors.New("resetPreContractNoFail")

			mockey.Mock((*handlerDraftSubmitPreContract).genOAContractID).Return(oaContractInfo, nil).Build()
			mockey.Mock((*handlerDraftSubmitPreContract).resetPreContractNo).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 获取销售运营人员失败", func() {
			// 场景描述:
			// 获取销售运营人员信息失败，函数应返回错误。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 返回错误。
			// 2. Process 函数中断并返回该错误。
			pc.ContractInfo.ContractNo = "CT-12345"
			mockErr := errors.New("reviewer not defined")
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(nil, mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 销售运营人员未定义(返回列表为空) case 1: len(reviewerMappings) == 0", func() {
			// 场景描述:
			// getAndValidateReviewerMappings 返回的 map 中没有销售运营角色，或该角色的邮箱列表为空。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 返回一个空的 map 或空的 email 列表。
			// 2. Process 函数判断后返回 "销售运营人员未定义" 错误。
			pc.ContractInfo.ContractNo = "CT-12345"

			// case 1: len(reviewerMappings) == 0
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{}, nil).Build()
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "销售运营人员未定义")
		})

		mockey.PatchConvey("失败场景 - 销售运营人员未定义(返回列表为空) case 2: len(salesOpEmails) == 0", func() {
			// 场景描述:
			// getAndValidateReviewerMappings 返回的 map 中没有销售运营角色，或该角色的邮箱列表为空。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 返回一个空的 map 或空的 email 列表。
			// 2. Process 函数判断后返回 "销售运营人员未定义" 错误。
			pc.ContractInfo.ContractNo = "CT-12345"

			// case 2: len(salesOpEmails) == 0
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): "",
			}, nil).Build()
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "销售运营人员未定义")
		})

		mockey.PatchConvey("失败场景 - 查询 people 数据失败 case 1: BatchGetEmployees returns error", func() {
			// 场景描述:
			// 调用 larkc 获取员工信息时失败。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 成功。
			// 2. BatchGetEmployees 或 GetUserIdByEmail 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()

			// case 1: BatchGetEmployees returns error
			mockErr := errors.New("batch get employees fail")
			mockey.Mock(larkc.BatchGetEmployees).Return(nil, mockErr).Build()
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 查询 people 数据失败 case 2: BatchGetEmployees returns empty map", func() {
			// 场景描述:
			// 调用 larkc 获取员工信息时失败。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 成功。
			// 2. BatchGetEmployees 或 GetUserIdByEmail 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()

			// case 2: BatchGetEmployees returns empty map
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{}, nil).Build()
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询people数据失败")
		})

		mockey.PatchConvey("失败场景 - 查询 people 数据失败 case 3: GetUserIdByEmail returns error", func() {
			// 场景描述:
			// 调用 larkc 获取员工信息时失败。
			// 逻辑链路:
			// 1. getAndValidateReviewerMappings 成功。
			// 2. BatchGetEmployees 或 GetUserIdByEmail 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()

			// case 3: GetUserIdByEmail returns error
			mockErr := errors.New("batch get employees fail")
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(nil, mockErr).Build()
			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 提交合规审查失败", func() {
			// 场景描述:
			// 在提交合规审查步骤失败。
			// 逻辑链路:
			// 1. 前置步骤均成功。
			// 2. SubmitComplianceCheck 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"
			mockErr := errors.New("submit compliance check fail")

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(user, nil).Build()
			mockey.Mock(mockey.GetMethod(&h.handlerCommon, "SubmitComplianceCheck")).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 更新合同数据失败", func() {
			// 场景描述:
			// 在更新合同数据步骤失败。
			// 逻辑链路:
			// 1. 前置步骤均成功。
			// 2. updateContractData 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"
			mockErr := errors.New("update contract data fail")

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(user, nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("失败场景 - 更新合同审批人失败", func() {
			// 场景描述:
			// 在更新合同审批人步骤失败。
			// 逻辑链路:
			// 1. 前置步骤均成功。
			// 2. updateContractReviewers 返回错误。
			// 3. Process 函数中断并返回错误。
			pc.ContractInfo.ContractNo = "CT-12345"
			mockErr := errors.New("update contract reviewers fail")

			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(map[string]string{
				_const.GetReviewerRoleName(_const.ReviewerRoleSalesOp): salesOpEmail,
			}, nil).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{salesOpEmail: employee}, nil).Build()
			mockey.Mock(larkc.GetUserIdByEmail).Return(user, nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractReviewers).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

	})
}

func Test_handlerDraftSubmitPreContract_PostProcess_BitsUTGen(t *testing.T) {
	type MockQuoteService struct {
		quoteservice.Service
	}

	mockey.PatchConvey("Test PostProcess for handlerDraftSubmitPreContract", t, func() {
		ctx := context.Background()
		h := &handlerDraftSubmitPreContract{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:     "CONTRACT-001",
				ContractName:   "Test Contract",
				OtherPartyName: "Test Party",
				RelateQuoteNo:  "QUOTE-001",
				Operator:       "operator-id",
				BasicInfo:      &bizmodels.BasicInfo{},
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "reviewer@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
			},
			StatusChangedValue: _const.PreSalesContractSalesOperationReview,
			Comment:            &bizmodels.RichTextInfo{},
		}

		mockey.PatchConvey("Success Case", func() {
			// 场景描述：
			// 构造数据：构造一个完整的ProcessCtx，使所有逻辑分支都被执行。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 执行成功，返回 nil。
			// 3. notifyC360 执行成功，返回 nil。
			// 4. PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockey.Mock(quotecli.BindQuoteContract).Return().Build()

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("handleQuoteChangeWhenSubmit logs an error but returns nil", func() {
			// 场景描述：
			// 构造数据：与成功案例类似。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 执行时，其依赖的 redis 操作失败，但是该错误被忽略，函数返回 nil。
			// 3. PostProcess 继续执行 notifyC360。
			// 4. PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(&bizmodels.QuoteChangeInfo{
				RelateQuoteNo: "OLD-QUOTE-001",
			}, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(errors.New("redis error")).Build()
			mockey.Mock(quotecli.BindQuoteContract).Return().Build()

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("notifyC360 fails but PostProcess returns nil", func() {
			// 场景描述：
			// 构造数据：与成功案例类似。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 执行成功。
			// 3. notifyC360 执行时，其依赖的 MQ 发送失败。
			// 4. PostProcess 内部会记录错误日志并发送告警，但由于该错误被忽略（`_ = ...`），PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockey.Mock(quotecli.BindQuoteContract).Return().Build()

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(errors.New("mq error")).Build()
			mockey.Mock(utils.ToJSON).Return("{\"key\":\"value\"}").Build()
			mockey.Mock(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {}).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Skips quote and C360 logic", func() {
			// 场景描述：
			// 构造数据：构造 ProcessCtx 使得 CalcRequireQuote 返回 false, IsBytePlus 返回 true。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 因为 CalcRequireQuote 返回 false 而提前返回 nil。
			// 3. notifyC360 因为 IsBytePlus 返回 true 而提前返回 nil。
			// 4. PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("handleQuoteChangeWhenSubmit Redis Get error but still success", func() {
			// 场景描述：
			// 构造数据：与成功案例类似。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 执行时，GetQuoteChangeInfo 返回错误，但不影响后续逻辑，最终成功。
			// 3. PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, errors.New("get redis error")).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockey.Mock(quotecli.BindQuoteContract).Return().Build()

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			pc.ContractInfo.Operator = ""
			pc.OperationState = _const.OperationSendBack
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return(nil, nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("notifyC360 get empty operator email", func() {
			// 场景描述：
			// 构造数据：与成功案例类似，但 GetEmployeeByID 返回空。
			// 逻辑链路：
			// 1. 发送飞书消息成功。
			// 2. handleQuoteChangeWhenSubmit 成功。
			// 3. notifyC360 执行时，GetEmployeeByID 返回空，不影响后续逻辑。
			// 4. PostProcess 最终返回 nil。
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockey.Mock(quotecli.BindQuoteContract).Return().Build()

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return(nil, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()
			pc.OperationState = _const.OperationSendBack
			pc.Comment.RichtextPlainText = "return reason"

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerDraftSubmitPreContract_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftSubmitPreContract_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：初始化一个handlerDraftSubmitPreContract实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于预定义的常量 _const.OperationSubmitPreContract。

			// 数据准备
			h := &handlerDraftSubmitPreContract{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitPreContract)
		})
	})
}

func Test_handlerDraftSubmitPreContract_genOAContractID_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test genOAContractID", t, func() {
		h := &handlerDraftSubmitPreContract{}
		ctx := context.Background()

		convey.Convey("Success case", func() {
			// Scene Description: Successfully generates a contract number.
			mockey.Mock(feishucli.GenerateContractNo).Return("Feishu-CT-001", nil).Build()

			resp, err := h.genOAContractID(ctx)

			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.ContractNumber, convey.ShouldEqual, "Feishu-CT-001")
		})

		convey.Convey("Failure case", func() {
			// Scene Description: Fails to generate a contract number from feishucli.
			expectedErr := errors.New("feishu error")
			mockey.Mock(feishucli.GenerateContractNo).Return("", expectedErr).Build()

			resp, err := h.genOAContractID(ctx)

			convey.So(resp, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "OAInitSalesContractFail")
		})
	})
}

func Test_handlerDraftSubmitPreContract_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftSubmitPreContract_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 该函数实现非常简单，直接返回 true 和 nil，没有任何逻辑判断。
			// 构造数据：
			// - h: 一个空的 handlerDraftSubmitPreContract 实例。
			// - ctx: 一个空的 context.Background()。
			// - pc: 一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回值为 true 和 nil。

			h := &handlerDraftSubmitPreContract{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerDraftSubmitPreContract_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftSubmitPreContract_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractDraft", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否正确返回预期的草稿状态常量。
			// 构造数据：
			// 无特殊数据构造。
			// 逻辑链路：
			// 1. 创建 handlerDraftSubmitPreContract 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值等于 _const.PreSalesContractDraft。

			// 准备数据
			h := &handlerDraftSubmitPreContract{}

			// 调用方法
			status := h.CurrentStatus()

			// 断言结果
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractDraft)
		})
	})
}

func Test_newHandlerDraftSubmitPreContract_BitsUTGen(t *testing.T) {
	// MockContractMetaDao is a mock implementation for the dal.ContractMetaDao interface.
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}

	mockey.PatchConvey("Test_newHandlerDraftSubmitPreContract", t, func() {
		convey.Convey("should return a new handler with dao initialized", func() {
			// 场景描述：
			// 测试 newHandlerDraftSubmitPreContract 函数是否能成功创建一个新的处理器实例。
			// 构造数据：
			// 无需特殊构造数据，主要依赖 Mock。
			// 逻辑链路：
			// 1. Mock dal.NewContractMetaDao() 函数，使其返回一个自定义的 mock DAO 实例。
			// 2. 调用目标函数 newHandlerDraftSubmitPreContract()。
			// 3. 断言返回的 handler 不为 nil。
			// 4. 断言返回的 handler 的具体类型为 *handlerDraftSubmitPreContract。
			// 5. 断言 handler 内的 dao 字段已被正确初始化为第1步中 mock 的 DAO 实例。

			// 准备 Mock
			mockDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()

			// 调用目标函数
			handler := newHandlerDraftSubmitPreContract()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)

			// 断言返回实例的类型和字段值
			h, ok := handler.(*handlerDraftSubmitPreContract)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(h, convey.ShouldNotBeNil)
			convey.So(h.dao, convey.ShouldEqual, mockDao)
		})
	})
}

func Test_handlerDraftSubmitPreContract_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerDraftSubmitPreContract.Validate", t, func() {
		h := &handlerDraftSubmitPreContract{}
		ctx := context.Background()
		mockMetaServiceV2 := &MockMetaServiceV2{}

		mockey.PatchConvey("should return error when ContractInfo is nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 中的 ContractInfo 为 nil。
			// 逻辑链路：
			// 1. 函数入口检查 pc.ContractInfo 是否为 nil。
			// 2. 条件成立，返回 "合同协同记录不存在" 错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: nil,
			}
			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同协同记录不存在")
		})

		mockey.PatchConvey("should return error when BasicInfo is nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.ContractInfo 不为 nil，但 BasicInfo 为 nil。
			// 逻辑链路：
			// 1. pc.ContractInfo 检查通过。
			// 2. 检查 meta.BasicInfo 是否为 nil。
			// 3. 条件成立，返回 "ContractTemplateType" 缺失参数错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: nil,
				},
			}
			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractTemplateType")
		})

		mockey.PatchConvey("should return error when ContractTemplateType is nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.ContractInfo.BasicInfo 不为 nil，但 ContractTemplateType 为 nil。
			// 逻辑链路：
			// 1. pc.ContractInfo 和 meta.BasicInfo 检查通过。
			// 2. 检查 meta.BasicInfo.ContractTemplateType 是否为 nil。
			// 3. 条件成立，返回 "ContractTemplateType" 缺失参数错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: nil,
					},
				},
			}
			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractTemplateType")
		})

		mockey.PatchConvey("should return error when TradePartyInfo.BaseValidate fails", func() {
			// 场景描述：
			// 构造数据：基础校验通过，但 TradePartyInfo.BaseValidate 返回错误。
			// 逻辑链路：
			// 1. 前续检查均通过。
			// 2. 调用 meta.TradePartyInfo.BaseValidate() 并返回错误。
			// 3. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("base validate error")
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "base validate error")
		})

		mockey.PatchConvey("should return error when IsFeishu is true and TradePartyInfo.CheckPayTypes fails", func() {
			// 场景描述：
			// 构造数据：IsFeishu 为 true，TradePartyInfo.CheckPayTypes 返回错误。
			// 逻辑链路：
			// 1. BaseValidate 通过。
			// 2. meta.BasicInfo.IsFeishu 为 true，进入 if 分支。
			// 3. 调用 meta.TradePartyInfo.CheckPayTypes() 并返回错误。
			// 4. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
						IsFeishu:             true,
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("check pay types error")
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "check pay types error")
		})

		mockey.PatchConvey("should return error when CheckRelateSubjectParty fails", func() {
			// 场景描述：
			// 构造数据：前面的校验都通过，但 CheckRelateSubjectParty 返回错误。
			// 逻辑链路：
			// 1. 前续检查均通过。
			// 2. 调用 CheckRelateSubjectParty 并返回错误。
			// 3. 函数记录日志并返回该错误。
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
						IsFeishu:             false,
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("check relate subject party error")
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(nil).Build()
			mockey.Mock((*handlerCommon).getMetaServiceV2).Return(mockMetaServiceV2).Build()
			mockey.Mock((*MockMetaServiceV2).CheckRelateSubjectParty).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateRequireQuote).Return(nil).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "check relate subject party error")
		})

		mockey.PatchConvey("should return error when validateSupply fails", func() {
			// 场景描述：
			// 构造数据：前面的校验都通过，但 h.validateSupply 返回错误。
			// 逻辑链路：
			// 1. 前续检查均通过。
			// 2. 调用 h.validateSupply 并返回错误。
			// 3. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("validate supply error")
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(nil).Build()
			mockey.Mock((*handlerCommon).getMetaServiceV2).Return(mockMetaServiceV2).Build()
			mockey.Mock((*MockMetaServiceV2).CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate supply error")
		})

		mockey.PatchConvey("should return error when validateRequireQuote fails", func() {
			// 场景描述：
			// 构造数据：前面的校验都通过，但 h.validateRequireQuote 返回错误。
			// 逻辑链路：
			// 1. 前续检查均通过，包括 validateSupply。
			// 2. 调用 h.validateRequireQuote 并返回错误。
			// 3. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("validate require quote error")
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(nil).Build()
			mockey.Mock((*handlerCommon).getMetaServiceV2).Return(mockMetaServiceV2).Build()
			mockey.Mock((*MockMetaServiceV2).CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateRequireQuote).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate require quote error")
		})

		mockey.PatchConvey("should return nil when all validations pass", func() {
			// 场景描述：
			// 构造数据：所有校验都通过。
			// 逻辑链路：
			// 1. 所有检查和函数调用都成功返回 nil。
			// 2. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: gptr.Of(1),
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
			}
			mockey.Mock((*bizmodels.TradePartyInfo).BaseValidate).Return(nil).Build()
			mockey.Mock((*handlerCommon).getMetaServiceV2).Return(mockMetaServiceV2).Build()
			mockey.Mock((*MockMetaServiceV2).CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateRequireQuote).Return(nil).Build()

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerDraftSubmitPreContract_GetStatusOpConfKey(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftSubmitPreContract_GetStatusOpConfKey", t, func() {
		h := &handlerDraftSubmitPreContract{}
		ctx := context.Background()

		mockey.PatchConvey("场景一: pc.ComplianceCheckInfo 为 nil，应返回默认状态", func() {
			// 场景描述：
			// 构造数据：传入的 ProcessCtx 的 ComplianceCheckInfo 字段为 nil。
			// 逻辑链路：
			// 1. 函数执行，进入第一个 if 条件 `pc.ComplianceCheckInfo == nil`。
			// 2. 函数返回兜底的默认状态键 `_const.ApprovalStatusKeyDefault`。
			pc := &auditmodel.ProcessCtx{}

			// 调用
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})

		mockey.PatchConvey("场景二: 命中人审，应返回合规审查中状态", func() {
			// 场景描述：
			// 构造数据：传入的 ProcessCtx 的 ComplianceCheckInfo.Result.IsTransaction 字段为 _const.RejectTransaction ("0")。
			// 逻辑链路：
			// 1. 函数执行，`pc.ComplianceCheckInfo` 不为 nil，跳过第一个 if。
			// 2. 进入第二个 if 条件 `pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction`。
			// 3. 函数返回合规审查状态键 `_const.ApprovalStatusKeyComplianceCheck`。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: _const.RejectTransaction,
					},
				},
			}

			// 调用
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyComplianceCheck)
		})

		mockey.PatchConvey("场景三: 未命中人审，应返回默认状态", func() {
			// 场景描述：
			// 构造数据：传入的 ProcessCtx 的 ComplianceCheckInfo.Result.IsTransaction 字段不为 _const.RejectTransaction。
			// 逻辑链路：
			// 1. 函数执行，`pc.ComplianceCheckInfo` 不为 nil，跳过第一个 if。
			// 2. `pc.ComplianceCheckInfo.Result.IsTransaction` 不等于 `_const.RejectTransaction`，跳过第二个 if。
			// 3. 函数执行最后的 return 语句，返回默认状态键 `_const.ApprovalStatusKeyDefault`。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: "1", // 非 RejectTransaction
					},
				},
			}

			// 调用
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})
	})
}

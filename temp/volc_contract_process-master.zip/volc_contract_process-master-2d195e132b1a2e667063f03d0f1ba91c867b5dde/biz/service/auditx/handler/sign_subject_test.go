package handler

//import (
//	"context"
//	"errors"
//	"testing"
//	"volc_contract_process/biz/bizmodels"
//	_const "volc_contract_process/pkg/const"
//	"volc_contract_process/pkg/proxy/signsubjectcli"
//
//	"code.byted.org/eps-platform/vcp_clients/pkg/util"
//	gopkg_context "code.byted.org/gopkg/context"
//	"code.byted.org/lang/gg/gptr"
//	volc_sign_subject_models "code.byted.org/overpass/eps_platform_volc_sign_subject/kitex_gen/eps/platform/volc_sign_subject/models"
//	site_metadata_models "code.byted.org/overpass/eps_trade_site_metadata/kitex_gen/eps/trade/site_metadata/models"
//	"fmt"
//	"github.com/bytedance/mockey"
//	"github.com/smartystreets/goconvey/convey"
//	"volc_contract_process/biz/service/auditx/auditmodel"
//	"volc_contract_process/biz/service/multienv"
//	"volc_contract_process/biz/service/multienv/i18nfmt"
//	"volc_contract_process/pkg/conf"
//	pkg_errors "volc_contract_process/pkg/errors"
//	"volc_contract_process/pkg/preload"
//	"volc_contract_process/pkg/proxy/accountcli"
//	"volc_contract_process/pkg/proxy/larkc"
//	"volc_contract_process/pkg/proxy/subjectmetacli"
//	utils "volc_contract_process/pkg/util"
//)
//
//func Test_QuerySignSubjectMap_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("TestQuerySignSubjectMap", t, func() {
//		ctx := context.Background()
//
//		mockey.PatchConvey("成功处理：所有账号都有指定的签约主体", func() {
//			// 场景描述：
//			// 构造数据：两个待检查账号 "123", "456"， 合同类型为普通合同。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 成功返回两个账号的签约主体信息。
//			// 2. ListSubjectMetaDatas 成功返回两个签约主体的元数据。
//			// 3. for 循环遍历 checkAccounts，每个账号都能在 changeApprovalMap 中找到对应的签约主体。
//			// 4. 每个签约主体都能在 subjectMetaMap 中找到对应的元数据。
//			// 5. 成功构建并返回包含两个账号详细信息的 map。
//			specialContractType := "1" // Normal contract
//			checkAccounts := []string{"123", "456"}
//
//			mockApprovals := []*volc_sign_subject_models.ChangeApprovalItemDTO{
//				{AccountID: 123, SubjectNO: "S123"},
//				{AccountID: 456, SubjectNO: "S456"},
//			}
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(mockApprovals, nil).Build()
//
//			mockMetaDatas := []*site_metadata_models.SubjectMetaData{
//				{SubjectCode: "S123", SubjectFullName: "Subject 123 Full Name", MdcpCode: "MDCP123", MdapCode: "MDAP123", Country: "CN"},
//				{SubjectCode: "S456", SubjectFullName: "Subject 456 Full Name", MdcpCode: "MDCP456", MdapCode: "MDAP456", Country: "US"},
//			}
//			mockey.Mock(ListSubjectMetaDatas).Return(mockMetaDatas, nil).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(len(result), convey.ShouldEqual, 2)
//			convey.So(result["123"], convey.ShouldResemble, &bizmodels.TradePartyInfoDetail{
//				SubjectNo:        "S123",
//				PartyName:        "Subject 123 Full Name",
//				PartyNumber:      "MDCP123",
//				LegalPartyNumber: "MDAP123",
//				Country:          "CN",
//				Signer:           "Subject 123 Full Name",
//			})
//			convey.So(result["456"], convey.ShouldResemble, &bizmodels.TradePartyInfoDetail{
//				SubjectNo:        "S456",
//				PartyName:        "Subject 456 Full Name",
//				PartyNumber:      "MDCP456",
//				LegalPartyNumber: "MDAP456",
//				Country:          "US",
//				Signer:           "Subject 456 Full Name",
//			})
//		})
//
//		mockey.PatchConvey("异常处理：查询签约主体ListChangeApproval失败", func() {
//			// 场景描述：
//			// 构造数据：一个待检查账号 "123"。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 调用返回错误。
//			// 2. 函数记录错误日志，并返回 "查询可用主体失败" 的 APIError。
//			specialContractType := "1"
//			checkAccounts := []string{"123"}
//			mockErr := errors.New("rpc failed")
//
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(nil, mockErr).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(result, convey.ShouldBeNil)
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "查询可用主体失败")
//		})
//
//		mockey.PatchConvey("异常处理：查询交易主数据ListSubjectMetaDatas失败", func() {
//			// 场景描述：
//			// 构造数据：一个待检查账号 "123"。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 成功返回。
//			// 2. ListSubjectMetaDatas 调用返回错误。
//			// 3. 函数记录错误日志，并返回 "查询可用主体失败" 的 APIError。
//			specialContractType := "1"
//			checkAccounts := []string{"123"}
//
//			mockApprovals := []*volc_sign_subject_models.ChangeApprovalItemDTO{
//				{AccountID: 123, SubjectNO: "S123"},
//			}
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(mockApprovals, nil).Build()
//
//			mockErr := errors.New("metadata rpc failed")
//			mockey.Mock(ListSubjectMetaDatas).Return(nil, mockErr).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(result, convey.ShouldBeNil)
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "查询可用主体失败")
//		})
//
//		mockey.PatchConvey("异常处理：签约主体的元数据缺失", func() {
//			// 场景描述：
//			// 构造数据：一个待检查账号 "123"。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 成功返回，包含 SubjectNO "S123"。
//			// 2. ListSubjectMetaDatas 成功返回，但结果中不包含 "S123" 的元数据。
//			// 3. for 循环中，根据 "S123" 在 subjectMetaMap 中查找元数据，结果为 nil。
//			// 4. 进入 if subjectMeta == nil 分支，函数返回 "查询可用主体失败" 的 APIError。
//			specialContractType := "1"
//			checkAccounts := []string{"123"}
//
//			mockApprovals := []*volc_sign_subject_models.ChangeApprovalItemDTO{
//				{AccountID: 123, SubjectNO: "S123"},
//			}
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(mockApprovals, nil).Build()
//
//			mockey.Mock(ListSubjectMetaDatas).Return([]*site_metadata_models.SubjectMetaData{}, nil).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(result, convey.ShouldBeNil)
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "查询可用主体失败")
//		})
//
//		mockey.PatchConvey("成功处理：部分账号无指定签约主体，返回默认主体", func() {
//			// 场景描述：
//			// 构造数据：两个待检查账号 "123", "456"，合同类型为普通合同。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 仅返回账号 "123" 的信息。
//			// 2. ListSubjectMetaDatas 返回 "123" 对应主体的元数据。
//			// 3. for 循环遍历 checkAccounts:
//			//    a. 处理 "123" 时，能找到签约主体和元数据，正常构建 TradePartyInfoDetail。
//			//    b. 处理 "456" 时，在 changeApprovalMap 中找不到，且合同类型不为 "主体变更协议"，进入 else 分支。
//			// 4. 调用 GetDefaultSubject 获取默认主体信息。
//			// 5. 成功返回 map，其中 "123" 为指定主体，"456" 为默认主体。
//			specialContractType := "1"
//			checkAccounts := []string{"123", "456"}
//
//			mockApprovals := []*volc_sign_subject_models.ChangeApprovalItemDTO{
//				{AccountID: 123, SubjectNO: "S123"},
//			}
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(mockApprovals, nil).Build()
//
//			mockMetaDatas := []*site_metadata_models.SubjectMetaData{
//				{SubjectCode: "S123", SubjectFullName: "Subject 123 Full Name"},
//			}
//			mockey.Mock(ListSubjectMetaDatas).Return(mockMetaDatas, nil).Build()
//
//			mockDefaultSubject := &bizmodels.TradePartyInfoDetail{SubjectNo: "DEFAULT_SUBJECT", PartyName: "Default Party"}
//			mockey.Mock(GetDefaultSubject).Return(mockDefaultSubject).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(len(result), convey.ShouldEqual, 2)
//			convey.So(result["123"].SubjectNo, convey.ShouldEqual, "S123")
//			convey.So(result["456"], convey.ShouldEqual, mockDefaultSubject)
//		})
//
//		mockey.PatchConvey("成功处理：主体变更协议，部分账号无指定签约主体，返回nil", func() {
//			// 场景描述：
//			// 构造数据：两个待检查账号 "123", "456"，合同类型为 "主体变更协议"。
//			// 逻辑链路：
//			// 1. signsubjectcli.ListChangeApproval 仅返回账号 "123" 的信息。
//			// 2. ListSubjectMetaDatas 返回 "123" 对应主体的元数据。
//			// 3. for 循环遍历 checkAccounts:
//			//    a. 处理 "123" 时，能找到签约主体和元数据，正常构建 TradePartyInfoDetail。
//			//    b. 处理 "456" 时，在 changeApprovalMap 中找不到，且合同类型为 "主体变更协议"，进入 else if 分支。
//			// 4. 将 "456" 对应的 map value 设置为 nil。
//			// 5. 成功返回 map，其中 "123" 为指定主体，"456" 的值为 nil。
//			specialContractType := _const.SpecialContractTypeSubjectChangeAgreement
//			checkAccounts := []string{"123", "456"}
//
//			mockApprovals := []*volc_sign_subject_models.ChangeApprovalItemDTO{
//				{AccountID: 123, SubjectNO: "S123"},
//			}
//			mockey.Mock(signsubjectcli.ListChangeApproval).Return(mockApprovals, nil).Build()
//
//			mockMetaDatas := []*site_metadata_models.SubjectMetaData{
//				{SubjectCode: "S123", SubjectFullName: "Subject 123 Full Name"},
//			}
//			mockey.Mock(ListSubjectMetaDatas).Return(mockMetaDatas, nil).Build()
//
//			result, err := QuerySignSubjectMap(ctx, specialContractType, checkAccounts)
//
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(len(result), convey.ShouldEqual, 2)
//			convey.So(result["123"].SubjectNo, convey.ShouldEqual, "S123")
//			convey.So(result["456"], convey.ShouldBeNil)
//		})
//	})
//}
//
//
//func TestCheckRelateSubjectParty_BitsUTGen(t *testing.T) {
//	ctx := context.Background()
//
//	mockey.PatchConvey("TestCheckRelateSubjectParty", t, func() {
//		mockey.PatchConvey("场景：前置校验 - 禁用主体校验开关打开", func() {
//			// 场景描述：
//			// 构造数据：无特定构造。
//			// 逻辑链路：
//			// 1. Mock IsDisableSignSubjectCheck 返回 true。
//			// 2. 函数应在第一个if判断后直接返回nil，跳过所有后续校验逻辑。
//			req := &auditmodel.CheckRelateSubjectPartyReq{}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(true).Build()
//
//			err := CheckRelateSubjectParty(ctx, req)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("场景：前置校验 - 无需校验的业务来源", func() {
//			// 场景描述：
//			// 构造数据：请求的BizSource为伙伴报价（_const.BizSourcePartnerQuote），属于不需要校验的场景。
//			// 逻辑链路：
//			// 1. Mock IsDisableSignSubjectCheck 返回 false，进入后续逻辑。
//			// 2. 内部函数 needCheckSubject 根据BizSource判断返回false。
//			// 3. 函数应跳过校验逻辑，返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource: _const.BizSourcePartnerQuote,
//			}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//
//			err := CheckRelateSubjectParty(ctx, req)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("场景：获取签约账号 - 失败", func() {
//			// 场景描述：在获取需要校验的账号ID时，依赖的账号服务调用失败。
//			// 构造数据：构造一个需要进行校验的普通请求。
//			// 逻辑链路：
//			// 1. IsDisableSignSubjectCheck 返回 false, needCheckSubject 返回 true。
//			// 2. 内部函数 getSealPartySaleCreateAccountIDs 实际执行，并调用 accountcli.GetAccountAndVerifyListFromCache。
//			// 3. Mock accountcli.GetAccountAndVerifyListFromCache 返回一个错误。
//			// 4. 函数应捕获此错误并返回一个包装后的APIError。
//			tradePartyInfo := bizmodels.TradePartyInfo{
//				OtherParty: []*bizmodels.TradePartyInfoDetail{
//					{Sealed: _const.TRUE_FLAG_INT, AccountID: "12345"},
//				},
//			}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: 5, // 修复点：设置状态以通过 needCheckSubject 校验
//				TradePartyInfo:    gptr.Of(tradePartyInfo),
//			}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(nil, errors.New("get account failed")).Build()
//
//			err := CheckRelateSubjectParty(ctx, req)
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "查询账号信息失败")
//		})
//
//		mockey.PatchConvey("场景：获取签约账号 - 无需校验的账号", func() {
//			// 场景描述：获取到的账号均为销售创建，根据逻辑不需要进行主体校验。
//			// 构造数据：构造一个需要校验的请求，但其关联账号CreateSource为销售创建。
//			// 逻辑链路：
//			// 1. IsDisableSignSubjectCheck 返回 false, needCheckSubject 返回 true。
//			// 2. Mock accountcli.GetAccountAndVerifyListFromCache 返回销售创建的账号信息。
//			// 3. 内部函数 getSealPartySaleCreateAccountIDs 过滤后返回一个空切片。
//			// 4. 函数应跳过后续校验并返回nil。
//			tradePartyInfo := bizmodels.TradePartyInfo{
//				OtherParty: []*bizmodels.TradePartyInfoDetail{
//					{Sealed: _const.TRUE_FLAG_INT, AccountID: "12345"},
//				},
//			}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: 5, // 修复点：设置状态以通过 needCheckSubject 校验
//				TradePartyInfo:    gptr.Of(tradePartyInfo),
//			}
//			accountMap := map[string]*accountcli.AccountAndVerifyInfo{
//				"12345": {AccountID: 12345, CreateSource: _const.PassportCreateSourceSale},
//			}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountMap, nil).Build()
//
//			err := CheckRelateSubjectParty(ctx, req)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("场景：获取有效主体 - 获取失败", func() {
//			// 场景描述：成功获取到需要校验的账号后，在获取这些账号的有效签约主体时失败。
//			// 构造数据：构造一个需要校验的请求，关联账号为非销售创建。
//			// 逻辑链路：
//			// 1. 前置校验通过，并成功获取到需要校验的账号ID。
//			// 2. Mock GetEffectiveSubjectMap 返回一个错误。
//			// 3. 函数应直接返回此错误。
//			tradePartyInfo := bizmodels.TradePartyInfo{
//				OtherParty: []*bizmodels.TradePartyInfoDetail{
//					{Sealed: _const.TRUE_FLAG_INT, AccountID: "12345"},
//				},
//			}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: 5, // 修复点：设置状态以通过 needCheckSubject 校验
//				TradePartyInfo:    gptr.Of(tradePartyInfo),
//			}
//			accountMap := map[string]*accountcli.AccountAndVerifyInfo{
//				"12345": {AccountID: 12345, CreateSource: _const.PassportCreateSourceNormal}, // Not sale created
//			}
//			mockErr := pkg_errors.ErrCommon.WithArgs("get subject map failed")
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountMap, nil).Build()
//			mockey.Mock(GetEffectiveSubjectMap).Return(nil, mockErr).Build()
//
//			err := CheckRelateSubjectParty(ctx, req)
//			convey.So(err, convey.ShouldEqual, mockErr)
//		})
//
//		mockey.PatchConvey("场景：通用主体校验", func() {
//			tradePartyInfo := bizmodels.TradePartyInfo{
//				Subject:    []*bizmodels.TradePartyInfoDetail{{PartyNumber: "PN-001"}},
//				OtherParty: []*bizmodels.TradePartyInfoDetail{{Sealed: _const.TRUE_FLAG_INT, AccountID: "12345"}},
//			}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:           _const.BizSourceCooperation,
//				CooperationStatus:   5, // 修复点：设置状态以通过 needCheckSubject 校验
//				SpecialContractType: "",
//				TradePartyInfo:      gptr.Of(tradePartyInfo),
//			}
//			accountMap := map[string]*accountcli.AccountAndVerifyInfo{
//				"12345": {AccountID: 12345, CreateSource: _const.PassportCreateSourceNormal},
//			}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountMap, nil).Build()
//
//			mockey.PatchConvey("子场景：校验成功", func() {
//				// 场景描述：请求中的我方主体编码与预期的主体编码一致。
//				// 逻辑链路：
//				// 1. 前置校验通过，进入通用校验逻辑 checkSubjectCommon。
//				// 2. Mock GetEffectiveSubjectMap 返回匹配的预期主体信息。
//				// 3. 校验通过，函数返回nil。
//				expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//					"12345": {PartyNumber: "PN-001", PartyName: "Expected Subject"},
//				}
//				mockey.Mock(GetEffectiveSubjectMap).Return(expectedSubjectMap, nil).Build()
//
//				err := CheckRelateSubjectParty(ctx, req)
//				convey.So(err, convey.ShouldBeNil)
//			})
//
//			mockey.PatchConvey("子场景：校验失败", func() {
//				// 场景描述：请求中的我方主体编码与预期的主体编码不一致。
//				// 逻辑链路：
//				// 1. 前置校验通过，进入通用校验逻辑 checkSubjectCommon。
//				// 2. Mock GetEffectiveSubjectMap 返回不匹配的预期主体信息。
//				// 3. 校验失败，函数返回错误。
//				mismatchedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//					"12345": {PartyNumber: "PN-002", PartyName: "Another Subject"},
//				}
//				expectedErrMsg := "主体不匹配"
//				mockey.Mock(GetEffectiveSubjectMap).Return(mismatchedSubjectMap, nil).Build()
//				mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//				err := CheckRelateSubjectParty(ctx, req)
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//			})
//		})
//
//		mockey.PatchConvey("场景：主体变更协议校验", func() {
//			tradePartyInfo := bizmodels.TradePartyInfo{
//				Subject:    []*bizmodels.TradePartyInfoDetail{{PartyNumber: "PN-001"}},
//				OtherParty: []*bizmodels.TradePartyInfoDetail{{Sealed: _const.TRUE_FLAG_INT, AccountID: "12345"}},
//			}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:           _const.BizSourceCooperation,
//				CooperationStatus:   5, // 修复点：设置状态以通过 needCheckSubject 校验
//				SpecialContractType: _const.SpecialContractTypeSubjectChangeAgreement,
//				TradePartyInfo:      gptr.Of(tradePartyInfo),
//			}
//			accountMap := map[string]*accountcli.AccountAndVerifyInfo{
//				"12345": {AccountID: 12345, CreateSource: _const.PassportCreateSourceNormal},
//			}
//
//			mockey.Mock(IsDisableSignSubjectCheck).Return(false).Build()
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountMap, nil).Build()
//
//			mockey.PatchConvey("子场景：预期主体为空", func() {
//				// 场景描述：主体变更协议场景下，获取到的预期主体为nil。
//				// 逻辑链路：
//				// 1. 前置校验通过，进入主体变更协议校验逻辑 checkSubjectWithSubjectChangeAgreement。
//				// 2. Mock GetEffectiveSubjectMap 返回的map中，账号对应的subject为nil。
//				// 3. 校验失败，函数返回错误。
//				expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{"12345": nil}
//				expectedErrMsg := "不存在审批通过的签约主体"
//
//				mockey.Mock(GetEffectiveSubjectMap).Return(expectedSubjectMap, nil).Build()
//				mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//				err := CheckRelateSubjectParty(ctx, req)
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//			})
//
//			mockey.PatchConvey("子场景：请求中未包含预期主体", func() {
//				// 场景描述：主体变更协议场景下，请求的我方主体列表未包含预期的主体。
//				// 逻辑链路：
//				// 1. 前置校验通过，进入主体变更协议校验逻辑。
//				// 2. Mock GetEffectiveSubjectMap 返回一个预期主体。
//				// 3. 该主体编码在请求的我方主体列表中不存在，校验失败，函数返回错误。
//				expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//					"12345": {PartyNumber: "PN-002", PartyName: "Another Subject"},
//				}
//				expectedErrMsg := "必须包含"
//
//				mockey.Mock(GetEffectiveSubjectMap).Return(expectedSubjectMap, nil).Build()
//				mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//				err := CheckRelateSubjectParty(ctx, req)
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//			})
//
//			mockey.PatchConvey("子场景：校验成功", func() {
//				// 场景描述：主体变更协议场景下，请求的我方主体列表包含了预期的主体。
//				// 逻辑链路：
//				// 1. 前置校验通过，进入主体变更协议校验逻辑。
//				// 2. Mock GetEffectiveSubjectMap 返回一个预期主体。
//				// 3. 该主体编码在请求的我方主体列表中存在，校验通过，函数返回nil。
//				expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//					"12345": {PartyNumber: "PN-001", PartyName: "Expected Subject"},
//				}
//
//				mockey.Mock(GetEffectiveSubjectMap).Return(expectedSubjectMap, nil).Build()
//
//				err := CheckRelateSubjectParty(ctx, req)
//				convey.So(err, convey.ShouldBeNil)
//			})
//		})
//	})
//}
//
//
//func Test_checkSubjectWithSubjectChangeAgreement_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test checkSubjectWithSubjectChangeAgreement", t, func() {
//		ctx := context.Background()
//
//		mockey.PatchConvey("成功场景 - 预期的主体都存在于请求中", func() {
//			// 场景描述：
//			// 构造数据：构造一个请求，其交易方主体列表包含所有预期的主体。预期主体Map包含两个有效的主体。
//			// 逻辑链路：
//			// 1. 函数遍历预期主体Map。
//			// 2. 对于每一个预期主体，都能在请求的交易方主体列表中找到匹配的PartyNumber。
//			// 3. 循环正常结束，函数返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{PartyNumber: "PN-001", PartyName: "主体1"},
//						{PartyNumber: "PN-002", PartyName: "主体2"},
//					},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				"ACC-01": {PartyNumber: "PN-001", PartyName: "主体1"},
//				"ACC-02": {PartyNumber: "PN-002", PartyName: "主体2"},
//			}
//
//			err := checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("成功场景 - 预期的主体Map为空", func() {
//			// 场景描述：
//			// 构造数据：构造一个空的预期主体Map。
//			// 逻辑链路：
//			// 1. 函数的for循环不会执行。
//			// 2. 函数直接返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{PartyNumber: "PN-001", PartyName: "主体1"},
//					},
//				},
//			}
//			expectedSubjectMap := make(map[string]*bizmodels.TradePartyInfoDetail)
//
//			err := checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("失败场景 - 预期主体在Map中为nil", func() {
//			// 场景描述：
//			// 构造数据：构造一个预期主体Map，其中一个账号ID对应的主体详情为nil。
//			// 逻辑链路：
//			// 1. 函数遍历预期主体Map。
//			// 2. 当遇到值为nil的条目时，进入if expectedSubject == nil分支。
//			// 3. Mock i18nfmt.Sprintf返回一个特定的错误信息。
//			// 4. 函数返回一个包含该错误信息的APIError。
//			req := &auditmodel.CheckRelateSubjectPartyReq{}
//			accountID := "ACC-NULL"
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				accountID: nil,
//			}
//			expectedErrMsg := fmt.Sprintf("我方主体变更协议，账号【%s】不存在审批通过的签约主体", accountID)
//
//			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//			err := checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//		})
//
//		mockey.PatchConvey("失败场景 - 请求中缺少预期的主体", func() {
//			// 场景描述：
//			// 构造数据：构造一个请求，其交易方主体列表不包含某个预期的主体。
//			// 逻辑链路：
//			// 1. 函数遍历预期主体Map。
//			// 2. 对于缺失的主体，内层循环结束后，include标志位仍为false。
//			// 3. 进入if !include分支。
//			// 4. Mock i18nfmt.Sprintf返回一个特定的错误信息。
//			// 5. 函数返回一个包含该错误信息的APIError。
//			missingSubject := &bizmodels.TradePartyInfoDetail{PartyNumber: "PN-002", PartyName: "缺失的主体"}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{PartyNumber: "PN-001", PartyName: "主体1"},
//					},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				"ACC-01": {PartyNumber: "PN-001", PartyName: "主体1"},
//				"ACC-02": missingSubject,
//			}
//			expectedErrMsg := fmt.Sprintf("我方主体变更协议的“我方”必须包含[%s]", missingSubject.PartyName)
//			mockey.Mock(i18nfmt.Sprintf).When(func(ctx context.Context, format string, a ...interface{}) bool {
//				return format == "我方主体变更协议的“我方”必须包含[%s]"
//			}).Return(expectedErrMsg).Build()
//
//			err := checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//		})
//
//		mockey.PatchConvey("失败场景 - 请求中的主体列表为空", func() {
//			// 场景描述：
//			// 构造数据：构造一个请求，其交易方主体列表为空，但预期主体Map不为空。
//			// 逻辑链路：
//			// 1. 这是“请求中缺少预期的主体”的一个特例。
//			// 2. 函数遍历预期主体Map。
//			// 3. 内层循环（遍历请求的主体列表）不会执行。
//			// 4. include标志位始终为false，进入if !include分支。
//			// 5. Mock i18nfmt.Sprintf返回一个特定的错误信息。
//			// 6. 函数返回一个包含该错误信息的APIError。
//			expectedSubject := &bizmodels.TradePartyInfoDetail{PartyNumber: "PN-001", PartyName: "主体1"}
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				"ACC-01": expectedSubject,
//			}
//			expectedErrMsg := fmt.Sprintf("我方主体变更协议的“我方”必须包含[%s]", expectedSubject.PartyName)
//			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//			err := checkSubjectWithSubjectChangeAgreement(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err, convey.ShouldHaveSameTypeAs, pkg_errors.ErrCommon)
//			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//		})
//	})
//}
//
//
//func Test_getSealPartySaleCreateAccountIDs_BitsUTGen(t *testing.T) {
//	ctx := context.Background()
//
//	mockey.PatchConvey("Test_getSealPartySaleCreateAccountIDs", t, func() {
//		mockey.PatchConvey("场景1: 无需校验的账号，GetSealPartyAccounts返回空map", func() {
//			// 场景描述：
//			// 构造数据：构造一个 tradePartyInfo，使其 GetSealPartyAccounts 方法返回一个空的 account ID 集合。
//			// 逻辑链路：
//			// 1. 调用 tradePartyInfo.GetSealPartyAccounts() 返回空 map。
//			// 2. 函数在 `if len(checkAccounts) == 0` 处判断为真，直接返回 `res, nil`。
//			// 3. 预期结果为 `[]string{}, nil`。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(make(map[string]struct{})).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldBeNil)
//			convey.So(len(res), convey.ShouldEqual, 0)
//		})
//
//		mockey.PatchConvey("场景2: 查询账号信息失败，GetAccountAndVerifyListFromCache返回错误", func() {
//			// 场景描述：
//			// 构造数据：构造 tradePartyInfo 返回非空账号列表，但 mock GetAccountAndVerifyListFromCache 返回错误。
//			// 逻辑链路：
//			// 1. 调用 tradePartyInfo.GetSealPartyAccounts() 返回非空 map `{"123": {}}`。
//			// 2. mock accountcli.GetAccountAndVerifyListFromCache 返回一个 error。
//			// 3. 函数捕获错误，记录日志，并返回一个包装后的通用错误。
//			// 4. 预期结果为 `[]string{}, APIError`。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			checkAccounts := map[string]struct{}{"123": {}}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(checkAccounts).Build()
//
//			mockErr := errors.New("mock get account error")
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(nil, mockErr).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldNotBeNil)
//			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "查询账号信息失败")
//			convey.So(len(res), convey.ShouldEqual, 0)
//		})
//
//		mockey.PatchConvey("场景3: 混合账号来源，部分为非销售创建", func() {
//			// 场景描述：
//			// 构造数据：返回的账号列表中，一个账号是销售创建，另一个是官网创建。
//			// 逻辑链路：
//			// 1. tradePartyInfo.GetSealPartyAccounts 返回 `{"1001", "1002"}`。
//			// 2. accountcli.GetAccountAndVerifyListFromCache 返回两个账号的信息：账号1001为销售创建，账号1002为非销售创建。
//			// 3. 函数遍历返回的账号信息。
//			// 4. 账号 1001 的 CreateSource 是销售创建，被跳过。
//			// 5. 账号 1002 的 CreateSource 不是销售创建，其 ID "1002" 被加入结果列表。
//			// 6. 最终返回 `["1002"], nil`。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			checkAccounts := map[string]struct{}{"1001": {}, "1002": {}}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(checkAccounts).Build()
//
//			accountInfos := map[string]*accountcli.AccountAndVerifyInfo{
//				"1001": {AccountID: 1001, CreateSource: _const.PassportCreateSourceSale},
//				"1002": {AccountID: 1002, CreateSource: _const.PassportCreateSourceNormal},
//			}
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountInfos, nil).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldBeNil)
//			convey.So(res, convey.ShouldResemble, []string{"1002"})
//		})
//
//		mockey.PatchConvey("场景4: 所有账号均为销售创建", func() {
//			// 场景描述：
//			// 构造数据：返回的账号列表中，所有账号都是销售创建。
//			// 逻辑链路：
//			// 1. tradePartyInfo.GetSealPartyAccounts 返回 `{"2001", "2002"}`。
//			// 2. accountcli.GetAccountAndVerifyListFromCache 返回两个账号的信息，CreateSource 均为 PassportCreateSourceSale。
//			// 3. 函数遍历所有账号，因为 CreateSource 都是销售创建，所以全部跳过。
//			// 4. 最终返回一个空列表 `[]string{}, nil`。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			checkAccounts := map[string]struct{}{"2001": {}, "2002": {}}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(checkAccounts).Build()
//
//			accountInfos := map[string]*accountcli.AccountAndVerifyInfo{
//				"2001": {AccountID: 2001, CreateSource: _const.PassportCreateSourceSale},
//				"2002": {AccountID: 2002, CreateSource: _const.PassportCreateSourceSale},
//			}
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountInfos, nil).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldBeNil)
//			convey.So(len(res), convey.ShouldEqual, 0)
//		})
//
//		mockey.PatchConvey("场景5: 所有账号均非销售创建", func() {
//			// 场景描述：
//			// 构造数据：返回的账号列表中，所有账号都不是销售创建。
//			// 逻辑链路：
//			// 1. tradePartyInfo.GetSealPartyAccounts 返回 `{"3001", "3002"}`。
//			// 2. accountcli.GetAccountAndVerifyListFromCache 返回两个账号的信息，CreateSource 均为非销售创建。
//			// 3. 函数遍历所有账号，因为 CreateSource 都不是销售创建，所以将所有账号ID都加入结果列表。
//			// 4. 最终返回包含 "3001" 和 "3002" 的列表和 nil 错误。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			checkAccounts := map[string]struct{}{"3001": {}, "3002": {}}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(checkAccounts).Build()
//
//			accountInfos := map[string]*accountcli.AccountAndVerifyInfo{
//				"3001": {AccountID: 3001, CreateSource: _const.PassportCreateSourceNormal},
//				"3002": {AccountID: 3002, CreateSource: _const.PassportCreateSourceNormal},
//			}
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountInfos, nil).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldBeNil)
//			convey.So(len(res), convey.ShouldEqual, 2)
//			convey.So(res, convey.ShouldContain, "3001")
//			convey.So(res, convey.ShouldContain, "3002")
//		})
//
//		mockey.PatchConvey("场景6: GetAccountAndVerifyListFromCache返回空map", func() {
//			// 场景描述：
//			// 构造数据：GetSealPartyAccounts 返回非空列表，但 GetAccountAndVerifyListFromCache 返回空 map（例如账号不存在或已注销）。
//			// 逻辑链路：
//			// 1. tradePartyInfo.GetSealPartyAccounts 返回 `{"4001"}`。
//			// 2. accountcli.GetAccountAndVerifyListFromCache 成功调用，但返回一个空的账号信息 map。
//			// 3. for 循环不会执行。
//			// 4. 函数返回初始的空列表 `[]string{}, nil`。
//			tradePartyInfo := &bizmodels.TradePartyInfo{}
//			checkAccounts := map[string]struct{}{"4001": {}}
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(checkAccounts).Build()
//
//			accountInfos := make(map[string]*accountcli.AccountAndVerifyInfo)
//			mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountInfos, nil).Build()
//
//			res, apiErr := getSealPartySaleCreateAccountIDs(ctx, tradePartyInfo)
//
//			convey.So(apiErr, convey.ShouldBeNil)
//			convey.So(len(res), convey.ShouldEqual, 0)
//		})
//	})
//}
//
//
//func TestGetEffectiveSubjectMap_BitsUTGen(t *testing.T) {
//	ctx := context.Background()
//
//	mockey.PatchConvey("TestGetEffectiveSubjectMap", t, func() {
//		mockey.PatchConvey("场景：需要查询签约主体（如直销业务）", func() {
//			mockey.PatchConvey("当依赖的服务都正常返回时，应成功获取主体信息（混合指定主体和默认主体）", func() {
//				// 场景描述：
//				// 业务类型为直销，需要查询签约主体。一个账号有指定主体，另一个没有，应走默认主体逻辑。
//				// 构造数据：
//				// req.BusinessType = _const.BusinessTypeDirectSelling
//				// req.AccountIDs = ["1001", "1002"]
//				// 逻辑链路：
//				// 1. shouldQuerySubject(1) 返回 true，进入查询分支。
//				// 2. 调用 QuerySignSubjectMap。
//				// 3. Mock signsubjectcli.ListChangeApproval 在循环中分别被调用：为 "1001" 返回签约主体信息，为 "1002" 返回空。
//				// 4. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回 "1001" 对应主体的元数据。
//				// 5. Mock multienv.GetSubjectInfo 为 "1002" 提供默认主体信息。
//				// 6. 函数成功返回一个包含指定主体和默认主体的 map。
//				req := &auditmodel.GetEffectiveSubjectMapReq{
//					BusinessType: _const.BusinessTypeDirectSelling,
//					AccountIDs:   []string{"1001", "1002"},
//				}
//
//				mockey.Mock(signsubjectcli.ListChangeApproval).
//					When(func(ctx gopkg_context.Context, accountIds []string, status []int32) bool {
//						return util.StringIn("1001", accountIds)
//					}).
//					Return([]*volc_sign_subject_models.ChangeApprovalItemDTO{
//						{AccountID: 1001, SubjectNO: "SUBJ-001"},
//					}, nil).
//					When(func(ctx gopkg_context.Context, accountIds []string, status []int32) bool {
//						return util.StringIn("1002", accountIds)
//					}).
//					Return([]*volc_sign_subject_models.ChangeApprovalItemDTO{}, nil).
//					Build()
//
//				mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return([]*site_metadata_models.SubjectMetaData{
//					{
//						SubjectCode:     "SUBJ-001",
//						SubjectFullName: "Volcengine",
//						MdcpCode:        "MDCP-001",
//						MdapCode:        "MDAP-001",
//						Country:         "China",
//					},
//				}, nil).Build()
//
//				mockey.Mock(multienv.GetSubjectInfo).Return(multienv.SubjectInfo{
//					SubjectNo:   "DEFAULT-SUBJ-NO",
//					AccountName: "Default Subject",
//					CPMdmCode:   "DEFAULT-MDCP",
//					APMdmCode:   "DEFAULT-MDAP",
//					Country:     "Default Country",
//					Signer:      "Default Signer",
//				}).Build()
//
//				res, err := GetEffectiveSubjectMap(ctx, req)
//
//				convey.So(err, convey.ShouldBeNil)
//				convey.So(res, convey.ShouldNotBeNil)
//				convey.So(len(res), convey.ShouldEqual, 2)
//				convey.So(res["1001"], convey.ShouldNotBeNil)
//				convey.So(res["1001"].SubjectNo, convey.ShouldEqual, "SUBJ-001")
//				convey.So(res["1001"].PartyName, convey.ShouldEqual, "Volcengine")
//				convey.So(res["1002"], convey.ShouldNotBeNil)
//				convey.So(res["1002"].SubjectNo, convey.ShouldEqual, "DEFAULT-SUBJ-NO")
//				convey.So(res["1002"].PartyName, convey.ShouldEqual, "Default Subject")
//			})
//
//			mockey.PatchConvey("当查询签约主体列表失败时，应返回错误", func() {
//				// 场景描述：
//				// 业务类型为直销，需要查询签约主体。在调用 `signsubjectcli.ListChangeApproval` 时发生错误。
//				// 构造数据：
//				// req.BusinessType = _const.BusinessTypeDirectSelling
//				// 逻辑链路：
//				// 1. shouldQuerySubject(1) 返回 true。
//				// 2. 调用 QuerySignSubjectMap。
//				// 3. Mock signsubjectcli.ListChangeApproval 返回 error。
//				// 4. 函数应捕获错误并向上返回，返回值为 nil 和一个 APIError。
//				req := &auditmodel.GetEffectiveSubjectMapReq{
//					BusinessType: _const.BusinessTypeDirectSelling,
//					AccountIDs:   []string{"1001"},
//				}
//
//				mockErr := errors.New("rpc error")
//				mockey.Mock(signsubjectcli.ListChangeApproval).Return(nil, mockErr).Build()
//
//				res, err := GetEffectiveSubjectMap(ctx, req)
//
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "查询可用主体失败")
//				convey.So(res, convey.ShouldBeNil)
//			})
//
//			mockey.PatchConvey("当查询主体元数据失败时，应返回错误", func() {
//				// 场景描述：
//				// 业务类型为直销，查询签约主体列表成功，但在查询主体元数据时失败。
//				// 构造数据：
//				// req.BusinessType = _const.BusinessTypeDirectSelling
//				// 逻辑链路：
//				// 1. shouldQuerySubject(1) 返回 true。
//				// 2. 调用 QuerySignSubjectMap。
//				// 3. Mock signsubjectcli.ListChangeApproval 成功返回。
//				// 4. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回 error，触发降级逻辑。
//				// 5. 降级逻辑（无法 mock）也会失败，最终 ListSubjectMetaDatas 返回 error。
//				// 6. 函数应捕获错误并向上返回，返回值为 nil 和一个 APIError。
//				req := &auditmodel.GetEffectiveSubjectMapReq{
//					BusinessType: _const.BusinessTypeDirectSelling,
//					AccountIDs:   []string{"1001"},
//				}
//
//				mockey.Mock(signsubjectcli.ListChangeApproval).Return([]*volc_sign_subject_models.ChangeApprovalItemDTO{
//					{AccountID: 1001, SubjectNO: "SUBJ-001"},
//				}, nil).Build()
//
//				mockErr := errors.New("metadata rpc error")
//				mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return(nil, mockErr).Build()
//
//				res, err := GetEffectiveSubjectMap(ctx, req)
//
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "查询可用主体失败")
//				convey.So(res, convey.ShouldBeNil)
//			})
//
//			mockey.PatchConvey("当合同类型为“主体变更协议”且未找到指定主体时，应返回nil而不是默认主体", func() {
//				// 场景描述：
//				// 合同类型为特殊的主体变更协议。当某个账号没有找到指定的签约主体时，其在结果map中的值应为 nil，而不是回退到默认主体。
//				// 构造数据：
//				// req.BusinessType = _const.BusinessTypeDirectSelling
//				// req.SpecialContractType = _const.SpecialContractTypeSubjectChangeAgreement
//				// req.AccountIDs = ["3001"]
//				// 逻辑链路：
//				// 1. shouldQuerySubject(1) 返回 true。
//				// 2. 调用 QuerySignSubjectMap。
//				// 3. Mock signsubjectcli.ListChangeApproval 对 "3001" 返回空列表。
//				// 4. 在 QuerySignSubjectMap 内部，由于未找到主体且 specialContractType 是主体变更协议，将 res["3001"] 设置为 nil。
//				// 5. 函数成功返回，map 中包含一个 nil 值的 entry。
//				req := &auditmodel.GetEffectiveSubjectMapReq{
//					BusinessType:        _const.BusinessTypeDirectSelling,
//					SpecialContractType: _const.SpecialContractTypeSubjectChangeAgreement,
//					AccountIDs:          []string{"3001"},
//				}
//
//				mockey.Mock(signsubjectcli.ListChangeApproval).Return([]*volc_sign_subject_models.ChangeApprovalItemDTO{}, nil).Build()
//
//				res, err := GetEffectiveSubjectMap(ctx, req)
//
//				convey.So(err, convey.ShouldBeNil)
//				convey.So(res, convey.ShouldNotBeNil)
//				convey.So(len(res), convey.ShouldEqual, 1)
//				convey.So(res, convey.ShouldContainKey, "3001")
//				convey.So(res["3001"], convey.ShouldBeNil)
//			})
//		})
//
//		mockey.PatchConvey("场景：不需要查询签约主体（如代售业务）", func() {
//			mockey.PatchConvey("应为所有账号返回默认主体", func() {
//				// 场景描述：
//				// 业务类型为代售，不需要查询签约主体服务，应直接使用默认主体。
//				// 构造数据：
//				// req.BusinessType = _const.BusinessTypeSalesAgency (非查询类型)
//				// req.AccountIDs = ["2001", "2002"]
//				// 逻辑链路：
//				// 1. shouldQuerySubject(3) 返回 false，进入 else 分支。
//				// 2. 循环遍历 AccountIDs。
//				// 3. 每次循环调用 GetDefaultSubject。
//				// 4. Mock GetDefaultSubject 的依赖 multienv.GetSubjectInfo 返回一个固定的默认主体信息。
//				// 5. 函数成功返回一个 map，其中所有账号都映射到同一个默认主体。
//				req := &auditmodel.GetEffectiveSubjectMapReq{
//					BusinessType: _const.BusinessTypeSalesAgency,
//					AccountIDs:   []string{"2001", "2002"},
//				}
//
//				defaultInfo := multienv.SubjectInfo{
//					SubjectNo:   "DEFAULT-SUBJ-NO",
//					AccountName: "Default Subject",
//					CPMdmCode:   "DEFAULT-MDCP",
//					APMdmCode:   "DEFAULT-MDAP",
//					Country:     "Default Country",
//					Signer:      "Default Signer",
//				}
//				mockey.Mock(multienv.GetSubjectInfo).Return(defaultInfo).Build()
//
//				res, err := GetEffectiveSubjectMap(ctx, req)
//
//				convey.So(err, convey.ShouldBeNil)
//				convey.So(res, convey.ShouldNotBeNil)
//				convey.So(len(res), convey.ShouldEqual, 2)
//				convey.So(res["2001"], convey.ShouldNotBeNil)
//				convey.So(res["2001"].SubjectNo, convey.ShouldEqual, "DEFAULT-SUBJ-NO")
//				convey.So(res["2002"], convey.ShouldNotBeNil)
//				convey.So(res["2002"].SubjectNo, convey.ShouldEqual, "DEFAULT-SUBJ-NO")
//				convey.So(res["2001"].PartyName, convey.ShouldEqual, res["2002"].PartyName)
//			})
//		})
//	})
//}
//
//
//func TestListSubjectMetaDatas_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("TestListSubjectMetaDatas", t, func() {
//		ctx := gopkg_context.Background()
//
//		mockey.PatchConvey("场景：传入的subjectNos为空", func() {
//			// 场景描述：
//			// 当传入的 subjectNos 切片为空时，函数应直接返回 nil, nil。
//			// 构造数据：
//			// subjectNos 为一个空的 string 切片。
//			// 逻辑链路：
//			// 1. 函数入口检查 len(subjectNos) == 0。
//			// 2. 条件为真，直接返回 nil, nil。
//
//			// 调用
//			result, err := ListSubjectMetaDatas(ctx, []string{})
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("场景：远程缓存查询成功", func() {
//			// 场景描述：
//			// 主逻辑，通过 subjectmetacli 远程缓存查询数据成功。
//			// 构造数据：
//			// subjectNos 包含一个 "subject-1"。
//			// 逻辑链路：
//			// 1. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回一个包含数据的切片和 nil error。
//			// 2. 函数调用 subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache。
//			// 3. 调用成功，函数直接返回获取到的数据。
//
//			subjectNos := []string{"subject-1"}
//			mockData := []*site_metadata_models.SubjectMetaData{
//				{SubjectCode: "subject-1", SubjectFullName: "Test Subject 1"},
//			}
//			mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return(mockData, nil).Build()
//
//			// 调用
//			result, err := ListSubjectMetaDatas(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(len(result), convey.ShouldEqual, 1)
//			convey.So(result[0].SubjectCode, convey.ShouldEqual, "subject-1")
//		})
//
//		mockey.PatchConvey("场景：远程缓存查询失败，降级访问本地缓存成功", func() {
//			// 场景描述：
//			// 当远程缓存查询失败时，降级到本地缓存，并成功从本地缓存获取数据。
//			// 构造数据：
//			// subjectNos 包含 "subject-2"。
//			// 逻辑链路：
//			// 1. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回一个 error。
//			// 2. 函数进入 error 处理分支，开始降级逻辑。
//			// 3. Mock preload.SubjectMetaNo2Data 返回一个有效的数据对象。
//			// 4. 函数调用 getSubjectMetaBySubjectNoFromLocalCache，内部循环调用 preload.SubjectMetaNo2Data。
//			// 5. 调用成功，函数返回从本地缓存获取的数据。
//
//			subjectNos := []string{"subject-2"}
//			mockLocalData := &site_metadata_models.SubjectMetaData{
//				SubjectCode:     "subject-2",
//				SubjectFullName: "Local Test Subject 2",
//			}
//			mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return(nil, errors.New("remote cache failed")).Build()
//			mockey.Mock(preload.SubjectMetaNo2Data).When(func(no string) bool {
//				return no == "subject-2"
//			}).Return(mockLocalData).Build()
//
//			// 调用
//			result, err := ListSubjectMetaDatas(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(len(result), convey.ShouldEqual, 1)
//			convey.So(result[0].SubjectCode, convey.ShouldEqual, "subject-2")
//		})
//
//		mockey.PatchConvey("场景：远程缓存查询失败，降级访问本地缓存也失败", func() {
//			// 场景描述：
//			// 远程缓存和本地缓存都查询失败，最终返回错误。
//			// 构造数据：
//			// subjectNos 包含 "subject-3"。
//			// 逻辑链路：
//			// 1. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回一个 error。
//			// 2. 函数进入 error 处理分支，开始降级逻辑。
//			// 3. Mock preload.SubjectMetaNo2Data 返回 nil，模拟本地缓存未命中。
//			// 4. 函数调用 getSubjectMetaBySubjectNoFromLocalCache，内部调用 preload.SubjectMetaNo2Data 失败。
//			// 5. 内部会调用 i18nfmt.Sprintf, logs.CtxError, larkc.Warning。
//			// 6. 最终 getSubjectMetaBySubjectNoFromLocalCache 返回 error。
//			// 7. ListSubjectMetaDatas 返回该 error。
//
//			subjectNos := []string{"subject-3"}
//			mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return(nil, errors.New("remote cache failed")).Build()
//			mockey.Mock(preload.SubjectMetaNo2Data).Return(nil).Build()
//			mockey.Mock(i18nfmt.Sprintf).Return("mocked error message").Build()
//			mockey.Mock(larkc.Warning).Return().Build()
//
//			// 调用
//			result, err := ListSubjectMetaDatas(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "GetSubjectMetaDataFromCacheFail")
//			convey.So(result, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("场景：远程缓存查询失败，降级访问本地缓存部分成功", func() {
//			// 场景描述：
//			// 远程缓存失败，降级访问本地缓存时，查询多个 subjectNo，其中一个失败，则整个调用失败。
//			// 构造数据：
//			// subjectNos 包含 "s1" (成功) 和 "s2" (失败)。
//			// 逻辑链路：
//			// 1. Mock subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache 返回 error。
//			// 2. 函数进入降级逻辑，调用 getSubjectMetaBySubjectNoFromLocalCache。
//			// 3. 在 getSubjectMetaBySubjectNoFromLocalCache 内部循环中：
//			//    a. 第一次循环，Mock preload.SubjectMetaNo2Data("s1") 返回成功数据。
//			//    b. 第二次循环，Mock preload.SubjectMetaNo2Data("s2") 返回 nil。
//			// 4. 因为 "s2" 失败，getSubjectMetaBySubjectNoFromLocalCache 立即返回 error，导致整个 ListSubjectMetaDatas 也失败。
//
//			subjectNos := []string{"s1", "s2"}
//			mockLocalDataS1 := &site_metadata_models.SubjectMetaData{SubjectCode: "s1"}
//			mockey.Mock(subjectmetacli.ListInForceSubjectMetaDatasBySubjectNosFromCache).Return(nil, errors.New("remote cache failed")).Build()
//			mockey.Mock(preload.SubjectMetaNo2Data).When(func(no string) bool {
//				return no == "s1"
//			}).Return(mockLocalDataS1).When(func(no string) bool {
//				return no == "s2"
//			}).Return(nil).Build()
//			mockey.Mock(i18nfmt.Sprintf).Return("mocked error message for s2").Build()
//			mockey.Mock(larkc.Warning).Return().Build()
//
//			// 调用
//			result, err := ListSubjectMetaDatas(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "GetSubjectMetaDataFromCacheFail")
//			convey.So(result, convey.ShouldBeNil)
//		})
//	})
//}
//
//
//func Test_needCheckSubject_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test_needCheckSubject", t, func() {
//		mockey.PatchConvey("场景一：当BizSource为伙伴入驻时，应返回false", func() {
//			// 场景描述：
//			// BizSource为伙伴入驻，属于不需要校验的类型。
//			// 构造数据：
//			// req.BizSource = _const.BizSourcePartner
//			// 逻辑链路：
//			// 1. 调用 util.IntIn 检查 BizSource 是否在豁免列表 `[]int{_const.BizSourcePartner, _const.BizSourcePartnerQuote}` 中。
//			// 2. Mock util.IntIn 返回 true。
//			// 3. 第一个if条件为true，函数直接返回false。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource: _const.BizSourcePartner,
//			}
//			mockey.Mock(util.IntIn).Return(true).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景二：当BizSource为伙伴报价时，应返回false", func() {
//			// 场景描述：
//			// BizSource为伙伴报价，属于不需要校验的类型。
//			// 构造数据：
//			// req.BizSource = _const.BizSourcePartnerQuote
//			// 逻辑链路：
//			// 1. 调用 util.IntIn 检查 BizSource 是否在豁免列表 `[]int{_const.BizSourcePartner, _const.BizSourcePartnerQuote}` 中。
//			// 2. Mock util.IntIn 返回 true。
//			// 3. 第一个if条件为true，函数直接返回false。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource: _const.BizSourcePartnerQuote,
//			}
//			mockey.Mock(util.IntIn).Return(true).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景三：当BizSource为在线协同且状态为草稿时，应返回false", func() {
//			// 场景描述：
//			// BizSource为在线协同，且协商状态为草稿，属于不需要校验的特殊情况。
//			// 构造数据：
//			// req.BizSource = _const.BizSourceCooperation
//			// req.CooperationStatus = _const.PreSalesContractDraft
//			// 逻辑链路：
//			// 1. 第一次调用 util.IntIn 检查 BizSource，mock其返回false。
//			// 2. 第一个if条件为false，进入第二个if。
//			// 3. req.BizSource == _const.BizSourceCooperation 条件为true。
//			// 4. 第二次调用 util.IntIn 检查 CooperationStatus，mock其返回true。
//			// 5. 第二个if条件整体为true，函数返回false。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: _const.PreSalesContractDraft,
//			}
//			mockey.Mock(util.IntIn).Return(mockey.Sequence(false).Then(true)).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景四：当BizSource为在线协同且状态为未创建时，应返回false", func() {
//			// 场景描述：
//			// BizSource为在线协同，且协商状态为未创建，属于不需要校验的特殊情况。
//			// 构造数据：
//			// req.BizSource = _const.BizSourceCooperation
//			// req.CooperationStatus = _const.PreSalesContractNotCreated
//			// 逻辑链路：
//			// 1. 第一次调用 util.IntIn 检查 BizSource，mock其返回false。
//			// 2. 第一个if条件为false，进入第二个if。
//			// 3. req.BizSource == _const.BizSourceCooperation 条件为true。
//			// 4. 第二次调用 util.IntIn 检查 CooperationStatus，mock其返回true。
//			// 5. 第二个if条件整体为true，函数返回false。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: _const.PreSalesContractNotCreated,
//			}
//			mockey.Mock(util.IntIn).Return(mockey.Sequence(false).Then(true)).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景五：当BizSource为在线协同但状态不是草稿或未创建时，应返回true", func() {
//			// 场景描述：
//			// BizSource为在线协同，但状态不满足豁免条件，需要校验。
//			// 构造数据：
//			// req.BizSource = _const.BizSourceCooperation
//			// req.CooperationStatus = _const.PreSalesContractCustomerConfirm
//			// 逻辑链路：
//			// 1. 第一次调用 util.IntIn 检查 BizSource，mock其返回false。
//			// 2. 第一个if条件为false，进入第二个if。
//			// 3. req.BizSource == _const.BizSourceCooperation 条件为true。
//			// 4. 第二次调用 util.IntIn 检查 CooperationStatus，mock其返回false。
//			// 5. 第二个if条件整体为false，函数继续执行。
//			// 6. 函数最终返回true。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource:         _const.BizSourceCooperation,
//				CooperationStatus: _const.PreSalesContractCustomerConfirm,
//			}
//			mockey.Mock(util.IntIn).Return(mockey.Sequence(false).Then(false)).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeTrue)
//		})
//
//		mockey.PatchConvey("场景六：当BizSource为其他类型时，应返回true", func() {
//			// 场景描述：
//			// BizSource为其他需要校验的类型（非伙伴相关、非在线协同）。
//			// 构造数据：
//			// req.BizSource = _const.BizSourceFee
//			// 逻辑链路：
//			// 1. 第一次调用 util.IntIn 检查 BizSource，mock其返回false。
//			// 2. 第一个if条件为false。
//			// 3. 第二个if条件的 req.BizSource == _const.BizSourceCooperation 为false，不进入分支。
//			// 4. 函数最终返回true。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				BizSource: _const.BizSourceFee,
//			}
//			mockey.Mock(util.IntIn).Return(false).Build()
//
//			result := needCheckSubject(req)
//
//			convey.So(result, convey.ShouldBeTrue)
//		})
//	})
//}
//
//
//func Test_getSubjectMetaBySubjectNoFromLocalCache_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test_getSubjectMetaBySubjectNoFromLocalCache", t, func() {
//		ctx := context.Background()
//
//		mockey.PatchConvey("正常场景：所有subjectNo都在本地缓存中找到", func() {
//			// 场景描述：
//			// 构造数据：提供一个包含两个有效 subjectNo 的切片。
//			// 逻辑链路：
//			// 1. 循环遍历 subjectNos 切片。
//			// 2. 对于每个 subjectNo，Mock preload.SubjectMetaNo2Data 函数以返回一个有效的 SubjectMetaData 对象。
//			// 3. 循环正常结束。
//			// 4. 函数返回包含两个 SubjectMetaData 对象的切片和 nil 错误。
//
//			// 数据准备
//			subjectNos := []string{"S001", "S002"}
//			mockData1 := &site_metadata_models.SubjectMetaData{SubjectCode: "S001", SubjectFullName: "Company 1"}
//			mockData2 := &site_metadata_models.SubjectMetaData{SubjectCode: "S002", SubjectFullName: "Company 2"}
//
//			// Mock
//			mockey.Mock(preload.SubjectMetaNo2Data).When(func(no string) bool {
//				return no == "S001"
//			}).Return(mockData1).When(func(no string) bool {
//				return no == "S002"
//			}).Return(mockData2).Build()
//
//			// 调用
//			res, err := getSubjectMetaBySubjectNoFromLocalCache(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(res, convey.ShouldNotBeNil)
//			convey.So(len(res), convey.ShouldEqual, 2)
//			convey.So(res[0], convey.ShouldEqual, mockData1)
//			convey.So(res[1], convey.ShouldEqual, mockData2)
//		})
//
//		mockey.PatchConvey("异常场景：部分subjectNo在本地缓存中未找到", func() {
//			// 场景描述：
//			// 构造数据：提供一个包含一个有效和一个无效 subjectNo 的切片。
//			// 逻辑链路：
//			// 1. 循环遍历 subjectNos 切片。
//			// 2. 对第一个有效的 subjectNo，Mock preload.SubjectMetaNo2Data 返回有效数据。
//			// 3. 对第二个无效的 subjectNo，Mock preload.SubjectMetaNo2Data 返回 nil。
//			// 4. 进入 if data == nil 分支。
//			// 5. Mock i18nfmt.Sprintf 返回错误信息。
//			// 6. Mock larkc.Warning 被调用。
//			// 7. 函数立即返回 nil 和一个错误。
//
//			// 数据准备
//			subjectNos := []string{"S001", "S999"}
//			mockData1 := &site_metadata_models.SubjectMetaData{SubjectCode: "S001", SubjectFullName: "Company 1"}
//
//			// Mock
//			mockey.Mock(preload.SubjectMetaNo2Data).When(func(no string) bool {
//				return no == "S001"
//			}).Return(mockData1).When(func(no string) bool {
//				return no == "S999"
//			}).Return(nil).Build()
//
//			mockey.Mock(i18nfmt.Sprintf).Return("mocked error content").Build()
//			mockey.Mock(larkc.Warning).Return().Build()
//
//			// 调用
//			res, err := getSubjectMetaBySubjectNoFromLocalCache(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "GetSubjectMetaDataFromCacheFail")
//			convey.So(res, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("边缘场景：传入空的subjectNos切片", func() {
//			// 场景描述：
//			// 构造数据：提供一个空的 subjectNo 切片。
//			// 逻辑链路：
//			// 1. for 循环不执行。
//			// 2. 函数直接返回一个 nil 切片和 nil 错误。
//
//			// 数据准备
//			subjectNos := []string{}
//
//			// 调用
//			res, err := getSubjectMetaBySubjectNoFromLocalCache(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//			// 对于空的 subjectNos，函数返回一个 nil 切片，其长度为 0
//			convey.So(len(res), convey.ShouldEqual, 0)
//		})
//
//		mockey.PatchConvey("异常场景：第一个subjectNo在本地缓存中未找到", func() {
//			// 场景描述：
//			// 构造数据：提供一个切片，其中第一个 subjectNo 就是无效的。
//			// 逻辑链路：
//			// 1. 循环开始，处理第一个 subjectNo。
//			// 2. Mock preload.SubjectMetaNo2Data 返回 nil。
//			// 3. 进入 if data == nil 分支并立即返回错误，循环中断。
//			// 4. 函数返回 nil 和一个错误。
//
//			// 数据准备
//			subjectNos := []string{"S999", "S001"}
//
//			// Mock
//			mockey.Mock(preload.SubjectMetaNo2Data).When(func(no string) bool {
//				return no == "S999"
//			}).Return(nil).Build()
//			mockey.Mock(i18nfmt.Sprintf).Return(fmt.Sprintf("本地缓存无此数据，subjectNo: %s", "S999")).Build()
//			mockey.Mock(larkc.Warning).Return().Build()
//
//			// 调用
//			res, err := getSubjectMetaBySubjectNoFromLocalCache(ctx, subjectNos)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldEqual, "GetSubjectMetaDataFromCacheFail")
//			convey.So(res, convey.ShouldBeNil)
//		})
//	})
//}
//
//
//func Test_checkSubjectCommon_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test_checkSubjectCommon", t, func() {
//		ctx := context.Background()
//
//		mockey.PatchConvey("成功场景: 请求的主体编码与预期的主体编码匹配", func() {
//			// 场景描述：
//			// 构造数据：请求中的主体PartyNumber与预期Map中的PartyNumber匹配。
//			// 逻辑链路：
//			// 1. mock utils.ToJSON函数。
//			// 2. 函数进入两层for循环。
//			// 3. if party.PartyNumber != expectedSubject.PartyNumber 条件不成立。
//			// 4. 循环正常结束，函数返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{
//							PartyNumber: "PN123",
//							PartyName:   "Request Party",
//						},
//					},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				"account1": {
//					PartyNumber: "PN123",
//					PartyName:   "Expected Party",
//				},
//			}
//
//			mockey.Mock(utils.ToJSON).Return("mocked json").Build()
//
//			err := checkSubjectCommon(ctx, req, expectedSubjectMap)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("成功场景: 请求中的主体列表为空", func() {
//			// 场景描述：
//			// 构造数据：请求中的`TradePartyInfo.Subject`切片为空。
//			// 逻辑链路：
//			// 1. mock utils.ToJSON函数。
//			// 2. 函数外层for循环不执行。
//			// 3. 函数直接返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				"account1": {
//					PartyNumber: "PN123",
//					PartyName:   "Expected Party",
//				},
//			}
//			mockey.Mock(utils.ToJSON).Return("mocked json").Build()
//
//			err := checkSubjectCommon(ctx, req, expectedSubjectMap)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("成功场景: 预期的主体Map为空", func() {
//			// 场景描述：
//			// 构造数据：`expectedSubjectMap`为空map。
//			// 逻辑链路：
//			// 1. mock utils.ToJSON函数。
//			// 2. 函数外层for循环执行。
//			// 3. 函数内层for循环不执行。
//			// 4. 循环正常结束，函数返回nil。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{
//							PartyNumber: "PN123",
//							PartyName:   "Request Party",
//						},
//					},
//				},
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{}
//			mockey.Mock(utils.ToJSON).Return("mocked json").Build()
//
//			err := checkSubjectCommon(ctx, req, expectedSubjectMap)
//			convey.So(err, convey.ShouldBeNil)
//		})
//
//		mockey.PatchConvey("失败场景: 主体编码不匹配", func() {
//			// 场景描述：
//			// 构造数据：请求中的主体PartyNumber与预期Map中的PartyNumber不匹配。
//			// 逻辑链路：
//			// 1. mock utils.ToJSON函数。
//			// 2. mock i18nfmt.Sprintf函数以构造预期的错误信息。
//			// 3. 函数进入两层for循环。
//			// 4. if party.PartyNumber != expectedSubject.PartyNumber 条件成立。
//			// 5. 函数返回一个由errors.ErrCommon.WithArgs构造的错误。
//			req := &auditmodel.CheckRelateSubjectPartyReq{
//				TradePartyInfo: &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{
//							PartyNumber: "PN_WRONG", // 错误的主体编码
//							PartyName:   "Request Party",
//						},
//					},
//				},
//			}
//			accountID := "test-account"
//			expectedSubject := &bizmodels.TradePartyInfoDetail{
//				PartyNumber: "PN_CORRECT",
//				PartyName:   "Expected Party Name",
//			}
//			expectedSubjectMap := map[string]*bizmodels.TradePartyInfoDetail{
//				accountID: expectedSubject,
//			}
//
//			mockey.Mock(utils.ToJSON).Return("mocked json").Build()
//
//			expectedErrMsg := fmt.Sprintf("%s当前仅可使用[%s]作为我方主体签约", accountID, expectedSubject.PartyName)
//			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()
//
//			err := checkSubjectCommon(ctx, req, expectedSubjectMap)
//
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err, convey.ShouldHaveSameTypeAs, pkg_errors.ErrCommon)
//			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
//		})
//	})
//}
//
//
//func TestGetDefaultSubject_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("TestGetDefaultSubject", t, func() {
//		mockey.PatchConvey("should return trade party info detail based on subject info", func() {
//			// 场景描述：
//			// 测试GetDefaultSubject函数是否能正确地从multienv.GetSubjectInfo()获取信息，并组装成一个*bizmodels.TradePartyInfoDetail对象返回。
//			// 构造数据：
//			// 构造一个multienv.SubjectInfo对象作为multienv.GetSubjectInfo()的mock返回值。
//			// 逻辑链路：
//			// 1. Mock multienv.GetSubjectInfo() 函数，使其返回一个预先定义好的 multienv.SubjectInfo 实例。
//			// 2. 调用目标函数 GetDefaultSubject()。
//			// 3. 断言返回的 *bizmodels.TradePartyInfoDetail 对象的各个字段是否与 mock 数据中的对应字段值相匹配。
//
//			// 准备mock数据
//			mockInfo := multienv.SubjectInfo{
//				SubjectNo:   "TEST_SUBJECT_NO_123",
//				AccountName: "Test Party Name",
//				CPMdmCode:   "TEST_CP_MDM_CODE_456",
//				APMdmCode:   "TEST_AP_MDM_CODE_789",
//				Country:     "CN",
//				Signer:      "Test Signer",
//			}
//
//			// Mock依赖函数
//			mockey.Mock(multienv.GetSubjectInfo).Return(mockInfo).Build()
//
//			// 调用目标函数
//			result := GetDefaultSubject()
//
//			// 断言结果
//			convey.So(result, convey.ShouldNotBeNil)
//			convey.So(result.SubjectNo, convey.ShouldEqual, mockInfo.SubjectNo)
//			convey.So(result.PartyName, convey.ShouldEqual, mockInfo.AccountName)
//			convey.So(result.PartyNumber, convey.ShouldEqual, mockInfo.CPMdmCode)
//			convey.So(result.LegalPartyNumber, convey.ShouldEqual, mockInfo.APMdmCode)
//			convey.So(result.Country, convey.ShouldEqual, mockInfo.Country)
//			convey.So(result.Signer, convey.ShouldEqual, mockInfo.Signer)
//		})
//	})
//}
//
//
//func TestNeedCheckRelateSubjectPartyByTradePartyChange_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("TestNeedCheckRelateSubjectPartyByTradePartyChange", t, func() {
//		// 构造mock用的空结构体指针
//		old := &bizmodels.TradePartyInfo{}
//		new := &bizmodels.TradePartyInfo{}
//
//		// 准备mock数据
//		oldAccountSet := map[string]struct{}{"acc1": {}}
//		newAccountSetSame := map[string]struct{}{"acc1": {}}
//		newAccountSetDiff := map[string]struct{}{"acc2": {}}
//
//		oldNumSet := map[string]struct{}{"num1": {}}
//		newNumSetSame := map[string]struct{}{"num1": {}}
//		newNumSetDiff := map[string]struct{}{"num2": {}}
//
//		mockey.PatchConvey("场景：当签约对方主体账号发生变化时，应返回true", func() {
//			// 场景描述：签约对方主体账号发生变化，我方主体不变。
//			// 构造数据：通过mock使GetSealPartyAccounts返回不同的集合，GetSubjectPartyNumber返回相同的集合。
//			// 逻辑链路：
//			// 1. old.GetSealPartyAccounts() 和 new.GetSealPartyAccounts() 的mock返回值不同。
//			// 2. utils.EqualStringSet(oldAccountSet, newAccountSet) 将返回false。
//			// 3. 第一个判断条件 !utils.EqualStringSet(...) 为 true，函数直接返回 true。
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(mockey.Sequence(oldAccountSet).Then(newAccountSetDiff)).Build()
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSubjectPartyNumber).Return(mockey.Sequence(oldNumSet).Then(newNumSetSame)).Build()
//
//			result := NeedCheckRelateSubjectPartyByTradePartyChange(old, new)
//			convey.So(result, convey.ShouldBeTrue)
//		})
//
//		mockey.PatchConvey("场景：当签约对方主体账号不变，但我方主体发生变化时，应返回true", func() {
//			// 场景描述：签约对方主体账号不变，我方主体发生变化。
//			// 构造数据：通过mock使GetSealPartyAccounts返回相同的集合，GetSubjectPartyNumber返回不同的集合。
//			// 逻辑链路：
//			// 1. GetSealPartyAccounts的mock返回值相同，第一个!utils.EqualStringSet(...)为false。
//			// 2. GetSubjectPartyNumber的mock返回值不同，第二个!utils.EqualStringSet(...)为true。
//			// 3. OR逻辑判断为true，函数返回 true。
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(mockey.Sequence(oldAccountSet).Then(newAccountSetSame)).Build()
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSubjectPartyNumber).Return(mockey.Sequence(oldNumSet).Then(newNumSetDiff)).Build()
//
//			result := NeedCheckRelateSubjectPartyByTradePartyChange(old, new)
//			convey.So(result, convey.ShouldBeTrue)
//		})
//
//		mockey.PatchConvey("场景：当签约对方主体账号与我方主体均未发生变化时，应返回false", func() {
//			// 场景描述：签约对方主体账号与我方主体均未发生变化。
//			// 构造数据：通过mock使GetSealPartyAccounts和GetSubjectPartyNumber都返回相同的集合。
//			// 逻辑链路：
//			// 1. GetSealPartyAccounts的mock返回值相同，第一个!utils.EqualStringSet(...)为false。
//			// 2. GetSubjectPartyNumber的mock返回值相同，第二个!utils.EqualStringSet(...)为false。
//			// 3. OR逻辑判断为false，函数返回 false。
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(mockey.Sequence(oldAccountSet).Then(newAccountSetSame)).Build()
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSubjectPartyNumber).Return(mockey.Sequence(oldNumSet).Then(newNumSetSame)).Build()
//
//			result := NeedCheckRelateSubjectPartyByTradePartyChange(old, new)
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景：当签约对方主体账号与我方主体均发生变化时，应返回true", func() {
//			// 场景描述：签约对方主体账号与我方主体均发生变化。
//			// 构造数据：通过mock使GetSealPartyAccounts和GetSubjectPartyNumber都返回不同的集合。
//			// 逻辑链路：
//			// 1. GetSealPartyAccounts的mock返回值不同，第一个!utils.EqualStringSet(...)为true。
//			// 2. 函数因短路求值直接返回 true。
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSealPartyAccounts).Return(mockey.Sequence(oldAccountSet).Then(newAccountSetDiff)).Build()
//			mockey.Mock((*bizmodels.TradePartyInfo).GetSubjectPartyNumber).Return(mockey.Sequence(oldNumSet).Then(newNumSetDiff)).Build()
//
//			result := NeedCheckRelateSubjectPartyByTradePartyChange(old, new)
//			convey.So(result, convey.ShouldBeTrue)
//		})
//
//		mockey.PatchConvey("场景：处理nil输入", func() {
//			// 此处不使用mock，直接测试函数对nil输入的处理能力
//			mockey.PatchConvey("当新旧交易方信息均为空时，应返回false", func() {
//				// 场景描述：old 和 new 都为 nil。
//				// 逻辑链路：
//				// 1. GetSealPartyAccounts 和 GetSubjectPartyNumber 方法内部会处理nil接收者，返回空map。
//				// 2. 两个空map集合通过utils.EqualStringSet比较是相等的。
//				// 3. 两个判断条件都为false，函数返回 false。
//				result := NeedCheckRelateSubjectPartyByTradePartyChange(nil, nil)
//				convey.So(result, convey.ShouldBeFalse)
//			})
//
//			mockey.PatchConvey("当旧交易方信息不为空，新交易方信息为空时，应返回true", func() {
//				// 场景描述：old 不为 nil 且有数据，new 为 nil。
//				// 构造数据：构造一个有数据的 old TradePartyInfo。
//				// 逻辑链路：
//				// 1. old.Get... 返回非空集合。
//				// 2. new.Get... (nil接收者) 返回空集合。
//				// 3. 非空集合与空集合不相等，!utils.EqualStringSet(...)为true，函数返回 true。
//				oldWithData := &bizmodels.TradePartyInfo{
//					Subject: []*bizmodels.TradePartyInfoDetail{
//						{PartyNumber: "PN123"},
//					},
//					OtherParty: []*bizmodels.TradePartyInfoDetail{
//						{Sealed: _const.TRUE_FLAG_INT, AccountID: "ACC456"},
//					},
//				}
//				var newNil *bizmodels.TradePartyInfo // 显式声明为nil
//
//				result := NeedCheckRelateSubjectPartyByTradePartyChange(oldWithData, newNil)
//				convey.So(result, convey.ShouldBeTrue)
//			})
//		})
//	})
//}
//
//
//func Test_IsDisableSignSubjectCheck_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test IsDisableSignSubjectCheck", t, func() {
//		mockey.PatchConvey("场景1: 全局配置加载失败返回nil", func() {
//			// 场景描述:
//			// 构造数据: 无
//			// 逻辑链路:
//			// 1. Mock conf.GetGlobalConf 返回 nil
//			// 2. IsDisableSignSubjectCheck 函数执行，进入 config == nil 的分支
//			// 3. 函数返回 false
//
//			// Mock
//			mockey.Mock(conf.GetGlobalConf).Return(nil).Build()
//
//			// 调用
//			result := IsDisableSignSubjectCheck(context.Background())
//
//			// 断言
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景2: 开关关闭", func() {
//			// 场景描述:
//			// 构造数据: 构造一个全局配置，其中 DisableSignSubjectCheck 开关为 false
//			// 逻辑链路:
//			// 1. Mock conf.GetGlobalConf 返回一个配置对象，其中 SwitchConfig.DisableSignSubjectCheck = false
//			// 2. IsDisableSignSubjectCheck 函数执行，不进入 config == nil 的分支
//			// 3. 函数返回 config.SwitchConfig.DisableSignSubjectCheck 的值，即 false
//
//			// 构造数据
//			mockConfig := &conf.GlobalConf{
//				SwitchConfig: conf.SwitchConfig{
//					DisableSignSubjectCheck: false,
//				},
//			}
//
//			// Mock
//			mockey.Mock(conf.GetGlobalConf).Return(mockConfig).Build()
//
//			// 调用
//			result := IsDisableSignSubjectCheck(context.Background())
//
//			// 断言
//			convey.So(result, convey.ShouldBeFalse)
//		})
//
//		mockey.PatchConvey("场景3: 开关开启", func() {
//			// 场景描述:
//			// 构造数据: 构造一个全局配置，其中 DisableSignSubjectCheck 开关为 true
//			// 逻辑链路:
//			// 1. Mock conf.GetGlobalConf 返回一个配置对象，其中 SwitchConfig.DisableSignSubjectCheck = true
//			// 2. IsDisableSignSubjectCheck 函数执行，不进入 config == nil 的分支
//			// 3. 函数返回 config.SwitchConfig.DisableSignSubjectCheck 的值，即 true
//
//			// 构造数据
//			mockConfig := &conf.GlobalConf{
//				SwitchConfig: conf.SwitchConfig{
//					DisableSignSubjectCheck: true,
//				},
//			}
//
//			// Mock
//			mockey.Mock(conf.GetGlobalConf).Return(mockConfig).Build()
//
//			// 调用
//			result := IsDisableSignSubjectCheck(context.Background())
//
//			// 断言
//			convey.So(result, convey.ShouldBeTrue)
//		})
//	})
//}
//
//
//func Test_shouldQuerySubject_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test_shouldQuerySubject", t, func() {
//		mockey.PatchConvey("should return true when businessType is in the list", func() {
//			// 场景描述：
//			// 待测试函数 shouldQuerySubject 依赖 util.IntIn 来判断 businessType 是否在预设的列表中。
//			// 本测试场景验证当 businessType 存在于列表中时，函数返回 true 的情况。
//			// 构造数据：
//			// - businessType: 使用一个预期的常量，如 BusinessTypeDirectSelling
//			// 逻辑链路：
//			// 1. Mock util.IntIn 函数，使其返回 true，模拟 businessType 在列表中的情况。
//			// 2. 调用 shouldQuerySubject 函数。
//			// 3. 断言返回结果为 true。
//
//			businessType := _const.BusinessTypeDirectSelling
//
//			mockey.Mock(util.IntIn).Return(true).Build()
//
//			result := shouldQuerySubject(businessType)
//			convey.So(result, convey.ShouldBeTrue)
//		})
//
//		mockey.PatchConvey("should return false when businessType is not in the list", func() {
//			// 场景描述：
//			// 待测试函数 shouldQuerySubject 依赖 util.IntIn 来判断 businessType 是否在预设的列表中。
//			// 本测试场景验证当 businessType 不存在于列表中时，函数返回 false 的情况。
//			// 构造数据：
//			// - businessType: 使用一个不在预期列表中的常量，如 BusinessTypeSalesAgency
//			// 逻辑链路：
//			// 1. Mock util.IntIn 函数，使其返回 false，模拟 businessType 不在列表中的情况。
//			// 2. 调用 shouldQuerySubject 函数。
//			// 3. 断言返回结果为 false。
//
//			businessType := _const.BusinessTypeSalesAgency
//
//			mockey.Mock(util.IntIn).Return(false).Build()
//
//			result := shouldQuerySubject(businessType)
//			convey.So(result, convey.ShouldBeFalse)
//		})
//	})
//}
//
//
//func Test_getSubjectStatus_BitsUTGen(t *testing.T) {
//	mockey.PatchConvey("Test_getSubjectStatus", t, func() {
//		mockey.PatchConvey("当合同类型包含主体变更协议时，应返回审批通过和主体变更协议签署中状态", func() {
//			// 场景描述：
//			// 传入的 specialContractType 字符串包含“我方主体变更协议”的类型标识。
//			// 构造数据：
//			// - specialContractType: "1," + _const.SpecialContractTypeSubjectChangeAgreement
//			// 逻辑链路：
//			// 1. Mock util.StringIn 函数返回 true，模拟在特殊合同类型列表中找到了“我方主体变更协议”。
//			// 2. 函数执行 if 条件为 true 的分支。
//			// 3. 函数返回包含审批通过和主体变更协议签署中状态的切片。
//
//			specialContractType := "1," + _const.SpecialContractTypeSubjectChangeAgreement
//
//			mockey.Mock(util.StringIn).Return(true).Build()
//
//			result := getSubjectStatus(specialContractType)
//
//			expected := []int32{signsubjectcli.ChangeApprovalItemPass, signsubjectcli.ChangeApprovalItemChangeAgreementSigned}
//			convey.So(result, convey.ShouldResemble, expected)
//		})
//
//		mockey.PatchConvey("当合同类型不包含主体变更协议时，应返回生效中状态", func() {
//			// 场景描述：
//			// 传入的 specialContractType 字符串不包含“我方主体变更协议”的类型标识。
//			// 构造数据：
//			// - specialContractType: "1,2"
//			// 逻辑链路：
//			// 1. Mock util.StringIn 函数返回 false，模拟在特殊合同类型列表中未找到“我方主体变更协议”。
//			// 2. 函数执行 if 条件为 false 的分支。
//			// 3. 函数返回仅包含生效中状态的切片。
//
//			specialContractType := "1,2"
//
//			mockey.Mock(util.StringIn).Return(false).Build()
//
//			result := getSubjectStatus(specialContractType)
//
//			expected := []int32{signsubjectcli.ChangeApprovalItemInForce}
//			convey.So(result, convey.ShouldResemble, expected)
//		})
//
//		mockey.PatchConvey("当合同类型为空字符串时，应返回生效中状态", func() {
//			// 场景描述：
//			// 传入的 specialContractType 为空字符串。
//			// 构造数据：
//			// - specialContractType: ""
//			// 逻辑链路：
//			// 1. Mock util.StringIn 函数返回 false，模拟在特殊合同类型列表中未找到“我方主体变更协议”。
//			// 2. 函数执行 if 条件为 false 的分支。
//			// 3. 函数返回仅包含生效中状态的切片。
//
//			specialContractType := ""
//
//			mockey.Mock(util.StringIn).Return(false).Build()
//
//			result := getSubjectStatus(specialContractType)
//
//			expected := []int32{signsubjectcli.ChangeApprovalItemInForce}
//			convey.So(result, convey.ShouldResemble, expected)
//		})
//	})
//}
//
//

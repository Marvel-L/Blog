package handler

import (
	"context"
	"encoding/json"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

func newHandlerInformationSendBack() StatusOpHandler {
	return &handlerInformationSendBack{}
}

// 销售运营完善信息(7) --- 退回(4) --> 销售确认中(5)
type handlerInformationSendBack struct {
	handlerCommon
}

func (h *handlerInformationSendBack) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationCompleteInformation
}

func (h *handlerInformationSendBack) CurrentOp() int {
	return _const.OperationSendBack
}

func (h *handlerInformationSendBack) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	if pc.Comment.IsEmpty() {
		return i18nfmt.Errorf(ctx, "审核意见不可为空")
	}
	return nil
}

func (h *handlerInformationSendBack) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.ContractInfo != nil && pc.ContractInfo.BasicInfo != nil && pc.ContractInfo.BasicInfo.IsSkipFTL {
		// 跳过财税法审批分支退回到前序节点后，需要清除跳过标识，后续重新按实际流程判断。
		pc.ContractInfo.BasicInfo.IsSkipFTL = false
		basicInfoStr, err := json.Marshal(pc.ContractInfo.BasicInfo)
		if err != nil {
			logs.CtxError(ctx, "InformationSendBackFail_BasicMarshal, err:%v", err)
			return err
		}
		pc.PreContractVO.BasicInfo = string(basicInfoStr)

		if err := h.updateContractData(ctx, pc); err != nil {
			logs.CtxError(ctx, "updateContractDataFail, err:%v", err)
			return err
		}
	}

	return nil
}

func (h *handlerInformationSendBack) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerInformationSendBack) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 退回到已退回节点时，清理报价单关联商品信息并仅保留申请人权限。
	if err := h.clearSendBackStatusQuoteAndReviewers(ctx, pc); err != nil {
		return err
	}

	// 退回到销售节点时通知c360
	if pc.StatusChangedValue == _const.PreSalesContractSendBack {
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSalesReviewSendBack, pc)
	}

	// 通知退回目标节点审批人，当前合同已被退回。
	h.sendBackNotifyTargetReviewers(ctx, pc)
	// 通知当前节点其他审批人，当前合同已被退回。
	h.SendBackNotifyPeerReviewers(ctx, pc)
	return nil
}

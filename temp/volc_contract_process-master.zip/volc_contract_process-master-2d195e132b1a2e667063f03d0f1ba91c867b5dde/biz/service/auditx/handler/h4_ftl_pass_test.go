package handler

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"testing"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_handlerFTLReviewPass_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerFTLReviewPass PostProcess", t, func() {
		// 准备通用测试数据
		h := &handlerFTLReviewPass{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:     "test-contract-no",
				ContractName:   "test-contract-name",
				OtherPartyName: "test-party-name",
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					{Reviewer: "op@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationCompleteInformation},
				},
			},
			PreContractVO: &model.ContractMetaDB{
				ContractNo: "test-pre-contract-no",
			},
		}

		mockey.PatchConvey("场景1: reviewPassSendReviewedMessage 返回错误", func() {
			// 场景描述:
			// 构造数据: 无特殊构造
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 方法返回一个错误
			// 2. 调用 PostProcess 方法
			// 3. 断言 PostProcess 返回的错误与mock的错误一致

			// Mock
			expectedErr := errors.New("send reviewed message failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(expectedErr).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "send reviewed message failed")
		})

		mockey.PatchConvey("场景2: StatusChanged 为 false", func() {
			// 场景描述:
			// 构造数据: 设置 ProcessCtx.StatusChanged 为 false
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 方法返回 nil
			// 2. 调用 PostProcess 方法
			// 3. 断言 PostProcess 返回 nil，且后续的飞书消息和C360通知逻辑不会被执行

			// 准备数据
			pc.StatusChanged = false

			// Mock
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: StatusChanged 为 true 且 IsBytePlus 为 true (BytePlus环境)", func() {
			// 场景描述:
			// 构造数据: 设置 ProcessCtx.StatusChanged 为 true
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 方法返回 nil
			// 2. Mock multienv.IsBytePlus 返回 true
			// 3. 所有依赖的获取审核人、发送飞书消息、生成URL、通知C360等方法都被成功Mock
			// 4. 断言 PostProcess 最终返回 nil

			// 准备数据
			pc.StatusChanged = true
			pc.StatusChangedValue = _const.PreSalesContractCustomerConfirm

			// Mock
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("lark-card-json").Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return([]string{"sales@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"op@example.com"}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(utils.StringListFormat).To(func(list []string, f func(string) string) []string {
				var result []string
				for _, item := range list {
					result = append(result, f(item))
				}
				return result
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).Return("<at>").Build()
			mockey.Mock(larkc.GenCRMDetailURL).Return("http://example.com/crm").Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review").Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: StatusChanged 为 true 且 IsBytePlus 为 false (国内环境)", func() {
			// 场景描述:
			// 构造数据: 设置 ProcessCtx.StatusChanged 为 true
			// 逻辑链路:
			// 1. Mock (*handlerCommon).reviewPassSendReviewedMessage 方法返回 nil
			// 2. Mock multienv.IsBytePlus 返回 false，跳过给销售发送消息的逻辑
			// 3. 成功 Mock 后续给销售运营发送消息和通知C360的逻辑
			// 4. 断言 PostProcess 最终返回 nil

			// 准备数据
			pc.StatusChanged = true

			// Mock
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("lark-card-json").Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
				// 验证此函数被调用，并且不是给销售的消息
				convey.So(strings.Join(emailList, ","), convey.ShouldNotContainSubstring, "sales@example.com")
			}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return([]string{"op@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(utils.StringListFormat).To(func(list []string, f func(string) string) []string {
				var result []string
				for _, item := range list {
					result = append(result, f(item))
				}
				return result
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).Return("<at>").Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review").Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: notifyC360 失败 (错误被忽略)", func() {
			// 场景描述:
			// 构造数据: 设置 ProcessCtx.StatusChanged 为 true
			// 逻辑链路:
			// 1. Mock (*handlerCommon).notifyC360 返回一个错误
			// 2. 由于函数实现中忽略了 notifyC360 的错误，PostProcess 应该仍然返回 nil

			// 准备数据
			pc.StatusChanged = true
			mockey.Mock(multienv.IsBytePlus).Return(false).Build() // 假设是国内环境

			// Mock
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return(nil).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return(nil).Build()
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(&larkc.CommonMessageCardBuilder{}).Build() // 返回一个空的即可
			mockey.Mock((*handlerCommon).notifyC360).Return(errors.New("c360 failed")).Build()

			// 调用
			err := h.PostProcess(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewPass_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewPass_Validate", t, func() {
		h := &handlerFTLReviewPass{
			handlerCommon: handlerCommon{},
		}
		ctx := context.Background()

		mockey.PatchConvey("should return error when SkipReturnReview is invalid", func() {
			// 场景描述：
			// 构造一个 pc.SkipReturnReview 为无效值的 ProcessCtx，
			// 使得 IsValidSkipReturnReviewType 返回 false。
			// 逻辑链路：
			// 1. Mock _const.IsValidSkipReturnReviewType 返回 false。
			// 2. 调用 h.Validate，进入第一个 if 分支。
			// 3. 函数返回 "SkipReturnReview字段异常" 错误。
			pc := &auditmodel.ProcessCtx{
				SkipReturnReview: 0, // Invalid value
			}

			mockey.Mock(_const.IsValidSkipReturnReviewType).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SkipReturnReview字段异常")
		})

		mockey.PatchConvey("should return error when commonCheckReviewerPass fails", func() {
			// 场景描述：
			// pc.SkipReturnReview 有效，但是 commonCheckReviewerPass 方法返回一个错误。
			// 逻辑链路：
			// 1. Mock _const.IsValidSkipReturnReviewType 返回 true。
			// 2. Mock h.commonCheckReviewerPass 返回一个预设的 error。
			// 3. 调用 h.Validate，跳过第一个 if 分支，进入第二个 if 分支。
			// 4. 函数返回 commonCheckReviewerPass 的错误。
			pc := &auditmodel.ProcessCtx{
				SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit,
			}
			expectedErr := errors.New("common check reviewer pass failed")

			mockey.Mock(_const.IsValidSkipReturnReviewType).Return(true).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("should succeed when all checks pass", func() {
			// 场景描述：
			// 所有校验都通过，函数应该成功返回 nil。
			// 逻辑链路：
			// 1. Mock _const.IsValidSkipReturnReviewType 返回 true。
			// 2. Mock h.commonCheckReviewerPass 返回 nil。
			// 3. 调用 h.Validate，跳过所有 if 分支。
			// 4. 函数成功返回 nil。
			pc := &auditmodel.ProcessCtx{
				SkipReturnReview: _const.SkipReturnReviewTypeNeedAudit,
			}

			mockey.Mock(_const.IsValidSkipReturnReviewType).Return(true).Build()
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewPass_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewPass_Process", t, func() {
		mockey.PatchConvey("should return nil", func() {
			// 场景描述：
			// 目标函数是一个空实现，直接返回nil。
			// 构造数据：
			// - handlerFTLReviewPass
			// - context.Context
			// - auditmodel.ProcessCtx
			// 逻辑链路：
			// 1. 调用Process方法。
			// 2. 断言返回的error为nil。

			// 初始化变量
			h := &handlerFTLReviewPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewPass_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerFTLReviewPass HitStateChangeCondition", t, func() {
		// 共同的测试数据准备
		h := &handlerFTLReviewPass{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no",
				CooperationStatus: 1,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 1,
			},
		}

		mockey.PatchConvey("场景：commonCheckHitContractStatusChange返回true，表示满足条件", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用了 commonCheckHitContractStatusChange。
			// 本场景模拟 commonCheckHitContractStatusChange 返回 true 和 nil error，表示条件满足。
			// 构造数据：
			// - 无特殊构造，使用通用pc即可。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (true, nil)。
			// 2. 调用目标函数 (h *handlerFTLReviewPass) HitStateChangeCondition。
			// 3. 目标函数直接返回 mock 的结果。
			// 4. 断言返回值为 (true, nil)。

			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(true, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：commonCheckHitContractStatusChange返回false，表示不满足条件", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用了 commonCheckHitContractStatusChange。
			// 本场景模拟 commonCheckHitContractStatusChange 返回 false 和 nil error，表示条件不满足。
			// 构造数据：
			// - 无特殊构造，使用通用pc即可。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (false, nil)。
			// 2. 调用目标函数 (h *handlerFTLReviewPass) HitStateChangeCondition。
			// 3. 目标函数直接返回 mock 的结果。
			// 4. 断言返回值为 (false, nil)。

			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(false, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：commonCheckHitContractStatusChange返回错误", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用了 commonCheckHitContractStatusChange。
			// 本场景模拟 commonCheckHitContractStatusChange 返回一个错误，模拟检查过程中出现异常。
			// 构造数据：
			// - 构造一个 error 对象用于 mock。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (false, mockError)。
			// 2. 调用目标函数 (h *handlerFTLReviewPass) HitStateChangeCondition。
			// 3. 目标函数直接返回 mock 的结果。
			// 4. 断言返回值为 (false, error)，且错误与 mock 的错误一致。

			mockErr := errors.New("check failed")
			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(false, mockErr).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(hit, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "check failed")
		})
	})
}

func Test_handlerFTLReviewPass_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewPass_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewPass", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回正确的操作常量。
			// 构造数据：
			// 创建一个 handlerFTLReviewPass 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于 _const.OperationReviewPass。

			// 准备数据
			h := &handlerFTLReviewPass{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.OperationReviewPass)
		})
	})
}

func Test_handlerFTLReviewPass_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewPass_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况-返回正确的状态码", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerFTLReviewPass 实例。
			// 逻辑链路：
			// 1. 直接调用 CurrentStatus 方法。
			// 2. 断言返回值等于预期的常量 _const.PreSalesContractFinanceTaxationLegalReview。

			// 数据准备
			h := &handlerFTLReviewPass{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalReview)
		})
	})
}

func Test_newHandlerFTLReviewPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLReviewPass", t, func() {
		mockey.PatchConvey("正常场景: 成功创建一个 handlerFTLReviewPass 实例", func() {
			// 场景描述：
			// 测试 newHandlerFTLReviewPass 函数能否正确创建一个新的处理器实例。
			// 构造数据：
			// 无需构造数据。
			// 逻辑链路：
			// 1. 调用 newHandlerFTLReviewPass()。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerFTLReviewPass。

			// 调用目标函数
			handler := newHandlerFTLReviewPass()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLReviewPass{})
		})
	})
}

package handler

import (
	"reflect"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/pkg/const"
)

func TestGetReviewerTypeStatusMappings_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetReviewerTypeStatusMappings", t, func() {
		mockey.PatchConvey("当approvalKey为自采平台时，应返回自采平台的特定映射关系", func() {
			// 场景描述:
			// 构造数据: approvalKey 设置为 _const.ApprovalKeyCooperationSelfPurchase
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeStatusMappings 函数
			// 2. 函数进入第一个 if 分支 (approvalKey == _const.ApprovalKeyCooperationSelfPurchase)
			// 3. 函数返回为自采平台硬编码的 map
			// 4. 断言返回结果与预期一致

			approvalKey := _const.ApprovalKeyCooperationSelfPurchase
			expected := map[int][]int{
				_const.ReviewerTypeSalesperson: {
					_const.PreSalesContractNotCreated, // 未创建
					_const.PreSalesContractDraft,      // 草稿
				},
			}

			result := GetReviewerTypeStatusMappings(approvalKey)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当是BytePlus环境时，应返回BP环境的映射关系", func() {
			// 场景描述:
			// 构造数据: approvalKey 设置为一个非自采平台的任意值
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 true
			// 2. 调用 GetReviewerTypeStatusMappings 函数
			// 3. 函数的第一个 if 条件不满足
			// 4. 函数进入第二个 if 分支 (multienv.IsBytePlus() 为 true)
			// 5. 函数返回 reviewerTypeStatusBPMappings
			// 6. 断言返回结果与预期的 BP 映射关系一致

			approvalKey := "any_other_key"
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			expected := map[int][]int{
				_const.ReviewerTypeSalesperson: {
					_const.PreSalesContractNotCreated,
					_const.PreSalesContractDraft,
					_const.PreSalesContractSendBack,
					_const.PreSalesContractCustomerConfirm,
					_const.PreSalesContractChange,
				},
				_const.ReviewerTypeSalesOperation: {
					_const.PreSalesContractSalesOperationReview,
					_const.PreSalesContractSalesOperationCompleteInformation,
				},
				_const.ReviewerTypeFinanceTaxationLegalReviewer: {
					_const.PreSalesContractFinanceTaxationLegalReview,
				},
			}

			result := GetReviewerTypeStatusMappings(approvalKey)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当approvalKey为合作报价时，应返回BP环境的映射关系", func() {
			// 场景描述:
			// 构造数据: approvalKey 设置为 _const.ApprovalKeyCooperationQuote
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false
			// 2. 调用 GetReviewerTypeStatusMappings 函数
			// 3. 函数的第一个 if 条件不满足
			// 4. 函数进入第二个 if 分支 (approvalKey == _const.ApprovalKeyCooperationQuote 为 true)
			// 5. 函数返回 reviewerTypeStatusBPMappings
			// 6. 断言返回结果与预期的 BP 映射关系一致

			approvalKey := _const.ApprovalKeyCooperationQuote
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			expected := map[int][]int{
				_const.ReviewerTypeSalesperson: {
					_const.PreSalesContractNotCreated,
					_const.PreSalesContractDraft,
					_const.PreSalesContractSendBack,
					_const.PreSalesContractCustomerConfirm,
					_const.PreSalesContractChange,
				},
				_const.ReviewerTypeSalesOperation: {
					_const.PreSalesContractSalesOperationReview,
					_const.PreSalesContractSalesOperationCompleteInformation,
				},
				_const.ReviewerTypeFinanceTaxationLegalReviewer: {
					_const.PreSalesContractFinanceTaxationLegalReview,
				},
			}

			result := GetReviewerTypeStatusMappings(approvalKey)

			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当非BP环境且为其他approvalKey时，应返回默认的映射关系", func() {
			// 场景描述:
			// 构造数据: approvalKey 设置为一个既非自采平台也非合作报价的值
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus() 返回 false
			// 2. 调用 GetReviewerTypeStatusMappings 函数
			// 3. 函数的前两个 if 条件均不满足
			// 4. 函数执行到最后，返回默认的 reviewerTypeStatusMappings
			// 5. 断言返回结果与预期的默认映射关系一致

			approvalKey := _const.ApprovalKeyDefault
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			expected := map[int][]int{
				_const.ReviewerTypeSalesperson: {
					_const.PreSalesContractNotCreated,
					_const.PreSalesContractDraft,
					_const.PreSalesContractSendBack,
					_const.PreSalesContractCustomerConfirm,
					_const.PreSalesContractChange,
				},
				_const.ReviewerTypeSalesOperation: {
					_const.PreSalesContractSalesOperationReview,
					_const.PreSalesContractSalesOperationCompleteInformation,
					_const.PreSalesContractRiskReview,
				},
				_const.ReviewerTypeFinanceTaxationLegalReviewer: {
					_const.PreSalesContractFinanceTaxationLegalReview,
					_const.PreSalesContractFinanceTaxationLegalSignReview,
				},
				_const.ReviewerTypeSolutionReviewer: {
					_const.PreSalesContractSolutionReview,
				},
			}

			result := GetReviewerTypeStatusMappings(approvalKey)

			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_AllHandlers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test AllHandlers", t, func() {
		mockey.PatchConvey("正常场景: 应返回所有已注册的状态操作处理器", func() {
			// 场景描述:
			// 本测试用于验证 AllHandlers 函数是否能够正确地初始化并返回一个包含所有已定义的 handler 的切片。
			// 逻辑链路:
			// 1. 调用 AllHandlers() 函数。
			// 2. 断言返回的切片不为 nil。
			// 3. 断言切片中的 handler 数量符合预期（47个）。
			// 4. 验证返回的切片中包含了每种预期的 handler 类型，并且每种类型只出现一次。

			// 调用目标函数
			handlers := AllHandlers()

			// 断言基本属性
			convey.So(handlers, convey.ShouldNotBeNil)
			convey.So(len(handlers), convey.ShouldEqual, 47)

			// 验证是否包含了所有预期的 handler 类型
			expectedTypes := map[reflect.Type]struct{}{
				// 多节点通用
				// reflect.TypeOf(&handlerMultiChangeQuote{}):     {},
				reflect.TypeOf(&handlerMultiAbandon{}):         {},
				reflect.TypeOf(&handlerMultiAcquireReviewer{}): {},
				// 未创建
				reflect.TypeOf(&handlerNotCreateSubmitDraft{}): {},
				// 草稿
				reflect.TypeOf(&handlerDraftDelete{}):            {},
				reflect.TypeOf(&handlerDraftSubmitPreContract{}): {},
				reflect.TypeOf(&handlerDraftUpdate{}):            {},
				reflect.TypeOf(&implDraftSubmitOA{}):             {},
				// 已退回
				reflect.TypeOf(&handlerSendBackSubmit{}): {},
				reflect.TypeOf(&handlerSendBackUpdate{}): {},
				// 销售运营审批
				reflect.TypeOf(&handlerSalesReviewPass{}):                {},
				reflect.TypeOf(&handlerSalesReviewSendBack{}):            {},
				reflect.TypeOf(&handlerSalesReviewAddReviewers{}):        {},
				reflect.TypeOf(&handlerSalesReviewChangeReviewer{}):      {},
				reflect.TypeOf(&handlerSalesReviewWithdrawPreContract{}): {},
				reflect.TypeOf(&handlerSalesReviewUpdate{}):              {},
				reflect.TypeOf(&handlerSalesReviewWithdraw{}):            {},
				reflect.TypeOf(&handlerSalesReviewPassSkip{}):            {},
				// 财税法交付专业审核
				reflect.TypeOf(&handlerFTLReviewPass{}):           {},
				reflect.TypeOf(&handlerFTLReviewSendBack{}):       {},
				reflect.TypeOf(&handlerFTLReviewAddReviewers{}):   {},
				reflect.TypeOf(&handlerFTLReviewChangeReviewer{}): {},
				reflect.TypeOf(&handlerFTLReviewWithdraw{}):       {},
				// 销售确认中
				reflect.TypeOf(&handlerConfirmHaveChange{}): {},
				reflect.TypeOf(&handlerConfirmFinalized{}):  {},
				reflect.TypeOf(&handlerConfirmSendback{}):   {},
				// 有修改
				reflect.TypeOf(&handlerHaveChangeUpdate{}): {},
				reflect.TypeOf(&handlerHaveChangeSubmit{}): {},
				reflect.TypeOf(&handlerHaveChangeCancel{}): {},
				// 销售运营完善信息
				reflect.TypeOf(&handlerInformationSubmitOA{}):     {},
				reflect.TypeOf(&handlerInformationSendBack{}):     {},
				reflect.TypeOf(&handlerInformationUpdate{}):       {},
				reflect.TypeOf(&handlerInformationSendBackSkip{}): {},
				reflect.TypeOf(&handlerInformationPass{}):         {},
				// 财税法签约审核
				reflect.TypeOf(&handlerFTLSignReviewAddReviewers{}):   {},
				reflect.TypeOf(&handlerFTLSignReviewChangeReviewer{}): {},
				reflect.TypeOf(&handlerFTLSignReviewPass{}):           {},
				reflect.TypeOf(&handlerFTLSignSendBack{}):             {},
				reflect.TypeOf(&handlerFTLSignReviewWithdraw{}):       {},
				// 风险条款审核
				reflect.TypeOf(&handlerRiskSendBack{}): {},
				reflect.TypeOf(&handlerRiskSubmitOA{}): {},
				reflect.TypeOf(&handlerRiskTurnDown{}): {},
				// 解决方案审批
				reflect.TypeOf(&handlerSolutionReviewPass{}):    {},
				reflect.TypeOf(&handlerSolutionWithdraw{}):      {},
				reflect.TypeOf(&handlerSolutionSendBack{}):      {},
				reflect.TypeOf(&handlerSolutionAddViewers{}):    {},
				reflect.TypeOf(&handlerSolutionChangeViewers{}): {},
				reflect.TypeOf(&handlerComplianceCheckPass{}):   {},
			}

			foundTypes := make(map[reflect.Type]int)
			for _, h := range handlers {
				hType := reflect.TypeOf(h)
				foundTypes[hType]++
			}

			// 验证找到的唯一类型数量与预期相符
			convey.So(len(foundTypes), convey.ShouldEqual, len(expectedTypes))

			// 逐一验证每种预期类型都已找到，且只找到一次
			for hType := range expectedTypes {
				mockey.PatchConvey("验证类型 "+hType.String(), func() {
					count, ok := foundTypes[hType]
					convey.So(ok, convey.ShouldBeTrue)
					convey.So(count, convey.ShouldEqual, 1)
				})
			}
		})
	})
}

func Test_GetReviewerTypeByCooperationStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetReviewerTypeByCooperationStatus", t, func() {
		mockey.PatchConvey("场景：当coStatus为销售人员相关状态时，应返回ReviewerTypeSalesperson", func() {
			// 场景描述:
			// 输入一个属于销售人员处理范围内的合作状态码，例如草稿状态。
			// 构造数据:
			// coStatus = _const.PreSalesContractDraft (1)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings。
			// 3. 在 _const.ReviewerTypeSalesperson 对应的状态列表中找到 coStatus。
			// 4. 函数返回 _const.ReviewerTypeSalesperson (0)。
			coStatus := _const.PreSalesContractDraft

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeSalesperson)
		})

		mockey.PatchConvey("场景：当coStatus为销售运营相关状态时，应返回ReviewerTypeSalesOperation", func() {
			// 场景描述:
			// 输入一个属于销售运营处理范围内的合作状态码，例如销售运营专业审核状态。
			// 构造数据:
			// coStatus = _const.PreSalesContractSalesOperationReview (3)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings。
			// 3. 在 _const.ReviewerTypeSalesOperation 对应的状态列表中找到 coStatus。
			// 4. 函数返回 _const.ReviewerTypeSalesOperation (1)。
			coStatus := _const.PreSalesContractSalesOperationReview

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeSalesOperation)
		})

		mockey.PatchConvey("场景：当coStatus为财税法审核相关状态时，应返回ReviewerTypeFinanceTaxationLegalReviewer", func() {
			// 场景描述:
			// 输入一个属于财税法审核处理范围内的合作状态码，例如财税法交付专业审核状态。
			// 构造数据:
			// coStatus = _const.PreSalesContractFinanceTaxationLegalReview (4)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings。
			// 3. 在 _const.ReviewerTypeFinanceTaxationLegalReviewer 对应的状态列表中找到 coStatus。
			// 4. 函数返回 _const.ReviewerTypeFinanceTaxationLegalReviewer (2)。
			coStatus := _const.PreSalesContractFinanceTaxationLegalReview

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
		})

		mockey.PatchConvey("场景：当coStatus为解决方案审核相关状态时，应返回ReviewerTypeSolutionReviewer", func() {
			// 场景描述:
			// 输入一个属于解决方案审核处理范围内的合作状态码。
			// 构造数据:
			// coStatus = _const.PreSalesContractSolutionReview (101)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings。
			// 3. 在 _const.ReviewerTypeSolutionReviewer 对应的状态列表中找到 coStatus。
			// 4. 函数返回 _const.ReviewerTypeSolutionReviewer (6)。
			coStatus := _const.PreSalesContractSolutionReview

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeSolutionReviewer)
		})

		mockey.PatchConvey("场景：当coStatus为未映射的无效状态时，应返回ReviewerTypeInvalid", func() {
			// 场景描述:
			// 输入一个不在任何角色处理范围内的合作状态码。
			// 构造数据:
			// coStatus = 999 (一个未定义的状态)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings，未找到匹配的状态。
			// 3. 函数返回默认值 _const.ReviewerTypeInvalid (-1)。
			coStatus := 999

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeInvalid)
		})

		mockey.PatchConvey("场景：当coStatus为已定义但未映射的状态时，应返回ReviewerTypeInvalid", func() {
			// 场景描述:
			// 输入一个已知的但不在映射表中的合作状态码，例如已废弃状态。
			// 构造数据:
			// coStatus = _const.PreSalesContractAbandoned (20)
			// 逻辑链路:
			// 1. 调用 GetReviewerTypeByCooperationStatus 函数。
			// 2. 函数遍历 reviewerTypeStatusMappings，未找到匹配的状态。
			// 3. 函数返回默认值 _const.ReviewerTypeInvalid (-1)。
			coStatus := _const.PreSalesContractAbandoned

			// 调用
			result := GetReviewerTypeByCooperationStatus(coStatus)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ReviewerTypeInvalid)
		})
	})
}

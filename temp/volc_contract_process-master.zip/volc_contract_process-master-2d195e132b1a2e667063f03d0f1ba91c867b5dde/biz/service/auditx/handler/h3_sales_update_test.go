package handler

import (
	"code.byted.org/eps-platform/commercialization_sdk_go/sdk/dto/lite"
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/innertopcommercializationcli"
)

// Mock Interfaces

func Test_handlerSalesReviewUpdate_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSalesReviewUpdate Process", t, func() {
		mockey.PatchConvey("happy path: successfully update all contract data", func() {
			// 场景描述：
			// 这是一个完整的成功路径测试，所有依赖的外部调用（如数据库、文件服务、模板服务）都返回成功。
			// 构造数据：
			// - ProcessCtx 包含所有需要更新的信息，如 PreContractVO, ContractInfo, AttachmentUpdateList, DelExtKeys 等。
			// - ManageInfo, TradePartyInfo, SettlementInfo 均有内容，以触发相应的保存逻辑。
			// 逻辑链路：
			// 1. Process 调用 updateContractData。
			// 2. GetTemplateFileId 成功，返回新的 fileId。
			//    - 依赖的 template.GetContractTemplate, UploadFileVolc, updateTemplateFilePermission 均被 mock 为成功。
			// 3. CreateOrUpdateAttachment 成功创建一个新的合同文本附件。
			//    - 依赖的 dal.FindByFileKey 返回 nil，触发创建逻辑，dal.Create 成功。
			// 4. updatePreContract 成功更新合同元数据。
			//    - 依赖的 dal.UpdateFieldsByNo 成功。
			// 5. SaveManageInfo 成功保存管理信息。
			//    - 依赖的 dal.FindByVolcContractId 返回 nil，触发创建逻辑，dal.Create 成功。
			//    - 依赖的 SaveCommodityList, SaveExternalCommodityList, dal.UpdateByMap 均成功。
			// 6. SaveTradePartyInfo 成功保存交易方信息。
			//    - 依赖的 dal.DeleteByVolcContractId 和 dal.BatchCreate 均成功。
			// 7. SaveMetaExt 成功保存扩展信息。
			//    - 依赖的 DeleteMetaExt 和 CreateOrUpdateMetaExt (包括其内部的 dal 调用) 均成功。
			// 8. updateContractSettlement 成功更新结算条款。
			//    - 依赖的 dal.SoftDeleteByContractID 和 dal.BatchCreate 均成功。
			// 9. updateAttachment 成功更新附件信息。
			//    - 依赖的 dal.UpdateByFileKey 成功。
			// 10. 最终 Process 函数返回 nil。

			ctx := context.Background()
			tx := &gorm.DB{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB:       model.BaseDB{Id: 1},
					ContractNo:   "TEST-CN-001",
					TemplateInfo: `{"key":"template_key"}`,
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo: &bizmodels.ManageInfo{
						ProductLevelMap:      make(map[string][]*bizmodels.ProductInfo),
						ProductValidityBegin: "2023-01-01 00:00:00",
						ProductValidityEnd:   "2023-12-31 23:59:59",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					Ext:            map[string]string{"new_key": "new_value"},
					SettlementInfo: &bizmodels.SettlementInfo{
						SettlementLines: []*bizmodels.SettlementLine{
							{InvoicingPercent: "100", InvoicingTotal: "1000", PaymentPercent: "100", PaymentTotal: "1000"},
						},
					},
				},
				AttachmentUpdateList: []*bizmodels.MetaAttachment{
					{DownloadID: "attach-to-update-1"},
				},
				DelExtKeys: []string{"key-to-delete"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()

			mockey.Mock(template.NewService).Return(&MockTemplateService{}).Build()
			mockey.Mock((*MockTemplateService).GetContractTemplate).Return(&templateclient.FillFileData{FileKey: "template-file-key"}, nil).Build()
			mockey.Mock(UploadFileVolc).Return("new-file-id", nil).Build()
			mockey.Mock(updateTemplateFilePermission).Return(nil).Build()

			mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock(dal.NewContractTradePartyDao).Return(&MockContractTradePartyDao{}).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(&MockContractMetaExtDao{}).Build()
			mockey.Mock(dal.NewContractSettlementDao).Return(&MockContractSettlementDao{}).Build()

			mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{Result: &filecli.GetNewestVersionInfo{Name: "contract file"}}, nil).Build()
			mockey.Mock((*MockContractAttachmentDao).Create).Return(nil).Build()

			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(nil).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{}, nil).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()

			mockey.Mock((*MockContractTradePartyDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(model.ConverTradePartyDB).Return(model.ContractTradePartyDBList{}).Build()
			mockey.Mock((*MockContractTradePartyDao).BatchCreate).Return(nil).Build()

			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(nil).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()

			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			h := &handlerSalesReviewUpdate{}
			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error path: updatePreContract fails", func() {
			// 场景描述：
			// 测试在更新流程中，某个关键步骤失败的场景。此处选择 updatePreContract 中的数据库更新操作失败。
			// 构造数据：
			// - ProcessCtx 与成功路径类似，包含 TemplateInfo 以触发主逻辑。
			// 逻辑链路：
			// 1. Process 调用 updateContractData。
			// 2. GetTemplateFileId 及 CreateOrUpdateAttachment 均成功。
			// 3. updatePreContract 调用 dal.UpdateFieldsByNo，此时 mock使其返回一个错误。
			// 4. 错误被捕获并向上传播，导致 Process 函数返回该错误。
			// 5. 后续的保存/更新操作（SaveManageInfo, SaveTradePartyInfo 等）将不会被执行。

			ctx := context.Background()
			tx := &gorm.DB{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB:       model.BaseDB{Id: 1},
					ContractNo:   "TEST-CN-001",
					TemplateInfo: `{"key":"template_key"}`,
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo: &bizmodels.ManageInfo{
						ProductValidityBegin: "2023-01-01 00:00:00",
						ProductValidityEnd:   "2023-12-31 23:59:59",
					},
				},
			}
			expectedErr := errors.New("db error on update")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()

			mockey.Mock(template.NewService).Return(&MockTemplateService{}).Build()
			mockey.Mock((*MockTemplateService).GetContractTemplate).Return(&templateclient.FillFileData{}, nil).Build()
			mockey.Mock(UploadFileVolc).Return("new-file-id", nil).Build()
			mockey.Mock(updateTemplateFilePermission).Return(nil).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{Result: &filecli.GetNewestVersionInfo{Name: "contract file"}}, nil).Build()

			mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
			mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(&model.ContractAttachmentDB{}, nil).Build()
			mockey.Mock((*MockContractAttachmentDao).Update).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(expectedErr).Build()

			h := &handlerSalesReviewUpdate{}
			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("error path: SaveManageInfo fails", func() {
			// 场景描述：
			// 测试在更新流程中，SaveManageInfo步骤失败的场景。
			// 构造数据：
			// - ProcessCtx 与成功路径类似，包含 TemplateInfo 以触发主逻辑。
			// 逻辑链路：
			// 1. Process 调用 updateContractData。
			// 2. GetTemplateFileId, CreateOrUpdateAttachment, updatePreContract 均成功。
			// 3. SaveManageInfo 被调用，其内部依赖 dal.FindByVolcContractId 返回错误。
			// 4. 错误被包装成 APIError 并向上传播，最终导致 Process 函数返回该错误。
			ctx := context.Background()
			tx := &gorm.DB{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB:       model.BaseDB{Id: 1},
					ContractNo:   "TEST-CN-001",
					TemplateInfo: `{"key":"template_key"}`,
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo: &bizmodels.ManageInfo{
						ProductLevelMap:      make(map[string][]*bizmodels.ProductInfo),
						ProductValidityBegin: "2023-01-01 00:00:00",
						ProductValidityEnd:   "2023-12-31 23:59:59",
					},
				},
			}
			expectedErr := errors.New("db error on find manage info")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()

			mockey.Mock(template.NewService).Return(&MockTemplateService{}).Build()
			mockey.Mock((*MockTemplateService).GetContractTemplate).Return(&templateclient.FillFileData{}, nil).Build()
			mockey.Mock(UploadFileVolc).Return("new-file-id", nil).Build()
			mockey.Mock(updateTemplateFilePermission).Return(nil).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{Result: &filecli.GetNewestVersionInfo{Name: "contract file"}}, nil).Build()

			mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
			mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractAttachmentDao).Create).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, expectedErr).Build()

			h := &handlerSalesReviewUpdate{}
			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(errorsV2.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "SaveManageInfoFail")
		})
	})
}

func Test_handlerSalesReviewUpdate_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewUpdate_PostProcess", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// PostProcess函数当前实现为空，直接返回nil。
			// 构造数据：
			// - 初始化一个handlerSalesReviewUpdate实例。
			// - 创建一个空的context.Context。
			// - 创建一个空的auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 调用PostProcess方法。
			// 2. 函数直接返回nil。

			h := &handlerSalesReviewUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewUpdate_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewUpdate_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数直接返回 false 和 nil，没有任何条件判断或外部调用。
			// 构造数据：
			// - 初始化 handlerSalesReviewUpdate 实例。
			// - 准备一个空的 context 和 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回值为 false 和 nil。

			// 准备数据
			h := &handlerSalesReviewUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			got, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSalesReviewUpdate_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewUpdate_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentOp 方法的返回值。
			// 构造数据：
			// 初始化一个 handlerSalesReviewUpdate 实例。
			// 逻辑链路：
			// 1. 创建 handlerSalesReviewUpdate 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于常量 _const.OperationSubmitDraft。
			h := &handlerSalesReviewUpdate{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerSalesReviewUpdate_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewUpdate_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况：应返回预设的状态值", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerSalesReviewUpdate 的实例。
			// 逻辑链路：直接调用 CurrentStatus 方法。
			// 预期结果：方法应返回常量 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewUpdate{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewUpdate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSalesReviewUpdate", t, func() {
		mockey.PatchConvey("should return a non-nil handler of type *handlerSalesReviewUpdate", func() {
			// 场景描述：
			// 验证 newHandlerSalesReviewUpdate 函数能否正确创建一个 *handlerSalesReviewUpdate 类型的实例。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerSalesReviewUpdate()。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerSalesReviewUpdate。

			// 调用目标函数
			handler := newHandlerSalesReviewUpdate()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewUpdate{})
		})
	})
}

func Test_handlerSalesReviewUpdate_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("handlerSalesReviewUpdate.Validate 单测集", t, func() {

		mockey.PatchConvey("模板合同存在且包含副签约主体时返回错误", func() {
			// 构造模板合同且包含副签约主体
			ctx := context.Background()
			h := &handlerSalesReviewUpdate{handlerCommon{}}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CON001",
					TemplateInfo: &bizmodels.TemplateInfo{
						Master: &bizmodels.TemplateDetail{TemplateKey: "tpl", Version: 1},
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
						},
					},
				},
			}

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "使用模板的合同不支持添加副签约主体")

			//mockey.UnPatchAll()
		})

		mockey.PatchConvey("副签约主体未签约时返回错误", func() {
			// 构造副签约主体未签约
			ctx := context.Background()
			h := &handlerSalesReviewUpdate{handlerCommon{}}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CON002",
					TemplateInfo: nil,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.FALSE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
						},
					},
				},
			}

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "副签约主体是否需要签约必须为是")

			//mockey.UnPatchAll()
		})

		mockey.PatchConvey("副签约主体为配价主体时返回错误", func() {
			// 构造副签约主体为配价主体
			ctx := context.Background()
			h := &handlerSalesReviewUpdate{handlerCommon{}}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CON003",
					TemplateInfo: nil,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.TRUE_FLAG_INT, // 非0，表示为配价主体
							},
						},
					},
				},
			}

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "副签约主体是否需要配价必须为否")

			//mockey.UnPatchAll()
		})

		mockey.PatchConvey("满足条件的副签约主体校验通过返回nil", func() {
			// 构造副签约主体符合要求
			ctx := context.Background()
			h := &handlerSalesReviewUpdate{handlerCommon{}}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CON004",
					TemplateInfo: nil,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
						},
					},
				},
			}

			err := h.Validate(ctx, pc)
			convey.So(err, convey.ShouldBeNil)

			//mockey.UnPatchAll()
		})
	})
}

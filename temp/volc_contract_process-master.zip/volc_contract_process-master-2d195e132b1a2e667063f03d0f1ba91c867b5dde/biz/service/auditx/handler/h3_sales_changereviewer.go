package handler

import (
	"context"
	"volc_contract_process/biz/service/riskclauserole"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSalesReviewChangeReviewer() StatusOpHandler {
	return &handlerSalesReviewChangeReviewer{}
}

// 销售运营专业审核(3) --- 转办(6) --> 销售运营专业审核(3)
type handlerSalesReviewChangeReviewer struct {
	handlerCommon
}

func (h *handlerSalesReviewChangeReviewer) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewChangeReviewer) CurrentOp() int {
	return _const.OperationChangeReviewer
}

func (h *handlerSalesReviewChangeReviewer) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerSalesReviewChangeReviewer) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 风险条款创建人转办
	return riskclauserole.NewService().ChangeRiskRoleCreator(ctx, pc.ContractInfo.ContractNo, pc.Extra, []string{pc.CurrentOperator})
}

func (h *handlerSalesReviewChangeReviewer) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerSalesReviewChangeReviewer) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

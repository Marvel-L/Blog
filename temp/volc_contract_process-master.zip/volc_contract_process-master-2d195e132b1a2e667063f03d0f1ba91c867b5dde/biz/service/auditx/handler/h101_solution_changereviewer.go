package handler

import (
	"context"
	"volc_contract_process/biz/service/riskclauserole"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSolutionChangeViewers() StatusOpHandler {
	return &handlerSolutionChangeViewers{}
}

// 解决方案审核(101) --- 转办(6) --> 解决方案审核(101)
type handlerSolutionChangeViewers struct {
	handlerCommon
}

func (h handlerSolutionChangeViewers) CurrentStatus() int {
	return _const.PreSalesContractSolutionReview
}

func (h handlerSolutionChangeViewers) CurrentOp() int {
	return _const.OperationChangeReviewer
}

func (h handlerSolutionChangeViewers) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h handlerSolutionChangeViewers) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 风险条款创建人转办
	return riskclauserole.NewService().ChangeRiskRoleCreator(ctx, pc.ContractInfo.ContractNo, pc.Extra, []string{pc.CurrentOperator})
}

func (h handlerSolutionChangeViewers) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h handlerSolutionChangeViewers) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

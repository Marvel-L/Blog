package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	quoteservice "volc_contract_process/biz/service/support/quote"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/pkg/const"
)

func Test_handlerMultiAbandon_PostProcess_BitsUTGen(t *testing.T) {
	// 定义用于Mock接口的结构体
	type MockQuoteService struct {
		quoteservice.Service
	}
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}

	mockey.PatchConvey("Test handlerMultiAbandon PostProcess", t, func() {
		// 准备通用变量
		h := &handlerMultiAbandon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				RelateQuoteNo: "test-quote-123",
				ContractNo:    "test-contract-456",
			},
			PreContractVO: &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Id: 1001,
				},
			},
		}

		mockQuoteSvc := &MockQuoteService{}
		mockDao := &MockContractMetaDao{}

		mockey.PatchConvey("正常处理：成功解除绑定并更新数据库", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同信息和先前合同视图对象的ProcessCtx。
			// 逻辑链路：
			// 1. Mock quoteservice.NewService() 返回一个mock service实例。
			// 2. Mock service实例的 UnbindQuote 方法，模拟成功解除报价单绑定。
			// 3. Mock dal.NewContractMetaDao() 返回一个mock dao实例。
			// 4. Mock pc.GetTx() 返回一个gorm.DB实例。
			// 5. Mock dao实例的 UpdateByMap 方法返回nil，模拟数据库更新成功。
			// 6. 目标函数应成功执行并返回nil。

			mockey.Mock(quoteservice.NewService).Return(mockQuoteSvc).Build()
			mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, nil).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("异常处理：更新数据库失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同信息和先前合同视图对象的ProcessCtx。
			// 逻辑链路：
			// 1. Mock quoteservice.NewService() 和 UnbindQuote 方法，模拟成功解除绑定。
			// 2. Mock dal.NewContractMetaDao() 返回一个mock dao实例。
			// 3. Mock pc.GetTx() 返回一个gorm.DB实例。
			// 4. Mock dao实例的 UpdateByMap 方法返回一个error，模拟数据库更新失败。
			// 5. 目标函数应捕获并返回该error。

			dbErr := errors.New("database update failed")
			mockey.Mock(quoteservice.NewService).Return(mockQuoteSvc).Build()
			mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, nil).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(dbErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database update failed")
		})

		mockey.PatchConvey("异常处理：消息通知执行失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同信息和先前合同视图对象的ProcessCtx。
			// 逻辑链路：
			// 1. Mock quoteservice.NewService() 返回一个mock service实例。
			// 2. Mock service实例的 UnbindQuote 方法，模拟成功解除报价单绑定。
			// 3. Mock dal.NewContractMetaDao() 返回一个mock dao实例。
			// 4. Mock pc.GetTx() 返回一个gorm.DB实例。
			// 5. Mock dao实例的 UpdateByMap 方法返回nil，模拟数据库更新成功。
			// 6. 目标函数应成功执行并返回nil。

			mockey.Mock(quoteservice.NewService).Return(mockQuoteSvc).Build()
			mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, nil).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()
			mockey.Mock((*handlerMultiAbandon).complianceCheckNotify).Return(fmt.Errorf("complianceCheckNotify failed")).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("异常处理：解除绑定失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同信息和先前合同视图对象的ProcessCtx。
			// 逻辑链路：
			// 1. Mock quoteservice.NewService() 返回一个mock service实例。
			// 2. Mock service实例的 UnbindQuote 方法，模拟成功解除报价单绑定。
			// 3. Mock dal.NewContractMetaDao() 返回一个mock dao实例。
			// 4. Mock pc.GetTx() 返回一个gorm.DB实例。
			// 5. Mock dao实例的 UpdateByMap 方法返回nil，模拟数据库更新成功。
			// 6. 目标函数应成功执行并返回nil。

			mockey.Mock(quoteservice.NewService).Return(mockQuoteSvc).Build()
			mockey.Mock(quotecli.UnbindQuoteContract).Return(nil, errors.New("unbind quote contract failed")).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerMultiAbandon_SupportStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_SupportStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 该函数没有外部依赖和复杂逻辑，仅返回一个固定的状态列表。
			// 构造数据：初始化一个 handlerMultiAbandon 实例。
			// 逻辑链路：
			// 1. 调用 SupportStatus 方法。
			// 2. 断言返回值是否与预期的状态列表一致。

			// 准备数据
			h := &handlerMultiAbandon{}

			// 调用
			result := h.SupportStatus()

			// 断言
			expected := []int{
				_const.PreSalesContractNotCreated,
				_const.PreSalesContractDraft,
				_const.PreSalesContractSendBack,
				_const.PreSalesContractCustomerConfirm,
				_const.PreSalesContractComplianceCheck,
			}
			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_newHandlerMultiAbandon_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerMultiAbandon", t, func() {
		mockey.PatchConvey("should return a non-nil handlerMultiAbandon instance", func() {
			// 场景描述：
			// 测试 newHandlerMultiAbandon 函数是否能成功创建一个新的处理器实例。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerMultiAbandon 函数。
			// 2. 断言返回的结果不为 nil。
			// 3. 断言返回的结果类型为 *handlerMultiAbandon。

			// 调用
			handler := newHandlerMultiAbandon()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerMultiAbandon{})
		})
	})
}

func Test_handlerMultiAbandon_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_CurrentStatus", t, func() {
		mockey.PatchConvey("should panic as expected", func() {
			// 场景描述:
			// CurrentStatus 方法被设计为不应被调用，直接触发 panic。
			// 构造数据:
			// 初始化一个 handlerMultiAbandon 实例。
			// 逻辑链路:
			// 1. 创建 handlerMultiAbandon 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言函数调用会触发 panic，并验证 panic 的信息是否符合预期。

			// 准备数据
			h := &handlerMultiAbandon{}

			// 调用和断言
			convey.So(func() {
				h.CurrentStatus()
			}, convey.ShouldPanicWith, "unexpected call MultiStatusOpHandler CurrentStatus() method")
		})
	})
}

func Test_handlerMultiAbandon_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationAbandon", func() {
			// 场景描述:
			// 测试 handlerMultiAbandon 的 CurrentOp 方法，验证其是否正确返回作废操作的常量。
			// 构造数据:
			// 初始化一个空的 handlerMultiAbandon 实例。
			// 逻辑链路:
			// 1. 创建 handlerMultiAbandon 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationAbandon。

			// 准备数据
			h := &handlerMultiAbandon{}

			// 调用目标函数
			op := h.CurrentOp()

			// 断言结果
			convey.So(op, convey.ShouldEqual, _const.OperationAbandon)
		})
	})
}

func Test_handlerMultiAbandon_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_Validate", t, func() {
		mockey.PatchConvey("场景: 正常调用，应始终返回nil", func() {
			// 场景描述:
			// 目标函数 Validate 的实现非常简单，它不执行任何逻辑，总是直接返回 nil。
			// 本测试用例旨在验证这一基本行为。
			// 构造数据:
			// - h: 一个空的 handlerMultiAbandon 实例。
			// - ctx: 一个 background context。
			// - pc: 一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路:
			// 1. 直接调用 h.Validate 方法。
			// 2. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerMultiAbandon{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerMultiAbandon_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_Process", t, func() {
		mockey.PatchConvey("normal case: should always return nil", func() {
			// 场景描述：
			// 这是一个非常简单的函数，其实现直接返回nil。
			// 构造数据：
			// - 初始化一个handlerMultiAbandon实例。
			// - 初始化一个空的ProcessCtx。
			// 逻辑链路：
			// - 调用Process方法。
			// - 断言返回的error为nil。

			// 数据准备
			h := &handlerMultiAbandon{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerMultiAbandon_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述:
			// 目标函数 HitStateChangeCondition 的实现是静态返回 true 和 nil，不依赖于任何输入参数或外部服务。
			// 构造数据:
			// - 初始化一个 handlerMultiAbandon 实例。
			// - 创建一个空的 context.Context。
			// - 创建一个空的 auditmodel.ProcessCtx。
			// 逻辑链路:
			// 1. 调用目标函数 HitStateChangeCondition。
			// 2. 断言返回的布尔值为 true。
			// 3. 断言返回的 error 为 nil。

			h := &handlerMultiAbandon{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerMultiAbandon_complianceCheckNotify(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAbandon_complianceCheckNotify", t, func() {
		h := &handlerMultiAbandon{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: 合同信息为nil, 直接跳过", func() {
			// 场景描述：
			// 构造数据：pc.ContractInfo 为 nil
			// 逻辑链路：
			// 1. 函数入口的 if pc.ContractInfo == nil 条件成立
			// 2. 调用 logs.CtxInfo 打印日志
			// 3. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: nil,
			}

			err := h.complianceCheckNotify(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 合同状态不是合规审查, 直接跳过", func() {
			// 场景描述：
			// 构造数据：pc.ContractInfo.CooperationStatus 不等于 PreSalesContractComplianceCheck
			// 逻辑链路：
			// 1. 函数入口的 if pc.ContractInfo.CooperationStatus != _const.PreSalesContractComplianceCheck 条件成立
			// 2. 调用 logs.CtxInfo 打印日志
			// 3. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 0, // 任意一个不等于 PreSalesContractComplianceCheck 的值
				},
			}

			err := h.complianceCheckNotify(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 合同前序状态不匹配, 跳过飞书通知, C360通知成功", func() {
			// 场景描述：
			// 构造数据：pc.ContractInfo.CooperationStatus 为 PreSalesContractComplianceCheck, 但 pc.ContractInfo.PreCooperationStatus 不等于 PreSalesContractSalesOperationCompleteInformation
			// 逻辑链路：
			// 1. 函数入口的 if 条件不成立
			// 2. 发送飞书消息的 if 条件 pc.ContractInfo.PreCooperationStatus == ... 不成立
			// 3. 调用 h.notifyC360
			// 4. Mock h.notifyC360 返回 nil
			// 5. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:    _const.PreSalesContractComplianceCheck,
					PreCooperationStatus: 0, // 不等于 PreSalesContractSalesOperationCompleteInformation
					ContractNo:           "test-contract-001",
					ContractName:         "test-name-001",
				},
				OperationState:     _const.OperationSendBack,
				StatusChangedValue: _const.PreSalesContractAbandoned,
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "comment text",
				},
			}

			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.complianceCheckNotify(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 所有条件满足, 飞书和C360通知均成功", func() {
			// 场景描述：
			// 构造数据：pc.ContractInfo.CooperationStatus 和 pc.ContractInfo.PreCooperationStatus 均满足条件
			// 逻辑链路：
			// 1. 函数入口的 if 条件不成立
			// 2. 发送飞书消息的 if 条件成立
			// 3. 调用 h.getReviewerFromPreContractReviewerListWithContractStatus 获取审批人
			// 4. 调用 message.BatchSendMessageToEmailIgnore 发送飞书消息
			// 5. 调用 h.notifyC360
			// 6. Mock h.notifyC360 返回 nil
			// 7. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:    _const.PreSalesContractComplianceCheck,
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					ContractNo:           "test-contract-002",
					ContractName:         "test-name-002",
					OtherPartyName:       "other party",
					Operator:             "operator@example.com",
					Status:               _const.PreSalesContractAbandoned,
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "reviewer@example.com",
							ReviewerType:   _const.ReviewerTypeSalesOperation,
							ContractStatus: _const.PreSalesContractSalesOperationCompleteInformation,
						},
					},
				},
				OperationState:     _const.OperationSendBack,
				StatusChangedValue: _const.PreSalesContractAbandoned,
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "comment text",
				},
			}

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.complianceCheckNotify(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: C360通知失败, 返回错误", func() {
			// 场景描述：
			// 构造数据：所有条件都满足，但C360通知失败
			// 逻辑链路：
			// 1. 函数入口和飞书消息的 if 条件均成立
			// 2. 正常调用飞书消息发送
			// 3. 调用 h.notifyC360
			// 4. Mock h.notifyC360 返回一个错误
			// 5. 函数返回该错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:    _const.PreSalesContractComplianceCheck,
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					ContractNo:           "test-contract-003",
					ContractName:         "test-name-003",
				},
			}
			expectedErr := fmt.Errorf("notify c360 failed")

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(expectedErr).Build()

			err := h.complianceCheckNotify(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})
	})
}

package handler

import (
	"context"
	"strconv"
	"strings"

	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/rediscli"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	utils "volc_contract_process/pkg/util"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerHaveChangeSubmit() StatusOpHandler {
	return &handlerHaveChangeSubmit{}
}

// 有修改(6) --- 提交修改(11) --> 财税法交付专业审核(4)
type handlerHaveChangeSubmit struct {
	handlerCommon
}

func (h *handlerHaveChangeSubmit) CurrentStatus() int {
	return _const.PreSalesContractChange
}

func (h *handlerHaveChangeSubmit) CurrentOp() int {
	return _const.OperationSubmitChange
}

func (h *handlerHaveChangeSubmit) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 客户有修改阶段 不需要校验
	// if err := h.validateRequireQuote(ctx, pc); err != nil {
	//	return err
	// }

	return nil
}

func (h *handlerHaveChangeSubmit) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerHaveChangeSubmit) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerHaveChangeSubmit) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 移除更换报价单记录
	_ = rediscli.RemoveQuoteChangeInfoFlag(ctx, pc.ContractInfo.ContractNo)
	// 发送飞书消息给合同创建人
	h.sendMsgToCreator(ctx, pc)
	// 通知 C360
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSendBackSubmit, pc)
	// 发送飞书消息
	multiCtx := context.Background()
	allEmails := h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeFinanceTaxationLegalReviewer, pc.StatusChangedValue)
	logs.CtxInfo(ctx, "handlerHaveChangeSubmit_PostProcess, allEmails=%v, skipReturnReviewNoAuditEmails=%v", allEmails, pc.SkipReturnReviewNoAuditEmails)
	allEmails = h.removeSkipReturnReviewNoAuditEmails(allEmails, pc.SkipReturnReviewNoAuditEmails)
	if len(allEmails) == 0 {
		return nil
	}
	larkc.BatchSendMessageToEmailIgnore(ctx,
		allEmails,
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
	return nil
}

func (h *handlerHaveChangeSubmit) sendMsgToCreator(ctx context.Context, pc *auditmodel.ProcessCtx) {

	contractInfo := pc.ContractInfo
	employeeIDList := []string{contractInfo.Creator, contractInfo.Operator}
	list, err := larkc.GetEmployeeByEmployeeIDsWithCache(ctx, employeeIDList)
	if err != nil {
		logs.CtxWarn(ctx, "sendMsgToCreator, GetEmployeeByEmployeeIDsFail, employeeIDList=%v, err=%s", employeeIDList, err.Error())
		return
	}
	var (
		creatorEmail, operatorEmail string
	)
	for _, emp := range list {
		idStr := strconv.Itoa(emp.ID)
		if idStr == contractInfo.Creator {
			creatorEmail = emp.Email
		}
		if idStr == contractInfo.Operator {
			operatorEmail = emp.Email
		}
	}
	if operatorEmail == "" {
		logs.CtxWarn(ctx, "sendMsgToCreator, operatorEmail is empty")
		return
	}
	multiCtx := context.Background()
	_ = larkc.SendMessageToEmail(ctx,
		creatorEmail,
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同发起人已提交返稿审核")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同已提交客户修改版本返稿审核，请关注！", larkc.LarkMdAtEmail(operatorEmail))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "查看详情"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
}

func (h *handlerHaveChangeSubmit) removeSkipReturnReviewNoAuditEmails(all []string, skipList []string) []string {
	if len(skipList) == 0 {
		return all
	}
	skipMap := make(map[string]struct{})
	for _, email := range skipList {
		skipMap[email] = struct{}{}
	}
	var res []string
	for _, email := range all {
		if _, ok := skipMap[email]; ok {
			continue
		}
		res = append(res, email)
	}
	return res
}

func (h *handlerHaveChangeSubmit) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	changeInfo, _ := rediscli.GetQuoteChangeInfo(ctx, pc.ContractInfo.ContractNo)
	if changeInfo != nil && changeInfo.RelateQuoteChanged {
		// 存在未审核通过的风险条款
		return _const.ApprovalStatusKeyMultiChangeQuote
	}
	return _const.ApprovalStatusKeyDefault
}

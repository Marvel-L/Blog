package handler

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/pkg/const"
)

func Test_handlerDraftDelete_PostProcess_BitsUTGen(t *testing.T) {
	// MockContractMetaDao is a mock type for the dal.ContractMetaDao interface.
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}

	mockey.PatchConvey("Test handlerDraftDelete PostProcess", t, func() {
		h := &handlerDraftDelete{}
		ctx := context.Background()

		mockey.PatchConvey("success: should delete contract meta and return nil", func() {
			// 场景描述：
			// 成功删除合同元数据。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx 实例，其中 ContractInfo 包含有效的 ContractNo。
			// - mockTx: 一个 gorm.DB 的模拟实例。
			// 逻辑链路：
			// 1. Mock pc.GetTx() 方法返回 mockTx。
			// 2. Mock dal.NewContractMetaDao() 返回一个 MockContractMetaDao 的实例。
			// 3. Mock (*MockContractMetaDao).DeleteByNo 方法，使其在被调用时返回 nil，表示删除成功。
			// 4. 调用目标函数 PostProcess。
			// 5. 断言返回的 error 为 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST_CONTRACT_NO_SUCCESS",
				},
			}
			mockTx := &gorm.DB{}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).DeleteByNo).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: should return error when DeleteByNo fails", func() {
			// 场景描述：
			// 删除合同元数据时数据库操作失败。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx 实例，其中 ContractInfo 包含有效的 ContractNo。
			// - mockTx: 一个 gorm.DB 的模拟实例。
			// - dbErr: 一个预定义的 error，用于模拟数据库错误。
			// 逻辑链路：
			// 1. Mock pc.GetTx() 方法返回 mockTx。
			// 2. Mock dal.NewContractMetaDao() 返回一个 MockContractMetaDao 的实例。
			// 3. Mock (*MockContractMetaDao).DeleteByNo 方法，使其在被调用时返回预定义的 dbErr。
			// 4. 调用目标函数 PostProcess。
			// 5. 断言返回的 error 不为 nil，并且错误信息包含预设的错误字符串。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST_CONTRACT_NO_FAILURE",
				},
			}
			mockTx := &gorm.DB{}
			dbErr := errors.New("mock db delete error")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).DeleteByNo).Return(dbErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock db delete error")
		})
	})
}

func Test_newHandlerDraftDelete_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerDraftDelete", t, func() {
		mockey.PatchConvey("正常场景: 成功创建一个 handlerDraftDelete 实例", func() {
			// 场景描述:
			// newHandlerDraftDelete 是一个简单的工厂函数，用于创建一个 handlerDraftDelete 实例并返回 StatusOpHandler 接口。
			// 本测试用例验证该函数是否能正确创建并返回预期的实例。
			// 构造数据:
			// 无需构造特定数据。
			// 逻辑链路:
			// 1. 调用 newHandlerDraftDelete() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的具体类型是 *handlerDraftDelete。

			// 调用目标函数
			handler := newHandlerDraftDelete()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerDraftDelete{})
		})
	})
}

func Test_handlerDraftDelete_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftDelete_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况-返回预设的草稿状态", func() {
			// 场景描述：
			// 这是一个简单的方法，它不依赖于任何外部服务或动态数据，总是返回一个硬编码的常量。
			// 构造数据：
			// - 创建一个`handlerDraftDelete`的实例。
			// 逻辑链路：
			// 1. 调用`CurrentStatus`方法。
			// 2. 断言返回的状态码是否等于`_const.PreSalesContractDraft`。

			// 准备数据
			h := &handlerDraftDelete{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractDraft)
		})
	})
}

func Test_handlerDraftDelete_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftDelete_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况: 应返回删除操作的常量值", func() {
			// 场景描述：
			// 构造一个 handlerDraftDelete 实例，并调用其 CurrentOp 方法。
			// 逻辑链路：
			// 1. 创建 handlerDraftDelete 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationDelete。

			// 数据准备
			h := &handlerDraftDelete{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationDelete)
		})
	})
}

func Test_handlerDraftDelete_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerDraftDelete.Validate", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerDraftDelete 实例和空的上下文、ProcessCtx。
			// 逻辑链路：
			// 1. 调用 Validate 方法。
			// 2. 由于函数体直接返回 nil，预期得到一个 nil error。
			// 3. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerDraftDelete{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerDraftDelete_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftDelete_Process", t, func() {
		mockey.PatchConvey("正常执行，返回nil", func() {
			// 场景描述：
			// 目标函数是一个空实现，直接返回 nil。
			// 构造数据：
			// - 构造一个空的 handlerDraftDelete 实例。
			// - 构造一个 background context。
			// - 构造一个空的 ProcessCtx 实例。
			// 逻辑链路：
			// - 直接调用 Process 方法，预期不执行任何操作并返回 nil。

			// 准备数据
			h := &handlerDraftDelete{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerDraftDelete_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftDelete_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should return false and nil", func() {
			// 场景描述：
			// 目标函数 `HitStateChangeCondition` for `handlerDraftDelete` 总是直接返回 `false` 和 `nil`。
			// 构造数据：
			// - 一个 `handlerDraftDelete` 的实例。
			// - 一个空的 `context.Context`。
			// - 一个空的 `auditmodel.ProcessCtx`。
			// 逻辑链路：
			// 1. 调用 `HitStateChangeCondition` 方法。
			// 2. 验证返回的布尔值是 `false`。
			// 3. 验证返回的错误是 `nil`。

			h := &handlerDraftDelete{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			got, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeFalse)
		})
	})
}

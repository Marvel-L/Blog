package handler

import (
	"volc_contract_process/biz/service/multienv"
	_const "volc_contract_process/pkg/const"
)

/**审批流程处理*/

// AllHandlers 支持的处理器列表
//
//	handlerNotCreateSubmitDraft             : 未创建(0)     --- 提交草稿(0)    --> 草稿(1)
//	handlerMultiAbandon                     : 未创建(0)     --- 作废合同(15)   --> 已废弃，与业务合同中心保持一致(20)
//	handlerDraftDelete                      : 草稿(1)      --- 删除草稿(14)   --> 未创建(0)
//	handlerDraftUpdate                      : 草稿(1)      --- 提交草稿(0)    --> 草稿(1)
//	handlerDraftSubmitPreContract           : 草稿(1)      --- 提交在线协同(1)  --> 销售运营专业审核(3)
//	handlerMultiAbandon                     : 草稿(1)      --- 作废合同(15)   --> 已废弃，与业务合同中心保持一致(20)
//	handlerSendBackUpdate                   : 已退回(2)     --- 提交草稿(0)    --> 已退回(2)
//	handlerMultiChangeQuote                 : 已退回(2)     --- 变更报价单(16)  --> 已退回(2)
//	handlerSendBackSubmit                   : 已退回(2)     --- 提交在线协同(1)  --> 销售运营专业审核(3)
//	handlerMultiAbandon                     : 已退回(2)     --- 作废合同(15)   --> 已废弃，与业务合同中心保持一致(20)
//	handlerSalesReviewWithdrawPreContract   : 销售运营专业审核(3)  --- 撤回(8)      --> 草稿(1)
//	handlerSalesReviewSendBack              : 销售运营专业审核(3)  --- 退回(4)      --> 已退回(2)
//	handlerSalesReviewChangeReviewer        : 销售运营专业审核(3)  --- 转办(6)      --> 销售运营专业审核(3)
//	handlerSalesReviewAddReviewers          : 销售运营专业审核(3)  --- 加签(5)      --> 销售运营专业审核(3)
//	handlerSalesReviewUpdate                : 销售运营专业审核(3)  --- 提交草稿(0)    --> 销售运营专业审核(3)
//	handlerMultiAcquireReviewer             : 销售运营专业审核(3)  --- 分配给我(17)   --> 销售运营专业审核(3)
//	handlerSalesReviewWithdraw              : 销售运营专业审核(3)  --- 审核撤回(3)    --> 销售运营专业审核(3)
//	handlerMultiChangeQuote                 : 销售运营专业审核(3)  --- 变更报价单(16)  --> 销售运营专业审核(3)
//	handlerSalesReviewPass                  : 销售运营专业审核(3)  --- 审核通过(2)    --> 财税法交付专业审核(4)
//	handlerFTLReviewSendBack                : 财税法交付专业审核(4)   --- 退回(4)      --> 销售运营专业审核(3)
//	handlerMultiAcquireReviewer             : 财税法交付专业审核(4)   --- 分配给我(17)   --> 财税法审核(4)
//	handlerFTLReviewChangeReviewer          : 财税法交付专业审核(4)   --- 转办(6)      --> 财税法审核(4)
//	handlerFTLReviewWithdraw                : 财税法交付专业审核(4)   --- 审核撤回(3)    --> 财税法审核(4)
//	handlerMultiChangeQuote                 : 财税法交付专业审核(4)   --- 变更报价单(16)  --> 财税法审核(4)
//	handlerFTLReviewAddReviewers            : 财税法交付专业审核(4)   --- 加签(5)      --> 财税法审核(4)
//	handlerFTLReviewPass                    : 财税法交付专业审核(4)   --- 审核通过(2)    --> 销售确认中(5)
//	handlerMultiChangeQuote                 : 销售确认中(5)   --- 变更报价单(16)  --> 销售确认中(5)
//	handlerConfirmHaveChange                : 销售确认中(5)   --- 有修改(10)    --> 有修改(6)
//	handlerConfirmFinalized                 : 销售确认中(5)   --- 可定稿(9)     --> 销售运营完善信息(7)
//	handlerMultiAbandon                     : 销售确认中(5)   --- 作废合同(15)   --> 已废弃，与业务合同中心保持一致(20)
//	handlerHaveChangeSubmit                 : 有修改(6)     --- 提交修改(11)   --> 财税法交付专业审核(4)
//	handlerHaveChangeCancel                 : 有修改(6)     --- 取消有修改(12)  --> 销售确认中(5)
//	handlerMultiChangeQuote                 : 有修改(6)     --- 变更报价单(16)  --> 有修改(6)
//	handlerInformationSendBack              : 销售运营完善信息(7) --- 退回(4)      --> 销售确认中(5)
//	handlerMultiChangeQuote                 : 销售运营完善信息(7) --- 变更报价单(16)  --> 销售运营完善信息(7)
//	handlerInformationUpdate                : 销售运营完善信息(7) --- 提交草稿(0)    --> 销售运营完善信息(7)
//	handlerInformationSubmitOA              : 销售运营完善信息(7) --- 提交OA(13)   --> 提交OA(8)
func AllHandlers() []StatusOpHandler {
	return []StatusOpHandler{
		// 多节点通用
		// newHandlerMultiChangeQuote(),     // 修改报价单
		newHandlerMultiAbandon(),         // 作废
		newHandlerMultiAcquireReviewer(), // 分配给我

		// 未创建
		newHandlerNotCreateSubmitDraft(), // 提交草稿

		// 草稿
		newHandlerDraftDelete(),            // 删除草稿
		newHandlerDraftSubmitPreContract(), // 提交在线协同
		newHandlerDraftUpdate(),            // 更新草稿
		newHandlerDraftSubmitOA(),          // 提交OA，仅用于自采合同场景

		// 已退回
		newHandlerSendBackSubmit(), // 提交在线协同
		newHandlerSendBackUpdate(), // 仅更新

		// 销售运营审批
		newHandlerSalesReviewPass(),                // 审批通过
		newHandlerSalesReviewSendBack(),            // 退回
		newHandlerSalesReviewAddReviewers(),        // 加签
		newHandlerSalesReviewChangeReviewer(),      // 转办
		newHandlerSalesReviewWithdrawPreContract(), // 撤回协同审批
		newHandlerSalesReviewUpdate(),              // 更新
		newHandlerSalesReviewWithdraw(),            // 撤回审核
		newHandlerSalesReviewPassSkip(),            // 通过-跳过财税法审批

		// 财税法交付专业审核
		newHandlerFTLReviewPass(),           // 审批通过
		newHandlerFTLReviewSendBack(),       // 退回
		newHandlerFTLReviewAddReviewers(),   // 加签
		newHandlerFTLReviewChangeReviewer(), // 转办
		newHandlerFTLReviewWithdraw(),       // 撤回

		// 销售确认中
		newHandlerConfirmHaveChange(), // 有修改
		newHandlerConfirmFinalized(),  // 可定稿
		newHandlerConfirmSendback(),   // 退回

		// 有修改
		newHandlerHaveChangeUpdate(), // 保存
		newHandlerHaveChangeSubmit(), // 提交修改
		newHandlerHaveChangeCancel(), // 取消修改

		// 销售运营完善信息
		newHandlerInformationSubmitOA(),     // 提交OA
		newHandlerInformationSendBack(),     // 退回
		newHandlerInformationUpdate(),       // 更新
		newHandlerInformationSendBackSkip(), // 退回-跳过财税法审批
		newHandlerInformationPass(),         // 审批通过

		// 财税法签约审核
		newHandlerFTLSignReviewAddReviewers(),   // 加签
		newHandlerFTLSignReviewChangeReviewer(), // 转办
		newHandlerFTLSignReviewPass(),           // 审批通过
		newHandlerFTLSignSendBack(),             // 退回
		newHandlerFTLSignReviewWithdraw(),       // 撤回

		// 风险条款审核
		newHandlerRiskSendBack(), // 退回
		newHandlerRiskSubmitOA(), // 提交OA
		newHandlerRiskTurnDown(), // 驳回

		// 解决方案审批
		newHandlerSolutionReviewPass(),    // 审批通过
		newHandlerSolutionWithdraw(),      // 审批撤回
		newHandlerSolutionSendBack(),      // 退回
		newHandlerSolutionAddViewers(),    // 加签
		newHandlerSolutionChangeViewers(), // 转办

		// 合规审查中
		newHandlerComplianceCheckPass(), // 合规审查通过
	}
}

func GetReviewerTypeByCooperationStatus(coStatus int) int {
	for k, status := range _const.ReviewerTypeStatusMappings {
		for _, v := range status {
			if v == coStatus {
				return k
			}
		}
	}
	return _const.ReviewerTypeInvalid
}

func GetReviewerTypeStatusMappings(approvalKey string) map[int][]int {
	if approvalKey == _const.ApprovalKeyCooperationSelfPurchase {
		return map[int][]int{
			// 销售人员
			_const.ReviewerTypeSalesperson: {
				_const.PreSalesContractNotCreated, // 未创建
				_const.PreSalesContractDraft,      // 草稿
			},
		}
	}
	if multienv.IsBytePlus() || approvalKey == _const.ApprovalKeyCooperationQuote {
		return _const.ReviewerTypeStatusBPMappings
	}
	return _const.ReviewerTypeStatusMappings
}

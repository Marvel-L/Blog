package handler

import (
	"context"
	"strings"

	"volc_contract_process/pkg/proxy/larkc"

	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	utils "volc_contract_process/pkg/util"
)

func newHandlerSendBackSubmit() StatusOpHandler {
	return &handlerSendBackSubmit{}
}

// 已退回(2) --- 提交在线协同(1) --> 销售运营专业审核(3)
type handlerSendBackSubmit struct {
	handlerCommon
}

func (h *handlerSendBackSubmit) CurrentStatus() int {
	return _const.PreSalesContractSendBack
}

func (h *handlerSendBackSubmit) CurrentOp() int {
	return _const.OperationSubmitPreContract
}

func (h *handlerSendBackSubmit) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	if pc.ContractInfo == nil {
		return i18nfmt.New(ctx, "合同协同记录不存在")
	}

	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}

	if err := h.validateRequireQuote(ctx, pc); err != nil {
		return err
	}

	return nil
}

func (h *handlerSendBackSubmit) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		return err
	}

	// 创建协同审批条目
	if err := h.updateContractReviewers(ctx, pc); err != nil {
		return err
	}

	return nil
}

func (h *handlerSendBackSubmit) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h handlerSendBackSubmit) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 通知报价系统绑定、解绑合同 出错时 仅提供报报警
	if err := h.handleQuoteChangeWhenSubmit(ctx, pc); err != nil {
		return err
	}
	// 发送飞书消息
	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, pc.StatusChangedValue),
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())

	// 通知 C360
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSendBackSubmit, pc)
	return nil
}

package handler

import (
	"context"
	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerNotCreateSubmitDraft() StatusOpHandler {
	return &handlerNotCreateSubmitDraft{}
}

// 未创建(0) --- 提交草稿(0) --> 草稿(1)
type handlerNotCreateSubmitDraft struct {
	handlerCommon
}

func (h *handlerNotCreateSubmitDraft) CurrentStatus() int {
	return _const.PreSalesContractNotCreated
}

func (h *handlerNotCreateSubmitDraft) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerNotCreateSubmitDraft) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}
	return nil
}

func (h *handlerNotCreateSubmitDraft) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerNotCreateSubmitDraft) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerNotCreateSubmitDraft) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

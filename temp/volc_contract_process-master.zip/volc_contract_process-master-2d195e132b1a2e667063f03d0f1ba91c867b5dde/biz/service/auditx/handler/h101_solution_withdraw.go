package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSolutionWithdraw() StatusOpHandler {
	return &handlerSolutionWithdraw{}
}

// 解决方案审核(101) --- 审核撤回(3) --> 解决方案审核(101)
type handlerSolutionWithdraw struct {
	handlerCommon
}

func (h handlerSolutionWithdraw) CurrentStatus() int {
	return _const.PreSalesContractSolutionReview
}

func (h handlerSolutionWithdraw) CurrentOp() int {
	return _const.OperationReviewWithdraw
}

func (h handlerSolutionWithdraw) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h handlerSolutionWithdraw) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h handlerSolutionWithdraw) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

func (h handlerSolutionWithdraw) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

package handler

import (
	"context"
	"encoding/json"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/supply"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"

	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"time"
	"volc_contract_process/biz/dal"
)

func Test_handlerDraftUpdate_Validate_BitsUTGen(t *testing.T) {
	// MockMetaService is a mock for the contractmeta.MetaService interface.
	type MockMetaService struct {
		contractmeta.MetaService
	}

	// MockSupplyService is a mock for the supply.SupplyService interface.
	type MockSupplyService struct {
		supply.SupplyService
	}

	mockey.PatchConvey("Test_handlerDraftUpdate_Validate", t, func() {
		h := &handlerDraftUpdate{}
		ctx := context.Background()

		mockey.PatchConvey("Scenario: Not a supplementary agreement", func() {
			// Scene description:
			// The contract is not a supplementary agreement because PreContractVO.SupplySource is empty.
			// Logic path:
			// 1. The Validate method calls validateSupply.
			// 2. In validateSupply, the condition `len(contractDB.SupplySource) == 0` is true.
			// 3. The MainContractNo fields in pc.PreContractVO and pc.ContractInfo are set to the current contract number.
			// 4. The function returns nil.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource: "",
					ContractNo:   "CONTRACT-001",
				},
				ContractInfo: &model.ContractMeta{},
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "CONTRACT-001")
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "CONTRACT-001")
		})

		mockey.PatchConvey("Scenario: Supplementary agreement with empty FromContractNo", func() {
			// Scene description:
			// The contract is a supplementary agreement, but the original contract number (FromContractNo) is missing.
			// Logic path:
			// 1. In validateSupply, `len(contractDB.SupplySource) == 0` is false.
			// 2. The condition `contractDB.FromContractNo == ""` is true.
			// 3. The function returns an error indicating that the original contract number is required.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "",
				},
				ContractInfo: &model.ContractMeta{},
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "原合同号不能为空")
		})

		mockey.PatchConvey("Scenario: GetSupplyContractList returns an error", func() {
			// Scene description:
			// The call to the meta service to get the supply contract list fails.
			// Logic path:
			// 1. In validateSupply, h.getMetaService(ctx).GetSupplyContractList(...) is called.
			// 2. The mocked GetSupplyContractList returns an error.
			// 3. The function logs the error and returns a generic error message.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
				},
				ContractInfo: &model.ContractMeta{},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, errorsV2.ErrCommon.WithArgs("db error")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
		})

		mockey.PatchConvey("Scenario: GetSupplyContractList returns a nil response", func() {
			// Scene description:
			// The call to GetSupplyContractList succeeds but returns a nil object, meaning the contract was not found.
			// Logic path:
			// 1. In validateSupply, h.getMetaService(ctx).GetSupplyContractList(...) returns (nil, nil).
			// 2. The function checks if the result is nil and returns an error indicating that the info is missing.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
				},
				ContractInfo: &model.ContractMeta{},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "补充协议相关合同信息不存在")
		})

		mockey.PatchConvey("Scenario: supplyService.ValidateBase fails", func() {
			// Scene description:
			// The basic validation of the supply agreement by the supply service fails.
			// Logic path:
			// 1. GetSupplyContractList returns valid data.
			// 2. The `fillSupplyExtInfoByFromContractInfo` function is called.
			// 3. `supplyService.ValidateBase` is called and the mocked function returns an error.
			// 4. The function returns the error from ValidateBase.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					RelateQuoteNo:  "Q001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo:  &bizmodels.ManageInfo{},
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationSubmitDraft,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{
					MainContractNo: "MAIN-001",
					ManageInfo:     &bizmodels.ManageInfo{},
					ProjectInfo:    &bizmodels.ProjectInfo{},
				},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			mockSupplySvc := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(errorsV2.ErrCommon.WithArgs("validate base failed")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate base failed")
		})

		mockey.PatchConvey("Scenario: JSON unmarshal fails when OperationState is OperationChangeQuoteNo", func() {
			// Scene description:
			// When the operation is to change a quote, the system tries to parse pc.Extra, which fails due to invalid JSON.
			// Logic path:
			// 1. GetSupplyContractList succeeds.
			// 2. The condition `pc.OperationState == _const.OperationChangeQuoteNo` is true.
			// 3. `json.Unmarshal` fails on the invalid `pc.Extra` string.
			// 4. The function returns an error for parsing failure.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					ManageInfo:  &bizmodels.ManageInfo{},
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          "this-is-not-valid-json",
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "MAIN-001"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解析合同变更信息失败")
		})

		mockey.PatchConvey("Scenario: supplyService.ValidateValidityTime fails", func() {
			// Scene description:
			// The validity time validation fails. This check is triggered by specific cooperation statuses.
			// Logic path:
			// 1. GetSupplyContractList and ValidateBase succeed.
			// 2. The condition `utils.IntIn(pc.ContractInfo.CooperationStatus, ...)` is true.
			// 3. `supplyService.ValidateValidityTime` is called and the mocked function returns an error.
			// 4. The function returns the error from ValidateValidityTime.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					RelateQuoteNo:  "Q001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
					ManageInfo:        &bizmodels.ManageInfo{},
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationSubmitDraft,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "MAIN-001"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			mockSupplySvc := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(errorsV2.ErrCommon.WithArgs("validate validity time failed")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate validity time failed")
		})

		mockey.PatchConvey("Scenario: Success path, skipping ValidateValidityTime due to CooperationStatus", func() {
			// Scene description:
			// All checks pass, and the validity time check is skipped because the CooperationStatus is not in the required list.
			// Logic path:
			// 1. GetSupplyContractList and ValidateBase succeed.
			// 2. The condition `utils.IntIn(pc.ContractInfo.CooperationStatus, ...)` is false.
			// 3. The function returns nil without calling ValidateValidityTime.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					RelateQuoteNo:  "Q001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft, // This status skips the check
					ManageInfo:        &bizmodels.ManageInfo{},
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationSubmitDraft,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "MAIN-001"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			mockSupplySvc := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Scenario: Success path, skipping ValidateValidityTime due to OperationState", func() {
			// Scene description:
			// All checks pass, and the validity time check is skipped because the OperationState is OperationChangeQuoteNo.
			// Logic path:
			// 1. GetSupplyContractList succeeds, JSON unmarshalling for change quote also succeeds.
			// 2. ValidateBase succeeds.
			// 3. The condition `pc.OperationState != _const.OperationChangeQuoteNo` is false, so the block for ValidateValidityTime is skipped.
			// 4. The function returns nil.
			changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "NEW-Q002"}
			extraJSON, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
					ManageInfo:        &bizmodels.ManageInfo{},
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          string(extraJSON),
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "MAIN-001"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			mockSupplySvc := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Scenario: Full success path including ValidateValidityTime", func() {
			// Scene description:
			// All checks pass, including the validity time validation.
			// Logic path:
			// 1. GetSupplyContractList, ValidateBase, and ValidateValidityTime all succeed.
			// 2. The function returns nil.
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some-source",
					FromContractNo: "FROM-CONTRACT-001",
					RelateQuoteNo:  "Q001",
					ManageInfo:     "{}",
					ProjectInfo:    "{}",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					ManageInfo:        &bizmodels.ManageInfo{},
					ProjectInfo:       &bizmodels.ProjectInfo{},
				},
				OperationState: _const.OperationSubmitDraft,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "MAIN-001"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()

			mockSupplySvc := &MockSupplyService{}
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerDraftUpdate_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerDraftUpdate Process", t, func() {
		// Common test data
		ctx := context.Background()
		h := &handlerDraftUpdate{}
		tx := &gorm.DB{}

		// Initialize ProcessCtx with sufficient data for the test cases
		pc := &auditmodel.ProcessCtx{
			PreContractVO: &model.ContractMetaDB{
				BaseDB:       model.BaseDB{Id: 1, UpdatedTime: time.Now(), CreatedTime: time.Now()},
				ContractNo:   "test-contract-no",
				TemplateInfo: `{"key":"template-info"}`, // non-empty to trigger GetTemplateFileId logic
				Creator:      "test.creator@example.com",
			},
			ContractInfo: &model.ContractMeta{
				ManageInfo: &bizmodels.ManageInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{},
					OtherParty: []*bizmodels.TradePartyInfoDetail{},
				},
				SettlementInfo: &bizmodels.SettlementInfo{
					SettlementLines: bizmodels.SettlementLines{
						{
							Id:                         1,
							InvoicingPercent:           "100",
							InvoicingTotal:             "1000",
							PaymentPercent:             "100",
							PaymentTotal:               "1000",
							InvoicingMilepostFixedTime: "2023-01-01",
							PaymentMilepostFixedTime:   "2023-01-01",
						},
					},
				},
				Ext: map[string]string{"ext_key": "ext_value"},
			},
			AttachmentUpdateList: []*bizmodels.MetaAttachment{
				{DownloadID: "att-id-1"},
			},
			DelExtKeys:      []string{"del_ext_key"},
			CurrentOperator: "operator@example.com",
		}

		mockey.PatchConvey("Success", func() {
			// 场景描述：
			// 构造数据：所有依赖的函数调用都返回成功。
			// 逻辑链路：
			// 1. 调用 h.updateContractData。
			// 2. 内部调用 GetTemplateFileId 成功返回文件ID。
			// 3. 内部调用 h.CreateOrUpdateAttachment 成功。
			// 4. 内部调用 h.updatePreContract, 其依赖 dal.UpdateFieldsByNo 成功。
			// 5. 内部调用 h.SaveManageInfo 成功。
			// 6. 内部调用 h.SaveTradePartyInfo 成功。
			// 7. 内部调用 h.SaveMetaExt 成功。
			// 8. 内部调用 h.updateContractSettlement, 其依赖的 dal 调用均成功。
			// 9. 内部调用 h.updateAttachment, 其依赖的 dal.UpdateByFileKey 成功。
			// 10. 最终 Process 方法返回 nil。

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

			mockMetaDao := &MockContractMetaDao{}
			mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

			mockSettlementDao := &MockContractSettlementDao{}
			mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			mockAttachmentDao := &MockContractAttachmentDao{}
			mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
			mockey.Mock(json.Marshal).Return([]byte{}, nil).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure cases", func() {
			mockey.PatchConvey("when GetTemplateFileId fails", func() {
				// 场景描述：GetTemplateFileId 调用返回错误，Process 应立即返回该错误。
				expectedErr := errors.New("GetTemplateFileId failed")
				mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "GetTemplateFileId failed")
			})

			mockey.PatchConvey("when CreateOrUpdateAttachment fails", func() {
				// 场景描述：GetTemplateFileId 成功后，CreateOrUpdateAttachment 调用失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()

				expectedErr := errors.New("CreateOrUpdateAttachment failed")
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "CreateOrUpdateAttachment failed")
			})

			mockey.PatchConvey("when updatePreContract fails", func() {
				// 场景描述：h.updatePreContract 内部的数据库更新操作失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()

				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				expectedErr := errors.New("UpdateFieldsByNo failed")
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByNo failed")
			})

			mockey.PatchConvey("when SaveManageInfo fails", func() {
				// 场景描述：保存管理信息 h.SaveManageInfo 失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

				expectedErr := errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("when SaveTradePartyInfo fails", func() {
				// 场景描述：保存交易方信息 h.SaveTradePartyInfo 失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()

				expectedErr := errorsV2.ErrInternalError.WithArgs("SaveTradePartyInfoFail")
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("when SaveMetaExt fails", func() {
				// 场景描述：保存合同扩展信息 h.SaveMetaExt 失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()

				expectedErr := errorsV2.ErrInternalError.WithArgs("SaveMetaExtFail")
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("when updateContractSettlement fails", func() {
				// 场景描述：h.updateContractSettlement 内部的数据库操作失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()

				mockSettlementDao := &MockContractSettlementDao{}
				mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
				expectedErr := errors.New("SoftDeleteByContractID failed")
				mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "SoftDeleteByContractID failed")
			})

			mockey.PatchConvey("when updateAttachment fails", func() {
				// 场景描述：h.updateAttachment 内部的数据库操作失败。
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockMetaDao := &MockContractMetaDao{}
				mockey.Mock(dal.NewContractMetaDao).Return(mockMetaDao).Build()
				mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
				mockSettlementDao := &MockContractSettlementDao{}
				mockey.Mock(dal.NewContractSettlementDao).Return(mockSettlementDao).Build()
				mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
				mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(&model.ContractSettlementDB{}, nil).Build()
				mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

				mockAttachmentDao := &MockContractAttachmentDao{}
				mockey.Mock(dal.NewContractAttachmentDao).Return(mockAttachmentDao).Build()
				expectedErr := errors.New("UpdateByFileKey failed")
				mockey.Mock(json.Marshal).Return([]byte{}, nil).Build() // ensure json marshal does not fail
				mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(expectedErr).Build()

				err := h.Process(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByFileKey failed")
			})
		})
	})
}

func Test_newHandlerDraftUpdate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerDraftUpdate", t, func() {
		mockey.PatchConvey("should return a new handlerDraftUpdate instance", func() {
			// 场景描述:
			// 验证 newHandlerDraftUpdate 函数是否能正确地创建一个 handlerDraftUpdate 实例。
			// 构造数据:
			// 无需构造特殊数据。
			// 逻辑链路:
			// 1. 直接调用 newHandlerDraftUpdate 函数。
			// 2. 断言返回的 StatusOpHandler 实例不为 nil。
			// 3. 断言返回的实例的底层具体类型是 *handlerDraftUpdate。

			// 调用目标函数
			handler := newHandlerDraftUpdate()

			// 断言结果
			convey.So(handler, convey.ShouldNotBeNil)
			_, ok := handler.(*handlerDraftUpdate)
			convey.So(ok, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerDraftUpdate_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftUpdate_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 构造数据：创建一个handlerDraftUpdate实例。
			// 逻辑链路：调用CurrentStatus方法。
			// 预期结果：该方法应返回常量_const.PreSalesContractDraft。

			// 准备数据
			h := &handlerDraftUpdate{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractDraft)
		})
	})
}

func Test_handlerDraftUpdate_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftUpdate_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSubmitDraft", func() {
			// 场景描述：
			// 测试 handlerDraftUpdate 的 CurrentOp 方法，期望其返回正确的操作类型。
			// 构造数据：
			// 初始化一个 handlerDraftUpdate 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否等于 _const.OperationSubmitDraft。

			// 准备数据
			h := &handlerDraftUpdate{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitDraft)
		})
	})
}

func Test_handlerDraftUpdate_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftUpdate_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况，函数直接返回false和nil", func() {
			// 场景描述：
			// 构造数据：构造一个handlerDraftUpdate实例和一个空的ProcessCtx。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 断言返回的布尔值为false，错误为nil。
			h := &handlerDraftUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerDraftUpdate_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerDraftUpdate_PostProcess", t, func() {
		mockey.PatchConvey("success", func() {
			// 场景描述：
			// 这是一个空函数，直接返回nil。
			// 构造数据：
			// 构造空的 handlerDraftUpdate 和 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 PostProcess 方法。
			// 2. 断言返回的error为nil。

			h := &handlerDraftUpdate{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

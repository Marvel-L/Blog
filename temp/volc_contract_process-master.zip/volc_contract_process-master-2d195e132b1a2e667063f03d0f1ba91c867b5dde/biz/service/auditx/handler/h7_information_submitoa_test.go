package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"
	"volc_contract_process/biz/service/contractmeta"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/support/metacommodity"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/riskenginecli"
	utils "volc_contract_process/pkg/util"
)

func Test_newHandlerInformationSubmitOA_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerInformationSubmitOA", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 newHandlerInformationSubmitOA 函数是否能成功创建一个新的 handler 实例。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerInformationSubmitOA 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerInformationSubmitOA。

			// 调用
			result := newHandlerInformationSubmitOA()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldHaveSameTypeAs, &handlerInformationSubmitOA{})
		})
	})
}

func Test_handlerInformationSubmitOA_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSubmitOA_PostProcess", t, func() {
		h := &handlerInformationSubmitOA{}
		ctx := context.Background()

		mockey.PatchConvey("正常流程-成功通知C360", func() {
			// 场景描述：
			// 构造数据：构造一个标准的ProcessCtx，非退回操作。
			// 逻辑链路：
			// 1. PostProcess 调用 notifyC360
			// 2. notifyC360中，multienv.IsBytePlus 返回 false，继续执行。
			// 3. larkc.GetEmployeeByID 成功返回员工信息。
			// 4. pc.OperationState 不是 OperationSendBack，不进入特定if分支。
			// 5. mqProducer.SendC360NotifyMessage 成功发送消息。
			// 6. PostProcess 最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:     "test-operator-id",
					ContractNo:   "CONTRACT-001",
					ContractName: "Test Contract",
				},
				OperationState:     _const.OperationReviewPass,
				StatusChangedValue: _const.PreSalesContractSubmitOA,
				Comment:            &bizmodels.RichTextInfo{},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("正常流程-退回操作", func() {
			// 场景描述：
			// 构造数据：构造一个退回操作的ProcessCtx，包含评论和对方公司名称。
			// 逻辑链路：
			// 1. PostProcess 调用 notifyC360
			// 2. notifyC360中，multienv.IsBytePlus 返回 false，继续执行。
			// 3. larkc.GetEmployeeByID 成功返回员工信息。
			// 4. pc.OperationState 是 OperationSendBack，进入if分支，填充退回原因和客户名称。
			// 5. mqProducer.SendC360NotifyMessage 成功发送带有退回原因的消息。
			// 6. PostProcess 最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:       "test-operator-id",
					ContractNo:     "CONTRACT-002",
					ContractName:   "Test Contract SendBack",
					OtherPartyName: "Test Customer",
				},
				OperationState:     _const.OperationSendBack,
				StatusChangedValue: _const.PreSalesContractDraft,
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "some reason for sending back",
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).When(func(ctx context.Context, d time.Duration, msg *bizmodels.C360NotifyMsg) bool {
				record := msg.ContractList[0]
				return record.StatusReturnReason == "some reason for sending back" && record.CustomerName == "Test Customer"
			}).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("异常流程-发送MQ消息失败", func() {
			// 场景描述：
			// 构造数据：构造一个标准的ProcessCtx。
			// 逻辑链路：
			// 1. PostProcess 调用 notifyC360。
			// 2. notifyC360 内部逻辑正常执行到发送MQ消息步骤。
			// 3. mqProducer.SendC360NotifyMessage 返回错误。
			// 4. notifyC360 内部会记录错误日志，并调用larkc.Warning发送告警。
			// 5. 尽管notifyC360返回了error，但PostProcess函数忽略了这个错误。
			// 6. PostProcess 最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:     "test-operator-id",
					ContractNo:   "CONTRACT-003",
					ContractName: "Test Contract MQ Fail",
				},
				OperationState:     _const.OperationReviewPass,
				StatusChangedValue: _const.PreSalesContractSubmitOA,
				Comment:            &bizmodels.RichTextInfo{},
			}
			mqErr := errors.New("mq send failed")

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(mqErr).Build()
			mockey.Mock(utils.ToJSON).Return("{\"some\":\"json\"}").Build()
			mockey.Mock(larkc.Warning).Return().Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界条件-IsBytePlus环境", func() {
			// 场景描述：
			// 构造数据：构造一个标准的ProcessCtx。
			// 逻辑链路：
			// 1. PostProcess 调用 notifyC360。
			// 2. notifyC360 中，multienv.IsBytePlus 返回 true，函数直接返回 nil。
			// 3. PostProcess 最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator: "test-operator-id",
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界条件-获取员工信息失败", func() {
			// 场景描述：
			// 构造数据：构造一个标准的ProcessCtx。
			// 逻辑链路：
			// 1. PostProcess 调用 notifyC360。
			// 2. notifyC360 中，larkc.GetEmployeeByID 返回错误。
			// 3. Operator email 会是空字符串，但流程继续。
			// 4. mqProducer.SendC360NotifyMessage 被调用并成功。
			// 5. PostProcess 最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					Operator:     "non-existent-operator",
					ContractNo:   "CONTRACT-004",
					ContractName: "Test Contract Get Employee Fail",
				},
				OperationState:     _const.OperationReviewPass,
				StatusChangedValue: _const.PreSalesContractSubmitOA,
				Comment:            &bizmodels.RichTextInfo{},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return(nil, errors.New("employee not found")).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).When(func(ctx context.Context, d time.Duration, msg *bizmodels.C360NotifyMsg) bool {
				return len(msg.Operator) == 1 && msg.Operator[0] == ""
			}).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerInformationSubmitOA_Process(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			// Act
			v := &handlerInformationSubmitOA{}
			err := v.Process(context.Background(), &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
			})

			// Assert
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case updateContractData fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(fmt.Errorf("updateContractDataFail")).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(nil).Build()
			// Act
			v := &handlerInformationSubmitOA{}
			err := v.Process(context.Background(), &auditmodel.ProcessCtx{PreContractVO: &model.ContractMetaDB{}})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "code: ErrCommon, message: updateContractDataFail")
		})
	})
	t.Run("case SubmitComplianceCheck fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).SubmitComplianceCheck).Return(fmt.Errorf("SubmitComplianceCheckFail")).Build()
			// Act
			v := &handlerInformationSubmitOA{}
			err := v.Process(context.Background(), &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
			})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SubmitComplianceCheckFail")
		})
	})
}

func Test_handlerInformationSubmitOA_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSubmitOA_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSalesOperationCompleteInformation", func() {
			// 场景描述：
			// 测试handlerInformationSubmitOA的CurrentStatus方法，预期返回预定义的常量。
			// 构造数据：
			// 初始化一个handlerInformationSubmitOA实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 断言返回值是否等于_const.PreSalesContractSalesOperationCompleteInformation。

			// 准备数据
			h := &handlerInformationSubmitOA{}

			// 调用目标函数
			status := h.CurrentStatus()

			// 断言结果
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationCompleteInformation)
		})
	})
}

//func Test_handlerInformationSubmitOA_Validate_BitsUTGen(t *testing.T) {
//	h := &handlerInformationSubmitOA{}
//	ctx := context.Background()
//	tx := &gorm.DB{}
//
//	mockey.PatchConvey("Test_handlerInformationSubmitOA_Validate", t, func() {
//		// Common setup for pc
//		pc := &auditmodel.ProcessCtx{
//			ContractInfo: &model.ContractMeta{
//				BasicInfo:      &bizmodels.BasicInfo{},
//				TradePartyInfo: &bizmodels.TradePartyInfo{},
//				ManageInfo:     &bizmodels.ManageInfo{},
//				ProjectInfo:    &bizmodels.ProjectInfo{},
//			},
//			PreContractVO:        &model.ContractMetaDB{},
//			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
//		}
//		// mock GetTx to avoid nil pointer
//		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
//
//		mockey.PatchConvey("domestic env and not cooperation quote should fail", func() {
//			// 场景描述：
//			// 环境为国内(非火山)，且审批类型不是合作报价。
//			// 逻辑链路：
//			// 1. env.IsBytePlus() 返回 false。
//			// 2. pc.ApprovalKey 设置为非 _const.ApprovalKeyCooperationQuote 的值。
//			// 3. 第一个if条件 `!env.IsBytePlus() && pc.ApprovalKey != _const.ApprovalKeyCooperationQuote` 成立。
//			// 4. 函数应返回错误 "国内暂不支持此操作"。
//
//			// 构造数据
//			pc.ApprovalKey = "some_other_key"
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(false).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "国内暂不支持此操作")
//		})
//
//		mockey.PatchConvey("validateSupply fails", func() {
//			// 场景描述：
//			// 补充协议校验函数 validateSupply 返回错误。
//			// 逻辑链路：
//			// 1. env.IsBytePlus() 返回 true 以通过第一个检查。
//			// 2. h.validateSupply 被mock并返回一个预期的错误。
//			// 3. 函数应直接返回这个预期的错误。
//
//			// 构造数据
//			expectedErr := errors.New("validateSupply failed")
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(expectedErr).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldEqual, expectedErr)
//		})
//
//		mockey.PatchConvey("missing WhetherProject", func() {
//			// 场景描述：
//			// 合同基本信息中缺少 `WhetherProject` 字段。
//			// 逻辑链路：
//			// 1. 通过前面的检查。
//			// 2. `len(contractInfo.BasicInfo.WhetherProject) == 0` 条件为真。
//			// 3. 函数应返回 ErrMissingParam 错误，并提示 "WhetherProject"。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = ""
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrMissingParam)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "WhetherProject")
//		})
//
//		mockey.PatchConvey("RelateQuote scenarios", func() {
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
//
//			mockey.PatchConvey("missing RelateQuoteNo", func() {
//				// 场景描述：
//				// 合同需要关联报价单，但 RelateQuoteNo 为空。
//				// 逻辑链路：
//				// 1. contractInfo.CalcRequireQuote() 返回 true。
//				// 2. contractInfo.RelateQuoteNo 为空。
//				// 3. 函数返回错误，提示需要关联报价单。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = ""
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "当前合同必须关联报价单")
//			})
//
//			mockey.PatchConvey("包含副签约主体且账号为空", func() {
//				// 场景描述：
//				// 合同需要关联报价单，但交易对方的 AccountID 缺失。
//				// 逻辑链路：
//				// 1. contractInfo.CalcRequireQuote() 为 true。
//				// 2. contractInfo.RelateQuoteNo 不为空。
//				// 3. 遍历交易对方列表，发现一个 AccountID 为空的对方。
//				// 4. 函数返回错误，提示合同账号ID缺失。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = "Q123"
//				pc.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
//					{AccountID: "", DeputyParty: 1}, {AccountID: "", DeputyParty: 0},
//				}
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "合同账号ID缺失")
//			})
//
//			mockey.PatchConvey("missing other party AccountID", func() {
//				// 场景描述：
//				// 合同需要关联报价单，但交易对方的 AccountID 缺失。
//				// 逻辑链路：
//				// 1. contractInfo.CalcRequireQuote() 为 true。
//				// 2. contractInfo.RelateQuoteNo 不为空。
//				// 3. 遍历交易对方列表，发现一个 AccountID 为空的对方。
//				// 4. 函数返回错误，提示合同账号ID缺失。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = "Q123"
//				pc.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
//					{AccountID: ""},
//				}
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "合同账号ID缺失")
//			})
//
//			mockey.PatchConvey("GetQuoteInfo fails", func() {
//				// 场景描述：
//				// 调用报价单服务接口失败。
//				// 逻辑链路：
//				// 1. 前置检查通过。
//				// 2. quotecli.GetQuoteInfo 返回错误。
//				// 3. 函数返回错误，提示查询报价单失败。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = "Q123"
//				pc.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
//					{AccountID: "12345"},
//				}
//				expectedErr := errors.New("quote service error")
//
//				// Mock
//				mockey.Mock(quotecli.GetQuoteInfo).Return(nil, expectedErr).Build()
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价单失败")
//			})
//
//			mockey.PatchConvey("GetQuoteInfo returns nil", func() {
//				// 场景描述：
//				// 调用报价单服务成功，但返回的报价单信息为 nil (即未找到)。
//				// 逻辑链路：
//				// 1. 前置检查通过。
//				// 2. quotecli.GetQuoteInfo 返回 (nil, nil)。
//				// 3. 函数返回错误，提示关联的报价单不存在。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = "Q123"
//				pc.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
//					{AccountID: "12345"},
//				}
//
//				// Mock
//				mockey.Mock(quotecli.GetQuoteInfo).Return(nil, nil).Build()
//				mockey.Mock(i18nfmt.Errorf).Return(errors.New("关联的报价单[Q123]不存在")).Build()
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "关联的报价单[Q123]不存在")
//			})
//
//			mockey.PatchConvey("WhetherProject mismatch", func() {
//				// 场景描述：
//				// 合同基本信息和管理信息中的 `WhetherProject` 标识不一致。
//				// 逻辑链路：
//				// 1. 报价单相关检查通过。
//				// 2. `contractInfo.BasicInfo.WhetherProject != contractInfo.ManageInfo.WhetherProject` 条件为真。
//				// 3. 函数返回错误，提示标识需与报价单保持一致。
//
//				// 构造数据
//				pc.ContractInfo.RelateQuoteNo = "Q123"
//				pc.ContractInfo.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
//					{AccountID: "12345"},
//				}
//				pc.ContractInfo.BasicInfo.WhetherProject = _const.Yes
//				pc.ContractInfo.ManageInfo.WhetherProject = _const.No
//
//				// Mock
//				mockey.Mock(quotecli.GetQuoteInfo).Return(&quote_client.QuoteRespSimpleInfo{}, nil).Build()
//				mockey.Mock(validateUsefulLifeType).Return(nil).Build()
//				mockey.Mock(validateAccountAssociationInfo).Return(nil).Build()
//
//				// 调用
//				err := h.Validate(ctx, pc)
//
//				// 断言
//				convey.So(err, convey.ShouldNotBeNil)
//				convey.So(err.Error(), convey.ShouldContainSubstring, "合同是否项目制标识需与报价单保持一致")
//			})
//		})
//
//		mockey.PatchConvey("validateValidityPeriod fails", func() {
//			// 场景描述：
//			// 合同有效期校验失败，例如有效期超长但未提供原因。
//			// 逻辑链路：
//			// 1. 前面的校验都通过。
//			// 2. 调用 validateValidityPeriod，由于构造的数据不合规，该函数返回错误。
//			// 3. 主函数返回此错误。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//			pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
//			pc.ContractInfo.BasicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
//			pc.ContractInfo.BasicInfo.UsefulLifeNum = 6 // > 5
//			pc.ContractInfo.BasicInfo.LongLifeReason = ""
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期超过五年，长有效期原因不允许为空")
//		})
//
//		mockey.PatchConvey("Subsequent validation failures", func() {
//
//			commonSuccessMock := func() {
//				pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//				mockey.Mock(env.IsBytePlus).Return(true).Build()
//				mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//				mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//				mockey.Mock(validateValidityPeriod).Return(nil).Build()
//			}
//
//			mockey.PatchConvey("validateTradePartyInfo fails", func() {
//				commonSuccessMock()
//				expectedErr := errors.New("trade party info error")
//				mockey.Mock(validateTradePartyInfo).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("validateProjectInfo fails", func() {
//				commonSuccessMock()
//				expectedErr := errors.New("project info error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("validateTermChangeDetail fails", func() {
//				commonSuccessMock()
//				expectedErr := errors.New("term change detail error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("ValidateExternalCommodity fails", func() {
//				commonSuccessMock()
//				expectedErr := errorsV2.ErrCommon.WithArgs("external commodity error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//				mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("validateManageInfo fails", func() {
//				commonSuccessMock()
//				expectedErr := errorsV2.ErrCommon.WithArgs("manage info error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//				mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//				mockey.Mock(validateManageInfo).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("validateMetaExt fails", func() {
//				commonSuccessMock()
//				expectedErr := errorsV2.ErrCommon.WithArgs("check relate subject party error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//				mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//				mockey.Mock(validateManageInfo).Return(nil).Build()
//				mockey.Mock(validateMetaExt).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("CheckRelateSubjectParty fails", func() {
//				commonSuccessMock()
//				expectedErr := errorsV2.ErrCommon.WithArgs("check relate subject party error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//				mockey.Mock(validateMetaExt).Return(nil).Build()
//				mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//				mockey.Mock(validateManageInfo).Return(nil).Build()
//				mockey.Mock(CheckRelateSubjectParty).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//
//			mockey.PatchConvey("validateAccountIdRequired fails", func() {
//				commonSuccessMock()
//				expectedErr := errorsV2.ErrCommon.WithArgs("account id required error")
//				mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//				mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//				mockey.Mock(validateProjectInfo).Return(nil).Build()
//				mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//				mockey.Mock(validateMetaExt).Return(nil).Build()
//				mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//				mockey.Mock(validateManageInfo).Return(nil).Build()
//				mockey.Mock(CheckRelateSubjectParty).Return(nil).Build()
//				mockey.Mock(validateAccountIdRequired).Return(expectedErr).Build()
//
//				err := h.Validate(ctx, pc)
//				convey.So(err, convey.ShouldEqual, expectedErr)
//			})
//		})
//
//		mockey.PatchConvey("validateRiskClauseRole fails", func() {
//			// 场景描述：
//			// 风险条款校验失败，存在未审批通过的风险条款。
//			// 逻辑链路：
//			// 1. 前面所有检查都通过。
//			// 2. 调用 validateRiskClauseRole。
//			// 3. DAL层返回存在状态为非“通过”或“关闭”的风险条款。
//			// 4. 函数返回错误。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//			pc.ContractInfo.ContractNo = "C123"
//			pc.PreContractVO.Id = 1
//			pc.PreContractVO.SupplySource = "" // 非条款变更
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//			mockey.Mock(validateValidityPeriod).Return(nil).Build()
//			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//			mockey.Mock(validateProjectInfo).Return(nil).Build()
//			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
//			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
//			mockey.Mock(dal.NewRiskClauseRoleDao).Return(&MockRiskClauseRoleDao{}).Build()
//			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return([]*model.RiskClauseRoleDB{
//				{BaseDB: model.BaseDB{Status: 1}}, // Use a non-passing status
//			}, nil).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "存在未审批通过的风险条款")
//		})
//
//		mockey.PatchConvey("settlement lines check fails", func() {
//			// 场景描述：
//			// 合同为收入类型，非报价单来源，且缺少结算条款。
//			// 逻辑链路：
//			// 1. 前面所有检查都通过。
//			// 2. 满足结算条款检查的条件。
//			// 3. DAL层返回空的结算条款列表。
//			// 4. 函数返回错误，提示结算条款必填。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//			pc.PreContractVO.InOutType = _const.BizInOutTypeIn
//			pc.PreContractVO.BizSource = _const.BizSourceCooperation
//			pc.ContractInfo.Initiator = 99 // a value that is not _const.InitiatorSelfPurchase
//			pc.PreContractVO.Id = 1
//			basicInfoBytes, _ := json.Marshal(pc.ContractInfo.BasicInfo)
//			pc.PreContractVO.BasicInfo = string(basicInfoBytes)
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//			mockey.Mock(validateValidityPeriod).Return(nil).Build()
//			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//			mockey.Mock(validateProjectInfo).Return(nil).Build()
//			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//			mockey.Mock(validateManageInfo).Return(nil).Build()
//			mockey.Mock(CheckRelateSubjectParty).Return(nil).Build()
//			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
//			mockey.Mock(dal.NewContractSettlementDao).Return(&MockContractSettlementDao{}).Build()
//			mockey.Mock((*MockContractSettlementDao).ListContractSettlementByContractID).Return([]*model.ContractSettlementDB{}, nil).Build()
//			mockey.Mock(i18nfmt.New).Return(errors.New("当合同收支类型为“收入类” / “既收又支”时，结算条款模块必填")).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款模块必填")
//		})
//
//		mockey.PatchConvey("IsReverseContract fails", func() {
//			// 场景描述：
//			// 倒签合同校验失败。
//			// 逻辑链路：
//			// 1. 所有前面的校验都通过。
//			// 2. h.IsReverseContract 被mock并返回一个预期的错误。
//			// 3. 函数返回这个错误。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//			pc.PreContractVO.InOutType = _const.BizInOutTypeOut
//			expectedErr := errors.New("reverse contract error")
//			basicInfoBytes, _ := json.Marshal(pc.ContractInfo.BasicInfo)
//			pc.PreContractVO.BasicInfo = string(basicInfoBytes)
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//			mockey.Mock(validateValidityPeriod).Return(nil).Build()
//			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//			mockey.Mock(validateProjectInfo).Return(nil).Build()
//			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//			mockey.Mock(validateManageInfo).Return(nil).Build()
//			mockey.Mock(CheckRelateSubjectParty).Return(nil).Build()
//			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
//			mockey.Mock((*handlerCommon).IsReverseContract).Return(expectedErr).Build()
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldEqual, expectedErr)
//		})
//
//		mockey.PatchConvey("success path", func() {
//			// 场景描述：
//			// 所有校验都成功通过。
//			// 逻辑链路：
//			// 1. 所有if err != nil的检查都被跳过。
//			// 2. 函数执行到末尾并返回nil。
//
//			// 构造数据
//			pc.ContractInfo.BasicInfo.WhetherProject = "Y"
//			pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
//			pc.ContractInfo.BasicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
//			pc.ContractInfo.BasicInfo.UsefulLifeNum = 1
//			pc.PreContractVO.InOutType = _const.BizInOutTypeOut
//			basicInfoBytes, _ := json.Marshal(pc.ContractInfo.BasicInfo)
//			pc.PreContractVO.BasicInfo = string(basicInfoBytes)
//			reverseSignInfoBytes, _ := json.Marshal(&bizmodels.ReverseSignInfo{ReverseSignReason: "test"})
//			pc.PreContractVO.ReverseSignInfo = string(reverseSignInfoBytes)
//			pc.PreContractVO.BeginTime = time.Now().AddDate(0, 0, 1)
//
//			// Mock
//			mockey.Mock(env.IsBytePlus).Return(true).Build()
//			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
//			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()
//			mockey.Mock(validateValidityPeriod).Return(nil).Build()
//			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
//			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
//			mockey.Mock(validateProjectInfo).Return(nil).Build()
//			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
//			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
//			mockey.Mock(validateManageInfo).Return(nil).Build()
//			mockey.Mock(CheckRelateSubjectParty).Return(nil).Build()
//			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
//			mockey.Mock(basicinfo.ParseBasicInfo).Return(pc.ContractInfo.BasicInfo, nil).Build()
//			mockey.Mock(i18nfmt.New).Return(nil).Build() // For IsReverseContract
//
//			// 调用
//			err := h.Validate(ctx, pc)
//
//			// 断言
//			convey.So(err, convey.ShouldBeNil)
//		})
//	})
//}

func Test_handlerInformationSubmitOA_Validate(t *testing.T) {
	contractmetaService := contractmeta.NewMetaServiceV2()
	// 测试env.IsBytePlus返回false且ApprovalKey不等于cooperation_quote的场景
	t.Run("IsNotBytePlusAndNotCooperationQuote", func(t *testing.T) {
		mockey.PatchConvey("国内环境非合作报价场景", t, func() {
			// 场景描述: 模拟在国内环境下，执行非合作报价单相关的操作，预期应被阻止。
			// Mock: env.IsBytePlus 返回 false，表示国内环境。
			// 数据构造: pc.ApprovalKey 设置为非"cooperation_quote"的值。
			// 逻辑链路: 进入第一个if判断 `!env.IsBytePlus() && pc.ApprovalKey != _const.ApprovalKeyCooperationQuote`，返回错误。
			mockey.Mock(env.IsBytePlus).Return(false).Build()
			var receiver *handlerInformationSubmitOA = &handlerInformationSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ApprovalKey: "not cooperation_quote",
			}

			err := receiver.Validate(ctxTest, pcTest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "国内暂不支持此操作")
		})
	})
	// 测试关联报价单场景为未完成报价审批的情况
	t.Run("RelateQuoteSceneNoCompleted", func(t *testing.T) {
		mockey.PatchConvey("关联未完成审批的报价单", t, func() {
			// 场景描述: 模拟合同关联的报价单审批流程尚未完成，此时提交OA应被阻止。
			// Mock: env.IsBytePlus 返回 true，跳过环境检查。
			// 数据构造: pc.ContractInfo.RelateQuoteScene 设置为 _const.RelateQuoteSceneNoCompleted。
			// 逻辑链路: 进入第二个if判断 `pc.ContractInfo.RelateQuoteScene == _const.RelateQuoteSceneNoCompleted`，返回错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			var receiver *handlerInformationSubmitOA = &handlerInformationSubmitOA{}
			var ctxTest context.Context = context.Background()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoCompleted,
				},
			}

			err := receiver.Validate(ctxTest, pcTest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "关联报价单场景 = 未完成报价审批")
		})
	})
	// 测试 validateSupply 函数返回错误的场景
	t.Run("ValidateSupplyReturnError", func(t *testing.T) {
		mockey.PatchConvey("补充协议校验失败", t, func() {
			// 场景描述: 模拟补充协议相关的前置校验失败。
			// Mock: 核心依赖 h.validateSupply 返回一个错误。
			// 数据构造: pc.ContractInfo.RelateQuoteScene 设为非未完成状态，以通过前序检查。
			// 逻辑链路: 执行到 h.validateSupply(ctx, pc) 时接收到错误并立即返回。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(fmt.Errorf("mock an error return")).Build()
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: 2,
				},
			}
			var receiver *handlerInformationSubmitOA = &handlerInformationSubmitOA{}
			var ctxTest context.Context = context.Background()

			err := receiver.Validate(ctxTest, pcTest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "mock an error return")
		})
	})

	t.Run("成功场景_所有校验通过", func(t *testing.T) {
		mockey.PatchConvey("当所有校验均成功时，应返回nil", t, func() {
			// 场景描述: 模拟所有校验逻辑都成功通过的理想情况。
			// Mock: 所有的校验函数和外部依赖调用都返回成功（nil或有效数据）。
			// 数据构造: 构造一个合法的ProcessCtx，使其能顺利通过所有检查点。
			// 逻辑链路: 函数从头执行到尾，不进入任何错误返回的分支，最终返回nil。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(metacommodity.ValidateInvoiceTaxRateForManageInfo).Return(nil).Build()
			mockey.Mock(validateManageInfo).Return(nil).Build()
			mockey.Mock(validateMetaExt).Return(nil).Build()
			mockey.Mock(contractmetaService.CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			settlementDao := dal.NewContractSettlementDao()
			mockey.Mock(dal.NewContractSettlementDao).Return(settlementDao).Build()
			mockey.Mock(mockey.GetMethod(settlementDao, "ListContractSettlementByContractID")).Return([]*model.ContractSettlementDB{{BaseDB: model.BaseDB{Id: 1}}}, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					Initiator:      _const.InitiatorCRM,
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					InOutType: _const.BizInOutTypeIn,
					BizSource: _const.BizSourceCooperation,
				},
				Ext: map[string]string{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景_校验返券规则有效期与合同有效期未通过", func(t *testing.T) {
		mockey.PatchConvey("失败场景_合同有效期校验未通过", t, func() {
			// 场景描述: 模拟合同基本信息中缺少"是否项目制"这一必填字段。
			// Mock: 前序校验通过。
			// 数据构造: pc.ContractInfo.BasicInfo.WhetherProject 设置为空字符串。
			// 逻辑链路: 执行到 `if len(contractInfo.BasicInfo.WhetherProject) == 0` 判断时为true，返回参数缺失错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(errors.New("coupon period is invalid")).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "", // 触发错误
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "coupon period is invalid")
		})
	})

	t.Run("失败场景_合同有效期校验未通过", func(t *testing.T) {
		mockey.PatchConvey("失败场景_合同有效期校验未通过", t, func() {
			// 场景描述: 模拟合同基本信息中缺少"是否项目制"这一必填字段。
			// Mock: 前序校验通过。
			// 数据构造: pc.ContractInfo.BasicInfo.WhetherProject 设置为空字符串。
			// 逻辑链路: 执行到 `if len(contractInfo.BasicInfo.WhetherProject) == 0` 判断时为true，返回参数缺失错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(errors.New("contract period is invalid")).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "", // 触发错误
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "contract period is invalid")
		})
	})

	t.Run("失败场景_项目制标识为空", func(t *testing.T) {
		mockey.PatchConvey("当WhetherProject为空时，应返回参数缺失错误", t, func() {
			// 场景描述: 模拟合同基本信息中缺少"是否项目制"这一必填字段。
			// Mock: 前序校验通过。
			// 数据构造: pc.ContractInfo.BasicInfo.WhetherProject 设置为空字符串。
			// 逻辑链路: 执行到 `if len(contractInfo.BasicInfo.WhetherProject) == 0` 判断时为true，返回参数缺失错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "", // 触发错误
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "WhetherProject")
		})
	})

	t.Run("失败场景_关联报价单但账号ID缺失", func(t *testing.T) {
		mockey.PatchConvey("当需要关联报价单但对方签约主体AccountID为空时，应返回错误", t, func() {
			// 场景描述: 模拟合同关联了报价单，但交易对方信息中缺少必填的AccountID。
			// Mock: 前序校验通过，且 `NeedRelateQuoteNo` 返回 true。
			// 数据构造: `TradePartyInfo.OtherParty` 中的某个元素的 `AccountID` 为空。
			// 逻辑链路: 进入 `NeedRelateQuoteNo` 逻辑块，遍历 `OtherParty` 时发现 `AccountID` 为空，返回错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneCompleted,
					RelateQuoteNo:    "Q-123",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: "", // 触发错误
							},
						},
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同账号ID缺失")
		})
	})

	t.Run("失败场景_关联报价单不存在", func(t *testing.T) {
		mockey.PatchConvey("当关联的报价单查询结果为nil时，应返回错误", t, func() {
			// 场景描述: 模拟合同关联了一个不存在的报价单号。
			// Mock: `quotecli.GetQuoteInfo` 返回 nil, nil，表示查询成功但未找到数据。
			// 数据构造: 提供一个有效的报价单号 `RelateQuoteNo`。
			// 逻辑链路: `GetQuoteInfo` 返回后，进入 `if info == nil` 判断，返回错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(quotecli.GetQuoteInfo).Return(nil, nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneCompleted,
					RelateQuoteNo:    "Q-NonExistent",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},

					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{AccountID: "12345"},
						},
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "不存在")
		})
	})

	t.Run("失败场景_项目信息校验失败", func(t *testing.T) {
		mockey.PatchConvey("当validateProjectInfo返回错误时，应传播该错误", t, func() {
			// 场景描述: 模拟在顺序校验过程中，`validateProjectInfo` 函数执行失败。
			// Mock: 前序所有校验函数均返回成功，`validateProjectInfo` 返回一个错误。
			// 逻辑链路: 顺序执行校验，直到 `validateProjectInfo` 失败并返回其错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(errors.New("项目信息校验失败")).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目信息校验失败")
		})
	})

	t.Run("失败场景_结算条款为空", func(t *testing.T) {
		mockey.PatchConvey("当需要结算条款但查询结果为空时，应返回错误", t, func() {
			// 场景描述: 模拟合同类型要求必须有结算条款，但数据库中未查询到。
			// Mock: 前序所有校验成功。`dal.NewContractSettlementDao().ListContractSettlementByContractID` 返回空列表。
			// 数据构造: 构造 `pc.PreContractVO` 和 `pc.ContractInfo` 使其满足需要校验结算条款的条件。
			// 逻辑链路: 进入结算条款校验逻辑，`len(settlementLines)` 为 0，返回错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(metacommodity.ValidateInvoiceTaxRateForManageInfo).Return(nil).Build()
			mockey.Mock(validateManageInfo).Return(nil).Build()
			mockey.Mock(validateMetaExt).Return(nil).Build()
			mockey.Mock(contractmetaService.CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			settlementDao := dal.NewContractSettlementDao()
			mockey.Mock(dal.NewContractSettlementDao).Return(settlementDao).Build()
			mockey.Mock(mockey.GetMethod(settlementDao, "ListContractSettlementByContractID")).Return([]*model.ContractSettlementDB{}, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					Initiator:      _const.InitiatorCRM,
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 123,
					},
					InOutType: _const.BizInOutTypeIn,
					BizSource: _const.BizSourceCooperation,
				},
				Ext: map[string]string{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款模块必填")
		})
	})

	t.Run("失败场景_开票项税率校验失败", func(t *testing.T) {
		mockey.PatchConvey("当ValidateInvoiceTaxRateForManageInfo返回错误时，应传播该错误", t, func() {
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()
			expectedErr := errorsV2.ErrCommon.WithArgs("invoice tax rate validate failed")
			mockey.Mock(metacommodity.ValidateInvoiceTaxRateForManageInfo).Return(expectedErr).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					RelateQuoteNo:    "Q-123",
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})

	t.Run("失败场景_倒签合同校验失败", func(t *testing.T) {
		mockey.PatchConvey("当IsReverseContract返回错误时，应传播该错误", t, func() {
			// 场景描述: 模拟在所有前序校验通过后，最终的倒签合同校验失败。
			// Mock: `h.IsReverseContract` 返回一个错误。
			// 逻辑链路: 函数执行到最后一步，调用 `IsReverseContract` 并返回其错误。
			mockey.Mock(env.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock(validateTradePartyInfo).Return(nil).Build()
			mockey.Mock(validateRiskClauseRole).Return(nil).Build()
			mockey.Mock(validateProjectInfo).Return(nil).Build()
			mockey.Mock(validateTermChangeDetail).Return(nil).Build()
			mockey.Mock((*bizmodels.ManageInfo).ValidateExternalCommodity).Return(nil).Build()
			mockey.Mock(metacommodity.ValidateInvoiceTaxRateForManageInfo).Return(nil).Build()
			mockey.Mock(validateManageInfo).Return(nil).Build()
			mockey.Mock(validateMetaExt).Return(nil).Build()
			mockey.Mock(contractmetaService.CheckRelateSubjectParty).Return(nil).Build()
			mockey.Mock(validateAccountIdRequired).Return(nil).Build()
			mockey.Mock(dal.NewContractSettlementDao).Return(&MockContractSettlementDao{}).Build()
			mockey.Mock((*handlerCommon).commonCheckValidityAndRebatePeriod).Return(nil).Build()
			mockey.Mock((*handlerCommon).checkAndCorrectCouponValiditySubset).Return(nil).Build()

			mockey.Mock((*handlerCommon).IsReverseContract).Return(errors.New("倒签合同原因未填")).Build()

			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyCooperationQuote,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoRequired,
					BasicInfo: &bizmodels.BasicInfo{
						WhetherProject: "Y",
					},
					ManageInfo:     &bizmodels.ManageInfo{},
					TradePartyInfo: &bizmodels.TradePartyInfo{},
					Initiator:      _const.InitiatorSelfPurchase, // 通过设置自采平台跳过结算条款校验
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
					InOutType: _const.BizInOutTypeOut,
				},
				Ext: map[string]string{},
			}
			h := &handlerInformationSubmitOA{}

			err := h.Validate(context.Background(), pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "倒签合同原因未填")
		})
	})
}

func Test_handlerInformationSubmitOA_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSubmitOA_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 目标函数是一个简单的实现，它总是返回true和nil，没有任何复杂的逻辑。
			// 构造数据：
			// - h: 一个handlerInformationSubmitOA实例。
			// - pc: 一个空的auditmodel.ProcessCtx实例。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 验证返回的结果是true和nil。

			// 初始化处理器
			h := &handlerInformationSubmitOA{}
			// 初始化上下文
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerInformationSubmitOA_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSubmitOA_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 测试 handlerInformationSubmitOA 的 CurrentOp 方法是否能正确返回预期的操作类型常量。
			// 构造数据:
			// 创建一个 handlerInformationSubmitOA 的实例。
			// 逻辑链路:
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于 _const.OperationSubmitOA。
			h := &handlerInformationSubmitOA{}

			result := h.CurrentOp()

			convey.So(result, convey.ShouldEqual, _const.OperationSubmitOA)
		})
	})
}
func Test_handlerInformationSubmitOA_GetStatusOpConfKey(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSubmitOA_GetStatusOpConfKey", t, func() {
		h := &handlerInformationSubmitOA{}
		ctx := context.Background()

		mockey.PatchConvey("场景一: pc.ComplianceCheckInfo为nil，返回默认状态", func() {
			// 场景描述：
			// 传入的ProcessCtx中ComplianceCheckInfo为nil，触发兜底逻辑。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx实例，其ComplianceCheckInfo字段为nil。
			// 逻辑链路：
			// 1. 函数执行，进入第一个if判断 `pc.ComplianceCheckInfo == nil`。
			// 2. 条件为true，函数直接返回`_const.ApprovalStatusKeyDefault`。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: nil,
			}

			result := h.GetStatusOpConfKey(ctx, pc)

			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})

		mockey.PatchConvey("场景二: 命中人审(IsTransaction为RejectTransaction)，返回合规审查中状态", func() {
			// 场景描述：
			// 传入的ProcessCtx中ComplianceCheckInfo不为nil，且其Result.IsTransaction字段值为RejectTransaction，表示命中人审。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx实例。
			// - pc.ComplianceCheckInfo: riskenginecli.RiskEngineResp实例。
			// - pc.ComplianceCheckInfo.Result.IsTransaction: 设置为`_const.RejectTransaction`。
			// 逻辑链路：
			// 1. 函数执行，第一个if判断 `pc.ComplianceCheckInfo == nil` 为false。
			// 2. 进入第二个if判断 `pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction`。
			// 3. 条件为true，函数返回`_const.ApprovalStatusKeyComplianceCheck`。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: _const.RejectTransaction,
					},
				},
			}

			result := h.GetStatusOpConfKey(ctx, pc)

			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyComplianceCheck)
		})

		mockey.PatchConvey("场景三: 未命中人审，返回默认状态", func() {
			// 场景描述：
			// 传入的ProcessCtx中ComplianceCheckInfo不为nil，但其Result.IsTransaction字段值不为RejectTransaction，表示未命中人审。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx实例。
			// - pc.ComplianceCheckInfo: riskenginecli.RiskEngineResp实例。
			// - pc.ComplianceCheckInfo.Result.IsTransaction: 设置为一个非`_const.RejectTransaction`的值。
			// 逻辑链路：
			// 1. 函数执行，第一个if判断 `pc.ComplianceCheckInfo == nil` 为false。
			// 2. 进入第二个if判断 `pc.ComplianceCheckInfo.Result.IsTransaction == _const.RejectTransaction`。
			// 3. 条件为false，跳过if块。
			// 4. 函数执行到最后，返回`_const.ApprovalStatusKeyDefault`。
			pc := &auditmodel.ProcessCtx{
				ComplianceCheckInfo: &riskenginecli.RiskEngineResp{
					Result: &riskenginecli.Result{
						IsTransaction: "1", // A value different from RejectTransaction
					},
				},
			}

			result := h.GetStatusOpConfKey(ctx, pc)

			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})
	})
}

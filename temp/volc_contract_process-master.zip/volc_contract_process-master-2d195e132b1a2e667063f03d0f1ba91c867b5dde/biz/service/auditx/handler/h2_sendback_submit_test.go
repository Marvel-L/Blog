package handler

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"reflect"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerSendBackSubmit_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackSubmit_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSubmitPreContract", func() {
			// 场景描述：
			// 测试 handlerSendBackSubmit 的 CurrentOp 方法，验证其是否返回正确的操作类型常量。
			// 构造数据：
			// 创建一个 handlerSendBackSubmit 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于预期的常量 _const.OperationSubmitPreContract。

			h := &handlerSendBackSubmit{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSubmitPreContract)
		})
	})
}

func Test_newHandlerSendBackSubmit_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSendBackSubmit", t, func() {
		mockey.PatchConvey("正常-成功创建handler", func() {
			// 场景描述：
			// 测试newHandlerSendBackSubmit函数是否能成功创建一个非空的handlerSendBackSubmit实例。
			// 构造数据：
			// 无需构造数据。
			// 逻辑链路：
			// 1. 调用 newHandlerSendBackSubmit() 函数。
			// 2. 断言返回的 handler 不为 nil。
			// 3. 断言返回的 handler 的具体类型是 *handlerSendBackSubmit。

			// 调用
			handler := newHandlerSendBackSubmit()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(reflect.TypeOf(handler), convey.ShouldEqual, reflect.TypeOf(&handlerSendBackSubmit{}))
		})
	})
}

func Test_handlerSendBackSubmit_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSendBackSubmit PostProcess", t, func() {
		// Arrange common variables
		ctx := context.Background()
		h := handlerSendBackSubmit{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:     "C001",
				ContractName:   "Test Contract",
				OtherPartyName: "Test Party",
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales.op@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview, ReviewerSource: 0},
					{Reviewer: "sales.person@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
				Operator: "operator@example.com",
			},
			StatusChangedValue: _const.PreSalesContractSalesOperationReview,
			OperationState:     _const.OperationSendBack,
			Comment: &bizmodels.RichTextInfo{
				RichtextPlainText: "Please review again.",
			},
		}

		// Arrange common mocks
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			// Mocked to do nothing as it's an async call.
		}).Build()

		// Mock dependencies for message building
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
			return fmt.Sprintf("<at email=%s>", email)
		}).Build()
		mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review/C001").Build()

		convey.Convey("Success Case", func() {
			// Scenario Description: The main logic path where all sub-processes succeed.
			// Constructed Data: A standard ProcessCtx is used. The real getReviewerFrom... methods will be called.
			// Logic Path:
			// 1. A Lark message is prepared and its sending is mocked.
			// 2. h.handleQuoteChangeWhenSubmit is called and returns nil (mocked).
			// 3. h.notifyC360 is called and returns nil (mocked).
			// 4. The function returns nil, indicating success.

			// Arrange
			mockey.Mock((*handlerCommon).handleQuoteChangeWhenSubmit).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("Error from handleQuoteChangeWhenSubmit", func() {
			// Scenario Description: Test the error handling when h.handleQuoteChangeWhenSubmit fails.
			// Constructed Data: A standard ProcessCtx is used.
			// Logic Path:
			// 1. A Lark message is prepared and its sending is mocked.
			// 2. h.handleQuoteChangeWhenSubmit is called and returns an error (mocked).
			// 3. The function immediately returns the error.
			// 4. h.notifyC360 is NOT called.

			// Arrange
			mockErr := errors.New("quote change failed")
			mockey.Mock((*handlerCommon).handleQuoteChangeWhenSubmit).Return(mockErr).Build()
			// No need to mock h.notifyC360 as it shouldn't be reached.

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "quote change failed")
		})

		convey.Convey("Error from notifyC360 is ignored", func() {
			// Scenario Description: Test that an error from h.notifyC360 is ignored as per the function logic `_ = ...`.
			// Constructed Data: A standard ProcessCtx is used.
			// Logic Path:
			// 1. A Lark message is prepared and its sending is mocked.
			// 2. h.handleQuoteChangeWhenSubmit succeeds (returns nil).
			// 3. h.notifyC360 is called and returns an error (mocked).
			// 4. The function ignores the error from h.notifyC360 and returns nil.

			// Arrange
			mockErr := errors.New("c360 notify failed")
			mockey.Mock((*handlerCommon).handleQuoteChangeWhenSubmit).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(mockErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSendBackSubmit_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackSubmit_Validate", t, func() {
		h := &handlerSendBackSubmit{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: pc.ContractInfo为nil", func() {
			// 场景描述:
			// 构造数据: pc.ContractInfo为nil。
			// 逻辑链路:
			// 1. 函数进入第一个if条件，判断pc.ContractInfo是否为nil。
			// 2. 条件成立，函数返回 "合同协同记录不存在" 错误。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: nil,
			}

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同协同记录不存在")
		})

		mockey.PatchConvey("场景2: validateSupply返回错误", func() {
			// 场景描述:
			// 构造数据: pc.ContractInfo不为nil。
			// 逻辑链路:
			// 1. Mock h.validateSupply方法返回一个预设的错误。
			// 2. 函数在第一个错误检查处捕获到错误并立即返回。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{},
			}
			expectedErr := errors.New("validateSupply error")

			// Mock
			mockey.Mock((*handlerCommon).validateSupply).Return(expectedErr).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeError, expectedErr)
		})

		mockey.PatchConvey("场景3: validateRequireQuote返回错误", func() {
			// 场景描述:
			// 构造数据: pc.ContractInfo不为nil。
			// 逻辑链路:
			// 1. Mock h.validateSupply方法返回nil，使其通过。
			// 2. Mock h.validateRequireQuote方法返回一个预设的错误。
			// 3. 函数在第二个错误检查处捕获到错误并立即返回。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{},
			}
			expectedErr := errors.New("validateRequireQuote error")

			// Mock
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateRequireQuote).Return(expectedErr).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeError, expectedErr)
		})

		mockey.PatchConvey("场景4: 所有校验都通过", func() {
			// 场景描述:
			// 构造数据: pc.ContractInfo不为nil。
			// 逻辑链路:
			// 1. Mock h.validateSupply方法返回nil。
			// 2. Mock h.validateRequireQuote方法返回nil。
			// 3. 所有校验均通过，函数正常返回nil。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{},
			}

			// Mock
			mockey.Mock((*handlerCommon).validateSupply).Return(nil).Build()
			mockey.Mock((*handlerCommon).validateRequireQuote).Return(nil).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSendBackSubmit_Process_BitsUTGen(t *testing.T) {
	// The target method `Process` is defined on `handlerSendBackSubmit`, which embeds `handlerCommon`.
	// The actual logic is in the unexported methods `updateContractData` and `updateContractReviewers` on `handlerCommon`.
	// We will mock these two methods to test the logic of the `Process` function itself.
	h := &handlerSendBackSubmit{}
	ctx := context.Background()
	pc := &auditmodel.ProcessCtx{}

	mockey.PatchConvey("Test handlerSendBackSubmit Process", t, func() {
		convey.Convey("Success: both updateContractData and updateContractReviewers succeed", func() {
			// 场景描述：
			// 正常流程，`updateContractData`和`updateContractReviewers`都成功执行。
			// 构造数据：
			// - 无特殊数据构造。
			// 逻辑链路：
			// 1. Mock `(*handlerCommon).updateContractData` 返回 nil。
			// 2. Mock `(*handlerCommon).updateContractReviewers` 返回 nil。
			// 3. 调用 `Process` 方法。
			// 4. 断言返回的 error 为 nil。

			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractReviewers).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("Failure: updateContractData fails", func() {
			// 场景描述：
			// 第一个调用的方法 `updateContractData` 失败，流程应立即中断并返回错误。
			// 构造数据：
			// - 无特殊数据构造。
			// 逻辑链路：
			// 1. Mock `(*handlerCommon).updateContractData` 返回一个错误。
			// 2. 调用 `Process` 方法。
			// 3. 断言返回的 error 不为 nil，且与 mock 的错误一致。
			// 4. `updateContractReviewers` 不应被调用。

			mockErr := errors.New("update contract data failed")
			mockey.Mock((*handlerCommon).updateContractData).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update contract data failed")
		})

		convey.Convey("Failure: updateContractReviewers fails", func() {
			// 场景描述：
			// 第一个方法 `updateContractData` 成功，但第二个方法 `updateContractReviewers` 失败。
			// 构造数据：
			// - 无特殊数据构造。
			// 逻辑链路：
			// 1. Mock `(*handlerCommon).updateContractData` 返回 nil。
			// 2. Mock `(*handlerCommon).updateContractReviewers` 返回一个错误。
			// 3. 调用 `Process` 方法。
			// 4. 断言返回的 error 不为 nil，且与 mock 的错误一致。

			mockErr := errors.New("update contract reviewers failed")
			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractReviewers).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update contract reviewers failed")
		})
	})
}

func Test_handlerSendBackSubmit_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackSubmit_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况-返回true", func() {
			// 场景描述：
			// 构造数据：构造一个handlerSendBackSubmit实例和空的ProcessCtx。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 预期该方法总是返回true和nil。
			h := &handlerSendBackSubmit{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerSendBackSubmit_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSendBackSubmit_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractSendBack", func() {
			// 场景描述：
			// 测试 handlerSendBackSubmit 的 CurrentStatus 方法能否正确返回其代表的状态。
			// 构造数据：
			// 初始化一个 handlerSendBackSubmit 实例。
			// 逻辑链路：
			// 1. 创建一个 handlerSendBackSubmit 实例。
			// 2. 调用其 CurrentStatus 方法。
			// 3. 断言返回值等于常量 _const.PreSalesContractSendBack。

			h := &handlerSendBackSubmit{}

			result := h.CurrentStatus()

			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSendBack)
		})
	})
}

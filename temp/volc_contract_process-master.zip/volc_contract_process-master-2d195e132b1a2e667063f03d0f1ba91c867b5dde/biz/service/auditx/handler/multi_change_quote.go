package handler

// import (
// 	"context"
// 	"encoding/json"
// 	"strings"
// 	"time"
//
// 	"volc_contract_process/biz/bizmodels"
// 	"volc_contract_process/biz/bizmodels/modelcommodity"
// 	"volc_contract_process/biz/service/contractmeta"
// 	"volc_contract_process/biz/service/multienv/i18nfmt"
//
// 	"code.byted.org/gopkg/logs"
//
// 	"volc_contract_process/biz/dal"
// 	"volc_contract_process/biz/service/auditx/auditmodel"
// 	quoteservice "volc_contract_process/biz/service/support/quote"
// 	_const "volc_contract_process/pkg/const"
// 	errorsV2 "volc_contract_process/pkg/errors"
// )
//
// func newHandlerMultiChangeQuote() MultiStatusOpHandler {
// 	return &handlerMultiChangeQuote{
// 		contractDao:  dal.NewContractMetaDao(),
// 		quoteService: quoteservice.NewService(),
// 	}
// }
//
// // 已退回(2) --- 变更报价单(16) --> 已退回(2)
// // 销售运营专业审核(3) --- 变更报价单(16) --> 销售运营专业审核(3)
// // 财税法交付专业审核(4) --- 变更报价单(16) --> 财税法审核(4)
// // 销售确认中(5) --- 变更报价单(16) --> 销售确认中(5)
// // 有修改(6) --- 变更报价单(16) --> 有修改(6)
// // 销售运营完善信息(7) --- 变更报价单(16) --> 销售运营完善信息(7)
// type handlerMultiChangeQuote struct {
// 	handlerCommon
// 	contractDao  dal.ContractMetaDao
// 	quoteService quoteservice.Service
// }
//
// func (h *handlerMultiChangeQuote) CurrentStatus() int {
// 	panic("unexpected call MultiStatusOpHandler CurrentStatus() method")
// }
//
// func (h *handlerMultiChangeQuote) SupportStatus() []int {
// 	return []int{
// 		_const.PreSalesContractNotCreated,
// 		_const.PreSalesContractDraft,
// 		_const.PreSalesContractSendBack,
// 		_const.PreSalesContractSalesOperationReview,
// 		_const.PreSalesContractSolutionReview,
// 		_const.PreSalesContractFinanceTaxationLegalReview,
// 		_const.PreSalesContractCustomerConfirm,
// 		_const.PreSalesContractChange,
// 		_const.PreSalesContractSalesOperationCompleteInformation,
// 	}
// }
//
// func (h *handlerMultiChangeQuote) CurrentOp() int {
// 	return _const.OperationChangeQuoteNo
// }
//
// func (h *handlerMultiChangeQuote) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
// 	// 处理补充协议场景下 相关逻辑校验
// 	if err := h.validateSupply(ctx, pc); err != nil {
// 		return err
// 	}
// 	return nil
// }
//
// func (h *handlerMultiChangeQuote) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
//
// 	extra := pc.Extra
// 	var changeInfo bizmodels.ChangeQuoteExtra
// 	if err := json.Unmarshal([]byte(extra), &changeInfo); err != nil {
// 		return i18nfmt.New(ctx, "变更报价单信息为空")
// 	}
// 	pc.Extra = ""
//
// 	newQuote := changeInfo.QuoteID
// 	oldQuoteID := pc.ContractInfo.RelateQuoteNo
//
// 	if newQuote == "" {
// 		return i18nfmt.New(ctx, "变更报价单信息为空")
// 	}
//
// 	if len(pc.PreContractVO.TemplateInfo) > 0 {
// 		return i18nfmt.New(ctx, "合同关联合同模板，不允许更换报价单。")
// 	}
//
// 	logs.CtxInfo(ctx, "handlerMultiChangeQuoteProcess, quoteID=%s, oldQuoteID=%s", newQuote, oldQuoteID)
//
// 	if pc.ContractInfo.RelateQuoteNo == newQuote {
// 		logs.CtxInfo(ctx, "handlerMultiChangeQuoteProcessIgnore, newQuote=%s, oldQuote=%s", newQuote, oldQuoteID)
// 		return i18nfmt.Errorf(ctx, "变更报价单信息[%s]解析失败,报价单未变更", newQuote)
// 	}
//
// 	// 判断报价单是否被使用
// 	resp, apiErr := h.getMetaCommodityService(ctx).HasQuoteRelateContract(ctx, newQuote)
// 	if apiErr != nil {
// 		logs.CtxError(ctx, "HasQuoteRelateContractCheckFail, quoteNo=%s, err=%s", newQuote, apiErr.Error())
// 		return errorsV2.ErrQuoteCommon.WithArgs(apiErr.Error())
// 	}
// 	// HasQuoteRelateContract方法中保证：err==nil时，resp!=nil
// 	if resp.Related {
// 		return errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "当前报价单已经被其他合同关联：%v", resp.RelatedContractList))
// 	}
//
// 	// 查询报价单详情
// 	manageInfo, metaExtMap, err := h.quoteService.BuildProductInfosFromQuote(ctx, newQuote, pc.ContractInfo.ManageInfo, pc.ContractInfo.SupplyScene)
// 	if err != nil {
// 		return err
// 	}
// 	if manageInfo == nil {
// 		return i18nfmt.Errorf(ctx, "变更报价单信息[%s]解析失败", newQuote)
// 	}
//
// 	pc.ContractInfo.ManageInfo = manageInfo
// 	pc.ContractInfo.Ext = metaExtMap
// 	// 项目信息
// 	detail, err := h.quoteService.GetCreateQuoteReq(ctx, newQuote)
// 	if err != nil {
// 		return i18nfmt.Errorf(ctx, "报价单[%s]查询详情失败", newQuote)
// 	}
// 	pc.ContractInfo.ProjectInfo = h.quoteService.BuildProjectInfo(ctx, detail, pc.ContractInfo.ProjectInfo)
//
// 	pc.PreContractVO.RelateQuoteNo = newQuote
//
// 	// 更新manage_info信息
// 	manageInfo.RelateQuoteChanged = true
// 	manageInfo.RelateQuoteChangedBefore = pc.ContractInfo.RelateQuoteNo
//
// 	// 特殊合同类型判定
// 	var specialContractTypes []string
// 	if _, ok := metaExtMap[_const.ExtKeyQuoteGuarantee]; ok {
// 		pc.PreContractVO.SpecialContractType = _const.SpecialContractTypeGuarantee
// 		specialContractTypes = append(specialContractTypes, _const.SpecialContractTypeGuarantee)
// 	} else {
// 		pc.PreContractVO.SpecialContractType = ""
// 	}
// 	// 阶梯报价合同
// 	if manageInfo.QuoteType == _const.QuoteTypeLadderQuote {
// 		specialContractTypes = append(specialContractTypes, _const.SpecialContractTypeLadderQuotation)
// 	}
//
// 	// 更换报价单场景，清空该合同上生效时间相关的五个参数
// 	pc.ContractInfo.BasicInfo.BeginTime = ""
// 	pc.ContractInfo.BasicInfo.EndTime = ""
// 	pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
// 	pc.ContractInfo.BasicInfo.IndefiniteDateFlag = ""
// 	pc.ContractInfo.BasicInfo.UsefulLifeUnit = ""
// 	pc.ContractInfo.BasicInfo.UsefulLifeNum = 0
// 	pc.ContractInfo.BasicInfo.LongLifeReason = ""
// 	pc.ContractInfo.BasicInfo.WhetherProject = manageInfo.WhetherProject
// 	pc.ContractInfo.BasicInfo.BusinessType = detail.BizInfo.TradeTypeCode
// 	pc.ContractInfo.BasicInfo.SpecialContractType = strings.Join(specialContractTypes, ",")
// 	basicInfoBody, _ := json.Marshal(pc.ContractInfo.BasicInfo)
// 	pc.PreContractVO.BasicInfo = string(basicInfoBody)
//
// 	var tradePartyInfo *bizmodels.TradePartyInfo
// 	if len(manageInfo.QuoteAccountID) > 0 {
// 		// 更新交易双方信息
// 		tradePartyInfo, err = h.fillTradePartyInfo(ctx, manageInfo, pc, detail.BizInfo)
// 		if err != nil {
// 			logs.CtxError(ctx, "fillTradePartyInfoFail, accountID:%d, err:%v", manageInfo.QuoteAccountID, err)
// 			return err
// 		}
// 		// 合同价验重
// 		repeatInfo, err := h.checkContractDiscount(ctx, manageInfo.QuoteAccountID, pc, changeInfo)
// 		if err != nil {
// 			logs.CtxError(ctx, "checkContractDiscountFail, accountID:%d, err:%v", manageInfo.QuoteAccountID, err)
// 			return err
// 		}
// 		if repeatInfo != nil && repeatInfo.Repeated {
// 			// 合同价重复 更新错误信息
// 			repeatBody, _ := json.Marshal(repeatInfo)
// 			metaExtMap[_const.ExtKeyContractPriceRepeatInfo] = string(repeatBody)
// 		}
// 		// 合同价预校验
// 		if err := h.checkPreCheckContractDiscount(ctx, pc.ContractInfo); err != nil {
// 			return err
// 		}
// 	} else {
// 		// accountID为空是 清空对方主体中的accountID信息，方便销售重新选择
// 		tradePartyInfo = h.clearTradePartyInfoAccountID(ctx, pc)
// 	}
//
// 	pc.Remark = i18nfmt.Sprintf(ctx, "更换后报价单号：%s", newQuote)
//
// 	tradePartyInfoBody, _ := json.Marshal(tradePartyInfo)
// 	projectInfoBody, _ := json.Marshal(pc.ContractInfo.ProjectInfo)
//
// 	updates := map[string]interface{}{
// 		"trade_party_info": string(tradePartyInfoBody),
// 		"project_info":     string(projectInfoBody),
// 		"basic_info":       string(basicInfoBody),
// 		"relate_quote_no":  newQuote,
// 		// "contract_price_repeat_info": repeatInfoStr,
// 		"begin_time":            time.Time{},
// 		"end_time":              time.Time{},
// 		"special_contract_type": pc.ContractInfo.BasicInfo.SpecialContractType,
// 	}
// 	err = h.contractDao.UpdateFieldsByNo(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, updates)
// 	if err != nil {
// 		logs.CtxError(ctx, "更新交易对方信息失败, updates=%+v, err=%s", updates, err.Error())
// 		return i18nfmt.Errorf(ctx, "变更报价单信息[%s],更新交易对方信息失败", newQuote)
// 	}
// 	err = h.SaveManageInfo(ctx, pc.GetTx(), manageInfo, pc.PreContractVO)
// 	if err != nil {
// 		logs.CtxError(ctx, "更新管理信息失败, manageInfo=%+v, err=%s", manageInfo, err.Error())
// 		return i18nfmt.Errorf(ctx, "变更报价单信息[%s],更新管理信息失败", newQuote)
// 	}
//
// 	err = h.SaveTradePartyInfo(ctx, pc.GetTx(), tradePartyInfo, pc.PreContractVO)
// 	if err != nil {
// 		logs.CtxError(ctx, "更新交易双方信息失败, manageInfo=%+v, err=%s", manageInfo, err.Error())
// 		return i18nfmt.Errorf(ctx, "变更报价单信息[%s],更新交易双方信息失败", newQuote)
// 	}
//
// 	// 更换报价单时，需要删除原先Ext表中，与原报价单相关的内容，具体是代金券&&保底信息
// 	// 合同附加信息创建&更新方法 方法内不删除 在外部处理删除逻辑
// 	err = h.SaveMetaExt(ctx, pc.GetTx(), _const.ReplaceQuoteRemoveExtKey, metaExtMap, pc.PreContractVO)
// 	if err != nil {
// 		logs.CtxError(ctx, "更新合同附加信息失败, metaExtMap=%+v, err=%s", metaExtMap, err.Error())
// 		return i18nfmt.Errorf(ctx, "报价单[%s]更新合同附加信息失败", newQuote)
// 	}
//
// 	// 通知报价系统绑定、解绑合同 出错时 仅提供报报警
// 	_ = quoteservice.NewService().ChangeQuoteContract(ctx, oldQuoteID, newQuote, pc.ContractInfo.ContractNo)
//
// 	return nil
// }
//
// func (h *handlerMultiChangeQuote) checkContractDiscount(ctx context.Context, accountID string, pc *auditmodel.ProcessCtx, changeInfo bizmodels.ChangeQuoteExtra) (*bizmodels.ContractPriceRepeatInfoV1, error) {
// 	contractInfo := pc.ContractInfo
// 	// 校验合同价重复
// 	var skipContractNoList []string
// 	if contractInfo.SupplyScene != _const.SupplySceneNew { // 补充协议
// 		// 更换报价单补充协议校验
// 		if supplyContractListResp, err := h.getMetaService(ctx).GetSupplyContractList(ctx, contractInfo.FromContractNo, false); err != nil {
// 			return nil, err
// 		} else if supplyContractListResp != nil {
// 			skipContractNoList = supplyContractListResp.ParentContractList
// 		}
// 	}
//
// 	beginTime, endTime := contractInfo.CalcQuoteValidity()
//
// 	// 拼接list
// 	var productLevelList []*bizmodels.ProductInfo
// 	for _, list := range contractInfo.ManageInfo.ProductLevelMap {
// 		productLevelList = append(productLevelList, list...)
// 	}
//
// 	isProject := _const.FALSE_FLAG_INT_STR
// 	if contractInfo.ManageInfo.WhetherProject == _const.Yes {
// 		isProject = _const.TRUE_FLAG_INT_STR
// 	}
// 	// 若合同类型为 BP分销，需传入最终用户信息
// 	var ownerID string
// 	if contractInfo.BasicInfo.BusinessType == _const.BusinessTypeBPDistribution &&
// 		contractInfo.ManageInfo.DistributBusinessType == _const.DistributBusinessTypeSpecial {
// 		ownerID = contractInfo.TradePartyInfo.EndUserAccountID
// 	}
// 	// 校验合同价 多账号 循环校验
// 	accountIdList := strings.Split(accountID, ",")
// 	repeatData, err := h.getMetaServiceV2(ctx).CheckQuoteItemRepeat(ctx, &modelcommodity.CheckQuoteItemRepeatReq{
// 		BizSource:          _const.BizSourceCooperation,
// 		AccountIDs:         accountIdList,
// 		ContractNo:         contractInfo.ContractNo,
// 		QuoteNo:            changeInfo.QuoteID,
// 		ProductList:        contractmeta.ConvertProductInfoForSales(productLevelList),
// 		SkipContractNoList: skipContractNoList,
// 		ValidityBegin:      beginTime,
// 		ValidityEnd:        endTime,
// 		IsProject:          isProject,
// 		OwnerID:            ownerID,
// 	})
// 	if err != nil {
// 		logs.CtxError(ctx, "CheckContractDiscountFail, quoteNo=%s, err=%s", changeInfo.QuoteID, err.Error())
// 		return nil, errorsV2.ErrInternalError.WithArgs("合同价[%s]重复校验失败", changeInfo.QuoteID)
// 	}
//
// 	if repeatData.Repeat {
// 		// 合同价重复 记录重复信息
// 		if !changeInfo.IgnorePriceRepeatReturn {
// 			commodityMsg, _ := json.Marshal(repeatData.CommodityRepeatMsg)
// 			priceMsg, _ := json.Marshal(repeatData.ContractPriceRepeatMsg)
// 			// 不忽略报价重复，将错误信息直接返回
// 			return nil, errorsV2.ErrQuoteDuplicated.WithArgs(strings.Join([]string{string(commodityMsg), string(priceMsg)}, "\n"))
// 		}
// 		if err := ClearContractRepeatQuote(ctx, pc, GetCommodityRepeatMsgMap(ctx, repeatData, changeInfo.QuoteID)); err != nil {
// 			logs.CtxError(ctx, "ClearContractRepeatQuoteFail, err:%v", err)
// 			return nil, err
// 		}
// 		pc.Remark = i18nfmt.Sprintf(ctx, "更换后报价单号：%s，与现有合同价重复，%v", changeInfo.QuoteID, changeInfo)
// 	}
//
// 	return &bizmodels.ContractPriceRepeatInfoV1{
// 		QuoteNo:      changeInfo.QuoteID,
// 		Repeated:     repeatData.Repeat,
// 		Msg:          repeatData.ContractPriceRepeatMsg,
// 		CommodityMsg: repeatData.CommodityRepeatMsg,
// 	}, nil
// }
//
// func (h *handlerMultiChangeQuote) clearTradePartyInfoAccountID(ctx context.Context, pc *auditmodel.ProcessCtx) *bizmodels.TradePartyInfo {
// 	logs.CtxInfo(ctx, "clearTradePartyInfoAccountID")
// 	// 更新交易对方信息
// 	tradePartyInfo := pc.ContractInfo.TradePartyInfo
// 	if tradePartyInfo == nil {
// 		tradePartyInfo = &bizmodels.TradePartyInfo{}
// 	}
// 	if len(tradePartyInfo.OtherParty) == 0 {
// 		tradePartyInfo.OtherParty = append(tradePartyInfo.OtherParty, &bizmodels.TradePartyInfoDetail{})
// 	} else {
// 		for _, v := range tradePartyInfo.OtherParty {
// 			v.AccountID = ""
// 		}
// 	}
// 	return tradePartyInfo
// }
//
// func (h *handlerMultiChangeQuote) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
// 	return false, nil
// }
//
// func (h *handlerMultiChangeQuote) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
// 	return nil
// }

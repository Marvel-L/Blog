package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSendBackUpdate() StatusOpHandler {
	return &handlerSendBackUpdate{}
}

// 已退回(2) --- 提交草稿(0) --> 已退回(2)
type handlerSendBackUpdate struct {
	handlerCommon
}

func (h *handlerSendBackUpdate) CurrentStatus() int {
	return _const.PreSalesContractSendBack
}

func (h *handlerSendBackUpdate) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerSendBackUpdate) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerSendBackUpdate) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerSendBackUpdate) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerSendBackUpdate) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

package handler

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/support/metacommodity"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"
)

func newHandlerHaveChangeUpdate() StatusOpHandler {
	return &handlerHaveChangeUpdate{}
}

// 销售运营完善信息(7) --- 提交草稿(0) --> 销售运营完善信息(7)
type handlerHaveChangeUpdate struct {
	handlerCommon
}

func (h *handlerHaveChangeUpdate) CurrentStatus() int {
	return _const.PreSalesContractChange
}

func (h *handlerHaveChangeUpdate) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerHaveChangeUpdate) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 客户有修改阶段 若出现报价单变更，需重新填充报价单信息
	if pc.RelateQuoteChange {
		// 更换报价单需清空相关的 ExtKey
		pc.DelExtKeys = append(pc.DelExtKeys, _const.ReplaceQuoteRemoveExtKey...)
		// 处理补充协议场景下 相关逻辑校验
		if err := h.validateSupply(ctx, pc); err != nil {
			return err
		}
		if !pc.IsQuoteUnbinding() {
			// 填充与校验报价单信息
			if err := h.validateRequireQuote(ctx, pc); err != nil {
				return err
			}
		}

	}
	return nil
}

func (h *handlerHaveChangeUpdate) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerHaveChangeUpdate) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerHaveChangeUpdate) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.IsQuoteUnbinding() {
		return h.getCommodityService(ctx).ClearQuoteRelatedData(ctx, pc.GetTx(), &metacommodity.ClearQuoteRelatedDataReq{
			Scene:      metacommodity.QuoteCleanupSceneApprovedToUnapproved,
			Meta:       pc.PreContractVO,
			ManageInfo: pc.ContractInfo.ManageInfo,
			QuoteNo:    pc.RelateQuoteChangeBeforeValue,
		})
	}
	if pc.RelateQuoteChange {
		// 存储报价单变更信息
		logs.CtxInfo(ctx, "SaveQuoteChangeInfo, contractNo=%s", pc.ContractInfo.ContractNo)
		err := rediscli.SetQuoteChangeInfoFlag(ctx, pc.ContractInfo.ContractNo, &bizmodels.QuoteChangeInfo{
			RelateQuoteNo:            pc.ContractInfo.RelateQuoteNo,
			RelateQuoteChangedBefore: pc.RelateQuoteChangeBeforeValue,
			RelateQuoteChanged:       true,
		})
		if err != nil {
			logs.CtxWarn(ctx, "SetQuoteChangeInfoFlagFail, err=%s", err.Error())
		}
		// 更换报价单
		_, err = quotecli.ChangeQuoteContract(ctx, pc.RelateQuoteChangeBeforeValue, pc.ContractInfo.RelateQuoteNo, pc.ContractInfo.ContractNo)
		if err != nil {
			logs.CtxWarn(ctx, "ChangeQuoteContractFail, err=%s", err.Error())
			return err
		}
	}
	return nil
}

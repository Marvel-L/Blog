package handler

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"testing"
	"time"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerFTLSignReviewPass_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewPass_PostProcess", t, func() {
		h := &handlerFTLSignReviewPass{}
		ctx := context.Background()

		mockey.PatchConvey("scenario: reviewPassSendReviewedMessage returns an error", func() {
			// 场景描述：
			// 构造数据：无特殊构造。
			// 逻辑链路：
			// 1. 调用 h.reviewPassSendReviewedMessage，返回一个错误。
			// 2. 函数应记录错误日志并立即返回该错误。

			// Arrange
			mockErr := errors.New("send reviewed message failed")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(mockErr).Build()
			pc := &auditmodel.ProcessCtx{}

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "send reviewed message failed")
		})

		mockey.PatchConvey("scenario: pc.StatusChanged is false, should return nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 StatusChanged 字段为 false。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 调用成功。
			// 2. 由于 pc.StatusChanged 为 false，函数不进入任何 if/else if 分支。
			// 3. 函数直接返回 nil。

			// Arrange
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			pc := &auditmodel.ProcessCtx{
				StatusChanged: false,
			}

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("scenario: status changed to PreSalesContractRiskReview, should send lark message", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 StatusChanged 为 true，且 ContractNewStatusOnSuccess 为 PreSalesContractRiskReview。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 调用成功。
			// 2. 条件 pc.StatusChanged && pc.ReviewerStatusOpConf.ContractNewStatusOnSuccess == _const.PreSalesContractRiskReview 成立。
			// 3. 进入 if 分支，调用相关函数获取审核人并构建飞书卡片消息。
			// 4. 调用 larkc.BatchSendMessageToEmailIgnore 发送消息。
			// 5. 函数返回 nil。

			// Arrange
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return([]string{"sales.op@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales.person@example.com"}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return format }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review").Build()

			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusOnSuccess: _const.PreSalesContractRiskReview,
				},
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-123",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("scenario: status changed to PreSalesContractSubmitOA", func() {

			mockey.PatchConvey("sub-scenario: updateContractData fails", func() {
				// 场景描述：
				// 构造数据：ProcessCtx 的 StatusChanged 为 true，且 ContractNewStatusOnSuccess 为 PreSalesContractSubmitOA。
				// 逻辑链路：
				// 1. h.reviewPassSendReviewedMessage 调用成功。
				// 2. 条件 pc.StatusChanged && pc.ReviewerStatusOpConf.ContractNewStatusOnSuccess == _const.PreSalesContractSubmitOA 成立。
				// 3. 进入 else if 分支，调用 h.updateContractData，该调用返回一个错误。
				// 4. 函数记录错误日志，包装错误并返回。

				// Arrange
				mockErr := errors.New("update contract data failed")
				mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractData).Return(mockErr).Build()

				pc := &auditmodel.ProcessCtx{
					StatusChanged: true,
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ContractNewStatusOnSuccess: _const.PreSalesContractSubmitOA,
					},
					PreContractVO: &model.ContractMetaDB{},
				}

				// Act
				err := h.PostProcess(ctx, pc)

				// Assert
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "update contract data failed")
			})

			mockey.PatchConvey("sub-scenario: SendSubmitOaMsg fails", func() {
				// 场景描述：
				// 构造数据：ProcessCtx 的 StatusChanged 为 true，且 ContractNewStatusOnSuccess 为 PreSalesContractSubmitOA。
				// 逻辑链路：
				// 1. h.reviewPassSendReviewedMessage 调用成功。
				// 2. 进入 else if 分支，调用 h.updateContractData 成功。
				// 3. 调用 h.SendSubmitOaMsg，该调用返回一个错误。
				// 4. 函数直接返回该错误。

				// Arrange
				mockErr := errorsV2.ErrCommon.WithArgs("send submit oa msg failed")
				mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
				mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(mockErr).Build()

				pc := &auditmodel.ProcessCtx{
					StatusChanged: true,
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ContractNewStatusOnSuccess: _const.PreSalesContractSubmitOA,
					},
					PreContractVO: &model.ContractMetaDB{},
				}

				// Act
				err := h.PostProcess(ctx, pc)

				// Assert
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "send submit oa msg failed")
			})

			mockey.PatchConvey("sub-scenario: all succeed", func() {
				// 场景描述：
				// 构造数据：ProcessCtx 的 StatusChanged 为 true，且 ContractNewStatusOnSuccess 为 PreSalesContractSubmitOA。
				// 逻辑链路：
				// 1. h.reviewPassSendReviewedMessage 调用成功。
				// 2. 进入 else if 分支，调用 h.updateContractData 成功。
				// 3. 调用 h.SendSubmitOaMsg 成功。
				// 4. 函数最终返回 nil。

				// Arrange
				mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()
				mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()

				pc := &auditmodel.ProcessCtx{
					StatusChanged: true,
					ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
						ContractNewStatusOnSuccess: _const.PreSalesContractSubmitOA,
					},
					PreContractVO: &model.ContractMetaDB{},
				}

				// Act
				err := h.PostProcess(ctx, pc)

				// Assert
				convey.So(err, convey.ShouldBeNil)
				convey.So(pc.PreContractVO.SubmitTime.IsZero(), convey.ShouldBeFalse)
			})
		})

		mockey.PatchConvey("scenario: no matching conditions, should return nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 StatusChanged 为 true，但 ContractNewStatusOnSuccess 不匹配任何分支。
			// 逻辑链路：
			// 1. h.reviewPassSendReviewedMessage 调用成功。
			// 2. 由于 ContractNewStatusOnSuccess 不匹配任何条件，不进入任何 if/else if 分支。
			// 3. 函数最终返回 nil。

			// Arrange
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()
			pc := &auditmodel.ProcessCtx{
				StatusChanged: true,
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusOnSuccess: 999, // An unmatched status
				},
			}
			pc.PreContractVO = &model.ContractMetaDB{
				SubmitTime: time.Time{},
			}

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.SubmitTime.IsZero(), convey.ShouldBeTrue)
		})
	})
}

func Test_handlerFTLSignReviewPass_GetStatusOpConfKey_BitsUTGen(t *testing.T) {
	// MockContractMetaDao is a mock type for dal.ContractMetaDao
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}
	// MockRiskClauseRoleDao is a mock type for dal.RiskClauseRoleDao
	type MockRiskClauseRoleDao struct {
		dal.RiskClauseRoleDao
	}

	mockey.PatchConvey("Test_handlerFTLSignReviewPass_GetStatusOpConfKey", t, func() {
		// h is the handler instance to be tested.
		h := &handlerFTLSignReviewPass{}
		// ctx is the context for the test.
		ctx := context.Background()
		// pc is the process context for the test.
		pc := &auditmodel.ProcessCtx{
			PreContractNo: "test-contract-no",
		}

		mockey.PatchConvey("存在未审核通过的风险条款，应返回RiskRoleNotApproved", func() {
			// 场景描述：
			// 构造数据：构造一个状态不是“审批通过”或“已关闭”的风险条款。
			// 逻辑链路：
			// 1. pc.GetTx() 返回一个有效的 *gorm.DB 实例。
			// 2. dal.NewContractMetaDao() 返回一个MockContractMetaDao实例。
			// 3. MockContractMetaDao.FindByNoForSales 返回一个有效的合同元数据。
			// 4. dal.NewRiskClauseRoleDao() 返回一个MockRiskClauseRoleDao实例。
			// 5. MockRiskClauseRoleDao.ListByVolcContractId 返回一个包含未审批通过风险条款的列表。
			// 6. utils.IntIn 对未通过的条款返回 false, 导致 !utils.IntIn 为 true，进入 if 分支。
			// 7. validateRiskClauseRole 函数返回一个错误。
			// 8. GetStatusOpConfKey 捕获错误并返回 _const.ApprovalStatusKeyRiskRoleNotApproved。
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
			mockey.Mock(dal.NewRiskClauseRoleDao).Return(&MockRiskClauseRoleDao{}).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(model.RiskClauseRoleDBList{
				{BaseDB: model.BaseDB{Status: _const.ApprovalRiskRoleStatus}}, // 审批中状态
			}, nil).Build()
			// 在此场景下，我们希望 `utils.IntIn` 返回 `false`，以触发错误路径。
			mockey.Mock(utils.IntIn).Return(false).Build()

			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyRiskRoleNotApproved)
		})

		mockey.PatchConvey("所有风险条款均已审核通过，应返回Default", func() {
			// 场景描述：
			// 构造数据：构造所有风险条款的状态均为“审批通过”或“已关闭”。
			// 逻辑链路：
			// 1. pc.GetTx() 返回一个有效的 *gorm.DB 实例。
			// 2. dal.NewContractMetaDao() 和 dal.NewRiskClauseRoleDao() 返回mock实例。
			// 3. FindByNoForSales 返回有效的合同元数据。
			// 4. ListByVolcContractId 返回一个包含已通过和已关闭风险条款的列表。
			// 5. utils.IntIn 对所有条款均返回 true, 导致 !utils.IntIn 为 false, 不进入 if 分支。
			// 6. validateRiskClauseRole 函数返回 nil。
			// 7. GetStatusOpConfKey 返回 _const.ApprovalStatusKeyDefault。
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
			mockey.Mock(dal.NewRiskClauseRoleDao).Return(&MockRiskClauseRoleDao{}).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(model.RiskClauseRoleDBList{
				{BaseDB: model.BaseDB{Status: _const.PassRiskRoleStatus}},
				{BaseDB: model.BaseDB{Status: _const.CloseRiskRoleStatus}},
			}, nil).Build()
			// 在此场景下，我们希望 `utils.IntIn` 返回 `true`，以模拟检查通过。
			mockey.Mock(utils.IntIn).Return(true).Build()

			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})

		mockey.PatchConvey("没有风险条款，应返回Default", func() {
			// 场景描述：
			// 构造数据：合同没有关联的风险条款。
			// 逻辑链路：
			// 1. pc.GetTx() 返回一个有效的 *gorm.DB 实例。
			// 2. dal.NewContractMetaDao() 和 dal.NewRiskClauseRoleDao() 返回mock实例。
			// 3. FindByNoForSales 返回有效的合同元数据。
			// 4. ListByVolcContractId 返回一个空列表。
			// 5. validateRiskClauseRole 函数直接返回 nil。
			// 6. GetStatusOpConfKey 返回 _const.ApprovalStatusKeyDefault。
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
			mockey.Mock(dal.NewRiskClauseRoleDao).Return(&MockRiskClauseRoleDao{}).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(model.RiskClauseRoleDBList{}, nil).Build()

			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})

		mockey.PatchConvey("查询合同元数据失败，应返回RiskRoleNotApproved", func() {
			// 场景描述：
			// 构造数据：模拟数据库查询合同元数据失败。
			// 逻辑链路：
			// 1. pc.GetTx() 返回一个有效的 *gorm.DB 实例。
			// 2. dal.NewContractMetaDao() 返回mock实例。
			// 3. FindByNoForSales 返回一个错误。
			// 4. validateRiskClauseRole 函数返回该错误。
			// 5. GetStatusOpConfKey 捕获错误并返回 _const.ApprovalStatusKeyRiskRoleNotApproved。
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(nil, errors.New("db error")).Build()

			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyRiskRoleNotApproved)
		})

		mockey.PatchConvey("查询风险条款列表失败，应返回RiskRoleNotApproved", func() {
			// 场景描述：
			// 构造数据：模拟数据库查询风险条款列表失败。
			// 逻辑链路：
			// 1. pc.GetTx() 返回一个有效的 *gorm.DB 实例。
			// 2. dal.NewContractMetaDao() 和 dal.NewRiskClauseRoleDao() 返回mock实例。
			// 3. FindByNoForSales 返回有效的合同元数据。
			// 4. ListByVolcContractId 返回一个错误。
			// 5. validateRiskClauseRole 函数返回该错误。
			// 6. GetStatusOpConfKey 捕获错误并返回 _const.ApprovalStatusKeyRiskRoleNotApproved。
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(&model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
			mockey.Mock(dal.NewRiskClauseRoleDao).Return(&MockRiskClauseRoleDao{}).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(nil, errors.New("db error")).Build()

			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyRiskRoleNotApproved)
		})
	})
}

func Test_handlerFTLSignReviewPass_Validate(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &handlerFTLSignReviewPass{}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			err := v.Validate(context.Background(), &auditmodel.ProcessCtx{})

			// Assert
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case commonCheckReviewerPassFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &handlerFTLSignReviewPass{}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(fmt.Errorf("commonCheckReviewerPassFail")).Build()
			err := v.Validate(context.Background(), &auditmodel.ProcessCtx{})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "commonCheckReviewerPassFail")
		})
	})
	t.Run("case IsReverseContract", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &handlerFTLSignReviewPass{}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(fmt.Errorf("IsReverseContract")).Build()
			err := v.Validate(context.Background(), &auditmodel.ProcessCtx{
				ContractInfo:  &model.ContractMeta{},
				PreContractVO: &model.ContractMetaDB{},
			})

			// Assert
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
}

func Test_newHandlerFTLSignReviewPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLSignReviewPass", t, func() {
		mockey.PatchConvey("正常-成功创建handler", func() {
			// 场景描述：
			// 成功调用 newHandlerFTLSignReviewPass 函数。
			// 构造数据：
			// 无特殊数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerFTLSignReviewPass() 函数。
			// 2. 函数返回一个 non-nil 的 handlerFTLSignReviewPass 实例。
			// 3. 断言返回的实例不为 nil，并且其类型为 *handlerFTLSignReviewPass。

			// 调用
			handler := newHandlerFTLSignReviewPass()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(reflect.TypeOf(handler), convey.ShouldEqual, reflect.TypeOf(&handlerFTLSignReviewPass{}))
		})
	})
}

func Test_handlerFTLSignReviewPass_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewPass_CurrentStatus", t, func() {
		mockey.PatchConvey("should return the correct status for FTL sign review pass", func() {
			// 场景描述：
			// 该测试旨在验证 handlerFTLSignReviewPass 的 CurrentStatus 方法是否返回正确的状态码。
			// 构造数据：
			// - 初始化一个 handlerFTLSignReviewPass 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回的状态码是否为 _const.PreSalesContractFinanceTaxationLegalSignReview。
			// 该函数逻辑简单，直接返回一个常量，因此不需要任何 mock。

			// 初始化 handler
			h := &handlerFTLSignReviewPass{}

			// 调用目标方法
			status := h.CurrentStatus()

			// 断言结果
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		})
	})
}

func Test_handlerFTLSignReviewPass_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewPass_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewPass", func() {
			// 场景描述：
			// 这是一个简单的 getter 方法，直接返回一个常量。
			// 构造数据：
			// 创建一个 handlerFTLSignReviewPass 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值等于预期的常量 _const.OperationReviewPass。

			// 准备数据
			h := &handlerFTLSignReviewPass{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationReviewPass)
		})
	})
}

func Test_handlerFTLSignReviewPass_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewPass_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述：
			// 这是一个简单的成功场景，目标函数没有任何逻辑，直接返回nil。
			// 构造数据：
			// - 构造一个空的 handlerFTLSignReviewPass 实例。
			// - 构造一个空的 ProcessCtx。
			// 逻辑链路：
			// 1. 调用Process方法。
			// 2. 函数直接返回nil。
			// 3. 断言返回的error为nil。

			// 数据准备
			h := &handlerFTLSignReviewPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignReviewPass_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewPass_HitStateChangeCondition", t, func() {
		// 准备通用变量
		ctx := context.Background()
		h := &handlerFTLSignReviewPass{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no-1",
				CooperationStatus: 1,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 2,
			},
		}

		mockey.PatchConvey("成功场景: 所有审批人都已通过", func() {
			// 场景描述:
			// 测试 HitStateChangeCondition 在所有审批人都已通过时，条件命中的场景。
			// 构造数据:
			// - pc 使用预设的合同信息和审批配置。
			// 逻辑链路:
			// 1. Mock dal.IsAllReviewerTypePassed 函数返回 true 和 nil，表示所有审批人都已通过。
			// 2. 调用 h.HitStateChangeCondition。
			// 3. 断言函数返回 true 和 nil 错误。
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(true, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("成功场景: 并非所有审批人都已通过", func() {
			// 场景描述:
			// 测试 HitStateChangeCondition 在尚有待审批的审批人时，条件未命中的场景。
			// 构造数据:
			// - pc 使用预设的合同信息和审批配置。
			// 逻辑链路:
			// 1. Mock dal.IsAllReviewerTypePassed 函数返回 false 和 nil，表示还有待处理的审批。
			// 2. 调用 h.HitStateChangeCondition。
			// 3. 断言函数返回 false 和 nil 错误。
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("失败场景: 检查审批结果时发生错误", func() {
			// 场景描述:
			// 测试在检查审批人状态时，底层依赖 dal.IsAllReviewerTypePassed 返回错误的场景。
			// 构造数据:
			// - pc 使用预设的合同信息和审批配置。
			// - 创建一个模拟的数据库错误。
			// 逻辑链路:
			// 1. Mock dal.IsAllReviewerTypePassed 函数返回 false 和一个错误。
			// 2. Mock i18nfmt.New 函数，以返回预期的包装后错误。
			// 3. 调用 h.HitStateChangeCondition。
			// 4. 断言函数返回 false 和一个非 nil 的错误，且错误信息符合预期。
			dbErr := errors.New("database query failed")
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, dbErr).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("检查节点审批结果失败")).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

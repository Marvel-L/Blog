package handler

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"sync"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/riskclauserole"
	"volc_contract_process/biz/service/support/reviewrule"
	_const "volc_contract_process/pkg/const"
	pkg_errors "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/recovery"
	"volc_contract_process/pkg/util"
)

type MockRiskClauseRoleService struct {
	riskclauserole.Service
}

func Test_handlerMultiAcquireReviewer_currentOperatorReviewers(t *testing.T) {
	mockey.PatchConvey("prefer non-countersign reviewer role for same status and type", t, func() {
		h := &handlerMultiAcquireReviewer{}
		operatorEmail := "operator@example.com"
		reviewers := model.PreContractReviewerDBList{
			{
				BaseDB:         model.BaseDB{Id: 1},
				Reviewer:       operatorEmail,
				ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
				ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
				ReviewerRole:   _const.ReviewerRoleCountersign,
			},
			{
				BaseDB:         model.BaseDB{Id: 2},
				Reviewer:       operatorEmail,
				ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
				ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
				ReviewerRole:   _const.ReviewerRoleLegalBP,
			},
			{
				BaseDB:         model.BaseDB{Id: 3},
				Reviewer:       "other@example.com",
				ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
				ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview,
				ReviewerRole:   _const.ReviewerRoleFinanceBP,
			},
		}

		got := h.currentOperatorReviewers(reviewers, operatorEmail)

		key := fmt.Sprintf("%d_%d", _const.PreSalesContractFinanceTaxationLegalSignReview, _const.ReviewerTypeFinanceTaxationLegalReviewer)
		convey.So(got, convey.ShouldHaveLength, 1)
		convey.So(got[key], convey.ShouldNotBeNil)
		convey.So(got[key].Id, convey.ShouldEqual, uint64(2))
		convey.So(got[key].ReviewerRole, convey.ShouldEqual, _const.ReviewerRoleLegalBP)
	})
}

func Test_handlerMultiAcquireReviewer_Process_BitsUTGen(t *testing.T) {
	mockReviewerDao := &MockPreContractReviewerDao{}
	mockRiskService := &MockRiskClauseRoleService{}

	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_Process", t, func() {
		ctx := context.Background()
		h := &handlerMultiAcquireReviewer{}

		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
		mockey.Mock(riskclauserole.NewService).Return(mockRiskService).Build()

		mockey.Mock(reviewrule.NewReviewerMatcher).Return(&reviewrule.ReviewerMatcher{}).Build()

		mockey.PatchConvey("Error case: failed to get operator info", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, errors.New("lark error")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取当前用户信息失败")
		})

		mockey.PatchConvey("Error case: operator info is nil", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取当前用户信息失败")
		})

		mockey.PatchConvey("Error case: invalid contract status for replacement", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
				},
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 1, Email: "operator@example.com"}, nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "不能进行变更操作")
		})

		mockey.PatchConvey("Error case: failed to find reviewers", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
				},
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 1, Email: "operator@example.com"}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, errors.New("db error")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取当前合同审核人员失败")
		})

		mockey.PatchConvey("Error case: failed to get related reviewers", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
				},
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 1, Email: "operator@example.com"}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(nil, errors.New("matcher error")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "获取审核人员角色失败")
		})

		mockey.PatchConvey("Edge case: no one to be replaced", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
				},
			}
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 1, Email: "operator@example.com"}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{
				{BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}, Reviewer: "other@example.com", ContractStatus: _const.PreSalesContractSalesOperationReview},
			}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(map[int]map[string]struct{}{}, nil).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.InternalState.(*handlerMultiAcquireReviewerState).UniqOriginalEmails, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("Happy path: update and delete reviewers, then succeed", func() {

			operatorEmail := "operator@example.com"
			emailToUpdate := "user-to-update@example.com"
			emailToDelete := "user-to-delete@example.com"

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: operatorEmail,
				ApprovalKey:     _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no-happy",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
					OnlineContract:    "file-id-123",
				},
			}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 100, Email: operatorEmail}, nil).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{

				{BaseDB: model.BaseDB{Id: 1, Status: _const.ReviewStatusUnreviewed}, Reviewer: emailToUpdate, ReviewerType: _const.ReviewerRoleLegalBP, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},

				{BaseDB: model.BaseDB{Id: 2, Status: _const.ReviewStatusUnreviewed}, Reviewer: emailToDelete, ReviewerType: _const.ReviewerRoleSalesOp, ContractStatus: _const.PreSalesContractSalesOperationReview},

				{BaseDB: model.BaseDB{Id: 3, Status: _const.ReviewStatusUnreviewed}, Reviewer: operatorEmail, ReviewerType: _const.ReviewerRoleSalesOp, ContractStatus: _const.PreSalesContractSalesOperationReview},

				{BaseDB: model.BaseDB{Id: 4, Status: _const.ReviewStatusUnreviewed}, Reviewer: "another@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractSalesOperationReview},
			}, nil).Build()

			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(map[int]map[string]struct{}{
				_const.ReviewerRoleLegalBP: {emailToUpdate: {}},
				_const.ReviewerRoleSalesOp: {emailToDelete: {}},
			}, nil).Build()

			mockey.Mock(util.IntIn).Return(true).Build()

			mockey.Mock(dal.GetDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Transaction).To(func(db *gorm.DB, fc func(tx *gorm.DB) error, opts ...*sql.TxOptions) error {
				return fc(&gorm.DB{})
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchReplaceReviewer).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchDeleteReviewer).Return(nil).Build()

			var (
				capturedFileID     string
				capturedPermission int
				capturedEmails     []string
			)
			wg := &sync.WaitGroup{}
			wg.Add(1)
			mockey.Mock(AddFilePermByEmailSync).To(func(ctx context.Context, fileID string, permission int, employeeEmails []string) {
				capturedFileID = fileID
				capturedPermission = permission
				capturedEmails = employeeEmails
				wg.Done()
			}).Build()

			expectedEmails := []string{emailToUpdate, emailToDelete}
			mockey.Mock(util.StringListUnique).Return(expectedEmails).Build()
			mockey.Mock(util.EmailToEmailPrefix).Return("operator").Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)
			wg.Wait()

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.Remark, convey.ShouldEqual, "权限分配成功")

			extraInfo := &OperationAcquireReviewerExtraInfo{}
			_ = json.Unmarshal([]byte(pc.Extra), extraInfo)
			convey.So(extraInfo.To, convey.ShouldResemble, []string{operatorEmail})
			convey.So(extraInfo.From, convey.ShouldResemble, expectedEmails)

			internalState := pc.InternalState.(*handlerMultiAcquireReviewerState)
			convey.So(internalState.UniqOriginalEmails, convey.ShouldResemble, expectedEmails)

			convey.So(capturedFileID, convey.ShouldEqual, "file-id-123")
			convey.So(capturedPermission, convey.ShouldEqual, _const.PermissionWrite)
			convey.So(capturedEmails, convey.ShouldResemble, []string{operatorEmail})
		})

		mockey.PatchConvey("Happy path: update reviewer role when operator already has countersign reviewer", func() {
			operatorEmail := "operator@example.com"
			emailToDelete := "user-to-delete@example.com"

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: operatorEmail,
				ApprovalKey:     _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no-role-update",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
				},
			}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 100, Email: operatorEmail}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{
				{
					BaseDB:         model.BaseDB{Id: 2, Status: _const.ReviewStatusUnreviewed},
					Reviewer:       emailToDelete,
					ReviewerType:   _const.ReviewerTypeSalesperson,
					ReviewerRole:   _const.ReviewerRoleSalesOp,
					ContractStatus: _const.PreSalesContractSalesOperationReview,
				},
				{
					BaseDB:         model.BaseDB{Id: 3, Status: _const.ReviewStatusUnreviewed},
					Reviewer:       operatorEmail,
					ReviewerType:   _const.ReviewerTypeSalesperson,
					ReviewerRole:   _const.ReviewerRoleCountersign,
					ContractStatus: _const.PreSalesContractSalesOperationReview,
				},
			}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(map[int]map[string]struct{}{
				_const.ReviewerRoleSalesOp: {emailToDelete: {}},
			}, nil).Build()
			mockey.Mock(util.IntIn).Return(true).Build()
			mockey.Mock(dal.GetDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Transaction).To(func(db *gorm.DB, fc func(tx *gorm.DB) error, opts ...*sql.TxOptions) error {
				return fc(&gorm.DB{})
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchReplaceReviewer).Return(nil).Build()

			var (
				capturedUpdateID   uint64
				capturedRoleUpdate map[string]interface{}
				capturedDeleteIDs  []uint64
			)
			mockey.Mock((*MockPreContractReviewerDao).UpdateByID).To(func(_ *MockPreContractReviewerDao, _ context.Context, _ *gorm.DB, id uint64, updates map[string]interface{}) error {
				capturedUpdateID = id
				capturedRoleUpdate = updates
				return nil
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchDeleteReviewer).To(func(_ *MockPreContractReviewerDao, _ context.Context, _ *gorm.DB, _ string, ids []uint64) error {
				capturedDeleteIDs = ids
				return nil
			}).Build()
			mockey.Mock(AddFilePermByEmailSync).Return().Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(capturedUpdateID, convey.ShouldEqual, uint64(3))
			convey.So(capturedRoleUpdate["reviewer_role"], convey.ShouldEqual, _const.ReviewerRoleSalesOp)
			convey.So(capturedDeleteIDs, convey.ShouldResemble, []uint64{2})
		})

		mockey.PatchConvey("Error case: DB transaction fails", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no-db-fail",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
				},
			}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 100, Email: "operator@example.com"}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{
				{BaseDB: model.BaseDB{Id: 1, Status: _const.ReviewStatusUnreviewed}, Reviewer: "another@example.com", ReviewerType: _const.ReviewerRoleSalesOp, ContractStatus: _const.PreSalesContractSalesOperationReview},
			}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(map[int]map[string]struct{}{
				_const.ReviewerRoleSalesOp: {"another@example.com": {}},
			}, nil).Build()

			dbErr := errors.New("db transaction error")
			mockey.Mock(dal.GetDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Transaction).To(func(db *gorm.DB, fc func(tx *gorm.DB) error, opts ...*sql.TxOptions) error {
				return fc(&gorm.DB{})
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchReplaceReviewer).Return(dbErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "更新合同审批人员失败")
		})

		mockey.PatchConvey("Error case: ChangeRiskRoleCreator fails", func() {

			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-no-risk-fail",
					CooperationStatus: _const.PreSalesContractSalesOperationReview,
					BasicInfo:         &bizmodels.BasicInfo{DepartmentId: "dep-1"},
				},
			}
			riskErr := pkg_errors.ErrCommon.WithArgs("risk error")

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{ID: 100, Email: "operator@example.com"}, nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetRelatedReviewers).Return(map[int]map[string]struct{}{}, nil).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(riskErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "risk error")
		})

	})
}

func Test_handlerMultiAcquireReviewer_SupportStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_SupportStatus", t, func() {
		mockey.PatchConvey("正常-返回支持的状态列表", func() {
			// 场景描述：
			// 验证 handlerMultiAcquireReviewer 的 SupportStatus 方法是否返回了预期的状态列表。
			// 构造数据：
			// - 创建一个 handlerMultiAcquireReviewer 实例。
			// 逻辑链路：
			// 1. 调用 SupportStatus 方法。
			// 2. 断言返回的切片与预期的切片内容和顺序完全一致。

			// 准备数据
			h := &handlerMultiAcquireReviewer{}
			expectedStatus := []int{
				_const.PreSalesContractSalesOperationReview,
				_const.PreSalesContractFinanceTaxationLegalReview,
				_const.PreSalesContractSalesOperationCompleteInformation,
				_const.PreSalesContractFinanceTaxationLegalSignReview,
				_const.PreSalesContractRiskReview,
				_const.PreSalesContractSolutionReview,
			}

			// 调用目标函数
			actualStatus := h.SupportStatus()

			// 断言结果
			convey.So(reflect.DeepEqual(actualStatus, expectedStatus), convey.ShouldBeTrue)
		})
	})
}

func Test_handlerMultiAcquireReviewer_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationAcquireReviewer", func() {
			// 场景描述:
			// 测试CurrentOp方法返回正确的操作类型常量。
			// 构造数据:
			// 初始化一个handlerMultiAcquireReviewer实例。
			// 逻辑链路:
			// 1. 创建handlerMultiAcquireReviewer实例。
			// 2. 调用CurrentOp方法。
			// 3. 断言返回值等于_const.OperationAcquireReviewer。

			// 数据准备
			h := &handlerMultiAcquireReviewer{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationAcquireReviewer)
		})
	})
}

func Test_handlerMultiAcquireReviewer_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_PostProcess", t, func() {
		// Common setup for all test cases
		h := &handlerMultiAcquireReviewer{}
		ctx := context.Background()

		// Mock i18n and Sprintf to simplify testing by returning the input string/format.
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v
		}).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()

		// Mock the BatchSendMessageToEmailIgnore function as it runs in a goroutine and has external dependencies.
		// We just need to ensure it's mocked to prevent actual execution.
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

		mockey.PatchConvey("scenario: pc.InternalState is nil or not of type *handlerMultiAcquireReviewerState", func() {
			// 场景描述:
			// 构造数据: pc.InternalState 为 nil。
			// 逻辑链路:
			// 1. 函数开始执行。
			// 2. internalState, _ := pc.InternalState.(*handlerMultiAcquireReviewerState) 导致 internalState 为 nil。
			// 3. if internalState != nil 条件不满足。
			// 4. 函数直接返回 nil，不执行任何通知逻辑。
			pc := &auditmodel.ProcessCtx{
				InternalState: nil,
			}
			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("scenario: pc.InternalState is valid", func() {
			// Common data for valid internal state scenarios
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					Operator:       "contract.operator.id",
					ContractNo:     "C-12345",
					OtherPartyName: "Test Customer Inc.",
					ContractName:   "Test Contract 2024",
				},
			}

			// Mock GetEmployeeByID to successfully return an employee email.
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "contract.operator@example.com"},
			}, nil).Build()

			mockey.PatchConvey("case: original reviewers exist and cooperation status leads to edit URL", func() {
				// 场景描述:
				// 构造数据:
				//  - UniqOriginalEmails 列表不为空。
				//  - pc.ContractInfo.CooperationStatus 为 PreSalesContractSalesOperationCompleteInformation。
				// 逻辑链路:
				// 1. internalState 断言成功。
				// 2. larkc.GetEmployeeByID 成功返回业务执行人邮箱。
				// 3. pc.ContractInfo.CooperationStatus 条件判断为 true，调用 larkc.GenEditURL。
				// 4. len(uniqOriginalEmails) > 0 条件为 true。
				// 5. 调用 larkc.BatchSendMessageToEmailIgnore 两次，分别通知新审批人和原审批人。
				pc.InternalState = &handlerMultiAcquireReviewerState{
					UniqOriginalEmails: []string{"old.reviewer1@example.com", "old.reviewer2@example.com"},
				}
				pc.ContractInfo.CooperationStatus = _const.PreSalesContractSalesOperationCompleteInformation

				mockey.Mock(larkc.GenEditURL).Return("http://example.com/edit/C-12345").Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("case: original reviewers exist and cooperation status leads to review URL", func() {
				// 场景描述:
				// 构造数据:
				//  - UniqOriginalEmails 列表不为空。
				//  - pc.ContractInfo.CooperationStatus 不为 PreSalesContractSalesOperationCompleteInformation。
				// 逻辑链路:
				// 1. internalState 断言成功。
				// 2. larkc.GetEmployeeByID 成功返回业务执行人邮箱。
				// 3. pc.ContractInfo.CooperationStatus 条件判断为 false，进入 else 分支，调用 larkc.GenReviewURL。
				// 4. len(uniqOriginalEmails) > 0 条件为 true。
				// 5. 调用 larkc.BatchSendMessageToEmailIgnore 两次，分别通知新审批人和原审批人。
				pc.InternalState = &handlerMultiAcquireReviewerState{
					UniqOriginalEmails: []string{"old.reviewer1@example.com"},
				}
				pc.ContractInfo.CooperationStatus = _const.PreSalesContractDraft

				mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review/C-12345").Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("case: no original reviewers changed (uniqOriginalEmails is empty)", func() {
				// 场景描述:
				// 构造数据:
				//  - UniqOriginalEmails 列表为空。
				// 逻辑链路:
				// 1. internalState 断言成功。
				// 2. larkc.GetEmployeeByID 成功返回业务执行人邮箱。
				// 3. 调用 larkc.GenReviewURL (或 GenEditURL)。
				// 4. len(uniqOriginalEmails) > 0 条件为 false, 进入 else 分支。
				// 5. 调用 larkc.BatchSendMessageToEmailIgnore 一次，通知当前操作人审批人未变更。
				pc.InternalState = &handlerMultiAcquireReviewerState{
					UniqOriginalEmails: []string{},
				}
				pc.ContractInfo.CooperationStatus = _const.PreSalesContractDraft
				mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review/C-12345").Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("case: GetEmployeeByID returns an empty list", func() {
				// 场景描述:
				// 构造数据:
				//  - larkc.GetEmployeeByID 返回空列表。
				// 逻辑链路:
				// 1. internalState 断言成功。
				// 2. larkc.GetEmployeeByID 返回空列表，contractOperatorEmail 将为空字符串。
				// 3. 后续逻辑继续执行，但发送的消息中 "业务执行人" 字段的值为空。
				// 4. 函数应正常执行完毕并返回 nil。
				pc.InternalState = &handlerMultiAcquireReviewerState{
					UniqOriginalEmails: []string{"old.reviewer1@example.com"},
				}
				mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{}, nil).Build()
				mockey.Mock(larkc.GenReviewURL).Return("http://example.com/review/C-12345").Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})
		})
	})
}

func Test_handlerMultiAcquireReviewer_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述:
			// 目标函数 HitStateChangeCondition 的实现是直接返回 false 和 nil，不涉及任何复杂逻辑或外部依赖。
			// 本测试用例旨在验证其基本行为是否符合预期。
			// 构造数据:
			// - h: 一个空的 handlerMultiAcquireReviewer 实例。
			// - ctx: 一个空的 context.Background()。
			// - pc: 一个空的 auditmodel.ProcessCtx 指针。
			// 逻辑链路:
			// 1. 调用 h.HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的错误为 nil。
			h := &handlerMultiAcquireReviewer{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			got, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(got, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_newHandlerMultiAcquireReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerMultiAcquireReviewer", t, func() {
		mockey.PatchConvey("正常场景: 成功创建handler", func() {
			// 场景描述：
			// 调用newHandlerMultiAcquireReviewer函数，期望返回一个非空的MultiStatusOpHandler实例。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerMultiAcquireReviewer()。
			// 2. 断言返回的实例不为nil。
			// 3. 断言返回的实例类型为 *handlerMultiAcquireReviewer。

			// 调用
			handler := newHandlerMultiAcquireReviewer()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerMultiAcquireReviewer{})
		})
	})
}

func Test_handlerMultiAcquireReviewer_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_CurrentStatus", t, func() {
		mockey.PatchConvey("should panic as expected", func() {
			// 场景描述：
			// 构造数据：创建一个handlerMultiAcquireReviewer的实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 预期该方法会立即触发一个panic。
			// 3. 使用ShouldPanicWith断言来捕获并验证panic信息是否符合预期。
			h := &handlerMultiAcquireReviewer{}

			// 调用并断言
			convey.So(func() {
				h.CurrentStatus()
			}, convey.ShouldPanicWith, "unexpected call MultiStatusOpHandler CurrentStatus() method")
		})
	})
}

func Test_handlerMultiAcquireReviewer_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerMultiAcquireReviewer_Validate", t, func() {
		mockey.PatchConvey("Happy Path: should return nil", func() {
			// 场景描述：
			// 测试 handlerMultiAcquireReviewer 的 Validate 方法。
			// 构造数据：
			// - 初始化一个 handlerMultiAcquireReviewer 实例。
			// - 初始化一个空的 context.Context。
			// - 初始化一个空的 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 调用 Validate 方法。
			// 2. 由于该方法当前实现为空，直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerMultiAcquireReviewer{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Validate(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_AddFilePermByEmailSync_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_AddFilePermByEmailSync", t, func() {
		ctx := context.Background()
		fileID := "test_file_id"
		permission := 2 // 2 for write permission

		mockey.PatchConvey("success case", func() {
			// 场景描述：
			// 这是一个成功的场景，所有提供的电子邮件都有效，并且可以成功找到对应的员工，最终文件权限也成功更新。
			// 构造数据：
			// - fileID: "test_file_id"
			// - permission: 2 (写权限)
			// - employeeEmails: ["test1@example.com", "test2@example.com"]
			// 逻辑链路：
			// 1. 遍历 employeeEmails 列表。
			// 2. 对每个 email 调用 `larkc.GetEmployeeByEmailWithCache` 均返回一个有效的 `peopleclient.Employee` 对象和 nil 错误。
			// 3. 构建包含两个用户的 `users` 切片。
			// 4. 调用 `(&handlerCommon{}).addOrUpdateFilePerm`。
			// 5. 在 `addOrUpdateFilePerm` 内部，`recovery.DefaultRecovery` 被调用。
			// 6. 接着调用 `larkc.GetEmployeeByMailsWithCache`，返回两个员工的信息和 nil 错误。
			// 7. 最后调用 `filecli.UpdateUserPermission`，返回 nil 错误，表示权限更新成功。
			// 8. 函数正常结束。
			employeeEmails := []string{"test1@example.com", "test2@example.com"}
			employee1 := &peopleclient.Employee{ID: 1, Name: "User One", Email: "test1@example.com", AvatarURL: "url1"}
			employee2 := &peopleclient.Employee{ID: 2, Name: "User Two", Email: "test2@example.com", AvatarURL: "url2"}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).
				When(func(ctx context.Context, email string) bool {
					return email == "test1@example.com"
				}).Return(employee1, nil).
				When(func(ctx context.Context, email string) bool {
					return email == "test2@example.com"
				}).Return(employee2, nil).
				Build()

			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{employee1, employee2}, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()

			AddFilePermByEmailSync(ctx, fileID, permission, employeeEmails)
		})

		mockey.PatchConvey("partial success: one email lookup fails", func() {
			// 场景描述：
			// 部分成功场景，提供的一个电子邮件无效，无法找到员工。函数应该跳过无效的邮件，并为有效的邮件成功更新权限。
			// 构造数据：
			// - employeeEmails: ["valid@example.com", "invalid@example.com"]
			// 逻辑链路：
			// 1. 遍历 employeeEmails 列表。
			// 2. 对 "valid@example.com" 调用 `larkc.GetEmployeeByEmailWithCache` 成功。
			// 3. 对 "invalid@example.com" 调用 `larkc.GetEmployeeByEmailWithCache` 返回错误，循环继续。
			// 4. `users` 切片只包含一个有效用户。
			// 5. 调用 `addOrUpdateFilePerm`，其内部对 `filecli.UpdateUserPermission` 的调用请求中只包含一个用户。
			// 6. 所有后续调用均成功。
			employeeEmails := []string{"valid@example.com", "invalid@example.com"}
			validEmployee := &peopleclient.Employee{ID: 101, Name: "Valid User", Email: "valid@example.com"}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).
				When(func(_ context.Context, email string) bool {
					return email == "valid@example.com"
				}).Return(validEmployee, nil).
				When(func(_ context.Context, email string) bool {
					return email == "invalid@example.com"
				}).Return(nil, errors.New("user not found")).
				Build()

			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{validEmployee}, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).When(func(_ context.Context, req *filecli.UpdateUserPermissionReq) bool {
				convey.So(len(req.Users), convey.ShouldEqual, 1)
				convey.So(req.Users[0].Email, convey.ShouldEqual, "valid@example.com")
				return true
			}).Return(nil).Build()

			AddFilePermByEmailSync(ctx, fileID, permission, employeeEmails)
		})

		mockey.PatchConvey("all email lookups fail", func() {
			// 场景描述：
			// 所有提供的电子邮件都无效。函数应该不会构建任何用户，并且最终不会调用权限更新接口。
			// 构造数据：
			// - employeeEmails: ["invalid1@example.com", "invalid2@example.com"]
			// 逻辑链路：
			// 1. 遍历 employeeEmails 列表。
			// 2. 所有对 `larkc.GetEmployeeByEmailWithCache` 的调用都返回错误。
			// 3. `users` 切片为空。
			// 4. 调用 `addOrUpdateFilePerm`，但因为用户列表为空，该函数会提前返回。
			// 5. `larkc.GetEmployeeByMailsWithCache` 和 `filecli.UpdateUserPermission` 不会被调用。
			employeeEmails := []string{"invalid1@example.com", "invalid2@example.com"}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, errors.New("user not found")).Build()
			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()

			AddFilePermByEmailSync(ctx, fileID, permission, employeeEmails)
		})

		mockey.PatchConvey("failure in addOrUpdateFilePerm - GetEmployeeByMailsWithCache fails", func() {
			// 场景描述：
			// 初始的用户信息获取成功，但在 `addOrUpdateFilePerm` 内部的 `larkc.GetEmployeeByMailsWithCache` 调用失败。
			// 逻辑链路：
			// 1. `larkc.GetEmployeeByEmailWithCache` 调用成功。
			// 2. `addOrUpdateFilePerm` 被调用。
			// 3. 在 `addOrUpdateFilePerm` 中，`larkc.GetEmployeeByMailsWithCache` 返回错误。
			// 4. 函数记录错误并返回，`filecli.UpdateUserPermission` 不会被调用。
			employeeEmails := []string{"test1@example.com"}
			employee1 := &peopleclient.Employee{ID: 1, Name: "User One", Email: "test1@example.com"}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(employee1, nil).Build()
			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, errors.New("larkc rpc failed")).Build()

			AddFilePermByEmailSync(ctx, fileID, permission, employeeEmails)
		})

		mockey.PatchConvey("failure in addOrUpdateFilePerm - UpdateUserPermission fails", func() {
			// 场景描述：
			// 所有用户信息查找都成功，但在最后调用 `filecli.UpdateUserPermission` 进行权限更新时失败。
			// 逻辑链路：
			// 1. 所有 `larkc` 调用均成功。
			// 2. `addOrUpdateFilePerm` 被调用。
			// 3. 在 `addOrUpdateFilePerm` 中，`filecli.UpdateUserPermission` 返回错误。
			// 4. 函数记录错误并完成执行。
			employeeEmails := []string{"test1@example.com"}
			employee1 := &peopleclient.Employee{ID: 1, Name: "User One", Email: "test1@example.com"}

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(employee1, nil).Build()
			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{employee1}, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(errors.New("filecli rpc failed")).Build()

			AddFilePermByEmailSync(ctx, fileID, permission, employeeEmails)
		})
	})
}

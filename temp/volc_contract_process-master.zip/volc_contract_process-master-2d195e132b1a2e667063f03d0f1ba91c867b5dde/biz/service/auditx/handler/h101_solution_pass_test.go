package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/env"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/biz/dal"
)

func Test_handlerSolutionReviewPass_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionReviewPass_PostProcess", t, func() {
		h := handlerSolutionReviewPass{}
		ctx := context.Background()

		mockey.PatchConvey("success case: status changed, should send lark message", func() {
			// Scene Description:
			// This test case simulates a successful post-process step where the contract status has changed.
			// Data Setup:
			// - pc.StatusChanged is true.
			// - pc.ContractInfo contains reviewers for both sales and finance roles.
			// Logic Flow:
			// 1. Mock `reviewPassSendReviewedMessage` to return success (nil).
			// 2. The code proceeds to the `if pc.StatusChanged` block as the condition is true.
			// 3. Mock `getReviewerFromPreContractReviewerListWithContractStatus` to provide the finance reviewers to be notified.
			// 4. Mock `getReviewerFromPreContractReviewerList` to provide the salesperson's name for the message content.
			// 5. Mock all Lark and i18n related functions (`larkc.BatchSendMessageToEmailIgnore`, `multienv.I18nFormat`, etc.) to prevent actual external calls.
			// 6. The function should execute successfully and return nil.
			pc := &auditmodel.ProcessCtx{
				StatusChanged:      true,
				StatusChangedValue: _const.ReviewerTypeFinanceTaxationLegalReviewer,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-2023-001",
					ContractName:   "Test Contract Name",
					OtherPartyName: "Test Customer",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales.person@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
						{Reviewer: "finance.reviewer@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ReviewerSource: 0, ContractStatus: _const.ReviewerTypeFinanceTaxationLegalReviewer},
					},
				},
			}

			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()

			// Following the prompt's guidance to mock unexported methods on the embedded struct.
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return([]string{"finance.reviewer@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales.person@example.com"}).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(multienv.I18nFormat(ctx, format), a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url/CN-2023-001").Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()
			// Mock env functions used by lark card builder
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(env.PSM).Return("test").Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case: status not changed", func() {
			// Scene Description:
			// This test case covers the scenario where the post-process runs successfully, but the contract status has not changed.
			// Data Setup:
			// - pc.StatusChanged is explicitly set to false.
			// Logic Flow:
			// 1. Mock `reviewPassSendReviewedMessage` to return success (nil).
			// 2. The code evaluates `if pc.StatusChanged`, which is false.
			// 3. The `if` block for sending a Lark message is correctly skipped.
			// 4. The function returns nil without performing further actions.
			pc := &auditmodel.ProcessCtx{
				StatusChanged: false,
			}

			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(nil).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error case: reviewPassSendReviewedMessage fails", func() {
			// Scene Description:
			// This test case simulates a failure in the initial step `reviewPassSendReviewedMessage`.
			// Data Setup:
			// - An empty ProcessCtx is sufficient as the failure happens early.
			// Logic Flow:
			// 1. Mock `reviewPassSendReviewedMessage` to return a specific error.
			// 2. The function should immediately catch this error.
			// 3. The function should log the error (behavior not asserted) and return it to the caller.
			// 4. The rest of the function logic, including the status check, should not be executed.
			pc := &auditmodel.ProcessCtx{}
			mockedErr := errors.New("failed to send reviewed message")
			mockey.Mock((*handlerCommon).reviewPassSendReviewedMessage).Return(mockedErr).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockedErr)
		})
	})
}

func Test_handlerSolutionReviewPass_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionReviewPass Validate", t, func() {
		// Arrange: 公共设置
		h := handlerSolutionReviewPass{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no",
				CooperationStatus: 1,
			},
		}

		// Mock依赖方法
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{
			ReviewerType:   2,
			ContractStatus: 1,
			Priority:       10,
		}).Build()

		mockey.PatchConvey("成功场景: commonCheckReviewerPass检查通过，无前置待审批人", func() {
			// 场景描述：
			// Validate方法依赖的commonCheckReviewerPass检查通过，因为dal.ListHighPriorityReviewerTypeNoPassedReviewer返回空列表，表示没有更高优先级的未通过审批人。
			// 构造数据：
			// - pc: 一个ProcessCtx实例。
			// 逻辑链路：
			// 1. Validate调用h.commonCheckReviewerPass。
			// 2. commonCheckReviewerPass内部调用dal.ListHighPriorityReviewerTypeNoPassedReviewer。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer返回一个空列表和nil error。
			// 4. commonCheckReviewerPass返回nil。
			// 5. Validate返回nil。

			// Arrange
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(model.PreContractReviewerDBList{}, nil).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: 数据库查询失败", func() {
			// 场景描述：
			// Validate方法依赖的commonCheckReviewerPass检查失败，因为查询数据库时dal.ListHighPriorityReviewerTypeNoPassedReviewer返回错误。
			// 构造数据：
			// - pc: 一个ProcessCtx实例。
			// 逻辑链路：
			// 1. Validate调用h.commonCheckReviewerPass。
			// 2. commonCheckReviewerPass内部调用dal.ListHighPriorityReviewerTypeNoPassedReviewer。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer返回一个非nil的error。
			// 4. commonCheckReviewerPass调用i18nfmt.New生成错误信息并返回。
			// 5. Validate返回该错误。

			// Arrange
			dbErr := errors.New("db query failed")
			expectedErrText := "检查节点审批结果失败"
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(nil, dbErr).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErrText)
		})

		mockey.PatchConvey("失败场景: 存在前置待审批人", func() {
			// 场景描述：
			// Validate方法依赖的commonCheckReviewerPass检查失败，因为存在更高优先级的未通过审批人。
			// 构造数据：
			// - pc: 一个ProcessCtx实例。
			// 逻辑链路：
			// 1. Validate调用h.commonCheckReviewerPass。
			// 2. commonCheckReviewerPass内部调用dal.ListHighPriorityReviewerTypeNoPassedReviewer。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer返回一个包含两个待审批人的列表。
			// 4. commonCheckReviewerPass构建错误信息字符串，并调用fmt.Errorf返回错误。
			// 5. Validate返回该错误。

			// Arrange
			pendingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "user.a"},
				{Reviewer: "user.b"},
			}
			expectedErrMsg := "存在前置审批人未审批通过，请等待前加签审批人审核通过后再操作。前置待审核人：user.a、user.b"

			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(pendingReviewers, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErrMsg)
		})
	})
}

func Test_handlerSolutionReviewPass_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionReviewPass_Process", t, func() {
		mockey.PatchConvey("正常处理", func() {
			// 场景描述：
			// 构造数据：构造一个空的 ProcessCtx
			// 逻辑链路：
			// 1. 调用 Process 方法
			// 2. 断言返回的 error 为 nil
			h := handlerSolutionReviewPass{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionReviewPass_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionReviewPass_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationReviewPass", func() {
			// 场景描述：
			// 测试 handlerSolutionReviewPass 的 CurrentOp 方法。
			// 构造数据：
			// - 创建一个 handlerSolutionReviewPass 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否等于预期的常量 _const.OperationReviewPass。

			// 准备数据
			h := handlerSolutionReviewPass{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationReviewPass)
		})
	})
}

func Test_handlerSolutionReviewPass_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionReviewPass_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 验证 handlerSolutionReviewPass 的 CurrentStatus 方法是否正确返回预设的状态值。
			// 构造数据:
			//   - 创建一个 handlerSolutionReviewPass 的实例。
			// 逻辑链路:
			//   1. 调用 CurrentStatus 方法。
			//   2. 断言返回值等于常量 _const.PreSalesContractSolutionReview。

			// 数据准备
			h := handlerSolutionReviewPass{}

			// 调用目标函数
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSolutionReview)
		})
	})
}

func Test_newHandlerSolutionReviewPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSolutionReviewPass", t, func() {
		mockey.PatchConvey("正常情况: 成功创建一个handler", func() {
			// 场景描述:
			// 构造数据: 无
			// 逻辑链路:
			// 1. 调用 newHandlerSolutionReviewPass 函数
			// 2. 断言返回的实例不为 nil
			// 3. 断言返回的实例的底层类型是 *handlerSolutionReviewPass

			// 调用目标函数
			handler := newHandlerSolutionReviewPass()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSolutionReviewPass{})
		})
	})
}

func Test_handlerSolutionReviewPass_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionReviewPass HitStateChangeCondition", t, func() {
		// Prepare common variables
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{}
		h := handlerSolutionReviewPass{
			handlerCommon: handlerCommon{},
		}

		mockey.PatchConvey("when common check returns true, indicating condition is met", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用的 commonCheckHitContractStatusChange 方法返回 true 和 nil，表示状态变更条件已满足。
			// 构造数据：
			// - 一个空的 auditmodel.ProcessCtx，因为它仅作为参数传递给被 mock 的函数。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (true, nil)。
			// 2. 调用目标函数 h.HitStateChangeCondition。
			// 3. 断言目标函数返回 (true, nil)，正确地传递了底层调用的结果。
			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(true, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("when common check returns false, indicating condition is not met", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用的 commonCheckHitContractStatusChange 方法返回 false 和 nil，表示状态变更条件未满足。
			// 构造数据：
			// - 一个空的 auditmodel.ProcessCtx，因为它仅作为参数传递给被 mock 的函数。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (false, nil)。
			// 2. 调用目标函数 h.HitStateChangeCondition。
			// 3. 断言目标函数返回 (false, nil)，正确地传递了底层调用的结果。
			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(false, nil).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("when common check returns an error", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 内部调用的 commonCheckHitContractStatusChange 方法返回一个错误，表示检查过程中发生异常。
			// 构造数据：
			// - 一个空的 auditmodel.ProcessCtx，因为它仅作为参数传递给被 mock 的函数。
			// - 一个自定义的 error 对象。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckHitContractStatusChange 方法，使其返回 (false, error)。
			// 2. 调用目标函数 h.HitStateChangeCondition。
			// 3. 断言目标函数返回 (false, error)，并将底层的错误原样返回。
			mockErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckHitContractStatusChange).Return(false, mockErr).Build()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

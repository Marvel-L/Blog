package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/riskclauserole"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerFTLSignReviewChangeReviewer_Process_BitsUTGen(t *testing.T) {
	// MockRiskClauseRoleService is a mock struct for the riskclauserole.Service interface.
	type MockRiskClauseRoleService struct {
		riskclauserole.Service
	}

	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_Process", t, func() {
		// Initialize the handler instance
		h := &handlerFTLSignReviewChangeReviewer{}
		// Prepare common test data
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: "test-contract-123",
			},
			Extra:           "new_creator@example.com",
			CurrentOperator: "current_operator@example.com",
		}
		mockService := &MockRiskClauseRoleService{}

		mockey.PatchConvey("Success case: ChangeRiskRoleCreator returns no error", func() {
			// 场景描述：
			// 本测试用例模拟风险条款创建人转办成功的场景。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "test-contract-123"
			// - pc.Extra: "new_creator@example.com" (新创建人)
			// - pc.CurrentOperator: "current_operator@example.com" (原创建人)
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 以返回一个 mock service 实例。
			// 2. Mock (*MockRiskClauseRoleService).ChangeRiskRoleCreator 方法，使其返回 nil，表示操作成功。
			// 3. 调用 h.Process 方法。
			// 4. 断言返回的错误为 nil。

			mockey.Mock(riskclauserole.NewService).Return(mockService).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			// Call the target function
			err := h.Process(ctx, pc)

			// Assert the result
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case: ChangeRiskRoleCreator returns an error", func() {
			// 场景描述：
			// 本测试用例模拟风险条款创建人转办失败的场景，例如底层服务调用返回错误。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "test-contract-123"
			// - pc.Extra: "new_creator@example.com" (新创建人)
			// - pc.CurrentOperator: "current_operator@example.com" (原创建人)
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 以返回一个 mock service 实例。
			// 2. Mock (*MockRiskClauseRoleService).ChangeRiskRoleCreator 方法，使其返回一个预设的错误。
			// 3. 调用 h.Process 方法。
			// 4. 断言返回的错误不为 nil，且错误信息与预设错误一致。

			expectedErr := errors.New("failed to change creator")
			mockey.Mock(riskclauserole.NewService).Return(mockService).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(expectedErr).Build()

			// Call the target function
			err := h.Process(ctx, pc)

			// Assert the result
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to change creator")
		})
	})
}

func Test_handlerFTLSignReviewChangeReviewer_PostProcess_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock struct for the PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_PostProcess", t, func() {
		ctx := context.Background()
		h := &handlerFTLSignReviewChangeReviewer{}

		mockey.PatchConvey("Success Case: Change reviewer successfully", func() {
			// 场景描述: 成功转办审核人
			// 构造数据: pc.OperationState设置为OperationChangeReviewer, pc.Extra为新审核人邮箱
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回成功，获取到新审核人信息
			// 2. h.changeReviewer 逻辑成功执行:
			//    a. dal.FindReviewersByNoAndEmail 第一次为旧审核人返回待办角色列表
			//    b. dal.FindReviewersByNoAndEmail 第二次为新审核人返回空列表
			//    c. dal.Create 为新审核人创建待办角色成功
			// 3. dal.DeleteChangedReviewer 成功删除旧审核人待办
			// 4. larkc.BatchSendMessageToEmailIgnore 被调用，发送通知
			// 5. 函数返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "TEST-CONTRACT-NO-01",
					PreContractNo:  "PRE-CONTRACT-NO-01",
					OtherPartyName: "Other Party",
					ContractName:   "Contract Name",
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "D001",
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
				CurrentOperator: "old.reviewer@example.com",
				Extra:           "new.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
			}
			mockDao := &MockPreContractReviewerDao{}
			newReviewerEmployee := &peopleclient.Employee{ID: 123, Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			// Mock dal calls within changeReviewer
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error) {
				if reviewer == pc.CurrentOperator {
					return model.PreContractReviewerDBList{
						{PreContractNo: pc.ContractInfo.PreContractNo, ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: 1},
						{PreContractNo: pc.ContractInfo.PreContractNo, ReviewerType: _const.ReviewerTypeMentioned, ContractStatus: 1}, // this one should be skipped
					}, nil
				}
				if reviewer == newReviewerEmployee.Email {
					return model.PreContractReviewerDBList{}, nil // new reviewer has no existing roles
				}
				return nil, errors.New("unexpected reviewer in mock")
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				s := format
				for _, v := range a {
					s += fmt.Sprintf("_%v", v)
				}
				return s
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()

			// Mock dal call after changeReviewer
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

			// Mock notification dependencies
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s>", email) }).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Error Case: GetEmployeeByMailsWithCache fails", func() {
			// 场景描述: 获取新审核人信息失败
			// 构造数据: 无
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回错误
			// 2. 函数立即返回错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				Extra: "new.reviewer@example.com",
			}
			expectedErr := errors.New("larkc failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("Error Case: changeReviewer fails", func() {
			// 场景描述: 转办逻辑中的数据库操作失败
			// 构造数据: pc.OperationState设置为OperationChangeReviewer
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回成功
			// 2. h.changeReviewer 内部逻辑失败:
			//    a. dal.FindReviewersByNoAndEmail 第一次返回成功
			//    b. dal.FindReviewersByNoAndEmail 第二次返回成功
			//    c. dal.Create 返回错误
			// 3. 函数立即返回错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:    "TEST-CONTRACT-NO-02",
					PreContractNo: "PRE-CONTRACT-NO-02",
					BasicInfo:     &bizmodels.BasicInfo{DepartmentId: "D001"},
				},
				CurrentOperator: "old.reviewer@example.com",
				Extra:           "new.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
			}
			mockDao := &MockPreContractReviewerDao{}
			expectedErr := errors.New("db create failed")
			newReviewerEmployee := &peopleclient.Employee{ID: 123, Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error) {
				if reviewer == pc.CurrentOperator {
					return model.PreContractReviewerDBList{{PreContractNo: pc.ContractInfo.PreContractNo, ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: 1}}, nil
				}
				if reviewer == newReviewerEmployee.Email {
					return model.PreContractReviewerDBList{}, nil
				}
				return nil, errors.New("unexpected reviewer")
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				s := format
				for _, v := range a {
					s += fmt.Sprintf("_%v", v)
				}
				return s
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("Success Case: DeleteChangedReviewer fails but function returns nil", func() {
			// 场景描述: 删除旧审核人待办失败，函数记录日志但整体成功
			// 构造数据: pc.OperationState设置为OperationChangeReviewer
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回成功
			// 2. h.changeReviewer 逻辑成功执行
			// 3. dal.DeleteChangedReviewer 返回错误
			// 4. 函数记录错误日志，但最终返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "TEST-CONTRACT-NO-03",
					PreContractNo:  "PRE-CONTRACT-NO-03",
					OtherPartyName: "Other Party",
					ContractName:   "Contract Name",
					BasicInfo:      &bizmodels.BasicInfo{DepartmentId: "D001"},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
				CurrentOperator: "old.reviewer@example.com",
				Extra:           "new.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
			}
			mockDao := &MockPreContractReviewerDao{}
			newReviewerEmployee := &peopleclient.Employee{ID: 123, Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error) {
				if reviewer == pc.CurrentOperator {
					return model.PreContractReviewerDBList{{PreContractNo: pc.ContractInfo.PreContractNo, ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: 1}}, nil
				}
				if reviewer == newReviewerEmployee.Email {
					return model.PreContractReviewerDBList{}, nil
				}
				return nil, errors.New("unexpected reviewer")
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				s := format
				for _, v := range a {
					s += fmt.Sprintf("_%v", v)
				}
				return s
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()

			// Mock failing DeleteChangedReviewer
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("db delete failed")).Build()

			// Mock notification dependencies
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s>", email) }).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success Case: No reviewers found for current operator", func() {
			// 场景描述: 当前操作员没有任何待办角色，转办逻辑直接跳过
			// 构造数据: pc.OperationState设置为OperationChangeReviewer
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回成功
			// 2. h.changeReviewer 内部逻辑:
			//    a. dal.FindReviewersByNoAndEmail 第一次为旧审核人返回空列表
			//    b. 函数提前返回 nil
			// 3. dal.DeleteChangedReviewer 成功
			// 4. 函数返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "TEST-CONTRACT-NO-04",
					PreContractNo:  "PRE-CONTRACT-NO-04",
					OtherPartyName: "Other Party",
					ContractName:   "Contract Name",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
				CurrentOperator: "old.reviewer.no.roles@example.com",
				Extra:           "new.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
			}
			mockDao := &MockPreContractReviewerDao{}
			newReviewerEmployee := &peopleclient.Employee{ID: 123, Email: "new.reviewer@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			// Mock dal.FindReviewersByNoAndEmail to return empty list for the old reviewer
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(model.PreContractReviewerDBList{}, nil).Build()

			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

			// Mock notification dependencies
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s>", email) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				s := format
				for _, v := range a {
					s += fmt.Sprintf("_%v", v)
				}
				return s
			}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success Case: New reviewer already has the same role", func() {
			// 场景描述: 新审核人已经拥有相同的待办角色，不重复创建
			// 构造数据: pc.OperationState设置为OperationChangeReviewer
			// 逻辑链路:
			// 1. larkc.GetEmployeeByMailsWithCache 返回成功
			// 2. h.changeReviewer 内部逻辑:
			//    a. dal.FindReviewersByNoAndEmail 第一次为旧审核人返回待办角色
			//    b. dal.FindReviewersByNoAndEmail 第二次为新审核人返回相同的待办角色
			//    c. 检查发现角色已存在，跳过 dal.Create 调用
			// 3. 函数返回 nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:     "TEST-CONTRACT-NO-05",
					PreContractNo:  "PRE-CONTRACT-NO-05",
					OtherPartyName: "Other Party",
					ContractName:   "Contract Name",
					BasicInfo:      &bizmodels.BasicInfo{DepartmentId: "D001"},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
				CurrentOperator: "old.reviewer@example.com",
				Extra:           "new.reviewer.existing@example.com",
				OperationState:  _const.OperationChangeReviewer,
			}
			mockDao := &MockPreContractReviewerDao{}
			newReviewerEmployee := &peopleclient.Employee{ID: 456, Email: "new.reviewer.existing@example.com"}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error) {
				role := model.PreContractReviewerDB{PreContractNo: pc.ContractInfo.PreContractNo, ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: 1}
				return model.PreContractReviewerDBList{&role}, nil // Both old and new reviewers have this role
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				// A more robust mock that handles different types and creates unique strings for map keys
				s := format
				for _, v := range a {
					s += fmt.Sprintf("_%v", v)
				}
				return s
			}).Build()
			// dal.Create should NOT be called.

			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).UpdateByID).Return(nil).Build()

			// Mock notification dependencies
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s>", email) }).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {}).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLSignReviewChangeReviewer_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 该函数当前实现是硬编码返回 false 和 nil，无任何其他逻辑。
			// 构造数据：
			// - 创建一个 handlerFTLSignReviewChangeReviewer 实例。
			// - 创建一个空的 ProcessCtx。
			// 逻辑链路：
			// 1. 直接调用 HitStateChangeCondition 方法。
			// 2. 断言返回结果为 (false, nil)。

			// 数据准备
			h := &handlerFTLSignReviewChangeReviewer{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLSignReviewChangeReviewer_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_Validate", t, func() {
		h := &handlerFTLSignReviewChangeReviewer{}
		ctx := context.Background()

		mockey.PatchConvey("场景一: 成功校验 - 新增的审批人不存在", func() {
			// 场景描述：
			// 构造数据：pc.Extra不为空, 包含新的审批人。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查通过。
			// 3. Mock perm.GetAllReviewersByType返回一个不包含新审批人的列表。
			// 4. 函数检查发现新审批人不在现有列表中。
			// 5. 函数返回nil，校验通过。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "TEST_CONTRACT_NO",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 2,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景二: 失败 - 人员为空", func() {
			// 场景描述：
			// 构造数据：pc.Extra为空字符串。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查失败。
			// 3. 函数返回错误 "人员不可为空"。
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景三: 失败 - 获取已有审批人列表时发生错误", func() {
			// 场景描述：
			// 构造数据：pc.Extra不为空。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查通过。
			// 3. Mock perm.GetAllReviewersByType返回一个错误。
			// 4. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "TEST_CONTRACT_NO",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 2,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, errors.New("db query failed")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db query failed")
		})

		mockey.PatchConvey("场景四: 失败 - 新增的审批人已经是审核人员且未通过", func() {
			// 场景描述：
			// 构造数据：pc.Extra包含一个已经存在的审批人, 且该审批人状态不是"审核通过"。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查通过。
			// 3. Mock perm.GetAllReviewersByType返回一个包含该审批人的列表, 状态为"未审核"。
			// 4. 函数检查发现该审批人已存在且状态不为"审核通过"。
			// 5. 函数返回错误, 提示该人员已是审核人员。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "TEST_CONTRACT_NO",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 2,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing.user@example.com")
		})

		mockey.PatchConvey("场景五: 成功校验 - 新增的审批人已是审核人员但已通过", func() {
			// 场景描述：
			// 构造数据：pc.Extra包含一个已经存在的审批人, 且该审批人状态为"审核通过"。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查通过。
			// 3. Mock perm.GetAllReviewersByType返回一个包含该审批人的列表, 状态为"审核通过"。
			// 4. 函数检查发现该审批人已存在但状态为"审核通过", 不计入重复。
			// 5. 函数返回nil, 校验通过。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "TEST_CONTRACT_NO",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 2,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景六: 失败 - 新增多个审批人，其中部分已存在", func() {
			// 场景描述：
			// 构造数据：pc.Extra包含多个审批人, 其中一个已经存在且未审核通过。
			// 逻辑链路：
			// 1. commonValidateUpdateReviewers被调用。
			// 2. pc.Extra长度检查通过。
			// 3. Mock perm.GetAllReviewersByType返回一个包含其中一个审批人的列表, 状态为"未审核"。
			// 4. 函数检查发现该审批人已存在且状态不为"审核通过"。
			// 5. 函数返回错误, 提示该人员已是审核人员。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com,existing.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "TEST_CONTRACT_NO",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 2,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "another.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing.user@example.com")
		})
	})
}

func Test_handlerFTLSignReviewChangeReviewer_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况：应返回正确的操作码", func() {
			// 场景描述：
			// 该函数是一个简单的getter，返回一个固定的操作码常量。
			// 构造数据：
			// 创建一个 handlerFTLSignReviewChangeReviewer 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否等于常量 _const.OperationChangeReviewer。

			// 准备数据
			h := &handlerFTLSignReviewChangeReviewer{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationChangeReviewer)
		})
	})
}

func Test_handlerFTLSignReviewChangeReviewer_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLSignReviewChangeReviewer_CurrentStatus", t, func() {
		mockey.PatchConvey("should return the correct status for FTL sign review change reviewer", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回预期的状态码。
			// 构造数据：
			// - 初始化一个 handlerFTLSignReviewChangeReviewer 实例。
			// 逻辑链路：
			// 1. 创建 handlerFTLSignReviewChangeReviewer 实例。
			// 2. 调用 CurrentStatus 方法。
			// 3. 断言返回值等于常量 _const.PreSalesContractFinanceTaxationLegalSignReview。

			// 准备数据
			h := &handlerFTLSignReviewChangeReviewer{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		})
	})
}

func Test_newHandlerFTLSignReviewChangeReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLSignReviewChangeReviewer", t, func() {
		mockey.PatchConvey("正常返回", func() {
			// 场景描述:
			// 正常调用 newHandlerFTLSignReviewChangeReviewer 函数。
			// 逻辑链路:
			// 1. 调用函数。
			// 2. 断言返回的 handler 不为 nil。
			// 3. 断言返回的 handler 的具体类型是 *handlerFTLSignReviewChangeReviewer。

			// 调用目标函数
			handler := newHandlerFTLSignReviewChangeReviewer()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLSignReviewChangeReviewer{})
		})
	})
}

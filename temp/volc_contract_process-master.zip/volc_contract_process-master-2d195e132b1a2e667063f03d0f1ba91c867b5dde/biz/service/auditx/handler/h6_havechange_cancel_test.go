package handler

import (
	"context"
	"errors"
	"reflect"
	"testing"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/rediscli"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/pkg/const"
)

func Test_handlerHaveChangeCancel_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_PostProcess", t, func() {
		h := &handlerHaveChangeCancel{}
		ctx := context.Background()

		mockey.PatchConvey("场景一: 成功获取并回滚文件版本", func() {
			// 场景描述:
			// 成功从Redis获取到暂存的文件版本号，并成功调用文件服务回滚到该版本。
			// 构造数据:
			// - pc.ContractInfo.OnlineContract: "test-file-id"
			// - pc.CurrentOperator: "test-operator"
			// 逻辑链路:
			// 1. rediscli.GetStashFileVersion 返回一个有效的版本号 "v1.0" 和 nil 错误。
			// 2. 检查版本号长度大于0，条件成立。
			// 3. 调用 filecli.RollbackVersion 并返回成功响应和 nil 错误。
			// 4. 函数最终返回 nil。

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					OnlineContract: "test-file-id",
				},
				CurrentOperator: "test-operator",
			}

			mockey.Mock(rediscli.GetStashFileVersion).Return("v1.0", nil).Build()
			mockey.Mock(filecli.RollbackVersion).Return(&filecli.RollbackVersionResp{}, nil).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景二: Redis中无暂存的文件版本", func() {
			// 场景描述:
			// Redis中没有暂存的文件版本号，因此不执行版本回滚操作。
			// 构造数据:
			// - pc.ContractInfo.OnlineContract: "test-file-id"
			// 逻辑链路:
			// 1. rediscli.GetStashFileVersion 返回空字符串 "" 和 nil 错误。
			// 2. 检查版本号长度大于0，条件不成立。
			// 3. 不会调用 filecli.RollbackVersion。
			// 4. 函数最终返回 nil。

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					OnlineContract: "test-file-id",
				},
				CurrentOperator: "test-operator",
			}

			mockey.Mock(rediscli.GetStashFileVersion).Return("", nil).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景三: 从Redis获取文件版本失败", func() {
			// 场景描述:
			// 从Redis获取暂存文件版本时发生错误，函数会记录错误但不会对外返回错误，也不执行后续的回滚操作。
			// 构造数据:
			// - pc.ContractInfo.OnlineContract: "test-file-id"
			// 逻辑链路:
			// 1. rediscli.GetStashFileVersion 返回一个非 nil 错误。
			// 2. 函数继续执行，获取到的版本号为空。
			// 3. 检查版本号长度大于0，条件不成立。
			// 4. 不会调用 filecli.RollbackVersion。
			// 5. 函数最终返回 nil。

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					OnlineContract: "test-file-id",
				},
				CurrentOperator: "test-operator",
			}

			mockey.Mock(rediscli.GetStashFileVersion).Return("", errors.New("redis connection error")).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景四: 回滚文件版本失败", func() {
			// 场景描述:
			// 成功获取到暂存版本后，调用文件服务回滚版本时发生错误。函数会记录错误但不会对外返回错误。
			// 构造数据:
			// - pc.ContractInfo.OnlineContract: "test-file-id"
			// - pc.CurrentOperator: "test-operator"
			// 逻辑链路:
			// 1. rediscli.GetStashFileVersion 返回一个有效的版本号 "v1.0" 和 nil 错误。
			// 2. 检查版本号长度大于0，条件成立。
			// 3. 调用 filecli.RollbackVersion 但返回一个非 nil 错误。
			// 4. 函数最终返回 nil。

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					OnlineContract: "test-file-id",
				},
				CurrentOperator: "test-operator",
			}

			mockey.Mock(rediscli.GetStashFileVersion).Return("v1.0", nil).Build()
			mockey.Mock(filecli.RollbackVersion).Return(nil, errors.New("rollback failed")).Build()
			mockey.Mock(rediscli.RemoveQuoteChangeInfoFlag).Return(nil).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeCancel_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述：
			// 目标函数是一个简单的实现，它总是返回 (true, nil)，不依赖于任何输入参数或内部状态。
			// 构造数据：
			// - 初始化一个 handlerHaveChangeCancel 实例。
			// - 创建一个空的 context 和 ProcessCtx。
			// 逻辑链路：
			// 1. 直接调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 true。
			// 3. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerHaveChangeCancel{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(hit, convey.ShouldBeTrue)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeCancel_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_Process", t, func() {
		mockey.PatchConvey("正常处理 - 成功返回nil", func() {
			// 场景描述：
			// 目标函数是一个空实现，直接返回nil
			// 构造数据：
			//   - 初始化 handlerHaveChangeCancel
			//   - 初始化 ProcessCtx
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 方法直接返回 nil。
			// 3. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerHaveChangeCancel{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeCancel_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_Validate", t, func() {
		mockey.PatchConvey("should always return nil", func() {
			// 场景描述：
			// 目标函数Validate的实现是直接返回nil，没有任何逻辑判断。
			// 构造数据：
			// - h: 一个空的handlerHaveChangeCancel实例。
			// - ctx: 一个空的context。
			// - pc: 一个空的ProcessCtx实例。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 期望返回nil。

			h := &handlerHaveChangeCancel{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerHaveChangeCancel_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 handlerHaveChangeCancel 的 CurrentOp 方法是否返回正确的操作类型。
			// 构造数据：
			// 创建一个 handlerHaveChangeCancel 实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 断言返回值是否为 _const.OperationCancel。

			h := &handlerHaveChangeCancel{}
			result := h.CurrentOp()
			convey.So(result, convey.ShouldEqual, _const.OperationCancel)
		})
	})
}

func Test_handlerHaveChangeCancel_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerHaveChangeCancel_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况-返回预设的状态值", func() {
			// 场景描述：
			// 调用CurrentStatus方法，应该返回预定义的常量值_const.PreSalesContractChange。
			// 构造数据：
			// 初始化一个handlerHaveChangeCancel实例。
			// 逻辑链路：
			// 1. 创建handlerHaveChangeCancel实例。
			// 2. 调用CurrentStatus()方法。
			// 3. 断言返回值等于_const.PreSalesContractChange。

			h := &handlerHaveChangeCancel{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractChange)
		})
	})
}

func Test_newHandlerHaveChangeCancel_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerHaveChangeCancel", t, func() {
		mockey.PatchConvey("当调用 newHandlerHaveChangeCancel 时，应成功返回一个 handlerHaveChangeCancel 实例", func() {
			// 场景描述：
			// 这是一个简单的构造函数，不涉及复杂的逻辑或依赖。
			// 构造数据：
			// 无需构造数据。
			// 逻辑链路：
			// 1. 调用 newHandlerHaveChangeCancel 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的具体类型是 *handlerHaveChangeCancel。

			// 调用
			handler := newHandlerHaveChangeCancel()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(reflect.TypeOf(handler).String(), convey.ShouldEqual, "*handler.handlerHaveChangeCancel")
		})
	})
}

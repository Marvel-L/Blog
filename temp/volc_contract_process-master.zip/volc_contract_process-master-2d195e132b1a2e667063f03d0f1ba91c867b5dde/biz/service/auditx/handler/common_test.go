package handler

import (
	"code.byted.org/eps-platform/commercialization_sdk_go/sdk/dto/lite"
	"code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"code.byted.org/eps-platform/quote_sdk_go/quote_client"
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/eps-platform/vcp_clients/pkg/util"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	. "github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	. "github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"math"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/metaattach"
	"volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/biz/service/ruleengine"
	"volc_contract_process/biz/service/supply"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/biz/service/support/metaext"
	quoteservice "volc_contract_process/biz/service/support/quote"
	"volc_contract_process/biz/service/support/reviewrule"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/mdparty"
	"volc_contract_process/pkg/preload"
	"volc_contract_process/pkg/proxy/accountcli"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/innertopcommercializationcli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/mdcli"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/proxy/riskenginecli"
	"volc_contract_process/pkg/recovery"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerCommon_needPAReviewer(t *testing.T) {
	mockey.PatchConvey("hit by government industry key", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: true, GovernmentIndustryKeys: []string{"Government"}}}).Build()
		h := &handlerCommon{}
		contract := &model.ContractMeta{TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{IndustryCKey: "Government", IndustryCDec: "政府"}}}}

		convey.So(h.needPAReviewer(context.Background(), contract), convey.ShouldBeTrue)
	})

	mockey.PatchConvey("hit by government industry name for compatibility", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: true, GovernmentIndustryNames: []string{"政府"}}}).Build()
		h := &handlerCommon{}
		contract := &model.ContractMeta{TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{IndustryCDec: "政府"}}}}

		convey.So(h.needPAReviewer(context.Background(), contract), convey.ShouldBeTrue)
	})

	mockey.PatchConvey("hit by public service department", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: true, PublicServiceDepartmentIds: []string{"dept-public"}}}).Build()
		h := &handlerCommon{}
		contract := &model.ContractMeta{BasicInfo: &bizmodels.BasicInfo{DepartmentId: "dept-public"}}

		convey.So(h.needPAReviewer(context.Background(), contract), convey.ShouldBeTrue)
	})

	mockey.PatchConvey("disabled config does not hit", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: false, GovernmentIndustryNames: []string{"政府"}}}).Build()
		h := &handlerCommon{}
		contract := &model.ContractMeta{TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{IndustryCDec: "政府"}}}}

		convey.So(h.needPAReviewer(context.Background(), contract), convey.ShouldBeFalse)
	})
}

func Test_handlerCommon_genPAReviewersIfNeeded(t *testing.T) {
	mockey.PatchConvey("gen PA reviewers only for current FTL node", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: true, GovernmentIndustryKeys: []string{"Government"}, PAReviewerEmails: []string{"pa@example.com"}}}).Build()
		mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{"pa@example.com": {ID: 1001, Email: "pa@example.com"}}, nil).Build()
		h := &handlerCommon{}
		pc := &auditmodel.ProcessCtx{StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalSignReview, ContractInfo: &model.ContractMeta{ContractNo: "PC001", BasicInfo: &bizmodels.BasicInfo{DepartmentId: "dept"}, TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{IndustryCKey: "Government", IndustryCDec: "政府"}}}}}

		reviewers, needReviewerMap, err := h.genPAReviewersIfNeeded(context.Background(), pc, _const.PreSalesContractFinanceTaxationLegalSignReview, map[string]bool{})

		convey.So(err, convey.ShouldBeNil)
		convey.So(reviewers, convey.ShouldHaveLength, 1)
		convey.So(reviewers[0].ReviewerRole, convey.ShouldEqual, _const.ReviewerRolePA)
		convey.So(reviewers[0].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
		convey.So(reviewers[0].ContractStatus, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
		convey.So(needReviewerMap[paReviewerUniqueKey(context.Background(), "pa@example.com", _const.PreSalesContractFinanceTaxationLegalSignReview)], convey.ShouldBeTrue)
	})

	mockey.PatchConvey("missing PA config blocks", t, func() {
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{Enable: true, GovernmentIndustryNames: []string{"政府"}}}).Build()
		mockey.Mock(larkc.Warning).Return().Build()
		h := &handlerCommon{}
		pc := &auditmodel.ProcessCtx{ContractInfo: &model.ContractMeta{ContractNo: "PC002", BasicInfo: &bizmodels.BasicInfo{DepartmentId: "dept"}, TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{IndustryCDec: "政府"}}}}}

		reviewers, needReviewerMap, err := h.genPAReviewersIfNeeded(context.Background(), pc, _const.PreSalesContractFinanceTaxationLegalReview, map[string]bool{})

		convey.So(err, convey.ShouldNotBeNil)
		convey.So(reviewers, convey.ShouldHaveLength, 0)
		convey.So(needReviewerMap, convey.ShouldBeNil)
	})
}

func Test_InitReviewersAfterStatusChanged(t *testing.T) {
	mockey.PatchConvey("reset PA reviewers when status changes to FTL review", t, func() {
		expectedErr := errors.New("reset pa failed")
		mockey.Mock((*handlerCommon).resetPANodeReviewers).Return(expectedErr).Build()

		err := InitReviewersAfterStatusChanged(context.Background(), &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
		})

		convey.So(err, convey.ShouldEqual, expectedErr)
	})

	mockey.PatchConvey("skip solution reviewers when approval key does not need solution node", t, func() {
		err := InitReviewersAfterStatusChanged(context.Background(), &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractSolutionReview,
		})

		convey.So(err, convey.ShouldBeNil)
	})
}

func Test_handlerCommon_resetPANodeReviewers(t *testing.T) {
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}
	mockey.PatchConvey("insert PA reviewers when current node has no existing PA", t, func() {
		mockDB := &gorm.DB{}
		mockReviewerDao := &MockPreContractReviewerDao{}
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{
			Enable:                 true,
			GovernmentIndustryKeys: []string{"Government"},
			PAReviewerEmails:       []string{"pa@example.com"},
		}}).Build()
		mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
			"pa@example.com": {ID: 1001, Email: "pa@example.com"},
		}, nil).Build()
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
		mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
			convey.So(entities, convey.ShouldHaveLength, 1)
			convey.So(entities[0].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
			convey.So(entities[0].ReviewerRole, convey.ShouldEqual, _const.ReviewerRolePA)
			convey.So(entities[0].ContractStatus, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
			return nil
		}).Build()
		h := &handlerCommon{}
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalSignReview,
			ContractInfo: &model.ContractMeta{
				ContractNo: "PC-PA-001",
				BasicInfo:  &bizmodels.BasicInfo{DepartmentId: "dept"},
				TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{
					{IndustryCKey: "Government", IndustryCDec: "政府"},
				}},
			},
		}

		err := h.resetPANodeReviewers(context.Background(), pc, _const.PreSalesContractFinanceTaxationLegalSignReview)

		convey.So(err, convey.ShouldBeNil)
		convey.So(pc.ContractInfo.Reviewers, convey.ShouldHaveLength, 1)
		convey.So(pc.ContractInfo.Reviewers[0].Reviewer, convey.ShouldEqual, "pa@example.com")
		convey.So(pc.ContractInfo.Reviewers[0].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
		convey.So(pc.ContractInfo.Reviewers[0].ReviewerRole, convey.ShouldEqual, _const.ReviewerRolePA)
		convey.So(pc.ContractInfo.Reviewers[0].ContractStatus, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
	})
	mockey.PatchConvey("keep existing PA, insert new PA, delete stale PA", t, func() {
		mockDB := &gorm.DB{}
		mockReviewerDao := &MockPreContractReviewerDao{}
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{
			Enable:                 true,
			GovernmentIndustryKeys: []string{"Government"},
			PAReviewerEmails:       []string{"keep@example.com", "new@example.com"},
		}}).Build()
		mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
			"keep@example.com": {ID: 1001, Email: "keep@example.com"},
			"new@example.com":  {ID: 1002, Email: "new@example.com"},
		}, nil).Build()
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
		mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{
			{BaseDB: model.BaseDB{Id: 1, Status: _const.ReviewStatusReviewPass}, Reviewer: "keep@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ReviewerRole: _const.ReviewerRolePA, ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview},
			{BaseDB: model.BaseDB{Id: 2}, Reviewer: "stale@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ReviewerRole: _const.ReviewerRolePA, ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview},
			{BaseDB: model.BaseDB{Id: 3}, Reviewer: "other-node@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ReviewerRole: _const.ReviewerRolePA, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
			{BaseDB: model.BaseDB{Id: 4}, Reviewer: "ftl@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview},
		}, nil).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchDeleteReviewer).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, ids []uint64) error {
			convey.So(preContractNo, convey.ShouldEqual, "PC-PA-001")
			convey.So(ids, convey.ShouldResemble, []uint64{2})
			return nil
		}).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
			convey.So(entities, convey.ShouldHaveLength, 1)
			convey.So(entities[0].Reviewer, convey.ShouldEqual, "new@example.com")
			convey.So(entities[0].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
			convey.So(entities[0].ReviewerRole, convey.ShouldEqual, _const.ReviewerRolePA)
			convey.So(entities[0].ContractStatus, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
			return nil
		}).Build()
		h := &handlerCommon{}
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalSignReview,
			ContractInfo: &model.ContractMeta{
				ContractNo: "PC-PA-001",
				BasicInfo:  &bizmodels.BasicInfo{DepartmentId: "dept"},
				TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{
					{IndustryCKey: "Government", IndustryCDec: "政府"},
				}},
			},
		}

		err := h.resetPANodeReviewers(context.Background(), pc, _const.PreSalesContractFinanceTaxationLegalSignReview)

		convey.So(err, convey.ShouldBeNil)
		convey.So(pc.ContractInfo.Reviewers, convey.ShouldHaveLength, 4)
		reviewerMap := map[string]*bizmodels.PreContractReviewer{}
		for _, reviewer := range pc.ContractInfo.Reviewers {
			reviewerMap[reviewer.Reviewer] = reviewer
		}
		convey.So(reviewerMap["keep@example.com"], convey.ShouldNotBeNil)
		convey.So(reviewerMap["keep@example.com"].Status, convey.ShouldEqual, _const.ReviewStatusReviewPass)
		convey.So(reviewerMap["stale@example.com"], convey.ShouldBeNil)
		convey.So(reviewerMap["new@example.com"], convey.ShouldNotBeNil)
		convey.So(reviewerMap["new@example.com"].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
		convey.So(reviewerMap["other-node@example.com"], convey.ShouldNotBeNil)
		convey.So(reviewerMap["ftl@example.com"], convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("skip insert when same reviewer already exists with non-PA role", t, func() {
		mockDB := &gorm.DB{}
		mockReviewerDao := &MockPreContractReviewerDao{}
		mockey.Mock(conf.GetGlobalConf).Return(&conf.GlobalConf{PAApprovalConfig: &conf.PAApprovalConfig{
			Enable:                 true,
			GovernmentIndustryKeys: []string{"Government"},
			PAReviewerEmails:       []string{"ftl@example.com"},
		}}).Build()
		mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
			"ftl@example.com": {ID: 1001, Email: "ftl@example.com"},
		}, nil).Build()
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
		mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{
			{BaseDB: model.BaseDB{Id: 1}, Reviewer: "ftl@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalSignReview},
		}, nil).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchDeleteReviewer).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, ids []uint64) error {
			convey.So(ids, convey.ShouldBeEmpty)
			return nil
		}).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
			convey.So(entities, convey.ShouldBeEmpty)
			return nil
		}).Build()
		h := &handlerCommon{}
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalSignReview,
			ContractInfo: &model.ContractMeta{
				ContractNo: "PC-PA-001",
				BasicInfo:  &bizmodels.BasicInfo{DepartmentId: "dept"},
				TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{
					{IndustryCKey: "Government", IndustryCDec: "政府"},
				}},
			},
		}

		err := h.resetPANodeReviewers(context.Background(), pc, _const.PreSalesContractFinanceTaxationLegalSignReview)

		convey.So(err, convey.ShouldBeNil)
		convey.So(pc.ContractInfo.Reviewers, convey.ShouldHaveLength, 1)
		convey.So(pc.ContractInfo.Reviewers[0].Reviewer, convey.ShouldEqual, "ftl@example.com")
		convey.So(pc.ContractInfo.Reviewers[0].ReviewerType, convey.ShouldEqual, _const.ReviewerTypeFinanceTaxationLegalReviewer)
	})
}

type (
	MockMetaServiceV2              struct{ contractmeta.MetaServiceV2 }
	MockMetaService                struct{ contractmeta.MetaService }
	MockContractMetaDao            struct{ dal.ContractMetaDao }
	MockPreContractReviewerDao     struct{ dal.PreContractReviewerDao }
	MockContractOperationRecordDao struct{ dal.ContractOperationRecordDao }
	MockMetaAttachService          struct{ metaattach.AttachmentService }
	MockMetaCommodityService       struct{ metacommodity.Service }
	MockQuoteService               struct{ quoteservice.Service }
	MockRiskClauseRoleDao          struct{ dal.RiskClauseRoleDao }
)

func Test_handlerCommon_checkPreCheckContractDiscount_BitsUTGen(t *testing.T) {
	mockMetaServiceV2 := &MockMetaServiceV2{}

	mockey.PatchConvey("Test_handlerCommon_checkPreCheckContractDiscount", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		// Mock 跨测试用例的通用依赖
		mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
			return errors.New(text)
		}).Build()
		mockey.Mock((*handlerCommon).getMetaServiceV2).Return(mockMetaServiceV2).Build()

		validBeginTimeStr := "2023-01-01 00:00:00"
		validEndTimeStr := "2023-12-31 00:00:00"
		validBeginTime, _ := utils.GetTimeFromString(validBeginTimeStr)
		validEndTime, _ := utils.GetTimeFromString(validEndTimeStr)

		mockey.PatchConvey("Success: All checks pass, correctly processing account IDs and dates", func() {
			meta := &model.ContractMeta{
				ManageInfo: &bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{
						"group_1": {
							&bizmodels.ProductInfo{QuoteItemID: "123"},
						},
					},
					DeductProductInfoMap: map[string][]*bizmodels.ProductInfo{
						"group_1": {
							&bizmodels.ProductInfo{QuoteItemID: "123"},
						},
					},
				},
				BasicInfo: &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{
					OtherParty: []*bizmodels.TradePartyInfoDetail{
						{PricingAccountID: "123,456"},
						{PricingAccountID: "456,,789"}, // 测试去重和空字符串处理
					},
				},
				BeginTime: validBeginTimeStr,
				EndTime:   validEndTimeStr,
			}

			// 断言传递给下游服务的参数是否正确，而不是 mock 内部的辅助函数
			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).When(func(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) bool {
				expectedAccountIDs := []string{"123", "456", "789"}
				convey.So(req.AccountIDs, convey.ShouldResemble, expectedAccountIDs)
				convey.So(req.ValidityBegin.Equal(validBeginTime), convey.ShouldBeTrue)
				convey.So(req.ValidityEnd.Equal(validEndTime), convey.ShouldBeTrue)
				return true
			}).Return(&modelcommodity.PreCheckCreateContractPriceReqResp{
				Success: true,
			}, nil).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: Fallback to ManageInfo for validity dates when meta times are zero", func() {
			manageBeginStr := "2024-01-01 00:00:00"
			manageEndStr := "2024-12-31 00:00:00"
			manageBegin, _ := time.ParseInLocation("2006-01-02 15:04:05", manageBeginStr, time.Local)
			manageEnd, _ := time.ParseInLocation("2006-01-02 15:04:05", manageEndStr, time.Local)

			meta := &model.ContractMeta{
				ManageInfo: &bizmodels.ManageInfo{
					ProductValidityBegin: manageBeginStr,
					ProductValidityEnd:   manageEndStr,
				},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
				BeginTime:      "0001-01-01 00:00:00", // 零值时间
				EndTime:        "0001-01-01 00:00:00", // 零值时间
			}

			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).When(func(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) bool {
				convey.So(req.ValidityBegin.Equal(manageBegin), convey.ShouldBeTrue)
				convey.So(req.ValidityEnd.Equal(manageEnd), convey.ShouldBeTrue)
				return true
			}).Return(&modelcommodity.PreCheckCreateContractPriceReqResp{
				Success: true,
			}, nil).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: JSON unmarshal for ManageInfo fails", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}
			unmarshalErr := errors.New("unmarshal manage info error")

			mockey.Mock(json.Unmarshal).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.ManageInfo)
					return ok
				}).Return(unmarshalErr).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldEqual, unmarshalErr)
		})

		mockey.PatchConvey("Failure: JSON unmarshal for BasicInfo fails", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}
			unmarshalErr := errors.New("unmarshal basic info error")

			mockey.Mock(json.Unmarshal).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.ManageInfo)
					return ok
				}).Return(nil).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.BasicInfo)
					return ok
				}).Return(unmarshalErr).
				Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldEqual, unmarshalErr)
		})

		mockey.PatchConvey("Failure: JSON unmarshal for TradePartyInfo fails", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}
			unmarshalErr := errors.New("unmarshal trade party info error")

			mockey.Mock(json.Unmarshal).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.ManageInfo)
					return ok
				}).Return(nil).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.BasicInfo)
					return ok
				}).Return(nil).
				When(func(data []byte, v interface{}) bool {
					_, ok := v.(*bizmodels.TradePartyInfo)
					return ok
				}).Return(unmarshalErr).
				Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldEqual, unmarshalErr)
		})

		mockey.PatchConvey("Failure: PreCheckCreateContractPrice returns an error", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}
			rpcErr := errors.New("rpc error")

			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).Return(nil, rpcErr).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同价预校验失败")
		})

		mockey.PatchConvey("Failure: PreCheckCreateContractPrice returns a nil response", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}

			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).Return(nil, nil).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "PreCheckCreateContractPriceRespIsNil")
		})

		mockey.PatchConvey("Failure: PreCheckCreateContractPrice response indicates failure", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: &bizmodels.TradePartyInfo{},
			}

			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).Return(&modelcommodity.PreCheckCreateContractPriceReqResp{
				Success: false,
				Msg:     "some business validation failed",
			}, nil).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同价预校验失败")
		})

		mockey.PatchConvey("Edge Case: TradePartyInfo is nil", func() {
			meta := &model.ContractMeta{
				ManageInfo:     &bizmodels.ManageInfo{},
				BasicInfo:      &bizmodels.BasicInfo{},
				TradePartyInfo: nil, // 核心测试条件
			}

			mockey.Mock((*MockMetaServiceV2).PreCheckCreateContractPrice).When(func(ctx context.Context, req *modelcommodity.PreCheckCreateContractPriceReq) bool {
				// 确认在这种情况下 AccountIDs 列表为空
				return len(req.AccountIDs) == 0
			}).Return(&modelcommodity.PreCheckCreateContractPriceReqResp{
				Success: true,
			}, nil).Build()

			err := h.checkPreCheckContractDiscount(ctx, meta)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_notifyC360_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerCommon_notifyC360", t, func() {

		mockey.PatchConvey("场景：正常流程，非退回操作，MQ发送成功", func() {
			// 场景描述：
			// 在非BytePlus环境下，进行非“退回”操作的通知，MQ消息发送成功。
			// 构造数据：
			// - pc.OperationState 不为 _const.OperationSendBack。
			// - pc.ContractInfo 包含必要信息。
			// 逻辑链路：
			// 1. mock multienv.IsBytePlus() 返回 false。
			// 2. mock larkc.GetEmployeeByID 返回一个有效的员工信息。
			// 3. pc.OperationState 不为退回，跳过相关字段赋值逻辑。
			// 4. mock mqProducer.SendC360NotifyMessage 返回 nil，模拟发送成功。
			// 5. 函数最终返回 nil。

			eventType := "SUBMIT"
			pc := &auditmodel.ProcessCtx{
				OperationState:     _const.OperationSubmitDraft,
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
				ContractInfo: &model.ContractMeta{
					Operator:     "test.operator",
					ContractNo:   "C-123",
					ContractName: "Test Contract",
				},
				Comment: &bizmodels.RichTextInfo{},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()

			var sentMsg *bizmodels.C360NotifyMsg
			mockey.Mock(mqProducer.SendC360NotifyMessage).To(func(ctx context.Context, d time.Duration, msg *bizmodels.C360NotifyMsg) error {
				sentMsg = msg // 捕获发送的消息用于断言
				return nil
			}).Build()

			err := h.notifyC360(ctx, eventType, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(sentMsg, convey.ShouldNotBeNil)
			convey.So(sentMsg.EventType, convey.ShouldEqual, eventType)
			convey.So(sentMsg.Operator, convey.ShouldResemble, []string{"test.operator@example.com"})
			convey.So(len(sentMsg.ContractList), convey.ShouldEqual, 1)
			convey.So(sentMsg.ContractList[0].ContractNumber, convey.ShouldEqual, "C-123")
			convey.So(sentMsg.ContractList[0].ContractName, convey.ShouldEqual, "Test Contract")
			convey.So(sentMsg.ContractList[0].NextAuditNode, convey.ShouldEqual, _const.ContractStatus2NameMapping[_const.PreSalesContractSalesOperationReview])
			convey.So(sentMsg.ContractList[0].StatusReturnReason, convey.ShouldBeEmpty)
			convey.So(sentMsg.ContractList[0].CustomerName, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("场景：正常流程，为退回操作，MQ发送成功", func() {
			// 场景描述：
			// 在非BytePlus环境下，进行“退回”操作的通知，消息中应包含退回原因和客户名称。
			// 构造数据：
			// - pc.OperationState 为 _const.OperationSendBack。
			// - pc.Comment 包含退回原因。
			// - pc.ContractInfo 包含客户名称。
			// 逻辑链路：
			// 1. mock multienv.IsBytePlus() 返回 false。
			// 2. mock larkc.GetEmployeeByID 返回一个有效的员工信息。
			// 3. pc.OperationState 为退回，进入if分支，为 statusReturnReason 和 customerName 赋值。
			// 4. mock mqProducer.SendC360NotifyMessage 返回 nil，模拟发送成功。
			// 5. 函数最终返回 nil。

			eventType := "SENDBACK"
			pc := &auditmodel.ProcessCtx{
				OperationState:     _const.OperationSendBack,
				StatusChangedValue: _const.PreSalesContractSendBack,
				ContractInfo: &model.ContractMeta{
					Operator:       "test.operator",
					ContractNo:     "C-456",
					ContractName:   "SendBack Contract",
					OtherPartyName: "Test Customer",
				},
				Comment: &bizmodels.RichTextInfo{
					RichtextPlainText: "Missing information.",
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()

			var sentMsg *bizmodels.C360NotifyMsg
			mockey.Mock(mqProducer.SendC360NotifyMessage).To(func(ctx context.Context, d time.Duration, msg *bizmodels.C360NotifyMsg) error {
				sentMsg = msg
				return nil
			}).Build()

			err := h.notifyC360(ctx, eventType, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(sentMsg, convey.ShouldNotBeNil)
			convey.So(sentMsg.ContractList[0].StatusReturnReason, convey.ShouldEqual, "Missing information.")
			convey.So(sentMsg.ContractList[0].CustomerName, convey.ShouldEqual, "Test Customer")
		})

		mockey.PatchConvey("场景：MQ发送消息失败，应记录日志并返回错误", func() {
			// 场景描述：
			// 消息发送到MQ时发生错误，函数需要处理此失败场景。
			// 构造数据：
			// 无需特定数据。
			// 逻辑链路：
			// 1. mock multienv.IsBytePlus() 返回 false。
			// 2. mock larkc.GetEmployeeByID 正常返回。
			// 3. mock mqProducer.SendC360NotifyMessage 返回一个 error。
			// 4. 进入错误处理分支，mock utils.ToJSON 和 larkc.Warning 被调用。
			// 5. 函数返回从MQ收到的错误。

			eventType := "FAILURE_CASE"
			pc := &auditmodel.ProcessCtx{
				OperationState:     _const.OperationSubmitDraft,
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
				ContractInfo: &model.ContractMeta{
					Operator:     "test.operator",
					ContractNo:   "C-FAIL",
					ContractName: "Failure Contract",
				},
				Comment: &bizmodels.RichTextInfo{},
			}
			mqError := errors.New("mq is down")

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{
				{Email: "test.operator@example.com"},
			}, nil).Build()
			mockey.Mock(mqProducer.SendC360NotifyMessage).Return(mqError).Build()
			mockey.Mock(utils.ToJSON).Return(`{"json":"dummy"}`).Build()
			mockey.Mock(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {}).Build()

			err := h.notifyC360(ctx, eventType, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mq is down")
		})

		mockey.PatchConvey("场景：Lark获取员工信息为空，应继续发送，操作人为空", func() {
			// 场景描述：
			// 无法通过Lark获取到操作员的邮箱信息。
			// 构造数据：
			// larkc.GetEmployeeByID 返回空数组。
			// 逻辑链路：
			// 1. mock multienv.IsBytePlus() 返回 false。
			// 2. mock larkc.GetEmployeeByID 返回空 slice，模拟找不到员工。
			// 3. contractOperatorEmail 变量将为空字符串。
			// 4. MQ消息正常发送，但Operator字段为空。
			// 5. 函数返回 nil。

			eventType := "SUBMIT"
			pc := &auditmodel.ProcessCtx{
				OperationState:     _const.OperationSubmitDraft,
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
				ContractInfo: &model.ContractMeta{
					Operator:     "unknown.operator",
					ContractNo:   "C-789",
					ContractName: "No Operator Contract",
				},
				Comment: &bizmodels.RichTextInfo{},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{}, nil).Build()

			var sentMsg *bizmodels.C360NotifyMsg
			mockey.Mock(mqProducer.SendC360NotifyMessage).To(func(ctx context.Context, d time.Duration, msg *bizmodels.C360NotifyMsg) error {
				sentMsg = msg
				return nil
			}).Build()

			err := h.notifyC360(ctx, eventType, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(sentMsg, convey.ShouldNotBeNil)
			convey.So(sentMsg.Operator, convey.ShouldResemble, []string{""})
		})
	})
}

func Test_handlerCommon_SaveStatusChangeFileVersion_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_SaveStatusChangeFileVersion", t, func() {
		mockey.PatchConvey("should succeed when all dependencies work correctly", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.Id 设为 1
			// 逻辑链路:
			// 1. 调用 h.GenProcessFileNestVersion, 返回一个正常的 map 和 nil error
			// 2. 调用 json.Marshal, 成功序列化 map
			// 3. 调用 pc.GetTx, 返回一个 *gorm.DB 实例
			// 4. 调用 h.CreateOrUpdateMetaExt, 返回 nil error
			// 5. 函数最终返回 nil

			// Arrange
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
				},
			}
			ctx := context.Background()

			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(map[string]string{"file1": "v1"}, nil, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateMetaExt).Return(nil).Build()

			// Act
			err := h.SaveStatusChangeFileVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return error when GenProcessFileNestVersion fails", func() {
			// 场景描述:
			// 构造数据: 空
			// 逻辑链路:
			// 1. 调用 h.GenProcessFileNestVersion, 返回一个 error
			// 2. 函数立即返回该 error

			// Arrange
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()
			expectedErr := errorsV2.ErrCommon.WithArgs("gen version failed")

			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(nil, nil, expectedErr).Build()

			// Act
			err := h.SaveStatusChangeFileVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "gen version failed")
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("should return error when json.Marshal fails", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.Id 设为 1
			// 逻辑链路:
			// 1. 调用 h.GenProcessFileNestVersion, 返回成功
			// 2. 调用 json.Marshal, 模拟序列化失败, 返回一个 error
			// 3. 函数立即返回该 marshalling error

			// Arrange
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
				},
			}
			ctx := context.Background()
			expectedErr := errors.New("json marshal error")

			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(map[string]string{"file1": "v1"}, nil, nil).Build()
			mockey.Mock(json.Marshal).Return(nil, expectedErr).Build()

			// Act
			err := h.SaveStatusChangeFileVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json marshal error")
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("should return error when CreateOrUpdateMetaExt fails", func() {
			// 场景描述:
			// 构造数据: pc.PreContractVO.Id 设为 1
			// 逻辑链路:
			// 1. 调用 h.GenProcessFileNestVersion, 返回成功
			// 2. 调用 json.Marshal, 成功序列化
			// 3. 调用 pc.GetTx, 返回一个 *gorm.DB 实例
			// 4. 调用 h.CreateOrUpdateMetaExt, 模拟数据库操作失败, 返回一个 error
			// 5. 函数返回该 error

			// Arrange
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{
						Id: 1,
					},
				},
			}
			ctx := context.Background()
			expectedErr := errorsV2.ErrInternalError.WithArgs("db update failed")

			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(map[string]string{"file1": "v1"}, nil, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateMetaExt).Return(expectedErr).Build()

			// Act
			err := h.SaveStatusChangeFileVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db update failed")
			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_handlerCommon_SaveProcessFileNestVersion_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_SaveProcessFileNestVersion", t, func() {
		// Arrange
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景：当前操作不符合审核通过条件，不执行存储最新版本逻辑", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 OperationState 不在 ReviewPassOperationList 中。
			// 逻辑链路：
			// 1. utils.IntIn 返回 false。
			// 2. 函数提前返回 nil。
			pc := &auditmodel.ProcessCtx{
				OperationState: -1, // An operation state that is not in the pass list.
			}
			mockey.Mock(utils.IntIn).Return(false).Build()

			// Act
			err := h.SaveProcessFileNestVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：GenProcessFileNestVersion 失败", func() {
			// 场景描述：
			// 构造数据：构造一个审核通过状态的 ProcessCtx。
			// 逻辑链路：
			// 1. utils.IntIn 返回 true。
			// 2. Mock GenProcessFileNestVersion 方法返回一个错误。
			// 3. 函数返回此错误。
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				ApprovalKey:    _const.ApprovalKeyDefault,
				PreContractVO:  &model.ContractMetaDB{},
			}
			mockey.Mock(utils.IntIn).Return(true).Build()
			expectedErr := errorsV2.ErrCommon.WithArgs("GenProcessFileNestVersionFail")
			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(nil, nil, expectedErr).Build()

			// Act
			err := h.SaveProcessFileNestVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景：json.Marshal 失败", func() {
			// 场景描述：
			// 构造数据：构造一个审核通过状态的 ProcessCtx。
			// 逻辑链路：
			// 1. utils.IntIn 返回 true。
			// 2. GenProcessFileNestVersion 成功返回。
			// 3. Mock json.Marshal 返回一个错误。
			// 4. 函数返回此序列化错误。
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				ApprovalKey:    _const.ApprovalKeyDefault,
				PreContractVO:  &model.ContractMetaDB{},
			}
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(make(map[string]string), nil, nil).Build()
			expectedErr := errors.New("marshal error")
			mockey.Mock(json.Marshal).Return(nil, expectedErr).Build()

			// Act
			err := h.SaveProcessFileNestVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "marshal error")
		})

		mockey.PatchConvey("场景：CreateOrUpdateMetaExt 失败", func() {
			// 场景描述：
			// 构造数据：构造一个审核通过状态的 ProcessCtx。
			// 逻辑链路：
			// 1. utils.IntIn 返回 true。
			// 2. GenProcessFileNestVersion 成功返回。
			// 3. json.Marshal 成功返回。
			// 4. pc.GetTx() 返回一个 gorm.DB 实例。
			// 5. Mock CreateOrUpdateMetaExt 返回一个错误。
			// 6. 函数返回此错误。
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				ApprovalKey:    _const.ApprovalKeyDefault,
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 1},
				},
			}
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(map[string]string{"file1": "v1"}, nil, nil).Build()
			// pc.GetTx() is a method on the struct pointer, needs to be mocked.
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			expectedErr := errorsV2.ErrInternalError.WithArgs("CreateOrUpdateMetaExtFail")
			mockey.Mock((*handlerCommon).CreateOrUpdateMetaExt).Return(expectedErr).Build()

			// Act
			err := h.SaveProcessFileNestVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景：成功保存最新版本文件", func() {
			// 场景描述：
			// 构造数据：构造一个审核通过状态且 ApprovalKey 为合作报价的 ProcessCtx。
			// 逻辑链路：
			// 1. utils.IntIn 返回 true。
			// 2. GenProcessFileNestVersion 成功返回，并返回一些版本记录。
			// 3. json.Marshal 成功返回。
			// 4. pc.GetTx() 返回一个 gorm.DB 实例。
			// 5. CreateOrUpdateMetaExt 成功返回。
			// 6. 函数成功返回 nil，并且 pc.RecordVersions 被正确赋值。
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				ApprovalKey:    _const.ApprovalKeyCooperationQuote,
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 1},
				},
			}
			recordVersions := []*bizmodels.FileVersionData{
				{BizType: 1, FileID: "file1", FileName: "contract.pdf", Version: "v2"},
			}
			newestVersionMap := map[string]string{
				"file1": "v2",
			}
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*handlerCommon).GenProcessFileNestVersion).Return(newestVersionMap, recordVersions, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateMetaExt).Return(nil).Build()

			// Act
			err := h.SaveProcessFileNestVersion(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.RecordVersions, convey.ShouldResemble, recordVersions)
		})
	})
}

func Test_SaveCommodityList_BitsUTGen(t *testing.T) {
	// MockContractCommodityDao is a mock for the dal.ContractCommodityDao interface
	type MockContractCommodityDao struct {
		dal.ContractCommodityDao
	}

	mockey.PatchConvey("TestSaveCommodityList", t, func() {
		ctx := context.Background()
		tx := &gorm.DB{}
		mockDao := &MockContractCommodityDao{}
		mockey.Mock(dal.NewContractCommodityDao).Return(mockDao).Build()

		mockey.PatchConvey("Success Case - Full flow", func() {
			// 场景描述：
			// 正常流程，所有依赖调用均成功。
			// 构造数据：
			// metaDB: Id=1, ContractNo="C-001"
			// commodityList: 包含两个商品，"ProductA" 和 "ProductB"
			// update: 空的 map
			// 逻辑链路：
			// 1. dal.NewContractCommodityDao() 返回 mockDao
			// 2. mockDao.DeleteByVolcContractId() 成功，返回 nil
			// 3. commodityList 不为空，继续执行
			// 4. utils.RemoveRepeat() 正常执行
			// 5. tradecli.QueryProductListV1() 成功，返回 "ProductA" 和 "ProductB" 的商品信息
			// 6. 遍历商品列表，根据查询结果填充商品信息（包括调用 utils.ParseInvoiceProject）
			// 7. mockDao.CreateInBatches() 成功，返回 nil
			// 8. update map 被正确填充
			// 9. 函数返回 nil

			metaDB := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 1},
				ContractNo: "C-001",
				Version:    1,
			}
			commodityList := []*model.VolcContractCommodity{
				{TradeProduct: "ProductA"},
				{TradeProduct: "ProductB", InvoiceProject: "pre-filled-invoice*project*1*0%"}, // Test case where invoice project is already filled
			}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{
				{
					Product:        "ProductA",
					ProductCode:    "PA-001",
					IncomeCode:     "IC-A",
					InvoiceProject: "*Service*Tech*6%",
				},
				{
					Product:        "ProductB",
					ProductCode:    "PB-001",
					IncomeCode:     "IC-B",
					InvoiceProject: "*Service*Consulting*3%", // This should not be used as the original is pre-filled
				},
			}, nil).Build()

			// Mock ParseInvoiceProject to ensure it's called correctly. We can also let the real function run.
			mockey.Mock(utils.ParseInvoiceProject).To(func(s string) (string, decimal.Decimal) {
				if s == "*Service*Tech*6%" {
					return "*Service*Tech", decimal.NewFromFloat(6)
				}
				return s, decimal.Zero
			}).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			err := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(err, convey.ShouldBeNil)
			convey.So(update["product"], convey.ShouldEqual, "ProductA,ProductB")
			convey.So(commodityList[0].InvoiceProject, convey.ShouldEqual, "*Service*Tech*6%")
			convey.So(commodityList[0].InvoiceProjectCode, convey.ShouldEqual, "*Service*Tech")
			convey.So(commodityList[0].TaxRatio.Equal(decimal.NewFromFloat(6)), convey.ShouldBeTrue)
			convey.So(commodityList[0].IncomeCode, convey.ShouldEqual, "IC-A")
			convey.So(commodityList[1].InvoiceProject, convey.ShouldEqual, "pre-filled-invoice*project*1*0%") // Should not change
			convey.So(commodityList[1].IncomeCode, convey.ShouldEqual, "IC-B")
		})

		mockey.PatchConvey("Failure Case - DeleteByVolcContractId returns error", func() {
			// 场景描述：
			// 删除旧商品记录时失败。
			// 构造数据：
			// metaDB: Id=1, ContractNo="C-001"
			// 逻辑链路：
			// 1. mockDao.DeleteByVolcContractId() 失败，返回一个 error
			// 2. 函数记录错误日志并返回 "DeleteCommodityByNoFail" 错误
			metaDB := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 1},
				ContractNo: "C-001",
			}
			commodityList := []*model.VolcContractCommodity{}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(errors.New("db delete error")).Build()

			apiErr := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "DeleteCommodityByNoFail")
		})

		mockey.PatchConvey("Success Case - Empty commodityList", func() {
			// 场景描述：
			// 传入的商品列表为空，函数应在删除旧数据后直接返回成功。
			// 构造数据：
			// commodityList: 空列表
			// 逻辑链路：
			// 1. mockDao.DeleteByVolcContractId() 成功
			// 2. 检测到 commodityList 为空，直接返回 nil
			metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			commodityList := []*model.VolcContractCommodity{}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()

			err := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(err, convey.ShouldBeNil)
			convey.So(update, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("Failure Case - QueryProductListV1 returns error", func() {
			// 场景描述：
			// 查询商品中心获取商品信息时失败。
			// 构造数据：
			// commodityList: 非空
			// 逻辑链路：
			// 1. mockDao.DeleteByVolcContractId() 成功
			// 2. tradecli.QueryProductListV1() 失败，返回一个 error
			// 3. 函数返回 "查询关联商品信息失败" 错误
			metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			commodityList := []*model.VolcContractCommodity{{TradeProduct: "ProductA"}}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return(nil, errors.New("trade api error")).Build()

			apiErr := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "查询关联商品信息失败")
		})

		mockey.PatchConvey("Failure Case - CreateInBatches returns error", func() {
			// 场景描述：
			// 批量创建新商品记录时失败。
			// 构造数据：
			// commodityList: 非空
			// 逻辑链路：
			// 1. DeleteByVolcContractId 成功
			// 2. QueryProductListV1 成功
			// 3. CreateInBatches 失败，返回一个 error
			// 4. 函数返回 "CreateCommodityFail" 错误
			metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			commodityList := []*model.VolcContractCommodity{{TradeProduct: "ProductA"}}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{
				{Product: "ProductA"},
			}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(errors.New("db create error")).Build()

			apiErr := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "CreateCommodityFail")
		})

		mockey.PatchConvey("Success Case - Skip items with empty TradeProduct or not found in tradecli", func() {
			// 场景描述：
			// 商品列表中包含无效数据（空TradeProduct，或在商品中心查不到），应能被正确跳过。
			// 构造数据：
			// commodityList: 包含三个商品，一个TradeProduct为空，一个在tradecli查不到，一个正常。
			// 逻辑链路：
			// 1. DeleteByVolcContractId 成功
			// 2. 收集 TradeProduct 时，空字符串的商品被跳过
			// 3. QueryProductListV1 只返回一个商品的信息
			// 4. 遍历 enrichment 循环时，找不到信息的商品被跳过
			// 5. CreateInBatches 被调用，包含所有原始（但部分被 enrich 的）商品
			// 6. 函数成功返回
			metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			commodityList := []*model.VolcContractCommodity{
				{TradeProduct: ""},                // Should be skipped in the first loop
				{TradeProduct: "ProductNotFound"}, // Should be skipped in the second loop
				{TradeProduct: "ProductOK"},
			}
			update := make(map[string]interface{})

			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{
				{
					Product:     "ProductOK",
					ProductCode: "POK-001",
					IncomeCode:  "IC-OK",
				},
			}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			err := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(err, convey.ShouldBeNil)
			convey.So(update["product"], convey.ShouldEqual, "ProductNotFound,ProductOK")
			// The first item is untouched as it was skipped early
			convey.So(commodityList[0].TradeProduct, convey.ShouldBeEmpty)
			convey.So(commodityList[0].IncomeCode, convey.ShouldBeEmpty)
			// The second item is untouched as it was not found in the mapping
			convey.So(commodityList[1].TradeProduct, convey.ShouldEqual, "ProductNotFound")
			convey.So(commodityList[1].IncomeCode, convey.ShouldBeEmpty)
			// The third item is enriched
			convey.So(commodityList[2].TradeProduct, convey.ShouldEqual, "ProductOK")
			convey.So(commodityList[2].IncomeCode, convey.ShouldEqual, "IC-OK")
		})

		mockey.PatchConvey("Failure Case - Delete with empty ContractNo should not fail", func() {
			// 场景描述：
			// 当 metaDB.ContractNo 为空时，即使 DeleteByVolcContractId 返回错误，也不应该触发错误返回路径。
			// 逻辑链路：
			// 1. metaDB.ContractNo 为空
			// 2. `len(metaDB.ContractNo) > 0` 条件为 false，因此即使有 error，if 条件也不满足。
			// 3. 函数继续执行，并因为 commodityList 为空而成功返回。
			metaDB := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 1},
				ContractNo: "", // Empty contract number
			}
			commodityList := []*model.VolcContractCommodity{}
			update := make(map[string]interface{})

			// This mock will return an error, but it should be ignored by the logic.
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(errors.New("db delete error")).Build()

			apiErr := SaveCommodityList(ctx, tx, metaDB, commodityList, update)

			convey.So(apiErr, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_getAttachmentService_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getAttachmentService", t, func() {
		mockey.PatchConvey("should initialize services on first call and return the same instance on subsequent calls", func() {
			// 场景描述：
			// 测试 getAttachmentService 方法能否正确地进行懒汉式单例初始化。
			// 首次调用时，应通过 initService 初始化 handlerCommon 内的所有服务，并返回 attachmentService。
			// 后续调用时，由于 sync.Once 的作用，不应再次执行初始化，而是直接返回已创建的实例。
			//
			// 构造数据：
			// - 一个全新的、未初始化的 handlerCommon 实例。
			// - 为 initService 中所有依赖的 New... 方法创建 mock 实例。
			//
			// 逻辑链路：
			// 1. Mock metaattach.NewAttachmentService 等四个服务构造函数，使其返回预设的 mock 实例。
			// 2. 首次调用 getAttachmentService。
			// 3. 断言返回的 attachmentService 是预期的 mock 实例，并且 handlerCommon 内部的所有服务字段都已被正确赋值。
			// 4. 再次调用 getAttachmentService。
			// 5. 断言第二次调用返回的实例与第一次调用返回的实例完全相同，以验证 sync.Once 的幂等性。

			// 数据准备
			h := &handlerCommon{}
			ctx := context.Background()

			mockAttachmentSvc := &MockMetaAttachService{}
			mockCommoditySvc := &MockMetaCommodityService{}
			mockMetaSvc := &MockMetaService{}
			mockMetaSvcV2 := &MockMetaServiceV2{}

			// Mocking
			mockey.Mock(metaattach.NewAttachmentService).Return(mockAttachmentSvc).Build()
			mockey.Mock(metacommodity.NewService).Return(mockCommoditySvc).Build()
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaSvc).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaSvcV2).Build()

			// 首次调用
			svc1 := h.getAttachmentService(ctx)

			// 断言首次调用
			convey.So(svc1, convey.ShouldNotBeNil)
			convey.So(svc1, convey.ShouldEqual, mockAttachmentSvc)
			convey.So(h.attachmentService, convey.ShouldEqual, mockAttachmentSvc)

			// 再次调用
			svc2 := h.getAttachmentService(ctx)

			// 断言再次调用
			convey.So(svc2, convey.ShouldNotBeNil)
			convey.So(svc2, convey.ShouldEqual, svc1)
		})
	})
}

func Test_handlerCommon_fillSupplyExtInfoByFromContractInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_fillSupplyExtInfoByFromContractInfo", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: fromContractInfo为nil，直接返回", func() {
			// 场景描述：
			// 构造数据：fromContractInfo为nil。
			// 逻辑链路：
			// 1. 函数接收到nil的fromContractInfo。
			// 2. 函数直接返回nil，不执行任何操作。
			pc := &auditmodel.ProcessCtx{}
			var fromContractInfo *bizmodels.ContractMetaInfo

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 关联了报价单(pc.PreContractVO.RelateQuoteNo非空)，直接返回", func() {
			// 场景描述：
			// 构造数据：pc.PreContractVO.RelateQuoteNo不为空。
			// 逻辑链路：
			// 1. 函数判断pc.PreContractVO.RelateQuoteNo不为空。
			// 2. 函数直接返回nil，不执行任何填充逻辑。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					RelateQuoteNo: "Q-2023-12345",
				},
			}
			fromContractInfo := &bizmodels.ContractMetaInfo{}

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 未关联报价单，但fromContractInfo中无任何有效信息", func() {
			// 场景描述：
			// 构造数据：
			// - pc.PreContractVO.RelateQuoteNo为空。
			// - fromContractInfo不为nil，但其ManageInfo和ProjectInfo均为nil。
			// 逻辑链路：
			// 1. 函数判断未关联报价单，进入填充逻辑。
			// 2. 检查fromContractInfo.ManageInfo，为nil，跳过。
			// 3. 检查fromContractInfo.ProjectInfo，为nil，跳过。
			// 4. 函数正常返回nil，ProcessCtx未被修改。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					RelateQuoteNo: "",
				},
			}
			fromContractInfo := &bizmodels.ContractMetaInfo{
				ManageInfo:  nil,
				ProjectInfo: nil,
			}

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 未关联报价单，且fromContractInfo中所有信息均有效", func() {
			// 场景描述：
			// 构造数据：
			// - pc.PreContractVO.RelateQuoteNo为空。
			// - fromContractInfo.ManageInfo.BelongingDepartment有值。
			// - fromContractInfo.ProjectInfo有值，且所有相关字段都有值。
			// 逻辑链路：
			// 1. 函数判断未关联报价单，进入填充逻辑。
			// 2. 填充一级产品线，调用pc.UpdateBelongingDepartment。
			// 3. 填充产解行解，调用pc.UpdateProductSolutionEmail。
			// 4. 填充涉及资源方，调用pc.UpdateRelatedResDepartment。
			// 5. 填充交付人员，调用pc.UpdateDeliveryStaff。
			// 6. 函数正常返回nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					RelateQuoteNo: "",
				},
			}
			fromContractInfo := &bizmodels.ContractMetaInfo{
				ManageInfo: &bizmodels.ManageInfo{
					BelongingDepartment: "test-department",
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					ProductSolutionEmail: gptr.Of("ps@example.com"),
					RelatedResDepartment: gptr.Of("res-dept-test"),
					DeliveryStaff:        gptr.Of("staff-test"),
				},
			}

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).UpdateBelongingDepartment).To(func(_ *auditmodel.ProcessCtx, department string, _ bool) {
				convey.So(department, convey.ShouldEqual, "test-department")
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).UpdateProductSolutionEmail).To(func(_ *auditmodel.ProcessCtx, email *string, _ bool) {
				convey.So(*email, convey.ShouldEqual, "ps@example.com")
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).UpdateRelatedResDepartment).To(func(_ *auditmodel.ProcessCtx, department *string, _ bool) {
				convey.So(*department, convey.ShouldEqual, "res-dept-test")
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).UpdateDeliveryStaff).To(func(_ *auditmodel.ProcessCtx, staff *string, _ bool) {
				convey.So(*staff, convey.ShouldEqual, "staff-test")
			}).Build()

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 未关联报价单，且fromContractInfo中部分信息有效", func() {
			// 场景描述：
			// 构造数据：
			// - pc.PreContractVO.RelateQuoteNo为空。
			// - fromContractInfo.ManageInfo.BelongingDepartment有值。
			// - fromContractInfo.ProjectInfo有值，但只有产解行解有值，其他字段为空字符串或nil。
			// 逻辑链路：
			// 1. 函数判断未关联报价单，进入填充逻辑。
			// 2. 填充一级产品线，调用pc.UpdateBelongingDepartment。
			// 3. 填充产解行解，调用pc.UpdateProductSolutionEmail。
			// 4. 检查涉及资源方，因HasRelatedResDepartment返回false，不调用Update。
			// 5. 检查交付人员，因HasDeliveryStaff返回false，不调用Update。
			// 6. 函数正常返回nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					RelateQuoteNo: "",
				},
			}
			fromContractInfo := &bizmodels.ContractMetaInfo{
				ManageInfo: &bizmodels.ManageInfo{
					BelongingDepartment: "test-department-partial",
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					ProductSolutionEmail: gptr.Of("ps-partial@example.com"),
					RelatedResDepartment: gptr.Of(""), // Empty string
					DeliveryStaff:        nil,         // Nil pointer
				},
			}

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).UpdateBelongingDepartment).To(func(_ *auditmodel.ProcessCtx, department string, _ bool) {
				convey.So(department, convey.ShouldEqual, "test-department-partial")
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).UpdateProductSolutionEmail).To(func(_ *auditmodel.ProcessCtx, email *string, _ bool) {
				convey.So(*email, convey.ShouldEqual, "ps-partial@example.com")
			}).Build()
			// UpdateRelatedResDepartment 和 UpdateDeliveryStaff 不应被调用，无需mock

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景6: 未关联报价单，ManageInfo中BelongingDepartment为空", func() {
			// 场景描述：
			// 构造数据：
			// - pc.PreContractVO.RelateQuoteNo为空。
			// - fromContractInfo.ManageInfo 不为nil，但BelongingDepartment为空字符串。
			// 逻辑链路：
			// 1. 函数判断未关联报价单，进入填充逻辑。
			// 2. 检查fromContractInfo.ManageInfo.BelongingDepartment，为空，跳过。
			// 3. 函数正常返回nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					RelateQuoteNo: "",
				},
			}
			fromContractInfo := &bizmodels.ContractMetaInfo{
				ManageInfo: &bizmodels.ManageInfo{
					BelongingDepartment: "",
				},
				ProjectInfo: nil,
			}

			// 调用
			err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, fromContractInfo)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_countersignReviewer_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock struct for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerCommon_countersignReviewer", t, func() {
		// Arrange: Initialize common variables for all test cases.
		h := &handlerCommon{}
		ctx := context.Background()
		mockDB := &gorm.DB{}

		mockey.PatchConvey("场景：前加签 (PreApostille)", func() {
			pc := &auditmodel.ProcessCtx{
				SecondaryOperationType: _const.SecondaryOperationTypePreApostille,
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-001",
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "dep-123",
					},
				},
			}
			curReviewer := &bizmodels.PreContractReviewer{
				ReviewerType:   1,
				ContractStatus: 10,
				ReviewerRole:   1,
				Priority:       5,
			}
			reviewer := &peopleclient.Employee{
				ID:    1001,
				Email: "new.reviewer@example.com",
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()

			mockey.PatchConvey("当审核人不存在时，成功创建新的前加签审核人", func() {
				// 场景描述：
				// 构造数据：设置操作类型为前加签，审核人不存在。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回 nil, nil (审核人不存在)
				// 2. if pc.SecondaryOperationType == _const.SecondaryOperationTypePreApostille 条件为 true, priority 增加1.
				// 3. if existsReviewer != nil 条件为 false.
				// 4. dal.CreatePreContractReviewer 被调用，用于创建新的审核人记录。
				// 5. dal.CreatePreContractReviewer 返回 nil (创建成功).
				// 6. 函数返回 nil.

				// Mock
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(nil, nil).Build()
				mockey.Mock(dal.CreatePreContractReviewer).To(func(_ context.Context, tx *gorm.DB, reviewerDB *model.PreContractReviewerDB) error {
					convey.So(reviewerDB.PreContractNo, convey.ShouldEqual, pc.ContractInfo.ContractNo)
					convey.So(reviewerDB.Reviewer, convey.ShouldEqual, reviewer.Email)
					convey.So(reviewerDB.ReviewerID, convey.ShouldEqual, strconv.Itoa(reviewer.ID))
					convey.So(reviewerDB.Priority, convey.ShouldEqual, curReviewer.Priority+1) // 前加签，优先级+1
					convey.So(reviewerDB.ReviewerSource, convey.ShouldEqual, _const.ReviewGradePreApostilleReviewers)
					return nil
				}).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("当审核人已存在时，成功更新已有的审核人信息", func() {
				// 场景描述：
				// 构造数据：设置操作类型为前加签，审核人已存在。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回一个已存在的审核人实例。
				// 2. if pc.SecondaryOperationType == _const.SecondaryOperationTypePreApostille 条件为 true, priority 增加1.
				// 3. if existsReviewer != nil 条件为 true，进入更新逻辑。
				// 4. dal.NewPreContractReviewerDao().UpdateByID 被调用。
				// 5. UpdateByID 返回 nil (更新成功).
				// 6. 函数返回 nil.

				// Mock
				existsReviewer := &model.PreContractReviewerDB{BaseDB: model.BaseDB{Id: 999}}
				mockDao := &MockPreContractReviewerDao{}
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(existsReviewer, nil).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
				mockey.Mock((*MockPreContractReviewerDao).UpdateByID).To(func(_ context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
					convey.So(id, convey.ShouldEqual, existsReviewer.Id)
					convey.So(updates["status"], convey.ShouldEqual, _const.ReviewStatusUnreviewed)
					convey.So(updates["priority"], convey.ShouldEqual, curReviewer.Priority+1) // 前加签，优先级+1
					convey.So(updates["skip_return_review"], convey.ShouldEqual, 0)
					return nil
				}).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("当审核人已存在且原角色为被加签人员时，更新为继承后的角色", func() {
				existsReviewer := &model.PreContractReviewerDB{
					BaseDB:       model.BaseDB{Id: 1000},
					ReviewerRole: _const.ReviewerRoleCountersign,
				}
				mockDao := &MockPreContractReviewerDao{}
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(existsReviewer, nil).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
				mockey.Mock((*MockPreContractReviewerDao).UpdateByID).To(func(_ context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
					convey.So(id, convey.ShouldEqual, existsReviewer.Id)
					convey.So(updates["reviewer_role"], convey.ShouldEqual, _const.ReviewerRoleCountersign)
					convey.So(updates["status"], convey.ShouldEqual, _const.ReviewStatusUnreviewed)
					convey.So(updates["priority"], convey.ShouldEqual, curReviewer.Priority+1)
					return nil
				}).Build()

				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("当创建审核人失败时，返回错误", func() {
				// 场景描述：
				// 构造数据：设置操作类型为前加签，审核人不存在。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回 nil, nil.
				// 2. if existsReviewer != nil 条件为 false.
				// 3. dal.CreatePreContractReviewer 返回一个错误。
				// 4. 函数记录日志并返回该错误。

				// Mock
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(nil, nil).Build()
				mockey.Mock(dal.CreatePreContractReviewer).Return(errors.New("db create error")).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "db create error")
			})

		})

		mockey.PatchConvey("场景：并加签 (StandApostille)", func() {
			pc := &auditmodel.ProcessCtx{
				SecondaryOperationType: _const.SecondaryOperationTypeStandApostille, // 并加签
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-002",
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "dep-456",
					},
				},
			}
			curReviewer := &bizmodels.PreContractReviewer{
				ReviewerType:   1,
				ContractStatus: 10,
				ReviewerRole:   1,
				Priority:       5,
			}
			reviewer := &peopleclient.Employee{
				ID:    1002,
				Email: "another.reviewer@example.com",
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()

			mockey.PatchConvey("当审核人不存在时，成功创建新的并加签审核人", func() {
				// 场景描述：
				// 构造数据：设置操作类型为并加签，审核人不存在。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回 nil, nil (审核人不存在)。
				// 2. if pc.SecondaryOperationType == ...PreApostille 条件为 false, priority 不变。
				// 3. if existsReviewer != nil 条件为 false。
				// 4. dal.CreatePreContractReviewer 被调用。
				// 5. dal.CreatePreContractReviewer 返回 nil (创建成功)。
				// 6. 函数返回 nil。

				// Mock
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(nil, nil).Build()
				mockey.Mock(dal.CreatePreContractReviewer).To(func(_ context.Context, tx *gorm.DB, reviewerDB *model.PreContractReviewerDB) error {
					convey.So(reviewerDB.Priority, convey.ShouldEqual, curReviewer.Priority) // 并加签，优先级不变
					convey.So(reviewerDB.ReviewerSource, convey.ShouldEqual, _const.ReviewGradeStandApostilleReviewers)
					return nil
				}).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("当审核人已存在时，成功更新已有的审核人信息", func() {
				// 场景描述：
				// 构造数据：设置操作类型为并加签，审核人已存在。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回一个已存在的审核人实例。
				// 2. if pc.SecondaryOperationType == ...PreApostille 条件为 false, priority 不变。
				// 3. if existsReviewer != nil 条件为 true，进入更新逻辑。
				// 4. dal.NewPreContractReviewerDao().UpdateByID 被调用。
				// 5. UpdateByID 返回 nil (更新成功)。
				// 6. 函数返回 nil。

				// Mock
				existsReviewer := &model.PreContractReviewerDB{BaseDB: model.BaseDB{Id: 888}}
				mockDao := &MockPreContractReviewerDao{}
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(existsReviewer, nil).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
				mockey.Mock((*MockPreContractReviewerDao).UpdateByID).To(func(_ context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
					convey.So(id, convey.ShouldEqual, existsReviewer.Id)
					convey.So(updates["priority"], convey.ShouldEqual, curReviewer.Priority) // 并加签，优先级不变
					return nil
				}).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("场景：通用错误处理", func() {
			pc := &auditmodel.ProcessCtx{}
			curReviewer := &bizmodels.PreContractReviewer{}
			reviewer := &peopleclient.Employee{}

			mockey.PatchConvey("当 matchExistsReviewer 返回错误时，函数直接返回错误", func() {
				// 场景描述：
				// 构造数据：无特殊构造。
				// 逻辑链路：
				// 1. matchExistsReviewer 返回一个错误。
				// 2. 函数直接将此错误返回。

				// Mock
				mockey.Mock((*handlerCommon).matchExistsReviewer).Return(nil, errors.New("match error")).Build()

				// Act
				err := h.countersignReviewer(ctx, pc, curReviewer, reviewer)

				// Assert
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "match error")
			})
		})
	})
}

func Test_handlerCommon_SendSubmitOaMsg_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon SendSubmitOaMsg", t, func() {
		// Common setup for all tests
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: "test-contract-no-12345",
			},
		}

		mockey.PatchConvey("场景: 成功发送提交OA延迟消息", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同号的ProcessCtx
			// 逻辑链路：
			// 1. json.Marshal 成功
			// 2. Mock mqProducer.SendDeferMessage 返回成功 (nil error)
			// 3. 函数返回 nil
			mockey.Mock(mqProducer.SendDeferMessage).Return(nil).Build()

			// 调用目标函数
			apiErr := h.SendSubmitOaMsg(ctx, pc)

			// 断言
			convey.So(apiErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景: 发送延迟消息失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同号的ProcessCtx
			// 逻辑链路：
			// 1. json.Marshal 成功
			// 2. Mock mqProducer.SendDeferMessage 返回一个错误
			// 3. 函数记录错误日志并返回一个 "SendSubmitOaMsgFail" 错误
			mqErr := errors.New("failed to send message to mq")
			mockey.Mock(mqProducer.SendDeferMessage).Return(mqErr).Build()

			// 调用目标函数
			apiErr := h.SendSubmitOaMsg(ctx, pc)

			// 断言
			convey.So(apiErr, convey.ShouldNotBeNil)
			expectedErr := errorsV2.ErrCommon.WithArgs("SendSubmitOaMsgFail")
			convey.So(apiErr.GetCode(), convey.ShouldEqual, expectedErr.GetCode())
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "SendSubmitOaMsgFail")
		})

		mockey.PatchConvey("场景: JSON序列化请求体失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含合同号的ProcessCtx
			// 逻辑链路：
			// 1. Mock json.Marshal 返回一个错误
			// 2. 函数记录错误日志并返回一个 "SubmitOAReqMarshalFail" 错误
			jsonErr := errors.New("json marshal failed")
			mockey.Mock(json.Marshal).When(func(v interface{}) bool {
				// 确保只mock我们预期的那次调用
				_, ok := v.(*bizmodels.DeferMsgSubmitOA)
				return ok
			}).Return(nil, jsonErr).Build()

			// 调用目标函数
			apiErr := h.SendSubmitOaMsg(ctx, pc)

			// 断言
			convey.So(apiErr, convey.ShouldNotBeNil)
			expectedErr := errorsV2.ErrCommon.WithArgs("SubmitOAReqMarshalFail")
			convey.So(apiErr.GetCode(), convey.ShouldEqual, expectedErr.GetCode())
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "SubmitOAReqMarshalFail")
		})
	})
}

func Test_handlerCommon_updatePreContract_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon updatePreContract", t, func() {
		mockey.Mock(logs.CtxInfo).Return().Build()
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}

		mockey.PatchConvey("success case - all fields are provided and updated", func() {
			entity := &model.ContractMetaDB{
				ContractNo:                 "CTR-2023-001",
				Creator:                    "test.user",
				MainContractNo:             "MAIN-CTR-001",
				FromContractNo:             "FROM-CTR-001",
				VolcContractNo:             "VOLC-CTR-001",
				FromContractTerminatedTime: time.Now(),
				SupplyScene:                1,
				SupplySource:               `["source1"]`,
				ContractName:               "Test Contract Name",
				SubjectName:                "Test Subject",
				OtherPartyName:             "Test Other Party",
				Operator:                   "operator1",
				OperatorNew:                "operator2",
				CreatorNew:                 "creator2",
				PropertyCode:               "P123",
				CategoryNo:                 "C456",
				SignatureType:              "E-SIGN",
				InOutType:                  "IN",
				SubjectAccountIds:          "acc1,acc2",
				BeginTime:                  time.Now().Add(-time.Hour * 24),
				EndTime:                    time.Now().Add(time.Hour * 24 * 30),
				SubmitTime:                 time.Now(),
				BasicInfo:                  `{"info":"basic"}`,
				ProjectInfo:                `{"info":"project"}`,
				TradePartyInfo:             `{"info":"trade"}`,
				SettlementClause:           `{"clause":"settlement"}`,
				IsContainRefundClause:      1,
				ContractProductInfo:        `{"product":"info"}`,
				ContractAttachment:         `{"attachment":"info"}`,
				IsBackdating:               1,
				ReverseSignInfo:            `{"reverse":"info"}`,
				RelateQuoteNo:              "QUOTE-001",
				SpecialContractType:        "TYPE-A",
				TemplateInfo:               `{"template":"info"}`,
				ContractFile:               `{"file":"info"}`,
			}

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).When(
				func(ctx context.Context, tx *gorm.DB, contractNo string, updates map[string]interface{}) bool {
					convey.So(contractNo, convey.ShouldEqual, entity.ContractNo)
					convey.So(updates["main_contract_no"], convey.ShouldEqual, entity.MainContractNo)
					convey.So(updates["from_contract_no"], convey.ShouldEqual, entity.FromContractNo)
					convey.So(updates["volc_contract_no"], convey.ShouldEqual, entity.VolcContractNo)
					convey.So(updates["from_contract_terminated_time"], convey.ShouldEqual, entity.FromContractTerminatedTime)
					convey.So(updates["supply_scene"], convey.ShouldEqual, entity.SupplyScene)
					convey.So(updates["supply_source"], convey.ShouldEqual, entity.SupplySource)
					convey.So(updates["contract_file"], convey.ShouldEqual, entity.ContractFile)
					convey.So(updates["contract_name"], convey.ShouldEqual, entity.ContractName)
					convey.So(updates["creator"], convey.ShouldEqual, entity.Creator)
					convey.So(updates["creator_new"], convey.ShouldEqual, entity.CreatorNew)
					convey.So(len(updates), convey.ShouldEqual, 35)
					return true
				},
			).Return(nil).Build()

			err := h.updatePreContract(ctx, tx, entity)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case - only required fields are provided", func() {
			entity := &model.ContractMetaDB{
				ContractNo:            "CTR-2023-002",
				Creator:               "test.user.minimal",
				ContractName:          "Minimal Contract",
				SubjectName:           "Minimal Subject",
				OtherPartyName:        "Minimal Other Party",
				Operator:              "op_min_1",
				OperatorNew:           "op_min_2",
				CreatorNew:            "creator_min_2",
				PropertyCode:          "P_MIN",
				CategoryNo:            "C_MIN",
				SignatureType:         "PAPER",
				InOutType:             "OUT",
				SubjectAccountIds:     "acc_min",
				BeginTime:             time.Now().Add(-time.Hour),
				EndTime:               time.Now().Add(time.Hour),
				SubmitTime:            time.Now(),
				BasicInfo:             `{}`,
				ProjectInfo:           `{}`,
				TradePartyInfo:        `{}`,
				SettlementClause:      `{}`,
				IsContainRefundClause: 0,
				ContractProductInfo:   `{}`,
				ContractAttachment:    `{}`,
				IsBackdating:          0,
				ReverseSignInfo:       `{}`,
				RelateQuoteNo:         "QUOTE-MIN",
				SpecialContractType:   "TYPE-MIN",
				TemplateInfo:          `{}`,
			}

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).When(
				func(ctx context.Context, tx *gorm.DB, contractNo string, updates map[string]interface{}) bool {
					convey.So(contractNo, convey.ShouldEqual, entity.ContractNo)
					convey.So(updates, convey.ShouldNotContainKey, "main_contract_no")
					convey.So(updates, convey.ShouldNotContainKey, "from_contract_no")
					convey.So(updates, convey.ShouldNotContainKey, "volc_contract_no")
					convey.So(updates, convey.ShouldNotContainKey, "from_contract_terminated_time")
					convey.So(updates, convey.ShouldNotContainKey, "supply_scene")
					convey.So(updates, convey.ShouldNotContainKey, "supply_source")
					convey.So(updates, convey.ShouldNotContainKey, "contract_file")
					convey.So(updates["creator"], convey.ShouldEqual, entity.Creator)
					convey.So(updates["creator_new"], convey.ShouldEqual, entity.CreatorNew)
					convey.So(len(updates), convey.ShouldEqual, 28)
					return true
				},
			).Return(nil).Build()

			err := h.updatePreContract(ctx, tx, entity)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case - database update fails", func() {
			entity := &model.ContractMetaDB{
				ContractNo: "CTR-2023-FAIL",
				Creator:    "test.user.fail",
			}
			dbErr := errors.New("database update error")

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(dbErr).Build()

			err := h.updatePreContract(ctx, tx, entity)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})
	})
}

func Test_handlerCommon_addOrUpdateFilePerm_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerCommon_addOrUpdateFilePerm", t, func() {
		// Mock the recovery function which is deferred in all cases.
		mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()

		mockey.PatchConvey("成功场景: 成功获取员工信息并更新文件权限", func() {
			// 场景描述：
			// 这是一个完整的成功路径测试。
			// 构造数据：
			// 构造一个包含两个用户的 UpdateUserPermissionReq 请求。
			// 逻辑链路：
			// 1. 函数检查 req.Users 不为空，继续执行。
			// 2. Mock req.GetAllUserEmails() 返回两个用户的邮箱列表。
			// 3. Mock larkc.GetEmployeeByMailsWithCache 成功返回两个员工的信息。
			// 4. 函数内部构建员工ID到员工信息的映射。
			// 5. 遍历 req.Users，使用映射中的信息更新每个用户的 Name 和 AvatarUrl。
			// 6. Mock filecli.UpdateUserPermission 成功，返回 nil。
			// 7. 函数正常结束，req 中的用户信息被成功修改。
			req := &filecli.UpdateUserPermissionReq{
				Users: filecli.Users{
					{Uid: "123", Email: "test1@example.com"},
					{Uid: "456", Email: "test2@example.com"},
				},
			}
			emails := []string{"test1@example.com", "test2@example.com"}
			employees := []*peopleclient.Employee{
				{ID: 123, Name: "User One", AvatarURL: "url1"},
				{ID: 456, Name: "User Two", AvatarURL: "url2"},
			}

			mockey.Mock((*filecli.UpdateUserPermissionReq).GetAllUserEmails).Return(emails).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(employees, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()

			h.addOrUpdateFilePerm(ctx, req)

			convey.So(req.Users[0].Name, convey.ShouldEqual, "User One")
			convey.So(req.Users[0].AvatarUrl, convey.ShouldEqual, "url1")
			convey.So(req.Users[1].Name, convey.ShouldEqual, "User Two")
			convey.So(req.Users[1].AvatarUrl, convey.ShouldEqual, "url2")
		})

		mockey.PatchConvey("边缘场景: 请求中用户列表为空", func() {
			// 场景描述：
			// 测试当传入请求的用户列表为空时，函数应提前返回。
			// 构造数据：
			// 构造一个 Users 字段为空切片的 UpdateUserPermissionReq 请求。
			// 逻辑链路：
			// 1. 函数检查 len(req.Users) == 0 为 true，直接 return。
			// 2. 后续的 API 调用（如 GetEmployeeByMailsWithCache）不应被执行。
			req := &filecli.UpdateUserPermissionReq{
				Users: filecli.Users{},
			}

			// No mocks needed beyond recovery, as the function should exit early.
			h.addOrUpdateFilePerm(ctx, req)

			// No assertion needed, test passes if no panic occurs.
		})

		mockey.PatchConvey("失败场景: 获取员工信息失败", func() {
			// 场景描述：
			// 测试当调用 larkc.GetEmployeeByMailsWithCache 获取员工信息失败时，函数能够正确处理错误并返回。
			// 构造数据：
			// 构造一个包含一个用户的 UpdateUserPermissionReq 请求。
			// 逻辑链路：
			// 1. Mock req.GetAllUserEmails() 返回邮箱列表。
			// 2. Mock larkc.GetEmployeeByMailsWithCache 返回一个非 nil 的 error。
			// 3. 函数捕获到错误，记录日志并 return。
			// 4. filecli.UpdateUserPermission 不应被调用。
			// 5. 请求中的用户信息不应被修改。
			req := &filecli.UpdateUserPermissionReq{
				Users: filecli.Users{
					{Uid: "123", Email: "test1@example.com", Name: "Original Name"},
				},
			}
			emails := []string{"test1@example.com"}
			mockErr := errors.New("larkc get employee failed")

			mockey.Mock((*filecli.UpdateUserPermissionReq).GetAllUserEmails).Return(emails).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, mockErr).Build()

			h.addOrUpdateFilePerm(ctx, req)

			convey.So(req.Users[0].Name, convey.ShouldEqual, "Original Name")
		})

		mockey.PatchConvey("边缘场景: 部分员工信息未找到", func() {
			// 场景描述：
			// 测试当获取到的员工列表不完整时，函数能正确处理，只更新找到的用户信息。
			// 构造数据：
			// 请求中包含两个用户，但 larkc.GetEmployeeByMailsWithCache 只返回一个员工的信息。
			// 逻辑链路：
			// 1. larkc.GetEmployeeByMailsWithCache 调用成功，但返回数据不完整。
			// 2. 在遍历 req.Users 时，一个用户能找到匹配的员工信息并更新，另一个用户找不到。
			// 3. 对于找不到的用户，if employee == nil 条件为 true，执行 continue 跳过。
			// 4. filecli.UpdateUserPermission 仍然被调用以更新找到的用户权限。
			req := &filecli.UpdateUserPermissionReq{
				Users: filecli.Users{
					{Uid: "123", Email: "test1@example.com"},
					{Uid: "789", Email: "notfound@example.com", Name: "Original Unchanged"},
				},
			}
			emails := []string{"test1@example.com", "notfound@example.com"}
			employees := []*peopleclient.Employee{
				{ID: 123, Name: "User One", AvatarURL: "url1"},
			}

			mockey.Mock((*filecli.UpdateUserPermissionReq).GetAllUserEmails).Return(emails).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(employees, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()

			h.addOrUpdateFilePerm(ctx, req)

			convey.So(req.Users[0].Name, convey.ShouldEqual, "User One")
			convey.So(req.Users[0].AvatarUrl, convey.ShouldEqual, "url1")
			convey.So(req.Users[1].Name, convey.ShouldEqual, "Original Unchanged")
			convey.So(req.Users[1].AvatarUrl, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("失败场景: 更新文件权限失败", func() {
			// 场景描述：
			// 测试在最后一步调用 filecli.UpdateUserPermission 更新权限时失败的场景。
			// 构造数据：
			// 所有前置步骤均成功，但最终的权限更新调用返回错误。
			// 逻辑链路：
			// 1. 获取员工信息并更新 req.Users 中的 Name 和 AvatarUrl 成功。
			// 2. Mock filecli.UpdateUserPermission 返回一个非 nil 的 error。
			// 3. 函数捕获到错误，记录日志并结束。
			// 4. 尽管最终调用失败，但 req 对象中的用户信息已经被修改。
			req := &filecli.UpdateUserPermissionReq{
				Users: filecli.Users{
					{Uid: "123", Email: "test1@example.com"},
				},
			}
			emails := []string{"test1@example.com"}
			employees := []*peopleclient.Employee{
				{ID: 123, Name: "User One", AvatarURL: "url1"},
			}
			mockErr := errors.New("filecli update permission failed")

			mockey.Mock((*filecli.UpdateUserPermissionReq).GetAllUserEmails).Return(emails).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(employees, nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(mockErr).Build()

			h.addOrUpdateFilePerm(ctx, req)

			// Assert that user info was updated in the request object before the final call failed.
			convey.So(req.Users[0].Name, convey.ShouldEqual, "User One")
			convey.So(req.Users[0].AvatarUrl, convey.ShouldEqual, "url1")
		})
	})
}

func Test_handlerCommon_commonPostProcessUpdateReviewers_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock struct for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerCommon.commonPostProcessUpdateReviewers", t, func() {
		// Common mocks for Lark message sending logic to avoid repetition.
		// These mocks ensure that the message building and sending parts don't cause panics
		// due to un-mocked dependencies and don't perform real external calls.
		mockBuilder := &larkc.CommonMessageCardBuilder{}
		mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return(`{}`).Build()

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
		mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
		mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()

		mockey.PatchConvey("场景：获取加签/转办人员信息失败", func() {
			// 场景描述:
			// 构造数据: pc.Extra包含一个邮箱
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer() 返回成功
			// 2. larkc.GetEmployeeByMailsWithCache 返回一个错误
			// 3. 函数记录错误日志并直接返回该错误
			pc := &auditmodel.ProcessCtx{
				Extra: "new.reviewer@example.com",
			}
			mockErr := errors.New("get employee failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, mockErr).Build()

			err := h.commonPostProcessUpdateReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "get employee failed")
		})

		mockey.PatchConvey("场景：加签操作", func() {
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationAddReviewer,
				Extra:           "new.reviewer1@example.com,new.reviewer2@example.com",
				CurrentOperator: "current.operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-123",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
				},
			}
			currentReviewer := &bizmodels.PreContractReviewer{Priority: 1}
			newReviewers := []*peopleclient.Employee{
				{Email: "new.reviewer1@example.com", ID: 101},
				{Email: "new.reviewer2@example.com", ID: 102},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			mockey.PatchConvey("子场景：成功加签并发送通知", func() {
				// 场景描述:
				// 构造数据: pc.OperationState = OperationAddReviewer, pc.Extra 包含两个邮箱
				// 逻辑链路:
				// 1. GetCurrentReviewer 和 GetEmployeeByMailsWithCache 均成功返回
				// 2. 循环两次，每次调用 h.countersignReviewer 均返回成功
				// 3. 不会进入 "转办" 相关的逻辑
				// 4. 成功发送飞书消息
				// 5. 函数返回 nil
				mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：加签时发生错误", func() {
				// 场景描述:
				// 构造数据: pc.OperationState = OperationAddReviewer, pc.Extra 包含两个邮箱
				// 逻辑链路:
				// 1. GetCurrentReviewer 和 GetEmployeeByMailsWithCache 均成功返回
				// 2. 第一次循环调用 h.countersignReviewer 时返回一个错误
				// 3. 函数立即中断并返回该错误
				mockErr := errors.New("countersign failed")
				mockey.Mock((*handlerCommon).countersignReviewer).Return(mockErr).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "countersign failed")
			})
		})

		mockey.PatchConvey("场景：转办操作", func() {
			mockDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()

			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "current.operator@example.com",
				PreContractNo:   "PC-456",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-456",
					ContractName:   "Test Contract 2",
					OtherPartyName: "Test Party 2",
				},
			}
			newReviewers := []*peopleclient.Employee{
				{Email: "new.reviewer@example.com", ID: 103},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			mockey.PatchConvey("子场景：成功转办并发送通知", func() {
				// 场景描述:
				// 构造数据: pc.OperationState = OperationChangeReviewer
				// 逻辑链路:
				// 1. GetEmployeeByMailsWithCache 成功返回
				// 2. 循环调用 h.changeReviewer 成功返回
				// 3. 调用 dal.DeleteChangedReviewer 成功返回
				// 4. 成功发送飞书消息
				// 5. 函数返回 nil
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：转办时发生错误", func() {
				// 场景描述:
				// 构造数据: pc.OperationState = OperationChangeReviewer
				// 逻辑链路:
				// 1. GetEmployeeByMailsWithCache 成功返回
				// 2. 循环调用 h.changeReviewer 时返回一个错误
				// 3. 函数立即中断并返回该错误
				mockErr := errors.New("change reviewer failed")
				mockey.Mock((*handlerCommon).changeReviewer).Return(mockErr).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "change reviewer failed")
			})

			mockey.PatchConvey("子场景：删除被转办人时发生错误", func() {
				// 场景描述:
				// 构造数据: pc.OperationState = OperationChangeReviewer
				// 逻辑链路:
				// 1. GetEmployeeByMailsWithCache 成功返回
				// 2. 循环调用 h.changeReviewer 成功返回
				// 3. 调用 dal.DeleteChangedReviewer 返回一个错误
				// 4. 函数记录错误日志，但继续执行并最终返回 nil
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("delete failed")).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("场景：其他操作", func() {
			// 场景描述:
			// 构造数据: pc.OperationState 不是加签或转办，例如审核通过
			// 逻辑链路:
			// 1. GetEmployeeByMailsWithCache 成功返回
			// 2. for 循环中的 if/else if 条件均不匹配，不调用 countersign/change reviewer
			// 3. 不进入 "转办后删除" 逻辑
			// 4. 进入发送飞书消息的 else 分支
			// 5. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				Extra:          "reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-789",
					ContractName:   "Test Contract 3",
					OtherPartyName: "Test Party 3",
				},
			}
			newReviewers := []*peopleclient.Employee{
				{Email: "reviewer@example.com", ID: 104},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			err := h.commonPostProcessUpdateReviewers(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_checkCategoryReviewerRole_BitsUTGen(t *testing.T) {
	// The method under test does not use any fields from handlerCommon,
	// so a simple initialization is sufficient.
	h := &handlerCommon{}

	mockey.PatchConvey("Test_handlerCommon_checkCategoryReviewerRole", t, func() {
		mockey.PatchConvey("场景：当合同分类为资源置换时，不进行任何过滤", func() {
			// 场景描述：
			// 构造数据：categoryNo 设置为 _const.BizCategoryNoCommonZYZH ("1038")，代表资源置换。
			// 逻辑链路：
			// 1. 函数执行，进入第一个 if 条件 `categoryNo == _const.BizCategoryNoCommonZYZH`。
			// 2. 函数直接返回传入的 roles 切片，不进行任何修改。
			categoryNo := _const.BizCategoryNoCommonZYZH
			roles := []string{"销售运营", "财务BP", "税务BP", "法务BP"}

			result := h.checkCategoryReviewerRole(categoryNo, roles)

			convey.So(result, convey.ShouldResemble, roles)
		})

		mockey.PatchConvey("场景：当合同分类非资源置换，且角色列表包含税务BP时，应过滤掉税务BP", func() {
			// 场景描述：
			// 构造数据：categoryNo 设置为非 "1038" 的值，roles 列表中包含 "税务BP"。
			// 逻辑链路：
			// 1. 函数不满足第一个 if 条件。
			// 2. Mock _const.GetReviewerRoleName(_const.ReviewerRoleTaxBP) 返回 "税务BP"。
			// 3. 函数遍历 roles 切片，当遇到 "税务BP" 时，if v == "税务BP" 条件成立，执行 continue。
			// 4. 其他角色被添加到新的结果切片中。
			// 5. 函数返回过滤后的切片。
			categoryNo := _const.BizCategoryNoCommonHZXY // 使用一个非资源置换的分类
			roles := []string{"销售运营", "财务BP", "税务BP", "法务BP"}
			expectedRoles := []string{"销售运营", "财务BP", "法务BP"}

			mockey.Mock(_const.GetReviewerRoleName).Return("税务BP").Build()

			result := h.checkCategoryReviewerRole(categoryNo, roles)

			convey.So(result, convey.ShouldResemble, expectedRoles)
		})

		mockey.PatchConvey("场景：当合同分类非资源置换，且角色列表不包含税务BP时，返回内容相同的角色列表", func() {
			// 场景描述：
			// 构造数据：categoryNo 设置为非 "1038" 的值，roles 列表中不包含 "税务BP"。
			// 逻辑链路：
			// 1. 函数不满足第一个 if 条件。
			// 2. Mock _const.GetReviewerRoleName(_const.ReviewerRoleTaxBP) 返回 "税务BP"。
			// 3. 函数遍历 roles 切片，if v == "税务BP" 条件始终不成立。
			// 4. 所有角色都被添加到新的结果切片中。
			// 5. 函数返回一个与输入内容相同的新切片。
			categoryNo := "some_other_category"
			roles := []string{"销售运营", "财务BP", "法务BP"}
			expectedRoles := []string{"销售运营", "财务BP", "法务BP"}

			mockey.Mock(_const.GetReviewerRoleName).Return("税务BP").Build()

			result := h.checkCategoryReviewerRole(categoryNo, roles)

			convey.So(result, convey.ShouldResemble, expectedRoles)
		})

		mockey.PatchConvey("场景：当角色列表为nil时，应返回nil", func() {
			// 场景描述：
			// 构造数据：传入一个nil的 roles 切片。
			// 逻辑链路：
			// 1. 假设 categoryNo 非资源置换，不满足第一个 if 条件。
			// 2. 函数的 for 循环不会执行。
			// 3. 函数返回一个初始化的nil切片。
			categoryNo := "some_other_category"
			var roles []string // nil slice

			result := h.checkCategoryReviewerRole(categoryNo, roles)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：当角色列表仅包含税务BP时，应返回nil", func() {
			// 场景描述：
			// 构造数据：categoryNo 非资源置换，roles 列表只包含 "税务BP"。
			// 逻辑链路：
			// 1. 函数不满足第一个 if 条件。
			// 2. Mock _const.GetReviewerRoleName(_const.ReviewerRoleTaxBP) 返回 "税务BP"。
			// 3. 函数遍历 roles 切片，唯一的元素 "税务BP" 满足过滤条件，被 continue。
			// 4. 循环结束后，结果切片为nil。
			// 5. 函数返回nil。
			categoryNo := "some_other_category"
			roles := []string{"税务BP"}

			mockey.Mock(_const.GetReviewerRoleName).Return("税务BP").Build()

			result := h.checkCategoryReviewerRole(categoryNo, roles)

			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_buildPermReq_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_buildPermReq", t, func() {
		h := &handlerCommon{}

		mockey.PatchConvey("正常场景-单个审核员匹配删除权限", func() {
			// 场景描述：
			// 构造一个审核员列表，其中一个审核员的类型与指定的删除权限类型匹配。
			// 构造数据：
			// - reviewers: 包含一个ReviewerType为1的审核员。
			// - updateInfo: DeletePermReviewerType指向1，WritePermReviewerType为nil。
			// 逻辑链路：
			// 1. 遍历reviewers列表。
			// 2. if条件 `reviewer.ReviewerType == *updateInfo.DeletePermReviewerType` 成立。
			// 3. permOP被赋值为_const.PermissionDelete。
			// 4. 创建一个filecli.User并添加到结果列表中。
			// 5. 返回包含一个用户的UpdateUserPermissionReq。
			reviewers := bizmodels.PreContractReviewerList{
				{
					ReviewerID:   "user1",
					Reviewer:     "user1@example.com",
					ReviewerType: 1,
				},
			}
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-123",
				DeletePermReviewerType: gptr.Of(1),
				WritePermReviewerType:  nil,
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 1)
			convey.So(req.Users[0].FileId, convey.ShouldEqual, "file-id-123")
			convey.So(req.Users[0].Uid, convey.ShouldEqual, "user1")
			convey.So(req.Users[0].Email, convey.ShouldEqual, "user1@example.com")
			convey.So(req.Users[0].Permission, convey.ShouldEqual, _const.PermissionDelete)
		})

		mockey.PatchConvey("正常场景-单个审核员匹配写入权限", func() {
			// 场景描述：
			// 构造一个审核员列表，其中一个审核员的类型与指定的写入权限类型匹配。
			// 构造数据：
			// - reviewers: 包含一个ReviewerType为2的审核员。
			// - updateInfo: DeletePermReviewerType为nil，WritePermReviewerType指向2。
			// 逻辑链路：
			// 1. 遍历reviewers列表。
			// 2. 第一个if条件不满足，进入else if分支 `reviewer.ReviewerType == *updateInfo.WritePermReviewerType` 成立。
			// 3. permOP被赋值为_const.PermissionWrite。
			// 4. 创建一个filecli.User并添加到结果列表中。
			// 5. 返回包含一个用户的UpdateUserPermissionReq。
			reviewers := bizmodels.PreContractReviewerList{
				{
					ReviewerID:   "user2",
					Reviewer:     "user2@example.com",
					ReviewerType: 2,
				},
			}
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-456",
				DeletePermReviewerType: nil,
				WritePermReviewerType:  gptr.Of(2),
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 1)
			convey.So(req.Users[0].FileId, convey.ShouldEqual, "file-id-456")
			convey.So(req.Users[0].Uid, convey.ShouldEqual, "user2")
			convey.So(req.Users[0].Permission, convey.ShouldEqual, _const.PermissionWrite)
		})

		mockey.PatchConvey("正常场景-混合权限匹配", func() {
			// 场景描述：
			// 构造一个包含多个审核员的列表，分别匹配删除、写入权限，以及不匹配任何权限。
			// 构造数据：
			// - reviewers: 包含三个审核员，ReviewerType分别为1, 2, 3。
			// - updateInfo: DeletePermReviewerType指向1，WritePermReviewerType指向2。
			// 逻辑链路：
			// 1. 遍历reviewers列表。
			// 2. 第一个审核员匹配删除权限，添加一个delete权限用户。
			// 3. 第二个审核员匹配写入权限，添加一个write权限用户。
			// 4. 第三个审核员不匹配任何权限，跳过。
			// 5. 返回包含两个用户的UpdateUserPermissionReq。
			reviewers := bizmodels.PreContractReviewerList{
				{ReviewerID: "user-del", ReviewerType: 1},
				{ReviewerID: "user-write", ReviewerType: 2},
				{ReviewerID: "user-none", ReviewerType: 3},
			}
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-789",
				DeletePermReviewerType: gptr.Of(1),
				WritePermReviewerType:  gptr.Of(2),
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 2)

			userMap := make(map[string]*filecli.User)
			for _, u := range req.Users {
				userMap[u.Uid] = u
			}

			delUser, ok := userMap["user-del"]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(delUser.Permission, convey.ShouldEqual, _const.PermissionDelete)

			writeUser, ok := userMap["user-write"]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(writeUser.Permission, convey.ShouldEqual, _const.PermissionWrite)
		})

		mockey.PatchConvey("正常场景-无任何权限匹配", func() {
			// 场景描述：
			// 构造的审核员列表中的类型与updateInfo中指定的任何权限类型都不匹配。
			// 构造数据：
			// - reviewers: 包含一个ReviewerType为1的审核员。
			// - updateInfo: DeletePermReviewerType指向99，WritePermReviewerType指向100。
			// 逻辑链路：
			// 1. 遍历reviewers列表。
			// 2. if和else if条件均不满足。
			// 3. permOP为0，执行continue。
			// 4. 循环结束，返回一个空的users列表。
			reviewers := bizmodels.PreContractReviewerList{
				{
					ReviewerID:   "user1",
					Reviewer:     "user1@example.com",
					ReviewerType: 1,
				},
			}
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-123",
				DeletePermReviewerType: gptr.Of(99),
				WritePermReviewerType:  gptr.Of(100),
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 0)
		})

		mockey.PatchConvey("边界场景-updateInfo中的权限类型指针为nil", func() {
			// 场景描述：
			// updateInfo中的权限类型指针字段都为nil，不应匹配任何权限。
			// 构造数据：
			// - reviewers: 包含一个审核员。
			// - updateInfo: DeletePermReviewerType和WritePermReviewerType均为nil。
			// 逻辑链路：
			// 1. 遍历reviewers列表。
			// 2. 由于权限类型指针为nil，if和else if的短路逻辑使其条件为false。
			// 3. 执行continue。
			// 4. 返回一个空的users列表。
			reviewers := bizmodels.PreContractReviewerList{
				{
					ReviewerID:   "user1",
					Reviewer:     "user1@example.com",
					ReviewerType: 1,
				},
			}
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-123",
				DeletePermReviewerType: nil,
				WritePermReviewerType:  nil,
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 0)
		})

		mockey.PatchConvey("边界场景-reviewers列表为空", func() {
			// 场景描述：
			// 传入的审核员列表为空。
			// 构造数据：
			// - reviewers: 空列表。
			// - updateInfo: 任意有效值。
			// 逻辑链路：
			// 1. for循环不执行。
			// 2. 直接返回一个空的users列表。
			var reviewers bizmodels.PreContractReviewerList
			updateInfo := &filePermUpdateInfo{
				FileID:                 "file-id-123",
				DeletePermReviewerType: gptr.Of(1),
			}

			req := h.buildPermReq(reviewers, updateInfo)

			convey.So(req, convey.ShouldNotBeNil)
			convey.So(req.Users, convey.ShouldHaveLength, 0)
		})
	})
}

func Test_handlerCommon_fillTradePartyInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_fillTradePartyInfo", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("error scenarios", func() {

			mockey.PatchConvey("should return error when GetAccountAndVerifyListFromCache fails", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockErr := errors.New("cache error")
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(nil, mockErr).Build()
				mockey.Mock(i18nfmt.Errorf).Return(errors.New("变更报价单信息,查询报价单账号ID[123]失败")).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()

				manageInfo := &bizmodels.ManageInfo{QuoteAccountID: "123"}
				pc := &auditmodel.ProcessCtx{ContractInfo: &model.ContractMeta{}}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价单账号ID[123]失败")
			})

			mockey.PatchConvey("should return error when account id is not found in cache result", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(make(map[string]*accountcli.AccountAndVerifyInfo), nil).Build()
				mockey.Mock(i18nfmt.Errorf).Return(errors.New("变更报价单信息,查询报价单账号ID[123]不存在")).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{QuoteAccountID: "123"}
				pc := &auditmodel.ProcessCtx{ContractInfo: &model.ContractMeta{}}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "查询报价单账号ID[123]不存在")
			})

			mockey.PatchConvey("should return error when other party count mismatches in non-byteplus env", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A"},
					"201": {AccountID: 201, VerifyName: "Party B"},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(i18nfmt.Errorf).Return(errors.New("合同对方主体数量,与报价单关联账号实名认证主体不一致")).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{QuoteAccountID: "101,201"}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{PartyName: "Party A"},
							},
						},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同对方主体数量,与报价单关联账号实名认证主体不一致")
			})

			mockey.PatchConvey("should return error when other party name is not in quote accounts in non-byteplus env", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A"},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(i18nfmt.Errorf).Return(errors.New("合同对方主体[Party C],不在报价单关联账号实名认证主体内")).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{QuoteAccountID: "101"}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{PartyName: "Party C"},
							},
						},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(result, convey.ShouldBeNil)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同对方主体[Party C],不在报价单关联账号实名认证主体内")
			})
		})

		mockey.PatchConvey("success scenarios", func() {
			mockey.PatchConvey("should fill empty OtherParty from scratch in non-byteplus env", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A", CreateSource: 1},
					"102": {AccountID: 102, VerifyName: "Party A", CreateSource: 2},
					"103": {AccountID: 103, VerifyName: "Party A", CreateSource: 1},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{
					QuoteAccountID:   "103",
					SealAccountID:    "101,103",
					PricingAccountID: "102",
					EndUser:          "End User Name",
					EndUserAccountID: "999",
				}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: nil,
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{PartnerName: "Test Partner"}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldNotBeNil)
				convey.So(len(result.OtherParty), convey.ShouldEqual, 1)

				party := result.OtherParty[0]
				convey.So(party.PartyName, convey.ShouldEqual, "Party A")
				convey.So(party.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(party.Pricing, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(result.RelatePartner, convey.ShouldEqual, "Test Partner")
				convey.So(result.EndUser, convey.ShouldEqual, "End User Name")
				convey.So(result.EndUserAccountID, convey.ShouldEqual, "999")

				ids := strings.Split(party.AccountID, ",")
				sort.Strings(ids)
				convey.So(ids, convey.ShouldResemble, []string{"101", "102", "103"})

				sealIDs := strings.Split(party.SealAccountID, ",")
				sort.Strings(sealIDs)
				convey.So(sealIDs, convey.ShouldResemble, []string{"101", "103"})

				pricingIDs := strings.Split(party.PricingAccountID, ",")
				sort.Strings(pricingIDs)
				convey.So(pricingIDs, convey.ShouldResemble, []string{"102"})

				sources := strings.Split(party.CreateSource, ",")
				sort.Strings(sources)
				convey.So(sources, convey.ShouldResemble, []string{"1", "1", "2"})
			})

			mockey.PatchConvey("同时包含主副签约主体", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A", CreateSource: 1},
					"102": {AccountID: 102, VerifyName: "Party A", CreateSource: 2},
					"103": {AccountID: 103, VerifyName: "Party A", CreateSource: 1},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()

				manageInfo := &bizmodels.ManageInfo{
					QuoteAccountID:   "103",
					SealAccountID:    "101,103",
					PricingAccountID: "102",
					EndUser:          "End User Name",
					EndUserAccountID: "999",
				}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{{DeputyParty: 0, PartyName: "Party A"}, {DeputyParty: 1}}},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{PartnerName: "Test Partner"}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldNotBeNil)
				convey.So(len(result.OtherParty), convey.ShouldEqual, 2)

				party := result.OtherParty[0]
				convey.So(party.PartyName, convey.ShouldEqual, "Party A")
				convey.So(party.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(party.Pricing, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(result.RelatePartner, convey.ShouldEqual, "Test Partner")
				convey.So(result.EndUser, convey.ShouldEqual, "End User Name")
				convey.So(result.EndUserAccountID, convey.ShouldEqual, "999")

				ids := strings.Split(party.AccountID, ",")
				sort.Strings(ids)
				convey.So(ids, convey.ShouldResemble, []string{"101", "102", "103"})

				sealIDs := strings.Split(party.SealAccountID, ",")
				sort.Strings(sealIDs)
				convey.So(sealIDs, convey.ShouldResemble, []string{"101", "103"})

				pricingIDs := strings.Split(party.PricingAccountID, ",")
				sort.Strings(pricingIDs)
				convey.So(pricingIDs, convey.ShouldResemble, []string{"102"})

				sources := strings.Split(party.CreateSource, ",")
				sort.Strings(sources)
				convey.So(sources, convey.ShouldResemble, []string{"1", "1", "2"})
			})

			mockey.PatchConvey("BP分销特殊报价主对方主体账号使用一级分销商账号", func() {
				relateInfo := map[string]map[string][]string{
					_const.RelateAccountTypeFirstTierDistributor: {"First Distributor": {"301"}},
					_const.RelateAccountTypeSecondaryDistributor: {"Second Distributor": {"302"}},
					_const.RelateAccountTypeEndUser:              {"End User": {"303"}},
				}
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(relateInfo, nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A", CreateSource: 1},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()

				manageInfo := &bizmodels.ManageInfo{
					QuoteAccountID:        "101",
					DistributBusinessType: _const.DistributBusinessTypeSpecial,
				}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						ContractNo: "CT-BP-001",
						BasicInfo: &bizmodels.BasicInfo{
							BusinessType: _const.BusinessTypeBPDistribution,
						},
						TradePartyInfo: &bizmodels.TradePartyInfo{OtherParty: []*bizmodels.TradePartyInfoDetail{
							{DeputyParty: _const.FALSE_FLAG_INT, PartyName: "Party A", AccountID: "101"},
							{DeputyParty: _const.TRUE_FLAG_INT, PartyName: "Deputy Party", AccountID: "KEEP"},
						}},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{PartnerName: "Test Partner"}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldNotBeNil)
				convey.So(result.OtherParty[0].AccountID, convey.ShouldEqual, "301")
				convey.So(result.OtherParty[0].RelateAccountInfo, convey.ShouldResemble, relateInfo)
				convey.So(result.OtherParty[1].AccountID, convey.ShouldEqual, "KEEP")
			})

			mockey.PatchConvey("should update existing OtherParty in non-byteplus env", func() {
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(make(map[string]map[string][]string), nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"101": {AccountID: 101, VerifyName: "Party A", CreateSource: 1},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{QuoteAccountID: "101", SealAccountID: "101"}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{PartyName: "Party A"},
							},
						},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldNotBeNil)
				convey.So(len(result.OtherParty), convey.ShouldEqual, 1)

				party := result.OtherParty[0]
				convey.So(party.PartyName, convey.ShouldEqual, "Party A")
				convey.So(party.AccountID, convey.ShouldEqual, "101")
				convey.So(party.SealAccountID, convey.ShouldEqual, "101")
				convey.So(party.PricingAccountID, convey.ShouldEqual, "")
				convey.So(party.CreateSource, convey.ShouldEqual, "1")
				convey.So(party.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(party.Pricing, convey.ShouldEqual, _const.FALSE_FLAG_INT)
			})

			mockey.PatchConvey("should fill OtherParty and apply byteplus logic in byteplus env", func() {
				relateInfo := map[string]map[string][]string{
					_const.RelateAccountTypeEndUser: {"BP End User": {"888"}},
				}
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(relateInfo, nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(true).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"201": {AccountID: 201, VerifyName: "BP Party"},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, nil).Build()
				manageInfo := &bizmodels.ManageInfo{
					QuoteAccountID:   "201",
					EndUser:          "Old End User",
					EndUserAccountID: "999",
				}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldNotBeNil)
				convey.So(len(result.OtherParty), convey.ShouldEqual, 1)

				party := result.OtherParty[0]
				convey.So(party.PartyName, convey.ShouldEqual, "BP Party")
				convey.So(party.AccountID, convey.ShouldEqual, "201")
				convey.So(party.RelateAccountInfo, convey.ShouldResemble, relateInfo)
				convey.So(party.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(party.Pricing, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(party.SealAccountID, convey.ShouldEqual, "201")
				convey.So(party.PricingAccountID, convey.ShouldEqual, "201")

				endUsers := strings.Split(result.EndUser, ",")
				sort.Strings(endUsers)
				convey.So(endUsers, convey.ShouldResemble, []string{"BP End User", "Old End User"})

				endUserIDs := strings.Split(result.EndUserAccountID, ",")
				sort.Strings(endUserIDs)
				convey.So(endUserIDs, convey.ShouldResemble, []string{"888", "999"})
			})
			mockey.PatchConvey("mdm error", func() {
				relateInfo := map[string]map[string][]string{
					_const.RelateAccountTypeEndUser: {"BP End User": {"888"}},
				}
				mockey.Mock((*bizmodels.QuoteBizInfo).ParseRelateAccountInfo).Return(relateInfo, nil).Build()
				mockey.Mock(multienv.IsBytePlus).Return(true).Build()
				accountList := map[string]*accountcli.AccountAndVerifyInfo{
					"201": {AccountID: 201, VerifyName: "BP Party"},
				}
				mockey.Mock(accountcli.GetAccountAndVerifyListFromCache).Return(accountList, nil).Build()
				mockey.Mock(mdparty.GetMdmCodeByName).Return(&mdcli.QueryTPMDData{}, errors.New("mdm error")).Build()
				manageInfo := &bizmodels.ManageInfo{
					QuoteAccountID:   "201",
					EndUser:          "Old End User",
					EndUserAccountID: "999",
				}
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						TradePartyInfo: &bizmodels.TradePartyInfo{},
					},
				}
				bizInfo := &bizmodels.QuoteBizInfo{}

				result, err := h.fillTradePartyInfo(ctx, manageInfo, pc, bizInfo)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(result, convey.ShouldBeNil)
			})
		})
	})
}

func Test_updateTemplateFilePermission_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test func updateTemplateFilePermission", t, func() {
		// Common data setup
		ctx := context.Background()
		fileId := "test-file-id-123"
		pc := &auditmodel.ProcessCtx{
			CurrentOperator: "test.user@example.com",
		}
		employee := &peopleclient.Employee{
			ID:        123,
			Name:      "Test User",
			Email:     "test.user@example.com",
			AvatarURL: "http://avatar.url/test.png",
		}

		mockey.PatchConvey("success case", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 ProcessCtx 和 fileId。
			// 逻辑链路：
			// 1. Mock larkc.GetEmployeeByEmailWithCache 成功返回一个有效的 employee。
			// 2. Mock filecli.ClearFilePermission 成功清空权限，返回 nil。
			// 3. Mock filecli.UpdateUserPermission 成功更新用户权限，返回 nil。
			// 4. 函数最终返回 nil。

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(employee, nil).Build()
			mockey.Mock(filecli.ClearFilePermission).Return(nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()

			err := updateTemplateFilePermission(ctx, fileId, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("fail case: GetEmployeeByEmailWithCache returns error", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 ProcessCtx 和 fileId。
			// 逻辑链路：
			// 1. Mock larkc.GetEmployeeByEmailWithCache 调用失败，返回一个 error。
			// 2. 函数提前返回，并将错误向上传递。

			mockErr := errors.New("get employee failed")
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, mockErr).Build()

			err := updateTemplateFilePermission(ctx, fileId, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "get employee failed")
		})

		mockey.PatchConvey("fail case: GetEmployeeByEmailWithCache returns nil employee", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 ProcessCtx 和 fileId。
			// 逻辑链路：
			// 1. Mock larkc.GetEmployeeByEmailWithCache 调用成功，但返回的 employee 为 nil。
			// 2. 函数判断 employee 为 nil，返回一个 "employee is nil" 错误。

			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, nil).Build()

			err := updateTemplateFilePermission(ctx, fileId, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "employee is nil")
		})

		mockey.PatchConvey("fail case: ClearFilePermission returns error", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 ProcessCtx 和 fileId。
			// 逻辑链路：
			// 1. Mock larkc.GetEmployeeByEmailWithCache 成功返回一个有效的 employee。
			// 2. Mock filecli.ClearFilePermission 调用失败，返回一个 error。
			// 3. 函数提前返回，并将错误向上传递。

			mockErr := errors.New("clear permission failed")
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(employee, nil).Build()
			mockey.Mock(filecli.ClearFilePermission).Return(mockErr).Build()

			err := updateTemplateFilePermission(ctx, fileId, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "clear permission failed")
		})

		mockey.PatchConvey("fail case: UpdateUserPermission returns error", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 ProcessCtx 和 fileId。
			// 逻辑链路：
			// 1. Mock larkc.GetEmployeeByEmailWithCache 成功返回一个有效的 employee。
			// 2. Mock filecli.ClearFilePermission 成功清空权限，返回 nil。
			// 3. Mock filecli.UpdateUserPermission 调用失败，返回一个 error。
			// 4. 函数返回错误。

			mockErr := errors.New("update permission failed")
			mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(employee, nil).Build()
			mockey.Mock(filecli.ClearFilePermission).Return(nil).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(mockErr).Build()

			err := updateTemplateFilePermission(ctx, fileId, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update permission failed")
		})
	})
}

func Test_validateTermChangeDetail_BitsUTGen(t *testing.T) {
	// MockContractMetaExtDao is a mock type for the ContractMetaExtDao interface.
	type MockContractMetaExtDao struct {
		dal.ContractMetaExtDao
	}

	mockey.PatchConvey("Test validateTermChangeDetail", t, func() {
		ctx := context.Background()
		tx := &gorm.DB{}

		mockey.PatchConvey("场景：合同非补充协议（SupplySource为空），应直接返回nil", func() {
			// 场景描述：
			// 构造数据：contractVO.SupplySource 为空字符串。
			// 逻辑链路：
			// 1. 函数进入，第一个if条件 `len(contractVO.SupplySource) == 0` 为true。
			// 2. 函数直接返回nil，表示校验通过。
			contractVO := &model.ContractMetaDB{
				SupplySource: "",
			}

			err := validateTermChangeDetail(ctx, tx, contractVO)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：合同为补充协议，但补充场景不包含条款变更，应直接返回nil", func() {
			// 场景描述：
			// 构造数据：contractVO.SupplySource 不为空，但不包含"条款变更"场景。
			// 逻辑链路：
			// 1. 函数进入，第一个if条件为false。
			// 2. 第二个if条件 `!utils.StringIn(_const.SupplySourceTermChange, contractVO.GetSupplySource())` 为true。
			// 3. 函数直接返回nil，表示校验通过。
			contractVO := &model.ContractMetaDB{
				SupplySource: "1,2", // 假设"1"和"2"是其他场景
			}

			err := validateTermChangeDetail(ctx, tx, contractVO)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：合同为补充协议且补充场景包含条款变更", func() {
			// 为该分组下的所有测试场景准备通用数据和Mock
			contractVO := &model.ContractMetaDB{
				BaseDB:       model.BaseDB{Id: 1},
				SupplySource: _const.SupplySourceTermChange,
			}
			mockey.Mock(dal.NewContractMetaExtDao).Return(&MockContractMetaExtDao{}).Build()

			mockey.PatchConvey("子场景：查询条款变更详情时数据库出错，应返回错误", func() {
				// 场景描述：
				// 构造数据：contractVO.SupplySource 包含 "条款变更" 场景。
				// 逻辑链路：
				// 1. 前两个if条件均为false。
				// 2. Mock dal.NewContractMetaExtDao().FindByAttrKey() 返回一个数据库错误。
				// 3. 函数捕获错误，并返回一个包装后的通用错误。
				mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, errors.New("db query failed")).Build()

				err := validateTermChangeDetail(ctx, tx, contractVO)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrCommon)
				convey.So(err.Error(), convey.ShouldContainSubstring, "FindMetaExtByAttrKeyFail")
			})

			mockey.PatchConvey("子场景：条款变更详情记录不存在（extDB为nil），应返回错误提示必填", func() {
				// 场景描述：
				// 构造数据：contractVO.SupplySource 包含 "条款变更" 场景。
				// 逻辑链路：
				// 1. 前两个if条件均为false。
				// 2. Mock dal.NewContractMetaExtDao().FindByAttrKey() 返回 (nil, nil)，表示没有找到记录。
				// 3. 第三个if条件 `extDB == nil` 为true。
				// 4. 函数返回内部错误，提示条款变更详情必填。
				mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()

				err := validateTermChangeDetail(ctx, tx, contractVO)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrInternalError)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同补充场景包含条款变更，条款变更详情必填。")
			})

			mockey.PatchConvey("子场景：条款变更详情记录存在但内容为空，应返回错误提示必填", func() {
				// 场景描述：
				// 构造数据：contractVO.SupplySource 包含 "条款变更" 场景。
				// 逻辑链路：
				// 1. 前两个if条件均为false。
				// 2. Mock dal.NewContractMetaExtDao().FindByAttrKey() 返回一个 AttrValue 为空的记录。
				// 3. 第三个if条件 `len(extDB.AttrValue) == 0` 为true。
				// 4. 函数返回内部错误，提示条款变更详情必填。
				extDB := &model.ContractMetaExt{
					AttrValue: "",
				}
				mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(extDB, nil).Build()

				err := validateTermChangeDetail(ctx, tx, contractVO)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldHaveSameTypeAs, errorsV2.ErrInternalError)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同补充场景包含条款变更，条款变更详情必填。")
			})

			mockey.PatchConvey("子场景：条款变更详情存在且不为空，校验通过，应返回nil", func() {
				// 场景描述：
				// 构造数据：contractVO.SupplySource 包含 "条款变更" 场景。
				// 逻辑链路：
				// 1. 前两个if条件均为false。
				// 2. Mock dal.NewContractMetaExtDao().FindByAttrKey() 返回一个有效的、AttrValue不为空的记录。
				// 3. 第三个if条件为false。
				// 4. 函数执行完毕，返回nil，表示校验成功。
				extDB := &model.ContractMetaExt{
					AttrValue: "some change detail",
				}
				mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(extDB, nil).Build()

				err := validateTermChangeDetail(ctx, tx, contractVO)

				convey.So(err, convey.ShouldBeNil)
			})
		})
	})
}

func TestGetCommodityRepeatMsgMap_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetCommodityRepeatMsgMap", t, func() {
		// Mock external dependencies.
		// The only external dependency in the tested code path is multienv.I18nFormat.
		// Mock it to return the input key, so we can predictably check the output string.
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v
		}).Build()

		ctx := context.Background()
		quoteNo := "QN-2023-001"

		mockey.PatchConvey("场景：输入c.CommodityRepeatInfo为nil", func() {
			// 场景描述：
			// 构造数据：输入参数 c 不为 nil, 但 c.CommodityRepeatInfo 为 nil.
			// 逻辑链路：
			// 1. 函数中的第一个 for-range 循环不会执行.
			// 2. 函数将返回一个空的 map.
			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: nil,
			}
			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景：输入c.CommodityRepeatInfo为空map", func() {
			// 场景描述：
			// 构造数据：c.CommodityRepeatInfo 是一个空的 map.
			// 逻辑链路：
			// 1. 函数中的第一个 for-range 循环不会执行.
			// 2. 函数将返回一个空的 map.
			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: map[string][]*bizmodels.ContractDiscountGroup{},
			}
			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景：单个账号，单个合同，多个重复项", func() {
			// 场景描述：
			// 构造数据：一个账号下有两个重复项，都对应同一个历史合同。
			// 逻辑链路：
			// 1. 函数遍历找到两个重复项.
			// 2. 将两个重复项都归到同一个合同号和账号ID下.
			// 3. 调用 GenRepeatProductMsg 一次，传入包含两个重复项的列表.
			// 4. 返回的 map 中，对应的消息字符串会包含两条记录.
			discount1 := &bizmodels.ContractDiscount{
				ContractNo: "CN-2022-001",
				Product:    "ProductA",
				PayType:    "PostPaid",
			}
			discount2 := &bizmodels.ContractDiscount{
				ContractNo: "CN-2022-001",
				Product:    "ProductB",
				PayType:    "PrePaid",
			}

			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: map[string][]*bizmodels.ContractDiscountGroup{
					"account_id_1": {
						// FIX: Split into two separate groups.
						// Each group represents a distinct duplicate finding.
						// The target function should aggregate these correctly.
						{
							PreviousList: []*bizmodels.ContractDiscount{discount1},
						},
						{
							PreviousList: []*bizmodels.ContractDiscount{discount2},
						},
					},
				},
			}

			expectedMsg := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[ProductA],付费方式为[PostPaid],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； 2: 商品[ProductB],付费方式为[PrePaid],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			expected := map[string]map[string]string{
				"CN-2022-001": {
					"account_id_1": expectedMsg,
				},
			}

			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(reflect.DeepEqual(result, expected), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：多个账号，多个合同，复杂场景", func() {
			// 场景描述：
			// 构造数据：两个账号，两个历史合同，重复项分布在不同账号和合同中.
			// 逻辑链路：
			// 1. 函数正确地将所有重复项分组到对应的合同号和账号ID下.
			// 2. 多次调用 GenRepeatProductMsg 生成不同的消息.
			// 3. 返回的 map 包含多个合同号，每个合同号下可能包含多个账号.
			discount_acc1_c1 := &bizmodels.ContractDiscount{ContractNo: "CN-001", Product: "P_A1_C1"}
			discount_acc1_c2 := &bizmodels.ContractDiscount{ContractNo: "CN-002", Product: "P_A1_C2"}
			discount_acc2_c1 := &bizmodels.ContractDiscount{ContractNo: "CN-001", Product: "P_A2_C1"}

			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: map[string][]*bizmodels.ContractDiscountGroup{
					"account_id_1": {
						{PreviousList: []*bizmodels.ContractDiscount{discount_acc1_c1, discount_acc1_c2}},
					},
					"account_id_2": {
						{PreviousList: []*bizmodels.ContractDiscount{discount_acc2_c1}},
					},
				},
			}

			msg_a1_c1 := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[P_A1_C1],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			msg_a1_c2 := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[P_A1_C2],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			msg_a2_c1 := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[P_A2_C1],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `

			expected := map[string]map[string]string{
				"CN-001": {
					"account_id_1": msg_a1_c1,
					"account_id_2": msg_a2_c1,
				},
				"CN-002": {
					"account_id_1": msg_a1_c2,
				},
			}

			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(reflect.DeepEqual(result, expected), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：重复项包含排除项信息", func() {
			// 场景描述：
			// 构造数据：一个重复项，其部分字段包含排除信息，测试逗号被替换为顿号。
			// 逻辑链路：
			// 1. 函数调用 GenRepeatProductMsg, 后者调用 BuildConfigurationSummaryDesc.
			// 2. BuildConfigurationSummaryDesc 会将排除信息拼接到描述中.
			// 3. 返回的消息字符串中应包含 "（不包含 ...）" 的文本.
			discount := &bizmodels.ContractDiscount{
				ContractNo:                       "CN-2022-001",
				Product:                          "ProductA",
				ConfigurationCategory:            "CategoryA",
				ConfigurationCategoryExcludeName: "ExcludeCategory",
				Configuration:                    "ConfigA",
				ConfigurationExcludeName:         "ExcludeConfig,OtherExclude",
				RegionCode:                       "cn-beijing",
				RegionExcludeName:                "ExcludeRegion",
			}

			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: map[string][]*bizmodels.ContractDiscountGroup{
					"account_id_1": {{PreviousList: []*bizmodels.ContractDiscount{discount}}},
				},
			}

			expectedMsg := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[ProductA],付费方式为[],配置分类为[CategoryA（不包含 ExcludeCategory）],配置[ConfigA（不包含 ExcludeConfig、OtherExclude）],计费项分类[],计费方式[],地域[cn-beijing（不包含 ExcludeRegion）],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			expected := map[string]map[string]string{
				"CN-2022-001": {
					"account_id_1": expectedMsg,
				},
			}

			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(reflect.DeepEqual(result, expected), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：重复项包含特殊字符", func() {
			// 场景描述：
			// 构造数据：一个重复项的字段包含需要转义的特殊字符（如 \ 和 "）。
			// 逻辑链路：
			// 1. 函数调用 GenRepeatProductMsg.
			// 2. GenRepeatProductMsg 内部会对 \ 和 "进行转义.
			// 3. 返回的消息字符串中应包含转义后的字符.
			discount := &bizmodels.ContractDiscount{
				ContractNo: "CN-2022-001",
				Product:    `Product"A\B"`,
			}

			c := &modelcommodity.CheckQuoteItemRepeatData{
				CommodityRepeatInfo: map[string][]*bizmodels.ContractDiscountGroup{
					"account_id_1": {{PreviousList: []*bizmodels.ContractDiscount{discount}}},
				},
			}

			expectedMsg := `报价单[QN-2023-001]存在如下重复报价项：1: 商品[Product\"A\\B\"],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			expected := map[string]map[string]string{
				"CN-2022-001": {
					"account_id_1": expectedMsg,
				},
			}

			result := GetCommodityRepeatMsgMap(ctx, c, quoteNo)
			convey.So(reflect.DeepEqual(result, expected), convey.ShouldBeTrue)
		})
	})
}

func Test_handlerCommon_getUnReviewedReviewerWithContractStatusAndBelowPriority_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getUnReviewedReviewerWithContractStatusAndBelowPriority", t, func() {
		h := &handlerCommon{}

		mockey.PatchConvey("场景一: 正常情况, 存在多个符合条件的审核人, 返回最高优先级的审核人列表", func() {
			// 场景描述:
			// 构造数据: 构造一个审核人列表, 其中包含不同优先级、不同状态的审核人, 部分符合筛选条件.
			// 逻辑链路:
			// 1. 函数接收审核人列表、审核人类型1、合同状态10.
			// 2. 遍历列表, 筛选出类型为1、合同状态为10且审核状态不为“通过”的审核人.
			// 3. 符合条件的审核人有: priority=1(reviewer_low), priority=2(reviewer_high_1), priority=2(reviewer_high_2).
			// 4. 函数识别出最高优先级为2.
			// 5. 返回优先级为2的所有审核人: ["reviewer_high_1", "reviewer_high_2"].
			list := bizmodels.PreContractReviewerList{
				// 不符合条件: 状态为通过
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_passed", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusReviewPass, Priority: 3},
				// 不符合条件: ReviewerType不匹配
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_wrong_type", ReviewerType: 2, ContractStatus: 10, Status: _const.ReviewStatusUnreviewed, Priority: 3},
				// 不符合条件: ContractStatus不匹配
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_wrong_status", ReviewerType: 1, ContractStatus: 11, Status: _const.ReviewStatusUnreviewed, Priority: 3},
				// 符合条件: 低优先级
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_low", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusUnreviewed, Priority: 1},
				// 符合条件: 高优先级
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_high_1", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusUnreviewed, Priority: 2},
				// 符合条件: 高优先级, 状态为退回(也属于未通过)
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_high_2", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusReviewSendBack, Priority: 2},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getUnReviewedReviewerWithContractStatusAndBelowPriority(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, []string{"reviewer_high_1", "reviewer_high_2"})
		})

		mockey.PatchConvey("场景二: 输入的审核人列表为空", func() {
			// 场景描述:
			// 构造数据: 传入一个nil的审核人列表.
			// 逻辑链路:
			// 1. 函数接收到nil列表.
			// 2. for循环不执行.
			// 3. resPriority保持初始值0.
			// 4. 函数返回reviewerMap[0], 即nil.
			var list bizmodels.PreContractReviewerList
			reviewerType := 1
			contractStatus := 10

			result := h.getUnReviewedReviewerWithContractStatusAndBelowPriority(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景三: 列表中没有符合条件的审核人", func() {
			// 场景描述:
			// 构造数据: 列表中的审核人均不符合筛选条件.
			// 逻辑链路:
			// 1. 函数遍历列表, 但if条件始终为false.
			// 2. 循环结束后, reviewerMap为空, resPriority为0.
			// 3. 函数返回reviewerMap[0], 即nil.
			list := bizmodels.PreContractReviewerList{
				// 不符合条件: 状态为通过
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_passed", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusReviewPass, Priority: 1},
				// 不符合条件: ReviewerType不匹配
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_wrong_type", ReviewerType: 2, ContractStatus: 10, Status: _const.ReviewStatusUnreviewed, Priority: 1},
				// 不符合条件: ContractStatus不匹配
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_wrong_status", ReviewerType: 1, ContractStatus: 11, Status: _const.ReviewStatusUnreviewed, Priority: 1},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getUnReviewedReviewerWithContractStatusAndBelowPriority(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景四: 唯一符合条件的审核人优先级为0", func() {
			// 场景描述:
			// 构造数据: 列表中只有一个符合条件的审核人, 其优先级为0.
			// 逻辑链路:
			// 1. 函数筛选出该审核人.
			// 2. resPriority初始值为0, `reviewer.Priority > resPriority` (0 > 0)为false, resPriority保持为0.
			// 3. 该审核人被添加到reviewerMap[0]中.
			// 4. 函数返回reviewerMap[resPriority], 即reviewerMap[0]的内容.
			list := bizmodels.PreContractReviewerList{
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_prio_0", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusUnreviewed, Priority: 0},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getUnReviewedReviewerWithContractStatusAndBelowPriority(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, []string{"reviewer_prio_0"})
		})

		mockey.PatchConvey("场景五: 所有符合类型和状态的审核人都已审核通过", func() {
			// 场景描述:
			// 构造数据: 列表中的审核人符合类型和合同节点, 但审核状态均为“通过”.
			// 逻辑链路:
			// 1. 函数遍历列表, 但 `reviewer.Status != _const.ReviewStatusReviewPass` 条件始终为false.
			// 2. 循环结束后, reviewerMap为空, resPriority为0.
			// 3. 函数返回reviewerMap[0], 即nil.
			list := bizmodels.PreContractReviewerList{
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_passed_1", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusReviewPass, Priority: 1},
				&bizmodels.PreContractReviewer{Reviewer: "reviewer_passed_2", ReviewerType: 1, ContractStatus: 10, Status: _const.ReviewStatusReviewPass, Priority: 2},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getUnReviewedReviewerWithContractStatusAndBelowPriority(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_CreateOrUpdateAttachment_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.CreateOrUpdateAttachment", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		contractNo := "test-contract-123"
		fileID := "test-file-id-456"

		mockey.PatchConvey("should return error when FindByFileKey fails", func() {

			findErr := errors.New("db find error")
			mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
			mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, findErr).Build()

			err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, findErr.Error())
		})

		mockey.PatchConvey("Create path: when attachment is not found (nil)", func() {
			mockey.PatchConvey("should create successfully with default file name when GetNewestVersion fails", func() {

				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(nil, errors.New("file service error")).Build()
				mockey.Mock((*MockContractAttachmentDao).Create).Return(nil).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should create successfully with new file name when GetNewestVersion succeeds", func() {

				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{Name: "NewContract.pdf"},
				}, nil).Build()
				mockey.Mock((*MockContractAttachmentDao).Create).Return(nil).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should return error when Create fails", func() {

				createErr := errors.New("db create error")
				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(nil, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{Name: "NewContract.pdf"},
				}, nil).Build()
				mockey.Mock((*MockContractAttachmentDao).Create).Return(createErr).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, createErr.Error())
			})
		})

		mockey.PatchConvey("Update path: when attachment exists", func() {
			existingAttachment := &model.ContractAttachmentDB{
				ContractNo: "old-contract-no",
				FileKey:    fileID,
				Name:       "OldName.pdf",
			}

			mockey.PatchConvey("should update successfully with default file name when GetNewestVersion fails", func() {

				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(existingAttachment, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(nil, nil).Build()
				mockey.Mock((*MockContractAttachmentDao).Update).Return(nil).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should update successfully with new file name when GetNewestVersion succeeds", func() {

				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(existingAttachment, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{Name: "UpdatedContract.pdf"},
				}, nil).Build()
				mockey.Mock((*MockContractAttachmentDao).Update).Return(nil).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should return error when Update fails", func() {

				updateErr := errors.New("db update error")
				mockey.Mock(dal.NewContractAttachmentDao).Return(&MockContractAttachmentDao{}).Build()
				mockey.Mock((*MockContractAttachmentDao).FindByFileKey).Return(existingAttachment, nil).Build()
				mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{Name: "UpdatedContract.pdf"},
				}, nil).Build()
				mockey.Mock((*MockContractAttachmentDao).Update).Return(updateErr).Build()

				err := h.CreateOrUpdateAttachment(ctx, tx, contractNo, fileID)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, updateErr.Error())
			})
		})
	})
}

func Test_handlerCommon_GetStatusOpConfKey_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_GetStatusOpConfKey", t, func() {
		mockey.PatchConvey("正常情况, 总是返回默认值", func() {
			// 场景描述：
			// 验证 GetStatusOpConfKey 函数总是返回预定义的默认常量。
			// 构造数据：
			// - h: 一个空的 handlerCommon 实例。
			// - ctx: 一个背景 context。
			// - pc: 一个空的 ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 GetStatusOpConfKey 方法。
			// 2. 断言返回值等于 _const.ApprovalStatusKeyDefault。
			h := &handlerCommon{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			result := h.GetStatusOpConfKey(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})
	})
}

func Test_handlerCommon_updateAttachment_BitsUTGen(t *testing.T) {
	// MockContractAttachmentDao is a mock type for dal.ContractAttachmentDao interface.
	type MockContractAttachmentDao struct {
		dal.ContractAttachmentDao
	}

	mockey.PatchConvey("Test_handlerCommon_updateAttachment", t, func() {
		// Initialize common variables for all test cases.
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		contractNo := "test-contract-no-12345"

		mockey.PatchConvey("成功场景: 附件列表不为空，且数据库更新成功", func() {
			// 场景描述：
			// 构造数据：构造一个包含两个附件的更新列表。
			// 逻辑链路：
			// 1. Mock dal.NewContractAttachmentDao 返回一个自定义的 mock DAO 实例。
			// 2. Mock (*MockContractAttachmentDao).UpdateByFileKey 方法，使其在每次调用时都返回 nil（表示成功）。
			// 3. 函数遍历附件列表，对每个附件调用 UpdateByFileKey。
			// 4. 由于所有数据库操作都成功，函数最终返回 nil。
			attachmentUpdateList := []*bizmodels.MetaAttachment{
				{
					Type:       "Contract",
					FileName:   "contract.pdf",
					DownloadID: "file-key-1",
				},
				{
					Type:       "Appendix",
					FileName:   "appendix.docx",
					DownloadID: "file-key-2",
				},
			}
			mockDao := &MockContractAttachmentDao{}

			mockey.Mock(dal.NewContractAttachmentDao).Return(mockDao).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(nil).Build()

			err := h.updateAttachment(ctx, tx, contractNo, attachmentUpdateList)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: 数据库更新失败", func() {
			// 场景描述：
			// 构造数据：构造一个包含一个附件的更新列表。
			// 逻辑链路：
			// 1. Mock dal.NewContractAttachmentDao 返回一个自定义的 mock DAO 实例。
			// 2. Mock (*MockContractAttachmentDao).UpdateByFileKey 方法，使其返回一个指定的错误。
			// 3. 函数在处理第一个附件时调用 UpdateByFileKey，接收到错误。
			// 4. 函数立即将此错误返回，停止进一步处理。
			attachmentUpdateList := []*bizmodels.MetaAttachment{
				{
					Type:       "Contract",
					FileName:   "contract.pdf",
					DownloadID: "file-key-fail",
				},
			}
			dbErr := errors.New("database update error")
			mockDao := &MockContractAttachmentDao{}

			mockey.Mock(dal.NewContractAttachmentDao).Return(mockDao).Build()
			mockey.Mock((*MockContractAttachmentDao).UpdateByFileKey).Return(dbErr).Build()

			err := h.updateAttachment(ctx, tx, contractNo, attachmentUpdateList)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})

		mockey.PatchConvey("边界场景: 附件更新列表为空", func() {
			// 场景描述：
			// 构造数据：传入一个空的附件更新列表。
			// 逻辑链路：
			// 1. 函数接收到空的附件列表。
			// 2. for 循环不会执行。
			// 3. 函数直接返回 nil。
			// 4. 此场景下不需要 Mock 任何依赖。
			var attachmentUpdateList []*bizmodels.MetaAttachment // nil slice

			err := h.updateAttachment(ctx, tx, contractNo, attachmentUpdateList)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界场景: 附件更新列表不为nil但长度为0", func() {
			// 场景描述：
			// 构造数据：传入一个长度为 0 的附件更新列表。
			// 逻辑链路：
			// 1. 函数接收到长度为 0 的附件列表。
			// 2. for 循环不会执行。
			// 3. 函数直接返回 nil。
			// 4. 此场景下不需要 Mock 任何依赖。
			attachmentUpdateList := make([]*bizmodels.MetaAttachment, 0)

			err := h.updateAttachment(ctx, tx, contractNo, attachmentUpdateList)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_getReviewerFromPreContractReviewerList_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getReviewerFromPreContractReviewerList", t, func() {
		// 构造一个 handlerCommon 实例
		h := &handlerCommon{}

		mockey.PatchConvey("正常情况：列表中包含匹配类型、不匹配类型和重复的审核人", func() {
			// 场景描述：
			// 构造数据：创建一个包含多种审核人类型的列表，其中目标类型的审核人存在重复。
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 筛选出 ReviewerType 匹配的审核人。
			// 3. 对筛选出的审核人进行去重。
			// 4. 返回去重后的审核人列表。
			list := bizmodels.PreContractReviewerList{
				&bizmodels.PreContractReviewer{Reviewer: "user1", ReviewerType: 1},
				&bizmodels.PreContractReviewer{Reviewer: "user2", ReviewerType: 2},
				&bizmodels.PreContractReviewer{Reviewer: "user3", ReviewerType: 1},
				&bizmodels.PreContractReviewer{Reviewer: "user1", ReviewerType: 1}, // 重复的 user1
			}
			reviewerType := 1
			expected := []string{"user1", "user3"}

			// 调用目标函数
			result := h.getReviewerFromPreContractReviewerList(list, reviewerType)

			// 断言结果
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("边界情况：输入列表为空", func() {
			// 场景描述：
			// 构造数据：传入一个空的审核人列表。
			// 逻辑链路：
			// 1. 函数接收到空列表。
			// 2. for 循环不执行。
			// 3. 返回一个空的字符串切片。
			var list bizmodels.PreContractReviewerList
			reviewerType := 1
			expected := []string{}

			// 调用目标函数
			result := h.getReviewerFromPreContractReviewerList(list, reviewerType)

			// 断言结果
			convey.So(result, convey.ShouldResemble, expected)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("边界情况：列表中没有匹配类型的审核人", func() {
			// 场景描述：
			// 构造数据：创建一个不包含目标审核人类型的列表。
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 循环中的 if reviewer.ReviewerType == reviewerType 条件始终为 false。
			// 3. 没有审核人被添加到结果切片中。
			// 4. 返回一个空的字符串切片。
			list := bizmodels.PreContractReviewerList{
				&bizmodels.PreContractReviewer{Reviewer: "user1", ReviewerType: 2},
				&bizmodels.PreContractReviewer{Reviewer: "user2", ReviewerType: 3},
			}
			reviewerType := 1
			expected := []string{}

			// 调用目标函数
			result := h.getReviewerFromPreContractReviewerList(list, reviewerType)

			// 断言结果
			convey.So(result, convey.ShouldResemble, expected)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("正常情况：列表中所有审核人类型都匹配且无重复", func() {
			// 场景描述：
			// 构造数据：创建一个所有审核人类型都与目标类型匹配，且没有重复的列表。
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 所有元素都满足 ReviewerType 匹配条件。
			// 3. 由于没有重复，所有审核人都被添加到结果切片中。
			// 4. 返回包含所有审核人的列表。
			list := bizmodels.PreContractReviewerList{
				&bizmodels.PreContractReviewer{Reviewer: "user1", ReviewerType: 1},
				&bizmodels.PreContractReviewer{Reviewer: "user2", ReviewerType: 1},
				&bizmodels.PreContractReviewer{Reviewer: "user3", ReviewerType: 1},
			}
			reviewerType := 1
			expected := []string{"user1", "user2", "user3"}

			// 调用目标函数
			result := h.getReviewerFromPreContractReviewerList(list, reviewerType)

			// 断言结果
			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_handlerCommon_getSendBackPeerReviewers(t *testing.T) {
	mockey.PatchConvey("当前退回节点存在多个审批人时返回非当前操作人", t, func() {
		h := &handlerCommon{}
		list := bizmodels.PreContractReviewerList{
			{Reviewer: "operator@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
			{Reviewer: "peer@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
			{Reviewer: "peer@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
			{Reviewer: "other-status@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
			{Reviewer: "other-type@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractSalesOperationReview},
		}

		result := h.getSendBackPeerReviewers(list, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationReview, "operator@example.com")

		convey.So(result, convey.ShouldResemble, []string{"peer@example.com"})
	})

	mockey.PatchConvey("当前退回节点只有一个审批人时不发送", t, func() {
		h := &handlerCommon{}
		list := bizmodels.PreContractReviewerList{
			{Reviewer: "operator@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
		}

		result := h.getSendBackPeerReviewers(list, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationReview, "operator@example.com")

		convey.So(result, convey.ShouldBeNil)
	})

	mockey.PatchConvey("忽略已删除审批人", t, func() {
		h := &handlerCommon{}
		list := bizmodels.PreContractReviewerList{
			{Reviewer: "operator@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview},
			{Reviewer: "deleted@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationReview, IsDeleted: 1},
		}

		result := h.getSendBackPeerReviewers(list, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationReview, "operator@example.com")

		convey.So(result, convey.ShouldBeNil)
	})
}

func Test_handlerCommon_getSendBackTargetActionURL(t *testing.T) {
	mockey.PatchConvey("参数为空时返回空字符串", t, func() {
		h := &handlerCommon{}

		convey.So(h.getSendBackTargetActionURL(context.Background(), nil), convey.ShouldEqual, "")
		convey.So(h.getSendBackTargetActionURL(context.Background(), &auditmodel.ProcessCtx{}), convey.ShouldEqual, "")
	})

	mockey.PatchConvey("退回到销售可操作节点时返回 CRM 链接", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractSendBack,
			ContractInfo:       &model.ContractMeta{ContractNo: "PC-CN"},
		}
		mockey.Mock(larkc.GenCRMDetailURL).To(func(ctx context.Context, contractNo string) string {
			return "crm://" + contractNo
		}).Build()

		result := h.getSendBackTargetActionURL(ctx, pc)

		convey.So(result, convey.ShouldEqual, "crm://PC-CN")
	})

	mockey.PatchConvey("退回到销售运营完善信息节点时返回编辑链接", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractSalesOperationCompleteInformation,
			ContractInfo:       &model.ContractMeta{ContractNo: "PC-CN"},
		}
		mockey.Mock(larkc.GenEditURL).To(func(ctx context.Context, contractNo string) string {
			return "edit://" + contractNo
		}).Build()

		result := h.getSendBackTargetActionURL(ctx, pc)

		convey.So(result, convey.ShouldEqual, "edit://PC-CN")
	})

	mockey.PatchConvey("退回到审核节点时返回审核链接", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			ContractInfo:       &model.ContractMeta{ContractNo: "PC-CN"},
		}
		mockey.Mock(larkc.GenReviewURL).To(func(ctx context.Context, contractNo string) string {
			return "review://" + contractNo
		}).Build()

		result := h.getSendBackTargetActionURL(ctx, pc)

		convey.So(result, convey.ShouldEqual, "review://PC-CN")
	})
}

func Test_handlerCommon_clearSendBackStatusQuoteAndReviewers(t *testing.T) {
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerCommon_clearSendBackStatusQuoteAndReviewers", t, func() {
		ctx := context.Background()
		h := &handlerCommon{}

		mockey.PatchConvey("退回目标不是已退回时直接跳过", func() {
			err := h.clearSendBackStatusQuoteAndReviewers(ctx, &auditmodel.ProcessCtx{StatusChangedValue: _const.PreSalesContractSalesOperationReview})

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("退回到已退回时清理报价单信息并删除非申请人审批权限", func() {
			mockTx := &gorm.DB{}
			pc := &auditmodel.ProcessCtx{
				PreContractNo:      "PC001",
				StatusChangedValue: _const.PreSalesContractSendBack,
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneCompleted,
					BasicInfo:        &bizmodels.BasicInfo{},
				},
				PreContractVO: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}},
			}
			mockReviewerDao := &MockPreContractReviewerDao{}

			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerTypes []int, contractStatusList ...int) error {
				convey.So(tx, convey.ShouldEqual, mockTx)
				convey.So(preContractNo, convey.ShouldEqual, "PC001")
				convey.So(reviewerTypes, convey.ShouldResemble, []int{
					_const.ReviewerTypeFinanceTaxationLegalReviewer,
					_const.ReviewerTypeSalesOperation,
					_const.ReviewerTypeSolutionReviewer,
				})
				return nil
			}).Build()

			err := h.clearSendBackStatusQuoteAndReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("清理报价单信息失败时直接返回错误", func() {
			expectedErr := errors.New("clear quote failed")
			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(expectedErr).Build()

			err := h.clearSendBackStatusQuoteAndReviewers(ctx, &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSendBack,
				ContractInfo:       &model.ContractMeta{RelateQuoteScene: _const.RelateQuoteSceneCompleted, BasicInfo: &bizmodels.BasicInfo{}},
				PreContractVO:      &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}},
			})

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("删除多余审批人失败时返回错误", func() {
			expectedErr := errors.New("delete reviewer failed")
			mockReviewerDao := &MockPreContractReviewerDao{}

			commodityService := metacommodity.NewService()
			h.commodityService = commodityService
			mockey.Mock(mockey.GetMethod(commodityService, "ClearQuoteRelatedData")).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(expectedErr).Build()

			err := h.clearSendBackStatusQuoteAndReviewers(ctx, &auditmodel.ProcessCtx{PreContractNo: "PC001", StatusChangedValue: _const.PreSalesContractSendBack})

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_SetReviewerMatcher_BitsUTGen(t *testing.T) {
	// mockPreContractReviewRuleDao is a mock for the dal.PreContractReviewRuleDao interface.
	type mockPreContractReviewRuleDao struct {
		dal.PreContractReviewRuleDao
	}
	// mockPreContractReviewRuleReviewerDao is a mock for the dal.PreContractReviewRuleReviewerDao interface.
	type mockPreContractReviewRuleReviewerDao struct {
		dal.PreContractReviewRuleReviewerDao
	}

	mockey.PatchConvey("TestSetReviewerMatcher", t, func() {
		// Reset the global variable before each test case for isolation.
		reviewerMatcher = nil

		mockey.PatchConvey("should set reviewerMatcher to a non-nil value", func() {
			// 场景描述:
			// 成功设置一个非空的 reviewerMatcher 实例。
			// 构造数据:
			// 通过 reviewrule.NewReviewerMatcher() 创建一个实例。
			// 逻辑链路:
			// 1. Mock dal.NewPreContractReviewRuleDao 和 dal.NewPreContractReviewRuleReviewerDao 以隔离数据库依赖。
			// 2. 调用 reviewrule.NewReviewerMatcher() 创建一个 *reviewrule.ReviewerMatcher 实例。
			// 3. 调用目标函数 SetReviewerMatcher()。
			// 4. 断言包级变量 reviewerMatcher 被正确设置为创建的实例。

			mockey.Mock(dal.NewPreContractReviewRuleDao).Return(&mockPreContractReviewRuleDao{}).Build()
			mockey.Mock(dal.NewPreContractReviewRuleReviewerDao).Return(&mockPreContractReviewRuleReviewerDao{}).Build()

			newMatcher := reviewrule.NewReviewerMatcher()

			SetReviewerMatcher(newMatcher)

			convey.So(reviewerMatcher, convey.ShouldNotBeNil)
			convey.So(reviewerMatcher, convey.ShouldEqual, newMatcher)
		})

		mockey.PatchConvey("should set reviewerMatcher to nil", func() {
			// 场景描述:
			// 成功将 reviewerMatcher 设置为 nil。
			// 构造数据:
			// 参数为 nil。
			// 逻辑链路:
			// 1. 首先将包级变量 reviewerMatcher 设置为一个非空值，以确保测试的有效性。
			// 2. 使用 nil 参数调用目标函数 SetReviewerMatcher()。
			// 3. 断言包级变量 reviewerMatcher 已变为 nil。

			reviewerMatcher = &reviewrule.ReviewerMatcher{}

			SetReviewerMatcher(nil)

			convey.So(reviewerMatcher, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_commonPostProcessUpdateReviewers1_BitsUTGen(t *testing.T) {

	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerCommon.commonPostProcessUpdateReviewers", t, func() {

		mockBuilder := &larkc.CommonMessageCardBuilder{}
		mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
		mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return(`{}`).Build()

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()
		mockey.Mock(utils.StringListFormat).To(func(list []string, f func(string) string) []string {
			result := make([]string, 0, len(list))
			for _, item := range list {
				result = append(result, f(item))
			}
			return result
		}).Build()
		mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
		mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()

		mockey.PatchConvey("场景：获取加签/转办人员信息失败", func() {
			pc := &auditmodel.ProcessCtx{
				Extra: "new.reviewer@example.com",
			}
			mockErr := errors.New("get employee failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, mockErr).Build()

			err := h.commonPostProcessUpdateReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "get employee failed")
		})

		mockey.PatchConvey("场景：加签操作", func() {
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationAddReviewer,
				Extra:           "new.reviewer1@example.com,new.reviewer2@example.com",
				CurrentOperator: "current.operator@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-123",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
				},
			}
			currentReviewer := &bizmodels.PreContractReviewer{Priority: 1}
			newReviewers := []*peopleclient.Employee{
				{Email: "new.reviewer1@example.com"},
				{Email: "new.reviewer2@example.com"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			mockey.PatchConvey("子场景：成功加签并发送通知", func() {
				mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：加签时发生错误", func() {
				mockErr := errors.New("countersign failed")
				mockey.Mock((*handlerCommon).countersignReviewer).Return(mockErr).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "countersign failed")
			})
		})

		mockey.PatchConvey("场景：转办操作", func() {
			mockDao := &MockPreContractReviewerDao{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()

			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "current.operator@example.com",
				PreContractNo:   "PC-456",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-456",
					ContractName:   "Test Contract 2",
					OtherPartyName: "Test Party 2",
				},
			}
			newReviewers := []*peopleclient.Employee{
				{Email: "new.reviewer@example.com"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			mockey.PatchConvey("子场景：成功转办并发送通知", func() {
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：转办时发生错误", func() {
				mockErr := errors.New("change reviewer failed")
				mockey.Mock((*handlerCommon).changeReviewer).Return(mockErr).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "change reviewer failed")
			})

			mockey.PatchConvey("子场景：删除被转办人时发生错误（不影响主流程）", func() {
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("delete failed")).Build()

				err := h.commonPostProcessUpdateReviewers(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("场景：其他操作（不触发加签/转办）", func() {
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationReviewPass,
				Extra:          "reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "C-789",
					ContractName:   "Test Contract 3",
					OtherPartyName: "Test Party 3",
				},
			}
			newReviewers := []*peopleclient.Employee{
				{Email: "reviewer@example.com"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(newReviewers, nil).Build()

			err := h.commonPostProcessUpdateReviewers(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_DeleteMetaExt_BitsUTGen(t *testing.T) {
	// MockContractMetaExtDao is a mock type for the ContractMetaExtDao interface.
	type MockContractMetaExtDao struct {
		dal.ContractMetaExtDao
	}

	mockey.PatchConvey("Test_handlerCommon_DeleteMetaExt", t, func() {
		// Common test variables
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}

		mockey.PatchConvey("Success: deleteKey is not empty and DAO deletion succeeds", func() {
			// 场景描述：
			// 传入非空的deleteKey，DAO层成功删除数据。
			// 构造数据：
			// deleteKey: "some_key"
			// contractId: 1
			// 逻辑链路：
			// 1. len(deleteKey) > 0, a non-empty key, proceed.
			// 2. Mock dal.NewContractMetaExtDao to return a mock DAO.
			// 3. Mock the DeleteByAttrKey method on the mock DAO to return nil (success).
			// 4. The function returns nil, indicating success.

			deleteKey := "some_key"
			contractId := uint64(1)

			mockey.Mock(dal.NewContractMetaExtDao).Return(&MockContractMetaExtDao{}).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(nil).Build()

			// Act
			apiErr := h.DeleteMetaExt(ctx, tx, deleteKey, contractId)

			// Assert
			convey.So(apiErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: deleteKey is empty", func() {
			// 场景描述：
			// 传入空的deleteKey，函数应直接返回成功，不执行数据库操作。
			// 构造数据：
			// deleteKey: ""
			// contractId: 1
			// 逻辑链路：
			// 1. len(deleteKey) == 0, the key is empty.
			// 2. The function enters the first if block, logs an info message, and returns nil immediately.
			// 3. No DAO methods are called.

			deleteKey := ""
			contractId := uint64(1)

			// Act
			apiErr := h.DeleteMetaExt(ctx, tx, deleteKey, contractId)

			// Assert
			convey.So(apiErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: DAO deletion fails", func() {
			// 场景描述：
			// 传入非空的deleteKey，但DAO层在删除数据时返回错误。
			// 构造数据：
			// deleteKey: "some_key"
			// contractId: 1
			// mockErr: a new error "db error"
			// 逻辑链路：
			// 1. len(deleteKey) > 0, a non-empty key, proceed.
			// 2. Mock dal.NewContractMetaExtDao to return a mock DAO.
			// 3. Mock the DeleteByAttrKey method on the mock DAO to return an error.
			// 4. The function catches the error, logs it, and returns an internal server error.

			deleteKey := "some_key"
			contractId := uint64(1)
			mockErr := errors.New("db error")

			mockey.Mock(dal.NewContractMetaExtDao).Return(&MockContractMetaExtDao{}).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(mockErr).Build()

			// Act
			apiErr := h.DeleteMetaExt(ctx, tx, deleteKey, contractId)

			// Assert
			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldEqual, errorsV2.ErrInternalError.WithArgs(mockErr.Error()).Error())
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "db error")
		})
	})
}

// Test_buildProductLineForceUpdates 覆盖产品线强制覆盖的适用边界：
// 仅无报价单场景返回强制覆盖字段，关联报价单时返回 nil 以回落到 AllFieldUpdate 的合并语义。
func Test_buildProductLineForceUpdates(t *testing.T) {
	mockey.PatchConvey("Test buildProductLineForceUpdates", t, func() {
		ctx := context.Background()
		manageInfo := &bizmodels.ManageInfo{BelongingDepartment: "", ProductLine: ""}

		mockey.PatchConvey("no relate quote returns force updates", func() {
			warned := mockey.Mock(logs.CtxWarn).Return().Build()
			got := buildProductLineForceUpdates(ctx, manageInfo, &model.ContractMetaDB{ContractNo: "TEST-001"})
			convey.So(got, convey.ShouldResemble, map[string]interface{}{
				"belonging_department": "",
				"product_line":         "",
			})
			// 空值清空需要打点，便于线上观测调用方漏传。
			convey.So(warned.Times(), convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("relate quote returns nil", func() {
			got := buildProductLineForceUpdates(ctx, manageInfo, &model.ContractMetaDB{ContractNo: "TEST-001", RelateQuoteNo: "QUOTE-001"})
			convey.So(got, convey.ShouldBeNil)
		})

		mockey.PatchConvey("no relate quote passes through edited values", func() {
			warned := mockey.Mock(logs.CtxWarn).Return().Build()
			edited := &bizmodels.ManageInfo{BelongingDepartment: "dept", ProductLine: "line"}
			got := buildProductLineForceUpdates(ctx, edited, &model.ContractMetaDB{ContractNo: "TEST-001"})
			convey.So(got, convey.ShouldResemble, map[string]interface{}{
				"belonging_department": "dept",
				"product_line":         "line",
			})
			// 正常修改不应打点。
			convey.So(warned.Times(), convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerCommon_SaveManageInfo_BitsUTGen(t *testing.T) {

	h := &handlerCommon{}
	ctx := context.Background()
	tx := &gorm.DB{}

	mockey.PatchConvey("Test handlerCommon.SaveManageInfo", t, func() {

		metaDB := &model.ContractMetaDB{
			BaseDB:     model.BaseDB{Id: 1, CreatedTime: time.Now(), UpdatedTime: time.Now(), Status: 0},
			ContractNo: "TEST-001",
			Version:    1,
		}

		manageInfo := &bizmodels.ManageInfo{
			RelatedPersonnel: "test.user",
			IsSplitProduct:   true,
			ProductLevelMap: map[string][]*bizmodels.ProductInfo{
				"level1": {
					{
						TradeProduct: "test_product",
						Income:       decimal.NewFromInt(100),
					},
				},
			},
			ExternalProductList: bizmodels.ExternalProductInfoList{
				{ID: 1, TradeProductName: "external_product"},
			},
		}

		mockey.PatchConvey("Success: Create new manage info", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{{Product: "test_product", InvoiceProject: "*tax*service*6%"}}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(nil).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: Update existing manage info and explicitly clear product lines without relate quote", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			manageInfo.BelongingDepartment = ""
			manageInfo.ProductLine = ""
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(&model.VolcContractManage{
				BelongingDepartment: "old_belonging_department",
				ProductLine:         "old_product_line",
			}, nil).Build()
			mockey.Mock((*MockContractManageDao).Update).To(func(_ *MockContractManageDao, _ context.Context, _ *gorm.DB, entity *model.VolcContractManage) error {
				convey.So(entity.BelongingDepartment, convey.ShouldBeEmpty)
				convey.So(entity.ProductLine, convey.ShouldBeEmpty)
				return nil
			}).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{{Product: "test_product"}}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(nil).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: keep stored product lines when contract relates a quote", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			// 关联报价单时产品线由报价单派生，入参空值不应清空已落库的派生结果。
			metaDB.RelateQuoteNo = "QUOTE-001"
			defer func() { metaDB.RelateQuoteNo = "" }()
			manageInfo.BelongingDepartment = ""
			manageInfo.ProductLine = ""
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(&model.VolcContractManage{
				BelongingDepartment: "old_belonging_department",
				ProductLine:         "old_product_line",
			}, nil).Build()
			mockey.Mock((*MockContractManageDao).Update).To(func(_ *MockContractManageDao, _ context.Context, _ *gorm.DB, entity *model.VolcContractManage) error {
				convey.So(entity.BelongingDepartment, convey.ShouldEqual, "old_belonging_department")
				convey.So(entity.ProductLine, convey.ShouldEqual, "old_product_line")
				return nil
			}).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{{Product: "test_product"}}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(nil).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: Nil input parameter", func() {

			err := h.SaveManageInfo(ctx, tx, nil, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "保存管理信息失败，入参异常")
		})

		mockey.PatchConvey("Failure: FindByVolcContractId fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, errors.New("db find error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveManageInfoFail")
		})

		mockey.PatchConvey("Failure: Update manage info fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(&model.VolcContractManage{}, nil).Build()
			mockey.Mock((*MockContractManageDao).Update).Return(errors.New("db update error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveManageInfoFail")
		})

		mockey.PatchConvey("Failure: Create manage info fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(errors.New("db create error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveManageInfoFail")
		})

		mockey.PatchConvey("Failure: SaveCommodityList fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(&model.VolcContractManage{}, nil).Build()
			mockey.Mock((*MockContractManageDao).Update).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(errors.New("delete commodity error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveCommodityListFail")
		})

		mockey.PatchConvey("Failure: UpdateContractMeta fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{{Product: "test_product"}}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(errors.New("update meta error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateContractMetaFail")
		})

		mockey.PatchConvey("Failure: SaveExternalCommodityList fails", func() {

			mockey.Mock(dal.NewContractManageDao).Return(&MockContractManageDao{}).Build()
			mockey.Mock((*MockContractManageDao).FindByVolcContractId).Return(nil, nil).Build()
			mockey.Mock((*MockContractManageDao).Create).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityDao).Return(&MockContractCommodityDao{}).Build()
			mockey.Mock((*MockContractCommodityDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(innertopcommercializationcli.BatchGetProductLite).Return([]*lite.ProductLite{{Product: "test_product"}}, nil).Build()
			mockey.Mock((*MockContractCommodityDao).CreateInBatches).Return(nil).Build()

			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateByMap).Return(nil).Build()

			mockey.Mock(dal.NewContractCommodityExternalDao).Return(&MockContractCommodityExternalDao{}).Build()
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(errors.New("delete external error")).Build()

			err := h.SaveManageInfo(ctx, tx, manageInfo, metaDB)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveExternalCommodityListFail")
		})
	})
}

func Test_validateRiskClauseRole_BitsUTGen(t *testing.T) {
	// Mock struct definitions for DAL interfaces
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}
	type MockRiskClauseRoleDao struct {
		dal.RiskClauseRoleDao
	}

	mockey.PatchConvey("Test validateRiskClauseRole", t, func() {
		// Common variables for all test cases
		ctx := context.Background()
		tx := &gorm.DB{}
		contractNo := "test-contract-123"

		// Mock DAO instances
		mockContractMetaDao := &MockContractMetaDao{}
		mockRiskClauseRoleDao := &MockRiskClauseRoleDao{}

		mockey.PatchConvey("failure case: FindByNoForSales returns an error", func() {
			// 场景描述:
			// 测试当获取合同元数据失败时，函数是否能正确处理并返回错误。
			// 构造数据:
			// 无特定数据构造。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回一个自定义的 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 方法，使其返回一个错误。
			// 3. 调用 validateRiskClauseRole 函数。
			// 4. 断言函数返回的错误与 mock 的错误一致。
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(nil, errors.New("db find error")).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db find error")
		})

		mockey.PatchConvey("failure case: contract meta not found", func() {
			// 场景描述:
			// 测试当根据合同号未找到对应的合同元数据时，函数是否返回预期的“校验失败”错误。
			// 构造数据:
			// 无特定数据构造。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回一个自定义的 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 方法，使其返回 (nil, nil)，模拟未找到记录。
			// 3. 调用 validateRiskClauseRole 函数。
			// 4. 断言函数返回的错误信息为 "校验风险条款失败"。
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(nil, nil).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "校验风险条款失败")
		})

		mockey.PatchConvey("failure case: ListByVolcContractId returns an error", func() {
			// 场景描述:
			// 测试当获取风险条款列表失败时，函数是否能正确处理并返回错误。
			// 构造数据:
			// 构造一个有效的 ContractMetaDB 对象。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 成功返回一个合同元数据。
			// 3. Mock dal.NewRiskClauseRoleDao() 返回 mockRiskClauseRoleDao 实例。
			// 4. Mock (*MockRiskClauseRoleDao).ListByVolcContractId 方法，使其返回一个错误。
			// 5. 调用 validateRiskClauseRole 函数。
			// 6. 断言函数返回的错误与 mock 的错误一致。
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(meta, nil).Build()

			mockey.Mock(dal.NewRiskClauseRoleDao).Return(mockRiskClauseRoleDao).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(nil, errors.New("db list error")).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db list error")
		})

		mockey.PatchConvey("success case: no risk clause roles found", func() {
			// 场景描述:
			// 测试当合同没有关联的风险条款时，函数应校验通过，返回 nil。
			// 构造数据:
			// 构造一个有效的 ContractMetaDB 对象。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 成功返回一个合同元数据。
			// 3. Mock dal.NewRiskClauseRoleDao() 返回 mockRiskClauseRoleDao 实例。
			// 4. Mock (*MockRiskClauseRoleDao).ListByVolcContractId 方法，返回一个空的列表。
			// 5. 调用 validateRiskClauseRole 函数。
			// 6. 断言函数返回 nil。
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(meta, nil).Build()

			mockey.Mock(dal.NewRiskClauseRoleDao).Return(mockRiskClauseRoleDao).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(model.RiskClauseRoleDBList{}, nil).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case: exists unapproved risk clause role", func() {
			// 场景描述:
			// 测试当存在未审批通过的风险条款时，函数应校验失败，并返回特定错误。
			// 构造数据:
			// 构造一个有效的 ContractMetaDB 对象。
			// 构造一个 RiskClauseRoleDB 列表，其中包含一个状态为“审批中”的条款。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 成功返回一个合同元数据。
			// 3. Mock dal.NewRiskClauseRoleDao() 返回 mockRiskClauseRoleDao 实例。
			// 4. Mock (*MockRiskClauseRoleDao).ListByVolcContractId 方法，返回包含未审批条款的列表。
			// 5. 函数进入 for 循环，检查到未通过的条款。
			// 6. 调用 validateRiskClauseRole 函数。
			// 7. 断言函数返回包含 "存在未审批通过的风险条款，不允许提交" 的错误。
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			riskRoleList := model.RiskClauseRoleDBList{
				{BaseDB: model.BaseDB{Status: _const.ApprovalRiskRoleStatus}},
			}
			expectedErr := errorsV2.ErrCommon.WithArgs("存在未审批通过的风险条款，不允许提交")

			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(meta, nil).Build()

			mockey.Mock(dal.NewRiskClauseRoleDao).Return(mockRiskClauseRoleDao).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(riskRoleList, nil).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("success case: all risk clause roles are approved or closed", func() {
			// 场景描述:
			// 测试当所有风险条款都处于“审批通过”或“已关闭”状态时，函数应校验成功。
			// 构造数据:
			// 构造一个有效的 ContractMetaDB 对象。
			// 构造一个 RiskClauseRoleDB 列表，其中条款状态均为 PassRiskRoleStatus 或 CloseRiskRoleStatus。
			// 逻辑链路:
			// 1. Mock dal.NewContractMetaDao() 返回 mockContractMetaDao 实例。
			// 2. Mock (*MockContractMetaDao).FindByNoForSales 成功返回一个合同元数据。
			// 3. Mock dal.NewRiskClauseRoleDao() 返回 mockRiskClauseRoleDao 实例。
			// 4. Mock (*MockRiskClauseRoleDao).ListByVolcContractId 方法，返回只包含已通过/已关闭条款的列表。
			// 5. 函数进入 for 循环，所有条款均满足条件。
			// 6. 调用 validateRiskClauseRole 函数。
			// 7. 断言函数返回 nil。
			meta := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 1}}
			riskRoleList := model.RiskClauseRoleDBList{
				{BaseDB: model.BaseDB{Status: _const.PassRiskRoleStatus}},
				{BaseDB: model.BaseDB{Status: _const.CloseRiskRoleStatus}},
			}
			mockey.Mock(dal.NewContractMetaDao).Return(mockContractMetaDao).Build()
			mockey.Mock((*MockContractMetaDao).FindByNoForSales).Return(meta, nil).Build()

			mockey.Mock(dal.NewRiskClauseRoleDao).Return(mockRiskClauseRoleDao).Build()
			mockey.Mock((*MockRiskClauseRoleDao).ListByVolcContractId).Return(riskRoleList, nil).Build()

			err := validateRiskClauseRole(ctx, tx, contractNo)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_matchExistsReviewer_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao 用于模拟 dal.PreContractReviewerDao 接口
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerCommon_matchExistsReviewer", t, func() {
		// 准备通用数据
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景: 数据库查询返回错误", func() {
			// 场景描述:
			// 构造数据: 无特殊构造
			// 逻辑链路:
			// 1. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个错误。
			// 2. 函数应捕获此错误并直接返回，结果为 nil 和该错误。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{ContractNo: "test-contract-no"},
			}
			curReviewer := &bizmodels.PreContractReviewer{}
			reviewer := &peopleclient.Employee{}
			dbErr := errors.New("database error")

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, dbErr).Build()

			// 调用
			result, err := h.matchExistsReviewer(ctx, pc, curReviewer, reviewer)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database error")
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景: 找到匹配的审核人", func() {
			// 场景描述:
			// 构造数据: 构造一个 curReviewer 和 reviewer，并使数据库返回的列表中有一个元素的 ContractStatus, ReviewerType, Reviewer 字段与之完全匹配。
			// 逻辑链路:
			// 1. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个包含多个审核人记录的列表。
			// 2. for 循环遍历列表，其中一个记录与输入参数完全匹配，进入 if 分支。
			// 3. 函数返回匹配到的 *model.PreContractReviewerDB 对象和 nil 错误。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{ContractNo: "test-contract-no"},
			}
			curReviewer := &bizmodels.PreContractReviewer{
				ContractStatus: 1,
				ReviewerType:   2,
			}
			reviewer := &peopleclient.Employee{
				Email: "match@example.com",
			}
			matchedReviewerDB := &model.PreContractReviewerDB{
				ContractStatus: 1,
				ReviewerType:   2,
				Reviewer:       "match@example.com",
			}
			reviewerDBList := model.PreContractReviewerDBList{
				{ContractStatus: 99, ReviewerType: 99, Reviewer: "other@example.com"},
				matchedReviewerDB,
				{ContractStatus: 1, ReviewerType: 2, Reviewer: "another@example.com"},
			}

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(reviewerDBList, nil).Build()

			// 调用
			result, err := h.matchExistsReviewer(ctx, pc, curReviewer, reviewer)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldEqual, matchedReviewerDB)
		})

		mockey.PatchConvey("场景: 未找到匹配的审核人", func() {
			// 场景描述:
			// 构造数据: 构造一个 curReviewer 和 reviewer, 数据库返回的列表中没有任何一个元素的字段与之完全匹配。
			// 逻辑链路:
			// 1. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个审核人记录列表。
			// 2. for 循环遍历列表，所有记录均不满足 if 条件。
			// 3. 循环结束后，函数返回 nil, nil。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{ContractNo: "test-contract-no"},
			}
			curReviewer := &bizmodels.PreContractReviewer{
				ContractStatus: 1,
				ReviewerType:   2,
			}
			reviewer := &peopleclient.Employee{
				Email: "target@example.com",
			}
			reviewerDBList := model.PreContractReviewerDBList{
				{ContractStatus: 99, ReviewerType: 2, Reviewer: "target@example.com"}, // ContractStatus 不匹配
				{ContractStatus: 1, ReviewerType: 99, Reviewer: "target@example.com"}, // ReviewerType 不匹配
				{ContractStatus: 1, ReviewerType: 2, Reviewer: "other@example.com"},   // Reviewer 不匹配
			}

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(reviewerDBList, nil).Build()

			// 调用
			result, err := h.matchExistsReviewer(ctx, pc, curReviewer, reviewer)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景: 数据库返回的审核人列表为空", func() {
			// 场景描述:
			// 构造数据: 无特殊构造
			// 逻辑链路:
			// 1. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个空列表和 nil 错误。
			// 2. for 循环不执行。
			// 3. 函数直接返回 nil, nil。

			// 准备数据
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{ContractNo: "test-contract-no"},
			}
			curReviewer := &bizmodels.PreContractReviewer{}
			reviewer := &peopleclient.Employee{}
			reviewerDBList := model.PreContractReviewerDBList{}

			// Mock
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(reviewerDBList, nil).Build()

			// 调用
			result, err := h.matchExistsReviewer(ctx, pc, curReviewer, reviewer)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_validateSupply_BitsUTGen(t *testing.T) {
	// Mock 接口的辅助结构体
	type MockMetaService struct {
		contractmeta.MetaService
	}
	type MockSupplyService struct {
		supply.SupplyService
	}

	mockey.PatchConvey("Test handlerCommon.validateSupply", t, func() {
		ctx := context.Background()
		h := &handlerCommon{}

		mockey.PatchConvey("场景1: 非补充协议场景，直接返回nil", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource: "",
					ContractNo:   "test-contract-no",
				},
				ContractInfo: &model.ContractMeta{},
			}

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "test-contract-no")
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "test-contract-no")
		})

		mockey.PatchConvey("场景2: 补充协议场景，但原合同号为空", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "",
					ContractNo:     "test-contract-no",
					SupplyScene:    1,
				},
				ContractInfo: &model.ContractMeta{},
			}
			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "原合同号不能为空")
		})

		mockey.PatchConvey("场景3: 获取补充协议相关合同信息失败(GetSupplyContractList返回error)", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					ContractNo:     "test-contract-no",
					SupplyScene:    1,
				},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, errorsV2.ErrCommon.WithArgs("db error")).Build()

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
		})

		mockey.PatchConvey("场景4: 补充协议相关合同信息不存在(GetSupplyContractList返回nil)", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					ContractNo:     "test-contract-no",
					SupplyScene:    1,
				},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, nil).Build()

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "补充协议相关合同信息不存在")
		})

		mockey.PatchConvey("场景5: 填充补充协议信息失败(fillSupplyExtInfoByFromContractInfo返回error)", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
				},
				ContractInfo: &model.ContractMeta{},
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(errors.New("fill error")).Build()

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "填充补充协议信息失败")
		})

		mockey.PatchConvey("场景6: 解析合同变更信息失败(变更报价单场景下json.Unmarshal失败)", func() {
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          "invalid-json",
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
				},
				ContractInfo: &model.ContractMeta{},
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}
			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()

			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解析合同变更信息失败")
		})

		mockey.PatchConvey("场景7: 基础校验失败(ValidateBase返回error)", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "quote-123",
				},
				ContractInfo: &model.ContractMeta{},
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}
			expectedErr := errorsV2.ErrCommon.WithArgs("validate base failed")

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(expectedErr).Build()

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景8: 有效期校验失败(ValidateValidityTime返回error)", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "quote-123",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
				},
				OperationState: 0,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}
			expectedErr := errorsV2.ErrCommon.WithArgs("validate validity time failed")

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(expectedErr).Build()

			err := h.validateSupply(ctx, pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景9: 成功路径-需要有效期校验", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "quote-123",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
				},
				OperationState: 0,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(true).Build()
			mockey.Mock((*MockSupplyService).ValidateValidityTime).Return(nil).Build()

			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.PreContractVO.MainContractNo, convey.ShouldEqual, "main-no")
			convey.So(pc.ContractInfo.MainContractNo, convey.ShouldEqual, "main-no")
		})

		mockey.PatchConvey("场景10: 成功路径-跳过有效期校验", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "quote-123",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
				},
				OperationState: 0,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(false).Build()

			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景11: 成功路径-主合同号为空", func() {
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "quote-123",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractDraft,
				},
				OperationState: 0,
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "", ContractNo: "from-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()
			mockey.Mock(utils.IntIn).Return(false).Build()

			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景12: 成功路径-变更报价单场景", func() {
			changeInfo := bizmodels.ChangeQuoteExtra{QuoteID: "new-quote-id"}
			extraBytes, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SupplySource:   "some_source",
					FromContractNo: "from-no",
					RelateQuoteNo:  "old-quote-id",
				},
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
				},
				OperationState: _const.OperationChangeQuoteNo,
				Extra:          string(extraBytes),
			}
			supplyContractList := &bizmodels.SupplyContractListResp{
				FromContract: &bizmodels.ContractMetaInfo{MainContractNo: "main-no"},
			}
			mockMetaSvc := &MockMetaService{}
			mockSupplySvc := &MockSupplyService{}

			mockey.Mock((*handlerCommon).getMetaService).Return(mockMetaSvc).Build()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(supplyContractList, nil).Build()
			mockey.Mock((*handlerCommon).fillSupplyExtInfoByFromContractInfo).Return(nil).Build()
			mockey.Mock(supply.NewSupplyService).Return(mockSupplySvc).Build()
			mockey.Mock((*MockSupplyService).ValidateBase).Return(nil).Build()

			err := h.validateSupply(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_fillSpecialContractType_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerCommon_fillSpecialContractType", t, func() {
		mockey.PatchConvey("场景: 既不是保底合同也不是阶梯报价合同", func() {
			// 场景描述:
			// 构造数据: metaExtMap不包含ExtKeyQuoteGuarantee, manageInfo.QuoteType不为QuoteTypeLadderQuote
			// 逻辑链路:
			// 1. 两个if条件都为false, specialContractTypes为空
			// 2. len(specialContractTypes)为0, 不会更新pc中的SpecialContractType字段
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					SpecialContractType: "",
				},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "",
					},
				},
			}
			metaExtMap := make(map[string]string)
			manageInfo := &bizmodels.ManageInfo{
				QuoteType: _const.QuoteTypeDefault,
			}

			h.fillSpecialContractType(ctx, pc, metaExtMap, manageInfo)

			convey.So(pc.PreContractVO.SpecialContractType, convey.ShouldBeEmpty)
			convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("场景: 是保底合同, 但不是阶梯报价合同", func() {
			// 场景描述:
			// 构造数据: metaExtMap包含ExtKeyQuoteGuarantee, manageInfo.QuoteType不为QuoteTypeLadderQuote
			// 逻辑链路:
			// 1. 第一个if条件为true, specialContractTypes追加"1" (SpecialContractTypeGuarantee)
			// 2. 第二个if条件为false
			// 3. len(specialContractTypes) > 0, 更新pc中相关字段为"1"
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			metaExtMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: "some_value",
			}
			manageInfo := &bizmodels.ManageInfo{
				QuoteType: _const.QuoteTypeDefault,
			}

			h.fillSpecialContractType(ctx, pc, metaExtMap, manageInfo)

			convey.So(pc.PreContractVO.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
			convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
		})

		mockey.PatchConvey("场景: 不是保底合同, 但是阶梯报价合同", func() {
			// 场景描述:
			// 构造数据: metaExtMap不包含ExtKeyQuoteGuarantee, manageInfo.QuoteType为QuoteTypeLadderQuote
			// 逻辑链路:
			// 1. 第一个if条件为false
			// 2. 第二个if条件为true, specialContractTypes追加"2" (SpecialContractTypeLadderQuotation)
			// 3. len(specialContractTypes) > 0, 更新pc中相关字段为"2"
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			metaExtMap := make(map[string]string)
			manageInfo := &bizmodels.ManageInfo{
				QuoteType: _const.QuoteTypeLadderQuote,
			}

			h.fillSpecialContractType(ctx, pc, metaExtMap, manageInfo)

			convey.So(pc.PreContractVO.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeLadderQuotation)
			convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldEqual, _const.SpecialContractTypeLadderQuotation)
		})

		mockey.PatchConvey("场景: 既是保底合同又是阶梯报价合同", func() {
			// 场景描述:
			// 构造数据: metaExtMap包含ExtKeyQuoteGuarantee, manageInfo.QuoteType为QuoteTypeLadderQuote
			// 逻辑链路:
			// 1. 第一个if条件为true, specialContractTypes追加"1"
			// 2. 第二个if条件为true, specialContractTypes追加"2"
			// 3. len(specialContractTypes) > 0, 更新pc中相关字段为"1,2"
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			metaExtMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: "some_value",
			}
			manageInfo := &bizmodels.ManageInfo{
				QuoteType: _const.QuoteTypeLadderQuote,
			}

			h.fillSpecialContractType(ctx, pc, metaExtMap, manageInfo)

			expectedType := strings.Join([]string{_const.SpecialContractTypeGuarantee, _const.SpecialContractTypeLadderQuotation}, ",")
			convey.So(pc.PreContractVO.SpecialContractType, convey.ShouldEqual, expectedType)
			convey.So(pc.ContractInfo.BasicInfo.SpecialContractType, convey.ShouldEqual, expectedType)
		})
	})
}

func Test_handlerCommon_updateContractSettlement_BitsUTGen(t *testing.T) {
	// MockContractSettlementDao is a mock type for the dal.ContractSettlementDao interface.
	type MockContractSettlementDao struct {
		dal.ContractSettlementDao
	}

	mockey.PatchConvey("Test_handlerCommon_updateContractSettlement", t, func() {
		// Common test setup
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		entity := &model.ContractMetaDB{
			BaseDB: model.BaseDB{
				Id: 1,
			},
			ContractNo: "TEST-CONTRACT-001",
		}

		mockey.PatchConvey("success case: successfully update contract settlement", func() {
			// 场景描述：
			// 正常更新合同结算条款。
			// 构造数据：
			// - entity: 一个有效的 ContractMetaDB 实例，ID为1。
			// - settlementLines: 包含一个有效的结算条款。
			// 逻辑链路：
			// 1. Mock dal.NewContractSettlementDao 返回一个 mock DAO 实例。
			// 2. Mock (*MockContractSettlementDao).SoftDeleteByContractID 成功，返回 nil。
			// 3. Mock model.GenSettlementDBFromSettlementInfo 成功，返回一个有效的 ContractSettlementDB 实例和 nil。
			// 4. Mock (*MockContractSettlementDao).BatchCreate 成功，返回 nil。
			// 5. 函数应成功执行并返回 nil。
			settlementLines := &bizmodels.SettlementInfo{
				SettlementLines: bizmodels.SettlementLines{
					{
						Id:               101,
						InvoicingPercent: "100",
						InvoicingTotal:   "1000",
						PaymentPercent:   "100",
						PaymentTotal:     "1000",
					},
				},
			}
			mockSettlementDB := &model.ContractSettlementDB{
				VolcContractID: int(entity.Id),
				ContractNo:     entity.ContractNo,
			}
			mockDao := &MockContractSettlementDao{}

			mockey.Mock(dal.NewContractSettlementDao).Return(mockDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(mockSettlementDB, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			err := h.updateContractSettlement(ctx, tx, entity, settlementLines)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case: SoftDeleteByContractID returns an error", func() {
			// 场景描述：
			// 在软删除旧结算条款时发生错误。
			// 构造数据：
			// - entity: 一个有效的 ContractMetaDB 实例。
			// - settlementLines: 任意结算条款数据。
			// 逻辑链路：
			// 1. Mock dal.NewContractSettlementDao 返回一个 mock DAO 实例。
			// 2. Mock (*MockContractSettlementDao).SoftDeleteByContractID 失败，返回一个错误。
			// 3. 函数应立即返回该错误。
			expectedErr := errors.New("soft delete error")
			settlementLines := &bizmodels.SettlementInfo{}
			mockDao := &MockContractSettlementDao{}

			mockey.Mock(dal.NewContractSettlementDao).Return(mockDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(expectedErr).Build()

			err := h.updateContractSettlement(ctx, tx, entity, settlementLines)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("failure case: GenSettlementDBFromSettlementInfo returns an error", func() {
			// 场景描述：
			// 在根据业务模型生成数据库模型时发生错误。
			// 构造数据：
			// - entity: 一个有效的 ContractMetaDB 实例。
			// - settlementLines: 包含一个结算条款，该条款将导致 GenSettlementDBFromSettlementInfo 失败。
			// 逻辑链路：
			// 1. Mock dal.NewContractSettlementDao 返回一个 mock DAO 实例。
			// 2. Mock (*MockContractSettlementDao).SoftDeleteByContractID 成功。
			// 3. Mock model.GenSettlementDBFromSettlementInfo 失败，返回一个错误。
			// 4. 函数应在循环中立即返回该错误。
			expectedErr := errors.New("gen settlement db error")
			settlementLines := &bizmodels.SettlementInfo{
				SettlementLines: bizmodels.SettlementLines{
					{
						Id: 101, // Data that causes an error
					},
				},
			}
			mockDao := &MockContractSettlementDao{}

			mockey.Mock(dal.NewContractSettlementDao).Return(mockDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(nil, expectedErr).Build()

			err := h.updateContractSettlement(ctx, tx, entity, settlementLines)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("failure case: BatchCreate returns an error", func() {
			// 场景描述：
			// 在批量创建新的结算条款时发生错误。
			// 构造数据：
			// - entity: 一个有效的 ContractMetaDB 实例。
			// - settlementLines: 包含一个有效的结算条款。
			// 逻辑链路：
			// 1. Mock dal.NewContractSettlementDao 返回一个 mock DAO 实例。
			// 2. Mock (*MockContractSettlementDao).SoftDeleteByContractID 成功。
			// 3. Mock model.GenSettlementDBFromSettlementInfo 成功。
			// 4. Mock (*MockContractSettlementDao).BatchCreate 失败，返回一个错误。
			// 5. 函数应返回该错误。
			expectedErr := errors.New("batch create error")
			settlementLines := &bizmodels.SettlementInfo{
				SettlementLines: bizmodels.SettlementLines{
					{
						Id:               101,
						InvoicingPercent: "100",
						InvoicingTotal:   "1000",
						PaymentPercent:   "100",
						PaymentTotal:     "1000",
					},
				},
			}
			mockSettlementDB := &model.ContractSettlementDB{}
			mockDao := &MockContractSettlementDao{}

			mockey.Mock(dal.NewContractSettlementDao).Return(mockDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock(model.GenSettlementDBFromSettlementInfo).Return(mockSettlementDB, nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(expectedErr).Build()

			err := h.updateContractSettlement(ctx, tx, entity, settlementLines)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("success case: empty settlement lines", func() {
			// 场景描述：
			// 传入的结算条款列表为空，表示删除所有现有条款。
			// 构造数据：
			// - entity: 一个有效的 ContractMetaDB 实例。
			// - settlementLines: SettlementLines 字段为空切片。
			// 逻辑链路：
			// 1. Mock dal.NewContractSettlementDao 返回一个 mock DAO 实例。
			// 2. Mock (*MockContractSettlementDao).SoftDeleteByContractID 成功。
			// 3. 循环不会执行。
			// 4. Mock (*MockContractSettlementDao).BatchCreate 被一个空切片调用，并成功返回 nil。
			// 5. 函数应成功返回 nil。
			settlementLines := &bizmodels.SettlementInfo{
				SettlementLines: bizmodels.SettlementLines{},
			}
			mockDao := &MockContractSettlementDao{}

			mockey.Mock(dal.NewContractSettlementDao).Return(mockDao).Build()
			mockey.Mock((*MockContractSettlementDao).SoftDeleteByContractID).Return(nil).Build()
			mockey.Mock((*MockContractSettlementDao).BatchCreate).Return(nil).Build()

			err := h.updateContractSettlement(ctx, tx, entity, settlementLines)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_validateManageInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test func validateManageInfo", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("场景1: contractVO为nil, 应返回nil", func() {
			// 场景描述:
			// 构造数据: contractVO为nil
			// 逻辑链路: 函数在开头检查到contractVO为nil，直接返回nil
			err := validateManageInfo(ctx, nil, &bizmodels.ManageInfo{})
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: manageInfo为nil, 应返回nil", func() {
			// 场景描述:
			// 构造数据: manageInfo为nil
			// 逻辑链路: 函数在开头检查到manageInfo为nil，直接返回nil
			err := validateManageInfo(ctx, &model.ContractMeta{}, nil)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 非自采合同, 不进行校验, 应返回nil", func() {
			// 场景描述:
			// 构造数据: contractVO.Initiator不等于_const.InitiatorSelfPurchase
			// 逻辑链路: 函数检查到Initiator不是自采合同类型，跳过校验逻辑，直接返回nil
			contractVO := &model.ContractMeta{
				Initiator: _const.InitiatorCRM, // 非自采
			}
			manageInfo := &bizmodels.ManageInfo{
				RelatedPersonnel: "0", // 即使值为"0"，也不应报错
				LegalReviewer:    "0", // 即使值为"0"，也不应报错
			}

			err := validateManageInfo(ctx, contractVO, manageInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 自采合同, 但管理信息均有效, 应返回nil", func() {
			// 场景描述:
			// 构造数据: contractVO.Initiator为_const.InitiatorSelfPurchase，manageInfo中的字段均不为"0"
			// 逻辑链路: 函数进入自采合同校验逻辑，但所有校验条件均不满足，最终返回nil
			contractVO := &model.ContractMeta{
				Initiator: _const.InitiatorSelfPurchase,
			}
			manageInfo := &bizmodels.ManageInfo{
				RelatedPersonnel: "user123",
				LegalReviewer:    "legal456",
			}

			err := validateManageInfo(ctx, contractVO, manageInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 自采合同, RelatedPersonnel为'0', 应返回错误", func() {
			// 场景描述:
			// 构造数据: contractVO.Initiator为_const.InitiatorSelfPurchase, manageInfo.RelatedPersonnel为"0"
			// 逻辑链路:
			// 1. 函数进入自采合同校验逻辑
			// 2. 检查到manageInfo.RelatedPersonnel为"0"，进入if分支
			// 3. 调用i18nfmt.Sprintf格式化错误信息
			// 4. 返回一个包含特定错误信息的APIError
			contractVO := &model.ContractMeta{
				Initiator: _const.InitiatorSelfPurchase,
			}
			manageInfo := &bizmodels.ManageInfo{
				RelatedPersonnel: "0",
				LegalReviewer:    "legal456",
			}

			// Mock i18nfmt.Sprintf
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := validateManageInfo(ctx, contractVO, manageInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "管理信息相关人员信息异常, RelatedPersonnel=0")
			apiErr, ok := err.(errorsV2.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, errorsV2.ErrCommon.GetCode())
		})

		mockey.PatchConvey("场景6: 自采合同, LegalReviewer为'0', 应返回错误", func() {
			// 场景描述:
			// 构造数据: contractVO.Initiator为_const.InitiatorSelfPurchase, manageInfo.LegalReviewer为"0"
			// 逻辑链路:
			// 1. 函数进入自采合同校验逻辑
			// 2. RelatedPersonnel校验通过
			// 3. 检查到manageInfo.LegalReviewer为"0"，进入if分支
			// 4. 调用i18nfmt.Sprintf格式化错误信息
			// 5. 返回一个包含特定错误信息的APIError
			contractVO := &model.ContractMeta{
				Initiator: _const.InitiatorSelfPurchase,
			}
			manageInfo := &bizmodels.ManageInfo{
				RelatedPersonnel: "user123",
				LegalReviewer:    "0",
			}

			// Mock i18nfmt.Sprintf
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := validateManageInfo(ctx, contractVO, manageInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "管理信息法务审核人信息异常, LegalReviewer=0")
			apiErr, ok := err.(errorsV2.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, errorsV2.ErrCommon.GetCode())
		})
	})
}

func Test_handlerCommon_GenRoleMapKeyByBasicInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_GenRoleMapKeyByBasicInfo", t, func() {
		// 初始化被测试的结构体
		h := &handlerCommon{}

		mockey.PatchConvey("场景一: CategoryNo为资源置换类型", func() {
			// 场景描述：
			// 构造数据：构造一个BasicInfo，其中CategoryNo为资源置换类型（_const.BizCategoryNoCommonZYZH）。
			// 逻辑链路：
			// 1. Mock utils.CategoryNo2WhetherResourceExchange 函数，当输入为 _const.BizCategoryNoCommonZYZH 时，返回 _const.ContractTypeResourceExchange (1)。
			// 2. 调用 GenRoleMapKeyByBasicInfo 方法。
			// 3. 断言返回的map中"ContractType"字段的值为_const.ContractTypeResourceExchange (1)。

			// 准备测试数据
			basicInfo := &bizmodels.BasicInfo{
				WhetherProject:       "Y",
				ContractTemplateType: gptr.Of(1),
				InOutType:            "Income",
				CategoryNo:           _const.BizCategoryNoCommonZYZH,
			}

			// Mock依赖函数
			mockey.Mock(utils.CategoryNo2WhetherResourceExchange).Return(_const.ContractTypeResourceExchange).Build()

			// 调用目标函数
			result := h.GenRoleMapKeyByBasicInfo(basicInfo)

			// 准备期望结果
			expectedParams := map[string]interface{}{
				"WhetherProject": "Y",
				"TemplateType":   1,
				"InOutType":      "Income",
				"ContractType":   _const.ContractTypeResourceExchange,
			}

			// 断言结果
			convey.So(result, convey.ShouldResemble, expectedParams)
		})

		mockey.PatchConvey("场景二: CategoryNo为非资源置换类型", func() {
			// 场景描述：
			// 构造数据：构造一个BasicInfo，其中CategoryNo为非资源置换类型（例如 _const.BizCategoryNoCommonHZXY）。
			// 逻辑链路：
			// 1. Mock utils.CategoryNo2WhetherResourceExchange 函数，当输入为非资源置换类型CategoryNo时，返回 _const.ContractTypeNotResourceExchange (0)。
			// 2. 调用 GenRoleMapKeyByBasicInfo 方法。
			// 3. 断言返回的map中"ContractType"字段的值为_const.ContractTypeNotResourceExchange (0)。

			// 准备测试数据
			basicInfo := &bizmodels.BasicInfo{
				WhetherProject:       "N",
				ContractTemplateType: gptr.Of(2),
				InOutType:            "Expense",
				CategoryNo:           _const.BizCategoryNoCommonHZXY,
			}

			// Mock依赖函数
			mockey.Mock(utils.CategoryNo2WhetherResourceExchange).Return(_const.ContractTypeNotResourceExchange).Build()

			// 调用目标函数
			result := h.GenRoleMapKeyByBasicInfo(basicInfo)

			// 准备期望结果
			expectedParams := map[string]interface{}{
				"WhetherProject": "N",
				"TemplateType":   2,
				"InOutType":      "Expense",
				"ContractType":   _const.ContractTypeNotResourceExchange,
			}

			// 断言结果
			convey.So(result, convey.ShouldResemble, expectedParams)
		})
	})
}

func Test_handlerCommon_reviewerMatcher_BitsUTGen(t *testing.T) {
	// 存储并恢复全局变量的原始值，以避免测试间的副作用
	originalMatcher := reviewerMatcher
	defer func() {
		reviewerMatcher = originalMatcher
	}()

	mockey.PatchConvey("Test_handlerCommon_reviewerMatcher", t, func() {
		mockey.PatchConvey("当全局变量 reviewerMatcher 为 nil 时", func() {
			// 场景描述:
			// 构造数据: 将包级别的全局变量 reviewerMatcher 设置为 nil。
			// 逻辑链路:
			// 1. 创建一个 handlerCommon 实例。
			// 2. 调用 reviewerMatcher() 方法。
			// 3. 断言返回的结果应该为 nil。
			reviewerMatcher = nil
			h := &handlerCommon{}

			// 调用目标函数
			result := h.reviewerMatcher()

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("当全局变量 reviewerMatcher 已被赋值时", func() {
			// 场景描述:
			// 构造数据: 将包级别的全局变量 reviewerMatcher 设置为一个具体的 ReviewerMatcher 实例。
			// 逻辑链路:
			// 1. 创建一个 ReviewerMatcher 实例。
			// 2. 将全局变量 reviewerMatcher 指向这个实例。
			// 3. 创建一个 handlerCommon 实例。
			// 4. 调用 reviewerMatcher() 方法。
			// 5. 断言返回的结果应该与之前设置的实例是同一个。
			expectedMatcher := &reviewrule.ReviewerMatcher{}
			reviewerMatcher = expectedMatcher
			h := &handlerCommon{}

			// 调用目标函数
			result := h.reviewerMatcher()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldEqual, expectedMatcher)
		})
	})
}

func Test_validateProjectInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test validateProjectInfo", t, func() {
		mockey.PatchConvey("场景1: 关联报价单号不为空，不执行校验", func() {
			// 场景描述:
			// 合同关联了报价单，不执行项目制信息校验，直接返回nil。
			// 构造数据:
			// contractInfo.RelateQuoteNo 设置为非空字符串。
			// 逻辑链路:
			// 1. 函数入口检查 contractInfo.RelateQuoteNo != ""。
			// 2. 条件成立，函数直接返回 nil。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "Q20240101",
			}

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 非项目制合同，不执行校验", func() {
			// 场景描述:
			// 合同的 WhetherProject 字段不为 "Y"，不执行项目制信息校验，直接返回nil。
			// 构造数据:
			// contractInfo.RelateQuoteNo 为空, BasicInfo.WhetherProject 设置为 "N"。
			// 逻辑链路:
			// 1. 函数入口检查 contractInfo.RelateQuoteNo，条件不成立。
			// 2. 进入后续逻辑，两个if条件中的 contractInfo.BasicInfo.WhetherProject == _const.Yes 均为 false。
			// 3. 函数未发现任何缺失字段，返回 nil。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.IN,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.No,
				},
				ProjectInfo: &bizmodels.ProjectInfo{},
			}

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 收入类项目制合同，必填字段均已提供", func() {
			// 场景描述:
			// 收支类型为收入类，且为项目制合同，所有必填的项目信息均已提供，校验通过。
			// 构造数据:
			// - InOutType: _const.IN
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: 包含所有必填字段 (QuoteID, QuoteApprovalLink, ProjectCode, ProjectApprovalLink)
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. 两个if条件中的 contractInfo.BasicInfo.WhetherProject == _const.Yes 均为 true。
			// 3. Mock utils.StringIn 第一次返回 true，进入收入类校验逻辑，第二次返回 false。
			// 4. 检查所有必填字段，发现均不为空。
			// 5. missingFields 列表为空，函数返回 nil。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.IN,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					QuoteID:             "quote_id_123",
					QuoteApprovalLink:   "quote_link_123",
					ProjectCode:         "project_code_123",
					ProjectApprovalLink: "project_link_123",
				},
			}

			mockey.Mock(utils.StringIn).Return(mockey.Sequence(true).Then(false)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 收入类项目制合同，缺少部分必填字段", func() {
			// 场景描述:
			// 收支类型为既收又支，且为项目制合同，缺少"项目制报价单编号"和"项目编号"，校验失败。
			// 构造数据:
			// - InOutType: _const.InAndOut
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: QuoteID 和 ProjectCode 为空。
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. Mock utils.StringIn 第一次返回 true，第二次返回 false，进入收入类校验逻辑。
			// 3. 检查发现 QuoteID 和 ProjectCode 为空，将 "项目制报价单编号" 和 "项目编号" 加入 missingFields。
			// 4. missingFields 列表不为空，返回带参数的 ErrMissingParam 错误。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.InAndOut,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					QuoteID:             "",
					QuoteApprovalLink:   "quote_link_123",
					ProjectCode:         "",
					ProjectApprovalLink: "project_link_123",
				},
			}
			mockey.Mock(utils.StringIn).Return(mockey.Sequence(true).Then(false)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制报价单编号")
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目编号")
			convey.So(err.Error(), convey.ShouldNotContainSubstring, "项目制报价流程")
		})

		mockey.PatchConvey("场景5: 支出类项目制合同，必填字段均已提供", func() {
			// 场景描述:
			// 收支类型为支出类，且为项目制合同，所有必填的项目信息均已提供，校验通过。
			// 构造数据:
			// - InOutType: _const.OUT
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: 包含所有必填字段 (ProjectCode, ProjectApprovalLink)
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. Mock utils.StringIn 第一次返回 false，第二次返回 true，进入支出类校验逻辑。
			// 3. 检查所有必填字段，发现均不为空。
			// 4. missingFields 列表为空，函数返回 nil。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.OUT,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					ProjectCode:         "project_code_123",
					ProjectApprovalLink: "project_link_123",
				},
			}
			mockey.Mock(utils.StringIn).Return(mockey.Sequence(false).Then(true)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景6: 支出类项目制合同，缺少部分必填字段", func() {
			// 场景描述:
			// 收支类型为无收无支，且为项目制合同，缺少"项目制立项流程"，校验失败。
			// 构造数据:
			// - InOutType: _const.NoInNoOut
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: ProjectApprovalLink 为空。
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. Mock utils.StringIn 第一次返回 false，第二次返回 true，进入支出类校验逻辑。
			// 3. 检查发现 ProjectApprovalLink 为空，将 "项目制立项流程" 加入 missingFields。
			// 4. missingFields 列表不为空，返回带参数的 ErrMissingParam 错误。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.NoInNoOut,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{
					ProjectCode:         "project_code_123",
					ProjectApprovalLink: "",
				},
			}
			mockey.Mock(utils.StringIn).Return(mockey.Sequence(false).Then(true)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制立项流程")
			convey.So(err.Error(), convey.ShouldNotContainSubstring, "项目编号")
		})

		mockey.PatchConvey("场景7: 收入类项目制合同，所有必填字段均缺失", func() {
			// 场景描述:
			// 收支类型为收入类，且为项目制合同，所有四个必填字段均缺失，校验失败并返回所有缺失字段。
			// 构造数据:
			// - InOutType: _const.IN
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: 为空结构体。
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. Mock utils.StringIn 第一次返回 true，第二次返回 false，进入收入类校验逻辑。
			// 3. 检查所有必填字段，发现均为空，将四个字段名加入 missingFields。
			// 4. missingFields 列表不为空，返回包含所有四个字段名的错误信息。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo: "",
				InOutType:     _const.IN,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{},
			}
			mockey.Mock(utils.StringIn).Return(mockey.Sequence(true).Then(false)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制报价单编号")
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制报价流程")
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目编号")
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目制立项流程")
			// 验证错误信息由所有缺失字段组成
			convey.So(err, convey.ShouldResemble, errorsV2.ErrMissingParam.WithArgs(strings.Join([]string{"项目制报价单编号", "项目制报价流程", "项目编号", "项目制立项流程"}, "、")))
		})
		mockey.PatchConvey("场景7: 收入类项目制合同，关联报价单情况为未完成报价审批，所有必填字段均缺失，不校验", func() {
			// 场景描述:
			// 收支类型为收入类，且为项目制合同，所有四个必填字段均缺失，校验失败并返回所有缺失字段。
			// 构造数据:
			// - InOutType: _const.IN
			// - BasicInfo.WhetherProject: _const.Yes
			// - ProjectInfo: 为空结构体。
			// 逻辑链路:
			// 1. RelateQuoteNo 为空，继续执行。
			// 2. Mock utils.StringIn 第一次返回 true，第二次返回 false，进入收入类校验逻辑。
			// 3. 检查所有必填字段，发现均为空，将四个字段名加入 missingFields。
			// 4. missingFields 列表不为空，返回包含所有四个字段名的错误信息。
			ctx := context.Background()
			contractInfo := &model.ContractMeta{
				RelateQuoteNo:    "",
				RelateQuoteScene: 1,
				InOutType:        _const.IN,
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject: _const.Yes,
				},
				ProjectInfo: &bizmodels.ProjectInfo{},
			}
			mockey.Mock(utils.StringIn).Return(mockey.Sequence(true).Then(false)).Build()

			err := validateProjectInfo(ctx, contractInfo)

			convey.So(err, convey.ShouldBeNil)
		})
	})

}

func Test_handlerCommon_commonCheckReviewerPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.commonCheckReviewerPass", t, func() {
		// Arrange
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景：成功，没有更高优先级的待审批人", func() {
			// 场景描述：
			// 存在前置审批人检查成功，因为DAL层返回了一个空的待审批人列表。
			// 构造数据：
			// - pc.ContractInfo 包含一个合同号
			// - currentReviewer 有基本的审批人信息
			// 逻辑链路：
			// 1. pc.GetCurrentReviewer() 返回一个模拟的当前审批人
			// 2. pc.GetTx() 返回一个模拟的 *gorm.DB 实例
			// 3. dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个空的审批人列表(model.PreContractReviewerDBList{})和nil错误
			// 4. 函数判断列表长度为0，直接返回nil

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT-001",
				},
			}
			currentReviewer := &bizmodels.PreContractReviewer{
				ReviewerType:   1,
				ContractStatus: 1,
				Priority:       10,
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(model.PreContractReviewerDBList{}, nil).Build()

			// Act
			err := h.commonCheckReviewerPass(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：失败，DAL层返回错误", func() {
			// 场景描述：
			// 在查询更高优先级的待审批人时，数据库操作失败。
			// 构造数据：
			// - pc.ContractInfo 包含一个合同号
			// - currentReviewer 有基本的审批人信息
			// - dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个非nil的error
			// 逻辑链路：
			// 1. pc.GetCurrentReviewer() 返回一个模拟的当前审批人
			// 2. pc.GetTx() 返回一个模拟的 *gorm.DB 实例
			// 3. dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个错误
			// 4. 函数捕获到错误，调用i18nfmt.New生成新的错误并返回

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT-002",
				},
			}
			currentReviewer := &bizmodels.PreContractReviewer{
				ReviewerType:   2,
				ContractStatus: 2,
				Priority:       20,
			}
			dbError := errors.New("database query error")
			expectedErr := errors.New("检查节点审批结果失败")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(nil, dbError).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			// Act
			err := h.commonCheckReviewerPass(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
		})

		mockey.PatchConvey("场景：失败，存在更高优先级的待审批人", func() {
			// 场景描述：
			// 检查发现存在一个或多个更高优先级的待审批人尚未完成审批。
			// 构造数据：
			// - pc.ContractInfo 包含一个合同号
			// - currentReviewer 有基本的审批人信息
			// - dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个包含两个待审批人的列表
			// 逻辑链路：
			// 1. pc.GetCurrentReviewer() 返回一个模拟的当前审批人
			// 2. pc.GetTx() 返回一个模拟的 *gorm.DB 实例
			// 3. dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个非空列表
			// 4. 函数遍历列表，拼接待审批人姓名
			// 5. 调用i18nfmt.Sprintf生成错误信息
			// 6. 调用logs.CtxInfo记录日志
			// 7. 使用fmt.Errorf返回最终错误

			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT-003",
				},
			}
			currentReviewer := &bizmodels.PreContractReviewer{
				ReviewerType:   3,
				ContractStatus: 3,
				Priority:       30,
			}
			noPassReviewers := model.PreContractReviewerDBList{
				{Reviewer: "user.a"},
				{Reviewer: "user.b"},
			}
			expectedErrMsg := "存在前置审批人未审批通过，请等待前加签审批人审核通过后再操作。前置待审核人：user.a、user.b"

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(noPassReviewers, nil).Build()
			mockey.Mock(logs.CtxInfo).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				// 模拟i18n格式化，直接使用fmt.Sprintf
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			err := h.commonCheckReviewerPass(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErrMsg)
		})
	})
}

func Test_handlerCommon_updateContractReviewers_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock type for dal.PreContractReviewerDao interface
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	h := &handlerCommon{}
	ctx := context.Background()
	mockTx := &gorm.DB{}

	mockey.PatchConvey("Test_handlerCommon_updateContractReviewers", t, func() {
		mockey.PatchConvey("Success: first-time update, create sales_op and ftl reviewers", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-001",
					Operator:   "operator_id_1",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_1",
						InOutType:            "支出",
						CategoryNo:           "C01",
					},
					ProjectInfo: nil,
				},
				ApprovalKey: _const.ApprovalKeyDefault,
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR+法务BP", nil).Build()

			mockey.Mock(_const.GetReviewerRoleName).When(func(value int) bool {
				return value == _const.ReviewerRoleSalesOp
			}).Return("销售运营").Build()

			reviewerMappings := map[string]string{
				"财务AR": "ar@example.com",
				"法务BP": "legal@example.com",
				"销售运营": "salesop@example.com",
			}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()

			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"ar@example.com", "legal@example.com", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return(nil).Build()

			employeeMappings := map[string]*peopleclient.Employee{
				"ar@example.com":      {ID: 101, Email: "ar@example.com"},
				"legal@example.com":   {ID: 102, Email: "legal@example.com"},
				"salesop@example.com": {ID: 103, Email: "salesop@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()

			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				switch name {
				case "财务AR":
					return _const.ReviewerRoleFinanceAR
				case "法务BP":
					return _const.ReviewerRoleLegalBP
				case "销售运营":
					return _const.ReviewerRoleSalesOp
				}
				return 0
			}).Build()

			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(nil).Build()
			mockey.Mock((*model.PreContractReviewerDB).GenResp).To(func(db *model.PreContractReviewerDB) *bizmodels.PreContractReviewer {
				return &bizmodels.PreContractReviewer{Reviewer: db.Reviewer}
			}).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(pc.ContractInfo.Reviewers), convey.ShouldBeGreaterThan, 0)
		})

		mockey.PatchConvey("Success: with solution reviewer", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			solutionEmail := "solution@example.com"
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-002",
					Operator:   "operator_id_2",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_2",
					},
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of(solutionEmail),
					},
				},
				ApprovalKey: _const.ApprovalKeyDefaultWithSolution,
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).Return("销售运营").Build()

			reviewerMappings := map[string]string{
				"财务AR": "ar@example.com",
				"销售运营": "salesop@example.com",
			}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()
			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"ar@example.com", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return([]string{solutionEmail}).Build()

			employeeMappings := map[string]*peopleclient.Employee{
				"ar@example.com":       {ID: 101, Email: "ar@example.com"},
				"salesop@example.com":  {ID: 103, Email: "salesop@example.com"},
				"solution@example.com": {ID: 104, Email: "solution@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).Return(0).Build()

			var createdReviewers []*model.PreContractReviewerDB
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, list []*model.PreContractReviewerDB) error {
				createdReviewers = list
				return nil
			}).Build()
			mockey.Mock((*model.PreContractReviewerDB).GenResp).To(func(db *model.PreContractReviewerDB) *bizmodels.PreContractReviewer {
				return &bizmodels.PreContractReviewer{Reviewer: db.Reviewer, ReviewerType: db.ReviewerType}
			}).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			hasSolutionReviewer := false
			for _, r := range createdReviewers {
				if r.ReviewerType == _const.ReviewerTypeSolutionReviewer && r.Reviewer == solutionEmail {
					hasSolutionReviewer = true
					break
				}
			}
			convey.So(hasSolutionReviewer, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("Success: multiple reviewers for one role", func() {
			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-MULTI-001",
					Operator:   "operator_id_multi",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_multi",
					},
				},
				ApprovalKey: _const.ApprovalKeyDefault,
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).When(func(value int) bool {
				return value == _const.ReviewerRoleSalesOp
			}).Return("销售运营").Build()

			reviewerMappings := map[string]string{
				"财务AR": "ar1@example.com,ar2@example.com",
				"销售运营": "salesop@example.com",
			}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()

			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"ar1@example.com", "ar2@example.com", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return(nil).Build()

			employeeMappings := map[string]*peopleclient.Employee{
				"ar1@example.com":     {ID: 201, Email: "ar1@example.com"},
				"ar2@example.com":     {ID: 202, Email: "ar2@example.com"},
				"salesop@example.com": {ID: 103, Email: "salesop@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()

			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				switch name {
				case "财务AR":
					return _const.ReviewerRoleFinanceAR
				case "销售运营":
					return _const.ReviewerRoleSalesOp
				}
				return 0
			}).Build()

			var createdReviewers []*model.PreContractReviewerDB
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, list []*model.PreContractReviewerDB) error {
				createdReviewers = list
				return nil
			}).Build()

			mockey.Mock((*model.PreContractReviewerDB).GenResp).To(func(db *model.PreContractReviewerDB) *bizmodels.PreContractReviewer {
				return &bizmodels.PreContractReviewer{Reviewer: db.Reviewer}
			}).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)

			// Default statuses for FTL: 2; for SalesOp: 3.
			// Total reviewers = (2 FTL reviewers * 2 statuses) + (1 SalesOp reviewer * 3 statuses) = 7
			// We can simply check the total count or be more specific.
			ftlCount := 0
			salesOpCount := 0
			for _, r := range createdReviewers {
				if r.ReviewerType == _const.ReviewerTypeFinanceTaxationLegalReviewer {
					if r.Reviewer == "ar1@example.com" || r.Reviewer == "ar2@example.com" {
						ftlCount++
					}
				}
				if r.ReviewerType == _const.ReviewerTypeSalesOperation {
					if r.Reviewer == "salesop@example.com" {
						salesOpCount++
					}
				}
			}
			convey.So(ftlCount, convey.ShouldEqual, 4)     // 2 FTL reviewers * 2 statuses each
			convey.So(salesOpCount, convey.ShouldEqual, 3) // 1 SalesOp reviewer * 3 statuses
		})

		mockey.PatchConvey("Early Exit: reviewers already exist", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-003",
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()

			existingReviewersDB := model.PreContractReviewerDBList{{Reviewer: "salesop@example.com", ReviewerType: _const.ReviewerTypeSalesOperation}}
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(existingReviewersDB, nil).Build()

			existingReviewersBiz := bizmodels.PreContractReviewerList{{Reviewer: "salesop@example.com", ReviewerType: _const.ReviewerTypeSalesOperation}}
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(existingReviewersBiz).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int) bool {
					return reviewerType == _const.ReviewerTypeSalesOperation
				}).Return([]string{"salesop@example.com"}).
				When(func(list bizmodels.PreContractReviewerList, reviewerType int) bool {
					return reviewerType == _const.ReviewerTypeFinanceTaxationLegalReviewer
				}).Return([]string{}).
				Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(pc.ContractInfo.Reviewers), convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("Error: FindReviewersByNo fails", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{ContractNo: "TEST-CONTRACT-004"},
			}
			dbErr := errors.New("db find error")
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, dbErr).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db find error")
		})

		mockey.PatchConvey("Error: missing contract template type", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-005",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: nil,
					},
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同模板类型缺失")
		})

		mockey.PatchConvey("Error: MatchFTLRule returns no roles", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-006",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
					},
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()

			mockey.Mock(ruleengine.MatchFTLRule).Return("", nil).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(i18nfmt.Sprintf).Return("formatted warning string").Build()
			mockey.Mock(utils.ContractTemplateType2String).Return("some type").Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "无此合同对应的财税法审核角色")
		})

		mockey.PatchConvey("Error: getAndValidateReviewerMappings fails", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-007",
					Operator:   "operator_id_3",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_3",
					},
				},
			}
			validateErr := errors.New("validate reviewer mappings error")
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).Return("销售运营").Build()
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(nil, validateErr).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "validate reviewer mappings error")
		})

		mockey.PatchConvey("Error: employee not found in lark", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-009",
					Operator:   "operator_id_4",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_4",
					},
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).Return("销售运营").Build()
			reviewerMappings := map[string]string{
				"财务AR": "ar.missing@example.com",
				"销售运营": "salesop@example.com",
			}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()
			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"ar.missing@example.com", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return(nil).Build()

			employeeMappings := map[string]*peopleclient.Employee{
				"salesop@example.com": {ID: 103, Email: "salesop@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).Return(_const.ReviewerRoleFinanceAR).Build()
			mockey.Mock(i18nfmt.Sprintf).When(func(ctx context.Context, format string, a ...interface{}) bool {
				return format == "查询用户[%s]信息失败, 无法新增审批"
			}).Return("查询用户[ar.missing@example.com]信息失败, 无法新增审批").Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询用户[ar.missing@example.com]信息失败, 无法新增审批")
		})

		mockey.PatchConvey("Error: BatchCreate fails", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-011",
					Operator:   "operator_id_5",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_5",
					},
				},
			}
			dbErr := errors.New("db batch create error")
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).Return("销售运营").Build()
			reviewerMappings := map[string]string{"财务AR": "ar@example.com", "销售运营": "salesop@example.com"}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()
			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"ar@example.com", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return(nil).Build()
			employeeMappings := map[string]*peopleclient.Employee{
				"ar@example.com":      {ID: 101, Email: "ar@example.com"},
				"salesop@example.com": {ID: 103, Email: "salesop@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).Return(0).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(dbErr).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("创建审批操作条目失败")).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建审批操作条目失败")
		})

		mockey.PatchConvey("Error: role has no configured reviewer", func() {

			templateType := _const.ContractTemplateTypeOurNoModify
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-012",
					Operator:   "operator_id_6",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dep_id_6",
					},
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(&MockPreContractReviewerDao{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(bizmodels.PreContractReviewerList{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(ruleengine.MatchFTLRule).Return("财务BP", nil).Build()
			mockey.Mock(_const.GetReviewerRoleName).Return("销售运营").Build()

			reviewerMappings := map[string]string{
				"财务BP": "", // No reviewer configured
				"销售运营": "salesop@example.com",
			}
			mockey.Mock((*handlerCommon).getAndValidateReviewerMappings).Return(reviewerMappings, nil).Build()
			// collectEmails will contain an empty string
			mockey.Mock((*handlerCommon).collectEmails).Return([]string{"", "salesop@example.com"}).Build()
			mockey.Mock((*model.ContractMeta).GetProductSolutionEmails).Return(nil).Build()

			// BatchListHireEmployeesByEmails will not find the empty email
			employeeMappings := map[string]*peopleclient.Employee{
				"salesop@example.com": {ID: 103, Email: "salesop@example.com"},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(employeeMappings, nil).Build()

			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				if name == "财务BP" {
					return _const.ReviewerRoleFinanceBP
				}
				return _const.ReviewerRoleSalesOp
			}).Build()

			// Mock Sprintf to return the expected error message for an empty user
			mockey.Mock(i18nfmt.Sprintf).When(func(ctx context.Context, format string, a ...interface{}) bool {
				return format == "查询用户[%s]信息失败, 无法新增审批"
			}).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf("查询用户[%s]信息失败, 无法新增审批", a[0])
			}).Build()

			err := h.updateContractReviewers(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			// The error comes from not finding the employee for the empty email string
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询用户[]信息失败, 无法新增审批")
		})
	})
}

func Test_handlerCommon_buildNewestProcessFileInfo_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test_handlerCommon_buildNewestProcessFileInfo", t, func() {
		mockey.PatchConvey("success case - with multiple file IDs", func() {
			// 场景描述：
			// 提供一个包含多个文件ID的列表，模拟filecli.GetNewestVersion对每个ID都成功返回最新版本信息。
			// 构造数据：
			// fileIDList: ["file-id-1", "file-id-2"]
			// 逻辑链路：
			// 1. 函数遍历文件ID列表。
			// 2. 对每个文件ID，mockey模拟的filecli.GetNewestVersion调用成功，并返回预设的版本信息。
			// 3. 函数解析时间字符串并构造ProcessFileInfo结构体。
			// 4. 所有文件都处理成功，最终返回一个包含所有文件信息的二维切片和nil错误。

			fileIDList := []string{"file-id-1", "file-id-2"}
			mockTimeStr1 := "2023-10-26T08:00:00Z"
			mockTimeStr2 := "2023-10-27T09:00:00Z"
			parsedTime1, _ := time.Parse(time.RFC3339, mockTimeStr1)
			parsedTime2, _ := time.Parse(time.RFC3339, mockTimeStr2)

			mockey.Mock(filecli.GetNewestVersion).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "file-id-1"
				}).
				Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{
						ID:         "file-id-1",
						Name:       "test_file_1.docx",
						Version:    "3",
						ModifiedAt: mockTimeStr1,
					},
				}, nil).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "file-id-2"
				}).
				Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{
						ID:         "file-id-2",
						Name:       "test_file_2.pdf",
						Version:    "5",
						ModifiedAt: mockTimeStr2,
					},
				}, nil).
				Build()

			res, err := h.buildNewestProcessFileInfo(ctx, fileIDList)

			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 2)

			// Check first file info
			convey.So(len(res[0]), convey.ShouldEqual, 1)
			convey.So(res[0][0].FileType, convey.ShouldEqual, _const.ProcessFileTypePending)
			convey.So(res[0][0].FileID, convey.ShouldEqual, "file-id-1")
			convey.So(res[0][0].FileName, convey.ShouldEqual, "test_file_1.docx")
			convey.So(res[0][0].Version, convey.ShouldEqual, "3")
			convey.So(res[0][0].ModifyAt.Equal(parsedTime1), convey.ShouldBeTrue)

			// Check second file info
			convey.So(len(res[1]), convey.ShouldEqual, 1)
			convey.So(res[1][0].FileType, convey.ShouldEqual, _const.ProcessFileTypePending)
			convey.So(res[1][0].FileID, convey.ShouldEqual, "file-id-2")
			convey.So(res[1][0].FileName, convey.ShouldEqual, "test_file_2.pdf")
			convey.So(res[1][0].Version, convey.ShouldEqual, "5")
			convey.So(res[1][0].ModifyAt.Equal(parsedTime2), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("failure case - GetNewestVersion returns error", func() {
			// 场景描述：
			// 模拟filecli.GetNewestVersion调用时返回错误，测试函数是否能正确处理并向上传播错误。
			// 构造数据：
			// fileIDList: ["file-id-1"]
			// Mock Error: "rpc error"
			// 逻辑链路：
			// 1. 函数遍历文件ID列表。
			// 2. 对第一个文件ID，mockey模拟的filecli.GetNewestVersion调用返回一个错误。
			// 3. 函数捕获到错误，记录日志，并立即返回nil和该错误。

			fileIDList := []string{"file-id-1"}
			mockErr := errors.New("rpc error")

			mockey.Mock(filecli.GetNewestVersion).Return(nil, mockErr).Build()

			res, err := h.buildNewestProcessFileInfo(ctx, fileIDList)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
			convey.So(res, convey.ShouldBeNil)
		})

		mockey.PatchConvey("edge case - empty fileIDList", func() {
			// 场景描述：
			// 输入的文件ID列表为空，测试函数是否能正常处理这种情况。
			// 构造数据：
			// fileIDList: []
			// 逻辑链路：
			// 1. 函数接收到空的文件ID列表。
			// 2. for循环不会执行。
			// 3. 函数直接返回一个空的（nil）二维切片和nil错误。

			fileIDList := []string{}

			res, err := h.buildNewestProcessFileInfo(ctx, fileIDList)

			convey.So(err, convey.ShouldBeNil)
			// var res [][]*... is initialized to a nil slice, which is returned directly
			convey.So(res, convey.ShouldBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerCommon_checkTradePartyInfoForQuote_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_checkTradePartyInfoForQuote", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景：成功-国内环境，交易对方信息校验通过", func() {
			// 场景描述：
			// 构造数据：构造一个包含两个逗号分隔AccountID的交易对方信息，且PartyName与账号实名认证名称一致。
			// 逻辑链路：
			// 1. 交易对方信息非空，进入循环。
			// 2. AccountID非空，通过split分割成两个ID。
			// 3. 循环两次，每次都成功解析AccountID。
			// 4. Mock accountcli.GetAccountAndVerifyFromCache 返回与PartyName一致的VerifyName。
			// 5. Mock multienv.IsBytePlus 返回 false，进入国内环境的实名校验逻辑。
			// 6. 校验通过，函数最终返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: "12345,67890",
								PartyName: "Test Company",
							},
						},
					},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{
				VerifyName: "Test Company",
			}, nil).Build()

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功-海外环境，跳过实名校验", func() {
			// 场景描述：
			// 构造数据：构造一个交易对方信息，其PartyName与账号实名认证名称不一致。
			// 逻辑链路：
			// 1. 交易对方信息非空，进入循环。
			// 2. AccountID非空，成功解析。
			// 3. Mock accountcli.GetAccountAndVerifyFromCache 返回有效的账号信息。
			// 4. Mock multienv.IsBytePlus 返回 true，进入海外环境逻辑。
			// 5. 函数直接返回nil，不进行实名校验。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: "12345",
								PartyName: "Different Name",
							},
						},
					},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{
				VerifyName: "Test Company",
			}, nil).Build()

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：失败-交易对方信息为空(TradePartyInfo为nil)", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中的ContractInfo.TradePartyInfo为nil。
			// 逻辑链路：
			// 1. 函数入口处检查到TradePartyInfo为nil，直接返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: nil,
				},
			}

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "交易对方信息为空")
		})

		mockey.PatchConvey("场景：失败-交易对方信息为空(OtherParty为空数组)", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中的TradePartyInfo.OtherParty为空数组。
			// 逻辑链路：
			// 1. 函数入口处检查到OtherParty长度为0，直接返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{},
					},
				},
			}

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "交易对方信息为空")
		})

		mockey.PatchConvey("场景：失败-AccountID为空字符串", func() {
			// 场景描述：
			// 构造数据：交易对方信息中的AccountID为空字符串。
			// 逻辑链路：
			// 1. 进入循环，检查到v.AccountID为空，返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: "",
								PartyName: "Test Company",
							},
						},
					},
				},
			}

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "交易对方信息AccountID为空")
		})

		mockey.PatchConvey("场景：失败-AccountID格式异常", func() {
			// 场景描述：
			// 构造数据：交易对方信息中的AccountID为非数字字符串 "abc"。
			// 逻辑链路：
			// 1. 进入循环，解析AccountID时strconv.ParseInt失败，返回错误。
			// 2. Mock i18nfmt.Sprintf返回预期的错误信息。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: "abc",
								PartyName: "Test Company",
							},
						},
					},
				},
			}
			mockey.Mock(i18nfmt.Sprintf).Return("交易对方信息AccountID[abc]异常").Build()

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "交易对方信息AccountID[abc]异常")
		})

		mockey.PatchConvey("场景：失败-账号信息不存在", func() {
			// 场景描述：
			// 构造数据：构造一个有效的AccountID。
			// 逻辑链路：
			// 1. 成功解析AccountID。
			// 2. Mock accountcli.GetAccountAndVerifyFromCache 返回nil, nil，表示未找到账号。
			// 3. 函数判断accountInfo为nil，返回错误。
			// 4. Mock i18nfmt.Sprintf返回预期的错误信息。
			accountID := int64(99999)
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: fmt.Sprintf("%d", accountID),
								PartyName: "Test Company",
							},
						},
					},
				},
			}
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(nil, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(fmt.Sprintf("交易对方信息AccountID[%d]账号信息不存在", accountID)).Build()

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("交易对方信息AccountID[%d]账号信息不存在", accountID))
		})

		mockey.PatchConvey("场景：失败-实名认证名称不一致", func() {
			// 场景描述：
			// 构造数据：交易对方的PartyName与Mock返回的实名认证名称VerifyName不一致。
			// 逻辑链路：
			// 1. 成功解析AccountID，并获取到账号信息。
			// 2. Mock multienv.IsBytePlus 返回false，进入国内环境校验逻辑。
			// 3. 比较accountInfo.VerifyName和v.PartyName，发现不一致，返回错误。
			// 4. Mock i18nfmt.Sprintf返回预期的错误信息。
			idStr := "12345"
			inputName := "Input Party Name"
			verifyName := "Verified Name"
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								AccountID: idStr,
								PartyName: inputName,
							},
						},
					},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{
				VerifyName: verifyName,
			}, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(fmt.Sprintf("交易对方信息AccountID[%s]实名认证名称[%s]与参数信息[%s]不一致", idStr, verifyName, inputName)).Build()

			err := h.checkTradePartyInfoForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("交易对方信息AccountID[%s]实名认证名称[%s]与参数信息[%s]不一致", idStr, verifyName, inputName))
		})
	})
}

func Test_handlerCommon_reviewPassSendReviewedMessage_BitsUTGen(t *testing.T) {
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}
	mockey.PatchConvey("Test handlerCommon reviewPassSendReviewedMessage", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:     "test-contract-no",
				PreContractNo:  "pre-test-contract-no",
				ContractName:   "test-contract-name",
				OtherPartyName: "test-customer",
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
			},
		}
		currentReviewer := &bizmodels.PreContractReviewer{
			ReviewerType:   _const.ReviewerTypeSalesOperation,
			ContractStatus: 1,
			Priority:       1,
		}

		mockey.PatchConvey("场景1: 获取同优先级未审核人列表失败", func() {
			// 场景描述:
			// 调用 dal.ListNotPassedReviewerByPriority 时返回数据库错误。
			// 构造数据:
			// - pc.GetCurrentReviewer() 返回一个有效的审核人信息
			// - dal.ListNotPassedReviewerByPriority 返回一个错误
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer() 成功获取当前审核人。
			// 2. pc.GetTx() 成功获取事务对象。
			// 3. dal.ListNotPassedReviewerByPriority 返回错误。
			// 4. 函数应立即将此错误返回。
			mockErr := errors.New("db error")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListNotPassedReviewerByPriority).Return(nil, mockErr).Build()

			err := h.reviewPassSendReviewedMessage(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db error")
		})

		mockey.PatchConvey("场景2: 存在同优先级未审核通过的审核人，不发送消息", func() {
			// 场景描述:
			// 当前审核节点还有其他同优先级的审核人未完成审核，因此不应向下一节点发送消息。
			// 构造数据:
			// - dal.ListNotPassedReviewerByPriority 返回一个包含一个或多个审核人的非空列表。
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer() 成功获取当前审核人。
			// 2. pc.GetTx() 成功获取事务对象。
			// 3. dal.ListNotPassedReviewerByPriority 返回非空列表，表示存在同级未审核人。
			// 4. 函数进入 if len(list) > 0 分支，记录日志并直接返回 nil。
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListNotPassedReviewerByPriority).Return(model.PreContractReviewerDBList{{}}, nil).Build()

			err := h.reviewPassSendReviewedMessage(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 获取所有审核人列表失败", func() {
			// 场景描述:
			// 在确定没有同级未审核人后，尝试获取合同的所有审核人列表时发生数据库错误。
			// 构造数据:
			// - dal.ListNotPassedReviewerByPriority 返回空列表。
			// - dal.NewPreContractReviewerDao().FindReviewersByNo 返回错误。
			// 逻辑链路:
			// 1. dal.ListNotPassedReviewerByPriority 成功并返回空列表。
			// 2. dal.NewPreContractReviewerDao() 返回一个 mock DAO 实例。
			// 3. 在 mock DAO 实例上调用 FindReviewersByNo 返回错误。
			// 4. 函数记录错误日志并返回该错误。
			mockErr := errors.New("find reviewers error")
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListNotPassedReviewerByPriority).Return(nil, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, mockErr).Build()

			err := h.reviewPassSendReviewedMessage(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "find reviewers error")
		})

		mockey.PatchConvey("场景4: 成功发送待审核消息", func() {
			// 场景描述:
			// 所有前置检查均通过，成功构建飞书消息卡片并调用发送接口。
			// 构造数据:
			// - 所有依赖的数据库查询和外部服务调用均被 Mock 为成功返回。
			// 逻辑链路:
			// 1. dal.ListNotPassedReviewerByPriority 返回空列表，表示无同级未审核人。
			// 2. dal.NewPreContractReviewerDao().FindReviewersByNo 成功返回所有审核人列表。
			// 3. 内部辅助方法 getUnReviewedReviewer... 和 getReviewerFromPreContractReviewerList 被 Mock 以返回预期的接收人列表。
			// 4. 构建消息卡片的依赖（如 I18n, Sprintf, GenReviewURL）均被 Mock。
			// 5. larkc.BatchSendMessageToEmailIgnore 被成功调用。
			// 6. 函数最终返回 nil。
			reviewersDB := model.PreContractReviewerDBList{
				{Reviewer: "next.reviewer@example.com"},
			}
			reviewersBiz := bizmodels.PreContractReviewerList{
				{Reviewer: "next.reviewer@example.com"},
			}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListNotPassedReviewerByPriority).Return(nil, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(reviewersDB, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(reviewersBiz).Build()
			mockey.Mock((*handlerCommon).getUnReviewedReviewerWithContractStatusAndBelowPriority).Return([]string{"next.reviewer@example.com"}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url/test-contract-no").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.reviewPassSendReviewedMessage(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_handleQuoteChangeWhenSubmit_BitsUTGen(t *testing.T) {
	// MockQuoteService is a helper struct for mocking the quoteservice.Service interface.
	type MockQuoteService struct {
		quoteservice.Service
	}

	mockey.PatchConvey("Test_handlerCommon_handleQuoteChangeWhenSubmit", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("should return nil when ContractInfo.BasicInfo is nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.ContractInfo.BasicInfo为nil。
			// 逻辑链路：
			// 1. 函数执行到第一个if条件 `pc.ContractInfo.BasicInfo == nil`。
			// 2. 条件成立，函数直接返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: nil,
				},
			}

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when CalcRequireQuote returns false", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.ContractInfo.BasicInfo不为nil。
			// 逻辑链路：
			// 1. 函数执行到第二个if条件 `!pc.ContractInfo.CalcRequireQuote()`。
			// 2. Mock ContractInfo.CalcRequireQuote() 方法返回false。
			// 3. 条件成立，函数直接返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(false).Build()

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success path when GetQuoteChangeInfo returns nil", func() {
			// 场景描述：
			// 构造数据：一个需要关联报价单的合同上下文，且Redis中没有该合同的报价变更信息。
			// 逻辑链路：
			// 1. CalcRequireQuote返回true，函数继续执行。
			// 2. Mock rediscli.GetQuoteChangeInfo 返回 (nil, nil)，表示没有找到变更信息。
			// 3. relateQuoteChangedBefore 变量将保持为空字符串。
			// 4. Mock rediscli.SetQuoteChangeInfoFlag 成功，设置新的报价信息，其中RelateQuoteChangedBefore为空。
			// 5. Mock quoteservice.NewService().BindQuote 成功。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:    "CONTRACT_NO_1",
					RelateQuoteNo: "QUOTE_NO_1",
					BasicInfo:     &bizmodels.BasicInfo{},
				},
			}

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(nil).Build()
			mockSvc := &MockQuoteService{}
			mockey.Mock(quoteservice.NewService).Return(mockSvc).Build()
			mockey.Mock(quotecli.ChangeQuoteContract).Return(nil).Build()

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success path when quote has changed", func() {
			// 场景描述：
			// 构造数据：合同关联的报价单发生了变更，新报价单为 "QUOTE_NEW"，Redis中记录的旧报价单为 "QUOTE_OLD"。
			// 逻辑链路：
			// 1. CalcRequireQuote返回true。
			// 2. Mock rediscli.GetQuoteChangeInfo 返回包含旧报价单号 "QUOTE_OLD" 的信息。
			// 3. if条件 `changeInfo.RelateQuoteChangedBefore != quoteNo` 成立，relateQuoteChangedBefore被赋值为 "QUOTE_OLD"。
			// 4. Mock rediscli.SetQuoteChangeInfoFlag 成功，设置新的报价信息，其中RelateQuoteChangedBefore为 "QUOTE_OLD"。
			// 5. Mock quoteservice.NewService().BindQuote 成功。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:    "CONTRACT_NO_2",
					RelateQuoteNo: "QUOTE_NEW",
					BasicInfo:     &bizmodels.BasicInfo{},
				},
			}
			changeInfo := &bizmodels.QuoteChangeInfo{
				RelateQuoteNo:            "QUOTE_OLD",
				RelateQuoteChangedBefore: "SOME_OTHER_QUOTE",
			}

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(changeInfo, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).When(func(ctx context.Context, contractNo string, info *bizmodels.QuoteChangeInfo) bool {
				return contractNo == "CONTRACT_NO_2" && info.RelateQuoteNo == "QUOTE_NEW" && info.RelateQuoteChangedBefore == "QUOTE_OLD"
			}).Return(nil).Build()
			mockSvc := &MockQuoteService{}
			mockey.Mock(quoteservice.NewService).Return(mockSvc).Build()
			mockey.Mock(quotecli.ChangeQuoteContract).Return(nil).Build()

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success path when quote has not changed", func() {
			// 场景描述：
			// 构造数据：合同关联的报价单未发生变更，Redis中记录的RelateQuoteChangedBefore与当前报价单号相同。
			// 逻辑链路：
			// 1. CalcRequireQuote返回true。
			// 2. Mock rediscli.GetQuoteChangeInfo 返回一个changeInfo，其RelateQuoteChangedBefore与当前报价单号 "QUOTE_NO_3" 相同。
			// 3. if条件 `changeInfo.RelateQuoteChangedBefore != quoteNo` 不成立，relateQuoteChangedBefore保持为空字符串。
			// 4. Mock rediscli.SetQuoteChangeInfoFlag 成功，设置新的报价信息，其中RelateQuoteChangedBefore为空字符串。
			// 5. Mock quoteservice.NewService().BindQuote 成功。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:    "CONTRACT_NO_3",
					RelateQuoteNo: "QUOTE_NO_3",
					BasicInfo:     &bizmodels.BasicInfo{},
				},
			}
			changeInfo := &bizmodels.QuoteChangeInfo{
				RelateQuoteNo:            "QUOTE_NO_3",
				RelateQuoteChangedBefore: "QUOTE_NO_3",
			}

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(changeInfo, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).When(func(ctx context.Context, contractNo string, info *bizmodels.QuoteChangeInfo) bool {
				return contractNo == "CONTRACT_NO_3" && info.RelateQuoteNo == "QUOTE_NO_3" && info.RelateQuoteChangedBefore == ""
			}).Return(nil).Build()
			mockSvc := &MockQuoteService{}
			mockey.Mock(quoteservice.NewService).Return(mockSvc).Build()
			mockey.Mock(quotecli.ChangeQuoteContract).Return(nil).Build()

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should continue when SetQuoteChangeInfoFlag fails", func() {
			// 场景描述：
			// 构造数据：一个需要关联报价单的合同上下文。
			// 逻辑链路：
			// 1. CalcRequireQuote返回true。
			// 2. Mock rediscli.GetQuoteChangeInfo 返回 (nil, nil)。
			// 3. Mock rediscli.SetQuoteChangeInfoFlag 返回一个错误。
			// 4. 函数会记录一个警告日志（不测试日志），但会继续执行。
			// 5. Mock quoteservice.NewService().BindQuote 仍然会被调用并成功。
			// 6. 函数最终返回nil，忽略了SetQuoteChangeInfoFlag的错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:    "CONTRACT_NO_4",
					RelateQuoteNo: "QUOTE_NO_4",
					BasicInfo:     &bizmodels.BasicInfo{},
				},
			}

			mockey.Mock((*model.ContractMeta).CalcRequireQuote).Return(true).Build()
			mockey.Mock(rediscli.GetQuoteChangeInfo).Return(nil, nil).Build()
			mockey.Mock(rediscli.SetQuoteChangeInfoFlag).Return(errors.New("redis set error")).Build()
			mockSvc := &MockQuoteService{}
			mockey.Mock(quoteservice.NewService).Return(mockSvc).Build()
			mockey.Mock(quotecli.ChangeQuoteContract).Return(nil).Build()

			err := h.handleQuoteChangeWhenSubmit(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_BuildConfigurationSummaryDesc(t *testing.T) {
	mockey.PatchConvey("Test_BuildConfigurationSummaryDesc", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("场景1: 只有 title 和 value", func() {
			// 场景描述:
			// 当只有 title 和 value 时, 函数应返回 "title: value" 格式的字符串。
			// 数据构造:
			// - title: "标题"
			// - value: "内容"
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 和 i18nfmt.Sprintf 为透传实现。
			// 2. 函数执行 len(title) > 0 的分支。
			// 3. 函数不执行 len(exclude) > 0 的分支。
			// 4. 返回格式化后的字符串。

			title := "标题"
			value := "内容"
			exclude := ""

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "标题: 内容")
		})

		mockey.PatchConvey("场景2: title, value, exclude 均存在", func() {
			// 场景描述:
			// 当所有参数都存在时, 函数应返回 "title: value（不包含 exclude）" 格式的字符串，且 exclude 中的逗号被替换为顿号。
			// 数据构造:
			// - title: "配置项"
			// - value: "全部"
			// - exclude: "特殊项A,特殊项B"
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 和 i18nfmt.Sprintf 为透传实现。
			// 2. 函数执行 len(title) > 0 的分支，res 变为 "配置项: 全部"。
			// 3. 函数执行 len(exclude) > 0 的分支，将 exclude 中的 "," 替换为 "、"。
			// 4. 调用 i18nfmt.Sprintf 拼接最终字符串。
			// 5. 返回拼接后的结果。

			title := "配置项"
			value := "全部"
			exclude := "特殊项A,特殊项B"

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "配置项: 全部（不包含 特殊项A、特殊项B）")
		})

		mockey.PatchConvey("场景3: 只有 value", func() {
			// 场景描述:
			// 当只有 value 时, 函数应直接返回 value。
			// 数据构造:
			// - title: ""
			// - value: "独立内容"
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 和 i18nfmt.Sprintf 为透传实现。
			// 2. 函数不执行 len(title) > 0 的分支。
			// 3. 函数不执行 len(exclude) > 0 的分支。
			// 4. 直接返回 value。

			title := ""
			value := "独立内容"
			exclude := ""

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "独立内容")
		})

		mockey.PatchConvey("场景4: 只有 value 和 exclude", func() {
			// 场景描述:
			// 当只有 value 和 exclude 时, 函数应返回 "value（不包含 exclude）" 格式的字符串。
			// 数据构造:
			// - title: ""
			// - value: "内容"
			// - exclude: "排除项"
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 和 i18nfmt.Sprintf 为透传实现。
			// 2. 函数不执行 len(title) > 0 的分支。
			// 3. 函数执行 len(exclude) > 0 的分支。
			// 4. 调用 i18nfmt.Sprintf 拼接最终字符串。
			// 5. 返回拼接后的结果。

			title := ""
			value := "内容"
			exclude := "排除项"

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "内容（不包含 排除项）")
		})

		mockey.PatchConvey("场景5: value为特殊值'*'，且存在title和exclude", func() {
			// 场景描述:
			// 当 value 为 "*" 时, 应被替换为国际化文本"所有选项", 并与其他参数正确拼接。
			// 数据构造:
			// - title: "i18n_title"
			// - value: "*"
			// - exclude: "特殊项"
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat, 将 "i18n_title" 翻译为 "Translated Title", 将 "所有选项" 翻译为 "All Options"。
			// 2. Mock i18nfmt.Sprintf 为透传实现。
			// 3. 函数内部调用 ReplaceQuoteOptionDesc, 将 value "*" 替换为 "All Options"。
			// 4. 函数执行 len(title) > 0 的分支，res 变为 "Translated Title: All Options"。
			// 5. 函数执行 len(exclude) > 0 的分支，拼接排除项。
			// 6. 返回最终结果。

			title := "i18n_title"
			value := "*"
			exclude := "特殊项"

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				switch v {
				case "i18n_title":
					return "Translated Title"
				case "所有选项":
					return "All Options"
				default:
					return v
				}
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "Translated Title: All Options（不包含 特殊项）")
		})

		mockey.PatchConvey("场景6: 所有输入均为空", func() {
			// 场景描述:
			// 当所有输入都为空字符串时, 函数应返回空字符串。
			// 数据构造:
			// - title: ""
			// - value: ""
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 和 i18nfmt.Sprintf 为透传实现。
			// 2. 函数不执行 len(title) > 0 的分支。
			// 3. 函数不执行 len(exclude) > 0 的分支。
			// 4. 返回初始的空字符串 res。

			title := ""
			value := ""
			exclude := ""

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			convey.So(result, convey.ShouldEqual, "")
		})
	})
}

func Test_handlerCommon_GenProcessFileNestVersion_BitsUTGen(t *testing.T) {
	type MockAttachmentService struct {
		metaattach.AttachmentService
	}

	mockey.PatchConvey("Test_handlerCommon_GenProcessFileNestVersion", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("scenario: needNewest is true, success", func() {
			// 场景描述: 当 needNewest 为 true 时，强制获取所有文件的最新版本。
			// 构造数据: pc 包含一个合同文件和一个附件。
			// 逻辑链路:
			// 1. 调用 SingleList 分别处理文件和附件ID。
			// 2. 两次调用 filecli.GetNewestVersion 均成功返回最新版本信息。
			// 3. 函数成功执行，返回正确的版本映射和版本记录。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractFile:       "file-1",
					ContractAttachment: "attach-1",
				},
				OperationState: 1,
			}
			needNewest := true

			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{"file-1"}).Then([]string{"attach-1"}),
			).Build()
			mockey.Mock(filecli.GetNewestVersion).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "file-1"
				}).Return(&filecli.GetNewestVersionResp{
				Result: &filecli.GetNewestVersionInfo{
					ID:         "file-1",
					Name:       "contract.pdf",
					Version:    "v1",
					ModifiedAt: "2023-10-26T10:00:00Z",
				},
			}, nil).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "attach-1"
				}).Return(&filecli.GetNewestVersionResp{
				Result: &filecli.GetNewestVersionInfo{
					ID:         "attach-1",
					Name:       "attachment.pdf",
					Version:    "v2",
					ModifiedAt: "2023-10-26T11:00:00Z",
				},
			}, nil).Build()

			newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newestVersionMap, convey.ShouldResemble, map[string]string{
				"file-1":   "v1",
				"attach-1": "v2",
			})
			convey.So(len(recordVersions), convey.ShouldEqual, 2)
			var file1, attach1 bool
			for _, v := range recordVersions {
				if v.FileID == "file-1" {
					file1 = true
				}
				if v.FileID == "attach-1" {
					attach1 = true
				}
			}
			convey.So(file1, convey.ShouldBeTrue)
			convey.So(attach1, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("scenario: cooperation status is Draft, success", func() {
			// 场景描述: 当合同状态为草稿时，逻辑同 needNewest=true，获取最新版本。
			// 构造数据: 合同状态为 PreSalesContractDraft。
			// 逻辑链路:
			// 1. utils.IntIn 判断为 true，进入 needNewest 分支。
			// 2. 后续逻辑同上一个成功场景。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:  _const.PreSalesContractDraft,
					ContractFile:       "file-1",
					ContractAttachment: "attach-1",
				},
			}
			needNewest := false

			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{"file-1"}).Then([]string{"attach-1"}),
			).Build()
			mockey.Mock(filecli.GetNewestVersion).
				When(func(_ context.Context, req *filecli.GetNewestVersionReq) bool { return req.FileID == "file-1" }).
				Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{
						ID: "file-1", Version: "v1", Name: "f1", ModifiedAt: time.Now().Format(time.RFC3339),
					},
				}, nil).
				When(func(_ context.Context, req *filecli.GetNewestVersionReq) bool { return req.FileID == "attach-1" }).
				Return(&filecli.GetNewestVersionResp{
					Result: &filecli.GetNewestVersionInfo{
						ID: "attach-1", Version: "v2", Name: "a1", ModifiedAt: time.Now().Format(time.RFC3339),
					},
				}, nil).
				Build()

			newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newestVersionMap["file-1"], convey.ShouldEqual, "v1")
			convey.So(newestVersionMap["attach-1"], convey.ShouldEqual, "v2")
			convey.So(len(recordVersions), convey.ShouldEqual, 2)
		})

		mockey.PatchConvey("scenario: needNewest is true, buildNewestProcessFileInfo for contract file fails", func() {
			// 场景描述: 当 needNewest 为 true 时，获取合同文件最新版本失败。
			// 构造数据: pc 包含一个合同文件。
			// 逻辑链路:
			// 1. 第一个 h.buildNewestProcessFileInfo 内部调用 filecli.GetNewestVersion 失败并返回错误。
			// 2. 函数提前返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractFile: "file-1",
				},
			}
			needNewest := true

			mockey.Mock(utils.SingleList).Return(mockey.Sequence([]string{"file-1"}).Then([]string{})).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(nil, errors.New("get newest version failed")).Build()

			_, _, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "buildNewestProcessFileInfoFail")
		})

		mockey.PatchConvey("scenario: needNewest is true, buildNewestProcessFileInfo for attachment fails", func() {
			// 场景描述: 当 needNewest 为 true 时，获取附件最新版本失败。
			// 构造数据: pc 包含一个合同文件和一个附件。
			// 逻辑链路:
			// 1. 获取合同文件最新版本成功。
			// 2. 获取附件最新版本失败，h.buildNewestProcessFileInfo 返回错误。
			// 3. 函数提前返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractFile:       "file-1",
					ContractAttachment: "attach-1",
				},
			}
			needNewest := true

			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{"file-1"}).Then([]string{"attach-1"}),
			).Build()
			mockey.Mock(filecli.GetNewestVersion).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "file-1"
				}).Return(&filecli.GetNewestVersionResp{Result: &filecli.GetNewestVersionInfo{ID: "file-1", Version: "v1", ModifiedAt: time.Now().Format(time.RFC3339)}}, nil).
				When(func(ctx context.Context, req *filecli.GetNewestVersionReq) bool {
					return req.FileID == "attach-1"
				}).Return(nil, errors.New("get newest version failed")).
				Build()

			_, _, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "buildNewestProcessFileInfoFail")
		})

		mockey.PatchConvey("scenario: not draft state, GetProcessFileInfo fails", func() {
			// 场景描述: 非草稿状态，调用 GetProcessFileInfo 接口失败。
			// 构造数据: 合同状态为 PreSalesContractCustomerConfirm。
			// 逻辑链路:
			// 1. utils.IntIn 判断为 false，进入 else 分支。
			// 2. 调用 h.getAttachmentService().GetProcessFileInfo() 返回错误。
			// 3. 函数提前返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractCustomerConfirm,
					ContractNo:        "C-123",
				},
			}
			needNewest := false
			mockAttachmentService := &MockAttachmentService{}

			mockey.Mock((*handlerCommon).getAttachmentService).Return(mockAttachmentService).Build()
			mockey.Mock(utils.SingleList).Return(mockey.Sequence([]string{}).Then([]string{})).Build()
			mockey.Mock((*MockAttachmentService).GetProcessFileInfo).Return(nil, errorsV2.ErrCommon.WithArgs("mock error")).Build()

			_, _, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "GetProcessFileInfoFail")
		})

		mockey.PatchConvey("scenario: not draft state, success with diff files", func() {
			// 场景描述: 非草稿状态，部分文件已有关联版本，部分文件为新增，成功处理。
			// 构造数据: GetProcessFileInfo 返回 attach-1 的信息，attach-2 为差异文件。
			// 逻辑链路:
			// 1. GetProcessFileInfo 成功，返回 file-1 和 attach-1 的信息。
			// 2. SubtractStringSlice 计算出差异文件 attach-2。
			// 3. buildNewestProcessFileInfo 获取 attach-2 的最新版本成功。
			// 4. 合并所有文件信息，并正确生成版本记录。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:  _const.PreSalesContractCustomerConfirm,
					ContractNo:         "C-123",
					ContractFile:       "file-1",
					ContractAttachment: "attach-1,attach-2",
				},
				CurrentOperator: "test@example.com",
			}
			needNewest := false
			mockAttachmentService := &MockAttachmentService{}

			mockey.Mock((*handlerCommon).getAttachmentService).Return(mockAttachmentService).Build()
			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{"file-1"}).Then([]string{"attach-1", "attach-2"}),
			).Build()
			approveTime := time.Now().Add(-time.Hour)
			pendingTime := time.Now()
			mockey.Mock((*MockAttachmentService).GetProcessFileInfo).Return(&metaattachmodels.GetProcessFileInfoResp{
				ContractFile: [][]*metaattachmodels.ProcessFileInfo{
					{
						{FileID: "file-1", Version: "v1.approved", FileType: _const.ProcessFileTypeApprove, ModifyAt: approveTime},
					},
				},
				ContractAttachment: [][]*metaattachmodels.ProcessFileInfo{
					{
						{FileID: "attach-1", Version: "v2.approved", FileType: _const.ProcessFileTypeApprove, ModifyAt: approveTime},
						{FileID: "attach-1", Version: "v2.pending", FileType: _const.ProcessFileTypePending, ModifyAt: pendingTime},
					},
				},
			}, nil).Build()
			mockey.Mock(utils.SubtractStringSlice).Return([]string{"attach-2"}).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(&filecli.GetNewestVersionResp{
				Result: &filecli.GetNewestVersionInfo{
					ID:         "attach-2",
					Name:       "new_attachment.pdf",
					Version:    "v3",
					ModifiedAt: "2023-10-26T12:00:00Z",
				},
			}, nil).Build()

			newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newestVersionMap, convey.ShouldResemble, map[string]string{
				"file-1":   "v1.approved",
				"attach-1": "v2.pending",
				"attach-2": "v3",
			})
			convey.So(len(recordVersions), convey.ShouldEqual, 2)
			var foundFile1, foundAttach1, foundAttach2 bool
			for _, v := range recordVersions {
				if v.FileID == "file-1" {
					foundFile1 = true
					convey.So(v.Version, convey.ShouldEqual, "v1.approved")
				}
				if v.FileID == "attach-1" {
					foundAttach1 = true
					convey.So(v.Version, convey.ShouldEqual, "v2.pending")
				}
				if v.FileID == "attach-2" {
					foundAttach2 = true
					convey.So(v.Version, convey.ShouldEqual, "v3")
				}
			}
			convey.So(foundFile1, convey.ShouldBeFalse)
			convey.So(foundAttach1, convey.ShouldBeTrue)
			convey.So(foundAttach2, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("scenario: not draft state, buildNewestProcessFileInfo for diff files fails", func() {
			// 场景描述: 非草稿状态，获取差异文件的最新版本信息失败。
			// 构造数据: SubtractStringSlice 返回差异文件，但 GetNewestVersion 失败。
			// 逻辑链路:
			// 1. GetProcessFileInfo 成功。
			// 2. buildNewestProcessFileInfo 对差异文件调用 GetNewestVersion 失败。
			// 3. 函数提前返回错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:  _const.PreSalesContractCustomerConfirm,
					ContractAttachment: "attach-1,attach-2",
					ContractNo:         "C-123",
				},
				CurrentOperator: "test@example.com",
			}
			needNewest := false
			mockAttachmentService := &MockAttachmentService{}

			mockey.Mock((*handlerCommon).getAttachmentService).Return(mockAttachmentService).Build()
			mockey.Mock(utils.SingleList).Return(mockey.Sequence([]string{}).Then([]string{"attach-1", "attach-2"})).Build()
			mockey.Mock((*MockAttachmentService).GetProcessFileInfo).Return(&metaattachmodels.GetProcessFileInfoResp{
				ContractAttachment: [][]*metaattachmodels.ProcessFileInfo{
					{
						{FileID: "attach-1"},
					},
				},
			}, nil).Build()
			mockey.Mock(utils.SubtractStringSlice).Return([]string{"attach-2"}).Build()
			mockey.Mock(filecli.GetNewestVersion).Return(nil, errors.New("get newest version failed")).Build()

			_, _, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "buildNewestProcessFileInfoFail")
		})

		mockey.PatchConvey("scenario: empty file lists", func() {
			// 场景描述: 处理空的合同文件和附件列表。
			// 构造数据: pc 中的文件和附件字段为空。
			// 逻辑链路:
			// 1. SingleList 返回空切片。
			// 2. 后续处理逻辑正常执行，最终返回空的 map 和切片。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractFile:       "",
					ContractAttachment: "",
				},
			}
			needNewest := true

			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{}).Then([]string{}),
			).Build()
			mockey.Mock((*handlerCommon).buildNewestProcessFileInfo).Return([][]*metaattachmodels.ProcessFileInfo{}, nil).Build()

			newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(newestVersionMap), convey.ShouldEqual, 0)
			convey.So(len(recordVersions), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("scenario: not draft state, no diff files", func() {
			// 场景描述: 非草稿状态，所有文件都已有关联版本，没有差异文件。
			// 构造数据: GetProcessFileInfo 返回所有文件的信息。
			// 逻辑链路:
			// 1. GetProcessFileInfo 成功。
			// 2. SubtractStringSlice 返回空切片，不进入差异文件处理逻辑。
			// 3. 成功生成版本记录。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus:  _const.PreSalesContractCustomerConfirm,
					ContractNo:         "C-123",
					ContractFile:       "file-1",
					ContractAttachment: "attach-1",
				},
				CurrentOperator: "test@example.com",
			}
			needNewest := false
			mockAttachmentService := &MockAttachmentService{}
			mockey.Mock((*handlerCommon).getAttachmentService).Return(mockAttachmentService).Build()

			mockey.Mock(utils.SingleList).Return(
				mockey.Sequence([]string{"file-1"}).Then([]string{"attach-1"}),
			).Build()
			approveTime := time.Now()
			mockey.Mock((*MockAttachmentService).GetProcessFileInfo).Return(&metaattachmodels.GetProcessFileInfoResp{
				ContractFile: [][]*metaattachmodels.ProcessFileInfo{
					{{FileID: "file-1", Version: "v1.approved", FileType: _const.ProcessFileTypeApprove, ModifyAt: approveTime}},
				},
				ContractAttachment: [][]*metaattachmodels.ProcessFileInfo{
					{{FileID: "attach-1", Version: "v2.approved", FileType: _const.ProcessFileTypeApprove, ModifyAt: approveTime}},
				},
			}, nil).Build()
			mockey.Mock(utils.SubtractStringSlice).Return([]string{}).Build()

			newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newestVersionMap, convey.ShouldResemble, map[string]string{
				"file-1":   "v1.approved",
				"attach-1": "v2.approved",
			})
			convey.So(len(recordVersions), convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerCommon_checkContractDiscount_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()
	testTime := time.Now().Format("2006-01-02 15:04:05")

	mockey.PatchConvey("Test checkContractDiscount", t, func() {

		mockMetaService := &MockMetaService{}
		mockMetaServiceV2 := &MockMetaServiceV2{}
		mockMetaExtDao := &MockContractMetaExtDao{}
		mockContractOperationRecordDao := &MockContractOperationRecordDao{}
		mockMetaAttachService := &MockMetaAttachService{}
		mockMetaCommodityService := &MockMetaCommodityService{}

		setupServiceMocks := func() {
			mockey.Mock(metaattach.NewAttachmentService).Return(mockMetaAttachService).Build()
			mockey.Mock(metacommodity.NewService).Return(mockMetaCommodityService).Build()
			mockey.Mock(contractmeta.NewMetaService).Return(mockMetaService).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockMetaServiceV2).Build()
		}

		mockey.PatchConvey("场景：交易双方信息缺失", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: nil,
					Ext:            make(map[string]string),
				},
				Extra: "{}",
			}

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "交易双方信息缺失")
		})

		mockey.PatchConvey("场景：非补充协议，无合同价重复", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					SupplyScene: _const.SupplySceneNew,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{PricingAccountID: "123"},
						},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				Extra: "{}",
			}
			setupServiceMocks()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(&modelcommodity.CheckQuoteItemRepeatData{
				Repeat: false,
			}, nil).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：合同价重复，且不忽略重复错误", func() {

			pc := &auditmodel.ProcessCtx{
				Extra: `{"IgnorePriceRepeatReturn":false}`,
				ContractInfo: &model.ContractMeta{
					ID:                1,
					ContractNo:        "CN-123",
					RelateQuoteNo:     "Q-123",
					CooperationStatus: 1,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				CurrentOperator: "test_operator",
			}
			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}

			setupServiceMocks()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return("repeated remark").Build()
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockContractOperationRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).Create).Return(nil).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorsV2.ErrQuoteDuplicated.GetCode(), convey.ShouldEqual, err.(errorsV2.APIError).GetCode())
		})

		mockey.PatchConvey("场景：合同价重复，但选择忽略错误", func() {

			changeInfo := bizmodels.ChangeQuoteExtra{IgnorePriceRepeatReturn: true}
			extra, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				Extra: string(extra),
				ContractInfo: &model.ContractMeta{
					ID:                1,
					ContractNo:        "CN-123",
					RelateQuoteNo:     "Q-123",
					CooperationStatus: 1,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				CurrentOperator: "test_operator",
			}
			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}

			setupServiceMocks()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(&model.ContractMetaExt{BaseDB: model.BaseDB{Id: 1}}, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return("repeated remark").Build()
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockContractOperationRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).Create).Return(nil).Build()
			mockey.Mock(GetCommodityRepeatMsgMap).Return(map[string]map[string]string{}).Build()
			mockey.Mock((*MockMetaServiceV2).ClearRelateQuote).Return(nil).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：补充协议，查询原合同列表失败", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					SupplyScene:    _const.SupplySceneAdjustPrice,
					FromContractNo: "FROM-CN-123",
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					Ext:        make(map[string]string),
				},
				Extra: "{}",
			}

			setupServiceMocks()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(nil, errorsV2.ErrInternalError).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询补充协议相关合同信息失败")
		})

		mockey.PatchConvey("场景：CheckQuoteItemRepeat 服务本身调用失败", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo:    &bizmodels.ManageInfo{},
					RelateQuoteNo: "Q-123",
					BasicInfo:     &bizmodels.BasicInfo{},
					BeginTime:     testTime,
					EndTime:       testTime,
					Ext:           make(map[string]string),
				},
				Extra: "{}",
			}

			setupServiceMocks()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(nil, errors.New("check failed")).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同价[%s]重复校验失败")
		})

		mockey.PatchConvey("场景：更新合同价重复信息失败", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ID: 1,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				Extra: "{}",
			}
			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}

			setupServiceMocks()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, errors.New("db error")).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "更新合同价重复信息失败")
		})

		mockey.PatchConvey("场景：创建操作记录失败", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ID: 1,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				Extra: "{}",
			}
			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}

			setupServiceMocks()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return("repeated remark").Build()
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockContractOperationRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).Create).Return(errors.New("db error")).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建操作记录失败")
		})

		mockey.PatchConvey("场景：忽略重复时，清空关联报价失败", func() {

			changeInfo := bizmodels.ChangeQuoteExtra{IgnorePriceRepeatReturn: true}
			extra, _ := json.Marshal(changeInfo)
			pc := &auditmodel.ProcessCtx{
				Extra: string(extra),
				ContractInfo: &model.ContractMeta{
					ID:                1,
					ContractNo:        "CN-123",
					RelateQuoteNo:     "Q-123",
					CooperationStatus: 1,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					ManageInfo: &bizmodels.ManageInfo{},
					BasicInfo:  &bizmodels.BasicInfo{},
					BeginTime:  testTime,
					EndTime:    testTime,
					Ext:        make(map[string]string),
				},
				CurrentOperator: "test_operator",
			}
			repeatData := &modelcommodity.CheckQuoteItemRepeatData{Repeat: true}
			clearErr := errorsV2.ErrInternalError.WithArgs("clear failed")

			setupServiceMocks()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).Return(repeatData, nil).Build()
			mockey.Mock(dal.NewContractMetaExtDao).Return(mockMetaExtDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return("repeated remark").Build()
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockContractOperationRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).Create).Return(nil).Build()
			mockey.Mock(GetCommodityRepeatMsgMap).Return(map[string]map[string]string{"CN-123": {}}).Build()
			mockey.Mock((*MockMetaServiceV2).ClearRelateQuote).Return(clearErr).Build()
			mockey.Mock(logid.GetLogIDFromCtx).Return("test_log_id", true).Build()
			mockey.Mock(larkc.Warning).To(func(title, content string, ctxOpt ...context.Context) {}).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "clear failed")
		})

		mockey.PatchConvey("场景：BP分销特殊业务类型", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BusinessType: _const.BusinessTypeBPDistribution,
					},
					ManageInfo: &bizmodels.ManageInfo{
						DistributBusinessType: _const.DistributBusinessTypeSpecial,
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty:       []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
						EndUserAccountID: "end_user_456",
					},
					BeginTime: testTime,
					EndTime:   testTime,
					Ext:       make(map[string]string),
				},
				Extra: "{}",
			}

			setupServiceMocks()
			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).To(func(_ context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {

				convey.So(req.OwnerID, convey.ShouldEqual, "end_user_456")
				return &modelcommodity.CheckQuoteItemRepeatData{Repeat: false}, nil
			}).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：补充协议，且为项目制", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					SupplyScene:    _const.SupplySceneAdjustPrice,
					FromContractNo: "FROM-CN-123",
					ManageInfo: &bizmodels.ManageInfo{
						WhetherProject: _const.Yes,
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{{PricingAccountID: "123"}},
					},
					BeginTime: testTime,
					EndTime:   testTime,
					BasicInfo: &bizmodels.BasicInfo{},
					Ext:       make(map[string]string),
				},
				Extra: "{}",
			}

			setupServiceMocks()
			mockey.Mock((*MockMetaService).GetSupplyContractList).Return(&bizmodels.SupplyContractListResp{
				ParentContractList: []string{"PARENT-CN-001"},
			}, nil).Build()

			mockey.Mock((*MockMetaServiceV2).CheckQuoteItemRepeat).To(func(_ context.Context, req *modelcommodity.CheckQuoteItemRepeatReq) (*modelcommodity.CheckQuoteItemRepeatData, error) {

				convey.So(req.IsProject, convey.ShouldEqual, _const.TRUE_FLAG_INT_STR)
				convey.So(req.SkipContractNoList, convey.ShouldResemble, []string{"PARENT-CN-001"})
				return &modelcommodity.CheckQuoteItemRepeatData{Repeat: false}, nil
			}).Build()

			err := h.checkContractDiscount(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestReplaceQuoteOptionDesc_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestReplaceQuoteOptionDesc", t, func() {
		mockey.PatchConvey("当option为*", func() {
			// 场景描述：
			// 构造数据：option为"*"
			// 逻辑链路：
			// 1. 函数进入 switch 的 case "*" 分支
			// 2. Mock multienv.I18nFormat 函数，使其返回预设的国际化文本
			// 3. 断言函数返回结果为预设的国际化文本
			ctx := context.Background()
			mockedDesc := "All Options"
			mockey.Mock(multienv.I18nFormat).Return(mockedDesc).Build()

			result := ReplaceQuoteOptionDesc(ctx, "*")

			convey.So(result, convey.ShouldEqual, mockedDesc)
		})

		mockey.PatchConvey("当option不为*", func() {
			// 场景描述：
			// 构造数据：option为"other_option"
			// 逻辑链路：
			// 1. 函数进入 switch 的 default 分支
			// 2. 函数直接返回传入的 option 字符串
			// 3. 断言函数返回结果与传入的 option 相同
			ctx := context.Background()
			option := "other_option"

			result := ReplaceQuoteOptionDesc(ctx, option)

			convey.So(result, convey.ShouldEqual, option)
		})
	})
}

func Test_handlerCommon_getMetaService_BitsUTGen(t *testing.T) {
	// mockMetaServiceImpl is a mock implementation of the contractmeta.MetaService interface for testing.
	type mockMetaServiceImpl struct {
		contractmeta.MetaService
	}

	mockey.PatchConvey("Test_handlerCommon_getMetaService", t, func() {
		mockey.PatchConvey("should initialize services on first call and return the same instance subsequently", func() {
			// 场景描述：
			// 测试 getMetaService 函数能够正确地初始化并返回 contractmeta.MetaService 实例。
			// 由于 handlerCommon 内部使用 sync.Once 来确保服务只初始化一次，
			// 因此连续多次调用 getMetaService 应该返回同一个实例。
			// 构造数据：
			// - 创建一个新的 handlerCommon 实例。
			// - 创建一个 mockMetaServiceImpl 实例作为 NewMetaService 的预期返回值。
			// 逻辑链路：
			// 1. Mock contractmeta.NewMetaService，使其返回预定义的 mock 实例。
			// 2. Mock 其他在 initService 中被调用的服务构造函数（如 NewAttachmentService 等），使其返回 nil，以隔离测试。
			// 3. 第一次调用 h.getMetaService，这将触发 initService 的执行，从而初始化 h.metaService 字段。
			// 4. 第二次调用 h.getMetaService，由于 sync.Once 的作用，初始化逻辑不会再次执行。
			// 5. 断言两次调用的返回值均为预定义的 mock 实例，并且两者是同一个实例。

			// 数据准备
			h := &handlerCommon{}
			ctx := context.Background()
			expectedService := &mockMetaServiceImpl{}

			// Mock 依赖的服务构造函数
			mockey.Mock(contractmeta.NewMetaService).Return(expectedService).Build()
			mockey.Mock(metaattach.NewAttachmentService).Return(nil).Build()
			mockey.Mock(metacommodity.NewService).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(nil).Build()

			// 调用
			firstCallResult := h.getMetaService(ctx)
			secondCallResult := h.getMetaService(ctx)

			// 断言
			convey.So(firstCallResult, convey.ShouldNotBeNil)
			convey.So(firstCallResult, convey.ShouldEqual, expectedService)
			convey.So(secondCallResult, convey.ShouldEqual, firstCallResult)
		})
	})
}

func Test_handlerCommon_getAndValidateReviewerMappings_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getAndValidateReviewerMappings", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		needRoles := []string{"销售运营", "法务BP"}
		departmentId := "dep-123"
		operator := "op-456"

		// Mock i18n and lark message formatters, used in error notifications
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return fmt.Sprintf("<at email=%s></at>", email) }).Build()

		convey.Convey("Success case: successfully get and validate all reviewer mappings", func() {
			// Arrange
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("Test Department").Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				// Simulate the mapping from role name to role ID
				roleMap := map[string]int{"销售运营": _const.ReviewerRoleSalesOp, "法务BP": _const.ReviewerRoleLegalBP}
				return roleMap[name]
			}).Build()
			mockey.Mock(h.reviewerMatcher).Return(reviewrule.NewReviewerMatcher()).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(
				map[int][]*model.ReviewRuleReviewerDB{
					_const.ReviewerRoleSalesOp: {{EmployeeEmail: "sales@example.com"}},
					_const.ReviewerRoleLegalBP: {{EmployeeEmail: "legal1@example.com"}, {EmployeeEmail: "legal2@example.com"}},
				}, nil).Build()

			// Act
			result, err := h.getAndValidateReviewerMappings(ctx, needRoles, departmentId, operator)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result["销售运营"], convey.ShouldEqual, "sales@example.com")
			convey.So(result["法务BP"], convey.ShouldEqual, "legal1@example.com,legal2@example.com")
		})

		convey.Convey("Error case: GetPrimaryReviewers returns an error", func() {
			// Arrange
			mockedErr := errors.New("database connection failed")
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("Test Department").Build()
			mockey.Mock(h.reviewerMatcher).Return(reviewrule.NewReviewerMatcher()).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(nil, mockedErr).Build()
			// Mock notification sending part
			mockey.Mock(larkc.GetReviewerErrorReceivers).Return([]string{"admin@example.com"}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			result, err := h.getAndValidateReviewerMappings(ctx, needRoles, departmentId, operator)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockedErr)
		})

		convey.Convey("Error case: a required reviewer role is not defined", func() {
			// Arrange
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("Test Department").Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				roleMap := map[string]int{"销售运营": _const.ReviewerRoleSalesOp, "法务BP": _const.ReviewerRoleLegalBP}
				return roleMap[name]
			}).Build()
			mockey.Mock(h.reviewerMatcher).Return(reviewrule.NewReviewerMatcher()).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(
				map[int][]*model.ReviewRuleReviewerDB{
					// Missing "法务BP" role
					_const.ReviewerRoleSalesOp: {{EmployeeEmail: "sales@example.com"}},
				}, nil).Build()
			// Mock notification sending part
			mockey.Mock(larkc.GetReviewerErrorReceivers).Return([]string{"admin@example.com"}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			result, err := h.getAndValidateReviewerMappings(ctx, needRoles, departmentId, operator)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs(_const.ReviewerError))
		})

		convey.Convey("Error case: a reviewer's email is empty", func() {
			// Arrange
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("Test Department").Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				roleMap := map[string]int{"销售运营": _const.ReviewerRoleSalesOp, "法务BP": _const.ReviewerRoleLegalBP}
				return roleMap[name]
			}).Build()
			mockey.Mock(h.reviewerMatcher).Return(reviewrule.NewReviewerMatcher()).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(
				map[int][]*model.ReviewRuleReviewerDB{
					_const.ReviewerRoleSalesOp: {{EmployeeEmail: "sales@example.com"}},
					_const.ReviewerRoleLegalBP: {{EmployeeEmail: ""}}, // Empty email
				}, nil).Build()
			// Mock notification sending part
			mockey.Mock(larkc.GetReviewerErrorReceivers).Return([]string{"admin@example.com"}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			result, err := h.getAndValidateReviewerMappings(ctx, needRoles, departmentId, operator)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs(_const.ReviewerError))
		})

		convey.Convey("Edge case: operator not found but process continues", func() {
			// Arrange
			mockey.Mock(larkc.GetEmployeeByID).Return(nil, nil).Build() // Operator not found
			mockey.Mock(preload.ReviewRuleID2Name).Return("Test Department").Build()
			mockey.Mock(_const.GetReviewerRoleValueByNameIgnore).To(func(name string) int {
				roleMap := map[string]int{"销售运营": _const.ReviewerRoleSalesOp, "法务BP": _const.ReviewerRoleLegalBP}
				return roleMap[name]
			}).Build()
			mockey.Mock(h.reviewerMatcher).Return(reviewrule.NewReviewerMatcher()).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(
				map[int][]*model.ReviewRuleReviewerDB{
					_const.ReviewerRoleSalesOp: {{EmployeeEmail: "sales@example.com"}},
					_const.ReviewerRoleLegalBP: {{EmployeeEmail: "legal@example.com"}},
				}, nil).Build()

			// Act
			result, err := h.getAndValidateReviewerMappings(ctx, needRoles, departmentId, operator)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result["销售运营"], convey.ShouldEqual, "sales@example.com")
			convey.So(result["法务BP"], convey.ShouldEqual, "legal@example.com")
		})
	})
}

func Test_handlerCommon_resetSolutionNodeReviewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_resetSolutionNodeReviewers", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("success case", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "test-contract",
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test1@example.com,test2@example.com"),
					},
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "dep-123",
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{ReviewerType: _const.ReviewerTypeSolutionReviewer, Reviewer: "old@example.com"},
						{ReviewerType: _const.ReviewerTypeSalesOperation, Reviewer: "sales@example.com"},
					},
				},
			}
			mockEmployees := map[string]*peopleclient.Employee{
				"test1@example.com": {ID: 1, Email: "test1@example.com", Terminated: false},
				"test2@example.com": {ID: 2, Email: "test2@example.com", Terminated: false},
			}
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(mockEmployees, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(nil).Build()
			mockey.Mock((*model.PreContractReviewerDB).GenResp).To(func(db *model.PreContractReviewerDB) *bizmodels.PreContractReviewer {
				return &bizmodels.PreContractReviewer{
					Reviewer:     db.Reviewer,
					ReviewerID:   db.ReviewerID,
					ReviewerType: db.ReviewerType,
				}
			}).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(pc.ContractInfo.Reviewers), convey.ShouldEqual, 3)
			foundNew1 := false
			foundNew2 := false
			foundOldSolution := false
			for _, r := range pc.ContractInfo.Reviewers {
				if r.Reviewer == "test1@example.com" {
					foundNew1 = true
				}
				if r.Reviewer == "test2@example.com" {
					foundNew2 = true
				}
				if r.Reviewer == "old@example.com" {
					foundOldSolution = true
				}
			}
			convey.So(foundNew1, convey.ShouldBeTrue)
			convey.So(foundNew2, convey.ShouldBeTrue)
			convey.So(foundOldSolution, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return error when project solution email is empty", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
			}

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "项目信息产解/行解信息为空")
		})

		mockey.PatchConvey("should return error when batch getting employees fails", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test@example.com"),
					},
				},
			}
			mockErr := errors.New("larkc rpc error")
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(nil, mockErr).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询用户信息失败, 无法新增审批")
		})

		mockey.PatchConvey("should return error when employee info not found for an email", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("found@example.com,notfound@example.com"),
					},
					BasicInfo: &bizmodels.BasicInfo{DepartmentId: "dep-123"},
				},
			}
			mockEmployees := map[string]*peopleclient.Employee{
				"found@example.com": {ID: 1, Email: "found@example.com", Terminated: false},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(mockEmployees, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询用户[notfound@example.com]信息失败, 无法新增审批")
		})

		mockey.PatchConvey("should return error when employee is terminated", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("terminated@example.com"),
					},
				},
			}
			mockEmployees := map[string]*peopleclient.Employee{
				"terminated@example.com": {ID: 1, Email: "terminated@example.com", Terminated: true},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(mockEmployees, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "用户[terminated@example.com]已离职, 无法新增审批")
		})

		mockey.PatchConvey("should return error when employee lookup returns empty map for a valid email", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test@example.com"),
					},
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{}, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "查询用户[test@example.com]信息失败, 无法新增审批")
		})

		mockey.PatchConvey("should return error when deleting reviewers fails", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "test-contract",
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test@example.com"),
					},
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			mockEmployees := map[string]*peopleclient.Employee{
				"test@example.com": {ID: 1, Email: "test@example.com", Terminated: false},
			}
			mockDao := &MockPreContractReviewerDao{}
			mockErr := errors.New("db delete error")

			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(mockEmployees, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(mockErr).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "reset reviewers fail")
		})

		mockey.PatchConvey("should return error when batch creating reviewers fails", func() {
			// Arrange
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "test-contract",
					ProjectInfo: &bizmodels.ProjectInfo{
						ProductSolutionEmail: gptr.Of("test@example.com"),
					},
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			mockEmployees := map[string]*peopleclient.Employee{
				"test@example.com": {ID: 1, Email: "test@example.com", Terminated: false},
			}
			mockDao := &MockPreContractReviewerDao{}
			mockErr := errors.New("db create error")

			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(mockEmployees, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(mockErr).Build()

			// Act
			err := h.resetSolutionNodeReviewers(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建审批操作条目失败")
		})
	})
}

func Test_handlerCommon_commonCheckHitContractStatusChange_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_commonCheckHitContractStatusChange", t, func() {
		// 准备通用测试数据
		h := &handlerCommon{}
		ctx := context.Background()
		// 初始化 ProcessCtx，不设置未导出的 tx 字段
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no",
				CooperationStatus: 1,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 2,
			},
		}

		mockey.PatchConvey("当所有审批人都通过时", func() {
			// 场景描述:
			// 模拟 dal.IsAllReviewerTypePassed 返回 true 和 nil error，表示当前节点所有审批操作都已完成。
			// 构造数据:
			// ProcessCtx 正常构造。
			// 逻辑链路:
			// 1. 调用 dal.IsAllReviewerTypePassed 成功，返回 (true, nil)。
			// 2. 函数不进入错误处理分支。
			// 3. 函数返回 dal.IsAllReviewerTypePassed 的结果 (true, nil)。
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(true, nil).Build()

			// 调用目标函数
			allPassed, err := h.commonCheckHitContractStatusChange(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(allPassed, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("当并非所有审批人都通过时", func() {
			// 场景描述:
			// 模拟 dal.IsAllReviewerTypePassed 返回 false 和 nil error，表示当前节点尚有未完成的审批操作。
			// 构造数据:
			// ProcessCtx 正常构造。
			// 逻辑链路:
			// 1. 调用 dal.IsAllReviewerTypePassed 成功，返回 (false, nil)。
			// 2. 函数不进入错误处理分支。
			// 3. 函数返回 dal.IsAllReviewerTypePassed 的结果 (false, nil)。
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, nil).Build()

			// 调用目标函数
			allPassed, err := h.commonCheckHitContractStatusChange(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(allPassed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当检查审批结果失败时", func() {
			// 场景描述:
			// 模拟 dal.IsAllReviewerTypePassed 返回一个错误，表示在数据库查询过程中发生异常。
			// 构造数据:
			// ProcessCtx 正常构造。
			// 逻辑链路:
			// 1. 调用 dal.IsAllReviewerTypePassed 失败，返回 (false, error)。
			// 2. 函数进入错误处理分支。
			// 3. 函数通过 i18nfmt.New 创建并返回一个新错误。
			// 4. 函数最终返回 (false, error)。
			dbErr := errors.New("database query failed")
			mockey.Mock(dal.IsAllReviewerTypePassed).Return(false, dbErr).Build()

			// 调用目标函数
			allPassed, err := h.commonCheckHitContractStatusChange(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
			convey.So(allPassed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("财税法节点检查财税法审批人类型", func() {
			pc.ContractInfo.CooperationStatus = _const.PreSalesContractFinanceTaxationLegalSignReview
			pc.ReviewerStatusOpConf.ReviewerType = _const.ReviewerTypeFinanceTaxationLegalReviewer
			checkedReviewerTypes := map[int]int{}
			mockey.Mock(dal.IsAllReviewerTypePassed).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType int, contractStatus int) (bool, error) {
				convey.So(preContractNo, convey.ShouldEqual, "test-contract-no")
				convey.So(contractStatus, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalSignReview)
				checkedReviewerTypes[reviewerType]++
				return true, nil
			}).Build()

			allPassed, err := h.commonCheckHitContractStatusChange(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(allPassed, convey.ShouldBeTrue)
			convey.So(checkedReviewerTypes[_const.ReviewerTypeFinanceTaxationLegalReviewer], convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("财税法节点未审批通过时不流转", func() {
			pc.ContractInfo.CooperationStatus = _const.PreSalesContractFinanceTaxationLegalSignReview
			pc.ReviewerStatusOpConf.ReviewerType = _const.ReviewerTypeFinanceTaxationLegalReviewer
			checkedReviewerTypes := map[int]int{}
			mockey.Mock(dal.IsAllReviewerTypePassed).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType int, contractStatus int) (bool, error) {
				checkedReviewerTypes[reviewerType]++
				return false, nil
			}).Build()

			allPassed, err := h.commonCheckHitContractStatusChange(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(allPassed, convey.ShouldBeFalse)
			convey.So(checkedReviewerTypes[_const.ReviewerTypeFinanceTaxationLegalReviewer], convey.ShouldEqual, 1)
		})
	})
}

func TestSaveExternalCommodityList_BitsUTGen(t *testing.T) {
	// MockContractCommodityExternalDao is a mock type for the dal.ContractCommodityExternalDao interface.
	type MockContractCommodityExternalDao struct {
		dal.ContractCommodityExternalDao
	}

	mockey.PatchConvey("TestSaveExternalCommodityList", t, func() {
		// Common test data setup
		ctx := context.Background()
		tx := &gorm.DB{}
		metaDB := &model.ContractMetaDB{
			BaseDB:     model.BaseDB{Id: 1},
			ContractNo: "TEST-CONTRACT-001",
			Version:    1,
		}
		commodityList := []*model.VolcContractCommodityExternal{
			{
				BaseDB:         model.BaseDB{Id: 101},
				VolcContractID: 1,
			},
		}
		mockDao := &MockContractCommodityExternalDao{}

		// Mock the DAO constructor to return our mock instance.
		mockey.Mock(dal.NewContractCommodityExternalDao).Return(mockDao).Build()

		convey.Convey("成功分支 - 正常保存商品列表", func() {
			// 场景描述:
			//   正常情况下，先删除旧数据，再创建新数据，一切顺利。
			// 构造数据:
			//   - commodityList 不为空。
			// 逻辑链路:
			//   1. dal.NewContractCommodityExternalDao 返回 mockDao 实例。
			//   2. commodityDao.DeleteByVolcContractID 成功，返回 nil error。
			//   3. commodityList 长度不为 0，继续执行。
			//   4. commodityDao.CreateInBatches 成功，返回 nil error。
			//   5. 函数返回 nil。
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(nil).Build()

			err := SaveExternalCommodityList(ctx, tx, metaDB, commodityList)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("失败分支 - 删除旧商品失败", func() {
			// 场景描述:
			//   在删除旧数据时发生数据库错误。
			// 构造数据:
			//   - metaDB.ContractNo 不为空。
			// 逻辑链路:
			//   1. dal.NewContractCommodityExternalDao 返回 mockDao 实例。
			//   2. commodityDao.DeleteByVolcContractID 失败，返回一个 error。
			//   3. if 条件 `len(metaDB.ContractNo) > 0 && err != nil` 为 true。
			//   4. 函数记录错误日志并返回 ErrInternalError，附带 "DeleteExternalCommodityByNoFail"。
			mockErr := errors.New("db delete error")
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(mockErr).Build()

			apiErr := SaveExternalCommodityList(ctx, tx, metaDB, commodityList)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "DeleteExternalCommodityByNoFail")
			convey.So(apiErr.GetCode(), convey.ShouldEqual, errorsV2.ErrInternalError.GetCode())
		})

		convey.Convey("成功分支 - 商品列表为空", func() {
			// 场景描述:
			//   传入的商品列表为空，只需删除旧数据即可，然后提前返回。
			// 构造数据:
			//   - commodityList 为空切片。
			// 逻辑链路:
			//   1. dal.NewContractCommodityExternalDao 返回 mockDao 实例。
			//   2. commodityDao.DeleteByVolcContractID 成功，返回 nil error。
			//   3. if 条件 `len(commodityList) == 0` 为 true。
			//   4. 函数直接返回 nil，不执行创建操作。
			emptyCommodityList := []*model.VolcContractCommodityExternal{}
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()

			apiErr := SaveExternalCommodityList(ctx, tx, metaDB, emptyCommodityList)

			convey.So(apiErr, convey.ShouldBeNil)
		})

		convey.Convey("失败分支 - 批量创建新商品失败", func() {
			// 场景描述:
			//   删除旧数据成功，但在批量创建新数据时发生数据库错误。
			// 构造数据:
			//   - commodityList 不为空。
			// 逻辑链路:
			//   1. dal.NewContractCommodityExternalDao 返回 mockDao 实例。
			//   2. commodityDao.DeleteByVolcContractID 成功，返回 nil error。
			//   3. commodityList 长度不为 0，继续执行。
			//   4. commodityDao.CreateInBatches 失败，返回一个 error。
			//   5. 函数记录错误日志并返回 ErrInternalError，附带 "CreateCommodityFail"。
			mockErr := errors.New("db create error")
			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(nil).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(mockErr).Build()

			apiErr := SaveExternalCommodityList(ctx, tx, metaDB, commodityList)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "CreateCommodityFail")
			convey.So(apiErr.GetCode(), convey.ShouldEqual, errorsV2.ErrInternalError.GetCode())
		})

		convey.Convey("边缘场景 - 删除失败但合同号为空，应忽略错误并继续", func() {
			// 场景描述:
			//   这是一个边缘情况，删除操作失败，但因为 metaDB.ContractNo 为空，错误被忽略，后续创建成功。
			// 构造数据:
			//   - metaDB.ContractNo 为空字符串。
			//   - commodityList 不为空。
			// 逻辑链路:
			//   1. dal.NewContractCommodityExternalDao 返回 mockDao 实例。
			//   2. commodityDao.DeleteByVolcContractID 失败，返回一个 error。
			//   3. if 条件 `len(metaDB.ContractNo) > 0 && err != nil` 为 false，因为 `len(metaDB.ContractNo) > 0` 为 false。
			//   4. commodityList 长度不为 0，继续执行。
			//   5. commodityDao.CreateInBatches 成功，返回 nil error。
			//   6. 函数返回 nil。
			metaDBNoContractNo := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 2},
				ContractNo: "", // ContractNo is empty
				Version:    1,
			}
			mockErr := errors.New("db delete error but ignored")

			mockey.Mock((*MockContractCommodityExternalDao).DeleteByVolcContractID).Return(mockErr).Build()
			mockey.Mock((*MockContractCommodityExternalDao).CreateInBatches).Return(nil).Build()

			apiErr := SaveExternalCommodityList(ctx, tx, metaDBNoContractNo, commodityList)

			convey.So(apiErr, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_resetFTLNodeReviewers_BitsUTGen(t *testing.T) {
	// 定义用于Mock dal 层的结构体
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}
	// 定义用于Mock reviewrule Matcher 层的结构体
	type MockReviewerMatcher struct {
		reviewrule.ReviewerMatcher
	}

	mockey.PatchConvey("Test_handlerCommon_resetFTLNodeReviewers", t, func() {

		h := &handlerCommon{}

		ctx := context.Background()
		mockDB := &gorm.DB{}

		mockey.PatchConvey("场景：成功重置财税法节点审批人", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-001",
					Operator:   "operator_id",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
					ProjectInfo: &bizmodels.ProjectInfo{
						DeliveryStaff: gptr.Of("delivery1@example.com,reviewer1@example.com"),
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "old@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer},
					},
				},
				ApprovalKey: _const.ApprovalKeyDefault,
			}
			mockReviewerDao := &MockPreContractReviewerDao{}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR+财务BP", nil).Build()
			// Mocks for inner function getAndValidateReviewerMappings
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
				_const.ReviewerRoleFinanceBP: {{EmployeeEmail: "reviewer2@example.com"}},
			}, nil).Build()
			// Mock for BatchListHireEmployeesByEmails
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
				"reviewer1@example.com": {ID: 1, Email: "reviewer1@example.com", Terminated: false},
				"reviewer2@example.com": {ID: 2, Email: "reviewer2@example.com", Terminated: false},
				"delivery1@example.com": {ID: 3, Email: "delivery1@example.com", Terminated: false},
			}, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerTypes []int, contractStatusList ...int) error {
				convey.So(preContractNo, convey.ShouldEqual, "TEST-CONTRACT-001")
				convey.So(reviewerTypes, convey.ShouldResemble, []int{_const.ReviewerTypeFinanceTaxationLegalReviewer})
				convey.So(contractStatusList, convey.ShouldBeEmpty)
				return nil
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
				relatedStatus := GetReviewerTypeStatusMappings(pc.ApprovalKey)[_const.ReviewerTypeFinanceTaxationLegalReviewer]
				convey.So(len(entities), convey.ShouldEqual, len(relatedStatus)*2+1)
				reviewerStatus := map[string]map[int]bool{}
				for _, e := range entities {
					if reviewerStatus[e.Reviewer] == nil {
						reviewerStatus[e.Reviewer] = map[int]bool{}
					}
					reviewerStatus[e.Reviewer][e.ContractStatus] = true
				}
				for _, reviewer := range []string{"reviewer1@example.com", "reviewer2@example.com"} {
					for _, status := range relatedStatus {
						convey.So(reviewerStatus[reviewer][status], convey.ShouldBeTrue)
					}
				}
				convey.So(reviewerStatus["delivery1@example.com"][_const.PreSalesContractFinanceTaxationLegalReview], convey.ShouldBeTrue)
				return nil
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock(logs.CtxInfo).Return().Build()
			paResetStatusMap := map[int]bool{}
			mockey.Mock((*handlerCommon).resetPANodeReviewers).To(func(_ *handlerCommon, resetCtx context.Context, resetPc *auditmodel.ProcessCtx, currentContractStatus int) error {
				convey.So(resetCtx, convey.ShouldEqual, ctx)
				convey.So(resetPc, convey.ShouldEqual, pc)
				paResetStatusMap[currentContractStatus] = true
				return nil
			}).Build()

			err := h.resetFTLNodeReviewers(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(paResetStatusMap, convey.ShouldResemble, map[int]bool{
				_const.PreSalesContractFinanceTaxationLegalReview:     true,
				_const.PreSalesContractFinanceTaxationLegalSignReview: true,
			})
		})

		mockey.PatchConvey("场景：合同模板类型缺失", func() {

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: nil,
					},
				},
			}
			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同模板类型缺失")
		})

		mockey.PatchConvey("场景：规则引擎未匹配到财税法角色", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST-CONTRACT-002",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
					},
				},
			}
			mockey.Mock(ruleengine.MatchFTLRule).Return("", nil).Build()
			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "无此合同对应的财税法审核角色")
		})

		mockey.PatchConvey("场景：获取审批人映射失败", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-003",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			// Mocks for inner function getAndValidateReviewerMappings
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(nil, errors.New("db error")).Build()

			mockey.Mock(larkc.GetReviewerErrorReceivers).Return([]string{"receiver@example.com"}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "db error")
		})

		mockey.PatchConvey("场景：批量查询员工信息失败", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-004",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			// Mocks for inner function getAndValidateReviewerMappings
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
			}, nil).Build()
			// Mock for BatchListHireEmployeesByEmails
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(nil, errors.New("lark rpc error")).Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "lark rpc error")
		})

		mockey.PatchConvey("场景：审批人在员工信息中缺失", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-005",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "terminated@example.com"}},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
				"terminated@example.com": {ID: 99, Email: "terminated@example.com", Terminated: true},
			}, nil).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("场景：成功重置财税法签约节点审批人", func() {
			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalSignReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-009",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "old@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer},
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			mockReviewerDao := &MockPreContractReviewerDao{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
				"reviewer1@example.com": {ID: 1, Email: "reviewer1@example.com", Terminated: false},
			}, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).To(func(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerTypes []int, contractStatusList ...int) error {
				convey.So(preContractNo, convey.ShouldEqual, "TEST-CONTRACT-009")
				convey.So(reviewerTypes, convey.ShouldResemble, []int{_const.ReviewerTypeFinanceTaxationLegalReviewer})
				convey.So(contractStatusList, convey.ShouldBeEmpty)
				return nil
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
				relatedStatus := GetReviewerTypeStatusMappings(pc.ApprovalKey)[_const.ReviewerTypeFinanceTaxationLegalReviewer]
				convey.So(len(entities), convey.ShouldEqual, len(relatedStatus))
				statusMap := map[int]bool{}
				for _, e := range entities {
					convey.So(e.Reviewer, convey.ShouldEqual, "reviewer1@example.com")
					statusMap[e.ContractStatus] = true
				}
				for _, status := range relatedStatus {
					convey.So(statusMap[status], convey.ShouldBeTrue)
				}
				return nil
			}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			paResetStatusMap := map[int]bool{}
			mockey.Mock((*handlerCommon).resetPANodeReviewers).To(func(_ *handlerCommon, resetCtx context.Context, resetPc *auditmodel.ProcessCtx, currentContractStatus int) error {
				convey.So(resetCtx, convey.ShouldEqual, ctx)
				convey.So(resetPc, convey.ShouldEqual, pc)
				paResetStatusMap[currentContractStatus] = true
				return nil
			}).Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
			convey.So(paResetStatusMap, convey.ShouldResemble, map[int]bool{
				_const.PreSalesContractFinanceTaxationLegalReview:     true,
				_const.PreSalesContractFinanceTaxationLegalSignReview: true,
			})
		})

		mockey.PatchConvey("场景：删除旧审批人列表失败", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-006",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerDao := &MockPreContractReviewerDao{}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
				"reviewer1@example.com": {ID: 1, Email: "reviewer1@example.com", Terminated: false},
			}, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(errors.New("delete db error")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock(logs.CtxWarn).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "reset reviewers fail")
		})

		mockey.PatchConvey("场景：批量创建新审批人列表失败", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-007",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerDao := &MockPreContractReviewerDao{}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
				"reviewer1@example.com": {ID: 1, Email: "reviewer1@example.com", Terminated: false},
			}, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(errors.New("batch create db error")).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock(logs.CtxWarn).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建审批操作条目失败")
		})

		mockey.PatchConvey("场景：审批人存在但Lark中查询不到员工信息", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-008a",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "non-exist@example.com"}},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{}, nil).Build()
			mockey.Mock(logs.CtxWarn).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("场景：角色下未配置审批人导致查询失败", func() {

			templateType := 1
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ApprovalKey:        _const.ApprovalKeyDefault,
				ContractInfo: &model.ContractMeta{
					Operator:   "operator_id",
					ContractNo: "TEST-CONTRACT-008b",
					BasicInfo: &bizmodels.BasicInfo{
						ContractTemplateType: &templateType,
						DepartmentId:         "dept_id_1",
					},
				},
			}
			mockReviewerMatcher := &MockReviewerMatcher{}
			reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher

			mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
			mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
			mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
			mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
				_const.ReviewerRoleFinanceAR: {},
			}, nil).Build()
			mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{}, nil).Build()
			mockey.Mock(logs.CtxWarn).Return().Build()

			err := h.resetFTLNodeReviewers(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
		})

	})
}

func Test_handlerCommon_resetFTLNodeReviewers_ResetPAFail(t *testing.T) {
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}
	type MockReviewerMatcher struct {
		reviewrule.ReviewerMatcher
	}

	mockey.PatchConvey("PA审批人初始化失败时透传错误", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		mockDB := &gorm.DB{}
		templateType := 1
		pc := &auditmodel.ProcessCtx{
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			ApprovalKey:        _const.ApprovalKeyDefault,
			ContractInfo: &model.ContractMeta{
				Operator:   "operator_id",
				ContractNo: "TEST-CONTRACT-010",
				BasicInfo: &bizmodels.BasicInfo{
					ContractTemplateType: &templateType,
					DepartmentId:         "dept_id_1",
				},
			},
		}
		mockReviewerMatcher := &MockReviewerMatcher{}
		mockReviewerDao := &MockPreContractReviewerDao{}
		reviewerMatcher = &mockReviewerMatcher.ReviewerMatcher
		expectedErr := errors.New("reset pa error")

		mockey.Mock(ruleengine.MatchFTLRule).Return("财务AR", nil).Build()
		mockey.Mock(preload.ReviewRuleID2Name).Return("测试行业线").Build()
		mockey.Mock(larkc.GetEmployeeByID).Return([]*peopleclient.Employee{{Email: "operator@example.com"}}, nil).Build()
		mockey.Mock((*reviewrule.ReviewerMatcher).GetPrimaryReviewers).Return(map[int][]*model.ReviewRuleReviewerDB{
			_const.ReviewerRoleFinanceAR: {{EmployeeEmail: "reviewer1@example.com"}},
		}, nil).Build()
		mockey.Mock(larkc.BatchListHireEmployeesByEmails).Return(map[string]*peopleclient.Employee{
			"reviewer1@example.com": {ID: 1, Email: "reviewer1@example.com", Terminated: false},
		}, nil).Build()
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockReviewerDao).Build()
		mockey.Mock((*MockPreContractReviewerDao).DeleteReviewersByType).Return(nil).Build()
		mockey.Mock((*MockPreContractReviewerDao).BatchCreate).Return(nil).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
		mockey.Mock((*handlerCommon).resetPANodeReviewers).Return(expectedErr).Build()

		err := h.resetFTLNodeReviewers(ctx, pc)
		convey.So(err, convey.ShouldEqual, expectedErr)
	})
}

func Test_handlerCommon_collectEmails_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_collectEmails", t, func() {
		// 构造一个 handlerCommon 实例以调用方法
		h := &handlerCommon{}

		mockey.PatchConvey("当 departmentMap 为空时，应返回空切片", func() {
			// 场景描述：
			// 构造数据：输入一个空的 map
			// 逻辑链路：函数接收空 map，for-range 循环不执行，直接返回一个空的 string 切片
			departmentMap := map[string]string{}
			result := h.collectEmails(departmentMap)

			convey.So(result, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("当 departmentMap 包含唯一的、非逗号分隔的 email 时，应正确收集所有 email", func() {
			// 场景描述：
			// 构造数据：输入一个 map，其中每个部门只有一个唯一的 email
			// 逻辑链路：函数遍历 map，将每个 email 添加到去重 map 中，最后转换为切片返回
			departmentMap := map[string]string{
				"dep1": "user1@example.com",
				"dep2": "user2@example.com",
			}
			result := h.collectEmails(departmentMap)
			expected := []string{"user1@example.com", "user2@example.com"}

			// 因为 map 迭代顺序不定，对结果进行排序以确保断言的稳定性
			sort.Strings(result)
			sort.Strings(expected)
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当 departmentMap 中有值包含逗号分隔的多个 email 时，应正确拆分并收集所有 email", func() {
			// 场景描述：
			// 构造数据：输入一个 map，其中一个部门的 email 字符串由逗号分隔
			// 逻辑链路：函数遍历 map，使用 strings.Split 对 email 字符串进行分割，并将所有分割后的 email 添加到去重 map 中
			departmentMap := map[string]string{
				"dep1": "user1@example.com,user2@example.com",
				"dep2": "user3@example.com",
			}
			result := h.collectEmails(departmentMap)
			expected := []string{"user1@example.com", "user2@example.com", "user3@example.com"}

			sort.Strings(result)
			sort.Strings(expected)
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当 departmentMap 中存在重复的 email 时，应返回去重后的 email 列表", func() {
			// 场景描述：
			// 构造数据：输入一个 map，其中不同部门或同一部门内存在相同的 email
			// 逻辑链路：函数利用 map 的键唯一性自动对 email 进行去重，最终返回不含重复项的 email 列表
			departmentMap := map[string]string{
				"dep1": "user1@example.com,user2@example.com",
				"dep2": "user2@example.com,user3@example.com",
				"dep3": "user1@example.com",
			}
			result := h.collectEmails(departmentMap)
			expected := []string{"user1@example.com", "user2@example.com", "user3@example.com"}

			sort.Strings(result)
			sort.Strings(expected)
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当 email 字符串包含空字符串（如连续逗号或结尾逗号）时，应将空字符串也收集起来", func() {
			// 场景描述：
			// 构造数据：输入的 email 字符串中包含 "a,,b" 或 "c," 这样的格式
			// 逻辑链路：strings.Split 会将这些情况分割出空字符串，函数逻辑会把空字符串也作为有效的 email 添加到结果中
			departmentMap := map[string]string{
				"dep1": "user1@example.com,,user2@example.com",
				"dep2": "user3@example.com,",
			}
			result := h.collectEmails(departmentMap)
			expected := []string{"", "user1@example.com", "user2@example.com", "user3@example.com"}

			sort.Strings(result)
			sort.Strings(expected)
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("当 departmentMap 中的值为单个空字符串时，应返回包含一个空字符串的切片", func() {
			// 场景描述：
			// 构造数据：输入一个 map，其中一个部门对应的 email 字符串是空字符串
			// 逻辑链路：strings.Split("", ",") 的结果是 []string{""}，因此函数会收集到一个空字符串
			departmentMap := map[string]string{
				"dep1": "",
			}
			result := h.collectEmails(departmentMap)
			expected := []string{""}

			convey.So(result, convey.ShouldResemble, expected)
		})
	})
}

func Test_validateTradePartyInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_validateTradePartyInfo", t, func() {
		ctx := context.Background()
		basicInfo := &bizmodels.BasicInfo{}
		tradePartyInfo := &bizmodels.TradePartyInfo{}

		mockey.PatchConvey("成功-所有校验通过-直连飞书", func() {
			// 场景描述：
			// 构造数据：构造一个直连飞书的 basicInfo (IsFeishu = true)
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回 nil
			// 2. tradePartyInfo.Validate 返回 nil
			// 3. tradePartyInfo.SealOrderCheck 返回 nil
			// 4. basicInfo.IsFeishu 为 true，进入 if 分支
			// 5. tradePartyInfo.CheckPayTypes 返回 nil
			// 6. 函数最终返回 nil
			basicInfo.IsFeishu = true

			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(nil).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功-所有校验通过-非直连飞书", func() {
			// 场景描述：
			// 构造数据：构造一个非直连飞书的 basicInfo (IsFeishu = false)
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回 nil
			// 2. tradePartyInfo.Validate 返回 nil
			// 3. tradePartyInfo.SealOrderCheck 返回 nil
			// 4. basicInfo.IsFeishu 为 false, 不进入 if 分支
			// 5. 函数最终返回 nil
			basicInfo.IsFeishu = false

			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败-CheckSignData返回错误", func() {
			// 场景描述：
			// 构造数据：无特殊构造
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回一个错误
			// 2. 函数记录日志并直接返回该错误
			mockErr := errors.New("CheckSignData failed")
			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(mockErr).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CheckSignData failed")
		})

		mockey.PatchConvey("失败-Validate返回错误", func() {
			// 场景描述：
			// 构造数据：无特殊构造
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回 nil
			// 2. tradePartyInfo.Validate 返回一个错误
			// 3. 函数直接返回该错误
			mockErr := errorsV2.ErrorCommon.WithArgs("Validate failed")
			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(mockErr).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Validate failed")
		})

		mockey.PatchConvey("失败-SealOrderCheck返回错误", func() {
			// 场景描述：
			// 构造数据：无特殊构造
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回 nil
			// 2. tradePartyInfo.Validate 返回 nil
			// 3. tradePartyInfo.SealOrderCheck 返回一个错误
			// 4. 函数直接返回该错误
			mockErr := errorsV2.ErrorCommon.WithArgs("SealOrderCheck failed")
			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(mockErr).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SealOrderCheck failed")
		})

		mockey.PatchConvey("失败-直连飞书且CheckPayTypes返回错误", func() {
			// 场景描述：
			// 构造数据：构造一个直连飞书的 basicInfo (IsFeishu = true)
			// 逻辑链路：
			// 1. tradePartyInfo.CheckSignData 返回 nil
			// 2. tradePartyInfo.Validate 返回 nil
			// 3. tradePartyInfo.SealOrderCheck 返回 nil
			// 4. basicInfo.IsFeishu 为 true，进入 if 分支
			// 5. tradePartyInfo.CheckPayTypes 返回一个错误
			// 6. 函数直接返回该错误
			basicInfo.IsFeishu = true
			mockErr := errorsV2.ErrorCommon.WithArgs("CheckPayTypes failed")

			mockey.Mock((*bizmodels.TradePartyInfo).CheckSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(mockErr).Build()

			err := validateTradePartyInfo(ctx, basicInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CheckPayTypes failed")
		})
	})
}

func Test_ConvertFullData_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ConvertFullData", t, func() {

		mockey.PatchConvey("success: with standard data and non-default life type", func() {
			// 准备输入数据
			db := &model.ContractMetaDB{
				IsContainRefundClause: 1, // 用于测试 strconv.Itoa
			}
			// 1. 准备 BasicInfo，测试 UsefulLifeType 不被修改的场景
			basicInfo := bizmodels.BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: "Y",
			}
			basicInfoBytes, _ := json.Marshal(basicInfo)
			db.BasicInfo = string(basicInfoBytes)

			// 2. 准备 TradePartyInfo，测试名称拼接、AccountID拆分以及内部nil切片的初始化
			tradePartyInfo := bizmodels.TradePartyInfo{
				Subject: []*bizmodels.TradePartyInfoDetail{
					{PartyName: "S1", PayTypes: nil, OpAddress: nil}, // PayTypes 和 OpAddress 为 nil
				},
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{PartyName: "O1", PayTypes: []*bizmodels.PayType{}, OpAddress: []bizmodels.OpAddress{}, AccountID: "acc1,acc2"}, // PayTypes 和 OpAddress 不为 nil
					{PartyName: "O2", AccountID: "acc3"},
				},
			}
			tradePartyInfoBytes, _ := json.Marshal(tradePartyInfo)
			db.TradePartyInfo = string(tradePartyInfoBytes)

			// Mock 依赖的 utils.SingleList 函数，模拟两次调用返回不同的结果
			mockey.Mock(utils.SingleList).Return(mockey.Sequence([]string{"acc1", "acc2"}).Then([]string{"acc3"})).Build()

			// 调用目标函数
			ret := ConvertFullData(db, nil, nil)

			// 断言结果
			convey.So(ret, convey.ShouldNotBeNil)
			// 断言 BasicInfo 未被修改
			convey.So(ret.BasicInfo.UsefulLifeType, convey.ShouldEqual, _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME)
			convey.So(ret.BasicInfo.IndefiniteDateFlag, convey.ShouldEqual, "Y")

			// 断言 TradePartyInfo 中 nil 的切片被正确初始化
			convey.So(ret.TradePartyInfo.Subject[0].PayTypes, convey.ShouldNotBeNil)
			convey.So(len(ret.TradePartyInfo.Subject[0].PayTypes), convey.ShouldEqual, 0)
			convey.So(ret.TradePartyInfo.Subject[0].OpAddress, convey.ShouldNotBeNil)
			convey.So(len(ret.TradePartyInfo.Subject[0].OpAddress), convey.ShouldEqual, 0)

			// 断言聚合字段
			convey.So(ret.SubjectName, convey.ShouldEqual, "S1")
			convey.So(ret.OtherPartyName, convey.ShouldEqual, "O1,O2")
			convey.So(ret.SubjectAccountIds, convey.ShouldEqual, "acc1,acc2,acc3")
			convey.So(ret.IsContainRefundClause, convey.ShouldEqual, "1")
		})

		mockey.PatchConvey("success: when life type is default, it should be corrected", func() {
			// 准备输入数据，主要关注 BasicInfo
			db := &model.ContractMetaDB{}
			basicInfo := bizmodels.BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME, // 触发修正逻辑的条件
				IndefiniteDateFlag: "Y",                                    // 这个值应该被覆盖
			}
			basicInfoBytes, _ := json.Marshal(basicInfo)
			db.BasicInfo = string(basicInfoBytes)
			db.TradePartyInfo = "{}" // 使用空的 TradePartyInfo 以聚焦测试点

			// 调用目标函数
			ret := ConvertFullData(db, nil, nil)

			// 断言结果
			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(ret.BasicInfo.UsefulLifeType, convey.ShouldEqual, _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME)
			convey.So(ret.BasicInfo.IndefiniteDateFlag, convey.ShouldEqual, _const.BizNo)
		})

		mockey.PatchConvey("success: when trade party lists in JSON are nil, they should be initialized", func() {
			// 准备输入数据，TradePartyInfo 中的切片为 nil
			db := &model.ContractMetaDB{}
			db.BasicInfo = "{}"
			tradePartyInfo := bizmodels.TradePartyInfo{
				Subject:    nil, // 触发外层 nil 保护的条件
				OtherParty: nil, // 触发外层 nil 保护的条件
			}
			tradePartyInfoBytes, _ := json.Marshal(tradePartyInfo)
			db.TradePartyInfo = string(tradePartyInfoBytes)

			// 调用目标函数
			ret := ConvertFullData(db, nil, nil)

			// 断言结果
			convey.So(ret, convey.ShouldNotBeNil)
			// 断言外层切片被初始化
			convey.So(ret.TradePartyInfo.Subject, convey.ShouldNotBeNil)
			convey.So(len(ret.TradePartyInfo.Subject), convey.ShouldEqual, 0)
			convey.So(ret.TradePartyInfo.OtherParty, convey.ShouldNotBeNil)
			convey.So(len(ret.TradePartyInfo.OtherParty), convey.ShouldEqual, 0)
			// 断言聚合字段为空
			convey.So(ret.SubjectName, convey.ShouldEqual, "")
			convey.So(ret.OtherPartyName, convey.ShouldEqual, "")
			convey.So(ret.SubjectAccountIds, convey.ShouldEqual, "")
		})
	})
}

func Test_handlerCommon_getMetaCommodityService_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getMetaCommodityService", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("当第一次调用时，应成功初始化并返回服务", func() {
			// 场景描述：
			// 在一个全新的 handlerCommon 实例上首次调用 getMetaCommodityService。
			// 构造数据：
			// - h: 一个新创建的 handlerCommon 实例，其所有 service 字段均为 nil。
			// 逻辑链路：
			// 1. 调用 h.getMetaCommodityService(ctx)。
			// 2. 内部调用 h.initService(ctx)。
			// 3. h.once.Do 中的匿名函数被执行，初始化 h.metaCommodityService 等服务。
			// 4. 函数返回已初始化的 h.metaCommodityService。
			// 5. 断言返回的服务不为 nil，且与 h.metaCommodityService 字段指向同一个实例。
			h := &handlerCommon{}

			// 调用
			service := h.getMetaCommodityService(ctx)

			// 断言
			convey.So(service, convey.ShouldNotBeNil)
			convey.So(h.metaCommodityService, convey.ShouldNotBeNil)
			convey.So(service, convey.ShouldEqual, h.metaCommodityService)
		})

		mockey.PatchConvey("当多次调用时，应只初始化一次并返回同一个服务实例", func() {
			// 场景描述：
			// 在同一个 handlerCommon 实例上多次调用 getMetaCommodityService，以验证 sync.Once 的幂等性。
			// 构造数据：
			// - h: 一个新创建的 handlerCommon 实例。
			// 逻辑链路：
			// 1. 第一次调用 h.getMetaCommodityService(ctx)，服务被初始化。
			// 2. 第二次调用 h.getMetaCommodityService(ctx)。
			// 3. 由于 sync.Once 的作用，h.once.Do 中的匿名函数不会再次执行。
			// 4. 第二次调用直接返回已存在的服务实例。
			// 5. 断言两次调用返回的服务实例指针相同。
			h := &handlerCommon{}

			// 调用
			service1 := h.getMetaCommodityService(ctx)
			service2 := h.getMetaCommodityService(ctx)

			// 断言
			convey.So(service1, convey.ShouldNotBeNil)
			convey.So(service2, convey.ShouldNotBeNil)
			convey.So(service1, convey.ShouldEqual, service2)
		})

		mockey.PatchConvey("在并发调用下，应只初始化一次并返回同一个服务实例", func() {
			// 场景描述：
			// 模拟多个 goroutine 并发调用 getMetaCommodityService，验证其线程安全性及 sync.Once 的并发保证。
			// 构造数据：
			// - h: 一个新创建的 handlerCommon 实例。
			// 逻辑链路：
			// 1. 启动多个 goroutine，每个 goroutine 都调用 h.getMetaCommodityService(ctx)。
			// 2. sync.Once 保证了即使在并发竞争条件下，初始化函数也只会被一个 goroutine 执行一次。
			// 3. 所有 goroutine 都应该获取到同一个服务实例。
			// 4. 断言所有 goroutine 获取到的服务实例都相同。
			h := &handlerCommon{}
			numGoroutines := 10
			services := make([]metacommodity.Service, numGoroutines)
			var wg sync.WaitGroup
			wg.Add(numGoroutines)

			// 并发调用
			for i := 0; i < numGoroutines; i++ {
				go func(j int) {
					defer wg.Done()
					services[j] = h.getMetaCommodityService(ctx)
				}(i)
			}
			wg.Wait()

			// 断言
			firstService := services[0]
			convey.So(firstService, convey.ShouldNotBeNil)
			for i := 1; i < numGoroutines; i++ {
				convey.So(services[i], convey.ShouldResemble, firstService)
			}
		})
	})
}

func Test_handlerCommon_commonValidateUpdateReviewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.commonValidateUpdateReviewers", t, func() {
		// 初始化handler和上下文
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景：传入的审批人员为空字符串", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra为空字符串。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) == 0为true。
			// 2. 返回错误"人员不可为空"。
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景：获取已有审批人列表失败", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra不为空。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个错误。
			// 3. 函数直接返回此错误。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			expectedErr := errors.New("db query failed")
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, expectedErr).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeError, expectedErr)
		})

		mockey.PatchConvey("场景：新增的审批人已经是审批人（且未通过）", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra包含一个已存在的、未审批通过的审批人。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个包含该审批人的列表，且其状态不为ReviewStatusReviewPass。
			// 3. 函数遍历新审批人列表，发现该审批人已存在且状态不满足条件。
			// 4. 将该审批人加入existReviewers列表。
			// 5. 循环结束后，检查len(existReviewers) > 0为true。
			// 6. 返回错误"%s已是审核人员"。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com,new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				&model.PreContractReviewerDB{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			expectedErr := errorsV2.ErrCommon.WithArgs("%s已是审核人员", "existing.user@example.com")
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("场景：新增的多个审批人均已是审批人（且未通过）", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra包含多个已存在的、未审批通过的审批人。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个包含这些审批人的列表，且其状态不为ReviewStatusReviewPass。
			// 3. 函数遍历新审批人列表，发现这些审批人均已存在且状态不满足条件。
			// 4. 将这些审批人加入existReviewers列表。
			// 5. 循环结束后，检查len(existReviewers) > 0为true。
			// 6. 返回包含所有已存在审批人的错误信息。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com,user2@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				&model.PreContractReviewerDB{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
				&model.PreContractReviewerDB{Reviewer: "user2@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusAddReviewers}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			expectedErr := errorsV2.ErrCommon.WithArgs("%s已是审核人员", "user1@example.com,user2@example.com")
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("场景：新增的审批人已是审批人（但已通过）", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra包含一个已存在的、但审批已通过的审批人。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个包含该审批人的列表，其状态为ReviewStatusReviewPass。
			// 3. 函数遍历新审批人列表，发现该审批人已存在，但其状态为ReviewStatusReviewPass，不满足if条件。
			// 4. existReviewers列表为空。
			// 5. 循环结束后，检查len(existReviewers) > 0为false。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				Extra: "passed.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				&model.PreContractReviewerDB{Reviewer: "passed.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功路径，新增的审批人均未在已有审批人列表中", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra包含全新的审批人。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个不包含新审批人的列表。
			// 3. 函数遍历新审批人列表，在map中找不到任何一个。
			// 4. existReviewers列表为空。
			// 5. 循环结束后，检查len(existReviewers) > 0为false。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user1@example.com,new.user2@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				&model.PreContractReviewerDB{Reviewer: "other.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功路径，当前没有任何已有审批人", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra包含全新的审批人。
			// 逻辑链路：
			// 1. 函数进入，检查len(pc.Extra) > 0。
			// 2. Mock perm.GetAllReviewersByType返回一个空列表。
			// 3. 函数遍历新审批人列表，在空的map中找不到任何一个。
			// 4. existReviewers列表为空。
			// 5. 循环结束后，检查len(existReviewers) > 0为false。
			// 6. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-12345",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{}, nil).Build()

			// 调用目标函数
			err := h.commonValidateUpdateReviewers(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_validateUsefulLifeType_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	mockey.PatchConvey("Test_validateUsefulLifeType", t, func() {
		// Common data setup
		loc := time.FixedZone("CST", 8*3600)
		t1, _ := time.ParseInLocation("2006-01-02", "2023-01-01", loc)
		// t2 代表日期 2023-12-31。使用 "2006-01-02" 格式解析会得到 00:00:00 时刻。
		t2, _ := time.ParseInLocation("2006-01-02", "2023-12-31", loc)
		// 目标函数会将合同结束时间转换为当天的最后一秒。为了正确测试边界，报价单的结束时间也应为当天的最后一秒。
		t2_end_of_day := time.Date(t2.Year(), t2.Month(), t2.Day(), 23, 59, 59, 0, loc)
		t3, _ := time.ParseInLocation("2006-01-02", "2022-12-31", loc)
		t4, _ := time.ParseInLocation("2006-01-02", "2024-01-01", loc)

		contractVO := &model.ContractMetaDB{}
		quoteInfo := &quote_client.QuoteRespSimpleInfo{}
		basicInfo := &bizmodels.BasicInfo{}
		manageInfo := &bizmodels.ManageInfo{}

		mockey.PatchConvey("场景：指定有效期类型", func() {
			basicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME

			mockey.PatchConvey("成功：合同有效期在报价单有效期内", func() {
				// 场景描述：
				// 构造数据：合同开始和结束日期与报价单的有效期范围的边界日期相同。
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SPECIFY_TIME，进入第一个if分支。
				// 2. contractVO.EndTime不为零。
				// 3. 目标函数内部将contractVO.EndTime ('2023-12-31 00:00:00') 转换为当天结束时间 ('2023-12-31 23:59:59')。
				// 4. 为使边界条件通过，将报价单结束时间设置为当天结束时间。
				// 5. 转换后的合同结束时间不晚于报价单的结束时间，函数返回nil。
				quoteInfo.PriceValidPeriodStartTime = t1
				quoteInfo.PriceValidPeriodEndTime = t2_end_of_day // FIX: 使用当天的结束时间
				contractVO.BeginTime = t1
				contractVO.EndTime = t2 // 合同结束于当天 (时刻为 00:00:00)

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("失败：报价单无截止日期，合同有效期在报价单开始时间之后", func() {
				// 场景描述：
				// 构造数据：报价单的结束时间为零值，表示不限制结束时间
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SPECIFY_TIME，进入第一个if分支
				// 2. contractVO.EndTime不为零
				// 3. !endTime.IsZero()为false，不校验结束时间
				// 4. 函数返回nil
				quoteInfo.PriceValidPeriodStartTime = t1
				quoteInfo.PriceValidPeriodEndTime = time.Time{} // 无截止日期
				contractVO.BeginTime = t1
				contractVO.EndTime = t4

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同关联了报价单，指定有效期不允许有效期为空")
			})

			mockey.PatchConvey("失败：合同截止日期为空", func() {
				// 场景描述：
				// 构造数据：合同的结束时间为零值
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SPECIFY_TIME，进入第一个if分支
				// 2. contractEndTime.IsZero()为true，返回错误
				quoteInfo.PriceValidPeriodStartTime = t1
				quoteInfo.PriceValidPeriodEndTime = t2
				contractVO.EndTime = time.Time{}

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同关联了报价单，合同有效期截止日期不能为空")
			})

			mockey.PatchConvey("失败：合同开始时间早于报价单有效期", func() {
				// 场景描述：
				// 构造数据：合同开始时间早于报价单开始时间
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SPECIFY_TIME，进入第一个if分支
				// 2. contractVO.BeginTime.Before(startTime)为true，进入错误处理逻辑
				// 3. Mock i18nfmt.Sprintf
				// 4. 函数返回错误
				quoteInfo.PriceValidPeriodStartTime = t1
				quoteInfo.PriceValidPeriodEndTime = t2
				contractVO.BeginTime = t3
				contractVO.EndTime = t2
				mockErrMsg := "合同有效期不在报价单有效期范围内"
				mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, mockErrMsg)
			})

			mockey.PatchConvey("失败：合同结束时间晚于报价单有效期", func() {
				// 场景描述：
				// 构造数据：合同结束时间晚于报价单结束时间
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_DEFAULT_TIME，进入第一个if分支
				// 2. contractEndTime.After(endTime)为true，进入错误处理逻辑
				// 3. Mock i18nfmt.Sprintf
				// 4. 函数返回错误
				basicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME
				quoteInfo.PriceValidPeriodStartTime = t1
				quoteInfo.PriceValidPeriodEndTime = t2
				contractVO.BeginTime = t1
				contractVO.EndTime = t4
				mockErrMsg := fmt.Sprintf("合同有效期不在报价单有效期范围内, 当前合同关联的报价单有效期为：%s ~ %s", quoteInfo.PriceValidPeriodStartTime, quoteInfo.PriceValidPeriodEndTime)
				mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期不在报价单有效期范围内")
			})
		})

		mockey.PatchConvey("场景：签订日起生效类型", func() {
			basicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			manageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME

			mockey.PatchConvey("成功：合同有效期等于报价单有效期", func() {
				// 场景描述：
				// 构造数据：合同与报价单的有效期单位和数值均相等
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. 类型、单位等级、数值均符合要求
				// 3. 函数返回nil
				basicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				basicInfo.UsefulLifeNum = 2
				manageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				manageInfo.UsefulLifeNum = 2

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("成功：合同有效期单位小于报价单有效期单位", func() {
				// 场景描述：
				// 构造数据：合同有效期单位为月，报价单为年
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. 合同单位等级小于报价单单位等级
				// 3. 函数返回nil
				basicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_MONTH
				basicInfo.UsefulLifeNum = 12
				manageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				manageInfo.UsefulLifeNum = 1

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("成功：合同有效期数值小于报价单有效期数值", func() {
				// 场景描述：
				// 构造数据：合同有效期数值小于报价单有效期数值，单位相同
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. 单位等级相同，合同数值小于报价单数值
				// 3. 函数返回nil
				basicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				basicInfo.UsefulLifeNum = 1
				manageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				manageInfo.UsefulLifeNum = 2

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("失败：报价单有效期类型不匹配", func() {
				// 场景描述：
				// 构造数据：报价单有效期类型不是签订日起生效
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. manageInfo.UsefulLifeType不为CONTRACT_LIFE_TYPE_SIGN_TIME，返回错误
				manageInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "关联报价单为指定日期生效，合同需与报价单保持一致")
			})

			mockey.PatchConvey("失败：合同有效期单位大于报价单", func() {
				// 场景描述：
				// 构造数据：合同有效期单位为年，报价单为月
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. 合同单位等级大于报价单单位等级，返回错误
				// 3. Mock i18nfmt.Sprintf
				// 4. 函数返回错误
				basicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				manageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_MONTH
				mockErrMsg := "签订日起生效，报价单有效期单位为MONTH，合同有效期单位为YEAR，合同有效期需小于等于报价单有效期"
				mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, mockErrMsg)
			})

			mockey.PatchConvey("失败：合同有效期数值大于报价单", func() {
				// 场景描述：
				// 构造数据：单位相同，合同有效期数值大于报价单
				// 逻辑链路：
				// 1. basicInfo.UsefulLifeType为CONTRACT_LIFE_TYPE_SIGN_TIME，进入第二个if分支
				// 2. 单位等级相同，但合同数值大于报价单数值，返回错误
				// 3. Mock i18nfmt.Sprintf
				// 4. 函数返回错误
				basicInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				basicInfo.UsefulLifeNum = 3
				manageInfo.UsefulLifeUnit = _const.USEFUL_LIFE_UNIT_YEAR
				manageInfo.UsefulLifeNum = 2
				mockErrMsg := "签订日起生效，报价单有效期为2YEAR，合同有效期为3YEAR，合同有效期需小于等于报价单有效期"
				mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

				err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, mockErrMsg)
			})
		})

		mockey.PatchConvey("场景：不支持的有效期类型", func() {
			// 场景描述：
			// 构造数据：传入一个未定义的有效期类型
			// 逻辑链路：
			// 1. 所有if/else if条件均不满足，进入最后的else分支
			// 2. 函数返回"暂不支持的有效期类型"错误
			basicInfo.UsefulLifeType = 99

			err := validateUsefulLifeType(ctx, contractVO, quoteInfo, basicInfo, manageInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "暂不支持的有效期类型")
		})
	})
}

func TestUploadFileVolc_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestUploadFileVolc", t, func() {
		// Common test data
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "TEST_CONTRACT_NO_12345",
				CooperationStatus: 1,
				OnlineContract:    "file_id_online_contract",
			},
		}
		fillData := &templateclient.FillFileData{
			FileKey: "tos://bucket/some_path/original_filename.pdf",
		}

		mockey.PatchConvey("scene: upload file successfully", func() {
			// 场景描述：
			// 该测试用例旨在验证当所有依赖项均成功执行时，`UploadFileVolc`函数能否正确上传文件并返回新的文件ID。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "TEST_CONTRACT_NO_12345"
			// - fillData.FileKey: "tos://bucket/some_path/original_filename.pdf"
			// 逻辑链路：
			// 1. 调用 `utils.GetFileBaseName` 成功，返回 "original_filename.pdf"。
			// 2. 调用 `utils.ReplaceFileName` 成功，返回 "TEST_CONTRACT_NO_12345.pdf"。
			// 3. 调用 `filecli.UploadFile` 成功，返回包含新文件ID "new_file_id_67890" 的响应和 nil 错误。
			// 4. 函数应返回 "new_file_id_67890" 和 nil 错误。

			mockey.Mock(utils.GetFileBaseName).Return("original_filename.pdf").Build()
			mockey.Mock(utils.ReplaceFileName).Return("TEST_CONTRACT_NO_12345.pdf").Build()
			mockey.Mock(filecli.UploadFile).Return(&filecli.FileMetaResponse{FileID: "new_file_id_67890"}, nil).Build()

			fileID, err := UploadFileVolc(ctx, pc, fillData)

			convey.So(err, convey.ShouldBeNil)
			convey.So(fileID, convey.ShouldEqual, "new_file_id_67890")
		})

		mockey.PatchConvey("scene: fail to upload file due to filecli.UploadFile error", func() {
			// 场景描述：
			// 该测试用例用于验证当底层的 `filecli.UploadFile` 调用失败时，`UploadFileVolc`函数能否正确处理错误并返回。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "TEST_CONTRACT_NO_12345"
			// - fillData.FileKey: "tos://bucket/some_path/original_filename.pdf"
			// 逻辑链路：
			// 1. 调用 `utils.GetFileBaseName` 成功，返回 "original_filename.pdf"。
			// 2. 调用 `utils.ReplaceFileName` 成功，返回 "TEST_CONTRACT_NO_12345.pdf"。
			// 3. 调用 `filecli.UploadFile` 失败，返回 nil 和一个错误 "upload failed"。
			// 4. 函数应记录错误日志（此部分不测试），并返回空字符串和接收到的错误。

			mockey.Mock(utils.GetFileBaseName).Return("original_filename.pdf").Build()
			mockey.Mock(utils.ReplaceFileName).Return("TEST_CONTRACT_NO_12345.pdf").Build()
			mockey.Mock(filecli.UploadFile).Return(nil, errors.New("upload failed")).Build()

			fileID, err := UploadFileVolc(ctx, pc, fillData)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "upload failed")
			convey.So(fileID, convey.ShouldBeEmpty)
		})
	})
}

func Test_handlerCommon_commonCheckHitMasterReviewerPass_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.commonCheckHitMasterReviewerPass", t, func() {
		// General setup for all test cases
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-123",
				CooperationStatus: 10,
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 5,
			},
		}

		mockey.PatchConvey("Scenario: dal.IsAllNoMasterReviewerTypePassed returns true and nil error", func() {
			// 场景描述:
			// 测试当底层DAL函数成功检查并且所有非主审审批人都已通过时的场景。
			// 构造数据:
			// - pc.ContractInfo.ContractNo = "test-contract-123"
			// - pc.ContractInfo.CooperationStatus = 10
			// - pc.ReviewerStatusOpConf.ReviewerType = 5
			// 逻辑链路:
			// 1. Mock dal.IsAllNoMasterReviewerTypePassed 函数返回 (true, nil)。
			// 2. 调用目标函数 commonCheckHitMasterReviewerPass。
			// 3. 断言返回结果为 (true, nil)。
			mockey.Mock(dal.IsAllNoMasterReviewerTypePassed).Return(true, nil).Build()

			passed, err := h.commonCheckHitMasterReviewerPass(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("Scenario: dal.IsAllNoMasterReviewerTypePassed returns false and nil error", func() {
			// 场景描述:
			// 测试当底层DAL函数成功检查但存在未通过的非主审审批人时的场景。
			// 构造数据:
			// - pc.ContractInfo.ContractNo = "test-contract-123"
			// - pc.ContractInfo.CooperationStatus = 10
			// - pc.ReviewerStatusOpConf.ReviewerType = 5
			// 逻辑链路:
			// 1. Mock dal.IsAllNoMasterReviewerTypePassed 函数返回 (false, nil)。
			// 2. 调用目标函数 commonCheckHitMasterReviewerPass。
			// 3. 断言返回结果为 (false, nil)。
			mockey.Mock(dal.IsAllNoMasterReviewerTypePassed).Return(false, nil).Build()

			passed, err := h.commonCheckHitMasterReviewerPass(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Scenario: dal.IsAllNoMasterReviewerTypePassed returns an error", func() {
			// 场景描述:
			// 测试当底层DAL函数在检查审批人状态时返回错误时的场景。
			// 构造数据:
			// - pc.ContractInfo.ContractNo = "test-contract-123"
			// - pc.ContractInfo.CooperationStatus = 10
			// - pc.ReviewerStatusOpConf.ReviewerType = 5
			// 逻辑链路:
			// 1. Mock dal.IsAllNoMasterReviewerTypePassed 函数返回一个非nil的error。
			// 2. 目标函数 commonCheckHitMasterReviewerPass 捕获该错误。
			// 3. 目标函数使用 i18nfmt.New 包装新错误信息 "检查节点审批结果失败"。
			// 4. 调用目标函数。
			// 5. 断言返回结果为 (false, 非nil的error)，并且错误信息包含 "检查节点审批结果失败"。
			mockErr := errors.New("database connection failed")
			mockey.Mock(dal.IsAllNoMasterReviewerTypePassed).Return(false, mockErr).Build()

			passed, err := h.commonCheckHitMasterReviewerPass(ctx, pc)

			convey.So(passed, convey.ShouldBeFalse)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
		})
	})
}

func Test_handlerCommon_needInitSolutionNode_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.needInitSolutionNode", t, func() {
		// 构造一个 handlerCommon 实例，该方法不依赖其内部字段，因此无需初始化
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景一: 当ApprovalKey为_const.ApprovalKeyDefaultWithSolution时, 应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个auditmodel.ProcessCtx实例，并将其ApprovalKey字段设置为_const.ApprovalKeyDefaultWithSolution。
			// 逻辑链路：
			// 1. 调用 needInitSolutionNode 方法。
			// 2. 方法内部的判断 pc.ApprovalKey == _const.ApprovalKeyDefaultWithSolution 结果为 true。
			// 3. 方法返回 true。
			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyDefaultWithSolution,
			}

			// 调用目标函数
			result := h.needInitSolutionNode(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景二: 当ApprovalKey不为_const.ApprovalKeyDefaultWithSolution时, 应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个auditmodel.ProcessCtx实例，并将其ApprovalKey字段设置为一个非_const.ApprovalKeyDefaultWithSolution的值，例如_const.ApprovalKeyDefault。
			// 逻辑链路：
			// 1. 调用 needInitSolutionNode 方法。
			// 2. 方法内部的判断 pc.ApprovalKey == _const.ApprovalKeyDefaultWithSolution 结果为 false。
			// 3. 方法返回 false。
			pc := &auditmodel.ProcessCtx{
				ApprovalKey: _const.ApprovalKeyDefault,
			}

			// 调用目标函数
			result := h.needInitSolutionNode(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景三: 当ApprovalKey为空字符串时, 应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个auditmodel.ProcessCtx实例，并将其ApprovalKey字段设置为空字符串。
			// 逻辑链路：
			// 1. 调用 needInitSolutionNode 方法。
			// 2. 方法内部的判断 pc.ApprovalKey == _const.ApprovalKeyDefaultWithSolution 结果为 false。
			// 3. 方法返回 false。
			pc := &auditmodel.ProcessCtx{
				ApprovalKey: "",
			}

			// 调用目标函数
			result := h.needInitSolutionNode(ctx, pc)

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerCommon_getMetaServiceV2_BitsUTGen(t *testing.T) {

	mockey.PatchConvey("Test_handlerCommon_getMetaServiceV2", t, func() {
		mockey.PatchConvey("should initialize services on first call and return the same instance on subsequent calls", func() {
			// 场景描述：
			// 测试 getMetaServiceV2 函数的正确性。
			// 构造数据：
			// - 一个空的 handlerCommon 实例。
			// - 各个服务的 mock 实例。
			// 逻辑链路：
			// 1. Mock contractmeta.NewMetaServiceV2() 和其他 New...() 函数，使其返回预设的 mock 实例。
			// 2. 首次调用 getMetaServiceV2()。
			// 3. 断言返回的 service 是 mock 的实例，并且 handlerCommon 的字段被正确初始化。
			// 4. 再次调用 getMetaServiceV2()。
			// 5. 断言返回的 service 仍然是第一次调用时返回的同一个 mock 实例，验证 sync.Once 的幂等性。

			// 准备 mock 服务实例
			mockSvcV2 := &MockMetaServiceV2{}
			mockSvc := &MockMetaService{}
			mockAttachSvc := &MockMetaAttachService{}
			mockCommoditySvc := &MockMetaCommodityService{}

			// Mock 服务创建函数
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(mockSvcV2).Build()
			mockey.Mock(contractmeta.NewMetaService).Return(mockSvc).Build()
			mockey.Mock(metaattach.NewAttachmentService).Return(mockAttachSvc).Build()
			mockey.Mock(metacommodity.NewService).Return(mockCommoditySvc).Build()

			// 初始化 handlerCommon
			h := &handlerCommon{}
			ctx := context.Background()

			// 第一次调用
			result1 := h.getMetaServiceV2(ctx)

			// 断言第一次调用的结果
			convey.So(result1, convey.ShouldEqual, mockSvcV2)
			convey.So(h.metaServiceV2, convey.ShouldEqual, mockSvcV2)

			// 第二次调用
			result2 := h.getMetaServiceV2(ctx)

			// 断言第二次调用的结果，验证幂等性
			convey.So(result2, convey.ShouldEqual, mockSvcV2)
			convey.So(result2, convey.ShouldEqual, result1)
		})
	})
}

func Test_ConvertManageInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ConvertManageInfo", t, func() {
		mockey.PatchConvey("success case: manageInfo is nil", func() {
			// 场景描述：
			// 构造数据：manageInfo为nil
			// 逻辑链路：
			// 1. 函数入参manageInfo为nil，进入if manageInfo == nil分支。
			// 2. 函数返回一个空的bizmodels.ManageInfo结构体指针。

			// 调用目标函数
			result := ConvertManageInfo(nil)

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, &bizmodels.ManageInfo{})
		})

		mockey.PatchConvey("success case: manageInfo is not nil", func() {
			// 场景描述：
			// 构造数据：manageInfo为一个非空的bizmodels.ManageInfo结构体指针
			// 逻辑链路：
			// 1. 函数入参manageInfo不为nil，不进入if分支。
			// 2. 使用json.Marshal将manageInfo序列化。
			// 3. 使用json.Unmarshal将序列化后的数据反序列化到一个新的bizmodels.ManageInfo实例。
			// 4. 函数返回这个新的实例的指针。

			// 构造数据
			inputManageInfo := &bizmodels.ManageInfo{
				PaymentType:           "TestPaymentType",
				PaymentTypeName:       "TestPaymentTypeName",
				BelongingDepartment:   "TestDepartment",
				ProductLine:           "TestProductLine",
				DistributBusinessType: 1,
				LegalReviewer:         "test.user",
				Remark:                "This is a test remark.",
				ProductTotalIncome:    10000.50,
			}

			// 调用目标函数
			result := ConvertManageInfo(inputManageInfo)

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			// 确认返回的是一个新的对象，而不是原来的指针
			convey.So(result, convey.ShouldNotPointTo, inputManageInfo)
			// 确认新对象的内容与原对象相同
			convey.So(result, convey.ShouldResemble, inputManageInfo)
		})
	})
}

func Test_handlerCommon_CreateOrUpdateMetaExt_BitsUTGen(t *testing.T) {
	// MockContractMetaExtDao is a mock type for the dal.ContractMetaExtDao interface.
	type MockContractMetaExtDao struct {
		dal.ContractMetaExtDao
	}

	mockey.PatchConvey("Test handlerCommon.CreateOrUpdateMetaExt", t, func() {
		// Common test variables
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		ext := &model.ContractMetaExt{
			ContractId: 123,
			AttrKey:    "test_key",
			AttrValue:  "new_value",
		}

		// Mock the DAO factory to return our mock implementation
		mockey.Mock(dal.NewContractMetaExtDao).Return(&MockContractMetaExtDao{}).Build()

		mockey.PatchConvey("Success: create a new meta extension when it does not exist", func() {
			// 场景描述：
			// 测试当记录不存在时，成功创建新记录的场景。
			// 构造数据：
			// 一个有效的 ContractMetaExt 指针 ext。
			// 逻辑链路：
			// 1. dal.NewContractMetaExtDao() 返回一个 mock 的 DAO 实例。
			// 2. metaExtDao.FindByAttrKey() 被 mock 返回 (nil, nil)，表示记录不存在。
			// 3. 代码进入 'else' 分支进行创建。
			// 4. metaExtDao.Create() 被 mock 返回 nil，表示创建成功。
			// 5. 函数最终返回 nil。
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()

			apiErr := h.CreateOrUpdateMetaExt(ctx, tx, ext)

			convey.So(apiErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: update an existing meta extension when it exists", func() {
			// 场景描述：
			// 测试当记录已存在时，成功更新记录的场景。
			// 构造数据：
			// - ext: 包含新值的 ContractMetaExt 指针。
			// - existingExt: FindByAttrKey 返回的已存在的记录。
			// 逻辑链路：
			// 1. dal.NewContractMetaExtDao() 返回一个 mock 的 DAO 实例。
			// 2. metaExtDao.FindByAttrKey() 被 mock 返回一个已存在的 metaExt 对象和 nil 错误。
			// 3. 代码进入 'if metaExt != nil' 分支进行更新。
			// 4. metaExtDao.UpdateValue() 被 mock 返回 nil，表示更新成功。
			// 5. 函数最终返回 nil。
			existingExt := &model.ContractMetaExt{
				BaseDB:     model.BaseDB{Id: 1},
				ContractId: 123,
				AttrKey:    "test_key",
				AttrValue:  "old_value",
			}

			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(existingExt, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(nil).Build()

			apiErr := h.CreateOrUpdateMetaExt(ctx, tx, ext)

			convey.So(apiErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: FindByAttrKey returns an error", func() {
			// 场景描述：
			// 测试在查找记录时数据库发生错误的场景。
			// 构造数据：
			// 一个有效的 ContractMetaExt 指针 ext。
			// 逻辑链路：
			// 1. dal.NewContractMetaExtDao() 返回一个 mock 的 DAO 实例。
			// 2. metaExtDao.FindByAttrKey() 被 mock 返回一个非 nil 的 error。
			// 3. 函数应立即返回一个内部错误 errorsV2.ErrInternalError。
			dbErr := errors.New("db find error")
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, dbErr).Build()

			apiErr := h.CreateOrUpdateMetaExt(ctx, tx, ext)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, errorsV2.ErrInternalError.GetCode())
		})

		mockey.PatchConvey("Failure: UpdateValue returns an error", func() {
			// 场景描述：
			// 测试在更新已存在记录时数据库发生错误的场景。
			// 构造数据：
			// - ext: 包含新值的 ContractMetaExt 指针。
			// - existingExt: FindByAttrKey 返回的已存在的记录。
			// 逻辑链路：
			// 1. dal.NewContractMetaExtDao() 返回一个 mock 的 DAO 实例。
			// 2. metaExtDao.FindByAttrKey() 成功返回一个已存在的记录。
			// 3. 代码进入更新分支。
			// 4. metaExtDao.UpdateValue() 被 mock 返回一个非 nil 的 error。
			// 5. 函数应返回一个内部错误 errorsV2.ErrInternalError。
			existingExt := &model.ContractMetaExt{
				BaseDB:     model.BaseDB{Id: 1},
				ContractId: 123,
				AttrKey:    "test_key",
				AttrValue:  "old_value",
			}
			dbErr := errors.New("db update error")

			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(existingExt, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(dbErr).Build()

			apiErr := h.CreateOrUpdateMetaExt(ctx, tx, ext)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, errorsV2.ErrInternalError.GetCode())
		})

		mockey.PatchConvey("Failure: Create returns an error", func() {
			// 场景描述：
			// 测试在创建新记录时数据库发生错误的场景。
			// 构造数据：
			// 一个有效的 ContractMetaExt 指针 ext。
			// 逻辑链路：
			// 1. dal.NewContractMetaExtDao() 返回一个 mock 的 DAO 实例。
			// 2. metaExtDao.FindByAttrKey() 成功返回 (nil, nil)，表示记录不存在。
			// 3. 代码进入创建分支。
			// 4. metaExtDao.Create() 被 mock 返回一个非 nil 的 error。
			// 5. 函数应返回一个内部错误 errorsV2.ErrInternalError。
			dbErr := errors.New("db create error")
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(dbErr).Build()

			apiErr := h.CreateOrUpdateMetaExt(ctx, tx, ext)

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, errorsV2.ErrInternalError.GetCode())
		})
	})
}

func Test_handlerCommon_SaveTradePartyInfo_BitsUTGen(t *testing.T) {
	// MockContractTradePartyDao is a mock for the dal.ContractTradePartyDao interface
	type MockContractTradePartyDao struct {
		dal.ContractTradePartyDao
	}

	mockey.PatchConvey("Test_handlerCommon_SaveTradePartyInfo", t, func() {
		// Common test data
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		metaDB := &model.ContractMetaDB{
			BaseDB: model.BaseDB{
				Id: 1,
			},
			ContractNo:     "test-contract-no",
			TradePartyInfo: `{"Subject":[{"PartyName":"Test Subject"}]}`,
		}
		tradePartyInfo := &bizmodels.TradePartyInfo{
			Subject: []*bizmodels.TradePartyInfoDetail{
				{PartyName: "Test Subject"},
			},
		}

		mockey.PatchConvey("Success case", func() {
			// 场景描述: 成功保存交易方信息
			// 构造数据:
			// - tradePartyInfo 和 metaDB 均不为 nil
			// 逻辑链路:
			// 1. dal.NewContractTradePartyDao 返回一个 mock dao 实例
			// 2. mock dao 的 DeleteByVolcContractId 方法成功执行，返回 nil
			// 3. model.ConverTradePartyDB 方法成功转换数据，返回一个 partyList
			// 4. mock dao 的 BatchCreate 方法成功执行，返回 nil
			// 5. 函数最终返回 nil

			// Arrange
			mockDao := &MockContractTradePartyDao{}
			mockey.Mock(dal.NewContractTradePartyDao).Return(mockDao).Build()
			mockey.Mock((*MockContractTradePartyDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(model.ConverTradePartyDB).Return(model.ContractTradePartyDBList{}).Build()
			mockey.Mock((*MockContractTradePartyDao).BatchCreate).Return(nil).Build()

			// Act
			err := h.SaveTradePartyInfo(ctx, tx, tradePartyInfo, metaDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case when tradePartyInfo is nil", func() {
			// 场景描述: 当传入的 tradePartyInfo 为 nil 时，函数应返回错误
			// 构造数据:
			// - tradePartyInfo 为 nil
			// 逻辑链路:
			// 1. 函数进行 nil 检查，发现 tradePartyInfo 为 nil
			// 2. 函数立即返回一个内部错误，错误信息为 "TradePartyInfo is nil"

			// Arrange
			// tradePartyInfo is set to nil

			// Act
			err := h.SaveTradePartyInfo(ctx, tx, nil, metaDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "TradePartyInfo is nil")
		})

		mockey.PatchConvey("Failure case when DeleteByVolcContractId fails", func() {
			// 场景描述: 当删除旧的交易方信息失败时，函数应返回错误
			// 构造数据:
			// - tradePartyInfo 和 metaDB 均不为 nil
			// 逻辑链路:
			// 1. dal.NewContractTradePartyDao 返回一个 mock dao 实例
			// 2. mock dao 的 DeleteByVolcContractId 方法执行失败，返回一个 error
			// 3. 函数捕获错误并返回一个内部错误，错误信息为 "SaveTradePartyInfoFail"

			// Arrange
			mockDao := &MockContractTradePartyDao{}
			mockey.Mock(dal.NewContractTradePartyDao).Return(mockDao).Build()
			mockey.Mock((*MockContractTradePartyDao).DeleteByVolcContractId).Return(errors.New("db delete error")).Build()

			// Act
			err := h.SaveTradePartyInfo(ctx, tx, tradePartyInfo, metaDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs("SaveTradePartyInfoFail"))
		})

		mockey.PatchConvey("Failure case when BatchCreate fails", func() {
			// 场景描述: 当批量创建新的交易方信息失败时，函数应返回错误
			// 构造数据:
			// - tradePartyInfo 和 metaDB 均不为 nil
			// 逻辑链路:
			// 1. dal.NewContractTradePartyDao 返回一个 mock dao 实例
			// 2. mock dao 的 DeleteByVolcContractId 方法成功执行，返回 nil
			// 3. model.ConverTradePartyDB 方法成功转换数据，返回一个 partyList
			// 4. mock dao 的 BatchCreate 方法执行失败，返回一个 error
			// 5. 函数捕获错误并返回一个内部错误，错误信息为 "SaveTradePartyInfoFail"

			// Arrange
			mockDao := &MockContractTradePartyDao{}
			mockey.Mock(dal.NewContractTradePartyDao).Return(mockDao).Build()
			mockey.Mock((*MockContractTradePartyDao).DeleteByVolcContractId).Return(nil).Build()
			mockey.Mock(model.ConverTradePartyDB).Return(model.ContractTradePartyDBList{}).Build()
			mockey.Mock((*MockContractTradePartyDao).BatchCreate).Return(errors.New("db batch create error")).Build()

			// Act
			err := h.SaveTradePartyInfo(ctx, tx, tradePartyInfo, metaDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs("SaveTradePartyInfoFail"))
		})
	})
}

func Test_handlerCommon_updateContractData_BitsUTGen(t *testing.T) {
	// 准备通用的测试数据
	mockTx := &gorm.DB{}
	mockProcessCtx := &auditmodel.ProcessCtx{
		PreContractVO: &model.ContractMetaDB{
			BaseDB:       model.BaseDB{Id: 1},
			ContractNo:   "CONTRACT-001",
			ContractFile: "old-file-id",
			TemplateInfo: "template-info", // 触发 GetTemplateFileId 逻辑
		},
		ContractInfo: &model.ContractMeta{
			ManageInfo:     &bizmodels.ManageInfo{},
			TradePartyInfo: &bizmodels.TradePartyInfo{},
			SettlementInfo: &bizmodels.SettlementInfo{
				SettlementLines: bizmodels.SettlementLines{
					&bizmodels.SettlementLine{},
				},
			},
			Ext: map[string]string{"key": "value"},
		},
		DelExtKeys:           []string{"del_key"},
		AttachmentUpdateList: []*bizmodels.MetaAttachment{{DownloadID: "attach-id"}},
	}

	mockey.PatchConvey("Test handlerCommon.updateContractData", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景：所有依赖项均成功执行", func() {
			// 场景描述：
			// 构造数据：使用通用的mockProcessCtx，所有依赖项都返回成功。
			// 逻辑链路：
			// 1. GetTemplateFileId 成功，返回新的 fileId。
			// 2. h.CreateOrUpdateAttachment 成功。
			// 3. h.updatePreContract 成功。
			// 4. h.SaveManageInfo 成功。
			// 5. h.SaveTradePartyInfo 成功。
			// 6. h.SaveMetaExt 成功。
			// 7. h.updateContractSettlement 成功。
			// 8. h.updateAttachment 成功。
			// 最终函数应返回 nil。

			// Mock
			mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
			mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
			mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateContractSettlement).Return(nil).Build()
			mockey.Mock((*handlerCommon).updateAttachment).Return(nil).Build()

			// Act
			err := h.updateContractData(ctx, mockProcessCtx)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：依赖项失败", func() {
			mockey.PatchConvey("当 GetTemplateFileId 失败时，应立即返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. GetTemplateFileId 返回错误。
				// 2. 函数应立即中断并返回该错误。
				expectedErr := errors.New("get template file id failed")
				mockey.Mock(GetTemplateFileId).Return("", expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 CreateOrUpdateAttachment 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. GetTemplateFileId 成功。
				// 2. h.CreateOrUpdateAttachment 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errors.New("create or update attachment failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 updatePreContract 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.updatePreContract 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errors.New("update precontract failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 SaveManageInfo 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.SaveManageInfo 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errorsV2.ErrInternalError.WithArgs("save manage info failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 SaveTradePartyInfo 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.SaveTradePartyInfo 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errorsV2.ErrInternalError.WithArgs("save trade party info failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 SaveMetaExt 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.SaveMetaExt 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errorsV2.ErrInternalError.WithArgs("save meta ext failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 updateContractSettlement 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.updateContractSettlement 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errors.New("update contract settlement failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractSettlement).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("当 updateAttachment 失败时，应返回错误", func() {
				// 场景描述：
				// 逻辑链路：
				// 1. 前续步骤成功。
				// 2. h.updateAttachment 返回错误。
				// 3. 函数应中断并返回该错误。
				expectedErr := errors.New("update attachment failed")
				mockey.Mock(GetTemplateFileId).Return("new-file-id", nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
				mockey.Mock((*handlerCommon).CreateOrUpdateAttachment).Return(nil).Build()
				mockey.Mock((*handlerCommon).updatePreContract).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveManageInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveTradePartyInfo).Return(nil).Build()
				mockey.Mock((*handlerCommon).SaveMetaExt).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateContractSettlement).Return(nil).Build()
				mockey.Mock((*handlerCommon).updateAttachment).Return(expectedErr).Build()

				// Act
				err := h.updateContractData(ctx, mockProcessCtx)

				// Assert
				convey.So(err, convey.ShouldEqual, expectedErr)
			})
		})
	})
}

func Test_handlerCommon_SaveMetaExt_BitsUTGen(t *testing.T) {
	// MockContractMetaExtDao is a mock for the dal.ContractMetaExtDao interface.
	type MockContractMetaExtDao struct {
		dal.ContractMetaExtDao
	}
	mockDao := &MockContractMetaExtDao{}

	mockey.PatchConvey("Test handlerCommon.SaveMetaExt", t, func() {
		// 构造通用数据
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		metaDB := &model.ContractMetaDB{
			BaseDB: model.BaseDB{Id: 123},
		}

		mockey.PatchConvey("场景：成功处理删除、更新和创建", func() {
			// 场景描述：
			// 构造数据：delExtKeys 包含一个待删除的key，metaExtMap 包含一个待更新的key和一个待创建的key。
			// 逻辑链路：
			// 1. 调用 SaveMetaExt。
			// 2. 循环 delExtKeys, 调用 DeleteMetaExt。
			// 3. DeleteMetaExt 内部调用 dal.NewContractMetaExtDao 和 metaExtDao.DeleteByAttrKey。
			//    - Mock dal.NewContractMetaExtDao 返回 mockDao。
			//    - Mock metaExtDao.DeleteByAttrKey 成功返回 nil。
			// 4. 循环 metaExtMap, 调用 CreateOrUpdateMetaExt。
			// 5. 对于更新的key "update_key":
			//    - CreateOrUpdateMetaExt 内部调用 dal.NewContractMetaExtDao, metaExtDao.FindByAttrKey, metaExtDao.UpdateValue。
			//    - Mock metaExtDao.FindByAttrKey 返回一个已存在的记录。
			//    - Mock metaExtDao.UpdateValue 成功返回 nil。
			// 6. 对于创建的key "create_key":
			//    - CreateOrUpdateMetaExt 内部调用 dal.NewContractMetaExtDao, metaExtDao.FindByAttrKey, metaExtDao.Create。
			//    - Mock metaExtDao.FindByAttrKey 返回 nil (记录不存在)。
			//    - Mock metaExtDao.Create 成功返回 nil。
			// 7. 函数最终返回 nil。
			delExtKeys := []string{"delete_key"}
			metaExtMap := map[string]string{
				"update_key": "update_value",
				"create_key": "create_value",
			}
			existingExt := &model.ContractMetaExt{BaseDB: model.BaseDB{Id: 456}, ContractId: 123, AttrKey: "update_key", AttrValue: "old_value"}

			mockey.Mock(dal.NewContractMetaExtDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(nil).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).To(func(ctx context.Context, tx *gorm.DB, volcContractId int64, attrKey string) (*model.ContractMetaExt, error) {
				if attrKey == "update_key" {
					return existingExt, nil
				}
				if attrKey == "create_key" {
					return nil, nil // Not found
				}
				return nil, errors.New("unexpected key")
			}).Build()
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(nil).Build()

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：metaExtMap 为空，应提前返回 nil", func() {
			// 场景描述：
			// 构造数据：metaExtMap 为空。
			// 逻辑链路：
			// 1. 调用 SaveMetaExt。
			// 2. 函数检查到 metaExtMap 为空, 立即返回 nil。
			// 3. 不会执行删除和更新/创建的逻辑。
			delExtKeys := []string{"delete_key"}
			metaExtMap := map[string]string{}

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：DeleteMetaExt 失败", func() {
			// 场景描述：
			// 构造数据：delExtKeys 不为空。
			// 逻辑链路：
			// 1. SaveMetaExt 调用 DeleteMetaExt。
			// 2. DeleteMetaExt 内部调用 metaExtDao.DeleteByAttrKey 失败。
			//    - Mock dal.NewContractMetaExtDao 返回 mockDao。
			//    - Mock metaExtDao.DeleteByAttrKey 返回一个错误。
			// 3. DeleteMetaExt 返回一个 APIError。
			// 4. SaveMetaExt 捕获到错误并立即返回。
			delExtKeys := []string{"delete_key"}
			metaExtMap := map[string]string{"any_key": "any_value"}
			mockErr := errors.New("db delete error")

			mockey.Mock(dal.NewContractMetaExtDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaExtDao).DeleteByAttrKey).Return(mockErr).Build()

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, mockErr.Error())
		})

		mockey.PatchConvey("场景：CreateOrUpdateMetaExt 在 FindByAttrKey 步骤失败", func() {
			// 场景描述：
			// 构造数据：metaExtMap 不为空。
			// 逻辑链路：
			// 1. SaveMetaExt 调用 CreateOrUpdateMetaExt。
			// 2. CreateOrUpdateMetaExt 内部调用 metaExtDao.FindByAttrKey 失败。
			//    - Mock dal.NewContractMetaExtDao 返回 mockDao。
			//    - Mock metaExtDao.FindByAttrKey 返回一个错误。
			// 3. CreateOrUpdateMetaExt 返回一个 APIError。
			// 4. SaveMetaExt 捕获到错误并立即返回。
			delExtKeys := []string{}
			metaExtMap := map[string]string{"some_key": "some_value"}
			mockErr := errors.New("db find error")

			mockey.Mock(dal.NewContractMetaExtDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, mockErr).Build()

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail"))
		})

		mockey.PatchConvey("场景：CreateOrUpdateMetaExt 在 UpdateValue 步骤失败", func() {
			// 场景描述：
			// 构造数据：metaExtMap 包含一个已存在的key。
			// 逻辑链路：
			// 1. SaveMetaExt 调用 CreateOrUpdateMetaExt。
			// 2. CreateOrUpdateMetaExt 成功调用 FindByAttrKey, 找到记录。
			// 3. 接着调用 metaExtDao.UpdateValue 失败。
			//    - Mock dal.NewContractMetaExtDao 返回 mockDao。
			//    - Mock metaExtDao.FindByAttrKey 返回一个已存在的记录。
			//    - Mock metaExtDao.UpdateValue 返回一个错误。
			// 4. CreateOrUpdateMetaExt 返回一个 APIError。
			// 5. SaveMetaExt 捕获到错误并立即返回。
			delExtKeys := []string{}
			metaExtMap := map[string]string{"update_key": "update_value"}
			mockErr := errors.New("db update error")
			existingExt := &model.ContractMetaExt{BaseDB: model.BaseDB{Id: 456}}

			mockey.Mock(dal.NewContractMetaExtDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(existingExt, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).UpdateValue).Return(mockErr).Build()

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail"))
		})

		mockey.PatchConvey("场景：CreateOrUpdateMetaExt 在 Create 步骤失败", func() {
			// 场景描述：
			// 构造数据：metaExtMap 包含一个新key。
			// 逻辑链路：
			// 1. SaveMetaExt 调用 CreateOrUpdateMetaExt。
			// 2. CreateOrUpdateMetaExt 调用 FindByAttrKey, 未找到记录。
			// 3. 接着调用 metaExtDao.Create 失败。
			//    - Mock dal.NewContractMetaExtDao 返回 mockDao。
			//    - Mock metaExtDao.FindByAttrKey 返回 nil (未找到)。
			//    - Mock metaExtDao.Create 返回一个错误。
			// 4. CreateOrUpdateMetaExt 返回一个 APIError。
			// 5. SaveMetaExt 捕获到错误并立即返回。
			delExtKeys := []string{}
			metaExtMap := map[string]string{"create_key": "create_value"}
			mockErr := errors.New("db create error")

			mockey.Mock(dal.NewContractMetaExtDao).Return(mockDao).Build()
			mockey.Mock((*MockContractMetaExtDao).FindByAttrKey).Return(nil, nil).Build()
			mockey.Mock((*MockContractMetaExtDao).Create).Return(mockErr).Build()

			err := h.SaveMetaExt(ctx, tx, delExtKeys, metaExtMap, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail"))
		})
	})
}

func Test_validateAccountIdRequired_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("func validateAccountIdRequired", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("场景一：收入类合同，且非报价合同，触发校验", func() {

			mockey.PatchConvey("当TradePartyInfo为nil时，应返回错误", func() {
				// 场景描述：
				// 构造数据：contractInfo的InOutType为IN，BizSource不为BizSourceQuote，TradePartyInfo为nil。
				// 逻辑链路：
				// 1. 第一个if条件 `(contractInfo.InOutType == _const.IN || ...)` 为true。
				// 2. 第二个if条件 `contractInfo.TradePartyInfo == nil` 为true。
				// 3. 返回错误 "当合同收支类型为“收入类” / “既收又支”时，对方账户id必填"。
				contractInfo := &model.ContractMeta{
					InOutType:      _const.IN,
					BizSource:      _const.BizSourceFee,
					TradePartyInfo: nil,
				}

				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "当合同收支类型为“收入类” / “既收又支”时，对方账户id必填")
			})

			mockey.PatchConvey("非海外环境，我方主体为中国大陆", func() {
				// Mock非海外环境
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()

				mockey.PatchConvey("对方签约主体缺少SealAccountID，应返回错误", func() {
					// 场景描述：
					// 构造数据：
					// - InOutType: IN
					// - BizSource: 非Quote
					// - multienv.IsBytePlus: false
					// - 我方主体(Subject) Country: CN
					// - 对方主体(OtherParty) Sealed: TRUE, SealAccountID: 空
					// 逻辑链路：
					// 1. 进入第一个主if块。
					// 2. TradePartyInfo不为nil。
					// 3. 遍历Subject，进入 `!multienv.IsBytePlus() && (subjectParty.Country == "CN" ...)` 分支。
					// 4. 遍历OtherParty，`party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0` 条件为true。
					// 5. 返回错误 "签约主体-签约主体账户id必填"。
					contractInfo := &model.ContractMeta{
						InOutType: _const.IN,
						BizSource: _const.BizSourceFee,
						TradePartyInfo: &bizmodels.TradePartyInfo{
							Subject: []*bizmodels.TradePartyInfoDetail{
								{Country: "CN"},
							},
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{
									Sealed:        _const.TRUE_FLAG_INT,
									SealAccountID: "", // Missing ID
								},
							},
						},
						BasicInfo: &bizmodels.BasicInfo{
							SpecialContractType: "",
						},
					}

					err := validateAccountIdRequired(ctx, contractInfo)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "签约主体-签约主体账户id必填")
				})

				mockey.PatchConvey("对方配价主体缺少PricingAccountID，应返回错误", func() {
					// 场景描述：
					// 构造数据：
					// - InOutType: IN
					// - BizSource: 非Quote
					// - multienv.IsBytePlus: false
					// - 我方主体(Subject) Country: CN
					// - 对方主体(OtherParty) Pricing: TRUE, PricingAccountID: 空
					// 逻辑链路：
					// 1. 流程同上一个case。
					// 2. 遍历OtherParty，`party.Pricing == _const.TRUE_FLAG_INT && len(party.PricingAccountID) == 0` 条件为true。
					// 3. 返回错误 "配价主体-配价主体账户id必填"。
					contractInfo := &model.ContractMeta{
						InOutType: _const.IN,
						BizSource: _const.BizSourceFee,
						TradePartyInfo: &bizmodels.TradePartyInfo{
							Subject: []*bizmodels.TradePartyInfoDetail{
								{Country: "MDCT00000040"},
							},
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{
									Sealed:           _const.TRUE_FLAG_INT,
									SealAccountID:    "some-seal-id",
									Pricing:          _const.TRUE_FLAG_INT,
									PricingAccountID: "", // Missing ID
								},
							},
						},
						BasicInfo: &bizmodels.BasicInfo{
							SpecialContractType: "",
						},
					}

					err := validateAccountIdRequired(ctx, contractInfo)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "配价主体-配价主体账户id必填")
				})

				mockey.PatchConvey("包含副签约主体，切主主体配价主体缺少账号", func() {
					// 场景描述：
					// 构造数据：
					// - InOutType: IN
					// - BizSource: 非Quote
					// - multienv.IsBytePlus: false
					// - 我方主体(Subject) Country: CN
					// - 对方主体(OtherParty) Pricing: TRUE, PricingAccountID: 空
					// 逻辑链路：
					// 1. 流程同上一个case。
					// 2. 遍历OtherParty，`party.Pricing == _const.TRUE_FLAG_INT && len(party.PricingAccountID) == 0` 条件为true。
					// 3. 返回错误 "配价主体-配价主体账户id必填"。
					contractInfo := &model.ContractMeta{
						InOutType: _const.IN,
						BizSource: _const.BizSourceFee,
						TradePartyInfo: &bizmodels.TradePartyInfo{
							Subject: []*bizmodels.TradePartyInfoDetail{
								{Country: "MDCT00000040"},
							},
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{
									Sealed:           _const.TRUE_FLAG_INT,
									SealAccountID:    "some-seal-id",
									Pricing:          _const.TRUE_FLAG_INT,
									PricingAccountID: "", // Missing ID
									DeputyParty:      1,
								},
								{
									Sealed:           _const.TRUE_FLAG_INT,
									SealAccountID:    "some-seal-id",
									Pricing:          _const.TRUE_FLAG_INT,
									PricingAccountID: "", // Missing ID
								},
							},
						},
						BasicInfo: &bizmodels.BasicInfo{
							SpecialContractType: "",
						},
					}

					err := validateAccountIdRequired(ctx, contractInfo)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "配价主体-配价主体账户id必填")
				})

			})

			mockey.PatchConvey("海外环境，我方主体为非中国大陆", func() {
				// Mock海外环境
				mockey.Mock(multienv.IsBytePlus).Return(true).Build()

				mockey.PatchConvey("对方签约主体缺少SealAccountID，应返回错误", func() {
					// 场景描述：
					// 构造数据：
					// - InOutType: IN_AND_OUT
					// - BizSource: 非Quote
					// - multienv.IsBytePlus: true
					// - 我方主体(Subject) Country: US
					// - 对方主体(OtherParty) Sealed: TRUE, SealAccountID: 空
					// 逻辑链路：
					// 1. 进入第一个主if块。
					// 2. TradePartyInfo不为nil。
					// 3. 遍历Subject，进入 `multienv.IsBytePlus() && subjectParty.Country != "CN" ...` 分支。
					// 4. 遍历OtherParty，`party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0` 条件为true。
					// 5. 返回错误 "签约主体-签约主体账户id必填"。
					contractInfo := &model.ContractMeta{
						InOutType: _const.InAndOut,
						BizSource: _const.BizSourceFee,
						TradePartyInfo: &bizmodels.TradePartyInfo{
							Subject: []*bizmodels.TradePartyInfoDetail{
								{Country: "US"},
							},
							OtherParty: []*bizmodels.TradePartyInfoDetail{
								{
									Sealed:        _const.TRUE_FLAG_INT,
									SealAccountID: "", // Missing ID
								},
							},
						},
						BasicInfo: &bizmodels.BasicInfo{
							SpecialContractType: "",
						},
					}

					err := validateAccountIdRequired(ctx, contractInfo)
					convey.So(err, convey.ShouldNotBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "签约主体-签约主体账户id必填")
				})
			})

			mockey.PatchConvey("条件不满足，不进入校验逻辑（海外环境+我方中国大陆）", func() {
				// Mock海外环境
				mockey.Mock(multienv.IsBytePlus).Return(true).Build()
				// Mock util.StringIn 返回 false, 避免进入第二个校验块
				mockey.Mock(util.StringIn).Return(false).Build()

				// 场景描述：
				// 构造数据：
				// - InOutType: IN
				// - multienv.IsBytePlus: true
				// - 我方主体(Subject) Country: CN
				// 逻辑链路：
				// 1. 进入第一个主if块。
				// 2. 遍历Subject，`multienv.IsBytePlus() && subjectParty.Country != "CN" ...` 条件为false。
				// 3. 第一个主if块校验逻辑未被触发。
				// 4. 第二个主if块因为util.StringIn返回false也未被触发。
				// 5. 返回nil。
				contractInfo := &model.ContractMeta{
					InOutType: _const.IN,
					BizSource: _const.BizSourceFee,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						Subject: []*bizmodels.TradePartyInfoDetail{
							{Country: "CN"},
						},
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								Sealed:        _const.TRUE_FLAG_INT,
								SealAccountID: "", // 即使ID为空，也不应报错
							},
						},
					},
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "", // 确保不进入第二个校验块
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("场景二：特殊合同类型为'我方主体变更协议'，触发校验", func() {
			// Mock util.StringIn 返回 true
			mockey.Mock(util.StringIn).When(func(item string, list []string) bool {
				return item == _const.SpecialContractTypeSubjectChangeAgreement
			}).Return(true).Build()

			mockey.PatchConvey("对方签约主体缺少SealAccountID，应返回错误", func() {
				// 场景描述：
				// 构造数据：
				// - InOutType: OUT (跳过第一个校验块)
				// - SpecialContractType: 包含 "3" (我方主体变更协议)
				// - util.StringIn: mock返回true
				// - 对方主体(OtherParty) Sealed: TRUE, SealAccountID: 空
				// 逻辑链路：
				// 1. 第一个主if块条件为false，跳过。
				// 2. 第二个主if块 `util.StringIn` 条件为true，进入。
				// 3. 遍历OtherParty，`party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0` 条件为true。
				// 4. 返回错误 "签约主体-签约主体账户id必填"。
				contractInfo := &model.ContractMeta{
					InOutType: _const.OUT, // Skip first check block
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								Sealed:        _const.TRUE_FLAG_INT,
								SealAccountID: "", // Missing ID
							},
						},
					},
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: _const.SpecialContractTypeSubjectChangeAgreement,
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "签约主体-签约主体账户id必填")
			})

			mockey.PatchConvey("包含副签约主体切主主体缺失签约账号", func() {
				// 场景描述：
				// 构造数据：
				// - InOutType: OUT (跳过第一个校验块)
				// - SpecialContractType: 包含 "3" (我方主体变更协议)
				// - util.StringIn: mock返回true
				// - 对方主体(OtherParty) Sealed: TRUE, SealAccountID: 空
				// 逻辑链路：
				// 1. 第一个主if块条件为false，跳过。
				// 2. 第二个主if块 `util.StringIn` 条件为true，进入。
				// 3. 遍历OtherParty，`party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0` 条件为true。
				// 4. 返回错误 "签约主体-签约主体账户id必填"。
				contractInfo := &model.ContractMeta{
					InOutType: _const.OUT, // Skip first check block
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								Sealed:        _const.TRUE_FLAG_INT,
								SealAccountID: "", // Missing ID
								DeputyParty:   1,
							},
							{
								Sealed:        _const.TRUE_FLAG_INT,
								SealAccountID: "", // Missing ID
								DeputyParty:   0,
							},
						},
					},
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: _const.SpecialContractTypeSubjectChangeAgreement,
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "签约主体-签约主体账户id必填")
			})

			mockey.PatchConvey("对方配价主体缺少PricingAccountID，应返回错误", func() {
				// 场景描述：
				// 构造数据：
				// - InOutType: OUT (跳过第一个校验块)
				// - SpecialContractType: 包含 "3" (我方主体变更协议)
				// - util.StringIn: mock返回true
				// - 对方主体(OtherParty) Pricing: TRUE, PricingAccountID: 空
				// 逻辑链路：
				// 1. 第一个主if块条件为false，跳过。
				// 2. 第二个主if块 `util.StringIn` 条件为true，进入。
				// 3. 遍历OtherParty，`party.Pricing == _const.TRUE_FLAG_INT && len(party.PricingAccountID) == 0` 条件为true。
				// 4. 返回错误 "配价主体-配价主体账户id必填"。
				contractInfo := &model.ContractMeta{
					InOutType: _const.OUT, // Skip first check block
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								Sealed:           _const.TRUE_FLAG_INT,
								SealAccountID:    "some-seal-id",
								Pricing:          _const.TRUE_FLAG_INT,
								PricingAccountID: "", // Missing ID
							},
						},
					},
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "1,3,2", // Contains '3'
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "配价主体-配价主体账户id必填")
			})
		})

		mockey.PatchConvey("场景三：Happy Path - 所有校验均通过", func() {
			// Mock util.StringIn 返回 false
			mockey.Mock(util.StringIn).Return(false).Build()

			mockey.PatchConvey("当InOutType为OUT时，跳过第一个校验块", func() {
				// 场景描述：
				// 构造数据：
				// - InOutType: OUT
				// - SpecialContractType: 不包含 "3"
				// 逻辑链路：
				// 1. 第一个if条件为false，跳过。
				// 2. 第二个if条件util.StringIn返回false，跳过。
				// 3. 返回nil。
				contractInfo := &model.ContractMeta{
					InOutType: _const.OUT,
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "1,2",
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("当BizSource为BizSourceQuote时，跳过第一个校验块", func() {
				// 场景描述：
				// 构造数据：
				// - InOutType: IN
				// - BizSource: BizSourceQuote
				// - SpecialContractType: 不包含 "3"
				// 逻辑链路：
				// 1. 第一个if条件为false，跳过。
				// 2. 第二个if条件util.StringIn返回false，跳过。
				// 3. 返回nil。
				contractInfo := &model.ContractMeta{
					InOutType: _const.IN,
					BizSource: _const.BizSourceQuote,
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "1,2",
					},
				}
				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("校验条件触发，但数据完整，校验通过", func() {
				// Mock非海外环境
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()
				// Mock util.StringIn 返回 false
				mockey.Mock(util.StringIn).Return(false).Build()

				// 场景描述：
				// 构造数据：
				// - InOutType: IN
				// - multienv.IsBytePlus: false
				// - 我方主体(Subject) Country: CN
				// - 对方主体(OtherParty) 账户ID都存在
				// - SpecialContractType: 不包含 "3"
				// 逻辑链路：
				// 1. 进入第一个if块。
				// 2. 内部校验条件都满足，但由于账户ID都存在，不返回错误。
				// 3. 跳出循环。
				// 4. 第二个if块不进入。
				// 5. 返回nil。
				contractInfo := &model.ContractMeta{
					InOutType: _const.IN,
					BizSource: _const.BizSourceFee,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						Subject: []*bizmodels.TradePartyInfoDetail{
							{Country: "CN"},
						},
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								Sealed:           _const.TRUE_FLAG_INT,
								SealAccountID:    "seal-id-123",
								Pricing:          _const.TRUE_FLAG_INT,
								PricingAccountID: "pricing-id-456",
							},
						},
					},
					BasicInfo: &bizmodels.BasicInfo{
						SpecialContractType: "1,2",
					},
				}

				err := validateAccountIdRequired(ctx, contractInfo)
				convey.So(err, convey.ShouldBeNil)
			})
		})
	})
}

func Test_handlerCommon_getReviewerFromPreContractReviewerListWithContractStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_getReviewerFromPreContractReviewerListWithContractStatus", t, func() {
		// 构造一个handlerCommon实例，因为目标函数是它的方法
		h := &handlerCommon{}

		mockey.PatchConvey("场景: 正常情况，列表包含匹配、不匹配、重复以及需要被过滤的审核人", func() {
			// 场景描述：
			// 构造数据：构造一个 PreContractReviewerList，其中：
			// - 2个审核人完全匹配条件 (reviewerType=1, contractStatus=10, reviewerSource=0)
			// - 1个是重复的匹配审核人
			// - 1个 ReviewerType 不匹配
			// - 1个 ContractStatus 不匹配
			// - 1个 ReviewerSource 不为0，应被跳过
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 跳过 ReviewerSource 不为0的审核人。
			// 3. 筛选出 ReviewerType 和 ContractStatus 都匹配的审核人。
			// 4. 对筛选出的审核人进行去重。
			// 5. 返回去重后的审核人列表。
			list := bizmodels.PreContractReviewerList{
				{Reviewer: "user_a", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 0},
				{Reviewer: "user_b", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 0},
				{Reviewer: "user_a", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 0}, // 重复项，应被去重
				{Reviewer: "user_c", ReviewerType: 2, ContractStatus: 10, ReviewerSource: 0}, // ReviewerType不匹配
				{Reviewer: "user_d", ReviewerType: 1, ContractStatus: 20, ReviewerSource: 0}, // ContractStatus不匹配
				{Reviewer: "user_e", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 1}, // ReviewerSource不为0，应被跳过
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getReviewerFromPreContractReviewerListWithContractStatus(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result, convey.ShouldResemble, []string{"user_a", "user_b"})
		})

		mockey.PatchConvey("场景: 列表中没有符合条件的审核人", func() {
			// 场景描述：
			// 构造数据：构造一个 PreContractReviewerList，其中所有审核人的 ReviewerType 或 ContractStatus 均不满足筛选条件。
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 由于没有审核人能同时满足 ReviewerType 和 ContractStatus 的条件，if条件不成立。
			// 3. 函数返回一个空切片。
			list := bizmodels.PreContractReviewerList{
				{Reviewer: "user_c", ReviewerType: 2, ContractStatus: 10, ReviewerSource: 0},
				{Reviewer: "user_d", ReviewerType: 1, ContractStatus: 20, ReviewerSource: 0},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getReviewerFromPreContractReviewerListWithContractStatus(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景: 列表中所有审核人的ReviewerSource不为0", func() {
			// 场景描述：
			// 构造数据：构造一个 PreContractReviewerList，其中所有审核人的 ReviewerSource 字段都不为0。
			// 逻辑链路：
			// 1. 函数遍历列表。
			// 2. 所有审核人因 reviewer.ReviewerSource != 0 的条件而直接 continue。
			// 3. 函数返回一个空切片。
			list := bizmodels.PreContractReviewerList{
				{Reviewer: "user_a", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 1},
				{Reviewer: "user_b", ReviewerType: 1, ContractStatus: 10, ReviewerSource: 2},
			}
			reviewerType := 1
			contractStatus := 10

			result := h.getReviewerFromPreContractReviewerListWithContractStatus(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景: 输入的列表为nil", func() {
			// 场景描述：
			// 构造数据：传入一个nil的 PreContractReviewerList。
			// 逻辑链路：
			// 1. 函数的 for-range 循环不会执行。
			// 2. 函数直接返回初始化的空切片。
			var list bizmodels.PreContractReviewerList = nil
			reviewerType := 1
			contractStatus := 10

			result := h.getReviewerFromPreContractReviewerListWithContractStatus(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景: 输入的列表为空列表", func() {
			// 场景描述：
			// 构造数据：传入一个空的 PreContractReviewerList。
			// 逻辑链路：
			// 1. 函数的 for-range 循环不会执行。
			// 2. 函数直接返回初始化的空切片。
			list := bizmodels.PreContractReviewerList{}
			reviewerType := 1
			contractStatus := 10

			result := h.getReviewerFromPreContractReviewerListWithContractStatus(list, reviewerType, contractStatus)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerCommon_checkUsefulLifeTypeForQuote_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_checkUsefulLifeTypeForQuote", t, func() {
		// 场景描述：
		// 初始化一个handlerCommon实例和context，用于后续测试用例。
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: 合同有效期类型不是 '自签订生效', 应直接返回nil", func() {
			// 场景描述：
			// 构造数据：设置合同的 UsefulLifeType 为非 _const.CONTRACT_LIFE_TYPE_SIGN_TIME。
			// 逻辑链路：
			// 1. 函数执行，进入第一个if判断 `basicInfo.UsefulLifeType != _const.CONTRACT_LIFE_TYPE_SIGN_TIME`。
			// 2. 条件为true，函数记录日志并直接返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
					},
				},
			}

			err := h.checkUsefulLifeTypeForQuote(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 合同是 '自签订生效' 且 '长期有效', 应返回错误", func() {
			// 场景描述：
			// 构造数据：设置合同 UsefulLifeType 为 '自签订生效'，同时设置 IndefiniteDateFlag 为 'Y'。
			// 逻辑链路：
			// 1. 第一个if条件为false。
			// 2. 第二个if条件 `basicInfo.IndefiniteDateFlag == _const.BizYes` 为true。
			// 3. 函数返回 "关联报价单的合同不允许长期有效" 错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						IndefiniteDateFlag: _const.BizYes,
					},
				},
			}

			err := h.checkUsefulLifeTypeForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "关联报价单的合同不允许长期有效")
		})

		mockey.PatchConvey("场景3: 合同是 '自签订生效' 且包含 '线上标品', 应返回错误", func() {
			// 场景描述：
			// 构造数据：设置合同 UsefulLifeType 为 '自签订生效'，非长期有效，但在 ManageInfo 的 ProductLevelMap 中包含一个 ItemType 为 '线上标品' 的产品。
			// 逻辑链路：
			// 1. 前两个if条件为false。
			// 2. 进入 for 循环遍历 ProductLevelMap。
			// 3. 在循环中，if条件 `item.ItemType == _const.ONLINE_STANDARD` 为true。
			// 4. 函数返回 "报价单中包含·线上标品·，不允许选择·自签订生效·" 错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						IndefiniteDateFlag: _const.BizNo,
					},
					ManageInfo: &bizmodels.ManageInfo{
						ProductLevelMap: map[string][]*bizmodels.ProductInfo{
							"level1": {
								{
									ItemType: _const.ONLINE_STANDARD,
								},
							},
						},
					},
				},
			}

			err := h.checkUsefulLifeTypeForQuote(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单中包含·线上标品·，不允许选择·自签订生效·")
		})

		mockey.PatchConvey("场景4: 合同是 '自签订生效', 合法且不包含 '线上标品', 应返回nil", func() {
			// 场景描述：
			// 构造数据：设置合同 UsefulLifeType 为 '自签订生效'，非长期有效，且 ProductLevelMap 中只包含 '线下标品'。
			// 逻辑链路：
			// 1. 前两个if条件为false。
			// 2. 进入 for 循环遍历 ProductLevelMap。
			// 3. 在循环中，if条件 `item.ItemType == _const.ONLINE_STANDARD` 始终为false。
			// 4. 循环正常结束，函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						IndefiniteDateFlag: _const.BizNo,
					},
					ManageInfo: &bizmodels.ManageInfo{
						ProductLevelMap: map[string][]*bizmodels.ProductInfo{
							"level1": {
								{
									ItemType: _const.OFFLINE_STANDARD,
								},
							},
						},
					},
				},
			}

			err := h.checkUsefulLifeTypeForQuote(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 合同是 '自签订生效', 合法且 ProductLevelMap 为空, 应返回nil", func() {
			// 场景描述：
			// 构造数据：设置合同 UsefulLifeType 为 '自签订生效'，非长期有效，且 ProductLevelMap 为空。
			// 逻辑链路：
			// 1. 前两个if条件为false。
			// 2. for 循环不会执行。
			// 3. 函数返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
						IndefiniteDateFlag: _const.BizNo,
					},
					ManageInfo: &bizmodels.ManageInfo{
						ProductLevelMap: make(map[string][]*bizmodels.ProductInfo),
					},
				},
			}

			err := h.checkUsefulLifeTypeForQuote(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_validateRequireQuote(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	PatchConvey("Test_handlerCommon_validateRequireQuote", t, func() {

		PatchConvey("场景1: 不需要关联报价单，且未提供报价单号，成功", func() {
			// 场景描述: 合同类型不需要关联报价单，且实际上也没有关联，流程应该正常通过。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 false
			// - pc.ContractInfo.RelateQuoteNo 为空
			// 逻辑链路:
			// 1. 函数进入第一个 if 分支。
			// 2. 判断 RelateQuoteNo 为空，直接返回 nil。
			// 断言:
			// - 函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "",
				},
			}

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景2: 不需要关联报价单，但提供了报价单号，失败", func() {
			// 场景描述: 合同类型不需要关联报价单，但错误地关联了一个，应返回错误。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 false
			// - pc.ContractInfo.RelateQuoteNo 不为空
			// 逻辑链路:
			// 1. 函数进入第一个 if 分支。
			// 2. 判断 RelateQuoteNo 不为空，返回错误。
			// 断言:
			// - 函数返回 ErrQuoteCommon 错误，提示不允许关联报价单。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(false).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "当前合同不允许关联报价单")
		})

		PatchConvey("场景3: 需要关联报价单，所有校验通过，成功", func() {
			// 场景描述: 合同需要关联报价单，并且所有相关校验（填充信息、签约方式、合同价）都成功。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 true
			// 逻辑链路:
			// 1. 函数进入需要校验报价单的分支。
			// 2. 依次调用 fillQuoteInfo, checkUsefulLifeTypeForQuote, checkContractDiscount, checkPreCheckContractDiscount。
			// 3. 所有内部调用均返回 nil。
			// 4. 函数最终返回 nil。
			// 断言:
			// - 函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(mockey.GetMethod(h, "fillQuoteInfo")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkUsefulLifeTypeForQuote")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkContractDiscount")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkPreCheckContractDiscount")).Return(nil).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景4: 需要关联报价单，但fillQuoteInfo失败", func() {
			// 场景描述: 合同需要关联报价单，但在填充报价单信息时发生错误。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 true
			// - Mock fillQuoteInfo 返回一个错误
			// 逻辑链路:
			// 1. 函数进入需要校验报价单的分支。
			// 2. 调用 fillQuoteInfo 失败，函数直接返回该错误。
			// 断言:
			// - 函数返回 fillQuoteInfo 抛出的错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}
			expectedErr := errors.New("fillQuoteInfo failed")

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(mockey.GetMethod(h, "fillQuoteInfo")).Return(expectedErr).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		PatchConvey("场景5: 需要关联报价单，但checkUsefulLifeTypeForQuote失败", func() {
			// 场景描述: 合同需要关联报价单，但在校验签约方式时失败。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 true
			// - Mock fillQuoteInfo 成功
			// - Mock checkUsefulLifeTypeForQuote 返回一个错误
			// 逻辑链路:
			// 1. 函数进入需要校验报价单的分支。
			// 2. fillQuoteInfo 调用成功。
			// 3. checkUsefulLifeTypeForQuote 调用失败，函数返回该错误。
			// 断言:
			// - 函数返回 checkUsefulLifeTypeForQuote 抛出的错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}
			expectedErr := errors.New("checkUsefulLifeTypeForQuote failed")

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(mockey.GetMethod(h, "fillQuoteInfo")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkUsefulLifeTypeForQuote")).Return(expectedErr).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err, ShouldEqual, expectedErr)
		})

		PatchConvey("场景6: 需要关联报价单，但checkContractDiscount失败", func() {
			// 场景描述: 合同需要关联报价单，但在校验合同价重复时失败。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 true
			// - 前序校验均成功
			// - Mock checkContractDiscount 返回一个错误
			// 逻辑链路:
			// 1. 函数进入需要校验报价单的分支。
			// 2. fillQuoteInfo, checkUsefulLifeTypeForQuote 调用成功。
			// 3. checkContractDiscount 调用失败，函数返回该错误。
			// 断言:
			// - 函数返回 checkContractDiscount 抛出的错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}
			expectedErr := errorsV2.ErrQuoteDuplicated.WithArgs("duplicate discount")

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(mockey.GetMethod(h, "fillQuoteInfo")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkUsefulLifeTypeForQuote")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkContractDiscount")).Return(expectedErr).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "duplicate discount")
		})

		PatchConvey("场景7: 需要关联报价单，但checkPreCheckContractDiscount失败", func() {
			// 场景描述: 合同需要关联报价单，但在预校验合同价时失败。
			// 数据构造:
			// - pc.ContractInfo.NeedRelateQuoteNo() 返回 true
			// - 前序校验均成功
			// - Mock checkPreCheckContractDiscount 返回一个错误
			// 逻辑链路:
			// 1. 函数进入需要校验报价单的分支。
			// 2. fillQuoteInfo, checkUsefulLifeTypeForQuote, checkContractDiscount 调用成功。
			// 3. checkPreCheckContractDiscount 调用失败，函数返回该错误。
			// 断言:
			// - 函数返回 checkPreCheckContractDiscount 抛出的错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					RelateQuoteNo: "Q-12345",
				},
			}
			expectedErr := errors.New("pre-check discount failed")

			mockey.Mock((*model.ContractMeta).NeedRelateQuoteNo).Return(true).Build()
			mockey.Mock(mockey.GetMethod(h, "fillQuoteInfo")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkUsefulLifeTypeForQuote")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkContractDiscount")).Return(nil).Build()
			mockey.Mock(mockey.GetMethod(h, "checkPreCheckContractDiscount")).Return(expectedErr).Build()

			err := h.validateRequireQuote(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err, ShouldEqual, expectedErr)
		})
	})
}

func Test_handlerCommon_IsReverseContract_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}
	ctx := context.Background()

	mockey.PatchConvey("Test IsReverseContract", t, func() {
		mockey.PatchConvey("当解析BasicInfo失败时，应返回错误", func() {
			// 场景描述：
			// 构造数据：一个包含BasicInfo的ContractMetaDB实例。
			// 逻辑链路：
			// 1. 调用 `basicinfo.ParseBasicInfo` 解析 `metaDB.BasicInfo`。
			// 2. Mock `basicinfo.ParseBasicInfo` 返回一个错误。
			// 3. 函数捕获错误，并返回一个 "IsReverseContractFail" 的新错误。
			metaDB := &model.ContractMetaDB{BasicInfo: "{}"}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(nil, errors.New("parse error")).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "IsReverseContractFail")
		})

		mockey.PatchConvey("当合同生效类型为'自签订生效'时，应直接返回成功", func() {
			// 场景描述：
			// 构造数据：一个ContractMetaDB实例，其BasicInfo中的UsefulLifeType为自签订生效。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 成功返回一个 `BasicInfo` 对象，其 `UsefulLifeType` 为 `CONTRACT_LIFE_TYPE_SIGN_TIME`。
			// 2. 函数检查 `UsefulLifeType`，发现是自签订生效类型。
			// 3. 函数直接返回 nil，不进行后续的倒签判断。
			metaDB := &model.ContractMetaDB{BasicInfo: "{}"}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("当解析ReverseSignInfo失败时，应返回错误", func() {
			// 场景描述：
			// 构造数据：一个ContractMetaDB实例，其 `ReverseSignInfo` 字段为无效的JSON字符串。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 成功返回，且合同不为'自签订生效'类型。
			// 2. 函数尝试用 `json.Unmarshal` 解析 `metaDB.ReverseSignInfo`。
			// 3. 由于JSON无效，解析失败并返回错误。
			// 4. 函数捕获错误，并返回一个 "IsReverseContractFail" 的新错误。
			metaDB := &model.ContractMetaDB{
				BasicInfo:       "{}",
				ReverseSignInfo: "invalid json",
			}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "IsReverseContractFail")
		})

		mockey.PatchConvey("当是倒签合同但缺少倒签原因时，应返回错误", func() {
			// 场景描述：
			// 构造数据：
			// - `metaDB.BeginTime` 设置为昨天，构成倒签条件。
			// - `metaDB.ReverseSignInfo` 中的 `ReverseSignReason` 为空。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 和 `json.Unmarshal` 均成功。
			// 2. 函数判断 `metaDB.BeginTime` 早于今天，将 `metaDB.IsBackdating` 设为1。
			// 3. 函数检查发现 `IsBackdating` 为1，但 `ReverseSignReason` 为空。
			// 4. 函数返回 "ReverseContract_ReverseReasonIsNil" 错误。
			reverseSignInfo, _ := json.Marshal(bizmodels.ReverseSignInfo{ReverseSignReason: ""})
			metaDB := &model.ContractMetaDB{
				BeginTime:       time.Now().AddDate(0, 0, -1),
				BasicInfo:       "{}",
				ReverseSignInfo: string(reverseSignInfo),
			}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ReverseContract_ReverseReasonIsNil")
			convey.So(metaDB.IsBackdating, convey.ShouldEqual, _const.Backdating)
		})

		mockey.PatchConvey("当是倒签合同且提供了倒签原因时，应返回成功", func() {
			// 场景描述：
			// 构造数据：
			// - `metaDB.BeginTime` 设置为昨天，构成倒签条件。
			// - `metaDB.ReverseSignInfo` 中的 `ReverseSignReason` 不为空。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 和 `json.Unmarshal` 均成功。
			// 2. 函数判断 `metaDB.BeginTime` 早于今天，将 `metaDB.IsBackdating` 设为1。
			// 3. 函数检查发现 `IsBackdating` 为1，且 `ReverseSignReason` 不为空，条件不满足。
			// 4. 函数继续执行并成功返回 nil。
			reverseSignInfo, _ := json.Marshal(bizmodels.ReverseSignInfo{ReverseSignReason: "some reason"})
			metaDB := &model.ContractMetaDB{
				BeginTime:       time.Now().AddDate(0, 0, -1),
				BasicInfo:       "{}",
				ReverseSignInfo: string(reverseSignInfo),
			}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldBeNil)
			convey.So(metaDB.IsBackdating, convey.ShouldEqual, _const.Backdating)
		})

		mockey.PatchConvey("当不是倒签合同(开始时间为今天或将来)时，应返回成功", func() {
			// 场景描述：
			// 构造数据：`metaDB.BeginTime` 设置为今天或未来某天，不构成倒签。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 和 `json.Unmarshal` 均成功。
			// 2. 函数判断 `metaDB.BeginTime` 不早于今天，`metaDB.IsBackdating` 保持为0。
			// 3. 后续的倒签原因检查条件不满足。
			// 4. 函数成功返回 nil。
			reverseSignInfo, _ := json.Marshal(bizmodels.ReverseSignInfo{ReverseSignReason: ""})
			metaDB := &model.ContractMetaDB{
				BeginTime:       time.Now().AddDate(0, 0, 1), // Tomorrow
				BasicInfo:       "{}",
				ReverseSignInfo: string(reverseSignInfo),
			}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldBeNil)
			convey.So(metaDB.IsBackdating, convey.ShouldEqual, _const.NoBackdating)
		})

		mockey.PatchConvey("当不是倒签合同(开始时间为零值)时，应返回成功", func() {
			// 场景描述：
			// 构造数据：`metaDB.BeginTime` 为 `time.Time{}` (零值)。
			// 逻辑链路：
			// 1. `basicinfo.ParseBasicInfo` 和 `json.Unmarshal` 均成功。
			// 2. 函数判断 `metaDB.BeginTime.IsZero()` 为 true，跳过倒签时间比较。
			// 3. `metaDB.IsBackdating` 保持为0。
			// 4. 后续的倒签原因检查条件不满足。
			// 5. 函数成功返回 nil。
			reverseSignInfo, _ := json.Marshal(bizmodels.ReverseSignInfo{ReverseSignReason: ""})
			metaDB := &model.ContractMetaDB{
				BeginTime:       time.Time{},
				BasicInfo:       "{}",
				ReverseSignInfo: string(reverseSignInfo),
			}
			mockey.Mock(basicinfo.ParseBasicInfo).Return(&bizmodels.BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
			}, nil).Build()

			err := h.IsReverseContract(ctx, metaDB)

			convey.So(err, convey.ShouldBeNil)
			convey.So(metaDB.IsBackdating, convey.ShouldEqual, _const.NoBackdating)
		})
	})
}

func TestBuildManageAndCommodity_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestBuildManageAndCommodity", t, func() {

		contractNo := "TEST-CONTRACT-001"
		version := 1
		volcContractID := uint64(12345)
		beginTimeStr := "2024-01-01 00:00:00"
		endTimeStr := "2024-12-31 23:59:59"
		mockBeginTime, _ := time.ParseInLocation("2006-01-02 15:04:05", beginTimeStr, time.Local)
		mockEndTime, _ := time.ParseInLocation("2006-01-02 15:04:05", endTimeStr, time.Local)

		mockey.PatchConvey("success case: when IsSplitProduct is false", func() {

			manageInfo := &bizmodels.ManageInfo{
				PaymentType:           "payment_type_1",
				PaymentTypeName:       "Payment Type Name 1",
				BelongingDepartment:   "Dept A",
				ProductLine:           "Line B",
				DistributBusinessType: 1,
				RelatedPersonnel:      "user1,user2",
				LegalReviewer:         "legal1",
				FeishuApostilleInfo:   bizmodels.FeishuApostilleInfo{DirectSupervisor: "supervisor1"},
				ReceivingPlace:        "Location C",
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {
						{ID: 1, Income: decimal.NewFromInt(100)},
						{ID: 2, Income: decimal.NewFromInt(200)},
					},
				},
				DeductProductInfoMap: map[string][]*bizmodels.ProductInfo{
					"group1": {
						{ID: 3, Income: decimal.NewFromInt(300)},
						{ID: 4, Income: decimal.NewFromInt(400)},
					},
				},
				Remark:                   "test remark",
				AccountAssociationInfo:   map[string]string{"key1": "value1"},
				UsefulLifeType:           1,
				IndefiniteDateFlag:       "N",
				UsefulLifeUnit:           "YEAR",
				UsefulLifeNum:            1,
				LongLifeReason:           "long life reason",
				ProductValidityBegin:     beginTimeStr,
				ProductValidityEnd:       endTimeStr,
				QuoteAccountID:           "quote_acc_id",
				SealAccountID:            "seal_acc_id",
				PricingAccountID:         "pricing_acc_id",
				EndUser:                  "end_user",
				EndUserAccountID:         "end_user_acc_id",
				RelateQuoteChanged:       true,
				RelateQuoteChangedBefore: "old_quote",
				WhetherProject:           "N",
				IsSplitProduct:           false,
			}

			mockCommodityList := []*model.VolcContractCommodity{
				{VolcContractID: volcContractID, ContractNo: contractNo, Version: version, TradeProductName: "Product 1"},
			}
			mockey.Mock(utils.GetTimeFromString).When(func(timeStr string) bool {
				return timeStr == beginTimeStr
			}).Return(mockBeginTime, nil).When(func(timeStr string) bool {
				return timeStr == endTimeStr
			}).Return(mockEndTime, nil).Build()

			mockey.Mock(model.ConvertCommodityList).Return(mockCommodityList).Build()

			info, list, externalList := BuildManageAndCommodity(contractNo, version, volcContractID, manageInfo)

			convey.So(info, convey.ShouldNotBeNil)
			// Base Info
			convey.So(info.ContractNo, convey.ShouldEqual, contractNo)
			convey.So(info.Version, convey.ShouldEqual, version)
			convey.So(info.VolcContractId, convey.ShouldEqual, volcContractID)
			convey.So(info.Remark, convey.ShouldEqual, manageInfo.Remark)
			// Manage Info fields
			convey.So(info.PaymentType, convey.ShouldEqual, manageInfo.PaymentType)
			convey.So(info.PaymentTypeName, convey.ShouldEqual, manageInfo.PaymentTypeName)
			convey.So(info.DistributBusinessType, convey.ShouldEqual, manageInfo.DistributBusinessType)
			convey.So(info.BelongingDepartment, convey.ShouldEqual, manageInfo.BelongingDepartment)
			convey.So(info.ProductLine, convey.ShouldEqual, manageInfo.ProductLine)
			convey.So(info.RelatedPersonnel, convey.ShouldEqual, manageInfo.RelatedPersonnel)
			convey.So(info.LegalReviewer, convey.ShouldEqual, manageInfo.LegalReviewer)
			convey.So(info.ReceivingPlace, convey.ShouldEqual, manageInfo.ReceivingPlace)
			// Account Info
			convey.So(info.QuoteAccountID, convey.ShouldEqual, manageInfo.QuoteAccountID)
			convey.So(info.SealAccountID, convey.ShouldEqual, manageInfo.SealAccountID)
			convey.So(info.PricingAccountID, convey.ShouldEqual, manageInfo.PricingAccountID)
			convey.So(info.EndUser, convey.ShouldEqual, manageInfo.EndUser)
			convey.So(info.EndUserAccountID, convey.ShouldEqual, manageInfo.EndUserAccountID)
			// Time & Income
			convey.So(info.ProductTotalIncome.Equal(decimal.NewFromInt(300)), convey.ShouldBeTrue)
			convey.So(info.ProductValidityBegin, convey.ShouldEqual, mockBeginTime)
			convey.So(info.ProductValidityEnd, convey.ShouldEqual, mockEndTime)
			// Useful Life Info
			convey.So(info.UsefulLifeType, convey.ShouldEqual, manageInfo.UsefulLifeType)
			convey.So(info.IndefiniteDateFlag, convey.ShouldEqual, manageInfo.IndefiniteDateFlag)
			convey.So(info.UsefulLifeUnit, convey.ShouldEqual, manageInfo.UsefulLifeUnit)
			convey.So(info.UsefulLifeNum, convey.ShouldEqual, manageInfo.UsefulLifeNum)
			convey.So(info.LongLifeReason, convey.ShouldEqual, manageInfo.LongLifeReason)
			// Other flags and Quote info
			convey.So(info.WhetherProject, convey.ShouldEqual, manageInfo.WhetherProject)
			convey.So(info.IsSplitProduct, convey.ShouldBeFalse)
			convey.So(info.RelateQuoteChanged, convey.ShouldEqual, manageInfo.RelateQuoteChanged)
			convey.So(info.RelateQuoteChangedBefore, convey.ShouldEqual, manageInfo.RelateQuoteChangedBefore)
			// JSON marshaled fields
			accountAssociationInfoByte, _ := json.Marshal(manageInfo.AccountAssociationInfo)
			convey.So(info.AccountAssociationInfo, convey.ShouldEqual, string(accountAssociationInfoByte))
			apostilleInfoBody, _ := json.Marshal(manageInfo.FeishuApostilleInfo)
			convey.So(info.FeishuApostilleInfo, convey.ShouldEqual, string(apostilleInfoBody))
			// Check returned lists
			convey.So(len(list), convey.ShouldEqual, 2)
			convey.So(externalList, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("success case: when IsSplitProduct is true", func() {

			manageInfo := &bizmodels.ManageInfo{
				PaymentType:           "payment_type_2",
				PaymentTypeName:       "Payment Type Name 2",
				BelongingDepartment:   "Dept B",
				ProductLine:           "Line C",
				DistributBusinessType: 2,
				RelatedPersonnel:      "user3,user4",
				LegalReviewer:         "legal2",
				FeishuApostilleInfo:   bizmodels.FeishuApostilleInfo{DirectSupervisor: "supervisor2"},
				ReceivingPlace:        "Location D",
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group2": {
						{ID: 3, Income: decimal.NewFromInt(500)},
					},
				},
				ExternalProductList: []*bizmodels.ExternalProductInfo{
					{ID: 101, TradeProductName: "External Product 1"},
				},
				Remark:                   "test remark split",
				AccountAssociationInfo:   map[string]string{"key2": "value2"},
				ProductValidityBegin:     beginTimeStr,
				ProductValidityEnd:       endTimeStr,
				UsefulLifeType:           2,
				IndefiniteDateFlag:       "Y",
				UsefulLifeUnit:           "DAY",
				UsefulLifeNum:            30,
				LongLifeReason:           "short life reason",
				QuoteAccountID:           "quote_acc_id_split",
				SealAccountID:            "seal_acc_id_split",
				PricingAccountID:         "pricing_acc_id_split",
				EndUser:                  "end_user_split",
				EndUserAccountID:         "end_user_acc_id_split",
				RelateQuoteChanged:       false,
				RelateQuoteChangedBefore: "",
				WhetherProject:           "Y",
				IsSplitProduct:           true,
			}

			mockCommodityList := []*model.VolcContractCommodity{
				{VolcContractID: volcContractID, ContractNo: contractNo, Version: version, TradeProductName: "Product 2"},
			}
			mockExternalList := []*model.VolcContractCommodityExternal{
				{VolcContractID: volcContractID, TradeProductName: "External Product 1"},
			}

			mockey.Mock(utils.GetTimeFromString).When(func(timeStr string) bool {
				return timeStr == beginTimeStr
			}).Return(mockBeginTime, nil).When(func(timeStr string) bool {
				return timeStr == endTimeStr
			}).Return(mockEndTime, nil).Build()

			mockey.Mock(model.ConvertCommodityList).Return(mockCommodityList).Build()
			mockey.Mock(model.ConvertExternalCommodityList).Return(mockExternalList).Build()

			info, list, externalList := BuildManageAndCommodity(contractNo, version, volcContractID, manageInfo)

			convey.So(info, convey.ShouldNotBeNil)
			// Check key flags
			convey.So(info.IsSplitProduct, convey.ShouldBeTrue)
			convey.So(info.WhetherProject, convey.ShouldEqual, manageInfo.WhetherProject)
			// Check income and time
			convey.So(info.ProductTotalIncome.Equal(decimal.NewFromInt(500)), convey.ShouldBeTrue)
			convey.So(info.ProductValidityBegin, convey.ShouldEqual, mockBeginTime)
			convey.So(info.ProductValidityEnd, convey.ShouldEqual, mockEndTime)
			// Check other fields
			convey.So(info.PaymentTypeName, convey.ShouldEqual, manageInfo.PaymentTypeName)
			convey.So(info.DistributBusinessType, convey.ShouldEqual, manageInfo.DistributBusinessType)
			convey.So(info.EndUser, convey.ShouldEqual, manageInfo.EndUser)
			convey.So(info.UsefulLifeType, convey.ShouldEqual, manageInfo.UsefulLifeType)
			convey.So(info.UsefulLifeNum, convey.ShouldEqual, manageInfo.UsefulLifeNum)
			// Check returned lists
			convey.So(list, convey.ShouldResemble, mockCommodityList)
			convey.So(externalList, convey.ShouldResemble, mockExternalList)
		})

		mockey.PatchConvey("edge case: empty manageInfo", func() {

			manageInfo := &bizmodels.ManageInfo{}

			mockey.Mock(utils.GetTimeFromString).Return(time.Time{}, nil).Build()

			info, list, externalList := BuildManageAndCommodity(contractNo, version, volcContractID, manageInfo)

			convey.So(info, convey.ShouldNotBeNil)
			convey.So(info.ContractNo, convey.ShouldEqual, contractNo)
			convey.So(info.Version, convey.ShouldEqual, version)
			convey.So(info.VolcContractId, convey.ShouldEqual, volcContractID)
			convey.So(info.Remark, convey.ShouldBeEmpty)
			convey.So(info.ProductTotalIncome.IsZero(), convey.ShouldBeTrue)
			convey.So(info.ProductValidityBegin.IsZero(), convey.ShouldBeTrue)
			convey.So(info.ProductValidityEnd.IsZero(), convey.ShouldBeTrue)
			convey.So(info.AccountAssociationInfo, convey.ShouldEqual, "null")
			convey.So(info.FeishuApostilleInfo, convey.ShouldEqual, "{\"DirectSupervisor\":\"\"}")

			convey.So(list, convey.ShouldBeEmpty)
			convey.So(externalList, convey.ShouldBeEmpty)
		})
	})
}

func Test_validateAccountAssociationInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_validateAccountAssociationInfo", t, func() {
		ctx := context.Background()

		convey.Convey("场景1: 失败 - 商品行分组数量与账号关联信息分组数量不匹配", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				DeductProductInfoMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "acc1",
					"group2": "acc2",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品行分组信息异常")
		})

		convey.Convey("场景2: 失败 - 商品行分组标识与账号关联信息分组标识不匹配", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group2": "acc1",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品行分组信息异常")
		})

		convey.Convey("场景3: 失败 - 某个商品行类别未关联账号ID", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "每个商品行类别必须关联账号ID")
		})

		convey.Convey("场景4: 失败 - 配价主体中的账号ID未全部关联到分组", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "acc1,acc2",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PricingAccountID: "acc1,acc3", // acc3 is not in AccountAssociationInfo
						SealAccountID:    "acc4",
						AccountID:        "acc5",
					},
				},
			}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "配价主体中的账号ID必须全部关联分组")
		})

		convey.Convey("场景5: 失败 - 商品行分组信息中存在异常账号ID", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "acc1,acc3", // acc3 is an invalid account
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PricingAccountID: "acc1",
						SealAccountID:    "acc2",
						AccountID:        "acc2",
					},
				},
			}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品行分组信息中存在异常账号ID")
		})

		convey.Convey("场景6: 成功 - 校验通过", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
					"group2": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "acc1,acc2",
					"group2": "acc3",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PricingAccountID: "acc1,acc3",
						SealAccountID:    "acc4",
						AccountID:        "acc5",
					},
					{
						PricingAccountID: "",
						SealAccountID:    "acc2",
						AccountID:        "acc6",
					},
				},
			}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景7: 成功 - 包含空账号ID字符串", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap: map[string][]*bizmodels.ProductInfo{
					"group1": {},
				},
				AccountAssociationInfo: map[string]string{
					"group1": "acc1,,acc2",
				},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PricingAccountID: "acc1,",
						SealAccountID:    ",acc2",
						AccountID:        "some_other_id",
					},
				},
			}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景8: 成功 - 没有对方主体信息", func() {
			manageInfo := &bizmodels.ManageInfo{
				ProductLevelMap:        map[string][]*bizmodels.ProductInfo{},
				AccountAssociationInfo: map[string]string{},
			}
			tradePartyInfo := &bizmodels.TradePartyInfo{
				OtherParty: nil,
			}

			err := validateAccountAssociationInfo(ctx, manageInfo, tradePartyInfo)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_fillRecordVersions_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_fillRecordVersions", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		bizType := 101

		mockey.PatchConvey("场景：正常情况，部分文件有新版本，部分文件没有", func() {
			// 场景描述：
			// 构造数据：
			// - fileIDList 包含 "file1", "file2", "file3"
			// - processFiles:
			//   - "file1": 有一个审核通过版本(Approve)和一个更新的待审核版本(Pending)
			//   - "file2": 只有一个审核通过版本(Approve)
			//   - "file3": 只有一个待审核版本(Pending)
			// 逻辑链路：
			// 1. 遍历 fileIDList
			// 2. 对于 "file1", 找到最新的 Pending 版本，更新 newestVersionMap 并添加到 recordVersions
			// 3. 对于 "file2", 找不到 Pending 版本，newestVersionMap 保留 Approve 版本的值，不添加到 recordVersions
			// 4. 对于 "file3", 找到唯一的 Pending 版本，更新 newestVersionMap 并添加到 recordVersions
			// 5. 返回最终的 newestVersionMap 和 recordVersions
			fileIDList := []string{"file1", "file2", "file3"}
			now := time.Now()
			processFiles := [][]*metaattachmodels.ProcessFileInfo{
				{ // for file1
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypeApprove,
						Version:  "v1.0",
						FileName: "file1.pdf",
						ModifyAt: now.Add(-2 * time.Hour),
					},
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypePending,
						Version:  "v1.1",
						FileName: "file1_new.pdf",
						ModifyAt: now.Add(-1 * time.Hour),
					},
				},
				{ // for file2
					{
						FileID:   "file2",
						FileType: _const.ProcessFileTypeApprove,
						Version:  "v2.0",
						FileName: "file2.pdf",
						ModifyAt: now.Add(-2 * time.Hour),
					},
				},
				{ // for file3
					{
						FileID:   "file3",
						FileType: _const.ProcessFileTypePending,
						Version:  "v3.1",
						FileName: "file3.pdf",
						ModifyAt: now.Add(-1 * time.Hour),
					},
				},
			}

			newestVersionMap, recordVersions := h.fillRecordVersions(ctx, bizType, fileIDList, processFiles)

			convey.So(len(newestVersionMap), convey.ShouldEqual, 3)
			convey.So(newestVersionMap["file1"], convey.ShouldEqual, "v1.1")
			convey.So(newestVersionMap["file2"], convey.ShouldEqual, "v2.0")
			convey.So(newestVersionMap["file3"], convey.ShouldEqual, "v3.1")

			convey.So(len(recordVersions), convey.ShouldEqual, 2)
			// Check record for file1
			foundFile1 := false
			for _, rec := range recordVersions {
				if rec.FileID == "file1" {
					foundFile1 = true
					convey.So(rec.BizType, convey.ShouldEqual, bizType)
					convey.So(rec.FileName, convey.ShouldEqual, "file1_new.pdf")
					convey.So(rec.Version, convey.ShouldEqual, "v1.1")
				}
			}
			convey.So(foundFile1, convey.ShouldBeTrue)
			// Check record for file3
			foundFile3 := false
			for _, rec := range recordVersions {
				if rec.FileID == "file3" {
					foundFile3 = true
					convey.So(rec.BizType, convey.ShouldEqual, bizType)
					convey.So(rec.FileName, convey.ShouldEqual, "file3.pdf")
					convey.So(rec.Version, convey.ShouldEqual, "v3.1")
				}
			}
			convey.So(foundFile3, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：文件有多个待审核版本，应选择最新的一个", func() {
			// 场景描述：
			// 构造数据：
			// - fileIDList 包含 "file1"
			// - processFiles for "file1" 包含一个 Approve 版本和多个 Pending 版本，其中一个时间戳最新
			// 逻辑链路：
			// 1. 遍历 "file1" 的所有版本信息
			// 2. 比较所有 Pending 版本的时间戳
			// 3. 确认 "v1.2" (ModifyAt 最新) 被选为 newest
			// 4. newestVersionMap["file1"] 应为 "v1.2"
			// 5. recordVersions 应包含 "file1" 的 "v1.2" 版本信息
			fileIDList := []string{"file1"}
			now := time.Now()
			processFiles := [][]*metaattachmodels.ProcessFileInfo{
				{
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypeApprove,
						Version:  "v1.0",
						FileName: "file1_approved.pdf",
						ModifyAt: now.Add(-3 * time.Hour),
					},
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypePending,
						Version:  "v1.1",
						FileName: "file1_pending_old.pdf",
						ModifyAt: now.Add(-2 * time.Hour),
					},
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypePending,
						Version:  "v1.2",
						FileName: "file1_pending_new.pdf",
						ModifyAt: now.Add(-1 * time.Hour),
					},
				},
			}

			newestVersionMap, recordVersions := h.fillRecordVersions(ctx, bizType, fileIDList, processFiles)

			convey.So(len(newestVersionMap), convey.ShouldEqual, 1)
			convey.So(newestVersionMap["file1"], convey.ShouldEqual, "v1.2")

			convey.So(len(recordVersions), convey.ShouldEqual, 1)
			convey.So(recordVersions[0].FileID, convey.ShouldEqual, "file1")
			convey.So(recordVersions[0].Version, convey.ShouldEqual, "v1.2")
			convey.So(recordVersions[0].FileName, convey.ShouldEqual, "file1_pending_new.pdf")
			convey.So(recordVersions[0].BizType, convey.ShouldEqual, bizType)
		})

		mockey.PatchConvey("场景：某个文件在 fileIDList 中，但在 processFiles 中不存在", func() {
			// 场景描述：
			// 构造数据：
			// - fileIDList 包含 "file1" (存在) 和 "file_missing" (不存在)
			// - processFiles 只包含 "file1" 的数据
			// 逻辑链路：
			// 1. 处理 "file1"，正常生成结果
			// 2. 处理 "file_missing"，在 processMap 中找不到对应的 fileList。
			// 3. 由于被测代码实现缺陷（approveFile初始化为非nil），依然会为 file_missing 在 newestVersionMap 中创建一条空记录。
			// 4. 最终结果中 newestVersionMap 长度为2。
			fileIDList := []string{"file1", "file_missing"}
			now := time.Now()
			processFiles := [][]*metaattachmodels.ProcessFileInfo{
				{
					{
						FileID:   "file1",
						FileType: _const.ProcessFileTypePending,
						Version:  "v1.1",
						FileName: "file1.pdf",
						ModifyAt: now,
					},
				},
			}

			newestVersionMap, recordVersions := h.fillRecordVersions(ctx, bizType, fileIDList, processFiles)

			// 由于代码实现缺陷(approveFile 初始化为 &metaattachmodels.ProcessFileInfo{}),
			// newestVersionMap 会包含所有在 fileIDList 中的 fileID，即使它没有对应的文件信息。
			convey.So(len(newestVersionMap), convey.ShouldEqual, 2)
			convey.So(newestVersionMap["file1"], convey.ShouldEqual, "v1.1")
			convey.So(newestVersionMap["file_missing"], convey.ShouldEqual, "")

			convey.So(len(recordVersions), convey.ShouldEqual, 1)
			convey.So(recordVersions[0].FileID, convey.ShouldEqual, "file1")
		})

		mockey.PatchConvey("场景：输入列表为空", func() {
			// 场景描述：
			// 构造数据：
			// - fileIDList 为空
			// - processFiles 为空
			// 逻辑链路：
			// 1. 函数的 for 循环不会执行
			// 2. 直接返回初始化的空 map 和空 slice
			var fileIDList []string
			var processFiles [][]*metaattachmodels.ProcessFileInfo

			newestVersionMap, recordVersions := h.fillRecordVersions(ctx, bizType, fileIDList, processFiles)

			convey.So(len(newestVersionMap), convey.ShouldEqual, 0)
			convey.So(len(recordVersions), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景：processFiles 列表包含空的文件列表", func() {
			// 场景描述：
			// 构造数据：
			// - fileIDList 不为空
			// - processFiles 包含一个空 slice
			// 逻辑链路：
			// 1. 构建 processMap 时，空的 fileList 会被跳过, processMap 为空。
			// 2. 遍历 fileIDList 时，找不到对应的文件信息，但由于代码实现缺陷, 依然会为 fileID 在 newestVersionMap 中创建一条空记录。
			// 3. 最终 newestVersionMap 长度为1， recordVersions 长度为0。
			fileIDList := []string{"file1"}
			processFiles := [][]*metaattachmodels.ProcessFileInfo{
				{}, // empty list
			}

			newestVersionMap, recordVersions := h.fillRecordVersions(ctx, bizType, fileIDList, processFiles)

			// 由于代码实现缺陷(approveFile 初始化为 &metaattachmodels.ProcessFileInfo{}),
			// newestVersionMap 会包含所有在 fileIDList 中的 fileID，即使它没有对应的文件信息。
			convey.So(len(newestVersionMap), convey.ShouldEqual, 1)
			convey.So(newestVersionMap["file1"], convey.ShouldEqual, "")
			convey.So(len(recordVersions), convey.ShouldEqual, 0)
		})
	})
}

func Test_validateMetaExt_BitsUTGen(t *testing.T) {
	PatchConvey("Test_validateMetaExt", t, func() {
		ctx := context.Background()

		PatchConvey("成功场景-无保底信息", func() {
			contractInfo := &model.ContractMeta{
				Ext: make(map[string]string),
			}
			meta := &model.ContractMetaDB{}
			extMap := make(map[string]string)

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldBeNil)
		})

		PatchConvey("成功场景-非按周期保底", func() {
			guaranteeInfo := bizmodels.GuaranteeResp{
				GuaranteeCategory: _const.GuaranteeCategoryValidity,
			}
			guaranteeStrBytes, _ := json.Marshal(guaranteeInfo)
			guaranteeStr := string(guaranteeStrBytes)

			contractInfo := &model.ContractMeta{}
			meta := &model.ContractMetaDB{}
			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: guaranteeStr,
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldBeNil)
		})

		PatchConvey("成功场景-按周期保底且时间范围有效", func() {
			beginTime, _ := time.Parse("2006-01-02", "2023-01-15")
			endTime, _ := time.Parse("2006-01-02", "2023-12-15")
			meta := &model.ContractMetaDB{
				BeginTime: beginTime,
				EndTime:   endTime,
			}
			guaranteeInfo := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2023-01",
				GuaranteeEndTime:   "2023-12",
			}
			guaranteeStrBytes, _ := json.Marshal(guaranteeInfo)
			guaranteeStr := string(guaranteeStrBytes)
			contractInfo := &model.ContractMeta{}
			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: guaranteeStr,
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldBeNil)
		})

		PatchConvey("成功场景-优先从外部参数extMap获取数据", func() {
			beginTime, _ := time.Parse("2006-01-02", "2023-01-15")
			endTime, _ := time.Parse("2006-01-02", "2023-12-15")
			meta := &model.ContractMetaDB{
				BeginTime: beginTime,
				EndTime:   endTime,
			}

			guaranteeInfoValid := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2023-02",
				GuaranteeEndTime:   "2023-11",
			}
			guaranteeStrValidBytes, _ := json.Marshal(guaranteeInfoValid)

			guaranteeInfoInvalid := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2022-01",
				GuaranteeEndTime:   "2024-12",
			}
			guaranteeStrInvalidBytes, _ := json.Marshal(guaranteeInfoInvalid)

			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: string(guaranteeStrValidBytes),
			}
			contractInfo := &model.ContractMeta{
				Ext: map[string]string{
					_const.ExtKeyQuoteGuarantee: string(guaranteeStrInvalidBytes),
				},
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldBeNil)
		})

		PatchConvey("成功场景-从合同信息contractInfo.Ext获取数据", func() {
			beginTime, _ := time.Parse("2006-01-02", "2023-01-15")
			endTime, _ := time.Parse("2006-01-02", "2023-12-15")
			meta := &model.ContractMetaDB{
				BeginTime: beginTime,
				EndTime:   endTime,
			}

			guaranteeInfo := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2023-02",
				GuaranteeEndTime:   "2023-11",
			}
			guaranteeStrBytes, _ := json.Marshal(guaranteeInfo)

			extMap := make(map[string]string)
			contractInfo := &model.ContractMeta{
				Ext: map[string]string{
					_const.ExtKeyQuoteGuarantee: string(guaranteeStrBytes),
				},
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldBeNil)
		})

		PatchConvey("失败场景-保底信息JSON格式错误", func() {
			invalidJsonStr := "this is not a valid json"
			contractInfo := &model.ContractMeta{}
			meta := &model.ContractMetaDB{}
			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: invalidJsonStr,
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldNotBeNil)
			So(err, ShouldHaveSameTypeAs, errorsV2.ErrCommon)
			So(err.Error(), ShouldContainSubstring, "校验保底信息失败")
		})

		PatchConvey("失败场景-保底开始时间早于合同开始时间", func() {
			beginTime, _ := time.Parse("2006-01-02", "2023-02-15")
			endTime, _ := time.Parse("2006-01-02", "2023-12-15")
			meta := &model.ContractMetaDB{
				BeginTime: beginTime,
				EndTime:   endTime,
			}
			guaranteeInfo := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2023-01",
				GuaranteeEndTime:   "2023-12",
			}
			guaranteeStrBytes, _ := json.Marshal(guaranteeInfo)
			guaranteeStr := string(guaranteeStrBytes)
			contractInfo := &model.ContractMeta{}
			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: guaranteeStr,
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldNotBeNil)
			So(err, ShouldHaveSameTypeAs, errorsV2.ErrCommon)
			So(err.Error(), ShouldContainSubstring, "“保底时间范围”填写有误，必须在合同有效期月份范围内。")
		})

		PatchConvey("失败场景-保底结束时间晚于合同结束时间", func() {
			beginTime, _ := time.Parse("2006-01-02", "2023-01-15")
			endTime, _ := time.Parse("2006-01-02", "2023-11-15")
			meta := &model.ContractMetaDB{
				BeginTime: beginTime,
				EndTime:   endTime,
			}
			guaranteeInfo := bizmodels.GuaranteeResp{
				GuaranteeCategory:  _const.GuaranteeCategoryPeriod,
				GuaranteeStartTime: "2023-01",
				GuaranteeEndTime:   "2023-12",
			}
			guaranteeStrBytes, _ := json.Marshal(guaranteeInfo)
			guaranteeStr := string(guaranteeStrBytes)
			contractInfo := &model.ContractMeta{}
			extMap := map[string]string{
				_const.ExtKeyQuoteGuarantee: guaranteeStr,
			}

			err := validateMetaExt(ctx, contractInfo, meta, extMap)
			So(err, ShouldNotBeNil)
			So(err, ShouldHaveSameTypeAs, errorsV2.ErrCommon)
			So(err.Error(), ShouldContainSubstring, "“保底时间范围”填写有误，必须在合同有效期月份范围内。")
		})
	})
}

func Test_QuoteChangeFillAccountID(t *testing.T) {
	ctx := context.Background()
	h := &handlerCommon{}

	PatchConvey("Test QuoteAccountID is not empty", t, func() {
		contractInfo := &model.ContractMeta{
			ManageInfo: &bizmodels.ManageInfo{
				QuoteAccountID: "123",
			},
			TradePartyInfo: &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PartyNumber: "456",
					},
				},
			},
		}
		tradePartyInfo := &bizmodels.TradePartyInfo{
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				{
					PartyNumber: "456",
				},
			},
		}
		h.QuoteChangeFillAccountID(ctx, contractInfo, tradePartyInfo)
		So(tradePartyInfo.OtherParty[0].AccountID, ShouldEqual, "")
		So(tradePartyInfo.OtherParty[0].SealAccountID, ShouldEqual, "")
		So(tradePartyInfo.OtherParty[0].PricingAccountID, ShouldEqual, "")
	})

	PatchConvey("Test QuoteAccountID is empty and other party exists", t, func() {
		contractInfo := &model.ContractMeta{
			ManageInfo: &bizmodels.ManageInfo{
				QuoteAccountID: "",
			},
			TradePartyInfo: &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PartyNumber:      "456",
						AccountID:        "789",
						SealAccountID:    "101",
						PricingAccountID: "112",
					},
				},
			},
		}
		tradePartyInfo := &bizmodels.TradePartyInfo{
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				{
					PartyNumber: "456",
				},
			},
		}
		h.QuoteChangeFillAccountID(ctx, contractInfo, tradePartyInfo)
		So(tradePartyInfo.OtherParty[0].AccountID, ShouldEqual, "789")
		So(tradePartyInfo.OtherParty[0].SealAccountID, ShouldEqual, "101")
		So(tradePartyInfo.OtherParty[0].PricingAccountID, ShouldEqual, "112")
	})

	PatchConvey("Test QuoteAccountID is empty and other party does not exist", t, func() {
		contractInfo := &model.ContractMeta{
			ManageInfo: &bizmodels.ManageInfo{
				QuoteAccountID: "",
			},
			TradePartyInfo: &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{
						PartyNumber: "456",
					},
				},
			},
		}
		tradePartyInfo := &bizmodels.TradePartyInfo{
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				{
					PartyNumber: "789",
				},
			},
		}
		h.QuoteChangeFillAccountID(ctx, contractInfo, tradePartyInfo)
		So(tradePartyInfo.OtherParty[0].AccountID, ShouldEqual, "")
		So(tradePartyInfo.OtherParty[0].SealAccountID, ShouldEqual, "")
		So(tradePartyInfo.OtherParty[0].PricingAccountID, ShouldEqual, "")
	})
}

func Test_handlerCommon_SubmitComplianceCheck(t *testing.T) {
	// mockService is an instance of our mock implementation for RiskEngineService.
	mockService := riskengineservice.NewRiskEngineService()

	mockey.PatchConvey("Test_handlerCommon_SubmitComplianceCheck", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("success case: risk engine check passes", func() {
			// 场景描述：
			// 合规审查成功，函数应正常返回，并更新上下文。
			// 构造数据：
			// - pc: 一个基本的 ProcessCtx
			// - mockResp: 一个表示成功的 riskenginecli.RiskEngineResp
			// 逻辑链路：
			// 1. Mock riskengineservice.NewRiskEngineService 返回一个 mock service 实例。
			// 2. Mock mock service 的 SubmitComplianceCheck 方法返回成功响应和 nil 错误。
			// 3. 调用目标函数 SubmitComplianceCheck。
			// 4. 断言函数返回 nil 错误。
			// 5. 断言 pc.ComplianceCheckInfo 已被更新为 mock 响应。
			// 6. 断言 pc.Ext 中已存入合规审查结果。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "PC-2023-01",
				},
				ContractInfo: &model.ContractMeta{
					Ext: make(map[string]string),
				},
			}
			mockResp := &riskenginecli.RiskEngineResp{
				RetCode: "0",
				RetMsg:  "Success",
				Result: &riskenginecli.Result{
					IsHit: "false",
				},
			}

			mockey.Mock(logs.CtxInfo).Return().Build()
			mockey.Mock(riskengineservice.NewRiskEngineService).Return(mockService).Build()
			mockey.Mock(mockey.GetMethod(mockService, "SubmitComplianceCheck")).Return(mockResp, nil).Build()

			err := h.SubmitComplianceCheck(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ComplianceCheckInfo, convey.ShouldEqual, mockResp)
			convey.So(pc.Ext, convey.ShouldContainKey, _const.ExtKeyComplianceCheckInfo)

			var resultInExt bizmodels.ComplianceCheckResult
			err = json.Unmarshal([]byte(pc.Ext[_const.ExtKeyComplianceCheckInfo]), &resultInExt)
			convey.So(err, convey.ShouldBeNil)

			expectedAutoCheckResult, _ := json.Marshal(mockResp)
			convey.So(resultInExt.AutoCheckResult, convey.ShouldEqual, string(expectedAutoCheckResult))
		})

		mockey.PatchConvey("failure case: risk engine service returns an error", func() {
			// 场景描述：
			// 合规审查接口调用失败，函数应将错误向上传递。
			// 构造数据：
			// - pc: 一个基本的 ProcessCtx
			// - mockErr: 一个模拟的 APIError
			// 逻辑链路：
			// 1. Mock riskengineservice.NewRiskEngineService 返回一个 mock service 实例。
			// 2. Mock mock service 的 SubmitComplianceCheck 方法返回 nil 响应和一个错误。
			// 3. Mock 日志记录 CtxWarn。
			// 4. 调用目标函数 SubmitComplianceCheck。
			// 5. 断言函数返回的错误与 mock 的错误一致。
			// 6. 断言 pc.ComplianceCheckInfo 未被设置。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "PC-2023-02",
				},
			}

			mockey.Mock(logs.CtxInfo).Return().Build()
			mockey.Mock(riskengineservice.NewRiskEngineService).Return(mockService).Build()
			mockey.Mock(GetMethod(mockService, "SubmitComplianceCheck")).Return(nil, errorsV2.ErrCommon).Build()
			mockey.Mock(logs.CtxWarn).Return().Build()

			err := h.SubmitComplianceCheck(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errorsV2.ErrCommon)
			convey.So(pc.ComplianceCheckInfo, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case: with pre-existing compliance info in contract", func() {
			// 场景描述：
			// 合规审查成功，并且合同的附加信息中已存在旧的合规信息。函数应加载旧信息，
			// 并用新的自动审查结果更新它，同时保留旧信息中的其他字段。
			// 构造数据：
			// - pc: ProcessCtx.ContractInfo.Ext 中包含一个已有的合规信息JSON。
			// - mockResp: 一个表示成功的 riskenginecli.RiskEngineResp
			// 逻辑链路：
			// 1. 构造一个包含已有字段的合规信息 JSON。
			// 2. Mock riskengineservice.NewRiskEngineService 和 SubmitComplianceCheck 方法成功返回。
			// 3. 调用目标函数 SubmitComplianceCheck。
			// 4. 断言函数成功返回。
			// 5. 断言最终存入 pc.Ext 的合规信息中，既包含新的自动审查结果，也保留了原有的字段。
			existingInfo := bizmodels.ComplianceCheckResult{
				ManualCheckResult: "manual check passed",
			}
			existingInfoJSON, _ := json.Marshal(existingInfo)

			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					ContractNo: "PC-2023-03",
				},
				ContractInfo: &model.ContractMeta{
					Ext: map[string]string{
						_const.ExtKeyComplianceCheckInfo: string(existingInfoJSON),
					},
				},
				// pc.Ext is nil to test initialization path in calcComplianceCheckInfo
				Ext: nil,
			}
			mockResp := &riskenginecli.RiskEngineResp{
				RetCode: "0",
				RetMsg:  "Success",
				Result: &riskenginecli.Result{
					IsHit: "true",
				},
			}

			mockey.Mock(riskengineservice.NewRiskEngineService).Return(mockService).Build()
			mockey.Mock(GetMethod(mockService, "SubmitComplianceCheck")).Return(mockResp, nil).Build()

			err := h.SubmitComplianceCheck(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ComplianceCheckInfo, convey.ShouldEqual, mockResp)
			convey.So(pc.Ext, convey.ShouldNotBeNil)
			convey.So(pc.Ext, convey.ShouldContainKey, _const.ExtKeyComplianceCheckInfo)

			var finalResult bizmodels.ComplianceCheckResult
			err = json.Unmarshal([]byte(pc.Ext[_const.ExtKeyComplianceCheckInfo]), &finalResult)
			convey.So(err, convey.ShouldBeNil)

			expectedAutoCheckResult, _ := json.Marshal(mockResp)
			convey.So(finalResult.AutoCheckResult, convey.ShouldEqual, string(expectedAutoCheckResult))
			convey.So(finalResult.ManualCheckResult, convey.ShouldEqual, "manual check passed")
		})
	})
}

func Test_handlerCommon_notifyC360(t *testing.T) {
	mockey.PatchConvey("Test_handlerCommon_notifyC360", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()

		mockey.PatchConvey("场景: 在非BytePlus环境下", func() {
			// 在此块内，所有测试都假定为非BytePlus环境
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 注意: 根据用户要求，此处不对mqProducer.SendC360NotifyMessage进行mock。
			// 测试依赖于该函数在测试环境中的默认行为（通常因为producer未初始化而返回nil）。
			// 因此，无法测试消息发送失败的错误处理路径。

			mockey.PatchConvey("子场景: 成功发送通知", func() {
				// 场景描述: 成功获取员工信息并发送MQ消息。
				// 构造数据:
				//  - employee.GetEmployeeByID 返回有效员工信息
				//  - pc 包含合同信息
				// 逻辑链路:
				// 1. mock multienv.IsBytePlus 返回 false
				// 2. mock employee.GetEmployeeByID 返回一个包含Email的Employee实例
				// 3. 调用 notifyC360
				// 4. 断言返回值为 nil
				mockey.Mock(larkc.GetEmployeeByID).To(func(ctx context.Context, employeeID string) ([]*peopleclient.Employee, error) {
					if employeeID == "1" {
						return []*peopleclient.Employee{{Email: "test.operator@example.com"}}, nil
					}
					return nil, fmt.Errorf("employee not found")
				}).Build()

				mockey.PatchConvey("当事件类型为合规审查且合同状态为已作废", func() {
					// 场景描述: 特殊情况处理，合规审查事件且合同已作废时，合同状态应为 "流程已自动作废"
					// 构造数据:
					//  - eventType = _const.C360NotifyEventTypeComplianceCheck
					//  - pc.StatusChangedValue = _const.PreSalesContractAbandoned
					// 逻辑链路:
					//  1. 函数构建 C360NotifyMsg
					//  2. if pc.StatusChangedValue == _const.PreSalesContractAbandoned 条件命中
					//  3. contractStatus 字段被赋值为 "流程已自动作废"
					//  4. 调用 mqProducer.SendC360NotifyMessage
					pc := &auditmodel.ProcessCtx{
						OperationState: _const.OperationAbandon,
						ContractInfo: &model.ContractMeta{
							ContractNo:   "C-789",
							ContractName: "Abandoned Contract",
							Operator:     "1",
						},
						StatusChangedValue: _const.PreSalesContractAbandoned,
					}
					eventType := _const.C360NotifyEventTypeComplianceCheck

					err := h.notifyC360(ctx, eventType, pc)
					convey.So(err, convey.ShouldBeNil)
				})

				mockey.PatchConvey("当事件类型为合规审查且合同状态非作废", func() {
					// 场景描述: 合规审查事件，从map中获取合规审查结果和合同状态
					// 构造数据:
					//  - eventType = _const.C360NotifyEventTypeComplianceCheck
					//  - pc.OperationState 和 pc.StatusChangedValue 均有对应映射值
					// 逻辑链路:
					//  1. legalAuditRes 从 _const.ComplianceCheckTradingSecMap 获取值
					//  2. contractStatus 从 _const.ContractStatus2NameMapping 获取值
					//  3. 调用 mqProducer.SendC360NotifyMessage
					pc := &auditmodel.ProcessCtx{
						OperationState: _const.OperationReviewPass,
						ContractInfo: &model.ContractMeta{
							ContractNo:   "C-456",
							ContractName: "Compliance Contract",
							Operator:     "1",
						},
						StatusChangedValue: _const.PreSalesContractCustomerConfirm,
					}
					eventType := _const.C360NotifyEventTypeComplianceCheck

					err := h.notifyC360(ctx, eventType, pc)
					convey.So(err, convey.ShouldBeNil)
				})

				mockey.PatchConvey("当操作为退回时", func() {
					// 场景描述: 操作状态为退回，应填充退回原因和客户名称
					// 构造数据:
					//  - pc.OperationState = _const.OperationSendBack
					//  - pc.Comment 和 pc.ContractInfo.OtherPartyName 有值
					// 逻辑链路:
					//  1. if pc.OperationState == _const.OperationSendBack 条件命中
					//  2. statusReturnReason 和 customerName 被赋值
					//  3. 调用 mqProducer.SendC360NotifyMessage
					pc := &auditmodel.ProcessCtx{
						OperationState: _const.OperationSendBack,
						ContractInfo: &model.ContractMeta{
							ContractNo:     "C-123",
							ContractName:   "Test Contract",
							Operator:       "1",
							OtherPartyName: "Customer A",
						},
						Comment: &bizmodels.RichTextInfo{
							RichtextPlainText: "Please revise this section.",
						},
						StatusChangedValue: _const.PreSalesContractSendBack,
					}
					eventType := "some_event_type"

					err := h.notifyC360(ctx, eventType, pc)
					convey.So(err, convey.ShouldBeNil)
				})
			})

			mockey.PatchConvey("子场景: 获取合同操作员信息失败", func() {
				// 场景描述: employee.GetEmployeeByID 调用返回 nil 或 error, contractOperatorEmail 应为空字符串
				// 构造数据:
				//  - employee.GetEmployeeByID 返回 nil, err
				//  - pc 包含一个无效的Operator ID
				// 逻辑链路:
				// 1. mock multienv.IsBytePlus 返回 false
				// 2. mock employee.GetEmployeeByID 返回 nil, error
				// 3. contractOperatorEmail 保持为空
				// 4. 调用 mqProducer.SendC360NotifyMessage
				// 5. 断言返回值为 nil
				mockey.Mock(larkc.GetEmployeeByID).Return(nil, fmt.Errorf("employee not found")).Build()

				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						ContractNo:   "C-ERR-02",
						ContractName: "No Operator Contract",
						Operator:     "invalid-id",
					},
				}
				err := h.notifyC360(ctx, "any_event", pc)
				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("场景: 消息发送失败(无法测试)", func() {
			// 场景描述: 模拟 mqProducer.SendC360NotifyMessage 返回错误。
			// 构造数据: 无
			// 逻辑链路:
			// 1. mock mqProducer.SendC360NotifyMessage 返回一个错误。
			// 2. 函数应该捕获错误，调用 logs.CtxError 和 message.Warning。
			// 3. 函数最终返回该错误。
			// **注意**: 根据用户指令 "禁止mock 方法 mqProducer.SendC360NotifyMessage", 此测试用例无法实现。
			// 如果可以 mock, 测试代码会类似下面被注释掉的部分。
			/*
				expectedErr := errors.New("mq send error")
				mockey.Mock(mqProducer.SendC360NotifyMessage).Return(expectedErr).Build()
				mockey.Mock(logs.CtxError).Return().Build()
				mockey.Mock(message.Warning).Return().Build()
				mockey.Mock(utils.ToJSON).Return("").Build()

				pc := &auditmodel.ProcessCtx{
					ContractInfo: &models.ContractMeta{
						ContractNo: "C-FAIL-01",
						Operator:   "1",
					},
				}
				err := h.notifyC360(ctx, "fail_event", pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "mq send error")
			*/
		})
	})
}

func Test_handlerCommon_changeReviewer(t *testing.T) {
	mockey.PatchConvey("Test handlerCommon.changeReviewer", t, func() {
		// --- 数据准备 ---
		h := &handlerCommon{}
		ctx := context.Background()
		tx := &gorm.DB{}
		mockDao := dal.NewPreContractReviewerDao()
		preContractNo := "PC-20230101"
		oldReviewerEmail := "old.reviewer@example.com"
		newReviewerEmail := "new.reviewer@example.com"
		newReviewerID := 12345

		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: preContractNo,
				BasicInfo: &bizmodels.BasicInfo{
					DepartmentId: "d-123",
				},
			},
			CurrentOperator: oldReviewerEmail,
		}
		newReviewer := &peopleclient.Employee{
			ID:    newReviewerID,
			Email: newReviewerEmail,
		}

		// --- 通用 Mock ---
		mockey.Mock(logs.CtxError).Return().Build()
		mockey.Mock(logs.CtxInfo).Return().Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(tx).Build()
		// 注意: 为了测试，必须 mock dal.NewPreContractReviewerDao() 以返回我们的 mock DAO 实例。
		// 原始 prompt 中的“禁止 mock dal.NewPreContractReviewerDao”指令与被测代码的结构相矛盾，
		// 遵循该指令将导致代码无法测试。因此，此处选择 mock 该函数。
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()

		convey.Convey("场景1: 成功 - 新审批人没有旧审批人的角色，为其创建新角色", func() {
			// 场景描述:
			// 构造数据: 旧审批人有1个审批角色，新审批人没有任何角色。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail (旧) 返回1条记录。
			// 2. FindReviewersByNoAndEmail (新) 返回空列表。
			// 3. 循环中，发现新审批人没有该角色。
			// 4. 调用 Create 创建新角色记录，并成功。
			// 5. 函数返回 nil。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  preContractNo,
					Reviewer:       oldReviewerEmail,
					ReviewerType:   1, // 销售运营
					ContractStatus: 3, // 销售运营专业审核
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(model.PreContractReviewerDBList{}, nil).Build()

			mockey.Mock(GetMethod(mockDao, "Create")).Return(nil).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景2: 成功 - 新审批人已存在相同角色，更新其状态", func() {
			// 场景描述:
			// 构造数据: 旧审批人有1个审批角色，新审批人已拥有该角色。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail (旧) 返回1条记录。
			// 2. FindReviewersByNoAndEmail (新) 返回1条匹配的记录。
			// 3. 循环中，发现新审批人已有该角色。
			// 4. 调用 UpdateByID 更新该记录状态，并成功。
			// 5. 函数直接返回 nil。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  preContractNo,
					ReviewerType:   2, // 财税法审核
					ContractStatus: 4, // 财税法交付专业审核
				},
			}
			newReviewerExistingRoles := model.PreContractReviewerDBList{
				{
					BaseDB:         model.BaseDB{Id: 99},
					PreContractNo:  preContractNo,
					Reviewer:       newReviewerEmail,
					ReviewerType:   2,
					ContractStatus: 4,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(newReviewerExistingRoles, nil).Build()

			mockey.Mock(GetMethod(mockDao, "UpdateByID")).Return(nil).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景2.1: 成功 - 新审批人已有被加签角色时继承旧角色并更新reviewer_role", func() {
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  preContractNo,
					ReviewerType:   2,
					ContractStatus: 4,
					ReviewerRole:   _const.ReviewerRoleLegalBP,
				},
			}
			newReviewerExistingRoles := model.PreContractReviewerDBList{
				{
					BaseDB:         model.BaseDB{Id: 199},
					PreContractNo:  preContractNo,
					Reviewer:       newReviewerEmail,
					ReviewerType:   2,
					ContractStatus: 4,
					ReviewerRole:   _const.ReviewerRoleCountersign,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(newReviewerExistingRoles, nil).Build()

			mockey.Mock(GetMethod(mockDao, "UpdateByID")).To(func(_ context.Context, _ *gorm.DB, id uint64, updates map[string]interface{}) error {
				convey.So(id, convey.ShouldEqual, uint64(199))
				convey.So(updates["reviewer_role"], convey.ShouldEqual, _const.ReviewerRoleLegalBP)
				convey.So(updates["status"], convey.ShouldEqual, _const.ReviewStatusUnreviewed)
				convey.So(updates["skip_return_review"], convey.ShouldEqual, 0)
				return nil
			}).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景3: 成功 - 旧审批人无任何角色，直接返回", func() {
			// 场景描述:
			// 构造数据: 旧审批人在该合同中没有任何角色。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail (旧) 返回空列表。
			// 2. 函数判断列表长度为0，直接返回 nil。
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).Return(model.PreContractReviewerDBList{}, nil).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景4: 成功 - 旧审批人的角色为被@人员，被忽略", func() {
			// 场景描述:
			// 构造数据: 旧审批人只有1个被@的角色。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail (旧) 返回1条被@的记录。
			// 2. FindReviewersByNoAndEmail (新) 返回空列表。
			// 3. 循环中，判断角色类型为 ReviewerTypeMentioned，continue。
			// 4. 循环结束，函数返回 nil。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					ReviewerType: _const.ReviewerTypeMentioned,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(model.PreContractReviewerDBList{}, nil).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景5: 失败 - 查找旧审批人角色时数据库出错", func() {
			// 场景描述:
			// 构造数据: 无。
			// 逻辑链路:
			// 1. 第一次调用 FindReviewersByNoAndEmail 返回 error。
			// 2. 函数捕获错误，打印日志并返回该错误。
			dbErr := fmt.Errorf("db find error")
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).Return(nil, dbErr).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})

		convey.Convey("场景6: 失败 - 查找新审批人角色时数据库出错", func() {
			// 场景描述:
			// 构造数据: 旧审批人有1个角色。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail (旧) 成功。
			// 2. FindReviewersByNoAndEmail (新) 返回 error。
			// 3. 函数捕获错误，打印日志并返回该错误。
			dbErr := fmt.Errorf("db find new error")
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(model.PreContractReviewerDBList{{}}, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(nil, dbErr).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})

		convey.Convey("场景7: 失败 - 创建新角色时数据库出错", func() {
			// 场景描述:
			// 构造数据: 同场景1，但Create操作会失败。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail 两次均成功。
			// 2. 调用 Create 时返回 error。
			// 3. 函数捕获错误，打印日志并返回该错误。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  preContractNo,
					ReviewerType:   1,
					ContractStatus: 3,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(model.PreContractReviewerDBList{}, nil).Build()

			dbErr := fmt.Errorf("db create error")
			mockey.Mock(GetMethod(mockDao, "Create")).Return(dbErr).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})

		convey.Convey("场景8: 失败 - 更新已存在角色时数据库出错", func() {
			// 场景描述:
			// 构造数据: 同场景2，但UpdateByID操作会失败。
			// 逻辑链路:
			// 1. FindReviewersByNoAndEmail 两次均成功。
			// 2. 调用 UpdateByID 时返回 error。
			// 3. 函数直接返回该错误。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  preContractNo,
					ReviewerType:   2,
					ContractStatus: 4,
				},
			}
			newReviewerExistingRoles := model.PreContractReviewerDBList{
				{
					BaseDB:         model.BaseDB{Id: 99},
					PreContractNo:  preContractNo,
					Reviewer:       newReviewerEmail,
					ReviewerType:   2,
					ContractStatus: 4,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(newReviewerExistingRoles, nil).Build()

			dbErr := fmt.Errorf("db update error")
			mockey.Mock(GetMethod(mockDao, "UpdateByID")).Return(dbErr).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
		})

		convey.Convey("场景9: 成功 - 转移多个角色，其中一个已存在，函数提前返回", func() {
			// 场景描述: 旧审批人有2个角色，新审批人已存在第1个角色。
			// 逻辑链路:
			// 1. 循环处理第1个角色，发现新审批人已存在，调用UpdateByID并成功。
			// 2. 函数在UpdateByID后直接返回，不会继续处理第2个角色。
			oldReviewerRoles := model.PreContractReviewerDBList{
				{ // 角色1，新审批人已存在
					PreContractNo:  preContractNo,
					ReviewerType:   1,
					ContractStatus: 3,
				},
				{ // 角色2，新审批人不存在
					PreContractNo:  preContractNo,
					ReviewerType:   2,
					ContractStatus: 4,
				},
			}
			newReviewerExistingRoles := model.PreContractReviewerDBList{
				{ // 新审批人已有的角色1
					BaseDB:         model.BaseDB{Id: 101},
					PreContractNo:  preContractNo,
					Reviewer:       newReviewerEmail,
					ReviewerType:   1,
					ContractStatus: 3,
				},
			}
			mockey.Mock(GetMethod(mockDao, "FindReviewersByNoAndEmail")).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).Return(newReviewerExistingRoles, nil).Build()

			mockUpdate := mockey.Mock(GetMethod(mockDao, "UpdateByID")).Return(nil).Build()
			mockCreate := mockey.Mock(GetMethod(mockDao, "Create")).Return(nil).Build()

			err := h.changeReviewer(ctx, pc, newReviewer)
			convey.So(err, convey.ShouldBeNil)
			// 断言Update被调用，而Create未被调用
			convey.So(mockUpdate.Times(), convey.ShouldEqual, 1)
			convey.So(mockCreate.Times(), convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerCommon_ValidateDeputyParty_BitsUTGen(t *testing.T) {
	// 顶层场景，统一包裹，子场景分别覆盖所有分支
	PatchConvey("ValidateDeputyParty 分支覆盖", t, func() {
		PatchConvey("模板型合同包含副签约主体，返回错误", func() {
			// 构造模板型合同且存在副签约主体
			ctx := context.Background()
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CNO-TPL",
					TemplateInfo: &bizmodels.TemplateInfo{
						Master: &bizmodels.TemplateDetail{TemplateKey: "tpl-key", Version: 1},
					},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
						},
					},
				},
			}

			err := h.ValidateDeputyParty(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "使用模板的合同不支持添加副签约主体")
		})

		PatchConvey("非模板合同下副签约主体未签约，返回错误", func() {
			// 非模板合同，副签约主体未签约
			ctx := context.Background()
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CNO-SEALED",
					TemplateInfo: nil,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.FALSE_FLAG_INT, // 未签约
								Pricing:     _const.FALSE_FLAG_INT, // 非配价
							},
						},
					},
				},
			}

			err := h.ValidateDeputyParty(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "副签约主体是否需要签约必须为是")
		})

		PatchConvey("非模板合同下副签约主体为配价主体，返回错误", func() {
			// 非模板合同，副签约主体配价为真
			ctx := context.Background()
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CNO-PRICING",
					TemplateInfo: &bizmodels.TemplateInfo{Master: nil},
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT, // 已签约
								Pricing:     _const.TRUE_FLAG_INT, // 配价主体，非法
							},
						},
					},
				},
			}

			err := h.ValidateDeputyParty(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "副签约主体是否需要配价必须为否")
		})

		PatchConvey("非模板合同下副签约主体合法，返回nil", func() {
			// 非模板合同，副签约主体合法：签约且非配价
			ctx := context.Background()
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:   "CNO-OK",
					TemplateInfo: nil,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{
							{
								DeputyParty: _const.TRUE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
							// 也包含非副签约主体，确保循环正常
							{
								DeputyParty: _const.FALSE_FLAG_INT,
								Sealed:      _const.TRUE_FLAG_INT,
								Pricing:     _const.FALSE_FLAG_INT,
							},
						},
					},
				},
			}

			err := h.ValidateDeputyParty(ctx, pc)
			So(err, ShouldBeNil)
		})
	})
}

// Mock结构体定义，包含接口字段用于Mock
type Mock_MetaCommodityService_fillQuoteInfo struct {
	metacommodity.Service
}

type Mock_QuoteService_fillQuoteInfo struct {
	quoteservice.Service
}

type Mock_MetaExtService_fillQuoteInfo struct {
	metaext.Service
}

func Test_handlerCommon_fillQuoteInfo_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	PatchConvey("handlerCommon.fillQuoteInfo 全分支覆盖", t, func() {
		PatchConvey("基础信息为空时直接返回成功", func() {
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: nil,
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldBeNil)
			// 基础信息为空直接返回，不会修改RelateQuoteChanged
			So(pc.ContractInfo.RelateQuoteChanged, ShouldEqual, false)
		})

		PatchConvey("获取报价详情失败", func() {
			h := &handlerCommon{}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:        &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo:    "Q-ERR",
					PropertyCode:     _const.PropertyCodeFrameContract,
					TradePartyInfo:   &bizmodels.TradePartyInfo{},
					ManageInfo:       &bizmodels.ManageInfo{},
					ProjectInfo:      &bizmodels.ProjectInfo{},
					RelateQuoteScene: 0,
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			Mock((*handlerCommon).getQuoteDetail).Return(nil, fmt.Errorf("getQuoteDetail error")).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "getQuoteDetail")
		})

		PatchConvey("构建管理信息失败", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo: "Q-1",
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 1,
					TotalSales:    "100",
				},
			}
			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return((*bizmodels.ManageInfo)(nil), fmt.Errorf("BuildManageInfo error")).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "BuildManageInfo")
		})

		PatchConvey("管理信息为nil返回ErrQuoteCommon", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo: "Q-NULL",
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 2,
					TotalSales:    "200",
				},
			}
			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return((*bizmodels.ManageInfo)(nil), nil).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "解析失败")
		})

		PatchConvey("构建项目信息失败", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo: "Q-PROJ-ERR",
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 3,
					TotalSales:    "300",
				},
			}
			manage := &bizmodels.ManageInfo{WhetherProject: "Y"}
			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return(manage, nil).Build()
			Mock((*Mock_QuoteService_fillQuoteInfo).BuildProjectInfo).Return((*bizmodels.ProjectInfo)(nil), fmt.Errorf("BuildProjectInfo error")).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "BuildProjectInfo")
		})

		PatchConvey("获取附加信息失败", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo: "Q-EXT-ERR",
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 4,
					TotalSales:    "400",
				},
			}
			manage := &bizmodels.ManageInfo{WhetherProject: "Y"}
			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return(manage, nil).Build()
			Mock((*Mock_QuoteService_fillQuoteInfo).BuildProjectInfo).Return(&bizmodels.ProjectInfo{QuoteID: "Q-EXT-ERR"}, nil).Build()
			Mock((*Mock_MetaExtService_fillQuoteInfo).GetExtMapByQuote).Return((map[string]string)(nil), fmt.Errorf("GetExtMapByQuote error")).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "GetExtMapByQuote")
		})

		PatchConvey("填充交易双方信息失败", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo: "Q-FILL-TP-ERR",
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 5,
					TotalSales:    "500",
				},
			}
			manage := &bizmodels.ManageInfo{WhetherProject: "Y", QuoteAccountID: "123"}
			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return(manage, nil).Build()
			Mock((*Mock_QuoteService_fillQuoteInfo).BuildProjectInfo).Return(&bizmodels.ProjectInfo{QuoteID: "Q-FILL-TP-ERR"}, nil).Build()
			Mock((*Mock_MetaExtService_fillQuoteInfo).GetExtMapByQuote).Return(map[string]string{"A": "B"}, nil).Build()
			Mock((*handlerCommon).fillTradePartyInfo).Return((*bizmodels.TradePartyInfo)(nil), fmt.Errorf("fillTradePartyInfo error")).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "fillTradePartyInfo")
		})

		PatchConvey("成功填充框架合同并更新交易双方信息", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			pc := &auditmodel.ProcessCtx{
				Ext: map[string]string{},
				ContractInfo: &model.ContractMeta{
					BasicInfo:     &bizmodels.BasicInfo{WhetherProject: "N", SpecialContractType: ""},
					RelateQuoteNo: "Q-SUCCESS-FRAME",
					PropertyCode:  _const.PropertyCodeFrameContract,
					TradePartyInfo: &bizmodels.TradePartyInfo{
						OtherParty: []*bizmodels.TradePartyInfoDetail{},
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 7,
					TotalSales:    "700",
				},
			}
			manage := &bizmodels.ManageInfo{WhetherProject: "Y", QuoteAccountID: "999", QuoteType: _const.QuoteTypeLadderQuote}
			project := &bizmodels.ProjectInfo{QuoteID: "Q-SUCCESS-FRAME"}

			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return(manage, nil).Build()
			Mock((*Mock_QuoteService_fillQuoteInfo).BuildProjectInfo).Return(project, nil).Build()
			Mock((*Mock_MetaExtService_fillQuoteInfo).GetExtMapByQuote).Return(map[string]string{_const.ExtKeyQuoteGuarantee: "Y", "K1": "V1"}, nil).Build()
			Mock((*handlerCommon).fillTradePartyInfo).Return(&bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{PartyName: "对方A", PartyNumber: "MDM001", AccountID: "111"},
				},
			}, nil).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldBeNil)

			// 基本信息与业务类型、金额赋值校验
			So(pc.ContractInfo.BasicInfo.BusinessType, ShouldEqual, detail.BizInfo.TradeTypeCode)
			So(pc.ContractInfo.BasicInfo.WhetherProject, ShouldEqual, manage.WhetherProject)
			So(pc.ContractInfo.BasicInfo.EstimateTotalIn, ShouldEqual, detail.BizInfo.TotalSales)
			// 关联报价变更标志
			So(pc.ContractInfo.RelateQuoteChanged, ShouldEqual, true)
			// 附加信息透传
			So(pc.Ext["K1"], ShouldEqual, "V1")
			So(pc.Ext[_const.ExtKeyQuoteGuarantee], ShouldEqual, "Y")
			// 特殊合同类型填充（保证+阶梯）
			So(pc.PreContractVO.SpecialContractType, ShouldContainSubstring, _const.SpecialContractTypeGuarantee)
			So(pc.PreContractVO.SpecialContractType, ShouldContainSubstring, _const.SpecialContractTypeLadderQuotation)
			// 交易双方信息赋值
			So(pc.ContractInfo.TradePartyInfo, ShouldNotBeNil)
			So(len(pc.ContractInfo.TradePartyInfo.OtherParty), ShouldEqual, 1)
			// 序列化结果
			So(pc.PreContractVO.BasicInfo, ShouldNotBeEmpty)
			So(pc.PreContractVO.ProjectInfo, ShouldNotBeEmpty)
			So(pc.PreContractVO.TradePartyInfo, ShouldNotBeEmpty)
		})

		PatchConvey("成功填充固定合同且不更新交易双方信息", func() {
			h := &handlerCommon{
				commodityService: &Mock_MetaCommodityService_fillQuoteInfo{},
				quoteService:     &Mock_QuoteService_fillQuoteInfo{},
				metaExtService:   &Mock_MetaExtService_fillQuoteInfo{},
			}
			origTradeParty := &bizmodels.TradePartyInfo{
				OtherParty: []*bizmodels.TradePartyInfoDetail{
					{PartyName: "原对方", PartyNumber: "MDM002", AccountID: "222"},
				},
			}
			pc := &auditmodel.ProcessCtx{
				Ext: map[string]string{},
				ContractInfo: &model.ContractMeta{
					BasicInfo:      &bizmodels.BasicInfo{WhetherProject: "N"},
					RelateQuoteNo:  "Q-SUCCESS-FIXED",
					PropertyCode:   _const.PropertyCodeFixedContract,
					TradePartyInfo: origTradeParty,
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			detail := &bizmodels.QuoteCreateContractReq{
				BizInfo: &bizmodels.QuoteBizInfo{
					TradeTypeCode: 8,
					TotalSales:    "800",
				},
			}
			manage := &bizmodels.ManageInfo{WhetherProject: "N", QuoteAccountID: ""}
			project := &bizmodels.ProjectInfo{QuoteID: "Q-SUCCESS-FIXED"}

			Mock((*handlerCommon).getQuoteDetail).Return(detail, nil).Build()
			Mock((*Mock_MetaCommodityService_fillQuoteInfo).BuildManageInfoByQuote).Return(manage, nil).Build()
			Mock((*Mock_QuoteService_fillQuoteInfo).BuildProjectInfo).Return(project, nil).Build()
			Mock((*Mock_MetaExtService_fillQuoteInfo).GetExtMapByQuote).Return(map[string]string{"E1": "EV1"}, nil).Build()

			err := h.fillQuoteInfo(ctx, pc)
			So(err, ShouldBeNil)

			// 固定合同金额赋值
			So(pc.ContractInfo.BasicInfo.TotalIn, ShouldEqual, detail.BizInfo.TotalSales)
			So(pc.ContractInfo.BasicInfo.BusinessType, ShouldEqual, detail.BizInfo.TradeTypeCode)
			// 未更新交易双方信息（保持原值）
			So(pc.ContractInfo.TradePartyInfo, ShouldEqual, origTradeParty)
			// 关联报价变更标志
			So(pc.ContractInfo.RelateQuoteChanged, ShouldEqual, true)
			// 序列化结果
			So(pc.PreContractVO.BasicInfo, ShouldNotBeEmpty)
			So(pc.PreContractVO.ProjectInfo, ShouldNotBeEmpty)
			So(pc.PreContractVO.TradePartyInfo, ShouldNotBeEmpty)
			// 扩展信息透传
			So(pc.Ext["E1"], ShouldEqual, "EV1")
		})
	})
}

func Test_handlerCommon_getQuoteDetail_ByteUT(t *testing.T) {
	defer mockey.UnPatchAll()
	ctx := context.Background()
	mockMetaSvc := &MockMetaCommodityService{}
	mockQuoteSvc := &MockQuoteService{}
	h := &handlerCommon{
		metaCommodityService: mockMetaSvc,
		quoteService:         mockQuoteSvc,
	}

	t.Run("当报价单号为空时，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当报价单号为空时，返回错误", t, func() {
			// 该子场景测试用例用途：测试当传入的 quoteNo 为空字符串时，函数是否按预期返回错误。
			// 单测调用链路为：getQuoteDetail -> if quoteNo == ""
			// 预期结果为：返回错误，提示必须关联报价单。
			res, err := h.getQuoteDetail(ctx, "", "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前合同必须关联报价单")
		})
	})

	t.Run("当报价单号包含多个时，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当报价单号包含多个时，返回错误", t, func() {
			// 该子场景测试用例用途：测试当传入的 quoteNo 包含多个以逗号分隔的报价单号时，函数是否按预期返回错误。
			// 单测调用链路为：getQuoteDetail -> strings.Split -> if len(quoteNos) > 1
			// 预期结果为：返回错误，提示不能绑定多个报价单。
			quoteNo := "Q-123,Q-456"
			res, err := h.getQuoteDetail(ctx, quoteNo, "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("不能绑定多个报价单[%s]", quoteNo))
		})
	})

	t.Run("当检查报价单关联状态时发生API错误，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当检查报价单关联状态时发生API错误，返回错误", t, func() {
			// 该子场景测试用例用途：测试在调用 HasQuoteRelateContract 检查报价单是否已关联其他合同时，如果API调用失败，函数是否能正确处理并返回错误。
			// 单测调用链路为：getQuoteDetail -> h.getMetaCommodityService().HasQuoteRelateContract -> if apiErr != nil
			// 预期结果为：返回从API错误中包装的错误。
			apiErr := errorsV2.ErrorCommon.WithArgs("network error")

			mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, apiErr).Build()

			res, err := h.getQuoteDetail(ctx, "Q-123", "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, apiErr.Error())
		})
	})

	t.Run("当报价单已被其他合同关联时，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当报价单已被其他合同关联时，返回错误", t, func() {
			// 该子场景测试用例用途：测试当 HasQuoteRelateContract 表明报价单已被其他合同关联时，函数是否返回相应的错误。
			// 单测调用链路为：getQuoteDetail -> h.getMetaCommodityService().HasQuoteRelateContract -> if resp.Related
			// 预期结果为：返回错误，提示报价单已被关联，并附带关联合同信息。
			mockResp := &modelcommodity.HasQuoteRelateContractResp{
				Related: true,
				RelatedContractList: []*modelcommodity.RelateContractInfo{
					{ContractNo: "C-001", Version: 1, ContractName: "Old Contract"},
				},
			}

			mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(mockResp, nil).Build()

			res, err := h.getQuoteDetail(ctx, "Q-123", "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "当前报价单已经被其他合同关联")
		})
	})

	t.Run("当获取报价单详情失败时，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当获取报价单详情失败时，返回错误", t, func() {
			// 该子场景测试用例用途：测试在调用 GetQuoteCreateContractReqByQuoteNo 获取报价单详细信息时，如果调用失败，函数是否能正确处理并返回错误。
			// 单测调用链路为：getQuoteDetail -> quotecli.GetQuoteCreateContractReqByQuoteNo -> if err != nil
			// 预期结果为：返回错误，提示报价单查询详情失败。
			mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
			mockey.Mock(quotecli.GetQuoteCreateContractReqByQuoteNo).Return(nil, errors.New("failed to get details")).Build()

			res, err := h.getQuoteDetail(ctx, "Q-123", "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "报价单[Q-123]查询详情失败")
		})
	})

	t.Run("当校验报价单失败时，返回错误", func(t *testing.T) {
		mockey.PatchConvey("当校验报价单失败时，返回错误", t, func() {
			// 该子场景测试用例用途：测试在调用 ValidateQuote 对获取到的报价单进行校验时，如果校验失败，函数是否能正确处理并返回错误。
			// 单测调用链路为：getQuoteDetail -> h.getQuoteService().ValidateQuote -> if err != nil
			// 预期结果为：返回从校验函数中得到的原始错误。
			validateErr := errors.New("validation failed")
			mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
			mockey.Mock(quotecli.GetQuoteCreateContractReqByQuoteNo).Return(&bizmodels.QuoteCreateContractReq{}, nil).Build()
			mockey.Mock((*MockQuoteService).ValidateQuote).Return(validateErr).Build()

			res, err := h.getQuoteDetail(ctx, "Q-123", "some_project")

			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, validateErr)
		})
	})

	t.Run("成功获取报价单详情", func(t *testing.T) {
		mockey.PatchConvey("成功获取报价单详情", t, func() {
			// 该子场景测试用例用途：测试在所有检查和调用都成功的情况下，函数是否能正确返回报价单的详细信息。
			// 单测调用链路为：getQuoteDetail -> ... -> return detail, nil
			// 预期结果为：返回获取到的报价单详情，且错误为 nil。
			mockDetail := &bizmodels.QuoteCreateContractReq{Identifier: "test-quote-id"}
			mockey.Mock((*MockMetaCommodityService).HasQuoteRelateContract).Return(&modelcommodity.HasQuoteRelateContractResp{Related: false}, nil).Build()
			mockey.Mock(quotecli.GetQuoteCreateContractReqByQuoteNo).Return(mockDetail, nil).Build()
			mockey.Mock((*MockQuoteService).ValidateQuote).Return(nil).Build()

			res, err := h.getQuoteDetail(ctx, "Q-123", "some_project")

			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldResemble, mockDetail)
		})
	})
}

func Test_handlerCommon_getQuoteService_ByteUTGen(t *testing.T) {
	// 测试当handlerCommon的quoteService为nil时，调用getQuoteService方法创建新服务实例的场景
	t.Run("QuoteServiceNilCreateNew", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.quoteService == nil
			var receiver *handlerCommon = &handlerCommon{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1 := receiver.getQuoteService(ctxTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 当receiver.quoteService为nil时，会调用quoteservice.NewService()创建一个新的服务实例并赋值给h.quoteService，且NewService被mock返回一个非nil的mocks_autogen.MockSupportQuoteService实例，所以最终返回的got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerCommon_getCommodityService_ByteUTGen(t *testing.T) {
	// 测试当handlerCommon的quoteService为nil时，调用getQuoteService方法创建新服务实例的场景
	t.Run("QuoteServiceNilCreateNew", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.quoteService == nil
			var receiver *handlerCommon = &handlerCommon{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1 := receiver.getCommodityService(ctxTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 当receiver.quoteService为nil时，会调用quoteservice.NewService()创建一个新的服务实例并赋值给h.quoteService，且NewService被mock返回一个非nil的mocks_autogen.MockSupportQuoteService实例，所以最终返回的got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerCommon_getExtService_ByteUTGen(t *testing.T) {
	// 测试当handlerCommon的quoteService为nil时，调用getQuoteService方法创建新服务实例的场景
	t.Run("QuoteServiceNilCreateNew", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.quoteService == nil
			var receiver *handlerCommon = &handlerCommon{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1 := receiver.getExtService(ctxTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 当receiver.quoteService为nil时，会调用quoteservice.NewService()创建一个新的服务实例并赋值给h.quoteService，且NewService被mock返回一个非nil的mocks_autogen.MockSupportQuoteService实例，所以最终返回的got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
		})
	})
}

func Test_EditExternalCommodityList_BitsUTGen(t *testing.T) {
	PatchConvey("Test_EditExternalCommodityList", t, func() {

		PatchConvey("FindLastByNo返回错误", func() {
			// 避免日志包空指针
			MockUnsafe(logs.CtxError).Return().Build()
			metaDao := dal.NewContractMetaDao()
			// Mock构造接口实例
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, errors.New("db fail")).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-ERR"
			var list bizmodels.ExternalProductInfoList

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "FindContractFail")
		})

		PatchConvey("合同不存在返回错误", func() {
			// 避免日志包空指针
			MockUnsafe(logs.CtxError).Return().Build()
			metaDao := dal.NewContractMetaDao()
			// Mock返回nil表示合同不存在
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, nil).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-NOT-FOUND"
			var list bizmodels.ExternalProductInfoList

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "ContractNotFound")
		})

		PatchConvey("保存外部报价返回成功", func() {
			metaDao := dal.NewContractMetaDao()
			contractManageDao := dal.NewContractManageDao()
			// Mock查找到合同
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			meta := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 1001},
				ContractNo: "CN-OK",
			}
			Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(meta, nil).Build()
			Mock(dal.NewContractManageDao).Return(contractManageDao).Build()
			manageInfo := &model.VolcContractManage{
				IsSplitProduct: false,
			}
			Mock(mockey.GetMethod(contractManageDao, "FindByVolcContractId")).Return(manageInfo, nil).Build()
			Mock(mockey.GetMethod(contractManageDao, "UpdateByMap")).Return(nil).Build()

			// Mock保存逻辑成功
			Mock(SaveExternalCommodityList).Return(nil).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-OK"
			list := bizmodels.ExternalProductInfoList{
				&bizmodels.ExternalProductInfo{
					GroupID:          1,
					RecordType:       1,
					TradeProductName: "商品A",
				},
			}

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldBeNil)
		})

		PatchConvey("保存外部报价返回错误", func() {
			metaDao := dal.NewContractMetaDao()
			contractManageDao := dal.NewContractManageDao()

			// Mock查找到合同
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			meta := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 2002},
				ContractNo: "CN-FAIL",
			}
			Mock(GetMethod(metaDao, "FindLastByNo")).Return(meta, nil).Build()

			Mock(dal.NewContractManageDao).Return(contractManageDao).Build()
			manageInfo := &model.VolcContractManage{
				IsSplitProduct: false,
			}
			Mock(mockey.GetMethod(contractManageDao, "FindByVolcContractId")).Return(manageInfo, nil).Build()
			Mock(mockey.GetMethod(contractManageDao, "UpdateByMap")).Return(nil).Build()

			// Mock保存逻辑失败
			Mock(SaveExternalCommodityList).Return(errorsV2.ErrInternalError.WithArgs("CreateCommodityFail")).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-FAIL"
			list := bizmodels.ExternalProductInfoList{
				&bizmodels.ExternalProductInfo{
					GroupID:          2,
					RecordType:       1,
					TradeProductName: "商品B",
				},
			}

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "CreateCommodityFail")
		})
		PatchConvey("查询合同管理信息失败", func() {
			metaDao := dal.NewContractMetaDao()
			contractManageDao := dal.NewContractManageDao()

			// Mock查找到合同
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			meta := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 2002},
				ContractNo: "CN-FAIL",
			}
			Mock(GetMethod(metaDao, "FindLastByNo")).Return(meta, nil).Build()

			Mock(dal.NewContractManageDao).Return(contractManageDao).Build()
			manageInfo := &model.VolcContractManage{
				IsSplitProduct: false,
			}
			Mock(mockey.GetMethod(contractManageDao, "FindByVolcContractId")).Return(manageInfo, errors.New("db fail")).Build()
			Mock(mockey.GetMethod(contractManageDao, "UpdateByMap")).Return(nil).Build()

			// Mock保存逻辑失败
			Mock(SaveExternalCommodityList).Return(errorsV2.ErrInternalError.WithArgs("CreateCommodityFail")).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-FAIL"
			list := bizmodels.ExternalProductInfoList{
				&bizmodels.ExternalProductInfo{
					GroupID:          2,
					RecordType:       1,
					TradeProductName: "商品B",
				},
			}

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "FindManageInfoFail")
		})

		PatchConvey("更新合同管理信息失败", func() {
			metaDao := dal.NewContractMetaDao()
			contractManageDao := dal.NewContractManageDao()

			// Mock查找到合同
			Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			meta := &model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 2002},
				ContractNo: "CN-FAIL",
			}
			Mock(GetMethod(metaDao, "FindLastByNo")).Return(meta, nil).Build()

			Mock(dal.NewContractManageDao).Return(contractManageDao).Build()
			manageInfo := &model.VolcContractManage{
				IsSplitProduct: false,
			}
			Mock(mockey.GetMethod(contractManageDao, "FindByVolcContractId")).Return(manageInfo, nil).Build()
			Mock(mockey.GetMethod(contractManageDao, "UpdateByMap")).Return(errors.New("db fail")).Build()

			// Mock保存逻辑失败
			Mock(SaveExternalCommodityList).Return(errorsV2.ErrInternalError.WithArgs("CreateCommodityFail")).Build()

			ctx := context.Background()
			var tx *gorm.DB
			contractNo := "CN-FAIL"
			list := bizmodels.ExternalProductInfoList{
				&bizmodels.ExternalProductInfo{
					GroupID:          2,
					RecordType:       1,
					TradeProductName: "商品B",
				},
			}

			err := EditExternalCommodityList(ctx, tx, contractNo, list, true)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "UpdateManageInfoFail")
		})
	})
}

//go:noinline
func newContractDiscountForRepeatMsgTest(contractNo, productName, product string) *bizmodels.ContractDiscount {
	return &bizmodels.ContractDiscount{
		ContractNo:  contractNo,
		ProductName: productName,
		Product:     product,
	}
}

func Test_GenRepeatProductMsg_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	PatchConvey("测试GenRepeatProductMsg", t, func() {
		PatchConvey("国际化为空且报价单为空时返回空字符串", func() {
			MockUnsafe(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return "" }).Build()

			result := GenRepeatProductMsg(ctx, bizmodels.ContractDiscountList{}, "")

			So(result, ShouldEqual, "")
		})

		PatchConvey("重复列表为空时仅返回报价单前缀", func() {
			result := GenRepeatProductMsg(ctx, bizmodels.ContractDiscountList{}, "Q-EMPTY")

			So(result, ShouldEqual, "报价单[Q-EMPTY]存在如下重复报价项：")
		})

		PatchConvey("存在节省计划抵扣项且包含特殊字符时按层级展示并转义", func() {
			mainItem := newContractDiscountForRepeatMsgTest(`C"100\A`, `包年包月"主\项`, "包年包月\"主\\项")
			mainItem.CanPrePay = "预付"
			mainItem.PayType = "预付"
			mainItem.BillingName = "包年"
			mainItem.PriceFactor = `pf"1\2`
			mainItem.SellingMode = "节省计划"
			mainItem.Extra = &bizmodels.DiscountExtra{
				SavingPlan: &bizmodels.SavingPlanInExtra{
					PrePayRatio:       "50%",
					CommitFeeInterval: "1000",
					SpBuyDuration:     "12个月",
				},
			}

			subItem1 := newContractDiscountForRepeatMsgTest("", "子项1", "子项1")
			subItem2 := newContractDiscountForRepeatMsgTest("", `子项"2\A`, "子项\"2\\A")
			mainItem.DeductList = []*bizmodels.ContractDiscount{subItem1, subItem2}

			result := GenRepeatProductMsg(ctx, bizmodels.ContractDiscountList{mainItem}, `Q"X\Y`)

			expected := `报价单[Q\"X\\Y]存在如下重复报价项：1: 报价项商品[包年包月\"主\\项],付费方式为[预付],配置分类为[],配置[],计费项分类[],计费方式[包年],地域[],计费单元[],价格影响因子[pf\"1\\2],售卖模式[节省计划],预付比例[50%],承诺消费金额[1000],购买时长[12个月]，包含重复节省计划抵扣项：(1.1) 商品[子项1],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； (1.2) 商品[子项\"2\\A],付费方式为[],配置分类为[],配置[],计费项分类[],计费方式[],地域[],计费单元[],价格影响因子[],售卖模式[],预付比例[],承诺消费金额[],购买时长[]； `
			So(result, ShouldEqual, expected)
		})
	})
}

type Mock_ContractMetaExtDao_commonCheckValidityAndRebatePeriod struct {
	dal.ContractMetaExtDao
}

func Test_handlerCommon_commonCheckValidityAndRebatePeriod_ByteUT(t *testing.T) {
	defer mockey.UnPatchAll()

	var (
		ctx = context.Background()
		h   = &handlerCommon{}
	)

	t.Run("获取优惠券配置列表失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("获取优惠券配置列表失败", t, func() {
			// 该子场景测试用例用于模拟获取优惠券配置列表时发生错误，预期直接返回该错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList
			mockErr := errors.New("get coupon config list failed")
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(nil, mockErr).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, mockErr.Error())
		})
	})

	t.Run("优惠券配置列表为空，直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("优惠券配置列表为空", t, func() {
			// 该子场景测试用例用于模拟获取到的优惠券配置列表为空，预期函数直接返回nil。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(nil, nil).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("单个优惠券配置列表为空，直接返回nil", func(t *testing.T) {
		mockey.PatchConvey("优惠券配置列表为空", t, func() {
			// 该子场景测试用例用于模拟获取到的优惠券配置列表为空，预期函数直接返回nil。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("返券规则有效期月份长度小于返券周期，返回错误", func(t *testing.T) {
		mockey.PatchConvey("有效期月份小于返券周期", t, func() {
			// 该子场景测试用例用于模拟返券规则的有效期月份长度小于指定的返券周期，预期返回校验失败的错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> i18nfmt.Sprintf
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    12,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type: 0,
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()
			mockErrMsg := "“返券规则有效期”的月份长度需要必须大于等于“返券周期”"
			mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BeginTime: "2023-01-01",
						EndTime:   "2023-06-01",
					},
				},
			}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, mockErrMsg)
		})
	})

	t.Run("合同开始时间为空", func(t *testing.T) {
		mockey.PatchConvey("解析合同开始时间失败", t, func() {
			// 该子场景测试用例用于模拟合同开始时间格式不正确导致解析失败，预期返回解析错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> time.ParseInLocation
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type: 0,
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BeginTime: "",
						EndTime:   "2023-12-31",
					},
				},
			}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("解析合同开始时间失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("解析合同开始时间失败", t, func() {
			// 该子场景测试用例用于模拟合同开始时间格式不正确导致解析失败，预期返回解析错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> time.ParseInLocation
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type: 0,
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BeginTime: "invalid-time",
						EndTime:   "2023-12-31",
					},
				},
			}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldHaveSameTypeAs, &time.ParseError{})
		})
	})

	t.Run("解析合同结束时间失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("解析合同结束时间失败", t, func() {
			// 该子场景测试用例用于模拟合同结束时间格式不正确导致解析失败，预期返回解析错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> time.ParseInLocation
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type: 0,
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BeginTime: "2023-01-01",
						EndTime:   "invalid-time",
					},
				},
			}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldHaveSameTypeAs, &time.ParseError{})
		})
	})

	t.Run("指定月份范围，但月份长度小于返券周期，返回错误", func(t *testing.T) {
		mockey.PatchConvey("指定月份范围但月份长度不足", t, func() {
			// 该子场景测试用例用于模拟返券规则为指定月份范围，但该范围的月份数小于返券周期，预期返回校验失败的错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> i18nfmt.Sprintf
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_PROPORTION_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type:       1,
						BeginMonth: "2023-01",
						EndMonth:   "2023-03",
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()
			mockErrMsg := "“返券规则有效期”的月份长度需要必须大于等于“返券周期”"
			mockey.Mock(i18nfmt.Sprintf).Return(mockErrMsg).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, errorsV2.ErrQuoteCommon.WithArgs(mockErrMsg))
		})
	})
	t.Run("指定月份范围，开始时间解析失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("开始时间解析失败", t, func() {
			// 该子场景测试用例用于模拟返券规则为指定月份范围，但该范围的月份数小于返券周期，预期返回校验失败的错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> i18nfmt.Sprintf
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_PROPORTION_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type:       1,
						BeginMonth: "2023/01",
						EndMonth:   "2023-03",
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldHaveSameTypeAs, &time.ParseError{})

		})
	})
	t.Run("指定月份范围，结束时间解析失败，返回错误", func(t *testing.T) {
		mockey.PatchConvey("结束时间解析失败", t, func() {
			// 该子场景测试用例用于模拟返券规则为指定月份范围，但该范围的月份数小于返券周期，预期返回校验失败的错误。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList -> i18nfmt.Sprintf
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{
					RebateCouponWay: _const.COUPON_REBATE_WAY_PROPORTION_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type:       1,
						BeginMonth: "2023-01",
						EndMonth:   "2023/03",
					},
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldHaveSameTypeAs, &time.ParseError{})

		})
	})

	t.Run("校验通过，所有条件均满足，返回nil", func(t *testing.T) {
		mockey.PatchConvey("所有条件满足", t, func() {
			// 该子场景测试用例用于模拟所有校验条件均满足的情况，预期函数正常执行完毕并返回nil。
			// 调用链路: commonCheckValidityAndRebatePeriod -> getCouponConfigList
			mockCouponConfigList := []*quote_client.ExtraConfigCouponDetail{
				{ // 场景一：跟随合同有效期，且长度满足
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    6,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type: 0,
					},
				},
				{ // 场景二：指定月份范围，且长度满足
					RebateCouponWay: _const.COUPON_REBATE_WAY_PROPORTION_REDUCE,
					RebatePeriod:    3,
					RuleValidityInfo: &quote_client.RuleValidityInfo{
						Type:       1,
						BeginMonth: "2023-01",
						EndMonth:   "2023-06",
					},
				},
				{ // 场景三：返券方式不符，跳过校验
					RebateCouponWay: _const.COUPON_REBATE_WAY_STAGE,
				},
				{ // 场景四：返券周期为0，跳过校验
					RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
					RebatePeriod:    0,
				},
			}
			mockey.Mock((*handlerCommon).getCouponConfigList).Return(mockCouponConfigList, nil).Build()

			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						BeginTime: "2023-01-01",
						EndTime:   "2023-12-31",
					},
				},
			}
			err := h.commonCheckValidityAndRebatePeriod(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerCommon_checkAndCorrectCouponValiditySubset_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	PatchConvey("Test_handlerCommon_checkAndCorrectCouponValiditySubset", t, func() {
		PatchConvey("场景：获取返券配置失败时返回错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(1)
			wantErr := errors.New("load coupon config failed")

			Mock((*handlerCommon).getCouponConfigList).Return(([]*quote_client.ExtraConfigCouponDetail)(nil), wantErr).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldEqual, wantErr)
			So(err.Error(), ShouldContainSubstring, "load coupon config failed")
		})

		PatchConvey("场景：返券配置为nil时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(2)

			Mock((*handlerCommon).getCouponConfigList).Return(([]*quote_client.ExtraConfigCouponDetail)(nil), nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：返券配置为空切片时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(3)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：合同开始时间为空时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(4)
			pc.ContractInfo.BasicInfo.BeginTime = ""
			cfg := newCouponDetail(101, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：合同结束时间为空时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(5)
			pc.ContractInfo.BasicInfo.EndTime = ""
			cfg := newCouponDetail(102, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：合同有效期类型为签订生效时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(6)
			pc.ContractInfo.BasicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			cfg := newCouponDetail(103, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：返券配置无需校验时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(7)
			cfg := newCouponDetail(104, 99, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
		})

		PatchConvey("场景：返券有效期完全在合同有效期子集内时直接通过", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(8)
			cfg := newCouponDetail(105, _const.COUPON_REBATE_WAY_PROPORTION_REDUCE, "2024-01", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
			So(cfg.RuleValidityInfo.BeginMonth, ShouldEqual, "2024-01")
			So(cfg.RuleValidityInfo.EndMonth, ShouldEqual, "2024-02")
		})

		PatchConvey("场景：返券有效期在合同后且无交集时返回普通错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(9)
			cfg := newCouponDetail(106, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2024-04", "2024-05", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			apiErr, ok := err.(hertz.APIError)
			So(ok, ShouldBeTrue)
			So(apiErr.GetCode(), ShouldEqual, errorsV2.ErrQuoteCommon.GetCode())
			So(getAPIErrorArg(err), ShouldContainSubstring, "没有交集")
			So(getAPIErrorArg(err), ShouldContainSubstring, "2024-04 ～ 2024-05")
		})

		PatchConvey("场景：返券有效期在合同前且无交集时返回普通错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(10)
			cfg := newCouponDetail(107, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-10", "2023-12", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			apiErr, ok := err.(hertz.APIError)
			So(ok, ShouldBeTrue)
			So(apiErr.GetCode(), ShouldEqual, errorsV2.ErrQuoteCommon.GetCode())
			So(getAPIErrorArg(err), ShouldContainSubstring, "没有交集")
			So(getAPIErrorArg(err), ShouldContainSubstring, "2023-10 ～ 2023-12")
		})

		PatchConvey("场景：返券有效期部分重叠且未二次确认时返回二次确认错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(11)
			cfg := newCouponDetail(108, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			apiErr, ok := err.(hertz.APIError)
			So(ok, ShouldBeTrue)
			So(apiErr.GetCode(), ShouldEqual, errorsV2.ErrSecondConfirm.GetCode())
			So(getAPIErrorArg(err), ShouldContainSubstring, "超出合同有效期")
			So(getAPIErrorArg(err), ShouldContainSubstring, "2024-01 ～ 2024-02")
		})

		PatchConvey("场景：二次确认后交集开始月份解析失败时返回错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(12)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(109, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2024-02x", "2024-04", 1)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "2024-02x")
		})

		PatchConvey("场景：二次确认后交集结束月份解析失败时返回错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(13)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(110, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02x", 1)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "2024-02x")
		})

		PatchConvey("场景：二次确认后返券周期大于修正后有效期长度时返回普通错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(14)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(111, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 3)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			apiErr, ok := err.(hertz.APIError)
			So(ok, ShouldBeTrue)
			So(apiErr.GetCode(), ShouldEqual, errorsV2.ErrQuoteCommon.GetCode())
			So(getAPIErrorArg(err), ShouldContainSubstring, "月份长度需要必须大于等于“返券周期”")
		})

		PatchConvey("场景：二次确认后自动修正且序列化失败时返回错误", func() {
			h := &handlerCommon{}
			pc := newProcessCtx(16)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(113, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 0)
			cfg.BalanceAlertThreshold = math.Inf(1)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "unsupported value")
		})

		PatchConvey("场景：二次确认后自动修正但落库失败时返回错误", func() {
			mockSvc := &Mock_Service_checkAndCorrectCouponValiditySubset{}
			h := &handlerCommon{metaExtService: mockSvc}
			pc := newProcessCtx(17)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(114, _const.COUPON_REBATE_WAY_FULL_REDUCE, "2023-12", "2024-02", 1)
			wantErr := errors.New("update meta ext failed")

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()
			Mock((*Mock_Service_checkAndCorrectCouponValiditySubset).UpdateMetaExt).When(func(callCtx context.Context, tx *gorm.DB, volcContractId int64, extMap map[string]string, delKeys []string) bool {
				So(callCtx, ShouldNotBeNil)
				So(volcContractId, ShouldEqual, int64(17))
				So(extMap[_const.ExtKeyCouponConfig], ShouldContainSubstring, `"BeginMonth":"2024-01"`)
				So(extMap[_const.ExtKeyCouponConfig], ShouldContainSubstring, `"EndMonth":"2024-02"`)
				return true
			}).Return(wantErr).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldEqual, wantErr)
			So(cfg.RuleValidityInfo.BeginMonth, ShouldEqual, "2024-01")
			So(cfg.RuleValidityInfo.EndMonth, ShouldEqual, "2024-02")
		})

		PatchConvey("场景：二次确认后自动修正并成功落库", func() {
			mockSvc := &Mock_Service_checkAndCorrectCouponValiditySubset{}
			h := &handlerCommon{metaExtService: mockSvc}
			pc := newProcessCtx(18)
			pc.IsSecondConfirm = _const.TRUE_FLAG_INT
			cfg := newCouponDetail(115, _const.COUPON_REBATE_WAY_PROPORTION_REDUCE, "2023-12", "2024-02", 0)

			Mock((*handlerCommon).getCouponConfigList).Return([]*quote_client.ExtraConfigCouponDetail{cfg}, nil).Build()
			Mock((*Mock_Service_checkAndCorrectCouponValiditySubset).UpdateMetaExt).When(func(callCtx context.Context, tx *gorm.DB, volcContractId int64, extMap map[string]string, delKeys []string) bool {
				So(callCtx, ShouldNotBeNil)
				So(volcContractId, ShouldEqual, int64(18))
				So(extMap[_const.ExtKeyCouponConfig], ShouldContainSubstring, `"BeginMonth":"2024-01"`)
				So(extMap[_const.ExtKeyCouponConfig], ShouldContainSubstring, `"EndMonth":"2024-02"`)
				return true
			}).Return(nil).Build()

			err := h.checkAndCorrectCouponValiditySubset(ctx, pc)

			So(err, ShouldBeNil)
			So(cfg.RuleValidityInfo.BeginMonth, ShouldEqual, "2024-01")
			So(cfg.RuleValidityInfo.EndMonth, ShouldEqual, "2024-02")
		})
	})
}

func Test_handlerCommon_shouldCheckCouponValidity_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}

	testCases := []struct {
		name string
		cfg  *quote_client.ExtraConfigCouponDetail
		want bool
	}{
		{
			name: "配置为空时不校验",
			cfg:  nil,
			want: false,
		},
		{
			name: "返券方式不匹配时不校验",
			cfg: &quote_client.ExtraConfigCouponDetail{
				RebateCouponWay: _const.COUPON_REBATE_WAY_STAGE,
			},
			want: false,
		},
		{
			name: "跟随合同有效期时不校验",
			cfg: &quote_client.ExtraConfigCouponDetail{
				RebateCouponWay: _const.COUPON_REBATE_WAY_FULL_REDUCE,
				RuleValidityInfo: &quote_client.RuleValidityInfo{
					Type: 0,
				},
			},
			want: false,
		},
		{
			name: "月份范围完整时需要校验",
			cfg: &quote_client.ExtraConfigCouponDetail{
				RebateCouponWay: _const.COUPON_REBATE_WAY_PROPORTION_REDUCE,
				RuleValidityInfo: &quote_client.RuleValidityInfo{
					Type:       1,
					BeginMonth: "2024-01",
					EndMonth:   "2024-03",
				},
			},
			want: true,
		},
	}

	for _, tc := range testCases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				So(h.shouldCheckCouponValidity(tc.cfg), ShouldEqual, tc.want)
			})
		})
	}
}

func Test_handlerCommon_calculateCouponValidityIntersection_BitsUTGen(t *testing.T) {
	h := &handlerCommon{}

	testCases := []struct {
		name      string
		rBegin    string
		rEnd      string
		cBegin    string
		cEnd      string
		wantBegin string
		wantEnd   string
	}{
		{
			name:      "返券有效期在合同内保持不变",
			rBegin:    "2024-01",
			rEnd:      "2024-03",
			cBegin:    "2024-01",
			cEnd:      "2024-06",
			wantBegin: "2024-01",
			wantEnd:   "2024-03",
		},
		{
			name:      "返券有效期超出合同区间时取交集",
			rBegin:    "2023-12",
			rEnd:      "2024-08",
			cBegin:    "2024-01",
			cEnd:      "2024-06",
			wantBegin: "2024-01",
			wantEnd:   "2024-06",
		},
	}

	for _, tc := range testCases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			mockey.PatchConvey(tc.name, t, func() {
				gotBegin, gotEnd := h.calculateCouponValidityIntersection(tc.rBegin, tc.rEnd, tc.cBegin, tc.cEnd)

				So(gotBegin, ShouldEqual, tc.wantBegin)
				So(gotEnd, ShouldEqual, tc.wantEnd)
			})
		})
	}
}

type Mock_ContractMetaExtDao_getCouponConfigList struct {
	dal.ContractMetaExtDao
}

func Test_handlerCommon_getCouponConfigList_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	h := &handlerCommon{}
	pc := &auditmodel.ProcessCtx{
		ContractInfo: &model.ContractMeta{
			ID: 12345,
		},
	}

	PatchConvey("Test_handlerCommon_getCouponConfigList", t, func() {
		PatchConvey("场景：查询合同扩展信息失败时返回错误", func() {
			mockDao := &Mock_ContractMetaExtDao_getCouponConfigList{}
			mockErr := errors.New("list by contract id failed")

			MockUnsafe(dal.NewContractMetaExtDao).Return(mockDao).Build()
			MockUnsafe((*Mock_ContractMetaExtDao_getCouponConfigList).ListByContractId).Return([]*model.ContractMetaExt(nil), 0, mockErr).Build()

			list, err := h.getCouponConfigList(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "list by contract id failed")
			So(list, ShouldBeNil)
		})

		PatchConvey("场景：未找到返券配置时返回空结果", func() {
			mockDao := &Mock_ContractMetaExtDao_getCouponConfigList{}
			metaExtList := []*model.ContractMetaExt{
				{
					AttrKey:   "OtherKey",
					AttrValue: `[{"Id":1}]`,
				},
			}

			MockUnsafe(dal.NewContractMetaExtDao).Return(mockDao).Build()
			MockUnsafe((*Mock_ContractMetaExtDao_getCouponConfigList).ListByContractId).Return(metaExtList, len(metaExtList), nil).Build()

			list, err := h.getCouponConfigList(ctx, pc)

			So(err, ShouldBeNil)
			So(list, ShouldBeNil)
		})

		PatchConvey("场景：返券配置存在但值为空时返回空结果", func() {
			mockDao := &Mock_ContractMetaExtDao_getCouponConfigList{}
			metaExtList := []*model.ContractMetaExt{
				{
					AttrKey:   _const.ExtKeyCouponConfig,
					AttrValue: "",
				},
			}

			MockUnsafe(dal.NewContractMetaExtDao).Return(mockDao).Build()
			MockUnsafe((*Mock_ContractMetaExtDao_getCouponConfigList).ListByContractId).Return(metaExtList, len(metaExtList), nil).Build()

			list, err := h.getCouponConfigList(ctx, pc)

			So(err, ShouldBeNil)
			So(list, ShouldBeNil)
		})

		PatchConvey("场景：返券配置不是合法JSON时返回错误", func() {
			mockDao := &Mock_ContractMetaExtDao_getCouponConfigList{}
			metaExtList := []*model.ContractMetaExt{
				{
					AttrKey:   _const.ExtKeyCouponConfig,
					AttrValue: "{bad json}",
				},
			}

			MockUnsafe(dal.NewContractMetaExtDao).Return(mockDao).Build()
			MockUnsafe((*Mock_ContractMetaExtDao_getCouponConfigList).ListByContractId).Return(metaExtList, len(metaExtList), nil).Build()

			list, err := h.getCouponConfigList(ctx, pc)

			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "invalid character")
			So(list, ShouldBeNil)
		})

		PatchConvey("场景：成功解析返券配置并返回列表", func() {
			mockDao := &Mock_ContractMetaExtDao_getCouponConfigList{}
			metaExtList := []*model.ContractMetaExt{
				{
					AttrKey:   "OtherKey",
					AttrValue: "ignored",
				},
				{
					AttrKey:   _const.ExtKeyCouponConfig,
					AttrValue: `[{"Id":101,"CouponType":3},{"Id":102,"RebatePeriod":6}]`,
				},
				{
					AttrKey:   _const.ExtKeyCouponConfig,
					AttrValue: `invalid-json`,
				},
			}

			MockUnsafe(dal.NewContractMetaExtDao).Return(mockDao).Build()
			MockUnsafe((*Mock_ContractMetaExtDao_getCouponConfigList).ListByContractId).Return(metaExtList, len(metaExtList), nil).Build()

			list, err := h.getCouponConfigList(ctx, pc)

			So(err, ShouldBeNil)
			So(list, ShouldNotBeNil)
			So(list, ShouldHaveLength, 2)
			So(list[0].Id, ShouldEqual, int64(101))
			So(list[0].CouponType, ShouldEqual, 3)
			So(list[1].Id, ShouldEqual, int64(102))
			So(list[1].RebatePeriod, ShouldEqual, 6)
		})
	})
}

func newProcessCtx(contractID uint64) *auditmodel.ProcessCtx {
	return &auditmodel.ProcessCtx{
		ContractInfo: &model.ContractMeta{
			ID:         contractID,
			ContractNo: "CN-TEST",
			BasicInfo: &bizmodels.BasicInfo{
				UsefulLifeType: 1,
				BeginTime:      "2024-01-01",
				EndTime:        "2024-03-31",
			},
		},
	}
}

func getAPIErrorArg(err error) string {
	apiErr, ok := err.(hertz.APIError)
	if !ok || len(apiErr.GetArgs()) == 0 {
		if err == nil {
			return ""
		}
		return err.Error()
	}
	if msg, ok := apiErr.GetArgs()[0].(string); ok {
		return msg
	}
	return ""
}

func newCouponDetail(id int64, rebateWay int, beginMonth, endMonth string, rebatePeriod int) *quote_client.ExtraConfigCouponDetail {
	return &quote_client.ExtraConfigCouponDetail{
		Id:              id,
		RebateCouponWay: rebateWay,
		RebatePeriod:    rebatePeriod,
		RuleValidityInfo: &quote_client.RuleValidityInfo{
			Type:       1,
			BeginMonth: beginMonth,
			EndMonth:   endMonth,
		},
	}
}

type Mock_Service_checkAndCorrectCouponValiditySubset struct {
	metaext.Service
}

func Test_handlerCommon_SendBackNotifyPeerReviewers(t *testing.T) {
	mockey.PatchConvey("按退回目标节点通知目标审批人", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			CurrentOperator:    "operator@example.com",
			OperationState:     _const.OperationSendBack,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractSalesOperationCompleteInformation,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer,
			},
			Comment: &bizmodels.RichTextInfo{
				RichtextPlainText: "请补充签约信息",
			},
			ContractInfo: &model.ContractMeta{
				ContractNo:     "CN-002",
				ContractName:   "测试合同2",
				OtherPartyName: "测试客户2",
				IsUrgent:       _const.TRUE_FLAG_INT,
				UrgentInfo: &bizmodels.UrgentInfo{
					UrgentName: "加急",
				},
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					{Reviewer: "sales.op@example.com", ReviewerType: _const.ReviewerTypeSalesOperation, ContractStatus: _const.PreSalesContractSalesOperationCompleteInformation},
				},
			},
		}

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v
		}).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
			return fmt.Sprintf("<at email=%s></at>", email)
		}).Build()
		mockey.Mock(larkc.GenEditURL).To(func(ctx context.Context, contractNo string) string {
			return "edit://" + contractNo
		}).Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			convey.So(emailList, convey.ShouldResemble, []string{"sales.op@example.com"})
			convey.So(msgType, convey.ShouldEqual, larkc.MsgTypeInteractive)
			convey.So(content, convey.ShouldContainSubstring, "合同退回提醒")
			convey.So(content, convey.ShouldContainSubstring, "重新完善信息")
			convey.So(content, convey.ShouldContainSubstring, "operator@example.com")
			convey.So(content, convey.ShouldContainSubstring, "退回原因：请补充签约信息")
			convey.So(content, convey.ShouldContainSubstring, "加急")
			convey.So(content, convey.ShouldContainSubstring, "edit://CN-002")
		}).Build()

		h.sendBackNotifyTargetReviewers(ctx, pc)
	})

	mockey.PatchConvey("目标节点通知在前置条件不满足时直接返回", t, func() {
		h := &handlerCommon{}
		called := false
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			called = true
		}).Build()

		h.sendBackNotifyTargetReviewers(context.Background(), &auditmodel.ProcessCtx{
			OperationState:     _const.OperationFinalized,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractSalesOperationReview,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeSalesOperation,
			},
			ContractInfo: &model.ContractMeta{
				ContractNo: "CN-SKIP-1",
			},
		})

		convey.So(called, convey.ShouldBeFalse)
	})

	mockey.PatchConvey("目标节点状态不支持时直接返回", t, func() {
		h := &handlerCommon{}
		called := false
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			called = true
		}).Build()

		h.sendBackNotifyTargetReviewers(context.Background(), &auditmodel.ProcessCtx{
			CurrentOperator:    "operator@example.com",
			OperationState:     _const.OperationSendBack,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractRiskReview,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeSalesOperation,
			},
			ContractInfo: &model.ContractMeta{
				ContractNo: "CN-SKIP-2",
			},
		})

		convey.So(called, convey.ShouldBeFalse)
	})

	mockey.PatchConvey("目标审批人为空时直接返回", t, func() {
		h := &handlerCommon{}
		called := false
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			called = true
		}).Build()

		h.sendBackNotifyTargetReviewers(context.Background(), &auditmodel.ProcessCtx{
			CurrentOperator:    "operator@example.com",
			OperationState:     _const.OperationSendBack,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer,
			},
			ContractInfo: &model.ContractMeta{
				ContractNo: "CN-SKIP-3",
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
			},
		})

		convey.So(called, convey.ShouldBeFalse)
	})

	mockey.PatchConvey("退回目标节点模板按状态匹配", t, func() {
		cases := []struct {
			status     int
			title      string
			contentKey string
			actionText string
		}{
			{_const.PreSalesContractSendBack, "合同审核提醒", "如有需要，请您重新提交", "查看详情"},
			{_const.PreSalesContractSalesOperationReview, "合同退回提醒", "请您重新审核", "去审核"},
			{_const.PreSalesContractFinanceTaxationLegalReview, "合同退回提醒", "请您重新审核", "去审核"},
			{_const.PreSalesContractCustomerConfirm, "合同退回提醒", "请您重新确认合同内容", "查看详情"},
			{_const.PreSalesContractSalesOperationCompleteInformation, "合同退回提醒", "重新完善信息", "查看详情"},
			{_const.PreSalesContractFinanceTaxationLegalSignReview, "合同退回提醒", "重新进行签约审核", "去审核"},
			{_const.PreSalesContractSolutionReview, "合同退回提醒", "请您重新审核", "去审核"},
		}
		for _, item := range cases {
			tpl, ok := getSendBackNotifyTemplate(item.status)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(tpl.title, convey.ShouldEqual, item.title)
			convey.So(tpl.content, convey.ShouldContainSubstring, item.contentKey)
			convey.So(tpl.actionText, convey.ShouldEqual, item.actionText)
		}

		_, ok := getSendBackNotifyTemplate(_const.PreSalesContractRiskReview)
		convey.So(ok, convey.ShouldBeFalse)
	})

	mockey.PatchConvey("满足退回条件时通知同节点其他审批人", t, func() {
		h := &handlerCommon{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			CurrentOperator:    "operator@example.com",
			OperationState:     _const.OperationSendBack,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer,
			},
			Comment: &bizmodels.RichTextInfo{
				RichtextPlainText: "请补充条款说明",
			},
			ContractInfo: &model.ContractMeta{
				ContractNo:        "CN-001",
				ContractName:      "测试合同",
				OtherPartyName:    "测试客户",
				CooperationStatus: _const.PreSalesContractFinanceTaxationLegalReview,
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "operator@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
					{Reviewer: "peer@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
			},
		}

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v
		}).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
			return fmt.Sprintf("<at email=%s></at>", email)
		}).Build()
		mockey.Mock(larkc.GenDetailURL).To(func(ctx context.Context, contractNo string) string {
			return "detail://" + contractNo
		}).Build()
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			convey.So(emailList, convey.ShouldResemble, []string{"peer@example.com"})
			convey.So(msgType, convey.ShouldEqual, larkc.MsgTypeInteractive)
			convey.So(content, convey.ShouldContainSubstring, "CN-001")
			convey.So(content, convey.ShouldContainSubstring, "测试合同")
			convey.So(content, convey.ShouldContainSubstring, "测试客户")
			convey.So(content, convey.ShouldContainSubstring, "请补充条款说明")
			convey.So(content, convey.ShouldContainSubstring, "at email=sales@example.com")
			convey.So(content, convey.ShouldContainSubstring, "detail://CN-001")
		}).Build()

		h.SendBackNotifyPeerReviewers(ctx, pc)
	})

	mockey.PatchConvey("非退回场景时不发送消息", t, func() {
		h := &handlerCommon{}
		called := false
		mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
			called = true
		}).Build()

		h.SendBackNotifyPeerReviewers(context.Background(), &auditmodel.ProcessCtx{
			OperationState:     _const.OperationFinalized,
			StatusChanged:      true,
			StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer,
			},
			ContractInfo: &model.ContractMeta{
				CooperationStatus: _const.PreSalesContractFinanceTaxationLegalReview,
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "operator@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
					{Reviewer: "peer@example.com", ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview},
				},
			},
		})

		convey.So(called, convey.ShouldBeFalse)
	})
}

func Test_handlerCommon_getSendBackReason(t *testing.T) {
	mockey.PatchConvey("优先返回审批意见文本", t, func() {
		h := &handlerCommon{}

		result := h.getSendBackReason(&auditmodel.ProcessCtx{
			Comment: &bizmodels.RichTextInfo{RichtextPlainText: "审批意见"},
			Remark:  "备注",
		})

		convey.So(result, convey.ShouldEqual, "审批意见")
	})

	mockey.PatchConvey("审批意见为空时返回备注", t, func() {
		h := &handlerCommon{}

		result := h.getSendBackReason(&auditmodel.ProcessCtx{
			Comment: &bizmodels.RichTextInfo{},
			Remark:  "备注",
		})

		convey.So(result, convey.ShouldEqual, "备注")
	})

	mockey.PatchConvey("上下文为空时返回空字符串", t, func() {
		h := &handlerCommon{}

		result := h.getSendBackReason(nil)

		convey.So(result, convey.ShouldEqual, "")
	})
}

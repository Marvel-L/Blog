package handler

import (
	"code.byted.org/gopkg/env"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerConfirmSendback_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmSendback_PostProcess", t, func() {
		// 构造被测对象
		h := &handlerConfirmSendback{}

		convey.Convey("正常发送飞书消息", func() {
			// 场景描述：
			// 正常调用PostProcess，函数应成功组装飞书消息并调用发送接口。
			// 构造数据：
			// - ProcessCtx 包含合同信息，如合同号、名称、对方名称。
			// - 合同的 Reviewers 列表包含一个财税法审核人和一个销售人员。
			// - StatusChangedValue 与财税法审核人的 ContractStatus 匹配。
			// 逻辑链路：
			// 1. 调用 PostProcess。
			// 2. 内部方法 getReviewerFromPreContractReviewerListWithContractStatus 会根据 StatusChangedValue 筛选出财税法审核人 "finance.reviewer@example.com"。
			// 3. 内部方法 getReviewerFromPreContractReviewerList 会筛选出销售 "sales.person@example.com"。
			// 4. Mock multienv.I18nFormat, larkc.LarkMdAtEmail, larkc.GenReviewURL 以便控制消息内容。
			// 5. Mock env.IsProduct() 返回 true 以生成不带环境前缀的标题。
			// 6. 使用真实的 larkc.CommonMessageCardBuilder 构建消息体。
			// 7. Mock larkc.BatchSendMessageToEmailIgnore，替换其异步实现为同步实现，并在其中断言接收到的参数是否符合预期。
			// 8. 函数最终返回 nil。

			// 准备数据
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CN-TEST-2024-001",
					ContractName:   "示例合同",
					OtherPartyName: "示例客户公司",
					Reviewers: bizmodels.PreContractReviewerList{
						{
							Reviewer:       "finance.reviewer@example.com",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview,
							ReviewerSource: 0,
						},
						{
							Reviewer:       "other.finance.reviewer@example.com",
							ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
							ContractStatus: 102, // 不匹配 StatusChangedValue
							ReviewerSource: 0,
						},
						{
							Reviewer:     "sales.person@example.com",
							ReviewerType: _const.ReviewerTypeSalesperson,
						},
					},
				},
			}

			// 进行Mock
			mockey.Mock(env.IsProduct).Return(true).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				// 简单透传，方便断言
				return v
			}).Build()

			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s></at>", email)
			}).Build()

			mockey.Mock(larkc.GenReviewURL).To(func(ctx context.Context, preContractNo string) string {
				return "https://review.example.com/contract/" + preContractNo
			}).Build()

			// Mock 最终的发送函数，并断言其参数
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).To(func(ctx context.Context, emailList []string, msgType string, content string) {
				convey.So(emailList, convey.ShouldResemble, []string{"finance.reviewer@example.com"})
				convey.So(msgType, convey.ShouldEqual, larkc.MsgTypeInteractive)

				// 断言消息卡片内容
				// 定义一个结构体来反序列化 JSON 以进行更健壮的断言
				var card struct {
					Header struct {
						Template string `json:"template"`
						Title    struct {
							Content string `json:"content"`
						} `json:"title"`
					} `json:"header"`
					Elements []json.RawMessage `json:"elements"`
				}

				err := json.Unmarshal([]byte(content), &card)
				convey.So(err, convey.ShouldBeNil)

				convey.So(card.Header.Template, convey.ShouldEqual, "wathet")
				convey.So(card.Header.Title.Content, convey.ShouldEqual, "合同审核提醒")

				// 检查主要内容
				var divText struct {
					Tag  string `json:"tag"`
					Text struct {
						Content string `json:"content"`
					} `json:"text"`
				}
				err = json.Unmarshal(card.Elements[0], &divText)
				convey.So(err, convey.ShouldBeNil)
				convey.So(divText.Tag, convey.ShouldEqual, "div")
				convey.So(divText.Text.Content, convey.ShouldEqual, `<at email=sales.person@example.com></at> 发起的合同待您审核，请尽快前往后台进行审核`)

				// 检查字段
				var divFields struct {
					Tag    string `json:"tag"`
					Fields []struct {
						Text struct {
							Content string `json:"content"`
						} `json:"text"`
					} `json:"fields"`
				}
				err = json.Unmarshal(card.Elements[1], &divFields)
				convey.So(err, convey.ShouldBeNil)
				convey.So(divFields.Tag, convey.ShouldEqual, "div")
				convey.So(divFields.Fields, convey.ShouldHaveLength, 3)
				convey.So(divFields.Fields[0].Text.Content, convey.ShouldEqual, `**合同号：**CN-TEST-2024-001`)
				convey.So(divFields.Fields[1].Text.Content, convey.ShouldEqual, `**合同名称：**示例合同`)
				convey.So(divFields.Fields[2].Text.Content, convey.ShouldEqual, `**客户名称：**示例客户公司`)

				// 检查操作按钮
				var action struct {
					Tag     string `json:"tag"`
					Actions []struct {
						URL  string `json:"url"`
						Text struct {
							Content string `json:"content"`
						} `json:"text"`
					} `json:"actions"`
				}
				err = json.Unmarshal(card.Elements[2], &action)
				convey.So(err, convey.ShouldBeNil)
				convey.So(action.Tag, convey.ShouldEqual, "action")
				convey.So(action.Actions, convey.ShouldHaveLength, 1)
				convey.So(action.Actions[0].URL, convey.ShouldEqual, "https://review.example.com/contract/CN-TEST-2024-001")
				convey.So(action.Actions[0].Text.Content, convey.ShouldEqual, "去审核")
			}).Build()

			// 调用目标函数
			err := h.PostProcess(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("非已退回状态时不通知C360", func() {
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractFinanceTaxationLegalReview,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		convey.Convey("清理退回状态失败时直接返回", func() {
			ctx := context.Background()
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerConfirmSendback_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerConfirmSendback Validate", t, func() {
		// Arrange
		h := &handlerConfirmSendback{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no-1",
				CooperationStatus: 1,
			},
			CurrentOperator: "test-operator",
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 2,
			},
		}
		currentReviewer := &bizmodels.PreContractReviewer{
			ReviewerType:   2,
			ContractStatus: 1,
			Priority:       10,
		}

		mockey.PatchConvey("场景：校验通过，没有更高优先级的未审批人员", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx 实例。
			// 逻辑链路：
			// 1. Mock pc.GetCurrentReviewer 返回一个虚拟的当前审批人。
			// 2. Mock pc.GetTx 返回一个 gorm.DB 实例。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个空的审批人列表和nil错误，表示检查通过。
			// 4. 调用 h.Validate，预期返回 nil。
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(model.PreContractReviewerDBList{}, nil).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：校验失败，查询未通过审批人列表时数据库出错", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx 实例。
			// 逻辑链路：
			// 1. Mock pc.GetCurrentReviewer 返回一个虚拟的当前审批人。
			// 2. Mock pc.GetTx 返回一个 gorm.DB 实例。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回一个错误，模拟数据库查询失败。
			// 4. Mock i18nfmt.New 返回一个指定的错误。
			// 5. 调用 h.Validate，预期返回 dal 层错误对应的业务错误。
			dbErr := errors.New("db query failed")
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(nil, dbErr).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("检查节点审批结果失败")).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "检查节点审批结果失败")
		})

		mockey.PatchConvey("场景：校验不通过，存在更高优先级的未审批人员", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx 实例，并构造一个包含未审批人员的列表。
			// 逻辑链路：
			// 1. Mock pc.GetCurrentReviewer 返回一个虚拟的当前审批人。
			// 2. Mock pc.GetTx 返回一个 gorm.DB 实例。
			// 3. Mock dal.ListHighPriorityReviewerTypeNoPassedReviewer 返回包含两个未审批人员的列表。
			// 4. Mock i18nfmt.Sprintf 生成预期的错误信息。
			// 5. 调用 h.Validate，预期返回一个包含未审批人员名单的错误。
			noPassReviewers := model.PreContractReviewerDBList{
				{Reviewer: "reviewerA"},
				{Reviewer: "reviewerB"},
			}
			expectedErrMsg := fmt.Sprintf("存在前置审批人未审批通过，请等待前加签审批人审核通过后再操作。前置待审核人：%s", "reviewerA、reviewerB")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.ListHighPriorityReviewerTypeNoPassedReviewer).Return(noPassReviewers, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			// Act
			err := h.Validate(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErrMsg)
		})
	})
}

func Test_newHandlerConfirmSendback_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerConfirmSendback", t, func() {
		mockey.PatchConvey("正常场景：成功创建并返回handler", func() {
			// 场景描述:
			// 这是一个工厂函数，不涉及复杂的逻辑。
			// 逻辑链路:
			// 1. 调用 newHandlerConfirmSendback()
			// 2. 断言返回的实例不为nil
			// 3. 断言返回的实例类型为*handlerConfirmSendback

			// 调用
			handler := newHandlerConfirmSendback()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerConfirmSendback{})
		})
	})
}

func Test_handlerConfirmSendback_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmSendback_CurrentStatus", t, func() {
		mockey.PatchConvey("当调用CurrentStatus时，应返回预期的状态码", func() {
			// 场景描述：
			// 测试handlerConfirmSendback的CurrentStatus方法是否返回正确的状态码。
			// 构造数据：
			// - 初始化一个handlerConfirmSendback实例。
			// 逻辑链路：
			// 1. 创建handlerConfirmSendback的实例。
			// 2. 调用CurrentStatus方法。
			// 3. 断言返回值是否为_const.PreSalesContractCustomerConfirm。

			h := &handlerConfirmSendback{}

			result := h.CurrentStatus()

			convey.So(result, convey.ShouldEqual, _const.PreSalesContractCustomerConfirm)
		})
	})
}

func Test_handlerConfirmSendback_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmSendback_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSendBack", func() {
			// 场景描述：
			// 测试 handlerConfirmSendback 的 CurrentOp 方法，验证其是否正确返回预定义的退回操作码。
			// 构造数据：
			// 初始化一个 handlerConfirmSendback 实例。
			// 逻辑链路：
			// 1. 创建一个 handlerConfirmSendback 实例。
			// 2. 调用其 CurrentOp 方法。
			// 3. 断言返回的操作码与常量 _const.OperationSendBack 相等。

			// 初始化 handler
			h := &handlerConfirmSendback{}

			// 调用目标方法
			op := h.CurrentOp()

			// 断言结果
			convey.So(op, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerConfirmSendback_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmSendback_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述：
			// 构造数据：构造一个空的 handlerConfirmSendback 实例和 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 Process 方法。
			// 2. 预期方法直接返回 nil，无任何错误。

			// 准备数据
			h := &handlerConfirmSendback{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerConfirmSendback_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerConfirmSendback_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return true and nil", func() {
			// 场景描述:
			// 这是一个简单场景，测试函数直接返回 true 和 nil。
			// 构造数据:
			// - h: 一个 handlerConfirmSendback 的实例。
			// - ctx: context.Background()
			// - pc: 一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路:
			// 1. 直接调用目标函数。
			// 2. 断言返回值为 true 和 nil。

			// 准备数据
			h := &handlerConfirmSendback{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/riskclauserole"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerFTLReviewChangeReviewer_Process_BitsUTGen(t *testing.T) {
	// MockRiskClauseRoleService is a mock struct for mocking the riskclauserole.Service interface.
	type MockRiskClauseRoleService struct {
		riskclauserole.Service
	}

	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_Process", t, func() {
		// Initialize the handler instance to be tested.
		h := &handlerFTLReviewChangeReviewer{}
		ctx := context.Background()

		mockey.PatchConvey("Success: ChangeRiskRoleCreator returns no error", func() {
			// 场景描述：
			// 测试在风险条款创建人转办的场景下，Process函数成功执行的逻辑。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx 实例，包含合同号、新处理人(Extra)和当前操作人。
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 返回一个 MockRiskClauseRoleService 实例。
			// 2. Mock MockRiskClauseRoleService 的 ChangeRiskRoleCreator 方法，使其返回 nil（表示成功）。
			// 3. 调用目标函数 h.Process。
			// 4. 断言返回的 error 为 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST_CONTRACT_NO_123",
				},
				Extra:           "new_creator@example.com",
				CurrentOperator: "current_operator@example.com",
			}

			mockey.Mock(riskclauserole.NewService).Return(&MockRiskClauseRoleService{}).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: ChangeRiskRoleCreator returns an error", func() {
			// 场景描述：
			// 测试在风险条款创建人转办的场景下，依赖的服务 ChangeRiskRoleCreator 调用失败，Process函数返回错误的逻辑。
			// 构造数据：
			// - pc: auditmodel.ProcessCtx 实例，与成功场景类似。
			// - mockError: 一个自定义的 error。
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 返回一个 MockRiskClauseRoleService 实例。
			// 2. Mock MockRiskClauseRoleService 的 ChangeRiskRoleCreator 方法，使其返回一个预设的 error。
			// 3. 调用目标函数 h.Process。
			// 4. 断言返回的 error 不为 nil，并且错误信息包含预设的错误字符串。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "TEST_CONTRACT_NO_456",
				},
				Extra:           "new_creator@example.com",
				CurrentOperator: "current_operator@example.com",
			}
			mockError := errors.New("failed to change risk role creator")

			mockey.Mock(riskclauserole.NewService).Return(&MockRiskClauseRoleService{}).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(mockError).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to change risk role creator")
		})
	})
}

func Test_handlerFTLReviewChangeReviewer_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_PostProcess", t, func() {
		// Common Arrange
		h := &handlerFTLReviewChangeReviewer{}
		ctx := context.Background()
		mockDB := &gorm.DB{}

		// Mock the DAO interface
		mockDao := &MockPreContractReviewerDao{}
		mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()

		mockey.PatchConvey("Success: Change reviewer successfully", func() {
			// 场景描述:
			// 用户成功将审核任务转办给另一位用户。系统会更新审核人列表，并发送飞书通知。
			// 构造数据:
			// - pc.OperationState 设置为 OperationChangeReviewer
			// - pc.Extra 包含新审核人的邮箱
			// - pc.CurrentOperator 为原审核人的邮箱
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 成功返回。
			// 2. larkc.GetEmployeeByMailsWithCache 成功获取新审核人信息。
			// 3. 进入 h.changeReviewer 方法：
			//    a. dal.FindReviewersByNoAndEmail (原审核人) 成功返回其审核角色。
			//    b. dal.FindReviewersByNoAndEmail (新审核人) 返回空列表，表示新审核人没有重复角色。
			//    c. dal.Create 为新审核人创建审核任务成功。
			// 4. dal.DeleteChangedReviewer 成功删除原审核人的任务。
			// 5. larkc.BatchSendMessageToEmailIgnore 被调用以发送通知。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-001",
				CurrentOperator: "old.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "PC-2023-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Client",
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "D-001",
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
			}
			newReviewerEmployee := &peopleclient.Employee{
				ID:    2,
				Email: "new.reviewer@example.com",
			}
			oldReviewerRoles := model.PreContractReviewerDBList{
				{
					PreContractNo:  pc.PreContractNo,
					Reviewer:       pc.CurrentOperator,
					ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
					ContractStatus: 1,
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == pc.CurrentOperator
				}).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmployee.Email
				}).Return(model.PreContractReviewerDBList{}, nil).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: GetEmployeeByMailsWithCache fails", func() {
			// 场景描述:
			// 获取新审核人信息失败，导致整个转办流程中止并返回错误。
			// 逻辑链路:
			// 1. pc.GetCurrentReviewer 成功返回。
			// 2. larkc.GetEmployeeByMailsWithCache 返回错误。
			// 3. 函数立即返回该错误。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationChangeReviewer,
				Extra:          "new.reviewer@example.com",
			}
			expectedErr := errors.New("peopleclient error")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "peopleclient error")
		})

		mockey.PatchConvey("Failure: changeReviewer fails due to DB error on find", func() {
			// 场景描述:
			// 在 h.changeReviewer 方法内部，查询原审核人角色时数据库发生错误，流程中断。
			// 逻辑链路:
			// 1. 获取新审核人信息成功。
			// 2. 进入 h.changeReviewer。
			// 3. dal.FindReviewersByNoAndEmail 返回数据库错误。
			// 4. 函数返回该错误。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-001",
				CurrentOperator: "old.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo: "PC-2023-001",
				},
			}
			newReviewerEmployee := &peopleclient.Employee{ID: 2, Email: "new.reviewer@example.com"}
			expectedErr := errors.New("db find error")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(nil, expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db find error")
		})

		mockey.PatchConvey("Failure: changeReviewer fails due to DB error on create", func() {
			// 场景描述:
			// 在 h.changeReviewer 方法内部，为新审核人创建任务时数据库发生错误，流程中断。
			// 逻辑链路:
			// 1. 查询审核人信息均成功。
			// 2. dal.Create 返回数据库错误。
			// 3. 函数返回该错误。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-001",
				CurrentOperator: "old.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo: "PC-2023-001",
					BasicInfo:  &bizmodels.BasicInfo{DepartmentId: "D-001"},
				},
			}
			newReviewerEmployee := &peopleclient.Employee{ID: 2, Email: "new.reviewer@example.com"}
			oldReviewerRoles := model.PreContractReviewerDBList{
				{PreContractNo: pc.PreContractNo, Reviewer: pc.CurrentOperator, ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: 1},
			}
			expectedErr := errors.New("db create error")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool { return reviewer == pc.CurrentOperator }).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmployee.Email
				}).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db create error")
		})

		mockey.PatchConvey("Success: DeleteChangedReviewer fails but function returns nil", func() {
			// 场景描述:
			// 删除原审核人任务时数据库发生错误，但该错误被记录日志而不会中断整个流程，函数最终返回 nil。
			// 逻辑链路:
			// 1. h.changeReviewer 成功执行。
			// 2. dal.DeleteChangedReviewer 返回错误。
			// 3. 函数记录错误日志（不测试日志），然后成功返回 nil。

			// Arrange
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-001",
				CurrentOperator: "old.reviewer@example.com",
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo: "PC-2023-001",
					BasicInfo:  &bizmodels.BasicInfo{DepartmentId: "D-001"},
				},
			}
			newReviewerEmployee := &peopleclient.Employee{ID: 2, Email: "new.reviewer@example.com"}
			oldReviewerRoles := model.PreContractReviewerDBList{
				{PreContractNo: pc.PreContractNo, Reviewer: pc.CurrentOperator, ReviewerType: _const.ReviewerTypeFinanceTaxationLegalReviewer, ContractStatus: 1},
			}
			expectedErr := errors.New("db delete error")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockDB).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool { return reviewer == pc.CurrentOperator }).Return(oldReviewerRoles, nil).
				When(func(_ context.Context, _ *gorm.DB, _, reviewer string) bool {
					return reviewer == newReviewerEmployee.Email
				}).Return(model.PreContractReviewerDBList{}, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(expectedErr).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewChangeReviewer_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常分支-直接返回false和nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 的实现是直接返回 false 和 nil，没有任何其他逻辑。
			// 构造数据：
			// - 初始化一个 handlerFTLReviewChangeReviewer 实例。
			// - 初始化一个空的 auditmodel.ProcessCtx。
			// - 使用 context.Background()。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的 error 为 nil。
			h := &handlerFTLReviewChangeReviewer{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			hit, err := h.HitStateChangeCondition(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLReviewChangeReviewer_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_Validate", t, func() {
		h := &handlerFTLReviewChangeReviewer{}
		ctx := context.Background()

		mockey.PatchConvey("失败场景: 人员不可为空", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra 为空字符串。
			// 逻辑链路：
			// 1. 函数进入 commonValidateUpdateReviewers。
			// 2. 检查 pc.Extra 长度为0，直接返回错误 "人员不可为空"。
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("失败场景: 获取已有审批人列表失败", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra 不为空。
			// 逻辑链路：
			// 1. 函数进入 commonValidateUpdateReviewers。
			// 2. 检查 pc.Extra 长度不为0，继续执行。
			// 3. Mock perm.GetAllReviewersByType 返回一个错误。
			// 4. 函数将此错误直接返回。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, errors.New("db query error")).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db query error")
		})

		mockey.PatchConvey("失败场景: 添加的审批人已经是审核人员", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra 包含一个或多个审批人，其中至少一个已经是审核人员且未审批通过。
			// 逻辑链路：
			// 1. 函数进入 commonValidateUpdateReviewers。
			// 2. pc.Extra 不为空。
			// 3. Mock perm.GetAllReviewersByType 返回一个已存在的审批人列表，其状态不为 ReviewStatusReviewPass。
			// 4. 函数检查发现新加的审批人存在于已有列表中，且状态不满足条件。
			// 5. 函数返回错误，提示该审批人已是审核人员。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com,user2@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "user2@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
				{Reviewer: "user3@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			// 修复断言：由于error的Error()方法返回的不是简单的格式化字符串，而是包含code和message的结构化信息，
			// 导致"user2@example.com"和"已是审核人员"不连续，因此将原先的单个包含断言拆分为两个，分别断言关键信息的存在。
			convey.So(err.Error(), convey.ShouldContainSubstring, "user2@example.com")
			convey.So(err.Error(), convey.ShouldContainSubstring, "已是审核人员")
		})

		mockey.PatchConvey("成功场景: 添加的审批人不存在", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra 包含一个全新的审批人。
			// 逻辑链路：
			// 1. 函数进入 commonValidateUpdateReviewers。
			// 2. pc.Extra 不为空。
			// 3. Mock perm.GetAllReviewersByType 返回一个不包含新审批人的列表。
			// 4. 函数检查发现新加的审批人不在已有列表中。
			// 5. 函数返回 nil，校验通过。
			pc := &auditmodel.ProcessCtx{
				Extra: "new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 添加的审批人已存在但已审批通过", func() {
			// 场景描述：
			// 构造数据：ProcessCtx.Extra 包含一个已审批通过的审批人。
			// 逻辑链路：
			// 1. 函数进入 commonValidateUpdateReviewers。
			// 2. pc.Extra 不为空。
			// 3. Mock perm.GetAllReviewersByType 返回一个已存在的审批人列表，其状态为 ReviewStatusReviewPass。
			// 4. 函数检查发现新加的审批人存在于已有列表中，但其状态为通过，因此不计为冲突。
			// 5. 函数返回 nil，校验通过。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewChangeReviewer_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationChangeReviewer", func() {
			// 场景描述：
			// 这是一个简单的方法，它直接返回一个常量。
			// 构造数据：
			// 初始化一个 handlerFTLReviewChangeReviewer 实例。
			// 逻辑链路：
			// 1. 创建 handlerFTLReviewChangeReviewer 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值是否等于 _const.OperationChangeReviewer。
			h := &handlerFTLReviewChangeReviewer{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationChangeReviewer)
		})
	})
}

func Test_handlerFTLReviewChangeReviewer_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewChangeReviewer_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractFinanceTaxationLegalReview", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法的返回值。
			// 构造数据：
			// - 初始化一个 handlerFTLReviewChangeReviewer 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值是否等于常量 _const.PreSalesContractFinanceTaxationLegalReview。

			// 准备数据
			h := &handlerFTLReviewChangeReviewer{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalReview)
		})
	})
}

func Test_newHandlerFTLReviewChangeReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLReviewChangeReviewer", t, func() {
		mockey.PatchConvey("正常创建", func() {
			// 场景描述：
			// 该测试旨在验证 newHandlerFTLReviewChangeReviewer 函数是否能成功创建一个新的 handler 实例。
			// 构造数据：无特定数据构造。
			// 逻辑链路：
			// 1. 调用 newHandlerFTLReviewChangeReviewer() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerFTLReviewChangeReviewer。

			// 调用
			handler := newHandlerFTLReviewChangeReviewer()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLReviewChangeReviewer{})
		})
	})
}

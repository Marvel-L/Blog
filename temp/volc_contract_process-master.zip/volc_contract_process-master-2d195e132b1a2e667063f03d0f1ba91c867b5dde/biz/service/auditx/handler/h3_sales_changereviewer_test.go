package handler

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/riskclauserole"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerSalesReviewChangeReviewer_Process_BitsUTGen(t *testing.T) {
	// MockRiskClauseRoleService is a mock struct for the riskclauserole.Service interface.
	type MockRiskClauseRoleService struct {
		riskclauserole.Service
	}

	mockey.PatchConvey("Test handlerSalesReviewChangeReviewer_Process", t, func() {
		h := &handlerSalesReviewChangeReviewer{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: "test-contract-no",
			},
			Extra:           "new_reviewer@example.com",
			CurrentOperator: "current_operator@example.com",
		}
		mockService := &MockRiskClauseRoleService{}

		mockey.PatchConvey("success: when ChangeRiskRoleCreator returns nil", func() {
			// 场景描述：
			// 正常转办场景，风险条款创建人转办成功。
			// 构造数据：
			// 构造一个 ProcessCtx，其中包含合同号、新的处理人(Extra)和当前操作人(CurrentOperator)。
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 调用，使其返回一个自定义的 mock service 实例。
			// 2. Mock 该 mock service 实例的 ChangeRiskRoleCreator 方法，使其返回 nil，模拟转办成功。
			// 3. 调用目标函数 Process。
			// 4. 断言返回的 error 为 nil。
			mockey.Mock(riskclauserole.NewService).Return(mockService).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: when ChangeRiskRoleCreator returns an error", func() {
			// 场景描述：
			// 异常转办场景，风险条款创建人转办失败。
			// 构造数据：
			// 构造一个 ProcessCtx，其中包含合同号、新的处理人(Extra)和当前操作人(CurrentOperator)。
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 调用，使其返回一个自定义的 mock service 实例。
			// 2. Mock 该 mock service 实例的 ChangeRiskRoleCreator 方法，使其返回一个 error，模拟转办失败。
			// 3. 调用目标函数 Process。
			// 4. 断言返回的 error 不为 nil，并且错误信息与 mock 的错误一致。
			expectedErr := errors.New("failed to change risk role creator")
			mockey.Mock(riskclauserole.NewService).Return(mockService).Build()
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to change risk role creator")
		})
	})
}

func Test_handlerSalesReviewChangeReviewer_PostProcess_BitsUTGen(t *testing.T) {
	// Mock dal.PreContractReviewerDao interface
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerSalesReviewChangeReviewer_PostProcess", t, func() {
		// Common variables
		ctx := context.Background()
		h := &handlerSalesReviewChangeReviewer{}
		mockPreContractReviewerDao := &MockPreContractReviewerDao{}
		mockTx := &gorm.DB{}

		mockey.PatchConvey("ChangeReviewer: Happy Path", func() {
			// Scene Description:
			// Test the successful path for changing a reviewer.
			//
			// Mock Data:
			// - pc.OperationState is OperationChangeReviewer.
			// - pc.Extra contains one new reviewer's email.
			//
			// Logic Path:
			// 1. GetCurrentReviewer returns a mock reviewer.
			// 2. GetEmployeeByMailsWithCache successfully returns the new reviewer's info.
			// 3. The loop calls the changeReviewer method, which is mocked to return nil.
			// 4. DeleteChangedReviewer is called and mocked to succeed.
			// 5. Lark message sending is mocked to succeed.
			// 6. The function returns nil.

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "old.reviewer@example.com",
				PreContractNo:   "CONTRACT-001",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
					BasicInfo: &bizmodels.BasicInfo{},
				},
			}
			newReviewerEmployee := &peopleclient.Employee{
				Email: "new.reviewer@example.com",
				ID:    123,
			}
			currentReviewer := &bizmodels.PreContractReviewer{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(currentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

			// Mock Lark message sending
			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("").Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("ChangeReviewer: changeReviewer fails", func() {
			// Scene Description:
			// Test the scenario where the internal changeReviewer method fails.
			//
			// Mock Data:
			// - pc.OperationState is OperationChangeReviewer.
			//
			// Logic Path:
			// 1. GetCurrentReviewer and GetEmployeeByMailsWithCache succeed.
			// 2. The loop calls changeReviewer, which is mocked to return an error.
			// 3. The function returns the error immediately.

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationChangeReviewer,
				Extra:          "new.reviewer@example.com",
			}
			newReviewerEmployee := &peopleclient.Employee{
				Email: "new.reviewer@example.com",
				ID:    123,
			}
			mockErr := errors.New("changeReviewer failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{newReviewerEmployee}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(mockErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "changeReviewer failed")
		})

		mockey.PatchConvey("ChangeReviewer: DeleteChangedReviewer fails but error is ignored", func() {
			// Scene Description:
			// Test the scenario where deleting the old reviewer fails. This error should be logged but not returned.
			//
			// Mock Data:
			// - pc.OperationState is OperationChangeReviewer.
			//
			// Logic Path:
			// 1. changeReviewer succeeds.
			// 2. DeleteChangedReviewer is called and mocked to return an error.
			// 3. The error is logged (not tested), and the function continues.
			// 4. Lark message sending succeeds.
			// 5. The function returns nil.

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState:  _const.OperationChangeReviewer,
				Extra:           "new.reviewer@example.com",
				CurrentOperator: "old.reviewer@example.com",
				PreContractNo:   "CONTRACT-001",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers:      bizmodels.PreContractReviewerList{},
					BasicInfo:      &bizmodels.BasicInfo{},
				},
			}
			mockErr := errors.New("delete failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{{}}, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockPreContractReviewerDao).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(mockTx).Build()
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(mockErr).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(utils.StringListFormat).Return([]string{}).Build()

			// Mock Lark message sending dependencies
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("").Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("AddReviewer: Happy Path", func() {
			// Scene Description:
			// Test the successful path for adding a reviewer (加签).
			//
			// Mock Data:
			// - pc.OperationState is OperationAddReviewer.
			//
			// Logic Path:
			// 1. GetCurrentReviewer and GetEmployeeByMailsWithCache succeed.
			// 2. The loop calls countersignReviewer, which is mocked to succeed.
			// 3. The DeleteChangedReviewer block is skipped.
			// 4. Lark message is sent successfully.
			// 5. The function returns nil.

			// Arrange
			pc := &auditmodel.ProcessCtx{
				OperationState: _const.OperationAddReviewer,
				Extra:          "new.reviewer@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers:      bizmodels.PreContractReviewerList{},
					BasicInfo:      &bizmodels.BasicInfo{},
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{{}}, nil).Build()
			mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Mock Lark message sending dependencies
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url").Build()
			mockBuilder := &larkc.CommonMessageCardBuilder{}
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("").Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("GetEmployeeByMailsWithCache fails", func() {
			// Scene Description:
			// Test the scenario where fetching employee info fails.
			//
			// Logic Path:
			// 1. GetEmployeeByMailsWithCache is mocked to return an error.
			// 2. The function returns the error immediately.

			// Arrange
			pc := &auditmodel.ProcessCtx{
				Extra: "bad.email@example.com",
			}
			mockErr := errors.New("larkc failed")
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, mockErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "larkc failed")
		})
	})
}

func Test_handlerSalesReviewChangeReviewer_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewChangeReviewer_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述:
			// 目标函数 HitStateChangeCondition 内部逻辑非常简单，直接返回 false 和 nil。
			// 构造数据:
			// - 构造一个空的 handlerSalesReviewChangeReviewer 实例。
			// - 构造一个空的 ProcessCtx。
			// 逻辑链路:
			// 1. 调用目标函数。
			// 2. 断言返回结果为 false 和 nil。

			// 数据准备
			h := &handlerSalesReviewChangeReviewer{}
			pc := &auditmodel.ProcessCtx{}
			ctx := context.Background()

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSalesReviewChangeReviewer_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewChangeReviewer_Validate", t, func() {
		h := &handlerSalesReviewChangeReviewer{}
		ctx := context.Background()

		mockey.PatchConvey("场景：传入的审批人员为空", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 Extra 字段为空字符串。
			// 逻辑链路：
			// 1. Validate 调用 commonValidateUpdateReviewers。
			// 2. commonValidateUpdateReviewers 检查 pc.Extra 长度为 0，为 true。
			// 3. 函数返回 "人员不可为空" 错误。
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景：获取所有审批人时发生数据库错误", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 Extra 字段不为空。
			// 逻辑链路：
			// 1. Validate 调用 commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回一个错误。
			// 3. 函数直接返回该错误。
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-TEST-001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			dbErr := errors.New("db query error")
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, dbErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbErr)
		})

		mockey.PatchConvey("场景：添加的审批人已存在且未完成审批", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 Extra 字段包含一个已存在的审批人，其状态为未审核。
			// 逻辑链路：
			// 1. Validate 调用 commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回一个包含该审批人的列表，其状态为未审核。
			// 3. 函数遍历新审批人，发现其中一个已存在且状态不为“审核通过”。
			// 4. 函数返回 "已是审核人员" 的错误。
			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com,new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-TEST-002",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{
					Reviewer: "existing.user@example.com",
					BaseDB: model.BaseDB{
						Status: _const.ReviewStatusUnreviewed,
					},
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing.user@example.com")
		})

		mockey.PatchConvey("场景：添加的审批人已存在但已完成审批", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 Extra 字段包含一个已存在的审批人，其状态为已通过。
			// 逻辑链路：
			// 1. Validate 调用 commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回一个包含该审批人的列表，其状态为“审核通过”。
			// 3. 函数遍历新审批人，发现其中一个已存在但状态为“审核通过”，因此忽略。
			// 4. 校验成功，返回 nil。
			pc := &auditmodel.ProcessCtx{
				Extra: "passed.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-TEST-003",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{
					Reviewer: "passed.user@example.com",
					BaseDB: model.BaseDB{
						Status: _const.ReviewStatusReviewPass,
					},
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：成功添加新的审批人", func() {
			// 场景描述：
			// 构造数据：ProcessCtx 的 Extra 字段包含一个全新的审批人。
			// 逻辑链路：
			// 1. Validate 调用 commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回一个不包含新审批人的列表。
			// 3. 函数遍历新审批人，未发现任何冲突。
			// 4. 校验成功，返回 nil。
			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CN-TEST-004",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{
					Reviewer: "another.user@example.com",
					BaseDB: model.BaseDB{
						Status: _const.ReviewStatusUnreviewed,
					},
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSalesReviewChangeReviewer_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewChangeReviewer_CurrentOp", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 该函数为一个简单返回值函数，直接返回一个常量。
			// 构造数据：
			// 初始化一个 handlerSalesReviewChangeReviewer 结构体实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否为预期的常量 _const.OperationChangeReviewer。

			// 准备数据
			h := &handlerSalesReviewChangeReviewer{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationChangeReviewer)
		})
	})
}

func Test_handlerSalesReviewChangeReviewer_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSalesReviewChangeReviewer_CurrentStatus", t, func() {
		mockey.PatchConvey("should return the correct status for sales operation review", func() {
			// 场景描述：
			// 构造数据：创建一个handlerSalesReviewChangeReviewer实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 验证返回值是否为预期的常量 _const.PreSalesContractSalesOperationReview。

			// 准备数据
			h := &handlerSalesReviewChangeReviewer{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
		})
	})
}

func Test_newHandlerSalesReviewChangeReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test newHandlerSalesReviewChangeReviewer", t, func() {
		mockey.PatchConvey("正常创建", func() {
			// 场景描述：
			// 测试工厂函数 newHandlerSalesReviewChangeReviewer 的基本功能。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. 调用 newHandlerSalesReviewChangeReviewer() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例类型为 *handlerSalesReviewChangeReviewer。

			// 调用
			handler := newHandlerSalesReviewChangeReviewer()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSalesReviewChangeReviewer{})
		})
	})
}

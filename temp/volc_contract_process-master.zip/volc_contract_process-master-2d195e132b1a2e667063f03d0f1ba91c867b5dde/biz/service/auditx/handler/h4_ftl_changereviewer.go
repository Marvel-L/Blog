package handler

import (
	"context"
	"volc_contract_process/biz/service/riskclauserole"

	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

func newHandlerFTLReviewChangeReviewer() StatusOpHandler {
	return &handlerFTLReviewChangeReviewer{}
}

// 财税法交付专业审核(4) --- 转办(6) --> 财税法审核(4)
type handlerFTLReviewChangeReviewer struct {
	handlerCommon
}

func (h *handlerFTLReviewChangeReviewer) CurrentStatus() int {
	return _const.PreSalesContractFinanceTaxationLegalReview
}

func (h *handlerFTLReviewChangeReviewer) CurrentOp() int {
	return _const.OperationChangeReviewer
}

func (h *handlerFTLReviewChangeReviewer) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h *handlerFTLReviewChangeReviewer) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 风险条款创建人转办
	return riskclauserole.NewService().ChangeRiskRoleCreator(ctx, pc.ContractInfo.ContractNo, pc.Extra, []string{pc.CurrentOperator})
}

func (h *handlerFTLReviewChangeReviewer) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerFTLReviewChangeReviewer) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

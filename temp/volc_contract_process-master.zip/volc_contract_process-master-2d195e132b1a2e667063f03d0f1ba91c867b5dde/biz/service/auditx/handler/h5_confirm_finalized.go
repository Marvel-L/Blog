package handler

import (
	"context"
	"strings"

	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	utils "volc_contract_process/pkg/util"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
)

func newHandlerConfirmFinalized() StatusOpHandler {
	return &handlerConfirmFinalized{}
}

// 销售确认中(5) --- 可定稿(9) --> 销售运营完善信息(7)
type handlerConfirmFinalized struct {
	handlerCommon
}

func (h *handlerConfirmFinalized) CurrentStatus() int {
	return _const.PreSalesContractCustomerConfirm
}

func (h *handlerConfirmFinalized) CurrentOp() int {
	return _const.OperationFinalized
}

func (h *handlerConfirmFinalized) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// “关联报价单场景 = 未完成报价审批”，不允许操作可定稿
	if pc.ContractInfo.RelateQuoteScene == _const.RelateQuoteSceneNoCompleted {
		return errorsV2.ErrInternalError.WithArgs("当前合同的“报价单情况”为“未完成报价审批”，不支持定稿，请在CRM系统通过“有修改”关联已完成审批的报价单。")
	}

	// 处理补充协议场景下 相关逻辑校验
	if err := h.validateSupply(ctx, pc); err != nil {
		return err
	}

	// 绑定报价单场景 校验合同有效期与报价单有效期
	contractInfo := pc.ContractInfo
	contractVO := pc.PreContractVO
	if contractInfo.NeedRelateQuoteNo() {
		if contractInfo.RelateQuoteNo == "" {
			return errorsV2.ErrQuoteCommon.WithArgs("当前合同必须关联报价单")
		}
		info, err := quotecli.GetQuoteInfo(ctx, contractInfo.RelateQuoteNo)
		if err != nil {
			return i18nfmt.New(ctx, "查询报价单失败")
		}
		if info == nil {
			return i18nfmt.Errorf(ctx, "关联的报价单[%s]不存在", contractInfo.RelateQuoteNo)
		}
		if err := validateUsefulLifeType(ctx, contractVO, info, contractInfo.BasicInfo, contractInfo.ManageInfo); err != nil {
			return err
		}
	}
	if err := contractInfo.BasicInfo.ValidateContractPeriod(ctx, _const.SalesContractUnSubmit); err != nil {
		logs.CtxError(ctx, "校验合同有效期类型信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
		return err
	}
	// if err := validateTradePartyInfo(ctx, contractInfo.BasicInfo, contractInfo.TradePartyInfo); err != nil {
	// 	logs.CtxError(ctx, "校验交易对方信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
	// 	return err
	// }
	// if err := validateRiskClauseRole(ctx, contractInfo.ContractNo); err != nil {
	// 	logs.CtxError(ctx, "校验风险条款条目信息失败，ContractNo：%s， err：%v", contractInfo.ContractNo, err)
	// 	return err
	// }

	// 校验返券规则有效期与合同有效期
	if err := h.checkAndCorrectCouponValiditySubset(ctx, pc); err != nil {
		logs.CtxError(ctx, "校验返券规则有效期与合同有效期交集失败，ContractNo：%s， err：%v", pc.ContractInfo.ContractNo, err)
		return err
	}

	return nil
}

func (h *handlerConfirmFinalized) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	if err := h.updateContractData(ctx, pc); err != nil {
		return err
	}

	pc.Extra = ""

	return nil
}

func (h *handlerConfirmFinalized) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerConfirmFinalized) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 发送飞书消息
	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationCompleteInformation),
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同待完善信息提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 提交的合同已完成协商及客户确认，待您完善信息，请您及时前往后台进行完善", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "查看详情"), larkc.GenEditURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
	// 通知 C360
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeConfirmFinalized, pc)
	return nil
}

package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"volc_contract_process/biz/service/riskclauserole"
	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/filecli"
	utils "volc_contract_process/pkg/util"

	_const "volc_contract_process/pkg/const"

	"volc_contract_process/biz/service/auditx/auditmodel"
)

var ReplaceReviewerConfig = map[int][]int{
	_const.PreSalesContractSalesOperationReview: {
		_const.ReviewerRoleSalesOp,
	},
	_const.PreSalesContractFinanceTaxationLegalReview: {
		_const.ReviewerRoleFinanceAR,
		_const.ReviewerRoleFinanceBP,
		_const.ReviewerRoleTaxBP,
		_const.ReviewerRoleLegalBP,
		_const.ReviewerRolePA,
		_const.ReviewerRoleDelivery,
	},
	_const.PreSalesContractSalesOperationCompleteInformation: {
		_const.ReviewerRoleSalesOp,
	},
	_const.PreSalesContractFinanceTaxationLegalSignReview: {
		_const.ReviewerRoleFinanceAR,
		_const.ReviewerRoleFinanceBP,
		_const.ReviewerRoleTaxBP,
		_const.ReviewerRoleLegalBP,
		_const.ReviewerRolePA,
	},
	_const.PreSalesContractRiskReview: {
		_const.ReviewerRoleSalesOp,
	},
	_const.PreSalesContractSolutionReview: {
		_const.ReviewerRoleSolution,
	},
}

func newHandlerMultiAcquireReviewer() MultiStatusOpHandler {
	return &handlerMultiAcquireReviewer{}
}

// handlerMultiAcquireReviewer
//
//	销售运营专业审核(3)  --- 分配给我(17)   --> 销售运营专业审核(3)
//	财税法交付专业审核(4)   --- 分配给我(17)   --> 财税法审核(4)
//	销售运营完善信息(7)   --- 分配给我(17)   --> 销售运营完善信息(7)
type handlerMultiAcquireReviewer struct {
	handlerCommon
}
type handlerMultiAcquireReviewerState struct {
	UniqOriginalEmails []string
}
type OperationAcquireReviewerExtraInfo struct {
	From []string `json:"from"`
	To   []string `json:"to"`
}

func (h *handlerMultiAcquireReviewer) CurrentStatus() int {
	panic("unexpected call MultiStatusOpHandler CurrentStatus() method")
}

func (h *handlerMultiAcquireReviewer) SupportStatus() []int {
	return []int{
		_const.PreSalesContractSalesOperationReview,
		_const.PreSalesContractFinanceTaxationLegalReview,
		_const.PreSalesContractSalesOperationCompleteInformation,
		_const.PreSalesContractFinanceTaxationLegalSignReview,
		_const.PreSalesContractRiskReview,
		_const.PreSalesContractSolutionReview,
	}
}

func (h *handlerMultiAcquireReviewer) CurrentOp() int {
	return _const.OperationAcquireReviewer
}

func (h *handlerMultiAcquireReviewer) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerMultiAcquireReviewer) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	operatorEmail := pc.CurrentOperator

	operatorEmployee, err1 := larkc.GetEmployeeByEmailWithCache(ctx, operatorEmail)
	if err1 != nil {
		logs.CtxError(ctx, "GetEmployeeByEmail error: %+v", err1)
		return errors.ErrCommon.WithArgs("获取当前用户信息失败")
	}
	if operatorEmployee == nil {
		logs.CtxError(ctx, "GetEmployeeByEmail operatorEmployee == nil")
		return errors.ErrCommon.WithArgs("获取当前用户信息失败")
	}
	operatorID := strconv.Itoa(operatorEmployee.ID)

	if _, ok := ReplaceReviewerConfig[pc.ContractInfo.CooperationStatus]; !ok {
		return errors.ErrCommon.WithArgs("合同状态当前节点不为销售运营专业审核、财税法交付专业审核、销售运营完善信息状态，不能进行变更操作")
	}

	reviewers, err4 := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, nil, pc.ContractInfo.ContractNo)
	if err4 != nil {
		logs.CtxError(ctx, "FindReviewersByNo error: %+v", err4)
		return errors.ErrCommon.WithArgs("获取当前合同审核人员失败")
	}

	relatedReviewers, err5 := h.reviewerMatcher().GetRelatedReviewers(ctx, operatorEmail, pc.ContractInfo.BasicInfo.DepartmentId)
	if err5 != nil {
		logs.CtxError(ctx, "GetReviewerRoles error: %+v", err5)
		return errors.ErrInternalError.WithArgs("获取审核人员角色失败")
	}

	currentOperatorReviewers := h.currentOperatorReviewers(reviewers, operatorEmail)

	var needUpdateIDs []uint64
	var needDeleteIDs []uint64
	var originalEmails []string
	roleUpdates := map[uint64]int{}

	permission := _const.PermissionRead
	// 获取当前合同节点具有合同写入权限的角色列表
	writableReviewerTypes, _ := GetWritableReviewerType(pc.ContractInfo.CooperationStatus, pc.ApprovalKey)

	for _, reviewer := range reviewers {
		if reviewer.Reviewer == operatorEmail {
			// 已经是自己就不用替换了
			continue
		}
		if reviewer.Status != _const.ReviewStatusUnreviewed {
			// 已经审核的节点不会改变
			continue
		}
		if reviewerRoles, ok := ReplaceReviewerConfig[reviewer.ContractStatus]; ok {
			for _, reviewerRole := range reviewerRoles {
				if _, ok := relatedReviewers[reviewerRole][reviewer.Reviewer]; ok {
					originalEmails = append(originalEmails, reviewer.Reviewer)

					// 判断被替换掉的角色是否有写入权限
					if len(writableReviewerTypes) > 0 {
						if utils.IntIn(reviewer.ReviewerType, writableReviewerTypes) {
							permission = _const.PermissionWrite
						}
					}

					reviewerKey := fmt.Sprintf("%d_%d", reviewer.ContractStatus, reviewer.ReviewerType)
					if existingReviewer, ok := currentOperatorReviewers[reviewerKey]; ok {
						targetReviewerRole := _const.InheritReviewerRole(reviewer.ReviewerRole, existingReviewer.ReviewerRole)
						if targetReviewerRole != existingReviewer.ReviewerRole {
							roleUpdates[existingReviewer.Id] = targetReviewerRole
							existingReviewer.ReviewerRole = targetReviewerRole
						}
						needDeleteIDs = append(needDeleteIDs, reviewer.Id)
					} else {
						needUpdateIDs = append(needUpdateIDs, reviewer.Id)
						currentOperatorReviewers[reviewerKey] = &model.PreContractReviewerDB{
							BaseDB:       model.BaseDB{Id: reviewer.Id},
							ReviewerRole: reviewer.ReviewerRole,
						}
					}
					break
				}
			}
		}
	}

	internalState := &handlerMultiAcquireReviewerState{}
	if len(needUpdateIDs) > 0 || len(needDeleteIDs) > 0 {
		logs.CtxInfo(ctx, "BatchReplaceReviewer preContractNo: %s, originalEmails=%+v", pc.ContractInfo.ContractNo, originalEmails)
		err6 := dal.GetDB(ctx).Transaction(func(tx *gorm.DB) error {
			if len(needUpdateIDs) > 0 {
				err := dal.NewPreContractReviewerDao().BatchReplaceReviewer(ctx, tx, operatorEmail, operatorID, pc.ContractInfo.ContractNo, needUpdateIDs)
				if err != nil {
					logs.CtxError(ctx, "BatchReplaceReviewer error: %+v", err)
					return errors.ErrCommon.WithArgs("更新合同审批人员失败")
				}
			}
			for id, reviewerRole := range roleUpdates {
				err := dal.NewPreContractReviewerDao().UpdateByID(ctx, tx, id, map[string]interface{}{"reviewer_role": reviewerRole})
				if err != nil {
					logs.CtxError(ctx, "Update reviewer_role error: %+v", err)
					return errors.ErrCommon.WithArgs("更新合同审批人员角色失败")
				}
			}
			if len(needDeleteIDs) > 0 {
				err := dal.NewPreContractReviewerDao().BatchDeleteReviewer(ctx, tx, pc.ContractInfo.ContractNo, needDeleteIDs)
				if err != nil {
					logs.CtxError(ctx, "BatchReplaceReviewer error: %+v", err)
					return errors.ErrCommon.WithArgs("移除重复的合同审批人员失败")
				}
			}
			return nil
		})
		if err6 != nil {
			logs.CtxError(ctx, "BatchReplaceReviewer error: %+v", err6)
			return errors.ErrCommon.WithArgs("更新合同审批人员失败")
		}

		// 加文件编辑器权限
		go AddFilePermByEmailSync(ctx, pc.ContractInfo.OnlineContract, permission, []string{operatorEmail})

		uniqOriginalEmails := utils.StringListUnique(originalEmails)
		pc.Remark = "权限分配成功"
		utils.EmailToEmailPrefix(operatorEmail)

		extraBytes, _ := json.Marshal(&OperationAcquireReviewerExtraInfo{
			From: uniqOriginalEmails,
			To:   []string{operatorEmail},
		})
		pc.Extra = string(extraBytes)

		internalState.UniqOriginalEmails = uniqOriginalEmails
	} else {
		logs.CtxInfo(ctx, "BatchReplaceReviewer 没有人被替换")
	}

	err := riskclauserole.NewService().ChangeRiskRoleCreator(ctx, pc.ContractInfo.ContractNo, pc.CurrentOperator, originalEmails)
	if err != nil {
		logs.CtxError(ctx, "ChangeRiskRoleCreatorFail, newCreator:%s, oldCreator:%v, err:%v", pc.CurrentOperator, originalEmails, err)
		return err
	}

	pc.InternalState = internalState
	return nil
}

func (h *handlerMultiAcquireReviewer) currentOperatorReviewers(reviewers model.PreContractReviewerDBList, operatorEmail string) map[string]*model.PreContractReviewerDB {
	currentOperatorReviewers := map[string]*model.PreContractReviewerDB{}
	for _, reviewer := range reviewers {
		if reviewer.Reviewer != operatorEmail {
			continue
		}
		key := fmt.Sprintf("%d_%d", reviewer.ContractStatus, reviewer.ReviewerType)
		oldReviewer, ok := currentOperatorReviewers[key]
		if !ok || oldReviewer.ReviewerRole == _const.ReviewerRoleCountersign {
			currentOperatorReviewers[key] = reviewer
		}
	}
	return currentOperatorReviewers
}

func (h *handlerMultiAcquireReviewer) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerMultiAcquireReviewer) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	operatorEmail := pc.CurrentOperator
	internalState, _ := pc.InternalState.(*handlerMultiAcquireReviewerState)
	if internalState != nil {
		uniqOriginalEmails := internalState.UniqOriginalEmails
		contractOperator, _ := larkc.GetEmployeeByID(ctx, pc.ContractInfo.Operator)
		var contractOperatorEmail string
		if contractOperator != nil && len(contractOperator) > 0 {
			contractOperatorEmail = contractOperator[0].Email
		}
		var url string
		if pc.ContractInfo.CooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation {
			url = larkc.GenEditURL(ctx, pc.ContractInfo.ContractNo)
		} else {
			url = larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)
		}
		multiCtx := context.Background()
		if len(uniqOriginalEmails) > 0 {
			atOriginalEmails := strings.Join(utils.StringListFormat(uniqOriginalEmails, larkc.LarkMdAtEmail), "")
			// 通知新分配的审批人
			larkc.BatchSendMessageToEmailIgnore(ctx, []string{operatorEmail}, larkc.MsgTypeInteractive, larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s已将%s的合同审核权限转移给自己，转移后%s不再拥有该合同的审核权限，请知悉！", larkc.LarkMdAtEmail(operatorEmail), atOriginalEmails, atOriginalEmails)).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "业务执行人"), larkc.LarkMdAtEmail(contractOperatorEmail)).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), url).
				BuildJSONString())
			// 通知原来的审批人
			larkc.BatchSendMessageToEmailIgnore(ctx, uniqOriginalEmails, larkc.MsgTypeInteractive, larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorYellow).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s已将%s的合同审核权限转移给自己，转移后%s不再拥有该合同的审核权限，请知悉！", larkc.LarkMdAtEmail(operatorEmail), atOriginalEmails, atOriginalEmails)).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "业务执行人"), larkc.LarkMdAtEmail(contractOperatorEmail)).
				BuildJSONString())
		} else {
			larkc.BatchSendMessageToEmailIgnore(ctx, []string{operatorEmail}, larkc.MsgTypeInteractive, larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s已将%s的合同审核权限转移给自己，%s已经是审核人员，审核人员没有改变，请知悉！", larkc.LarkMdAtEmail(operatorEmail), pc.ContractInfo.ContractNo, larkc.LarkMdAtEmail(operatorEmail))).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "业务执行人"), larkc.LarkMdAtEmail(contractOperatorEmail)).
				AddAction(multienv.I18nFormat(multiCtx, "查看详情"), url).
				BuildJSONString())
		}
	}
	return nil
}

func AddFilePermByEmailSync(ctx context.Context, fileID string, permission int, employeeEmails []string) {
	logs.CtxInfo(ctx, "[AddFilePermByEmailSync] input: fileID=%s employeeEmails=%v", fileID, employeeEmails)
	users := []*filecli.User{}
	for _, employeeEmail := range employeeEmails {
		employee, err := larkc.GetEmployeeByEmailWithCache(ctx, employeeEmail)
		if err != nil || employee == nil {
			continue
		}
		users = append(users, &filecli.User{
			FileId:     fileID,
			Uid:        strconv.Itoa(employee.ID),
			Name:       employee.Name,
			Email:      employee.Email,
			AvatarUrl:  employee.AvatarURL,
			Permission: permission,
		})
	}
	// 修改在线编辑权限
	(&handlerCommon{}).addOrUpdateFilePerm(ctx, &filecli.UpdateUserPermissionReq{
		Users: users,
	})
	logs.CtxInfo(ctx, "[AddFilePermByEmailSync] finish: fileID=%s", fileID)
}

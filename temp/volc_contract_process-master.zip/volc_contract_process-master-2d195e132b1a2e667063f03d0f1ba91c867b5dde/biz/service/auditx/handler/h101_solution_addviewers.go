package handler

import (
	"context"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSolutionAddViewers() StatusOpHandler {
	return &handlerSolutionAddViewers{}
}

// 解决方案审核(101) --- 加签(5) --> 解决方案审核(101)
type handlerSolutionAddViewers struct {
	handlerCommon
}

func (h handlerSolutionAddViewers) CurrentStatus() int {
	return _const.PreSalesContractSolutionReview
}

func (h handlerSolutionAddViewers) CurrentOp() int {
	return _const.OperationAddReviewer
}

func (h handlerSolutionAddViewers) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonValidateUpdateReviewers(ctx, pc)
}

func (h handlerSolutionAddViewers) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h handlerSolutionAddViewers) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h handlerSolutionAddViewers) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.commonPostProcessUpdateReviewers(ctx, pc)
}

package handler

import (
	"context"
	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSalesReviewUpdate() StatusOpHandler {
	return &handlerSalesReviewUpdate{}
}

// 销售运营专业审核(3) --- 提交草稿(0) --> 销售运营专业审核(3)
type handlerSalesReviewUpdate struct {
	handlerCommon
}

func (h *handlerSalesReviewUpdate) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewUpdate) CurrentOp() int {
	return _const.OperationSubmitDraft
}

func (h *handlerSalesReviewUpdate) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return h.ValidateDeputyParty(ctx, pc)
}

func (h *handlerSalesReviewUpdate) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 更新pre_sales_contract字段
	return h.updateContractData(ctx, pc)
}

func (h *handlerSalesReviewUpdate) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return false, nil
}

func (h *handlerSalesReviewUpdate) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

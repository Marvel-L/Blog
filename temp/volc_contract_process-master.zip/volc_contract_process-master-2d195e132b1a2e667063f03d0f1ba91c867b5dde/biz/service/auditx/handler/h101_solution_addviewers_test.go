package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

type MockPreContractReviewerDao2 struct {
	dal.PreContractReviewerDao
}

func Test_handlerSolutionAddViewers_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionAddViewers PostProcess", t, func() {

		ctx := context.Background()
		h := handlerSolutionAddViewers{}
		pc := &auditmodel.ProcessCtx{
			PreContractNo:   "PCN-TEST-123",
			CurrentOperator: "operator@example.com",
			Extra:           "new.reviewer@example.com",
			ContractInfo: &model.ContractMeta{
				ContractNo:        "CN-TEST-123",
				ContractName:      "Test Contract",
				OtherPartyName:    "Test Party Inc.",
				CooperationStatus: _const.ReviewerTypeSolutionReviewer,
				BasicInfo: &bizmodels.BasicInfo{
					DepartmentId: "D-001",
				},
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
				},
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: _const.ReviewerTypeSolutionReviewer,
			},
		}
		mockNewReviewers := []*peopleclient.Employee{
			{ID: 1001, Email: "new.reviewer@example.com", Name: "New Reviewer"},
		}
		mockCurrentReviewer := &bizmodels.PreContractReviewer{
			Reviewer:       pc.CurrentOperator,
			ReviewerType:   pc.ReviewerStatusOpConf.ReviewerType,
			ContractStatus: pc.ContractInfo.CooperationStatus,
			Priority:       1,
		}

		mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
		mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockCurrentReviewer).Build()

		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
		mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
		mockey.Mock(larkc.GenReviewURL).Return("http://review.url/").Build()
		mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()

		mockey.PatchConvey("成功场景: 操作为加签(AddReviewer)", func() {

			pc.OperationState = _const.OperationAddReviewer

			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 操作为转办(ChangeReviewer)", func() {

			pc.OperationState = _const.OperationChangeReviewer

			mockDao := &MockPreContractReviewerDao2{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao2).DeleteChangedReviewer).Return(nil).Build()
			mockLarkCardBuilder := larkc.NewCommonMessageCardBuilder()
			mockey.Mock(larkc.NewCommonMessageCardBuilder).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockLarkCardBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("").Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 其他操作", func() {

			pc.OperationState = _const.OperationReviewPass

			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: GetEmployeeByMailsWithCache返回错误", func() {

			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, errors.New("mock get employee error")).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock get employee error")
		})

		mockey.PatchConvey("失败场景: countersignReviewer返回错误", func() {

			pc.OperationState = _const.OperationAddReviewer
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock((*handlerCommon).countersignReviewer).Return(errors.New("mock countersign error")).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock countersign error")
		})

		mockey.PatchConvey("失败场景: changeReviewer返回错误", func() {

			pc.OperationState = _const.OperationChangeReviewer
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(errors.New("mock change reviewer error")).Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock change reviewer error")
		})

		mockey.PatchConvey("部分失败场景: DeleteChangedReviewer返回错误", func() {

			pc.OperationState = _const.OperationChangeReviewer

			mockDao := &MockPreContractReviewerDao2{}
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(mockNewReviewers, nil).Build()
			mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
			mockey.Mock((*MockPreContractReviewerDao2).DeleteChangedReviewer).Return(errors.New("mock delete reviewer error")).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.PostProcess(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionAddViewers_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionAddViewers_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should always return false and nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 当前实现是一个存根，总是返回 false 和 nil。
			// 本测试旨在验证这一固定行为。
			//
			// 构造数据：
			// - 初始化一个 handlerSolutionAddViewers 实例。
			// - 创建一个 background context。
			// - 创建一个空的 auditmodel.ProcessCtx 实例。
			//
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的 error 为 nil。

			// 数据准备
			h := handlerSolutionAddViewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSolutionAddViewers_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionAddViewers_Process", t, func() {
		mockey.PatchConvey("should return nil for default case", func() {
			// 场景描述：
			// 目标函数 Process 当前的实现是直接返回 nil，因此本测试用例旨在验证其基本行为。
			// 构造数据：
			// - 初始化一个 handlerSolutionAddViewers 实例。
			// - 创建一个空的 context.Context。
			// - 创建一个空的 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. 直接调用 Process 方法。
			// 2. 断言返回的 error 为 nil。

			// 数据准备
			h := handlerSolutionAddViewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			err := h.Process(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionAddViewers_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionAddViewers_Validate", t, func() {
		ctx := context.Background()
		h := handlerSolutionAddViewers{}

		mockey.PatchConvey("场景一：人员为空，校验失败", func() {
			// 场景描述：
			// 构造数据：传入的ProcessCtx的Extra字段为空字符串。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. commonValidateUpdateReviewers检查到pc.Extra长度为0。
			// 3. 函数返回"人员不可为空"的错误。

			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景二：获取已有审核人列表失败", func() {
			// 场景描述：
			// 构造数据：传入的ProcessCtx的Extra字段不为空。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 函数返回一个错误。
			// 3. commonValidateUpdateReviewers函数直接返回该错误。

			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			dbErr := errors.New("database error")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, dbErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbErr)
		})

		mockey.PatchConvey("场景三：成功添加全新的审核人", func() {
			// 场景描述：
			// 构造数据：传入的审核人不在已有的审核人列表中。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回一个空的审核人列表。
			// 3. commonValidateUpdateReviewers检查发现新增人员不与现有人员冲突。
			// 4. 函数返回nil，校验通过。

			pc := &auditmodel.ProcessCtx{
				Extra: "new.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景四：添加已存在的审核人（非通过状态），校验失败", func() {
			// 场景描述：
			// 构造数据：要添加的审核人已存在，并且其状态不是“审核通过”。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回包含该审核人的列表。
			// 3. commonValidateUpdateReviewers检查发现该人员已存在且状态不为通过。
			// 4. 函数返回包含该人员姓名的错误信息。

			pc := &auditmodel.ProcessCtx{
				Extra: "existing.user@example.com,another.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "existing.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "existing.user@example.com")
		})

		mockey.PatchConvey("场景五：添加已存在的审核人（已通过状态），校验成功", func() {
			// 场景描述：
			// 构造数据：要添加的审核人已存在，但其状态是“审核通过”。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回包含该审核人的列表，状态为“审核通过”。
			// 3. commonValidateUpdateReviewers检查发现该人员虽存在但状态为通过，不计为冲突。
			// 4. 函数返回nil，校验通过。

			pc := &auditmodel.ProcessCtx{
				Extra: "passed.user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "passed.user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景六：添加多个已存在的审核人（非通过状态），错误信息应合并", func() {
			// 场景描述：
			// 构造数据：要添加的多个审核人均已存在，并且其状态都不是“审核通过”。
			// 逻辑链路：
			// 1. Validate方法调用commonValidateUpdateReviewers。
			// 2. Mock perm.GetAllReviewersByType 返回包含这些审核人的列表。
			// 3. commonValidateUpdateReviewers检查发现多个人员冲突。
			// 4. 函数返回一个合并了所有冲突人员姓名的错误信息。

			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com,user2@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			existingReviewers := model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
				{Reviewer: "user2@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewSendBack}},
			}
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.GetAllReviewersByType).Return(existingReviewers, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "user1@example.com,user2@example.com")
		})
	})
}

func Test_handlerSolutionAddViewers_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionAddViewers_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationAddReviewer", func() {
			// 场景描述：
			// 本测试用例旨在验证 `handlerSolutionAddViewers` 的 `CurrentOp` 方法是否总是返回预期的操作类型常量 `_const.OperationAddReviewer`。
			// 构造数据：
			// 初始化一个 `handlerSolutionAddViewers` 结构体实例。
			// 逻辑链路：
			// 1. 创建 `handlerSolutionAddViewers` 的一个实例。
			// 2. 调用该实例的 `CurrentOp` 方法。
			// 3. 断言返回的整数值与常量 `_const.OperationAddReviewer` 相等。

			// 初始化 handler
			h := handlerSolutionAddViewers{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.OperationAddReviewer)
		})
	})
}

func Test_handlerSolutionAddViewers_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionAddViewers CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法，该方法应返回一个预定义的常量状态值。
			// 构造数据：
			// - 初始化一个 handlerSolutionAddViewers 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回的状态值是否等于 _const.PreSalesContractSolutionReview。

			h := handlerSolutionAddViewers{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSolutionReview)
		})
	})
}

func Test_newHandlerSolutionAddViewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSolutionAddViewers", t, func() {
		mockey.PatchConvey("should return a non-nil handler of type *handlerSolutionAddViewers", func() {
			// 场景描述：
			// 这是一个简单的工厂函数，不涉及复杂的逻辑和外部依赖。
			// 构造数据：
			// 无需构造特殊数据。
			// 逻辑链路：
			// 1. 调用 newHandlerSolutionAddViewers() 函数。
			// 2. 验证返回的处理器不为 nil。
			// 3. 验证返回的处理器具体类型为 *handlerSolutionAddViewers。

			// 调用目标函数
			handler := newHandlerSolutionAddViewers()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSolutionAddViewers{})
		})
	})
}

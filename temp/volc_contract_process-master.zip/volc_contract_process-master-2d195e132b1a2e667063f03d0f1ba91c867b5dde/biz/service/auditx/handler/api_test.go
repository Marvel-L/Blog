package handler

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels/modelcooperation"
	_const "volc_contract_process/pkg/const"
)

func Test_GetWritableReviewerType_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestGetWritableReviewerType", t, func() {
		mockey.PatchConvey("场景一: 审批流key和合同状态均存在, 成功获取权限列表", func() {
			// 场景描述:
			// 传入的approvalKey和contractState在预设的权限映射表中都有对应的配置。
			// 构造数据:
			// approvalKey = _const.ApprovalKeyDefault
			// contractState = _const.PreSalesContractSalesOperationReview
			// 逻辑链路:
			// 1. 在 reviewerTypeWritePermApprovalMappings 中成功找到 approvalKey 对应的权限映射 writePermMap。
			// 2. 在 writePermMap 中成功找到 contractState 对应的权限列表 t。
			// 3. 函数返回权限列表 t 和 true。

			contractState := _const.PreSalesContractSalesOperationReview
			approvalKey := _const.ApprovalKeyDefault

			got, exist := GetWritableReviewerType(contractState, approvalKey)

			convey.So(exist, convey.ShouldBeTrue)
			expected := []int{
				_const.ReviewerTypeSalesOperation,
				_const.ReviewerTypeSalesperson,
				_const.ReviewerTypeFinanceTaxationLegalReviewer,
				_const.ReviewerTypeMentioned,
			}
			convey.So(got, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("场景二: 审批流key存在但合同状态不存在, 获取权限列表失败", func() {
			// 场景描述:
			// 传入的approvalKey在权限映射表中有配置，但对应的合同状态contractState没有配置。
			// 构造数据:
			// approvalKey = _const.ApprovalKeyDefault
			// contractState = 999 (一个未配置的状态)
			// 逻辑链路:
			// 1. 在 reviewerTypeWritePermApprovalMappings 中成功找到 approvalKey 对应的权限映射 writePermMap。
			// 2. 在 writePermMap 中未找到 contractState 对应的权限列表。
			// 3. 函数返回 nil 和 false。

			contractState := 999 // 一个不存在的合同状态
			approvalKey := _const.ApprovalKeyDefault

			got, exist := GetWritableReviewerType(contractState, approvalKey)

			convey.So(exist, convey.ShouldBeFalse)
			convey.So(got, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景三: 审批流key不存在, 获取权限列表失败", func() {
			// 场景描述:
			// 传入的approvalKey在权限映射表中不存在。
			// 构造数据:
			// approvalKey = "non_existent_key"
			// contractState = _const.PreSalesContractDraft
			// 逻辑链路:
			// 1. 在 reviewerTypeWritePermApprovalMappings 中未找到 approvalKey 对应的权限映射。
			// 2. 函数直接返回 nil 和 false。

			contractState := _const.PreSalesContractDraft
			approvalKey := "non_existent_key"

			got, exist := GetWritableReviewerType(contractState, approvalKey)

			convey.So(exist, convey.ShouldBeFalse)
			convey.So(got, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景四: 另一个有效的审批流key和合同状态组合", func() {
			// 场景描述:
			// 传入的approvalKey和contractState是另一个在预设的权限映射表中存在的有效组合。
			// 构造数据:
			// approvalKey = _const.ApprovalKeyDefault
			// contractState = _const.PreSalesContractDraft
			// 逻辑链路:
			// 1. 在 reviewerTypeWritePermApprovalMappings 中成功找到 approvalKey 对应的权限映射 writePermMap。
			// 2. 在 writePermMap 中成功找到 contractState 对应的权限列表 t。
			// 3. 函数返回权限列表 t 和 true。

			contractState := _const.PreSalesContractDraft
			approvalKey := _const.ApprovalKeyDefault

			got, exist := GetWritableReviewerType(contractState, approvalKey)

			convey.So(exist, convey.ShouldBeTrue)
			expected := []int{_const.ReviewerTypeSalesperson}
			convey.So(got, convey.ShouldResemble, expected)
		})
	})
}

func Test_GetValidReviewerType_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test GetValidReviewerType", t, func() {
		mockey.PatchConvey("success: should return correct config for valid default approval key", func() {
			// 场景描述：
			// 测试当提供有效的 approvalKey, contractState, 和 opState 时，函数是否能正确返回对应的配置。
			// 本场景使用默认审批流 (_const.ApprovalKeyDefault)。
			// 构造数据：
			// approvalKey: _const.ApprovalKeyDefault
			// contractState: _const.PreSalesContractDraft (草稿)
			// opState: _const.OperationSubmitPreContract (提交在线协同)
			// 逻辑链路：
			// 1. 函数在 reviewerTypeApprovalMappings 中找到 "default" 对应的映射。
			// 2. 在该映射中，找到 contractState `1` (草稿) 对应的映射。
			// 3. 在该映射中，找到 opState `1` (提交在线协同) 对应的配置并返回。
			// 4. 断言返回的配置不为nil，并且关键字段符合预期。

			approvalKey := _const.ApprovalKeyDefault
			contractState := _const.PreSalesContractDraft
			opState := _const.OperationSubmitPreContract

			result := GetValidReviewerType(contractState, opState, approvalKey)

			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.ReviewerType, convey.ShouldEqual, _const.ReviewerTypeSalesperson)
			convey.So(result.NewStatusOnSuccess, convey.ShouldEqual, _const.ReviewStatusReviewPass)
			status, ok := result.ContractNewStatusMapOnSuccess[_const.ApprovalStatusKeyDefault]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(status, convey.ShouldNotBeNil)
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractSalesOperationReview)
			convey.So(result.IgnoreRolePermCheck, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("success: should return correct config for another valid approval key", func() {
			// 场景描述：
			// 测试当提供另一个有效的 approvalKey (_const.ApprovalKeyCooperationSelfPurchase) 时，函数是否能正确返回配置。
			// 构造数据：
			// approvalKey: _const.ApprovalKeyCooperationSelfPurchase
			// contractState: _const.PreSalesContractNotCreated (未创建)
			// opState: _const.OperationSubmitDraft (提交草稿)
			// 逻辑链路：
			// 1. 函数在 reviewerTypeApprovalMappings 中找到 "cooperation_self_purchase" 对应的映射。
			// 2. 在该映射中，找到 contractState `0` (未创建) 对应的映射。
			// 3. 在该映射中，找到 opState `0` (提交草稿) 对应的配置并返回。
			// 4. 断言返回的配置不为nil，并且关键字段符合预期。

			approvalKey := _const.ApprovalKeyCooperationSelfPurchase
			contractState := _const.PreSalesContractNotCreated
			opState := _const.OperationSubmitDraft

			result := GetValidReviewerType(contractState, opState, approvalKey)

			convey.So(result, convey.ShouldNotBeNil)
			status, ok := result.ContractNewStatusMapOnSuccess[_const.ApprovalStatusKeyDefault]
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(status, convey.ShouldNotBeNil)
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractDraft)
			convey.So(result.IgnoreRolePermCheck, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("failure: should return nil for an invalid contractState", func() {
			// 场景描述：
			// 测试当 contractState 在映射中不存在时，函数是否返回 nil。
			// 构造数据：
			// approvalKey: _const.ApprovalKeyDefault
			// contractState: 9999 (一个无效的状态)
			// opState: _const.OperationSubmitDraft
			// 逻辑链路：
			// 1. 函数在 reviewerTypeApprovalMappings 中找到 "default" 对应的映射。
			// 2. 在该映射中，尝试查找 contractState `9999`，得到一个空 map。
			// 3. 函数检查到 map 长度为 0，返回 nil。
			// 4. 断言结果为 nil。

			approvalKey := _const.ApprovalKeyDefault
			contractState := 9999
			opState := _const.OperationSubmitDraft

			result := GetValidReviewerType(contractState, opState, approvalKey)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: should return nil for an invalid opState", func() {
			// 场景描述：
			// 测试当 opState 在映射中不存在时，函数是否返回 nil。
			// 构造数据：
			// approvalKey: _const.ApprovalKeyDefault
			// contractState: _const.PreSalesContractDraft
			// opState: 9999 (一个无效的操作)
			// 逻辑链路：
			// 1. 函数在 reviewerTypeApprovalMappings 中找到 "default" 对应的映射。
			// 2. 在该映射中，找到 contractState `1` (草稿) 对应的映射。
			// 3. 在该映射中，尝试查找 opState `9999`，返回该 map value 类型的零值，即 nil。
			// 4. 断言结果为 nil。

			approvalKey := _const.ApprovalKeyDefault
			contractState := _const.PreSalesContractDraft
			opState := 9999

			result := GetValidReviewerType(contractState, opState, approvalKey)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: should return nil for an invalid approvalKey", func() {
			// 场景描述：
			// 测试当 approvalKey 在顶层映射中不存在时，函数是否返回 nil。
			// 构造数据：
			// approvalKey: "invalid_key"
			// contractState: _const.PreSalesContractDraft
			// opState: _const.OperationSubmitDraft
			// 逻辑链路：
			// 1. 函数在 reviewerTypeApprovalMappings 中查找 "invalid_key"，返回 nil。
			// 2. `typeMappings` 变量被赋值为 nil。
			// 3. 接下来对 nil map `typeMappings` 进行索引操作 `typeMappings[contractState]`，返回 nil。
			// 4. len(m) == 0 条件成立，函数返回 nil。
			// 5. 断言结果为 nil。

			approvalKey := "invalid_key"
			contractState := _const.PreSalesContractDraft
			opState := _const.OperationSubmitDraft

			result := GetValidReviewerType(contractState, opState, approvalKey)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success: should return nil when contract state map is empty", func() {
			// 场景描述：
			// 这是一个理论上的测试用例，用于覆盖 if len(m) == 0 的分支。
			// 假设存在一个 approvalKey，其下的某个 contractState 映射存在但为空 map。
			// 在当前的数据结构下，这种情况不会自然发生，但为了代码覆盖率和健壮性，可以进行测试。
			// 这里通过修改全局变量来模拟这种情况。
			// 构造数据：
			// approvalKey: "test_empty_map"
			// contractState: 1
			// 逻辑链路：
			// 1. 临时向 reviewerTypeApprovalMappings 添加一个测试条目，其 contractState 映射为空。
			// 2. 调用函数，函数获取到这个空的 contractState 映射。
			// 3. len(m) == 0 条件成立，函数返回 nil。
			// 4. 断言结果为 nil。
			// 5. 清理临时添加的测试条目。

			testApprovalKey := "test_empty_map"
			_const.ReviewerTypeApprovalMappings[testApprovalKey] = map[int]map[int]*modelcooperation.ReviewerStatusOpConf{
				1: {}, // Empty map for contractState 1
			}
			defer delete(_const.ReviewerTypeApprovalMappings, testApprovalKey)

			result := GetValidReviewerType(1, 1, testApprovalKey)

			convey.So(result, convey.ShouldBeNil)
		})
	})
}

package handler

import (
	"context"
	"encoding/json"
	"errors"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"
)

func Test_handlerComplianceCheckPass_Process(t *testing.T) {

	mockey.PatchConvey("Test_handlerComplianceCheckPass_Process_BitsUTGen", t, func() {
		h := &handlerComplianceCheckPass{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: 前序状态不为“销售运营完善信息”，直接返回nil", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus不等于_const.PreSalesContractSalesOperationCompleteInformation
			// 逻辑链路：
			// 1. 第一个if条件 `pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation` 为false。
			// 2. 函数直接返回nil，不执行任何操作。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: 0, // Not PreSalesContractSalesOperationCompleteInformation
				},
			}

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 前序状态正确，但不是海外环境且未关联模板，直接返回nil", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，但IsBytePlus返回false且TemplateInfo为nil。
			// 逻辑链路：
			// 1. 第一个if条件为true。
			// 2. Mock multienv.IsBytePlus() 返回 false。
			// 3. 第二个if条件 `multienv.IsBytePlus() || (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil)` 为false。
			// 4. 函数直接返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					TemplateInfo:         nil, // No template
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 海外环境，非倒签合同，成功提交OA消息", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，IsBytePlus返回true，IsReverseContract返回nil。
			// 逻辑链路：
			// 1. 第一个if条件为true。
			// 2. Mock multienv.IsBytePlus() 返回 true，进入第二个if。
			// 3. Mock h.IsReverseContract 返回 nil，不进入倒签处理逻辑。
			// 4. Mock h.SendSubmitOaMsg 成功返回。
			// 5. 函数成功返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 关联了模板，非倒签合同，成功提交OA消息", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，IsBytePlus返回false，但关联了模板。IsReverseContract返回nil。
			// 逻辑链路：
			// 1. 第一个if条件为true。
			// 2. Mock multienv.IsBytePlus() 返回 false，但因为模板存在，进入第二个if。
			// 3. Mock h.IsReverseContract 返回 nil，不进入倒签处理逻辑。
			// 4. Mock h.SendSubmitOaMsg 成功返回。
			// 5. 函数成功返回nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					TemplateInfo: &bizmodels.TemplateInfo{
						Master: &bizmodels.TemplateDetail{},
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: 海外环境，是倒签合同，更新倒签信息成功，并成功提交OA消息", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，IsBytePlus返回true，IsReverseContract返回error。
			// 逻辑链路：
			// 1. 第一个if条件为true。
			// 2. Mock multienv.IsBytePlus() 返回 true，进入第二个if。
			// 3. Mock h.IsReverseContract 返回 error，进入倒签处理逻辑。
			// 4. 更新倒签信息，Mock dal.NewVolcContractMetaDao().UpdateByMap 返回 nil。
			// 5. Mock h.SendSubmitOaMsg 成功返回。
			// 6. 函数成功返回nil。
			mockDao := dal.NewContractMetaDao()
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ID:                   123,
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 123, UpdatedTime: time.Now()},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(errors.New("is reverse contract")).Build()
			// 尽管用户要求禁止mock dal.NewVolcContractMetaDao，但为了测试此分支，必须mock数据库调用以避免实际的DB操作。
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock(mockey.GetMethod(mockDao, "UpdateByMap")).Return(nil).Build()
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(nil).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldBeNil)

			// 断言倒签信息是否被正确填充
			expectedReverseInfo := &bizmodels.ReverseSignInfo{
				ReverseSignCode:   "RS008",
				ReverseSignReason: "合同签署的提前计划/安排不足",
			}
			expectedJSON, _ := json.Marshal(expectedReverseInfo)
			convey.So(pc.PreContractVO.ReverseSignInfo, convey.ShouldEqual, string(expectedJSON))
			convey.So(pc.ContractInfo.ReverseSignInfo, convey.ShouldResemble, expectedReverseInfo)
		})

		mockey.PatchConvey("场景6: 海外环境，是倒签合同，但更新倒签信息失败", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，IsBytePlus返回true，IsReverseContract返回error。
			// 逻辑链路：
			// 1. 第一个if条件为true。
			// 2. Mock multienv.IsBytePlus() 返回 true，进入第二个if。
			// 3. Mock h.IsReverseContract 返回 error，进入倒签处理逻辑。
			// 4. 更新倒签信息，Mock dal.NewVolcContractMetaDao().UpdateByMap 返回一个错误。
			// 5. 函数将此错误返回，后续的SendSubmitOaMsg不被调用。
			mockDao := dal.NewContractMetaDao()
			dbErr := errors.New("db update failed")
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ID:                   123,
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
				},
				PreContractVO: &model.ContractMetaDB{
					BaseDB: model.BaseDB{Id: 123},
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(errors.New("is reverse contract")).Build()
			// 尽管用户要求禁止mock dal.NewVolcContractMetaDao，但为了测试此分支，必须mock数据库调用以避免实际的DB操作。
			mockey.Mock(dal.NewContractMetaDao).Return(mockDao).Build()
			mockey.Mock(mockey.GetMethod(mockDao, "UpdateByMap")).Return(dbErr).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db update failed")
		})

		mockey.PatchConvey("场景7: 提交OA消息失败", func() {
			// 场景描述：
			// 构造数据：PreCooperationStatus正确，IsBytePlus返回true，IsReverseContract返回nil。
			// 逻辑链路：
			// 1. 各项检查通过，进入提交OA消息步骤。
			// 2. Mock h.SendSubmitOaMsg 返回一个错误。
			// 3. 函数将此错误返回。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			sendErr := errorsV2.ErrCommon.WithArgs("send oa msg failed")

			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			mockey.Mock((*handlerCommon).IsReverseContract).Return(nil).Build()
			mockey.Mock((*handlerCommon).SendSubmitOaMsg).Return(sendErr).Build()

			err := h.Process(ctx, pc)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, sendErr)
		})
	})
}

func Test_handlerComplianceCheckPass_GetStatusOpConfKey(t *testing.T) {
	mockey.PatchConvey("Test_handlerComplianceCheckPass_GetStatusOpConfKey", t, func() {
		h := &handlerComplianceCheckPass{}
		ctx := context.Background()

		mockey.PatchConvey("场景一：前置状态为销售运营完善信息", func() {
			mockey.PatchConvey("分支1：是海外环境，应返回提交OA", func() {
				// 场景描述：
				// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractSalesOperationCompleteInformation
				// 逻辑链路：
				// 1. 进入第一个if分支 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation)
				// 2. Mock multienv.IsBytePlus() 返回 true
				// 3. 进入嵌套的if分支 (multienv.IsBytePlus() || ...)
				// 4. 返回 _const.ApprovalStatusKeyCompleteInformationComplianceCheckSubmitOA
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
					},
				}
				mockey.Mock(multienv.IsBytePlus).Return(true).Build()

				result := h.GetStatusOpConfKey(ctx, pc)
				convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyCompleteInformationComplianceCheckSubmitOA)
			})

			mockey.PatchConvey("分支2：非海外环境但关联了主模板，应返回提交OA", func() {
				// 场景描述：
				// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractSalesOperationCompleteInformation，且TemplateInfo.Master不为nil
				// 逻辑链路：
				// 1. 进入第一个if分支 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation)
				// 2. Mock multienv.IsBytePlus() 返回 false
				// 3. 进入嵌套的if分支，因为 (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil) 为 true
				// 4. 返回 _const.ApprovalStatusKeyCompleteInformationComplianceCheckSubmitOA
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
						TemplateInfo: &bizmodels.TemplateInfo{
							Master: &bizmodels.TemplateDetail{},
						},
					},
				}
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()

				result := h.GetStatusOpConfKey(ctx, pc)
				convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyCompleteInformationComplianceCheckSubmitOA)
			})

			mockey.PatchConvey("分支3：非海外环境且未关联模板，应返回通过", func() {
				// 场景描述：
				// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractSalesOperationCompleteInformation，且TemplateInfo为nil
				// 逻辑链路：
				// 1. 进入第一个if分支 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation)
				// 2. Mock multienv.IsBytePlus() 返回 false
				// 3. 进入嵌套的else分支，因为 (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil) 为 false
				// 4. 返回 _const.ApprovalStatusKeyCompleteInformationComplianceCheckPass
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
						TemplateInfo:         nil,
					},
				}
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()

				result := h.GetStatusOpConfKey(ctx, pc)
				convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyCompleteInformationComplianceCheckPass)
			})

			mockey.PatchConvey("分支4：非海外环境且关联模板但无主模板，应返回通过", func() {
				// 场景描述：
				// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractSalesOperationCompleteInformation，且TemplateInfo.Master为nil
				// 逻辑链路：
				// 1. 进入第一个if分支 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation)
				// 2. Mock multienv.IsBytePlus() 返回 false
				// 3. 进入嵌套的else分支，因为 (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil) 为 false
				// 4. 返回 _const.ApprovalStatusKeyCompleteInformationComplianceCheckPass
				pc := &auditmodel.ProcessCtx{
					ContractInfo: &model.ContractMeta{
						PreCooperationStatus: _const.PreSalesContractSalesOperationCompleteInformation,
						TemplateInfo: &bizmodels.TemplateInfo{
							Master: nil,
						},
					},
				}
				mockey.Mock(multienv.IsBytePlus).Return(false).Build()

				result := h.GetStatusOpConfKey(ctx, pc)
				convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyCompleteInformationComplianceCheckPass)
			})
		})

		mockey.PatchConvey("场景二：前置状态为草稿", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractDraft
			// 逻辑链路：
			// 1. 跳过第一个if分支
			// 2. 进入else if分支 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractDraft)
			// 3. 返回 _const.ApprovalStatusKeyDraftComplianceCheckPass
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: _const.PreSalesContractDraft,
				},
			}
			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDraftComplianceCheckPass)
		})

		mockey.PatchConvey("场景三：其他前置状态", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为一个未定义的值
			// 逻辑链路：
			// 1. 跳过所有if/else if分支
			// 2. 返回默认值 _const.ApprovalStatusKeyDefault
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: 999, // 任意其他状态
				},
			}
			result := h.GetStatusOpConfKey(ctx, pc)
			convey.So(result, convey.ShouldEqual, _const.ApprovalStatusKeyDefault)
		})
	})
}

func Test_handlerComplianceCheckPass_PostProcess(t *testing.T) {
	// 测试输入合同预合作状态为草稿的场景
	t.Run("PreCooperationStatusIsDraft", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock((*handlerComplianceCheckPass).notifyDraftPass).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			// 构造函数入参
			var receiver *handlerComplianceCheckPass = &handlerComplianceCheckPass{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo.PreCooperationStatus == 1 && pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: 1,
				},
			}
			// 运行被测函数
			err := receiver.PostProcess(ctxTest, pcTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 业务函数中没有返回错误的逻辑，最后返回的是nil，所以err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
	// 测试PreCooperationStatus为7的场景
	t.Run("PreCooperationStatusIs7", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock((*handlerComplianceCheckPass).notifyCompleteInformationPass).Return().Build()
			mockey.Mock((*handlerComplianceCheckPass).notifyDraftPass).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			// 构造函数入参
			var receiver *handlerComplianceCheckPass = &handlerComplianceCheckPass{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo.PreCooperationStatus == 7 && pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: 7,
				},
			}
			// 运行被测函数
			err := receiver.PostProcess(ctxTest, pcTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 业务函数中没有返回错误的逻辑，最后返回值为nil，所以err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerComplianceCheckPass_notifyDraftPass(t *testing.T) {
	// 测试在模拟被调用函数的情况下，notifyDraftPass函数的执行情况
	t.Run("NotifyDraftPassWithMockedFunctions", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString, mockey.OptUnsafe).Return("{\\\"key\\\": \\\"value\\\"}").Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf, mockey.OptUnsafe).Return("Mocked sprintf return value").Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock(utils.StringListFormat).Return(nil).Build()
			mockey.Mock(larkc.NewCommonMessageCardBuilder, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("https://example.com/review/123").Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return(nil).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(multienv.I18nFormat).Return("Mocked i18n format return data").Build()
			// 构造函数入参
			var receiver *handlerComplianceCheckPass = &handlerComplianceCheckPass{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				StatusChangedValue: 0,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CT2024001",
					ContractName:   "Sales Contract",
					OtherPartyName: "ABC Company",
				},
			}
			// 断言值由大模型生成，需要评估是否符合预期值!
			convey.So(func() { receiver.notifyDraftPass(ctxTest, pcTest) }, convey.ShouldNotPanic)
		})
	})
}

func Test_handlerComplianceCheckPass_notifyCompleteInformationPass(t *testing.T) {
	// 测试pc.StatusChangedValue等于8且pc.ContractInfo不为空的场景
	t.Run("StatusChangedValueEquals8AndContractInfoNotNull", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf, mockey.OptUnsafe).Return("Mocked sprintf return value").Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return(nil).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(multienv.I18nFormat).Return("en-US").Build()
			mockey.Mock(larkc.NewCommonMessageCardBuilder, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString, mockey.OptUnsafe).Return("{\\\"key\\\": \\\"value\\\"}").Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("https://example.com/review/123").Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			// 构造函数入参
			// [目标分支] pcTest.StatusChangedValue == 8 && pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractName: "Sales Contract",
					ContractNo:   "CT2024001",
				},
				StatusChangedValue: 8,
			}
			var receiver *handlerComplianceCheckPass = &handlerComplianceCheckPass{}
			var ctxTest context.Context = context.Background()
			// 断言值由大模型生成，需要评估是否符合预期值!
			convey.So(func() { receiver.notifyCompleteInformationPass(ctxTest, pcTest) }, convey.ShouldNotPanic)
		})
	})
	// 测试输入pc.StatusChangedValue等于9的场景
	t.Run("StatusChangedValueEquals9", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock(i18nfmt.Sprintf, mockey.OptUnsafe).Return("Mocked sprintf return value").Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).Return(nil).Build()
			mockey.Mock(larkc.NewCommonMessageCardBuilder, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()
			mockey.Mock(utils.StringListFormat).Return(nil).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString, mockey.OptUnsafe).Return("{\\\"key\\\": \\\"value\\\"}").Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("https://example.com/review/123").Build()
			mockey.Mock((*handlerCommon).notifyC360).Return(nil).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			mockey.Mock(multienv.I18nFormat).Return("en-US").Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return(nil).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent, mockey.OptUnsafe).Return(&larkc.CommonMessageCardBuilder{}).Build()
			// 构造函数入参
			// [目标分支] pcTest.ContractInfo != nil && pcTest.StatusChangedValue == 9
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					OtherPartyName: "ABC Company",
					ContractName:   "Sales Contract",
					ContractNo:     "CT2024001",
				},
				StatusChangedValue: 9,
			}
			var receiver *handlerComplianceCheckPass = &handlerComplianceCheckPass{}
			var ctxTest context.Context = context.Background()
			// 断言值由大模型生成，需要评估是否符合预期值!
			convey.So(func() { receiver.notifyCompleteInformationPass(ctxTest, pcTest) }, convey.ShouldNotPanic)
		})
	})
}

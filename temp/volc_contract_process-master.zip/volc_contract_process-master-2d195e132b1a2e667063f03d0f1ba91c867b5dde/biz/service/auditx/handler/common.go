package handler

/***/

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/shopspring/decimal"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	metaattachmodels "volc_contract_process/biz/bizmodels/metaattach"
	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/businessmodeclause"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/guarantee"
	"volc_contract_process/biz/service/metaattach"
	mqProducer "volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/biz/service/riskengineservice"
	"volc_contract_process/biz/service/ruleengine"
	"volc_contract_process/biz/service/supply"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/biz/service/support/metaext"
	quoteservice "volc_contract_process/biz/service/support/quote"
	"volc_contract_process/biz/service/support/reviewrule"
	"volc_contract_process/biz/service/template"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/mdparty"
	"volc_contract_process/pkg/preload"
	"volc_contract_process/pkg/proxy/accountcli"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/innertopcommercializationcli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/quotecli"
	"volc_contract_process/pkg/proxy/riskenginecli"
	"volc_contract_process/pkg/recovery"
	utils "volc_contract_process/pkg/util"

	"code.byted.org/eps-platform/commercialization_sdk_go/sdk/dto/lite"
	"code.byted.org/eps-platform/quote_sdk_go/quote_client"
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/eps-platform/vcp_clients/pkg/util"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
)

var reviewerMatcher *reviewrule.ReviewerMatcher

func SetReviewerMatcher(reviewerMatcher1 *reviewrule.ReviewerMatcher) {
	reviewerMatcher = reviewerMatcher1
}

// 通用默认逻辑处理器
type handlerCommon struct {
	attachmentService    metaattach.AttachmentService
	metaCommodityService metacommodity.Service
	metaExtService       metaext.Service
	metaService          contractmeta.MetaService
	metaServiceV2        contractmeta.MetaServiceV2
	quoteService         quoteservice.Service
	commodityService     metacommodity.Service
}

func (h *handlerCommon) getAttachmentService(ctx context.Context) metaattach.AttachmentService {
	if h.attachmentService == nil {
		h.attachmentService = metaattach.NewAttachmentService()
	}
	return h.attachmentService
}

func (h *handlerCommon) getMetaCommodityService(ctx context.Context) metacommodity.Service {
	if h.metaCommodityService == nil {
		h.metaCommodityService = metacommodity.NewService()
	}
	return h.metaCommodityService
}

func (h *handlerCommon) getMetaService(ctx context.Context) contractmeta.MetaService {
	if h.metaService == nil {
		h.metaService = contractmeta.NewMetaService()
	}
	return h.metaService
}

func (h *handlerCommon) getMetaServiceV2(ctx context.Context) contractmeta.MetaServiceV2 {
	if h.metaServiceV2 == nil {
		h.metaServiceV2 = contractmeta.NewMetaServiceV2()
	}
	//
	return h.metaServiceV2
}

func (h *handlerCommon) getQuoteService(ctx context.Context) quoteservice.Service {
	if h.quoteService == nil {
		h.quoteService = quoteservice.NewService()
	}
	//
	return h.quoteService
}

func (h *handlerCommon) getCommodityService(ctx context.Context) metacommodity.Service {
	if h.commodityService == nil {
		h.commodityService = metacommodity.NewService()
	}
	return h.commodityService
}

func (h *handlerCommon) getExtService(ctx context.Context) metaext.Service {
	if h.metaExtService == nil {
		h.metaExtService = metaext.NewService()
	}
	return h.metaExtService
}

// reviewerMatcher 获取审核人匹配器
func (h *handlerCommon) reviewerMatcher() *reviewrule.ReviewerMatcher {
	return reviewerMatcher
}

// addOrUpdateFilePerm 添加或更新文件权限
func (h *handlerCommon) addOrUpdateFilePerm(ctx context.Context, req *filecli.UpdateUserPermissionReq) {

	defer recovery.DefaultRecovery(ctx, "addOrUpdateFilePerm")()

	if len(req.Users) == 0 {
		return
	}

	// 填充 name、头像属性
	emails := req.GetAllUserEmails()
	employees, err := larkc.GetEmployeeByMailsWithCache(ctx, emails)
	if err != nil {
		logs.CtxError(ctx, "GetEmployeeByMailFail, emails:%v, err:%v", emails, err.Error())
		return
	}

	employeeMapping := map[string]*peopleclient.Employee{}
	for _, e := range employees {
		employeeMapping[strconv.Itoa(e.ID)] = e
	}

	for _, u := range req.Users {
		employee := employeeMapping[u.Uid]
		if employee == nil {
			continue
		}
		u.Name = employee.Name
		u.AvatarUrl = employee.AvatarURL
	}

	if err = filecli.UpdateUserPermission(ctx, req); err != nil {
		logs.CtxError(ctx, "UpdateUserPermissionFail, err:%v", err.Error())
	}

}

// buildPermReq 构建权限更新请求
func (h *handlerCommon) buildPermReq(reviewers bizmodels.PreContractReviewerList, updateInfo *filePermUpdateInfo) *filecli.UpdateUserPermissionReq {
	var users filecli.Users

	for _, reviewer := range reviewers {
		var permOP int
		if updateInfo.DeletePermReviewerType != nil && reviewer.ReviewerType == *updateInfo.DeletePermReviewerType {
			permOP = _const.PermissionDelete
		} else if updateInfo.WritePermReviewerType != nil && reviewer.ReviewerType == *updateInfo.WritePermReviewerType {
			permOP = _const.PermissionWrite
		}

		if permOP == 0 {
			continue
		}

		user := &filecli.User{
			FileId:     updateInfo.FileID,
			Uid:        reviewer.ReviewerID,
			Email:      reviewer.Reviewer,
			Permission: permOP,
		}

		users = append(users, user)
	}

	return &filecli.UpdateUserPermissionReq{
		Users: users,
	}
}

// getReviewerFromPreContractReviewerList 查找指定reviewerType的审批人列表
func (h *handlerCommon) getReviewerFromPreContractReviewerList(list bizmodels.PreContractReviewerList, reviewerType int) []string {
	reviewers := make([]string, 0)
	existMap := map[string]bool{}
	for _, reviewer := range list {
		if reviewer.ReviewerType == reviewerType {
			if existMap[reviewer.Reviewer] {
				continue
			}
			reviewers = append(reviewers, reviewer.Reviewer)
			existMap[reviewer.Reviewer] = true
		}
	}
	return reviewers
}

// getReviewerFromPreContractReviewerListWithContractStatus 查找指定reviewerType、审核状态的审批人列表
func (h *handlerCommon) getReviewerFromPreContractReviewerListWithContractStatus(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) []string {
	reviewers := make([]string, 0)
	existMap := map[string]bool{}
	for _, reviewer := range list {
		if reviewer.ReviewerSource != 0 {
			// 该方法调用节点全部是在当前节点处理完毕后，即将进入到下一个节点时处理。
			// 理论上，进入新节点时，新节点中历史的加签人都会被软删，不会生效
			continue
		}
		if reviewer.ReviewerType == reviewerType && reviewer.ContractStatus == contractStatus {
			if existMap[reviewer.Reviewer] {
				continue
			}
			reviewers = append(reviewers, reviewer.Reviewer)
			existMap[reviewer.Reviewer] = true
		}
	}
	return reviewers
}

// getUnReviewedReviewerWithContractStatusAndBelowPriority 查找指定reviewerType、审核状态、优先级的审批人列表
func (h *handlerCommon) getUnReviewedReviewerWithContractStatusAndBelowPriority(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int) []string {
	var (
		resPriority int
		reviewerMap = map[int][]string{}
	)
	// 构建各优先级未审核通过审核人 MAP
	for _, reviewer := range list {
		if reviewer.ReviewerType == reviewerType &&
			reviewer.ContractStatus == contractStatus &&
			reviewer.Status != _const.ReviewStatusReviewPass {
			if reviewer.Priority > resPriority {
				resPriority = reviewer.Priority
			}
			reviewerMap[reviewer.Priority] = append(reviewerMap[reviewer.Priority], reviewer.Reviewer)
		}
	}
	// 返回最高优先级审核人列表
	return reviewerMap[resPriority]
}

// commonValidateUpdateReviewers 加签、转办校验
func (h *handlerCommon) commonValidateUpdateReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	if len(pc.Extra) == 0 {
		return errorsV2.ErrCommon.WithArgs("人员不可为空")
	}

	allReviewers, err := perm.GetAllReviewersByType(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, pc.ReviewerStatusOpConf.ReviewerType, pc.ContractInfo.CooperationStatus)
	if err != nil {
		return err
	}

	// 求交集 existReviewers & reviewers

	m := map[string]*model.PreContractReviewerDB{}
	for _, v := range allReviewers {
		m[v.Reviewer] = v
	}

	// 查询已有审批人员
	newReviewers := strings.Split(pc.Extra, ",")
	var existReviewers []string
	for _, v := range newReviewers {
		if oldV, exist := m[v]; exist {
			if oldV.Status != _const.ReviewStatusReviewPass {
				existReviewers = append(existReviewers, v)
			}
		}
	}

	if len(existReviewers) > 0 {
		return errorsV2.ErrCommon.WithArgs("%s已是审核人员", strings.Join(existReviewers, ","))
	}

	return nil
}

// commonPostProcessUpdateReviewers 更新审批人员，加签转办
func (h *handlerCommon) commonPostProcessUpdateReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 计算当前节点审核人
	currentReviewer := pc.GetCurrentReviewer()
	// 查询加签、转办人员信息
	newReviewers, err := larkc.GetEmployeeByMailsWithCache(ctx, strings.Split(pc.Extra, ","))
	if err != nil {
		logs.CtxError(ctx, "GetEmployeeByMailsFail, emails:%s, err:%s", pc.Extra, err.Error())
		return err
	}

	for _, reviewer := range newReviewers {
		if pc.OperationState == _const.OperationAddReviewer {
			// 加签
			if err = h.countersignReviewer(ctx, pc, currentReviewer, reviewer); err != nil {
				return err
			}
		} else if pc.OperationState == _const.OperationChangeReviewer {
			// 转办
			if err = h.changeReviewer(ctx, pc, reviewer); err != nil {
				return err
			}
		}
	}

	// 转办
	if pc.OperationState == _const.OperationChangeReviewer {
		// 将被转办人员从审批列表中删除
		err = dal.NewPreContractReviewerDao().DeleteChangedReviewer(ctx, pc.GetTx(), pc.CurrentOperator, pc.PreContractNo)
		if err != nil {
			logs.CtxError(ctx, "DeleteChangedReviewerFail, err:%s", err.Error())
		}
	}

	logs.CtxInfo(ctx, "prepare_send_msg, emails: %s", pc.Extra)
	// 发送飞书消息
	multiCtx := context.Background()
	if pc.OperationState == _const.OperationAddReviewer {
		larkc.BatchSendMessageToEmailIgnore(ctx,
			strings.Split(pc.Extra, ","),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核加签提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 加签 %s 参与合同审核，请尽快前往后台进行审核",
					larkc.LarkMdAtEmail(pc.CurrentOperator),
					strings.Join(utils.StringListFormat(strings.Split(pc.Extra, ","), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddField(multienv.I18nFormat(multiCtx, "业务执行人"), strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), "")).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	} else if pc.OperationState == _const.OperationChangeReviewer {
		larkc.BatchSendMessageToEmailIgnore(ctx,
			strings.Split(pc.Extra, ","),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核转办提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 将合同审核转办给了 %s，请尽快前往后台进行审核",
					larkc.LarkMdAtEmail(pc.CurrentOperator),
					strings.Join(utils.StringListFormat(strings.Split(pc.Extra, ","), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddField(multienv.I18nFormat(multiCtx, "业务执行人"), strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), "")).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	} else {
		larkc.BatchSendMessageToEmailIgnore(ctx,
			strings.Split(pc.Extra, ","),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
	}
	return nil
}

// sendBackNotifyTargetReviewers 退回时根据目标节点通知对应审批人。
func (h *handlerCommon) sendBackNotifyTargetReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) {
	if pc == nil || pc.ContractInfo == nil || pc.ReviewerStatusOpConf == nil || !pc.StatusChanged || pc.StatusChangedValue == 0 {
		return
	}
	if pc.OperationState != _const.OperationSendBack && pc.OperationState != _const.OperationSendBackSkipApproval && pc.OperationState != _const.OperationSendBackWithTemplate {
		return
	}
	tpl, ok := getSendBackNotifyTemplate(pc.StatusChangedValue)
	if !ok {
		logs.CtxInfo(ctx, "SendBackNotifyTargetReviewers skip unsupported target status, contractNo=%s, status=%d", pc.ContractInfo.ContractNo, pc.StatusChangedValue)
		return
	}

	reviewerType := GetReviewerTypeByCooperationStatus(pc.StatusChangedValue)
	reviewers := h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, reviewerType, pc.StatusChangedValue)
	if len(reviewers) == 0 {
		logs.CtxInfo(ctx, "SendBackNotifyTargetReviewers skip empty reviewers, contractNo=%s, status=%d, reviewerType=%d", pc.ContractInfo.ContractNo, pc.StatusChangedValue, reviewerType)
		return
	}

	multiCtx := context.Background()
	builder := larkc.NewCommonMessageCardBuilder().
		SetTitleColor(larkc.TitleColorWathet).
		SetTitle(multienv.I18nFormat(multiCtx, tpl.title)).
		SetContent(i18nfmt.Sprintf(multiCtx, tpl.content,
			strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""),
			larkc.LarkMdAtEmail(pc.CurrentOperator),
			h.getSendBackReason(pc))).
		AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
		AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
		AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName)
	if tpl.appendUrgentInfo {
		builder.AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo)
	}
	larkc.BatchSendMessageToEmailIgnore(ctx,
		reviewers,
		larkc.MsgTypeInteractive,
		builder.AddAction(multienv.I18nFormat(multiCtx, tpl.actionText), h.getSendBackTargetActionURL(ctx, pc)).
			BuildJSONString())
}

func getSendBackNotifyTemplate(targetStatus int) (struct {
	title            string
	content          string
	actionText       string
	appendUrgentInfo bool
}, bool) {
	type sendBackNotifyTemplate struct {
		title            string
		content          string
		actionText       string
		appendUrgentInfo bool
	}

	switch targetStatus {
	case _const.PreSalesContractSendBack:
		return sendBackNotifyTemplate{
			title:      "合同审核提醒",
			content:    "%s 提交的合同在线协同已被退回，如有需要，请您重新提交。\n退回操作人：%s\n退回原因：%s",
			actionText: "查看详情",
		}, true
	case _const.PreSalesContractCustomerConfirm:
		return sendBackNotifyTemplate{
			title:      "合同退回提醒",
			content:    "%s 提交的合同在线协同被审核退回，请您重新确认合同内容。\n退回操作人：%s\n退回原因：%s",
			actionText: "查看详情",
		}, true
	case _const.PreSalesContractSalesOperationCompleteInformation:
		return sendBackNotifyTemplate{
			title:            "合同退回提醒",
			content:          "%s 提交的合同在线协同被审核退回，待您重新完善信息，请您及时前往后台进行完善。\n退回操作人：%s\n退回原因：%s",
			actionText:       "查看详情",
			appendUrgentInfo: true,
		}, true
	case _const.PreSalesContractSalesOperationReview, _const.PreSalesContractFinanceTaxationLegalReview, _const.PreSalesContractSolutionReview:
		return sendBackNotifyTemplate{
			title:            "合同退回提醒",
			content:          "%s 提交的合同在线协同被审核退回，请您重新审核。\n退回操作人：%s\n退回原因：%s",
			actionText:       "去审核",
			appendUrgentInfo: true,
		}, true
	case _const.PreSalesContractFinanceTaxationLegalSignReview:
		return sendBackNotifyTemplate{
			title:            "合同退回提醒",
			content:          "%s 提交的合同在线协同被审核退回，待您重新进行签约审核，请尽快前往后台进行审核。\n退回操作人：%s\n退回原因：%s",
			actionText:       "去审核",
			appendUrgentInfo: true,
		}, true
	default:
		return sendBackNotifyTemplate{}, false
	}
}

// SendBackNotifyPeerReviewers 退回时通知当前节点除操作人外的其他审批人。
func (h *handlerCommon) SendBackNotifyPeerReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) {
	if pc == nil || pc.ContractInfo == nil || pc.ReviewerStatusOpConf == nil || !pc.StatusChanged || pc.StatusChangedValue == 0 {
		return
	}
	if pc.OperationState != _const.OperationSendBack && pc.OperationState != _const.OperationSendBackSkipApproval && pc.OperationState != _const.OperationSendBackWithTemplate {
		return
	}

	reviewers := h.getSendBackPeerReviewers(pc.ContractInfo.Reviewers, pc.ReviewerStatusOpConf.ReviewerType, pc.ContractInfo.CooperationStatus, pc.CurrentOperator)
	if len(reviewers) == 0 {
		return
	}

	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		reviewers,
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同退回提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "合同%s已被%s操作退回至%s", pc.ContractInfo.ContractNo, larkc.LarkMdAtEmail(pc.CurrentOperator), multienv.GenStatusDescForNodeDisplay(multiCtx, pc.StatusChangedValue))).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddField(multienv.I18nFormat(multiCtx, "业务执行人"), strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), "")).
			AddField(multienv.I18nFormat(multiCtx, "退回原因"), h.getSendBackReason(pc)).
			AddAction(multienv.I18nFormat(multiCtx, "查看详情"), larkc.GenDetailURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
}

func (h *handlerCommon) getSendBackPeerReviewers(list bizmodels.PreContractReviewerList, reviewerType int, contractStatus int, currentOperator string) []string {
	allReviewers := make([]string, 0)
	peerReviewers := make([]string, 0)
	existMap := map[string]bool{}
	for _, reviewer := range list {
		if reviewer == nil || reviewer.IsDeleted != 0 || reviewer.ReviewerType != reviewerType || reviewer.ContractStatus != contractStatus || reviewer.Reviewer == "" {
			continue
		}
		if existMap[reviewer.Reviewer] {
			continue
		}
		existMap[reviewer.Reviewer] = true
		allReviewers = append(allReviewers, reviewer.Reviewer)
		if !strings.EqualFold(reviewer.Reviewer, currentOperator) {
			peerReviewers = append(peerReviewers, reviewer.Reviewer)
		}
	}
	if len(allReviewers) <= 1 {
		return nil
	}
	return peerReviewers
}

func (h *handlerCommon) getSendBackReason(pc *auditmodel.ProcessCtx) string {
	if pc == nil {
		return ""
	}
	if pc.Comment != nil && pc.Comment.RichtextPlainText != "" {
		return pc.Comment.RichtextPlainText
	}
	return pc.Remark
}

func (h *handlerCommon) getSendBackTargetActionURL(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	if pc == nil || pc.ContractInfo == nil {
		return ""
	}
	contractNo := pc.ContractInfo.ContractNo
	if utils.IntIn(pc.StatusChangedValue, _const.CRMChangeableCooperationStatusList) {
		return larkc.GenCRMDetailURL(ctx, contractNo)
	}
	if pc.StatusChangedValue == _const.PreSalesContractSalesOperationCompleteInformation {
		return larkc.GenEditURL(ctx, contractNo)
	}
	return larkc.GenReviewURL(ctx, contractNo)
}

func (h *handlerCommon) countersignReviewer(ctx context.Context, pc *auditmodel.ProcessCtx, curReviewer *bizmodels.PreContractReviewer, reviewer *peopleclient.Employee) error {

	var (
		// 并加签审核人权限等级与当前审核人权限等级一致，审核人来源为并加签审核人
		countersignPriority = curReviewer.Priority
		reviewerSource      = _const.ReviewGradeStandApostilleReviewers
	)
	// 前加签审核人权限等级与当前审核人权限等级+1，审核人来源为前加签审核人
	if pc.SecondaryOperationType == _const.SecondaryOperationTypePreApostille {
		reviewerSource = _const.ReviewGradePreApostilleReviewers
		countersignPriority = curReviewer.Priority + 1
	}

	existsReviewer, err := h.matchExistsReviewer(ctx, pc, curReviewer, reviewer)
	if err != nil {
		return err
	}
	if existsReviewer != nil {
		logs.CtxInfo(ctx, "countersignReviewer, update old reviewer")
		targetReviewerRole := _const.InheritReviewerRole(_const.ReviewerRoleCountersign, existsReviewer.ReviewerRole)
		updates := map[string]interface{}{
			"status":             _const.ReviewStatusUnreviewed,
			"priority":           countersignPriority,
			"reviewer_role":      targetReviewerRole,
			"skip_return_review": 0,
		}
		return dal.NewPreContractReviewerDao().UpdateByID(ctx, pc.GetTx(), existsReviewer.Id, updates)
	}

	// 加签
	reviewerDB := &model.PreContractReviewerDB{
		PreContractNo:  pc.ContractInfo.ContractNo,
		Reviewer:       reviewer.Email,
		ReviewerID:     strconv.Itoa(reviewer.ID),
		ReviewerType:   curReviewer.ReviewerType,
		ContractStatus: curReviewer.ContractStatus,
		Department:     pc.ContractInfo.BasicInfo.DepartmentId,
		ReviewerRole:   _const.ReviewerRoleCountersign,
		ReviewerSource: reviewerSource,
		Priority:       countersignPriority,
	}

	if err = dal.CreatePreContractReviewer(ctx, pc.GetTx(), reviewerDB); err != nil {
		// 仅日志
		logs.CtxError(ctx, "createContractReviewerFail, no:%s, reviewer:%s err:%s", reviewerDB.PreContractNo, reviewerDB.Reviewer, err.Error())
		return err
	}
	return nil
}

// 若加签人是已经存在的
func (h *handlerCommon) matchExistsReviewer(ctx context.Context, pc *auditmodel.ProcessCtx, curReviewer *bizmodels.PreContractReviewer, reviewer *peopleclient.Employee) (*model.PreContractReviewerDB, error) {
	reviewerDBList, err := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, pc.GetTx(), pc.ContractInfo.ContractNo)
	if err != nil {
		return nil, err
	}
	for _, v := range reviewerDBList {
		if v.ContractStatus == curReviewer.ContractStatus &&
			v.ReviewerType == curReviewer.ReviewerType &&
			v.Reviewer == reviewer.Email {
			return v, nil
		}
	}
	return nil, nil
}

// changeReviewer 转办
func (h *handlerCommon) changeReviewer(ctx context.Context, pc *auditmodel.ProcessCtx, newReviewer *peopleclient.Employee) error {

	preContractNo := pc.ContractInfo.ContractNo

	list, err := dal.NewPreContractReviewerDao().FindReviewersByNoAndEmail(ctx, pc.GetTx(), preContractNo, pc.CurrentOperator)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoAndEmailFail, email:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}

	if len(list) == 0 {
		return nil
	}

	newReviewerCurList, err := dal.NewPreContractReviewerDao().FindReviewersByNoAndEmail(ctx, pc.GetTx(), preContractNo, newReviewer.Email)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoAndEmailFail, email:%s, err:%s", newReviewer.Email, err.Error())
		return err
	}

	newReviewerCurMap := map[string]*model.PreContractReviewerDB{}
	for _, v := range newReviewerCurList {
		key := i18nfmt.Sprintf(ctx, "%s_%d_%d", v.PreContractNo, v.ReviewerType, v.ContractStatus)
		newReviewerCurMap[key] = v
	}

	for _, v := range list {
		// 忽略被艾特角色 仅关注审批角色
		if v.ReviewerType == _const.ReviewerTypeMentioned {
			continue
		}
		// 查询当前用户是否已具备相同角色  reviewer+reviewer_type+pre_contract_no+contract_status
		key := i18nfmt.Sprintf(ctx, "%s_%d_%d", v.PreContractNo, v.ReviewerType, v.ContractStatus)
		newUserInfo, _ := newReviewerCurMap[key]
		if newUserInfo == nil {
			reviewerDB := &model.PreContractReviewerDB{
				PreContractNo:  preContractNo,
				Reviewer:       newReviewer.Email,
				ReviewerID:     strconv.Itoa(newReviewer.ID),
				ReviewerType:   v.ReviewerType,
				ContractStatus: v.ContractStatus,
				Department:     pc.ContractInfo.BasicInfo.DepartmentId,
				ReviewerRole:   v.ReviewerRole,
				ReviewerSource: v.ReviewerSource,
				Priority:       v.Priority,
			}
			err = dal.NewPreContractReviewerDao().Create(ctx, pc.GetTx(), reviewerDB)
			if err != nil {
				logs.CtxError(ctx, "CreateReviewerFail, err:%s", err.Error())
				return err
			}
		} else {
			logs.CtxInfo(ctx, "countersignReviewer, update old reviewer")
			targetReviewerRole := _const.InheritReviewerRole(v.ReviewerRole, newUserInfo.ReviewerRole)
			updates := map[string]interface{}{
				"status":             _const.ReviewStatusUnreviewed,
				"skip_return_review": 0,
			}
			if targetReviewerRole != newUserInfo.ReviewerRole {
				updates["reviewer_role"] = targetReviewerRole
				newUserInfo.ReviewerRole = targetReviewerRole
			}
			return dal.NewPreContractReviewerDao().UpdateByID(ctx, pc.GetTx(), newUserInfo.Id, updates)
		}
	}

	return nil
}

// commonCheckHitContractStatusChange 判断当前审批节点下，所有审批操作是否都已完成
func (h *handlerCommon) commonCheckHitContractStatusChange(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	// 判断当前审批节点下，所有审批操作是否都已完成
	allReviewerTypePassed, err := dal.IsAllReviewerTypePassed(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, pc.ReviewerStatusOpConf.ReviewerType, pc.ContractInfo.CooperationStatus)
	if err != nil {
		return false, i18nfmt.New(ctx, "检查节点审批结果失败")
	}
	return allReviewerTypePassed, nil
}

// commonCheckHitMasterReviewerPass 判断当前审批节点下，除住审核人外，所有审批操作是否都已完成
func (h *handlerCommon) commonCheckHitMasterReviewerPass(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	// 判断当前审批节点下，所有审批操作是否都已完成
	allNoMasterReviewerTypePassed, err := dal.IsAllNoMasterReviewerTypePassed(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, pc.ReviewerStatusOpConf.ReviewerType, pc.ContractInfo.CooperationStatus)
	if err != nil {
		return false, i18nfmt.New(ctx, "检查节点审批结果失败")
	}
	return allNoMasterReviewerTypePassed, nil
}

// commonCheckReviewerPass 判断当前审批节点下，除住审核人外，所有审批操作是否都已完成
func (h *handlerCommon) commonCheckReviewerPass(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	var reviewerList []string
	currentReviewer := pc.GetCurrentReviewer()
	// 判断当前审批节点下，所有审批操作是否都已完成
	noPassReviewers, err := dal.ListHighPriorityReviewerTypeNoPassedReviewer(ctx, pc.GetTx(), &model.ListPreContractReviewerReq{
		PreContractNo:  pc.ContractInfo.ContractNo,
		ReviewerType:   currentReviewer.ReviewerType,
		ContractStatus: currentReviewer.ContractStatus,
		Priority:       currentReviewer.Priority,
	})
	if err != nil {
		return i18nfmt.New(ctx, "检查节点审批结果失败")
	}
	if len(noPassReviewers) == 0 {
		return nil
	}
	for _, v := range noPassReviewers {
		reviewerList = append(reviewerList, v.Reviewer)
	}
	errMsg := i18nfmt.Sprintf(ctx, "存在前置审批人未审批通过，请等待前加签审批人审核通过后再操作。前置待审核人：%s", strings.Join(reviewerList, "、"))
	logs.CtxInfo(ctx, errMsg)
	return fmt.Errorf(errMsg)
}

func (h *handlerCommon) reviewPassSendReviewedMessage(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	currentReviewer := pc.GetCurrentReviewer()
	// 获取当前操作人审核优先级的未审核通过审核人
	list, err := dal.ListNotPassedReviewerByPriority(ctx, pc.GetTx(), &model.ListPreContractReviewerReq{
		PreContractNo:  pc.ContractInfo.ContractNo,
		ReviewerType:   currentReviewer.ReviewerType,
		ContractStatus: currentReviewer.ContractStatus,
		Priority:       currentReviewer.Priority,
	})
	if err != nil {
		return err
	}
	// 若存在未审核通过审核人，不发送待审核消息
	if len(list) > 0 {
		logs.CtxInfo(ctx, "【%s】存在未审核通过的同优先级审核人，不发送待审核消息", pc.ContractInfo.PreContractNo)
		return nil
	}
	reviewers, err := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, pc.GetTx(), pc.ContractInfo.ContractNo)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoFail, err:%s", err.Error())
		return err
	}
	// 给下一优先级的审核人发送飞书消息
	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		h.getUnReviewedReviewerWithContractStatusAndBelowPriority(reviewers.GenResp(), currentReviewer.ReviewerType, currentReviewer.ContractStatus),
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
	return nil
}

func (h *handlerCommon) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	return _const.ApprovalStatusKeyDefault
}

func (h *handlerCommon) SubmitComplianceCheck(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "SubmitComplianceCheck, PreContractNo:%s", pc.PreContractVO.ContractNo)
	// 提交合规审查
	res, err := riskengineservice.NewRiskEngineService().SubmitComplianceCheck(ctx, pc.PreContractVO)
	if err != nil {
		logs.CtxWarn(ctx, "SubmitComplianceCheckFail, err:%v", err)
		return err
	}
	// 保存合规审查信息至合同附加信息
	h.calcComplianceCheckInfo(ctx, pc, res)
	// 保存在上下文中，用于后续流程处理
	pc.ComplianceCheckInfo = res
	return nil
}

func (h *handlerCommon) calcComplianceCheckInfo(ctx context.Context, pc *auditmodel.ProcessCtx, resp *riskenginecli.RiskEngineResp) {
	var complianceResult bizmodels.ComplianceCheckResult
	if pc.Ext == nil {
		pc.Ext = make(map[string]string)
	}
	// 优先查询当前合同关联的合规审查信息
	info, ok := pc.ContractInfo.Ext[_const.ExtKeyComplianceCheckInfo]
	if ok {
		// 若当前合同存在合规审查信息，以当前合同关联数据为准
		_ = json.Unmarshal([]byte(info), &complianceResult)
	}
	body, _ := json.Marshal(resp)
	complianceResult.AutoCheckResult = string(body)
	complianceResultJson, _ := json.Marshal(complianceResult)
	pc.Ext[_const.ExtKeyComplianceCheckInfo] = string(complianceResultJson)
}

// updateContractData 更新合同数据
func (h *handlerCommon) updateContractData(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	logs.CtxInfo(ctx, "updateCreator => %s", pc.PreContractVO.Creator)
	// 每次更新默认重新生成一次合同文本、若使用了模板
	fileId, err := GetTemplateFileId(ctx, pc)
	if err != nil {
		logs.CtxError(ctx, "GetTemplateFileIdFail, err:%v", err)
		return err
	}
	logs.CtxInfo(ctx, "GetTemplateFileId, fileId:%s", fileId)
	// 处理原合同文本
	pc.PreContractVO.ContractFile = fileId
	pc.ContractInfo.ContractFile = fileId
	if err := h.CreateOrUpdateAttachment(ctx, pc.GetTx(), pc.PreContractVO.ContractNo, fileId); err != nil {
		return err
	}
	if err := h.updatePreContract(ctx, pc.GetTx(), pc.PreContractVO); err != nil {
		return err
	}
	if err := h.SaveManageInfo(ctx, pc.GetTx(), pc.ContractInfo.ManageInfo, pc.PreContractVO); err != nil {
		return err
	}
	if err := h.SaveTradePartyInfo(ctx, pc.GetTx(), pc.ContractInfo.TradePartyInfo, pc.PreContractVO); err != nil {
		return err
	}
	if err := h.SaveMetaExt(ctx, pc.GetTx(), pc.DelExtKeys, pc.Ext, pc.PreContractVO); err != nil {
		return err
	}
	if err := h.updateContractSettlement(ctx, pc.GetTx(), pc.PreContractVO, pc.ContractInfo.SettlementInfo); err != nil {
		return err
	}
	if err := h.updateBusinessModeClauses(ctx, pc.GetTx(), pc.PreContractVO, pc.ContractInfo.BusinessModeClauses, pc.CurrentOperator); err != nil {
		return err
	}
	if err := h.updateAttachment(ctx, pc.GetTx(), pc.PreContractVO.ContractNo, pc.AttachmentUpdateList); err != nil {
		return err
	}
	return nil
}

// CreateOrUpdateAttachment 更新合同附件
func (h *handlerCommon) CreateOrUpdateAttachment(ctx context.Context, tx *gorm.DB, contractNo, fileID string) error {
	// 插入 contractAttachment 表
	attachment, err := dal.NewContractAttachmentDao().FindByFileKey(ctx, tx, fileID)
	if err != nil {
		logs.CtxError(ctx, "FindAttachmentByFileKeyFail, fileKey:%s, err:%v", fileID, err)
		return err
	}
	fileName := "合同文本"
	resp, err := filecli.GetNewestVersion(ctx, &filecli.GetNewestVersionReq{
		FileID: fileID,
	})
	if err != nil || resp == nil {
		logs.CtxWarn(ctx, "fileId:%s, 查询文件信息失败，合同名称使用兜底名称", fileID)
	} else {
		fileName = resp.Result.Name
	}
	// 非空更新合同号 下载Key 附加信息
	if attachment == nil {
		attach := &bizmodels.MetaAttachment{
			DownloadID:  fileID,
			StorageType: _const.ContractAttachmentStorageFileManage,
			FileName:    fileName,
		}
		body, _ := json.Marshal(attach)
		attachmentDB := &model.ContractAttachmentDB{
			ContractNo:  contractNo,
			FileKey:     attach.DownloadID,
			Name:        attach.FileName,
			StorageType: attach.StorageType,
			BizType:     _const.ContractAttachmentTypeFile,
			Extra:       string(body),
		}
		err = dal.NewContractAttachmentDao().Create(ctx, tx, attachmentDB)
	} else {
		attachment.ContractNo = contractNo
		attachment.Name = fileName
		err = dal.NewContractAttachmentDao().Update(ctx, tx, attachment)
	}
	if err != nil {
		logs.CtxError(ctx, "CreateContractAttachmentFail, err:%v", err)
		return err
	}
	return nil
}

// updateContractSettlement 更新contract_settlement表
func (h *handlerCommon) updateContractSettlement(ctx context.Context, tx *gorm.DB,
	entity *model.ContractMetaDB, settlementLines *bizmodels.SettlementInfo) error {
	logs.CtxInfo(ctx, "updateContractSettlement Start")

	err := dal.NewContractSettlementDao().SoftDeleteByContractID(ctx, tx, int(entity.Id))
	if err != nil {
		return err
	}

	var settlementDBs []*model.ContractSettlementDB
	for _, settlement := range settlementLines.SettlementLines {
		settlementDB, err := model.GenSettlementDBFromSettlementInfo(entity, settlement)
		if err != nil {
			return err
		}
		settlementDBs = append(settlementDBs, settlementDB)
	}

	return dal.NewContractSettlementDao().BatchCreate(ctx, tx, settlementDBs)

}

// updateBusinessModeClauses 更新商务模式条款摘要表
func (h *handlerCommon) updateBusinessModeClauses(ctx context.Context, tx *gorm.DB,
	entity *model.ContractMetaDB, clauses []*bizmodels.BusinessModeClause, operator string) error {
	logs.CtxInfo(ctx, "updateBusinessModeClauses Start")
	return businessmodeclause.NewService().SaveBusinessModeClauses(ctx, tx, entity, clauses, operator)
}

func (h *handlerCommon) validateRequiredBusinessModeClauses(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc == nil || pc.ContractInfo == nil {
		return nil
	}
	return businessmodeclause.NewService().ValidateRequiredBusinessModeClauses(ctx, pc.GetTx(), pc.ContractInfo, pc.ContractInfo.BusinessModeClauses)
}

// updatePreContract 更新pre_contract表
func (h *handlerCommon) updatePreContract(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error {

	logs.CtxInfo(ctx, "updateCreator => %s", entity.Creator)

	updates := map[string]interface{}{}
	// todo： 后面需要明确前段传值
	if entity.MainContractNo != "" {
		updates["main_contract_no"] = entity.MainContractNo
	}
	if entity.FromContractNo != "" {
		updates["from_contract_no"] = entity.FromContractNo
	}
	if entity.VolcContractNo != "" {
		updates["volc_contract_no"] = entity.VolcContractNo
	}
	if !entity.FromContractTerminatedTime.IsZero() {
		updates["from_contract_terminated_time"] = entity.FromContractTerminatedTime
	}
	if entity.SupplyScene != 0 {
		updates["supply_scene"] = entity.SupplyScene
	}
	if len(entity.SupplySource) > 0 {
		updates["supply_source"] = entity.SupplySource
	}
	updates["contract_name"] = entity.ContractName
	updates["subject_name"] = entity.SubjectName
	updates["other_party_name"] = entity.OtherPartyName
	updates["operator"] = entity.Operator
	updates["operator_new"] = entity.OperatorNew
	updates["creator"] = entity.Creator        // 新增
	updates["creator_new"] = entity.CreatorNew // 新增
	updates["property_code"] = entity.PropertyCode
	updates["category_no"] = entity.CategoryNo
	updates["signature_type"] = entity.SignatureType
	updates["in_out_type"] = entity.InOutType
	updates["subject_account_ids"] = entity.SubjectAccountIds
	updates["begin_time"] = entity.BeginTime
	updates["end_time"] = entity.EndTime
	updates["submit_time"] = entity.SubmitTime
	updates["basic_info"] = entity.BasicInfo
	updates["project_info"] = entity.ProjectInfo
	// updates["manage_info"] = entity.ManageInfo
	updates["trade_party_info"] = entity.TradePartyInfo
	// updates["settlement_info"] = entity.SettlementInfo

	updates["settlement_clause"] = entity.SettlementClause
	updates["is_contain_refund_clause"] = entity.IsContainRefundClause

	updates["contract_product_info"] = entity.ContractProductInfo
	updates["contract_attachment"] = entity.ContractAttachment
	updates["is_backdating"] = entity.IsBackdating
	updates["reverse_sign_info"] = entity.ReverseSignInfo
	updates["relate_quote_no"] = entity.RelateQuoteNo
	updates["relate_quote_scene"] = entity.RelateQuoteScene
	updates["special_contract_type"] = entity.SpecialContractType
	// 更新模板信息
	updates["template_info"] = entity.TemplateInfo
	if len(entity.ContractFile) > 0 {
		updates["contract_file"] = entity.ContractFile
	}

	return dal.NewContractMetaDao().UpdateFieldsByNo(ctx, tx, entity.ContractNo, updates)
}

// buildProductLineForceUpdates 构造一二级产品线的强制覆盖字段，用于支持在线协同显式清空产品线。
//
// AllFieldUpdate 对这两列的默认语义是空值不覆盖，因此清空必须依赖强制覆盖。但 ManageInfo 的字段是值类型，
// 「未传该字段」与「显式传空串」反序列化后都是空串、无法区分，无条件强制覆盖会让任何漏传入参的调用方
// 清空存量数据。
//
// 关联报价单的合同，这两列由报价单派生而来（BuildManageInfoByQuote），不应被入参空值覆盖；清空产品线
// 只针对无报价单场景。故仅在合同不关联报价单时才强制覆盖，其余情况回落到 AllFieldUpdate 的合并语义。
//
// metaDB.RelateQuoteNo 的时点语义按链路区分：CreateOrUpdate 链路已由 fillEntity 覆盖为本次入参值，
// 因此本次解绑报价单的合同会被判定为无报价单、允许清空；OperatePreContract 链路无该入参，取数据库现值，
// 且该链路的 ManageInfo 同样取自数据库，强制覆盖是幂等的。
func buildProductLineForceUpdates(ctx context.Context, manageInfo *bizmodels.ManageInfo, metaDB *model.ContractMetaDB) map[string]interface{} {
	if metaDB.RelateQuoteNo != "" {
		logs.CtxInfo(ctx, "SaveManageInfo_skipProductLineForceUpdate, contractNo:%s, relateQuoteNo:%s", metaDB.ContractNo, metaDB.RelateQuoteNo)
		return nil
	}
	// 无报价单场景允许清空，但入参漏传与显式清空无法区分；打点便于线上观测是否存在调用方漏传。
	if manageInfo.BelongingDepartment == "" || manageInfo.ProductLine == "" {
		logs.CtxWarn(ctx, "SaveManageInfo_clearProductLine, contractNo:%s, belongingDepartment:%q, productLine:%q",
			metaDB.ContractNo, manageInfo.BelongingDepartment, manageInfo.ProductLine)
	}
	return map[string]interface{}{
		"belonging_department": manageInfo.BelongingDepartment,
		"product_line":         manageInfo.ProductLine,
	}
}

// SaveManageInfo 保存管理信息
func (h *handlerCommon) SaveManageInfo(ctx context.Context, tx *gorm.DB, manageInfo *bizmodels.ManageInfo, metaDB *model.ContractMetaDB) errorsV2.APIError {
	// 更新manage_info主表
	if manageInfo == nil || metaDB == nil {
		return errorsV2.ErrInternalError.WithArgs("保存管理信息失败，入参异常")
	}
	newManageDB, commodityList, externalCommodityList := BuildManageAndCommodity(metaDB.ContractNo, metaDB.Version, metaDB.Id, manageInfo)

	manageDao := dal.NewContractManageDao()
	manageDB, err := manageDao.FindByVolcContractId(ctx, tx, int64(metaDB.Id))
	if err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, FindByNoFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
		return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
	}
	if manageDB != nil {
		// 更新
		manageDB.AllFieldUpdate(newManageDB, buildProductLineForceUpdates(ctx, manageInfo, metaDB))
		if err = manageDao.Update(ctx, tx, manageDB); err != nil {
			logs.CtxError(ctx, "SaveManageInfoFail, UpdateManageFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
			return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
		}
	} else {
		// 新建
		if err = manageDao.Create(ctx, tx, newManageDB); err != nil {
			logs.CtxError(ctx, "SaveManageInfoFail, CreateManageFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
			return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
		}
	}

	update := map[string]interface{}{
		"related_personnel": manageInfo.RelatedPersonnel,
		"product":           "",
	}

	err = SaveCommodityList(ctx, tx, metaDB, commodityList, update)
	if err != nil {
		return errorsV2.ErrInternalError.WithArgs("SaveCommodityListFail")
	}

	err = dal.NewContractMetaDao().UpdateByMap(ctx, tx, int64(metaDB.Id), update)
	if err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, UpdateContractMetaFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
		return errorsV2.ErrInternalError.WithArgs("UpdateContractMetaFail")
	}

	err = SaveExternalCommodityList(ctx, tx, metaDB, externalCommodityList)
	if err != nil {
		return errorsV2.ErrInternalError.WithArgs("SaveExternalCommodityListFail")
	}

	return nil
}

// SaveTradePartyInfo 保存交易方信息
func (h *handlerCommon) SaveTradePartyInfo(ctx context.Context, tx *gorm.DB, tradePartyInfo *bizmodels.TradePartyInfo, metaDB *model.ContractMetaDB) errorsV2.APIError {
	logs.CtxInfo(ctx, "SaveMetaTradePartyInfo, contractId:%s", metaDB.Id)
	if tradePartyInfo == nil {
		logs.CtxError(ctx, "SaveTradePartyInfoFail, TradePartyInfo is nil")
		return errorsV2.ErrInternalError.WithArgs("TradePartyInfo is nil")
	}
	tradePartytDao := dal.NewContractTradePartyDao()
	// 删除老数据
	if err := tradePartytDao.DeleteByVolcContractId(ctx, tx, int(metaDB.Id)); err != nil {
		logs.CtxError(ctx, "DeleteTradePartyByIdFail, contract_id=%s, err=%s", metaDB.Id, err.Error())
		return errorsV2.ErrInternalError.WithArgs("SaveTradePartyInfoFail")
	}
	// 拆分子条目
	partyList := model.ConverTradePartyDB(metaDB, tradePartyInfo)
	// 插入
	if saveErr := tradePartytDao.BatchCreate(ctx, tx, partyList); saveErr != nil {
		logs.CtxError(ctx, "SaveMetaTradePartyInfo_BatchCreateFail, TradePartyInfo=%s, err=%s", metaDB.TradePartyInfo, saveErr.Error())
		return errorsV2.ErrInternalError.WithArgs("SaveTradePartyInfoFail")
	}

	return nil
}

// SaveMetaExt 合同附加信息创建&更新方法 方法内不删除 在外部处理删除逻辑
func (h *handlerCommon) SaveMetaExt(ctx context.Context, tx *gorm.DB, delExtKeys []string, metaExtMap map[string]string, metaDB *model.ContractMetaDB) errorsV2.APIError {
	// 更新合同附加信息表
	if len(metaExtMap) == 0 {
		logs.CtxInfo(ctx, "metaExtMap is nil, continue.")
		return nil
	}
	for _, delKey := range delExtKeys {
		if err := h.DeleteMetaExt(ctx, tx, delKey, metaDB.Id); err != nil {
			logs.CtxError(ctx, "DeleteMetaExtFail, err:%v", err)
			return err
		}
	}
	for attrKey, attrValue := range metaExtMap {
		extNew := &model.ContractMetaExt{
			ContractId: metaDB.Id,
			AttrKey:    attrKey,
			AttrValue:  attrValue,
		}
		if err := h.CreateOrUpdateMetaExt(ctx, tx, extNew); err != nil {
			logs.CtxError(ctx, "CreateOrUpdateMetaExtFail, err:%v", err)
			return err
		}
	}

	return nil
}

// SaveProcessFileNestVersion 存储审核通过版本信息
func (h *handlerCommon) SaveProcessFileNestVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if !utils.IntIn(pc.OperationState, _const.ReviewPassOperationList) {
		logs.CtxInfo(ctx, "当前操作不符合审核通过条件，不执行存储最新版本逻辑。")
		return nil
	}

	var needNewest = false
	if pc.ApprovalKey == _const.ApprovalKeyCooperationQuote {
		needNewest = true
	}
	// 查询合同关联文件最新版本信息
	newestVersionMap, recordVersions, err := h.GenProcessFileNestVersion(ctx, pc, needNewest)
	if err != nil {
		logs.CtxError(ctx, "GenProcessFileNestVersionFail, err:%s", err.Error())
		return err
	}
	// 赋值到流程上下文中，用于后续流程节点使用
	pc.RecordVersions = recordVersions

	mapBody, marshalErr := json.Marshal(newestVersionMap)
	if marshalErr != nil {
		logs.CtxError(ctx, "MarshalFail, err:%s", marshalErr.Error())
		return marshalErr
	}
	extNew := &model.ContractMetaExt{
		ContractId: pc.PreContractVO.Id,
		AttrKey:    _const.ExtKeyProcessFileNewestVersion,
		AttrValue:  string(mapBody),
	}
	if err := h.CreateOrUpdateMetaExt(ctx, pc.GetTx(), extNew); err != nil {
		logs.CtxError(ctx, "CreateOrUpdateMetaExtFail, err:%v", err)
		return err
	}
	return nil
}

// SaveStatusChangeFileVersion 存储最近一次审核通过的文件版本信息
func (h *handlerCommon) SaveStatusChangeFileVersion(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	logs.CtxInfo(ctx, "SaveStatusChangeFileVersion, pc.OperationState:%d", pc.OperationState)
	// 查询合同关联文件最新版本信息
	newestVersionMap, _, err := h.GenProcessFileNestVersion(ctx, pc, true)
	if err != nil {
		logs.CtxError(ctx, "GenProcessFileNestVersionFail, err:%s", err.Error())
		return err
	}
	// 赋值到流程上下文中，用于后续流程节点使用
	// pc.RecordVersions = recordVersions

	mapBody, marshalErr := json.Marshal(newestVersionMap)
	if marshalErr != nil {
		logs.CtxError(ctx, "MarshalFail, err:%s", marshalErr.Error())
		return marshalErr
	}
	extNew := &model.ContractMetaExt{
		ContractId: pc.PreContractVO.Id,
		AttrKey:    _const.ExtKeyReviewPassNewestVersion,
		AttrValue:  string(mapBody),
	}
	if err := h.CreateOrUpdateMetaExt(ctx, pc.GetTx(), extNew); err != nil {
		logs.CtxError(ctx, "CreateOrUpdateMetaExtFail, err:%v", err)
		return err
	}
	return nil
}

func (h *handlerCommon) GenProcessFileNestVersion(ctx context.Context, pc *auditmodel.ProcessCtx, needNewest bool) (map[string]string, []*bizmodels.FileVersionData, errorsV2.APIError) {
	var (
		err              error
		recordVersions   []*bizmodels.FileVersionData
		newestVersionMap = map[string]string{}
		processFileInfo  = &metaattachmodels.GetProcessFileInfoResp{}
	)
	logs.CtxInfo(ctx, "GenProcessFileNestVersion, pc.OperationState:%d, needNewest:%v", pc.OperationState, needNewest)
	// 计算合同关联文件ID信息
	contractFileList := utils.SingleList(strings.Split(pc.ContractInfo.ContractFile, ","))
	contractAttachmentList := utils.SingleList(strings.Split(pc.ContractInfo.ContractAttachment, ","))
	// 未创建，或草稿状态，仅提交在线协同可保存审核通过版本，默认去当前文件最新版本为审核通过版本
	if needNewest || utils.IntIn(pc.ContractInfo.CooperationStatus, []int{_const.PreSalesContractNotCreated, _const.PreSalesContractDraft}) {
		logs.CtxInfo(ctx, "GenProcessFileNestVersion, GetNewestProcessFileInfo, needNewest:%v", needNewest)
		processFileInfo.ContractFile, err = h.buildNewestProcessFileInfo(ctx, contractFileList)
		if err != nil {
			logs.CtxError(ctx, "buildNewestProcessFileInfoFail_contractFileList:%s, err:%s", contractFileList, err.Error())
			return nil, nil, errorsV2.ErrCommon.WithArgs("buildNewestProcessFileInfoFail")
		}
		processFileInfo.ContractAttachment, err = h.buildNewestProcessFileInfo(ctx, contractAttachmentList)
		if err != nil {
			logs.CtxError(ctx, "buildDraftProcessFileInfoFail_contractAttachmentList:%s, err:%s", contractAttachmentList, err.Error())
			return nil, nil, errorsV2.ErrCommon.WithArgs("buildNewestProcessFileInfoFail")
		}
	} else {
		logs.CtxInfo(ctx, "GenProcessFileNestVersion, GetProcessFileInfo, ContractNo:%s, CurrentOperator:%s",
			pc.ContractInfo.ContractNo, pc.CurrentOperator)
		var fetchedFileList []string
		// 非草稿、未创建状态，默认调用接口查询。文件已通过接口完成版本更迭，不受事务影响
		processFileInfo, err = h.getAttachmentService(ctx).GetProcessFileInfo(ctx, pc.ContractInfo.ContractNo, pc.CurrentOperator)
		if err != nil {
			logs.CtxError(ctx, "GetProcessFileInfoFail, err:%s", err.Error())
			return nil, nil, errorsV2.ErrCommon.WithArgs("GetProcessFileInfoFail")
		}
		// 已查询到的附件列表
		for _, file := range processFileInfo.ContractAttachment {
			if len(file) > 0 {
				fetchedFileList = append(fetchedFileList, file[0].FileID)
			}
		}
		// 计算是否存在未查询到的文件
		diffFileList := utils.SubtractStringSlice(contractAttachmentList, fetchedFileList)
		// 查询未查询到的文件最新版本信息
		if diffAttachmentList, err := h.buildNewestProcessFileInfo(ctx, diffFileList); err != nil {
			logs.CtxError(ctx, "buildDraftProcessFileInfoFail_contractAttachmentList:%s, err:%s", contractAttachmentList, err.Error())
			return nil, nil, errorsV2.ErrCommon.WithArgs("buildNewestProcessFileInfoFail")
		} else if len(diffAttachmentList) > 0 {
			processFileInfo.ContractAttachment = append(processFileInfo.ContractAttachment, diffAttachmentList...)
		}
	}
	// 计算文件版本信息
	fileVersionMap, fileRecordVersions := h.fillRecordVersions(ctx, _const.ContractAttachmentTypeFile, contractFileList, processFileInfo.ContractFile)
	attVersionMap, attRecordVersions := h.fillRecordVersions(ctx, _const.ContractAttachmentTypeCommon, contractAttachmentList, processFileInfo.ContractAttachment)
	// 合并版本信息
	recordVersions = append(recordVersions, fileRecordVersions...)
	for k, v := range fileVersionMap {
		newestVersionMap[k] = v
	}
	recordVersions = append(recordVersions, attRecordVersions...)
	for k, v := range attVersionMap {
		newestVersionMap[k] = v
	}
	return newestVersionMap, recordVersions, nil
}

func (h *handlerCommon) buildNewestProcessFileInfo(ctx context.Context, fileIDList []string) ([][]*metaattachmodels.ProcessFileInfo, error) {
	var res [][]*metaattachmodels.ProcessFileInfo
	for _, fileID := range fileIDList {
		newest, err := filecli.GetNewestVersion(ctx, &filecli.GetNewestVersionReq{
			FileID: fileID,
		})
		if err != nil {
			logs.CtxError(ctx, "GetNewestVersionFail, err:%s", err.Error())
			return nil, err
		}
		modifiedAt, _ := time.Parse(time.RFC3339, newest.Result.ModifiedAt)
		res = append(res, []*metaattachmodels.ProcessFileInfo{
			{
				FileType: _const.ProcessFileTypePending,
				FileID:   newest.Result.ID,
				FileName: newest.Result.Name,
				Version:  newest.Result.Version,
				ModifyAt: modifiedAt,
			},
		})
	}
	return res, nil
}

func (h *handlerCommon) fillRecordVersions(ctx context.Context,
	bizType int,
	fileIDList []string,
	processFiles [][]*metaattachmodels.ProcessFileInfo) (
	map[string]string, []*bizmodels.FileVersionData) {
	var (
		recordVersions   []*bizmodels.FileVersionData
		newestVersionMap = map[string]string{}
	)
	// 构建版本信息map，Key=文件ID，Value=版本列表
	processMap := map[string][]*metaattachmodels.ProcessFileInfo{}
	for _, fileList := range processFiles {
		if len(fileList) > 0 && fileList[0] != nil {
			processMap[fileList[0].FileID] = fileList
		}
	}
	for _, fileID := range fileIDList {
		var newest *metaattachmodels.ProcessFileInfo
		approveFile := &metaattachmodels.ProcessFileInfo{}
		fileList := processMap[fileID]
		for _, file := range fileList {
			// 审核通过版本不参与计算当前操作人审核通过版本
			if file.FileType == _const.ProcessFileTypeApprove {
				approveFile = file
				continue
			}
			if newest == nil || file.ModifyAt.After(newest.ModifyAt) {
				newest = file
			}
		}
		// 默认复制待审核版本为原待审核版本
		if approveFile != nil {
			newestVersionMap[fileID] = approveFile.Version
		}
		// 没有当前操作人上传的版本信息，待审核版本保持与原待审核版本一致，审核记录记录的操作人审核通过版本不存储
		if newest == nil {
			logs.CtxInfo(ctx, "FillRecordVersionsFail, fileID:%s, processFiles:%v", fileID, processFiles)
			continue
		}
		// 当前节点当前用户上传了新的版本，记录当前操作人为审核通过版本
		newestVersionMap[fileID] = newest.Version
		recordVersions = append(recordVersions, &bizmodels.FileVersionData{
			BizType:  bizType,
			FileID:   newest.FileID,
			FileName: newest.FileName,
			Version:  newest.Version,
		})
	}
	return newestVersionMap, recordVersions
}

// CreateOrUpdateMetaExt 创建或更新附加信息
func (h *handlerCommon) CreateOrUpdateMetaExt(ctx context.Context, tx *gorm.DB, ext *model.ContractMetaExt) errorsV2.APIError {
	metaExtDao := dal.NewContractMetaExtDao()
	metaExt, err := metaExtDao.FindByAttrKey(ctx, tx, int64(ext.ContractId), ext.AttrKey)
	if err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, FindByNoFail contractId:%d attrKey:%s", ext.ContractId, ext.AttrKey)
		return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
	}
	if metaExt != nil {
		// 更新
		if err = metaExtDao.UpdateValue(ctx, tx, metaExt.Id, ext.AttrValue); err != nil {
			logs.CtxError(ctx, "SaveManageInfoFail, UpdateManageFail contractId:%d attrKey:%s", ext.ContractId, ext.AttrKey)
			return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
		}
	} else {
		// 新建
		if err = metaExtDao.Create(ctx, tx, ext); err != nil {
			logs.CtxError(ctx, "SaveManageInfoFail, CreateManageFail contractId:%d attrKey:%s", ext.ContractId, ext.AttrKey)
			return errorsV2.ErrInternalError.WithArgs("SaveManageInfoFail")
		}
	}

	return nil
}

// DeleteMetaExt 删除合同附加信息
func (h *handlerCommon) DeleteMetaExt(ctx context.Context, tx *gorm.DB, deleteKey string, contractId uint64) errorsV2.APIError {
	// 更新合同附加信息表
	if len(deleteKey) == 0 {
		logs.CtxInfo(ctx, "deleteKeyList is empty, continue.")
		return nil
	}
	// 查询合同所有附加信息
	metaExtDao := dal.NewContractMetaExtDao()
	err := metaExtDao.DeleteByAttrKey(ctx, tx, contractId, deleteKey)
	if err != nil {
		logs.CtxError(ctx, "FindByAttrKeyFail, contractId:%d, deleteKey:%s, err:%v", contractId, deleteKey, err)
		return errorsV2.ErrInternalError.WithArgs(err.Error())
	}
	return nil
}

func (h *handlerCommon) SendSubmitOaMsg(ctx context.Context, pc *auditmodel.ProcessCtx) errorsV2.APIError {
	detail := &bizmodels.DeferMsgSubmitOA{
		ContractNo: pc.ContractInfo.ContractNo,
	}

	body, err := json.Marshal(detail)
	if err != nil {
		logs.CtxError(ctx, "SubmitOAReqMarshalFail, err:%s", err.Error())
		return errorsV2.ErrCommon.WithArgs("SubmitOAReqMarshalFail")
	}
	// 发送延迟消息
	msg := &bizmodels.DeferMsg{
		DeferType: _const.DeferTypeSalesSubmitOA,
		Body:      string(body),
	}
	logs.CtxInfo(ctx, "SendSubmitOaMsg, data => %s", string(body))
	if err := mqProducer.SendDeferMessage(ctx, time.Second, msg); err != nil {
		logs.CtxError(ctx, "SendSubmitOaMsgFail, err:%s", err.Error())
		return errorsV2.ErrCommon.WithArgs("SendSubmitOaMsgFail")
	}
	return nil
}

// SaveCommodityList 保存报价商品详情
func SaveCommodityList(ctx context.Context, tx *gorm.DB, metaDB *model.ContractMetaDB, commodityList []*model.VolcContractCommodity, update map[string]interface{}) errorsV2.APIError {

	// 更新报价商品详情表
	commodityDao := dal.NewContractCommodityDao()
	if err := commodityDao.DeleteByVolcContractId(ctx, tx, int64(metaDB.Id)); len(metaDB.ContractNo) > 0 && err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, DeleteCommodityByNoFail contractNo:%s version:%d, err:%v", metaDB.ContractNo, metaDB.Version, err)
		return errorsV2.ErrInternalError.WithArgs("DeleteCommodityByNoFail")
	}
	if len(commodityList) == 0 {
		return nil
	}

	var tradeProductList []string
	for _, v := range commodityList {
		if len(v.TradeProduct) == 0 {
			continue
		}
		tradeProductList = append(tradeProductList, v.TradeProduct)
	}
	tradeProductList = utils.RemoveRepeat(tradeProductList)

	// 查询商品相关信息
	// tradeProductInfoList, err := tradecli.QueryProductListV1(ctx, strings.Join(tradeProductList, ","))
	tradeProductInfoList, err := innertopcommercializationcli.BatchGetProductLite(ctx, strings.Join(tradeProductList, ","))
	if err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, CreateManageFail contractNo:%s version:%d err:%v", metaDB.ContractNo, metaDB.Version, err)
		return errorsV2.ErrInternalError.WithArgs("查询关联商品信息失败")
	}

	// tradeProductMapping := map[string]*commercialization_api.ProductItem{}
	tradeProductMapping := map[string]*lite.ProductLite{}
	for _, v := range tradeProductInfoList {
		tradeProductMapping[v.Product] = v
	}

	for _, v := range commodityList {
		product := tradeProductMapping[v.TradeProduct]
		if product == nil {
			continue
		} // todo zhangyujie 工具方法 搜索全局   innertopcommercializationcli
		if !conf.IsEnableInvoiceTaxRateValidate(ctx) {
			if len(v.InvoiceProject) == 0 {
				invoiceCode, ratio := utils.ParseInvoiceProject(product.InvoiceProject)
				v.InvoiceProject = product.InvoiceProject
				v.InvoiceProjectCode = invoiceCode
				v.TaxRatio = ratio
			}
			v.IncomeCode = product.IncomeCode
		}
		v.TradeProductCode = product.ProductCode
		v.TradeProduct = product.Product
	}

	// 补全默认开票项目、收入类型
	if err := commodityDao.CreateInBatches(ctx, tx, commodityList); err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, CreateCommodityFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
		return errorsV2.ErrInternalError.WithArgs("CreateCommodityFail")
	}
	update["product"] = strings.Join(tradeProductList, ",")
	return nil
}

// SaveExternalCommodityList 保存外部商品信息
func SaveExternalCommodityList(ctx context.Context, tx *gorm.DB, metaDB *model.ContractMetaDB, commodityList []*model.VolcContractCommodityExternal) errorsV2.APIError {
	logs.CtxInfo(ctx, "SaveCommodityList, ContractNo:%s, length:%d", metaDB.ContractNo, len(commodityList))
	// 更新报价商品详情表
	commodityDao := dal.NewContractCommodityExternalDao()
	if err := commodityDao.DeleteByVolcContractID(ctx, tx, int64(metaDB.Id)); len(metaDB.ContractNo) > 0 && err != nil {
		logs.CtxError(ctx, "SaveExternalCommodityListFail, DeleteCommodityByNoFail contractNo:%s version:%d, err:%v", metaDB.ContractNo, metaDB.Version, err)
		return errorsV2.ErrInternalError.WithArgs("DeleteExternalCommodityByNoFail")
	}
	if len(commodityList) == 0 {
		return nil
	}

	// 补全默认开票项目、收入类型
	if err := commodityDao.CreateInBatches(ctx, tx, commodityList); err != nil {
		logs.CtxError(ctx, "SaveManageInfoFail, CreateCommodityFail contractNo:%s version:%d", metaDB.ContractNo, metaDB.Version)
		return errorsV2.ErrInternalError.WithArgs("CreateCommodityFail")
	}
	return nil
}

// EditExternalCommodityList 编辑外部报价项
func EditExternalCommodityList(ctx context.Context, tx *gorm.DB, contractNo string, commodityList bizmodels.ExternalProductInfoList, isSplitProduct bool) errorsV2.APIError {
	metaDB, err := dal.NewContractMetaDao().FindLastByNo(ctx, tx, contractNo)
	if err != nil {
		logs.CtxError(ctx, "EditExternalCommodityList, FindLastByNo err:%v, contractNo:%s", err, contractNo)
		return errorsV2.ErrInternalError.WithArgs("FindContractFail")
	}
	if metaDB == nil {
		logs.CtxError(ctx, "EditExternalCommodityList, ContractNotFound contractNo:%s", contractNo)
		return errorsV2.ErrInternalError.WithArgs("ContractNotFound")
	}

	// 补充逻辑：查完合同信息之后，更新合同管理信息中的IsSplitProduct
	manageInfo, err := dal.NewContractManageDao().FindByVolcContractId(ctx, tx, int64(metaDB.Id))
	if err != nil {
		logs.CtxError(ctx, "EditExternalCommodityList, FindByVolcContractId err:%v, volcContractId:%d", err, metaDB.Id)
		return errorsV2.ErrInternalError.WithArgs("FindManageInfoFail")
	}
	if manageInfo != nil {
		err = dal.NewContractManageDao().UpdateByMap(ctx, tx, int64(manageInfo.Id), map[string]interface{}{"is_split_product": isSplitProduct})
		if err != nil {
			logs.CtxError(ctx, "EditExternalCommodityList, UpdateManageInfo err:%v, id:%d", err, manageInfo.Id)
			return errorsV2.ErrInternalError.WithArgs("UpdateManageInfoFail")
		}
	}

	externalList := model.ConvertExternalCommodityList(commodityList, uint64(metaDB.Id))
	return SaveExternalCommodityList(ctx, tx, metaDB, externalList)
}

// BuildManageAndCommodity 构建管理信息和商品信息(内外部映射表)
func BuildManageAndCommodity(contractNo string, version int, volcContractID uint64, manageInfo *bizmodels.ManageInfo) (*model.VolcContractManage, []*model.VolcContractCommodity, []*model.VolcContractCommodityExternal) {

	info := &model.VolcContractManage{
		ContractNo: contractNo,
		Version:    version,
	}

	// 处理ProductTotalIncome
	// 标准报价项
	productTotalIncome := decimal.NewFromInt(0)
	for _, list := range manageInfo.ProductLevelMap {
		for _, product := range list {
			productTotalIncome = productTotalIncome.Add(product.Income)
		}
	}
	// 分组信息
	accountAssociationInfoByte, _ := json.Marshal(manageInfo.AccountAssociationInfo)
	// 飞书加签信息
	apostilleInfoBody, _ := json.Marshal(manageInfo.FeishuApostilleInfo)

	info.VolcContractId = volcContractID
	info.Remark = manageInfo.Remark
	info.PaymentType = manageInfo.PaymentType
	info.PaymentTypeName = manageInfo.PaymentTypeName
	info.DistributBusinessType = manageInfo.DistributBusinessType
	info.BelongingDepartment = manageInfo.BelongingDepartment
	info.ProductLine = manageInfo.ProductLine
	info.RelatedPersonnel = manageInfo.RelatedPersonnel
	info.LegalReviewer = manageInfo.LegalReviewer
	info.FeishuApostilleInfo = string(apostilleInfoBody)
	info.ReceivingPlace = manageInfo.ReceivingPlace
	info.QuoteAccountID = manageInfo.QuoteAccountID
	info.SealAccountID = manageInfo.SealAccountID
	info.PricingAccountID = manageInfo.PricingAccountID
	info.EndUser = manageInfo.EndUser
	info.EndUserAccountID = manageInfo.EndUserAccountID
	info.ProductValidityBegin, _ = utils.GetTimeFromString(manageInfo.ProductValidityBegin)
	info.ProductValidityEnd, _ = utils.GetTimeFromString(manageInfo.ProductValidityEnd)
	info.ProductTotalIncome = productTotalIncome
	info.RelateQuoteChanged = manageInfo.RelateQuoteChanged
	info.RelateQuoteChangedBefore = manageInfo.RelateQuoteChangedBefore

	info.UsefulLifeType = manageInfo.UsefulLifeType
	info.IndefiniteDateFlag = manageInfo.IndefiniteDateFlag
	info.UsefulLifeUnit = manageInfo.UsefulLifeUnit
	info.UsefulLifeNum = manageInfo.UsefulLifeNum
	info.LongLifeReason = manageInfo.LongLifeReason
	info.WhetherProject = manageInfo.WhetherProject
	info.IsSplitProduct = manageInfo.IsSplitProduct
	info.DistributBusinessType = manageInfo.DistributBusinessType
	info.AccountAssociationInfo = string(accountAssociationInfoByte)

	var list []*model.VolcContractCommodity
	// 标准报价项
	for _, v := range manageInfo.ProductLevelMap {
		list = append(list, model.ConvertCommodityList(v, volcContractID, contractNo, version)...)
	}
	// 抵扣项
	for _, v := range manageInfo.DeductProductInfoMap {
		list = append(list, model.ConvertCommodityList(v, volcContractID, contractNo, version)...)
	}

	// 选择拆分内外部映射表是 存储外部映射表信息
	var externalList []*model.VolcContractCommodityExternal
	if manageInfo.IsSplitProduct {
		externalList = model.ConvertExternalCommodityList(manageInfo.ExternalProductList, volcContractID)
	}

	return info, list, externalList
}

// updateAttachment 更新附件信息
func (h *handlerCommon) updateAttachment(ctx context.Context, tx *gorm.DB, contractNo string, attachmentUpdateList []*bizmodels.MetaAttachment) error {

	logs.CtxInfo(ctx, "UpdateAttachmentStart")

	for _, attachment := range attachmentUpdateList {
		extra, err := json.Marshal(attachment)
		if err != nil {
			logs.CtxError(ctx, "UpdateAttachmentFail, fileKey:%s, error: %v", attachment.DownloadID, err)
			return err
		}
		err = dal.NewContractAttachmentDao().UpdateByFileKey(ctx, tx, attachment.DownloadID, map[string]interface{}{"extra": string(extra), "contract_no": contractNo})
		if err != nil {
			logs.CtxError(ctx, "UpdateAttachmentFail_UpdateByFileKey, fileKey:%s, error: %v", attachment.DownloadID, err)
			return err
		}
	}
	return nil
}

// updateContractReviewers 更新协同操作条目
func (h *handlerCommon) updateContractReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	contract := pc.ContractInfo
	// 查询当前合同协同已经存在的审批人条目列表
	allReviewers, err := dal.NewPreContractReviewerDao().FindReviewersByNo(ctx, pc.GetTx(), contract.ContractNo)
	if err != nil {
		return err
	}

	allReviewerList := allReviewers.GenResp()
	contract.Reviewers = allReviewerList

	// 判断是否已经完成审批条目初始化
	salesOperatorList := h.getReviewerFromPreContractReviewerList(allReviewerList, _const.ReviewerTypeSalesOperation)
	ftlOperatorList := h.getReviewerFromPreContractReviewerList(allReviewerList, _const.ReviewerTypeFinanceTaxationLegalReviewer)
	if len(salesOperatorList) > 0 || len(ftlOperatorList) > 0 {
		// 之前已经创建过审批人员条目 则忽略 由前置流程保证正确性
		return nil
	}

	basicInfo := contract.BasicInfo
	if basicInfo.ContractTemplateType == nil {
		return errorsV2.ErrCommon.WithArgs("合同模板类型缺失")
	}
	// 查询该合同需要的财税法审核角色 示例：财务AR+财务BP+税务BP+法务BP
	rolesStr, _ := ruleengine.MatchFTLRule(ctx, h.GenRoleMapKeyByBasicInfo(basicInfo))
	if len(rolesStr) == 0 {

		larkc.Warning("无此合同对应的财税法审核角色",
			i18nfmt.Sprintf(ctx, "PreContractNo:%v 模板类型:%v 收支类型:%v 合同分类编码:%v",
				contract.ContractNo,
				utils.ContractTemplateType2String(basicInfo.ContractTemplateType),
				basicInfo.InOutType, basicInfo.CategoryNo))

		return errorsV2.ErrInternalError.WithArgs("无此合同对应的财税法审核角色 PreContractNo: %v", contract.ContractNo)
	}

	// 财务AR+财务BP+税务BP+法务BP => [财务AR,财务BP,税务BP,法务BP]
	needRoles := strings.Split(rolesStr, "+")
	// 新增销售运营角色
	needRoles = append(needRoles, _const.GetReviewerRoleName(_const.ReviewerRoleSalesOp))

	// 示例 key=财务AR value=email
	reviewerMappings, err := h.getAndValidateReviewerMappings(ctx, needRoles, basicInfo.DepartmentId, contract.Operator)
	if err != nil {
		return err
	}

	// 获取全部用户 从people查询用户信息
	collectEmails := h.collectEmails(reviewerMappings)
	productSolutionEmails := contract.GetProductSolutionEmails()
	collectEmails = append(collectEmails, productSolutionEmails...)
	employeeMappings, err := larkc.BatchListHireEmployeesByEmails(ctx, collectEmails)
	if err != nil {
		return err
	}

	// var fileUserPerms filecli.Users
	var reviewerDBList []*model.PreContractReviewerDB
	existReviewerMap := map[string]bool{}
	for _, role := range needRoles {
		reviewerRole := _const.GetReviewerRoleValueByNameIgnore(role)
		reviewerStr := reviewerMappings[role]
		reviewers := strings.Split(reviewerStr, ",")
		if len(reviewers) == 0 {
			return i18nfmt.Errorf(ctx, "当前角色[%s]未配置审核人员", role)
		}
		for _, email := range reviewers {

			employee := employeeMappings[email]
			if employee == nil {
				logs.CtxError(ctx, "查询用户信息失败, 无法新增审批记录, email: %s", email)
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "查询用户[%s]信息失败, 无法新增审批", email))
			}

			reviewerType := _const.ReviewerTypeFinanceTaxationLegalReviewer
			if role == _const.GetReviewerRoleName(_const.ReviewerRoleSalesOp) {
				reviewerType = _const.ReviewerTypeSalesOperation
			}

			// 获取不同reviewer_type对应的审批节点列表
			reviewerTypeStatusMap := GetReviewerTypeStatusMappings(pc.ApprovalKey)
			relateStatusList := reviewerTypeStatusMap[reviewerType]

			for _, contractStatus := range relateStatusList {
				// email == reviewer_type == contract_status
				existKey := i18nfmt.Sprintf(ctx, "%s_%d_%d", employee.Email, reviewerType, contractStatus)

				if existReviewerMap[existKey] {
					logs.CtxInfo(ctx, "[%s]已存在, 忽略", existKey)
					continue
				}

				// contract_reviewer
				reviewerDBList = append(reviewerDBList, &model.PreContractReviewerDB{
					BaseDB:         model.BaseDB{},
					PreContractNo:  contract.ContractNo,
					Reviewer:       employee.Email,
					ReviewerID:     strconv.Itoa(employee.ID),
					ReviewerType:   reviewerType,
					ContractStatus: contractStatus,
					Department:     contract.BasicInfo.DepartmentId,
					ReviewerRole:   reviewerRole,
				})

				existReviewerMap[existKey] = true
			}

		}
	}

	logs.CtxInfo(ctx, "updateContractReviewers, ApprovalKey=%s", pc.ApprovalKey)
	// 新增 解决方案审批节点 审批人
	projectInfo := contract.ProjectInfo
	if pc.ApprovalKey == _const.ApprovalKeyDefaultWithSolution && projectInfo != nil {
		if projectInfo.HasProductSolutionEmail() {
			arr := strings.Split(projectInfo.GetProductSolutionEmail(), ",")
			for _, email := range arr {
				if email == "" {
					continue
				}
				emp := employeeMappings[email]
				if emp == nil {
					continue
				}
				reviewerDBList = append(reviewerDBList, &model.PreContractReviewerDB{
					BaseDB:         model.BaseDB{},
					PreContractNo:  contract.ContractNo,
					Reviewer:       emp.Email,
					ReviewerID:     strconv.Itoa(emp.ID),
					ReviewerType:   _const.ReviewerTypeSolutionReviewer,
					ContractStatus: _const.PreSalesContractSolutionReview,
					Department:     contract.BasicInfo.DepartmentId,
					ReviewerRole:   _const.ReviewerRoleSolution,
				})
			}
		}
	}

	if len(reviewerDBList) > 0 {
		// 保存审批操作条目
		if err = dal.NewPreContractReviewerDao().BatchCreate(ctx, pc.GetTx(), reviewerDBList); err != nil {
			return i18nfmt.New(ctx, "创建审批操作条目失败")
		}
		for _, v := range reviewerDBList {
			vv := v.GenResp()
			pc.ContractInfo.Reviewers = append(pc.ContractInfo.Reviewers, vv)
		}
	}

	return nil
}

// checkCategoryReviewerRole 检查合同分类是否需要审批节点
func (h *handlerCommon) checkCategoryReviewerRole(categoryNo string, roles []string) []string {
	if categoryNo == _const.BizCategoryNoCommonZYZH {
		return roles
	}
	// 非资产置换 【税务BP】不作为固定审批节点
	var ret []string
	for _, v := range roles {
		if v == _const.GetReviewerRoleName(_const.ReviewerRoleTaxBP) {
			continue
		}
		ret = append(ret, v)
	}
	return ret
}

// collectEmails 拆分email  key=department value=emails
func (h *handlerCommon) collectEmails(departmentMap map[string]string) []string {
	m := map[string]struct{}{}
	for _, emails := range departmentMap {
		arr := strings.Split(emails, ",")
		for _, v := range arr {
			m[v] = struct{}{}
		}
	}
	var ret []string
	for email := range m {
		ret = append(ret, email)
	}
	return ret
}

// getAndValidateReviewerMappings 获取并校验部门审核人
// needRoles 需要获取的销售归属行业的审批角色（中文）
// department 销售归属行业（中文）
// operator 业务执行人工号（仅用于发送飞书告警）
func (h *handlerCommon) getAndValidateReviewerMappings(ctx context.Context, needRoles []string, departmentId string, operator string) (map[string]string, error) {
	contractOperator, _ := larkc.GetEmployeeByID(ctx, operator)
	var contractOperatorEmail string
	if contractOperator != nil && len(contractOperator) > 0 {
		contractOperatorEmail = contractOperator[0].Email
	}

	departmentName := preload.ReviewRuleID2Name(departmentId)

	primaryReviewers, err1 := h.reviewerMatcher().GetPrimaryReviewers(ctx, departmentId)
	if err1 != nil {
		multiCtx := context.Background()
		larkc.BatchSendMessageToEmailIgnore(ctx,
			larkc.GetReviewerErrorReceivers(),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorRed).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核人员配置异常")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 提交的合同销售归属行业不存在", larkc.LarkMdAtEmail(contractOperatorEmail))).
				AddField(multienv.I18nFormat(multiCtx, "行业线"), departmentName).
				BuildJSONString())
		logs.CtxError(ctx, "GetPrimaryReviewers error: err=%v department=%s", err1, departmentName)
		return nil, err1
	}

	reviewerMappings := map[string]string{}
	// 检查是否有未指定审核人的角色
	for _, role := range needRoles {
		reviewers, ok := primaryReviewers[_const.GetReviewerRoleValueByNameIgnore(role)]
		if !ok {
			logs.CtxError(ctx, "审核人未定义, department:%s, role:%s", departmentName, role)
			// 发送飞书消息
			multiCtx := context.Background()
			larkc.BatchSendMessageToEmailIgnore(ctx,
				larkc.GetReviewerErrorReceivers(),
				larkc.MsgTypeInteractive,
				larkc.NewCommonMessageCardBuilder().
					SetTitleColor(larkc.TitleColorRed).
					SetTitle(multienv.I18nFormat(multiCtx, "审核人员匹配失败提醒")).
					SetContent(i18nfmt.Sprintf(multiCtx, "%s 提交的合同找不到对应的审核人，请及时维护审核分工关系", larkc.LarkMdAtEmail(contractOperatorEmail))).
					AddField(multienv.I18nFormat(multiCtx, "行业线"), departmentName).
					AddField(multienv.I18nFormat(multiCtx, "审批角色"), role).
					BuildJSONString())
			return nil, errorsV2.ErrInternalError.WithArgs(_const.ReviewerError)
		}
		var emails []string
		for _, reviewer := range reviewers {
			if reviewer.EmployeeEmail == "" {
				logs.CtxError(ctx, "审核人邮箱为空, department: %s, role: %s", departmentName, role)
				multiCtx := context.Background()
				larkc.BatchSendMessageToEmailIgnore(ctx,
					larkc.GetReviewerErrorReceivers(),
					larkc.MsgTypeInteractive,
					larkc.NewCommonMessageCardBuilder().
						SetTitleColor(larkc.TitleColorRed).
						SetTitle(multienv.I18nFormat(multiCtx, "审核人员匹配失败提醒")).
						SetContent(i18nfmt.Sprintf(multiCtx, "%s 提交的合同对应的审核人邮箱为空，请检查审核人员配置", larkc.LarkMdAtEmail(contractOperatorEmail))).
						AddField(multienv.I18nFormat(multiCtx, "行业线"), departmentName).
						AddField(multienv.I18nFormat(multiCtx, "审批角色"), role).
						BuildJSONString())

				return nil, errorsV2.ErrInternalError.WithArgs(_const.ReviewerError)
			}
			emails = append(emails, reviewer.EmployeeEmail)
		}

		reviewerMappings[role] = strings.Join(emails, ",")
	}

	return reviewerMappings, nil
}

// IsReverseContract 判断是否为倒签合同
func (h *handlerCommon) IsReverseContract(ctx context.Context, metaDB *model.ContractMetaDB) error {
	basicInfo, err := basicinfo.ParseBasicInfo(ctx, metaDB.BasicInfo)
	if err != nil {
		logs.CtxError(ctx, "ConfirmFinalizedValidate, BasicInfoMarshalFail, err:%v", err)
		return i18nfmt.New(ctx, "IsReverseContractFail")
	}
	logs.CtxInfo(ctx, "ConfirmFinalizedValidate, basicInfo:%s", basicInfo)
	// todo: 加到签合同判断， 自签订生效 为非到签合同
	if basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
		logs.CtxInfo(ctx, "UsefulLifeType is sign time, continue.")
		return nil
	}

	var reverseSignInfo bizmodels.ReverseSignInfo
	err = json.Unmarshal([]byte(metaDB.ReverseSignInfo), &reverseSignInfo)
	if err != nil {
		logs.CtxError(ctx, "ConfirmFinalizedValidate, ReverseSignInfoMarshalFail, err:%v", err)
		return i18nfmt.New(ctx, "IsReverseContractFail")
	}
	logs.CtxInfo(ctx, "ConfirmFinalizedValidate, reverseSignInfo:%s", reverseSignInfo)

	// 重新判断是否为倒签合同
	year, month, day := time.Now().Date()
	date := time.Date(year, month, day, 0, 0, 0, 0, metaDB.BeginTime.Location())
	metaDB.IsBackdating = _const.NoBackdating
	if !metaDB.BeginTime.IsZero() && metaDB.BeginTime.Before(date) {
		metaDB.IsBackdating = _const.Backdating
	}

	if metaDB.IsBackdating != 0 && len(reverseSignInfo.ReverseSignReason) == 0 {
		logs.CtxError(ctx, "ReverseContract_ReverseReasonIsNil, preContractNo: %s", metaDB.ContractNo)
		return i18nfmt.New(ctx, "ReverseContract_ReverseReasonIsNil")
	}
	return nil
}

// GenRoleMapKeyByBasicInfo 根据合同基本信息生成角色映射key
func (h *handlerCommon) GenRoleMapKeyByBasicInfo(basicInfo *bizmodels.BasicInfo) map[string]interface{} {
	params := map[string]interface{}{
		"WhetherProject": basicInfo.WhetherProject,
		"TemplateType":   *basicInfo.ContractTemplateType,
		"InOutType":      basicInfo.InOutType,
		"ContractType":   utils.CategoryNo2WhetherResourceExchange(basicInfo.CategoryNo),
	}
	return params
}

// validateRequireQuote 关联报价单校验
func (h *handlerCommon) validateRequireQuote(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 不需要关联报价单场景
	if !pc.ContractInfo.NeedRelateQuoteNo() {
		if pc.ContractInfo.RelateQuoteNo != "" {
			logs.CtxInfo(ctx, "validateRequireQuote_clearRelateQuoteNo")
			return errorsV2.ErrQuoteCommon.WithArgs("当前合同不允许关联报价单")
		}
		return nil
	}
	// 需要绑定报价单场景
	logs.CtxInfo(ctx, "handlerDraftSubmitPreContract, needValidateRequireQuote")
	// 解析报价单信息绑定到合同上下文
	if err := h.fillQuoteInfo(ctx, pc); err != nil {
		logs.CtxError(ctx, "fillQuoteInfoFail, err=%s", err.Error())
		return err
	}
	// 校验签约方式
	if err := h.checkUsefulLifeTypeForQuote(ctx, pc); err != nil {
		logs.CtxError(ctx, "checkUsefulLifeTypeForQuoteFail, err=%s", err.Error())
		return err
	}
	// 合同价重复校验
	if err := h.checkContractDiscount(ctx, pc); err != nil {
		return err
	}
	// 合同价预校验
	if err := h.checkPreCheckContractDiscount(ctx, pc.ContractInfo); err != nil {
		return err
	}

	logs.CtxInfo(ctx, "tempQuoteChangeInfoWhenSubmit, contractNo=%s, before=%s", pc.ContractInfo.ContractNo, pc.ContractInfo.RelateQuoteChangedBefore)
	return nil
}

// getQuoteDetail 获取报价单详情、报价单需处于可用的状态
func (h *handlerCommon) getQuoteDetail(ctx context.Context, quoteNo string, whetherProject string) (*bizmodels.QuoteCreateContractReq, error) {
	// 必须关联报价单
	if quoteNo == "" {
		return nil, errorsV2.ErrQuoteCommon.WithArgs("当前合同必须关联报价单")
	}

	quoteNos := strings.Split(quoteNo, ",")
	if len(quoteNos) > 1 {
		return nil, errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "不能绑定多个报价单[%s]", quoteNo))
	}

	// 判断报价单是否被使用
	resp, apiErr := h.getMetaCommodityService(ctx).HasQuoteRelateContract(ctx, quoteNo)
	if apiErr != nil {
		logs.CtxError(ctx, "HasQuoteRelateContractCheckFail, quoteNo=%s, err=%s", quoteNo, apiErr.Error())
		return nil, errorsV2.ErrQuoteCommon.WithArgs(apiErr.Error())
	}
	// HasQuoteRelateContract方法中保证：err==nil时，resp!=nil
	if resp.Related {
		return nil, errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "当前报价单已经被其他合同关联：%v", resp.RelatedContractList))
	}
	detail, err := quotecli.GetQuoteCreateContractReqByQuoteNo(ctx, quoteNo)
	if err != nil {
		return nil, i18nfmt.Errorf(ctx, "报价单[%s]查询详情失败", quoteNo)
	}
	// 报价单校验
	if err := h.getQuoteService(ctx).ValidateQuote(ctx, detail, whetherProject); err != nil {
		logs.CtxError(ctx, "ValidateQuoteFail, err:%v", err)
		return nil, err
	}
	return detail, nil
}

// fillQuoteInfo 填充合同关联的报价单信息
func (h *handlerCommon) fillQuoteInfo(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	contractInfo := pc.ContractInfo
	quoteNo := contractInfo.RelateQuoteNo
	// 先置空 后面逻辑正常后再重新设置
	contractInfo.RelateQuoteChanged = false
	contractInfo.RelateQuoteChangedBefore = ""

	if contractInfo.BasicInfo == nil {
		return nil
	}
	// 获取报价信息
	detail, err := h.getQuoteDetail(ctx, quoteNo, contractInfo.BasicInfo.WhetherProject)
	if err != nil {
		logs.CtxError(ctx, "validateRequireQuote_GetQuoteDetailFail, err:%v", err)
		return err
	}

	// 合同管理信息
	manageInfo, err := h.getCommodityService(ctx).BuildManageInfoByQuote(ctx, detail, contractInfo.ManageInfo)
	if err != nil {
		logs.CtxError(ctx, "BuildManageInfoFail, err:%v", err)
		return err
	}
	if manageInfo == nil {
		logs.CtxError(ctx, "BuildManageInfoFail, quoteNo:%s", quoteNo)
		return errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "关联报价单信息[%s]解析失败", quoteNo))
	}
	contractInfo.ManageInfo = manageInfo

	// 项目信息
	contractInfo.ProjectInfo, err = h.getQuoteService(ctx).BuildProjectInfo(ctx, quoteNo, contractInfo.ProjectInfo)
	if err != nil {
		logs.CtxError(ctx, "BuildProjectInfoFail, err:%v", err)
		return err
	}

	// 合同附加信息
	// 构建合同附加信息
	metaExtMap, err := h.getExtService(ctx).GetExtMapByQuote(ctx, quoteNo)
	if err != nil {
		logs.CtxError(ctx, "BuildMetaExtMapFail, err:%v", err)
		return err
	}
	// 外部传入的附加信息
	for k, v := range metaExtMap {
		if pc.Ext == nil {
			pc.Ext = map[string]string{}
		}
		pc.Ext[k] = v
	}

	// 基本信息
	// 计算特殊合同类型
	h.fillSpecialContractType(ctx, pc, metaExtMap, manageInfo)
	// 关联报价单的合同 是否项目制默认与报价单保持一致
	pc.ContractInfo.BasicInfo.WhetherProject = manageInfo.WhetherProject
	// 报价单业务类型赋值
	pc.ContractInfo.BasicInfo.BusinessType = detail.BizInfo.TradeTypeCode
	// 基于报价单赋值 收入金额、预估收入金额
	if pc.ContractInfo.PropertyCode == _const.PropertyCodeFrameContract {
		pc.ContractInfo.BasicInfo.EstimateTotalIn = detail.BizInfo.TotalSales
	} else if pc.ContractInfo.PropertyCode == _const.PropertyCodeFixedContract {
		pc.ContractInfo.BasicInfo.TotalIn = detail.BizInfo.TotalSales
	}

	contractInfo.RelateQuoteChanged = true

	// 交易双方信息
	// 校验对方主体
	tradePartyInfo := pc.ContractInfo.TradePartyInfo
	if len(manageInfo.QuoteAccountID) > 0 {
		// 更新交易双方信息
		tradePartyInfo, err = h.fillTradePartyInfo(ctx, manageInfo, pc, detail.BizInfo)
		if err != nil {
			logs.CtxError(ctx, "updateTradePartyInfoFail, accountID:%d, err:%v", manageInfo.QuoteAccountID, err)
			return err
		}
	}
	// 处理交易双方信息的关联
	h.QuoteChangeFillAccountID(ctx, contractInfo, tradePartyInfo)
	// 交易双方信息赋值
	contractInfo.TradePartyInfo = tradePartyInfo

	basicInfoStr, _ := json.Marshal(pc.ContractInfo.BasicInfo)
	pc.PreContractVO.BasicInfo = string(basicInfoStr)
	tradePartyInfoBody, _ := json.Marshal(pc.ContractInfo.TradePartyInfo)
	pc.PreContractVO.TradePartyInfo = string(tradePartyInfoBody)
	projectInfoBody, _ := json.Marshal(pc.ContractInfo.ProjectInfo)
	pc.PreContractVO.ProjectInfo = string(projectInfoBody)
	return nil
}

// QuoteChangeFillAccountID 关联报价单变更时，填充账号信息
func (h *handlerCommon) QuoteChangeFillAccountID(ctx context.Context, contractInfo *model.ContractMeta, tradePartyInfo *bizmodels.TradePartyInfo) {
	// 报价单关联账号信息
	if len(contractInfo.ManageInfo.QuoteAccountID) > 0 {
		return
	}
	// 构建原交易对方信息 Map
	otherPartyMap := map[string]*bizmodels.TradePartyInfoDetail{}
	for _, party := range contractInfo.TradePartyInfo.OtherParty {
		otherPartyMap[party.PartyNumber] = party
	}
	// 若报价单关联账号为空时，处理下合同关联账号
	for _, party := range tradePartyInfo.OtherParty {
		// 若对方主体发生了变更，不处理
		if oldParty, ok := otherPartyMap[party.PartyNumber]; ok {
			// 当更换报价单，把副主体替换成主主体时，主体关联账号信息以报价单为主
			if oldParty.IsDeputyParty() {
				continue
			}
			// 若对方主体未发生变更，保持合同关联账号不变
			party.AccountID = oldParty.AccountID
			party.SealAccountID = oldParty.SealAccountID
			party.PricingAccountID = oldParty.PricingAccountID
		}
	}
}

// fillSpecialContractType 填充特殊合同类型
func (h *handlerCommon) fillSpecialContractType(ctx context.Context, pc *auditmodel.ProcessCtx, metaExtMap map[string]string, manageInfo *bizmodels.ManageInfo) {
	// 结算特殊合同类型
	basicInfo := pc.ContractInfo.BasicInfo
	specialContractTypes := strings.Split(basicInfo.SpecialContractType, ",")
	if guarantee.ContainsGuaranteeExt(metaExtMap) {
		specialContractTypes = append(specialContractTypes, _const.SpecialContractTypeGuarantee)
	}
	// 阶梯报价合同
	if manageInfo.QuoteType == _const.QuoteTypeLadderQuote {
		specialContractTypes = append(specialContractTypes, _const.SpecialContractTypeLadderQuotation)
	}
	specialContractTypes = utils.SingleList(specialContractTypes)
	if len(specialContractTypes) > 0 {
		pc.PreContractVO.SpecialContractType = strings.Join(specialContractTypes, ",")
		basicInfo.SpecialContractType = strings.Join(specialContractTypes, ",")
	}
}

// fillTradePartyInfo 填充交易双方信息
func (h *handlerCommon) fillTradePartyInfo(ctx context.Context, manageInfo *bizmodels.ManageInfo, pc *auditmodel.ProcessCtx, bizInfo *bizmodels.QuoteBizInfo) (*bizmodels.TradePartyInfo, error) {
	relateAccountInfo, parseRelateAccountInfoErr := bizInfo.ParseRelateAccountInfo(ctx)
	if parseRelateAccountInfoErr != nil {
		logs.CtxError(ctx, "ParseRelateAccountInfoFail, err:%v", parseRelateAccountInfoErr)
	}
	// 报价单数据处理
	accountIdList := strings.Split(manageInfo.QuoteAccountID, ",")
	pricingAccountIDList := strings.Split(manageInfo.PricingAccountID, ",")
	sealAccountIDList := strings.Split(manageInfo.SealAccountID, ",")
	accountIdList = append(accountIdList, sealAccountIDList...)
	accountIdList = append(accountIdList, pricingAccountIDList...)
	accountIdList = utils.SingleList(accountIdList)
	endUserList := strings.Split(manageInfo.EndUser, ",")
	endUserIDList := strings.Split(manageInfo.EndUserAccountID, ",")
	// 查询所有账号信息
	accountInfoMap, err := accountcli.GetAccountAndVerifyListFromCache(ctx, accountIdList)
	if err != nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, accountID=%d, err=%s", accountIdList, err.Error())
		return nil, i18nfmt.Errorf(ctx, "变更报价单信息,查询报价单账号ID[%v]失败", accountIdList)
	}
	partyMap := map[string][]*accountcli.AccountAndVerifyInfo{}
	for _, accountId := range accountIdList {
		if _, ok := accountInfoMap[accountId]; !ok {
			logs.CtxError(ctx, "GetAccountInfoFromCacheNotFound, accountID=%s", accountId)
			return nil, i18nfmt.Errorf(ctx, "变更报价单信息,查询报价单账号ID[%d]不存在", accountId)
		} else {
			accountInfo := accountInfoMap[accountId]
			if _, ok := partyMap[accountInfo.VerifyName]; !ok {
				partyMap[accountInfo.VerifyName] = []*accountcli.AccountAndVerifyInfo{}
			}
			partyMap[accountInfo.VerifyName] = append(partyMap[accountInfo.VerifyName], accountInfo)
		}
	}
	var verifiedNameList []string
	for verifiedName := range partyMap {
		verifiedNameList = append(verifiedNameList, verifiedName)
	}

	// 更新交易对方信息
	tradePartyInfo := pc.ContractInfo.TradePartyInfo
	if tradePartyInfo == nil {
		tradePartyInfo = &bizmodels.TradePartyInfo{}
	} else if len(tradePartyInfo.GetMainOtherParty()) != 0 && !multienv.IsBytePlus() {
		// 非海外环境执行后面的校验
		if len(tradePartyInfo.GetMainOtherParty()) != len(partyMap) {
			return nil, i18nfmt.Errorf(ctx, "合同对方主体数量,与报价单关联账号实名认证主体[%s]不一致", strings.Join(verifiedNameList, ","))
		}
		for _, v := range tradePartyInfo.OtherParty {
			if v.IsDeputyParty() {
				continue
			}
			if _, ok := partyMap[v.PartyName]; !ok {
				return nil, i18nfmt.Errorf(ctx, "合同对方主体[%s],不在报价单关联账号实名认证主体[%s]内", v.PartyName, strings.Join(verifiedNameList, ","))
			}
		}
	}

	logs.CtxInfo(ctx, "changeTradePartyInfo, VerifiedNameList=%s", strings.Join(verifiedNameList, ","))
	if len(tradePartyInfo.OtherParty) == 0 {
		// 为空时通过报价单中的账号ID的实名认证名称补充合同交易对方信息
		for verifiedName, accountInfos := range partyMap {
			var createSourceList, idList, sealIDList, pricingIDList []string
			var seal, pricing int
			// 交易对方参数准备
			for _, accountInfo := range accountInfos {
				idList = append(idList, strconv.Itoa(int(accountInfo.AccountID)))
				createSourceList = append(createSourceList, strconv.Itoa(int(accountInfo.CreateSource)))
				if utils.StringIn(strconv.Itoa(int(accountInfo.AccountID)), sealAccountIDList) {
					seal = _const.TRUE_FLAG_INT
					sealIDList = append(sealIDList, strconv.Itoa(int(accountInfo.AccountID)))
				}
				if utils.StringIn(strconv.Itoa(int(accountInfo.AccountID)), pricingAccountIDList) {
					pricing = _const.TRUE_FLAG_INT
					pricingIDList = append(pricingIDList, strconv.Itoa(int(accountInfo.AccountID)))
				}
			}
			// 查询主体编码
			mdpartyResp, err := mdparty.GetMdmCodeByName(ctx, verifiedName)
			if err != nil {
				logs.CtxError(ctx, "GetMdmCodeByNameFail, name:%s, err:%v", verifiedName, err)
				return nil, err
			}
			tradePartyInfo.OtherParty = append(tradePartyInfo.OtherParty, &bizmodels.TradePartyInfoDetail{
				AccountID:        strings.Join(utils.SingleList(idList), ","),
				PartyName:        verifiedName,
				PartyNumber:      mdpartyResp.MdmCode,
				CreateSource:     strings.Join(createSourceList, ","),
				Sealed:           seal,
				Pricing:          pricing,
				SealAccountID:    strings.Join(utils.SingleList(sealIDList), ","),
				PricingAccountID: strings.Join(utils.SingleList(pricingIDList), ","),
				// Country:      accountInfo.CountryArea,
			})
		}
	} else if !multienv.IsBytePlus() {
		// 海外环境 当传入交易对方信息时 直接返回
		// 非海外环境执行执行基于 partyMap 构建交易对方流程
		for _, v := range tradePartyInfo.OtherParty {
			// 解析报价单参数时，过滤副签约主体
			if v.IsDeputyParty() {
				continue
			}
			var createSourceList, idList, sealIDList, pricingIDList []string
			var seal, pricing int
			// 参数准备
			for _, accountInfo := range partyMap[v.PartyName] {
				idList = append(idList, strconv.Itoa(int(accountInfo.AccountID)))
				createSourceList = append(createSourceList, strconv.Itoa(int(accountInfo.CreateSource)))
				if utils.StringIn(strconv.Itoa(int(accountInfo.AccountID)), sealAccountIDList) {
					seal = _const.TRUE_FLAG_INT
					sealIDList = append(sealIDList, strconv.Itoa(int(accountInfo.AccountID)))
				}
				if utils.StringIn(strconv.Itoa(int(accountInfo.AccountID)), pricingAccountIDList) {
					pricing = _const.TRUE_FLAG_INT
					pricingIDList = append(pricingIDList, strconv.Itoa(int(accountInfo.AccountID)))
				}
			}
			// 默认添加报价单绑定账号到对方主体内
			v.AccountID = strings.Join(utils.SingleList(idList), ",")
			v.SealAccountID = strings.Join(utils.SingleList(sealIDList), ",")
			v.PricingAccountID = strings.Join(utils.SingleList(pricingIDList), ",")
			v.CreateSource = strings.Join(createSourceList, ",")
			v.Sealed = seal
			v.Pricing = pricing
		}
	}
	for endUser, endUserIDs := range relateAccountInfo[_const.RelateAccountTypeEndUser] {
		endUserIDList = append(endUserIDList, endUserIDs...)
		endUserList = append(endUserList, endUser)
	}
	var firstTierDistributorAccountIDs []string
	if pc.ContractInfo != nil && pc.ContractInfo.BasicInfo != nil &&
		pc.ContractInfo.BasicInfo.BusinessType == _const.BusinessTypeBPDistribution &&
		manageInfo.DistributBusinessType == _const.DistributBusinessTypeSpecial {
		for _, accountIDs := range relateAccountInfo[_const.RelateAccountTypeFirstTierDistributor] {
			firstTierDistributorAccountIDs = append(firstTierDistributorAccountIDs, accountIDs...)
		}
		firstTierDistributorAccountIDs = utils.SingleList(firstTierDistributorAccountIDs)
	}
	// BP分销-账号关联信息赋值
	for _, v := range tradePartyInfo.OtherParty {

		// bp分销场景只给主签约主体的账号关联信息赋值
		if v.IsDeputyParty() {
			continue
		}
		v.RelateAccountInfo = relateAccountInfo
		if len(firstTierDistributorAccountIDs) > 0 {
			v.AccountID = strings.Join(firstTierDistributorAccountIDs, ",")
		} else if pc.ContractInfo != nil && pc.ContractInfo.BasicInfo != nil &&
			pc.ContractInfo.BasicInfo.BusinessType == _const.BusinessTypeBPDistribution &&
			manageInfo.DistributBusinessType == _const.DistributBusinessTypeSpecial {
			logs.CtxWarn(ctx, "FillBPDistributionFirstTierDistributorAccountEmpty, contractNo:%s", pc.ContractInfo.ContractNo)
		}
		// TODO:兼容逻辑，关联报价单合同，海外环境默认为即签约又配价
		if multienv.IsBytePlus() {
			v.Sealed = _const.TRUE_FLAG_INT
			v.SealAccountID = v.AccountID
			v.Pricing = _const.TRUE_FLAG_INT
			v.PricingAccountID = v.AccountID
		}
	}
	tradePartyInfo.RelatePartner = bizInfo.PartnerName
	tradePartyInfo.EndUserAccountID = strings.Join(utils.SingleList(endUserIDList), ",")
	tradePartyInfo.EndUser = strings.Join(utils.SingleList(endUserList), ",")
	return tradePartyInfo, nil
}

// checkTradePartyInfoForQuote 校验交易方相关信息
func (h *handlerCommon) checkTradePartyInfoForQuote(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	tradePartyInfo := pc.ContractInfo.TradePartyInfo
	if tradePartyInfo == nil || len(tradePartyInfo.OtherParty) == 0 {
		return errorsV2.ErrCommon.WithArgs("交易对方信息为空")
	}
	for _, v := range tradePartyInfo.OtherParty {
		if v.AccountID == "" {
			return errorsV2.ErrCommon.WithArgs("交易对方信息AccountID为空")
		}
		arr := strings.Split(v.AccountID, ",")
		for _, idStr := range arr {
			accountID, err := strconv.ParseInt(idStr, 10, 64)
			if err != nil {
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "交易对方信息AccountID[%s]异常", idStr))
			}
			accountInfo, _ := accountcli.GetAccountAndVerifyFromCache(ctx, accountID)
			if accountInfo == nil {
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "交易对方信息AccountID[%d]账号信息不存在", accountID))
			}
			if multienv.IsBytePlus() {
				logs.CtxInfo(ctx, "海外环境不做账号实名校验")
				return nil
			}
			if accountInfo.VerifyName != v.PartyName {
				logs.CtxError(ctx, "交易对方信息AccountID[%s]实名认证名称[%s]与参数信息[%s]不一致", idStr, accountInfo.VerifyName, v.PartyName)
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "交易对方信息AccountID[%s]实名认证名称[%s]与参数信息[%s]不一致", idStr, accountInfo.VerifyName, v.PartyName))
			}
		}
	}
	return nil
}

// checkUsefulLifeTypeForQuote 校验合同有效期
func (h *handlerCommon) checkUsefulLifeTypeForQuote(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	basicInfo := pc.ContractInfo.BasicInfo
	if basicInfo.UsefulLifeType != _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
		logs.CtxInfo(ctx, "UsefulLifeType is not sing time, continue.")
		return nil
	}
	if basicInfo.IndefiniteDateFlag == _const.BizYes {
		logs.CtxError(ctx, "BizCheckUsefulLifeType_fail， IndefiniteDateFlag:%s", basicInfo.IndefiniteDateFlag)
		return errorsV2.ErrCommon.WithArgs("关联报价单的合同不允许长期有效")
	}

	manageInfo := pc.ContractInfo.ManageInfo
	allProductMaps := []map[string][]*bizmodels.ProductInfo{
		manageInfo.ProductLevelMap,
		manageInfo.DeductProductInfoMap,
	}
	for _, productMap := range allProductMaps {
		for _, items := range productMap {
			for _, item := range items {
				if item.ItemType == _const.ONLINE_STANDARD {
					return errorsV2.ErrCommon.WithArgs("报价单中包含·线上标品·，不允许选择·自签订生效·")
				}
			}
		}
	}
	return nil
}

// checkContractDiscount 合同价重复校验：首次重复报错; 二次提交未修改报价单，忽略;  二次提交修改报价单，再次验证;
func (h *handlerCommon) checkContractDiscount(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	contractInfo := pc.ContractInfo
	// 判断是否为首次重复报错
	var changeInfo bizmodels.ChangeQuoteExtra
	if err := json.Unmarshal([]byte(pc.Extra), &changeInfo); err != nil {
		logs.CtxError(ctx, "checkContractDiscount_unmarshalExtraFail, extra=%s, err=%s", pc.Extra, err.Error())
	}
	pc.Extra = "" // 恢复

	// 合同价重复判断
	if contractInfo.TradePartyInfo == nil {
		return errorsV2.ErrCommon.WithArgs("交易双方信息缺失")
	}

	manageInfo := contractInfo.ManageInfo

	isProject := _const.FALSE_FLAG_INT_STR
	if manageInfo.WhetherProject == _const.Yes {
		isProject = _const.TRUE_FLAG_INT_STR
	}

	// 暂定逻辑，当存在多个账号时，任意账号存在重复现象则认为合同价重复
	var skipContractNoList []string
	if contractInfo.SupplyScene != _const.SupplySceneNew {
		// 从火山合同中心查询原合同详情：主合同信息(报价单信息)、原合同信息(报价单信息)
		supplyContractList, err := h.getMetaService(ctx).GetSupplyContractList(ctx, contractInfo.FromContractNo, false)
		if err != nil {
			logs.CtxError(ctx, "GetSupplyContractListFail, from_contract_no=%s, err=%s", contractInfo.FromContractNo, err.Error())
			return errorsV2.ErrInternalError.WithArgs("查询补充协议相关合同信息失败")
		}
		if supplyContractList == nil {
			logs.CtxError(ctx, "GetSupplyContractListFail, from_contract_no=%s", contractInfo.FromContractNo)
			return errorsV2.ErrInternalError.WithArgs("补充协议相关合同信息不存在")
		}
		skipContractNoList = supplyContractList.ParentContractList
	}

	// 拼接list
	var productLevelList []*bizmodels.ProductInfo
	// 标准报价项
	for _, list := range manageInfo.ProductLevelMap {
		productLevelList = append(productLevelList, list...)
	}
	// 抵扣项
	for _, list := range manageInfo.DeductProductInfoMap {
		productLevelList = append(productLevelList, list...)
	}
	var repeatData *modelcommodity.CheckQuoteItemRepeatData
	var err error
	for _, v := range contractInfo.TradePartyInfo.OtherParty {
		arr := strings.Split(v.PricingAccountID, ",")
		beginTime, endTime := pc.ContractInfo.CalcQuoteValidity()

		checkReq := &modelcommodity.CheckQuoteItemRepeatReq{
			AccountIDs:         arr,
			ContractNo:         pc.ContractInfo.ContractNo,
			BizSource:          contractInfo.BizSource,
			QuoteNo:            contractInfo.RelateQuoteNo,
			ProductList:        productLevelList,
			SkipContractNoList: skipContractNoList,
			ValidityBegin:      beginTime,
			ValidityEnd:        endTime,
			IsProject:          isProject,
		}
		// 若合同类型为 BP分销，需传入最终用户信息
		if contractInfo.BasicInfo.BusinessType == _const.BusinessTypeBPDistribution &&
			contractInfo.ManageInfo.DistributBusinessType == _const.DistributBusinessTypeSpecial {
			checkReq.OwnerID = contractInfo.TradePartyInfo.EndUserAccountID
		}
		repeatData, err = h.getMetaServiceV2(ctx).CheckQuoteItemRepeat(ctx, checkReq)
		if err != nil {
			logs.CtxError(ctx, "CheckContractDiscountFail, quoteNo=%s, err=%s", contractInfo.RelateQuoteNo, err.Error())
			return errorsV2.ErrInternalError.WithArgs("合同价[%s]重复校验失败", contractInfo.RelateQuoteNo)
		}
	}

	if repeatData == nil || !repeatData.Repeat {
		return nil
	}

	logs.CtxInfo(ctx, "CheckContractDiscountRepeated, quoteNo=%s, repeatMap=%v", contractInfo.RelateQuoteNo, repeatData)

	// 合同价重复 更新错误信息
	repeatInfo := &bizmodels.ContractPriceRepeatInfoV1{
		QuoteNo:      contractInfo.RelateQuoteNo,
		Repeated:     true,
		Msg:          repeatData.ContractPriceRepeatMsg,
		CommodityMsg: repeatData.CommodityRepeatMsg,
	}

	repeatBody, _ := json.Marshal(repeatInfo)
	pc.ContractInfo.Ext[_const.ExtKeyContractPriceRepeatInfo] = string(repeatBody)

	// 更新合同价重复相关信息
	extNew := &model.ContractMetaExt{
		ContractId: contractInfo.ID,
		AttrKey:    _const.ExtKeyContractPriceRepeatInfo,
		AttrValue:  string(repeatBody),
	}
	if err := h.CreateOrUpdateMetaExt(ctx, pc.GetTx(), extNew); err != nil {
		logs.CtxError(ctx, "CreateOrUpdateMetaExtFail, err:%v", err)
		return errorsV2.ErrInternalError.WithArgs("更新合同价重复信息失败")
	}

	// 合同价重复 记录协作记录 prd_5.1.3
	record := &model.ContractOperationRecordDB{
		PreContractNo:  pc.ContractInfo.ContractNo,
		Operator:       pc.CurrentOperator,
		Operation:      _const.OperationPriceRepeated,
		ContractStatus: pc.ContractInfo.CooperationStatus,
		Remark:         i18nfmt.Sprintf(ctx, "报价单号：%s，与现有报价项重复，重复项：%s", contractInfo.RelateQuoteNo, string(repeatBody)),
	}

	if err := dal.NewContractOperationRecordDao().Create(ctx, pc.GetTx(), record); err != nil {
		logs.CtxError(ctx, "createOpRecordFail, err:%s", err.Error())
		return errorsV2.ErrInternalError.WithArgs("创建操作记录失败")
	}

	// 忽略合同价重复时，不返回错误信息, 清空合同重复合同关联报价信息
	if changeInfo.IgnorePriceRepeatReturn {
		if err := ClearContractRepeatQuote(ctx, pc, GetCommodityRepeatMsgMap(ctx, repeatData, contractInfo.RelateQuoteNo)); err != nil {
			logs.CtxError(ctx, "ClearContractRepeatQuoteFail, err:%v", err)
			return err
		}
		return nil
	}

	return errorsV2.ErrQuoteDuplicated.WithArgs(string(repeatBody))
}

func GetCommodityRepeatMsgMap(ctx context.Context, c *modelcommodity.CheckQuoteItemRepeatData, quoteNo string) map[string]map[string]string {
	// 合同号-账号-重复项
	resMap := map[string]map[string]bizmodels.ContractDiscountList{}
	for accountId, commodityMap := range c.CommodityRepeatInfo {
		for _, commodityData := range commodityMap {
			for _, previous := range commodityData.PreviousList {
				// 是否存在
				repeatMap, ok := resMap[previous.ContractNo]
				if !ok {
					repeatMap = map[string]bizmodels.ContractDiscountList{}
					resMap[previous.ContractNo] = repeatMap
				}
				repeatList, ok := repeatMap[accountId]
				if !ok {
					repeatList = []*bizmodels.ContractDiscount{}
				}
				repeatList = append(repeatList, previous)
				repeatMap[accountId] = repeatList
			}
		}
	}
	res := map[string]map[string]string{}
	for contractNo, repeatMap := range resMap {
		repeat := map[string]string{}
		for accountId, repeatList := range repeatMap {
			repeat[accountId] = GenRepeatProductMsg(ctx, repeatList, quoteNo)
		}
		res[contractNo] = repeat
	}
	return res
}

func GenRepeatProductMsg(ctx context.Context, c bizmodels.ContractDiscountList, quoteID string) string {
	var buf bytes.Buffer
	buf.WriteString(multienv.I18nFormat(ctx, "报价单["))
	buf.WriteString(quoteID)
	buf.WriteString(multienv.I18nFormat(ctx, "]存在如下重复报价项："))

	for idx, v := range c {
		if v == nil {
			continue
		}

		buf.WriteString(fmt.Sprintf("%d: ", idx+1))
		// buf.WriteString(multienv.I18nFormat(ctx, "合同["))
		// buf.WriteString(v.ContractNo)
		// buf.WriteString("],")

		if len(v.DeductList) > 0 {
			// 主子层级展示
			buf.WriteString(multienv.I18nFormat(ctx, "报价项"))
			buf.WriteString(formatDiscount(ctx, v))
			buf.WriteString(multienv.I18nFormat(ctx, "，包含重复节省计划抵扣项："))
			for subIdx, subV := range v.DeductList {
				buf.WriteString(fmt.Sprintf("(%d.%d) ", idx+1, subIdx+1))
				buf.WriteString(formatDiscount(ctx, subV))
				if subIdx < len(v.DeductList)-1 {
					buf.WriteString("； ")
				}
			}
		} else {
			// 普通平铺展示
			buf.WriteString(formatDiscount(ctx, v))
		}
		buf.WriteString("； ")
	}
	if buf.Len() == 0 {
		return ""
	}
	duplicatedInfo := buf.String()
	duplicatedInfo = strings.ReplaceAll(duplicatedInfo, "\\", "\\\\")
	duplicatedInfo = strings.ReplaceAll(duplicatedInfo, "\"", "\\\"")
	return duplicatedInfo
}

func formatDiscount(ctx context.Context, v *bizmodels.ContractDiscount) string {
	var prePayRatio, commitFeeInterval, spBuyDuration string
	if v.Extra != nil && v.Extra.SavingPlan != nil {
		prePayRatio = v.Extra.SavingPlan.PrePayRatio
		commitFeeInterval = v.Extra.SavingPlan.CommitFeeInterval
		spBuyDuration = v.Extra.SavingPlan.SpBuyDuration
	}

	var b bytes.Buffer
	b.WriteString(multienv.I18nFormat(ctx, "商品["))
	b.WriteString(v.Product)
	b.WriteString(multienv.I18nFormat(ctx, "],付费方式为["))
	b.WriteString(v.PayType)
	b.WriteString(multienv.I18nFormat(ctx, "],配置分类为["))
	b.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ConfigurationCategory, v.ConfigurationCategoryExcludeName))
	b.WriteString(multienv.I18nFormat(ctx, "],配置["))
	b.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.Configuration, v.ConfigurationExcludeName))
	b.WriteString(multienv.I18nFormat(ctx, "],计费项分类["))
	b.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ChargeItemTag, v.ChargeItemTagExcludeName))
	b.WriteString(multienv.I18nFormat(ctx, "],计费方式["))
	b.WriteString(v.BillingName)
	b.WriteString(multienv.I18nFormat(ctx, "],地域["))
	b.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.RegionCode, v.RegionExcludeName))
	b.WriteString(multienv.I18nFormat(ctx, "],计费单元["))
	b.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ChargeElementCode, v.ChargeElementExcludeName))
	b.WriteString(multienv.I18nFormat(ctx, "],价格影响因子["))
	b.WriteString(v.PriceFactor)
	b.WriteString(multienv.I18nFormat(ctx, "],售卖模式["))
	b.WriteString(v.SellingMode)
	b.WriteString(multienv.I18nFormat(ctx, "],预付比例["))
	b.WriteString(prePayRatio)
	b.WriteString(multienv.I18nFormat(ctx, "],承诺消费金额["))
	b.WriteString(commitFeeInterval)
	b.WriteString(multienv.I18nFormat(ctx, "],购买时长["))
	b.WriteString(spBuyDuration)
	b.WriteString("]")
	return b.String()
}

func BuildConfigurationSummaryDesc(ctx context.Context, title, value, exclude string) string {
	title = multienv.I18nFormat(ctx, title)
	value = ReplaceQuoteOptionDesc(ctx, value)
	var res = value
	// 默认格式
	if len(title) > 0 {
		res = fmt.Sprintf("%s: %s", title, value)
	}
	// 若排除项不为空，需拼接排除信息
	if len(exclude) > 0 {
		exclude = strings.ReplaceAll(exclude, ",", "、")
		res = i18nfmt.Sprintf(ctx, "%s（不包含 %s）", res, exclude)
	}
	return res
}

func ReplaceQuoteOptionDesc(ctx context.Context, option string) string {
	switch option {
	case "*":
		return multienv.I18nFormat(ctx, "所有选项")
	default:
		return option
	}
}

// checkPreCheckContractDiscount 合同价预校验接口 请求合同中心SDK
func (h *handlerCommon) checkPreCheckContractDiscount(ctx context.Context, meta *model.ContractMeta) error {
	logs.CtxInfo(ctx, "[checkPreCheckContractDiscount] start")

	manageBody, _ := json.Marshal(meta.ManageInfo)
	var reqManage bizmodels.ManageInfo
	if err := json.Unmarshal(manageBody, &reqManage); err != nil {
		logs.CtxInfo(ctx, "[checkPreCheckContractDiscount]parseManageInfoFail, err=%s", err.Error())
		return err
	}
	basicBody, _ := json.Marshal(meta.BasicInfo)
	var reqBasicInfo bizmodels.BasicInfo
	if err := json.Unmarshal(basicBody, &reqBasicInfo); err != nil {
		logs.CtxInfo(ctx, "[checkPreCheckContractDiscount]parseBasicInfoFail, err=%s", err.Error())
		return err
	}
	tradePartyBody, _ := json.Marshal(meta.TradePartyInfo)
	var reqTradePartyInfo bizmodels.TradePartyInfo
	if err := json.Unmarshal(tradePartyBody, &reqTradePartyInfo); err != nil {
		logs.CtxInfo(ctx, "[checkPreCheckContractDiscount]parseTradePartyInfoFail, err=%s", err.Error())
		return err
	}

	var accountIDList []string
	if meta.TradePartyInfo != nil {
		for _, v := range meta.TradePartyInfo.OtherParty {
			ids := strings.Split(v.PricingAccountID, ",")
			for _, vv := range ids {
				if vv != "" {
					accountIDList = append(accountIDList, vv)
				}
			}
		}
		accountIDList = utils.SingleList(accountIDList)
	}

	logs.CtxInfo(ctx, "accountIDList=%v", accountIDList)

	beginTime, endTime := meta.CalcQuoteValidity()

	req := &modelcommodity.PreCheckCreateContractPriceReq{
		CurrentOperator: meta.Operator,
		ContractNo:      meta.ContractNo,
		FromContractNo:  meta.FromContractNo,
		AccountIDs:      accountIDList,
		ContractName:    meta.ContractName,
		Operator:        meta.Operator,
		SubjectName:     meta.SubjectName,
		SupplyScene:     meta.SupplyScene,
		QuoteNo:         meta.RelateQuoteNo,
		ValidityBegin:   beginTime,
		ValidityEnd:     endTime,
		ManageInfo:      &reqManage,
		BasicInfo:       &reqBasicInfo,
		TradePartyInfo:  &reqTradePartyInfo,
	}

	resp, err := h.getMetaServiceV2(ctx).PreCheckCreateContractPrice(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[checkPreCheckContractDiscount]Fail, err=%s", err.Error())
		return i18nfmt.New(ctx, "合同价预校验失败")
	}
	if resp == nil {
		logs.CtxError(ctx, "[checkPreCheckContractDiscount]response is nil")
		return i18nfmt.New(ctx, "PreCheckCreateContractPriceRespIsNil")
	}
	if !resp.Success {
		logs.CtxError(ctx, "[checkPreCheckContractDiscount]response msg =%s", resp.Msg)
		return i18nfmt.New(ctx, "合同价预校验失败")
	}
	return nil
}

// clearSendBackStatusQuoteAndReviewers 退回到[已退回]状态时，清理报价单关联商品信息，并仅保留申请人审批权限。
func (h *handlerCommon) clearSendBackStatusQuoteAndReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc == nil || pc.StatusChangedValue != _const.PreSalesContractSendBack {
		return nil
	}
	if pc.ContractInfo != nil && pc.ContractInfo.NeedRelateQuoteNo() {
		logs.CtxInfo(ctx, "clearSendBackStatusQuoteAndReviewers, relationQuoteNo:%s, relationScene:%d", pc.ContractInfo.RelateQuoteNo, pc.ContractInfo.RelateQuoteScene)
		if err := h.getCommodityService(ctx).ClearQuoteRelatedData(ctx, pc.GetTx(), &metacommodity.ClearQuoteRelatedDataReq{
			Scene:      metacommodity.QuoteCleanupSceneSendBack,
			Meta:       pc.PreContractVO,
			ManageInfo: pc.ContractInfo.ManageInfo,
		}); err != nil {
			return err
		}
	}

	// 退回到[已退回]状态时，仅保留申请人权限
	err := dal.NewPreContractReviewerDao().DeleteReviewersByType(ctx, pc.GetTx(), pc.PreContractNo, []int{
		_const.ReviewerTypeFinanceTaxationLegalReviewer,
		_const.ReviewerTypeSalesOperation,
		_const.ReviewerTypeSolutionReviewer,
	})
	if err != nil {
		logs.CtxError(ctx, "重置审批人员失败, err:%s", err.Error())
		return err
	}

	return nil
}

// handleQuoteChangeWhenSubmit 提交时，如果报价单发生变更，则更新合同价重复缓存
func (h *handlerCommon) handleQuoteChangeWhenSubmit(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if pc.ContractInfo.BasicInfo == nil {
		return nil
	}
	// 不需要关联报价单场景，不需要处理
	if !pc.ContractInfo.NeedRelateQuoteNo() {
		return nil
	}
	// 通知报价系统绑定、解绑合同 出错时 仅提供报报警
	quoteNo := pc.ContractInfo.RelateQuoteNo
	if len(quoteNo) == 0 {
		return nil
	}

	_, err := quotecli.ChangeQuoteContract(ctx, pc.RelateQuoteChangeBeforeValue, pc.ContractInfo.RelateQuoteNo, pc.ContractInfo.ContractNo)
	if err != nil {
		return err
	}

	return nil
}

// validateSupply 校验补充协议场景下相关逻辑
func (h *handlerCommon) validateSupply(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	contractDB := pc.PreContractVO

	// 仅校验补充协议场景
	if len(contractDB.SupplySource) == 0 {
		pc.PreContractVO.MainContractNo = pc.PreContractVO.ContractNo
		pc.ContractInfo.MainContractNo = pc.PreContractVO.ContractNo
		return nil
	}

	logs.CtxInfo(ctx, "validateSupplyScene_start, contract_no=%s, from_contract_no=%s, supply_scene=%d", contractDB.ContractNo, contractDB.SupplyScene)

	if contractDB.FromContractNo == "" {
		return errorsV2.ErrCommon.WithArgs("原合同号不能为空")
	}

	// 从火山合同中心查询原合同详情：主合同信息(报价单信息)、原合同信息(报价单信息)
	supplyContractList, err := h.getMetaService(ctx).GetSupplyContractList(ctx, contractDB.FromContractNo, false)
	if err != nil {
		logs.CtxError(ctx, "GetSupplyContractListFail, from_contract_no=%s, err=%s", contractDB.FromContractNo, err.Error())
		return errorsV2.ErrCommon.WithArgs("查询补充协议相关合同信息失败")
	}
	if supplyContractList == nil {
		logs.CtxError(ctx, "GetSupplyContractListFail, from_contract_no=%s", contractDB.FromContractNo)
		return errorsV2.ErrCommon.WithArgs("补充协议相关合同信息不存在")
	}

	if supplyContractList.FromContract != nil {
		mainContractNo := supplyContractList.FromContract.MainContractNo
		if len(mainContractNo) == 0 {
			mainContractNo = supplyContractList.FromContract.ContractNo
		}
		pc.ContractInfo.MainContractNo = mainContractNo
		pc.PreContractVO.MainContractNo = mainContractNo
		// 补全产解行解、涉及资源方、交付人员、一级产品线
		if err := h.fillSupplyExtInfoByFromContractInfo(ctx, pc, supplyContractList.FromContract); err != nil {
			return errorsV2.ErrCommon.WithArgs("填充补充协议信息失败")
		}
	}
	supplyService := supply.NewSupplyService()
	quoteNo := pc.PreContractVO.RelateQuoteNo
	if pc.OperationState == _const.OperationChangeQuoteNo {
		var changeInfo bizmodels.ChangeQuoteExtra
		if err := json.Unmarshal([]byte(pc.Extra), &changeInfo); err != nil {
			return errorsV2.ErrCommon.WithArgs("解析合同变更信息失败")
		}
		quoteNo = changeInfo.QuoteID
	}
	err = supplyService.ValidateBase(ctx, quoteNo, contractDB, supplyContractList)
	if err != nil {
		return err
	}
	logs.CtxInfo(ctx, "仅可定稿与销售运营完善信息节点进行补充协议有效期校验，当前节点【%v】", pc.ContractInfo.CooperationStatus)
	if utils.IntIn(pc.ContractInfo.CooperationStatus, []int{_const.PreSalesContractSalesOperationCompleteInformation, _const.PreSalesContractCustomerConfirm}) &&
		pc.OperationState != _const.OperationChangeQuoteNo {
		err = supplyService.ValidateValidityTime(ctx, quoteNo, contractDB, supplyContractList)
		if err != nil {
			return err
		}
		return nil
	}

	return nil
}

// 补全产解行解、涉及资源方、交付人员、一级产品线 https://bytedance.larkoffice.com/wiki/F3HKwK3xYiw5x2kPl4uclhTan2b
func (h *handlerCommon) fillSupplyExtInfoByFromContractInfo(ctx context.Context, pc *auditmodel.ProcessCtx, fromContractInfo *bizmodels.ContractMetaInfo) error {
	if fromContractInfo == nil {
		return nil
	}
	// 关联报价单时，一级产品线、产解行解、涉及资源方从报价单取值，在后续流程中处理
	if pc.PreContractVO.RelateQuoteNo == "" {
		// 此处仅处理未关联报价单的情况
		// 一级产品线处理
		fromManageInfo := fromContractInfo.ManageInfo
		if fromManageInfo != nil && fromManageInfo.BelongingDepartment != "" {
			pc.UpdateBelongingDepartment(fromManageInfo.BelongingDepartment, false)
		}
		// 产解行解处理
		fromProjectInfo := fromContractInfo.ProjectInfo
		if fromProjectInfo != nil && fromProjectInfo.HasProductSolutionEmail() {
			pc.UpdateProductSolutionEmail(fromProjectInfo.ProductSolutionEmail, false)
		}
		// 涉及资源方处理
		if fromProjectInfo != nil && fromProjectInfo.HasRelatedResDepartment() {
			pc.UpdateRelatedResDepartment(fromProjectInfo.RelatedResDepartment, false)
		}
		// 交付人员
		if fromProjectInfo != nil && fromProjectInfo.HasDeliveryStaff() {
			pc.UpdateDeliveryStaff(fromProjectInfo.DeliveryStaff, false)
		}
	}
	return nil
}

// validateTradePartyInfo 校验交易方信息
func validateTradePartyInfo(ctx context.Context, basicInfo *bizmodels.BasicInfo, tradePartyInfo *bizmodels.TradePartyInfo) error {
	if err := tradePartyInfo.CheckSignData(basicInfo.SignatureType); err != nil {
		logs.CtxError(ctx, "CheckSignDataFail, err=%s", err.Error())
		return err
	}
	// 是否盖章，是否归档字段合理性校验
	if err := tradePartyInfo.Validate(ctx, basicInfo.InOutType); err != nil {
		return err
	}
	// 先盖章方，是否盖章，是否归档字段合理性校验
	if err := tradePartyInfo.SealOrderCheck(basicInfo.SealOrder); err != nil {
		return err
	}
	// 银行账号信息校验，目前仅直连飞书的合同执行此校验
	if basicInfo.IsFeishu {
		if err := tradePartyInfo.CheckPayTypes(); err != nil {
			return err
		}
	}
	return nil
}

// validateAccountIdRequired 账号ID必填校验
func validateAccountIdRequired(ctx context.Context, contractInfo *model.ContractMeta) errorsV2.APIError {
	logs.CtxInfo(ctx, "validateAccountIdRequired, InOutType:%s, BizSource:%d", contractInfo.InOutType, contractInfo.BizSource)
	if (contractInfo.InOutType == _const.IN || contractInfo.InOutType == _const.InAndOut) &&
		contractInfo.BizSource != _const.BizSourceQuote {
		if contractInfo.TradePartyInfo == nil {
			return errorsV2.ErrCommon.WithArgs("当合同收支类型为“收入类” / “既收又支”时，对方账户id必填")
		}
		for _, subjectParty := range contractInfo.TradePartyInfo.Subject {
			// 海外环境 存在交易我方的注册国家/地区 ≠ 中国大陆时，交易对方账号 ID 必填
			if (multienv.IsBytePlus() && subjectParty.Country != "CN" && subjectParty.Country != "MDCT00000040") ||
				// 非海外环境 存在我方是中国大陆时，对方账号ID必填
				(!multienv.IsBytePlus() && (subjectParty.Country == "CN" || subjectParty.Country == "MDCT00000040")) {
				// 对方账号ID必填
				for _, party := range contractInfo.TradePartyInfo.OtherParty {
					// 仅校验主签约主体账号
					if party.IsDeputyParty() {
						continue
					}
					if party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0 {
						return errorsV2.ErrCommon.WithArgs("签约主体-签约主体账户id必填")
					}
					if party.Pricing == _const.TRUE_FLAG_INT && len(party.PricingAccountID) == 0 {
						return errorsV2.ErrCommon.WithArgs("配价主体-配价主体账户id必填")
					}
				}
				break // 校验结束 跳出循环
			}
		}
	}
	// “特殊合同类型 包含 我方主体变更协议”时，对方主体的账号ID必填。
	specialContractTypes := strings.Split(contractInfo.BasicInfo.SpecialContractType, ",")
	if util.StringIn(_const.SpecialContractTypeSubjectChangeAgreement, specialContractTypes) {
		for _, party := range contractInfo.TradePartyInfo.OtherParty {
			// 仅校验主签约主体账号
			if party.IsDeputyParty() {
				continue
			}
			if party.Sealed == _const.TRUE_FLAG_INT && len(party.SealAccountID) == 0 {
				return errorsV2.ErrCommon.WithArgs("签约主体-签约主体账户id必填")
			}
			if party.Pricing == _const.TRUE_FLAG_INT && len(party.PricingAccountID) == 0 {
				return errorsV2.ErrCommon.WithArgs("配价主体-配价主体账户id必填")
			}
		}
	}
	return nil
}

// validateTermChangeDetail 条款变更字段校验
func validateTermChangeDetail(ctx context.Context, tx *gorm.DB, contractVO *model.ContractMetaDB) error {
	// 补充场景为空时
	if len(contractVO.SupplySource) == 0 {
		logs.CtxInfo(ctx, "合同非补充协议")
		return nil
	}
	// 补充场景不包含条款变更
	if !utils.StringIn(_const.SupplySourceTermChange, contractVO.GetSupplySource()) {
		logs.CtxInfo(ctx, "合同补充场景不包含条款变更")
		return nil
	}
	extDB, err := dal.NewContractMetaExtDao().FindByAttrKey(ctx, tx, int64(contractVO.Id), _const.ExtKeyTermChangeDetail)
	if err != nil {
		logs.CtxError(ctx, "FindMetaExtByAttrKeyFail， err:%v", err)
		return errorsV2.ErrCommon.WithArgs("FindMetaExtByAttrKeyFail")
	}
	if extDB == nil || len(extDB.AttrValue) == 0 {
		logs.CtxError(ctx, "合同补充场景包含条款变更，条款变更详情必填。")
		return errorsV2.ErrInternalError.WithArgs("合同补充场景包含条款变更，条款变更详情必填。")
	}
	return nil
}

// validateProjectInfo 项目信息校验
func validateProjectInfo(ctx context.Context, contractInfo *model.ContractMeta) error {
	// 关联报价单合同不执行项目制信息校验
	if contractInfo.RelateQuoteNo != "" {
		logs.CtxInfo(ctx, "合同关联了报价单，不执行项目制信息校验。ContractNo:%s, RelateQuoteNo:%s", contractInfo.ContractNo, contractInfo.RelateQuoteNo)
		return nil
	}
	// 收支类型 = 收入类 / 既收又支。 是否项目制 = 是
	// 关联报价单无值时，“项目编号”、“项目制立项流程”、“项目制报价编号”、“项目制报价流程”必填。关联报价单场景为未完成报价审批/无需报价或线下报价时，不执行项目制信息校验。
	var missingFields []string
	if utils.StringIn(contractInfo.InOutType, []string{_const.IN, _const.InAndOut}) && contractInfo.BasicInfo.WhetherProject == _const.Yes {
		if utils.IntIn(contractInfo.RelateQuoteScene, []int{_const.RelateQuoteSceneNoCompleted, _const.RelateQuoteSceneNoRequired}) {
			logs.CtxInfo(ctx, "报价单未完成报价审批/无需报价或线下报价，不执行项目制信息校验。ContractNo:%s, RelateQuoteScene:%d", contractInfo.ContractNo, contractInfo.RelateQuoteScene)
			return nil
		}
		if len(contractInfo.ProjectInfo.QuoteID) == 0 {
			missingFields = append(missingFields, "项目制报价单编号")
		}
		if len(contractInfo.ProjectInfo.QuoteApprovalLink) == 0 {
			missingFields = append(missingFields, "项目制报价流程")
		}
		if len(contractInfo.ProjectInfo.ProjectCode) == 0 {
			missingFields = append(missingFields, "项目编号")
		}
		if len(contractInfo.ProjectInfo.ProjectApprovalLink) == 0 {
			missingFields = append(missingFields, "项目制立项流程")
		}
	}
	// 收支类型 = 支出类 / 无收无支。 是否项目制 = 是
	// “项目编号”、“项目制立项流程”必填。
	if utils.StringIn(contractInfo.InOutType, []string{_const.OUT, _const.NoInNoOut}) && contractInfo.BasicInfo.WhetherProject == _const.Yes {
		if len(contractInfo.ProjectInfo.ProjectCode) == 0 {
			missingFields = append(missingFields, "项目编号")
		}
		if len(contractInfo.ProjectInfo.ProjectApprovalLink) == 0 {
			missingFields = append(missingFields, "项目制立项流程")
		}
	}
	if len(missingFields) > 0 {
		return errorsV2.ErrMissingParam.WithArgs(strings.Join(missingFields, "、"))
	}
	return nil
}

// validateRiskClauseRole 校验风险条款全部通过
func validateRiskClauseRole(ctx context.Context, tx *gorm.DB, contractNo string) error {
	meta, err := dal.NewContractMetaDao().FindByNoForSales(ctx, tx, contractNo)
	if err != nil {
		logs.CtxError(ctx, "validateRiskClauseRole_FindMetaFail, err:%v", err)
		return err
	}
	if meta == nil {
		return errors.New("校验风险条款失败")
	}
	riskRoleList, err := dal.NewRiskClauseRoleDao().ListByVolcContractId(ctx, tx, int64(meta.Id))
	if err != nil {
		logs.CtxError(ctx, "validateRiskClauseRole_ListRiskRoleFail, err:%v", err)
		return err
	}
	if len(riskRoleList) == 0 {
		return nil
	}
	for _, role := range riskRoleList {
		// 结算条款状态非审批通过&已关闭
		if !utils.IntIn(role.Status, []int{_const.PassRiskRoleStatus, _const.CloseRiskRoleStatus}) {
			return errorsV2.ErrCommon.WithArgs("存在未审批通过的风险条款，不允许提交")
		}
	}
	return nil
}

// validateAccountAssociationInfo 校验账号分组信息
func validateAccountAssociationInfo(ctx context.Context, manageInfo *bizmodels.ManageInfo, tradePartyInfo *bizmodels.TradePartyInfo) error {
	// 在线协同合同 调整账号，校验账号分组信息
	manageAccountMap := map[string]string{}
	tradeAccountMap := map[string]string{}
	priceAccountMap := map[string]string{}

	// 合并商品行分组和抵扣项分组的 Key
	allProductGroupKeys := map[string]struct{}{}
	for k := range manageInfo.ProductLevelMap {
		allProductGroupKeys[k] = struct{}{}
	}
	for k := range manageInfo.DeductProductInfoMap {
		allProductGroupKeys[k] = struct{}{}
	}

	// 商品行分组数 与 账号ID分组信息数量不匹配
	if len(allProductGroupKeys) != len(manageInfo.AccountAssociationInfo) {
		logs.CtxError(ctx, "商品行分组信息商品行信息分组数量不匹配, allProductGroupKeys:%d, AccountAssociationInfo:%d", len(allProductGroupKeys), len(manageInfo.AccountAssociationInfo))
		return errorsV2.ErrCommon.WithArgs("商品行分组信息异常")
	}

	// 商品行分组信息 与 账号分组信息 需一致
	for key, accountIds := range manageInfo.AccountAssociationInfo {
		if _, ok := allProductGroupKeys[key]; !ok {
			logs.CtxError(ctx, "商品行分组信息商品行信息分组标识不匹配, key:%s", key)
			return errorsV2.ErrCommon.WithArgs("商品行分组信息异常")
		}

		if len(accountIds) == 0 {
			return errorsV2.ErrCommon.WithArgs("每个商品行类别必须关联账号ID")
		}
		for _, accountID := range strings.Split(accountIds, ",") {
			if len(accountID) == 0 {
				continue
			}
			manageAccountMap[accountID] = ""
		}
	}

	for _, party := range tradePartyInfo.OtherParty {
		for _, accountID := range strings.Split(party.PricingAccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			priceAccountMap[accountID] = ""
			tradeAccountMap[accountID] = ""
		}
		for _, accountID := range strings.Split(party.SealAccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			tradeAccountMap[accountID] = ""
		}
		// 兜底逻辑，保证能拿到所有账号
		for _, accountID := range strings.Split(party.AccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			tradeAccountMap[accountID] = ""
		}
	}

	for accountID := range priceAccountMap {
		if _, ok := manageAccountMap[accountID]; !ok {
			return errorsV2.ErrCommon.WithArgs("配价主体中的账号ID必须全部关联分组")
		}
	}

	for accountID := range manageAccountMap {
		if _, ok := tradeAccountMap[accountID]; !ok {
			return errorsV2.ErrCommon.WithArgs("商品行分组信息中存在异常账号ID")
		}
	}

	return nil
}

// validateUsefulLifeType 校验合同有效期
func validateUsefulLifeType(ctx context.Context, contractVO *model.ContractMetaDB, quoteInfo *quote_client.QuoteRespSimpleInfo, basicInfo *bizmodels.BasicInfo, manageInfo *bizmodels.ManageInfo) errorsV2.APIError {
	// 指定合同有效期
	if basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME ||
		basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		if manageInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
			logs.CtxError(ctx, "合同有效期类型与报价单有效期类型不一致，basicUsefulLifeType:%d, manageUsefulLifeType:%d", basicInfo.UsefulLifeType, manageInfo.UsefulLifeType)
			return errorsV2.ErrCommon.WithArgs("合同有效期类别需要与报价单一致")
		}
		// 合同有效期包含报价单有效期，contractInfo.BeginTime<=info.PriceValidPeriodStartTime && contractInfo.EndTime<info.PriceValidPeriodEndTime
		// 2022-04-07T00:00:00+08:00
		startTime := quoteInfo.PriceValidPeriodStartTime
		endTime := quoteInfo.PriceValidPeriodEndTime

		contractEndTime := contractVO.EndTime
		if contractEndTime.IsZero() {
			return errorsV2.ErrCommon.WithArgs("合同关联了报价单，合同有效期截止日期不能为空")
		}
		if startTime.IsZero() || endTime.IsZero() {
			return errorsV2.ErrCommon.WithArgs("合同关联了报价单，指定有效期不允许有效期为空")
		}
		contractEndTime = utils.ToSecendEndOfDay(contractEndTime)
		// 前端允许结束时间为空，表示不限制结束时间
		if contractVO.BeginTime.Before(startTime) || (!endTime.IsZero() && contractEndTime.After(endTime)) {
			logs.CtxError(ctx, "合同有效期不在报价单有效期范围内2, start=%v, end=%v", contractVO.BeginTime, contractEndTime)
			errMsg := i18nfmt.Sprintf(ctx, "合同有效期不在报价单有效期范围内, 当前合同关联的报价单有效期为：%s ~ %s",
				quoteInfo.PriceValidPeriodStartTime, quoteInfo.PriceValidPeriodEndTime,
			)
			return errorsV2.ErrCommon.WithArgs(errMsg)
		}
	} else if basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
		// 需要与报价单保持一致，有效期单位与有效期数值，合同需小于等于报价单
		if manageInfo.UsefulLifeType != _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
			logs.CtxError(ctx, "UsefulLifeTypeIsDiff, manageType:%d, contractType:%d", manageInfo.UsefulLifeUnit, basicInfo.UsefulLifeUnit)
			return errorsV2.ErrCommon.WithArgs("关联报价单为指定日期生效，合同需与报价单保持一致")
		}
		manageLevel := _const.UsefulLifeUnitLevelMap[manageInfo.UsefulLifeUnit]
		contractLevel := _const.UsefulLifeUnitLevelMap[basicInfo.UsefulLifeUnit]
		if manageLevel < contractLevel {
			errMsg := i18nfmt.Sprintf(ctx, "签订日起生效，报价单有效期单位为%s，合同有效期单位为%s，合同有效期需小于等于报价单有效期",
				manageInfo.UsefulLifeUnit, basicInfo.UsefulLifeUnit)
			return errorsV2.ErrCommon.WithArgs(errMsg)
		} else if manageLevel == contractLevel && manageInfo.UsefulLifeNum < basicInfo.UsefulLifeNum {
			errMsg := i18nfmt.Sprintf(ctx, "签订日起生效，报价单有效期为%d%s，合同有效期为%d%s，合同有效期需小于等于报价单有效期",
				manageInfo.UsefulLifeNum, manageInfo.UsefulLifeUnit, basicInfo.UsefulLifeNum, basicInfo.UsefulLifeUnit)
			return errorsV2.ErrCommon.WithArgs(errMsg)
		}
	} else {
		return errorsV2.ErrCommon.WithArgs("暂不支持的有效期类型")
	}
	return nil
}

func validateManageInfo(ctx context.Context, contractVO *model.ContractMeta, manageInfo *bizmodels.ManageInfo) errorsV2.APIError {
	if contractVO == nil || manageInfo == nil {
		return nil
	}
	if contractVO.Initiator == _const.InitiatorSelfPurchase {
		// 目前仅针对自采合同场景新增校验
		if manageInfo.RelatedPersonnel == "0" {
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "管理信息相关人员信息异常, RelatedPersonnel=%s", manageInfo.RelatedPersonnel))
		}
		if manageInfo.LegalReviewer == "0" {
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "管理信息法务审核人信息异常, LegalReviewer=%s", manageInfo.LegalReviewer))
		}
	}
	return nil
}

func validateMetaExt(ctx context.Context, contractInfo *model.ContractMeta, meta *model.ContractMetaDB, extMap map[string]string) errorsV2.APIError {
	// 校验保底信息
	if err := guarantee.ValidateGuaranteeRuleValidity(ctx, meta,
		fetchValidateExtData(contractInfo.Ext, extMap, _const.ExtKeyQuoteGuaranteeItems),
		fetchValidateExtData(contractInfo.Ext, extMap, _const.ExtKeyQuoteGuarantee)); err != nil {
		logs.CtxError(ctx, "校验保底信息失败，err:%v", err)
		return err
	}
	return nil
}

// fetchValidateExtData 获取需要校验的附加信息数据
func fetchValidateExtData(contract, external map[string]string, extKey string) string {
	// 优先取外部入参的数据
	if value, ok := external[extKey]; ok {
		return value
	}
	// 外部入参中不包含时，取当前合同关联参数
	if value, ok := contract[extKey]; ok {
		return value
	}
	return ""
}

// GetTemplateFileId 获取模板生成合同文本的文件ID
func GetTemplateFileId(ctx context.Context, pc *auditmodel.ProcessCtx) (string, error) {
	// 合同未关联模板ID，返回原合同文件ID
	if len(pc.PreContractVO.TemplateInfo) == 0 {
		logs.CtxInfo(ctx, "contract no relate template.")
		return pc.PreContractVO.ContractFile, nil
	}
	// 获取构建模板合同的参数
	fillData, apiErr := template.NewService().GetContractTemplate(ctx, &bizmodels.TemplateReplaceReq{
		CurrentOperator: pc.CurrentOperator,
		ContractNo:      pc.PreContractVO.PreContractNo,
		FullData:        ConvertFullData(pc.PreContractVO, pc.ContractInfo.ManageInfo, pc.Ext),
		TextParam:       pc.TextParam,
		TableParam:      pc.TableParam,
	})
	if apiErr != nil {
		logs.CtxError(ctx, "GetTemplateReplaceMapFail, err:%v", apiErr)
		return "", apiErr
	}
	// 更新合同关联文本-上传至文件管理系统
	fileId, err := UploadFileVolc(ctx, pc, fillData)
	if err != nil {
		logs.CtxError(ctx, "UploadFileVolcFail, err:%v", err)
		return "", err
	}
	// 给创建人加权限
	if err := updateTemplateFilePermission(ctx, fileId, pc); err != nil {
		logs.CtxError(ctx, "UpdateUserPermissionFail, CurrentOperator:%s, err:%v", pc.CurrentOperator, err)
		return "", err
	}
	return fileId, nil
}

func ConvertFullData(db *model.ContractMetaDB, manageData *bizmodels.ManageInfo, ext map[string]string) *bizmodels.ContractFullData {
	basicInfo := &bizmodels.BasicInfo{}
	_ = json.Unmarshal([]byte(db.BasicInfo), &basicInfo)
	tradePartyInfo := &bizmodels.TradePartyInfo{}
	_ = json.Unmarshal([]byte(db.TradePartyInfo), &tradePartyInfo)
	reverseSignInfo := &bizmodels.ReverseSignInfo{}
	_ = json.Unmarshal([]byte(db.ReverseSignInfo), &reverseSignInfo)
	templateInfo := &bizmodels.TemplateInfo{}
	_ = json.Unmarshal([]byte(db.TemplateInfo), &templateInfo)
	manageInfo := ConvertManageInfo(manageData)

	if tradePartyInfo.OtherParty == nil {
		tradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{}
	}
	if tradePartyInfo.Subject == nil {
		tradePartyInfo.Subject = []*bizmodels.TradePartyInfoDetail{}
	}
	var accountIDs, sealAccountIDs, priceAccountIDs []string
	var otherPartyNames []string
	var subjectNames []string
	for _, v := range tradePartyInfo.OtherParty {
		if v.PayTypes == nil {
			v.PayTypes = []*bizmodels.PayType{}
		}
		if v.OpAddress == nil {
			v.OpAddress = []bizmodels.OpAddress{}
		}
		otherPartyNames = append(otherPartyNames, v.PartyName)
		subAccountIds := strings.Split(v.AccountID, ",")
		accountIDs = append(accountIDs, utils.SingleList(subAccountIds)...)
		sealAccountIDs = append(sealAccountIDs, strings.Split(v.SealAccountID, ",")...)
		priceAccountIDs = append(priceAccountIDs, strings.Split(v.PricingAccountID, ",")...)
	}
	for _, v := range tradePartyInfo.Subject {
		if v.PayTypes == nil {
			v.PayTypes = []*bizmodels.PayType{}
		}
		if v.OpAddress == nil {
			v.OpAddress = []bizmodels.OpAddress{}
		}
		subjectNames = append(subjectNames, v.PartyName)
	}
	if basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		basicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
		basicInfo.IndefiniteDateFlag = _const.BizNo
	}

	ret := &bizmodels.ContractFullData{
		BizScene:                   db.BizScene,                   // 业务来源
		BizSource:                  db.BizSource,                  // 合同来源
		SupplyScene:                db.SupplyScene,                // 补充协议分类
		SupplySource:               db.SupplySource,               // 补充场景
		Initiator:                  db.Initiator,                  // 发起端
		ContractNo:                 db.ContractNo,                 // 合同号
		Version:                    db.Version,                    // 版本
		OaContractNo:               db.OaContractNo,               // 提交签章生成的合同号
		PreContractNo:              db.PreContractNo,              // 临时合同号
		FromContractNo:             db.FromContractNo,             // 原合同号
		MainContractNo:             db.MainContractNo,             // 主合同号
		OaAppId:                    db.OAAppID,                    // 提交签章的 AppID，历史对接的 OA 系统签约
		SubjectNo:                  db.SubjectNo,                  // 合同主体编号-交易侧维护的
		Creator:                    db.Creator,                    // 创建人
		Operator:                   db.Operator,                   // 业务执行人工号
		CreatorNew:                 db.CreatorNew,                 // 创建人
		OperatorNew:                db.OperatorNew,                // 业务执行人工号
		PropertyCode:               db.PropertyCode,               // 合同性质
		InOutType:                  db.InOutType,                  // 收支类型
		CategoryNo:                 db.CategoryNo,                 // 合同分类编码
		SignatureType:              db.SignatureType,              // 签约形式
		SpecialContractType:        db.SpecialContractType,        // 特殊合同类型
		ContractName:               db.ContractName,               // 合同名称
		BeginTime:                  db.BeginTime,                  // 开始时间
		EndTime:                    db.EndTime,                    // 结束时间
		SubmitTime:                 db.SubmitTime,                 // 合同提交时间
		VersionCreatedTime:         db.VersionCreatedTime,         // 合同版本创建时间
		SignTime:                   db.SignTime,                   // 合同签订时间
		FileTime:                   db.FileTime,                   // 合同归档时间
		FinishTime:                 db.FinishTime,                 // 合同流程结束时间
		ContractPriceCreatedTime:   db.ContractPriceCreatedTime,   // 合同价创建时间
		FromContractTerminatedTime: db.FromContractTerminatedTime, // 原合同终止日期
		BasicInfo:                  basicInfo,                     // 合同基本信息
		ManageInfo:                 manageInfo,                    // 管理信息
		TradePartyInfo:             tradePartyInfo,                // 交易双方信息
		ReverseSignInfo:            reverseSignInfo,               // 合同倒签信息
		RelateQuoteNo:              db.RelateQuoteNo,              // 关联报价单号
		TemplateInfo:               templateInfo,                  // 模板信息
		ContractTemplateVersion:    db.ContractTemplateVersion,    // 合同模板版本
		ContractFile:               db.ContractFile,               // 合同文件 ID
		ContractAttachment:         db.ContractAttachment,         // 合同附件 ID
		BizIdentifier:              db.BizIdentifier,              // 业务唯一标识
		CooperationStatus:          db.CooperationStatus,          // 协商状态
		PreCooperationStatus:       db.PreCooperationStatus,       // 前序协商状态
		ArchivedStatus:             db.ArchivedStatus,             // 归档状态
		ActiveStatus:               db.ActiveStatus,               // 生效状态
		IsBackdating:               db.IsBackdating,               // 是否倒签
		IsMainContract:             db.IsMainContract,             // 是否主合同
		IsNewest:                   db.IsNewest,                   // 是否为最新版本
		IsDeleted:                  db.IsDeleted,                  // 是否被删除
		Status:                     db.Status,                     // 合同状态
		CurVersionFrom:             db.CurVersionFrom,             // cur_version_from
		Remark:                     db.Remark,                     // 备注

		// 后续移动到 BasicInfo 内的参数
		CrmKey:                db.CRMKey,                              // crm_key
		RelatedPersonnel:      db.RelatedPersonnel,                    // related_personnel
		OfacUrl:               db.OfacUrl,                             // ofac_url
		OpenChatId:            db.OpenChatID,                          // open_chat_id
		BizData:               db.BizData,                             // biz_data
		SettlementClause:      db.SettlementClause,                    // settlement_clause
		IsContainRefundClause: strconv.Itoa(db.IsContainRefundClause), // is_contain_refund_clause

		// 后续会删除的字段
		RequestId:      db.RequestId,
		CheckCode:      db.CheckCode,
		ContractId:     db.ContractId,
		FileIdSigned:   db.FileIdSigned,
		FileIdUnsigned: db.FileIdUnsigned,
		FinanceSubject: db.FinanceSubject,

		// ProductList: ,
		// Finance: ,
		SubjectName:       strings.Join(subjectNames, ","),
		OtherPartyName:    strings.Join(otherPartyNames, ","),
		SubjectAccountIds: strings.Join(accountIDs, ","),
		SealAccountIDs:    strings.Join(utils.SingleList(sealAccountIDs), ","),
		PricingAccountIDs: strings.Join(utils.SingleList(priceAccountIDs), ","),

		// TODO：本期不涉及 后续需求改造
		Ext: ext,
		// RealTimeExt                map[string]string // 基于合同入参拆分的合同附加信息，需要处理历史信息，若变更后某一信息变更时，需要删除对应参数
	}

	return ret
}

func ConvertManageInfo(manageInfo *bizmodels.ManageInfo) *bizmodels.ManageInfo {
	if manageInfo == nil {
		return &bizmodels.ManageInfo{}
	}
	manageBytes, _ := json.Marshal(manageInfo)
	var res bizmodels.ManageInfo
	_ = json.Unmarshal(manageBytes, &res)
	return &res
}

// UploadFileVolc 上传文件至文件管理系统
func UploadFileVolc(ctx context.Context, pc *auditmodel.ProcessCtx, fillData *templateclient.FillFileData) (string, error) {
	// currentEmployee, err := employee.GetEmployeeByEmail(ctx, pc.CurrentOperator)
	// if err != nil {
	//	logs.CtxError(ctx, "GetEmployeeByEmailFail, email:%s, err:%v", pc.CurrentOperator, err)
	//	return "", err
	// }
	// 更新合同关联文本-上传至文件管理系统
	// 构建上传文件管理系统文件名称
	fileName := utils.ReplaceFileName(utils.GetFileBaseName(fillData.FileKey), pc.ContractInfo.ContractNo)
	// 上传文件管理系统
	// todo: 参数不同的兼容改造
	extMap := map[string]interface{}{
		"CooperationStatus": pc.ContractInfo.CooperationStatus,
	}
	extJsonBytes, _ := json.Marshal(extMap)
	extJsonStr := string(extJsonBytes)
	//
	fileResp, err := filecli.UploadFile(ctx, &filecli.UploadFileReq{
		UID:      _const.OperationSystemID,
		Name:     _const.OperationSystem,
		Email:    _const.OperationSystem,
		FileName: fileName,
		FileID:   pc.ContractInfo.OnlineContract,
		FileKey:  fillData.FileKey,
		Ext:      extJsonStr,
	})
	if err != nil {
		logs.CtxError(ctx, "UploadTemplateFileFail, FileKey:%s, err:%v", fillData.FileKey, err)
		return "", err
	}
	return fileResp.FileID, nil
}

// updateTemplateFilePermission 更新模板合同文本操作权限
func updateTemplateFilePermission(ctx context.Context, fileId string, pc *auditmodel.ProcessCtx) error {
	// 给创建人加权限
	employee, err := larkc.GetEmployeeByEmailWithCache(ctx, pc.CurrentOperator)
	if err != nil {
		logs.CtxError(ctx, "GetEmployeeByEmailFail, CurrentOperator:%s, err:%v", pc.CurrentOperator, err)
		return err
	}
	if employee == nil {
		logs.CtxError(ctx, "GetEmployeeByEmailFail, CurrentOperator:%s, employee is nil", pc.CurrentOperator)
		return i18nfmt.New(ctx, "employee is nil")
	}
	// 清空原 ID 权限
	if err := filecli.ClearFilePermission(ctx, &filecli.ClearFilePermissionRequest{
		FileId: fileId,
	}); err != nil {
		logs.CtxError(ctx, "ClearFilePermissionFail, err:%v", err)
		return err
	}
	// 更新模板合同文本操作权限
	err = filecli.UpdateUserPermission(ctx, &filecli.UpdateUserPermissionReq{
		Users: []*filecli.User{{
			FileId:     fileId,
			Uid:        strconv.Itoa(employee.ID),
			Name:       employee.Name,
			Email:      employee.Email,
			AvatarUrl:  employee.AvatarURL,
			Permission: _const.PermissionRead,
		},
		},
	})
	if err != nil {
		logs.CtxError(ctx, "UpdateUserPermissionFail, CurrentOperator:%s, err:%v", pc.CurrentOperator, err)
		return err
	}
	return nil
}

// ClearContractRepeatQuote 清空合同关联报价单信息
func ClearContractRepeatQuote(ctx context.Context, pc *auditmodel.ProcessCtx, repeatMsgMap map[string]map[string]string) errorsV2.APIError {
	if len(repeatMsgMap) == 0 {
		logs.CtxWarn(ctx, "ClearContractRepeatQuote, contractNoList is empty.")
		return nil
	}

	if err := contractmeta.NewMetaServiceV2().ClearRelateQuote(ctx, &modelcommodity.ClearRelateQuoteReq{
		OperatorEmail:    pc.CurrentOperator,
		OriginContractNo: pc.ContractInfo.ContractNo,
		RepeatMsgMap:     repeatMsgMap,
	}); err != nil {
		logs.CtxError(ctx, "ClearQuoteManageInfoFail, err:%v", err)
		logID, _ := logid.GetLogIDFromCtx(ctx)
		errMsg := i18nfmt.Sprintf(ctx, "logId:%s, err:%v", logID, err)
		larkc.Warning("清空合同关联报价单信息失败", errMsg)
		return errorsV2.ErrInternalError.WithArgs(err.Error())
	}
	return nil
}

// 是否需要初始化解决方案审批节点，通过前置计算的ApprovalKey判断。
func (h *handlerCommon) needInitSolutionNode(ctx context.Context, pc *auditmodel.ProcessCtx) bool {
	// if pc.ContractInfo != nil && pc.ContractInfo.ProjectInfo != nil {
	//	return pc.ContractInfo.ProjectInfo.HasProductSolutionEmail()
	// }
	return pc.ApprovalKey == _const.ApprovalKeyDefaultWithSolution
}

// InitReviewersAfterStatusChanged 在合同协商状态流转到目标审批节点后初始化节点审批人。
func InitReviewersAfterStatusChanged(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	h := &handlerCommon{}
	switch pc.StatusChangedValue {
	case _const.PreSalesContractFinanceTaxationLegalReview, _const.PreSalesContractFinanceTaxationLegalSignReview:
		return h.resetPANodeReviewers(ctx, pc, pc.StatusChangedValue)
	case _const.PreSalesContractSolutionReview:
		if h.needInitSolutionNode(ctx, pc) {
			return h.resetSolutionNodeReviewers(ctx, pc)
		}
	}
	return nil
}

// 重置「解决方案审批」节点审批人，该节点审批人根据合同字段生成
func (h *handlerCommon) resetSolutionNodeReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	var (
		reviewerType = _const.ReviewerTypeSolutionReviewer
		contract     = pc.ContractInfo
	)

	emailStr := contract.ProjectInfo.GetProductSolutionEmail()
	if emailStr == "" {
		return errorsV2.ErrCommon.WithArgs("项目信息产解/行解信息为空")
	}
	emails := strings.Split(emailStr, ",")
	employeeMappings, err := larkc.BatchListHireEmployeesByEmails(ctx, emails)
	if err != nil {
		logs.CtxWarn(ctx, "BatchGetEmployeesFail, err=%s", err.Error())
		return errorsV2.ErrCommon.WithArgs("查询用户信息失败, 无法新增审批")
	}

	var reviewerDBList []*model.PreContractReviewerDB
	for _, email := range emails {
		employeeInfo := employeeMappings[email]
		if employeeInfo == nil {
			logs.CtxError(ctx, "查询用户信息失败, 无法新增审批记录, email: %s", email)
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "查询用户[%s]信息失败, 无法新增审批", email))
		}

		if employeeInfo.Terminated {
			logs.CtxError(ctx, "查询用户已离职, 无法新增审批记录, email: %s", email)
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "用户[%s]已离职, 无法新增审批", email))
		}

		reviewerDBList = append(reviewerDBList, &model.PreContractReviewerDB{
			BaseDB:         model.BaseDB{},
			PreContractNo:  contract.ContractNo,
			Reviewer:       employeeInfo.Email,
			ReviewerID:     strconv.Itoa(employeeInfo.ID),
			ReviewerType:   reviewerType,
			ContractStatus: _const.PreSalesContractSolutionReview,
			Department:     contract.BasicInfo.DepartmentId,
			ReviewerRole:   _const.ReviewerRoleSolution,
		})

	}

	if len(reviewerDBList) == 0 {
		logs.CtxWarn(ctx, "query reviewer result is empty")
		return errorsV2.ErrCommon.WithArgs("无有效项目信息产解/行解信息")
	}

	// 删除当前节点
	err = dal.NewPreContractReviewerDao().DeleteReviewersByType(ctx, pc.GetTx(), contract.ContractNo, []int{reviewerType})
	if err != nil {
		logs.CtxWarn(ctx, "DeleteReviewersByTypeFail, contractNo=%s, reviewerType=%d, err=%s", contract.ContractNo, reviewerType, err.Error())
		return errorsV2.ErrInternalError.WithArgs("reset reviewers fail")
	}

	// 保存审批操作条目
	if err = dal.NewPreContractReviewerDao().BatchCreate(ctx, pc.GetTx(), reviewerDBList); err != nil {
		logs.CtxWarn(ctx, "BatchCreateReviewerFail, contractNo=%s, reviewerType=%d, err=%s", contract.ContractNo, reviewerType, err.Error())
		return errorsV2.ErrCommon.WithArgs("创建审批操作条目失败")
	}

	var newReviewers bizmodels.PreContractReviewerList
	// 移除历史解决方案审批人，将新审批人加入
	for _, reviewer := range contract.Reviewers {
		if reviewer.ReviewerType == _const.ReviewerTypeSolutionReviewer {
			continue
		}
		newReviewers = append(newReviewers, reviewer)
	}
	for _, reviewer := range reviewerDBList {
		contractReviewer := reviewer.GenResp()
		newReviewers = append(newReviewers, contractReviewer)
	}
	contract.Reviewers = newReviewers

	return nil
}

// 重置「财税法交付专业审核」、「财税法签约审核」节点审批人
func (h *handlerCommon) resetFTLNodeReviewers(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	var (
		reviewerType = _const.ReviewerTypeFinanceTaxationLegalReviewer
		contract     = pc.ContractInfo
		basicInfo    = contract.BasicInfo
	)

	if basicInfo.ContractTemplateType == nil {
		return errorsV2.ErrCommon.WithArgs("合同模板类型缺失")
	}

	// 重新匹配「财税法交付专业审核」、「财税法签约审核」节点审批人
	// 查询该合同需要的财税法审核角色 示例：财务AR+财务BP+税务BP+法务BP
	rolesStr, _ := ruleengine.MatchFTLRule(ctx, h.GenRoleMapKeyByBasicInfo(basicInfo))
	if len(rolesStr) == 0 {
		return errorsV2.ErrInternalError.WithArgs("无此合同对应的财税法审核角色 PreContractNo: %v", contract.ContractNo)
	}

	// 财务AR+财务BP+税务BP+法务BP => [财务AR,财务BP,税务BP,法务BP]
	needRoles := strings.Split(rolesStr, "+")

	// 示例 key=财务AR value=email
	reviewerMappings, err := h.getAndValidateReviewerMappings(ctx, needRoles, basicInfo.DepartmentId, contract.Operator)
	if err != nil {
		return err
	}

	collectEmails := h.collectEmails(reviewerMappings)
	deliveryStaffEmails := contract.GetDeliveryStaffEmails()
	collectEmails = append(collectEmails, deliveryStaffEmails...)
	employeeMappings, err := larkc.BatchListHireEmployeesByEmails(ctx, collectEmails)
	if err != nil {
		return err
	}

	var newReviewerDBList []*model.PreContractReviewerDB
	existReviewerMap := map[string]bool{}
	for _, role := range needRoles {
		reviewerRole := _const.GetReviewerRoleValueByNameIgnore(role)
		reviewerStr := reviewerMappings[role]
		reviewers := strings.Split(reviewerStr, ",")
		if len(reviewers) == 0 {
			return i18nfmt.Errorf(ctx, "当前角色[%s]未配置审核人员", role)
		}
		for _, email := range reviewers {
			emp := employeeMappings[email]
			if emp == nil {
				logs.CtxWarn(ctx, "查询用户信息失败, 无法新增审批记录, email: %s", email)
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "查询用户[%s]信息失败, 无法新增审批", email))
			}
			if emp.Terminated {
				logs.CtxError(ctx, "查询用户已离职, 无法新增审批记录, email: %s", email)
				return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "用户[%s]已离职, 无法新增审批", email))
			}
			// 获取不同reviewer_type对应的审批节点列表
			reviewerTypeStatusMap := GetReviewerTypeStatusMappings(pc.ApprovalKey)
			relateStatusList := reviewerTypeStatusMap[reviewerType]
			for _, contractStatus := range relateStatusList {
				existKey := i18nfmt.Sprintf(ctx, "%s_%d_%d", emp.Email, reviewerType, contractStatus)

				if existReviewerMap[existKey] {
					logs.CtxInfo(ctx, "[%s]已存在, 忽略", existKey)
					continue
				}

				newReviewerDBList = append(newReviewerDBList, &model.PreContractReviewerDB{
					BaseDB:         model.BaseDB{},
					PreContractNo:  contract.ContractNo,
					Reviewer:       emp.Email,
					ReviewerID:     strconv.Itoa(emp.ID),
					ReviewerType:   reviewerType,
					ContractStatus: contractStatus,
					Department:     contract.BasicInfo.DepartmentId,
					ReviewerRole:   reviewerRole,
				})
				existReviewerMap[existKey] = true
			}
		}
	}

	if len(newReviewerDBList) == 0 {
		logs.CtxWarn(ctx, "query reviewer result is empty")
		return errorsV2.ErrCommon.WithArgs("未匹配到财税法审批人")
	}

	// 额外添加交付人员到审批人列表中
	for _, staff := range deliveryStaffEmails {
		emp := employeeMappings[staff]
		if emp == nil {
			logs.CtxWarn(ctx, "查询用户信息失败, 无法新增审批记录, email: %s", staff)
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "查询用户[%s]信息失败, 无法新增审批", staff))
		}
		if emp.Terminated {
			logs.CtxError(ctx, "查询用户已离职, 无法新增审批记录, email: %s", staff)
			return errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "用户[%s]已离职, 无法新增审批", staff))
		}
		existKey := i18nfmt.Sprintf(ctx, "%s_%d_%d", emp.Email, reviewerType, _const.PreSalesContractFinanceTaxationLegalReview)

		if existReviewerMap[existKey] {
			logs.CtxInfo(ctx, "[%s]已存在, 忽略", existKey)
			continue
		}

		newReviewerDBList = append(newReviewerDBList, &model.PreContractReviewerDB{
			BaseDB:         model.BaseDB{},
			PreContractNo:  contract.ContractNo,
			Reviewer:       emp.Email,
			ReviewerID:     strconv.Itoa(emp.ID),
			ReviewerType:   reviewerType,
			ContractStatus: _const.PreSalesContractFinanceTaxationLegalReview,
			Department:     contract.BasicInfo.DepartmentId,
			ReviewerRole:   _const.ReviewerRoleDelivery,
		})

		existReviewerMap[existKey] = true
	}

	// 删除财税法现有审批人
	err = dal.NewPreContractReviewerDao().DeleteReviewersByType(ctx, pc.GetTx(), contract.ContractNo, []int{reviewerType})
	if err != nil {
		logs.CtxWarn(ctx, "DeleteReviewersByTypeFail, contractNo=%s, reviewerType=%d, err=%s", contract.ContractNo, reviewerType, err.Error())
		return errorsV2.ErrInternalError.WithArgs("reset reviewers fail")
	}

	// 保存审批操作条目
	if err = dal.NewPreContractReviewerDao().BatchCreate(ctx, pc.GetTx(), newReviewerDBList); err != nil {
		logs.CtxWarn(ctx, "BatchCreateReviewerFail, contractNo=%s, reviewerType=%d, err=%s", contract.ContractNo, reviewerType, err.Error())
		return errorsV2.ErrCommon.WithArgs("创建审批操作条目失败")
	}

	for _, contractStatus := range []int{_const.PreSalesContractFinanceTaxationLegalReview, _const.PreSalesContractFinanceTaxationLegalSignReview} {
		if err = h.resetPANodeReviewers(ctx, pc, contractStatus); err != nil {
			return err
		}
	}

	return nil
}

func (h *handlerCommon) resetPANodeReviewers(ctx context.Context, pc *auditmodel.ProcessCtx, currentContractStatus int) error {
	contract := pc.ContractInfo
	if contract == nil {
		return errorsV2.ErrCommon.WithArgs("合同信息缺失")
	}
	if !utils.IntIn(currentContractStatus, []int{_const.PreSalesContractFinanceTaxationLegalReview, _const.PreSalesContractFinanceTaxationLegalSignReview}) {
		return errorsV2.ErrCommon.WithArgs("PA审批人仅支持财税法审核节点初始化")
	}
	reviewerDao := dal.NewPreContractReviewerDao()
	currentReviewers, err := reviewerDao.FindReviewersByNo(ctx, pc.GetTx(), contract.ContractNo)
	if err != nil {
		logs.CtxWarn(ctx, "QueryPAReviewersFail, contractNo=%s, err=%s", contract.ContractNo, err.Error())
		return errorsV2.ErrInternalError.WithArgs("query PA reviewers fail")
	}
	existReviewerMap := h.buildCurrentPAReviewerMap(ctx, currentReviewers, currentContractStatus)
	paReviewerDBList, needReviewerMap, err := h.genPAReviewersIfNeeded(ctx, pc, currentContractStatus, existReviewerMap)
	if err != nil {
		return err
	}
	needDeleteIDs := h.filterStalePAReviewerIDs(ctx, currentReviewers, currentContractStatus, needReviewerMap)
	if len(needDeleteIDs) > 0 {
		if err = reviewerDao.BatchDeleteReviewer(ctx, pc.GetTx(), contract.ContractNo, needDeleteIDs); err != nil {
			logs.CtxWarn(ctx, "DeleteStalePAReviewersFail, contractNo=%s, ids=%v, err=%s", contract.ContractNo, needDeleteIDs, err.Error())
			return errorsV2.ErrInternalError.WithArgs("reset PA reviewers fail")
		}
	}
	if len(paReviewerDBList) > 0 {
		if err = reviewerDao.BatchCreate(ctx, pc.GetTx(), paReviewerDBList); err != nil {
			logs.CtxWarn(ctx, "BatchCreatePAReviewerFail, contractNo=%s, err=%s", contract.ContractNo, err.Error())
			return errorsV2.ErrCommon.WithArgs("创建PA审批操作条目失败")
		}
	}
	h.refreshContractReviewersAfterPAReset(ctx, contract, currentReviewers, currentContractStatus, needReviewerMap, paReviewerDBList)
	return nil
}

func (h *handlerCommon) refreshContractReviewersAfterPAReset(ctx context.Context, contract *model.ContractMeta, currentReviewers model.PreContractReviewerDBList, currentContractStatus int, needReviewerMap map[string]bool, paReviewerDBList []*model.PreContractReviewerDB) {
	var newReviewers bizmodels.PreContractReviewerList
	for _, reviewer := range currentReviewers {
		if reviewer == nil {
			continue
		}
		if isCurrentPAReviewer(reviewer, currentContractStatus) && !needReviewerMap[paReviewerUniqueKey(ctx, reviewer.Reviewer, currentContractStatus)] {
			continue
		}
		newReviewers = append(newReviewers, reviewer.GenResp())
	}
	for _, reviewer := range paReviewerDBList {
		newReviewers = append(newReviewers, reviewer.GenResp())
	}
	contract.Reviewers = newReviewers
}

func (h *handlerCommon) buildCurrentPAReviewerMap(ctx context.Context, currentReviewers model.PreContractReviewerDBList, currentContractStatus int) map[string]bool {
	existReviewerMap := map[string]bool{}
	for _, reviewer := range currentReviewers {
		if reviewer == nil || reviewer.ContractStatus != currentContractStatus {
			continue
		}
		existReviewerMap[paReviewerUniqueKey(ctx, reviewer.Reviewer, currentContractStatus)] = true
	}
	return existReviewerMap
}

func (h *handlerCommon) filterStalePAReviewerIDs(ctx context.Context, currentReviewers model.PreContractReviewerDBList, currentContractStatus int, needReviewerMap map[string]bool) []uint64 {
	var needDeleteIDs []uint64
	for _, reviewer := range currentReviewers {
		if !isCurrentPAReviewer(reviewer, currentContractStatus) {
			continue
		}
		if needReviewerMap[paReviewerUniqueKey(ctx, reviewer.Reviewer, currentContractStatus)] {
			continue
		}
		needDeleteIDs = append(needDeleteIDs, reviewer.Id)
	}
	return needDeleteIDs
}

func isCurrentPAReviewer(reviewer *model.PreContractReviewerDB, currentContractStatus int) bool {
	return reviewer != nil &&
		reviewer.ReviewerType == _const.ReviewerTypeFinanceTaxationLegalReviewer &&
		reviewer.ReviewerRole == _const.ReviewerRolePA &&
		reviewer.ContractStatus == currentContractStatus
}

func paReviewerUniqueKey(ctx context.Context, reviewer string, contractStatus int) string {
	return i18nfmt.Sprintf(ctx, "%s_%d_%d", reviewer, _const.ReviewerTypeFinanceTaxationLegalReviewer, contractStatus)
}

func (h *handlerCommon) needPAReviewer(ctx context.Context, contract *model.ContractMeta) bool {
	cfg := conf.GetPAApprovalConfig(ctx)
	if cfg == nil || !cfg.Enable || contract == nil {
		return false
	}
	if contract.TradePartyInfo != nil {
		for _, party := range contract.TradePartyInfo.OtherParty {
			if party == nil {
				continue
			}
			if party.IndustryCKey != "" && utils.StringIn(party.IndustryCKey, cfg.GovernmentIndustryKeys) {
				return true
			}
			if party.IndustryCDec != "" && utils.StringIn(party.IndustryCDec, cfg.GovernmentIndustryNames) {
				return true
			}
		}
	}
	if contract.BasicInfo == nil {
		return false
	}
	return utils.StringIn(contract.BasicInfo.DepartmentId, cfg.PublicServiceDepartmentIds)
}

func (h *handlerCommon) genPAReviewersIfNeeded(ctx context.Context, pc *auditmodel.ProcessCtx, contractStatus int, existReviewerMap map[string]bool) ([]*model.PreContractReviewerDB, map[string]bool, error) {
	contract := pc.ContractInfo
	if !h.needPAReviewer(ctx, contract) {
		return nil, map[string]bool{}, nil
	}
	cfg := conf.GetPAApprovalConfig(ctx)
	if cfg == nil || len(cfg.PAReviewerEmails) == 0 {
		larkc.Warning("PA审批人配置异常", i18nfmt.Sprintf(ctx, "PreContractNo:%s PAReviewerEmails为空", contract.ContractNo), ctx)
		return nil, nil, errorsV2.ErrCommon.WithArgs("PA审批人配置为空")
	}
	employeeMappings, err := larkc.BatchListHireEmployeesByEmails(ctx, cfg.PAReviewerEmails)
	if err != nil {
		return nil, nil, err
	}
	var reviewerDBList []*model.PreContractReviewerDB
	needReviewerMap := map[string]bool{}
	for _, email := range cfg.PAReviewerEmails {
		emp := employeeMappings[email]
		if emp == nil {
			larkc.Warning("PA审批人配置异常", i18nfmt.Sprintf(ctx, "PreContractNo:%s 查询PA用户失败:%s", contract.ContractNo, email), ctx)
			return nil, nil, errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "查询PA用户[%s]信息失败", email))
		}
		if emp.Terminated {
			larkc.Warning("PA审批人配置异常", i18nfmt.Sprintf(ctx, "PreContractNo:%s PA用户已离职:%s", contract.ContractNo, email), ctx)
			return nil, nil, errorsV2.ErrCommon.WithArgs(i18nfmt.Sprintf(ctx, "PA用户[%s]已离职", email))
		}
		existKey := paReviewerUniqueKey(ctx, emp.Email, contractStatus)
		needReviewerMap[existKey] = true
		if existReviewerMap[existKey] {
			continue
		}
		reviewerDBList = append(reviewerDBList, &model.PreContractReviewerDB{
			BaseDB:         model.BaseDB{},
			PreContractNo:  contract.ContractNo,
			Reviewer:       emp.Email,
			ReviewerID:     strconv.Itoa(emp.ID),
			ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
			ContractStatus: contractStatus,
			Department:     contract.BasicInfo.DepartmentId,
			ReviewerRole:   _const.ReviewerRolePA,
		})
		existReviewerMap[existKey] = true
	}
	return reviewerDBList, needReviewerMap, nil
}

// notifyC360 发送 C360 通知（目前仅国内通知）
func (h *handlerCommon) notifyC360(ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
	var contractOperatorEmail, statusReturnReason, customerName, legalAuditRes, contractStatus string
	contractOperator, _ := larkc.GetEmployeeByID(ctx, pc.ContractInfo.Operator)
	if contractOperator != nil && len(contractOperator) > 0 {
		contractOperatorEmail = contractOperator[0].Email
	}
	if pc.OperationState == _const.OperationSendBack {
		statusReturnReason = pc.Comment.RichtextPlainText
		customerName = pc.ContractInfo.OtherPartyName
	}
	// 若合同类型为合规审查消息提醒
	if eventType == _const.C360NotifyEventTypeComplianceCheck {
		legalAuditRes = _const.ComplianceCheckTradingSecMap[pc.OperationState]
		contractStatus = _const.ContractStatus2NameMapping[pc.StatusChangedValue]
		// 已作废时，合同状态字段赋值"流程已自动作废"
		if pc.StatusChangedValue == _const.PreSalesContractAbandoned {
			contractStatus = "流程已自动作废"
		}
	}
	msg := &bizmodels.C360NotifyMsg{
		EventType: eventType,
		Operator:  []string{contractOperatorEmail},
		ContractList: []bizmodels.C360NotifyRecord{
			{
				ContractNumber:     pc.ContractInfo.ContractNo,                               // 合同编号
				ContractName:       pc.ContractInfo.ContractName,                             // 合同名称
				NextAuditNode:      _const.ContractStatus2NameMapping[pc.StatusChangedValue], // 下一个审核节点
				StatusReturnReason: statusReturnReason,                                       // 退回原因
				CustomerName:       customerName,                                             // 客户名称
				LegalAuditRes:      legalAuditRes,                                            // 合规审查结果
				ContractStatus:     contractStatus,                                           // 合同状态
			},
		},
	}
	if err := mqProducer.SendC360NotifyMessage(ctx, time.Second, msg); err != nil {
		logs.CtxError(ctx, "SendC360NotifyMessageFail, err=%s", err.Error())
		content := fmt.Sprintf("合同号：%s, 事件类型：%s，errMsg:%s \nMsgBody：%s",
			pc.ContractInfo.ContractNo, eventType, err.Error(), utils.ToJSON(msg))
		larkc.Warning("合同状态变更触发C360通知失败", content)
		return err
	}
	return nil
}

// ValidateDeputyParty 校验是否允许增加交易对方主体
func (h *handlerCommon) ValidateDeputyParty(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 模板型合同不允许添加副签约主体
	if pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil {
		for _, otherParty := range pc.ContractInfo.TradePartyInfo.OtherParty {
			if otherParty.IsDeputyParty() {
				logs.CtxError(ctx, "使用模板的合同不支持添加副签约主体, contractNo=%s", pc.ContractInfo.ContractNo)
				return errorsV2.ErrCommon.WithArgs("使用模板的合同不支持添加副签约主体")
			}
		}
	}

	// 副签约主体必须为签约且不配价主体
	for _, otherParty := range pc.ContractInfo.TradePartyInfo.OtherParty {
		if otherParty.IsDeputyParty() {
			if otherParty.Sealed != _const.TRUE_FLAG_INT {
				logs.CtxError(ctx, "副签约主体必须为签约主体, contractNo=%s", pc.ContractInfo.ContractNo)
				return errorsV2.ErrCommon.WithArgs("副签约主体是否需要签约必须为是")
			}
			if otherParty.Pricing != _const.FALSE_FLAG_INT {
				logs.CtxError(ctx, "副签约主体不可为配价主体, contractNo=%s", pc.ContractInfo.ContractNo)
				return errorsV2.ErrCommon.WithArgs("副签约主体是否需要配价必须为否")
			}
		}
	}
	return nil
}

// getCouponConfigList
func (h *handlerCommon) getCouponConfigList(ctx context.Context, pc *auditmodel.ProcessCtx) ([]*quote_client.ExtraConfigCouponDetail, error) {
	metaExtList, _, err := dal.NewContractMetaExtDao().ListByContractId(ctx, pc.GetTx(), int64(pc.ContractInfo.ID), nil)
	if err != nil {
		logs.CtxError(ctx, "ListByContractIdFail, ContractId=%d, err=%s", pc.ContractInfo.ID, err.Error())
		return nil, err
	}

	var couponConfigStr string
	hasCouponConfig := false
	for _, metaExt := range metaExtList {
		if metaExt.AttrKey == _const.ExtKeyCouponConfig {
			couponConfigStr = metaExt.AttrValue
			hasCouponConfig = true
			break
		}
	}
	if !hasCouponConfig || couponConfigStr == "" {
		logs.CtxInfo(ctx, "CouponConfig is empty, ContractId=%d", pc.ContractInfo.ID)
		return nil, nil
	}

	var couponConfigList []*quote_client.ExtraConfigCouponDetail
	err = json.Unmarshal([]byte(couponConfigStr), &couponConfigList)
	if err != nil {
		logs.CtxError(ctx, "UnmarshalCouponConfigFail, ContractId=%d, AttrValue=%s, err=%s", pc.ContractInfo.ID, couponConfigStr, err.Error())
		return nil, err
	}
	return couponConfigList, nil
}

func (h *handlerCommon) commonCheckValidityAndRebatePeriod(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	couponConfigList, err := h.getCouponConfigList(ctx, pc)
	if err != nil {
		return err
	}
	if couponConfigList == nil || len(couponConfigList) == 0 {
		return nil
	}

	for _, couponConfig := range couponConfigList {
		if couponConfig == nil {
			continue
		}
		// 仅返券类型为按账单金额返券和按账单金额比例返券时校验
		if couponConfig.RebateCouponWay != _const.COUPON_REBATE_WAY_FULL_REDUCE && couponConfig.RebateCouponWay != _const.COUPON_REBATE_WAY_PROPORTION_REDUCE {
			continue
		}
		// 校验条件：合同包含返券信息，且“返券周期”、“返券规则有效期”字段均有值。
		if couponConfig.RebatePeriod > 0 && couponConfig.RuleValidityInfo != nil {
			var ruleBeginTime, ruleEndTime time.Time
			var err error
			if couponConfig.RuleValidityInfo.Type == _const.COUPON_VALIDITY_LIMIT_FOLLOW_CONTRACT { // 跟随合同有效期
				basicInfo := pc.ContractInfo.BasicInfo
				if basicInfo.BeginTime == "" || basicInfo.EndTime == "" || basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
					continue
				}
				ruleBeginTime, err = time.ParseInLocation(utils.DateFormatTpl, basicInfo.BeginTime, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseContractBeginTimeFail, BeginTime=%s, err=%s", basicInfo.BeginTime, err.Error())
					return err
				}
				ruleEndTime, err = time.ParseInLocation(utils.DateFormatTpl, basicInfo.EndTime, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseContractEndTimeFail, EndTime=%s, err=%s", basicInfo.EndTime, err.Error())
					return err
				}
			} else { // 指定月份范围
				if couponConfig.RuleValidityInfo.BeginMonth == "" || couponConfig.RuleValidityInfo.EndMonth == "" {
					continue
				}

				ruleBeginTime, err = time.ParseInLocation(utils.DateFormatTplYearMonth, couponConfig.RuleValidityInfo.BeginMonth, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseRuleBeginMonthFail, BeginMonth=%s, err=%s", couponConfig.RuleValidityInfo.BeginMonth, err.Error())
					return err
				}
				ruleEndTime, err = time.ParseInLocation(utils.DateFormatTplYearMonth, couponConfig.RuleValidityInfo.EndMonth, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseRuleEndMonthFail, EndMonth=%s, err=%s", couponConfig.RuleValidityInfo.EndMonth, err.Error())
					return err
				}
			}

			// 计算返券规则有效期开始时间和结束时间月份差
			ruleBeginYear, ruleBeginMonth := ruleBeginTime.Year(), ruleBeginTime.Month()
			ruleEndYear, ruleEndMonth := ruleEndTime.Year(), ruleEndTime.Month()
			logs.CtxInfo(ctx, "couponValidityCheck, couponId=%d, ruleBeginYear=%d, ruleBeginMonth=%d, ruleEndYear=%d, ruleEndMonth=%d", couponConfig.Id, ruleBeginYear, ruleBeginMonth, ruleEndYear, ruleEndMonth)
			ruleValidityMonths := (ruleEndYear-ruleBeginYear)*_const.MONTHS_IN_YEAR + int(ruleEndMonth-ruleBeginMonth) + 1

			// 校验规则：“返券规则有效期”的月份长度必须大于等于“返券周期”。
			if ruleValidityMonths < couponConfig.RebatePeriod {
				logs.CtxError(ctx, "couponValidityCheckFail, couponId=%d, ruleValidityMonths=%d, rebatePeriod=%d", couponConfig.Id, ruleValidityMonths, couponConfig.RebatePeriod)
				return errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "返券规则ID为%d的“返券规则有效期”的月份长度需要必须大于等于“返券周期”", couponConfig.Id))
			}
		}
	}

	return nil
}

func (h *handlerCommon) checkAndCorrectCouponValiditySubset(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	couponConfigList, err := h.getCouponConfigList(ctx, pc)
	if err != nil {
		return err
	}
	if couponConfigList == nil || len(couponConfigList) == 0 {
		return nil
	}

	basicInfo := pc.ContractInfo.BasicInfo
	if basicInfo.BeginTime == "" || basicInfo.EndTime == "" || basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
		return nil
	}

	// 1. 准备合同有效期范围（yyyy-mm 格式用于逻辑计算，yyyy-mm-dd 格式用于展示）
	cBeginTime, _ := time.ParseInLocation(utils.DateFormatTpl, basicInfo.BeginTime, time.Local)
	cEndTime, _ := time.ParseInLocation(utils.DateFormatTpl, basicInfo.EndTime, time.Local)
	cBeginMonth, cEndMonth := cBeginTime.Format(utils.DateFormatTplYearMonth), cEndTime.Format(utils.DateFormatTplYearMonth)
	contractDisplayRange := fmt.Sprintf("%s ～ %s", cBeginTime.Format(utils.DateFormatTpl), cEndTime.Format(utils.DateFormatTpl))

	var (
		needUpdate              bool
		noIntersectionSummaries []string
		outOfRangeSummaries     []string
		isSecondConfirm         = pc.IsSecondConfirm == _const.TRUE_FLAG_INT
	)

	for _, cfg := range couponConfigList {
		if !h.shouldCheckCouponValidity(cfg) {
			logs.CtxInfo(ctx, "couponValidityCheckSkip, couponId=%d", cfg.Id)
			continue
		}

		rBegin, rEnd := cfg.RuleValidityInfo.BeginMonth, cfg.RuleValidityInfo.EndMonth

		// 场景 A：完全没有交集 -> 强拦截
		if rBegin > cEndMonth || rEnd < cBeginMonth {
			rulePeriodMsg := i18nfmt.Sprintf(ctx, "返券规则ID为%d的“返券有效期”为%s ～ %s，与合同有效期没有交集，请重新调整合同有效期。",
				cfg.Id, rBegin, rEnd)
			noIntersectionSummaries = append(noIntersectionSummaries, rulePeriodMsg)
			continue
		}

		// 场景 B：如果是子集 -> 通过
		if rBegin >= cBeginMonth && rEnd <= cEndMonth {
			continue
		}

		// 场景 C：部分重叠 -> 计算建议修正后的交集
		adjBegin, adjEnd := h.calculateCouponValidityIntersection(rBegin, rEnd, cBeginMonth, cEndMonth)

		if !isSecondConfirm {
			// 收集二次确认文案
			outOfRangeSummaries = append(outOfRangeSummaries, i18nfmt.Sprintf(ctx, "返券规则ID为%d的“返券有效期”为%s ～ %s，超出合同有效期，请你确认合同有效期是否符合预期，若继续操作，系统会在完善信息节点后将“返券有效期”调整为%s ～ %s。",
				cfg.Id, rBegin, rEnd, adjBegin, adjEnd))
		} else {
			// 校验返券规则有效期与返券周期的关系
			if cfg.RebatePeriod > 0 {
				adjBeginTime, err := time.ParseInLocation(utils.DateFormatTplYearMonth, adjBegin, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseRuleBeginMonthFail, BeginMonth=%s, err=%s", adjBegin, err.Error())
					return err
				}
				adjEndTime, err := time.ParseInLocation(utils.DateFormatTplYearMonth, adjEnd, time.Local)
				if err != nil {
					logs.CtxError(ctx, "ParseRuleEndMonthFail, EndMonth=%s, err=%s", adjEnd, err.Error())
					return err
				}

				// 计算返券规则有效期开始时间和结束时间月份差
				ruleBeginYear, ruleBeginMonth := adjBeginTime.Year(), adjBeginTime.Month()
				ruleEndYear, ruleEndMonth := adjEndTime.Year(), adjEndTime.Month()
				ruleValidityMonths := (ruleEndYear-ruleBeginYear)*_const.MONTHS_IN_YEAR + int(ruleEndMonth-ruleBeginMonth) + 1
				logs.CtxInfo(ctx, "couponValidityCheck, couponId=%d, ruleBeginYear=%d, ruleBeginMonth=%d, ruleEndYear=%d, ruleEndMonth=%d", cfg.Id, ruleBeginYear, ruleBeginMonth, ruleEndYear, ruleEndMonth)

				// 校验规则：“返券规则有效期”的月份长度必须大于等于“返券周期”。
				if ruleValidityMonths < cfg.RebatePeriod {
					logs.CtxError(ctx, "couponValidityCheckFail, couponId=%d, ruleValidityMonths=%d, rebatePeriod=%d", cfg.Id, ruleValidityMonths, cfg.RebatePeriod)
					return errorsV2.ErrQuoteCommon.WithArgs(i18nfmt.Sprintf(ctx, "返券规则ID为%d的“返券规则有效期”的月份长度需要必须大于等于“返券周期”", cfg.Id))
				}
			}

			// 用户已确认且满足条件，执行自动修正
			cfg.RuleValidityInfo.BeginMonth, cfg.RuleValidityInfo.EndMonth = adjBegin, adjEnd
			needUpdate = true
		}
	}

	// 2. 存在不合规情况，返回汇总错误
	if len(noIntersectionSummaries) > 0 || len(outOfRangeSummaries) > 0 {
		contractPeriodMsg := i18nfmt.Sprintf(ctx, "当前合同的合同有效期为%s。", contractDisplayRange)
		if len(noIntersectionSummaries) > 0 {
			logs.CtxError(ctx, "返券规则有效期和合同有效期无交集, contract_no: %s", pc.ContractInfo.ContractNo)
			return errorsV2.ErrQuoteCommon.WithArgs(fmt.Sprintf("%s\n%s", contractPeriodMsg, strings.Join(noIntersectionSummaries, "\n")))
		}
		logs.CtxError(ctx, "返券规则有效期超出合同有效期, contract_no: %s", pc.ContractInfo.ContractNo)
		return errorsV2.ErrSecondConfirm.WithArgs(fmt.Sprintf("%s\n%s", contractPeriodMsg, strings.Join(outOfRangeSummaries, "\n")))
	}

	// 3. 如果没有执行自动修正，直接返回
	if !needUpdate {
		return nil
	}

	// 4. 定稿节点（销售确认中+可定稿操作）不做数据更新
	if pc.ContractInfo.CooperationStatus == _const.PreSalesContractCustomerConfirm && pc.OperationState == _const.OperationFinalized {
		return nil
	}

	// 5. 持久化回合同扩展表
	data, marshalErr := json.Marshal(couponConfigList)
	if marshalErr != nil {
		logs.CtxError(ctx, "MarshalUpdatedCouponConfigFail, err=%s", marshalErr.Error())
		return marshalErr
	}
	if updateErr := h.getExtService(ctx).UpdateMetaExt(ctx, pc.GetTx(), int64(pc.ContractInfo.ID), map[string]string{_const.ExtKeyCouponConfig: string(data)}, nil); updateErr != nil {
		logs.CtxError(ctx, "UpdateMetaExtFail, err=%s", updateErr.Error())
		return updateErr
	}

	// 同步最新的ext信息到在线协同上下文pc的Ext里面
	if pc.Ext == nil {
		pc.Ext = make(map[string]string)
	}
	pc.Ext[_const.ExtKeyCouponConfig] = string(data)

	return nil
}

// shouldCheckCouponValidity 判断该返券配置是否需要进行有效期子集校验
func (h *handlerCommon) shouldCheckCouponValidity(cfg *quote_client.ExtraConfigCouponDetail) bool {
	if cfg == nil {
		return false
	}
	// 仅返券类型为按账单金额返券和按账单金额比例返券时校验
	if cfg.RebateCouponWay != _const.COUPON_REBATE_WAY_FULL_REDUCE && cfg.RebateCouponWay != _const.COUPON_REBATE_WAY_PROPORTION_REDUCE {
		return false
	}
	// 无有效期规则、跟随合同有效期、或月份字段为空时不校验
	if cfg.RuleValidityInfo == nil || cfg.RuleValidityInfo.Type == _const.COUPON_VALIDITY_LIMIT_FOLLOW_CONTRACT || cfg.RuleValidityInfo.BeginMonth == "" || cfg.RuleValidityInfo.EndMonth == "" {
		return false
	}
	return true
}

// calculateCouponValidityIntersection 计算返券规则有效期与合同有效期的交集（月份维度）
func (h *handlerCommon) calculateCouponValidityIntersection(rBegin, rEnd, cBegin, cEnd string) (string, string) {
	adjBegin, adjEnd := rBegin, rEnd
	if adjBegin < cBegin {
		adjBegin = cBegin
	}
	if adjEnd > cEnd {
		adjEnd = cEnd
	}
	return adjBegin, adjEnd
}

package handler

import (
	"context"
	"encoding/json"
	"strings"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	utils "volc_contract_process/pkg/util"
)

func newHandlerComplianceCheckPass() StatusOpHandler {
	return &handlerComplianceCheckPass{}
}

// 合规审查中(22) --- 审核通过(2) --> 销售运营专业审核(3)/销售运营完善信息(7)/已提交飞书合同(8)
type handlerComplianceCheckPass struct {
	handlerCommon
}

func (h *handlerComplianceCheckPass) CurrentStatus() int {
	return _const.PreSalesContractComplianceCheck
}

func (h *handlerComplianceCheckPass) CurrentOp() int {
	return _const.OperationReviewPass
}

func (h *handlerComplianceCheckPass) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerComplianceCheckPass) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 若前序状态为销售运营完善信息
	if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation {
		// 若为海外环境或关联了模板，需提交签约
		if multienv.IsBytePlus() || (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil) {
			// 若此时合同倒签，页面无法填充倒签原因，需补齐倒签信息
			if err := h.IsReverseContract(ctx, pc.PreContractVO); err != nil {
				pc.ContractInfo.ReverseSignInfo = &bizmodels.ReverseSignInfo{
					ReverseSignCode:   "RS008",
					ReverseSignReason: "合同签署的提前计划/安排不足",
				}
				reverseSignInfo, _ := json.Marshal(pc.ContractInfo.ReverseSignInfo)
				pc.PreContractVO.ReverseSignInfo = string(reverseSignInfo)
				// 单独更新倒签信息
				err = dal.NewContractMetaDao().UpdateByMap(ctx, nil, int64(pc.ContractInfo.ID), map[string]interface{}{
					"reverse_sign_info": pc.PreContractVO.ReverseSignInfo,
				})
				if err != nil {
					return err
				}
			}
			// 提交飞书
			return h.SendSubmitOaMsg(ctx, pc)
		}
	}
	return nil
}

func (h *handlerComplianceCheckPass) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerComplianceCheckPass) GetStatusOpConfKey(ctx context.Context, pc *auditmodel.ProcessCtx) string {
	// 前置状态为销售运营完善信息时
	if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation {
		// 若为海外环境或关联了模板，需提交签约
		if multienv.IsBytePlus() || (pc.ContractInfo.TemplateInfo != nil && pc.ContractInfo.TemplateInfo.Master != nil) {
			return _const.ApprovalStatusKeyCompleteInformationComplianceCheckSubmitOA
		} else {
			return _const.ApprovalStatusKeyCompleteInformationComplianceCheckPass
		}
	} else if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractDraft {
		return _const.ApprovalStatusKeyDraftComplianceCheckPass
	}
	return _const.ApprovalStatusKeyDefault
}

func (h *handlerComplianceCheckPass) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	// 发送飞书消息
	if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractSalesOperationCompleteInformation {
		h.notifyCompleteInformationPass(ctx, pc)
	} else if pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractDraft {
		h.notifyDraftPass(ctx, pc)
	}
	// 发送c360通知
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeComplianceCheck, pc)
	return nil
}

// notifyDraftPass 前置状态为草稿时 消息通知
func (h *handlerComplianceCheckPass) notifyDraftPass(ctx context.Context, pc *auditmodel.ProcessCtx) {
	// 发送飞书消息
	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, pc.StatusChangedValue),
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
			SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
			AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
			AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())

	// 通知 C360
	_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSubmitPreContract, pc)
}

// notifyCompleteInformationPass 前置状态为销售运营完善信息时 消息通知
func (h *handlerComplianceCheckPass) notifyCompleteInformationPass(ctx context.Context, pc *auditmodel.ProcessCtx) {
	// 销售运营完善信息，合同创建人, 合规审查通过通知
	multiCtx := context.Background()
	larkc.BatchSendMessageToEmailIgnore(ctx,
		h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesOperation, _const.PreSalesContractSalesOperationCompleteInformation),
		larkc.MsgTypeInteractive,
		larkc.NewCommonMessageCardBuilder().
			SetTitleColor(larkc.TitleColorWathet).
			SetTitle(multienv.I18nFormat(multiCtx, "合规审查结果通知")).
			SetContent(i18nfmt.Sprintf(multiCtx, "你提交的合同已完成合规审查，合规审查结果为“通过”，合同流程已自动往后流转，详情请点击按钮前往后台查看。")).
			AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
			AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
			AddAction(multienv.I18nFormat(multiCtx, "查看合同详情"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
			BuildJSONString())
	if pc.StatusChangedValue == _const.PreSalesContractFinanceTaxationLegalSignReview {
		// 发送飞书消息
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, _const.ReviewerTypeFinanceTaxationLegalReviewer, pc.StatusChangedValue),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同已完成前置专业审核环节，待您进行签约审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeInformationPass, pc)
	} else if pc.StatusChangedValue == _const.PreSalesContractSubmitOA {
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeInformationPass, pc)
	}
}

package handler

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/rediscli"
)

func newHandlerConfirmHaveChange() StatusOpHandler {
	return &handlerConfirmHaveChange{}
}

// 销售确认中(5) --- 有修改(10) --> 有修改(6)
type handlerConfirmHaveChange struct {
	handlerCommon
}

func (h *handlerConfirmHaveChange) CurrentStatus() int {
	return _const.PreSalesContractCustomerConfirm
}

func (h *handlerConfirmHaveChange) CurrentOp() int {
	return _const.OperationHaveChange
}

func (h *handlerConfirmHaveChange) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerConfirmHaveChange) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// 获取当前文件的最新版本
	fileID := pc.ContractInfo.OnlineContract

	req := &filecli.GetNewestVersionReq{
		FileID: fileID,
	}

	resp, err := filecli.GetNewestVersion(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetNewestVersionFail, fileID:%s, err:%s", fileID, err.Error())
		// todo 上线前改为返回错误
		return nil
	}
	if resp == nil || resp.Result == nil || len(resp.Result.Version) == 0 {
		logs.CtxError(ctx, "GetNewestVersionFail, fileID:%s, err:version_nil", fileID)
		return nil
	}

	version := resp.Result.Version
	logs.CtxInfo(ctx, "prepare_stash_file_version, fileID:%s, version:%s", fileID, version)
	err = rediscli.SaveStashFileVersion(ctx, fileID, version)
	if err != nil {
		return err
	}

	logs.CtxInfo(ctx, "stash_file_version_success, fileID:%s, version:%s", fileID, version)
	return nil
}

func (h *handlerConfirmHaveChange) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return true, nil
}

func (h *handlerConfirmHaveChange) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {

	// // 修改在线编辑权限
	// writePermReviewType := _const.ReviewerTypeSalesperson
	// var req = h.buildPermReq(pc.ContractInfo.Reviewers, &filePermUpdateInfo{
	//	FileID:                pc.ContractInfo.OnlineContract,
	//	WritePermReviewerType: &writePermReviewType,
	// })
	//
	// go h.addOrUpdateFilePerm(ctx, req)

	return nil
}

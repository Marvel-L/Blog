package handler

import (
	"context"
	"encoding/json"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"

	logs "code.byted.org/fido2/sdk/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/const"
)

func Test_handlerRiskTurnDown_Process_BitsUTGen(t *testing.T) {
	// MockContractMetaDao is a mock struct for the dal.ContractMetaDao interface.
	type MockContractMetaDao struct {
		dal.ContractMetaDao
	}

	mockey.PatchConvey("Test handlerRiskTurnDown Process", t, func() {
		h := &handlerRiskTurnDown{}
		ctx := context.Background()

		mockey.PatchConvey("should process successfully when all dependencies work", func() {
			// 场景描述:
			// 正常执行，成功将 IsSkipFTL 字段置为 false，并更新数据库。
			// 构造数据:
			// - ProcessCtx 包含一个 ContractInfo。
			// - ContractInfo.BasicInfo.IsSkipFTL 初始值为 true 以便验证其被修改。
			// 逻辑链路:
			// 1. json.Marshal 成功序列化 BasicInfo。
			// 2. pc.GetTx() 返回一个模拟的 *gorm.DB 实例。
			// 3. dal.NewContractMetaDao 返回一个 MockContractMetaDao 实例。
			// 4. MockContractMetaDao 的 UpdateFieldsByNo 方法返回 nil，表示数据库更新成功。
			// 5. 函数最终返回 nil。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT_NO_SUCCESS",
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
			}
			dbTx := &gorm.DB{}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(dbTx).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return error when json marshal fails", func() {
			// 场景描述:
			// 测试当 json.Marshal 序列化 BasicInfo 失败时的错误处理逻辑。
			// 构造数据:
			// - ProcessCtx 包含一个 ContractInfo。
			// 逻辑链路:
			// 1. json.Marshal 被 mock 并返回一个错误，以模拟序列化失败。
			// 2. logs.CtxError 被调用以记录错误。
			// 3. 函数返回 json.Marshal 产生的错误。
			// 注意：根据要求，标准库函数通常不应被 mock。但在这种情况下，由于无法通过构造数据的方式使 `json.Marshal` 稳定地对 `bizmodels.BasicInfo` 产生错误，
			// mock 是测试此错误路径的唯一实用方法。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
			}
			marshalErr := errors.New("json marshal error")

			mockey.Mock(json.Marshal).Return(nil, marshalErr).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json marshal error")
			// IsSkipFTL is modified before the marshal call
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("should return error when database update fails", func() {
			// 场景描述:
			// 测试当数据库更新操作失败时的错误处理逻辑。
			// 构造数据:
			// - ProcessCtx 包含一个 ContractInfo。
			// 逻辑链路:
			// 1. json.Marshal 成功。
			// 2. pc.GetTx() 返回一个模拟的 *gorm.DB 实例。
			// 3. dal.NewContractMetaDao 返回一个 MockContractMetaDao 实例。
			// 4. MockContractMetaDao 的 UpdateFieldsByNo 方法返回一个数据库错误。
			// 5. logs.CtxError 被调用以记录错误。
			// 6. 函数返回数据库错误。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo: "CONTRACT_NO_DB_FAIL",
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
			}
			dbTx := &gorm.DB{}
			dbErr := errors.New("db update failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(dbTx).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(&MockContractMetaDao{}).Build()
			mockey.Mock((*MockContractMetaDao).UpdateFieldsByNo).Return(dbErr).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db update failed")
			// IsSkipFTL is modified before the db call
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerRiskTurnDown_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskTurnDown_Validate", t, func() {
		mockey.PatchConvey("should return error when comment is empty", func() {
			// 场景描述：
			// 审批意见为空
			// 构造数据：
			// 构造一个ProcessCtx，其Comment字段不为空，但IsEmpty()方法返回true。
			// 逻辑链路：
			// 1. Mock pc.Comment.IsEmpty() 返回 true，表示审核意见为空。
			// 2. Mock i18nfmt.Errorf 返回一个预设的错误。
			// 3. 调用 Validate 方法，预期会进入 if 分支并返回错误。
			h := &handlerRiskTurnDown{}
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			ctx := context.Background()
			expectedErr := errors.New("审核意见不可为空")

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.Errorf).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("should return nil when comment is not empty", func() {
			// 场景描述：
			// 审批意见不为空
			// 构造数据：
			// 构造一个ProcessCtx，其Comment字段不为空，且IsEmpty()方法返回false。
			// 逻辑链路：
			// 1. Mock pc.Comment.IsEmpty() 返回 false，表示审核意见不为空。
			// 2. 调用 Validate 方法，预期不会进入 if 分支，直接返回 nil。
			h := &handlerRiskTurnDown{}
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			ctx := context.Background()

			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerRiskTurnDown_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskTurnDown_PostProcess", t, func() {
		mockey.PatchConvey("正常情况，函数无任何逻辑，直接返回nil", func() {
			// 场景描述：
			// 构造一个空的handlerRiskTurnDown实例和空的上下文参数。
			// 逻辑链路：
			// 1. 调用 PostProcess 方法。
			// 2. 方法直接返回nil。
			// 3. 断言返回的error为nil。

			// 准备数据
			h := &handlerRiskTurnDown{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.PostProcess(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerRiskTurnDown_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskTurnDown_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("should return true and nil", func() {
			// 场景描述：
			// 这是一个基本情况的测试，目标函数逻辑非常简单，总是返回 true 和 nil。
			// 构造数据：
			// - h: 一个 handlerRiskTurnDown 实例
			// - ctx: 一个空的 context
			// - pc: 一个空的 auditmodel.ProcessCtx 实例
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 方法直接返回 (true, nil)。
			// 3. 断言结果为 true，错误为 nil。
			h := &handlerRiskTurnDown{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			got, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerRiskTurnDown_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskTurnDown_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationTurnDown", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerRiskTurnDown 实例。
			// 逻辑链路：调用 CurrentOp 方法。
			// 预期结果：方法返回常量 _const.OperationTurnDown。

			// 准备数据
			h := &handlerRiskTurnDown{}

			// 调用
			op := h.CurrentOp()

			// 断言
			convey.So(op, convey.ShouldEqual, _const.OperationTurnDown)
		})
	})
}

func Test_handlerRiskTurnDown_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerRiskTurnDown_CurrentStatus", t, func() {
		mockey.PatchConvey("正常返回当前状态", func() {
			// 场景描述：
			// 构造一个 handlerRiskTurnDown 实例，调用其 CurrentStatus 方法。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 验证返回值是否为预期的常量 _const.PreSalesContractRiskReview。
			h := &handlerRiskTurnDown{}

			// 调用
			status := h.CurrentStatus()

			// 断言
			convey.So(status, convey.ShouldEqual, _const.PreSalesContractRiskReview)
		})
	})
}

func Test_newHandlerRiskTurnDown_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerRiskTurnDown", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 调用 newHandlerRiskTurnDown 函数，验证其能正确地创建一个 *handlerRiskTurnDown 类型的实例，
			// 并将其作为 StatusOpHandler 接口返回。
			// 构造数据：
			// 无需构造特定数据。
			// 逻辑链路：
			// 1. 直接调用 newHandlerRiskTurnDown() 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的底层具体类型是 *handlerRiskTurnDown。

			// 调用
			handler := newHandlerRiskTurnDown()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerRiskTurnDown{})
		})
	})
}

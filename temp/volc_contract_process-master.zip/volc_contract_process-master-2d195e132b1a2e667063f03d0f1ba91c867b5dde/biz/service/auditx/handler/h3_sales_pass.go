package handler

import (
	"context"
	"strings"

	"volc_contract_process/pkg/proxy/larkc"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"

	"volc_contract_process/biz/service/auditx/auditmodel"
	_const "volc_contract_process/pkg/const"
)

func newHandlerSalesReviewPass() StatusOpHandler {
	return &handlerSalesReviewPass{}
}

// 销售运营专业审核(3) --- 审核通过(2) --> 财税法交付专业审核(4)
type handlerSalesReviewPass struct {
	handlerCommon
}

func (h *handlerSalesReviewPass) CurrentStatus() int {
	return _const.PreSalesContractSalesOperationReview
}

func (h *handlerSalesReviewPass) CurrentOp() int {
	return _const.OperationReviewPass
}

func (h *handlerSalesReviewPass) Validate(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.commonCheckReviewerPass(ctx, pc); err != nil {
		return err
	}
	currentOperatorReviewers, err := dal.NewPreContractReviewerDao().FindReviewersByNoAndEmail(ctx, pc.GetTx(), pc.ContractInfo.ContractNo, pc.CurrentOperator)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoAndEmailFail 2, email:%s, err:%s", pc.CurrentOperator, err.Error())
		return err
	}
	for _, reviewer := range currentOperatorReviewers {
		if reviewer.ContractStatus == _const.PreSalesContractSalesOperationReview &&
			reviewer.ReviewerSource != _const.ReviewGradeOriginReviewers {
			return nil
		}
	}
	// 主审核人最后审批
	flag, err := h.commonCheckHitMasterReviewerPass(ctx, pc)
	if err != nil {
		logs.CtxError(ctx, "GetNoMasterReviewerTypePassFail, err: %v", err)
		return errors.ErrInternalError.WithArgs("查询审核人状态异常，请重试。")
	}
	if !flag {
		return errors.ErrInternalError.WithArgs("当前节点有审批人未通过，请销运同学在该节点其他审批人完成审批后再审批；")
	}
	return nil
}

func (h *handlerSalesReviewPass) Process(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	return nil
}

func (h *handlerSalesReviewPass) HitStateChangeCondition(ctx context.Context, pc *auditmodel.ProcessCtx) (bool, error) {
	return h.commonCheckHitContractStatusChange(ctx, pc)
}

// PostProcess /** 判断当前节点是否已处理完毕 更新状态 发送飞书消息 修改文件权限
func (h *handlerSalesReviewPass) PostProcess(ctx context.Context, pc *auditmodel.ProcessCtx) error {
	if err := h.reviewPassSendReviewedMessage(ctx, pc); err != nil {
		logs.CtxError(ctx, "SendReviewedMessageFail, err:%s", err.Error())
		return err
	}
	// 发送飞书消息
	if pc.StatusChanged {

		// 销售运营专业审核节点 审批通过时
		// 重新匹配财税法审批人，重新匹配时需要更新“财税法交付专业审核”、“财税法签约审核”的审核人员。
		// reset指定审批节点、指定角色的审批人员列表
		if err := h.resetFTLNodeReviewers(ctx, pc); err != nil {
			return err
		}

		// 如果需要初始化「解决方案审核」，需要临时增加审批人
		if h.needInitSolutionNode(ctx, pc) {
			if err := h.resetSolutionNodeReviewers(ctx, pc); err != nil {
				return err
			}
		}

		var notifyReviewerType = _const.ReviewerTypeFinanceTaxationLegalReviewer
		if pc.StatusChangedValue == _const.PreSalesContractSolutionReview {
			notifyReviewerType = _const.ReviewerTypeSolutionReviewer
		}

		// 发送飞书消息
		multiCtx := context.Background()
		larkc.BatchSendMessageToEmailIgnore(ctx,
			h.getReviewerFromPreContractReviewerListWithContractStatus(pc.ContractInfo.Reviewers, notifyReviewerType, pc.StatusChangedValue),
			larkc.MsgTypeInteractive,
			larkc.NewCommonMessageCardBuilder().
				SetTitleColor(larkc.TitleColorWathet).
				SetTitle(multienv.I18nFormat(multiCtx, "合同审核提醒")).
				SetContent(i18nfmt.Sprintf(multiCtx, "%s 发起的合同待您审核，请尽快前往后台进行审核", strings.Join(utils.StringListFormat(h.getReviewerFromPreContractReviewerList(pc.ContractInfo.Reviewers, _const.ReviewerTypeSalesperson), larkc.LarkMdAtEmail), ""))).
				AppendUrgentContent(pc.ContractInfo.IsUrgent, pc.ContractInfo.UrgentInfo).
				AddField(multienv.I18nFormat(multiCtx, "合同号"), pc.ContractInfo.ContractNo).
				AddField(multienv.I18nFormat(multiCtx, "合同名称"), pc.ContractInfo.ContractName).
				AddField(multienv.I18nFormat(multiCtx, "客户名称"), pc.ContractInfo.OtherPartyName).
				AddAction(multienv.I18nFormat(multiCtx, "去审核"), larkc.GenReviewURL(ctx, pc.ContractInfo.ContractNo)).
				BuildJSONString())
		// 通知 C360
		_ = h.notifyC360(ctx, _const.C360NotifyEventTypeSalesReviewPass, pc)
	}
	return nil
}

package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_newHandlerFTLReviewAddReviewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerFTLReviewAddReviewers", t, func() {
		mockey.PatchConvey("正常调用", func() {
			// 场景描述：
			// 正常调用newHandlerFTLReviewAddReviewers函数。
			// 逻辑链路：
			// 1. 调用newHandlerFTLReviewAddReviewers函数。
			// 2. 断言返回的handler不为nil。
			// 3. 断言返回的handler类型为*handlerFTLReviewAddReviewers。

			// 调用
			handler := newHandlerFTLReviewAddReviewers()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerFTLReviewAddReviewers{})
		})
	})
}

func Test_handlerFTLReviewAddReviewers_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewAddReviewers_CurrentStatus", t, func() {
		mockey.PatchConvey("should return PreSalesContractFinanceTaxationLegalReview", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回正确的状态码。
			// 构造数据：
			// 初始化一个 handlerFTLReviewAddReviewers 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 断言返回值等于预定义的常量 _const.PreSalesContractFinanceTaxationLegalReview。

			// 准备数据
			h := &handlerFTLReviewAddReviewers{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractFinanceTaxationLegalReview)
		})
	})
}

func Test_handlerFTLReviewAddReviewers_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewAddReviewers_CurrentOp", t, func() {
		mockey.PatchConvey("should return the correct operation code for adding reviewers", func() {
			// 场景描述：
			// 本测试旨在验证 `handlerFTLReviewAddReviewers` 结构体的 `CurrentOp` 方法是否能正确返回“加签”操作的常量值。
			// 构造数据：
			// 初始化一个 `handlerFTLReviewAddReviewers` 实例。
			// 逻辑链路：
			// 1. 创建 `handlerFTLReviewAddReviewers` 实例。
			// 2. 调用 `CurrentOp` 方法。
			// 3. 断言返回的整数值等于预期的常量 `_const.OperationAddReviewer`。

			// 初始化结构体实例
			h := &handlerFTLReviewAddReviewers{}

			// 调用目标方法
			opCode := h.CurrentOp()

			// 断言结果
			convey.So(opCode, convey.ShouldEqual, _const.OperationAddReviewer)
		})
	})
}

func Test_handlerFTLReviewAddReviewers_Validate_BitsUTGen(t *testing.T) {
	h := &handlerFTLReviewAddReviewers{}
	ctx := context.Background()

	mockey.PatchConvey("Test handlerFTLReviewAddReviewers.Validate", t, func() {
		mockey.PatchConvey("场景一：pc.Extra为空，返回人员不可为空错误", func() {
			// 场景描述：
			// 验证当传入的审批人员列表(pc.Extra)为空字符串时，函数能否正确返回错误。
			// 构造数据：
			// pc.Extra 设置为空字符串 ""。
			// 逻辑链路：
			// 1. 调用 h.Validate，内部进入 commonValidateUpdateReviewers。
			// 2. 函数入口处检查 len(pc.Extra) == 0。
			// 3. 条件成立，直接返回 "人员不可为空" 的错误。

			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景二：获取所有审批人失败，返回数据库错误", func() {
			// 场景描述：
			// 验证当底层获取已有审批人列表的函数 perm.GetAllReviewersByType 返回错误时，Validate 函数能否将该错误向上传递。
			// 构造数据：
			// 1. pc.Extra 设置为非空字符串 "user1@example.com"。
			// 2. 构造 pc.ContractInfo 和 pc.ReviewerStatusOpConf。
			// 3. Mock perm.GetAllReviewersByType，使其返回一个自定义的错误。
			// 逻辑链路：
			// 1. 调用 h.Validate，内部进入 commonValidateUpdateReviewers。
			// 2. len(pc.Extra) 检查通过。
			// 3. 调用 perm.GetAllReviewersByType。
			// 4. Mock 的函数返回错误，该错误被直接 return。

			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockErr := errors.New("mock db error")
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, mockErr).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("场景三：添加的审批人已存在且状态非通过，返回重复添加错误", func() {
			// 场景描述：
			// 验证当尝试添加的审批人中，有人已经是审批人（且审批状态不是“通过”）时，函数能正确识别并报错。
			// 构造数据：
			// 1. pc.Extra 设置为 "user1@example.com,new_user@example.com"。
			// 2. Mock perm.GetAllReviewersByType 返回的列表中包含 "user1@example.com"，且其状态为 ReviewStatusUnreviewed。
			// 逻辑链路：
			// 1. 调用 perm.GetAllReviewersByType 成功获取已有审批人列表。
			// 2. 遍历待添加的审批人 "user1@example.com", "new_user@example.com"。
			// 3. 发现 "user1@example.com" 已存在且状态不为 ReviewStatusReviewPass。
			// 4. 将 "user1@example.com" 加入 existReviewers 列表。
			// 5. 循环结束后，existReviewers 列表非空，返回“已是审核人员”的错误。

			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com,new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(err.Error(), convey.ShouldContainSubstring, "user1@example.com")
		})

		mockey.PatchConvey("场景四：添加的审批人已存在但状态为通过，校验成功", func() {
			// 场景描述：
			// 验证当尝试添加的审批人已经是审批人，但其状态为“通过”时，系统不应报错，允许操作。
			// 构造数据：
			// 1. pc.Extra 设置为 "user1@example.com"。
			// 2. Mock perm.GetAllReviewersByType 返回的列表中包含 "user1@example.com"，但其状态为 ReviewStatusReviewPass。
			// 逻辑链路：
			// 1. 获取已有审批人列表成功。
			// 2. 遍历待添加审批人，找到 "user1@example.com"。
			// 3. 检查其状态，发现 oldV.Status == _const.ReviewStatusReviewPass，条件不满足。
			// 4. "user1@example.com" 未被加入 existReviewers 列表。
			// 5. 循环结束，existReviewers 列表为空，函数返回 nil。

			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景五：添加全新的审批人，校验成功", func() {
			// 场景描述：
			// 验证当添加的审批人都是新的人员时，函数能够正常通过校验。
			// 构造数据：
			// 1. pc.Extra 设置为 "new_user@example.com"。
			// 2. Mock perm.GetAllReviewersByType 返回一个不包含 "new_user@example.com" 的列表。
			// 逻辑链路：
			// 1. 获取已有审批人列表成功。
			// 2. 遍历待添加审批人 "new_user@example.com"。
			// 3. 在已有列表中未找到该用户。
			// 4. existReviewers 列表为空。
			// 5. 函数返回 nil。

			pc := &auditmodel.ProcessCtx{
				Extra: "new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "test-contract-no",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			allReviewers := model.PreContractReviewerDBList{
				{Reviewer: "existing_user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(allReviewers, nil).Build()

			// 调用
			err := h.Validate(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewAddReviewers_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewAddReviewers_Process", t, func() {
		mockey.PatchConvey("Normal case: should return nil", func() {
			// 场景描述:
			// 测试 handlerFTLReviewAddReviewers.Process 方法的正常执行路径。
			// 构造数据:
			//   - 初始化一个空的 handlerFTLReviewAddReviewers 实例。
			//   - 初始化一个空的 auditmodel.ProcessCtx 实例。
			// 逻辑链路:
			//   1. 调用 Process 方法。
			//   2. 由于当前方法体直接返回 nil，因此预期结果为 nil。
			//   3. 断言返回的 error 为 nil。

			// 准备数据
			h := &handlerFTLReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.Process(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerFTLReviewAddReviewers_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerFTLReviewAddReviewers_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常调用，应始终返回 false 和 nil", func() {
			// 场景描述：
			// 目标函数 HitStateChangeCondition 的实现是直接返回 false 和 nil，无任何外部依赖和复杂逻辑。
			// 因此，本测试用例验证在任何输入下，函数的返回值都符合预期。
			// 构造数据：
			// - 初始化一个 handlerFTLReviewAddReviewers 实例
			// - 初始化一个空的 context.Context
			// - 初始化一个空的 auditmodel.ProcessCtx
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 断言返回的布尔值为 false。
			// 3. 断言返回的 error 为 nil。

			// 数据准备
			h := &handlerFTLReviewAddReviewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerFTLReviewAddReviewers_PostProcess_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock implementation for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerFTLReviewAddReviewers_PostProcess", t, func() {
		// Initialize the handler instance
		h := &handlerFTLReviewAddReviewers{}
		ctx := context.Background()

		// Common mock data
		mockContractNo := "contract-123"
		mockOperator := "operator@example.com"
		mockNewReviewerEmail := "new.reviewer@example.com"
		mockNewReviewer := &peopleclient.Employee{
			ID:    1,
			Email: mockNewReviewerEmail,
		}
		mockCurrentReviewer := &bizmodels.PreContractReviewer{
			Reviewer: mockOperator,
		}

		pc := &auditmodel.ProcessCtx{
			PreContractNo:   mockContractNo,
			CurrentOperator: mockOperator,
			Extra:           mockNewReviewerEmail,
			ContractInfo: &model.ContractMeta{
				ContractNo:        mockContractNo,
				ContractName:      "Test Contract",
				OtherPartyName:    "Test Party",
				CooperationStatus: 1,
				BasicInfo:         &bizmodels.BasicInfo{},
				Reviewers:         bizmodels.PreContractReviewerList{},
			},
		}

		mockey.PatchConvey("scenario: get new reviewers fails", func() {
			// Scene Description:
			// This test case simulates the scenario where fetching employee information for new reviewers fails.
			// Constructed Data:
			// - pc.Extra is set to a new reviewer's email.
			// Mock Logic:
			// 1. Mock `pc.GetCurrentReviewer` to return a dummy reviewer.
			// 2. Mock `larkc.GetEmployeeByMailsWithCache` to return an error.
			// Expected Outcome:
			// - The function should propagate the error and return it.
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockCurrentReviewer).Build()
			expectedErr := errors.New("lark error")
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, expectedErr).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
		})

		mockey.PatchConvey("scenario: operation is add reviewer", func() {
			pc.OperationState = _const.OperationAddReviewer

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockCurrentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockNewReviewer}, nil).Build()

			// Mocks for message sending
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://fake-review-url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.PatchConvey("when countersign reviewer succeeds", func() {
				// Scene Description:
				// This test case simulates the successful addition of a reviewer (加签).
				// Constructed Data:
				// - pc.OperationState is set to OperationAddReviewer.
				// Mock Logic:
				// 1. All initial mocks (`GetCurrentReviewer`, `GetEmployeeByMailsWithCache`) are successful.
				// 2. Mock `h.countersignReviewer` to return nil, simulating a successful operation.
				// 3. Mock the Lark message sending to prevent actual API calls.
				// Expected Outcome:
				// - The function should complete successfully and return nil.
				mockey.Mock((*handlerCommon).countersignReviewer).Return(nil).Build()

				err := h.PostProcess(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("when countersign reviewer fails", func() {
				// Scene Description:
				// This test case simulates a failure during the addition of a reviewer.
				// Constructed Data:
				// - pc.OperationState is set to OperationAddReviewer.
				// Mock Logic:
				// 1. `h.countersignReviewer` is mocked to return an error.
				// Expected Outcome:
				// - The function should stop processing and return the error from `countersignReviewer`.
				expectedErr := errors.New("countersign error")
				mockey.Mock((*handlerCommon).countersignReviewer).Return(expectedErr).Build()

				err := h.PostProcess(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})
		})

		mockey.PatchConvey("scenario: operation is change reviewer", func() {
			pc.OperationState = _const.OperationChangeReviewer
			mockDao := &MockPreContractReviewerDao{}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockCurrentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockNewReviewer}, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

			// Mocks for message sending
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://fake-review-url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.PatchConvey("when change reviewer succeeds", func() {
				// Scene Description:
				// This test case simulates the successful transfer of a review task (转办).
				// Constructed Data:
				// - pc.OperationState is set to OperationChangeReviewer.
				// Mock Logic:
				// 1. `h.changeReviewer` is mocked to succeed.
				// 2. The DAO call `DeleteChangedReviewer` is mocked to succeed.
				// 3. Lark message sending is mocked.
				// Expected Outcome:
				// - The function should complete successfully and return nil.
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

				err := h.PostProcess(ctx, pc)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("when change reviewer fails", func() {
				// Scene Description:
				// This test case simulates a failure during the transfer of a review task.
				// Constructed Data:
				// - pc.OperationState is set to OperationChangeReviewer.
				// Mock Logic:
				// 1. `h.changeReviewer` is mocked to return an error.
				// Expected Outcome:
				// - The function should stop and return the error from `changeReviewer`.
				expectedErr := errors.New("change reviewer error")
				mockey.Mock((*handlerCommon).changeReviewer).Return(expectedErr).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, expectedErr.Error())
			})

			mockey.PatchConvey("when deleting old reviewer fails", func() {
				// Scene Description:
				// This test case simulates a failure when deleting the old reviewer's task, which should be logged but not block the process.
				// Constructed Data:
				// - pc.OperationState is set to OperationChangeReviewer.
				// Mock Logic:
				// 1. `h.changeReviewer` succeeds.
				// 2. The DAO call `DeleteChangedReviewer` is mocked to return an error.
				// Expected Outcome:
				// - The function should log the error but still return nil, indicating overall success.
				mockey.Mock((*handlerCommon).changeReviewer).Return(nil).Build()
				mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
				mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("db delete error")).Build()

				err := h.PostProcess(ctx, pc)
				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("scenario: operation is other type", func() {
			// Scene Description:
			// This test case simulates an operation that is neither Add nor Change, triggering the default message sending.
			// Constructed Data:
			// - pc.OperationState is set to an arbitrary value (e.g., -1).
			// Mock Logic:
			// 1. All initial mocks are successful. The for loop over new reviewers will be skipped.
			// 2. Lark message sending is mocked to catch the default case.
			// Expected Outcome:
			// - The function should run to completion and return nil.
			pc.OperationState = _const.OperationInvalid // An operation that is not add or change
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(mockCurrentReviewer).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{mockNewReviewer}, nil).Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return email }).Build()
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).Return([]string{"sales@example.com"}).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://fake-review-url").Build()
			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

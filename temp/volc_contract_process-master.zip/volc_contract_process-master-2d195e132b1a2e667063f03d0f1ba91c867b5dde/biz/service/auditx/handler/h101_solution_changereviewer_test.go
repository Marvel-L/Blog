package handler

import (
	"context"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	"volc_contract_process/biz/service/riskclauserole"
	"volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerSolutionChangeViewers_Process_BitsUTGen(t *testing.T) {
	// MockRiskClauseRoleService is a mock type for the riskclauserole.Service interface.
	type MockRiskClauseRoleService struct {
		riskclauserole.Service
	}

	mockey.PatchConvey("Test handlerSolutionChangeViewers.Process", t, func() {
		// Common setup for all test cases
		h := handlerSolutionChangeViewers{}
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo: "test-contract-123",
			},
			Extra:           "new_creator@example.com",
			CurrentOperator: "current_operator@example.com",
		}

		mockService := &MockRiskClauseRoleService{}
		// Mock NewService to return our mock service instance for dependency injection
		mockey.Mock(riskclauserole.NewService).Return(mockService).Build()

		mockey.PatchConvey("should return nil when ChangeRiskRoleCreator succeeds", func() {
			// 场景描述：
			// 测试当依赖的 ChangeRiskRoleCreator 方法成功执行（返回nil）时，Process 方法也应返回 nil。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "test-contract-123"
			// - pc.Extra: "new_creator@example.com"
			// - pc.CurrentOperator: "current_operator@example.com"
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 返回一个 MockRiskClauseRoleService 实例。
			// 2. Mock (*MockRiskClauseRoleService).ChangeRiskRoleCreator 方法，使其返回 nil。
			// 3. 调用目标方法 handlerSolutionChangeViewers.Process。
			// 4. 断言返回的 error 为 nil。
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return an error when ChangeRiskRoleCreator fails", func() {
			// 场景描述：
			// 测试当依赖的 ChangeRiskRoleCreator 方法执行失败（返回error）时，Process 方法应将该错误向上透传。
			// 构造数据：
			// - pc.ContractInfo.ContractNo: "test-contract-123"
			// - pc.Extra: "new_creator@example.com"
			// - pc.CurrentOperator: "current_operator@example.com"
			// - 构造一个预期的 error。
			// 逻辑链路：
			// 1. Mock riskclauserole.NewService() 返回一个 MockRiskClauseRoleService 实例。
			// 2. Mock (*MockRiskClauseRoleService).ChangeRiskRoleCreator 方法，使其返回一个预设的 error。
			// 3. 调用目标方法 handlerSolutionChangeViewers.Process。
			// 4. 断言返回的 error 不为 nil，并且错误信息与预设的错误信息一致。
			expectedErr := errors.New("failed to change risk role creator")
			mockey.Mock((*MockRiskClauseRoleService).ChangeRiskRoleCreator).Return(expectedErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "failed to change risk role creator")
		})
	})
}

// Test_handlerSolutionChangeViewers_PostProcess tests the PostProcess method of handlerSolutionChangeViewers.
func Test_handlerSolutionChangeViewers_PostProcess_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock implementation for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_handlerSolutionChangeViewers_PostProcess", t, func() {
		// Arrange: Initialize the handler.
		h := handlerSolutionChangeViewers{}
		mockDao := &MockPreContractReviewerDao{}

		mockey.PatchConvey("Success case: Change reviewer successfully", func() {
			// Scene Description:
			// This test case simulates the successful process of changing a reviewer.
			// Data setup:
			// - pc.OperationState is set to OperationChangeReviewer.
			// - pc.Extra contains the email of the new reviewer.
			// - pc.CurrentOperator is the email of the old reviewer.
			// Logic flow:
			// 1. GetCurrentReviewer is mocked to return a dummy reviewer to prevent nil pointer issues.
			// 2. GetEmployeeByMailsWithCache successfully returns the new reviewer's info.
			// 3. The internal `changeReviewer` function is executed.
			// 4. `FindReviewersByNoAndEmail` for the old reviewer returns their roles.
			// 5. `FindReviewersByNoAndEmail` for the new reviewer returns an empty list.
			// 6. `Create` is called to add the new reviewer with the old roles, and succeeds.
			// 7. `DeleteChangedReviewer` is called to remove the old reviewer, and succeeds.
			// 8. A Lark notification is sent via `BatchSendMessageToEmailIgnore`.
			// 9. The function returns no error.

			// Arrange: Prepare test data and context.
			ctx := context.Background()
			oldReviewerEmail := "old.reviewer@example.com"
			newReviewerEmail := "new.reviewer@example.com"
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-001",
				CurrentOperator: oldReviewerEmail,
				OperationState:  _const.OperationChangeReviewer,
				Extra:           newReviewerEmail,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "PC-2023-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					BasicInfo: &bizmodels.BasicInfo{
						DepartmentId: "D001",
					},
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "sales@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
					},
				},
			}

			// Arrange: Mock dependencies.
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()

			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
				{ID: 1001, Email: newReviewerEmail},
			}, nil).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).
				When(func(_ context.Context, _ *gorm.DB, _ string, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).
				Return(model.PreContractReviewerDBList{
					{
						PreContractNo:  pc.PreContractNo,
						Reviewer:       oldReviewerEmail,
						ReviewerType:   _const.ReviewerTypeFinanceTaxationLegalReviewer,
						ContractStatus: 1,
					},
				}, nil).
				When(func(_ context.Context, _ *gorm.DB, _ string, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).
				Return(model.PreContractReviewerDBList{}, nil).
				Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()

			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(nil).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act: Call the target function.
			err := h.PostProcess(ctx, pc)

			// Assert: Check the result.
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case: GetEmployeeByMailsWithCache returns an error", func() {
			// Scene Description:
			// This test case simulates a failure where fetching the new reviewer's information fails.
			// Logic flow:
			// 1. GetCurrentReviewer is mocked to prevent a nil pointer panic.
			// 2. GetEmployeeByMailsWithCache returns an error.
			// 3. The function should log the error and return it immediately.

			// Arrange
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				Extra: "new.reviewer@example.com",
			}
			expectedErr := errors.New("lark API error")
			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return(nil, expectedErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "lark API error")
		})

		mockey.PatchConvey("Failure case: changeReviewer fails on DB create", func() {
			// Scene Description:
			// This test case simulates a failure during the `changeReviewer` process, specifically when creating the new reviewer's roles in the database.
			// Logic flow:
			// 1. GetCurrentReviewer is mocked to prevent a nil pointer panic.
			// 2. GetEmployeeByMailsWithCache succeeds.
			// 3. The internal `changeReviewer` function is executed.
			// 4. `FindReviewersByNoAndEmail` calls succeed.
			// 5. `Create` is called but returns a database error.
			// 6. The function should propagate this error and return it.

			// Arrange
			ctx := context.Background()
			oldReviewerEmail := "old.reviewer@example.com"
			newReviewerEmail := "new.reviewer@example.com"
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-002",
				CurrentOperator: oldReviewerEmail,
				OperationState:  _const.OperationChangeReviewer,
				Extra:           newReviewerEmail,
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{DepartmentId: "D002"},
				},
			}
			dbCreateErr := errors.New("db create failed")

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{
				{ID: 1002, Email: newReviewerEmail},
			}, nil).Build()

			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).
				When(func(_ context.Context, _ *gorm.DB, _ string, reviewer string) bool {
					return reviewer == oldReviewerEmail
				}).
				Return(model.PreContractReviewerDBList{{}}, nil).
				When(func(_ context.Context, _ *gorm.DB, _ string, reviewer string) bool {
					return reviewer == newReviewerEmail
				}).
				Return(model.PreContractReviewerDBList{}, nil).
				Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock((*MockPreContractReviewerDao).Create).Return(dbCreateErr).Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db create failed")
		})

		mockey.PatchConvey("Failure case: DeleteChangedReviewer returns an error", func() {
			// Scene Description:
			// This test case simulates a non-critical failure where deleting the old reviewer record fails.
			// Logic flow:
			// 1. GetCurrentReviewer is mocked to prevent a nil pointer panic.
			// 2. `changeReviewer` succeeds.
			// 3. `DeleteChangedReviewer` is called and returns a database error.
			// 4. The error is logged, but the function should still return `nil` as this is not a blocking error.

			// Arrange
			ctx := context.Background()
			oldReviewerEmail := "old.reviewer@example.com"
			newReviewerEmail := "new.reviewer@example.com"
			pc := &auditmodel.ProcessCtx{
				PreContractNo:   "PC-2023-003",
				CurrentOperator: oldReviewerEmail,
				OperationState:  _const.OperationChangeReviewer,
				Extra:           newReviewerEmail,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "PC-2023-003",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					BasicInfo:      &bizmodels.BasicInfo{DepartmentId: "D001"},
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetCurrentReviewer).Return(&bizmodels.PreContractReviewer{}).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock(larkc.GetEmployeeByMailsWithCache).Return([]*peopleclient.Employee{{ID: 1003, Email: newReviewerEmail}}, nil).Build()

			// Mock successful changeReviewer
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNoAndEmail).Return(model.PreContractReviewerDBList{{}}, nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock((*MockPreContractReviewerDao).Create).Return(nil).Build()

			// Mock failed DeleteChangedReviewer
			mockey.Mock((*MockPreContractReviewerDao).DeleteChangedReviewer).Return(errors.New("db delete failed")).Build()
			mockey.Mock((*MockPreContractReviewerDao).UpdateByID).Return(nil).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			// Act
			err := h.PostProcess(ctx, pc)

			// Assert
			// The error from DeleteChangedReviewer is only logged, not returned.
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionChangeViewers_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionChangeViewers_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况-直接返回false和nil", func() {
			// 场景描述：
			// 目标函数是一个空实现，总是返回 false 和 nil。
			// 构造数据：
			// 无特殊构造。
			// 逻辑链路：
			// 1. 调用目标函数。
			// 2. 断言返回值为 false 和 nil。

			// 数据准备
			h := handlerSolutionChangeViewers{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeFalse)
		})
	})
}

func Test_handlerSolutionChangeViewers_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionChangeViewers_Validate", t, func() {
		h := handlerSolutionChangeViewers{}
		ctx := context.Background()

		mockey.PatchConvey("场景1: 失败 - 人员为空", func() {
			// 场景描述:
			// 构造数据: pc.Extra为空字符串.
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra长度为0.
			// 2. 返回 "人员不可为空" 错误.
			pc := &auditmodel.ProcessCtx{
				Extra: "",
			}

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "人员不可为空")
		})

		mockey.PatchConvey("场景2: 失败 - 获取已有审核人失败", func() {
			// 场景描述:
			// 构造数据: pc.Extra不为空.
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra长度不为0.
			// 2. 调用perm.GetAllReviewersByType，mock返回一个错误.
			// 3. 函数将错误直接返回.
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "C001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			expectedErr := errors.New("failed to get reviewers")
			mockey.Mock(perm.GetAllReviewersByType).Return(nil, expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("场景3: 成功 - 新增人员不存在", func() {
			// 场景描述:
			// 构造数据: pc.Extra为新用户 "new_user@example.com".
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra不为空.
			// 2. 调用perm.GetAllReviewersByType, mock返回一个不包含 "new_user@example.com" 的列表.
			// 3. existReviewers列表为空.
			// 4. 函数返回nil.
			pc := &auditmodel.ProcessCtx{
				Extra: "new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "C001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing_user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 失败 - 新增人员已存在且未通过", func() {
			// 场景描述:
			// 构造数据: pc.Extra包含一个已存在的用户 "existing_user@example.com".
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra不为空.
			// 2. 调用perm.GetAllReviewersByType, mock返回一个包含 "existing_user@example.com" 且状态为未审核的列表.
			// 3. existReviewers列表包含 "existing_user@example.com".
			// 4. 函数返回 "已是审核人员" 错误.
			pc := &auditmodel.ProcessCtx{
				Extra: "existing_user@example.com,new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "C001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "existing_user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(errorsV2.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "existing_user@example.com")
		})

		mockey.PatchConvey("场景5: 成功 - 新增人员已存在但已通过", func() {
			// 场景描述:
			// 构造数据: pc.Extra包含一个已存在的用户 "passed_user@example.com", 但其状态为审核通过.
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra不为空.
			// 2. 调用perm.GetAllReviewersByType, mock返回一个包含 "passed_user@example.com" 且状态为审核通过的列表.
			// 3. existReviewers列表为空，因为状态为通过的审核人会被过滤掉.
			// 4. 函数返回nil.
			pc := &auditmodel.ProcessCtx{
				Extra: "passed_user@example.com,new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "C001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "passed_user@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewPass}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景6: 失败 - 多个新增人员已存在", func() {
			// 场景描述:
			// 构造数据: pc.Extra包含多个已存在的用户 "user1@example.com" 和 "user2@example.com".
			// 逻辑链路:
			// 1. commonValidateUpdateReviewers函数检查pc.Extra不为空.
			// 2. 调用perm.GetAllReviewersByType, mock返回包含这两个用户的列表, 且状态都未通过.
			// 3. existReviewers列表包含 "user1@example.com" 和 "user2@example.com".
			// 4. 函数返回的错误信息应包含这两个用户的拼接字符串.
			pc := &auditmodel.ProcessCtx{
				Extra: "user1@example.com,user2@example.com,new_user@example.com",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "C001",
					CooperationStatus: 1,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ReviewerType: 1,
				},
			}
			mockey.Mock(perm.GetAllReviewersByType).Return(model.PreContractReviewerDBList{
				{Reviewer: "user1@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusUnreviewed}},
				{Reviewer: "user2@example.com", BaseDB: model.BaseDB{Status: _const.ReviewStatusReviewSendBack}},
			}, nil).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			apiErr, ok := err.(errorsV2.APIError)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "已是审核人员")
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "user1@example.com,user2@example.com")
		})
	})
}

func Test_handlerSolutionChangeViewers_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionChangeViewers CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationChangeReviewer", func() {
			// 场景描述：
			// 测试 CurrentOp 方法是否返回正确的操作码。
			// 构造数据：
			// 创建一个 handlerSolutionChangeViewers 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于预期的常量 _const.OperationChangeReviewer。

			// 数据准备
			h := handlerSolutionChangeViewers{}

			// 调用
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationChangeReviewer)
		})
	})
}

func Test_handlerSolutionChangeViewers_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionChangeViewers_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试handlerSolutionChangeViewers的CurrentStatus方法是否返回正确的状态码。
			// 构造数据：
			// 创建一个handlerSolutionChangeViewers实例。
			// 逻辑链路：
			// 1. 调用CurrentStatus方法。
			// 2. 验证返回值是否为_const.PreSalesContractSolutionReview。

			// 准备数据
			h := handlerSolutionChangeViewers{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSolutionReview)
		})
	})
}

func Test_newHandlerSolutionChangeViewers_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSolutionChangeViewers", t, func() {
		mockey.PatchConvey("正常创建", func() {
			// 场景描述：
			// 测试newHandlerSolutionChangeViewers函数能否成功创建一个非空的handler实例。
			// 构造数据：
			// 无
			// 逻辑链路：
			// 1. 调用 newHandlerSolutionChangeViewers 函数。
			// 2. 断言返回的实例不为nil。
			// 3. 断言返回的实例类型为 *handlerSolutionChangeViewers。

			// 调用
			result := newHandlerSolutionChangeViewers()

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldHaveSameTypeAs, &handlerSolutionChangeViewers{})
		})
	})
}

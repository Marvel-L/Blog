package handler

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_handlerSolutionSendBack_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionSendBack_PostProcess", t, func() {
		// Common setup for all test cases
		ctx := context.Background()
		h := handlerSolutionSendBack{}
		// This mock builder instance is used as the return value for the mocked chained methods.
		// The methods are mocked on the type, so they will apply to the real instance created in the SUT.
		mockBuilder := larkc.NewCommonMessageCardBuilder()

		mockey.PatchConvey("should send lark message and return nil when process is successful", func() {
			// 场景描述：
			// 这是一个成功的场景，函数找到需要通知的销售运营和在消息中需要@的销售人员，
			// 构建飞书卡片消息并发送，最终返回nil。
			// 构造数据：
			// - pc: 一个ProcessCtx实例，包含合同信息和状态变更值。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 返回一个销售运营的邮箱列表。
			// 2. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 返回一个销售人员的邮箱列表。
			// 3. Mock larkc.LarkMdAtEmail 来格式化销售人员的邮箱。
			// 4. Mock multienv.I18nFormat 来处理国际化文本。
			// 5. Mock i18nfmt.Sprintf 来生成消息内容。
			// 6. Mock larkc.GenReviewURL 来生成审核链接。
			// 7. Mock larkc.CommonMessageCardBuilder 的链式调用，并让 BuildJSONString 返回一个预设的JSON字符串。
			// 8. Mock larkc.BatchSendMessageToEmailIgnore 模拟飞书消息的发送。
			// 9. 调用 PostProcess 方法。
			// 10. 断言返回的error为nil。

			// Data preparation
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: 12345,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-001",
					ContractName:   "Test Contract",
					OtherPartyName: "Test Party",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			// Mocks
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{"operation@example.com"}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{"salesperson@example.com"}).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v // Return as-is for simplicity
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string {
				return fmt.Sprintf("<at email=%s>", email)
			}).Build()

			mockey.Mock(larkc.GenReviewURL).Return("http://review.url/CONTRACT-001").Build()

			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("mock-json-payload").Build()

			// Call the target function
			err := h.PostProcess(ctx, pc)

			// Assertions
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should not fail when no reviewers are found", func() {
			// 场景描述：
			// 测试当没有找到任何需要通知的审核人时，函数的行为。
			// 预期函数应该静默处理，不发送消息（即发送给空列表），并且不返回错误。
			// 构造数据：
			// - pc: 一个ProcessCtx实例。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus 返回一个空列表。
			// 2. Mock (*handlerCommon).getReviewerFromPreContractReviewerList 返回一个空列表。
			// 3. 其他Mocks与成功场景类似。
			// 4. 调用 PostProcess 方法。
			// 5. 断言返回的error为nil。

			// Data preparation
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: 54321,
				ContractInfo: &model.ContractMeta{
					ContractNo:     "CONTRACT-002",
					ContractName:   "Empty Reviewer Contract",
					OtherPartyName: "Test Party 2",
					Reviewers:      bizmodels.PreContractReviewerList{},
				},
			}

			// Mocks
			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerListWithContractStatus).
				Return([]string{}).Build()

			mockey.Mock((*handlerCommon).getReviewerFromPreContractReviewerList).
				Return([]string{}).Build()

			mockey.Mock(larkc.BatchSendMessageToEmailIgnore).Return().Build()

			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(larkc.LarkMdAtEmail).To(func(email string) string { return "" }).Build()
			mockey.Mock(larkc.GenReviewURL).Return("http://review.url/CONTRACT-002").Build()

			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitleColor).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetTitle).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).SetContent).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddField).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).AddAction).Return(mockBuilder).Build()
			mockey.Mock((*larkc.CommonMessageCardBuilder).BuildJSONString).Return("mock-json-payload-for-empty").Build()

			// Call the target function
			err := h.PostProcess(ctx, pc)

			// Assertions
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非已退回状态时不通知C360", func() {
			pc := &auditmodel.ProcessCtx{
				StatusChangedValue: _const.PreSalesContractSalesOperationReview,
			}
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(nil).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 1)
			convey.So(peerCount, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("清理退回状态失败时直接返回", func() {
			expectedErr := errors.New("clear failed")
			notifyCount := 0
			targetCount := 0
			peerCount := 0

			mockey.Mock((*handlerCommon).clearSendBackStatusQuoteAndReviewers).Return(expectedErr).Build()
			mockey.Mock((*handlerCommon).notifyC360).To(func(h *handlerCommon, ctx context.Context, eventType string, pc *auditmodel.ProcessCtx) error {
				notifyCount++
				return nil
			}).Build()
			mockey.Mock((*handlerCommon).sendBackNotifyTargetReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				targetCount++
			}).Build()
			mockey.Mock((*handlerCommon).SendBackNotifyPeerReviewers).To(func(h *handlerCommon, ctx context.Context, pc *auditmodel.ProcessCtx) {
				peerCount++
			}).Build()

			err := h.PostProcess(ctx, &auditmodel.ProcessCtx{})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(notifyCount, convey.ShouldEqual, 0)
			convey.So(targetCount, convey.ShouldEqual, 0)
			convey.So(peerCount, convey.ShouldEqual, 0)
		})
	})
}

func Test_handlerSolutionSendBack_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionSendBack.Validate", t, func() {
		// Common setup
		h := handlerSolutionSendBack{}
		ctx := context.Background()

		mockey.PatchConvey("场景：前置检查失败", func() {
			// 场景描述：
			// 依赖的 commonCheckReviewerPass 方法返回错误。
			// 构造数据：
			// 构造一个空的 auditmodel.ProcessCtx。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回一个自定义的 error。
			// 2. 调用目标函数 Validate。
			// 3. 断言 Validate 返回的 error 与 Mock 的 error 一致。
			pc := &auditmodel.ProcessCtx{}
			expectedErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(expectedErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "common check failed")
		})

		mockey.PatchConvey("场景：前置检查成功，但审核意见为空", func() {
			// 场景描述：
			// commonCheckReviewerPass 检查通过，但审核意见为空。
			// 构造数据：
			// 构造 ProcessCtx，使其 Comment 字段不为 nil，但其 IsEmpty 方法返回 true。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回 nil（表示通过）。
			// 2. 构造一个非nil的Comment，并Mock其 (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 true。
			// 3. Mock i18nfmt.New 方法以隔离国际化逻辑，使其返回一个包含特定文本的 error。
			// 4. 调用目标函数 Validate。
			// 5. 断言 Validate 返回 "审核意见不可为空" 的错误。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("场景：所有检查成功", func() {
			// 场景描述：
			// 所有校验均通过，函数成功返回。
			// 构造数据：
			// 构造 ProcessCtx，使其 Comment 字段不为 nil，且其 IsEmpty 方法返回 false。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法，使其返回 nil（表示通过）。
			// 2. 构造一个非nil的Comment，并Mock其 (*bizmodels.RichTextInfo).IsEmpty 方法，使其返回 false。
			// 3. 调用目标函数 Validate。
			// 4. 断言 Validate 返回 nil。
			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionSendBack_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionSendBack_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况，应始终返回true", func() {
			// 场景描述：
			// 构造数据：创建一个空的handlerSolutionSendBack实例和ProcessCtx实例。
			// 逻辑链路：
			// 1. 调用HitStateChangeCondition方法。
			// 2. 函数直接返回true和nil。
			// 3. 断言返回值为true，error为nil。
			h := handlerSolutionSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerSolutionSendBack_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionSendBack_Process", t, func() {
		mockey.PatchConvey("正常处理返回nil", func() {
			// 场景描述：
			// 构造数据：创建一个空的handlerSolutionSendBack实例和一个空的ProcessCtx。
			// 逻辑链路：
			// 1. 调用Process方法。
			// 2. 由于函数体直接返回nil，预期得到nil错误。
			h := handlerSolutionSendBack{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerSolutionSendBack_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerSolutionSendBack CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSendBack", func() {
			// 场景描述：
			// 构造数据：创建一个 handlerSolutionSendBack 的实例。
			// 逻辑链路：
			// 1. 调用 CurrentOp 方法。
			// 2. 验证返回值是否等于预定义的常量 _const.OperationSendBack。

			// 构造实例
			h := handlerSolutionSendBack{}

			// 调用方法
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSendBack)
		})
	})
}

func Test_handlerSolutionSendBack_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerSolutionSendBack_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述：
			// 测试 CurrentStatus 方法是否返回正确的状态码。
			// 构造数据：
			// 创建一个 handlerSolutionSendBack 实例。
			// 逻辑链路：
			// 1. 调用 CurrentStatus 方法。
			// 2. 验证返回值是否等于预期的常量 _const.PreSalesContractSolutionReview。

			h := handlerSolutionSendBack{}

			// 调用
			result := h.CurrentStatus()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSolutionReview)
		})
	})
}

func Test_newHandlerSolutionSendBack_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerSolutionSendBack", t, func() {
		mockey.PatchConvey("正常情况：成功创建一个handler", func() {
			// 场景描述：
			// 构造数据：无
			// 逻辑链路：
			// 1. 调用 newHandlerSolutionSendBack 函数。
			// 2. 验证返回的 handler 不为 nil。
			// 3. 验证返回的 handler 的类型是 *handlerSolutionSendBack。

			// 调用目标函数
			handler := newHandlerSolutionSendBack()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(handler, convey.ShouldHaveSameTypeAs, &handlerSolutionSendBack{})
		})
	})
}

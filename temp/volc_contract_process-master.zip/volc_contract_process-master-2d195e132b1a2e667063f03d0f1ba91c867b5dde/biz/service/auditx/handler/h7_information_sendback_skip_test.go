package handler

import (
	"context"
	"encoding/json"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"reflect"
	"volc_contract_process/pkg/const"
)

func Test_handlerInformationSendBackSkip_Process_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBackSkip_Process", t, func() {
		h := &handlerInformationSendBackSkip{}
		ctx := context.Background()

		mockey.PatchConvey("success", func() {
			// 场景描述：
			// 构造数据：构造一个ProcessCtx，其中IsSkipFTL为true
			// 逻辑链路：
			// 1. 函数将 IsSkipFTL 设置为 false
			// 2. json.Marshal 成功
			// 3. 将序列化后的字符串赋值给 PreContractVO.BasicInfo
			// 4. 调用 h.updateContractData 成功
			// 5. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true, // 初始为 true
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			mockey.Mock((*handlerCommon).updateContractData).Return(nil).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ContractInfo.BasicInfo.IsSkipFTL, convey.ShouldBeFalse)

			// 验证 PreContractVO.BasicInfo 被正确更新
			expectedBasicInfo, _ := json.Marshal(&bizmodels.BasicInfo{IsSkipFTL: false})
			convey.So(pc.PreContractVO.BasicInfo, convey.ShouldEqual, string(expectedBasicInfo))
		})

		mockey.PatchConvey("json marshal failed", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx
			// 逻辑链路：
			// 1. 函数将 IsSkipFTL 设置为 false
			// 2. Mock json.Marshal使其返回错误
			// 3. 函数记录错误日志并返回该错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}

			// Mock json.Marshal 失败
			mockey.Mock(json.Marshal).Return(nil, errors.New("json marshal error")).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "json marshal error")
		})

		mockey.PatchConvey("updateContractData failed", func() {
			// 场景描述：
			// 构造数据：构造一个 ProcessCtx
			// 逻辑链路：
			// 1. 函数将 IsSkipFTL 设置为 false
			// 2. json.Marshal 成功
			// 3. Mock h.updateContractData使其返回错误
			// 4. 函数记录错误日志并返回该错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
				PreContractVO: &model.ContractMetaDB{},
			}
			mockErr := errors.New("update contract data failed")

			mockey.Mock((*handlerCommon).updateContractData).Return(mockErr).Build()

			err := h.Process(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "update contract data failed")
		})
	})
}

func Test_handlerInformationSendBackSkip_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBackSkip_Validate", t, func() {
		h := &handlerInformationSendBackSkip{}
		ctx := context.Background()

		mockey.PatchConvey("场景：commonCheckReviewerPass前置校验失败", func() {
			// 场景描述：
			// 调用 Validate 方法时，第一步 h.commonCheckReviewerPass 返回错误。
			// 构造数据：
			//  - pc: 一个空的 auditmodel.ProcessCtx 即可。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回一个自定义错误。
			// 2. 调用 h.Validate(ctx, pc)。
			// 3. 断言返回的错误就是 Mock 的错误。

			pc := &auditmodel.ProcessCtx{}
			mockErr := errors.New("common check failed")
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(mockErr).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, mockErr.Error())
		})

		mockey.PatchConvey("场景：审核意见为空", func() {
			// 场景描述：
			// commonCheckReviewerPass 校验通过，但审核意见为空。
			// 构造数据：
			//  - pc: ProcessCtx.Comment 为一个空的 RichTextInfo 实例。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回 nil。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法返回 true。
			// 3. 调用 h.Validate(ctx, pc)。
			// 4. 断言返回错误，且错误信息包含 "审核意见不可为空"。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(true).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审核意见不可为空")
		})

		mockey.PatchConvey("场景：合同未跳过财税法审批", func() {
			// 场景描述：
			// 前置校验和审核意见校验都通过，但合同信息中的 IsSkipFTL 标志为 false。
			// 构造数据：
			//  - pc: ProcessCtx.ContractInfo.BasicInfo.IsSkipFTL 设置为 false。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回 nil。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法返回 false。
			// 3. 调用 h.Validate(ctx, pc)。
			// 4. 断言返回错误，且错误信息包含 "此合同未跳过财税法审批，不可执行此操作类型。"。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: false,
					},
				},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "此合同未跳过财税法审批，不可执行此操作类型。")
		})

		mockey.PatchConvey("场景：校验成功", func() {
			// 场景描述：
			// 所有校验条件均满足，函数应成功返回 nil。
			// 构造数据：
			//  - pc: 包含非空的审核意见，并且 ContractInfo.BasicInfo.IsSkipFTL 设置为 true。
			// 逻辑链路：
			// 1. Mock (*handlerCommon).commonCheckReviewerPass 方法返回 nil。
			// 2. Mock (*bizmodels.RichTextInfo).IsEmpty 方法返回 false。
			// 3. 调用 h.Validate(ctx, pc)。
			// 4. 断言返回的错误为 nil。

			pc := &auditmodel.ProcessCtx{
				Comment: &bizmodels.RichTextInfo{},
				ContractInfo: &model.ContractMeta{
					BasicInfo: &bizmodels.BasicInfo{
						IsSkipFTL: true,
					},
				},
			}
			mockey.Mock((*handlerCommon).commonCheckReviewerPass).Return(nil).Build()
			mockey.Mock((*bizmodels.RichTextInfo).IsEmpty).Return(false).Build()

			err := h.Validate(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerInformationSendBackSkip_PostProcess_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test handlerInformationSendBackSkip PostProcess", t, func() {
		mockey.PatchConvey("Normal case: should always return nil", func() {
			// 场景描述：
			// 目标函数 PostProcess 的实现是直接返回 nil，没有任何业务逻辑。
			// 构造数据：
			// - h: 一个 handlerInformationSendBackSkip 实例。
			// - ctx: 一个背景上下文。
			// - pc: 一个 ProcessCtx 实例。
			// 逻辑链路：
			// 1. 调用 PostProcess 方法。
			// 2. 断言返回的 error 为 nil。
			h := &handlerInformationSendBackSkip{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用目标函数
			err := h.PostProcess(ctx, pc)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_handlerInformationSendBackSkip_HitStateChangeCondition_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBackSkip_HitStateChangeCondition", t, func() {
		mockey.PatchConvey("正常情况，应直接返回 true 和 nil", func() {
			// 场景描述：
			// 构造数据：初始化 handlerInformationSendBackSkip 和空的 ProcessCtx。
			// 逻辑链路：
			// 1. 调用 HitStateChangeCondition 方法。
			// 2. 该方法不依赖任何外部调用或内部状态，直接返回 true 和 nil。
			// 3. 断言返回结果为 true 和 nil。

			// 数据准备
			h := &handlerInformationSendBackSkip{}
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{}

			// 调用
			hit, err := h.HitStateChangeCondition(ctx, pc)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(hit, convey.ShouldBeTrue)
		})
	})
}

func Test_handlerInformationSendBackSkip_CurrentOp_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBackSkip_CurrentOp", t, func() {
		mockey.PatchConvey("should return OperationSendBackSkipApproval", func() {
			// 场景描述：
			// 测试CurrentOp方法，它应该总是返回常量 _const.OperationSendBackSkipApproval。
			// 构造数据：
			// - 初始化一个 handlerInformationSendBackSkip 实例。
			// 逻辑链路：
			// 1. 创建 handlerInformationSendBackSkip 实例。
			// 2. 调用 CurrentOp 方法。
			// 3. 断言返回值等于 _const.OperationSendBackSkipApproval。

			// 准备数据
			h := &handlerInformationSendBackSkip{}

			// 调用目标函数
			result := h.CurrentOp()

			// 断言
			convey.So(result, convey.ShouldEqual, _const.OperationSendBackSkipApproval)
		})
	})
}

func Test_handlerInformationSendBackSkip_CurrentStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_handlerInformationSendBackSkip_CurrentStatus", t, func() {
		mockey.PatchConvey("正常情况", func() {
			// 场景描述:
			// 测试 CurrentStatus 方法是否能正确返回预期的状态常量。
			// 构造数据:
			// - 初始化一个 handlerInformationSendBackSkip 实例。
			// 逻辑链路:
			// 1. 创建 handlerInformationSendBackSkip 实例。
			// 2. 调用其 CurrentStatus 方法。
			// 3. 断言返回值等于预定义的常量 _const.PreSalesContractSalesOperationCompleteInformation。

			h := &handlerInformationSendBackSkip{}

			// 调用目标函数
			result := h.CurrentStatus()

			// 断言结果
			convey.So(result, convey.ShouldEqual, _const.PreSalesContractSalesOperationCompleteInformation)
		})
	})
}

func Test_newHandlerInformationSendBackSkip_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_newHandlerInformationSendBackSkip", t, func() {
		mockey.PatchConvey("should return a non-nil handler", func() {
			// 场景描述:
			// 测试 newHandlerInformationSendBackSkip 函数能否成功创建一个处理器实例。
			// 构造数据:
			// 无
			// 逻辑链路:
			// 1. 调用 newHandlerInformationSendBackSkip 函数。
			// 2. 断言返回的实例不为 nil。
			// 3. 断言返回的实例的具体类型为 *handlerInformationSendBackSkip。

			// 调用目标函数
			handler := newHandlerInformationSendBackSkip()

			// 断言
			convey.So(handler, convey.ShouldNotBeNil)
			convey.So(reflect.TypeOf(handler), convey.ShouldEqual, reflect.TypeOf(&handlerInformationSendBackSkip{}))
		})
	})
}

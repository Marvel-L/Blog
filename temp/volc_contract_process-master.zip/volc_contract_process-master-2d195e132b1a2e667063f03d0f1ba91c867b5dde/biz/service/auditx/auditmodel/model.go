package auditmodel

//import (
//	"volc_contract_process/biz/bizmodels"
//)
//
//type CheckRelateSubjectPartyReq struct {
//	BizSource           int
//	CooperationStatus   int
//	SpecialContractType string
//	BusinessType        int
//	TradePartyInfo      *bizmodels.TradePartyInfo
//}
//
//type GetEffectiveSubjectMapReq struct {
//	BusinessType        int
//	SpecialContractType string
//	AccountIDs          []string
//}

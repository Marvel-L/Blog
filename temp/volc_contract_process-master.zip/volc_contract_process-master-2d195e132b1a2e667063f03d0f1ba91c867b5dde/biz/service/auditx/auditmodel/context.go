package auditmodel

import (
	"encoding/json"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/proxy/riskenginecli"

	"gorm.io/gorm"

	_const "volc_contract_process/pkg/const"
)

// ProcessCtx 引擎上下文
type ProcessCtx struct {
	IsOpenCall                   bool                                   // 是否通过open api调用
	PreContractNo                string                                 //
	CurrentOperator              string                                 // 当前用户，使用user.email
	OperationState               int                                    // 操作动作: 审核通过、加签、撤回....
	SecondaryOperationType       int                                    // 二级操作类型: 审核通过无修改、审核通过有修改
	SkipReturnReview             int                                    // 返稿重审类型：0-忽略处理，1-审核通过无异议，2-修改/确认后重审
	Remark                       string                                 // 审批意见
	Comment                      *bizmodels.RichTextInfo                // 审批意见富文本信息
	Extra                        string                                 // 加签人员
	ContractInfo                 *model.ContractMeta                    // 合同协同实例
	PreContractVO                *model.ContractMetaDB                  // 合同协同实例原始数据
	AttachmentUpdateList         []*bizmodels.MetaAttachment            // 附件附加信息更新
	ReviewerStatusOpConf         *modelcooperation.ReviewerStatusOpConf // 状态操作配置
	tx                           *gorm.DB                               //
	RelateQuoteChange            bool                                   // 关联报价单变更
	RelateQuoteChangeBeforeValue string                                 // 关联报价单变更前结果
	StatusChanged                bool                                   //
	StatusChangedValue           int                                    // 状态变更后的结果
	InternalState                interface{}                            // 不同 handler 内部自定义的状态
	ApprovalKey                  string                                 // 审批流 Key 关联模板 ID 执行不同的审批流
	DelExtKeys                   []string                               // 需要删除的 ExtKey
	Ext                          map[string]string                      // 业务方传入参数
	IsSecondConfirm              int                                    // 二次确认标识: 0-否，1-是
	SendBackTargetStatus         int                                    // 指定退回目标节点状态，仅 SecondaryOperationType=1 时必填

	TextParam map[string]interface{}
	// TableParam map[string][]map[string][]interface{}
	TableParam map[string]*bizmodels.TableReplaceData

	// 记录版本信息
	RecordVersions []*bizmodels.FileVersionData
	// 变更信息
	// ChangedFieldInfo ChangedFieldInfo
	SkipReturnReviewNoAuditEmails []string // 返稿场景不需要审批的人员列表
	// 流程数据
	ComplianceCheckInfo *riskenginecli.RiskEngineResp
}

func (pc *ProcessCtx) GetTx() *gorm.DB {
	return pc.tx
}

func (pc *ProcessCtx) SetTX(tx *gorm.DB) {
	pc.tx = tx
}

func (pc *ProcessCtx) CalcApprovalKey() {
	pc.ApprovalKey = pc.PreContractVO.CalcApprovalKey()
}

func (pc *ProcessCtx) IsSpecifiedSendBack() bool {
	return (pc.OperationState == _const.OperationSendBack || pc.OperationState == _const.OperationSendBackSkipApproval || pc.OperationState == _const.OperationSendBackWithTemplate) &&
		pc.SecondaryOperationType == _const.SecondaryOperationTypeSendBackSpecified
}

// IsQuoteUnbinding 判断本次修改是否为已完成报价审批变更为未完成报价审批。
func (pc *ProcessCtx) IsQuoteUnbinding() bool {
	return pc != nil && pc.RelateQuoteChange && pc.RelateQuoteChangeBeforeValue != "" &&
		pc.ContractInfo != nil && pc.ContractInfo.RelateQuoteNo == "" &&
		pc.ContractInfo.RelateQuoteScene == _const.RelateQuoteSceneNoCompleted
}

func (pc *ProcessCtx) GetCurrentReviewer() *bizmodels.PreContractReviewer {
	var currentReviewer, lastReviewer *bizmodels.PreContractReviewer
	curStatusReviewerType := pc.ReviewerStatusOpConf.ReviewerType
	// 计算当前节点审核人
	for _, reviewer := range pc.ContractInfo.Reviewers {
		if reviewer.ContractStatus == pc.ContractInfo.CooperationStatus &&
			reviewer.ReviewerType == curStatusReviewerType &&
			reviewer.Reviewer == pc.CurrentOperator {
			currentReviewer = reviewer
		}
		// 计算当前节点未审核通过的最晚加签的审核人
		if reviewer.ContractStatus == pc.ContractInfo.CooperationStatus &&
			reviewer.ReviewerType == curStatusReviewerType &&
			reviewer.Status != _const.ReviewStatusReviewPass {
			if lastReviewer == nil || lastReviewer.Priority < reviewer.Priority {
				lastReviewer = reviewer
			}
		}
	}
	if currentReviewer == nil {
		return lastReviewer
	}
	return currentReviewer
}

type ChangedFieldInfo struct {
	BasicTemplateTypeChange bool // 合同模板类型变更
}

// UpdateBelongingDepartment 更新一级产品线
func (pc *ProcessCtx) UpdateBelongingDepartment(belongingDepartment string, force bool) {
	if pc.ContractInfo != nil && pc.ContractInfo.ManageInfo != nil {
		if force || pc.ContractInfo.ManageInfo.BelongingDepartment == "" {
			pc.ContractInfo.ManageInfo.BelongingDepartment = belongingDepartment
		}
	}
	if pc.PreContractVO != nil {
		var manage bizmodels.ManageInfo
		_ = json.Unmarshal([]byte(pc.PreContractVO.ManageInfo), &manage)
		if force || manage.BelongingDepartment == "" {
			manage.BelongingDepartment = belongingDepartment
			body, _ := json.Marshal(manage)
			pc.PreContractVO.ManageInfo = string(body)
		}
	}
}

// UpdateProductSolutionEmail 更新产解行解信息
func (pc *ProcessCtx) UpdateProductSolutionEmail(productSolutionEmail *string, force bool) {
	if productSolutionEmail == nil {
		return
	}
	if pc.ContractInfo != nil && pc.ContractInfo.ProjectInfo != nil {
		if force || !pc.ContractInfo.ProjectInfo.HasProductSolutionEmail() {
			pc.ContractInfo.ProjectInfo.ProductSolutionEmail = productSolutionEmail
		}
	}
	if pc.PreContractVO != nil {
		var project bizmodels.ProjectInfo
		_ = json.Unmarshal([]byte(pc.PreContractVO.ProjectInfo), &project)
		if force || !project.HasProductSolutionEmail() {
			project.ProductSolutionEmail = productSolutionEmail
			body, _ := json.Marshal(project)
			pc.PreContractVO.ProjectInfo = string(body)
		}
	}
}

// UpdateRelatedResDepartment 更新涉及资源方
func (pc *ProcessCtx) UpdateRelatedResDepartment(relatedResDepartment *string, force bool) {
	if relatedResDepartment == nil {
		return
	}
	if pc.ContractInfo != nil && pc.ContractInfo.ProjectInfo != nil {
		if force || !pc.ContractInfo.ProjectInfo.HasRelatedResDepartment() {
			pc.ContractInfo.ProjectInfo.RelatedResDepartment = relatedResDepartment
		}
	}
	if pc.PreContractVO != nil {
		var project bizmodels.ProjectInfo
		_ = json.Unmarshal([]byte(pc.PreContractVO.ProjectInfo), &project)
		if force || !project.HasRelatedResDepartment() {
			project.RelatedResDepartment = relatedResDepartment
			body, _ := json.Marshal(project)
			pc.PreContractVO.ProjectInfo = string(body)
		}
	}
}

// UpdateDeliveryStaff 更新涉及资源方
func (pc *ProcessCtx) UpdateDeliveryStaff(deliveryStaff *string, force bool) {
	if deliveryStaff == nil {
		return
	}
	if pc.ContractInfo != nil && pc.ContractInfo.ProjectInfo != nil {
		if force || !pc.ContractInfo.ProjectInfo.HasDeliveryStaff() {
			pc.ContractInfo.ProjectInfo.DeliveryStaff = deliveryStaff
		}
	}
	if pc.PreContractVO != nil {
		var project bizmodels.ProjectInfo
		_ = json.Unmarshal([]byte(pc.PreContractVO.ProjectInfo), &project)
		if force || !project.HasDeliveryStaff() {
			project.DeliveryStaff = deliveryStaff
			body, _ := json.Marshal(project)
			pc.PreContractVO.ProjectInfo = string(body)
		}
	}
}

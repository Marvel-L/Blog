package auditmodel

import (
	"reflect"
	"strings"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"
)

func TestProcessCtxIsQuoteUnbinding(t *testing.T) {
	testCases := []struct {
		name string
		pc   *ProcessCtx
		want bool
	}{
		{
			name: "approved to unapproved",
			pc: &ProcessCtx{
				RelateQuoteChange:            true,
				RelateQuoteChangeBeforeValue: "old-quote",
				ContractInfo: &model.ContractMeta{
					RelateQuoteScene: _const.RelateQuoteSceneNoCompleted,
				},
			},
			want: true,
		},
		{
			name: "new quote replacement",
			pc: &ProcessCtx{
				RelateQuoteChange:            true,
				RelateQuoteChangeBeforeValue: "old-quote",
				ContractInfo:                 &model.ContractMeta{RelateQuoteNo: "new-quote"},
			},
		},
		{
			name: "nil context",
		},
	}

	for _, testCase := range testCases {
		t.Run(testCase.name, func(t *testing.T) {
			if got := testCase.pc.IsQuoteUnbinding(); got != testCase.want {
				t.Fatalf("IsQuoteUnbinding() = %v, want %v", got, testCase.want)
			}
		})
	}
}

func Test_UpdateProductSolutionEmail(t *testing.T) {
	t.Run("case UpdateProductSolutionEmail#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			pc := &ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				PreContractVO: &model.ContractMetaDB{
					ManageInfo: "{}",
				},
			}
			value := "demo"
			pc.UpdateProductSolutionEmail(&value, false)

			// t.Log(pc.PreContractVO.ProjectInfo)
			// Assert
			convey.So(*pc.ContractInfo.ProjectInfo.ProductSolutionEmail, convey.ShouldEqual, "demo")
			convey.So(strings.Contains(pc.PreContractVO.ProjectInfo, "demo"), convey.ShouldBeTrue)
		})
	})
}

func Test_ProcessCtx_SetTX_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_ProcessCtx_SetTX", t, func() {
		mockey.PatchConvey("should set the tx field correctly when it is initially nil", func() {
			// 场景描述：
			// 这是一个简单的setter方法，用于设置ProcessCtx结构体内部未导出的tx字段。
			// 本场景测试当tx字段初始为nil时，能否被成功设置。
			// 构造数据：
			// - 创建一个ProcessCtx实例，其tx字段为默认的nil。
			// - 创建一个gorm.DB实例。
			// 逻辑链路：
			// 1. 调用SetTX方法，传入gorm.DB实例。
			// 2. 使用反射来访问未导出的tx字段。
			// 3. 断言该字段的值已成功设置为传入的gorm.DB实例。

			// Arrange
			pc := &ProcessCtx{}
			tx := &gorm.DB{}

			// Act
			pc.SetTX(tx)

			// Assert
			// 由于 'tx' 字段是未导出的，我们使用反射来验证它是否被正确设置。
			val := reflect.ValueOf(pc).Elem()
			field := val.FieldByName("tx")
			convey.So(field.IsValid(), convey.ShouldBeTrue)
			// 使用 Pointer() 来比较未导出字段的地址，而不是 Interface()
			convey.So(field.Pointer(), convey.ShouldEqual, reflect.ValueOf(tx).Pointer())
		})

		mockey.PatchConvey("should overwrite an existing tx field with a new one", func() {
			// 场景描述：
			// 测试当ProcessCtx中已存在一个tx实例时，SetTX方法是否能成功覆盖它。
			// 构造数据：
			// - 创建一个ProcessCtx实例并预设一个旧的gorm.DB实例。
			// - 创建一个新的gorm.DB实例。
			// 逻辑链路：
			// 1. 调用SetTX方法，传入新的gorm.DB实例。
			// 2. 使用反射来访问未导出的tx字段。
			// 3. 断言该字段的值已成功更新为新的gorm.DB实例。

			// Arrange
			oldTx := &gorm.DB{}
			pc := &ProcessCtx{
				tx: oldTx,
			}
			newTx := &gorm.DB{}

			// Act
			pc.SetTX(newTx)

			// Assert
			val := reflect.ValueOf(pc).Elem()
			field := val.FieldByName("tx")
			convey.So(field.IsValid(), convey.ShouldBeTrue)
			// 使用 Pointer() 来比较未导出字段的地址，而不是 Interface()
			convey.So(field.Pointer(), convey.ShouldNotEqual, reflect.ValueOf(oldTx).Pointer())
			convey.So(field.Pointer(), convey.ShouldEqual, reflect.ValueOf(newTx).Pointer())
		})

		mockey.PatchConvey("should set tx field to nil", func() {
			// 场景描述：
			// 测试当传入一个nil的gorm.DB指针时，SetTX方法是否能正确将字段设置为nil。
			// 构造数据：
			// - 创建一个ProcessCtx实例并预设一个非nil的gorm.DB实例。
			// 逻辑链路：
			// 1. 调用SetTX方法，传入nil。
			// 2. 使用反射来访问未导出的tx字段。
			// 3. 断言该字段的值已成功更新为nil。

			// Arrange
			existingTx := &gorm.DB{}
			pc := &ProcessCtx{
				tx: existingTx,
			}

			// Act
			pc.SetTX(nil)

			// Assert
			val := reflect.ValueOf(pc).Elem()
			field := val.FieldByName("tx")
			convey.So(field.IsValid(), convey.ShouldBeTrue)
			convey.So(field.IsNil(), convey.ShouldBeTrue)
		})
	})
}

func Test_UpdateDeliveryStaff(t *testing.T) {
	t.Run("case UpdateDeliveryStaff#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			pc := &ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				PreContractVO: &model.ContractMetaDB{
					ManageInfo: "{}",
				},
			}
			value := "demo"
			pc.UpdateDeliveryStaff(&value, false)

			// t.Log(pc.PreContractVO.ProjectInfo)
			// Assert
			convey.So(*pc.ContractInfo.ProjectInfo.DeliveryStaff, convey.ShouldEqual, "demo")
			convey.So(strings.Contains(pc.PreContractVO.ProjectInfo, "demo"), convey.ShouldBeTrue)
		})
	})
}

func TestProcessCtx_GetCurrentReviewer(t *testing.T) {
	mockey.PatchConvey("TestProcessCtx_GetCurrentReviewer", t, func() {
		pc := &ProcessCtx{
			ContractInfo: &model.ContractMeta{
				CooperationStatus: 1,
				Reviewers: []*bizmodels.PreContractReviewer{
					{
						ContractStatus: 1,
						ReviewerType:   1,
						Reviewer:       "test",
					},
				},
			},
			CurrentOperator: "test",
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ReviewerType: 1,
			},
		}

		convey.So(pc.GetCurrentReviewer(), convey.ShouldResemble, &bizmodels.PreContractReviewer{
			ContractStatus: 1,
			ReviewerType:   1,
			Reviewer:       "test",
		})
	})
}

func Test_ProcessCtx_GetTx_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ProcessCtx GetTx", t, func() {
		mockey.PatchConvey("should return the tx field", func() {
			// 场景描述：
			// 构造一个ProcessCtx实例，并为其私有字段tx设置一个gorm.DB的指针。
			// 逻辑链路：
			// 1. 调用GetTx方法。
			// 2. 断言返回的gorm.DB指针与我们设置的指针相同。

			// 准备数据
			// 创建一个*gorm.DB的模拟实例
			expectedTx := &gorm.DB{}
			// 创建ProcessCtx实例并设置tx字段
			pc := &ProcessCtx{
				tx: expectedTx,
			}

			// 调用目标函数
			actualTx := pc.GetTx()

			// 断言
			convey.So(actualTx, convey.ShouldEqual, expectedTx)
		})

		mockey.PatchConvey("should return nil when tx field is nil", func() {
			// 场景描述：
			// 构造一个ProcessCtx实例，其私有字段tx为nil。
			// 逻辑链路：
			// 1. 调用GetTx方法。
			// 2. 断言返回值为nil。

			// 准备数据
			// 创建一个tx为nil的ProcessCtx实例
			pc := &ProcessCtx{
				tx: nil,
			}

			// 调用目标函数
			actualTx := pc.GetTx()

			// 断言
			convey.So(actualTx, convey.ShouldBeNil)
		})
	})
}

func Test_ProcessCtx_CalcApprovalKey_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ProcessCtx CalcApprovalKey", t, func() {
		mockey.PatchConvey("should call PreContractVO.CalcApprovalKey and set the result to ApprovalKey", func() {
			// 场景描述：
			// 测试 ProcessCtx.CalcApprovalKey 方法。该方法会调用其成员 PreContractVO 的 CalcApprovalKey 方法，
			// 并将返回的审批流 key 设置到 ProcessCtx 的 ApprovalKey 字段上。
			// 构造数据：
			// - 创建一个 ProcessCtx 实例 pc。
			// - 初始化 pc.PreContractVO 为一个 model.ContractMetaDB 的实例。
			// 逻辑链路：
			// 1. Mock (*model.ContractMetaDB).CalcApprovalKey 方法，使其返回一个预设的字符串 "mocked_approval_key"。
			// 2. 调用 pc.CalcApprovalKey()。
			// 3. 断言 pc.ApprovalKey 的值是否等于 "mocked_approval_key"。

			// Arrange
			pc := &ProcessCtx{
				PreContractVO: &model.ContractMetaDB{},
			}
			expectedKey := "mocked_approval_key"

			mockey.Mock((*model.ContractMetaDB).CalcApprovalKey).Return(expectedKey).Build()

			// Act
			pc.CalcApprovalKey()

			// Assert
			convey.So(pc.ApprovalKey, convey.ShouldEqual, expectedKey)
		})
	})
}

func Test_UpdateBelongingDepartment(t *testing.T) {
	t.Run("case UpdateBelongingDepartment#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			pc := &ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ManageInfo: &bizmodels.ManageInfo{},
				},
				PreContractVO: &model.ContractMetaDB{
					ManageInfo: "{}",
				},
			}
			pc.UpdateBelongingDepartment("demo", false)

			// t.Log(pc.PreContractVO.ManageInfo)
			// Assert
			convey.So(pc.ContractInfo.ManageInfo.BelongingDepartment, convey.ShouldEqual, "demo")
			convey.So(strings.Contains(pc.PreContractVO.ManageInfo, "demo"), convey.ShouldBeTrue)
		})
	})
}

func Test_UpdateRelatedResDepartment(t *testing.T) {
	t.Run("case UpdateRelatedResDepartment#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			pc := &ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ProjectInfo: &bizmodels.ProjectInfo{},
				},
				PreContractVO: &model.ContractMetaDB{
					ManageInfo: "{}",
				},
			}
			value := "demo"
			pc.UpdateRelatedResDepartment(&value, false)

			// t.Log(pc.PreContractVO.ProjectInfo)
			// Assert
			convey.So(*pc.ContractInfo.ProjectInfo.RelatedResDepartment, convey.ShouldEqual, "demo")
			convey.So(strings.Contains(pc.PreContractVO.ProjectInfo, "demo"), convey.ShouldBeTrue)
		})
	})
}

package auditx

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"sort"
	"strings"
	"sync"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/auditx/handler"
	_const "volc_contract_process/pkg/const"
)

/**处理审批流程*/
/**
* 逻辑说明
* 整个审批流程包含几个固定状态：草稿、已退回、销售运营专业审核、财税法交付专业审核、销售确认中、有修改、销售完善信息、提交OA、已作废
* 在某个确定的状态下，不同用户可以执行不同的操作，执行操作后需要涉及对应的数据变更
 */

var once sync.Once
var _instance *engine

// Init 包初始化
func Init() error {

	once.Do(func() {

		statusHandleMappings := map[int]map[int]handler.StatusOpHandler{}
		handlers := handler.AllHandlers()

		for _, h := range handlers {
			if err := register(statusHandleMappings, h); err != nil {
				logs.Errorf("auditx.InitFail, err:%v", err)
				return
			}
		}
		_instance = &engine{
			statusHandleMappings:     statusHandleMappings,
			statusReviewTypeMappings: getStatusReviewTypeMappings(),
		}
	})

	if _instance == nil {
		return errors.New("审批引擎初始化失败")
	}

	logs.Info("审批流程状态转换图\n%s", GetGraph().String())
	return nil
}

func register(mappings map[int]map[int]handler.StatusOpHandler, h handler.StatusOpHandler) error {

	var statusList []int
	multiH, ok := h.(handler.MultiStatusOpHandler)
	if ok {
		statusList = multiH.SupportStatus()
	} else {
		statusList = []int{h.CurrentStatus()}
	}

	for _, status := range statusList {
		statusMapping := mappings[status]
		if statusMapping == nil {
			statusMapping = map[int]handler.StatusOpHandler{}
		}
		if _, exist := statusMapping[h.CurrentOp()]; exist {
			logs.CtxError(context.Background(), "重复的处理器, status: %d, op: %d", status, h.CurrentOp())
			return fmt.Errorf("duplicate handler, status:%d, op:%d", status, h.CurrentOp())
		}
		statusMapping[h.CurrentOp()] = h
		mappings[status] = statusMapping
	}

	return nil
}

func getStatusReviewTypeMappings() map[int]int {
	return map[int]int{
		_const.PreSalesContractDraft:                             _const.ReviewerTypeSalesperson,
		_const.PreSalesContractSendBack:                          _const.ReviewerTypeSalesperson,
		_const.PreSalesContractSolutionReview:                    _const.ReviewerTypeSolutionReviewer,
		_const.PreSalesContractSalesOperationReview:              _const.ReviewerTypeSalesOperation,
		_const.PreSalesContractFinanceTaxationLegalReview:        _const.ReviewerTypeFinanceTaxationLegalReviewer,
		_const.PreSalesContractCustomerConfirm:                   _const.ReviewerTypeSalesperson,
		_const.PreSalesContractChange:                            _const.ReviewerTypeSalesperson,
		_const.PreSalesContractSalesOperationCompleteInformation: _const.ReviewerTypeSalesOperation,
		_const.PreSalesContractFinanceTaxationLegalSignReview:    _const.ReviewerTypeFinanceTaxationLegalReviewer,
		_const.PreSalesContractRiskReview:                        _const.ReviewerTypeSalesOperation,
	}
}

// region Graph

type Node struct {
	Name  string
	Value int
}

type Edge struct {
	EdgeKey  string
	EdgeName string
	OpName   string
	OpValue  int
	From     *Node
	To       *Node
}

type Graph struct {
	Nodes []*Node
	Edges []*Edge
}

func (g *Graph) String() string {
	var list []string
	for _, e := range g.Edges {
		list = append(list, fmt.Sprintf("%-40s: %-10s --- %-10s --> %-10s", e.EdgeName, e.From.Name, e.OpName, e.To.Name))
	}
	return strings.Join(list, "\n")
}

func GetGraph() *Graph {
	nodeMap := map[string]*Node{}
	edgeMap := map[string]*Edge{}
	for fromStatus, m := range _instance.statusHandleMappings {
		nodeMap[_const.GenStatusDesc(fromStatus)] = &Node{
			Name:  _const.GenStatusDesc(fromStatus),
			Value: fromStatus,
		}
		for op, opHandler := range m {
			_ = opHandler
			statusInfo := handler.GetValidReviewerType(fromStatus, op, _const.ApprovalKeyDefault)
			if statusInfo == nil {
				continue
			}
			if !statusInfo.IgnoreUpdatePreContractStatus {
				for _, value := range statusInfo.ContractNewStatusMapOnSuccess {
					nodeMap[_const.GenStatusDesc(value)] = &Node{
						Name:  _const.GenStatusDesc(value),
						Value: value,
					}
				}
			}
		}
	}
	for fromStatus, m := range _instance.statusHandleMappings {
		for op, opHandler := range m {
			statusInfo := handler.GetValidReviewerType(fromStatus, op, _const.ApprovalKeyDefault)
			if statusInfo == nil {
				continue
			}
			for _, value := range statusInfo.ContractNewStatusMapOnSuccess {
				if statusInfo.IgnoreUpdatePreContractStatus {
					value = fromStatus
				}
				edgeMap[reflect.TypeOf(opHandler).Elem().Name()+" "+_const.GenStatusDesc(fromStatus)] = &Edge{
					// EdgeKey:  key,
					EdgeName: reflect.TypeOf(opHandler).Elem().Name(),
					OpName:   _const.GenOperateDesc(op),
					OpValue:  op,
					From:     nodeMap[_const.GenStatusDesc(fromStatus)],
					To:       nodeMap[_const.GenStatusDesc(value)],
				}
			}
		}
	}
	graph := &Graph{
		Nodes: nil,
		Edges: nil,
	}
	for _, node := range nodeMap {
		graph.Nodes = append(graph.Nodes, node)
	}
	for _, edge := range edgeMap {
		graph.Edges = append(graph.Edges, edge)
	}
	sort.Slice(graph.Edges, func(i, j int) bool {
		if graph.Edges[i].From.Value != graph.Edges[j].From.Value {
			return graph.Edges[i].From.Value < graph.Edges[j].From.Value
		}
		if graph.Edges[i].To.Value != graph.Edges[j].To.Value {
			return graph.Edges[i].To.Value < graph.Edges[j].To.Value
		}
		return graph.Edges[i].OpValue < graph.Edges[i].OpValue
	})
	return graph
}

// endregion Graph

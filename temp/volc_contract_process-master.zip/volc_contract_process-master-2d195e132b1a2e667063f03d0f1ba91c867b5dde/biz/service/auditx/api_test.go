package auditx

import (
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/modelcooperation"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/auditx/auditmodel"
	"volc_contract_process/biz/service/auditx/handler"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/perm"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/filecli"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/salesforcecli"
	"volc_contract_process/pkg/recovery"
)

// MockStatusOpHandler is a mock for the handler.StatusOpHandler interface.
type MockStatusOpHandler struct {
	handler.StatusOpHandler
}

func Test_engine_fillReviewers_BitsUTGen(t *testing.T) {
	// MockPreContractReviewerDao is a mock struct for the dal.PreContractReviewerDao interface.
	type MockPreContractReviewerDao struct {
		dal.PreContractReviewerDao
	}

	mockey.PatchConvey("Test_engine_fillReviewers", t, func() {
		// Setup common variables for all test cases
		e := &engine{}
		ctx := context.Background()
		tx := &gorm.DB{}

		mockey.PatchConvey("场景1: meta中已经存在Reviewers, 应该直接返回", func() {
			// 场景描述：
			// 构造数据：meta.Reviewers 字段长度大于0
			// 逻辑链路：
			// 1. 函数执行到 `if len(meta.Reviewers) > 0` 条件，判断为 true。
			// 2. 函数直接返回 nil，不执行后续数据库查询逻辑。

			// 准备数据
			meta := &model.ContractMeta{
				Reviewers: bizmodels.PreContractReviewerList{
					{Reviewer: "existing_reviewer"},
				},
			}

			// 调用目标函数
			err := e.fillReviewers(ctx, tx, meta)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(meta.Reviewers), convey.ShouldEqual, 1)
			convey.So(meta.Reviewers[0].Reviewer, convey.ShouldEqual, "existing_reviewer")
		})

		mockey.PatchConvey("场景2: meta中不存在Reviewers, 成功从数据库中查询并填充", func() {
			// 场景描述：
			// 构造数据：meta.Reviewers 字段为空，数据库返回有效的审核人列表。
			// 逻辑链路：
			// 1. 函数执行到 `if len(meta.Reviewers) > 0` 条件，判断为 false。
			// 2. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个包含数据的 reviewerDBList 和 nil error。
			// 3. 函数执行到 `if len(reviewerDBList) > 0` 条件，判断为 true。
			// 4. Mock reviewerDBList.GenResp() 返回转换后的业务模型列表 allReviewerList。
			// 5. Mock e.buildReviewersLogInfo 返回日志字符串。
			// 6. allReviewerList 被赋值给 meta.Reviewers。
			// 7. 函数返回 nil。

			// 准备数据
			meta := &model.ContractMeta{
				ContractNo: "CN-TEST-001",
				Reviewers:  bizmodels.PreContractReviewerList{},
			}
			mockDao := &MockPreContractReviewerDao{}
			reviewerDBList := model.PreContractReviewerDBList{
				{
					Reviewer: "test_reviewer_from_db",
					BaseDB:   model.BaseDB{Status: 1},
				},
			}
			allReviewerList := bizmodels.PreContractReviewerList{
				{
					Reviewer: "test_reviewer_from_resp",
					Status:   1,
				},
			}

			// Mock依赖
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(reviewerDBList, nil).Build()
			mockey.Mock((*model.PreContractReviewerDBList).GenResp).Return(allReviewerList).Build()
			mockey.Mock((*engine).buildReviewersLogInfo).Return("reviewer log info").Build()

			// 调用目标函数
			err := e.fillReviewers(ctx, tx, meta)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(meta.Reviewers), convey.ShouldEqual, 1)
			convey.So(meta.Reviewers[0].Reviewer, convey.ShouldEqual, "test_reviewer_from_resp")
		})

		mockey.PatchConvey("场景3: meta中不存在Reviewers, 数据库查询结果为空", func() {
			// 场景描述：
			// 构造数据：meta.Reviewers 字段为空，数据库返回空的审核人列表。
			// 逻辑链路：
			// 1. 函数执行到 `if len(meta.Reviewers) > 0` 条件，判断为 false。
			// 2. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回一个空的 reviewerDBList 和 nil error。
			// 3. 函数执行到 `if len(reviewerDBList) > 0` 条件，判断为 false。
			// 4. 函数不执行 if 块内的逻辑，直接返回 nil。
			// 5. meta.Reviewers 保持为空。

			// 准备数据
			meta := &model.ContractMeta{
				ContractNo: "CN-TEST-002",
				Reviewers:  bizmodels.PreContractReviewerList{},
			}
			mockDao := &MockPreContractReviewerDao{}

			// Mock依赖
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(model.PreContractReviewerDBList{}, nil).Build()

			// 调用目标函数
			err := e.fillReviewers(ctx, tx, meta)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(meta.Reviewers), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景4: meta中不存在Reviewers, 数据库查询失败", func() {
			// 场景描述：
			// 构造数据：meta.Reviewers 字段为空。
			// 逻辑链路：
			// 1. 函数执行到 `if len(meta.Reviewers) > 0` 条件，判断为 false。
			// 2. Mock dal.NewPreContractReviewerDao().FindReviewersByNo 返回 nil 和一个 error。
			// 3. 函数执行到 `if err != nil` 条件，判断为 true。
			// 4. 函数直接返回该 error。
			// 5. meta.Reviewers 保持为空。

			// 准备数据
			meta := &model.ContractMeta{
				ContractNo: "CN-TEST-003",
				Reviewers:  bizmodels.PreContractReviewerList{},
			}
			mockDao := &MockPreContractReviewerDao{}
			dbError := errors.New("database connection failed")

			// Mock依赖
			mockey.Mock(dal.NewPreContractReviewerDao).Return(mockDao).Build()
			mockey.Mock((*MockPreContractReviewerDao).FindReviewersByNo).Return(nil, dbError).Build()

			// 调用目标函数
			err := e.fillReviewers(ctx, tx, meta)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database connection failed")
			convey.So(len(meta.Reviewers), convey.ShouldEqual, 0)
		})
	})
}

func Test_engine_Handle_BitsUTGen(t *testing.T) {
	e := &engine{}
	mockHandler := &MockStatusOpHandler{}

	mockey.PatchConvey("Test engine.Handle", t, func() {

		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				ContractNo:        "test-contract-no",
				CooperationStatus: _const.PreSalesContractDraft,
				Reviewers: bizmodels.PreContractReviewerList{
					{
						Reviewer:       "test-operator@example.com",
						ReviewerType:   _const.ReviewerTypeSalesperson,
						ContractStatus: _const.PreSalesContractDraft,
					},
				},
			},
			CurrentOperator: "test-operator@example.com",
			OperationState:  _const.OperationSubmitPreContract,
		}

		mockey.PatchConvey("scenario: preparation phase failures", func() {
			mockey.PatchConvey("should return error when matchReviewerStatusOpConf fails", func() {

				expectedErr := errors.New("match error")
				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*engine).matchReviewerStatusOpConf).Return(nil, nil, expectedErr).Build()

				err := e.Handle(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when fillReviewers fails", func() {

				statusOpConf := &modelcooperation.ReviewerStatusOpConf{}
				expectedErr := errors.New("fill reviewers error")

				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
				mockey.Mock((*engine).fillReviewers).Return(expectedErr).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

				err := e.Handle(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return permission error when checkPerm returns false", func() {

				statusOpConf := &modelcooperation.ReviewerStatusOpConf{IgnoreRolePermCheck: false}
				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
				mockey.Mock((*engine).fillReviewers).Return(nil).Build()
				mockey.Mock((*engine).checkPerm).Return(false, nil).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

				mockey.Mock(i18nfmt.New).Return(errors.New("用户无权限")).Build()

				err := e.Handle(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "用户无权限")
			})

			mockey.PatchConvey("should return permission error when checkPerm returns an error", func() {

				statusOpConf := &modelcooperation.ReviewerStatusOpConf{IgnoreRolePermCheck: false}
				checkPermErr := errors.New("check perm db error")
				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
				mockey.Mock((*engine).fillReviewers).Return(nil).Build()
				mockey.Mock((*engine).checkPerm).Return(false, checkPermErr).Build()
				mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()

				mockey.Mock(i18nfmt.New).Return(errors.New("用户无权限")).Build()

				err := e.Handle(ctx, pc)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "用户无权限")
			})
		})

		mockey.PatchConvey("scenario: handler execution failures", func() {

			statusOpConf := &modelcooperation.ReviewerStatusOpConf{IgnoreRolePermCheck: true}
			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock(perm.CheckOpPerm).Return(true, nil).Build()

			mockey.PatchConvey("should return error when h.Validate fails", func() {

				expectedErr := errors.New("validate error")
				mockey.Mock((*MockStatusOpHandler).Validate).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when h.Process fails", func() {

				expectedErr := errors.New("process error")
				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).Process).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when h.SaveProcessFileNestVersion fails", func() {

				expectedErr := errors.New("save version error")
				mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
				mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

		})

		mockey.PatchConvey("scenario: status update failures", func() {
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				IgnoreRolePermCheck:           true,
				IgnoreUpdateReviewerStatus:    false,
				IgnoreUpdatePreContractStatus: false,
			}

			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock(perm.CheckOpPerm).Return(true, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(nil).Build()

			mockey.PatchConvey("should return error when UpdateReviewerStatus fails", func() {

				expectedErr := errors.New("update reviewer status error")
				mockey.Mock(dal.UpdateReviewerStatus).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when h.HitStateChangeCondition fails", func() {

				expectedErr := errors.New("hit condition error")
				mockey.Mock(dal.UpdateReviewerStatus).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).HitStateChangeCondition).Return(false, expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when changeContractStatus fails", func() {

				expectedErr := errors.New("change contract status error")
				mockey.Mock(dal.UpdateReviewerStatus).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).HitStateChangeCondition).Return(true, nil).Build()
				mockey.Mock((*engine).changeContractStatus).Return(expectedErr).Build()
				mockey.Mock((*MockStatusOpHandler).SaveStatusChangeFileVersion).Return(nil).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when h.SaveStatusChangeFileVersion fails", func() {

				expectedErr := errors.New("save status change file version error")
				mockey.Mock(dal.UpdateReviewerStatus).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).HitStateChangeCondition).Return(true, nil).Build()
				mockey.Mock((*engine).changeContractStatus).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).SaveStatusChangeFileVersion).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})
		})

		mockey.PatchConvey("scenario: post-processing failures", func() {

			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				IgnoreRolePermCheck:           true,
				IgnoreUpdateReviewerStatus:    true,
				IgnoreUpdatePreContractStatus: true,
			}
			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(nil).Build()

			mockey.PatchConvey("should return error when createOperateRecord fails", func() {

				expectedErr := errors.New("create record error")
				mockey.Mock((*engine).createOperateRecord).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})

			mockey.PatchConvey("should return error when h.PostProcess fails", func() {

				expectedErr := errors.New("post process error")
				mockey.Mock((*engine).createOperateRecord).Return(nil).Build()
				mockey.Mock((*MockStatusOpHandler).PostProcess).Return(expectedErr).Build()

				err := e.Handle(ctx, pc)
				convey.So(err, convey.ShouldEqual, expectedErr)
			})
		})

		mockey.PatchConvey("scenario: happy path - all steps succeed", func() {

			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				IgnoreRolePermCheck:           false,
				IgnoreUpdateReviewerStatus:    false,
				IgnoreUpdatePreContractStatus: false,
				ContractNewStatusOnSuccess:    _const.PreSalesContractSalesOperationReview,
			}

			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock((*engine).checkPerm).Return(true, nil).Build()
			mockey.Mock(dal.UpdateReviewerStatus).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*engine).changeContractStatus).Return(nil).Build()
			mockey.Mock((*engine).createOperateRecord).Return(nil).Build()

			mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).HitStateChangeCondition).Return(true, nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveStatusChangeFileVersion).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).PostProcess).Return(nil).Build()

			err := e.Handle(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.ReviewerStatusOpConf, convey.ShouldEqual, statusOpConf)
		})

		mockey.PatchConvey("scenario: successful execution but no status change triggered", func() {
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				IgnoreRolePermCheck:           false,
				IgnoreUpdateReviewerStatus:    false,
				IgnoreUpdatePreContractStatus: false, // Key: do not ignore contract status update
			}

			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock((*engine).checkPerm).Return(true, nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(nil).Build()
			mockey.Mock(dal.UpdateReviewerStatus).Return(nil).Build()

			// Key mock for this scenario: condition for status change is not met
			mockey.Mock((*MockStatusOpHandler).HitStateChangeCondition).Return(false, nil).Build()

			mockey.Mock((*engine).createOperateRecord).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).PostProcess).Return(nil).Build()

			// Reset StatusChanged before calling Handle
			pc.StatusChanged = false
			err := e.Handle(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.StatusChanged, convey.ShouldBeFalse) // Assert that status did not change
		})

		mockey.PatchConvey("scenario: happy path - skip status changes", func() {

			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				IgnoreRolePermCheck:           true,
				IgnoreUpdateReviewerStatus:    true,
				IgnoreUpdatePreContractStatus: true,
			}
			pc.Comment = &bizmodels.RichTextInfo{}
			pc.StatusChanged = false // Reset before test

			mockey.Mock((*MockStatusOpHandler).GetStatusOpConfKey).Return("").Build()
			mockey.Mock((*engine).matchReviewerStatusOpConf).Return(mockHandler, statusOpConf, nil).Build()
			mockey.Mock((*engine).fillReviewers).Return(nil).Build()
			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(&gorm.DB{}).Build()
			mockey.Mock((*engine).createOperateRecord).Return(nil).Build()

			mockey.Mock((*MockStatusOpHandler).Validate).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).Process).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).SaveProcessFileNestVersion).Return(nil).Build()
			mockey.Mock((*MockStatusOpHandler).PostProcess).Return(nil).Build()

			err := e.Handle(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.StatusChanged, convey.ShouldBeFalse)
		})
	})
}

func Test_engine_checkPerm_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_engine_checkPerm", t, func() {
		// 准备engine实例
		e := &engine{}

		mockey.PatchConvey("场景一：允许系统调用且操作者为系统，应直接返回true", func() {
			// 场景描述：
			// 构造数据：
			// - statusOpConf.AllowSystemCalls = true
			// - pc.CurrentOperator = _const.OperationSystem
			// 逻辑链路：
			// 1. 函数进入第一个if条件，因为AllowSystemCalls为true且CurrentOperator为"system"。
			// 2. 记录日志信息。
			// 3. 直接返回 (true, nil)，不调用 perm.CheckOpPerm。

			// 构造输入数据
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: _const.OperationSystem,
			}
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				AllowSystemCalls: true,
			}

			// 调用目标函数
			hasPerm, err := e.checkPerm(ctx, pc, statusOpConf)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景二：非系统调用，调用perm.CheckOpPerm并返回有权限", func() {
			// 场景描述：
			// 构造数据：
			// - statusOpConf.AllowSystemCalls = false
			// - pc.CurrentOperator = "test.user"
			// 逻辑链路：
			// 1. 函数不进入第一个if条件。
			// 2. 调用 perm.CheckOpPerm。
			// 3. Mock perm.CheckOpPerm 返回 (true, nil)。
			// 4. 函数返回 perm.CheckOpPerm 的结果 (true, nil)。

			// 构造输入数据
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.user",
			}
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				AllowSystemCalls: false,
				ReviewerType:     1,
			}

			// Mock依赖
			mockey.Mock(perm.CheckOpPerm).Return(true, nil).Build()

			// 调用目标函数
			hasPerm, err := e.checkPerm(ctx, pc, statusOpConf)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景三：非系统调用，调用perm.CheckOpPerm并返回无权限", func() {
			// 场景描述：
			// 构造数据：
			// - pc.CurrentOperator = "test.user"
			// 逻辑链路：
			// 1. 函数不进入第一个if条件。
			// 2. 调用 perm.CheckOpPerm。
			// 3. Mock perm.CheckOpPerm 返回 (false, nil)。
			// 4. 函数返回 perm.CheckOpPerm 的结果 (false, nil)。

			// 构造输入数据
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.user",
			}
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				AllowSystemCalls: true, // 即使AllowSystemCalls为true, 但操作者不是system，仍然会走权限校验
				ReviewerType:     1,
			}

			// Mock依赖
			mockey.Mock(perm.CheckOpPerm).Return(false, nil).Build()

			// 调用目标函数
			hasPerm, err := e.checkPerm(ctx, pc, statusOpConf)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景四：非系统调用，调用perm.CheckOpPerm返回错误", func() {
			// 场景描述：
			// 构造数据：
			// - pc.CurrentOperator = "test.user"
			// 逻辑链路：
			// 1. 函数不进入第一个if条件。
			// 2. 调用 perm.CheckOpPerm。
			// 3. Mock perm.CheckOpPerm 返回 (false, error)。
			// 4. 函数返回 perm.CheckOpPerm 的结果 (false, error)。

			// 构造输入数据
			ctx := context.Background()
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "test.user",
			}
			statusOpConf := &modelcooperation.ReviewerStatusOpConf{
				AllowSystemCalls: false,
				ReviewerType:     1,
			}
			mockErr := errors.New("perm check error")

			// Mock依赖
			mockey.Mock(perm.CheckOpPerm).Return(false, mockErr).Build()

			// 调用目标函数
			hasPerm, err := e.checkPerm(ctx, pc, statusOpConf)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "perm check error")
			convey.So(hasPerm, convey.ShouldBeFalse)
		})
	})
}

func TestHandle_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestHandle", t, func() {
		// 准备通用测试数据
		ctx := context.Background()
		pc := &auditmodel.ProcessCtx{}
		// 保存并恢复全局变量 _instance，防止测试污染
		originalInstance := _instance
		defer func() {
			_instance = originalInstance
		}()

		mockey.PatchConvey("当审批引擎_instance未初始化(为nil)时, 应返回初始化错误", func() {
			// 场景描述：
			// 检查当审批引擎实例 `_instance` 未初始化（为nil）时的边界情况。
			// 构造数据：
			// 将全局变量 _instance 设置为 nil。
			// 逻辑链路：
			// 1. 调用 Handle 函数。
			// 2. 函数进入 `if _instance == nil` 的判断分支。
			// 3. 返回一个表示“审批引擎尚未初始化”的错误。
			// 4. 断言返回的错误不为 nil，并且错误信息包含预期的文本。

			_instance = nil

			err := Handle(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批引擎尚未初始化")
		})

		mockey.PatchConvey("当审批引擎_instance.Handle方法返回错误时, 应将错误透传", func() {
			// 场景描述：
			// 模拟内部引擎的 `Handle` 方法执行失败并返回错误的场景。
			// 构造数据：
			// 1. 初始化 `_instance` 为一个非空的 `engine` 实例。
			// 2. Mock `(*engine).Handle` 方法，使其返回一个自定义的错误。
			// 逻辑链路：
			// 1. 调用 Handle 函数。
			// 2. `if _instance == nil` 判断为 false，继续执行。
			// 3. 调用 `_instance.Handle` 方法，该方法返回了被 mock 的错误。
			// 4. Handle 函数捕获到错误并将其返回。
			// 5. 断言返回的错误与 mock 的错误是同一个。

			_instance = &engine{}
			mockErr := errors.New("engine handle error")
			mockey.Mock((*engine).Handle).Return(mockErr).Build()

			err := Handle(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})

		mockey.PatchConvey("当审批引擎_instance.Handle方法成功执行时, 应返回nil", func() {
			// 场景描述：
			// 模拟内部引擎的 `Handle` 方法成功执行的正常流程。
			// 构造数据：
			// 1. 初始化 `_instance` 为一个非空的 `engine` 实例。
			// 2. Mock `(*engine).Handle` 方法，使其返回 nil，表示成功。
			// 逻辑链路：
			// 1. 调用 Handle 函数。
			// 2. `if _instance == nil` 判断为 false，继续执行。
			// 3. 调用 `_instance.Handle` 方法，该方法返回 nil。
			// 4. Handle 函数最终返回 nil。
			// 5. 断言返回的错误为 nil。

			_instance = &engine{}
			mockey.Mock((*engine).Handle).Return(nil).Build()

			err := Handle(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_engine_fetchSkipReturnReviewNoAuditEmails_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_engine_fetchSkipReturnReviewNoAuditEmails", t, func() {
		// 初始化公共变量
		e := &engine{}
		ctx := context.Background()
		newStatus := 10
		reviewerType := 20

		mockey.PatchConvey("场景1: 合同协商状态不是“有修改”，应直接返回nil", func() {
			// 场景描述：当合同的协商状态(CooperationStatus)不是“有修改”(_const.PreSalesContractChange)时，函数应立即返回nil。
			// 构造数据：
			// - pc.PreContractVO.CooperationStatus 设置为 _const.PreSalesContractDraft (非 _const.PreSalesContractChange)。
			// 逻辑链路：
			// 1. 函数入口的第一个 if 条件 (pc.PreContractVO.CooperationStatus != _const.PreSalesContractChange) 为 true。
			// 2. 函数直接返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					CooperationStatus: _const.PreSalesContractDraft,
				},
			}

			result := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 合同状态正确，但没有符合条件的审核人，应返回nil", func() {
			// 场景描述：当合同状态正确，但审核人列表中没有任何审核人满足类型、合同状态和来源的筛选条件时，函数最终应返回nil。
			// 构造数据：
			// - pc.PreContractVO.CooperationStatus 设置为 _const.PreSalesContractChange。
			// - pc.ContractInfo.Reviewers 列表中的审核人均不满足 if 条件（例如，类型、状态或来源不匹配）。
			// 逻辑链路：
			// 1. 函数入口的第一个 if 条件为 false，继续执行。
			// 2. for 循环遍历 Reviewers，但内部的 if 条件始终为 false。
			// 3. 循环结束后，hasAuditEmail 标志位保持为 false。
			// 4. 最后的 if (!hasAuditEmail) 条件为 true，函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					CooperationStatus: _const.PreSalesContractChange,
				},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						// 类型不匹配
						{Reviewer: "user1@test.com", ReviewerType: reviewerType + 1, ContractStatus: newStatus, ReviewerSource: 0},
						// 状态不匹配
						{Reviewer: "user2@test.com", ReviewerType: reviewerType, ContractStatus: newStatus + 1, ReviewerSource: 0},
						// 来源不匹配
						{Reviewer: "user3@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 1},
					},
				},
			}

			result := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: 所有符合条件的审核人都选择“跳过审核”，应返回nil（触发全员重审）", func() {
			// 场景描述：当所有符合条件的审核人都选择了“审核通过无异议”（即跳过返稿重审），业务逻辑规定需要全员重审，因此函数应返回nil。
			// 构造数据：
			// - pc.PreContractVO.CooperationStatus 设置为 _const.PreSalesContractChange。
			// - pc.ContractInfo.Reviewers 列表中所有符合条件的审核人的 SkipReturnReview 字段都为 _const.SkipReturnReviewTypeSkipAudit。
			// 逻辑链路：
			// 1. 函数入口的第一个 if 条件为 false。
			// 2. for 循环遍历 Reviewers，所有符合条件的审核人进入 if (reviewer.SkipReturnReview == _const.SkipReturnReviewTypeSkipAudit) 分支。
			// 3. skipReturnReviewNoAuditEmails 列表被填充，但 hasAuditEmail 标志位始终为 false。
			// 4. 最后的 if (!hasAuditEmail) 条件为 true，函数返回 nil。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					CooperationStatus: _const.PreSalesContractChange,
				},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "user.skip1@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit},
						{Reviewer: "user.skip2@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit},
					},
				},
			}

			result := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)

			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景4: 部分审核人跳过、部分需要重审，应返回跳过审核的人员列表", func() {
			// 场景描述：当符合条件的审核人中，有人选择“跳过审核”，也有人选择“需要重审”时，函数应返回那些选择“跳过审核”的人员的邮箱列表。
			// 构造数据：
			// - pc.PreContractVO.CooperationStatus 设置为 _const.PreSalesContractChange。
			// - pc.ContractInfo.Reviewers 列表中，符合条件的审核人中：
			//   - 至少一个 SkipReturnReview 为 _const.SkipReturnReviewTypeSkipAudit。
			//   - 至少一个 SkipReturnReview 为 _const.SkipReturnReviewTypeNeedAudit (或其他非1的值)。
			// 逻辑链路：
			// 1. 函数入口的第一个 if 条件为 false。
			// 2. for 循环遍历 Reviewers。
			// 3. 对于选择跳过的审核人，其邮箱被加入 skipReturnReviewNoAuditEmails。
			// 4. 对于选择重审的审核人，hasAuditEmail 标志位被设置为 true。
			// 5. 循环结束后，hasAuditEmail 为 true。
			// 6. 最后的 if (!hasAuditEmail) 条件为 false，函数返回填充了跳过人员邮箱的 skipReturnReviewNoAuditEmails 列表。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					CooperationStatus: _const.PreSalesContractChange,
				},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "user.skip@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit},
						{Reviewer: "user.reaudit@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeNeedAudit},
						{Reviewer: "user.skip2@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit},
						// 不符合条件的审核人，应被忽略
						{Reviewer: "user.ignore@test.com", ReviewerType: reviewerType + 1, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeSkipAudit},
					},
				},
			}

			result := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)

			expected := []string{"user.skip@test.com", "user.skip2@test.com"}
			convey.So(result, convey.ShouldResemble, expected)
		})

		mockey.PatchConvey("场景5: 所有符合条件的审核人都需要重审，应返回空列表", func() {
			// 场景描述：当所有符合条件的审核人都选择“需要重审”时，函数应返回一个空的列表，因为没有需要跳过审核的人员。
			// 构造数据：
			// - pc.PreContractVO.CooperationStatus 设置为 _const.PreSalesContractChange。
			// - pc.ContractInfo.Reviewers 列表中所有符合条件的审核人的 SkipReturnReview 字段都不是 _const.SkipReturnReviewTypeSkipAudit。
			// 逻辑链路：
			// 1. 函数入口的第一个 if 条件为 false。
			// 2. for 循环遍历 Reviewers，所有符合条件的审核人进入 else 分支，将 hasAuditEmail 设置为 true。
			// 3. skipReturnReviewNoAuditEmails 列表保持为空（nil）。
			// 4. 循环结束后，hasAuditEmail 为 true。
			// 5. 最后的 if (!hasAuditEmail) 条件为 false，函数返回空的（nil） skipReturnReviewNoAuditEmails 列表。
			pc := &auditmodel.ProcessCtx{
				PreContractVO: &model.ContractMetaDB{
					CooperationStatus: _const.PreSalesContractChange,
				},
				ContractInfo: &model.ContractMeta{
					Reviewers: bizmodels.PreContractReviewerList{
						{Reviewer: "user.reaudit1@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeNeedAudit},
						{Reviewer: "user.reaudit2@test.com", ReviewerType: reviewerType, ContractStatus: newStatus, ReviewerSource: 0, SkipReturnReview: _const.SkipReturnReviewTypeNone},
					},
				},
			}

			result := e.fetchSkipReturnReviewNoAuditEmails(ctx, pc, newStatus, reviewerType)

			// 修复：函数在这种情况下返回一个nil切片，它是一个“空列表”。
			// 使用ShouldBeEmpty断言可以正确处理nil切片和非nil空切片的情况。
			convey.So(result, convey.ShouldBeEmpty)
		})
	})
}

func Test_engine_selectHandler_BitsUTGen(t *testing.T) {
	// MockStatusOpHandler is a mock implementation of the handler.StatusOpHandler interface
	// for testing purposes.
	type MockStatusOpHandler struct {
		handler.StatusOpHandler
	}

	mockey.PatchConvey("Test_engine_selectHandler", t, func() {
		mockey.PatchConvey("success: when contractState and opState both exist, should return the correct handler", func() {
			// 场景描述：
			// 构造一个 engine 实例，并在其 statusHandleMappings 字段中设置一个存在的 contractState 和 opState，
			// 对应一个有效的 handler 实例。
			// 逻辑链路：
			// 1. 调用 selectHandler 方法，传入预设的 contractState 和 opState。
			// 2. 方法在 statusHandleMappings 中成功找到 contractState 对应的一级 map。
			// 3. 检查一级 map 的长度不为 0。
			// 4. 在一级 map 中成功找到 opState 对应的 handler。
			// 5. 方法返回该 handler 实例。

			// 准备数据
			mockHandler := &MockStatusOpHandler{}
			e := &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					1: { // contractState = 1
						10: mockHandler, // opState = 10
					},
				},
			}

			// 调用目标函数
			result := e.selectHandler(1, 10)

			// 断言
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldEqual, mockHandler)
		})

		mockey.PatchConvey("failure: when contractState exists but opState does not, should return nil", func() {
			// 场景描述：
			// 构造一个 engine 实例，在 statusHandleMappings 中设置一个存在的 contractState，
			// 但该状态对应的 map 中不包含要查询的 opState。
			// 逻辑链路：
			// 1. 调用 selectHandler 方法，传入存在的 contractState 和一个不存在的 opState。
			// 2. 方法在 statusHandleMappings 中成功找到 contractState 对应的一级 map。
			// 3. 检查一级 map 的长度不为 0。
			// 4. 在一级 map 中查找 opState，因 key 不存在，返回 map 的零值，即 nil。
			// 5. 方法返回 nil。

			// 准备数据
			e := &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					1: { // contractState = 1
						10: &MockStatusOpHandler{}, // 存在的 opState
					},
				},
			}

			// 调用目标函数
			result := e.selectHandler(1, 99) // opState = 99 不存在

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: when contractState does not exist, should return nil", func() {
			// 场景描述：
			// 构造一个 engine 实例，其 statusHandleMappings 中不包含要查询的 contractState。
			// 逻辑链路：
			// 1. 调用 selectHandler 方法，传入一个不存在的 contractState。
			// 2. 方法在 statusHandleMappings 中查找 contractState，因 key 不存在，返回 map 的零值，即一个空的 map。
			// 3. 方法检查返回的 map 长度 `len(m) == 0`，条件成立。
			// 4. 方法直接返回 nil。

			// 准备数据
			e := &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{
					1: { // 存在的 contractState
						10: &MockStatusOpHandler{},
					},
				},
			}

			// 调用目标函数
			result := e.selectHandler(99, 10) // contractState = 99 不存在

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: when statusHandleMappings is empty, should return nil", func() {
			// 场景描述：
			// 构造一个 engine 实例，其 statusHandleMappings 字段为一个空 map。
			// 逻辑链路：
			// 1. 调用 selectHandler 方法。
			// 2. 方法在空的 statusHandleMappings 中查找任何 contractState，都将返回一个空的 map。
			// 3. 方法检查返回的 map 长度 `len(m) == 0`，条件成立。
			// 4. 方法直接返回 nil。

			// 准备数据
			e := &engine{
				statusHandleMappings: map[int]map[int]handler.StatusOpHandler{},
			}

			// 调用目标函数
			result := e.selectHandler(1, 10)

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure: when statusHandleMappings is nil, should return nil", func() {
			// 场景描述：
			// 构造一个 engine 实例，其 statusHandleMappings 字段为 nil。
			// 逻辑链路：
			// 1. 调用 selectHandler 方法。
			// 2. 方法在 nil 的 statusHandleMappings 中查找任何 contractState，都将返回一个空的 map。
			// 3. 方法检查返回的 map 长度 `len(m) == 0`，条件成立。
			// 4. 方法直接返回 nil。

			// 准备数据
			e := &engine{
				statusHandleMappings: nil,
			}

			// 调用目标函数
			result := e.selectHandler(1, 10)

			// 断言
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func TestFillSkipNodeOpRecord(t *testing.T) {
	mockey.PatchConvey("TestFillSkipNodeOpRecord", t, func() {
		ctx := context.Background()
		e := &engine{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				CooperationStatus: 3,
				Reviewers: []*bizmodels.PreContractReviewer{
					{
						ContractStatus: 4,
						Reviewer:       "reviewer1",
					},
					{
						ContractStatus: 4,
						Reviewer:       "reviewer2",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer3",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer4",
					},
				},
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ContractNewStatusOnSuccess: 7,
			},
			OperationState: _const.OperationReviewPass,
			StatusChanged:  true,
		}
		record := &model.ContractOperationRecordDB{
			PreContractNo: "",
		}
		res := e.fillSkipNodeOpRecord(ctx, record, pc)
		convey.So(len(res), convey.ShouldResemble, 4)
		for _, r := range res {
			if r.ContractStatus == 4 {
				convey.So(r.Operator, convey.ShouldBeIn, []string{"reviewer1", "reviewer2"})
			}
			if r.ContractStatus == 5 {
				convey.So(r.Operator, convey.ShouldBeIn, []string{"reviewer3", "reviewer4"})
			}
		}
	})

	mockey.PatchConvey("TestFillSkipNodeOpRecord StatusChanged-continue", t, func() {
		ctx := context.Background()
		e := &engine{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				CooperationStatus: 3,
				Reviewers: []*bizmodels.PreContractReviewer{
					{
						ContractStatus: 4,
						Reviewer:       "reviewer1",
					},
					{
						ContractStatus: 4,
						Reviewer:       "reviewer2",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer3",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer4",
					},
				},
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ContractNewStatusOnSuccess: 7,
			},
			OperationState: _const.OperationReviewPass,
			StatusChanged:  false,
		}
		record := &model.ContractOperationRecordDB{
			PreContractNo: "",
		}
		res := e.fillSkipNodeOpRecord(ctx, record, pc)
		convey.So(len(res), convey.ShouldResemble, 0)
	})

	mockey.PatchConvey("TestFillSkipNodeOpRecord OperationState-continue", t, func() {
		ctx := context.Background()
		e := &engine{}
		pc := &auditmodel.ProcessCtx{
			ContractInfo: &model.ContractMeta{
				CooperationStatus: 3,
				Reviewers: []*bizmodels.PreContractReviewer{
					{
						ContractStatus: 4,
						Reviewer:       "reviewer1",
					},
					{
						ContractStatus: 4,
						Reviewer:       "reviewer2",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer3",
					},
					{
						ContractStatus: 5,
						Reviewer:       "reviewer4",
					},
				},
			},
			ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
				ContractNewStatusOnSuccess: 7,
			},
			OperationState: _const.OperationSendBack,
			StatusChanged:  true,
		}
		record := &model.ContractOperationRecordDB{
			PreContractNo: "",
		}
		res := e.fillSkipNodeOpRecord(ctx, record, pc)
		convey.So(len(res), convey.ShouldResemble, 0)
	})
}

func Test_engine_createOperateRecord_BitsUTGen(t *testing.T) {
	type MockRichTextDao struct {
		dal.RichTextDao
	}
	type MockContractOperationRecordDao struct {
		dal.ContractOperationRecordDao
	}
	mockey.PatchConvey("Test engine.createOperateRecord", t, func() {
		ctx := context.Background()
		e := &engine{}
		db := &gorm.DB{}

		mockey.PatchConvey("Happy path: all operations succeed with comment and file versions", func() {
			// 场景描述:
			// 构造数据: pc包含所有需要的信息，包括Comment, RecordVersions等
			// 逻辑链路:
			// 1. json.Marshal被调用以处理RecordVersions
			// 2. model.ConvertRichTextDB 被调用
			// 3. dal.NewRichTextDao().Create 成功，并模拟设置了富文本ID
			// 4. e.fillSkipNodeOpRecord 返回一个空slice
			// 5. dal.NewContractOperationRecordDao().BatchCreate 成功
			// 6. 函数返回nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CONTRACT-001",
					CooperationStatus: _const.PreSalesContractDraft,
				},
				CurrentOperator: "test.operator",
				OperationState:  _const.OperationReviewPass,
				Remark:          "Test remark",
				Extra:           "Test extra",
				RecordVersions: []*bizmodels.FileVersionData{
					{BizType: 1, FileID: "file1", FileName: "file1.pdf", Version: "v1"},
				},
				Comment: &bizmodels.RichTextInfo{
					ID:                0,
					Richtext:          "rich text content",
					RichtextPlainText: "plain text",
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(db).Build()
			mockRichTextDao := &MockRichTextDao{}
			mockey.Mock(dal.NewRichTextDao).Return(mockRichTextDao).Build()
			mockey.Mock((*MockRichTextDao).Create).To(func(_ context.Context, _ *gorm.DB, rt *model.RichText) error {
				if rt != nil {
					rt.Id = 123
				}
				return nil
			}).Build()
			mockey.Mock((*engine).fillSkipNodeOpRecord).Return(make([]*model.ContractOperationRecordDB, 0)).Build()
			mockOpRecordDao := &MockContractOperationRecordDao{}
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockOpRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).BatchCreate).Return(nil).Build()

			err := e.createOperateRecord(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case: RichTextDao Create fails", func() {
			// 场景描述:
			// 构造数据: pc包含Comment, 导致调用RichTextDao.Create
			// 逻辑链路:
			// 1. dal.NewRichTextDao().Create 返回一个错误
			// 2. 函数记录日志并返回 "存储富文本信息失败" 错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CONTRACT-002",
					CooperationStatus: _const.PreSalesContractDraft,
				},
				CurrentOperator: "test.operator",
				Comment: &bizmodels.RichTextInfo{
					Richtext: "some text",
				},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(db).Build()
			mockRichTextDao := &MockRichTextDao{}
			mockey.Mock(dal.NewRichTextDao).Return(mockRichTextDao).Build()
			mockey.Mock((*MockRichTextDao).Create).Return(errors.New("db create error")).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			err := e.createOperateRecord(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "存储富文本信息失败")
		})

		mockey.PatchConvey("Failure case: ContractOperationRecordDao BatchCreate fails", func() {
			// 场景描述:
			// 构造数据: pc不包含Comment，因此RichTextDao部分成功
			// 逻辑链路:
			// 1. dal.NewRichTextDao().Create 成功 (被调用时参数为nil)
			// 2. e.fillSkipNodeOpRecord 成功
			// 3. dal.NewContractOperationRecordDao().BatchCreate 返回错误
			// 4. 函数记录日志并返回 "创建操作记录失败" 错误
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CONTRACT-003",
					CooperationStatus: _const.PreSalesContractDraft,
				},
				CurrentOperator: "test.operator",
				Comment:         nil, // No comment
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(db).Build()
			mockRichTextDao := &MockRichTextDao{}
			mockey.Mock(dal.NewRichTextDao).Return(mockRichTextDao).Build()
			mockey.Mock((*MockRichTextDao).Create).Return(nil).Build()
			mockey.Mock((*engine).fillSkipNodeOpRecord).Return(make([]*model.ContractOperationRecordDB, 0)).Build()
			mockOpRecordDao := &MockContractOperationRecordDao{}
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockOpRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).BatchCreate).Return(errors.New("db batch create error")).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			err := e.createOperateRecord(ctx, pc)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "创建操作记录失败")
		})

		mockey.PatchConvey("Success case: with skipped node records returned by fillSkipNodeOpRecord", func() {
			// 场景描述:
			// 构造数据: pc不包含Comment
			// 逻辑链路:
			// 1. dal.NewRichTextDao().Create 成功
			// 2. e.fillSkipNodeOpRecord 返回一个包含2个记录的slice
			// 3. dal.NewContractOperationRecordDao().BatchCreate 被调用时，应该收到一个包含3个记录(1个主操作+2个跳过)的slice
			// 4. dal.NewContractOperationRecordDao().BatchCreate 成功
			// 5. 函数返回 nil
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CONTRACT-004",
					CooperationStatus: _const.PreSalesContractDraft,
				},
				CurrentOperator: "test.operator",
				Comment:         nil,
			}
			skippedRecords := []*model.ContractOperationRecordDB{
				{PreContractNo: "CONTRACT-004", Operator: "skipped.user1"},
				{PreContractNo: "CONTRACT-004", Operator: "skipped.user2"},
			}

			mockey.Mock((*auditmodel.ProcessCtx).GetTx).Return(db).Build()
			mockRichTextDao := &MockRichTextDao{}
			mockey.Mock(dal.NewRichTextDao).Return(mockRichTextDao).Build()
			mockey.Mock((*MockRichTextDao).Create).Return(nil).Build()
			mockey.Mock((*engine).fillSkipNodeOpRecord).Return(skippedRecords).Build()
			mockOpRecordDao := &MockContractOperationRecordDao{}
			mockey.Mock(dal.NewContractOperationRecordDao).Return(mockOpRecordDao).Build()
			mockey.Mock((*MockContractOperationRecordDao).BatchCreate).To(func(_ context.Context, _ *gorm.DB, records []*model.ContractOperationRecordDB) error {
				convey.So(len(records), convey.ShouldEqual, 3)
				convey.So(records[0].Operator, convey.ShouldEqual, "test.operator")
				convey.So(records[1].Operator, convey.ShouldEqual, "skipped.user1")
				convey.So(records[2].Operator, convey.ShouldEqual, "skipped.user2")
				return nil
			}).Build()

			err := e.createOperateRecord(ctx, pc)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

// func Test_engine_resetFilePerm_BitsUTGen(t *testing.T) {
// 	mockey.PatchConvey("Test_engine_resetFilePerm", t, func() {
//
// 		e := &engine{}
// 		ctx := context.Background()
//
// 		mockey.PatchConvey("场景1: 正常流程，部分reviewer有写权限，部分只有读权限", func() {
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					OnlineContract:    "file-id-123",
// 					CooperationStatus: _const.PreSalesContractDraft,
// 				},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
// 					ContractNewStatusOnSuccess: _const.PreSalesContractSalesOperationReview,
// 				},
// 				ApprovalKey: _const.ApprovalKeyDefault,
// 			}
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "writable@example.com", ReviewerType: _const.ReviewerTypeSalesOperation},
// 				{Reviewer: "readonly@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context {
// 				return ctx
// 			}).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
// 			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{
// 				"writable@example.com": {ID: 1001, Name: "Writable User", Email: "writable@example.com"},
// 				"readonly@example.com": {ID: 1002, Name: "Readonly User", Email: "readonly@example.com"},
// 			}, nil).Build()
// 			writableTypes := []int{_const.ReviewerTypeSalesOperation}
// 			mockey.Mock(handler.GetWritableReviewerType).Return(writableTypes, true).Build()
// 			mockey.Mock(utils.IntIn).To(func(item int, list []int) bool {
// 				return item == _const.ReviewerTypeSalesOperation
// 			}).Build()
// 			var capturedReq *filecli.UpdateUserPermissionReq
// 			mockey.Mock(filecli.UpdateUserPermission).To(func(ctx context.Context, req *filecli.UpdateUserPermissionReq) error {
// 				capturedReq = req
// 				return nil
// 			}).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(capturedReq, convey.ShouldNotBeNil)
// 			convey.So(len(capturedReq.Users), convey.ShouldEqual, 3)
// 			permsMap := make(map[string][]int)
// 			for _, u := range capturedReq.Users {
// 				permsMap[u.Email] = append(permsMap[u.Email], u.Permission)
// 			}
// 			convey.So(permsMap["writable@example.com"], convey.ShouldContain, _const.PermissionRead)
// 			convey.So(permsMap["writable@example.com"], convey.ShouldContain, _const.PermissionWrite)
// 			convey.So(permsMap["readonly@example.com"], convey.ShouldContain, _const.PermissionRead)
// 			convey.So(permsMap["readonly@example.com"], convey.ShouldNotContain, _const.PermissionWrite)
// 		})
//
// 		mockey.PatchConvey("场景2: reviewers 列表为空", func() {
//
// 			err := e.resetFilePerm(ctx, &auditmodel.ProcessCtx{}, bizmodels.PreContractReviewerList{})
//
// 			convey.So(err, convey.ShouldBeNil)
// 		})
//
// 		mockey.PatchConvey("场景3: 获取员工信息失败 (larkc.BatchGetEmployees)", func() {
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo:         &model.ContractMeta{},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{},
// 			}
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "user@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context { return ctx }).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
// 			mockey.Mock(larkc.BatchGetEmployees).Return(nil, errors.New("larkc error")).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err.Error(), convey.ShouldContainSubstring, "larkc error")
// 		})
//
// 		mockey.PatchConvey("场景4: 更新文件权限失败 (filecli.UpdateUserPermission)", func() {
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					OnlineContract: "file-id-123",
// 				},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
// 					ContractNewStatusOnSuccess: _const.PreSalesContractSalesOperationReview,
// 				},
// 				ApprovalKey: _const.ApprovalKeyDefault,
// 			}
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "user@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context { return ctx }).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
// 			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{
// 				"user@example.com": {ID: 1001, Name: "Test User", Email: "user@example.com"},
// 			}, nil).Build()
// 			mockey.Mock(handler.GetWritableReviewerType).Return([]int{}, true).Build()
// 			mockey.Mock(filecli.UpdateUserPermission).Return(errors.New("filecli error")).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldNotBeNil)
// 			convey.So(err.Error(), convey.ShouldContainSubstring, "filecli error")
// 		})
//
// 		mockey.PatchConvey("场景5: 无可写权限定义 (handler.GetWritableReviewerType returns defined=false)", func() {
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					OnlineContract: "file-id-123",
// 				},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
// 					ContractNewStatusOnSuccess: _const.PreSalesContractSalesOperationReview,
// 				},
// 				ApprovalKey: _const.ApprovalKeyDefault,
// 			}
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "user1@example.com", ReviewerType: _const.ReviewerTypeSalesOperation},
// 				{Reviewer: "user2@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context { return ctx }).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
// 			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{
// 				"user1@example.com": {ID: 1001, Name: "User 1", Email: "user1@example.com"},
// 				"user2@example.com": {ID: 1002, Name: "User 2", Email: "user2@example.com"},
// 			}, nil).Build()
// 			mockey.Mock(handler.GetWritableReviewerType).Return(nil, false).Build()
// 			var capturedReq *filecli.UpdateUserPermissionReq
// 			mockey.Mock(filecli.UpdateUserPermission).To(func(ctx context.Context, req *filecli.UpdateUserPermissionReq) error {
// 				capturedReq = req
// 				return nil
// 			}).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(capturedReq, convey.ShouldNotBeNil)
// 			convey.So(len(capturedReq.Users), convey.ShouldEqual, 2)
// 			for _, u := range capturedReq.Users {
// 				convey.So(u.Permission, convey.ShouldEqual, _const.PermissionRead)
// 			}
// 		})
//
// 		mockey.PatchConvey("场景6: 某个reviewer在lark中未找到", func() {
//
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					OnlineContract: "file-id-123",
// 				},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
// 					ContractNewStatusOnSuccess: _const.PreSalesContractSalesOperationReview,
// 				},
// 				ApprovalKey: _const.ApprovalKeyDefault,
// 			}
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "found@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 				{Reviewer: "notfound@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context { return ctx }).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
// 			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{
// 				"found@example.com": {ID: 1001, Name: "Found User", Email: "found@example.com"},
// 			}, nil).Build()
// 			mockey.Mock(handler.GetWritableReviewerType).Return(nil, false).Build()
// 			var capturedReq *filecli.UpdateUserPermissionReq
// 			mockey.Mock(filecli.UpdateUserPermission).To(func(ctx context.Context, req *filecli.UpdateUserPermissionReq) error {
// 				capturedReq = req
// 				return nil
// 			}).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(capturedReq, convey.ShouldNotBeNil)
// 			convey.So(len(capturedReq.Users), convey.ShouldEqual, 1)
// 			convey.So(capturedReq.Users[0].Email, convey.ShouldEqual, "found@example.com")
// 			convey.So(capturedReq.Users[0].Permission, convey.ShouldEqual, _const.PermissionRead)
// 		})
//
// 		mockey.PatchConvey("场景7: 单个用户有多个角色，其中一个可写", func() {
// 			pc := &auditmodel.ProcessCtx{
// 				ContractInfo: &model.ContractMeta{
// 					OnlineContract:    "file-id-789",
// 					CooperationStatus: _const.PreSalesContractDraft,
// 				},
// 				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
// 					ContractNewStatusOnSuccess: _const.PreSalesContractSalesOperationReview,
// 				},
// 				ApprovalKey: _const.ApprovalKeyDefault,
// 			}
// 			// a single user with two roles
// 			reviewers := bizmodels.PreContractReviewerList{
// 				{Reviewer: "multi-role@example.com", ReviewerType: _const.ReviewerTypeSalesperson},
// 				{Reviewer: "multi-role@example.com", ReviewerType: _const.ReviewerTypeSalesOperation},
// 			}
//
// 			mockey.Mock(utils.CopyContext).To(func(ctx context.Context) context.Context {
// 				return ctx
// 			}).Build()
// 			mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
// 			mockey.Mock((*engine).buildReviewersLogInfo).Return("mocked_log_info").Build()
//
// 			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{
// 				"multi-role@example.com": {ID: 1003, Name: "Multi Role User", Email: "multi-role@example.com"},
// 			}, nil).Build()
//
// 			writableTypes := []int{_const.ReviewerTypeSalesOperation}
// 			mockey.Mock(handler.GetWritableReviewerType).Return(writableTypes, true).Build()
//
// 			mockey.Mock(utils.IntIn).To(func(item int, list []int) bool {
// 				// This mock is simple but effective for this test case's logic
// 				return item == _const.ReviewerTypeSalesOperation
// 			}).Build()
//
// 			var capturedReq *filecli.UpdateUserPermissionReq
// 			mockey.Mock(filecli.UpdateUserPermission).To(func(ctx context.Context, req *filecli.UpdateUserPermissionReq) error {
// 				capturedReq = req
// 				return nil
// 			}).Build()
//
// 			err := e.resetFilePerm(ctx, pc, reviewers)
//
// 			convey.So(err, convey.ShouldBeNil)
// 			convey.So(capturedReq, convey.ShouldNotBeNil)
// 			convey.So(len(capturedReq.Users), convey.ShouldEqual, 2) // read + write
//
// 			perms := make(map[int]bool)
// 			for _, u := range capturedReq.Users {
// 				convey.So(u.Email, convey.ShouldEqual, "multi-role@example.com")
// 				perms[u.Permission] = true
// 			}
// 			convey.So(perms[_const.PermissionRead], convey.ShouldBeTrue)
// 			convey.So(perms[_const.PermissionWrite], convey.ShouldBeTrue)
// 		})
// 	})
// }

func Test_engine_matchReviewerStatusOpConf(t *testing.T) {
	// 测试输入ProcessCtx为nil的场景
	t.Run("InputProcessCtxNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			// 构造函数入参
			var receiver = &engine{}
			var ctxTest = context.Background()
			// 运行被测函数
			got1, got2, err := receiver.matchReviewerStatusOpConf(ctxTest, nil)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 入参pc为nil，函数提前返回，不会获取到有效的处理器，所以got1为nil
			convey.So(got1 == nil, convey.ShouldBeTrue)
			// 入参pc为nil，函数提前返回，不会获取到有效的审批流转配置，所以got2为nil
			convey.So(got2, convey.ShouldBeNil)
			// 当入参pc为nil时，函数会进入参数异常的判断分支，返回错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当入参pc为nil时，函数会使用i18nfmt.New返回错误信息，由于i18nfmt.New被mock返回nil，这里根据业务函数逻辑应该返回\"参数异常\
			convey.So(err.Error(), convey.ShouldNotBeBlank)
		})
	})
	// 测试selectHandler返回nil的场景
	t.Run("SelectHandlerReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			mockey.Mock(_const.GenOperateDesc).Return("Operation successful").Build()
			// [目标分支] selectHandlerRet1Mock == nil
			mockey.Mock((*engine).selectHandler).Return(nil).Build()
			mockey.Mock(i18nfmt.Errorf, mockey.OptUnsafe).Return(nil).Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			// 构造函数入参
			var receiver *engine = &engine{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				CurrentOperator: "Default Value",
				OperationState:  10,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 1,
					ContractNo:        "CT20240001",
				},
			}
			// 运行被测函数
			got1, got2, err := receiver.matchReviewerStatusOpConf(ctxTest, pcTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// selectHandler返回nil，函数会提前返回，不会给got1赋值，所以got1为nil
			convey.So(got1 == nil, convey.ShouldBeTrue)
			// selectHandler返回nil，函数会提前返回，不会给got2赋值，所以got2为nil
			convey.So(got2, convey.ShouldBeNil)
			// selectHandler返回nil时，函数会进入相应的错误处理逻辑，返回错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// selectHandler返回nil时，会构造该错误信息返回
			convey.So(err.Error(), convey.ShouldNotBeBlank)
		})
	})
	// 测试输入handler.GetValidReviewerType返回nil的场景
	t.Run("GetValidReviewerTypeReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			// [目标分支] getValidReviewerTypeRet1Mock == nil
			mockey.Mock(handler.GetValidReviewerType).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			mockey.Mock(_const.GenOperateDesc).Return("Operation successful").Build()
			// [目标分支] selectHandlerRet1Mock != nil
			mockey.Mock((*engine).selectHandler).Return(&mockStatusOpHandler{}).Build()
			// 构造函数入参
			var receiver *engine = &engine{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				ApprovalKey: "Default Value",
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 1,
				},
				CurrentOperator: "Default Value",
				OperationState:  10,
			}
			// 运行被测函数
			got1, got2, err := receiver.matchReviewerStatusOpConf(ctxTest, pcTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// mock (*engine).selectHandler返回非nil值，所以got1不为nil
			convey.So(got1, convey.ShouldBeNil)
			// mock handler.GetValidReviewerType返回nil，所以got2为nil
			convey.So(got2, convey.ShouldBeNil)
			// mock handler.GetValidReviewerType返回nil时，预期执行分支会返回权限配置未定义的错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当handler.GetValidReviewerType返回nil时，函数会返回权限配置未定义的错误
			convey.So(err.Error(), convey.ShouldNotBeBlank)
		})
	})
	// 测试输入正常且mock函数正常返回的场景
	t.Run("NormalInputAndMockReturn", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// mock调用的函数与全局变量
			// [目标分支] selectHandlerRet1Mock != nil
			mockey.Mock((*engine).selectHandler).Return(&mockStatusOpHandler{}).Build()
			mockey.Mock(handler.GetValidReviewerType).Return(&modelcooperation.ReviewerStatusOpConf{
				ContractNewStatusOnSuccess: 1,
			}).Build()
			mockey.Mock(_const.GenStatusDesc).Return("Generation status is normal").Build()
			mockey.Mock(_const.GenOperateDesc).Return("Operation successful").Build()
			// 构造函数入参
			var receiver *engine = &engine{}
			var ctxTest context.Context = context.Background()
			// [目标分支] pcTest.ContractInfo != nil
			var pcTest *auditmodel.ProcessCtx = &auditmodel.ProcessCtx{
				OperationState: 10,
				ApprovalKey:    "Default Value",
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 1,
				},
				CurrentOperator: "Default Value",
			}
			// 运行被测函数
			got1, got2, err := receiver.matchReviewerStatusOpConf(ctxTest, pcTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// mock了selectHandler函数返回非nil值，所以got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
			// mock了GetValidReviewerType函数返回非nil值，所以got2不为nil
			convey.So(got2, convey.ShouldNotBeNil)
			// mock GetValidReviewerType函数时设置了ContractNewStatusOnSuccess的值为1
			convey.So(got2.ContractNewStatusOnSuccess, convey.ShouldEqual, 1)
			// 根据代码逻辑，mock函数使selectHandler和GetValidReviewerType都有返回值，且入参pc和pc.ContractInfo不为nil，不会触发错误返回，所以err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_engine_notifyCRM_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test engine.notifyCRM", t, func() {
		// Common setup
		e := &engine{}
		ctx := context.Background()
		meta := &model.ContractMeta{
			ContractNo: "TEST-CONTRACT-123",
		}
		newStatus := 1

		// Mock the recovery function to prevent panic-related logic.
		mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()

		convey.Convey("场景: 成功通知CRM", func() {
			// 场景描述:
			// 测试当对CRM的回调成功时，整个函数能够正常执行并返回nil。
			// 构造数据:
			// - meta: 一个有效的ContractMeta指针，包含ContractNo。
			// - newStatus: 一个有效的状态码。
			// 逻辑链路:
			// 1. 调用 salesforcecli.PreContractStatusCallback。
			// 2. Mock salesforcecli.PreContractStatusCallback 返回 nil，表示调用成功。
			// 3. if 条件(err != nil)为 false，不进入错误处理分支。
			// 4. 函数记录成功日志并返回 nil。

			mockey.Mock(salesforcecli.PreContractStatusCallbackV2).Return(nil).Build()

			// 调用目标函数
			err := e.notifyCRM(ctx, &auditmodel.ProcessCtx{
				ContractInfo: meta,
			}, newStatus)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("场景: 通知CRM失败", func() {
			// 场景描述:
			// 测试当对CRM的回调失败时，函数能够捕获错误，记录警告日志，但仍然返回nil，不会将错误向上传播。
			// 构造数据:
			// - meta: 一个有效的ContractMeta指针，包含ContractNo。
			// - newStatus: 一个有效的状态码。
			// 逻辑链路:
			// 1. 调用 salesforcecli.PreContractStatusCallback。
			// 2. Mock salesforcecli.PreContractStatusCallback 返回一个 error，表示调用失败。
			// 3. if 条件(err != nil)为 true，进入错误处理分支，记录警告日志。
			// 4. 函数继续执行，最终返回 nil。

			mockErr := errors.New("salesforce callback failed")
			mockey.Mock(salesforcecli.PreContractStatusCallbackV2).Return(mockErr).Build()

			// 调用目标函数
			err := e.notifyCRM(ctx, &auditmodel.ProcessCtx{
				ContractInfo: meta,
			}, newStatus)

			// 断言结果
			// 根据函数实现，即使内部调用失败，函数本身也会返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_engine_buildReviewersLogInfo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_engine_buildReviewersLogInfo", t, func() {
		// 初始化一个 engine 实例，因为 buildReviewersLogInfo 是它的方法
		e := &engine{}

		mockey.PatchConvey("场景: 输入的列表为nil", func() {
			// 场景描述：
			// 构造数据：构造一个nil的bizmodels.PreContractReviewerList
			// 逻辑链路：
			// 1. 调用buildReviewersLogInfo方法，传入nil列表
			// 2. 方法内的len(list) == 0判断为true
			// 3. 方法返回空字符串

			// 构造数据
			var list bizmodels.PreContractReviewerList = nil

			// 调用
			result := e.buildReviewersLogInfo(list)

			// 断言
			convey.So(result, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("场景: 输入的列表为空", func() {
			// 场景描述：
			// 构造数据：构造一个空的bizmodels.PreContractReviewerList
			// 逻辑链路：
			// 1. 调用buildReviewersLogInfo方法，传入空列表
			// 2. 方法内的len(list) == 0判断为true
			// 3. 方法返回空字符串

			// 构造数据
			list := bizmodels.PreContractReviewerList{}

			// 调用
			result := e.buildReviewersLogInfo(list)

			// 断言
			convey.So(result, convey.ShouldEqual, "")
		})

		mockey.PatchConvey("场景: 列表中有一个审核人", func() {
			// 场景描述：
			// 构造数据：构造一个包含单个bizmodels.PreContractReviewer的列表
			// 逻辑链路：
			// 1. 调用buildReviewersLogInfo方法，传入含单个审核人的列表
			// 2. 方法内的len(list) == 0判断为false
			// 3. for循环执行一次，将格式化后的审核人信息写入buffer
			// 4. 方法返回拼接后的字符串

			// 构造数据
			list := bizmodels.PreContractReviewerList{
				{
					Reviewer:     "user1",
					ReviewerType: 1,
					Status:       2,
				},
			}

			// 调用
			result := e.buildReviewersLogInfo(list)

			// 断言
			convey.So(result, convey.ShouldEqual, "user1_type(1)_status(2)||")
		})

		mockey.PatchConvey("场景: 列表中有多个审核人", func() {
			// 场景描述：
			// 构造数据：构造一个包含多个bizmodels.PreContractReviewer的列表
			// 逻辑链路：
			// 1. 调用buildReviewersLogInfo方法，传入含多个审核人的列表
			// 2. 方法内的len(list) == 0判断为false
			// 3. for循环执行多次，将每个格式化后的审核人信息依次写入buffer
			// 4. 方法返回所有信息拼接后的字符串

			// 构造数据
			list := bizmodels.PreContractReviewerList{
				{
					Reviewer:     "user_A",
					ReviewerType: 10,
					Status:       20,
				},
				{
					Reviewer:     "user_B",
					ReviewerType: 30,
					Status:       40,
				},
			}

			// 调用
			result := e.buildReviewersLogInfo(list)

			// 断言
			convey.So(result, convey.ShouldEqual, "user_A_type(10)_status(20)||user_B_type(30)_status(40)||")
		})
	})
}

func Test_engine_calcComplianceCheckResult(t *testing.T) {
	mockey.PatchConvey("Test_engine_calcComplianceCheckResult", t, func() {
		// 初始化被测试的结构体
		e := &engine{}
		ctx := context.Background()

		mockey.PatchConvey("场景: 合规审查合同且审核通过", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractComplianceCheck，OperationState为OperationReviewPass。
			// 逻辑链路：
			// 1. 第一个if条件 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractComplianceCheck) 为true。
			// 2. 进入内层if，条件 (pc.OperationState == _const.OperationReviewPass) 为true。
			// 3. 函数返回 "Approved"。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractComplianceCheck,
				},
				OperationState: _const.OperationReviewPass,
			}

			// 调用并断言
			result := e.calcComplianceCheckResult(ctx, pc)
			convey.So(result, convey.ShouldEqual, "Approved")
		})

		mockey.PatchConvey("场景: 合规审查合同但审核不通过", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus为PreSalesContractComplianceCheck，但OperationState不为OperationReviewPass。
			// 逻辑链路：
			// 1. 第一个if条件 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractComplianceCheck) 为true。
			// 2. 进入内层if，条件 (pc.OperationState == _const.OperationReviewPass) 为false，进入else分支。
			// 3. 函数返回 "Rejected"。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					CooperationStatus: _const.PreSalesContractComplianceCheck,
				},
				OperationState: 99, // 非 OperationReviewPass 的任意值
			}

			// 调用并断言
			result := e.calcComplianceCheckResult(ctx, pc)
			convey.So(result, convey.ShouldEqual, "Rejected")
		})

		mockey.PatchConvey("场景: 非合规审查合同", func() {
			// 场景描述：
			// 构造数据：ProcessCtx中ContractInfo的PreCooperationStatus不为PreSalesContractComplianceCheck。
			// 逻辑链路：
			// 1. 第一个if条件 (pc.ContractInfo.PreCooperationStatus == _const.PreSalesContractComplianceCheck) 为false。
			// 2. 函数直接返回空字符串 ""。
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					PreCooperationStatus: 1, // 非 PreSalesContractComplianceCheck 的任意值
				},
			}

			// 调用并断言
			result := e.calcComplianceCheckResult(ctx, pc)
			convey.So(result, convey.ShouldEqual, "")
		})
	})
}

func Test_engine_changeContractStatus(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.ResetReviewerStatusByReviewerType).Return(nil).Build()
			var v10 = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{}})
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNo")).Return(v10, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(nil).Build()
			mockey.Mock(recovery.DefaultRecovery).Return(func() { return }).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{"": {
				ID:        0,
				Name:      "",
				Email:     "",
				AvatarURL: "",
			}}, nil).Build()
			mockey.Mock(handler.GetWritableReviewerType).Return([]int{0}, false).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()
			mockey.Mock(salesforcecli.PreContractStatusCallbackV2).Return(nil).Build()

			// Act
			v26 := &engine{
				statusReviewTypeMappings: map[int]int{0: 0},
			}
			var v27 = bizmodels.PreContractReviewerList([]*bizmodels.PreContractReviewer{{}})
			err := v26.changeContractStatus(context.Background(), "approvalKey", &auditmodel.ProcessCtx{
				CurrentOperator: "xxxx@email",
				OperationState:  1,
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
					Reviewers:         v27,
					OnlineContract:    "cn_filexxxxx01",
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusOnSuccess: 8,
					ContractNewStatusMapOnSuccess: map[string]int{
						"approvalKey": 8,
					},
				},
				ApprovalKey: "",
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case resolveContractNewStatus fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			expectedErr := fmt.Errorf("resolveContractNewStatusFail")
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}

			mockey.Mock((*engine).resolveContractNewStatus).Return(0, expectedErr).Build()

			err := (&engine{}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(pc.StatusChanged, convey.ShouldBeFalse)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 0)
		})
	})
	t.Run("case UpdateCooperationStatus fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}
			pc.SetTX(&gorm.DB{})

			mockey.Mock(i18nfmt.New).To(func(_ context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*engine).resolveContractNewStatus).Return(8, nil).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(fmt.Errorf("UpdateCooperationStatusFail")).Build()

			err := (&engine{}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err.Error(), convey.ShouldEqual, "更新合同协同状态失败")
			convey.So(pc.StatusChanged, convey.ShouldBeFalse)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 0)
		})
	})
	t.Run("case SoftDeleteCountersignReviewerFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.ResetReviewerStatusByReviewerType).Return(nil).Build()
			var v10 = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{}})
			mockey.Mock(mockey.GetMethod(reviewerDao, "FindReviewersByNo")).Return(v10, nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(fmt.Errorf("SoftDeleteCountersignReviewerFail")).Build()
			mockey.Mock(recovery.DefaultRecovery).Return(func() { return }).Build()
			mockey.Mock(larkc.BatchGetEmployees).Return(map[string]*peopleclient.Employee{"": {
				ID:        0,
				Name:      "",
				Email:     "",
				AvatarURL: "",
			}}, nil).Build()
			mockey.Mock(handler.GetWritableReviewerType).Return([]int{0}, false).Build()
			mockey.Mock(filecli.UpdateUserPermission).Return(nil).Build()
			mockey.Mock(salesforcecli.PreContractStatusCallbackV2).Return(nil).Build()

			// Act
			v26 := &engine{
				statusReviewTypeMappings: map[int]int{0: 0},
			}
			var v27 = bizmodels.PreContractReviewerList([]*bizmodels.PreContractReviewer{{}})
			err := v26.changeContractStatus(context.Background(), "approvalKey", &auditmodel.ProcessCtx{
				CurrentOperator: "xxxx@email",
				OperationState:  1,
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
					Reviewers:         v27,
					OnlineContract:    "cn_filexxxxx01",
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusOnSuccess: 8,
					ContractNewStatusMapOnSuccess: map[string]int{
						"approvalKey": 8,
					},
				},
				ApprovalKey: "",
			})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "SoftDeleteCountersignReviewerFail")
		})
	})
	t.Run("case InitReviewersAfterStatusChanged fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			expectedErr := fmt.Errorf("InitReviewersAfterStatusChangedFail")
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}
			pc.SetTX(&gorm.DB{})

			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(nil).Build()
			mockey.Mock((*engine).resolveContractNewStatus).Return(8, nil).Build()
			mockey.Mock(handler.InitReviewersAfterStatusChanged).Return(expectedErr).Build()

			err := (&engine{}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(pc.StatusChanged, convey.ShouldBeTrue)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 8)
		})
	})
	t.Run("case no reviewer reset mapping", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			notifyDone := make(chan struct{}, 1)
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "xxxx@email",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}
			pc.SetTX(&gorm.DB{})

			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(nil).Build()
			mockey.Mock((*engine).resolveContractNewStatus).Return(8, nil).Build()
			mockey.Mock(handler.InitReviewersAfterStatusChanged).Return(nil).Build()
			mockey.Mock((*engine).notifyCRM).To(func(_ *engine, _ context.Context, _ *auditmodel.ProcessCtx, _ int) error {
				notifyDone <- struct{}{}
				return nil
			}).Build()

			err := (&engine{}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldBeNil)
			select {
			case <-notifyDone:
			case <-time.After(time.Second):
				t.Fatal("notifyCRM not called")
			}
			convey.So(pc.StatusChanged, convey.ShouldBeTrue)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 8)
			convey.So(pc.SkipReturnReviewNoAuditEmails, convey.ShouldBeNil)
		})
	})
	t.Run("case reviewer reset mapping with skip emails", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			notifyDone := make(chan struct{}, 1)
			expectedSkipEmails := []string{"skip1@email", "skip2@email"}
			pc := &auditmodel.ProcessCtx{
				CurrentOperator: "xxxx@email",
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}
			pc.SetTX(&gorm.DB{})

			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(nil).Build()
			mockey.Mock((*engine).resolveContractNewStatus).Return(8, nil).Build()
			mockey.Mock(handler.InitReviewersAfterStatusChanged).Return(nil).Build()
			mockey.Mock((*engine).fetchSkipReturnReviewNoAuditEmails).Return(expectedSkipEmails).Build()
			mockey.Mock(dal.ResetReviewerStatusByReviewerType).To(
				func(_ context.Context, _ *gorm.DB, param *model.ResetReviewerStatusByReviewerTypeReq) error {
					convey.So(param.PreContractNO, convey.ShouldEqual, "CTXXXXX01")
					convey.So(param.ReviewerType, convey.ShouldEqual, 9)
					convey.So(param.ContractStatus, convey.ShouldEqual, 8)
					convey.So(param.SkipReturnReviewNoAuditEmails, convey.ShouldResemble, expectedSkipEmails)
					return nil
				},
			).Build()
			mockey.Mock((*engine).notifyCRM).To(func(_ *engine, _ context.Context, _ *auditmodel.ProcessCtx, _ int) error {
				notifyDone <- struct{}{}
				return nil
			}).Build()

			err := (&engine{statusReviewTypeMappings: map[int]int{8: 9}}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(pc.StatusChanged, convey.ShouldBeTrue)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 8)
			convey.So(pc.SkipReturnReviewNoAuditEmails, convey.ShouldResemble, expectedSkipEmails)
			select {
			case <-notifyDone:
			case <-time.After(time.Second):
				t.Fatal("notifyCRM not called")
			}
		})
	})
	t.Run("case ResetReviewerStatusByReviewerType fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			expectedSkipEmails := []string{"skip1@email", "skip2@email"}
			pc := &auditmodel.ProcessCtx{
				ContractInfo: &model.ContractMeta{
					ContractNo:        "CTXXXXX01",
					CooperationStatus: 7,
				},
			}
			pc.SetTX(&gorm.DB{})

			mockey.Mock(i18nfmt.New).To(func(_ context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock(dal.NewContractMetaDao).Return(metaDao).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "UpdateCooperationStatus")).Return(nil).Build()
			mockey.Mock(dal.NewPreContractReviewerDao).Return(reviewerDao).Build()
			mockey.Mock(mockey.GetMethod(reviewerDao, "SoftDeleteCountersignReviewer")).Return(nil).Build()
			mockey.Mock((*engine).resolveContractNewStatus).Return(8, nil).Build()
			mockey.Mock(handler.InitReviewersAfterStatusChanged).Return(nil).Build()
			mockey.Mock((*engine).fetchSkipReturnReviewNoAuditEmails).Return(expectedSkipEmails).Build()
			mockey.Mock(dal.ResetReviewerStatusByReviewerType).Return(fmt.Errorf("ResetReviewerStatusByReviewerTypeFail")).Build()

			err := (&engine{statusReviewTypeMappings: map[int]int{8: 9}}).changeContractStatus(context.Background(), "approvalKey", pc)

			convey.So(err.Error(), convey.ShouldEqual, "重置操作人员状态失败")
			convey.So(pc.StatusChanged, convey.ShouldBeTrue)
			convey.So(pc.StatusChangedValue, convey.ShouldEqual, 8)
			convey.So(pc.SkipReturnReviewNoAuditEmails, convey.ShouldResemble, expectedSkipEmails)
		})
	})
}

func Test_engine_resolveContractNewStatus(t *testing.T) {
	t.Run("case mapped approval key", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusMapOnSuccess: map[string]int{
						"approvalKey": 8,
					},
				},
			}

			newStatus, err := (&engine{}).resolveContractNewStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newStatus, convey.ShouldEqual, 8)
		})
	})
	t.Run("case specified send back target", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			pc := &auditmodel.ProcessCtx{
				OperationState:         _const.OperationSendBack,
				SecondaryOperationType: _const.SecondaryOperationTypeSendBackSpecified,
				SendBackTargetStatus:   6,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 7,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					SpecifiedSendBackTargetStatuses: []int{5, 6},
				},
			}

			newStatus, err := (&engine{statusReviewTypeMappings: map[int]int{6: 9}}).resolveContractNewStatus(context.Background(), "approvalKey", pc)

			convey.So(err, convey.ShouldBeNil)
			convey.So(newStatus, convey.ShouldEqual, 6)
		})
	})
	t.Run("case invalid specified send back target", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(_ context.Context, text string) error { return fmt.Errorf(text) }).Build()
			e := &engine{statusReviewTypeMappings: map[int]int{5: 9}}

			zeroTargetPC := &auditmodel.ProcessCtx{
				OperationState:         _const.OperationSendBack,
				SecondaryOperationType: _const.SecondaryOperationTypeSendBackSpecified,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 7,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					SpecifiedSendBackTargetStatuses: []int{5, 6},
				},
			}
			_, err := e.resolveContractNewStatus(context.Background(), "approvalKey", zeroTargetPC)
			convey.So(err.Error(), convey.ShouldEqual, "请选择退回节点")

			outOfRangePC := &auditmodel.ProcessCtx{
				OperationState:         _const.OperationSendBack,
				SecondaryOperationType: _const.SecondaryOperationTypeSendBackSpecified,
				SendBackTargetStatus:   4,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 7,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					SpecifiedSendBackTargetStatuses: []int{5, 6},
				},
			}
			_, err = e.resolveContractNewStatus(context.Background(), "approvalKey", outOfRangePC)
			convey.So(err.Error(), convey.ShouldEqual, "无效的退回节点")

			noReviewerTypePC := &auditmodel.ProcessCtx{
				OperationState:         _const.OperationSendBack,
				SecondaryOperationType: _const.SecondaryOperationTypeSendBackSpecified,
				SendBackTargetStatus:   6,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 7,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					SpecifiedSendBackTargetStatuses: []int{5, 6},
				},
			}
			_, err = e.resolveContractNewStatus(context.Background(), "approvalKey", noReviewerTypePC)
			convey.So(err.Error(), convey.ShouldEqual, "退回节点审批角色配置错误")

			sameStatusPC := &auditmodel.ProcessCtx{
				OperationState:         _const.OperationSendBack,
				SecondaryOperationType: _const.SecondaryOperationTypeSendBackSpecified,
				SendBackTargetStatus:   5,
				ContractInfo: &model.ContractMeta{
					CooperationStatus: 5,
				},
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					SpecifiedSendBackTargetStatuses: []int{5, 6},
				},
			}
			_, err = e.resolveContractNewStatus(context.Background(), "approvalKey", sameStatusPC)
			convey.So(err.Error(), convey.ShouldEqual, "不能退回至当前节点")
		})
	})
	t.Run("case approval key not configured", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(_ context.Context, text string) error { return fmt.Errorf(text) }).Build()
			pc := &auditmodel.ProcessCtx{
				ReviewerStatusOpConf: &modelcooperation.ReviewerStatusOpConf{
					ContractNewStatusMapOnSuccess: map[string]int{
						"otherKey": 8,
					},
				},
			}

			newStatus, err := (&engine{}).resolveContractNewStatus(context.Background(), "approvalKey", pc)

			convey.So(err.Error(), convey.ShouldEqual, "合同协同状态变更配置错误")
			convey.So(newStatus, convey.ShouldEqual, 0)
		})
	})
}

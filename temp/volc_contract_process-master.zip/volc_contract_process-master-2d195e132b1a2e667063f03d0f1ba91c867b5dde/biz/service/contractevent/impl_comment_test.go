package contractevent

import (
	"context"
	"fmt"
	"testing"

	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/comment"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_Process(t *testing.T) {
	ctx := context.Background()
	table := "comment"
	dmlType := "insert"
	beforeColumns := map[string]interface{}{}
	afterColumns := map[string]interface{}{
		"comment_id": "CMT000001",
	}

	PatchConvey("Test DMLType is not insert", t, func() {
		dmlType = "update"
		actual, err := (commentEventRule{}).Process(ctx, table, dmlType, beforeColumns, afterColumns)
		So(actual, ShouldBeNil)
		So(err, ShouldBeNil)
	})

	PatchConvey("Test DMLType is insert and succeeds", t, func() {
		dmlType = "insert"
		Mock(commentNotify).Return().Build()
		Mock(commentPermissions).Return().Build()
		actual, err := (commentEventRule{}).Process(ctx, table, dmlType, beforeColumns, afterColumns)
		So(actual, ShouldBeNil)
		So(err, ShouldBeNil)
	})
}

func Test_commentNotify(t *testing.T) {
	ctx := context.Background()
	afterColumns := map[string]interface{}{
		"comment_id":    "CMT123456",
		"comment_scene": "1",
	}

	PatchConvey("Test commentScene is CommentSceneContractPage", t, func() {
		Mock(contractCommentNotify).Return().Build()
		commentNotify(ctx, afterColumns)
	})
}

func Test_commentPermissions(t *testing.T) {
	ctx := context.Background()
	afterColumns := map[string]interface{}{
		"comment_id":    "CMT123456",
		"comment_scene": "1",
	}

	PatchConvey("Test commentScene is CommentSceneContractPage", t, func() {
		Mock(commentMentionPermissions).Return().Build()
		commentPermissions(ctx, afterColumns)
	})
}

func Test_commentMentionPermissions(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		PatchConvey("", t, func() {
			commentService := comment.NewCommentService()
			// Arrange
			Mock(comment.NewCommentService).Return(commentService).Build()
			Mock(GetMethod(commentService, "AddMentionReviewerByCommentID")).Return(nil).Build()
			Mock(larkc.Warning).Return().Build()

			// Act
			commentMentionPermissions(context.Background(), "")
		})
	})
	t.Run("case AddMentionReviewerByCommentIDFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			warningMsg := ""
			commentService := comment.NewCommentService()
			// Arrange
			Mock(comment.NewCommentService).Return(commentService).Build()
			Mock(GetMethod(commentService, "AddMentionReviewerByCommentID")).Return(fmt.Errorf("AddMentionReviewerByCommentIDFail")).Build()
			Mock(larkc.Warning).To(func(title string, content string, ctxOpt ...context.Context) {
				warningMsg = content
				return
			}).Build()

			// Act
			commentMentionPermissions(context.Background(), "CMT123456")
			So(warningMsg, ShouldEqual, fmt.Sprintf("CommentID: %s, err: %s", "CMT123456", "AddMentionReviewerByCommentIDFail"))
		})
	})
}

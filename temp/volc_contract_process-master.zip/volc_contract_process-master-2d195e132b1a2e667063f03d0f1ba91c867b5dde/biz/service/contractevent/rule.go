package contractevent

const (
	ruleTypeLiteralChange    = "LiteralChange"    // 字面值变更
	ruleTypeFieldFromAToB    = "FieldFromAToB"    // 字面值变更从A到B
	ruleTypeLiteralToSpecify = "LiteralToSpecify" // 字面值变更为指定值
	ruleTypeRecordDelete     = "RecordDelete"     // 记录删除
	ruleTypeRecordInsert     = "RecordInsert"     // 记录删除
)

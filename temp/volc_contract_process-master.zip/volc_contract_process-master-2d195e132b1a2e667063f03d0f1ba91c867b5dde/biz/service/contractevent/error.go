package contractevent

import (
	"errors"
)

var skipRetryError = errors.New("skipRetryError")

func wrapError(e error) error {
	if e == skipRetryError {
		return nil
	}
	return e
}

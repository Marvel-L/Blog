package contractevent

import (
	"context"
	"encoding/json"
	"fmt"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/pkg/proxy/dkmscli"
	"volc_contract_process/pkg/proxy/larkc"

	"volc_contract_process/biz/bizmodels"
)

type metaEventRule struct {
	baseEventRule
}

func (m metaEventRule) TableName() string {
	return tableVolcContractMeta
}

func (m metaEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {

	logs.CtxInfo(ctx, "ContractEvent HandleBinlog begin, table:%s, dmlType:%s", table, dmlType)

	info := &tableFieldInfo{
		PKField:          "id",
		ContractIdField:  "id",
		UpdatedTimeField: "updated_time",
	}

	// 通用配置规则计算
	preEvent, err := m.commonRelateTableProcess(ctx, info, table, dmlType, beforeColumns, afterColumns)
	if err != nil {
		return nil, err
	}
	if preEvent == nil {
		return nil, nil
	}

	// basic info 处理
	details, err := m.calcBasicInfo(ctx, info, table, dmlType, beforeColumns, afterColumns)
	if err != nil {
		return nil, err
	}
	preEvent.EventDetails = append(preEvent.EventDetails, details...)

	// 交易双方信息
	details, err = m.calcTradePartyInfo(ctx, dmlType, beforeColumns, afterColumns)
	if err != nil {
		return nil, err
	}
	preEvent.EventDetails = append(preEvent.EventDetails, details...)

	return preEvent, nil
}

func (m metaEventRule) calcBasicInfo(ctx context.Context, info *tableFieldInfo, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) ([]*eventDetail, error) {

	var beforeValue = map[string]interface{}{}
	var afterValue = map[string]interface{}{}
	beforeStr := interface2string(beforeColumns["basic_info"])
	afterStr := interface2string(afterColumns["basic_info"])
	_ = json.Unmarshal([]byte(beforeStr), &beforeValue)
	_ = json.Unmarshal([]byte(afterStr), &afterValue)

	table = table + "_basic_info"

	id := getInt64ValueFromColumns(afterColumns, info.PKField)
	contractId := getInt64ValueFromColumns(afterColumns, info.ContractIdField)
	beforeValue[info.PKField] = id
	beforeValue[info.ContractIdField] = contractId
	afterValue[info.PKField] = id
	afterValue[info.ContractIdField] = contractId

	preEvent, err := m.commonRelateTableProcess(ctx, info, table, dmlType, beforeValue, afterValue)
	if err != nil {
		return nil, err
	}
	if preEvent == nil {
		return nil, nil
	}

	return preEvent.EventDetails, nil
}

// 计算交易双方信息
func (m metaEventRule) calcTradePartyInfo(ctx context.Context, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) ([]*eventDetail, error) {

	logs.CtxInfo(ctx, "calcTradePartyInfo begin")

	var beforeValue, afterValue bizmodels.TradePartyInfo
	var beforeStr, afterStr string

	encryptBeforeStr := interface2string(beforeColumns["encrypt_trade_party_info"])
	if encryptBeforeStr != "" {
		var err error
		beforeStr, err = dkmscli.DecryptWithContext(ctx, encryptBeforeStr)
		if err != nil {
			logs.CtxError(ctx, "encrypt_trade_party_info: %s, err: %s", encryptBeforeStr, err.Error())
			larkc.Warning("解密encrypt_trade_party_info binlog失败", fmt.Sprintf("encrypt_trade_party_info: %s, err: %s", encryptBeforeStr, err.Error()))
		}
	}

	encryptAfterStr := interface2string(afterColumns["encrypt_trade_party_info"])
	if encryptAfterStr != "" {
		var err error
		afterStr, err = dkmscli.DecryptWithContext(ctx, encryptAfterStr)
		if err != nil {
			logs.CtxError(ctx, "encrypt_trade_party_info: %s, err: %s", encryptAfterStr, err.Error())
			larkc.Warning("解密encrypt_trade_party_info binlog失败", fmt.Sprintf("encrypt_trade_party_info: %s, err: %s", encryptAfterStr, err.Error()))
		}
	}

	_ = json.Unmarshal([]byte(beforeStr), &beforeValue)
	_ = json.Unmarshal([]byte(afterStr), &afterValue)

	var list []*eventDetail

	// 对比我方信息
	detail := m.compareSubject(&beforeValue, &afterValue)
	if detail != nil {
		list = append(list, detail)
	}

	// 对比对方信息
	detail = m.compareOtherSubject(&beforeValue, &afterValue)
	if detail != nil {
		list = append(list, detail)
	}

	return list, nil
}

func (m metaEventRule) compareSubject(before *bizmodels.TradePartyInfo, after *bizmodels.TradePartyInfo) *eventDetail {

	beforeMap := map[string]*bizmodels.TradePartyInfoDetail{}
	for _, v := range before.Subject {
		beforeMap[v.PartyNumber] = v
	}
	afterMap := map[string]*bizmodels.TradePartyInfoDetail{}
	for _, v := range after.Subject {
		afterMap[v.PartyNumber] = v
	}

	if len(beforeMap) != len(afterMap) {
		return &eventDetail{
			Type:   EventTypeChangePartyI,
			Remark: "meta-subject:数量不一致",
		}
	}

	for partyNumber, beforeSubject := range beforeMap {
		afterSubject := afterMap[partyNumber]
		if afterSubject == nil {
			return &eventDetail{
				Type:   EventTypeChangePartyI,
				Remark: fmt.Sprintf("meta-subject:数量不一致[%s]", partyNumber),
			}
		}
		if afterSubject.PartyName != beforeSubject.PartyName {
			return &eventDetail{
				Type:   EventTypeChangePartyI,
				Remark: fmt.Sprintf("meta-我方名称[%s]", partyNumber),
			}
		}
		if afterSubject.SignKeyword != beforeSubject.SignKeyword {
			return &eventDetail{
				Type:   EventTypeChangePartyI,
				Remark: fmt.Sprintf("meta-签约关键字[%s]", partyNumber),
			}
		}
		if len(beforeSubject.PayTypes) != len(afterSubject.PayTypes) {
			return &eventDetail{
				Type:   EventTypeChangePartyI,
				Remark: fmt.Sprintf("meta-PayTypes[%s]", partyNumber),
			}
		}
		for idx, beforePay := range beforeSubject.PayTypes {
			afterPay := afterSubject.PayTypes[idx]
			if afterPay.AccountNumber != beforePay.AccountNumber {
				return &eventDetail{
					Type:   EventTypeChangePartyI,
					Remark: fmt.Sprintf("meta-Pay_银行账号[%s]", partyNumber),
				}
			}
			if afterPay.BranchName != beforePay.BranchName {
				return &eventDetail{
					Type:   EventTypeChangePartyI,
					Remark: fmt.Sprintf("meta-Pay_开户行名称[%s]", partyNumber),
				}
			}
		}

	}

	return nil
}

func (m metaEventRule) compareOtherSubject(before *bizmodels.TradePartyInfo, after *bizmodels.TradePartyInfo) *eventDetail {

	beforeMap := map[string]*bizmodels.TradePartyInfoDetail{}
	for _, v := range before.OtherParty {
		beforeMap[v.PartyNumber] = v
	}
	afterMap := map[string]*bizmodels.TradePartyInfoDetail{}
	for _, v := range after.OtherParty {
		afterMap[v.PartyNumber] = v
	}

	if len(beforeMap) != len(afterMap) {
		return &eventDetail{
			Type:   EventTypeChangePartyO,
			Remark: "meta-对方数量不一致",
		}
	}

	for partyNumber, beforeSubject := range beforeMap {
		afterSubject := afterMap[partyNumber]
		if afterSubject == nil {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方数量不一致[%s]", partyNumber),
			}
		}
		if afterSubject.PartyName != beforeSubject.PartyName {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方名称[%s]", partyNumber),
			}
		}
		if afterSubject.SignKeyword != beforeSubject.SignKeyword {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方签约关键字[%s]", partyNumber),
			}
		}
		if afterSubject.AccountID != beforeSubject.AccountID {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方账号ID[%s]", partyNumber),
			}
		}
		if afterSubject.Country != beforeSubject.Country {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方国家[%s]", partyNumber),
			}
		}
		if len(beforeSubject.PayTypes) != len(afterSubject.PayTypes) {
			return &eventDetail{
				Type:   EventTypeChangePartyO,
				Remark: fmt.Sprintf("meta-对方PayTypes[%s]", partyNumber),
			}
		}
		for idx, beforePay := range beforeSubject.PayTypes {
			afterPay := afterSubject.PayTypes[idx]
			if afterPay.AccountNumber != beforePay.AccountNumber {
				return &eventDetail{
					Type:   EventTypeChangePartyO,
					Remark: fmt.Sprintf("对方Pay_银行账号[%s]", partyNumber),
				}
			}
			if afterPay.BranchName != beforePay.BranchName {
				return &eventDetail{
					Type:   EventTypeChangePartyO,
					Remark: fmt.Sprintf("对方Pay_开户行名称[%s]", partyNumber),
				}
			}
			if afterPay.PayType != beforePay.PayType {
				return &eventDetail{
					Type:   EventTypeChangePartyO,
					Remark: fmt.Sprintf("对方Pay_支付类型[%s]", partyNumber),
				}
			}
			if afterPay.ClctName != beforePay.ClctName {
				return &eventDetail{
					Type:   EventTypeChangePartyO,
					Remark: fmt.Sprintf("对方Pay_账户名称[%s]", partyNumber),
				}
			}
		}

	}

	return nil
}

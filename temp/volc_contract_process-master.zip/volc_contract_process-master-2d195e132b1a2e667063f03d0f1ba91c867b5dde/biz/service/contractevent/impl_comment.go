package contractevent

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/comment"
	"volc_contract_process/biz/service/notify"
	"volc_contract_process/pkg/proxy/larkc"
)

type commentEventRule struct {
	baseEventRule
}

func (m commentEventRule) TableName() string {
	return tableComment
}

func (m commentEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {
	// 是否关闭评论事件处理
	if _disableCommentEvent {
		return nil, nil
	}
	// 目前只关注insert事件
	if dmlType == DMLTypeInsert {
		commentNotify(ctx, afterColumns)
		commentPermissions(ctx, afterColumns)
	}

	return nil, nil
}

func commentPermissions(ctx context.Context, afterColumns map[string]interface{}) {
	commentID := getStringValueFromColumns(afterColumns, "comment_id")
	commentScene := getInt64ValueFromColumns(afterColumns, "comment_scene")

	switch commentScene {
	case comment.CommentSceneContractPage:
		commentMentionPermissions(ctx, commentID)
	}
}

func commentMentionPermissions(ctx context.Context, commentID string) {
	if err := comment.NewCommentService().AddMentionReviewerByCommentID(ctx, commentID); err != nil {
		logs.CtxError(ctx, "AddMentionReviewerByCommentIDFail, err:%s", err.Error())
		larkc.Warning("评论提及人权限处理失败", fmt.Sprintf("CommentID: %s, err: %s", commentID, err.Error()))
	}
}

func commentNotify(ctx context.Context, afterColumns map[string]interface{}) {

	commentID := getStringValueFromColumns(afterColumns, "comment_id")
	commentScene := getInt64ValueFromColumns(afterColumns, "comment_scene")

	switch commentScene {
	case comment.CommentSceneContractPage:
		contractCommentNotify(ctx, commentID)
	}

}

func contractCommentNotify(ctx context.Context, commentID string) {
	notifyCtx := &notify.MsgContext{
		ExtInfo: notify.MsgContextContractCommentNotify{
			CommentID: commentID,
		},
	}

	notify.SendMsgV2(ctx, notify.MsgEventContractCommentNotify, notifyCtx)
}

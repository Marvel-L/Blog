package contractevent

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
)

func Test_checkRule(t *testing.T) {
	t.Run("case 执行成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()
			mockey.Mock(checkLiteralChangeRule).Return(true, "checkLiteralChangeRule").Build()
			mockey.Mock(checkFieldFromAToBRule).Return(true, "checkFieldFromAToBRule").Build()
			mockey.Mock(checkFieldLiteralToSpecify).Return(true, "checkFieldLiteralToSpecify").Build()
			mockey.Mock(checkRecordDeleteRule).Return(true, "checkRecordDeleteRule").Build()
			mockey.Mock(checkRecordInsertRule).Return(true, "checkRecordInsertRule").Build()

			// Act
			res, err := checkRule(context.Background(), &conf.RuleInfo{
				MatchResultType: "ceshi",
				Details: []*conf.RuleDetail{
					{RuleType: ruleTypeLiteralChange},
					{RuleType: ruleTypeFieldFromAToB},
					{RuleType: ruleTypeLiteralToSpecify},
					{RuleType: ruleTypeRecordDelete},
					{RuleType: ruleTypeRecordInsert},
				},
			}, 0, tableVolcContractMeta, "", map[string]interface{}{"": nil}, map[string]interface{}{"": nil})
			// Assert
			convey.So(res.Remark, convey.ShouldEqual, "0:meta[c]-checkLiteralChangeRule;metafrom_to-checkFieldFromAToBRule;meta[LTS]-checkFieldLiteralToSpecify;metadel-0;metaInsert-0;")
			convey.So(res.Type, convey.ShouldEqual, "ceshi")
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_checkFieldFromAToBRuleV2(t *testing.T) {
	t.Run("case 补充协议，命中规则，协商状态终态，已拒绝", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "cooperation_status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"14", "19", "20"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "14",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
			convey.So(str, convey.ShouldEqual, "[supply_scene=1]->cooperation_status:13=>14")
		})
	})
	t.Run("case 补充协议，命中规则，协商状态终态，已终止", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "cooperation_status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"14", "19", "20"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "19",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
			convey.So(str, convey.ShouldEqual, "[supply_scene=1]->cooperation_status:13=>19")
		})
	})
	t.Run("case 补充协议，命中规则，协商状态终态，已作废", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "cooperation_status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"14", "19", "20"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "20",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
			convey.So(str, convey.ShouldEqual, "[supply_scene=1]->cooperation_status:13=>20")
		})
	})
	t.Run("case 补充协议，命中规则，合同状态终态，已取消", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"9"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
				"status":             8,
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "20",
				"status":             "9",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
			convey.So(str, convey.ShouldEqual, "[supply_scene=1]->status:8=>9")
		})
	})

	t.Run("case 补充协议，未命中规则，筛选条件未通过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"9"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "0",
				"cooperation_status": "13",
				"status":             8,
			}, map[string]interface{}{
				"supply_scene":       "0",
				"cooperation_status": "20",
				"status":             "9",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
	t.Run("case 补充协议，未命中规则，合同协商状态未通过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "cooperation_status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"14", "19", "20"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
				"status":             8,
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "15",
				"status":             "9",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
	t.Run("case 补充协议，未命中规则，合同状态未通过", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"9"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
				"status":             0,
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "20",
				"status":             "8",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
	t.Run("case 补充协议，未命中规则，合同协商状态未变更", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "cooperation_status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"14", "19", "20"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "8",
				"status":             8,
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "8",
				"status":             "9",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
	t.Run("case 补充协议，未命中规则，合同状态未变更", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{
					{
						FieldName: "supply_scene",
						Value:     []string{"1"},
					},
				},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{{
					FieldName:        "status",
					FieldBeforeValue: []string{""},
					FieldAfterValue:  []string{"9"},
				}},
			}, "", map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "13",
				"status":             "8",
			}, map[string]interface{}{
				"supply_scene":       "1",
				"cooperation_status": "20",
				"status":             "8",
			})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
}

func Test_checkRecordInsertRule(t *testing.T) {
	t.Run("case 命中规则", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkRecordInsertRule(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"1"},
				}},
			}, DMLTypeInsert, map[string]interface{}{"": nil}, map[string]interface{}{"supply_scene": "1"})

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
			convey.So(str, convey.ShouldEqual, "[supply_scene=1]->insert")
		})
	})
	t.Run("case 未命中规则", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			flag, str := checkRecordInsertRule(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"1"},
				}},
			}, DMLTypeInsert, map[string]interface{}{"": nil}, map[string]interface{}{"supply_scene": " 0"})

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
			convey.So(str, convey.ShouldEqual, "")
		})
	})
}

func Test_checkFieldLiteralToSpecify(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit, msg := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"30"},
				}},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{&conf.EventRuleFieldChange{
					FieldName: "status",
					IgnoreFields: &conf.FieldValue{
						FieldBeforeValue: []string{"1"},
						FieldAfterValue:  []string{"2"},
					},
					FieldAfterValue: []string{"3"},
				}},
			}, "update", map[string]interface{}{"supply_scene": "30", "status": "0"},
				map[string]interface{}{"supply_scene": "30", "status": "3"})

			// Assert
			convey.So(hit, convey.ShouldEqual, true)
			convey.So(msg, convey.ShouldEqual, "[supply_scene=30]->status:0=>3")
		})
	})
	t.Run("case 变更前数值命中屏蔽值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit, msg := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"30"},
				}},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{&conf.EventRuleFieldChange{
					FieldName: "status",
					IgnoreFields: &conf.FieldValue{
						FieldBeforeValue: []string{"1"},
						FieldAfterValue:  []string{"2"},
					},
					FieldAfterValue: []string{"3"},
				}},
			}, "update", map[string]interface{}{"supply_scene": "30", "status": "1"},
				map[string]interface{}{"supply_scene": "30", "status": "3"})

			// Assert
			convey.So(hit, convey.ShouldEqual, false)
			convey.So(msg, convey.ShouldEqual, "")
		})
	})
	t.Run("case 变更后数值命中屏蔽值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit, msg := checkFieldLiteralToSpecify(context.Background(), &conf.RuleDetail{
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"30"},
				}},
				EventRuleFieldChangeList: []*conf.EventRuleFieldChange{&conf.EventRuleFieldChange{
					FieldName: "status",
					IgnoreFields: &conf.FieldValue{
						FieldBeforeValue: []string{"1"},
						FieldAfterValue:  []string{"2"},
					},
					FieldAfterValue: []string{"3"},
				}},
			}, "update", map[string]interface{}{"supply_scene": "30", "status": "0"},
				map[string]interface{}{"supply_scene": "30", "status": "2"})

			// Assert
			convey.So(hit, convey.ShouldEqual, false)
			convey.So(msg, convey.ShouldEqual, "")
		})
	})
}

func Test_checkLiteralChangeRule(t *testing.T) {
	t.Run("case NoIgnoreFields success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit, msg := checkLiteralChangeRule(context.Background(), &conf.RuleDetail{
				Fields:       []string{"status"},
				IgnoreFields: []string{},
				IgnoreFieldValues: map[string]*conf.FieldValue{"status": {
					FieldBeforeValue: []string{"1"},
					FieldAfterValue:  []string{"2"},
				}},
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"30"},
				}},
			}, "update", map[string]interface{}{"supply_scene": "30", "status": "0"},
				map[string]interface{}{"supply_scene": "30", "status": "1"})

			// Assert
			convey.So(hit, convey.ShouldEqual, true)
			convey.So(msg, convey.ShouldEqual, "[supply_scene=30]->status")
		})
	})
	t.Run("case IgnoreFields success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit, msg := checkLiteralChangeRule(context.Background(), &conf.RuleDetail{
				Fields:       []string{"status"},
				IgnoreFields: []string{"cooperation_status"},
				IgnoreFieldValues: map[string]*conf.FieldValue{"status": {
					FieldBeforeValue: []string{"1"},
					FieldAfterValue:  []string{"2"},
				}},
				EventRuleFieldFilter: []*conf.EventRuleFieldFilter{&conf.EventRuleFieldFilter{
					FieldName: "supply_scene",
					Value:     []string{"30"},
				}},
			}, "update", map[string]interface{}{"supply_scene": "30", "status": "0"},
				map[string]interface{}{"supply_scene": "30", "status": "1"})

			// Assert
			convey.So(hit, convey.ShouldEqual, true)
			convey.So(msg, convey.ShouldEqual, "[supply_scene=30]->status")
		})
	})
}

func Test_isDiffFieldValue(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit := isDiffFieldValue("status", &conf.FieldValue{
				FieldBeforeValue: []string{"1"},
				FieldAfterValue:  []string{"2"},
			}, map[string]interface{}{"status": "0"}, map[string]interface{}{"status": "3"})

			// Assert
			convey.So(hit, convey.ShouldEqual, true)
		})
	})
	t.Run("case 变更前数值命中屏蔽值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit := isDiffFieldValue("status", &conf.FieldValue{
				FieldBeforeValue: []string{"1"},
				FieldAfterValue:  []string{"2"},
			}, map[string]interface{}{"status": "1"}, map[string]interface{}{"status": "3"})

			// Assert
			convey.So(hit, convey.ShouldEqual, false)
		})
	})
	t.Run("case 变更后数值命中屏蔽值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			hit := isDiffFieldValue("status", &conf.FieldValue{
				FieldBeforeValue: []string{"1"},
				FieldAfterValue:  []string{"2"},
			}, map[string]interface{}{"status": "0"}, map[string]interface{}{"status": "2"})

			// Assert
			convey.So(hit, convey.ShouldEqual, false)
		})
	})
}

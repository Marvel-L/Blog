package contractevent

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
)

type preContractReviewerEventRule struct {
	baseEventRule
}

func (r *preContractReviewerEventRule) TableName() string {
	return tablePreContractReviewer
}

func (r *preContractReviewerEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {
	if dmlType != DMLTypeInsert && dmlType != DMLTypeUpdate && dmlType != DMLTypeDelete {
		logs.CtxInfo(ctx, "PreContractReviewerEventIgnore_unsupported_dml_type, dmlType=%s", dmlType)
		return nil, nil
	}

	contractNo := getPreContractReviewerContractNo(afterColumns, beforeColumns)
	if contractNo == "" {
		logs.CtxWarn(ctx, "PreContractReviewerEventIgnore_contractNo_empty, dmlType=%s", dmlType)
		return nil, nil
	}

	metaDB, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		logs.CtxError(ctx, "PreContractReviewerEvent_FindLastByNoFail, contractNo=%s, err=%s", contractNo, err.Error())
		return nil, err
	}
	if metaDB == nil {
		logs.CtxWarn(ctx, "PreContractReviewerEvent_ContractNotExist, contractNo=%s", contractNo)
		return nil, nil
	}

	info := &tableFieldInfo{
		PKField:          "id",
		ContractIdField:  "contract_id",
		UpdatedTimeField: "updated_time",
	}
	afterColumnsWithContractID := copyPreContractReviewerColumns(afterColumns)
	if len(afterColumnsWithContractID) == 0 {
		afterColumnsWithContractID = copyPreContractReviewerColumns(beforeColumns)
	}
	afterColumnsWithContractID["contract_id"] = metaDB.Id

	return r.commonRelateTableProcess(ctx, info, table, dmlType, beforeColumns, afterColumnsWithContractID)
}

func getPreContractReviewerContractNo(afterColumns map[string]interface{}, beforeColumns map[string]interface{}) string {
	contractNo := getStringValueFromColumns(afterColumns, "pre_contract_no")
	if contractNo != "" {
		return contractNo
	}
	return getStringValueFromColumns(beforeColumns, "pre_contract_no")
}

func copyPreContractReviewerColumns(columns map[string]interface{}) map[string]interface{} {
	ret := make(map[string]interface{}, len(columns)+1)
	for k, v := range columns {
		ret[k] = v
	}
	return ret
}

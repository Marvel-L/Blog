package contractevent

import (
	"bytes"
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
	"volc_contract_process/pkg/util"
)

func checkRules(ctx context.Context, rules []*conf.RuleInfo, id int64, table string, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) ([]*eventDetail, error) {

	var details []*eventDetail
	for _, rule := range rules {
		detail, err := checkRule(ctx, rule, id, table, dmlType, beforeColumns, afterColumns)
		if err != nil {
			// 仅打印日志
			logs.CtxError(ctx, "checkRuleFail_Ignore, err=%s", err.Error())
		}
		if detail != nil {
			details = append(details, detail)
		}
	}

	return details, nil
}

func checkRule(ctx context.Context, rule *conf.RuleInfo, id int64, table string, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*eventDetail, error) {

	var hasOneHit bool
	var buf bytes.Buffer
	buf.WriteString(i18nfmt.Sprintf(ctx, "%d:", id))
	for _, ruleDetail := range rule.Details {
		switch ruleDetail.RuleType {
		case ruleTypeLiteralChange:
			hit, msg := checkLiteralChangeRule(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
			if hit {
				hasOneHit = true
				buf.WriteString(i18nfmt.Sprintf(ctx, "%s[c]-%s;", tableNameMappings[table], msg))
			}
		case ruleTypeFieldFromAToB:
			hit, msg := checkFieldFromAToBRule(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
			if hit {
				hasOneHit = true
				buf.WriteString(i18nfmt.Sprintf(ctx, "%sfrom_to-%s;", tableNameMappings[table], msg))
			}
		case ruleTypeLiteralToSpecify:
			hit, msg := checkFieldLiteralToSpecify(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
			if hit {
				hasOneHit = true
				buf.WriteString(i18nfmt.Sprintf(ctx, "%s[LTS]-%s;", tableNameMappings[table], msg))
			}
		case ruleTypeRecordDelete:
			hit, _ := checkRecordDeleteRule(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
			if hit {
				hasOneHit = true
				buf.WriteString(i18nfmt.Sprintf(ctx, "%sdel-%d;", tableNameMappings[table], id))
			}
		case ruleTypeRecordInsert:
			hit, _ := checkRecordInsertRule(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
			if hit {
				hasOneHit = true
				buf.WriteString(i18nfmt.Sprintf(ctx, "%sInsert-%d;", tableNameMappings[table], id))
			}
		default:
			logs.CtxInfo(ctx, "checkRule_unsupportedRuleType => %s", ruleDetail.RuleType)
		}
		// 此处暂不判断hasOneHit=true跳出，尽量多收集命中规则的信息
	}

	if hasOneHit {
		return &eventDetail{
			Type:   rule.MatchResultType,
			Remark: buf.String(),
		}, nil
	}

	return nil, nil
}

func checkFieldFromAToBRule(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {

	flag, filterStr := checkFileFilter(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
	if !flag {
		logs.CtxInfo(ctx, "checkFileFilter_ignora")
		return false, ""
	}

	cfg := ruleDetail.EventRuleFieldChange
	if cfg == nil {
		logs.CtxError(ctx, "checkLiteralChangeRule_FieldChange_is_nil")
		return false, ""
	}

	beforeValue := interface2string(beforeColumns[cfg.FieldName])
	afterValue := interface2string(afterColumns[cfg.FieldName])

	logs.CtxInfo(ctx, "checkFieldFromAToBRule, name=%s, before=%s, after=%s", cfg.FieldName, beforeValue, afterValue)

	if util.StringIn(beforeValue, cfg.FieldBeforeValue) && util.StringIn(afterValue, cfg.FieldAfterValue) {
		return true, fmt.Sprintf("[%s]->[%s=>%s]", filterStr, beforeValue, afterValue)
	}

	return false, ""
}

// checkFieldLiteralToSpecify 字面值变更为指定值
// 更新前与更新后数值不一致 且 更新后数值再配置范围内
func checkFieldLiteralToSpecify(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {

	flag, filterStr := checkFileFilter(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
	if !flag {
		logs.CtxInfo(ctx, "checkFileFilter_ignora")
		return false, ""
	}

	cfgs := ruleDetail.EventRuleFieldChangeList
	if cfgs == nil {
		logs.CtxError(ctx, "checkFieldLiteralToSpecify_FieldChange_is_nil")
		return false, ""
	}
	var msg []string
	for _, cfg := range cfgs {
		beforeValue := interface2string(beforeColumns[cfg.FieldName])
		afterValue := interface2string(afterColumns[cfg.FieldName])
		// 处理参数屏蔽列表
		if cfg.IgnoreFields.IsIgnoreField(beforeValue, afterValue) {
			logs.CtxInfo(ctx, "checkFieldLiteralToSpecify_IgnoreField_is_ignore, name=%s, before=%s, after=%s", cfg.FieldName, beforeValue, afterValue)
			continue
		}
		logs.CtxInfo(ctx, "checkFieldLiteralToSpecifyRule, name=%s, before=%s, after=%s", cfg.FieldName, beforeValue, afterValue)
		// 更新前与更新后数值不一致 且 更新后数值再配置范围内
		if beforeValue != afterValue && util.StringIn(afterValue, cfg.FieldAfterValue) {
			msg = append(msg, fmt.Sprintf("%s:%s=>%s", cfg.FieldName, beforeValue, afterValue))
		}
	}

	if len(msg) == 0 {
		return false, ""
	}

	return true, fmt.Sprintf("[%s]->%s", filterStr, strings.Join(msg, "&"))
}

func checkLiteralChangeRule(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {

	flag, filterStr := checkFileFilter(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
	if !flag {
		logs.CtxInfo(ctx, "checkFileFilter_ignora")
		return false, ""
	}

	if len(ruleDetail.IgnoreFields) > 0 {
		for _, v := range ruleDetail.Fields {
			if !util.StringIn(v, ruleDetail.IgnoreFields) && isDiffFieldValue(v, ruleDetail.IgnoreFieldValues[v], beforeColumns, afterColumns) {
				return true, fmt.Sprintf("[%s]->%s", filterStr, v)
			}
		}
	} else {
		for _, v := range ruleDetail.Fields {
			if isDiffFieldValue(v, ruleDetail.IgnoreFieldValues[v], beforeColumns, afterColumns) {
				return true, fmt.Sprintf("[%s]->%s", filterStr, v)
			}
		}
	}

	return false, ""
}

func checkRecordDeleteRule(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {

	flag, filterStr := checkFileFilter(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
	if !flag {
		logs.CtxInfo(ctx, "checkFileFilter_ignora")
		return false, ""
	}

	if dmlType == DMLTypeDelete {
		return true, fmt.Sprintf("[%s]->del", filterStr)
	}

	return false, ""
}

func checkRecordInsertRule(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {

	flag, filterStr := checkFileFilter(ctx, ruleDetail, dmlType, beforeColumns, afterColumns)
	if !flag {
		logs.CtxInfo(ctx, "checkFileFilter_ignora")
		return false, ""
	}

	if dmlType != DMLTypeInsert {
		return false, ""
	}

	return true, fmt.Sprintf("[%s]->insert", filterStr)
}

// checkFileFilter 检查是否满足过滤条件，不满足则不处理
func checkFileFilter(ctx context.Context, ruleDetail *conf.RuleDetail, dmlType string,
	beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (bool, string) {
	// 未配置时，默认按全部合同处理，不进行过滤
	cfg := ruleDetail.EventRuleFieldFilter
	if cfg == nil {
		logs.CtxWarn(ctx, "checkRecordInsertRule_RecordInsert_is_nil")
		return true, ""
	}

	var msgs []string
	// 每组条件列表为或关系，多组为且关系
	for _, record := range cfg {
		afterValue := interface2string(afterColumns[record.FieldName])
		// 字段等于指定值 计算此类合同
		if util.StringIn(afterValue, record.Value) {
			msgs = append(msgs, fmt.Sprintf("%s=%s", record.FieldName, afterValue))
		}
		// 字段包含指定值时 计算此类合同
		for _, subStr := range record.SubValue {
			if strings.Contains(afterValue, subStr) {
				msgs = append(msgs, fmt.Sprintf("%s(%s)", record.FieldName, afterValue))
			}
		}
	}
	if len(msgs) > 0 {
		return true, strings.Join(msgs, "&")
	}
	return false, ""
}

func isDiffFieldValue(field string, ignoreFieldValues *conf.FieldValue, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) bool {
	beforeCol := beforeColumns[field]
	afterCol := afterColumns[field]

	beforeVal := interface2string(beforeCol)
	afterVal := interface2string(afterCol)
	// 处理参数屏蔽列表
	if ignoreFieldValues.IsIgnoreField(beforeVal, afterVal) {
		return false
	}
	return beforeVal != afterVal
}

func getInt64ValueFromColumns(columns map[string]interface{}, filed string) int64 {
	value := columns[filed]
	if value == nil {
		return 0
	}
	v := interface2string(value)
	ret, _ := strconv.ParseInt(v, 10, 64)
	return ret
}

func getTimeValueFromColumns(columns map[string]interface{}, filed string) time.Time {
	value := columns[filed]
	if value == nil {
		return time.Time{}
	}
	v := interface2string(value)
	ret, _ := time.ParseInLocation(util.DBDateFormatTpl, v, multienv.GetBinlogTimeZone())

	return ret
}

func getStringValueFromColumns(columns map[string]interface{}, filed string) string {
	value := columns[filed]

	v := interface2string(value)

	return v
}

func interface2string(v interface{}) string {
	if v == nil {
		return ""
	}
	return fmt.Sprintf("%+v", v)
}

package contractevent

import (
	"bytes"
	"fmt"
)

type Event struct {
	ContractId     int64    `json:"ContractId"`     // 合同主键
	BizScene       int      `json:"BizScene"`       // 业务场景 1 销售合同&在线协同 2 订单合同 3 产品报价合同 4 信控合同 6 伙伴合同
	Initiator      int      `json:"Initiator"`      // 发起端，8-自采平台
	ContractNo     string   `json:"ContractNo"`     // 合同号
	Version        int      `json:"Version"`        // 合同版本
	EventTypes     []string `json:"EventTypes"`     // 事件类型
	EventTimestamp int64    `json:"EventTimestamp"` // 事件发生时间，秒
	Archived       bool     `json:"Archived"`       // 是否已归档
}

type preEvent struct {
	ContractId      int64          `json:"ContractId"`        // 合同主键
	BizScene        int            `json:"BizScene"`          // 业务场景 1 销售合同&在线协同 2 订单合同 3 产品报价合同 4 信控合同 6 伙伴合同
	ContractNo      string         `json:"ContractNo"`        // 合同号
	Version         int            `json:"Version"`           // 合同版本
	EventTimestamp  int64          `json:"EventTimestamp"`    // 事件发生时间，秒
	Archived        bool           `json:"Archived"`          // 是否已归档
	EventDetails    []*eventDetail `json:"event_details"`     // 事件明细
	EventTimeWindow int64          `json:"event_time_window"` // 事件发生时间窗口
	IsTest          bool           `json:"is_test"`           // 测试标记
}

func (p *preEvent) getTypes() []string {
	var list []string
	for _, v := range p.EventDetails {
		list = append(list, v.Type)
	}
	return list
}

func (p *preEvent) summaryRemarks() string {
	var buf bytes.Buffer
	for _, v := range p.EventDetails {
		buf.WriteString(v.Remark)
		buf.WriteString(";")
	}
	return buf.String()
}

func (p *preEvent) buildStashKey() string {
	return fmt.Sprintf("contract:event:%d:%d", p.ContractId, p.EventTimeWindow)
}

type eventDetail struct {
	Type   string
	Remark string
}

type deferPreEventInfo struct {
	StashKey        string `json:"StashKey"`
	ContractId      int64  `json:"ContractId"`
	EventTimestamp  int64  `json:"EventTimestamp"`    // 事件发生时间，秒
	EventTimeWindow int64  `json:"event_time_window"` // 事件发生时间窗口
	IsTest          bool   `json:"is_test"`           //
}

type tableFieldInfo struct {
	PKField          string
	ContractIdField  string
	UpdatedTimeField string
}

package contractevent

import (
	"bytes"
	"context"
	"encoding/json"
	"math/rand"
	"sort"
	"strconv"
	"strings"
	"time"

	"code.byted.org/gopkg/dbus"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	mqProducer "volc_contract_process/biz/service/mpproducer"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/recovery"
	"volc_contract_process/pkg/util"
)

type tableEventRule interface {
	TableName() string
	Process(ctx context.Context, table string, dmlType string,
		beforeValues map[string]interface{},
		afterValues map[string]interface{}) (*preEvent, error)
}

type eventRuleChain struct {
	rules map[string]tableEventRule
}

func (c *eventRuleChain) Handle(ctx context.Context, tableName, dmlType string, beforeColumns map[string]dbus.MysqlIncrementColumn, afterColumns map[string]dbus.MysqlIncrementColumn) error {
	defer recovery.DefaultRecovery(ctx, "eventRuleChain_handle")()
	beforeValues := c.binlogColumns2Map(beforeColumns)
	afterValues := c.binlogColumns2Map(afterColumns)
	c.printLog(ctx, tableName, dmlType, beforeValues, afterValues, false)
	return c.DoHandle(ctx, tableName, dmlType, beforeValues, afterValues, false)
}

func (c *eventRuleChain) printLog(ctx context.Context, tableName, dmlType string, beforeValues map[string]interface{}, afterValues map[string]interface{}, isTest bool) {
	globalConf := conf.GetGlobalConf(ctx)
	if globalConf == nil || globalConf.ContractEventConf == nil {
		return
	}
	if !globalConf.ContractEventConf.OpenLog {
		logs.CtxInfo(ctx, "eventRuleChain_printLog_Ignore")
		return
	}
	params := map[string]interface{}{
		"tableName":    tableName,
		"dmlType":      dmlType,
		"beforeValues": beforeValues,
		"afterValues":  afterValues,
	}
	body, _ := json.Marshal(params)
	logs.CtxInfo(ctx, "eventRuleChain_printLog_body => %s", string(body))
}

// DoHandle 用于模拟调用
func (c *eventRuleChain) DoHandle(ctx context.Context, tableName, dmlType string, beforeValues map[string]interface{}, afterValues map[string]interface{}, isTest bool) error {

	rule := c.rules[tableName]
	if rule == nil {
		logs.CtxInfo(ctx, "Handle unsupported table => %s", tableName)
		return nil
	}

	logs.CtxInfo(ctx, "Handle current table => %s", tableName)

	// 计算预处理事件
	preEvent, err := rule.Process(ctx, tableName, dmlType, beforeValues, afterValues)
	if err != nil {
		logs.CtxInfo(ctx, "EventRuleChainHandleFail, table=%s, err=%s", rule.TableName(), err.Error())
		return wrapError(err)
	}
	if preEvent == nil || len(preEvent.EventDetails) == 0 {
		// 未触发变更事件
		logs.CtxInfo(ctx, "EventRuleChainHandleFinish no event")
		return nil
	}

	if preEvent.EventTimestamp == 0 {
		// 仅打印错误日志，添加报警监控
		logs.CtxError(ctx, "eventRuleProcess_EventTimestamp_is_zero")
	}

	// 时间窗口 preEvent.EventTimestamp由EventRule根据UpdatedTime计算得出
	preEvent.EventTimeWindow = preEvent.EventTimestamp / _defTimeWindow
	preEvent.IsTest = isTest

	logs.CtxInfo(ctx, "ProcessResult, contractId=%d, contractNo=%s, eventTypes=%v, archived=%v, timeWindow=%d", preEvent.ContractId, preEvent.ContractNo, preEvent.getTypes(), preEvent.Archived, preEvent.EventTimeWindow)

	// 保存合同事件临时记录到DB 此处不考虑后续操作失败的场景，如果后续失败，不回滚，DB记录可作为异常数据补偿
	if err = c.saveContractEventToDB(ctx, preEvent); err != nil {
		logs.CtxError(ctx, "EventRuleChainHandle_saveContractEventToDBFail, err=%s", err.Error())
		return wrapError(err)
	}

	// 保存REDIS记录
	if err = c.saveContractEventToRedis(ctx, preEvent); err != nil {
		logs.CtxError(ctx, "EventRuleChainHandle_saveContractEventToRedisFail, err=%s", err.Error())
		return wrapError(err)
	}

	// 发送延时处理消息
	if err = c.sendDeferMsg(ctx, preEvent); err != nil {
		logs.CtxError(ctx, "EventRuleChainHandle_sendDeferMsgFail, err=%s", err.Error())
		return wrapError(err)
	}

	return nil
}

func (c *eventRuleChain) binlogColumns2Map(columns map[string]dbus.MysqlIncrementColumn) map[string]interface{} {
	values := map[string]interface{}{}
	for k, v := range columns {
		values[k] = v.GetStringValue()
	}
	return values
}

func (c *eventRuleChain) saveContractEventToDB(ctx context.Context, event *preEvent) error {

	lock := rediscli.RedisLock{
		LockKey: i18nfmt.Sprintf(ctx, "%s:saveDB", event.buildStashKey()),
		Value:   logid.GenLogID() + "_" + strconv.Itoa(rand.Int()),
		Timeout: time.Second * (_defTimeWindow * 2),
	}

	var needUnlock bool
	defer func() {
		if needUnlock {
			logs.CtxInfo(ctx, "准备释放Lock，key=%s", lock.LockKey)
			lock.Unlock()
		}
	}()

	if err := lock.Lock(); err != nil {
		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
		if err == rediscli.ErrLockObtainFail {
			return nil
		}
		return err
	}

	// 此时仅为临时存储 记录唯一标识即可
	eventDB := &model.ContractEventDB{
		StashKey:        event.buildStashKey(),
		ContractID:      event.ContractId,
		ContractNo:      event.ContractNo,
		Version:         event.Version,
		BizScene:        event.BizScene,
		EventTimeWindow: event.EventTimeWindow,
		EventTimestamp:  time.Unix(event.EventTimestamp, 0),
		BaseDB: model.BaseDB{
			Status:      _statusDraft,
			CreatedTime: time.Now(),
			UpdatedTime: time.Now(),
		},
	}

	eventDao := dal.NewContractEventDao()
	err := dal.GetDB(ctx).Transaction(func(tx *gorm.DB) error {

		entity, err := eventDao.FindByStashKey(ctx, tx, eventDB.StashKey)
		if err != nil {
			return err
		}

		if entity != nil {
			// 同一个时间窗口内，仅保留一条记录
			if entity.Status != _statusDraft {
				logs.CtxError(ctx, "saveContractEventToDB_has_unexpected_record, key=%s, contractNo=%s, status=%d", eventDB.StashKey, eventDB.ContractNo, entity.Status)
			}
			return nil
		}

		err = eventDao.Create(ctx, tx, eventDB)
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		needUnlock = true
	}

	return err
}

func (c *eventRuleChain) saveContractEventToRedis(ctx context.Context, event *preEvent) error {
	// 注意正确设置超时时间
	body, _ := json.Marshal(event)

	key := event.buildStashKey()
	expiredTime := c.calcStashKeyExpiredTime(ctx)

	totalCnt, err := rediscli.LPushWithTimeOut(ctx, key, string(body), expiredTime)
	if err != nil {
		logs.CtxError(ctx, "LPushWithTimeOutFail, key=%s, err=%s", key, err.Error())
		return err
	}

	if totalCnt >= 500 {
		// 用于监控, List过多时可能会导致查询异常
		logs.CtxWarn(ctx, "LPushWithTimeOutOverLimit500, key=%s, cnt=%d", key, totalCnt)
	}

	return nil
}

func (c *eventRuleChain) calcStashKeyExpiredTime(ctx context.Context) time.Duration {
	cfg := conf.GetGlobalConf(ctx)
	if cfg == nil || cfg.ContractEventConf == nil {
		return _defExpiredTime
	}
	// 至少保留一天
	seconds := time.Duration(cfg.ContractEventConf.StashExpiredTime) * time.Second
	if seconds > _defExpiredTime {
		return seconds
	}
	return _defExpiredTime
}

// 发送延迟消息：同一个stashKey维度，只发送一次 待review
func (c *eventRuleChain) sendDeferMsg(ctx context.Context, event *preEvent) error {

	lock := rediscli.RedisLock{
		LockKey: i18nfmt.Sprintf(ctx, "%s:sendcount", event.buildStashKey()),
		Value:   logid.GenLogID() + "_" + strconv.Itoa(rand.Int()),
		Timeout: time.Second * (_defTimeWindow * 2),
	}

	var needUnlock bool
	defer func() {
		if needUnlock {
			logs.CtxInfo(ctx, "准备释放Lock，key=%s", lock.LockKey)
			lock.Unlock()
		}
	}()

	if err := lock.Lock(); err != nil {
		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
		if err == rediscli.ErrLockObtainFail {
			return nil
		}
		return err
	}

	info := deferPreEventInfo{
		StashKey:        event.buildStashKey(),
		ContractId:      event.ContractId,
		EventTimestamp:  event.EventTimestamp,
		EventTimeWindow: event.EventTimeWindow,
		IsTest:          event.IsTest,
	}
	msgBody, _ := json.Marshal(info)
	logs.CtxInfo(ctx, "prepareSendSummaryMsg, body=%s", string(msgBody))

	// 发送消息 预期在当前时间窗口结束后执行
	err := mqProducer.SendDeferMessage(ctx, time.Second*(_defTimeWindow+_defDeferDeltaSeconds), &bizmodels.DeferMsg{
		DeferType: _const.DeferTypeContractEventSummary,
		Body:      string(msgBody),
	})
	if err != nil {
		logs.CtxError(ctx, "sendContractEventDeferMsgFail_SendDeferMessageFai, key=%s, err=%s", info.StashKey, err.Error())
		needUnlock = true
		return err
	}

	return nil
}

func (c *eventRuleChain) GetTables() []string {
	m := map[string]bool{}
	var ret []string
	for _, v := range c.rules {
		if m[v.TableName()] {
			continue
		}
		ret = append(ret, v.TableName())
		m[v.TableName()] = true
	}
	return ret
}

// HandleEventSummaryMsg 延时汇总
func HandleEventSummaryMsg(ctx context.Context, msg *bizmodels.DeferMsg) error {

	defer recovery.DefaultRecovery(ctx, "HandleEventSummaryMsg")()

	var info deferPreEventInfo
	if err := json.Unmarshal([]byte(msg.Body), &info); err != nil {
		logs.CtxError(ctx, "HandleEventSummaryMsgFail_msg_body_unmarshalFail, err=%s", err.Error())
		return err
	}

	if time.Now().Unix()-info.EventTimestamp > 3600 {
		logs.CtxInfo(ctx, "HandleEventSummaryMsg, 事件消息时间[%d]与当前时间[%d]超过1小时, 不再处理.", info.EventTimestamp, time.Now().Unix())
		return nil
	}

	lock := rediscli.RedisLock{
		LockKey: i18nfmt.Sprintf(ctx, "%s:summary", info.StashKey),
		Value:   logid.GenLogID() + "_" + strconv.Itoa(rand.Int()),
		Timeout: time.Second * (_defTimeWindow * 2),
	}

	var needUnlock bool
	defer func() {
		if needUnlock {
			logs.CtxInfo(ctx, "准备释放Lock，key=%s", lock.LockKey)
			lock.Unlock()
		}
	}()

	if err := lock.Lock(); err != nil {
		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
		if err == rediscli.ErrLockObtainFail {
			return nil
		}
		return err
	}

	if err := doHandleEventSummaryMsg(ctx, &info); err != nil {
		needUnlock = true
		return err
	}

	return nil
}

func doHandleEventSummaryMsg(ctx context.Context, info *deferPreEventInfo) error {

	// 查询REDIS中List长度
	totalCnt, err := rediscli.LLen(ctx, info.StashKey)
	if err != nil {
		logs.CtxError(ctx, "HandleEventSummaryMsgFail_LLenFail, key=%s, err=%s", info.StashKey, err.Error())
		return err
	}

	logs.CtxInfo(ctx, "LLen, key=%s, cnt=%d", info.StashKey, totalCnt)

	list, err := rediscli.LRange(ctx, info.StashKey, 0, totalCnt)
	if err != nil {
		logs.CtxError(ctx, "HandleEventSummaryMsgFail_LRangeFail, key=%s, err=%s", info.StashKey, err.Error())
		return err
	}

	var preEventList []*preEvent
	for _, v := range list {
		var pe preEvent
		if err := json.Unmarshal([]byte(v), &pe); err != nil {
			logs.CtxError(ctx, "HandleEventSummaryMsgFail_preEventUnmarshalFail, body=%s, err=%s", v, err.Error())
			return err
		}
		preEventList = append(preEventList, &pe)
	}

	// 按时间排序
	sort.Slice(preEventList, func(i, j int) bool {
		return preEventList[i].EventTimestamp < preEventList[j].EventTimestamp
	})

	event, eventDB, err := summary(ctx, info, preEventList)
	if err != nil {
		logs.CtxError(ctx, "HandleEventSummaryMsgFail_summaryFail, err=%s", err.Error())
		return err
	}
	if event == nil || eventDB == nil {
		logs.CtxInfo(ctx, "HandleEventSummaryMsg_summary_is_empty")
		return nil
	}

	err = dal.GetDB(ctx).Transaction(func(tx *gorm.DB) error {
		eventDao := dal.NewContractEventDao()
		oldEvent, err := eventDao.FindByStashKey(ctx, tx, eventDB.StashKey)
		if err != nil {
			return err
		}
		if oldEvent != nil {
			eventDB.Id = oldEvent.Id
			eventDB.CreatedTime = oldEvent.CreatedTime
		}
		// 更新DB
		if err = dal.NewContractEventDao().Update(ctx, tx, eventDB); err != nil {
			return err
		}

		body, _ := json.Marshal(event)
		logs.CtxInfo(ctx, "HandleEventSummaryMsg_sendMsg, body=%s", string(body))
		// 发送合同事件消息, 合同ID作为分区键
		if !info.IsTest {
			if err = mqProducer.SendContractEventMsg(ctx, strconv.FormatInt(info.ContractId, 10), body); err != nil {
				logs.CtxError(ctx, "HandleEventSummaryMsgFail_SendContractEventMsgFail, err=%s", err.Error())
				return err
			}
		} else {
			logs.CtxInfo(ctx, "测试场景，不发送实际事件")
		}

		return nil
	})

	return err
}

func summary(ctx context.Context, info *deferPreEventInfo, details []*preEvent) (*Event, *model.ContractEventDB, error) {

	metaDB, err := dal.NewContractMetaDao().FindByID(ctx, nil, info.ContractId)
	if err != nil {
		return nil, nil, err
	}
	if metaDB == nil {
		return nil, nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "MetaFindByIDNotExist, id=%d", info.ContractId))
	}

	event := &Event{
		ContractId:     info.ContractId,
		BizScene:       metaDB.BizScene,
		Initiator:      metaDB.Initiator,
		ContractNo:     metaDB.ContractNo,
		Version:        metaDB.Version,
		EventTimestamp: info.EventTimestamp,
		Archived:       metaDB.ArchivedStatus == _const.ContractArchived,
	}

	eventDB := &model.ContractEventDB{
		StashKey:        info.StashKey,
		ContractID:      info.ContractId,
		BizScene:        metaDB.BizScene,
		ContractNo:      metaDB.ContractNo,
		Version:         metaDB.Version,
		EventTimestamp:  time.Unix(info.EventTimestamp, 0),
		EventTimeWindow: info.EventTimeWindow,
		Archived:        metaDB.ArchivedStatus,
		BaseDB: model.BaseDB{
			Status: _statusSendSuccess,
		},
	}

	var types []string
	var remarks []string
	for _, detail := range details {
		for _, v := range detail.EventDetails {
			types = append(types, v.Type)
			if v.Remark != "" {
				remarks = append(remarks, v.Remark)
			}
		}
	}

	types = util.SingleList(types)
	remarks = util.SingleList(remarks)
	var buf bytes.Buffer
	logIdStr, _ := logid.GetLogIDFromCtx(ctx)
	buf.WriteString(logIdStr + ";")
	for _, remark := range remarks {
		if remark == "" {
			continue
		}
		buf.WriteString(remark)
		buf.WriteString(";")
	}

	event.EventTypes = types
	eventDB.EventTypes = strings.Join(types, ",")
	eventDB.Extra = buf.String()

	return event, eventDB, nil
}

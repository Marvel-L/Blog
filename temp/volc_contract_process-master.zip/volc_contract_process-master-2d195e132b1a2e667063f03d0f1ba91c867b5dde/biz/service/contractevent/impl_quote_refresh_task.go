package contractevent

import (
	"context"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
)

type quoteRefreshTaskEventRule struct {
	baseEventRule
}

func (r *quoteRefreshTaskEventRule) TableName() string {
	return tableQuoteRefreshTask
}

func (r *quoteRefreshTaskEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {
	contractNo := getStringValueFromColumns(afterColumns, "contract_no")
	if contractNo == "" {
		logs.CtxWarn(ctx, "QuoteRefreshTaskEventIgnore_contractNo_empty")
		return nil, nil
	}

	metaDB, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
	if err != nil {
		logs.CtxError(ctx, "QuoteRefreshTaskEvent_FindLastByNoFail, contractNo=%s, err=%s", contractNo, err.Error())
		return nil, err
	}
	if metaDB == nil {
		logs.CtxError(ctx, "QuoteRefreshTaskEvent_ContractNotExist, contractNo=%s", contractNo)
		return nil, nil
	}

	info := &tableFieldInfo{
		PKField:          "id",
		ContractIdField:  "contract_id",
		UpdatedTimeField: "updated_time",
	}
	afterColumnsWithContractID := copyQuoteRefreshTaskColumns(afterColumns)
	afterColumnsWithContractID["contract_id"] = metaDB.Id

	return r.commonRelateTableProcess(ctx, info, table, dmlType, beforeColumns, afterColumnsWithContractID)
}

func copyQuoteRefreshTaskColumns(columns map[string]interface{}) map[string]interface{} {
	ret := make(map[string]interface{}, len(columns)+1)
	for k, v := range columns {
		ret[k] = v
	}
	return ret
}

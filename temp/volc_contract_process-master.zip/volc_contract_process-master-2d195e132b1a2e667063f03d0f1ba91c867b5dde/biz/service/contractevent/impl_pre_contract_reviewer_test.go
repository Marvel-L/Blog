package contractevent

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
)

func TestPreContractReviewerEventRuleProcess(t *testing.T) {
	rule := &preContractReviewerEventRule{}
	ctx := context.Background()

	t.Run("非增删改事件时跳过处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			event, err := rule.Process(ctx, tablePreContractReviewer, "OTHER", nil, map[string]interface{}{
				"pre_contract_no": "CT001",
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("合同号为空时跳过处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeInsert, nil, map[string]interface{}{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("查询合同元数据失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			expectedErr := errors.New("query meta failed")
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, expectedErr).Build()

			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeUpdate, nil, map[string]interface{}{
				"pre_contract_no": "CT001",
			})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("未查询到合同元数据时跳过处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, nil).Build()

			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeUpdate, nil, map[string]interface{}{
				"pre_contract_no": "CT001",
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("新增审批人时生成粗粒度合同事件", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockPreContractReviewerEventRules()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(&model.ContractMetaDB{
				BaseDB:         model.BaseDB{Id: 9527},
				ContractNo:     "CT001",
				BizScene:       _const.BizSceneSalesContract,
				Version:        3,
				ArchivedStatus: _const.ContractArchived,
			}, nil).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{
				BaseDB:         model.BaseDB{Id: 9527},
				ContractNo:     "CT001",
				BizScene:       _const.BizSceneSalesContract,
				Version:        3,
				ArchivedStatus: _const.ContractArchived,
			}, nil).Build()
			fixedTime := time.Date(2024, 1, 2, 3, 4, 5, 0, time.UTC)
			mockey.Mock(time.Now).Return(fixedTime).Build()

			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeInsert, nil, map[string]interface{}{
				"id":              "123",
				"pre_contract_no": "CT001",
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 9527)
			convey.So(event.ContractNo, convey.ShouldEqual, "CT001")
			convey.So(event.BizScene, convey.ShouldEqual, _const.BizSceneSalesContract)
			convey.So(event.Version, convey.ShouldEqual, 3)
			convey.So(event.EventTimestamp, convey.ShouldEqual, fixedTime.Unix())
			convey.So(event.Archived, convey.ShouldBeTrue)
			convey.So(event.EventDetails, convey.ShouldHaveLength, 1)
			convey.So(event.EventDetails[0].Type, convey.ShouldEqual, EventTypeChangeReviewer)
			convey.So(event.EventDetails[0].Remark, convey.ShouldEqual, "123:在线协同审批人Insert-123;")
		})
	})

	t.Run("更新审批人字段时基于变更规则生成事件", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockPreContractReviewerEventRules()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(&model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 9529},
				ContractNo: "CT003",
				Version:    1,
			}, nil).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 9529},
				ContractNo: "CT003",
				Version:    1,
			}, nil).Build()

			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeUpdate, map[string]interface{}{
				"id":              "789",
				"pre_contract_no": "CT003",
				"reviewer":        "old@bytedance.com",
			}, map[string]interface{}{
				"id":              "789",
				"pre_contract_no": "CT003",
				"reviewer":        "new@bytedance.com",
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 9529)
			convey.So(event.ContractNo, convey.ShouldEqual, "CT003")
			convey.So(event.EventDetails, convey.ShouldHaveLength, 1)
			convey.So(event.EventDetails[0].Type, convey.ShouldEqual, EventTypeChangeReviewer)
			convey.So(event.EventDetails[0].Remark, convey.ShouldEqual, "789:在线协同审批人[c]-[]->reviewer;")
		})
	})

	t.Run("删除审批人时从before中读取合同号和行ID", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockPreContractReviewerEventRules()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(&model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 9528},
				ContractNo: "CT002",
				Version:    1,
			}, nil).Build()
			mockey.Mock(mockey.GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{
				BaseDB:     model.BaseDB{Id: 9528},
				ContractNo: "CT002",
				Version:    1,
			}, nil).Build()

			event, err := rule.Process(ctx, tablePreContractReviewer, DMLTypeDelete, map[string]interface{}{
				"id":              "456",
				"pre_contract_no": "CT002",
			}, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 9528)
			convey.So(event.ContractNo, convey.ShouldEqual, "CT002")
			convey.So(event.EventDetails[0].Type, convey.ShouldEqual, EventTypeChangeReviewer)
			convey.So(event.EventDetails[0].Remark, convey.ShouldEqual, "456:在线协同审批人del-456;")
		})
	})
}

func TestGetPreContractReviewerContractNo(t *testing.T) {
	mockey.PatchConvey("优先从after读取合同号，after为空时读取before", t, func() {
		convey.So(getPreContractReviewerContractNo(map[string]interface{}{"pre_contract_no": "after"}, map[string]interface{}{"pre_contract_no": "before"}), convey.ShouldEqual, "after")
		convey.So(getPreContractReviewerContractNo(nil, map[string]interface{}{"pre_contract_no": "before"}), convey.ShouldEqual, "before")
	})
}

func mockPreContractReviewerEventRules() {
	mockey.Mock(conf.GetEventRules).Return(map[string][]*conf.RuleInfo{
		tablePreContractReviewer: {{
			MatchResultType: EventTypeChangeReviewer,
			Details: []*conf.RuleDetail{
				{RuleType: ruleTypeRecordInsert},
				{RuleType: ruleTypeRecordDelete},
				{
					RuleType: ruleTypeLiteralChange,
					Fields: []string{
						"reviewer",
						"reviewer_id",
						"department",
						"reviewer_type",
						"reviewer_role",
						"reviewer_source",
						"contract_status",
						"priority",
						"is_deleted",
						"skip_return_review",
						"status",
					},
				},
			},
		}},
	}).Build()
}

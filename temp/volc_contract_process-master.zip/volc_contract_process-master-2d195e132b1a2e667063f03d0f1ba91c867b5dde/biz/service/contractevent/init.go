package contractevent

import (
	"context"
	"errors"
	"fmt"
	"runtime/debug"
	"sort"
	"strings"
	"time"

	"code.byted.org/gopkg/dbus"
	"code.byted.org/gopkg/dbus/filter/mysql_filter"
	"code.byted.org/gopkg/logs"
	"code.byted.org/rocketmq/rocketmq-go-proxy/pkg/config"
	"code.byted.org/rocketmq/rocketmq-go-proxy/pkg/pb"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
	"volc_contract_process/pkg/env"
)

var _disableCommentEvent bool

func Init() error {

	chain := initEventChain()
	if chain == nil {
		return errors.New("事件处理器初始化失败")
	}

	ctx := context.Background()

	globalConf := conf.GetGlobalConf(ctx)
	if globalConf == nil {
		return i18nfmt.New(ctx, "conf尚未初始化")
	}

	cfg := globalConf.ContractEventConf
	if cfg == nil {
		return i18nfmt.New(ctx, "conf.ContractEventConf尚未初始化")
	}

	// 不启用，比如PPE环境
	if cfg.Disable {
		return nil
	}

	tables := chain.GetTables()
	if len(tables) == 0 {
		return i18nfmt.New(ctx, "尚未有可用的事件处理表")
	}

	logs.CtxInfo(ctx, "contract event tables => %v", tables)

	events := []string{DMLTypeInsert, DMLTypeUpdate, DMLTypeDelete}

	if err := initCommonConsumer(cfg, "contract_binlog", chain, tables, events); err != nil {
		return err
	}

	// 是否关闭评论事件处理
	_disableCommentEvent = cfg.DisableCommentEvent

	return nil
}

func initEventChain() *eventRuleChain {

	chain := &eventRuleChain{
		rules: map[string]tableEventRule{},
	}

	register(chain, &metaEventRule{})
	register(chain, &settlementEventRule{})
	register(chain, &manageEventRule{})
	register(chain, &commodityEventRule{})
	register(chain, &commentEventRule{})
	register(chain, &quoteRefreshTaskEventRule{})
	register(chain, &preContractReviewerEventRule{})

	return chain
}

func register(chain *eventRuleChain, rule tableEventRule) {
	chain.rules[rule.TableName()] = rule
}

func initCommonConsumer(cfg *conf.ContractEventConf, flag string, h dbus.MysqlIncrementEventHandler, tables []string, events []string) error {

	// 表名按字母排序
	sort.Slice(tables, func(i, j int) bool {
		return tables[i] < tables[j]
	})

	logs.Infof("[initCommonConsumer]tables=%s", strings.Join(tables, ","))

	/* 从topic的最新位置消费 */
	// 如果consumer_group之前使用过，会从之前的位置开始消费
	ccc := config.NewDefaultConsumerConfig(cfg.Group, cfg.Topic, cfg.ClusterName)
	ccc.EnableBytedTrace = false
	ccc.Orderly = true
	ccc.AutoCommit = true
	ccc.ConsumeFromWhere = pb.SubscribeRequest_CONSUME_FROM_LATEST
	ccc.MQLeaseEnable = true // 避免重启时消费乱序的参数
	if !env.IsPPE() {        // 非PPE环境 不开启泳道
		ccc.EnablePPE = false
	}

	// https://bytedance.larkoffice.com/docx/doxcnYsxusAtYWzEAGSu8FdMnGd
	// 该版本只能越改越大，当启动配置发生变化时，可以通过调整该值实现滚动升级
	// 一般情况下该值不需要修改，在如下情况下需要修改：
	// 1. tables有多个，且顺序发生变化时，会导致SubExpr发生变化
	// 2. tables个数发生变化时，会导致SubExpr发生变化
	if cfg.ClientConfigEpoch > 0 {
		ccc.ClientConfigEpoch = cfg.ClientConfigEpoch
	}

	c := dbus.NewDefaultMysqlIncrementConsumerByConf(ccc)
	c.RegisterEventHandler(h, tables...)

	/* DML事件过滤 */
	/**
	 * 在解析出pb内容前，提前过滤insert/update/delete
	 * 存在大量dml操作且需要过滤时，这样性能会比较高。例如大量delete，且消费者需要过滤delete
	 * 需要import code.byted.org/gopkg/dbus/filter/mysql_filter
	 * "INSERT", "UPDATE", "DELETE"
	 */
	includeEvents, err := mysql_filter.GetMysqlEvents(events...) // 注意：如果需要订阅全部DML的，请删除这几行DML事件过滤相关代码
	if err != nil {
		return err
	}
	eventFilter, err := mysql_filter.BuildMySQLEventFilter(includeEvents)
	if err != nil {
		return err
	}
	c.RegisterBeforeParseFilter(eventFilter)

	/* 延迟消费 */
	// 设置期望延迟时间。该参数如果大于0，sdk会保证业务方读到的每条数据的时间，不早于 binlog时间 + delayDurationEachRow 。
	// 由于mq中的数据超过一定时间会过期，建议delayDurationEachRow值不要设置的太大，控制在秒级别或者分钟级别，以免该行数据后面的数据还没消费就过期
	// 如果希望最快速度读到每条mq中的数据，不需要sdk做延迟的处理逻辑，则设置delayDurationEachRow := time.Duration(0)
	delayDurationEachRow := time.Duration(0)

	/* 启动消费者 */
	// consumer.Start 如果没有error的情况下，会阻塞，如果Start之后还有其他业务逻辑，需要启动一个go routine来执行Start

	go func() {

		defer func() {
			if e := recover(); e != nil {
				logs.CtxError(context.Background(), "__PANIC__[%s], err:%v, stack:%s", flag, err, string(debug.Stack()))
				err = fmt.Errorf("StartPanic")
			}
		}()

		if e := c.Start(delayDurationEachRow); e != nil {
			logs.CtxError(context.Background(), "__PANIC__Fail, flag=%s, e=%v", flag, e.Error())
			err = e
		}

	}()

	// 等待3s，等待启动立即失败的情况返回Error
	time.Sleep(time.Second * 3)

	return err
}

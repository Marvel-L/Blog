package contractevent

import (
	"context"
)

type settlementEventRule struct {
	baseEventRule
}

func (m settlementEventRule) TableName() string {
	return tableVolcContractSettlement
}

func (m settlementEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {

	info := &tableFieldInfo{
		PKField:          "id",
		ContractIdField:  "volc_contract_id",
		UpdatedTimeField: "updated_time",
	}

	return m.commonRelateTableProcess(ctx, info, table, dmlType, beforeColumns, afterColumns)
}

package contractevent

import (
	"context"
)

type commodityEventRule struct {
	baseEventRule
}

func (m commodityEventRule) TableName() string {
	return tableVolcContractCommodity
}

func (m commodityEventRule) Process(ctx context.Context, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {

	info := &tableFieldInfo{
		PKField:          "id",
		ContractIdField:  "volc_contract_id",
		UpdatedTimeField: "updated_time",
	}

	return m.commonRelateTableProcess(ctx, info, table, dmlType, beforeColumns, afterColumns)
}

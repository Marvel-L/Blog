package contractevent

import (
	"context"
	"fmt"
	"testing"
	"time"

	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/proxy/rediscli"
	"volc_contract_process/pkg/recovery"
)

func Test_eventRuleChain_saveContractEventToDB(t *testing.T) {
	// Arrange
	v1 := &eventRuleChain{}
	type args struct {
		ctx   context.Context
		event *preEvent
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx: context.Background(),
				event: &preEvent{
					ContractId:      0,
					BizScene:        0,
					ContractNo:      "",
					Version:         0,
					EventTimestamp:  0,
					EventTimeWindow: 0,
				},
			},
			mocks: func() {
				mockey.Mock(i18nfmt.Sprintf).Return("").Build()
				mockey.Mock(logs.CtxInfo).Return().Build()
				mockey.Mock(logs.CtxWarn).Return().Build()
				mockey.Mock(logid.GenLogID).Return("1111").Build()
				mockey.Mock((*preEvent).buildStashKey).Return("").Build()
				mockey.Mock((*rediscli.RedisLock).Unlock).Return().Build()
				mockey.Mock((*rediscli.RedisLock).Lock).Return(fmt.Errorf("your error")).Build()
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				err := v1.saveContractEventToDB(
					tt.args.ctx,
					tt.args.event,
				)

				// Assert
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

func Test_eventRuleChain_sendDeferMsg(t *testing.T) {
	// Arrange
	v1 := &eventRuleChain{}
	type args struct {
		ctx   context.Context
		event *preEvent
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx: context.Background(),
				event: &preEvent{
					ContractId:      0,
					BizScene:        0,
					ContractNo:      "",
					Version:         0,
					EventTimestamp:  0,
					EventTimeWindow: 0,
				},
			},
			mocks: func() {
				mockey.Mock(i18nfmt.Sprintf).Return("").Build()
				mockey.Mock(logs.CtxInfo).Return().Build()
				mockey.Mock(logs.CtxWarn).Return().Build()
				mockey.Mock(logid.GenLogID).Return("1111").Build()
				mockey.Mock((*preEvent).buildStashKey).Return("").Build()
				mockey.Mock((*rediscli.RedisLock).Unlock).Return().Build()
				mockey.Mock((*rediscli.RedisLock).Lock).Return(fmt.Errorf("your error")).Build()
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				err := v1.sendDeferMsg(
					tt.args.ctx,
					tt.args.event,
				)

				// Assert
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

func Test_HandleEventSummaryMsg(t *testing.T) {
	// Arrange
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx: context.Background(),
			},
			mocks: func() {
				mockey.Mock(i18nfmt.Sprintf).Return("").Build()
				mockey.Mock(logs.CtxInfo).Return().Build()
				mockey.Mock(logs.CtxWarn).Return().Build()
				mockey.Mock(recovery.DefaultRecovery).Return(func() {}).Build()
				mockey.Mock(logid.GenLogID).Return("1111").Build()
				mockey.Mock((*preEvent).buildStashKey).Return("").Build()
				mockey.Mock((*rediscli.RedisLock).Unlock).Return().Build()
				mockey.Mock((*rediscli.RedisLock).Lock).Return(fmt.Errorf("your error")).Build()
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				ts := time.Now().Unix()
				// Act
				err := HandleEventSummaryMsg(
					tt.args.ctx,
					&bizmodels.DeferMsg{
						Body: fmt.Sprintf("{\"EventTimestamp\":%d}", ts),
					},
				)

				// Assert
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

package contractevent

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
)

func Test_baseEventRule_commonRelateTableProcess_BitsUTGen(t *testing.T) {
	// 准备公共测试数据
	m := baseEventRule{}
	testTable := "test_table"
	testPKField := "id"
	testContractIdField := "contract_id"
	ctx := context.Background()

	t.Run("成功场景-规则命中并生成事件详情", func(t *testing.T) {
		mockey.PatchConvey("成功场景-规则命中并生成事件详情", t, func() {
			// 场景描述:
			// 当所有依赖都正常返回，且checkRules返回了匹配的事件详情时，
			// 函数应正确处理并返回一个包含事件详情的preEvent对象。
			// 数据构造:
			// - afterColumns 包含有效的 PK 和 contractId。
			// - conf.GetEventRules 返回有效的规则配置。
			// - buildPreEventByContractId 成功构建基础事件。
			// - checkRules 返回一个非空的详情列表。
			// - time.Now 被mock以获得确定的时间戳。
			// 逻辑链路:
			// 1. conf.GetEventRules 返回规则。
			// 2. 从 afterColumns 成功提取 contractId。
			// 3. m.buildPreEventByContractId 成功返回 preEvent。
			// 4. time.Now 返回固定时间。
			// 5. checkRules 返回事件详情。
			// 6. 最终返回组装好的 preEvent，包含 EventDetails。

			// 数据构造
			tableInfo := &tableFieldInfo{
				PKField:          testPKField,
				ContractIdField:  testContractIdField,
				UpdatedTimeField: "updated_time",
			}
			afterColumns := map[string]interface{}{
				testPKField:         "123",
				testContractIdField: "456",
			}
			mockPreEvent := &preEvent{ContractId: 456, ContractNo: "CON-123"}
			mockDetails := []*eventDetail{{Type: "TestType", Remark: "Test Remark"}}
			mockRules := map[string][]*conf.RuleInfo{
				testTable: {{MatchResultType: "TestType"}},
			}
			mockTime := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()
			mockey.Mock((baseEventRule).buildPreEventByContractId).Return(mockPreEvent, nil).Build()
			mockey.Mock(time.Now).Return(mockTime).Build()
			mockey.Mock(checkRules).Return(mockDetails, nil).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, tableInfo, testTable, "UPDATE", nil, afterColumns)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 456)
			convey.So(event.EventTimestamp, convey.ShouldEqual, mockTime.Unix())
			convey.So(event.EventDetails, convey.ShouldResemble, mockDetails)
		})
	})

	t.Run("成功场景-规则未命中", func(t *testing.T) {
		mockey.PatchConvey("成功场景-规则未命中", t, func() {
			// 场景描述:
			// 当所有依赖都正常，但checkRules未匹配到任何规则（返回空详情列表）时，
			// 函数应正确处理并返回一个不包含事件详情的preEvent对象。
			// 逻辑链路:
			// 1. ... (与成功场景类似)
			// 5. checkRules 返回一个空的详情列表。
			// 6. 最终返回组装好的 preEvent，其 EventDetails 为 nil。

			// 数据构造
			tableInfo := &tableFieldInfo{PKField: testPKField, ContractIdField: testContractIdField}
			afterColumns := map[string]interface{}{testPKField: "123", testContractIdField: "456"}
			mockPreEvent := &preEvent{ContractId: 456, ContractNo: "CON-123"}
			mockRules := map[string][]*conf.RuleInfo{testTable: {{}}}
			mockTime := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()
			mockey.Mock((baseEventRule).buildPreEventByContractId).Return(mockPreEvent, nil).Build()
			mockey.Mock(time.Now).Return(mockTime).Build()
			mockey.Mock(checkRules).Return([]*eventDetail{}, nil).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, tableInfo, testTable, "UPDATE", nil, afterColumns)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 456)
			convey.So(event.EventDetails, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-全局事件规则未配置", func(t *testing.T) {
		mockey.PatchConvey("失败场景-全局事件规则未配置", t, func() {
			// 场景描述:
			// 当从配置中获取全局事件规则失败（返回nil）时，函数应返回一个明确的错误。
			// 逻辑链路:
			// 1. conf.GetEventRules 返回 nil。
			// 2. 函数应立即通过 i18nfmt.New 创建并返回错误。

			// Mock
			mockey.Mock(conf.GetEventRules).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, &tableFieldInfo{}, testTable, "UPDATE", nil, nil)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同事件规则未配置")
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("跳过场景-指定表未配置规则", func(t *testing.T) {
		mockey.PatchConvey("跳过场景-指定表未配置规则", t, func() {
			// 场景描述:
			// 当全局规则存在，但当前处理的表没有对应的规则时，函数应静默处理，不报错，并返回 nil。
			// 逻辑链路:
			// 1. conf.GetEventRules 返回一个不包含当前 table 的规则映射。
			// 2. 函数检查到无规则，记录日志并返回 nil, nil。

			// 数据构造
			mockRules := map[string][]*conf.RuleInfo{"another_table": {}}

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, &tableFieldInfo{}, testTable, "UPDATE", nil, nil)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("跳过场景-未找到合同ID", func(t *testing.T) {
		mockey.PatchConvey("跳过场景-未找到合同ID", t, func() {
			// 场景描述:
			// 当 afterColumns 中缺少 contract_id 字段或其值为0时，函数应静默处理，并返回 nil。
			// 逻辑链路:
			// 1. conf.GetEventRules 返回规则。
			// 2. 从 afterColumns 提取 contractId 得到 0。
			// 3. 函数记录警告日志并返回 nil, nil。

			// 数据构造
			tableInfo := &tableFieldInfo{PKField: testPKField, ContractIdField: testContractIdField}
			afterColumns := map[string]interface{}{testPKField: "123"} // 缺少 contract_id
			mockRules := map[string][]*conf.RuleInfo{testTable: {{}}}

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, tableInfo, testTable, "UPDATE", nil, afterColumns)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-构建preEvent失败", func(t *testing.T) {
		mockey.PatchConvey("失败场景-构建preEvent失败", t, func() {
			// 场景描述:
			// 当根据 contractId 构建基础事件对象（buildPreEventByContractId）失败时，函数应将错误向上传递。
			// 逻辑链路:
			// 1. ...
			// 3. m.buildPreEventByContractId 返回一个错误。
			// 4. 函数捕获错误并立即返回。

			// 数据构造
			tableInfo := &tableFieldInfo{PKField: testPKField, ContractIdField: testContractIdField}
			afterColumns := map[string]interface{}{testPKField: "123", testContractIdField: "456"}
			mockRules := map[string][]*conf.RuleInfo{testTable: {{}}}
			mockError := errors.New("database error")

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()
			mockey.Mock((baseEventRule).buildPreEventByContractId).Return(nil, mockError).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, tableInfo, testTable, "UPDATE", nil, afterColumns)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database error")
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景-检查规则失败", func(t *testing.T) {
		mockey.PatchConvey("失败场景-检查规则失败", t, func() {
			// 场景描述:
			// 当执行规则检查（checkRules）本身发生错误时，函数应将错误向上传递。
			// 逻辑链路:
			// 1. ...
			// 5. checkRules 返回一个错误。
			// 6. 函数记录错误日志并返回该错误。

			// 数据构造
			tableInfo := &tableFieldInfo{PKField: testPKField, ContractIdField: testContractIdField}
			afterColumns := map[string]interface{}{testPKField: "123", testContractIdField: "456"}
			mockPreEvent := &preEvent{ContractId: 456}
			mockRules := map[string][]*conf.RuleInfo{testTable: {{}}}
			mockError := errors.New("check rule error")
			mockTime := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)

			// Mock
			mockey.Mock(conf.GetEventRules).Return(mockRules).Build()
			mockey.Mock((baseEventRule).buildPreEventByContractId).Return(mockPreEvent, nil).Build()
			mockey.Mock(time.Now).Return(mockTime).Build()
			mockey.Mock(checkRules).Return(nil, mockError).Build()

			// 调用
			event, err := m.commonRelateTableProcess(ctx, tableInfo, testTable, "UPDATE", nil, afterColumns)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "check rule error")
			convey.So(event, convey.ShouldBeNil)
		})
	})
}

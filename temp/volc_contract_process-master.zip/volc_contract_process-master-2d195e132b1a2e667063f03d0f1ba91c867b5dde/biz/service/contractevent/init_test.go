package contractevent

import (
	"code.byted.org/gopkg/dbus/filter/mysql_filter"
	"code.byted.org/gopkg/logs"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/pkg/conf"
)

func Test_demo(t *testing.T) {
	t.Run("case demo#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(logs.Infof).Return().Build()
			mockey.Mock(mysql_filter.GetMysqlEvents).Return(nil, fmt.Errorf("")).Build()
			// Act
			err := initCommonConsumer(&conf.ContractEventConf{}, "test",
				&eventRuleChain{},
				[]string{"a", "b"}, []string{"INSERT"})
			// Assert
			convey.So(err, convey.ShouldNotBeNil)

		})
	})
}

func TestInitEventChain(t *testing.T) {
	t.Run("注册刷数任务规则", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			chain := initEventChain()

			convey.So(chain, convey.ShouldNotBeNil)
			convey.So(chain.rules[tableQuoteRefreshTask], convey.ShouldNotBeNil)

			rule, ok := chain.rules[tableQuoteRefreshTask].(*quoteRefreshTaskEventRule)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(rule.TableName(), convey.ShouldEqual, tableQuoteRefreshTask)
		})
	})
	t.Run("注册在线协同审批人变更规则", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			chain := initEventChain()

			convey.So(chain, convey.ShouldNotBeNil)
			convey.So(chain.rules[tablePreContractReviewer], convey.ShouldNotBeNil)

			rule, ok := chain.rules[tablePreContractReviewer].(*preContractReviewerEventRule)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(rule.TableName(), convey.ShouldEqual, tablePreContractReviewer)
		})
	})
}

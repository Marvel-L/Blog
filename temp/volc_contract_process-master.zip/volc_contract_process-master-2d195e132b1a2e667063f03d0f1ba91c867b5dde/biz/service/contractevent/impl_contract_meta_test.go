package contractevent

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"testing"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/proxy/dkmscli"
	"volc_contract_process/pkg/proxy/larkc"
)

func newTestTradePartyInfo(subjectName, otherPartyName, partyNumber string) *bizmodels.TradePartyInfo {
	return &bizmodels.TradePartyInfo{
		Subject: []*bizmodels.TradePartyInfoDetail{
			{
				PartyName:   subjectName,
				PartyNumber: partyNumber,
				SignKeyword: "subject_keyword",
				PayTypes: []*bizmodels.PayType{
					{
						AccountNumber: "subject_account_123",
						BranchName:    "subject_branch_abc",
					},
				},
			},
		},
		OtherParty: []*bizmodels.TradePartyInfoDetail{
			{
				PartyName:   otherPartyName,
				PartyNumber: partyNumber,
				SignKeyword: "other_keyword",
				AccountID:   "other_account_id_123",
				PayTypes: []*bizmodels.PayType{
					{
						AccountNumber: "other_account_456",
						BranchName:    "other_branch_def",
					},
				},
			},
		},
	}
}

func Test_metaEventRule_calcTradePartyInfo_BitsUTGen(t *testing.T) {
	// Common test data
	baseInfo := newTestTradePartyInfo("Subject A", "Other A", "P001")
	baseInfoJSON, _ := json.Marshal(baseInfo)

	t.Run("Success - no changes detected", func(t *testing.T) {
		mockey.PatchConvey("Success - no changes detected", t, func() {
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after"}

			mockey.Mock(dkmscli.DecryptWithContext).Return(string(baseInfoJSON), nil).Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 0)
		})
	})

	t.Run("Success - change in our party's name", func(t *testing.T) {
		mockey.PatchConvey("Success - change in our party's name", t, func() {
			afterInfo := newTestTradePartyInfo("Subject B", "Other A", "P001")
			afterInfoJSON, _ := json.Marshal(afterInfo)
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after"}

			mockey.Mock(dkmscli.DecryptWithContext).Return(mockey.Sequence(string(baseInfoJSON), nil).Then(string(afterInfoJSON), nil)).Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 1)
			convey.So(details[0].Type, convey.ShouldEqual, EventTypeChangePartyI)
			convey.So(details[0].Remark, convey.ShouldEqual, fmt.Sprintf("meta-我方名称[%s]", "P001"))
		})
	})

	t.Run("Failure - decryption fails for beforeColumns", func(t *testing.T) {
		mockey.PatchConvey("Failure - decryption fails for beforeColumns", t, func() {
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before_invalid"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after"}
			decryptErr := errors.New("decryption failed")

			mockey.Mock(dkmscli.DecryptWithContext).Return(mockey.Sequence("", decryptErr).Then(string(baseInfoJSON), nil)).Build()
			mockey.Mock(larkc.Warning).Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			// The function proceeds with an empty 'before' struct, leading to a 'quantity mismatch' change.
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 2)
			convey.So(details[0].Type, convey.ShouldEqual, EventTypeChangePartyI)
			convey.So(details[0].Remark, convey.ShouldEqual, "meta-subject:数量不一致")
			convey.So(details[1].Type, convey.ShouldEqual, EventTypeChangePartyO)
			convey.So(details[1].Remark, convey.ShouldEqual, "meta-对方数量不一致")
		})
	})

	t.Run("Failure - decryption fails for afterColumns", func(t *testing.T) {
		mockey.PatchConvey("Failure - decryption fails for afterColumns", t, func() {
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after_invalid"}
			decryptErr := errors.New("decryption failed")

			mockey.Mock(dkmscli.DecryptWithContext).Return(mockey.Sequence(string(baseInfoJSON), nil).Then("", decryptErr)).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(larkc.Warning).Return().Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			// The function proceeds with an empty 'after' struct, leading to a 'quantity mismatch' change.
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 2)
			convey.So(details[0].Type, convey.ShouldEqual, EventTypeChangePartyI)
			convey.So(details[0].Remark, convey.ShouldEqual, "meta-subject:数量不一致")
			convey.So(details[1].Type, convey.ShouldEqual, EventTypeChangePartyO)
			convey.So(details[1].Remark, convey.ShouldEqual, "meta-对方数量不一致")
		})
	})

	t.Run("Success - empty columns map results in no changes", func(t *testing.T) {
		mockey.PatchConvey("Success - empty columns map results in no changes", t, func() {
			beforeColumns := map[string]interface{}{}
			afterColumns := map[string]interface{}{}

			// DecryptWithContext will not be called
			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 0)
		})
	})

	t.Run("Success - change in other party's AccountID", func(t *testing.T) {
		mockey.PatchConvey("Success - change in other party's AccountID", t, func() {
			afterInfo := newTestTradePartyInfo("Subject A", "Other A", "P001")
			afterInfo.OtherParty[0].AccountID = "other_account_id_456"
			afterInfoJSON, _ := json.Marshal(afterInfo)
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after"}

			mockey.Mock(dkmscli.DecryptWithContext).Return(mockey.Sequence(string(baseInfoJSON), nil).Then(string(afterInfoJSON), nil)).Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 1)
			convey.So(details[0].Type, convey.ShouldEqual, EventTypeChangePartyO)
			convey.So(details[0].Remark, convey.ShouldEqual, fmt.Sprintf("meta-对方账号ID[%s]", "P001"))
		})
	})

	t.Run("Success - change in our party's PayTypes", func(t *testing.T) {
		mockey.PatchConvey("Success - change in our party's PayTypes", t, func() {
			afterInfo := newTestTradePartyInfo("Subject A", "Other A", "P001")
			afterInfo.Subject[0].PayTypes[0].AccountNumber = "new_subject_account"
			afterInfoJSON, _ := json.Marshal(afterInfo)
			beforeColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_before"}
			afterColumns := map[string]interface{}{"encrypt_trade_party_info": "encrypted_after"}

			mockey.Mock(dkmscli.DecryptWithContext).Return(mockey.Sequence(string(baseInfoJSON), nil).Then(string(afterInfoJSON), nil)).Build()

			m := metaEventRule{}
			details, err := m.calcTradePartyInfo(context.Background(), "UPDATE", beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(details), convey.ShouldEqual, 1)
			convey.So(details[0].Type, convey.ShouldEqual, EventTypeChangePartyI)
			convey.So(details[0].Remark, convey.ShouldEqual, fmt.Sprintf("meta-Pay_银行账号[%s]", "P001"))
		})
	})
}

// 构造测试用的交易方信息
func buildTradePartyInfo(other []*bizmodels.TradePartyInfoDetail) *bizmodels.TradePartyInfo {
	return &bizmodels.TradePartyInfo{
		OtherParty: other,
	}
}

// 构造一个包含支付信息的对方主体
func buildOtherParty(partyNumber, partyName, signKeyword, accountID, country string, pays []*bizmodels.PayType) *bizmodels.TradePartyInfoDetail {
	return &bizmodels.TradePartyInfoDetail{
		PrimaryFlag:    "O",
		PartyNumber:    partyNumber,
		PartyName:      partyName,
		SignKeyword:    signKeyword,
		AccountID:      accountID,
		Country:        country,
		PayTypes:       pays,
		OtherPartyType: 0,
	}
}

// 构造PayType
func buildPayType(payType, accountNumber, branchName, clctName string) *bizmodels.PayType {
	return &bizmodels.PayType{
		PayType:       payType,
		AccountNumber: accountNumber,
		BranchName:    branchName,
		ClctName:      clctName,
	}
}

func Test_metaEventRule_compareOtherSubject_BitsUTGen(t *testing.T) {
	m := metaEventRule{}

	mockey.PatchConvey("compareOtherSubject-对方数量不一致", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{}) // 少一个

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方数量不一致")
	})

	mockey.PatchConvey("compareOtherSubject-缺失某交易方编码", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
			buildOtherParty("PN2", "B", "KW2", "ACC2", "US", []*bizmodels.PayType{
				buildPayType("T2", "NO2", "B2", "C2"),
			}),
		})
		// after中缺少PN2
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
			buildOtherParty("PN3", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方数量不一致[PN2]")
	})

	mockey.PatchConvey("compareOtherSubject-名称差异", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A-NEW", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方名称[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-签约关键字差异", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW-NEW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方签约关键字[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-账号ID差异", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC-NEW", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方账号ID[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-国家差异", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "US", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方国家[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-PayTypes长度差异", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
				buildPayType("T2", "NO2", "B2", "C2"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "meta-对方PayTypes[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-PayType字段差异-银行账号", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1-NEW", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "对方Pay_银行账号[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-PayType字段差异-开户行名称", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1-NEW", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "对方Pay_开户行名称[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-PayType字段差异-支付类型", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1-NEW", "NO1", "B1", "C1"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "对方Pay_支付类型[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-PayType字段差异-账户名称", t, func() {
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1-NEW"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldNotBeNil)
		convey.So(res.Type, convey.ShouldEqual, EventTypeChangePartyO)
		convey.So(res.Remark, convey.ShouldEqual, "对方Pay_账户名称[PN1]")
	})

	mockey.PatchConvey("compareOtherSubject-完全一致返回nil", t, func() {
		pays := []*bizmodels.PayType{
			buildPayType("T1", "NO1", "B1", "C1"),
			buildPayType("T2", "NO2", "B2", "C2"),
		}
		before := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", pays),
			buildOtherParty("PN2", "B", "KW2", "ACC2", "US", []*bizmodels.PayType{
				buildPayType("T3", "NO3", "B3", "C3"),
			}),
		})
		after := buildTradePartyInfo([]*bizmodels.TradePartyInfoDetail{
			buildOtherParty("PN1", "A", "KW", "ACC", "CN", []*bizmodels.PayType{
				buildPayType("T1", "NO1", "B1", "C1"),
				buildPayType("T2", "NO2", "B2", "C2"),
			}),
			buildOtherParty("PN2", "B", "KW2", "ACC2", "US", []*bizmodels.PayType{
				buildPayType("T3", "NO3", "B3", "C3"),
			}),
		})

		res := m.compareOtherSubject(before, after)
		convey.So(res, convey.ShouldBeNil)
	})
}

package contractevent

import (
	"context"
	"time"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
)

type baseEventRule struct {
}

func (m baseEventRule) commonRelateTableProcess(ctx context.Context, tableInfo *tableFieldInfo, table string, dmlType string, beforeColumns map[string]interface{}, afterColumns map[string]interface{}) (*preEvent, error) {

	allRules := conf.GetEventRules(ctx)
	if allRules == nil {
		return nil, i18nfmt.New(ctx, "合同事件规则未配置")
	}
	rules := allRules[table]
	if len(rules) == 0 {
		logs.CtxInfo(ctx, "表[%s]未配置事件规则", table)
		return nil, nil
	}

	id := getInt64ValueFromColumns(afterColumns, tableInfo.PKField)
	contractId := getInt64ValueFromColumns(afterColumns, tableInfo.ContractIdField)
	if contractId == 0 {
		logs.CtxWarn(ctx, "getInt64ValueFromColumns_contractId_not_exist, table=%s, id=%d", table, id)
		return nil, nil
	}

	event, err := m.buildPreEventByContractId(ctx, contractId)
	if err != nil {
		return nil, err
	}

	// updatedTime := getTimeValueFromColumns(afterColumns, tableInfo.UpdatedTimeField)
	// event.EventTimestamp = updatedTime.Unix()
	event.EventTimestamp = time.Now().Unix()

	details, err := checkRules(ctx, rules, id, table, dmlType, beforeColumns, afterColumns)
	if err != nil {
		logs.CtxError(ctx, "checkRuleFail, err=%s", err.Error())
		return nil, err
	}

	if len(details) == 0 {
		logs.CtxInfo(ctx, "no details")
		return event, nil
	}

	event.EventDetails = details

	return event, nil
}

func (m baseEventRule) buildPreEventByContractId(ctx context.Context, contractId int64) (*preEvent, error) {

	metaDB, err := dal.NewContractMetaDao().FindByID(ctx, nil, contractId)
	if err != nil {
		logs.CtxError(ctx, "FindByIDFail, contractId=%d, err=%s", contractId, err.Error())
		return nil, err
	}
	if metaDB == nil {
		logs.CtxError(ctx, "buildPreEventByContractIdFail_not_exist, contractId=%d", contractId)
		return nil, skipRetryError
	}

	event := &preEvent{
		ContractId: int64(metaDB.Id),
		ContractNo: metaDB.ContractNo,
		Version:    metaDB.Version,
		BizScene:   metaDB.BizScene,
		Archived:   metaDB.ArchivedStatus == _const.ContractArchived,
	}

	return event, nil
}

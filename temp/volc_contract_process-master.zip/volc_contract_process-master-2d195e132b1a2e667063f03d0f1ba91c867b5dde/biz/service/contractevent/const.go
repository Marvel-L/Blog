package contractevent

import "time"

type EventType string

const (
	EventTypeMilestoneArchived = "MILESTONE_ARCHIVED" // 里程碑节点：归档-tcc配置支持
	EventTypeChangeBaseInfo    = "CHANGE_BASE_INFO"   // 合同基本信息变更-tcc配置支持
	EventTypeChangeManageInfo  = "CHANGE_MANAGE_INFO" // 合同管理信息变更-tcc配置支持
	EventTypeChangePartyI      = "CHANGE_PARTY_I"     // 交易方信息我方变更-定制逻辑
	EventTypeChangePartyO      = "CHANGE_PARTY_O"     // 交易方信息对方变更-定制逻辑
	EventTypeChangeSettlement  = "CHANGE_SETTLEMENT"  // 合同结算条款变更-tcc配置支持
	EventTypeChangeStatus      = "CHANGE_STATUS"      // 合同状态变更-tcc配置支持
	EventTypeChangeReviewer    = "CHANGE_REVIEWER"    // 在线协同审批人变更-定制逻辑
	EventTypeCouponRefresh     = "COUPON_REFRESH"     // 合同代金券刷数完成-定制逻辑
)

const (
	tableVolcContractMeta       = "volc_contract_meta"       // 合同主表
	tableVolcContractSettlement = "volc_contract_settlement" // 结算信息表
	tableVolcContractCommodity  = "volc_contract_commodity"  // 商品行
	tableVolcContractManage     = "volc_contract_manage"     // 商品行
	tableComment                = "comment"                  // 商品行
	tableQuoteRefreshTask       = "quote_refresh_task"       // 报价刷数任务
	tablePreContractReviewer    = "pre_contract_reviewer"    // 在线协同审批人
)

var tableNameMappings = map[string]string{
	tableVolcContractMeta:       "meta",
	tableVolcContractSettlement: "结算",
	tableVolcContractCommodity:  "商品行",
	tableVolcContractManage:     "管理信息",
	tableQuoteRefreshTask:       "刷数任务",
	tablePreContractReviewer:    "在线协同审批人",
}

const (
	DMLTypeInsert = "INSERT"
	DMLTypeUpdate = "UPDATE"
	DMLTypeDelete = "DELETE"
)

const (
	_statusDraft       = 0 // 待聚合发送
	_statusSendSuccess = 1 // 已发送
	_statusSendFail    = 2 // 发送失败
)

const (
	_defTimeWindow        = 10 // 默认时间窗口：10秒, 使用时需要乘以time.Second
	_defDeferDeltaSeconds = 3  //
)

var _defExpiredTime = time.Hour * 24 // 默认过期时间 1天

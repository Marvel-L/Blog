package contractevent

import (
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"time"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/conf"
)

func TestQuoteRefreshTaskEventRuleProcess(t *testing.T) {
	rule := &quoteRefreshTaskEventRule{}
	ctx := context.Background()

	t.Run("合同号为空时跳过处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			event, err := rule.Process(ctx, tableQuoteRefreshTask, DMLTypeUpdate, nil, map[string]interface{}{})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("查询合同元数据失败时返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			expectedErr := errors.New("query meta failed")
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, expectedErr).Build()

			event, err := rule.Process(ctx, tableQuoteRefreshTask, DMLTypeUpdate, nil, map[string]interface{}{
				"contract_no": "CN001",
			})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("未查询到合同元数据时跳过处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(nil, nil).Build()

			event, err := rule.Process(ctx, tableQuoteRefreshTask, DMLTypeUpdate, nil, map[string]interface{}{
				"contract_no": "CN001",
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldBeNil)
		})
	})

	t.Run("查询成功时补充合同ID并继续处理", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(metaDao, "FindLastByNo")).Return(&model.ContractMetaDB{
				BaseDB: model.BaseDB{Id: 9527},
			}, nil).Build()

			beforeColumns := map[string]interface{}{"id": "1"}
			afterColumns := map[string]interface{}{
				"id":          "1",
				"contract_no": "CN001",
			}
			fixedTime := time.Date(2024, 1, 2, 3, 4, 5, 0, time.UTC)
			var capturedContractID int64
			var capturedTable string
			var capturedDML string
			var capturedBefore map[string]interface{}
			var capturedAfter map[string]interface{}
			expectedDetails := []*eventDetail{{Type: EventTypeCouponRefresh, Remark: "hit"}}

			mockey.Mock(conf.GetEventRules).Return(map[string][]*conf.RuleInfo{
				tableQuoteRefreshTask: {{}},
			}).Build()
			mockey.Mock((baseEventRule).buildPreEventByContractId).To(func(_ baseEventRule, _ context.Context, contractID int64) (*preEvent, error) {
				capturedContractID = contractID
				return &preEvent{ContractId: contractID, ContractNo: "CN001"}, nil
			}).Build()
			mockey.Mock(time.Now).Return(fixedTime).Build()
			mockey.Mock(checkRules).To(func(_ context.Context, _ []*conf.RuleInfo, _ int64, table string, dmlType string,
				beforeColumns map[string]interface{}, afterColumns map[string]interface{}) ([]*eventDetail, error) {
				capturedTable = table
				capturedDML = dmlType
				capturedBefore = beforeColumns
				capturedAfter = afterColumns
				return expectedDetails, nil
			}).Build()

			event, err := rule.Process(ctx, tableQuoteRefreshTask, DMLTypeUpdate, beforeColumns, afterColumns)

			convey.So(err, convey.ShouldBeNil)
			convey.So(event, convey.ShouldNotBeNil)
			convey.So(event.ContractId, convey.ShouldEqual, 9527)
			convey.So(event.ContractNo, convey.ShouldEqual, "CN001")
			convey.So(event.EventTimestamp, convey.ShouldEqual, fixedTime.Unix())
			convey.So(event.EventDetails, convey.ShouldResemble, expectedDetails)
			convey.So(capturedContractID, convey.ShouldEqual, 9527)
			convey.So(capturedTable, convey.ShouldEqual, tableQuoteRefreshTask)
			convey.So(capturedDML, convey.ShouldEqual, DMLTypeUpdate)
			convey.So(capturedBefore, convey.ShouldResemble, beforeColumns)
			convey.So(capturedAfter["contract_no"], convey.ShouldEqual, "CN001")
			convey.So(capturedAfter["contract_id"], convey.ShouldEqual, uint64(9527))
			convey.So(afterColumns["contract_id"], convey.ShouldBeNil)
		})
	})
}

var capturedTable string

var capturedAfter map[string]interface{}

var capturedContractID int64

var capturedDML string

var capturedBefore map[string]interface{}

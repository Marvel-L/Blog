package comment

import (
	"context"
	"fmt"
	"strconv"
	stringsV1 "strings"

	"code.byted.org/gopkg/lang/strings"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/support/richtext"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/idgenerator"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"
)

type CommentService interface {
	ListComment(ctx context.Context, req *bizmodels.ListCommentReq) (*bizmodels.ListCommentResp, errors.APIError)
	DeleteComment(ctx context.Context, req *bizmodels.DeleteCommentReq) errors.APIError
	PublishComment(ctx context.Context, req *bizmodels.PublishCommentReq) (*bizmodels.PublishCommentResp, errors.APIError)
	AddMentionReviewerByCommentID(ctx context.Context, commentID string) error
}

var svc = &serviceImpl{
	metaDao:         dal.NewContractMetaDao(),
	commentDao:      dal.NewCommentDao(),
	richTextDao:     dal.NewRichTextDao(),
	reviewerDao:     dal.NewPreContractReviewerDao(),
	richTextService: richtext.NewService(),
}

func NewCommentService() CommentService {
	return svc
}

type serviceImpl struct {
	metaDao         dal.ContractMetaDao
	commentDao      dal.CommentDao
	richTextDao     dal.RichTextDao
	reviewerDao     dal.PreContractReviewerDao
	richTextService richtext.Service
}

func (c *serviceImpl) ListComment(ctx context.Context, req *bizmodels.ListCommentReq) (*bizmodels.ListCommentResp, errors.APIError) {
	logs.CtxInfo(ctx, "[ListComment] req : %s", util.ToJSON(req))
	resp := &bizmodels.ListCommentResp{}

	commentDBList, err := c.commentDao.ListCommentByRelatedID(ctx, nil, req.CommentScene, req.RelatedID)
	if err != nil {
		logs.CtxWarn(ctx, "[commentDao] ListCommentByRelatedID failed, err: %s", err.Error())
		return nil, errors.ErrInternalErrorRaw.WithArgs("query comment failed")
	}

	comments := commentDBList.GenResp()

	richTextIDList := make([]int, 0, len(comments))
	for _, item := range comments {
		// 只查询有效评论的富文本信息
		if item.Status == StatusValid {
			richTextIDList = append(richTextIDList, int(item.RichTextID))
		}
	}
	richTextMap, err := c.richTextService.GetRichTextMapByIDs(ctx, richTextIDList)
	if err != nil {
		logs.CtxWarn(ctx, "[richTextDao] ListByIds failed, err: %s", err.Error())
		return nil, errors.ErrInternalErrorRaw.WithArgs("query rich text failed")
	}

	subCommentsMap := make(map[string][]*bizmodels.Comment, len(comments))
	for _, item := range comments {
		// 填充富文本内容
		item.Content = richTextMap[int(item.RichTextID)]

		// 构建父子评论关系
		if !strings.IsEmpty(item.ParentCommentID) {
			subCommentsMap[item.ParentCommentID] = append(subCommentsMap[item.ParentCommentID], item)
		}
	}

	res := make([]*bizmodels.Comment, 0)
	for _, item := range comments {
		if !strings.IsEmpty(req.CommentID) {
			if item.CommentID == req.CommentID {
				res = append(res, item)
				break
			}
		} else {
			if strings.IsEmpty(item.ParentCommentID) {
				res = append(res, item)
			}
		}
	}

	// 整体排序
	sortCommentByCreatedTimeAsc(res)

	for _, item := range res {
		allChildComments := gatherAllChildComments(item, subCommentsMap)
		// 子评论排序
		sortCommentByCreatedTimeAsc(allChildComments)
		item.SubCommentList = allChildComments
	}

	resp.CommentList = res
	return resp, nil
}

func (c *serviceImpl) DeleteComment(ctx context.Context, req *bizmodels.DeleteCommentReq) errors.APIError {
	logs.CtxInfo(ctx, "[DeleteComment] req : %s", util.ToJSON(req))
	// 校验评论是否存在
	commentDB, err := c.commentDao.GetCommentByCommentID(ctx, nil, req.CommentID)
	if err != nil {
		logs.CtxWarn(ctx, "[commentDao] GetCommentByCommentID failed, err: %s", err.Error())
		return errors.ErrInternalErrorRaw.WithArgs("query comment failed")
	}

	if commentDB.Sender != req.Operator {
		return errors.ErrRequestInvalid.WithArgs("no permission")
	}

	updates := map[string]interface{}{
		"status": StatusDeleted,
	}
	err = c.commentDao.UpdateCommentByCommentID(ctx, nil, req.CommentID, updates)
	if err != nil {
		logs.CtxWarn(ctx, "[commentDao] UpdateCommentByCommentID failed, err: %s", err.Error())
		return errors.ErrInternalErrorRaw.WithArgs("delete comment failed")
	}

	return nil
}

func (c *serviceImpl) PublishComment(ctx context.Context, req *bizmodels.PublishCommentReq) (*bizmodels.PublishCommentResp, errors.APIError) {
	logs.CtxInfo(ctx, "[PublishComment] req : %s", util.ToJSON(req))
	resp := &bizmodels.PublishCommentResp{}

	if apiErr := checkRelatedID(ctx, req.CommentScene, req.RelatedID); apiErr != nil {
		logs.CtxWarn(ctx, "[checkRelatedID] failed, err: %s", apiErr.Error())
		return nil, apiErr
	}

	commentID := idgenerator.GeneratorID("CMT")

	richTextDB := model.ConvertRichTextDB(req.Content)
	commentDB := &model.CommentDB{
		BaseDB: model.BaseDB{
			Status: StatusValid,
		},
		RelatedID:       req.RelatedID,
		CommentScene:    req.CommentScene,
		CommentID:       commentID,
		ParentCommentID: req.ParentCommentID,
		Sender:          req.Sender,
	}

	err := dal.GetDB(ctx).Transaction(func(tx *gorm.DB) error {
		if err := c.richTextDao.Save(ctx, tx, richTextDB); err != nil {
			logs.CtxWarn(ctx, "[richTextDao] Save failed, err: %s", err.Error())
			return fmt.Errorf("save rich text failed")
		}

		commentDB.RichTextID = int64(richTextDB.Id)
		if err := c.commentDao.CreateComment(ctx, tx, commentDB); err != nil {
			logs.CtxWarn(ctx, "[commentDao] CreateComment failed, err: %s", err.Error())
			return fmt.Errorf("create comment failed")
		}

		return nil
	})
	if err != nil {
		logs.CtxWarn(ctx, "[Transaction] failed, err: %s", err.Error())
		return nil, errors.ErrInternalErrorRaw.WithArgs("publish comment failed")
	}

	resp.CommentID = commentID

	return resp, nil
}

func (c *serviceImpl) AddMentionReviewerByCommentID(ctx context.Context, commentID string) error {
	var (
		metaDB      *model.ContractMetaDB
		commentDB   *model.CommentDB
		richTextDB  *model.RichText
		mentionList []string
		err         error
	)
	// 获取评论信息
	commentDB, err = c.commentDao.GetCommentByCommentID(ctx, nil, commentID)
	if err != nil {
		logs.CtxError(ctx, "getCommentByCommentIDFail, err : %v", err)
		return err
	}
	if commentDB == nil {
		logs.CtxError(ctx, "getCommentByCommentID[%s], comment not find", commentID)
		return fmt.Errorf("comment not find")
	}
	// 获取评论关联合同信息
	metaID, _ := strconv.ParseInt(commentDB.RelatedID, 10, 64)
	metaDB, err = c.metaDao.FindByID(ctx, nil, metaID)
	if err != nil {
		logs.CtxError(ctx, "getContractMetaByIDFail, err : %v", err)
		return err
	}
	if metaDB == nil {
		logs.CtxError(ctx, "getContractMetaByID[%d], meta not find", metaID)
		return fmt.Errorf("meta not find")
	}
	// 获取评论富文本信息
	richTextDB, err = c.richTextDao.GetByID(ctx, nil, commentDB.RichTextID)
	if err != nil {
		logs.CtxError(ctx, "getRichTextByIDFail, err : %v", err)
		return err
	}
	if richTextDB == nil {
		logs.CtxError(ctx, "getRichTextByID[%d], richText not find", commentDB.RichTextID)
		return fmt.Errorf("richText not find")
	}
	// 评论中提及的人
	if len(richTextDB.MentionList) > 0 {
		mentionList = stringsV1.Split(richTextDB.MentionList, ",")
	}
	// 无提及的人，不增加审核人，直接返回即可
	if len(mentionList) == 0 {
		logs.CtxInfo(ctx, "comment[%d], mentionList is empty", commentID)
		return nil
	}
	// 增加审核人，角色为被提及的人
	if err = c.createMentionReviewers(ctx, metaDB, mentionList); err != nil {
		logs.CtxError(ctx, "createMentionReviewersFail, err : %v", err)
		return err
	}
	return nil
}

func (c *serviceImpl) createMentionReviewers(ctx context.Context, metaDB *model.ContractMetaDB, mentionList []string) error {
	var (
		reviewers       []*model.PreContractReviewerDB
		entityList      []*model.PreContractReviewerDB
		reviewerMapping = map[string]*model.PreContractReviewerDB{}
		err             error
	)
	// 修改审批表 将被艾特的人员添加到审批列表中 首先查询当前用户是否在艾特列表中
	reviewers, err = c.reviewerDao.FindReviewersByNoAndReviewerType(ctx, nil, []string{metaDB.ContractNo}, _const.ReviewerTypeMentioned)
	if err != nil {
		logs.CtxError(ctx, "FindReviewersByNoAndReviewerTypeFail, err:%s", err.Error())
		return err
	}
	for _, v := range reviewers {
		reviewerMapping[v.Reviewer] = v
	}
	for _, v := range mentionList {
		_, exist := reviewerMapping[v]
		if !exist {
			// 新建
			employee, err := larkc.GetEmployeeByMail(ctx, v)
			if err != nil {
				logs.CtxError(ctx, "GetEmployeeByMailFail, email:%s, err:%s", v, err)
				continue
			}
			if employee == nil {
				logs.CtxWarn(ctx, "EmployeeNotExist, email:%s", v)
				continue
			}
			entityList = append(entityList, &model.PreContractReviewerDB{
				PreContractNo:  metaDB.ContractNo,
				Reviewer:       employee[0].Email,
				ReviewerID:     strconv.Itoa(employee[0].ID),
				ReviewerType:   _const.ReviewerTypeMentioned,
				ContractStatus: 0, // 被艾特人员忽略审批
			})
		}
	}
	if err = c.reviewerDao.BatchCreate(ctx, nil, entityList); err != nil {
		logs.CtxError(ctx, "CreateReviewerFail, err:%s", err.Error())
		return err
	}
	return nil
}

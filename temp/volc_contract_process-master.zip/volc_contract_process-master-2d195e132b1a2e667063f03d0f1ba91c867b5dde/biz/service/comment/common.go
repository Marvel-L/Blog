package comment

import (
	"context"
	"sort"
	"strconv"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/errors"
)

// sortCommentByCreatedTimeAsc 按照创建时间升序排序（优先看创建时间，其次看ID，确保排序的稳定性）
func sortCommentByCreatedTimeAsc(comments []*bizmodels.Comment) {
	if len(comments) == 0 {
		return
	}

	sort.Slice(comments, func(i, j int) bool {
		if comments[i].CreatedTime == comments[j].CreatedTime {
			return comments[i].ID < comments[j].ID
		}

		return comments[i].CreatedTime < comments[j].CreatedTime
	})
}

func checkRelatedID(ctx context.Context, commentScene int, relatedID string) errors.APIError {
	switch commentScene {
	case CommentSceneContractPage:
		return checkMetaID(ctx, relatedID)
	}

	return errors.ErrRequestInvalid.WithArgs("unknown comment scene")
}

func checkMetaID(ctx context.Context, metaID string) errors.APIError {
	id, err := strconv.ParseInt(metaID, 10, 64)
	if err != nil {
		return errors.ErrRequestInvalid.WithArgs("invalid related_id")
	}

	meta, err := svc.metaDao.FindByID(ctx, nil, id)
	if err != nil {
		return errors.ErrInternalErrorRaw.WithArgs("query contract failed")
	}

	if meta == nil {
		return errors.ErrRequestInvalid.WithArgs("contract not exist")
	}

	return nil
}

func gatherAllChildComments(curr *bizmodels.Comment, subCommentsMap map[string][]*bizmodels.Comment) []*bizmodels.Comment {
	subComments, ok := subCommentsMap[curr.CommentID]
	if !ok || len(subComments) == 0 {
		return []*bizmodels.Comment{}
	}

	var ret []*bizmodels.Comment
	ret = append(ret, subComments...)

	for _, item := range subComments {
		ret = append(ret, gatherAllChildComments(item, subCommentsMap)...)
	}

	return ret
}

package comment

const (
	StatusValid   = 1
	StatusDeleted = 0
)

const (
	CommentSceneContractPage = 1
)

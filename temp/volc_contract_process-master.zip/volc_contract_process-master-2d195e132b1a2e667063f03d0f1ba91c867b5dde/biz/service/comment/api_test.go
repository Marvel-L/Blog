package comment

import (
	"context"
	"fmt"
	"testing"

	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/support/richtext"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/idgenerator"
	"volc_contract_process/pkg/proxy/larkc"
)

func Test_ListComment(t *testing.T) {
	ctx := context.Background()
	richTextService := richtext.NewService()
	c := &serviceImpl{
		metaDao:         dal.NewContractMetaDao(),
		commentDao:      dal.NewCommentDao(),
		richTextDao:     dal.NewRichTextDao(),
		richTextService: richTextService,
	}
	mockGetRichTextMapByIDs := GetMethod(c.richTextService, "GetRichTextMapByIDs")
	req := &bizmodels.ListCommentReq{RelatedID: "123", CommentID: "456"}
	PatchConvey("Test ListCommentByRelatedID failed", t, func() {
		Mock(GetMethod(c.commentDao, "ListCommentByRelatedID")).Return(nil, fmt.Errorf("query comment failed")).Build()
		Mock(mockGetRichTextMapByIDs).Return(map[int]*bizmodels.RichTextInfo{}, nil).Build()
		resp, err := c.ListComment(ctx, req)
		So(resp, ShouldBeNil)
		So(err, ShouldNotBeNil)
	})
	PatchConvey("Test ListCommentByRelatedID success", t, func() {
		Mock(GetMethod(c.commentDao, "ListCommentByRelatedID")).Return([]*model.CommentDB{
			{BaseDB: model.BaseDB{Id: 1, Status: StatusValid}, RelatedID: "123", CommentID: "456", ParentCommentID: "", RichTextID: 1},
			{BaseDB: model.BaseDB{Id: 2, Status: StatusValid}, RelatedID: "123", CommentID: "789", ParentCommentID: "456", RichTextID: 2},
		}, nil).Build()
		PatchConvey("Test GetRichTextMapByIDs failed", func() {
			Mock(mockGetRichTextMapByIDs).Return(map[int]*bizmodels.RichTextInfo{}, fmt.Errorf("GetRichTextMapByIDsFail")).Build()
			resp, err := c.ListComment(ctx, req)
			So(resp, ShouldBeNil)
			So(err, ShouldNotBeNil)
		})
		PatchConvey("Test ListByIds success", func() {
			Mock(mockGetRichTextMapByIDs).Return(map[int]*bizmodels.RichTextInfo{}, nil).Build()
			PatchConvey("Test sub comments and parent comments", func() {
				resp, err := c.ListComment(ctx, req)
				So(err, ShouldBeNil)
				So(resp.CommentList, ShouldHaveLength, 1)
				So(resp.CommentList[0].CommentID, ShouldEqual, "456")
				So(resp.CommentList[0].SubCommentList, ShouldHaveLength, 1)
				So(resp.CommentList[0].SubCommentList[0].CommentID, ShouldEqual, "789")
			})
			PatchConvey("Test specific comment ID", func() {
				req.CommentID = "789"
				resp, err := c.ListComment(ctx, req)
				So(err, ShouldBeNil)
				So(resp.CommentList, ShouldHaveLength, 1)
				So(resp.CommentList[0].CommentID, ShouldEqual, "789")
			})
			PatchConvey("Test no specific comment ID", func() {
				req.CommentID = ""
				resp, err := c.ListComment(ctx, req)
				So(err, ShouldBeNil)
				So(resp.CommentList, ShouldHaveLength, 1)
				So(resp.CommentList[0].CommentID, ShouldEqual, "456")
			})
		})
	})
}

func Test_DeleteComment(t *testing.T) {
	ctx := context.Background()
	c := &serviceImpl{
		metaDao:     dal.NewContractMetaDao(),
		commentDao:  dal.NewCommentDao(),
		richTextDao: dal.NewRichTextDao(),
	}
	req := &bizmodels.DeleteCommentReq{
		CommentID: "123",
		Operator:  "user1",
	}
	PatchConvey("Test GetCommentByCommentID failed", t, func() {
		Mock(GetMethod(c.commentDao, "GetCommentByCommentID")).Return(nil, fmt.Errorf("get comment failed")).Build()
		actual := c.DeleteComment(ctx, req)
		So(actual, ShouldNotBeNil)
	})
	PatchConvey("Test comment found but no permission", t, func() {
		commentDB := &model.CommentDB{
			Sender: "user2",
		}
		Mock(GetMethod(c.commentDao, "GetCommentByCommentID")).Return(commentDB, nil).Build()
		actual := c.DeleteComment(ctx, req)
		So(actual, ShouldNotBeNil)
	})
	PatchConvey("Test comment found and has permission", t, func() {
		commentDB := &model.CommentDB{
			Sender: "user1",
		}
		Mock(GetMethod(c.commentDao, "GetCommentByCommentID")).Return(commentDB, nil).Build()
		Mock(GetMethod(c.commentDao, "UpdateCommentByCommentID")).Return(fmt.Errorf("update comment failed")).Build()
		actual := c.DeleteComment(ctx, req)
		So(actual, ShouldNotBeNil)
	})
	PatchConvey("Test comment found and has permission, update success", t, func() {
		commentDB := &model.CommentDB{
			Sender: "user1",
		}
		Mock(GetMethod(c.commentDao, "GetCommentByCommentID")).Return(commentDB, nil).Build()
		Mock(GetMethod(c.commentDao, "UpdateCommentByCommentID")).Return(nil).Build()
		actual := c.DeleteComment(ctx, req)
		So(actual, ShouldBeNil)
	})
}

func Test_PublishComment(t *testing.T) {
	ctx := context.Background()
	req := &bizmodels.PublishCommentReq{
		RelatedID:       "123",
		CommentScene:    1,
		ParentCommentID: "",
		Content: &bizmodels.RichTextInfo{
			ID:                0,
			Richtext:          "{\"text\": \"Hello, World!\"}",
			RichtextPlainText: "Hello, World!",
			MentionUserList:   []string{"user1", "user2"},
			AttachmentList:    []*bizmodels.FileVersionData{},
			ImageIdList:       []string{"img1", "img2"},
			ImageInfoList:     []bizmodels.ImageInfo{},
		},
		Sender: "user3",
	}

	PatchConvey("Test checkRelatedID failed", t, func() {
		req.CommentScene = 0
		resp, apiErr := (&serviceImpl{}).PublishComment(ctx, req)
		So(resp, ShouldBeNil)
		So(apiErr, ShouldNotBeNil)
	})

	PatchConvey("Test transaction success", t, func() {
		c := &serviceImpl{
			metaDao:     dal.NewContractMetaDao(),
			commentDao:  dal.NewCommentDao(),
			richTextDao: dal.NewRichTextDao(),
		}
		req.CommentScene = 1
		Mock(checkMetaID).Return(nil).Build()
		Mock(idgenerator.GeneratorID).Return("CMT123").Build()
		Mock(dal.GetDB).Return(&gorm.DB{}).Build()
		Mock((*gorm.DB).Transaction).Return(nil).Build()
		resp, apiErr := c.PublishComment(ctx, req)
		So(resp, ShouldNotBeNil)
		So(apiErr, ShouldBeNil)
	})
}

func Test_commentServiceImpl_AddMentionReviewerByCommentID(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err, ShouldBeNil)
		})
	})
	t.Run("case GetCommentByCommentIDFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, fmt.Errorf("GetCommentByCommentIDFail")).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "GetCommentByCommentIDFail")
		})
	})
	t.Run("case commentDB == nil", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(nil, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "comment not find")
		})
	})
	t.Run("case FindMetaByIDFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, fmt.Errorf("FindMetaByIDFail")).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "FindMetaByIDFail")
		})
	})
	t.Run("case metaDB == nil", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(nil, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "meta not find")
		})
	})
	t.Run("case getRichTextByIDFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, fmt.Errorf("getRichTextByIDFail")).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "getRichTextByIDFail")
		})
	})
	t.Run("case richTextDB == nil", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(nil, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "richText not find")
		})
	})
	t.Run("case len(mentionList) == 0", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err, ShouldBeNil)
		})
	})
	t.Run("case createMentionReviewersFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			metaDao := dal.NewContractMetaDao()
			commentDao := dal.NewCommentDao()
			richTextDao := dal.NewRichTextDao()
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			Mock(GetMethod(commentDao, "GetCommentByCommentID")).Return(&model.CommentDB{
				RelatedID:  "123321",
				RichTextID: 1112,
			}, nil).Build()
			Mock(GetMethod(metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			Mock(GetMethod(richTextDao, "GetByID")).Return(&model.RichText{
				MentionList: "test@email",
			}, nil).Build()
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{
				ID:    123123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).Return(nil).Build()
			Mock((*serviceImpl).createMentionReviewers).Return(fmt.Errorf("createMentionReviewersFail")).Build()

			// Act
			v31 := &serviceImpl{
				metaDao:     metaDao,
				commentDao:  commentDao,
				richTextDao: richTextDao,
				reviewerDao: reviewerDao,
			}
			err := v31.AddMentionReviewerByCommentID(context.Background(), "CMT123")

			// Assert
			So(err.Error(), ShouldEqual, "createMentionReviewersFail")
		})
	})
}

func Test_commentServiceImpl_createMentionReviewers(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		PatchConvey("", t, func() {
			reviewerDao := dal.NewPreContractReviewerDao()
			var mentionReviewers []*model.PreContractReviewerDB
			// Arrange
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{&peopleclient.Employee{
				ID:    123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
				mentionReviewers = entities
				return nil
			}).Build()

			// Act
			v13 := &serviceImpl{
				reviewerDao: reviewerDao,
			}
			err := v13.createMentionReviewers(context.Background(), &model.ContractMetaDB{
				ContractNo: "CTXXXX01",
			}, []string{""})

			// Assert
			So(err, ShouldBeNil)
			So(mentionReviewers, ShouldResemble, []*model.PreContractReviewerDB{{
				PreContractNo:  "CTXXXX01",
				Reviewer:       "test@email",
				ReviewerID:     "123",
				ReviewerType:   _const.ReviewerTypeMentioned,
				ContractStatus: 0, // 被艾特人员忽略审批
			}})
		})
	})
	t.Run("case FindReviewersByNoAndReviewerTypeFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, fmt.Errorf("FindReviewersByNoAndReviewerTypeFail")).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{&peopleclient.Employee{
				ID:    123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
				return nil
			}).Build()

			// Act
			v13 := &serviceImpl{
				reviewerDao: reviewerDao,
			}
			err := v13.createMentionReviewers(context.Background(), &model.ContractMetaDB{
				ContractNo: "CTXXXX01",
			}, []string{""})

			// Assert
			So(err.Error(), ShouldEqual, "FindReviewersByNoAndReviewerTypeFail")
		})
	})
	t.Run("case BatchCreateFail", func(t *testing.T) {
		PatchConvey("", t, func() {
			reviewerDao := dal.NewPreContractReviewerDao()
			// Arrange
			var v = model.PreContractReviewerDBList([]*model.PreContractReviewerDB{{
				Reviewer: "test@email",
			}})
			Mock(GetMethod(reviewerDao, "FindReviewersByNoAndReviewerType")).Return(v, nil).Build()
			Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{&peopleclient.Employee{
				ID:    123,
				Email: "test@email",
			}}, nil).Build()
			Mock(GetMethod(reviewerDao, "BatchCreate")).To(func(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
				return fmt.Errorf("BatchCreateFail")
			}).Build()

			// Act
			v13 := &serviceImpl{
				reviewerDao: reviewerDao,
			}
			err := v13.createMentionReviewers(context.Background(), &model.ContractMetaDB{
				ContractNo: "CTXXXX01",
			}, []string{""})

			// Assert
			So(err.Error(), ShouldEqual, "BatchCreateFail")
		})
	})
}

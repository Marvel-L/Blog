package comment

import (
	"context"
	"fmt"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/dal/model"
)

func Test_checkMetaID(t *testing.T) {
	ctx := context.Background()

	PatchConvey("Test ParseInt failed", t, func() {
		metaID := "sdasdas"
		actual := checkMetaID(ctx, metaID)
		So(actual, ShouldNotBeNil)
	})

	PatchConvey("Test ParseInt success", t, func() {
		metaID := "12345"
		PatchConvey("Test FindByID failed", func() {
			Mock(GetMethod(svc.metaDao, "FindByID")).Return(nil, fmt.Errorf("find by id error")).Build()
			actual := checkMetaID(ctx, metaID)
			So(actual, ShouldNotBeNil)
		})
		PatchConvey("Test FindByID success but meta is nil", func() {
			Mock(GetMethod(svc.metaDao, "FindByID")).Return(nil, nil).Build()
			actual := checkMetaID(ctx, metaID)
			So(actual, ShouldNotBeNil)
		})
		PatchConvey("Test FindByID success and meta is not nil", func() {
			Mock(GetMethod(svc.metaDao, "FindByID")).Return(&model.ContractMetaDB{}, nil).Build()
			actual := checkMetaID(ctx, metaID)
			So(actual, ShouldBeNil)
		})
	})
}

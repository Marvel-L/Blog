package basicinfo

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/bizmodels/metabasic"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/preload"
	"volc_contract_process/pkg/proxy/mdcli"
	"volc_contract_process/pkg/proxy/tradebalancecli"
	"volc_contract_process/pkg/proxy/tradefundingcli"
	"volc_contract_process/pkg/util"
)

func GetDepartmentFromBasicInfo(basicInfo *bizmodels.BasicInfo) string {
	if basicInfo.DepartmentId != "" {
		name := preload.ReviewRuleID2Name(basicInfo.DepartmentId)
		return name
	}
	return basicInfo.Department
}

// ParseBasicInfo 解析 注意必须返回值
func ParseBasicInfo(ctx context.Context, str string) (*bizmodels.BasicInfo, error) {
	var info bizmodels.BasicInfo
	if err := json.Unmarshal([]byte(str), &info); err != nil {
		logs.CtxError(ctx, "parseBasicInfoFail, basicInfo:%s, err:%s", str, err.Error())
		return &info, errors.ErrorCommon.WithArgs("basic_info parse fail")
	}
	if info.DepartmentId != "" { // 响应时将归属行业ID对应的归属行业中文名补全-前提是DB历史数据已刷新
		info.Department = preload.ReviewRuleID2Name(info.DepartmentId)
	} else if info.Department != "" { // 将归属行业中文名转换为归属行业ID
		info.DepartmentId = preload.ReviewRuleName2ID(info.Department)
	}
	return &info, nil
}

// CheckCurrencyAndExchangeRate 校验币种、汇率信息是否一致
func CheckCurrencyAndExchangeRate(ctx context.Context, req *metabasic.CheckCurrencyAndExchangeRateReq) (*metabasic.CheckCurrencyAndExchangeRateResp, errors.APIError) {
	list, err := ListExchangeRateData(ctx, req.AccountIDs)
	if err != nil {
		logs.CtxError(ctx, "ListExchangeRateDataFail, err:%v", err)
		return &metabasic.CheckCurrencyAndExchangeRateResp{}, err
	}
	currencyCode := req.CurrencyCode
	// 如果是 MDCR 开头的，字段存储的是主数据编码，需要查询主数据获取币种二字码
	if strings.HasPrefix(currencyCode, "MDCR") {
		currencyData, _ := mdcli.QueryCurrencyByNameOrCode(ctx, currencyCode)
		if currencyData != nil {
			currencyCode = currencyData.Code
		}
	}
	// 校验币种、汇率信息是否一致
	isSame, diff := IsSameCurrencyAndExchangeRate(ctx, &metabasic.CurrencyAndExchangeRateData{
		CurrencyCode:     currencyCode,
		ExchangeRateType: req.ExchangeRateType,
		ExchangeRate:     req.ExchangeRate,
	}, list)
	return &metabasic.CheckCurrencyAndExchangeRateResp{
		Agree: isSame,
		CurrentData: metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     currencyCode,
			ExchangeRateType: req.ExchangeRateType,
			ExchangeRate:     req.ExchangeRate,
		},
		List: diff,
	}, nil
}

// ListExchangeRateData 列表查询汇率信息
func ListExchangeRateData(ctx context.Context, accountIDs []string) ([]*metabasic.CurrencyAndExchangeRateData, errors.APIError) {
	if len(accountIDs) == 0 {
		return nil, errors.ErrorCommon.WithArgs("查询汇率信息失败，账号为空")
	}
	var res []*metabasic.CurrencyAndExchangeRateData
	// 国内默认人民币，不返回汇率信息
	if !env.IsBytePlus() {
		for _, accountID := range accountIDs {
			res = append(res, &metabasic.CurrencyAndExchangeRateData{
				AccountID:    accountID,
				CurrencyCode: _const.CurrencyCNY,
			})
		}
		return res, nil
	}
	// 查询生效币种
	uid2CurrencyMap, err := tradebalancecli.ListBalanceCurrency(ctx, util.StrSliceToInt64(accountIDs))
	if err != nil {
		logs.CtxError(ctx, "GetCurrencyFail, err:%v", err)
		return nil, errors.ErrorCommon.WithArgs("查询币种信息失败")
	}
	if len(uid2CurrencyMap) != len(accountIDs) {
		logs.CtxError(ctx, "获取币种数量异常, uid2CurrencyMap:%v", uid2CurrencyMap)
		return nil, errors.ErrorCommon.WithArgs("查询币种信息失败")
	}
	// 查询汇率信息
	for uid, currencyCode := range uid2CurrencyMap {
		resp, err := tradefundingcli.QueryExchangeRate(ctx, int64(uid), currencyCode)
		if err != nil {
			return nil, errors.ErrorCommon.WithArgs("查询汇率信息失败")
		}
		res = append(res, &metabasic.CurrencyAndExchangeRateData{
			AccountID:        strconv.Itoa(int(uid)),
			CurrencyCode:     currencyCode,
			ExchangeRateType: int(resp.Source),
			ExchangeRate:     resp.ExchangeRate,
		})
	}
	return res, nil
}

// ClacQuoteSpecialContractType 预处理特殊合同类型
func ClacQuoteSpecialContractType(ctx context.Context, preQuoteNo, defQuoteNo, preSpecialContractType, defSpecialContractType string) string {
	var (
		preSpecialContractTypes = strings.Split(preSpecialContractType, ",")
		defSpecialContractTypes = strings.Split(defSpecialContractType, ",")
		res                     []string
	)
	// 若合同变更前后，均未关联报价单不需要特殊处理
	if len(preQuoteNo) == 0 && len(defQuoteNo) == 0 {
		logs.CtxInfo(ctx, "clacQuoteSpecialContractType, 合同变更前后，均未关联报价单不需要特殊处理")
		return defSpecialContractType
	}
	// 提取出更新后数据中，非通过报价单赋值的特殊合同类型
	for _, contractType := range defSpecialContractTypes {
		if !util.StringIn(contractType, _const.QuoteSpecialContractTypeList) {
			res = append(res, contractType)
		}
	}

	// 若关联报价单发生变更时，需清空通过报价单赋值的特殊合同类型
	if !strings.EqualFold(preQuoteNo, defQuoteNo) {
		logs.CtxInfo(ctx, "clacQuoteSpecialContractType, 关联报价单发生变更，需清空通过报价单赋值的特殊合同类型, p.RelateQuoteNo=%s, specialContractType=%s", preSpecialContractType, defSpecialContractType)
		return strings.Join(res, ",")
	}
	// 关联报价单未发生变更时，通过报价单赋值的特殊合同类型不允许修改
	// 提取出更新前数据中，通过报价单赋值的特殊合同类型
	// 拼接更新后非报价单赋值的特殊合同类型
	for _, contractType := range preSpecialContractTypes {
		if util.StringIn(contractType, _const.QuoteSpecialContractTypeList) {
			res = append(res, contractType)
		}
	}
	return strings.Join(res, ",")
}

// IsSameCurrencyAndExchangeRate 校验币种、汇率信息是否一致
func IsSameCurrencyAndExchangeRate(ctx context.Context, currentData *metabasic.CurrencyAndExchangeRateData, list []*metabasic.CurrencyAndExchangeRateData) (bool, []*metabasic.CurrencyAndExchangeRateData) {
	var (
		diffList = []*metabasic.CurrencyAndExchangeRateData{}
	)
	for _, data := range list {
		// 币种不一致则返回false
		if data.CurrencyCode != currentData.CurrencyCode {
			logs.CtxInfo(ctx, "币种不一致, accountID:%s, ContractCurrencyCode:%s, CurrencyCode:%s",
				data.AccountID, currentData.CurrencyCode, data.CurrencyCode)
			diffList = append(diffList, data)
			continue
		}
		// 若币种一致 且合同关联币种为美元，则返回true
		if util.StringIn(data.CurrencyCode, []string{_const.CurrencyUSD, _const.CurrencyUSDMdCode}) {
			continue
		}
		// 汇率类型不一致则返回false
		if data.ExchangeRateType != currentData.ExchangeRateType {
			logs.CtxInfo(ctx, "汇率形式不一致, accountID:%s, ContractExchangeRateType:%s, ExchangeRateType:%s",
				data.AccountID, currentData.ExchangeRateType, data.ExchangeRateType)
			diffList = append(diffList, data)
			continue
		}
		// 汇率为实时汇率 且 汇率形式一致时，不需要校验汇率是否一致。
		if data.ExchangeRateType == _const.ExchangeRateTypeFloat {
			logs.CtxInfo(ctx, "汇率形式为实时汇率且汇率形式一致, 不校验汇率")
			continue
		}
		// 汇率为固定汇率时，需要校验汇率是否一致。
		if data.ExchangeRate != currentData.ExchangeRate {
			logs.CtxInfo(ctx, "汇率不一致, accountID:%s, ContractExchangeRate:%s, ExchangeRate:%s",
				data.AccountID, currentData.ExchangeRate, data.ExchangeRate)
			diffList = append(diffList, data)
			continue
		}
	}
	return len(diffList) == 0, diffList
}

// FixDepartmentWhenSave 读写操作时 兼容department和DepartmentID
func FixDepartmentWhenSave(basicInfo *bizmodels.BasicInfo) {
	if basicInfo == nil {
		return
	}
	/**
	 * 需要兼容的情况：
	 *  1.将请求参数中的dept统一置为deptId，并置空原始字段——目的是保证DB中basic_info.Department值为空(一期上线前不能将Department置空，新代码要兼容老数据)
	 */
	if basicInfo.DepartmentId == "" && basicInfo.Department != "" {
		basicInfo.DepartmentId = preload.ReviewRuleName2ID(basicInfo.Department)
	}
}

// FixDepartmentWhenQuery 响应时 兼容department和DepartmentID
func FixDepartmentWhenQuery(basicInfo *bizmodels.BasicInfo) {
	if basicInfo == nil {
		return
	}
	/**
	 * 需要兼容的情况：
	 *  1.历史数据未刷新，响应时将dept转换为deptId;
	 *  2.历史数据已刷新，响应时根据deptId补全dept;
	 */
	if basicInfo.DepartmentId != "" {
		basicInfo.Department = preload.ReviewRuleID2Name(basicInfo.DepartmentId)
	} else if basicInfo.Department != "" {
		basicInfo.DepartmentId = preload.ReviewRuleID2Name(basicInfo.Department)
	}
}

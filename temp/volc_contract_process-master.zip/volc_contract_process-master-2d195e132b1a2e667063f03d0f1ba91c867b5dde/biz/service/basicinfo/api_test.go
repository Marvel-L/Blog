package basicinfo

import (
	"context"
	"fmt"
	"testing"

	"code.byted.org/overpass/eps_platform_trade_funding/kitex_gen/eps/platform/trade_funding"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/preload"
	"volc_contract_process/pkg/util"

	"volc_contract_process/biz/bizmodels/metabasic"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/mdcli"
	"volc_contract_process/pkg/proxy/tradebalancecli"
	"volc_contract_process/pkg/proxy/tradefundingcli"

	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
)

func Test_FixDepartmentWhenQuery_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test FixDepartmentWhenQuery", t, func() {
		mockey.PatchConvey("场景1: basicInfo 为 nil", func() {
			// 场景描述：
			// 构造数据：入参 basicInfo 为 nil
			// 逻辑链路：函数直接返回，不应发生 panic
			var basicInfo *bizmodels.BasicInfo = nil
			FixDepartmentWhenQuery(basicInfo)
			convey.So(basicInfo, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: DepartmentId 不为空，根据 DepartmentId 补全 Department", func() {
			// 场景描述：
			// 构造数据：构造一个只有 DepartmentId 的 BasicInfo，模拟历史数据已刷新但缺少 Department 名称的场景。
			// 逻辑链路：
			// 1. Mock preload.ReviewRuleID2Name 函数，使其在接收到 "dept_id_123" 时返回 "Sales Department"。
			// 2. 调用 FixDepartmentWhenQuery。
			// 3. 断言 basicInfo.Department 字段被正确填充为 "Sales Department"。
			basicInfo := &bizmodels.BasicInfo{
				DepartmentId: "dept_id_123",
				Department:   "",
			}

			mockey.Mock(preload.ReviewRuleID2Name).Return("Sales Department").Build()

			FixDepartmentWhenQuery(basicInfo)

			convey.So(basicInfo.Department, convey.ShouldEqual, "Sales Department")
			convey.So(basicInfo.DepartmentId, convey.ShouldEqual, "dept_id_123")
		})

		mockey.PatchConvey("场景3: DepartmentId 为空，根据 Department 补全 DepartmentId", func() {
			// 场景描述：
			// 构造数据：构造一个只有 Department 名称的 BasicInfo，模拟历史数据未刷新，需要将名称转换为 ID 的场景。
			// 逻辑链路：
			// 1. Mock preload.ReviewRuleID2Name 函数，使其在接收到 "Finance Department" 时返回 "dept_id_456"。
			// 2. 调用 FixDepartmentWhenQuery。
			// 3. 断言 basicInfo.DepartmentId 字段被正确填充为 "dept_id_456"。
			basicInfo := &bizmodels.BasicInfo{
				DepartmentId: "",
				Department:   "Finance Department",
			}

			mockey.Mock(preload.ReviewRuleID2Name).Return("dept_id_456").Build()

			FixDepartmentWhenQuery(basicInfo)

			convey.So(basicInfo.Department, convey.ShouldEqual, "Finance Department")
			convey.So(basicInfo.DepartmentId, convey.ShouldEqual, "dept_id_456")
		})

		mockey.PatchConvey("场景4: DepartmentId 和 Department 都为空", func() {
			// 场景描述：
			// 构造数据：构造一个 DepartmentId 和 Department 都为空的 BasicInfo。
			// 逻辑链路：
			// 1. 调用 FixDepartmentWhenQuery。
			// 2. 函数不应执行任何填充逻辑，preload.ReviewRuleID2Name 不应被调用。
			// 3. 断言两个字段都保持为空。
			basicInfo := &bizmodels.BasicInfo{
				DepartmentId: "",
				Department:   "",
			}

			FixDepartmentWhenQuery(basicInfo)

			convey.So(basicInfo.Department, convey.ShouldBeEmpty)
			convey.So(basicInfo.DepartmentId, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("场景5: DepartmentId 和 Department 都不为空，优先根据 DepartmentId 补全 Department", func() {
			// 场景描述：
			// 构造数据：构造一个 DepartmentId 和 Department 都不为空的 BasicInfo，模拟数据可能不一致的场景。
			// 逻辑链路：
			// 1. 函数逻辑会优先处理 DepartmentId 非空的
			// 2. Mock preload.ReviewRuleID2Name 函数，使其根据 DepartmentId 返回正确的 Department 名称 "Correct Department"。
			// 3. 调用 FixDepartmentWhenQuery。
			// 4. 断言 basicInfo.Department 字段被更新为 "Correct Department"。
			basicInfo := &bizmodels.BasicInfo{
				DepartmentId: "dept_id_789",
				Department:   "Old Incorrect Department",
			}

			mockey.Mock(preload.ReviewRuleID2Name).Return("Correct Department").Build()

			FixDepartmentWhenQuery(basicInfo)

			convey.So(basicInfo.Department, convey.ShouldEqual, "Correct Department")
			convey.So(basicInfo.DepartmentId, convey.ShouldEqual, "dept_id_789")
		})

		mockey.PatchConvey("场景6: preload.ReviewRuleID2Name 返回空字符串", func() {
			// 场景描述：
			// 构造数据：构造一个有 DepartmentId 的 BasicInfo，但 preload 中没有对应的映射。
			// 逻辑链路：
			// 1. Mock preload.ReviewRuleID2Name 函数，使其返回空字符串。
			// 2. 调用 FixDepartmentWhenQuery。
			// 3. 断言 basicInfo.Department 字段被设置为空字符串。
			basicInfo := &bizmodels.BasicInfo{
				DepartmentId: "non_existent_id",
				Department:   "Should be cleared",
			}

			mockey.Mock(preload.ReviewRuleID2Name).Return("").Build()

			FixDepartmentWhenQuery(basicInfo)

			convey.So(basicInfo.Department, convey.ShouldBeEmpty)
			convey.So(basicInfo.DepartmentId, convey.ShouldEqual, "non_existent_id")
		})
	})
}

func TestFixDepartmentWhenSave_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test FixDepartmentWhenSave", t, func() {
		mockey.PatchConvey("当 basicInfo 为 nil 时，函数应直接返回", func() {
			// 场景描述：
			// 构造数据：basicInfo 指针为 nil。
			// 逻辑链路：
			// 1. 函数入口检查 basicInfo 是否为 nil。
			// 2. 条件满足，函数直接 return。
			FixDepartmentWhenSave(nil)
			// 无需断言，确保不发生 panic 即可。
		})

		mockey.PatchConvey("当 DepartmentId 不为空时，不进行任何处理", func() {
			// 场景描述：
			// 构造数据：构造一个 basicInfo，其 DepartmentId 字段有值。
			// 逻辑链路：
			// 1. 函数入口检查 basicInfo 不为 nil。
			// 2. 进入第二个 if 条件判断 `basicInfo.DepartmentId == ""`。
			// 3. 条件不满足，函数结束。
			info := &bizmodels.BasicInfo{
				DepartmentId: "existing-dept-id",
				Department:   "some-department",
			}
			originalID := info.DepartmentId

			FixDepartmentWhenSave(info)

			convey.So(info.DepartmentId, convey.ShouldEqual, originalID)
		})

		mockey.PatchConvey("当 DepartmentId 为空但 Department 也为空时，不进行任何处理", func() {
			// 场景描述：
			// 构造数据：构造一个 basicInfo，其 DepartmentId 和 Department 字段均为空。
			// 逻辑链路：
			// 1. 函数入口检查 basicInfo 不为 nil。
			// 2. 进入第二个 if 条件判断 `basicInfo.Department != ""`。
			// 3. 条件不满足，函数结束。
			info := &bizmodels.BasicInfo{
				DepartmentId: "",
				Department:   "",
			}

			FixDepartmentWhenSave(info)

			convey.So(info.DepartmentId, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("当 DepartmentId 为空且 Department 不为空时，调用 preload.ReviewRuleName2ID 更新 DepartmentId", func() {
			// 场景描述：
			// 构造数据：构造一个 basicInfo，其 DepartmentId 为空，但 Department 有值。
			// 逻辑链路：
			// 1. 函数入口检查 basicInfo 不为 nil。
			// 2. 进入第二个 if 条件判断 `basicInfo.DepartmentId == ""` 和 `basicInfo.Department != ""`，条件均满足。
			// 3. Mock preload.ReviewRuleName2ID 函数。
			// 4. 调用 preload.ReviewRuleName2ID 并将其返回值赋给 DepartmentId。
			departmentName := "Test Department"
			expectedDepartmentID := "dept-id-from-name"
			mockey.Mock(preload.ReviewRuleName2ID).When(func(name string) bool {
				return name == departmentName
			}).Return(expectedDepartmentID).Build()

			info := &bizmodels.BasicInfo{
				Department:   departmentName,
				DepartmentId: "",
			}

			FixDepartmentWhenSave(info)

			convey.So(info.DepartmentId, convey.ShouldEqual, expectedDepartmentID)
		})

		mockey.PatchConvey("当 DepartmentId 为空且 Department 不为空，但 preload.ReviewRuleName2ID 返回空字符串时", func() {
			// 场景描述：
			// 构造数据：构造一个 basicInfo，其 DepartmentId 为空，但 Department 有一个无法在 preload 中找到对应 ID 的值。
			// 逻辑链路：
			// 1. 函数入口检查 basicInfo 不为 nil。
			// 2. 进入第二个 if 条件判断，条件满足。
			// 3. Mock preload.ReviewRuleName2ID 函数返回空字符串。
			// 4. 调用 preload.ReviewRuleName2ID 并将其返回的空字符串赋给 DepartmentId。
			departmentName := "Unknown Department"
			mockey.Mock(preload.ReviewRuleName2ID).When(func(name string) bool {
				return name == departmentName
			}).Return("").Build()

			info := &bizmodels.BasicInfo{
				Department:   departmentName,
				DepartmentId: "",
			}

			FixDepartmentWhenSave(info)

			convey.So(info.DepartmentId, convey.ShouldBeEmpty)
		})
	})
}

func Test_CheckCurrencyAndExchangeRate(t *testing.T) {
	ctx := context.Background()
	req := &metabasic.CheckCurrencyAndExchangeRateReq{
		AccountIDs:       []string{"acc1", "acc2"},
		CurrencyCode:     "USD",
		ExchangeRateType: 1,
		ExchangeRate:     "1.2",
	}

	PatchConvey("Test ListExchangeRateData failed", t, func() {
		Mock(ListExchangeRateData).Return(nil, errors.ErrorCommon.WithArgs("failed to list exchange rate data")).Build()
		resp, err := CheckCurrencyAndExchangeRate(ctx, req)
		So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{})
		So(err, ShouldNotBeNil)
	})

	PatchConvey("Test CurrencyCode Prefix is MDCR and QueryCurrencyByNameOrCode success", t, func() {
		req := &metabasic.CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"acc1", "acc2"},
			CurrencyCode:     "MDCRxxxxx01",
			ExchangeRateType: 1,
			ExchangeRate:     "1.2",
		}
		Mock(mdcli.QueryCurrencyByNameOrCode).Return(&mdcli.MDCurrencyData{Code: "USD"}, nil).Build()
		Mock(ListExchangeRateData).Return(nil, errors.ErrorCommon.WithArgs("failed to list exchange rate data")).Build()
		resp, err := CheckCurrencyAndExchangeRate(ctx, req)
		So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{})
		So(err, ShouldNotBeNil)
	})

	PatchConvey("Test ListExchangeRateData success", t, func() {
		mockList := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc1",
				CurrencyCode:     "USD",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
			{
				AccountID:        "acc2",
				CurrencyCode:     "USD",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
		}
		Mock(ListExchangeRateData).Return(mockList, nil).Build()

		PatchConvey("Test IsSameCurrencyAndExchangeRate returns false", func() {
			Mock(IsSameCurrencyAndExchangeRate).Return(false, mockList).Build()
			resp, err := CheckCurrencyAndExchangeRate(ctx, req)
			So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
				Agree: false,
				CurrentData: metabasic.CurrencyAndExchangeRateData{
					CurrencyCode:     req.CurrencyCode,
					ExchangeRateType: req.ExchangeRateType,
					ExchangeRate:     req.ExchangeRate,
				},
				List: mockList,
			})
			So(err, ShouldBeNil)
		})

		PatchConvey("Test IsSameCurrencyAndExchangeRate returns true", func() {
			Mock(IsSameCurrencyAndExchangeRate).Return(true, []*metabasic.CurrencyAndExchangeRateData{}).Build()
			resp, err := CheckCurrencyAndExchangeRate(ctx, req)
			So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
				Agree: true,
				CurrentData: metabasic.CurrencyAndExchangeRateData{
					CurrencyCode:     req.CurrencyCode,
					ExchangeRateType: req.ExchangeRateType,
					ExchangeRate:     req.ExchangeRate,
				},
				List: []*metabasic.CurrencyAndExchangeRateData{},
			})
			So(err, ShouldBeNil)
		})
	})
}

func Test_ListExchangeRateData(t *testing.T) {
	ctx := context.Background()
	accountIDs := []string{"123", "456"}

	PatchConvey("Test empty accountIDs", t, func() {
		actual, err := ListExchangeRateData(ctx, []string{})
		So(actual, ShouldBeNil)
		So(err, ShouldNotBeNil)
	})

	PatchConvey("Test non-BytePlus environment", t, func() {
		Mock(env.IsBytePlus).Return(false).Build()
		expectedResp := []*metabasic.CurrencyAndExchangeRateData{
			{AccountID: "123", CurrencyCode: _const.CurrencyCNY},
			{AccountID: "456", CurrencyCode: _const.CurrencyCNY},
		}
		actual, err := ListExchangeRateData(ctx, accountIDs)
		So(actual, ShouldResemble, expectedResp)
		So(err, ShouldBeNil)
	})

	PatchConvey("Test BytePlus environment", t, func() {
		Mock(env.IsBytePlus).Return(true).Build()

		PatchConvey("Test ListBalanceCurrency failed", func() {
			Mock(tradebalancecli.ListBalanceCurrency).Return(nil, fmt.Errorf("ListBalanceCurrency failed")).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
		})

		PatchConvey("Test ListBalanceCurrency returns incorrect length", func() {
			Mock(tradebalancecli.ListBalanceCurrency).Return(map[int64]string{123: "USD"}, nil).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
		})

		PatchConvey("Test QueryExchangeRate failed", func() {
			uid2CurrencyMap := map[int64]string{123: "USD", 456: "EUR"}
			Mock(tradebalancecli.ListBalanceCurrency).Return(uid2CurrencyMap, nil).Build()
			Mock(tradefundingcli.QueryExchangeRate).Return(nil, fmt.Errorf("QueryExchangeRate failed")).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
		})

		PatchConvey("Test QueryExchangeRate success", func() {
			uid2CurrencyMap := map[int64]string{123: "USD", 456: "EUR"}
			Mock(tradebalancecli.ListBalanceCurrency).Return(uid2CurrencyMap, nil).Build()
			Mock(tradefundingcli.QueryExchangeRate).Return(&trade_funding.QueryExchangeRateResp{ExchangeRate: "1.2", Source: 1}, nil).Build()
			expectedStrList := []string{
				"123, USD, 1.2, 1",
				"456, EUR, 1.2, 1",
			}
			actual, err := ListExchangeRateData(ctx, accountIDs)
			for _, item := range actual {
				actualStr := fmt.Sprintf("%s, %s, %s, %d", item.AccountID, item.CurrencyCode, item.ExchangeRate, item.ExchangeRateType)
				So(actualStr, ShouldBeIn, expectedStrList)
			}
			So(err, ShouldBeNil)
		})
	})
}

func Test_IsSameCurrencyAndExchangeRate(t *testing.T) {
	ctx := context.Background()
	currentData := &metabasic.CurrencyAndExchangeRateData{
		AccountID:        "acc123",
		CurrencyCode:     "USD",
		ExchangeRateType: 1,
		ExchangeRate:     "1.2",
	}

	PatchConvey("Test currency code mismatch", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc456",
				CurrencyCode:     "EUR",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, list)
	})

	PatchConvey("Test currency code is USD", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc123",
				CurrencyCode:     "USD",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})
	currentData = &metabasic.CurrencyAndExchangeRateData{
		AccountID:        "acc123",
		CurrencyCode:     "EUR",
		ExchangeRateType: 1,
		ExchangeRate:     "1.2",
	}
	PatchConvey("Test exchange rate type mismatch", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc456",
				CurrencyCode:     "EUR",
				ExchangeRateType: 2,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, list)
	})

	PatchConvey("Test exchange rate type is float", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc456",
				CurrencyCode:     "EUR",
				ExchangeRateType: _const.ExchangeRateTypeFloat,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test exchange rate mismatch for fixed rate", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc123",
				CurrencyCode:     "EUR",
				ExchangeRateType: 1,
				ExchangeRate:     "1.3",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test all conditions match", t, func() {
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc456",
				CurrencyCode:     "EUR",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})
}

func Test_ListExchangeRateData_BitsUTGen(t *testing.T) {
	ctx := context.Background()
	accountIDs := []string{"123", "456"}

	PatchConvey("Test empty accountIDs", t, func() {
		actual, err := ListExchangeRateData(ctx, []string{})
		So(actual, ShouldBeNil)
		So(err, ShouldNotBeNil)
		So(err.Error(), ShouldContainSubstring, "查询汇率信息失败，账号为空")
	})

	PatchConvey("Test non-BytePlus environment", t, func() {
		Mock(env.IsBytePlus).Return(false).Build()
		expectedResp := []*metabasic.CurrencyAndExchangeRateData{
			{AccountID: "123", CurrencyCode: _const.CurrencyCNY},
			{AccountID: "456", CurrencyCode: _const.CurrencyCNY},
		}
		actual, err := ListExchangeRateData(ctx, accountIDs)
		So(err, ShouldBeNil)
		So(actual, ShouldResemble, expectedResp)
	})

	PatchConvey("Test BytePlus environment", t, func() {
		Mock(env.IsBytePlus).Return(true).Build()

		PatchConvey("Test ListBalanceCurrency failed", func() {
			Mock(tradebalancecli.ListBalanceCurrency).Return(nil, fmt.Errorf("ListBalanceCurrency failed")).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "查询币种信息失败")
		})

		PatchConvey("Test ListBalanceCurrency returns incorrect length", func() {
			Mock(tradebalancecli.ListBalanceCurrency).Return(map[int64]string{123: "USD"}, nil).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "查询币种信息失败")
		})

		PatchConvey("Test QueryExchangeRate failed", func() {
			uid2CurrencyMap := map[int64]string{123: "USD", 456: "EUR"}
			Mock(tradebalancecli.ListBalanceCurrency).Return(uid2CurrencyMap, nil).Build()
			Mock(tradefundingcli.QueryExchangeRate).Return(nil, fmt.Errorf("QueryExchangeRate failed")).Build()
			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(actual, ShouldBeNil)
			So(err, ShouldNotBeNil)
			So(err.Error(), ShouldContainSubstring, "查询汇率信息失败")
		})

		PatchConvey("Test QueryExchangeRate success", func() {
			uid2CurrencyMap := map[int64]string{123: "USD", 456: "EUR"}
			Mock(tradebalancecli.ListBalanceCurrency).Return(uid2CurrencyMap, nil).Build()

			// Mock QueryExchangeRate to return different values based on input uid to make the test more robust
			Mock(tradefundingcli.QueryExchangeRate).
				When(func(_ context.Context, uid int64, currencyCode string) bool { return uid == 123 }).
				Return(&trade_funding.QueryExchangeRateResp{ExchangeRate: "1.23", Source: 1}, nil).
				When(func(_ context.Context, uid int64, currencyCode string) bool { return uid == 456 }).
				Return(&trade_funding.QueryExchangeRateResp{ExchangeRate: "0.98", Source: 2}, nil).
				Build()

			expectedStrList := []string{
				"123, USD, 1.23, 1",
				"456, EUR, 0.98, 2",
			}

			actual, err := ListExchangeRateData(ctx, accountIDs)
			So(err, ShouldBeNil)
			// Add a length check to ensure the result set is complete
			So(len(actual), ShouldEqual, len(expectedStrList))

			// Check that each actual item is in the expected list to handle non-deterministic order
			for _, item := range actual {
				actualStr := fmt.Sprintf("%s, %s, %s, %d", item.AccountID, item.CurrencyCode, item.ExchangeRate, item.ExchangeRateType)
				So(actualStr, ShouldBeIn, expectedStrList)
			}
		})
	})
}

func Test_IsSameCurrencyAndExchangeRate_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	PatchConvey("Test currency code mismatch", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "USD",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "1.0",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_diff_currency",
				CurrencyCode:     "EUR", // Mismatch
				ExchangeRateType: _const.ExchangeRateTypeFixed,
				ExchangeRate:     "1.0",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, list)
	})

	PatchConvey("Test when currency is USD, should always be true", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode: "USD",
			// Other fields are intentionally different to prove they are ignored
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "1.0",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_usd",
				CurrencyCode:     "USD",
				ExchangeRateType: _const.ExchangeRateTypeFloat,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test when currency is USD MD Code, should always be true", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode: _const.CurrencyUSDMdCode,
			// Other fields are intentionally different
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "1.0",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_usd_md",
				CurrencyCode:     _const.CurrencyUSDMdCode,
				ExchangeRateType: _const.ExchangeRateTypeFloat,
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test exchange rate type mismatch for non-USD currency", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFixed, // Type 2
			ExchangeRate:     "1.2",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_diff_type",
				CurrencyCode:     "EUR",
				ExchangeRateType: _const.ExchangeRateTypeFloat, // Type 1, mismatch
				ExchangeRate:     "1.2",
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, list)
	})

	PatchConvey("Test float exchange rate type matches regardless of rate value", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFloat, // Type 1
			ExchangeRate:     "1.2",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_float_rate",
				CurrencyCode:     "EUR",
				ExchangeRateType: _const.ExchangeRateTypeFloat, // Type 1, match
				ExchangeRate:     "9.9",                        // Different rate, but should be ignored
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test exchange rate mismatch for fixed rate", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFixed, // Type 2
			ExchangeRate:     "1.2",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_fixed_rate_mismatch",
				CurrencyCode:     "EUR",
				ExchangeRateType: _const.ExchangeRateTypeFixed, // Type 2, match
				ExchangeRate:     "1.3",                        // Mismatch
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, list)
	})

	PatchConvey("Test all conditions match for fixed rate", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFixed, // Type 2
			ExchangeRate:     "1.2",
		}
		list := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc_fixed_rate_match",
				CurrencyCode:     "EUR",
				ExchangeRateType: _const.ExchangeRateTypeFixed, // Type 2, match
				ExchangeRate:     "1.2",                        // Match
			},
		}
		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeTrue)
		So(diff, ShouldResemble, []*metabasic.CurrencyAndExchangeRateData{})
	})

	PatchConvey("Test with a mixed list of matching and non-matching data", t, func() {
		currentData := &metabasic.CurrencyAndExchangeRateData{
			CurrencyCode:     "CNY",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "7.0",
		}

		matchingItem := &metabasic.CurrencyAndExchangeRateData{
			AccountID:        "acc_match",
			CurrencyCode:     "CNY",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "7.0",
		}
		diffCurrencyItem := &metabasic.CurrencyAndExchangeRateData{
			AccountID:        "acc_diff_curr",
			CurrencyCode:     "EUR", // Diff
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "7.0",
		}
		diffRateItem := &metabasic.CurrencyAndExchangeRateData{
			AccountID:        "acc_diff_rate",
			CurrencyCode:     "CNY",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "7.1", // Diff
		}

		list := []*metabasic.CurrencyAndExchangeRateData{
			matchingItem,
			diffCurrencyItem,
			diffRateItem,
		}

		expectedDiff := []*metabasic.CurrencyAndExchangeRateData{
			diffCurrencyItem,
			diffRateItem,
		}

		result, diff := IsSameCurrencyAndExchangeRate(ctx, currentData, list)
		So(result, ShouldBeFalse)
		So(diff, ShouldResemble, expectedDiff)
	})
}

func Test_CheckCurrencyAndExchangeRate_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	// Base request for standard (non-MDCR) cases
	req := &metabasic.CheckCurrencyAndExchangeRateReq{
		AccountIDs:       []string{"acc1", "acc2"},
		CurrencyCode:     "USD",
		ExchangeRateType: 1,
		ExchangeRate:     "1.2",
	}

	PatchConvey("Test ListExchangeRateData failed", t, func() {
		// This test covers the initial error handling path, which is independent of the currency code logic.
		Mock(ListExchangeRateData).Return(nil, errors.ErrorCommon.WithArgs("failed to list exchange rate data")).Build()
		resp, err := CheckCurrencyAndExchangeRate(ctx, req)
		So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{})
		So(err, ShouldNotBeNil)
	})

	PatchConvey("Test ListExchangeRateData success", t, func() {
		mockList := []*metabasic.CurrencyAndExchangeRateData{
			{
				AccountID:        "acc1",
				CurrencyCode:     "USD",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
			{
				AccountID:        "acc2",
				CurrencyCode:     "USD",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			},
		}
		// Mock ListExchangeRateData to succeed for all sub-tests in this block
		Mock(ListExchangeRateData).Return(mockList, nil).Build()

		PatchConvey("When CurrencyCode is standard (non-MDCR)", func() {
			PatchConvey("and IsSameCurrencyAndExchangeRate returns true", func() {
				Mock(IsSameCurrencyAndExchangeRate).Return(true, []*metabasic.CurrencyAndExchangeRateData{}).Build()
				resp, err := CheckCurrencyAndExchangeRate(ctx, req)
				So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
					Agree: true,
					CurrentData: metabasic.CurrencyAndExchangeRateData{
						CurrencyCode:     "USD",
						ExchangeRateType: 01,
						ExchangeRate:     "1.2",
					},
					List: []*metabasic.CurrencyAndExchangeRateData{},
				})
				So(err, ShouldBeNil)
			})

			PatchConvey("and IsSameCurrencyAndExchangeRate returns false", func() {
				Mock(IsSameCurrencyAndExchangeRate).Return(false, mockList).Build()
				resp, err := CheckCurrencyAndExchangeRate(ctx, req)
				So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
					Agree: false,
					CurrentData: metabasic.CurrencyAndExchangeRateData{
						CurrencyCode:     req.CurrencyCode,
						ExchangeRateType: req.ExchangeRateType,
						ExchangeRate:     req.ExchangeRate,
					},
					List: mockList,
				})
				So(err, ShouldBeNil)
			})
		})

		PatchConvey("When CurrencyCode has 'MDCR' prefix", func() {
			mdcrReq := &metabasic.CheckCurrencyAndExchangeRateReq{
				AccountIDs:       []string{"acc1", "acc2"},
				CurrencyCode:     "MDCRxxxxx01",
				ExchangeRateType: 1,
				ExchangeRate:     "1.2",
			}

			PatchConvey("and QueryCurrencyByNameOrCode succeeds in resolving the code", func() {
				// Arrange: Mock MDCR lookup to succeed
				Mock(mdcli.QueryCurrencyByNameOrCode).Return(&mdcli.MDCurrencyData{Code: "USD"}, nil).Build()

				// Arrange: Mock the final check, ensuring it receives the *resolved* currency code "USD".
				// We expect a match since the mockList also uses "USD".
				Mock(IsSameCurrencyAndExchangeRate).When(func(ctx context.Context, currentData *metabasic.CurrencyAndExchangeRateData, list []*metabasic.CurrencyAndExchangeRateData) bool {
					return currentData.CurrencyCode == "USD"
				}).Return(true, []*metabasic.CurrencyAndExchangeRateData{}).Build()

				// Act
				resp, err := CheckCurrencyAndExchangeRate(ctx, mdcrReq)

				// Assert
				So(err, ShouldBeNil)
				So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
					Agree: true,
					CurrentData: metabasic.CurrencyAndExchangeRateData{
						CurrencyCode:     req.CurrencyCode,
						ExchangeRateType: req.ExchangeRateType,
						ExchangeRate:     req.ExchangeRate,
					},
					List: []*metabasic.CurrencyAndExchangeRateData{},
				})
			})

			PatchConvey("and QueryCurrencyByNameOrCode fails to resolve the code (returns nil)", func() {
				// Arrange: Mock MDCR lookup to fail (return nil)
				Mock(mdcli.QueryCurrencyByNameOrCode).Return(nil, nil).Build()

				// Arrange: Mock the final check, ensuring it receives the *original* MDCR code.
				// This will cause a mismatch with the mockList's "USD", so we expect `false`.
				Mock(IsSameCurrencyAndExchangeRate).When(func(ctx context.Context, currentData *metabasic.CurrencyAndExchangeRateData, list []*metabasic.CurrencyAndExchangeRateData) bool {
					return currentData.CurrencyCode == "MDCRxxxxx01"
				}).Return(false, mockList).Build()

				// Act
				resp, err := CheckCurrencyAndExchangeRate(ctx, mdcrReq)

				// Assert
				So(err, ShouldBeNil)
				So(resp, ShouldResemble, &metabasic.CheckCurrencyAndExchangeRateResp{
					Agree: false,
					CurrentData: metabasic.CurrencyAndExchangeRateData{
						CurrencyCode:     mdcrReq.CurrencyCode,
						ExchangeRateType: mdcrReq.ExchangeRateType,
						ExchangeRate:     mdcrReq.ExchangeRate,
					},
					List: mockList,
				})
			})
		})
	})
}

func Test_clacQuoteSpecialContractType(t *testing.T) {
	ctx := context.Background()

	relateQuoteNo := ""
	specialContractType := "TypeA,TypeB,TypeC"
	mockey.PatchConvey("Test when RelateQuoteNo is empty", t, func() {
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "",
			SpecialContractType: "TypeX,TypeY",
		}
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "TypeA,TypeB,TypeC")
	})

	mockey.PatchConvey("Test when RelateQuoteNo is not empty and no special contract types from quote", t, func() {
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "Quote123",
			SpecialContractType: "TypeX,TypeY",
		}
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "TypeA,TypeB,TypeC")
	})

	mockey.PatchConvey("Test when RelateQuoteNo is not empty and some special contract types from quote", t, func() {
		relateQuoteNo = "Quote123"
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "Quote123",
			SpecialContractType: "TypeX,TypeY,TypeZ",
		}
		// Assuming TypeZ is in _const.QuoteSpecialContractTypeList
		mockey.Mock(util.StringIn).To(func(item string, list []string) bool {
			if item == "TypeZ" {
				return true
			}
			return false // Add your code
		}).Build()
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "TypeA,TypeB,TypeC,TypeZ")
	})

	mockey.PatchConvey("Test when RelateQuoteNo is not empty and all special contract types from quote", t, func() {
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "Quote123",
			SpecialContractType: "TypeX,TypeY,TypeZ",
		}
		// Assuming TypeX, TypeY, and TypeZ are in _const.QuoteSpecialContractTypeList

		mockey.Mock(util.StringIn).To(func(item string, list []string) bool {
			if item == "TypeX" {
				return true
			}
			if item == "TypeY" {
				return true
			}
			if item == "TypeZ" {
				return true
			}
			return false // Add your code
		}).Build()
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "TypeA,TypeB,TypeC,TypeX,TypeY,TypeZ")
	})

	mockey.PatchConvey("Test when RelateQuoteNo is not empty and no special contract types in BasicInfo", t, func() {
		specialContractType = ""
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "Quote123",
			SpecialContractType: "TypeX,TypeY",
		}
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("Test when RelateQuoteNo is not empty and no special contract types in meta", t, func() {
		specialContractType = "TypeA,TypeB,TypeC"
		meta := &model.ContractMetaDB{
			RelateQuoteNo:       "Quote123",
			SpecialContractType: "",
		}
		actual := ClacQuoteSpecialContractType(ctx, meta.RelateQuoteNo, relateQuoteNo, meta.SpecialContractType, specialContractType)
		convey.So(actual, convey.ShouldEqual, "TypeA,TypeB,TypeC")
	})
}

package businessmodeclause

import (
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
)

type fakeBusinessModeClauseDao struct {
	createdEntity *model.BusinessModeClauseDB
	createdCount  int
	createErr     error
	updatedID     uint64
	updates       map[string]interface{}
	updateCount   int
	updateErr     error
	deletedIDs    []uint64
	deleteErr     error
	listCount     int
	list          []*model.BusinessModeClauseDB
	listErr       error
	modes         []string
}

func (f *fakeBusinessModeClauseDao) Create(ctx context.Context, tx *gorm.DB, entity *model.BusinessModeClauseDB) error {
	f.createdCount++
	f.createdEntity = entity
	return f.createErr
}

func (f *fakeBusinessModeClauseDao) UpdateByID(ctx context.Context, tx *gorm.DB, contractID int, id uint64, updates map[string]interface{}) error {
	f.updateCount++
	f.updatedID = id
	f.updates = updates
	return f.updateErr
}

func (f *fakeBusinessModeClauseDao) DeleteByIDs(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error {
	f.deletedIDs = ids
	return f.deleteErr
}

func (f *fakeBusinessModeClauseDao) ListByContractID(ctx context.Context, tx *gorm.DB, contractID int) ([]*model.BusinessModeClauseDB, error) {
	f.listCount++
	return f.list, f.listErr
}

func (f *fakeBusinessModeClauseDao) ListByContractIDAndBusinessModes(ctx context.Context, tx *gorm.DB,
	contractID int, businessModes []string) ([]*model.BusinessModeClauseDB, error) {
	f.modes = businessModes
	return f.list, f.listErr
}

func TestServiceImpl_SaveBusinessModeClauses(t *testing.T) {
	mockey.PatchConvey("SaveBusinessModeClauses", t, func() {
		ctx := context.Background()
		fakeDao := &fakeBusinessModeClauseDao{}
		svc := &serviceImpl{clauseDao: fakeDao}
		metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 123}, ContractNo: "contract_no"}

		convey.Convey("nil入参表示不修改", func() {
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, nil, "operator")
			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
		})

		convey.Convey("新增数据时直接创建", func() {
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity.VolcContractID, convey.ShouldEqual, 123)
			convey.So(fakeDao.createdEntity.ContractNo, convey.ShouldEqual, "contract_no")
			convey.So(fakeDao.createdEntity.BusinessMode, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
			convey.So(fakeDao.createdEntity.ClauseSummary, convey.ShouldEqual, "摘要")
			convey.So(fakeDao.createdEntity.Creator, convey.ShouldEqual, "operator")
			convey.So(fakeDao.createdEntity.Updater, convey.ShouldEqual, "operator")
		})

		convey.Convey("编辑已有数据时只更新发生变化的摘要", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.updates["clause_summary"], convey.ShouldEqual, "新摘要")
			convey.So(fakeDao.updates["updater"], convey.ShouldEqual, "new_operator")
			convey.So(len(fakeDao.updates), convey.ShouldEqual, 2)
		})

		convey.Convey("编辑已有数据时只更新发生变化的商务模式", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: "manual_guarantee", ClauseSummary: "摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.updates["business_mode"], convey.ShouldEqual, "manual_guarantee")
			convey.So(fakeDao.updates["updater"], convey.ShouldEqual, "new_operator")
			convey.So(len(fakeDao.updates), convey.ShouldEqual, 2)
		})

		convey.Convey("编辑已有数据时商务模式和摘要都变化则同时更新", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: "manual_guarantee", ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.updates["business_mode"], convey.ShouldEqual, "manual_guarantee")
			convey.So(fakeDao.updates["clause_summary"], convey.ShouldEqual, "新摘要")
			convey.So(fakeDao.updates["updater"], convey.ShouldEqual, "new_operator")
			convey.So(len(fakeDao.updates), convey.ShouldEqual, 3)
		})

		convey.Convey("编辑已有数据但商务模式和摘要未变化则不更新", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updateCount, convey.ShouldEqual, 0)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
		})

		convey.Convey("业务模式相同但Id未匹配时新增记录", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}
			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldNotBeNil)
			convey.So(fakeDao.createdEntity.BusinessMode, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
			convey.So(fakeDao.createdEntity.ClauseSummary, convey.ShouldEqual, "新摘要")
		})

		convey.Convey("传入列表缺少旧记录时删除旧记录", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 99}, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保留摘要"},
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "删除摘要"},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{100})
		})

		convey.Convey("传入空列表时删除全部旧记录", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 99}, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "旧摘要1"},
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "旧摘要2"},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{99, 100})
		})
	})
}

func TestServiceImpl_ValidateRequiredBusinessModeClauses(t *testing.T) {
	mockey.PatchConvey("ValidateRequiredBusinessModeClauses", t, func() {
		ctx := context.Background()
		fakeDao := &fakeBusinessModeClauseDao{}
		svc := &serviceImpl{clauseDao: fakeDao}
		meta := &model.ContractMeta{
			ID: 123,
			BasicInfo: &bizmodels.BasicInfo{
				SpecialContractType: _const.SpecialContractTypeGuarantee + ",manual_guarantee",
			},
			TemplateInfo: &bizmodels.TemplateInfo{},
		}
		mockey.Mock(conf.GetConstConf).Return(&conf.ConstConf{
			BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"},
		}).Build()

		convey.Convey("系统模板合同不校验", func() {
			meta.TemplateInfo = &bizmodels.TemplateInfo{Master: &bizmodels.TemplateDetail{TemplateKey: "master_key"}}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, nil)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("命中配置的商务模式都有摘要时校验通过", func() {
			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
				{BusinessMode: "manual_guarantee", ClauseSummary: "人工保底摘要"},
			})

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("命中配置的商务模式缺少摘要时报错", func() {
			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商务模式=manual_guarantee,缺少条款摘要数据,请补充后再提交")
		})

		convey.Convey("传入 clauses 为 nil 时不进行校验", func() {
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
			}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.listCount, convey.ShouldEqual, 0)
		})

		convey.Convey("摘要内容为空字符串时报错", func() {
			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
				{BusinessMode: "manual_guarantee", ClauseSummary: ""},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商务模式=manual_guarantee,缺少条款摘要数据,请补充后再提交")
		})

		convey.Convey("单条摘要关联多个商务模式时校验通过", func() {
			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee + ",manual_guarantee", ClauseSummary: "摘要"},
			})

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func (f *fakeContractMetaDao) FindLastByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	f.findCount++
	f.contractNo = contractNo
	return f.metaDB, f.err
}

func TestGetBusinessModeName(t *testing.T) {
	mockey.PatchConvey("GetBusinessModeName", t, func() {
		ctx := context.Background()
		var modeNameMap map[string]string
		mockey.Mock(conf.GetSpecialContractTypeItem).To(func(context.Context) map[string]string {
			return modeNameMap
		}).Build()

		convey.Convey("优先使用配置中的文案", func() {
			modeNameMap = map[string]string{"manual_guarantee": "人工保底"}

			name := getBusinessModeName(ctx, "manual_guarantee")

			convey.So(name, convey.ShouldEqual, "人工保底")
		})

		convey.Convey("配置缺失时回退到常量映射", func() {
			modeNameMap = nil

			name := getBusinessModeName(ctx, _const.SpecialContractTypeGuarantee)

			convey.So(name, convey.ShouldEqual, "保底合同")
		})

		convey.Convey("配置和常量都没有时返回原值", func() {
			modeNameMap = nil

			name := getBusinessModeName(ctx, "manual_guarantee")

			convey.So(name, convey.ShouldEqual, "manual_guarantee")
		})
	})
}

func TestGetRequiredBusinessModes(t *testing.T) {
	mockey.PatchConvey("GetRequiredBusinessModes", t, func() {
		convey.Convey("过滤空值并保持首次出现顺序", func() {
			modes := getRequiredBusinessModes(","+_const.SpecialContractTypeGuarantee+",manual_guarantee,other,"+_const.SpecialContractTypeGuarantee,
				[]string{_const.SpecialContractTypeGuarantee, "manual_guarantee"})

			convey.So(modes, convey.ShouldResemble, []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"})
		})

		convey.Convey("未命中目标商务模式时返回空结果", func() {
			modes := getRequiredBusinessModes("other", []string{_const.SpecialContractTypeGuarantee})

			convey.So(modes, convey.ShouldBeEmpty)
		})
	})
}

func TestServiceImplSaveBusinessModeClauses(t *testing.T) {
	mockey.PatchConvey("SaveBusinessModeClauses", t, func() {
		ctx := context.Background()
		newService := func() (*serviceImpl, *fakeBusinessModeClauseDao, *model.ContractMetaDB) {
			fakeDao := &fakeBusinessModeClauseDao{}
			svc := &serviceImpl{clauseDao: fakeDao}
			metaDB := &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 123}, ContractNo: "contract_no"}
			return svc, fakeDao, metaDB
		}

		convey.Convey("nil入参表示不修改", func() {
			svc, fakeDao, metaDB := newService()

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, nil, "operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.listCount, convey.ShouldEqual, 0)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
		})

		convey.Convey("合同元数据为空时返回错误", func() {
			svc, _, _ := newService()

			err := svc.SaveBusinessModeClauses(ctx, nil, nil, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SaveBusinessModeClausesFail")
		})

		convey.Convey("查询旧数据失败时直接返回", func() {
			expectedErr := errors.New("list failed")
			svc, fakeDao, metaDB := newService()
			fakeDao.listErr = expectedErr

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(fakeDao.createdCount, convey.ShouldEqual, 0)
		})

		convey.Convey("新增数据时直接创建", func() {
			svc, fakeDao, metaDB := newService()

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity.VolcContractID, convey.ShouldEqual, 123)
			convey.So(fakeDao.createdEntity.ContractNo, convey.ShouldEqual, "contract_no")
			convey.So(fakeDao.createdEntity.BusinessMode, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
			convey.So(fakeDao.createdEntity.ClauseSummary, convey.ShouldEqual, "摘要")
			convey.So(fakeDao.createdEntity.Creator, convey.ShouldEqual, "operator")
			convey.So(fakeDao.createdEntity.Updater, convey.ShouldEqual, "operator")
		})

		convey.Convey("新增数据失败时返回创建错误", func() {
			expectedErr := errors.New("create failed")
			svc, fakeDao, metaDB := newService()
			fakeDao.createErr = expectedErr

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(fakeDao.createdCount, convey.ShouldEqual, 1)
		})

		convey.Convey("编辑已有数据时只更新发生变化的摘要", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.updates["clause_summary"], convey.ShouldEqual, "新摘要")
			convey.So(fakeDao.updates["updater"], convey.ShouldEqual, "new_operator")
			convey.So(len(fakeDao.updates), convey.ShouldEqual, 2)
		})

		convey.Convey("更新已有数据失败时直接返回", func() {
			expectedErr := errors.New("update failed")
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
				},
			}
			fakeDao.updateErr = expectedErr

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: "manual_guarantee", ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
		})

		convey.Convey("编辑已有数据时商务模式和摘要都变化则同时更新", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: "manual_guarantee", ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.updates["business_mode"], convey.ShouldEqual, "manual_guarantee")
			convey.So(fakeDao.updates["clause_summary"], convey.ShouldEqual, "新摘要")
			convey.So(fakeDao.updates["updater"], convey.ShouldEqual, "new_operator")
			convey.So(len(fakeDao.updates), convey.ShouldEqual, 3)
		})

		convey.Convey("编辑已有数据但商务模式和摘要未变化则不更新", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updateCount, convey.ShouldEqual, 0)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
		})

		convey.Convey("业务模式相同但Id未匹配时新增记录", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{
					BaseDB:        model.BaseDB{Id: 99},
					BusinessMode:  _const.SpecialContractTypeGuarantee,
					ClauseSummary: "旧摘要",
					Creator:       "creator",
					Updater:       "old_operator",
				},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldNotBeNil)
			convey.So(fakeDao.createdEntity.BusinessMode, convey.ShouldEqual, _const.SpecialContractTypeGuarantee)
			convey.So(fakeDao.createdEntity.ClauseSummary, convey.ShouldEqual, "新摘要")
		})

		convey.Convey("忽略空条款和空旧记录", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				nil,
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "旧摘要"},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				nil,
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdCount, convey.ShouldEqual, 1)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{100})
		})

		convey.Convey("传入列表缺少旧记录时删除旧记录", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 99}, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保留摘要"},
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "删除摘要"},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{
				{Id: 99, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "新摘要"},
			}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.updatedID, convey.ShouldEqual, 99)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{100})
		})

		convey.Convey("删除旧记录失败时直接返回", func() {
			expectedErr := errors.New("delete failed")
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "删除摘要"},
			}
			fakeDao.deleteErr = expectedErr

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{}, "new_operator")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{100})
		})

		convey.Convey("传入空列表时删除全部旧记录", func() {
			svc, fakeDao, metaDB := newService()
			fakeDao.list = []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 100}, BusinessMode: "manual_guarantee", ClauseSummary: "旧摘要2"},
				{BaseDB: model.BaseDB{Id: 99}, BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "旧摘要1"},
			}

			err := svc.SaveBusinessModeClauses(ctx, nil, metaDB, []*bizmodels.BusinessModeClause{}, "new_operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(fakeDao.createdEntity, convey.ShouldBeNil)
			convey.So(fakeDao.updates, convey.ShouldBeNil)
			convey.So(fakeDao.deletedIDs, convey.ShouldResemble, []uint64{99, 100})
		})
	})
}

func TestServiceImplValidateRequiredBusinessModeClauses(t *testing.T) {
	mockey.PatchConvey("ValidateRequiredBusinessModeClauses", t, func() {
		ctx := context.Background()
		var constConf *conf.ConstConf
		var modeNameMap map[string]string
		mockey.Mock(conf.GetConstConf).To(func(context.Context) *conf.ConstConf {
			return constConf
		}).Build()
		mockey.Mock(conf.GetSpecialContractTypeItem).To(func(context.Context) map[string]string {
			return modeNameMap
		}).Build()

		newMeta := func(specialContractType string) *model.ContractMeta {
			return &model.ContractMeta{
				ID: 123,
				BasicInfo: &bizmodels.BasicInfo{
					SpecialContractType: specialContractType,
				},
				TemplateInfo: &bizmodels.TemplateInfo{},
			}
		}

		convey.Convey("合同为空时不校验", func() {
			constConf = &conf.ConstConf{BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee}}
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, nil, nil)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("配置为空时不校验", func() {
			constConf = nil
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee), nil)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("未命中配置的商务模式时校验通过", func() {
			constConf = &conf.ConstConf{BusinessModeClauseModes: []string{"manual_guarantee"}}
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee), []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
			})

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("系统模板合同不校验", func() {
			constConf = &conf.ConstConf{BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee}}
			meta := newMeta(_const.SpecialContractTypeGuarantee)
			meta.TemplateInfo = &bizmodels.TemplateInfo{Master: &bizmodels.TemplateDetail{TemplateKey: "master_key"}}
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, meta, nil)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("命中配置的商务模式都有摘要时校验通过", func() {
			constConf = &conf.ConstConf{
				BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"},
			}
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee+",manual_guarantee"), []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
				{BusinessMode: "manual_guarantee", ClauseSummary: "人工保底摘要"},
			})

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("摘要内容为空字符串时报错", func() {
			constConf = &conf.ConstConf{
				BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"},
			}
			modeNameMap = nil
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee+",manual_guarantee"), []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "保底摘要"},
				{BusinessMode: "manual_guarantee", ClauseSummary: ""},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商务模式=manual_guarantee,缺少条款摘要数据,请补充后再提交")
		})

		convey.Convey("缺少保底摘要时使用常量映射文案", func() {
			constConf = &conf.ConstConf{
				BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"},
			}
			modeNameMap = nil
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee+",manual_guarantee"), []*bizmodels.BusinessModeClause{
				{BusinessMode: "manual_guarantee", ClauseSummary: "人工保底摘要"},
			})

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商务模式=保底合同,缺少条款摘要数据,请补充后再提交")
		})

		convey.Convey("单条摘要关联多个商务模式时校验通过", func() {
			constConf = &conf.ConstConf{
				BusinessModeClauseModes: []string{_const.SpecialContractTypeGuarantee, "manual_guarantee"},
			}
			svc := &serviceImpl{}

			err := svc.ValidateRequiredBusinessModeClauses(ctx, nil, newMeta(_const.SpecialContractTypeGuarantee+",manual_guarantee"), []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee + ",manual_guarantee", ClauseSummary: "摘要"},
			})

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestServiceImplEditBusinessModeClauses(t *testing.T) {
	mockey.PatchConvey("EditBusinessModeClauses", t, func() {
		ctx := context.Background()

		convey.Convey("合同编号为空时返回参数错误", func() {
			svc := &serviceImpl{}

			err := svc.EditBusinessModeClauses(ctx, nil, "", nil, "operator")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractNo")
		})

		convey.Convey("查询合同失败时直接返回", func() {
			expectedErr := errors.New("find meta failed")
			metaDao := &fakeContractMetaDao{err: expectedErr}
			svc := &serviceImpl{metaDao: metaDao}

			err := svc.EditBusinessModeClauses(ctx, nil, "contract_no", nil, "operator")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(metaDao.findCount, convey.ShouldEqual, 1)
			convey.So(metaDao.contractNo, convey.ShouldEqual, "contract_no")
		})

		convey.Convey("合同不存在时返回内部错误", func() {
			metaDao := &fakeContractMetaDao{}
			svc := &serviceImpl{metaDao: metaDao}

			err := svc.EditBusinessModeClauses(ctx, nil, "contract_no", nil, "operator")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractNotFound")
		})

		convey.Convey("查询到合同后复用保存逻辑", func() {
			metaDao := &fakeContractMetaDao{
				metaDB: &model.ContractMetaDB{BaseDB: model.BaseDB{Id: 123}, ContractNo: "contract_no"},
			}
			clauseDao := &fakeBusinessModeClauseDao{}
			svc := &serviceImpl{metaDao: metaDao, clauseDao: clauseDao}

			err := svc.EditBusinessModeClauses(ctx, nil, "contract_no", []*bizmodels.BusinessModeClause{
				{BusinessMode: _const.SpecialContractTypeGuarantee, ClauseSummary: "摘要"},
			}, "operator")

			convey.So(err, convey.ShouldBeNil)
			convey.So(clauseDao.createdCount, convey.ShouldEqual, 1)
			convey.So(clauseDao.createdEntity.ContractNo, convey.ShouldEqual, "contract_no")
			convey.So(clauseDao.createdEntity.VolcContractID, convey.ShouldEqual, 123)
		})
	})
}

type fakeContractMetaDao struct {
	dal.ContractMetaDao
	metaDB     *model.ContractMetaDB
	err        error
	findCount  int
	contractNo string
}

var constConf *conf.ConstConf

var modeNameMap map[string]string

package businessmodeclause

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type Service interface {
	EditBusinessModeClauses(ctx context.Context, tx *gorm.DB, contractNo string, clauses []*bizmodels.BusinessModeClause, operator string) error
	SaveBusinessModeClauses(ctx context.Context, tx *gorm.DB, metaDB *model.ContractMetaDB, clauses []*bizmodels.BusinessModeClause, operator string) error
	ValidateRequiredBusinessModeClauses(ctx context.Context, tx *gorm.DB, meta *model.ContractMeta, clauses []*bizmodels.BusinessModeClause) error
}

func NewService() Service {
	return &serviceImpl{
		metaDao:   dal.NewContractMetaDao(),
		clauseDao: dal.NewBusinessModeClauseDao(),
	}
}

type serviceImpl struct {
	metaDao   dal.ContractMetaDao
	clauseDao dal.BusinessModeClauseDao
}

func (s *serviceImpl) EditBusinessModeClauses(ctx context.Context, tx *gorm.DB, contractNo string,
	clauses []*bizmodels.BusinessModeClause, operator string) error {
	if contractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}

	metaDB, err := s.metaDao.FindLastByNo(ctx, tx, contractNo)
	if err != nil {
		logs.CtxError(ctx, "EditBusinessModeClausesFail, FindLastByNoFail, contractNo:%s, err:%v", contractNo, err)
		return err
	}
	if metaDB == nil {
		logs.CtxError(ctx, "EditBusinessModeClausesFail, ContractNotFound, contractNo:%s", contractNo)
		return errors.ErrInternalError.WithArgs("ContractNotFound")
	}

	return s.SaveBusinessModeClauses(ctx, tx, metaDB, clauses, operator)
}

func (s *serviceImpl) SaveBusinessModeClauses(ctx context.Context, tx *gorm.DB, metaDB *model.ContractMetaDB,
	clauses []*bizmodels.BusinessModeClause, operator string) error {
	if clauses == nil {
		return nil
	}
	if metaDB == nil {
		logs.CtxError(ctx, "SaveBusinessModeClausesFail, metaDB is nil")
		return errors.ErrInternalError.WithArgs("SaveBusinessModeClausesFail")
	}

	oldClauses, err := s.clauseDao.ListByContractID(ctx, tx, int(metaDB.Id))
	if err != nil {
		logs.CtxError(ctx, "SaveBusinessModeClausesFail, ListByContractIDFail, contractID:%d, err:%v", metaDB.Id, err)
		return err
	}
	oldClauseMap := make(map[uint64]*model.BusinessModeClauseDB, len(oldClauses))
	for _, oldClause := range oldClauses {
		if oldClause == nil {
			continue
		}
		oldClauseMap[oldClause.Id] = oldClause
	}

	keptOldClauseIDs := make(map[uint64]struct{}, len(clauses))
	for _, clause := range clauses {
		if clause == nil {
			continue
		}
		if oldClause, ok := oldClauseMap[clause.Id]; ok {
			keptOldClauseIDs[clause.Id] = struct{}{}
			updates := make(map[string]interface{}, 3)
			if oldClause.BusinessMode != clause.BusinessMode {
				updates["business_mode"] = clause.BusinessMode
			}
			if oldClause.ClauseSummary != clause.ClauseSummary {
				updates["clause_summary"] = clause.ClauseSummary
			}
			if len(updates) == 0 {
				continue
			}
			updates["updater"] = operator
			if err := s.clauseDao.UpdateByID(ctx, tx, int(metaDB.Id), clause.Id, updates); err != nil {
				logs.CtxError(ctx, "SaveBusinessModeClausesFail, UpdateByIDFail, contractID:%d, clauseID:%d, err:%v", metaDB.Id, clause.Id, err)
				return err
			}
			continue
		}

		entity := model.GenBusinessModeClauseDB(metaDB, clause, operator)
		if err := s.clauseDao.Create(ctx, tx, entity); err != nil {
			logs.CtxError(ctx, "SaveBusinessModeClausesFail, CreateFail, contractID:%d, businessMode:%s, err:%v", metaDB.Id, clause.BusinessMode, err)
			return err
		}
	}

	var deleteIDs []uint64
	for id := range oldClauseMap {
		if _, ok := keptOldClauseIDs[id]; ok {
			continue
		}
		deleteIDs = append(deleteIDs, id)
	}
	sort.Slice(deleteIDs, func(i, j int) bool { return deleteIDs[i] < deleteIDs[j] })
	if err := s.clauseDao.DeleteByIDs(ctx, tx, int(metaDB.Id), deleteIDs); err != nil {
		logs.CtxError(ctx, "SaveBusinessModeClausesFail, DeleteByIDsFail, contractID:%d, ids:%v, err:%v", metaDB.Id, deleteIDs, err)
		return err
	}
	return nil
}

func (s *serviceImpl) ValidateRequiredBusinessModeClauses(ctx context.Context, tx *gorm.DB,
	meta *model.ContractMeta, clauses []*bizmodels.BusinessModeClause) error {
	if meta == nil || meta.BasicInfo == nil {
		return nil
	}
	constConf := conf.GetConstConf(ctx)
	if constConf == nil || len(constConf.BusinessModeClauseModes) == 0 {
		return nil
	}
	if hasMasterTemplate(meta.TemplateInfo) {
		return nil
	}

	requiredModes := getRequiredBusinessModes(meta.BasicInfo.SpecialContractType, constConf.BusinessModeClauseModes)
	if len(requiredModes) == 0 {
		return nil
	}

	finalClauses := clauses
	if finalClauses == nil {
		return nil
	}

	modeHasSummary := make(map[string]bool, len(finalClauses))
	for _, clause := range finalClauses {
		if clause == nil {
			continue
		}
		for _, mode := range strings.Split(clause.BusinessMode, ",") {
			if mode == "" {
				continue
			}
			if clause.ClauseSummary != "" {
				modeHasSummary[mode] = true
			}
		}
	}

	for _, mode := range requiredModes {
		if modeHasSummary[mode] {
			continue
		}
		return i18nfmt.New(ctx, fmt.Sprintf("商务模式=%s,缺少条款摘要数据,请补充后再提交", getBusinessModeName(ctx, mode)))
	}
	return nil
}

func hasMasterTemplate(templateInfo *bizmodels.TemplateInfo) bool {
	return templateInfo != nil && templateInfo.Master != nil && templateInfo.Master.TemplateKey != ""
}

func getRequiredBusinessModes(specialContractType string, targetBusinessModes []string) []string {
	targetModeSet := make(map[string]struct{}, len(targetBusinessModes))
	for _, mode := range targetBusinessModes {
		if mode == "" {
			continue
		}
		targetModeSet[mode] = struct{}{}
	}

	var requiredModes []string
	selectedModeSet := make(map[string]struct{})
	for _, mode := range strings.Split(specialContractType, ",") {
		if mode == "" {
			continue
		}
		if _, ok := targetModeSet[mode]; !ok {
			continue
		}
		if _, ok := selectedModeSet[mode]; ok {
			continue
		}
		selectedModeSet[mode] = struct{}{}
		requiredModes = append(requiredModes, mode)
	}
	return requiredModes
}

func getBusinessModeName(ctx context.Context, mode string) string {
	if modeNameMap := conf.GetSpecialContractTypeItem(ctx); len(modeNameMap) > 0 {
		if name := modeNameMap[mode]; name != "" {
			return name
		}
	}
	if name := _const.SpecialContractTypeDisplayMapping[mode]; name != "" {
		return name
	}
	return mode
}

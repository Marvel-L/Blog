package common

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"
)

func Test_FilterHighestPriorityReviewers_BitsUTGen(t *testing.T) {
	t.Run("状态过滤命中四种状态时全部被剔除", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造四种状态均命中剔除条件的审核人
			r1 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: _const.ReviewStatusReviewPass},
				PreContractNo:  "PC1",
				ContractStatus: 10,
				Priority:       99,
			}
			r2 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: _const.ReviewStatusChangeReviewer},
				PreContractNo:  "PC2",
				ContractStatus: 20,
				Priority:       5,
			}
			r3 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: _const.ReviewStatusSubmitChange},
				PreContractNo:  "PC3",
				ContractStatus: 30,
				Priority:       7,
			}
			r4 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: _const.ReviewStatusFinalized},
				PreContractNo:  "PC4",
				ContractStatus: 40,
				Priority:       1,
			}
			reviewerList := model.PreContractReviewerDBList{r1, r2, r3, r4}

			// 合同映射存在，但由于状态命中剔除条件，最终应为空
			contractMap := map[string]*model.ContractMetaDB{
				"PC1": {CooperationStatus: 10},
				"PC2": {CooperationStatus: 20},
				"PC3": {CooperationStatus: 30},
				"PC4": {CooperationStatus: 40},
			}

			result := FilterHighestPriorityReviewers(reviewerList, contractMap)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("合同映射存在且协商状态匹配时按优先级选择，包含并列最高优先级", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 允许状态的审核人：A组用于最高优先级选择，B组用于并列最高优先级
			rA1 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "A",
				ContractStatus: 100,
				Priority:       3,
			}
			rA2 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "A",
				ContractStatus: 100,
				Priority:       5,
			}
			rA3 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "A",
				ContractStatus: 100,
				Priority:       5,
			}
			rB1 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "B",
				ContractStatus: 200,
				Priority:       1,
			}
			rB2 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "B",
				ContractStatus: 200,
				Priority:       1,
			}

			// 不存在映射的审核人
			rMiss := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "MISS",
				ContractStatus: 300,
				Priority:       9,
			}
			// 协商状态不匹配的审核人
			rMismatch := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "C",
				ContractStatus: 777,
				Priority:       8,
			}

			reviewerList := model.PreContractReviewerDBList{rA1, rA2, rA3, rB1, rB2, rMiss, rMismatch}
			contractMap := map[string]*model.ContractMetaDB{
				"A": {CooperationStatus: 100},
				"B": {CooperationStatus: 200},
				"C": {CooperationStatus: 666},
				// MISS 不存在，模拟映射缺失
			}

			result := FilterHighestPriorityReviewers(reviewerList, contractMap)

			// 结果数量
			convey.So(len(result), convey.ShouldEqual, 4)

			// 包含并列最高优先级的两人（A组）
			convey.So(containsReviewer(result, rA2), convey.ShouldBeTrue)
			convey.So(containsReviewer(result, rA3), convey.ShouldBeTrue)
			// A组的非最高优先级不应包含
			convey.So(containsReviewer(result, rA1), convey.ShouldBeFalse)

			// 包含并列最高优先级的两人（B组）
			convey.So(containsReviewer(result, rB1), convey.ShouldBeTrue)
			convey.So(containsReviewer(result, rB2), convey.ShouldBeTrue)

			// 不存在映射的审核人不应包含
			convey.So(containsReviewer(result, rMiss), convey.ShouldBeFalse)
			// 协商状态不匹配的审核人不应包含
			convey.So(containsReviewer(result, rMismatch), convey.ShouldBeFalse)
		})
	})

	t.Run("优先级全为负数时不选任何审核人", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// NEG组只包含负数优先级，最高优先级初始化为0且没有人匹配0
			rNeg1 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "NEG",
				ContractStatus: 500,
				Priority:       -1,
			}
			rNeg2 := &model.PreContractReviewerDB{
				BaseDB:         model.BaseDB{Status: 0},
				PreContractNo:  "NEG",
				ContractStatus: 500,
				Priority:       -2,
			}
			reviewerList := model.PreContractReviewerDBList{rNeg1, rNeg2}
			contractMap := map[string]*model.ContractMetaDB{
				"NEG": {CooperationStatus: 500},
			}

			result := FilterHighestPriorityReviewers(reviewerList, contractMap)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})
}

// 辅助方法：判断目标审核人是否在结果集中（指针相等判断）
func containsReviewer(list model.PreContractReviewerDBList, r *model.PreContractReviewerDB) bool {
	for _, item := range list {
		if item == r {
			return true
		}
	}
	return false
}

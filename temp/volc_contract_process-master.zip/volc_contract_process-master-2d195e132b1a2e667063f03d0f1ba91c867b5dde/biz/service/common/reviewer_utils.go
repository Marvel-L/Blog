package common

import (
	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"
)

// FilterHighestPriorityReviewers 过滤出最高优先级的审核人
// 给最高优先级的未审核人发送消息，多人优先级相同时，多人均需要发送消息
func FilterHighestPriorityReviewers(reviewerList model.PreContractReviewerDBList, contractMap map[string]*model.ContractMetaDB) model.PreContractReviewerDBList {
	// 1、去掉 status in （_const.ReviewStatusReviewPass，_const.ReviewStatusChangeReviewer，_const.ReviewStatusSubmitChange，_const.ReviewStatusFinalized）
	var filteredReviewers model.PreContractReviewerDBList
	for _, reviewer := range reviewerList {
		if reviewer.Status == _const.ReviewStatusReviewPass ||
			reviewer.Status == _const.ReviewStatusChangeReviewer ||
			reviewer.Status == _const.ReviewStatusSubmitChange ||
			reviewer.Status == _const.ReviewStatusFinalized {
			continue
		}
		if contract, exists := contractMap[reviewer.PreContractNo]; exists {
			if reviewer.ContractStatus == contract.CooperationStatus {
				filteredReviewers = append(filteredReviewers, reviewer)
			}
		}
	}

	// 2、根据newReviewerList元素里的 priority 来取最高的优先级的审核人，有多少取多少
	priorityMap := make(map[string][]*model.PreContractReviewerDB)
	for _, reviewer := range filteredReviewers {
		priorityMap[reviewer.PreContractNo] = append(priorityMap[reviewer.PreContractNo], reviewer)
	}

	var finalReviewerList model.PreContractReviewerDBList
	for _, reviewers := range priorityMap {
		// 找到最高优先级
		highestPriority := 0
		for _, reviewer := range reviewers {
			if reviewer.Priority > highestPriority {
				highestPriority = reviewer.Priority
			}
		}

		// 收集所有具有最高优先级的审核人
		for _, reviewer := range reviewers {
			if reviewer.Priority == highestPriority {
				finalReviewerList = append(finalReviewerList, reviewer)
			}
		}
	}

	return finalReviewerList
}

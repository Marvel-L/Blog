package autopriceapproval

//import (
//	"context"
//	"fmt"
//	"testing"
//
//	"code.byted.org/gopkg/logs"
//	"github.com/bytedance/mockey"
//	"github.com/smartystreets/goconvey/convey"
//
//	"volc_contract_process/biz/dal"
//	"volc_contract_process/biz/dal/model"
//	"volc_contract_process/biz/service/multienv"
//	"volc_contract_process/pkg/proxy/rediscli"
//)
//
//func Test_buildLock(t *testing.T) {
//	t.Run("case buildLock#1", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			//mockey.Mock(retry.Do).Return("", nil).Build()
//			// Act
//			lock := buildLock(context.Background(), "CT001")
//
//			// Assert
//			convey.So(lock, convey.ShouldNotBeNil)
//		})
//	})
//}
//
//func Test_Handle(t *testing.T) {
//	t.Run("case Handle#1 lock fail", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			lock := &rediscli.RedisLock{}
//			mockey.Mock(buildLock).Return(lock).Build()
//
//			mockey.Mock((*rediscli.RedisLock).Unlock).Return().Build()
//			mockey.Mock((*rediscli.RedisLock).Lock).Return(fmt.Errorf("your error")).Build()
//
//			mockey.Mock(logs.CtxError).Return().Build()
//			mockey.Mock(logs.CtxWarn).Return().Build()
//			mockey.Mock(logs.CtxInfo).Return().Build()
//			// Act
//			err := Handle(context.Background(), "CT001")
//			// Assert
//			convey.So(err, convey.ShouldNotBeNil)
//		})
//	})
//}
//
//func Test_createAgileProcess(t *testing.T) {
//	t.Run("case createAgileProcess#1 contract not exist", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			dao := dal.NewAutoPriceApprovalDao()
//			mockey.Mock(dal.NewAutoPriceApprovalDao).Return(dao).Build()
//			methodFindByContractId := mockey.GetMethod(dao, "FindByContractId")
//			mockey.Mock(methodFindByContractId).Return(nil, fmt.Errorf("error")).Build()
//
//			// Act
//			err := createAgileProcess(context.Background(), &model.ContractMetaDB{}, "")
//			// Assert
//			convey.So(err, convey.ShouldNotBeNil)
//		})
//	})
//	t.Run("case createAgileProcess#2 contract not exist", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			dao := dal.NewAutoPriceApprovalDao()
//			mockey.Mock(dal.NewAutoPriceApprovalDao).Return(dao).Build()
//			methodFindByContractId := mockey.GetMethod(dao, "FindByContractId")
//			mockey.Mock(methodFindByContractId).Return(&model.AutoPriceApproval{
//				ApprovalInstanceId: "demo",
//			}, nil).Build()
//
//			// Act
//			err := createAgileProcess(context.Background(), &model.ContractMetaDB{}, "")
//			// Assert
//			convey.So(err, convey.ShouldBeNil)
//		})
//	})
//}
//
//func Test_needCreateAgileProcess(t *testing.T) {
//	t.Run("case needCreateAgileProcess#1 containsSpecCommodity fail", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			mockey.Mock(logs.CtxInfo).Return().Build()
//			mockey.Mock(containsSpecCommodity).Return(false, fmt.Errorf("")).Build()
//			// Act
//			ret, err := needCreateAgileProcess(context.Background(), model.VolcContractCommodityList{})
//			// Assert
//			convey.So(err, convey.ShouldNotBeNil)
//			convey.So(ret, convey.ShouldEqual, false)
//		})
//	})
//	t.Run("case needCreateAgileProcess#2 containsSpecCommodity has", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			mockey.Mock(logs.CtxInfo).Return().Build()
//			mockey.Mock(containsSpecCommodity).Return(true, nil).Build()
//			// Act
//			ret, err := needCreateAgileProcess(context.Background(), model.VolcContractCommodityList{})
//			// Assert
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(ret, convey.ShouldEqual, true)
//		})
//	})
//	t.Run("case needCreateAgileProcess#3 containsSpecCommodity false, byte_plus true", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			mockey.Mock(logs.CtxInfo).Return().Build()
//			mockey.Mock(containsSpecCommodity).Return(false, nil).Build()
//			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
//			// Act
//			ret, err := needCreateAgileProcess(context.Background(), model.VolcContractCommodityList{})
//			// Assert
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(ret, convey.ShouldEqual, false)
//		})
//	})
//	t.Run("case needCreateAgileProcess#4 containsSpecCommodity false, byte_plus false", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			// Arrange
//			mockey.Mock(logs.CtxInfo).Return().Build()
//			mockey.Mock(containsSpecCommodity).Return(false, nil).Build()
//			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
//			mockey.Mock(containsPrivateSales).Return(true, nil).Build()
//			// Act
//			ret, err := needCreateAgileProcess(context.Background(), model.VolcContractCommodityList{})
//			// Assert
//			convey.So(err, convey.ShouldBeNil)
//			convey.So(ret, convey.ShouldEqual, true)
//		})
//	})
//}

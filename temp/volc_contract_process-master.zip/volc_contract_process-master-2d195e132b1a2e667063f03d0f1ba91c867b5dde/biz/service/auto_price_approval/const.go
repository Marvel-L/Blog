package autopriceapproval

//const (
//	SalesStatusInnerTest    int8 = 1 // 内测
//	SalesStatusInviteTest   int8 = 2 // 邀测
//	SalesStatusPublicTest   int8 = 3 // 公测
//	SalesStatusOfficialSale int8 = 4 // 正式售卖
//)
//
//var ignoreSalesStatus = map[int8]struct{}{
//	SalesStatusInnerTest:  {},
//	SalesStatusInviteTest: {},
//	SalesStatusPublicTest: {},
//}

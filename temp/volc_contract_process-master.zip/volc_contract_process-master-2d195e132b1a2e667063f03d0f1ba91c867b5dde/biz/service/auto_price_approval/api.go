package autopriceapproval

//const (
//	selectAll = "*" // 全部选项
//)

//
//func buildLock(ctx context.Context, contractNo string) *rediscli.RedisLock {
//	lock := &rediscli.RedisLock{
//		LockKey: i18nfmt.Sprintf(ctx, "AutoPriceApprovalCreate:%s", contractNo),
//		Value:   logid.GenLogID() + "_" + strconv.Itoa(rand.Int()),
//		Timeout: 10 * time.Second, // 10秒锁定，后续重复消费由底层方法二次去重判断
//	}
//	return lock
//}

//// Handle 购买权限配置 该逻辑后续会放到【履约系统】，该package仅临时支持
//func Handle(ctx context.Context, contractNo string) error {
//	defer recovery.DefaultRecovery(ctx, "autopriceapproval_Handle")()
//
//	// 加锁判断 避免重复创建
//	lock := buildLock(ctx, contractNo)
//
//	var success bool
//	defer func() {
//		if success {
//			logs.CtxInfo(ctx, "准备释放Lock，key=%s", lock.LockKey)
//			lock.Unlock()
//		}
//	}()
//
//	if err := lock.Lock(); err != nil {
//		logs.CtxWarn(ctx, "获取Lock失败，key=%s", lock.LockKey, err.Error())
//		if errors.Is(err, rediscli.ErrLockObtainFail) {
//			return nil
//		}
//		return err
//	}
//
//	logs.CtxInfo(ctx, "autoprice.Handle, lock success, contractNo=%s", contractNo)
//
//	// 查询合同信息
//	metaDB, err := dal.NewContractMetaDao().FindLastByNo(ctx, nil, contractNo)
//	if err != nil {
//		logs.CtxError(ctx, "autopriceapproval_HandleFail, 查询合同信息错误, no=%s, err=%s", contractNo, err.Error())
//		return err
//	}
//	if metaDB == nil {
//		logs.CtxError(ctx, "autopriceapproval_HandleFail, 合同不存在, no=%s", contractNo)
//		return i18nfmt.New(ctx, "合同不存在")
//	}
//
//	//  检查合同来源
//	hit, err := checkContractType(ctx, metaDB)
//	if err != nil {
//		return err
//	}
//	if !hit {
//		logs.CtxInfo(ctx, "autopriceapproval_HandleEnd, checkContractTypeFail, no=%s", contractNo)
//		return nil
//	}
//
//	// 获取合同商品信息
//	commodityList, err := dal.NewContractCommodityDao().ListByVolcContractId(ctx, nil, int64(metaDB.Id))
//	if err != nil {
//		return err
//	}
//	if len(commodityList) == 0 {
//		logs.CtxInfo(ctx, "autopriceapproval_HandleEnd, commodityListEmpty, no=%s", contractNo)
//		return nil
//	}
//
//	// 判断商品是否包含月结更配、合同中是否包含非公开售卖的配置
//	need, err := needCreateAgileProcess(ctx, commodityList)
//	if err != nil {
//		return err
//	}
//	if !need {
//		logs.CtxInfo(ctx, "autopriceapproval_HandleEnd_ignore_process")
//		return nil
//	}
//
//	logs.CtxInfo(ctx, "autopriceapproval_Handle, begin create process, contractNo=%s", contractNo)
//
//	// 查询业务执行人信息
//	employees, err := larkc.GetEmployeeByID(ctx, metaDB.Operator)
//	if err != nil {
//		logs.CtxError(ctx, "GetEmployeeByIDFail, Operator=%s, err=%s", metaDB.Operator, err.Error())
//		return err
//	}
//	if len(employees) == 0 {
//		logs.CtxError(ctx, "GetEmployeeByIDFail, Operator=%s, err=不存在", metaDB.Operator)
//		return i18nfmt.New(ctx, "业务执行人不存在")
//	}
//
//	operator := employees[0]
//	logs.CtxInfo(ctx, "autopriceapproval_Handle_Prepare_create_process, operatorEmail=%s, contractNo=%s", operator.Email, contractNo)
//
//	// 发起敏捷流程
//	for i := 0; i < 3; i++ {
//		if e := createAgileProcess(ctx, metaDB, operator.Email); e == nil {
//			// 发起成功
//			logs.CtxInfo(ctx, "autopriceapproval_Handle_create_process_Success")
//			success = true
//			return nil
//		}
//	}
//
//	logs.CtxInfo(ctx, "autopriceapproval_Handle_create_process_retry_fail, prepare_notify")
//
//	// 重试3次仍失败 发送消息提醒 该消息认为已经处理完毕 采用消息模板
//	var buf bytes.Buffer
//	buf.WriteString("合同号：")
//	buf.WriteString(metaDB.ContractNo)
//	buf.WriteString("，客户名称：")
//	names := buildCustomerNames(ctx, metaDB.TradePartyInfo)
//	buf.WriteString(names)
//	buf.WriteString("，所属销售：")
//	buf.WriteString(operator.Email)
//	buf.WriteString("\\n")
//
//	larkc.AutoPriceUrgentAlert(ctx, "月结购买权限&实例更配飞书审批发起失败", buf.String())
//
//	return nil
//}

//func buildCustomerNames(ctx context.Context, tradePartyInfos string) string {
//	var info bizmodels.TradePartyInfo
//	if err := json.Unmarshal([]byte(tradePartyInfos), &info); err != nil {
//		logs.CtxError(ctx, "", err.Error())
//		return ""
//	}
//
//	var ids []int64
//	existMap := map[int64]struct{}{}
//	for _, v := range info.OtherParty {
//		arr := strings.Split(v.AccountID, ",")
//		for _, vv := range arr {
//			id, _ := strconv.ParseInt(vv, 10, 64)
//			if id > 0 {
//				if _, exist := existMap[id]; exist {
//					continue
//				}
//				ids = append(ids, id)
//				existMap[id] = struct{}{}
//			}
//		}
//	}
//
//	var names []string
//	for _, id := range ids {
//		accountInfo, _ := accountcli.GetAccountAndVerifyFromCache(ctx, id)
//		if accountInfo != nil {
//			names = append(names, i18nfmt.Sprintf(ctx, "%s(%d)", accountInfo.VerifyName, accountInfo.AccountID))
//		}
//	}
//
//	return strings.Join(names, ",")
//}

// 创建敏捷流程
//func createAgileProcess(ctx context.Context, metaDB *model.ContractMetaDB, applicant string) error {
//
//	// 校验是否已经创建过敏捷流程，若已经创建过 则忽略
//	dao := dal.NewAutoPriceApprovalDao()
//	priceApproval, err := dao.FindByContractId(ctx, nil, metaDB.Id)
//	if err != nil {
//		return err
//	}
//
//	if priceApproval != nil && priceApproval.ApprovalInstanceId != "" {
//		// 已经创建，忽略
//		logs.CtxInfo(ctx, "createAgileProcess, AutoPriceApprovalExisted_Skip, contractNo=%s", metaDB.ContractNo)
//		return nil
//	}
//
//	if priceApproval == nil { // 此处判断不要忽略
//		priceApproval = &model.AutoPriceApproval{
//			ContractId: metaDB.Id,
//			BaseDB: model.BaseDB{
//				CreatedTime: time.Now(),
//				UpdatedTime: time.Now(),
//			},
//		}
//		if err := dao.Create(ctx, nil, priceApproval); err != nil {
//			return err
//		}
//	}
//
//	// 已经提交过
//	if priceApproval.Status != _const.AutoPriceInit {
//		logs.CtxInfo(ctx, "createAgileProcessIgnore, status=%d", priceApproval.Status)
//		return nil
//	}
//
//	// 提交敏捷流程
//	resp, err := feishuapproval.Submit(ctx, feishuapproval.ApplicationTypeAutoPricePerm, applicant, metaDB)
//	if err != nil {
//		logs.CtxError(ctx, "SubmitFail, err=%s", err.Error())
//		return err
//	}
//	if resp == nil {
//		return i18nfmt.New(ctx, "SubmitFail")
//	}
//
//	logID, _ := logid.GetLogIDFromCtx(ctx)
//	logs.CtxInfo(ctx, "报价合同自动配价发起权限申请成功")
//	// 通知 创建敏捷流程成功
//	larkc.AutoPriceAlert(ctx, "月结购买权限&实例更配飞书审批发起成功", i18nfmt.Sprintf(ctx, "流程发起成功，合同号: %s, logId: %s, 流程链接：%s", metaDB.ContractNo, logID, resp.FormInstanceUrl))
//
//	// 更新自动配价权限申请记录
//	priceApproval.ApprovalCode = resp.FormCode
//	priceApproval.ApprovalInstanceId = resp.ProcessInstanceID
//	priceApproval.ApprovalURL = resp.FormInstanceUrl
//	priceApproval.Status = _const.AutoPriceDone
//
//	if err = dao.Update(ctx, nil, priceApproval); err != nil {
//		// 仅告警通知 不报错
//		logs.CtxError(ctx, "保存飞书审批信息失败, err=%s", err.Error())
//		// larkc.AutoPriceAlert(ctx, "报价合同自动配价发起权限申请", i18nfmt.Sprintf(ctx, "保存敏捷流程信息失败，合同号: %s, logId: %s", metaDB.ContractNo, logID))
//		return nil
//	}
//
//	return nil
//}

// 是否需要创建敏捷流程
//func needCreateAgileProcess(ctx context.Context, list model.VolcContractCommodityList) (bool, error) {
//
//	// 首先判断是否包含月结变更商品
//	has, err := containsSpecCommodity(ctx, list)
//	if err != nil {
//		return false, err
//	}
//	if has {
//		return true, nil
//	}
//
//	logs.CtxInfo(ctx, "needCreateAgileProcess_prepareCheckPrivateSales")
//
//	if multienv.IsBytePlus() {
//		logs.CtxInfo(ctx, "needCreateAgileProcess, byte_plus skip")
//		return false, nil
//	} else {
//		// 判断是否公开售卖
//		return containsPrivateSales(ctx, list)
//	}
//
//}

//// 是否包含月结变更商品
//func containsSpecCommodity(ctx context.Context, list model.VolcContractCommodityList) (bool, error) {
//
//	specMappings := conf.GetSettlementSpecCommodity(ctx)
//	if len(specMappings) == 0 {
//		logs.CtxError(ctx, "checkSpecCommodity, specListEmpty")
//		return false, nil
//	}
//
//	for _, v := range list {
//		_, ok := specMappings[v.TradeProduct]
//		if ok {
//			logs.CtxInfo(ctx, "hasSpecCommodity_hit, tradeProduct=%s", v.TradeProduct)
//			return true, nil
//		}
//	}
//
//	return false, nil
//}

// 是否包含【非公开售卖】配置, 当前系统存储：全部选项=*
/**
	- 当“配置”字段是确定值时，直接通过“配置名称”查询“是否公开售卖 = 否”；
	- 当“配置”字段是全部选项时，用“商品+付费方式+配置分类”的查询该条件下的配置是否有“是否公开售卖 = 否”的情况；
  		- “商品”一定会有值，“付费方式”/“配置分类”存在“全部选项”的可能，若选择全部选项时则不用该字段作为查询条件，可能性如下：
    		- “付费方式”、“配置分类”均为指定值，根据“商品+付费方式+配置分类”作为条件组合查询；
    		- “付费方式”为全部选项、“配置分类”为指定选项，根据“商品+配置分类”作为条件组合查询；
    		- “付费方式”为指定选项，“配置分类”为全部选项，根据“商品+付费方式”作为条件组合查询；
*/
//func containsPrivateSales(ctx context.Context, list model.VolcContractCommodityList) (bool, error) {
//
//	var productCodes []string
//	for _, v := range list {
//		productCodes = append(productCodes, v.TradeProduct)
//	}
//	productCodes = util.SingleList(productCodes)
//
//	// 查询所有商品下全部非公开配置
//	configurations, err := tradecli.ListConfigurationOnlyPrivate(ctx, strings.Join(productCodes, ","))
//	if err != nil {
//		return false, err
//	}
//
//	if len(configurations) == 0 {
//		logs.CtxInfo(ctx, "containsPrivateSales, ListConfigurationOnlyPrivate is empty")
//		return false, nil
//	}
//
//	// 收集
//	privateConfigurationSet := map[string]struct{}{}
//	for _, v := range configurations {
//		// 过滤掉：配置售卖状态 = 内测 / 邀测 / 公测
//		if _, ok := ignoreSalesStatus[v.SalesStatus]; ok {
//			logs.CtxInfo(ctx, "containsPrivateSales, skip configurationCode=%s, sales status = %d", v.ConfigurationCode, v.SalesStatus)
//			continue
//		}
//		// IsPublic 0 非公开  1 公开
//		if v.IsPublic == 1 {
//			// 避免接口语义与结果不匹配 打印报警信息
//			logs.CtxWarn(ctx, "ListConfigurationOnlyPrivateFail, containsPublicConf, code=%s", v.ConfigurationCode)
//			continue
//		}
//		logs.CtxInfo(ctx, "非公开配置属性：product=%s, configurationCode=%s, category=%s, cayPrePay=%d", v.Product, v.ConfigurationCode, v.Category, v.CanPrePay)
//		// 精确配置
//		privateConfigurationSet[v.ConfigurationCode] = struct{}{}
//		// 商品+付费方式+配置分类
//		privateConfigurationSet[i18nfmt.Sprintf(ctx, "%s_%d_%s", v.Product, v.CanPrePay, v.Category)] = struct{}{}
//		// 商品+配置分类
//		privateConfigurationSet[i18nfmt.Sprintf(ctx, "%s_%s", v.Product, v.Category)] = struct{}{}
//		// 商品+付费方式
//		privateConfigurationSet[i18nfmt.Sprintf(ctx, "%s_%d", v.Product, v.CanPrePay)] = struct{}{}
//		// 仅商品，避免重复添加自定义前缀
//		privateConfigurationSet[i18nfmt.Sprintf(ctx, "product_vcp_%s", v.Product)] = struct{}{}
//	}
//
//	// 新增日志打印
//	if len(privateConfigurationSet) > 0 {
//		if len(configurations) > 0 {
//			body, _ := json.Marshal(configurations)
//			logs.CtxInfo(ctx, "ListConfigurationOnlyPrivateResp => %s", string(body))
//		} else {
//			logs.CtxInfo(ctx, "ListConfigurationOnlyPrivateResp_empty")
//		}
//	}
//
//	for _, v := range list {
//
//		logs.CtxInfo(ctx, "当前商品属性：product=%s, configurationCode=%s, category=%s, cayPrePay=%d", v.TradeProduct, v.Configuration, v.ConfigCategory, v.CanPrePay)
//
//		// 有精确配置的情况
//		if v.Configuration != selectAll {
//			if _, exist := privateConfigurationSet[v.Configuration]; exist {
//				logs.CtxWarn(ctx, "containsPrivateSalesA, code=%s", v.Configuration)
//				return true, nil
//			}
//			continue
//		}
//
//		// 付费方式、配置分类都为【全部选项】
//		if v.CanPrePayCode == selectAll && isAllConfigCategory(v.ConfigCategory) {
//			// 仅商品，避免重复添加自定义前缀
//			if _, exist := privateConfigurationSet[i18nfmt.Sprintf(ctx, "product_vcp_%s", v.TradeProduct)]; exist {
//				logs.CtxWarn(ctx, "containsPrivateSalesB, product=%s", v.TradeProduct)
//				return true, nil
//			}
//			continue
//		}
//
//		if v.CanPrePayCode == selectAll {
//			// 商品+配置分类
//			key := i18nfmt.Sprintf(ctx, "%s_%s", v.TradeProduct, v.ConfigCategory)
//			if _, exist := privateConfigurationSet[key]; exist {
//				logs.CtxWarn(ctx, "containsPrivateSalesC, product=%s, category=%s", v.TradeProduct, v.ConfigCategory)
//				return true, nil
//			}
//		} else if v.ConfigCategory == selectAll || isAllConfigCategory(v.ConfigCategory) {
//			// 商品+付费方式
//			key := i18nfmt.Sprintf(ctx, "%s_%s", v.TradeProduct, v.CanPrePayCode)
//			if _, exist := privateConfigurationSet[key]; exist {
//				logs.CtxWarn(ctx, "containsPrivateSalesD, product=%s, CanPrePayCode=%s", v.TradeProduct, v.CanPrePayCode)
//				return true, nil
//			}
//		}
//	}
//
//	return false, nil
//}
//
//func isAllConfigCategory(v string) bool {
//	return v == selectAll || v == ""
//}
//
//// 检查合同类型
//func checkContractType(ctx context.Context, metaDB *model.ContractMetaDB) (bool, error) {
//
//	if metaDB.BizScene == _const.BizSceneQuoteContract {
//		return true, nil
//	}
//
//	if metaDB.BizSource == _const.BizSourceCooperation && metaDB.RelateQuoteNo != "" {
//		logs.CtxInfo(ctx, "checkTriggerConditionTrue, quoteNo=%s", metaDB.RelateQuoteNo)
//		return true, nil
//	}
//
//	return false, nil
//}

package contractintelligence

import (
	"code.byted.org/eps-platform/volcengine-innersdk-golang/service/c360callservice"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"context"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"os"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/crminnertopcli"
	"volc_contract_process/pkg/proxy/larkc"
)

func setBytePlusEnv(t *testing.T, value string) func() {
	t.Helper()
	oldValue, existed := os.LookupEnv(multienv.EnvIsBytePlusFlag)
	if err := os.Setenv(multienv.EnvIsBytePlusFlag, value); err != nil {
		t.Fatalf("set %s failed: %v", multienv.EnvIsBytePlusFlag, err)
	}
	return func() {
		if existed {
			_ = os.Setenv(multienv.EnvIsBytePlusFlag, oldValue)
			return
		}
		_ = os.Unsetenv(multienv.EnvIsBytePlusFlag)
	}
}

func TestGetAIAuditReportReqValidate(t *testing.T) {
	convey.Convey("validate get ai audit report request", t, func() {
		req := &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		}
		convey.So(req.Validate(), convey.ShouldBeNil)

		req.CurrentOperator = ""
		convey.So(req.Validate(), convey.ShouldNotBeNil)

		req.CurrentOperator = "operator@bytedance.com"
		req.ContractNo = ""
		convey.So(req.Validate(), convey.ShouldNotBeNil)
	})
}

func TestServiceImplGetAIAuditReport(t *testing.T) {
	mockey.PatchConvey("get ai audit report returns nil in byte plus env", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "1")
		defer restore()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp, convey.ShouldBeNil)
	})

	mockey.PatchConvey("get ai audit report success", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "0")
		defer restore()
		mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{
			Email: "operator@bytedance.com",
			Name:  "张三",
		}, nil).Build()
		mockey.Mock(crminnertopcli.GetContractAiReview).To(func(ctx context.Context, input *c360callservice.GetContractAiReviewInput) (*c360callservice.GetContractAiReviewOutput, error) {
			convey.So(*input.ContractNo, convey.ShouldEqual, "C001")
			convey.So(*input.UserInfo.Email, convey.ShouldEqual, "operator@bytedance.com")
			convey.So(*input.UserInfo.Name, convey.ShouldEqual, "张三")
			return (&c360callservice.GetContractAiReviewOutput{}).SetData((&c360callservice.DataForGetContractAiReviewOutput{}).
				SetVisible(true).
				SetStatus("finished").
				SetFeishuDocURL("https://bytedance.feishu.cn/docx/report")), nil
		}).Build()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp.ContractNo, convey.ShouldEqual, "C001")
		convey.So(resp.Visible, convey.ShouldBeTrue)
		convey.So(resp.AuditTaskState, convey.ShouldEqual, "finished")
		convey.So(resp.ReportURL, convey.ShouldEqual, "https://bytedance.feishu.cn/docx/report")
	})

	mockey.PatchConvey("get ai audit report degrades when crm fails", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "0")
		defer restore()
		mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{
			Email: "operator@bytedance.com",
			Name:  "张三",
		}, nil).Build()
		mockey.Mock(crminnertopcli.GetContractAiReview).Return(nil, fmt.Errorf("crm failed")).Build()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp.ContractNo, convey.ShouldEqual, "C001")
		convey.So(resp.Visible, convey.ShouldBeFalse)
		convey.So(resp.AuditTaskState, convey.ShouldEqual, _const.AIAuditReportStatusFailed)
		convey.So(resp.ReportURL, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("get ai audit report returns default resp when crm visible false", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "0")
		defer restore()
		mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{
			Email: "operator@bytedance.com",
			Name:  "张三",
		}, nil).Build()
		mockey.Mock(crminnertopcli.GetContractAiReview).Return((&c360callservice.GetContractAiReviewOutput{}).
			SetData((&c360callservice.DataForGetContractAiReviewOutput{}).
				SetVisible(false).
				SetStatus("finished").
				SetFeishuDocURL("https://bytedance.feishu.cn/docx/report")), nil).Build()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp.ContractNo, convey.ShouldEqual, "C001")
		convey.So(resp.Visible, convey.ShouldBeFalse)
		convey.So(resp.AuditTaskState, convey.ShouldEqual, _const.AIAuditReportStatusFailed)
		convey.So(resp.ReportURL, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("get ai audit report degrades when employee name missing", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "0")
		defer restore()
		mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(&peopleclient.Employee{
			Email: "operator@bytedance.com",
		}, nil).Build()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp.ContractNo, convey.ShouldEqual, "C001")
		convey.So(resp.Visible, convey.ShouldBeFalse)
		convey.So(resp.AuditTaskState, convey.ShouldEqual, _const.AIAuditReportStatusFailed)
		convey.So(resp.ReportURL, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("get ai audit report degrades when employee lookup fails", t, func() {
		ctx := context.Background()
		restore := setBytePlusEnv(t, "0")
		defer restore()
		mockey.Mock(larkc.GetEmployeeByEmailWithCache).Return(nil, fmt.Errorf("employee lookup failed")).Build()

		resp, err := NewService().GetAIAuditReport(ctx, &bizmodels.GetAIAuditReportReq{
			CurrentOperator: "operator@bytedance.com",
			ContractNo:      "C001",
		})

		convey.So(err, convey.ShouldBeNil)
		convey.So(resp.ContractNo, convey.ShouldEqual, "C001")
		convey.So(resp.Visible, convey.ShouldBeFalse)
		convey.So(resp.AuditTaskState, convey.ShouldEqual, _const.AIAuditReportStatusFailed)
		convey.So(resp.ReportURL, convey.ShouldEqual, "")
	})
}

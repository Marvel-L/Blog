package contractintelligence

import (
	"context"
	"strings"

	"code.byted.org/eps-platform/volcengine-innersdk-golang/service/c360callservice"
	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/crminnertopcli"
	"volc_contract_process/pkg/proxy/larkc"
)

// GetAIAuditReport 查询合同智能审核报告，并转换为前端可展示结果。
func (s *serviceImpl) GetAIAuditReport(ctx context.Context, req *bizmodels.GetAIAuditReportReq) (*bizmodels.GetAIAuditReportResp, error) {
	logs.CtxInfo(ctx, "GetAIAuditReport, req:%v", req)
	if multienv.IsBytePlus() {
		logs.CtxInfo(ctx, "GetAIAuditReportSkipBytePlusEnv")
		return nil, nil
	}
	if err := req.Validate(); err != nil {
		return nil, err
	}

	contractNo := strings.TrimSpace(req.ContractNo)
	currentOperator := strings.TrimSpace(req.CurrentOperator)
	resp := &bizmodels.GetAIAuditReportResp{
		ContractNo:     contractNo,
		Visible:        false,
		AuditTaskState: _const.AIAuditReportStatusFailed,
	}
	employee, err := larkc.GetEmployeeByEmailWithCache(ctx, currentOperator)
	if err != nil {
		logs.CtxError(ctx, "GetAIAuditReportGetEmployeeFail, CurrentOperator:%s, err:%v", currentOperator, err)
		return resp, nil
	}
	if employee == nil || strings.TrimSpace(employee.Name) == "" {
		logs.CtxWarn(ctx, "GetAIAuditReportGetEmployeeEmpty, CurrentOperator:%s", currentOperator)
		return resp, nil
	}

	crmResp, err := crminnertopcli.GetContractAiReview(ctx, (&c360callservice.GetContractAiReviewInput{}).
		SetContractNo(contractNo).
		SetUserInfo((&c360callservice.UserInfoForGetContractAiReviewInput{}).
			SetEmail(currentOperator).
			SetName(strings.TrimSpace(employee.Name))))
	if err != nil {
		logs.CtxError(ctx, "GetContractAiReviewFail, ContractNo:%s, CurrentOperator:%s, err:%v", req.ContractNo, req.CurrentOperator, err)
		return resp, nil
	}
	if crmResp == nil || crmResp.Data == nil {
		logs.CtxWarn(ctx, "GetContractAiReviewEmpty, ContractNo:%s, CurrentOperator:%s", req.ContractNo, req.CurrentOperator)
		return resp, nil
	}
	// 当前操作人没有查看权限，默认兜底为任务失败，前端不展示查看入口
	if crmResp.Data.Visible != nil && !*crmResp.Data.Visible {
		return resp, nil
	}

	if crmResp.Data.Visible != nil {
		resp.Visible = *crmResp.Data.Visible
	}
	if crmResp.Data.FeishuDocURL != nil {
		resp.ReportURL = strings.TrimSpace(*crmResp.Data.FeishuDocURL)
	}
	if crmResp.Data.Status != nil {
		resp.AuditTaskState = strings.TrimSpace(*crmResp.Data.Status)
	}
	return resp, nil
}

package dal

import (
	"context"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/util"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tBContractAttachment = "volc_contract_attachment"
)

type ContractAttachmentDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractAttachmentDB) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.ContractAttachmentDB) error
	UpdateByFileKey(ctx context.Context, tx *gorm.DB, fileKey string, updates map[string]interface{}) error
	ChangeContractNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error
	ListByNo(ctx context.Context, tx *gorm.DB, contractNo string) (model.ContractAttachmentDBList, error)
	ListByFileKey(ctx context.Context, tx *gorm.DB, fileKey string) (*model.ContractAttachmentDB, error)
	ListByFileKeys(ctx context.Context, tx *gorm.DB, fileKeys []string) (model.ContractAttachmentDBList, error)
	FindByFileKey(ctx context.Context, tx *gorm.DB, fileKey string) (*model.ContractAttachmentDB, error)
}

var _contractAttachmentDaoInstance = &contractAttachmentDaoImpl{}

func NewContractAttachmentDao() ContractAttachmentDao {
	return _contractAttachmentDaoInstance
}

type contractAttachmentDaoImpl struct {
}

func (c *contractAttachmentDaoImpl) ChangeContractNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error {

	err := initDB(ctx, tx).Table(tBContractAttachment).Where("contract_no = ?", oldNo).
		Updates(map[string]interface{}{"contract_no": newNo}).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangeContractNoFail, err: %v", err)
		return i18nfmt.New(ctx, "ChangeContractNoFail")
	}

	return nil
}

func (c *contractAttachmentDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.ContractAttachmentDB) error {
	err := initDB(ctx, tx).Table(tBContractAttachment).Where("file_key = ?", entity.FileKey).Updates(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractAttachmentFail, contractNo:%d, err:%s", entity.ContractNo, err.Error())
		return i18nfmt.New(ctx, "updateContractAttachmentFail")
	}
	return nil
}

func (c *contractAttachmentDaoImpl) UpdateByFileKey(ctx context.Context, tx *gorm.DB, fileKey string, updates map[string]interface{}) error {
	err := initDB(ctx, tx).Table(tBContractAttachment).Where("file_key = ?", fileKey).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractAttachmentFail, fileKey:%s, err:%s", fileKey, err.Error())
		return i18nfmt.New(ctx, "updateContractAttachmentFail")
	}
	return nil
}

func (c *contractAttachmentDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractAttachmentDB) error {
	err := initDB(ctx, tx).Table(tBContractAttachment).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractAttachmentFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractAttachmentFail")
	}
	return nil
}

func (c *contractAttachmentDaoImpl) ListByNo(ctx context.Context, tx *gorm.DB, contractNo string) (model.ContractAttachmentDBList, error) {
	if len(contractNo) == 0 {
		logs.CtxInfo(ctx, "ListByNo, contractNo is nil, contractNo:%s", contractNo)
		return model.ContractAttachmentDBList{}, nil
	}
	db := initDB(ctx, tx).Table(tBContractAttachment).Where("contract_no = ? ", contractNo)
	var ret model.ContractAttachmentDBList
	err := db.Find(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contractNo=%s, err=%s", contractNo, err.Error())
		return nil, i18nfmt.New(ctx, "FindByNoFail")
	}
	return ret, nil
}

func (c *contractAttachmentDaoImpl) ListByFileKeys(ctx context.Context, tx *gorm.DB, fileKeys []string) (model.ContractAttachmentDBList, error) {
	fileKeys = util.SingleList(fileKeys)
	if len(fileKeys) == 0 {
		return model.ContractAttachmentDBList{}, nil
	}
	db := initDB(ctx, tx).Table(tBContractAttachment).Where("file_key in (?)", fileKeys)
	var ret model.ContractAttachmentDBList
	err := db.Find(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByFileKeysFail, fileKeys=%s, err=%s", fileKeys, err.Error())
		return nil, i18nfmt.New(ctx, "ListByFileKeysFail")
	}
	return ret, nil
}

func (c *contractAttachmentDaoImpl) ListByFileKey(ctx context.Context, tx *gorm.DB, fileKey string) (*model.ContractAttachmentDB, error) {
	if len(fileKey) == 0 {
		logs.CtxInfo(ctx, "ListByFileKey,fileKey is nil, fileKey:%s", fileKey)
		return nil, nil
	}

	db := initDB(ctx, tx).Table(tBContractAttachment).Where("file_key = ? ", fileKey)
	var ret model.ContractAttachmentDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByFileKeyFail, file_key=%s, err=%s", fileKey, err.Error())
		return nil, i18nfmt.New(ctx, "FindByFileKeyFail")
	}
	if ret.Id > 0 {
		return &ret, nil
	}
	return nil, nil
}

func (c *contractAttachmentDaoImpl) FindByFileKey(ctx context.Context, tx *gorm.DB, fileKey string) (*model.ContractAttachmentDB, error) {
	if len(fileKey) == 0 {
		logs.CtxInfo(ctx, "FindByFileKey,fileKey is nil, fileKey:%s", fileKey)
		return nil, nil
	}
	db := initDB(ctx, tx).Table(tBContractAttachment).Where("file_key = ? ", fileKey)
	var ret model.ContractAttachmentDB
	err := db.Last(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByFileKeyFail, file_key=%s, err=%s", fileKey, err.Error())
		return nil, i18nfmt.New(ctx, "FindByFileKeyFail")
	}
	return &ret, nil
}

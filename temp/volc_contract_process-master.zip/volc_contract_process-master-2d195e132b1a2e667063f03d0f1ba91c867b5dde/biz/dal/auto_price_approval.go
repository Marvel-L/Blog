package dal

import (
	"context"
	"errors"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tVolcAutoPriceApproval = "volc_auto_price_approval"
)

// AutoPriceApprovalDao 购买权限申请 临时代码 后续由履约系统承接
type AutoPriceApprovalDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.AutoPriceApproval) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.AutoPriceApproval) error
	UpdateByContractId(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error
	FindByContractId(ctx context.Context, tx *gorm.DB, contractId uint64) (*model.AutoPriceApproval, error)
}

var _autoPriceApprovalDaoInstance = &autoPriceApprovalDaoImpl{}

func NewAutoPriceApprovalDao() AutoPriceApprovalDao {
	return _autoPriceApprovalDaoInstance
}

type autoPriceApprovalDaoImpl struct {
}

func (a *autoPriceApprovalDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.AutoPriceApproval) error {
	err := initDB(ctx, tx).Table(tVolcAutoPriceApproval).Select("*").Omit("created_time").Updates(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateAutoPriceApprovalFail, err:%s", err.Error())
		return errors.New("updateAutoPriceApprovalFail")
	}
	return nil
}

func (a *autoPriceApprovalDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.AutoPriceApproval) error {
	err := initDB(ctx, tx).Table(tVolcAutoPriceApproval).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createAutoPriceApprovalFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createAutoPriceApprovalFail")
	}
	return nil
}

func (a *autoPriceApprovalDaoImpl) UpdateByContractId(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tVolcAutoPriceApproval)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByContractIdFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByContractIdFail")
	}
	return nil
}

func (a *autoPriceApprovalDaoImpl) FindByContractId(ctx context.Context, tx *gorm.DB, contractId uint64) (*model.AutoPriceApproval, error) {

	logs.CtxInfo(ctx, "FindByContractId, contractId=%d", contractId)

	db := initDB(ctx, tx).Table(tVolcAutoPriceApproval).Where("contract_id = ?", contractId)

	var ret model.AutoPriceApproval

	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contractId=%d, err=%s", contractId, err.Error())
		return nil, i18nfmt.New(ctx, "FindByNoFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

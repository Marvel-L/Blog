package dal

import (
	"context"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"

	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tCommonBizRetry = "common_retry_task"
)

// CommonRetryTaskDao 业务重试表
type CommonRetryTaskDao interface {
	// Create 新增重试任务
	Create(ctx context.Context, tx *gorm.DB, recordDB *model.CommonRetryTaskDB) error
	// FindByIdentifier 根据ID查询
	FindByIdentifier(ctx context.Context, tx *gorm.DB, taskType int, identifier string, scene int) (*model.CommonRetryTaskDB, error)
	// ListWaitRetry 查询待重试列表
	ListWaitRetry(ctx context.Context, tx *gorm.DB) (model.CommonRetryTaskDBList, error)
	// IncrRetryCount 更新重试次数
	IncrRetryCount(ctx context.Context, tx *gorm.DB, taskType int, identifier string, curCount int) error
	// UpdateStatus 更新任务状态
	UpdateStatus(ctx context.Context, tx *gorm.DB, taskType int, identifier string, status int) error
	// UpdateCommonRetryTask 更新任务信息
	UpdateCommonRetryTask(ctx context.Context, tx *gorm.DB, entity *model.CommonRetryTaskDB) error
	// UpdateFieldsByNo 更新任务信息
	UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, identifier string, taskType int, updates map[string]interface{}) error
}

var _commonRetryTaskInstance = &commonCommonRetryTaskDaoImpl{}

func NewCommonRetryTaskDao() CommonRetryTaskDao {
	return _commonRetryTaskInstance
}

type commonCommonRetryTaskDaoImpl struct {
}

func (c *commonCommonRetryTaskDaoImpl) Create(ctx context.Context, tx *gorm.DB, recordDB *model.CommonRetryTaskDB) error {
	logID, exist := logid.GetLogIDFromCtx(ctx)
	if exist {
		recordDB.TriggerLogID = logID
	}
	err := initDB(ctx, tx).Table(tCommonBizRetry).Create(recordDB).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateRetryTaskFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "CreateRetryTaskFail")
	}
	return nil
}

func (c *commonCommonRetryTaskDaoImpl) FindByIdentifier(ctx context.Context, tx *gorm.DB, taskType int, identifier string, scene int) (*model.CommonRetryTaskDB, error) {
	var ret model.CommonRetryTaskDB
	db := initDB(ctx, tx).Table(tCommonBizRetry).Where("task_type = ?", taskType).
		Where("identifier = ?", identifier).Where("scene = ?", scene)
	if err := db.First(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdentifierFail, task_type:%s, identifier:%s, err:%s", taskType, identifier, err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdentifierFail")
	}
	if ret.Id > 0 {
		return &ret, nil
	}
	return nil, nil
}

func (c *commonCommonRetryTaskDaoImpl) ListWaitRetry(ctx context.Context, tx *gorm.DB) (model.CommonRetryTaskDBList, error) {
	var ret []*model.CommonRetryTaskDB
	db := initDB(ctx, tx).Table(tCommonBizRetry).Where("status in (?)", []int{_const.RetryTaskStatusInit})
	if err := db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListWaitRetryFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListWaitRetryFail")
	}
	return ret, nil
}

func (c *commonCommonRetryTaskDaoImpl) IncrRetryCount(ctx context.Context, tx *gorm.DB, taskType int, identifier string, curCount int) error {
	err := initDB(ctx, tx).Table(tCommonBizRetry).Where("task_type = ?", taskType).
		Where("identifier = ?", identifier).
		Where("retry_count = ?", curCount).
		Updates(map[string]interface{}{
			"retry_count": curCount + 1,
		}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateStatusFail, err: %v", err)
		return i18nfmt.New(ctx, "UpdateStatusFail")
	}
	return nil
}

func (c *commonCommonRetryTaskDaoImpl) UpdateStatus(ctx context.Context, tx *gorm.DB, taskType int, identifier string, status int) error {
	err := initDB(ctx, tx).Table(tCommonBizRetry).Where("task_type = ?", taskType).Where("identifier = ?", identifier).
		Updates(map[string]interface{}{
			"status": status,
		}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateStatusFail, err: %v", err)
		return i18nfmt.New(ctx, "UpdateStatusFail")
	}
	return nil
}

func (c *commonCommonRetryTaskDaoImpl) UpdateCommonRetryTask(ctx context.Context, tx *gorm.DB, entity *model.CommonRetryTaskDB) error {
	updates := map[string]interface{}{}
	updates["detail"] = entity.Detail
	updates["retry_count"] = entity.RetryCount
	updates["status"] = entity.Status
	updates["remark"] = entity.Remark
	logID, exist := logid.GetLogIDFromCtx(ctx)
	if exist {
		updates["trigger_log_id"] = logID
	}

	return c.UpdateFieldsByNo(ctx, tx, entity.Identifier, entity.TaskType, updates)
}

func (c *commonCommonRetryTaskDaoImpl) UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, identifier string, taskType int, updates map[string]interface{}) error {
	err := initDB(ctx, tx).Table(tCommonBizRetry).Where("identifier = ?", identifier).
		Where("task_type = ?", taskType).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateFieldsByNoFail, updateMap:%v, err: %v", updates, err)
		return i18nfmt.New(ctx, "UpdateFieldsByNoFail")
	}
	return nil
}

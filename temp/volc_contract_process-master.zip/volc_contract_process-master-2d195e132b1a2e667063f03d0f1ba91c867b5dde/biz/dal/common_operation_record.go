package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

const (
	tCommonOperationRecord = "common_operation_record"
)

type CommonOperationRecordDao interface {
	CreateOperationRecord(ctx context.Context, tx *gorm.DB, recordDB *model.CommonOperationRecordDB) error
	ListOperationRecordByIdentNo(ctx context.Context, tx *gorm.DB, identNo string, scene int) (model.CommonOperationRecordDBList, error)
	ListOperationRecordByContractID(ctx context.Context, tx *gorm.DB, scene int, contractID int64) (model.CommonOperationRecordDBList, error)
	GetLastOperationRecord(ctx context.Context, tx *gorm.DB, operation int, identNo string, scene int) (*model.CommonOperationRecordDB, error)
	GetLastOperationRecordByCreatedTime(ctx context.Context, tx *gorm.DB, req *model.CommonOperationRecordCreatedTimeReq) (*model.CommonOperationRecordDB, error)
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.CommonOperationRecordDBList, error)
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
}

var _commonOperationRecordInstance = &commonOperationRecordImpl{}

func NewCommonOperationRecordDao() CommonOperationRecordDao {
	return _commonOperationRecordInstance
}

type commonOperationRecordImpl struct {
}

func (c *commonOperationRecordImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tCommonOperationRecord)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c *commonOperationRecordImpl) CreateOperationRecord(ctx context.Context, tx *gorm.DB, recordDB *model.CommonOperationRecordDB) error {
	err := initDB(ctx, tx).Table(tCommonOperationRecord).Create(recordDB).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateOperationRecordFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "CreateOperationRecordFail")
	}
	return nil
}

func (c *commonOperationRecordImpl) ListOperationRecordByIdentNo(ctx context.Context, tx *gorm.DB, identNo string, scene int) (model.CommonOperationRecordDBList, error) {
	var list model.CommonOperationRecordDBList
	db := initDB(ctx, tx).Table(tCommonOperationRecord).Where("scene = ?", scene).Where("ident_no = ?", identNo).
		Where("operation IN ?", _const.SupportedApprovalOperationList)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListOperationRecordByIdentNoFail, identNo:%s, err:%s", identNo, err.Error())
		return nil, i18nfmt.New(ctx, "ListOperationRecordByIdentNoFail")
	}
	return list, nil
}

func (c *commonOperationRecordImpl) ListOperationRecordByContractID(ctx context.Context, tx *gorm.DB, scene int, contractID int64) (model.CommonOperationRecordDBList, error) {
	var list model.CommonOperationRecordDBList
	db := initDB(ctx, tx).Table(tCommonOperationRecord).Where("scene = ? and volc_contract_id = ?", scene, contractID).
		Where("operation IN ?", _const.SupportedApprovalOperationList)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListOperationRecordByIdentNoFail, scene=%d, contractID:%s, err:%s", scene, contractID, err.Error())
		return nil, i18nfmt.New(ctx, "ListOperationRecordByIdentNoFail")
	}
	return list, nil
}

func (c *commonOperationRecordImpl) GetLastOperationRecord(ctx context.Context, tx *gorm.DB, operation int, identNo string, scene int) (*model.CommonOperationRecordDB, error) {
	var record model.CommonOperationRecordDB
	db := initDB(ctx, tx).Table(tCommonOperationRecord).Where("scene = ?", scene).Where("ident_no = ?", identNo).
		Where("operation = ?", operation).Order("id desc").Limit(1)
	if err := db.Find(&record).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListOperationRecordByIdentNoFail, identNo:%s, err:%s", identNo, err.Error())
		return nil, i18nfmt.New(ctx, "ListOperationRecordByIdentNoFail")
	}
	return &record, nil
}

func (c *commonOperationRecordImpl) GetLastOperationRecordByCreatedTime(ctx context.Context, tx *gorm.DB, req *model.CommonOperationRecordCreatedTimeReq) (*model.CommonOperationRecordDB, error) {
	if req == nil {
		return nil, i18nfmt.New(ctx, "req_is_nil")
	}
	if req.VolcContractID == 0 {
		return nil, i18nfmt.New(ctx, "volcContractID_is_nil")
	}

	var record model.CommonOperationRecordDB
	db := initDB(ctx, tx).Table(tCommonOperationRecord).
		Where("scene = ?", req.Scene).
		Where("volc_contract_id = ?", req.VolcContractID).
		Where("operation = ?", req.Operation).
		Where("created_time = ?", req.CreatedTime).
		Order("id desc").Limit(1)
	result := db.Find(&record)
	if ignoreErr(result.Error) != nil {
		logs.CtxError(ctx, "ListOperationRecordByContractIDFail, contractID:%d, err:%s", req.VolcContractID, result.Error.Error())
		return nil, i18nfmt.New(ctx, "ListOperationRecordByContractIDFail")
	}
	if result.RowsAffected == 0 {
		return nil, nil
	}
	return &record, nil
}

func (c *commonOperationRecordImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.CommonOperationRecordDBList, error) {
	db := initDB(ctx, tx).Table(tCommonOperationRecord).Where("id >= ?", startID)
	var list model.CommonOperationRecordDBList
	err := db.Order("id asc").Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListByIdRangeFail")
	}
	return list, nil
}

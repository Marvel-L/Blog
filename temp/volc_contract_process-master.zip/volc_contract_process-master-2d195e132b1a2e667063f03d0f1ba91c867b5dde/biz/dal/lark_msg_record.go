package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tBLarkMsgRecord = "lark_msg_record"
)

// LarkMsgRecordDao 飞书消息发送记录表Dao
type LarkMsgRecordDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.LarkMsgRecordDB) error
}

var _larkMsgRecordDaoInstance = &larkMsgRecordDaoImpl{}

func NewLarkMsgRecordDao() LarkMsgRecordDao {
	return _larkMsgRecordDaoInstance
}

type larkMsgRecordDaoImpl struct {
}

func (l *larkMsgRecordDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.LarkMsgRecordDB) error {
	err := initDB(ctx, tx).Table(tBLarkMsgRecord).Select("*").Create(entity).Error
	if retErr := ignoreErr(err); retErr != nil {
		logs.CtxError(ctx, "createLarkMsgRecordDBFail, err:%s", retErr.Error())
		return i18nfmt.New(ctx, "createLarkMsgRecordDBFail")
	}
	return nil
}

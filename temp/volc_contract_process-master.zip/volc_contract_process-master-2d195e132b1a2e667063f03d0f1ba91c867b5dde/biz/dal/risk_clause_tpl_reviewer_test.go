package dal

import (
	"context"
	"errors"
	"testing"

	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_riskClauseTplReviewerDaoImpl_ListNewestByTemplateIDs_BitsUTGen(t *testing.T) {
	t.Run("Return nil when templateIDs is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Act
			r := riskClauseTplReviewerDaoImpl{}
			list, err := r.ListNewestByTemplateIDs(context.Background(), nil, []int64{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("Return i18n error when query fails and error not ignored", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			failErr := errors.New("db fatal error")
			mockey.MockUnsafe(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: failErr}).Build()

			// Act
			r := riskClauseTplReviewerDaoImpl{}
			list, err := r.ListNewestByTemplateIDs(context.Background(), nil, []int64{1, 2})

			// Assert
			convey.So(list, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListNewestByTemplateIDsFail")
		})
	})

	t.Run("Return reviewers list when query success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockUnsafe(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(_ *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				data := []*model.RiskClauseTplReviewerDB{
					{RiskClauseTplID: 10, Reviewer: "alice", IsNewest: 1},
					{RiskClauseTplID: 20, Reviewer: "bob", IsNewest: 1},
				}
				if p, ok := dest.(*[]*model.RiskClauseTplReviewerDB); ok {
					*p = data
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			r := riskClauseTplReviewerDaoImpl{}
			list, err := r.ListNewestByTemplateIDs(context.Background(), nil, []int64{10, 20})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldNotBeNil)
			convey.So(len(list), convey.ShouldEqual, 2)
			convey.So(list[0].Reviewer, convey.ShouldEqual, "alice")
			convey.So(list[1].Reviewer, convey.ShouldEqual, "bob")
		})
	})
}

func Test_riskClauseTplReviewerDaoImpl_MigrateReviewersToHistory_BitsUTGen(t *testing.T) {
	t.Run("Return nil when update succeeds", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange: mock the DB chain to return nil error
			ctx := context.Background()
			dao := riskClauseTplReviewerDaoImpl{}
			db := &gorm.DB{}

			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// Act
			err := dao.MigrateReviewersToHistory(ctx, nil, int64(100), int64(200), 1)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return i18n error when update fails and is not ignored", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange: force online env to avoid RASP ignore, mock DB chain to return a non-ignored error
			env.Runtime = env.EnvOnline
			defer func() { env.Runtime = env.EnvOffline }()

			ctx := context.Background()
			dao := riskClauseTplReviewerDaoImpl{}
			db := &gorm.DB{}

			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(&gorm.DB{Error: errors.New("db error")}).Build()

			// Avoid nil pointer inside logs.CtxError
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// Act
			err := dao.MigrateReviewersToHistory(ctx, nil, int64(101), int64(201), 2)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "MigrateReviewersToHistoryFail")
		})
	})
}

func Test_riskClauseTplReviewerDaoImpl_ListHistoryByTemplateIDs_BitsUTGen(t *testing.T) {
	t.Run("Empty templateIDs returns nil result", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Act
			dao := riskClauseTplReviewerDaoImpl{}
			list, err := dao.ListHistoryByTemplateIDs(context.Background(), nil, []int64{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("DB Find returns nil error and list is returned", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			db := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Find).Return(&gorm.DB{Error: nil}).Build()

			// Act
			dao := riskClauseTplReviewerDaoImpl{}
			list, err := dao.ListHistoryByTemplateIDs(context.Background(), nil, []int64{1, 2})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("ErrRecordNotFound is ignored and list returned", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			db := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			dao := riskClauseTplReviewerDaoImpl{}
			list, err := dao.ListHistoryByTemplateIDs(context.Background(), nil, []int64{3})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("RASP error offline is ignored and list returned", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			env.Runtime = env.EnvOffline
			db := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Find).Return(&gorm.DB{Error: errors.New("some error: API blocked by RASP")}).Build()

			// Act
			dao := riskClauseTplReviewerDaoImpl{}
			list, err := dao.ListHistoryByTemplateIDs(context.Background(), nil, []int64{10})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("Non-ignorable DB error returns i18n error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			env.Runtime = env.EnvOffline
			db := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Find).Return(&gorm.DB{Error: errors.New("db failed")}).Build()

			// Act
			dao := riskClauseTplReviewerDaoImpl{}
			list, err := dao.ListHistoryByTemplateIDs(context.Background(), nil, []int64{100})

			// Assert
			convey.So(list, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListByTemplateIDsFail")
		})
	})
}

func Test_riskClauseTplReviewerDaoImpl_CreateInBatches_BitsUTGen(t *testing.T) {
	t.Run("Return nil when entities is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			r := riskClauseTplReviewerDaoImpl{}
			ctx := context.Background()
			var entities []*model.RiskClauseTplReviewerDB

			// Act
			err := r.CreateInBatches(ctx, nil, entities)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return nil when DB CreateInBatches returns ErrRecordNotFound (ignored error)", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocks
			db := &gorm.DB{}
			retDB := &gorm.DB{Error: gorm.ErrRecordNotFound}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).CreateInBatches).Return(retDB).Build()

			// Arrange inputs
			r := riskClauseTplReviewerDaoImpl{}
			ctx := context.Background()
			entities := []*model.RiskClauseTplReviewerDB{
				{Reviewer: "Alice"},
			}

			// Act
			err := r.CreateInBatches(ctx, nil, entities)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return i18n error when DB CreateInBatches returns non-ignored error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocks
			db := &gorm.DB{}
			dbErr := errors.New("db failure")
			retDB := &gorm.DB{Error: dbErr}
			mockey.MockUnsafe(initDB).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(db).Build()
			mockey.MockUnsafe((*gorm.DB).CreateInBatches).Return(retDB).Build()
			// Ensure i18n returns a predictable error message
			mockey.MockUnsafe(i18nfmt.New).Return(errors.New("createRiskClauseTplReviewerInBatchesFail")).Build()

			// Arrange inputs
			r := riskClauseTplReviewerDaoImpl{}
			ctx := context.Background()
			entities := []*model.RiskClauseTplReviewerDB{
				{Reviewer: "Bob"},
			}

			// Act
			err := r.CreateInBatches(ctx, nil, entities)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createRiskClauseTplReviewerInBatchesFail")
		})
	})
}

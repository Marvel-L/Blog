package dal

import (
	context2 "context"
	"errors"
	"testing"

	"code.byted.org/gopkg/context"
	gopkg_context "code.byted.org/gopkg/context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/dal/model"
)

func Test_preContractReviewRuleDaoImpl_ListByEmployeeEmail_BitsUTGen(t *testing.T) {
	// Setup common variables for all test cases
	ctx := gopkg_context.Background()
	mockDB := &gorm.DB{}
	employeeEmail := "test.employee@example.com"
	d := &preContractReviewRuleDaoImpl{}

	mockey.PatchConvey("Test_preContractReviewRuleDaoImpl_ListByEmployeeEmail", t, func() {
		// Mock the database initialization and chainable methods to return a mock DB instance.
		// This setup is common for all DB interactions in the function under test.
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()

		mockey.PatchConvey("success case: withReviewers is false", func() {
			// 场景描述: 成功查询到审阅人和审阅规则，且不需要填充审阅人详情
			// 构造数据:
			//   - 构造一个审阅人列表，包含一个审阅人信息
			//   - 构造一个审阅规则列表，包含对应的规则信息
			// 逻辑链路:
			// 1. 第一次调用gorm.Find，mock其成功返回一个审阅人列表
			// 2. 函数从返回的审阅人列表中提取rule_id
			// 3. 第二次调用gorm.Find，mock其成功返回对应的审阅规则列表
			// 4. withReviewers为false，不调用FillReviewers方法
			// 5. 函数成功返回审阅人列表、审阅规则列表和nil error

			expectedReviewers := []*model.ReviewRuleReviewerDB{
				{
					RuleID:        "rule-id-123",
					EmployeeEmail: employeeEmail,
				},
			}
			expectedRules := []*model.ReviewRuleDB{
				{
					RuleID: "rule-id-123",
				},
			}

			findCallCount := 0
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				findCallCount++
				if findCallCount == 1 {
					// Mock the first Find call for reviewers
					reviewers := dest.(*[]*model.ReviewRuleReviewerDB)
					*reviewers = expectedReviewers
					return &gorm.DB{Error: nil}
				}
				// Mock the second Find call for reviewRules
				rules := dest.(*[]*model.ReviewRuleDB)
				*rules = expectedRules
				return &gorm.DB{Error: nil}
			}).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, false)

			convey.So(err, convey.ShouldBeNil)
			convey.So(reviewers, convey.ShouldResemble, expectedReviewers)
			convey.So(reviewRules, convey.ShouldResemble, expectedRules)
		})

		mockey.PatchConvey("success case: withReviewers is true", func() {
			// 场景描述: 成功查询到审阅人和审阅规则，并成功填充审阅人详情
			// 构造数据:
			//   - 同上一个成功场景
			// 逻辑链路:
			// 1. 前两次gorm.Find调用均mock为成功
			// 2. withReviewers为true，调用FillReviewers方法
			// 3. mock FillReviewers方法成功返回nil
			// 4. 函数成功返回审阅人列表、审阅规则列表和nil error

			expectedReviewers := []*model.ReviewRuleReviewerDB{
				{
					RuleID:        "rule-id-123",
					EmployeeEmail: employeeEmail,
				},
			}
			expectedRules := []*model.ReviewRuleDB{
				{
					RuleID: "rule-id-123",
				},
			}

			findCallCount := 0
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				findCallCount++
				if findCallCount == 1 {
					reviewers := dest.(*[]*model.ReviewRuleReviewerDB)
					*reviewers = expectedReviewers
					return &gorm.DB{Error: nil}
				}
				rules := dest.(*[]*model.ReviewRuleDB)
				*rules = expectedRules
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock((*preContractReviewRuleDaoImpl).FillReviewers).Return(nil).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, true)

			convey.So(err, convey.ShouldBeNil)
			convey.So(reviewers, convey.ShouldResemble, expectedReviewers)
			convey.So(reviewRules, convey.ShouldResemble, expectedRules)
		})

		mockey.PatchConvey("error case: first find for reviewers fails", func() {
			// 场景描述: 第一次数据库查询（查找审阅人）失败
			// 构造数据:
			//   - 构造一个error对象
			// 逻辑链路:
			// 1. 第一次调用gorm.Find，mock其返回一个error
			// 2. 函数应立即返回nil, nil和该error

			dbErr := errors.New("database find 1 error")
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				return &gorm.DB{Error: dbErr}
			}).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, false)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
			convey.So(reviewers, convey.ShouldBeNil)
			convey.So(reviewRules, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error case: second find for review rules fails", func() {
			// 场景描述: 第二次数据库查询（查找审阅规则）失败
			// 构造数据:
			//   - 构造一个error对象
			// 逻辑链路:
			// 1. 第一次gorm.Find调用成功
			// 2. 第二次gorm.Find调用失败，mock其返回一个error
			// 3. 函数应返回nil, nil和该error

			dbErr := errors.New("database find 2 error")
			expectedReviewers := []*model.ReviewRuleReviewerDB{
				{
					RuleID:        "rule-id-123",
					EmployeeEmail: employeeEmail,
				},
			}

			findCallCount := 0
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				findCallCount++
				if findCallCount == 1 {
					reviewers := dest.(*[]*model.ReviewRuleReviewerDB)
					*reviewers = expectedReviewers
					return &gorm.DB{Error: nil}
				}
				return &gorm.DB{Error: dbErr}
			}).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, false)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, dbErr.Error())
			convey.So(reviewers, convey.ShouldBeNil)
			convey.So(reviewRules, convey.ShouldBeNil)
		})

		mockey.PatchConvey("error case: FillReviewers fails", func() {
			// 场景描述: 填充审阅人详情失败
			// 构造数据:
			//   - 构造一个error对象
			// 逻辑链路:
			// 1. 前两次gorm.Find调用均成功
			// 2. withReviewers为true，调用FillReviewers
			// 3. mock FillReviewers方法返回一个error
			// 4. 函数应返回nil, nil和该error

			fillErr := errors.New("fill reviewers error")
			expectedReviewers := []*model.ReviewRuleReviewerDB{
				{
					RuleID:        "rule-id-123",
					EmployeeEmail: employeeEmail,
				},
			}
			expectedRules := []*model.ReviewRuleDB{
				{
					RuleID: "rule-id-123",
				},
			}

			findCallCount := 0
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				findCallCount++
				if findCallCount == 1 {
					reviewers := dest.(*[]*model.ReviewRuleReviewerDB)
					*reviewers = expectedReviewers
					return &gorm.DB{Error: nil}
				}
				rules := dest.(*[]*model.ReviewRuleDB)
				*rules = expectedRules
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock((*preContractReviewRuleDaoImpl).FillReviewers).Return(fillErr).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, true)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fillErr.Error())
			convey.So(reviewers, convey.ShouldBeNil)
			convey.So(reviewRules, convey.ShouldBeNil)
		})

		mockey.PatchConvey("edge case: no reviewers found", func() {
			// 场景描述: 找不到任何与该员工邮箱关联的审阅人记录
			// 构造数据: 无
			// 逻辑链路:
			// 1. 第一次gorm.Find调用成功，但返回一个空列表
			// 2. 提取的rule_id列表为空
			// 3. 第二次gorm.Find调用也返回一个空列表
			// 4. 函数应返回两个空列表和nil error

			findCallCount := 0
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				findCallCount++
				if findCallCount == 1 {
					reviewers := dest.(*[]*model.ReviewRuleReviewerDB)
					*reviewers = []*model.ReviewRuleReviewerDB{} // Return empty slice
					return &gorm.DB{Error: nil}
				}
				rules := dest.(*[]*model.ReviewRuleDB)
				*rules = []*model.ReviewRuleDB{} // Return empty slice
				return &gorm.DB{Error: nil}
			}).Build()

			reviewers, reviewRules, err := d.ListByEmployeeEmail(ctx, nil, employeeEmail, false)

			convey.So(err, convey.ShouldBeNil)
			convey.So(reviewers, convey.ShouldBeEmpty)
			convey.So(reviewRules, convey.ShouldBeEmpty)
		})
	})
}

func Test_preContractReviewRuleDaoImpl_List_ByteUTGen(t *testing.T) {
	// 测试输入NeedTotal为true且Limit不为0，所有函数无错误返回的场景
	t.Run("ListWithNeedTotalAndLimit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*preContractReviewRuleDaoImpl).buildQuery).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] paramTest.NeedTotal == true && paramTest.Limit != 0
			var paramTest *modelreviewrule.ReviewRuleListParams = &modelreviewrule.ReviewRuleListParams{
				Offset:    10,
				NeedTotal: true,
				Limit:     1,
			}
			var receiver *preContractReviewRuleDaoImpl = &preContractReviewRuleDaoImpl{}
			var ctxTest context.Context = context2.Background()
			// 运行被测函数
			got1, got2, err := receiver.List(ctxTest, txTest, paramTest)

			// 虽然Find函数被mock，但没有对结果列表进行赋值操作，因此结果列表为空，长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 代码中total未被赋值，默认初始值为0，因此返回的总数为0
			convey.So(got2, convey.ShouldEqual, 0)
			// 所有mock函数返回值均无错误，且ignoreErr函数返回nil，不会触发错误处理逻辑，因此err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

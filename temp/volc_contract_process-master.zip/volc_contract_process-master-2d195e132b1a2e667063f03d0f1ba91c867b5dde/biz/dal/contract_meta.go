package dal

import (
	"context"
	"errors"
	"strconv"
	"strings"
	"time"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"
)

const (
	tBContractMeta = "volc_contract_meta"
)

type ContractMetaDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	UpdateIdentifierByMap(ctx context.Context, tx *gorm.DB, bizScene int, contractID int64, updates map[string]interface{}) error
	UpdateCoStatusById(ctx context.Context, tx *gorm.DB, bizScene int, contractID int64, coStatus int) error
	UpdateActiveStatusById(ctx context.Context, tx *gorm.DB, bizScene int, contractId int64, activeStatus int) error
	UpdateAttachmentFields(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error
	UpdateAfterSubmit(ctx context.Context, tx *gorm.DB, contractNo, ofacURL string, status int) error
	List(ctx context.Context, tx *gorm.DB, param *model.ContractMetaReq) (model.ContractMetaDBList, int, error)
	ListSupplyContract(ctx context.Context, tx *gorm.DB, fromContractNo string) (model.ContractMetaDBList, error)
	ListQuoteRelateContracts(ctx context.Context, tx *gorm.DB, quoteID string) (model.ContractMetaDBList, error)
	ListNoReverseFinalNoExpiredContract(ctx context.Context, tx *gorm.DB, accountID string, limit, offset int) (model.ContractMetaDBList, error)
	ListAbnormalArchivedContract(ctx context.Context, tx *gorm.DB, limit, offset int) (model.ContractMetaDBList, error)
	ListByContractIds(ctx context.Context, tx *gorm.DB, volcContractIds []uint64) (model.ContractMetaDBList, error)
	FindByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) (*model.ContractMetaDB, error)
	FindLastByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error)
	FindLastByOaNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error)
	ListByMainNo(ctx context.Context, tx *gorm.DB, mainContractNo string) (model.ContractMetaDBList, error)
	FindByID(ctx context.Context, tx *gorm.DB, id int64) (*model.ContractMetaDB, error)
	FindByOaNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) (*model.ContractMetaDB, error)
	findByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error)
	findLastByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error)
	FindByBizIdentifierAdaptor(ctx context.Context, tx *gorm.DB, contractNo string, version int, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error)
	FindLastByBizIdentifierAdaptor(ctx context.Context, tx *gorm.DB, contractNo string, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error)
	FindInProcessContractByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error)
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.ContractMetaDBList, error)
	ListByIdRangeAndScene(ctx context.Context, tx *gorm.DB, bizScene int, startID int64, offset int) (model.ContractMetaDBList, error)
	Delete(ctx context.Context, tx *gorm.DB, id int64) error
	DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error
	// 在线协同
	UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, contractNo string, updates map[string]interface{}) error
	UpdateFieldsByContractIds(ctx context.Context, tx *gorm.DB, contractIds []uint64, updates map[string]interface{}) error
	UpdateCooperationStatus(ctx context.Context, tx *gorm.DB, contractNo string, preStatus, status int) error
	ResetContractNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string, contractID string, checkCode string, requestID string, status int) error
	FindFromContractByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error)
	FindHistoryContractByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error)
	ListByReq(ctx context.Context, tx *gorm.DB, req *model.ContractMetaReq) (model.ContractMetaDBList, int, error)
	FindByNoForSales(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error)
	ListByContractNos(ctx context.Context, tx *gorm.DB, contractNos []string) (model.ContractMetaDBList, error)
}

var _contractMetaDaoInstance = &contractMetaDaoImpl{}

func NewContractMetaDao() ContractMetaDao {
	return _contractMetaDaoInstance
}

type contractMetaDaoImpl struct {
}

// ListByReq 根据条件查询
func (p *contractMetaDaoImpl) ListByReq(ctx context.Context, tx *gorm.DB, req *model.ContractMetaReq) (model.ContractMetaDBList, int, error) {

	var total int64
	var err error

	db := p.buildQuery(ctx, tx, req)

	if req.NeedTotal {
		if err := db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListVolcContractMetaCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListVolcContractMetaCountFail")
		}
	}

	// 分页逻辑兼容
	if req.Limit > 0 {
		db = db.Limit(req.Limit)
		db = db.Offset(req.Offset)
	}

	var list model.ContractMetaDBList
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListVolcContractMetaFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListVolcContractMetaFail")
	}

	return list, int(total), nil
}

// FindHistoryContractByNo 查询历史合同
func (p *contractMetaDaoImpl) FindHistoryContractByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	// 查询历史合同，放开合同来源限制
	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no = ? ", contractNo).Where("is_deleted = 0 ")
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindHistoryContractByNoFail")
	}
	return &ret, nil
}

// FindByNo 根据编号查询
func (p *contractMetaDaoImpl) FindFromContractByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	// 支持针对产品报价合同发起补充协议，放开合同来源限制
	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no = ? ", contractNo).Where("is_deleted = 0 ")
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindFromContractByNoFail")
	}
	return &ret, nil
}

func (p *contractMetaDaoImpl) ResetContractNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string, contractID string, checkCode string, requestID string, status int) error {
	err := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("contract_no = ?", oldNo).
		Updates(map[string]interface{}{
			"contract_no":        newNo,
			"contract_id":        contractID,
			"check_code":         checkCode,
			"request_id":         requestID,
			"cooperation_status": status,
		}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ResetContractNoFail, err: %v", err)
		return i18nfmt.New(ctx, "ResetContractNoFail")
	}
	return nil
}

func (p *contractMetaDaoImpl) UpdateCooperationStatus(ctx context.Context, tx *gorm.DB, contractNo string, preStatus, status int) error {
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta)
	err := db.Where("contract_no = ?", contractNo).Updates(map[string]interface{}{
		"pre_cooperation_status":         preStatus,
		"cooperation_status":             status,
		"cooperation_status_change_time": time.Now(),
	}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractMetaCooperationStatusFail, err:%v", err)
		return i18nfmt.New(ctx, "updateContractMetaCooperationStatusFail")
	}
	return nil
}

func (p *contractMetaDaoImpl) UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, contractNo string, updates map[string]interface{}) error {
	err := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("contract_no = ?", contractNo).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateFieldsByNoFail, err: %v", err)
		return i18nfmt.New(ctx, "UpdateFieldsByNoFail")
	}
	return nil
}

// UpdateFieldsByContractIds 根据合同ID列表更新字段
func (p *contractMetaDaoImpl) UpdateFieldsByContractIds(ctx context.Context, tx *gorm.DB, contractIds []uint64, updates map[string]interface{}) error {
	if len(contractIds) == 0 || len(updates) == 0 {
		logs.CtxError(ctx, "UpdateFieldsByContractIdsFail, len(contractIds): %d, len(updates): %d", len(contractIds), len(updates))
		return i18nfmt.New(ctx, "UpdateFieldsByContractIdsFail")
	}
	err := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).
		Where("id in (?)", contractIds).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateFieldsByContractIdsFail, contractIds: %v, err: %v", contractIds, err)
		return i18nfmt.New(ctx, "UpdateFieldsByContractIdsFail")
	}
	return nil
}

func (c *contractMetaDaoImpl) DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error {
	updates := map[string]interface{}{
		"is_deleted": 1,
	}
	var versions []int
	if version <= 1 {
		versions = []int{0, 1} // 兼容0、1
	} else {
		versions = []int{version}
	}
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta)
	err := db.Where("contract_no = ? and version in (?)", contractNo, versions).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteByNoFail, err:%v", err)
		return i18nfmt.New(ctx, "DeleteByNoFail")
	}
	return nil
}

// Delete 软删
func (c *contractMetaDaoImpl) Delete(ctx context.Context, tx *gorm.DB, id int64) error {
	updates := map[string]interface{}{
		"is_deleted": 1,
	}
	return ignoreErr(c.UpdateByMap(ctx, tx, id, updates))
}

func (c *contractMetaDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error {
	// 敏感字段在create是会被gorm-dkms置空，创建业务合同的长事务中使用该明文字段，因此这里需要先保存明文，create后再赋值。
	if entity == nil {
		return i18nfmt.New(ctx, "updateContractMetaFail, entity is nil")
	}
	tradePartyInfoPlaintext := entity.TradePartyInfo
	BizDataPlaintext := entity.BizData

	db := initDB(ctx, tx)
	err := db.Model(&model.ContractMetaDB{}).Table(tBContractMeta).Select("*").Omit("manage_info", "settlement_info", "created_time", "perform_flag").
		Where("id = ?", entity.Id).Updates(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractMetaFail, contractNo:%d, err:%s", entity.ContractNo, err.Error())
		return i18nfmt.New(ctx, "updateContractMetaFail")
	}
	entity.TradePartyInfo = tradePartyInfoPlaintext
	entity.BizData = BizDataPlaintext
	return nil
}

func (c *contractMetaDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

// 报价合同场景，添加更新限制
func (c *contractMetaDaoImpl) addBizUpdateCondition(ctx context.Context, bizScene int, db *gorm.DB) *gorm.DB {
	logs.CtxInfo(ctx, "addBizUpdateCondition, bizScene=%d", bizScene)
	db = db.Where("cooperation_status not in (?)",
		[]int{
			_const.ContractStatusInvalid, // 已失效
			_const.ContractStatusAbandon, // 已作废
			_const.ContractStatusRevoke,  // 已撤销
		})
	db = db.Where("active_status != ?", _const.ActiveStatusTerminated) // 已终止

	return db
}

func (c *contractMetaDaoImpl) UpdateIdentifierByMap(ctx context.Context, tx *gorm.DB, bizScene int, contractID int64, updates map[string]interface{}) error {
	if contractID == 0 {
		return nil
	}
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("id = ?", contractID)
	db = c.addBizUpdateCondition(ctx, bizScene, db)
	err := db.Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateBizByMapFail, biz_scene=%d, contractId=%s, err:%v", bizScene, contractID, err)
		return i18nfmt.New(ctx, "UpdateBizByMapFail")
	}
	return nil
}

// func (c *contractMetaDaoImpl) UpdateCoStatusByIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string, coStatus int) error {
//	updates := map[string]interface{}{
//		"cooperation_status": coStatus,
//	}
//	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("biz_scene = ? and biz_identifier = ? and version in (0,1) and is_deleted = 0", bizScene, bizIdentifier)
//	// 已终止、已作废为合同终态，允许报价单重提，合同可能出现多条。更新时跳过状态为已作废、已失效、已提交飞书合同的合同。
//	db = c.addBizUpdateCondition(ctx, bizScene, db)
//	err := db.Updates(updates).Error
//	if ignoreErr(err) != nil {
//		logs.CtxError(ctx, "UpdateCoStatusByIdentifierFail, biz_scene=%d, biz_identifier=%s, coStatus=%d, err:%v", bizScene, bizIdentifier, coStatus, err)
//		return i18nfmt.New(ctx, "UpdateCoStatusByIdentifierFail")
//	}
//	return nil
// }

func (c *contractMetaDaoImpl) UpdateCoStatusById(ctx context.Context, tx *gorm.DB, bizScene int, contractID int64, coStatus int) error {
	updates := map[string]interface{}{
		"cooperation_status": coStatus,
	}
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("id = ?", contractID).Where("is_deleted = 0")
	// 已终止、已作废为合同终态，允许报价单重提，合同可能出现多条。更新时跳过状态为已作废、已失效、已提交飞书合同的合同。
	db = c.addBizUpdateCondition(ctx, bizScene, db)
	err := db.Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateCoStatusByIdFail, biz_scene=%d, contractId=%d, coStatus=%d, err:%v", bizScene, contractID, coStatus, err)
		return i18nfmt.New(ctx, "UpdateCoStatusByIdFail")
	}
	return nil
}

// func (c *contractMetaDaoImpl) UpdateActiveStatusByIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string, activeStatus int) error {
//	updates := map[string]interface{}{
//		"active_status": activeStatus,
//	}
//	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("biz_scene = ? and biz_identifier = ? and is_deleted = 0", bizScene, bizIdentifier)
//	db = c.addBizUpdateCondition(ctx, bizScene, db)
//	err := db.Updates(updates).Error
//	if ignoreErr(err) != nil {
//		logs.CtxError(ctx, "UpdateActiveStatusByIdentifierFail, biz_scene=%d, biz_identifier=%s, activeStatus=%d, err:%v", bizScene, bizIdentifier, activeStatus, err)
//		return i18nfmt.New(ctx, "UpdateActiveStatusByIdentifierFail")
//	}
//	return nil
// }

func (c *contractMetaDaoImpl) UpdateActiveStatusById(ctx context.Context, tx *gorm.DB, bizScene int, contractId int64, activeStatus int) error {
	updates := map[string]interface{}{
		"active_status": activeStatus,
	}
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("id = ?", contractId).Where("is_deleted = 0")
	db = c.addBizUpdateCondition(ctx, bizScene, db)
	err := db.Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateActiveStatusById, biz_scene=%d, contractId=%d, activeStatus=%v, err:%v", bizScene, contractId, activeStatus, err)
		return i18nfmt.New(ctx, "UpdateActiveStatusByIdFail")
	}
	return nil
}

func (c *contractMetaDaoImpl) UpdateAttachmentFields(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error {
	updates := map[string]interface{}{
		"contract_attachment": entity.ContractAttachment,
		"contract_file":       entity.ContractFile,
	}
	db := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta)
	err := db.Where("id = ?", entity.Id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateAttachmentFieldsFail, err:%v", err)
		return i18nfmt.New(ctx, "UpdateAttachmentFieldsFail")
	}
	return nil
}

func (c *contractMetaDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaDB) error {
	// 敏感字段在create是会被gorm-dkms置空，创建业务合同的长事务中使用该明文字段，因此这里需要先保存明文，create后再赋值。
	if entity == nil {
		return i18nfmt.New(ctx, "createContractMetaFail, entity is nil")
	}
	tradePartyInfoPlaintext := entity.TradePartyInfo
	BizDataPlaintext := entity.BizData
	err := initDB(ctx, tx).Table(tBContractMeta).Select("*").Omit("manage_info", "settlement_info").Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractMetaFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractMetaFail")
	}
	entity.TradePartyInfo = tradePartyInfoPlaintext
	entity.BizData = BizDataPlaintext
	return nil
}

func (c *contractMetaDaoImpl) FindByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) (*model.ContractMetaDB, error) {
	var versions []int
	if version <= 1 {
		versions = []int{0, 1} // 兼容0、1
	} else {
		versions = []int{version}
	}
	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no = ? and version in (?)", contractNo, versions).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contract_no=%s, version=%d err=%s", contractNo, version, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

func (c *contractMetaDaoImpl) ListByMainNo(ctx context.Context, tx *gorm.DB, mainContractNo string) (model.ContractMetaDBList, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).
		Where("main_contract_no = ?", mainContractNo).Order("id desc")

	var list model.ContractMetaDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByMainNoFail, main_contract_no:%s, err:%s", mainContractNo, err.Error())
		return nil, i18nfmt.New(ctx, "ListByMainNoFail")
	}

	return list, nil
}

func (c *contractMetaDaoImpl) FindLastByNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no = ?", contractNo).Where("is_deleted = 0").
		Order("version desc").Limit(1)
	var ret model.ContractMetaDB
	err := db.Find(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contract_no=%s err=%s", contractNo, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

// UpdateAfterSubmit 更新RequestId和提交时间
func (c *contractMetaDaoImpl) UpdateAfterSubmit(ctx context.Context, tx *gorm.DB, contractNo, ofacURL string, status int) error {
	err := initDB(ctx, tx).Model(&model.ContractMetaDB{}).Table(tBContractMeta).Where("contract_no = ?", contractNo).
		Updates(map[string]interface{}{"ofac_url": ofacURL, "status": status}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateAfterSubmitFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "UpdateAfterSubmitFail")
	}
	return nil
}

func (c *contractMetaDaoImpl) FindLastByOaNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("(oa_contract_no = ? or contract_no = ?)", contractNo, contractNo).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.Last(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contract_no=%s err=%s", contractNo, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

func (c *contractMetaDaoImpl) FindByOaNo(ctx context.Context, tx *gorm.DB, oaContractNo string, version int) (*model.ContractMetaDB, error) {
	var versions []int
	if version <= 1 {
		versions = []int{0, 1} // 兼容0、1
	} else {
		versions = []int{version}
	}
	db := initDB(ctx, tx).Table(tBContractMeta).Where("oa_contract_no = ? and version in (?)", oaContractNo, versions).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, oa_contract_no=%s, version=%d err=%s", oaContractNo, version, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

func (c *contractMetaDaoImpl) FindByID(ctx context.Context, tx *gorm.DB, id int64) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("id = ?", id).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIDFail, id=%d, err=%s", id, err.Error())
		return nil, i18nfmt.New(ctx, "FindByIDFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

// FindByBizIdentifier 根据业务场景标识查找 注意不要随意修改
func (c *contractMetaDaoImpl) findByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("biz_scene = ? and biz_identifier = ? and version in (0,1)", bizScene, bizIdentifier).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.Last(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, biz_scene=%d, biz_identifier=%s, err=%s", bizScene, bizIdentifier, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

// FindByBizIdentifier 根据业务场景标识查找 注意不要随意修改
func (c *contractMetaDaoImpl) findLastByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("biz_scene = ? and biz_identifier = ?", bizScene, bizIdentifier).Where("is_deleted = 0")
	var ret model.ContractMetaDB
	err := db.Last(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, biz_scene=%d, biz_identifier=%s, err=%s", bizScene, bizIdentifier, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

// FindByBizIdentifierAdaptor 兼容接口 优先根据合同号查询，合同号为空时再根据biz_scene+biz_identifier查询
func (c *contractMetaDaoImpl) FindByBizIdentifierAdaptor(ctx context.Context, tx *gorm.DB, contractNo string, version int, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error) {
	// 后续改造根据该日志定位尚未改造的入口流量，目标逐步
	logs.CtxInfo(ctx, "FindByBizIdentifierAdaptorIn, contractNo=%s, version=%d, bizScene=%d, bizIdent=%s", contractNo, version, bizScene, bizIdentifier)
	if contractNo != "" {
		ret, err := c.FindByNo(ctx, tx, contractNo, version)
		if err != nil {
			return nil, err
		}
		if ret != nil {
			return ret, nil
		}
	}
	// 根据合同号无法查询时 兜底查询
	return c.findByBizIdentifier(ctx, tx, bizScene, bizIdentifier)
}

// FindByBizIdentifierAdaptor 兼容接口 优先根据合同号查询，合同号为空时再根据biz_scene+biz_identifier查询
func (c *contractMetaDaoImpl) FindLastByBizIdentifierAdaptor(ctx context.Context, tx *gorm.DB, contractNo string, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error) {
	// 后续改造根据该日志定位尚未改造的入口流量，目标逐步
	logs.CtxInfo(ctx, "FindByBizIdentifierAdaptorIn, contractNo=%s, bizScene=%d, bizIdent=%s", contractNo, bizScene, bizIdentifier)
	if contractNo != "" {
		ret, err := c.FindLastByNo(ctx, tx, contractNo)
		if err != nil {
			return nil, err
		}
		if ret != nil {
			return ret, nil
		}
	}
	// 根据合同号无法查询时 兜底查询
	return c.findLastByBizIdentifier(ctx, tx, bizScene, bizIdentifier)
}

func (c *contractMetaDaoImpl) FindInProcessContractByBizIdentifier(ctx context.Context, tx *gorm.DB, bizScene int, bizIdentifier string) (*model.ContractMetaDB, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("biz_scene = ? and biz_identifier = ? and version in (0,1)", bizScene, bizIdentifier).Where("is_deleted = 0")
	db = c.addBizUpdateCondition(ctx, bizScene, db)
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, biz_scene=%d, biz_identifier=%s, err=%s", bizScene, bizIdentifier, err.Error())
		return nil, i18nfmt.New(ctx, "FindMetaByNoFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

func (c *contractMetaDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.ContractMetaDBList, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("id >= ?", startID)
	var list model.ContractMetaDBList
	err := db.Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractMetaDaoImpl) ListByIdRangeAndScene(ctx context.Context, tx *gorm.DB, bizScene int, startID int64, offset int) (model.ContractMetaDBList, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Where("id >= ? and biz_scene=?", startID, bizScene)
	var list model.ContractMetaDBList
	err := db.Order("id asc").Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractMetaDaoImpl) ListSupplyContract(ctx context.Context, tx *gorm.DB, fromContractNo string) (model.ContractMetaDBList, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).Where("from_contract_no = ? and is_deleted=0", fromContractNo).
		Where("cooperation_status not in (?)",
			[]int{
				_const.ContractStatusAbandon,
				_const.ContractStatusRevoke,
				_const.ContractStatusInvalid,
				_const.ContractStatusCustomerRefuse,
			}).
		Where("status not in (?)",
			[]int{_const.SalesContractCanceled})

	var list model.ContractMetaDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListSupplyContractFail, fromContractNo:%s, err:%s", fromContractNo, err.Error())
		return nil, i18nfmt.New(ctx, "ListSupplyContractFail")
	}

	return list, nil
}

func (c *contractMetaDaoImpl) ListAbnormalArchivedContract(ctx context.Context, tx *gorm.DB, limit, offset int) (model.ContractMetaDBList, error) {
	var err error

	db := initDB(ctx, tx).Table(tBContractMeta)

	db = db.Where("is_deleted = 0 and archived_status = 1 and file_time = ?", "0000-00-00 00:00:00")

	db = db.Order("created_time desc")

	var list model.ContractMetaDBList
	query := db.Offset(offset)
	// 只有当limit不为0时，才添加Limit条件
	if limit != 0 {
		query = query.Limit(limit)
	}
	err = query.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListAbnormalArchivedContractFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListAbnormalArchivedContractFail")
	}
	return list, nil
}

// ListQuoteRelateContracts 不包含：“协商状态”为“已作废”/“客户已拒绝”/"草稿"/"已退回"
func (c *contractMetaDaoImpl) ListQuoteRelateContracts(ctx context.Context, tx *gorm.DB, quoteID string) (model.ContractMetaDBList, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).
		Where("relate_quote_no = ?", quoteID).
		Where("cooperation_status not in (?)",
			[]int{
				_const.ContractStatusNotCreated,
				_const.ContractStatusDraft,
				_const.ContractStatusSendBack,
				_const.ContractStatusCustomerRefuse,
				_const.ContractStatusInvalid,
				_const.ContractStatusAbandon,
				_const.ContractStatusRevoke,
			}).
		Where("active_status != ?", _const.ActiveStatusTerminated).
		Where("status != ?", _const.SalesContractCanceled)

	var list model.ContractMetaDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListQuoteRelateContractsFail, relate_quote_no:%s, err:%s", quoteID, err.Error())
		return nil, i18nfmt.New(ctx, "ListQuoteRelateContractsFail")
	}

	return list, nil
}

func (c *contractMetaDaoImpl) ListNoReverseFinalNoExpiredContract(ctx context.Context, tx *gorm.DB, accountID string, limit, offset int) (model.ContractMetaDBList, error) {
	accountIds := i18nfmt.Sprintf(ctx, "%%%s%%", accountID)
	db := initDB(ctx, tx).Table(tBContractMeta).
		Where("In_out_type in (?)", []string{_const.IN, _const.InAndOut}).
		Where("cooperation_status not in (?)", _const.ReverseFinalCooperationStatus).
		Where("active_status in (?)", []int{
			_const.ActiveStatusWaitEffective,
			_const.ActiveStatusInForce,
		}).
		Where("status != ?", _const.SalesContractCanceled).
		Where("(biz_account_id = ? or subject_account_ids like ?)", accountID, accountIds)

	var list model.ContractMetaDBList
	query := db.Offset(offset)
	// 只有当limit不为0时，才添加Limit条件
	if limit != 0 {
		query = query.Limit(limit)
	}
	if err := query.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListNoReverseFinalNoExpiredContractFail, accountId:%s, err:%s", accountID, err.Error())
		return nil, i18nfmt.New(ctx, "ListNoReverseFinalNoExpiredContractFail")
	}

	return list, nil
}

// ListQuoteRelateContracts 不包含：“协商状态”为“已作废”/“客户已拒绝”/"草稿"/"已退回"
func (c *contractMetaDaoImpl) ListByContractIds(ctx context.Context, tx *gorm.DB, volcContractIds []uint64) (model.ContractMetaDBList, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).Where("id in (?)", volcContractIds)

	var list model.ContractMetaDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByContractIdsFail, volcContractIds:%v, err:%s", volcContractIds, err.Error())
		return nil, i18nfmt.New(ctx, "ListByContractIdsFail")
	}

	return list, nil
}

func (c *contractMetaDaoImpl) collectContractNoResult(ctx context.Context, query *gorm.DB) ([]string, error) {
	var list []*model.ContractNoVO
	if err := query.Find(&list).Error; ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "QueryContractNoFail")
	}
	var ret []string
	for _, v := range list {
		ret = append(ret, v.ContractNo)
	}
	return ret, nil
}

func (c *contractMetaDaoImpl) collectPreContractNoResult(ctx context.Context, query *gorm.DB) ([]string, error) {
	var list []*model.PreContractNoVO
	if err := query.Find(&list).Error; ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "QueryContractNoFail")
	}
	var ret []string
	for _, v := range list {
		ret = append(ret, v.PreContractNo)
	}
	return ret, nil
}

// https://bytedance.larkoffice.com/wiki/LQaVwdbLCi7GIik8qPQc94KwnVc
// 匹配：后台发起、合同状态=(草稿或已拒绝)、当前访问人为创建人
func (c *contractMetaDaoImpl) findBizSourceFeeWaitMeDealList(ctx context.Context, tx *gorm.DB,
	param *model.ContractMetaReq) ([]string, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Select("distinct contract_no").
		Where("is_deleted = 0 and biz_scene = 1 and biz_source = ? and status in (?) and cooperation_status in (?) and (creator=? or creator_new=?)",
			_const.BizSourceFee,
			[]int{_const.SalesContractUnSubmit, _const.SalesContractRejected},    // 0，7 草稿+已拒绝
			[]int{_const.PreSalesContractDraft, _const.PreSalesContractSubmitOA}, // 1，8 草稿+已提交飞书
			param.CurrentOperatorUID,
			param.CurrentOperatorUID,
		)
	return c.collectContractNoResult(ctx, db)
}

// https://bytedance.larkoffice.com/wiki/LQaVwdbLCi7GIik8qPQc94KwnVc
// 匹配：在线协同、（协商状态 ≠ 已提交飞书合同 / 已作废）、当前节点审批人
func (c *contractMetaDaoImpl) findBizSourceCooperationWaitMeDealList(ctx context.Context, tx *gorm.DB,
	param *model.ContractMetaReq) ([]string, error) {
	db := initDB(ctx, tx).Table(tBContractMeta).Select("distinct volc_contract_meta.contract_no as contract_no").
		Joins("left join pre_contract_reviewer reviewer on volc_contract_meta.contract_no = reviewer.pre_contract_no").
		Where("volc_contract_meta.biz_source = ? and volc_contract_meta.cooperation_status not in (?) and reviewer.contract_status = volc_contract_meta.cooperation_status and reviewer.reviewer=? and reviewer.status in (?)",
			_const.BizSourceCooperation,
			[]int{_const.ContractStatusSubmitOA, _const.ContractStatusAbandon, _const.ContractStatusRevoke}, // 8,20
			param.CurrentOperator,
			[]int{_const.ReviewStatusUnreviewed, _const.ReviewStatusReviewWithdraw}, // 未审核、审核撤回
		)
	return c.collectContractNoResult(ctx, db)
}

// 匹配：在线协同、当前登录人点击过 审核通过
func (c *contractMetaDaoImpl) findBizSourceCooperationDealtList(ctx context.Context, tx *gorm.DB,
	param *model.ContractMetaReq) ([]string, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).Select("distinct pre_contract_no").
		Where("reviewer = ? and status in (1,3,5,6,13)", param.CurrentOperator)
	return c.collectPreContractNoResult(ctx, db)
}

// return:
// 0: 限定的合同号范围
// 1: 是否需要限定, true=需要限定  false=不需要限定
// 2: 错误信息
func (c *contractMetaDaoImpl) findTabSceneAccessibleContractList(ctx context.Context, tx *gorm.DB,
	param *model.ContractMetaReq) ([]string, bool, error) {
	if param.TabScene == _const.ListTabSceneWaitMeDeal { // 待我处理
		// 后台发起-待我处理
		list1, err := c.findBizSourceFeeWaitMeDealList(ctx, tx, param)
		if err != nil {
			return nil, false, err
		}
		// 在线协同-待我处理
		list2, err := c.findBizSourceCooperationWaitMeDealList(ctx, tx, param)
		if err != nil {
			return nil, false, err
		}
		allList := util.SingleList(append(list1, list2...))
		return allList, true, nil
	} else if param.TabScene == _const.ListTabSceneIHadDealt { // 我已处理
		list, err := c.findBizSourceCooperationDealtList(ctx, tx, param)
		if err != nil {
			return nil, false, err
		}
		return list, true, nil
	} else if param.TabScene == 0 {
		return nil, false, nil
	}
	return nil, false, errors.New("unexpected tab scene")
}

func (c *contractMetaDaoImpl) List(ctx context.Context, tx *gorm.DB, param *model.ContractMetaReq) (model.ContractMetaDBList, int, error) {

	var total int64
	var err error

	// 待我处理、我已处理
	limitContractNoList, needLimit, err := c.findTabSceneAccessibleContractList(ctx, tx, param)
	if err != nil {
		return nil, 0, err
	}
	param.NeedLimit = needLimit
	param.LimitContractNoList = limitContractNoList
	if needLimit && len(limitContractNoList) == 0 {
		// 此种情况不需要再查询
		return nil, 0, nil
	}

	// current_operator 数据权限限制
	// 单独筛选在线协同 全量查询时跳过
	// 管理员默认可查询全量合同
	if !param.IsManager && !needLimit {
		preContractNos, err := c.FindAccessibleCooperationNoList(ctx, tx, param)
		if err != nil {
			logs.CtxError(ctx, "FindAccessibleCooperationNoListFail, err:%v", err)
			return nil, int(total), err
		}
		param.PreContractNoList = preContractNos
	}

	db := c.buildQuery(ctx, tx, param)

	if param.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListContractMetaCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListContractMetaCountFail")
		}
	}

	// 分页逻辑兼容
	if param.Limit != 0 {
		db = db.Limit(param.Limit)
	}
	if param.StartId == 0 {
		// 默认基于创建时间排序、指定offset查询
		db = db.Offset(param.Offset)
	}

	var list model.ContractMetaDBList
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractMetaFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListContractMetaFail")
	}

	return list, int(total), nil
}

func (c *contractMetaDaoImpl) FindAccessibleCooperationNoList(ctx context.Context, tx *gorm.DB, param *model.ContractMetaReq) ([]string, error) {
	// 指定合同来源 切合同来源非在线协同时 不需要查询当前用户能查询的在线协同合同
	if (param.BizSource != 0 || len(param.BizSourceList) != 0) && param.BizSource != _const.BizSourceCooperation &&
		!strings.Contains(param.BizSourceList, strconv.Itoa(_const.BizSourceCooperation)) {
		return nil, nil
	}
	// 未传入当前操作人 默认返回全量合同
	if len(param.CurrentOperator) == 0 {
		return nil, nil
	}
	// 查询合同信息
	db := initDB(ctx, tx).Table(tPreContractReviewer)
	db.Select("distinct pre_contract_no").Where("reviewer = ? ", param.CurrentOperator)
	if len(param.RuleIdAndRoles) > 0 {
		db = db.Or("(department, reviewer_role) IN ?", param.RuleIdAndRoles)
	}
	if len(param.DepartmentAndRoles) > 0 {
		db = db.Or("(department, reviewer_role) IN ?", param.DepartmentAndRoles)
	}
	var list []*model.PreContractNoVO
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "QueryPreContractNoFail, reviewer:%s, err:%s", param.CurrentOperator, err.Error())
		return nil, i18nfmt.New(ctx, "QueryPreContractNoFail")
	}
	ret := make([]string, len(list))
	for idx, v := range list {
		ret[idx] = v.PreContractNo
	}
	// 查询 创建人||业务执行人 是当前操作人的合同列表
	coopContractNos, err := c.GetAccessibleCoopNo(ctx, tx, param)
	if err != nil {
		logs.CtxError(ctx, "GetAccessibleCoopNoFail, err:%v")
		return nil, err
	}
	ret = append(ret, coopContractNos...)

	return ret, nil
}

func (c *contractMetaDaoImpl) GetAccessibleCoopNo(ctx context.Context, tx *gorm.DB, param *model.ContractMetaReq) ([]string, error) {
	// 查询业务执行人是当前操作人的在线协同合同
	var ret []string
	employees, _ := larkc.GetEmployeeByMail(ctx, param.CurrentOperator)
	if len(employees) != 0 {
		db := initDB(ctx, tx).Table(tBContractMeta)
		db = db.Select("distinct contract_no as pre_contract_no").
			Where("biz_source = 2").
			Where("operator = ? or operator_new = ? or creator = ? or creator_new = ?",
				employees[0].ID, employees[0].ID, employees[0].ID, employees[0].ID).
			Where("is_deleted = 0")
		// 查询业务执行人为当前操作人的合同 同步加上筛选条件
		if len(param.ContractNo) > 0 {
			// db = db.Where("contract_no like ? or pre_contract_no like ?", buildRightLikeQuery(param.ContractNo), buildRightLikeQuery(param.ContractNo))
			if strings.HasPrefix(param.ContractNo, "PCT") {
				db = db.Where("pre_contract_no like ?", buildRightLikeQuery(param.ContractNo))
			} else if strings.HasPrefix(param.ContractNo, "CT") {
				db = db.Where("contract_no like ?", buildRightLikeQuery(param.ContractNo))
			}
		}
		if len(param.ContractNoList) > 0 {
			db = db.Where("contract_no in (?)", strings.Split(param.ContractNoList, ","))
		}
		if len(param.ContractName) > 0 {
			db = db.Where("contract_name like ?", buildLikeQuery(param.ContractName))
		}
		if len(param.SubjectName) > 0 {
			db = db.Where("subject_name like ?", buildLikeQuery(param.SubjectName))
		}
		if len(param.OtherPartyName) > 0 {
			db = db.Where("other_party_name like ?", buildLikeQuery(param.OtherPartyName))
		}
		if len(param.PropertyCode) > 0 {
			db = db.Where("property_code = ?", param.PropertyCode)
		}
		if len(param.CategoryNo) > 0 {
			categoryNoList := util.SingleList(strings.Split(param.CategoryNo, ","))
			if len(categoryNoList) > 1 {
				db = db.Where("category_no in (?)", categoryNoList)
			} else if len(categoryNoList) == 1 {
				db = db.Where("category_no = ?", categoryNoList[0])
			}
		}
		if len(param.InOutType) > 0 {
			inOutTypeList := util.SingleList(strings.Split(param.InOutType, ","))
			if len(inOutTypeList) > 1 {
				db = db.Where("in_out_type in (?)", inOutTypeList)
			} else if len(inOutTypeList) == 1 {
				db = db.Where("in_out_type = ?", inOutTypeList[0])
			}
		}
		if param.Initiator > 0 {
			db = db.Where("initiator = ?", param.Initiator)
		}
		if param.Status != nil {
			db = db.Where("status = ?", *param.Status)
		}
		if len(param.StatusList) > 0 {
			db = db.Where("status in (?)", strings.Split(param.StatusList, ","))
		}
		if param.ActiveStatus != nil {
			db = db.Where("active_status = ?", *param.ActiveStatus)
		}
		if len(param.ActiveStatusList) > 0 {
			db = db.Where("active_status in (?)", param.ActiveStatusList)
		}
		if param.ArchivedStatus != nil {
			db = db.Where("archived_status = ?", *param.ArchivedStatus)
		}
		if param.CooperationStatus != nil {
			db = db.Where("cooperation_status = ?", *param.CooperationStatus)
		}
		if len(param.CooperationStatusList) > 0 {
			db = db.Where("cooperation_status in (?)", param.CooperationStatusList)
		}
		// 关联报价单号
		if len(param.RelateQuoteID) > 0 {
			db = db.Where("volc_contract_meta.relate_quote_no = ?", param.RelateQuoteID)
		}
		// 合同需要报价单
		if param.RelateQuote {
			db = db.Where("volc_contract_meta.relate_quote_no != ?", "")
		}
		if param.Creator > 0 {
			db = db.Where("creator = ? or creator_new = ? ", param.Creator, param.Creator)
		}
		if !param.CreatedTimeBegin.IsZero() {
			db = db.Where("created_time >= ?", param.CreatedTimeBegin.Format(_const.CommonDateFormatTpl))
		}
		if !param.CreatedTimeEnd.IsZero() {
			db = db.Where("created_time <= ?", param.CreatedTimeEnd.Format(_const.CommonDateFormatTpl))
		}
		if !param.SubmitTimeBegin.IsZero() {
			db = db.Where("submit_time >= ?", param.SubmitTimeBegin.Format(_const.CommonDateFormatTpl))
		}
		if !param.SubmitTimeEnd.IsZero() {
			db = db.Where("submit_time <= ?", param.SubmitTimeEnd.Format(_const.CommonDateFormatTpl))
		}
		// 归档时间
		if !param.FileTimeBegin.IsZero() {
			db = db.Where("file_time >= ?", param.FileTimeBegin.Format(_const.CommonDateFormatTpl))
		}
		if !param.FileTimeEnd.IsZero() {
			db = db.Where("file_time <= ?", param.FileTimeEnd.Format(_const.CommonDateFormatTpl))
		}
		if !param.BeginTime.IsZero() {
			db = db.Where("begin_time >= ?", param.BeginTime.Format(_const.CommonDateFormatTpl))
		}
		if !param.EndTime.IsZero() {
			db = db.Where("end_time <= ?", param.EndTime.Format(_const.CommonDateFormatTpl))
		}
		if !param.EndTimeBegin.IsZero() {
			db = db.Where("end_time >= ?", param.EndTimeBegin.Format(_const.CommonDateFormatTpl))
		}
		if !param.EndTimeEnd.IsZero() {
			db = db.Where("end_time <= ?", param.EndTimeEnd.Format(_const.CommonDateFormatTpl))
		}
		var list []*model.PreContractNoVO
		if err := db.Find(&list).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "QueryCoopContractNoFail, CurrentOperator:%s, employeeId:%d, err:%s", param.CurrentOperator, employees[0].ID, err.Error())
			return nil, i18nfmt.New(ctx, "QueryCoopContractNoFail")
		}
		ret = make([]string, len(list))
		for idx, v := range list {
			ret[idx] = v.PreContractNo
		}
	}
	return ret, nil
}

func (c *contractMetaDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, param *model.ContractMetaReq) *gorm.DB {
	db := initDB(ctx, tx).Table(tBContractMeta)

	db = db.Where("is_deleted = 0")

	if param.SourceType == _const.SourceTypeOpen && !param.IsManager {
		excludeStatus := []int{
			_const.ContractStatusProductLineMissed,
			_const.ContractStatusNoAuth,
			_const.ContractStatusPriceRepeat,
			_const.ContractStatusNotCreated,
			_const.ContractStatusRevoke,
			_const.ContractStatusComplianceCheck,
		}
		if param.BizScene != _const.BizScenePayOnBehalf && param.BizScene != _const.BizScenePartnerContract && param.BizSource != _const.BizSourcePartnerQuote &&
			!strings.Contains(param.BizSourceList, strconv.Itoa(_const.BizSourcePartnerQuote)) {
			excludeStatus = append(excludeStatus, _const.ContractStatusDraft)
		}
		db = db.Where("cooperation_status not in (?)", excludeStatus)
	}
	// 若在线协同合同号列表为空 限制只能查询 非在线协同合同
	if len(param.PreContractNoList) > 0 {
		db = db.Where("(biz_source=2 and contract_no in (?)) or biz_source != 2", param.PreContractNoList)
	} else if !param.IsManager && param.TabScene == 0 {
		db = db.Where("biz_source != 2")
	}
	if param.NeedLimit {
		db = db.Where("contract_no in (?)", param.LimitContractNoList)
	}

	if param.BizScene > 0 {
		db = db.Where("biz_scene = ?", param.BizScene)
	}
	if len(param.BizSceneList) > 0 {
		db = db.Where("biz_scene in (?)", strings.Split(param.BizSceneList, ","))
	}
	if param.BizSource > 0 {
		db = db.Where("biz_source = ?", param.BizSource)
	}
	if len(param.BizSourceList) > 0 {
		db = db.Where("biz_source in (?)", strings.Split(param.BizSourceList, ","))
	}
	if len(param.SupplyScene) > 0 {
		supplySceneList := util.SingleList(strings.Split(param.SupplyScene, ","))
		if len(supplySceneList) > 1 {
			db = db.Where("supply_scene in (?)", supplySceneList)
		} else if len(supplySceneList) == 1 {
			db = db.Where("supply_scene = ?", supplySceneList[0])
		}
	}
	if len(param.ContractNo) > 0 {
		// db = db.Where("contract_no like ? or pre_contract_no like ?", buildRightLikeQuery(param.ContractNo), buildRightLikeQuery(param.ContractNo))
		if strings.HasPrefix(param.ContractNo, "PCT") {
			db = db.Where("pre_contract_no like ?", buildRightLikeQuery(param.ContractNo))
		} else if strings.HasPrefix(param.ContractNo, "CT") {
			db = db.Where("contract_no like ?", buildRightLikeQuery(param.ContractNo))
		} else {
			db = db.Where("contract_no = ?", buildRightLikeQuery(param.ContractNo))
		}
	}
	if len(param.VolcContractNo) > 0 {
		db = db.Where("volc_contract_no like ?", buildRightLikeQuery(param.VolcContractNo))
	}
	if len(param.ContractNoList) > 0 {
		db = db.Where("contract_no in (?)", strings.Split(param.ContractNoList, ","))
	}
	if len(param.ContractName) > 0 {
		db = db.Where("contract_name like ?", buildLikeQuery(param.ContractName))
	}
	if len(param.SubjectName) > 0 {
		db = db.Where("subject_name like ?", buildLikeQuery(param.SubjectName))
	}
	if len(param.OtherPartyName) > 0 {
		db = db.Where("other_party_name like ?", buildLikeQuery(param.OtherPartyName))
	}
	if len(param.PropertyCode) > 0 {
		db = db.Where("property_code = ?", param.PropertyCode)
	}
	if len(param.CategoryNo) > 0 {
		categoryNoList := util.SingleList(strings.Split(param.CategoryNo, ","))
		if len(categoryNoList) > 1 {
			db = db.Where("category_no in (?)", categoryNoList)
		} else if len(categoryNoList) == 1 {
			db = db.Where("category_no = ?", categoryNoList[0])
		}
	}
	if len(param.InOutType) > 0 {
		inOutTypeList := util.SingleList(strings.Split(param.InOutType, ","))
		if len(inOutTypeList) > 1 {
			db = db.Where("in_out_type in (?)", inOutTypeList)
		} else if len(inOutTypeList) == 1 {
			db = db.Where("in_out_type = ?", inOutTypeList[0])
		}
	}
	if param.Initiator > 0 {
		db = db.Where("initiator = ?", param.Initiator)
	}
	if param.Status != nil {
		db = db.Where("status = ?", *param.Status)
	}
	if len(param.StatusList) > 0 {
		db = db.Where("status in (?)", strings.Split(param.StatusList, ","))
	}
	if param.ActiveStatus != nil {
		db = db.Where("active_status = ?", *param.ActiveStatus)
	}
	if len(param.ActiveStatusList) > 0 {
		db = db.Where("active_status in (?)", param.ActiveStatusList)
	}
	if param.ArchivedStatus != nil {
		db = db.Where("archived_status = ?", *param.ArchivedStatus)
	}
	if param.CooperationStatus != nil {
		db = db.Where("cooperation_status = ?", *param.CooperationStatus)
	}
	if len(param.CooperationStatusList) > 0 {
		db = db.Where("cooperation_status in (?)", param.CooperationStatusList)
	}
	// 关联报价单号
	if len(param.RelateQuoteID) > 0 {
		db = db.Where("volc_contract_meta.relate_quote_no like ?", buildRightLikeQuery(param.RelateQuoteID))
	}
	// 合同需要报价单
	if param.RelateQuote {
		db = db.Where("volc_contract_meta.relate_quote_no != ?", "")
	}

	if param.Operator > 0 {
		db = db.Where("operator = ? or operator_new = ?", param.Operator, param.Operator)
	}
	if param.RelatedPersonnel > 0 {
		db = db.Where("(operator = ? or related_personnel like ?)", param.RelatedPersonnel, buildLikeQuery(strconv.Itoa(int(param.RelatedPersonnel))))
	}
	if param.Creator > 0 {
		db = db.Where("creator = ? or creator_new = ? ", param.Creator, param.Creator)
	}
	// 注意兼容
	if param.BizAccountID > 0 {
		accountIds := i18nfmt.Sprintf(ctx, "%%%d%%", param.BizAccountID)
		db = db.Where("(biz_account_id = ? or subject_account_ids like ?)", param.BizAccountID, accountIds)
		// db = db.Where("volc_contract_trade_party.account_id = ?", param.BizAccountID).
		// 	Where("volc_contract_trade_party.party_type = 3") // 限制type=3 查询账号，账号信息 存储了关联的对方主体信息
	}
	if !param.CreatedTimeBegin.IsZero() {
		db = db.Where("created_time >= ?", param.CreatedTimeBegin.Format(_const.CommonDateFormatTpl))
	}
	if !param.CreatedTimeEnd.IsZero() {
		db = db.Where("created_time <= ?", param.CreatedTimeEnd.Format(_const.CommonDateFormatTpl))
	}
	if !param.SubmitTimeBegin.IsZero() {
		db = db.Where("submit_time >= ?", param.SubmitTimeBegin.Format(_const.CommonDateFormatTpl))
	}
	if !param.SubmitTimeEnd.IsZero() {
		db = db.Where("submit_time <= ?", param.SubmitTimeEnd.Format(_const.CommonDateFormatTpl))
	}
	// 归档时间
	if !param.FileTimeBegin.IsZero() {
		db = db.Where("file_time >= ?", param.FileTimeBegin.Format(_const.CommonDateFormatTpl))
	}
	if !param.FileTimeEnd.IsZero() {
		db = db.Where("file_time <= ?", param.FileTimeEnd.Format(_const.CommonDateFormatTpl))
	}
	if !param.BeginTime.IsZero() {
		db = db.Where("begin_time >= ?", param.BeginTime.Format(_const.CommonDateFormatTpl))
	}
	if !param.EndTime.IsZero() {
		db = db.Where("end_time <= ?", param.EndTime.Format(_const.CommonDateFormatTpl))
	}
	if !param.EndTimeBegin.IsZero() {
		db = db.Where("end_time >= ?", param.EndTimeBegin.Format(_const.CommonDateFormatTpl))
	}
	if !param.EndTimeEnd.IsZero() {
		db = db.Where("end_time <= ?", param.EndTimeEnd.Format(_const.CommonDateFormatTpl))
	}
	if param.EntrustedParty != "" {
		db = db.Where("entrusted_party like ?", buildLikeQuery(param.EntrustedParty))
	}
	if param.PrincipalParty != "" {
		db = db.Where("principal_party like ?", buildLikeQuery(param.PrincipalParty))
	}
	if param.StartId > 0 {
		// 由于查询是按创建时间降序，所以如果指定startID时，需要按递减逻辑
		db = db.Where("id < ?", param.StartId)
		// 仅在包含StartID参数时生效
		db = db.Order("id desc")
	} else if param.TabScene == _const.ListTabSceneWaitMeDeal {
		// 待我处理页面基于协商状态变更时间正序排序，若协商状态变更时间为空，则基于创建时间正序排序
		db = db.Order("is_urgent DESC, CASE WHEN cooperation_status_change_time IS NULL OR cooperation_status_change_time <= '1970-01-01 00:00:00' THEN created_time ELSE cooperation_status_change_time END ASC")
	} else {
		// 注意
		db = db.Order("id desc")
	}

	if len(param.SpecialContractType) > 0 {
		db = db.Where("FIND_IN_SET(?, special_contract_type)", param.SpecialContractType)
	}
	// 批量申请鲜章 0-否 1-是
	if param.IsMultiApply == _const.FreshSealMultiApplyYes {
		db = db.Where("FIND_IN_SET(?, seal_account_ids)", param.BizAccountID)
		db = db.Where("archived_status = ?", _const.ContractArchived)
		db = db.Where("fresh_seal_approval_no = ?", "")
		db = db.Where("active_status in  (?)", _const.ActiveStatusList)
	}

	// 「合同查询条件&列表内容调整」新增筛选条件
	db = c.buildExtraFilterQuery(ctx, tx, db, param)

	return db
}

// buildExtraFilterQuery 承载「合同查询条件&列表内容调整」新增筛选条件。
// 主表字段直接下推 where；跨表字段通过子查询约束 volc_contract_meta.id，
// 不直接 join 1:N 子表，避免结果集膨胀影响分页与总数。
func (c *contractMetaDaoImpl) buildExtraFilterQuery(ctx context.Context, tx *gorm.DB, db *gorm.DB, param *model.ContractMetaReq) *gorm.DB {
	// 主合同号：直接过滤
	if len(param.MainContractNo) > 0 {
		db = db.Where("main_contract_no like ?", buildRightLikeQuery(param.MainContractNo))
	}
	// 补充场景：主表逗号拼接多值字段，按 PRD 表头多选语义做 OR 匹配
	if len(param.SupplySource) > 0 {
		supplySourceList := util.SingleList(strings.Split(param.SupplySource, ","))
		if len(supplySourceList) == 1 {
			db = db.Where("FIND_IN_SET(?, supply_source)", supplySourceList[0])
		} else if len(supplySourceList) > 1 {
			clauses := make([]string, 0, len(supplySourceList))
			args := make([]interface{}, 0, len(supplySourceList))
			for _, supplySource := range supplySourceList {
				clauses = append(clauses, "FIND_IN_SET(?, supply_source)")
				args = append(args, supplySource)
			}
			db = db.Where("("+strings.Join(clauses, " OR ")+")", args...)
		}
	}
	// 签约形式：修复历史未生效问题
	if len(param.SignatureType) > 0 {
		db = db.Where("signature_type = ?", param.SignatureType)
	}
	// 项目编号：DDL 已通过生成列承接 project_info.ProjectCode，按 PRD 走左精准右模糊
	if len(param.ProjectCode) > 0 {
		db = db.Where("project_code_gen like ?", buildRightLikeQuery(param.ProjectCode))
	}

	// 商务模式：special_contract_type 为主表逗号拼接多值字段，
	// 多选采用多个 FIND_IN_SET AND 串联，保证命中合同需包含全部选中值。
	if len(param.BusinessModeList) > 0 {
		for _, businessMode := range param.BusinessModeList {
			db = db.Where("FIND_IN_SET(?, special_contract_type)", businessMode)
		}
	}

	// 商品名称：前端传入商品英文名唯一标识，仅按内部商品表 volc_contract_commodity.trade_product 过滤，
	// 多选需包含全部选中值，采用 group by having count(distinct) 约束。
	if len(param.TradeProductList) > 0 {
		sub := initDB(ctx, tx).Table(tContractCommodity).
			Select("volc_contract_id").
			Where("trade_product in (?)", param.TradeProductList).
			Group("volc_contract_id").
			Having("count(distinct trade_product) = ?", len(param.TradeProductList))
		db = db.Where("id in (?)", sub)
	}

	// 商机名称：contract_trade_party 拆表过滤，左精准右模糊
	if len(param.OpportunityName) > 0 {
		sub := initDB(ctx, tx).Table(tContractTradeParty).
			Select("volc_contract_id").
			Where("party_type = ?", _const.TradePartyTypeOpportunityName).
			Where("party_name like ?", buildRightLikeQuery(param.OpportunityName))
		db = db.Where("id in (?)", sub)
	}
	// 商机ID：contract_trade_party 拆表过滤，左精准右模糊
	if len(param.OpportunityID) > 0 {
		sub := initDB(ctx, tx).Table(tContractTradeParty).
			Select("volc_contract_id").
			Where("party_type = ?", _const.TradePartyTypeOpportunityID).
			Where("party_name like ?", buildRightLikeQuery(param.OpportunityID))
		db = db.Where("id in (?)", sub)
	}

	// 是否项目制：DDL 已通过生成列将历史无效 JSON 或空值统一落为 N。
	if len(param.WhetherProject) > 0 {
		if param.WhetherProject == _const.Yes {
			db = db.Where("whether_project_gen = ?", _const.Yes)
		} else if param.WhetherProject == _const.No {
			db = db.Where("whether_project_gen = ?", _const.No)
		}
	}

	// 归属行业：DDL 已通过生成列承接 basic_info.DepartmentId，多选任一命中即可。
	if len(param.DepartmentIdList) > 0 {
		db = db.Where("department_id_gen in (?)", param.DepartmentIdList)
	}
	// 业务类型：DDL 已通过生成列承接 basic_info.BusinessType，多选任一命中即可。
	if len(param.BusinessTypeList) > 0 {
		db = db.Where("business_type_gen in (?)", param.BusinessTypeList)
	}

	return db
}

// FindByNo 在线协同专用
func (p *contractMetaDaoImpl) FindByNoForSales(ctx context.Context, tx *gorm.DB, contractNo string) (*model.ContractMetaDB, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no = ? ", contractNo).Where("is_deleted = 0 ").
		Where("biz_source = 2") // 限制只能查到在线协同的合同
	var ret model.ContractMetaDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindVolcContractMetaByNoFail")
	}
	return &ret, nil
}

// ListByContractNos
func (c *contractMetaDaoImpl) ListByContractNos(ctx context.Context, tx *gorm.DB, contractNos []string) (model.ContractMetaDBList, error) {

	db := initDB(ctx, tx).Table(tBContractMeta).Where("contract_no in (?)", contractNos)

	var list model.ContractMetaDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByContractIdsFail, contractNos:%v, err:%s", contractNos, err.Error())
		return nil, i18nfmt.New(ctx, "ListByContractIdsFail")
	}

	return list, nil
}

package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tQuoteRefreshTask = "quote_refresh_task"
)

// QuoteRefreshTaskDao 报价刷数任务 DAO
type QuoteRefreshTaskDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.QuoteRefreshTaskDB) error
	FindByRefreshApprovalID(ctx context.Context, tx *gorm.DB, refreshApprovalID string) (*model.QuoteRefreshTaskDB, error)
	UpdateStatus(ctx context.Context, tx *gorm.DB, id uint64, status int) error
}

type quoteRefreshTaskDaoImpl struct{}

var _quoteRefreshTaskDaoInstance = &quoteRefreshTaskDaoImpl{}

// NewQuoteRefreshTaskDao 创建报价刷数任务 DAO
func NewQuoteRefreshTaskDao() QuoteRefreshTaskDao {
	return _quoteRefreshTaskDaoInstance
}

func (d *quoteRefreshTaskDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.QuoteRefreshTaskDB) error {
	err := initDB(ctx, tx).Table(tQuoteRefreshTask).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateQuoteRefreshTaskFail, refreshApprovalID=%s, err=%s", entity.RefreshApprovalID, err.Error())
		return i18nfmt.New(ctx, "CreateQuoteRefreshTaskFail")
	}
	return nil
}

func (d *quoteRefreshTaskDaoImpl) FindByRefreshApprovalID(ctx context.Context, tx *gorm.DB, refreshApprovalID string) (*model.QuoteRefreshTaskDB, error) {
	var ret model.QuoteRefreshTaskDB
	err := initDB(ctx, tx).Table(tQuoteRefreshTask).
		Where("refresh_approval_id = ?", refreshApprovalID).
		First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindQuoteRefreshTaskFail, refreshApprovalID=%s, err=%s", refreshApprovalID, err.Error())
		return nil, i18nfmt.New(ctx, "FindQuoteRefreshTaskFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

func (d *quoteRefreshTaskDaoImpl) UpdateStatus(ctx context.Context, tx *gorm.DB, id uint64, status int) error {
	updates := map[string]interface{}{
		"status": status,
	}
	err := initDB(ctx, tx).Table(tQuoteRefreshTask).
		Where("id = ?", id).
		Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateQuoteRefreshTaskStatusFail, id=%d, status=%d, err=%s", id, status, err.Error())
		return i18nfmt.New(ctx, "UpdateQuoteRefreshTaskStatusFail")
	}
	return nil
}

package dal

import (
	"code.byted.org/gopkg/lang/conv"
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
)

func Test_riskClauseRoleDaoImpl_List_ByteUTGen(t *testing.T) {
	// 测试List函数在正常情况下，req.Limit不为0且req.NeedTotal为true时的成功场景
	t.Run("ListRiskClauseRoleSuccess", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*riskClauseRoleDaoImpl).buildQuery).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] reqTest.Limit != 0 && reqTest.NeedTotal == true
			var reqTest *model.ListRiskClauseRoleReq = &model.ListRiskClauseRoleReq{
				Offset:    1,
				NeedTotal: true,
				Limit:     1,
			}
			// [目标分支]
			var receiver riskClauseRoleDaoImpl = riskClauseRoleDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1, got2, err := receiver.List(ctxTest, txTest, reqTest)
			// Find函数被mock，但没有对查询结果list赋值，所以查询结果列表为空，长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 虽然对Count函数进行了mock，但没有对total赋值，total初始化为0，所以返回的总数为0
			convey.So(got2, convey.ShouldEqual, 0)
			// 所有被mock的函数均未返回错误，且ignoreErr函数被mock为返回nil，因此不会触发错误返回逻辑，最终err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_riskClauseRoleDaoImpl_buildQuery_ByteUTGen(t *testing.T) {
	// 测试输入`RiskClauseType > 0`且`Status != nil`的场景
	t.Run("RiskClauseTypeAndStatusConditionMet", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var receiver *riskClauseRoleDaoImpl = &riskClauseRoleDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] reqTest.RiskClauseType > 0 && reqTest.Status != nil
			var reqTest *model.ListRiskClauseRoleReq = &model.ListRiskClauseRoleReq{
				Status:         conv.IntPtr(10),
				VolcContractId: 10,
				ApproveId:      "test",
				RiskClauseType: 1,
				RiskLevel:      "Test Value",
			}
			// 运行被测函数
			got1 := receiver.buildQuery(ctxTest, txTest, reqTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 在`buildQuery`函数中，即使对相关函数进行了mock，函数也会初始化一个`gorm.DB`对象并进行一系列操作后返回，不会返回`nil`
			convey.So(got1, convey.ShouldNotBeNil)
		})
	})
}

func Test_riskClauseRoleDaoImpl_ListByVolcContractId_ByteUTGen(t *testing.T) {

	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var volcContractIdTest int64 = 123456789
			// [目标分支]
			var receiver riskClauseRoleDaoImpl = riskClauseRoleDaoImpl{}
			// 运行被测函数
			got1, err := receiver.ListByVolcContractId(ctxTest, txTest, volcContractIdTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 测试中没有对查询结果进行特殊处理，默认情况下查询结果为空列表，所以长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 测试中mock了ignoreErr函数返回nil，因此不会进入错误处理分支，err应该为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

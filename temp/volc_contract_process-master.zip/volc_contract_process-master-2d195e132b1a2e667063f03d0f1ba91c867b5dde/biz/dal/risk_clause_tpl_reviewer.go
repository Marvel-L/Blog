package dal

import (
	"context"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"code.byted.org/gopkg/logs"
)

const (
	tRiskClauseTplReviewer = "risk_clause_tpl_reviewer"
)

type RiskClauseTplReviewerDao interface {
	CreateInBatches(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseTplReviewerDB) error
	ListNewestByTemplateIDs(ctx context.Context, tx *gorm.DB, templateIDs []int64) ([]*model.RiskClauseTplReviewerDB, error)
	ListHistoryByTemplateIDs(ctx context.Context, tx *gorm.DB, templateIDs []int64) ([]*model.RiskClauseTplReviewerDB, error)
	MigrateReviewersToHistory(ctx context.Context, tx *gorm.DB, currentTplID, historyTplID int64, version int) error
}

var _riskClauseTplReviewerDaoInstance = &riskClauseTplReviewerDaoImpl{}

func NewRiskClauseTplReviewerDao() RiskClauseTplReviewerDao {
	return _riskClauseTplReviewerDaoInstance
}

type riskClauseTplReviewerDaoImpl struct {
}

func (r riskClauseTplReviewerDaoImpl) CreateInBatches(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseTplReviewerDB) error {
	if len(entities) == 0 {
		return nil
	}
	err := initDB(ctx, tx).Table(tRiskClauseTplReviewer).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createRiskClauseTplReviewerInBatchesFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createRiskClauseTplReviewerInBatchesFail")
	}
	return nil
}

func (r riskClauseTplReviewerDaoImpl) ListNewestByTemplateIDs(ctx context.Context, tx *gorm.DB, templateIDs []int64) ([]*model.RiskClauseTplReviewerDB, error) {
	if len(templateIDs) == 0 {
		return nil, nil
	}
	var list []*model.RiskClauseTplReviewerDB
	err := initDB(ctx, tx).Table(tRiskClauseTplReviewer).
		Where("risk_clause_tpl_id IN (?) AND is_newest = 1", templateIDs).
		Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListNewestByTemplateIDsFail, ids=%v, err:%s", templateIDs, err.Error())
		return nil, i18nfmt.New(ctx, "ListNewestByTemplateIDsFail")
	}
	return list, nil
}

func (r riskClauseTplReviewerDaoImpl) ListHistoryByTemplateIDs(ctx context.Context, tx *gorm.DB, templateIDs []int64) ([]*model.RiskClauseTplReviewerDB, error) {
	if len(templateIDs) == 0 {
		return nil, nil
	}
	var list []*model.RiskClauseTplReviewerDB
	err := initDB(ctx, tx).Table(tRiskClauseTplReviewer).
		Where("risk_clause_tpl_id IN (?) AND is_newest = 0", templateIDs).
		Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByTemplateIDsFail, ids=%v, err:%s", templateIDs, err.Error())
		return nil, i18nfmt.New(ctx, "ListByTemplateIDsFail")
	}
	return list, nil
}

func (r riskClauseTplReviewerDaoImpl) MigrateReviewersToHistory(ctx context.Context, tx *gorm.DB, currentTplID, historyTplID int64, version int) error {
	err := initDB(ctx, tx).Table(tRiskClauseTplReviewer).
		Where("risk_clause_tpl_id = ? AND version = ?", currentTplID, version).
		Updates(map[string]interface{}{
			"risk_clause_tpl_id": historyTplID,
			"is_newest":          0,
		}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "MigrateReviewersToHistoryFail, currentTplID=%v, historyTplID=%v, version=%v, err:%s", currentTplID, historyTplID, version, err.Error())
		return i18nfmt.New(ctx, "MigrateReviewersToHistoryFail")
	}
	return nil
}

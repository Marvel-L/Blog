package dal

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func TestNewRichTextDao(t *testing.T) {
	mockey.PatchConvey("TestNewRichTextDao", t, func() {
		mockey.PatchConvey("success", func() {
			res := NewRichTextDao()
			convey.So(res, convey.ShouldResemble, &richTextDaoImpl{})
		})
	})
}

func Test_richTextDaoImpl_Create(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Create).To(func(value interface{}) (tx *gorm.DB) {
				return &gorm.DB{}
			}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.Create(context.Background(), &gorm.DB{}, &model.RichText{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case entity == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Create).To(func(value interface{}) (tx *gorm.DB) {
				return &gorm.DB{}
			}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.Create(context.Background(), &gorm.DB{}, nil)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case CreateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Create).To(func(value interface{}) (tx *gorm.DB) {
				return &gorm.DB{
					Error: fmt.Errorf("CreateFail"),
				}
			}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(fmt.Errorf("CreateFail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.Create(context.Background(), &gorm.DB{}, &model.RichText{})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "CreateFail")
		})
	})
}

func Test_richTextDaoImpl_ListByIds(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock(ignoreNotFoundErr).Return(fmt.Errorf("your error")).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				switch dest.(type) {
				case *[]*model.RichText:
					*(dest.(*[]*model.RichText)) = []*model.RichText{{}}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			res, err := v.ListByIds(context.Background(), &gorm.DB{}, []int{0})

			// Assert
			convey.So(res, convey.ShouldResemble, []*model.RichText{{}})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case err == gorm.ErrRecordNotFound", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock(ignoreNotFoundErr).Return(fmt.Errorf("your error")).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				switch dest.(type) {
				case *[]*model.RichText:
					*(dest.(*[]*model.RichText)) = []*model.RichText{{}}
				}
				return &gorm.DB{
					Error: gorm.ErrRecordNotFound,
				}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			res, err := v.ListByIds(context.Background(), &gorm.DB{}, []int{0})

			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case ignoreErr(err) != nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsProduct).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock(ignoreNotFoundErr).Return(fmt.Errorf("your error")).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				switch dest.(type) {
				case *[]*model.RichText:
					*(dest.(*[]*model.RichText)) = []*model.RichText{{}}
				}
				return &gorm.DB{
					Error: fmt.Errorf("ignoreErr"),
				}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			res, err := v.ListByIds(context.Background(), &gorm.DB{}, []int{0})

			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "ignoreErr")
		})
	})
}

func TestRichTextDaoImpl_DeleteByIds(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{0})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case DeleteFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{0})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "DeleteFail")
		})
	})
	t.Run("case Id is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &richTextDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

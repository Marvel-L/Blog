package dal

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_freshSealApprovalItemDaoImpl_List_BitsUTGen(t *testing.T) {
	t.Run("空参数返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：入参两个列表都为空，直接返回错误
			receiver := &freshSealApprovalItemDaoImpl{}
			ctxTest := context.Background()
			var txTest *gorm.DB = nil
			listParams := &ListParams{ContractNoList: []string{}, ApplyIds: []string{}}

			gotList, err := receiver.List(ctxTest, txTest, listParams)

			convey.So(gotList, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListFail listParams")
		})
	})

	t.Run("仅合同号列表查询成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：只有合同号列表非空，查询成功
			receiver := &freshSealApprovalItemDaoImpl{}
			ctxTest := context.Background()
			txTest := &gorm.DB{}

			// 打桩gorm方法，确保链路正常返回
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: nil}).Build()

			listParams := &ListParams{ContractNoList: []string{"CNO-1"}, ApplyIds: []string{}}

			gotList, err := receiver.List(ctxTest, txTest, listParams)

			convey.So(err, convey.ShouldBeNil)
			convey.So(gotList, convey.ShouldBeNil)
		})
	})

	t.Run("仅申请ID查询失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：只有申请ID非空，Find返回错误，触发ignoreErr != nil分支并返回i18n错误
			receiver := &freshSealApprovalItemDaoImpl{}
			ctxTest := context.Background()
			txTest := &gorm.DB{}

			// 打桩gorm方法
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: errors.New("db error")}).Build()

			// 打桩日志，避免默认logger为nil导致的空指针
			mockey.Mock(logs.CtxError).Return().Build()

			listParams := &ListParams{ContractNoList: []string{}, ApplyIds: []string{"AID-1"}}

			gotList, err := receiver.List(ctxTest, txTest, listParams)

			convey.So(gotList, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "freshSealApprovalItemListFail")
		})
	})
}

func Test_freshSealApprovalItemDaoImpl_BatchCreate_BitsUTGen(t *testing.T) {
	t.Run("批量创建失败返回国际化错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与数据
			ctx := context.TODO()
			entities := []*model.FreshSealApprovalItemDB{{ApplyId: "a1"}}

			// 初始化全局_dbClient，保证非空
			baseDB := &gorm.DB{}
			mockey.MockValue(&_dbClient).To(baseDB)

			// Mock WithContext、Table与CreateInBatches使其返回错误
			mockey.Mock((*gorm.DB).WithContext).Return(baseDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(baseDB).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).Return(&gorm.DB{Error: errors.New("db-error")}).Build()

			dao := &freshSealApprovalItemDaoImpl{}
			err := dao.BatchCreate(ctx, nil, entities)

			// 断言走到了错误分支并返回国际化错误
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createFreshSealApprovalItemFail")
		})
	})

	t.Run("批量创建报错但被忽略返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与数据
			ctx := context.TODO()
			entities := []*model.FreshSealApprovalItemDB{{ApplyId: "a2"}}

			// 传入非空tx，走initDB的tx分支
			tx := &gorm.DB{}

			// Mock Table与CreateInBatches，制造RASP拦截错误以被ignoreErr忽略
			mockey.Mock((*gorm.DB).Table).Return(tx).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).Return(&gorm.DB{Error: errors.New("API blocked by RASP")}).Build()

			dao := &freshSealApprovalItemDaoImpl{}
			err := dao.BatchCreate(ctx, tx, entities)

			// 断言错误被忽略，返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_NewFreshSealApprovalItemDao_BitsUTGen(t *testing.T) {
	t.Run("返回单例实例等于全局变量", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 设置全局单例为一个新的实现实例
			inst := &freshSealApprovalItemDaoImpl{}
			mockey.MockValue(&_freshSealApprovalItemDaoInstance).To(inst)

			// 调用构造函数
			got := NewFreshSealApprovalItemDao()

			// 断言返回值类型为实现类型
			_, ok := got.(*freshSealApprovalItemDaoImpl)
			convey.So(ok, convey.ShouldBeTrue)

			// 断言返回值等于全局单例
			convey.So(got, convey.ShouldEqual, inst)
			convey.So(got, convey.ShouldEqual, _freshSealApprovalItemDaoInstance)
		})
	})

	t.Run("多次调用返回相同实例", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 设置全局单例为一个新的实现实例
			inst := &freshSealApprovalItemDaoImpl{}
			mockey.MockValue(&_freshSealApprovalItemDaoInstance).To(inst)

			// 连续调用构造函数
			got1 := NewFreshSealApprovalItemDao()
			got2 := NewFreshSealApprovalItemDao()

			// 断言两次返回一致且等于全局单例
			convey.So(got1, convey.ShouldEqual, got2)
			convey.So(got1, convey.ShouldEqual, _freshSealApprovalItemDaoInstance)
			convey.So(got2, convey.ShouldEqual, _freshSealApprovalItemDaoInstance)
		})
	})
}

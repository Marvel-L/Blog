package dal

import (
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"time"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_contractOperationRecordDaoImpl_ListLastRecordByOperationAndStatus(t *testing.T) {
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDB:
					*(dest.(*model.ContractOperationRecordDB)) = model.ContractOperationRecordDB{}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.ListLastRecordByOperationAndStatus(context.Background(), &gorm.DB{}, "CTXXXXX01", []int{0}, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_contractOperationRecordDaoImpl_GetLastRecordByOperationStatusAndCreatedTime(t *testing.T) {
	t.Run("case req nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			v := contractOperationRecordDaoImpl{}
			got, err := v.GetLastRecordByOperationStatusAndCreatedTime(context.Background(), &gorm.DB{}, nil)

			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "req_is_nil")
		})
	})

	t.Run("case preContractNo empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			v := contractOperationRecordDaoImpl{}
			got, err := v.GetLastRecordByOperationStatusAndCreatedTime(context.Background(), &gorm.DB{}, &model.ContractOperationRecordCreatedTimeReq{
				Operation:      113,
				ContractStatus: 51,
				CreatedTime:    time.Now(),
			})

			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "preContractNo_is_nil")
		})
	})

	t.Run("case no record", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{RowsAffected: 0}).Build()

			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.GetLastRecordByOperationStatusAndCreatedTime(context.Background(), &gorm.DB{}, &model.ContractOperationRecordCreatedTimeReq{
				PreContractNo:  "CTXXXXX01",
				Operation:      113,
				ContractStatus: 51,
				CreatedTime:    time.Now(),
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("case record exists", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				if record, ok := dest.(*model.ContractOperationRecordDB); ok {
					record.Id = 1001
				}
				return &gorm.DB{RowsAffected: 1}
			}).Build()

			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.GetLastRecordByOperationStatusAndCreatedTime(context.Background(), &gorm.DB{}, &model.ContractOperationRecordCreatedTimeReq{
				PreContractNo:  "CTXXXXX01",
				Operation:      113,
				ContractStatus: 51,
				CreatedTime:    time.Now(),
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(got.Id, convey.ShouldEqual, 1001)
		})
	})
}

func Test_contractOperationRecordDaoImpl_ListLastRecordByOperation(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDB:
					logs.Info("dest: %v", dest)
					*(dest.(*model.ContractOperationRecordDB)) = model.ContractOperationRecordDB{}
				case *model.ContractOperationRecordDBList:
					logs.Info("dest: %v", dest)
					*(dest.(*model.ContractOperationRecordDBList)) = model.ContractOperationRecordDBList{{}}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			res, err := v.ListRecordByOperation(context.Background(), &gorm.DB{}, "CTXXXX01", []int{0})

			// Assert
			convey.So(res, convey.ShouldResemble, model.ContractOperationRecordDBList{{}})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case preContractNo == nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDB:
					logs.Info("dest: %v", dest)
					*(dest.(*model.ContractOperationRecordDB)) = model.ContractOperationRecordDB{}
				case *model.ContractOperationRecordDBList:
					logs.Info("dest: %v", dest)
					*(dest.(*model.ContractOperationRecordDBList)) = model.ContractOperationRecordDBList{}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			res, err := v.ListRecordByOperation(context.Background(), &gorm.DB{}, "", []int{0})

			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "preContractNo_is_nil")
		})
	})
	t.Run("case FindErr", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{
					Error: fmt.Errorf("FindErr"),
				}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			res, err := v.ListRecordByOperation(context.Background(), &gorm.DB{}, "CTXXXX01", []int{0})

			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "opRecordDalListByReqFail")
		})
	})
}

func Test_contractOperationRecordDaoImpl_BatchCreate_BitsUTGen(t *testing.T) {
	// Common variables for tests
	ctx := context.Background()
	dao := &contractOperationRecordDaoImpl{}
	entities := []*model.ContractOperationRecordDB{
		{
			Operator: "test_user_1",
		},
		{
			Operator: "test_user_2",
		},
	}
	mockDB := &gorm.DB{}

	mockey.PatchConvey("Test contractOperationRecordDaoImpl BatchCreate", t, func() {
		// Mock the logger to avoid panic and side effects in tests
		mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()

		mockey.PatchConvey("Success cases", func() {
			mockey.PatchConvey("Success case without transaction", func() {
				// Scene Description:
				// This test case simulates a successful batch creation of records when no explicit transaction is provided.
				// Data Setup:
				// - The input transaction 'tx' is nil, so the global DB client will be used.
				// - A slice of ContractOperationRecordDB is provided.
				// Logic Flow:
				// 1. `initDB` is called with a nil `tx`, which in turn calls `_dbClient.WithContext`. The global `_dbClient` is set to a mockable object.
				// 2. Mock `(*gorm.DB).WithContext` to return a valid DB instance for chaining.
				// 3. Mock the chained gorm calls: `Table` and `CreateInBatches`.
				// 4. The final `.Error` on the gorm chain is mocked to be `nil`.
				// 5. The function should return `nil`, indicating success.
				_dbClient = &gorm.DB{} // Initialize global DB client for initDB
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: nil}
				}).Build()

				err := dao.BatchCreate(ctx, nil, entities)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Success case with transaction", func() {
				// Scene Description:
				// This test case simulates a successful batch creation within an existing database transaction.
				// Data Setup:
				// - A non-nil `gorm.DB` instance 'tx' is provided.
				// - A slice of `ContractOperationRecordDB` is provided.
				// Logic Flow:
				// 1. `initDB` is called with a non-nil `tx`, so it returns the provided `tx` directly. `_dbClient.WithContext` is not called.
				// 2. Mock the chained gorm calls on the transaction: `Table` and `CreateInBatches`.
				// 3. The final `.Error` on the gorm chain is mocked to be `nil`.
				// 4. The function should return `nil`, indicating success.
				tx := &gorm.DB{}
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: nil}
				}).Build()

				err := dao.BatchCreate(ctx, tx, entities)

				convey.So(err, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("Failure cases", func() {
			mockey.PatchConvey("Generic database error", func() {
				// Scene Description:
				// This test case simulates a failure during batch creation due to a generic database error.
				// Data Setup:
				// - The input transaction 'tx' is nil.
				// Logic Flow:
				// 1. The Gorm chain is mocked to return a generic error.
				// 2. `ignoreErr` will not ignore this error.
				// 3. `i18nfmt.Sprintf` is mocked to format the error message.
				// 4. The function should return a new error containing the formatted message.
				_dbClient = &gorm.DB{}
				dbErr := errors.New("database connection lost")
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: dbErr}
				}).Build()
				mockey.Mock(i18nfmt.Sprintf).Return("database create failed").Build()

				err := dao.BatchCreate(ctx, nil, entities)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "database create failed")
			})

			mockey.PatchConvey("Record not found error should be ignored", func() {
				// Scene Description:
				// This test case checks that a `gorm.ErrRecordNotFound` is correctly ignored by the `ignoreErr` function.
				// Logic Flow:
				// 1. The Gorm chain is mocked to return `gorm.ErrRecordNotFound`.
				// 2. `ignoreErr` will catch this specific error and return `nil`.
				// 3. The function should proceed as if no error occurred and return `nil`.
				_dbClient = &gorm.DB{}
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: gorm.ErrRecordNotFound}
				}).Build()

				err := dao.BatchCreate(ctx, nil, entities)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("RASP error in non-online env should be ignored", func() {
				// Scene Description:
				// This test case ensures RASP (Runtime Application Self-Protection) errors are ignored in non-production environments.
				// Logic Flow:
				// 1. `env.IsOnline` is mocked to return `false`.
				// 2. The Gorm chain is mocked to return a RASP-specific error message.
				// 3. `ignoreErr` will detect the RASP error in a non-online env and return `nil`.
				// 4. The function should return `nil`.
				_dbClient = &gorm.DB{}
				mockey.Mock(env.IsOnline).Return(false).Build()
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: errors.New("API blocked by RASP")}
				}).Build()

				err := dao.BatchCreate(ctx, nil, entities)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("RASP error in online env should not be ignored", func() {
				// Scene Description:
				// This test case ensures RASP errors are propagated in production environments.
				// Logic Flow:
				// 1. `env.IsOnline` is mocked to return `true`.
				// 2. The Gorm chain is mocked to return a RASP-specific error.
				// 3. `ignoreErr` will not ignore the error because the environment is online.
				// 4. The function will format and return a new error.
				_dbClient = &gorm.DB{}
				mockey.Mock(env.IsOnline).Return(true).Build()
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).CreateInBatches).To(func(db *gorm.DB, value interface{}, batchSize int) *gorm.DB {
					return &gorm.DB{Error: errors.New("API blocked by RASP")}
				}).Build()
				mockey.Mock(i18nfmt.Sprintf).Return("rasp error occurred").Build()

				err := dao.BatchCreate(ctx, nil, entities)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "rasp error occurred")
			})
		})
	})
}

func Test_contractOperationRecordDaoImpl_DeleteByNo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_contractOperationRecordDaoImpl_DeleteByNo", t, func() {
		dao := contractOperationRecordDaoImpl{}
		ctx := context.Background()
		preContractNo := "test-contract-no"
		mockDB := &gorm.DB{}

		mockey.PatchConvey("success case without transaction", func() {
			// 场景描述：
			// 数据库删除操作成功，未使用事务。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. initDB 通过 _dbClient.WithContext 获取 gorm.DB 实例。
			// 2. GORM 链式调用 Table, Where, Delete 均成功。
			// 3. Delete 方法返回的 gorm.DB 实例中 Error 字段为 nil。
			// 4. ignoreErr(nil) 直接返回 nil。
			// 5. 函数返回 nil，表示删除成功。
			_dbClient = &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, nil, preContractNo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case with transaction", func() {
			// 场景描述：
			// 数据库删除操作成功，使用传入的事务。
			// 构造数据：
			// 传入一个非 nil 的 *gorm.DB 作为事务句柄。
			// 逻辑链路：
			// 1. initDB 直接返回传入的事务 tx。
			// 2. GORM 链式调用 Table, Where, Delete 在 tx 上执行。
			// 3. Delete 方法返回的 gorm.DB 实例中 Error 字段为 nil。
			// 4. ignoreErr(nil) 直接返回 nil。
			// 5. 函数返回 nil，表示删除成功。
			mockTx := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, mockTx, preContractNo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("db error case", func() {
			// 场景描述：
			// 数据库删除操作返回一个通用错误。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. initDB 获取 gorm.DB 实例。
			// 2. GORM 链式调用到 Delete 方法时，返回的 gorm.DB 实例中 Error 字段为一个通用错误。
			// 3. ignoreErr 无法识别该错误，将其原样返回。
			// 4. 函数返回该通用错误。
			_dbClient = &gorm.DB{}
			dbErr := errors.New("generic db error")
			finalDB := &gorm.DB{Error: dbErr}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, nil, preContractNo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "generic db error")
		})

		mockey.PatchConvey("record not found error case", func() {
			// 场景描述：
			// 数据库删除操作返回 gorm.ErrRecordNotFound，该错误应被忽略。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. initDB 获取 gorm.DB 实例。
			// 2. GORM 的 Delete 方法返回的 gorm.DB 实例中 Error 字段为 gorm.ErrRecordNotFound。
			// 3. ignoreErr 通过 ignoreNotFoundErr 识别到该错误，返回 nil。
			// 4. 函数返回 nil。
			_dbClient = &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, nil, preContractNo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("RASP error in non-online env case", func() {
			// 场景描述：
			// 在非线上环境，数据库返回 RASP 错误，该错误应被忽略。
			// 构造数据：
			// env.IsOnline() 返回 false。
			// 逻辑链路：
			// 1. initDB 获取 gorm.DB 实例。
			// 2. GORM 的 Delete 方法返回的 gorm.DB 实例中 Error 字段为 RASP 错误。
			// 3. env.IsOnline() 返回 false。
			// 4. ignoreErr 通过 ignoreRaspErr 识别到该错误，返回 nil。
			// 5. 函数返回 nil。
			_dbClient = &gorm.DB{}
			raspErr := errors.New("some error: API blocked by RASP")
			finalDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, nil, preContractNo)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("RASP error in online env case", func() {
			// 场景描述：
			// 在线上环境，数据库返回 RASP 错误，该错误不应被忽略。
			// 构造数据：
			// env.IsOnline() 返回 true。
			// 逻辑链路：
			// 1. initDB 获取 gorm.DB 实例。
			// 2. GORM 的 Delete 方法返回的 gorm.DB 实例中 Error 字段为 RASP 错误。
			// 3. env.IsOnline() 返回 true。
			// 4. ignoreErr 中的 ignoreRaspErr 不处理该错误，原样返回。
			// 5. 函数返回 RASP 错误。
			_dbClient = &gorm.DB{}
			raspErr := errors.New("some error: API blocked by RASP")
			finalDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(finalDB).Build()

			err := dao.DeleteByNo(ctx, nil, preContractNo)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
		})
	})
}

func Test_contractOperationRecordDaoImpl_UpdateNo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_contractOperationRecordDaoImpl_UpdateNo", t, func() {
		// Arrange common variables
		c := contractOperationRecordDaoImpl{}
		ctx := context.Background()
		oldNo := "OLD_NO_123"
		newNo := "NEW_NO_456"

		mockey.PatchConvey("success case with transaction", func() {
			// 场景描述：
			// 在传入有效事务（tx）的情况下，数据库更新操作成功。
			// 构造数据：
			// - tx: 一个mock的 *gorm.DB 实例，其Error字段为nil。
			// 逻辑链路：
			// 1. 调用 UpdateNo 函数，传入一个非空的 tx。
			// 2. initDB(ctx, tx) 将直接返回传入的 tx。
			// 3. GORM 的链式调用 Table(...).Where(...).Updates(...) 在此 tx 上执行。
			// 4. Mock Updates 方法返回的 *gorm.DB 实例，其 Error 字段为 nil。
			// 5. ignoreErr(nil) 返回 nil。
			// 6. 函数成功执行并返回 nil。
			mockTx := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockTx).Build()

			// Act
			err := c.UpdateNo(ctx, mockTx, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case without transaction", func() {
			// 场景描述：
			// 在未传入事务（tx为nil）的情况下，使用全局DB客户端，数据库更新操作成功。
			// 构造数据：
			// - tx: nil
			// 逻辑链路：
			// 1. 调用 UpdateNo 函数，传入 tx=nil。
			// 2. initDB(ctx, nil) 会调用 _dbClient.WithContext(ctx)。
			// 3. 我们需要初始化 _dbClient 以免空指针，并 Mock (*gorm.DB).WithContext 方法来返回我们控制的 mock DB。
			// 4. Mock GORM 的链式调用，使其最终返回的 Error 为 nil。
			// 5. ignoreErr(nil) 返回 nil。
			// 6. 函数成功执行并返回 nil。
			_dbClient = &gorm.DB{}
			defer func() { _dbClient = nil }() // Clean up global state

			mockDB := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()

			// Act
			err := c.UpdateNo(ctx, nil, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case with generic db error", func() {
			// 场景描述：
			// 数据库更新操作返回一个通用的、未被特殊处理的错误。
			// 构造数据：
			// - tx: 一个mock的 *gorm.DB 实例，其Error字段为一个通用error。
			// 逻辑链路：
			// 1. GORM 的 Updates 方法返回的 *gorm.DB 实例，其 Error 字段为一个非nil的通用错误。
			// 2. ignoreErr(err) 会将此错误原样返回。
			// 3. 函数内部会记录错误日志 (logs.CtxError)。
			// 4. 函数会调用 i18nfmt.New 生成并返回一个新的错误。
			mockTx := &gorm.DB{Error: errors.New("db connection failed")}
			expectedErr := errors.New("RecordUpdateNoFail")

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockTx).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			// Act
			err := c.UpdateNo(ctx, mockTx, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RecordUpdateNoFail")
		})

		mockey.PatchConvey("failure case with record not found error", func() {
			// 场景描述：
			// 数据库操作返回 gorm.ErrRecordNotFound，该错误应被忽略。
			// 构造数据：
			// - tx: 一个mock的 *gorm.DB 实例，其Error字段为 gorm.ErrRecordNotFound。
			// 逻辑链路：
			// 1. GORM 的 Updates 方法返回的 *gorm.DB 实例，其 Error 字段为 gorm.ErrRecordNotFound。
			// 2. ignoreErr(gorm.ErrRecordNotFound) 会返回 nil。
			// 3. 函数应返回 nil，表示操作成功（或无事发生）。
			mockTx := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockTx).Build()

			// Act
			err := c.UpdateNo(ctx, mockTx, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case with RASP error in non-online env", func() {
			// 场景描述：
			// 数据库操作返回 RASP 错误，但在非线上环境中，该错误应被忽略。
			// 构造数据：
			// - tx: 一个mock的 *gorm.DB 实例，其Error字段为一个包含 "API blocked by RASP" 的错误。
			// - env.IsOnline: Mock 返回 false。
			// 逻辑链路：
			// 1. GORM 的 Updates 方法返回 RASP 错误。
			// 2. ignoreErr 函数调用 ignoreRaspErr。
			// 3. 由于 env.IsOnline() 为 false，ignoreRaspErr 返回 nil。
			// 4. 函数最终返回 nil。
			mockTx := &gorm.DB{Error: errors.New("API blocked by RASP")}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockTx).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()

			// Act
			err := c.UpdateNo(ctx, mockTx, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case with RASP error in online env", func() {
			// 场景描述：
			// 数据库操作返回 RASP 错误，在线上环境中，该错误不应被忽略。
			// 构造数据：
			// - tx: 一个mock的 *gorm.DB 实例，其Error字段为一个包含 "API blocked by RASP" 的错误。
			// - env.IsOnline: Mock 返回 true。
			// 逻辑链路：
			// 1. GORM 的 Updates 方法返回 RASP 错误。
			// 2. ignoreErr 函数调用 ignoreRaspErr。
			// 3. 由于 env.IsOnline() 为 true，ignoreRaspErr 原样返回错误。
			// 4. 函数将此错误视为通用失败，记录日志并返回 i18nfmt.New 生成的错误。
			mockTx := &gorm.DB{Error: errors.New("API blocked by RASP")}
			expectedErr := errors.New("RecordUpdateNoFail")

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockTx).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			// Act
			err := c.UpdateNo(ctx, mockTx, oldNo, newNo)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RecordUpdateNoFail")
		})
	})
}

func Test_contractOperationRecordDaoImpl_BatchListRecordByOperationAndStatus(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			whereArg := map[string]interface{}{}
			MockGormDBWhere(whereArg)
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDBList:
					*(dest.(*model.ContractOperationRecordDBList)) = model.ContractOperationRecordDBList{}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.BatchListRecordByOperationAndStatus(context.Background(), &gorm.DB{}, []string{"CTXXX01"}, []int{2, 103}, 2)

			// Assert
			GetWhereArgStringArry(whereArg, "pre_contract_no in (?)")
			convey.So(GetWhereArgStringArry(whereArg, "pre_contract_no in (?)"), convey.ShouldResemble, []string{"CTXXX01"})
			convey.So(GetWhereArgIntArry(whereArg, "operation in (?)"), convey.ShouldResemble, []int{2, 103})
			convey.So(GetWhereArgInt(whereArg, "contract_status = ?"), convey.ShouldEqual, 2)
			convey.So(got, convey.ShouldResemble, model.ContractOperationRecordDBList{})
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case preContractNos is nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			whereArg := map[string]interface{}{}
			MockGormDBWhere(whereArg)
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDBList:
					*(dest.(*model.ContractOperationRecordDBList)) = model.ContractOperationRecordDBList{}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.BatchListRecordByOperationAndStatus(context.Background(), &gorm.DB{}, []string{}, []int{2, 103}, 2)

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "preContractNos_is_nil")
		})
	})
	t.Run("case ignoreErrFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreErr).Return(fmt.Errorf("ignoreNotFoundErrFail")).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			whereArg := map[string]interface{}{}
			MockGormDBWhere(whereArg)
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.ContractOperationRecordDBList:
					*(dest.(*model.ContractOperationRecordDBList)) = model.ContractOperationRecordDBList{}
				}
				return &gorm.DB{}
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := contractOperationRecordDaoImpl{}
			got, err := v.BatchListRecordByOperationAndStatus(context.Background(), &gorm.DB{}, []string{"CTXXX01"}, []int{2, 103}, 2)

			// Assert
			GetWhereArgStringArry(whereArg, "pre_contract_no in (?)")
			convey.So(GetWhereArgStringArry(whereArg, "pre_contract_no in (?)"), convey.ShouldResemble, []string{"CTXXX01"})
			convey.So(GetWhereArgIntArry(whereArg, "operation in (?)"), convey.ShouldResemble, []int{2, 103})
			convey.So(GetWhereArgInt(whereArg, "contract_status = ?"), convey.ShouldEqual, 2)
			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "opRecordDalListByReqFail")
		})
	})
}

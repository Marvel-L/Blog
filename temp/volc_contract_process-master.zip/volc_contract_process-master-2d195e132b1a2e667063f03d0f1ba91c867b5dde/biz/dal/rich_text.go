package dal

import (
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
)

const (
	tRichText = "rich_text"
)

type RichTextDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.RichText) error
	ListByIds(ctx context.Context, tx *gorm.DB, ids []int) ([]*model.RichText, error)
	DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error
	Save(ctx context.Context, tx *gorm.DB, entity *model.RichText) error
	GetByID(ctx context.Context, tx *gorm.DB, id int64) (*model.RichText, error)
}

type richTextDaoImpl struct {
}

var _richTextDaoInstance = &richTextDaoImpl{}

func NewRichTextDao() RichTextDao {
	return _richTextDaoInstance
}

func (r *richTextDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.RichText) error {
	if entity == nil {
		logs.CtxInfo(ctx, "CreateRichText, entity is nil")
		return nil
	}
	err := initDB(ctx, tx).Table(tRichText).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createVolcContractRichTextFail, err:%s", err.Error())
		return err
	}
	return nil
}

func (r *richTextDaoImpl) ListByIds(ctx context.Context, tx *gorm.DB, ids []int) ([]*model.RichText, error) {
	logs.CtxInfo(ctx, "ListByIds, ids=%v", ids)
	db := initDB(ctx, tx).Table(tRichText).
		Where("id in (?)", ids)
	var list []*model.RichText
	err := db.Find(&list).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListRichTextByIdsFail, ids=%v, err=%s", ids, err.Error())
		return nil, err
	}
	return list, nil
}

func (r *richTextDaoImpl) DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error {
	if len(ids) == 0 {
		return nil
	}
	db := initDB(ctx, tx).Table(tRichText).Where("id in (?)", ids)
	return ignoreErr(db.Delete(nil).Error)
}

func (r *richTextDaoImpl) Save(ctx context.Context, tx *gorm.DB, entity *model.RichText) error {
	if entity == nil {
		logs.CtxInfo(ctx, "SaveRichText, entity is nil")
		return nil
	}
	err := initDB(ctx, tx).Table(tRichText).Save(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "SaveRichTextFail, err:%s", err.Error())
		return err
	}

	return nil
}

func (r *richTextDaoImpl) GetByID(ctx context.Context, tx *gorm.DB, id int64) (*model.RichText, error) {
	ret := &model.RichText{}
	if err := initDB(ctx, tx).Table(tRichText).Where("id = ?", id).First(ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

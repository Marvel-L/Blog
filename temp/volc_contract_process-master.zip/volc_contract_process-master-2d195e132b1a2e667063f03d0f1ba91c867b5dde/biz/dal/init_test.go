package dal

import (
	"code.byted.org/security/dkms-gorm/double_write_hook"
	"code.byted.org/security/dkms-gorm/encrypt_type"
	"errors"
	"testing"

	"code.byted.org/gorm/bytedgorm"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"

	"volc_contract_process/pkg/conf"
)

/**
 * @Author: wangzhen.12@bytedance.com
 * @Date: 2024/8/14 17:18
 * @Desc:
 */

func Test_Init(t *testing.T) {
	t.Run("case demo#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(gorm.Open).Return(&gorm.DB{
				Config: &gorm.Config{
					Logger: bytedgorm.Logger{},
				},
			}, nil).Build()
			// Act
			cfg := &conf.MysqlConf{Cluster: "a.b.c"}
			db, err := newDBClient(cfg, false, dbresolver.Write)
			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(db, convey.ShouldNotBeNil)
		})
	})
	t.Run("case demo#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(encrypt_type.Init).Return().Build()
			mockey.Mock(double_write_hook.SetDBHook).Return(nil).Build()
			mockey.Mock(newDBClient).Return(&gorm.DB{}, nil).Build()
			// Act
			err := Init(&conf.GlobalConf{})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case demo#3", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(encrypt_type.Init).Return().Build()
			mockey.Mock(double_write_hook.SetDBHook).Return(errors.New("double_write_hook.SetDBHook fail")).Build()
			mockey.Mock(newDBClient).Return(&gorm.DB{}, nil).Build()
			// Act

			convey.So(func() { Init(&conf.GlobalConf{}) }, convey.ShouldPanic)
		})
	})
}

package dal

import (
	"context"
	"errors"
	"strings"
	"time"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/util"

	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tBizContract = "biz_contract"
)

type BizContractDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.BizContractDB) error
	List(ctx context.Context, tx *gorm.DB, req *model.BizContractReq) (model.BizContractDBList, int, error)
	UpdateStatus(ctx context.Context, tx *gorm.DB, identifier string, scene int, status int) error
	ChangeContractNo(ctx context.Context, tx *gorm.DB, identifier string, scene int, contractNo string) error
	UpdateContract(ctx context.Context, tx *gorm.DB, entity *model.BizContractDB) error
	UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, identifier string, scene int, updates map[string]interface{}) error
	FindListByAccountID(ctx context.Context, tx *gorm.DB, accountId int, scene int) ([]string, error)
	FindListByCreator(ctx context.Context, tx *gorm.DB, creator string, scene int) ([]string, error)
	FindByIdentifier(ctx context.Context, tx *gorm.DB, identifier string, scene int) (*model.BizContractDB, error)
	QueryUnconfirmedContractCount(ctx context.Context, tx *gorm.DB, accountId string, scene int) (int, error)
	FindByContractNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.BizContractDB, error)
	FindByOAContractNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.BizContractDB, error)
	FindByID(ctx context.Context, tx *gorm.DB, id int64) (*model.BizContractDB, error)
}

var _bizContractDaoInstance = &bizContractDaoImpl{}

func NewBizContractDao() BizContractDao {
	return _bizContractDaoInstance
}

type bizContractDaoImpl struct {
}

func (q *bizContractDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.BizContractDB) error {
	err := initDB(ctx, tx).Table(tBizContract).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createBizContractFail, err:%s", err.Error())
		return errors.New("createBizContractFail")
	}
	return nil
}

func (q *bizContractDaoImpl) UpdateStatus(ctx context.Context, tx *gorm.DB, identifier string, scene int, status int) error {
	db := initDB(ctx, tx).Table(tBizContract)
	err := db.Where("identifier = ?", identifier).Where("scene = ?", scene).
		Updates(map[string]interface{}{"status": status}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateBizContractStatusFail, err:%v", err)
		return i18nfmt.New(ctx, "updateBizContractStatusFail")
	}
	return nil
}

func (q *bizContractDaoImpl) ChangeContractNo(ctx context.Context, tx *gorm.DB, identifier string, scene int, contractNo string) error {
	db := initDB(ctx, tx).Table(tBizContract)
	err := db.Where("identifier = ?", identifier).Where("scene = ?", scene).
		Updates(map[string]interface{}{"contract_no": contractNo}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangeContractNoFail, err:%v", err)
		return i18nfmt.New(ctx, "ChangeContractNoFail")
	}
	return nil
}

// FindByIdentifier 根据编号查询
func (q *bizContractDaoImpl) FindByIdentifier(ctx context.Context, tx *gorm.DB, identifier string, scene int) (*model.BizContractDB, error) {

	db := initDB(ctx, tx).Table(tBizContract).Where("identifier = ? ", identifier).Where("scene = ?", scene)
	var ret model.BizContractDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindPreSalesContractByNoFail")
	}
	return &ret, nil
}

func (q *bizContractDaoImpl) FindListByAccountID(ctx context.Context, tx *gorm.DB, accountId int, scene int) ([]string, error) {
	db := initDB(ctx, tx).Table(tBizContract).Select("distinct contract_no").Where("account_id = ? ", accountId).
		Where("scene = ?", scene)
	var list []*model.ContractNoVo
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindListByAccountIDFail, accountId:%s, err:%s", accountId, err.Error())
		return nil, i18nfmt.New(ctx, "FindListByAccountIDFail")
	}
	ret := make([]string, len(list))
	for idx, v := range list {
		ret[idx] = v.ContractNo
	}
	return ret, nil
}

func (q *bizContractDaoImpl) FindListByCreator(ctx context.Context, tx *gorm.DB, creator string, scene int) ([]string, error) {
	db := initDB(ctx, tx).Table(tBizContract).Select("distinct contract_no").Where("creator = ? ", creator).
		Where("scene = ?", scene)
	var list []*model.ContractNoVo
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindListByCreatorFail, creator:%s, err:%s", creator, err.Error())
		return nil, i18nfmt.New(ctx, "FindListByCreatorFail")
	}
	ret := make([]string, len(list))
	for idx, v := range list {
		ret[idx] = v.ContractNo
	}
	return ret, nil
}

func (q *bizContractDaoImpl) UpdateContract(ctx context.Context, tx *gorm.DB, entity *model.BizContractDB) error {
	updates := map[string]interface{}{}
	if len(entity.ContractNo) != 0 {
		updates["contract_no"] = entity.ContractNo
	}
	if !entity.FinishTime.IsZero() {
		updates["finish_time"] = entity.FinishTime
	}
	if !entity.ValidityBegin.IsZero() {
		updates["validity_begin"] = entity.ValidityBegin
	}
	if len(entity.FileIdUnsigned) != 0 {
		updates["file_id_unsigned"] = entity.FileIdUnsigned
	}
	if len(entity.FileIdSigned) != 0 {
		updates["file_id_signed"] = entity.FileIdSigned
	}
	if len(entity.BizDataInfo) != 0 {
		updates["biz_data_info"] = entity.BizDataInfo
	}
	if len(entity.Extra) != 0 {
		updates["extra"] = entity.Extra
	}
	if len(entity.Remark) != 0 {
		updates["remark"] = entity.Remark
	}
	if len(entity.OaContractNo) != 0 {
		updates["oa_contract_no"] = entity.OaContractNo
	}
	err := NewBizContractDao().UpdateFieldsByNo(ctx, tx, entity.Identifier, entity.Scene, updates)
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateFieldsByNoFail, err:%v", err)
		return err
	}
	return nil
}

func (q *bizContractDaoImpl) QueryUnconfirmedContractCount(ctx context.Context, tx *gorm.DB, accountId string, scene int) (int, error) {
	db := initDB(ctx, tx).Table(tBizContract).Where("account_id = ? ", accountId).
		Where("status = ?", _const.BizContractStatusToBeConfirm).Where("scene = ?", scene)
	var total int64
	if err := db.Count(&total).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListBizContractCountFail, err:%s", err.Error())
		return int(total), i18nfmt.New(ctx, "QueryUnconfirmedContractCountFail")
	}
	return int(total), nil
}

func (q *bizContractDaoImpl) List(ctx context.Context, tx *gorm.DB, req *model.BizContractReq) (model.BizContractDBList, int, error) {
	var total int64
	var err error

	db := q.buildQuery(ctx, tx, req)

	if req.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListBizContractCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListBizContractCountFail")
		}
	}

	var list model.BizContractDBList

	query := db.Offset(req.Offset)
	// 只有当req.Limit不为0时，才添加Limit条件
	if req.Limit != 0 {
		query = query.Limit(req.Limit)
	}
	err = query.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListBizContractFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListBizContractFail")
	}

	return list, int(total), nil
}

func (q *bizContractDaoImpl) UpdateFieldsByNo(ctx context.Context, tx *gorm.DB, identifier string, scene int, updates map[string]interface{}) error {
	err := initDB(ctx, tx).Table(tBizContract).Where("identifier = ?", identifier).
		Where("scene = ?", scene).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateFieldsByNoFail, err: %v", err)
		return i18nfmt.New(ctx, "UpdateFieldsByNoFail")
	}
	return nil
}

func (q *bizContractDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, req *model.BizContractReq) *gorm.DB {
	db := initDB(ctx, tx).Table(tBizContract)

	if req.SourceType == _const.SourceTypeInner {
		if !req.IsManager { // 内部用户 非管理员仅允许查看自己相关的合同
			db = db.Where("creator = ?", req.CurrentOperator)
		}
	} else if req.SourceType == _const.SourceTypeOpen {
		if req.Scene != _const.BizScenePayOnBehalf { // 代付场景不限制
			db = db.Where("status not in (?)", []int{
				_const.BizContractStatusInit,              // 初始化
				_const.BizContractStatusNoAuth,            // 未实名认证
				_const.BizContractStatusProductLineMissed, // 产品线未配置
				_const.BizContractStatusPriceRepeat,
			})
		}
	}

	if len(req.ExcludeScreenStatus) > 0 {
		db = db.Where("status not in (?)", req.ExcludeScreenStatus)
	}
	if len(req.ContractNo) > 0 {
		db = db.Where("contract_no = ?", req.ContractNo)
	}
	if len(req.Identifier) > 0 {
		db = db.Where("Identifier like ?", util.GenLikeStr(req.Identifier))
	}
	if req.CreateTimeBegin > 0 {
		createTimeBegin := time.Unix(req.CreateTimeBegin, 0).Local()
		db = db.Where("created_time >= ?", createTimeBegin)
	}
	if req.CreateTimeEnd > 0 {
		createTimeEnd := time.Unix(req.CreateTimeEnd, 0).Local()
		db = db.Where("created_time <= ?", createTimeEnd)
	}
	if req.UpdateTimeBegin > 0 {
		updateTimeBegin := time.Unix(req.UpdateTimeBegin, 0).Local()
		db = db.Where("updated_time >= ?", updateTimeBegin)
	}
	if req.UpdateTimeEnd > 0 {
		updateTimeEnd := time.Unix(req.UpdateTimeEnd, 0).Local()
		db = db.Where("updated_time <= ?", updateTimeEnd)
	}
	if req.ValidityBegin > 0 && req.ValidityEnd > 0 {
		beginTime := time.Unix(req.ValidityBegin, 0).Local()
		endTime := time.Unix(req.ValidityEnd, 0).Local()
		db = db.Where("? >= validity_begin and validity_end >= ?", endTime, beginTime)
	}
	if req.AccountID > 0 {
		db = db.Where("account_id = ?", req.AccountID)
	}
	if len(req.Status) > 0 {
		db = db.Where("status in (?)", strings.Split(req.Status, ","))
	}
	db = db.Where("scene = ?", req.Scene)
	db = db.Order(_const.GetOrderType(req.OrderBy))
	return db
}

func (q *bizContractDaoImpl) FindByContractNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.BizContractDB, error) {
	db := initDB(ctx, tx).Table(tBizContract).Where("contract_no = ? ", contractNo)
	var ret model.BizContractDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindByContractNoFail")
	}
	return &ret, nil
}

func (q *bizContractDaoImpl) FindByOAContractNo(ctx context.Context, tx *gorm.DB, contractNo string) (*model.BizContractDB, error) {
	db := initDB(ctx, tx).Table(tBizContract).Where("oa_contract_no = ? or contract_no = ?", contractNo, contractNo)
	var ret model.BizContractDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindByContractNoFail")
	}
	return &ret, nil
}

func (q *bizContractDaoImpl) FindByID(ctx context.Context, tx *gorm.DB, id int64) (*model.BizContractDB, error) {
	db := initDB(ctx, tx).Table(tBizContract).Where("id = ? ", id)
	var ret model.BizContractDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		return nil, i18nfmt.New(ctx, "FindByContractNoFail")
	}
	return &ret, nil
}

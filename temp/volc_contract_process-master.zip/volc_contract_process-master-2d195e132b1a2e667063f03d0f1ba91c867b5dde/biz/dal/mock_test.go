package dal

import (
	"fmt"
	"strconv"

	"github.com/bytedance/mockey"
	"gorm.io/gorm"

	"volc_contract_process/pkg/util"
)

func MockGormDBWhere(whereArg map[string]interface{}) {
	mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
		key := query.(string)
		var values []string
		for _, arg := range args {
			if v, ok := arg.([]string); ok {
				values = append(values, v...)
			}
			if v, ok := arg.(string); ok {
				values = append(values, v)
			}
			if v, ok := arg.([]int); ok {
				values = append(values, util.ListInt2String(v)...)
			}
			if v, ok := arg.(int); ok {
				values = append(values, fmt.Sprintf("%d", v))
			}
		}
		whereArg[key] = values
		return &gorm.DB{} // Add your code
	}).Build()
}

func GetWhereArgString(whereArg map[string]interface{}, key string) string {
	value := whereArg[key]
	res, _ := value.([]string)
	return res[0]
}

func GetWhereArgStringArry(whereArg map[string]interface{}, key string) []string {
	value := whereArg[key]
	res, _ := value.([]string)
	return res
}

func GetWhereArgInt(whereArg map[string]interface{}, key string) int {
	value := whereArg[key]
	res, _ := value.([]string)
	data, _ := strconv.Atoi(res[0])
	return data
}

func GetWhereArgIntArry(whereArg map[string]interface{}, key string) []int {
	value := whereArg[key]
	res, _ := value.([]string)
	intRes := make([]int, 0)
	for _, v := range res {
		data, _ := strconv.Atoi(v)
		intRes = append(intRes, data)
	}
	return intRes
}

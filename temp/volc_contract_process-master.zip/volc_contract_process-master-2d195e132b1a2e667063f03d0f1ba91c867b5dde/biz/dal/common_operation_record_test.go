package dal

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_commonOperationRecordImpl_ListOperationRecord(t *testing.T) {
	tests := []struct {
		name string
		list func(*commonOperationRecordImpl) error
	}{
		{
			name: "by ident no",
			list: func(dao *commonOperationRecordImpl) error {
				_, err := dao.ListOperationRecordByIdentNo(context.Background(), &gorm.DB{}, "contract-no", 1)
				return err
			},
		},
		{
			name: "by contract id",
			list: func(dao *commonOperationRecordImpl) error {
				_, err := dao.ListOperationRecordByContractID(context.Background(), &gorm.DB{}, 1, 1001)
				return err
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey("filters unsupported approval operation records", t, func() {
				whereArgs := map[string]interface{}{}
				MockGormDBWhere(whereArgs)
				mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
				mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()

				err := tt.list(&commonOperationRecordImpl{})

				convey.So(err, convey.ShouldBeNil)
				operation, ok := whereArgs["operation IN ?"]
				convey.So(ok, convey.ShouldBeTrue)
				convey.So(operation, convey.ShouldResemble, []string{
					"1", "2", "3", "4", "5", "6", "7", "8", "9",
					"11", "12", "13", "14", "15", "16", "17", "18", "118",
				})
			})
		})
	}
}

func Test_commonOperationRecordImpl_GetLastOperationRecordByCreatedTime(t *testing.T) {
	t.Run("case req nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			v := &commonOperationRecordImpl{}
			got, err := v.GetLastOperationRecordByCreatedTime(context.Background(), &gorm.DB{}, nil)

			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "req_is_nil")
		})
	})

	t.Run("case contractID empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			v := &commonOperationRecordImpl{}
			got, err := v.GetLastOperationRecordByCreatedTime(context.Background(), &gorm.DB{}, &model.CommonOperationRecordCreatedTimeReq{
				Scene:       1,
				Operation:   118,
				CreatedTime: time.Now(),
			})

			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "volcContractID_is_nil")
		})
	})

	t.Run("case no record", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{RowsAffected: 0}).Build()

			_dbClient = &gorm.DB{}
			v := &commonOperationRecordImpl{}
			got, err := v.GetLastOperationRecordByCreatedTime(context.Background(), &gorm.DB{}, &model.CommonOperationRecordCreatedTimeReq{
				VolcContractID: 1001,
				Scene:          1,
				Operation:      118,
				CreatedTime:    time.Now(),
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("case record exists", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				if record, ok := dest.(*model.CommonOperationRecordDB); ok {
					record.Id = 1001
				}
				return &gorm.DB{RowsAffected: 1}
			}).Build()

			_dbClient = &gorm.DB{}
			v := &commonOperationRecordImpl{}
			got, err := v.GetLastOperationRecordByCreatedTime(context.Background(), &gorm.DB{}, &model.CommonOperationRecordCreatedTimeReq{
				VolcContractID: 1001,
				Scene:          1,
				Operation:      118,
				CreatedTime:    time.Now(),
			})

			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeNil)
			convey.So(got.Id, convey.ShouldEqual, 1001)
		})
	})
}

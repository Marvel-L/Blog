package Iterator

import (
	"context"
	"errors"
	"testing"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"

	"code.byted.org/lang/gg/gptr"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_ContractIterator_fetchNextBatch_BitsUTGen(t *testing.T) {
	t.Run("hasMore为false时直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 10)

			// 预设状态为无更多数据
			it.hasMore = false
			it.currentBatch = model.ContractMetaDBList{&model.ContractMetaDB{}}
			it.currentIndex = 5
			it.offset = 20

			it.fetchNextBatch()

			convey.So(it.currentBatch, convey.ShouldBeNil)
			convey.So(it.currentIndex, convey.ShouldEqual, 0)
			convey.So(it.offset, convey.ShouldEqual, 20)
		})
	})

	t.Run("List返回错误时应重置状态并关闭hasMore", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 10)
			it.offset = 5

			// 针对真实单例对象的方法进行打桩
			dao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(dao, "List")).Return(model.ContractMetaDBList(nil), 0, errors.New("db error")).Build()

			origOffset := it.offset
			it.fetchNextBatch()

			convey.So(it.req.Limit, convey.ShouldEqual, it.pageLimit)
			convey.So(it.req.Offset, convey.ShouldEqual, origOffset)
			convey.So(it.currentBatch, convey.ShouldBeNil)
			convey.So(it.currentIndex, convey.ShouldEqual, 0)
			convey.So(it.hasMore, convey.ShouldBeFalse)
			convey.So(it.offset, convey.ShouldEqual, origOffset)
		})
	})

	t.Run("List返回非空数据时应更新offset并保持hasMore为true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 10)
			it.offset = 2

			batch := model.ContractMetaDBList{&model.ContractMetaDB{}, &model.ContractMetaDB{}}
			dao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(dao, "List")).Return(batch, 2, nil).Build()

			origOffset := it.offset
			it.fetchNextBatch()

			convey.So(it.req.Limit, convey.ShouldEqual, it.pageLimit)
			convey.So(it.req.Offset, convey.ShouldEqual, origOffset)
			convey.So(len(it.currentBatch), convey.ShouldEqual, 2)
			convey.So(it.currentIndex, convey.ShouldEqual, 0)
			convey.So(it.hasMore, convey.ShouldBeTrue)
			convey.So(it.offset, convey.ShouldEqual, origOffset+it.pageLimit)
		})
	})

	t.Run("List返回空数据时应更新offset并置hasMore为false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 10)
			it.offset = 3

			batch := model.ContractMetaDBList{} // 空数据
			dao := dal.NewContractMetaDao()
			mockey.Mock(mockey.GetMethod(dao, "List")).Return(batch, 0, nil).Build()

			origOffset := it.offset
			it.fetchNextBatch()

			convey.So(it.req.Limit, convey.ShouldEqual, it.pageLimit)
			convey.So(it.req.Offset, convey.ShouldEqual, origOffset)
			convey.So(len(it.currentBatch), convey.ShouldEqual, 0)
			convey.So(it.currentIndex, convey.ShouldEqual, 0)
			convey.So(it.hasMore, convey.ShouldBeFalse)
			convey.So(it.offset, convey.ShouldEqual, origOffset+it.pageLimit)
		})
	})
}

func Test_NewContractIterator_BitsUTGen(t *testing.T) {
	t.Run("创建迭代器_请求非空_初始化状态正确", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造上下文与请求参数
			ctx := context.WithValue(context.Background(), "k", "v")
			req := &model.ContractMetaReq{
				CurrentOperator:   "alice",
				Limit:             123,
				NeedTotal:         true,
				CooperationStatus: gptr.Of(1),
				ActiveStatus:      gptr.Of(2),
				ArchivedStatus:    gptr.Of(3),
			}
			pageLimit := 200

			// 调用待测函数
			iter := NewContractIterator(ctx, req, pageLimit)

			// 断言迭代器初始化的各字段
			convey.So(iter, convey.ShouldNotBeNil)
			convey.So(iter.ctx, convey.ShouldEqual, ctx)
			convey.So(iter.req, convey.ShouldEqual, req)
			convey.So(iter.pageLimit, convey.ShouldEqual, pageLimit)
			convey.So(iter.offset, convey.ShouldEqual, 0)
			convey.So(iter.hasMore, convey.ShouldBeTrue)
			convey.So(iter.currentBatch, convey.ShouldBeNil)
			convey.So(iter.currentIndex, convey.ShouldEqual, 0)
		})
	})

	t.Run("创建迭代器_请求为空_仅校验字段赋值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 请求参数置为nil，校验函数仍能正确初始化
			ctx := context.Background()
			var req *model.ContractMetaReq = nil
			pageLimit := 500

			iter := NewContractIterator(ctx, req, pageLimit)

			convey.So(iter, convey.ShouldNotBeNil)
			convey.So(iter.ctx, convey.ShouldEqual, ctx)
			convey.So(iter.req, convey.ShouldNotBeNil)
			convey.So(iter.pageLimit, convey.ShouldEqual, pageLimit)
			convey.So(iter.offset, convey.ShouldEqual, 0)
			convey.So(iter.hasMore, convey.ShouldBeTrue)
			convey.So(iter.currentBatch, convey.ShouldBeNil)
			convey.So(iter.currentIndex, convey.ShouldEqual, 0)
		})
	})
}

func Test_ContractIterator_HasNext_BitsUTGen(t *testing.T) {
	t.Run("当前批次有数据直接返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当前批次已有数据，应该直接返回true
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 2)
			it.currentBatch = []*model.ContractMetaDB{{}, {}}
			it.currentIndex = 0

			ret := it.HasNext()
			convey.So(ret, convey.ShouldBeTrue)
		})
	})

	t.Run("没有更多数据返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// hasMore=false，且当前批次为空，应该返回false
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 2)
			it.currentBatch = nil
			it.currentIndex = 0
			it.hasMore = false

			ret := it.HasNext()
			convey.So(ret, convey.ShouldBeFalse)
		})
	})

	t.Run("有更多数据且拉取到非空批次返回true", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// hasMore=true，fetchNextBatch后拿到非空批次，最终返回true
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 2)
			it.currentBatch = nil
			it.currentIndex = 0
			it.hasMore = true

			mockey.Mock((*ContractIterator).fetchNextBatch).To(func(ci *ContractIterator) {
				ci.currentBatch = []*model.ContractMetaDB{{}}
				ci.currentIndex = 0
			}).Build()

			ret := it.HasNext()
			convey.So(ret, convey.ShouldBeTrue)
		})
	})

	t.Run("有更多数据但拉取到空批次返回false", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// hasMore=true，fetchNextBatch后拿到空批次（nil或len=0），最终返回false
			ctx := context.Background()
			req := &model.ContractMetaReq{}
			it := NewContractIterator(ctx, req, 2)
			it.currentBatch = nil
			it.currentIndex = 0
			it.hasMore = true

			mockey.Mock((*ContractIterator).fetchNextBatch).To(func(ci *ContractIterator) {
				ci.currentBatch = nil
				ci.currentIndex = 0
			}).Build()

			ret := it.HasNext()
			convey.So(ret, convey.ShouldBeFalse)
		})
	})
}

func Test_ContractIterator_Next_BitsUTGen(t *testing.T) {
	t.Run("当前批次为nil时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			it := &ContractIterator{
				currentBatch: nil,
				currentIndex: 0,
			}
			db := it.Next()

			// 断言返回nil且索引不变
			convey.So(db, convey.ShouldBeNil)
			convey.So(it.currentIndex, convey.ShouldEqual, 0)
		})
	})

	t.Run("当前索引越界时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			batch := []*model.ContractMetaDB{
				{Creator: "creator1"},
			}
			it := &ContractIterator{
				currentBatch: batch,
				currentIndex: 1, // 索引越界
			}
			db := it.Next()

			// 断言返回nil且索引不变
			convey.So(db, convey.ShouldBeNil)
			convey.So(it.currentIndex, convey.ShouldEqual, 1)
		})
	})

	t.Run("正常返回元素并递增索引", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			it := NewContractIterator(context.Background(), &model.ContractMetaReq{}, 10)
			batch := []*model.ContractMetaDB{
				{Creator: "creatorA"},
				{Creator: "creatorB"},
			}
			it.currentBatch = batch
			it.currentIndex = 0

			// 第一次获取应返回第一个元素，索引递增
			db1 := it.Next()
			convey.So(db1, convey.ShouldEqual, batch[0])
			convey.So(it.currentIndex, convey.ShouldEqual, 1)

			// 第二次获取应返回第二个元素，索引递增
			db2 := it.Next()
			convey.So(db2, convey.ShouldEqual, batch[1])
			convey.So(it.currentIndex, convey.ShouldEqual, 2)

			// 第三次获取应返回nil（索引越界），索引不变
			db3 := it.Next()
			convey.So(db3, convey.ShouldBeNil)
			convey.So(it.currentIndex, convey.ShouldEqual, 2)
		})
	})
}

package Iterator

import (
	"context"

	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
)

// ContractIterator 合同迭代器
// 提供分页迭代合同数据的功能
// 可以用于批量处理大量合同数据，避免一次性加载所有数据到内存
// 使用示例：
//
//	iterator := NewContractIterator(ctx, req, 200)
//	for iterator.HasNext() {
//	    contract := iterator.Next()
//	    // 处理合同数据
//	}
type ContractIterator struct {
	ctx       context.Context
	req       *model.ContractMetaReq
	pageLimit int

	// 当前批次数据
	currentBatch []*model.ContractMetaDB
	currentIndex int

	// 分页状态
	offset  int
	hasMore bool
}

// NewContractIterator 创建新的合同迭代器
// ctx: 上下文
// req: 合同查询请求参数
// pageLimit: 每页大小，建议设置为200-500之间
func NewContractIterator(ctx context.Context, req *model.ContractMetaReq, pageLimit int) *ContractIterator {
	if req == nil {
		req = &model.ContractMetaReq{}
	}
	return &ContractIterator{
		ctx:       ctx,
		req:       req,
		pageLimit: pageLimit,
		offset:    0,
		hasMore:   true,
	}
}

// HasNext 检查是否还有更多合同数据
func (it *ContractIterator) HasNext() bool {
	// 如果当前批次还有数据，返回true
	if it.currentBatch != nil && it.currentIndex < len(it.currentBatch) {
		return true
	}

	// 如果没有更多数据了，返回false
	if !it.hasMore {
		return false
	}

	// 获取下一批数据
	it.fetchNextBatch()

	// 检查新批次是否有数据
	return it.currentBatch != nil && it.currentIndex < len(it.currentBatch)
}

// Next 获取下一个合同数据
func (it *ContractIterator) Next() *model.ContractMetaDB {
	if it.currentBatch == nil || it.currentIndex >= len(it.currentBatch) {
		return nil
	}

	db := it.currentBatch[it.currentIndex]
	it.currentIndex++
	return db
}

// fetchNextBatch 获取下一批合同数据
func (it *ContractIterator) fetchNextBatch() {
	if !it.hasMore {
		it.currentBatch = nil
		it.currentIndex = 0
		return
	}

	it.req.Limit = it.pageLimit
	it.req.Offset = it.offset

	batch, _, err := dal.NewContractMetaDao().List(it.ctx, nil, it.req)
	if err != nil {
		logs.CtxError(it.ctx, "ListContractMetaFail, req=%+v, err=%s", it.req, err.Error())
		it.currentBatch = nil
		it.currentIndex = 0
		it.hasMore = false
		return
	}

	it.offset += it.pageLimit
	it.hasMore = len(batch) > 0 // 只要返回的数据不为空，就认为还有更多数据
	it.currentBatch = batch
	it.currentIndex = 0
}

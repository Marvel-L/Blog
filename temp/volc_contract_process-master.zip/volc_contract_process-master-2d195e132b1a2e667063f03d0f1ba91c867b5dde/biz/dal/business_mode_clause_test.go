package dal

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_businessModeClauseDaoImpl_Create(t *testing.T) {
	t.Run("创建成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			entity := &model.BusinessModeClauseDB{
				VolcContractID: 1001,
				ContractNo:     "CT2024062201",
				BusinessMode:   "直营",
				ClauseSummary:  "摘要",
			}
			var gotEntity *model.BusinessModeClauseDB

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				gotEntity = value.(*model.BusinessModeClauseDB)
				return &gorm.DB{}
			}).Build()

			err := dao.Create(ctx, nil, entity)

			convey.So(err, convey.ShouldBeNil)
			convey.So(gotEntity, convey.ShouldResemble, entity)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			entity := &model.BusinessModeClauseDB{}
			dbErr := errors.New("create failed")
			expectedErr := errors.New("CreateBusinessModeClauseFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.Create(ctx, nil, entity)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_businessModeClauseDaoImpl_UpdateByID(t *testing.T) {
	t.Run("更新字段为空时直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &businessModeClauseDaoImpl{}

			err := dao.UpdateByID(context.Background(), nil, 1001, 12, nil)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("更新成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			updates := map[string]interface{}{
				"clause_summary": "更新后的摘要",
				"updater":        "tester",
			}
			var whereCalls []string
			var gotUpdates map[string]interface{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				gotUpdates = values.(map[string]interface{})
				return &gorm.DB{}
			}).Build()

			err := dao.UpdateByID(ctx, nil, 1001, 12, updates)

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "id = ? and volc_contract_id = ?|[12 1001]")
			convey.So(whereCalls, convey.ShouldContain, "is_deleted = ?|[0]")
			convey.So(gotUpdates, convey.ShouldResemble, updates)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("update failed")
			expectedErr := errors.New("UpdateBusinessModeClauseByIDFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.UpdateByID(ctx, nil, 1001, 12, map[string]interface{}{"updater": "tester"})

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_businessModeClauseDaoImpl_DeleteByIDs(t *testing.T) {
	t.Run("待删除ID为空时直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &businessModeClauseDaoImpl{}

			err := dao.DeleteByIDs(context.Background(), nil, 1001, nil)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("删除成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			var whereCalls []string
			var gotUpdates map[string]interface{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				gotUpdates = values.(map[string]interface{})
				return &gorm.DB{}
			}).Build()

			err := dao.DeleteByIDs(ctx, nil, 1001, []uint64{12, 34})

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "volc_contract_id = ?|[1001]")
			convey.So(whereCalls, convey.ShouldContain, "id in (?)|[[12 34]]")
			convey.So(whereCalls, convey.ShouldContain, "is_deleted = ?|[0]")
			convey.So(gotUpdates, convey.ShouldResemble, map[string]interface{}{"is_deleted": 1})
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("delete failed")
			expectedErr := errors.New("DeleteBusinessModeClauseByIDsFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.DeleteByIDs(ctx, nil, 1001, []uint64{12})

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_businessModeClauseDaoImpl_ListByContractID(t *testing.T) {
	t.Run("查询成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			expected := []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 12}, VolcContractID: 1001, BusinessMode: "直营"},
				{BaseDB: model.BaseDB{Id: 34}, VolcContractID: 1001, BusinessMode: "分销"},
			}
			var whereCalls []string

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				*(dest.(*[]*model.BusinessModeClauseDB)) = expected
				return &gorm.DB{}
			}).Build()

			list, err := dao.ListByContractID(ctx, nil, 1001)

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "volc_contract_id = ?|[1001]")
			convey.So(whereCalls, convey.ShouldContain, "is_deleted = ?|[0]")
			convey.So(list, convey.ShouldResemble, expected)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("query failed")
			expectedErr := errors.New("ListBusinessModeClauseByContractIDFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			list, err := dao.ListByContractID(ctx, nil, 1001)

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(list, convey.ShouldBeNil)
		})
	})
}

func Test_businessModeClauseDaoImpl_ListByContractIDAndBusinessModes(t *testing.T) {
	t.Run("商务模式为空时直接返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &businessModeClauseDaoImpl{}

			list, err := dao.ListByContractIDAndBusinessModes(context.Background(), nil, 1001, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
		})
	})

	t.Run("查询成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			expected := []*model.BusinessModeClauseDB{
				{BaseDB: model.BaseDB{Id: 12}, VolcContractID: 1001, BusinessMode: "直营"},
			}
			var whereCalls []string

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				*(dest.(*[]*model.BusinessModeClauseDB)) = expected
				return &gorm.DB{}
			}).Build()

			list, err := dao.ListByContractIDAndBusinessModes(ctx, nil, 1001, []string{"直营", "分销"})

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "volc_contract_id = ?|[1001]")
			convey.So(whereCalls, convey.ShouldContain, "business_mode in (?)|[[直营 分销]]")
			convey.So(whereCalls, convey.ShouldContain, "is_deleted = ?|[0]")
			convey.So(list, convey.ShouldResemble, expected)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &businessModeClauseDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("query failed")
			expectedErr := errors.New("ListBusinessModeClauseByContractIDAndBusinessModesFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			list, err := dao.ListByContractIDAndBusinessModes(ctx, nil, 1001, []string{"直营"})

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(list, convey.ShouldBeNil)
		})
	})
}

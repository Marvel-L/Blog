package dal

import (
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_mdPartyInfoDaoImpl_ListByIdRange_BitsUTGen(t *testing.T) {
	c := &mdPartyInfoDaoImpl{}
	ctx := context.Background()
	mockDB := &gorm.DB{}

	t.Run("Success case with tx is nil", func(t *testing.T) {
		mockey.PatchConvey("should return a list of MdPartyInfoDB successfully", t, func() {
			// Mock dependencies for the tx == nil path in initDB
			mockey.Mock(initDB).Return(mockDB).Build()

			// Mock the GORM query chain
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()

			// Mock the Find operation to populate the list and return no error
			expectedList := model.MdPartyInfoDBList{{}}
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.MdPartyInfoDBList); ok {
					*list = expectedList
				}
				return &gorm.DB{}
			}).Build()

			result, err := c.ListByIdRange(ctx, nil, 10, 5)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedList)
		})
	})

	t.Run("Success case with tx is not nil and no results", func(t *testing.T) {
		mockey.PatchConvey("should use the provided tx and return an empty list successfully", t, func() {
			txDB := &gorm.DB{}
			// Mock dependencies for the tx != nil path in initDB
			mockey.Mock(initDB).Return(mockDB).Build()

			// Mock the GORM query chain on the transaction DB
			mockey.Mock((*gorm.DB).Table).Return(txDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(txDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(txDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(txDB).Build()

			// Mock the Find operation to return no error and no results
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()

			result, err := c.ListByIdRange(ctx, txDB, 10, 5)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeEmpty)
		})
	})

	t.Run("Failure case - DB error", func(t *testing.T) {
		mockey.PatchConvey("should return an error when the database find operation fails", t, func() {
			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()

			// Mock Find to return a generic DB error
			dbError := errors.New("database query failed")
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbError}).Build()

			// Mock the error formatter
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			result, err := c.ListByIdRange(ctx, nil, 10, 5)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "FindByIdRangeFail")
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Success case - Record not found", func(t *testing.T) {
		mockey.PatchConvey("should return an empty list and no error when record not found", t, func() {
			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()

			// Mock Find to return gorm.ErrRecordNotFound, which should be ignored
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			result, err := c.ListByIdRange(ctx, nil, 10, 5)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeEmpty)
		})
	})
}

func Test_mdPartyInfoDaoImpl_UpdateByMap(t *testing.T) {
	dao := &mdPartyInfoDaoImpl{}
	updates := map[string]interface{}{
		"ident_no": "test_ident_no",
	}
	ctx := context.Background()

	t.Run("Success case", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when database update is successful", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			// Test with a non-nil transaction
			errWithTx := dao.UpdateByMap(ctx, mockDB, int64(1), updates)
			convey.So(errWithTx, convey.ShouldBeNil)

			// Test with a nil transaction (uses global _dbClient)
			errWithoutTx := dao.UpdateByMap(ctx, nil, int64(1), updates)
			convey.So(errWithoutTx, convey.ShouldBeNil)
		})
	})

	t.Run("Failure case - database error", func(t *testing.T) {
		mockey.PatchConvey("Should return a formatted error when database update fails", t, func() {
			dbErr := errors.New("database update failed")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: dbErr}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.UpdateByMap(ctx, nil, int64(1), updates)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "UpdateByMapFail")
		})
	})

	t.Run("Success case - ignored 'record not found' error", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when 'record not found' error is returned from DB", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.UpdateByMap(ctx, nil, int64(1), updates)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_mdPartyInfoDaoImpl_GetMdPartyInfoByID_BitsUTGen(t *testing.T) {
	c := &mdPartyInfoDaoImpl{}
	ctx := context.Background()
	mockDB := &gorm.DB{}

	t.Run("Success case - record found", func(t *testing.T) {
		mockey.PatchConvey("should return party info when record is found", t, func() {
			expectedInfo := &model.MdPartyInfoDB{
				BaseDB:    model.BaseDB{Id: 1},
				IdentName: "Test Party",
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if info, ok := dest.(*model.MdPartyInfoDB); ok {
					*info = *expectedInfo
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, nil, 1)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, expectedInfo)
		})
	})

	t.Run("Success case - record not found", func(t *testing.T) {
		mockey.PatchConvey("should return nil, nil when gorm.ErrRecordNotFound is returned", t, func() {
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, nil, 99)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure case - generic database error", func(t *testing.T) {
		mockey.PatchConvey("should return the error when a generic db error occurs", t, func() {
			dbErr := errors.New("database connection failed")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: dbErr}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, nil, 1)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Success case - using transaction", func(t *testing.T) {
		mockey.PatchConvey("should use the provided transaction and return the record", t, func() {
			txDB := &gorm.DB{}
			expectedInfo := &model.MdPartyInfoDB{
				BaseDB:    model.BaseDB{Id: 2},
				IdentName: "Tx Party",
			}

			mockey.Mock(initDB).Return(txDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(txDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(txDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if info, ok := dest.(*model.MdPartyInfoDB); ok {
					*info = *expectedInfo
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, txDB, 2)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, expectedInfo)
		})
	})

	t.Run("Success case - RASP error ignored in non-online env", func(t *testing.T) {
		mockey.PatchConvey("should ignore RASP error and return nil, nil in non-online env", t, func() {
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, nil, 3)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure case - RASP error not ignored in online env", func(t *testing.T) {
		mockey.PatchConvey("should not ignore RASP error and return it in online env", t, func() {
			raspErr := errors.New("test_error")
			mockey.Mock(env.IsOnline).Return(true).Build()

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()

			result, err := c.GetMdPartyInfoByID(ctx, nil, 4)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, raspErr)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_mdPartyInfoDaoImpl_GetMdPartyInfoByIdentNo_BitsUTGen(t *testing.T) {
	c := &mdPartyInfoDaoImpl{}
	ctx := context.Background()
	identNo := "test-ident-no"
	mockDB := &gorm.DB{}

	t.Run("Success - Record found", func(t *testing.T) {
		mockey.PatchConvey("should return party info when a record is found", t, func() {
			expectedPartyInfo := &model.MdPartyInfoDB{
				BaseDB: model.BaseDB{Id: 123},
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if p, ok := dest.(*model.MdPartyInfoDB); ok {
					*p = *expectedPartyInfo
				}
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(ignoreErr).To(func(err error) error { return err }).Build()

			result, err := c.GetMdPartyInfoByIdentNo(ctx, nil, identNo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedPartyInfo)
		})
	})

	t.Run("Success - Record not found", func(t *testing.T) {
		mockey.PatchConvey("should return nil, nil when record is not found", t, func() {
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build() // ignoreErr handles ErrRecordNotFound

			result, err := c.GetMdPartyInfoByIdentNo(ctx, nil, identNo)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("Failure - Database error", func(t *testing.T) {
		mockey.PatchConvey("should return an error when a database error occurs", t, func() {
			dbError := errors.New("database connection failed")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: dbError}).Build()
			mockey.Mock(ignoreErr).Return(dbError).Build() // ignoreErr does not handle this error

			result, err := c.GetMdPartyInfoByIdentNo(ctx, nil, identNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, dbError)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_mdPartyInfoDaoImpl_CreateMdPartyInfo_ByteUTGen(t *testing.T) {
	// 测试输入mdPartyInfo为nil的场景
	t.Run("CreateMdPartyInfoWithNilInput", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			var receiver *mdPartyInfoDaoImpl = &mdPartyInfoDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] mdPartyInfoTest == nil
			var mdPartyInfoTest *model.MdPartyInfoDB = nil
			// 运行被测函数
			err := receiver.CreateMdPartyInfo(ctxTest, txTest, mdPartyInfoTest)
			// 传入的mdPartyInfo为nil时，预期执行分支if mdPartyInfo == nil，会返回错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 传入的mdPartyInfo为nil时，会调用i18nfmt.New返回该错误信息
			convey.So(err.Error(), convey.ShouldEqual, "CreateMdPartyInfoFail, mdPartyInfo is nil")
		})
	})

	t.Run("ignoreErr(err) != nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(errors.New("ignoreErrReturn")).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: errors.New("createMdPartyInfoFail")}).Build()
			// 构造函数入参
			var receiver *mdPartyInfoDaoImpl = &mdPartyInfoDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var mdPartyInfoTest *model.MdPartyInfoDB = &model.MdPartyInfoDB{
				IdentNo: "123456199001011234",
			}
			// 运行被测函数
			err := receiver.CreateMdPartyInfo(ctxTest, txTest, mdPartyInfoTest)
			// 因为mock了ignoreErr函数返回nil，不会触发错误返回逻辑，所以预期err为nil
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "createMdPartyInfoFail")
		})
	})

	// 测试创建MdPartyInfo时无错误发生的场景
	t.Run("CreateMdPartyInfoSuccess", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var receiver *mdPartyInfoDaoImpl = &mdPartyInfoDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var mdPartyInfoTest *model.MdPartyInfoDB = &model.MdPartyInfoDB{
				IdentNo: "123456199001011234",
			}
			// 运行被测函数
			err := receiver.CreateMdPartyInfo(ctxTest, txTest, mdPartyInfoTest)
			// 因为mock了ignoreErr函数返回nil，不会触发错误返回逻辑，所以预期err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

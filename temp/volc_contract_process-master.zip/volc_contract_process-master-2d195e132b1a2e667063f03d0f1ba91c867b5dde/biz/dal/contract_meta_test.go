package dal

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"code.byted.org/gopkg/logs"
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/proxy/starlingcli"
)

func Test_contractMetaDaoImpl_UpdateCoStatusById(t *testing.T) {
	t.Run("case 执行成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).Return(fmt.Errorf("fail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateCoStatusById(context.Background(), &gorm.DB{}, 0, 0, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录未找到", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(fmt.Errorf("fail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateCoStatusById(context.Background(), &gorm.DB{}, 0, 0, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录命中RASP", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("API blocked by RASP")}).Build()
			mockey.Mock(i18nfmt.New).Return(fmt.Errorf("fail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateCoStatusById(context.Background(), &gorm.DB{}, 0, 0, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录命中RASP，线上环境", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("API blocked by RASP")}).Build()
			mockey.Mock(i18nfmt.New).Return(fmt.Errorf("fail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateCoStatusById(context.Background(), &gorm.DB{}, 0, 0, 0)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "fail")
		})
	})
	t.Run("case 更新失败，未命中跳过逻辑", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("UpdateFail")}).Build()
			mockey.Mock(i18nfmt.New).Return(fmt.Errorf("fail")).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateCoStatusById(context.Background(), &gorm.DB{}, 0, 0, 0)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "fail")
		})
	})
}

func Test_contractMetaDaoImpl_FindByNoForSales_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_contractMetaDaoImpl_FindByNoForSales", t, func() {
		// 准备通用数据
		ctx := context.Background()
		testContractNo := "test-contract-123"
		p := &contractMetaDaoImpl{}
		mockDB := &gorm.DB{}

		// 模拟数据库链式调用
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()

		mockey.PatchConvey("查询成功", func() {
			// 场景描述：数据库查询成功，找到匹配的合同记录。
			// 构造数据：构造一个预期的ContractMetaDB返回结果。
			// 逻辑链路：
			// 1. initDB, Table, Where链式调用正常。
			// 2. db.First调用成功，返回nil错误，并将查询结果填充到传入的结构体指针中。
			// 3. 函数返回填充好的结构体指针和nil错误。
			expectedResult := &model.ContractMetaDB{
				ContractNo: testContractNo,
				BizSource:  2, // 匹配 "biz_source = 2"
			}
			mockey.Mock((*gorm.DB).First).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractMetaDB); ok {
					*ret = *expectedResult
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// 调用目标函数
			result, err := p.FindByNoForSales(ctx, nil, testContractNo)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("记录未找到", func() {
			// 场景描述：数据库中没有找到匹配的合同记录。
			// 构造数据：无。
			// 逻辑链路：
			// 1. initDB, Table, Where链式调用正常。
			// 2. db.First调用返回gorm.ErrRecordNotFound错误。
			// 3. 函数捕获该特定错误，并返回(nil, nil)。
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// 调用目标函数
			result, err := p.FindByNoForSales(ctx, nil, testContractNo)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("数据库查询通用错误", func() {
			// 场景描述：数据库查询时发生了一个通用错误（非RecordNotFound）。
			// 构造数据：构造一个通用的error。
			// 逻辑链路：
			// 1. initDB, Table, Where链式调用正常。
			// 2. db.First调用返回一个通用错误。
			// 3. 错误进入ignoreErr函数，由于不是可忽略的错误，被原样返回。
			// 4. 函数调用i18nfmt.New生成新的错误信息并返回。
			dbErr := errors.New("some db connection error")
			i18nErr := errors.New("FindVolcContractMetaByNoFail")
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build() // 确保ignoreRaspErr不忽略
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			// 调用目标函数
			result, err := p.FindByNoForSales(ctx, nil, testContractNo)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, i18nErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("非线上环境忽略RASP错误", func() {
			// 场景描述：在非线上环境，数据库查询返回RASP错误，该错误应被忽略。
			// 构造数据：构造一个包含"API blocked by RASP"的error。
			// 逻辑链路：
			// 1. initDB, Table, Where链式调用正常。
			// 2. db.First返回RASP错误。
			// 3. Mock env.IsOnline()返回false。
			// 4. 错误进入ignoreErr -> ignoreRaspErr，由于是非线上环境，返回nil。
			// 5. ignoreErr返回nil，函数继续执行并返回(&ret, nil)。
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			// 调用目标函数
			result, err := p.FindByNoForSales(ctx, nil, testContractNo)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(*result, convey.ShouldResemble, model.ContractMetaDB{}) // 返回的是一个空的结构体指针
		})

		mockey.PatchConvey("线上环境不忽略RASP错误", func() {
			// 场景描述：在线上环境，数据库查询返回RASP错误，该错误不应被忽略。
			// 构造数据：构造一个包含"API blocked by RASP"的error。
			// 逻辑链路：
			// 1. initDB, Table, Where链式调用正常。
			// 2. db.First返回RASP错误。
			// 3. Mock env.IsOnline()返回true。
			// 4. 错误进入ignoreErr -> ignoreRaspErr，由于是线上环境，原样返回错误。
			// 5. ignoreErr返回错误，函数调用i18nfmt.New生成新的错误信息并返回。
			raspErr := errors.New("API blocked by RASP")
			i18nErr := errors.New("FindVolcContractMetaByNoFail")
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			// 调用目标函数
			result, err := p.FindByNoForSales(ctx, nil, testContractNo)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, i18nErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_contractMetaDaoImpl_collectPreContractNoResult(t *testing.T) {
	// Arrange
	v := &contractMetaDaoImpl{}
	type args struct {
		ctx   context.Context
		query *gorm.DB
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		want    []string
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx:   context.Background(),
				query: &gorm.DB{},
			},
			mocks: func() {
				db := &gorm.DB{}
				mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
					switch dest.(type) {
					case *[]*model.PreContractNoVO: // Here replace with your model type, like Task{}
						*(dest.(*[]*model.PreContractNoVO)) = []*model.PreContractNoVO{
							{PreContractNo: "a"},
							{PreContractNo: "b"},
						}
					}
					return db
				}).Build()
				mockey.Mock(i18nfmt.New).Return(fmt.Errorf("your error")).Build()
			},
			want:    []string{"a", "b"},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				got, err := v.collectPreContractNoResult(
					tt.args.ctx,
					tt.args.query,
				)

				// Assert
				convey.So(got, convey.ShouldResemble, tt.want)
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

func Test_contractMetaDaoImpl_collectContractNoResult(t *testing.T) {
	// Arrange
	v := &contractMetaDaoImpl{}
	type args struct {
		ctx   context.Context
		query *gorm.DB
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		want    []string
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx:   context.Background(),
				query: &gorm.DB{},
			},
			mocks: func() {
				db := &gorm.DB{}
				mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
					switch dest.(type) {
					case *[]*model.ContractNoVO: // Here replace with your model type, like Task{}
						*(dest.(*[]*model.ContractNoVO)) = []*model.ContractNoVO{
							{ContractNo: "a"},
							{ContractNo: "b"},
						}
					}
					return db
				}).Build()
				mockey.Mock(i18nfmt.New).Return(fmt.Errorf("your error")).Build()
			},
			want:    []string{"a", "b"},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				got, err := v.collectContractNoResult(
					tt.args.ctx,
					tt.args.query,
				)

				// Assert
				convey.So(got, convey.ShouldResemble, tt.want)
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

func Test_contractMetaDaoImpl_FindHistoryContractByNo_BitsUTGen(t *testing.T) {
	// Setup
	dao := &contractMetaDaoImpl{}
	ctx := context.Background()
	contractNo := "test-contract-123"

	mockey.PatchConvey("Test_contractMetaDaoImpl_FindHistoryContractByNo", t, func() {
		mockDB := &gorm.DB{}

		mockey.PatchConvey("Success: should find a contract record successfully", func() {
			// 场景描述：
			// 模拟数据库查询成功，找到匹配的合同记录。
			// 构造数据：
			// - contractNo: "test-contract-123"
			// - tx: nil (测试使用全局_dbClient的路径)
			// - 期望返回的合同对象
			// 逻辑链路：
			// 1. _dbClient.WithContext 返回一个有效的 *gorm.DB 实例，模拟 initDB 的行为。
			// 2. gorm的Table, Where, Where 链式调用成功，均返回同一个 *gorm.DB 实例。
			// 3. gorm的First 方法成功找到记录，填充传入的结构体，并返回一个 error 为 nil 的 *gorm.DB。
			// 4. 函数中的错误检查均通过。
			// 5. 函数最终返回找到的合同对象和 nil 错误。

			// Arrange
			expectedContract := &model.ContractMetaDB{
				ContractNo:   contractNo,
				ContractName: "Sample Contract",
				BaseDB:       model.BaseDB{Id: 1},
			}
			_dbClient = &gorm.DB{} // 初始化包内变量
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractMetaDB); ok {
					*ret = *expectedContract
				}
				db.Error = nil
				return db
			}).Build()

			// Act
			result, err := dao.FindHistoryContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedContract)
		})

		mockey.PatchConvey("Success: should find a contract record successfully using a transaction", func() {
			// 场景描述：
			// 模拟在一个已存在的数据库事务中查询并成功找到记录。
			// 构造数据：
			// - contractNo: "test-contract-123"
			// - tx: 提供一个非nil的 *gorm.DB 实例
			// 逻辑链路：
			// 1. initDB 直接返回传入的 tx 实例。
			// 2. 后续的 Table, Where, First 调用在 tx 上执行，并成功返回记录。
			// 3. 函数最终返回找到的合同对象和 nil 错误。

			// Arrange
			mockTx := &gorm.DB{}
			expectedContract := &model.ContractMetaDB{
				ContractNo:   contractNo,
				ContractName: "Sample Contract in TX",
			}
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractMetaDB); ok {
					*ret = *expectedContract
				}
				db.Error = nil
				return db
			}).Build()

			// Act
			result, err := dao.FindHistoryContractByNo(ctx, mockTx, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedContract)
		})

		mockey.PatchConvey("Not Found: should return nil when record does not exist", func() {
			// 场景描述：
			// 模拟数据库查询，但未找到匹配的记录。
			// 逻辑链路：
			// 1. initDB, Table, Where 调用成功。
			// 2. First 方法返回 gorm.ErrRecordNotFound 错误。
			// 3. 函数内的 errors.Is(err, gorm.ErrRecordNotFound) 条件判断为 true。
			// 4. 函数按逻辑返回 (nil, nil)，表示未找到但并非执行错误。

			// Arrange
			_dbClient = &gorm.DB{}
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				db.Error = gorm.ErrRecordNotFound
				return db
			}).Build()

			// Act
			result, err := dao.FindHistoryContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: should return an error when a generic database error occurs", func() {
			// 场景描述：
			// 模拟数据库查询时发生了一个通用错误（非 RecordNotFound）。
			// 逻辑链路：
			// 1. First 方法返回一个通用 error。
			// 2. errors.Is(err, gorm.ErrRecordNotFound) 为 false。
			// 3. ignoreErr(err) 返回该通用 error，因为不是可忽略的错误类型。
			// 4. else if 条件为 true，调用 i18nfmt.New 生成一个新的包装错误。
			// 5. 函数返回 nil 结果和一个包装后的错误。

			// Arrange
			dbError := errors.New("something went wrong")
			i18nError := errors.New("FindHistoryContractByNoFail")
			_dbClient = &gorm.DB{}
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				db.Error = dbError
				return db
			}).Build()
			mockey.Mock(i18nfmt.New).Return(i18nError).Build()

			// Act
			result, err := dao.FindHistoryContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "FindHistoryContractByNoFail")
		})

		mockey.PatchConvey("Ignored Error: should return success when RASP error is ignored in non-online env", func() {
			// 场景描述：
			// 模拟数据库返回一个 RASP 错误，并且当前环境为非线上环境，该错误应被忽略。
			// 逻辑链路：
			// 1. First 方法返回一个包含 "API blocked by RASP" 的 error。
			// 2. env.IsOnline() 被mock为返回 false。
			// 3. ignoreErr(err) 内部的 ignoreRaspErr 识别并忽略该错误，因此 ignoreErr 返回 nil。
			// 4. else if 条件为 false。
			// 5. 函数继续执行，返回一个指向零值 model.ContractMetaDB 的指针和 nil 错误。

			// Arrange
			raspError := errors.New("API blocked by RASP")
			_dbClient = &gorm.DB{}
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				db.Error = raspError
				return db
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()

			// Act
			result, err := dao.FindHistoryContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, &model.ContractMetaDB{})
		})
	})
}

func Test_contractMetaDaoImpl_UpdateFieldsByNo_BitsUTGen(t *testing.T) {
	// 准备公共测试数据
	ctx := context.Background()
	p := &contractMetaDaoImpl{}
	contractNo := "test-contract-123"
	updates := map[string]interface{}{"status": 1}

	mockey.PatchConvey("Test contractMetaDaoImpl.UpdateFieldsByNo", t, func() {
		// mockDB用于链式调用中的中间返回对象
		mockDB := &gorm.DB{}

		mockey.PatchConvey("成功场景: 传入有效事务 tx", func() {
			// 场景描述：
			// 提供了有效的事务对象 tx，GORM 更新操作成功。
			// 构造数据：
			// tx 是一个非空的 *gorm.DB 对象。
			// 逻辑链路：
			// 1. initDB(ctx, tx) 直接返回传入的 tx 对象。
			// 2. 在 tx 对象上依次调用 Table, Where, Updates 方法。
			// 3. Updates 方法返回的 *gorm.DB 对象的 Error 字段为 nil。
			// 4. ignoreErr(nil) 返回 nil。
			// 5. 函数最终返回 nil，表示更新成功。

			// 准备
			tx := &gorm.DB{}
			dbResult := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, tx, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 未传入事务 tx，使用全局 DBClient", func() {
			// 场景描述：
			// 未提供事务对象 tx，使用全局的 _dbClient，GORM 更新操作成功。
			// 构造数据：
			// tx 参数为 nil。
			// 逻辑链路：
			// 1. initDB(ctx, nil) 调用 _dbClient.WithContext(ctx)。
			// 2. Mock _dbClient.WithContext(ctx) 返回一个 mock DB 对象。
			// 3. 在该 mock DB 对象上依次调用 Table, Where, Updates 方法。
			// 4. Updates 方法返回的 *gorm.DB 对象的 Error 字段为 nil。
			// 5. ignoreErr(nil) 返回 nil。
			// 6. 函数最终返回 nil，表示更新成功。

			// 准备
			_dbClient = &gorm.DB{}
			dbResult := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, nil, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: GORM 返回通用错误", func() {
			// 场景描述：
			// GORM 更新操作返回一个通用的数据库错误。
			// 构造数据：
			// tx 参数为 nil。GORM 链式调用的最终 Error 字段为一个非特殊的 error。
			// 逻辑链路：
			// 1. GORM 链式调用最终返回一个包含通用错误的 *gorm.DB 对象。
			// 2. ignoreErr 接收到此错误，由于不是特殊错误，直接返回该错误。
			// 3. if ignoreErr(err) != nil 条件成立。
			// 4. 调用 logs.CtxError 记录日志。
			// 5. 调用 i18nfmt.New 生成指定的业务错误。
			// 6. 函数返回该业务错误。

			// 准备
			_dbClient = &gorm.DB{}
			dbError := errors.New("database connection failed")
			dbResult := &gorm.DB{Error: dbError}
			finalError := errors.New("UpdateFieldsByNoFail")

			mockey.Mock(env.IsOnline).Return(false).Build() // ignoreErr 内部会调用
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock(i18nfmt.New).Return(finalError).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, nil, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByNoFail")
		})

		mockey.PatchConvey("成功场景: GORM 返回 ErrRecordNotFound 错误", func() {
			// 场景描述：
			// GORM 更新操作返回 gorm.ErrRecordNotFound，该错误被忽略，视为成功。
			// 构造数据：
			// tx 参数为 nil。GORM 链式调用的最终 Error 字段为 gorm.ErrRecordNotFound。
			// 逻辑链路：
			// 1. GORM 链式调用最终返回一个包含 gorm.ErrRecordNotFound 错误的 *gorm.DB 对象。
			// 2. ignoreErr 接收到此错误，并返回 nil。
			// 3. if ignoreErr(err) != nil 条件不成立。
			// 4. 函数最终返回 nil。

			// 准备
			_dbClient = &gorm.DB{}
			dbResult := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, nil, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: GORM 返回 RASP 错误且环境非线上", func() {
			// 场景描述：
			// GORM 更新操作返回 RASP 错误，但在非线上环境中，该错误被忽略，视为成功。
			// 构造数据：
			// tx 参数为 nil。GORM 错误包含 "API blocked by RASP"。env.IsOnline() 返回 false。
			// 逻辑链路：
			// 1. Mock env.IsOnline() 返回 false。
			// 2. GORM 链式调用返回一个 RASP 错误。
			// 3. ignoreErr 调用 ignoreRaspErr，检测到 RASP 错误和非线上环境，返回 nil。
			// 4. if ignoreErr(err) != nil 条件不成立。
			// 5. 函数最终返回 nil。

			// 准备
			_dbClient = &gorm.DB{}
			raspError := errors.New("API blocked by RASP")
			dbResult := &gorm.DB{Error: raspError}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, nil, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: GORM 返回 RASP 错误且环境为线上", func() {
			// 场景描述：
			// GORM 更新操作返回 RASP 错误，在线上环境中，该错误不被忽略，视为失败。
			// 构造数据：
			// tx 参数为 nil。GORM 错误包含 "API blocked by RASP"。env.IsOnline() 返回 true。
			// 逻辑链路：
			// 1. Mock env.IsOnline() 返回 true。
			// 2. GORM 链式调用返回一个 RASP 错误。
			// 3. ignoreErr 调用 ignoreRaspErr，检测到 RASP 错误和线上环境，返回原始错误。
			// 4. if ignoreErr(err) != nil 条件成立。
			// 5. 函数返回 i18nfmt.New 生成的业务错误。

			// 准备
			_dbClient = &gorm.DB{}
			raspError := errors.New("API blocked by RASP")
			dbResult := &gorm.DB{Error: raspError}
			finalError := errors.New("UpdateFieldsByNoFail")

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(dbResult).Build()
			mockey.Mock(i18nfmt.New).Return(finalError).Build()
			mockey.Mock((*gorm.DB).Model).Return(dbResult).Build()

			// 调用
			err := p.UpdateFieldsByNo(ctx, nil, contractNo, updates)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByNoFail")
		})
	})
}

func Test_contractMetaDaoImpl_FindFromContractByNo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test contractMetaDaoImpl.FindFromContractByNo", t, func() {
		// Arrange: Common setup for all test cases
		dao := &contractMetaDaoImpl{}
		ctx := context.Background()
		contractNo := "test-contract-no-123"
		mockDB := &gorm.DB{}

		mockey.PatchConvey("Success: contract meta found", func() {
			// 场景描述：
			// 数据库查询成功，找到匹配的合同元数据。
			// 构造数据：
			// 构造一个预期的 model.ContractMetaDB 实例作为查询结果。
			// 逻辑链路：
			// 1. mock initDB 返回一个 *gorm.DB 实例。
			// 2. mock gorm 的 Table, Where 链式调用，都返回同一个 *gorm.DB 实例。
			// 3. mock gorm 的 First 方法，模拟查询成功，通过 "To" 函数填充结果到传入的指针，并返回一个 Error 为 nil 的 *gorm.DB。
			// 4. 函数执行成功，返回找到的数据和 nil error。

			// Arrange
			expectedResult := &model.ContractMetaDB{
				ContractNo:   contractNo,
				ContractName: "Test Contract",
			}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractMetaDB); ok {
					*ret = *expectedResult
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			result, err := dao.FindFromContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("Success: record not found", func() {
			// 场景描述：
			// 数据库查询未找到匹配的记录。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. mock initDB, Table, Where 链式调用。
			// 2. mock gorm 的 First 方法返回 gorm.ErrRecordNotFound 错误。
			// 3. 函数内部逻辑捕获 gorm.ErrRecordNotFound，并将其视作正常情况，返回 (nil, nil)。

			// Arrange
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			result, err := dao.FindFromContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: general database error", func() {
			// 场景描述：
			// 数据库查询时发生了一个通用错误（非 RecordNotFound）。
			// 构造数据：
			// 构造一个通用的 error 实例。
			// 逻辑链路：
			// 1. mock initDB, Table, Where 链式调用。
			// 2. mock gorm 的 First 方法返回一个通用 error。
			// 3. mock env.IsOnline 返回 false，以确保 ignoreErr 函数会处理此错误。
			// 4. 函数内部的 ignoreErr(err) 返回非 nil，进入错误处理分支。
			// 5. mock multienv.I18nFormat 返回预期的错误信息。
			// 6. 函数最终返回 nil 数据和包装后的错误。

			// Arrange
			dbErr := errors.New("some unexpected database error")
			expectedErrMsg := "FindFromContractByNoFail"
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(multienv.I18nFormat).Return(expectedErrMsg).Build()

			// Act
			result, err := dao.FindFromContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
		})

		mockey.PatchConvey("Success: RASP error is ignored in non-online env", func() {
			// 场景描述：
			// 数据库查询返回一个 RASP 错误，但在非线上环境中该错误被忽略。
			// 构造数据：
			// 构造一个包含 "API blocked by RASP" 的 error 实例。
			// 逻辑链路：
			// 1. mock initDB, Table, Where 链式调用。
			// 2. mock gorm 的 First 方法返回 RASP 错误。
			// 3. mock env.IsOnline 返回 false，这是触发 RASP 错误忽略逻辑的关键。
			// 4. mock logs.CtxError 因为 RASP 错误会被日志记录。
			// 5. 函数内部的 ignoreErr(err) 返回 nil，错误被忽略。
			// 6. 函数继续执行，返回一个零值的 *model.ContractMetaDB 和 nil error。

			// Arrange
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			// Act
			result, err := dao.FindFromContractByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, &model.ContractMetaDB{})
		})
	})
}

func Test_contractMetaDaoImpl_UpdateIdentifierByMap(t *testing.T) {
	t.Run("case 入参为0，跳过执行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 执行成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录未找到", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录命中RASP", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("API blocked by RASP")}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 更新失败，记录命中RASP，线上环境", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(true).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("API blocked by RASP")}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "UpdateBizByMapFail")
		})
	})
	t.Run("case 更新失败，未命中跳过逻辑", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			mockey.Mock(env.IsOnline).Return(false).Build()

			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("UpdateFail")}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			err := v.UpdateIdentifierByMap(context.Background(), &gorm.DB{}, 0, 100, map[string]interface{}{"": nil})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "UpdateBizByMapFail")
		})
	})
}

func Test_contractMetaDaoImpl_ListSupplyContract(t *testing.T) {
	t.Run("case 执行成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				switch dest.(type) {
				case *model.ContractMetaDBList: // Here replace with your model type, like Task{}
					*(dest.(*model.ContractMetaDBList)) = model.ContractMetaDBList{{}, {}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			list, err := v.ListSupplyContract(context.Background(), &gorm.DB{}, "")

			// Assert
			convey.So(len(list), convey.ShouldEqual, 2)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_contractMetaDaoImpl_ResetContractNo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_contractMetaDaoImpl_ResetContractNo", t, func() {
		// 构造通用测试数据
		ctx := context.Background()
		p := &contractMetaDaoImpl{}
		oldNo := "OLD-NO-123"
		newNo := "NEW-NO-456"
		contractID := "contract-id-789"
		checkCode := "check-code-abc"
		requestID := "request-id-def"
		status := 1
		mockDB := &gorm.DB{}

		// Mock GORM链式调用的前置部分
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()

		convey.Convey("成功更新", func() {
			// 场景描述：
			// 数据库更新操作成功执行，没有任何错误。
			// 构造数据：
			// 无特殊构造，使用通用测试数据。
			// 逻辑链路：
			// 1. 调用initDB返回一个mock的gorm.DB实例。
			// 2. GORM链式调用 (Table, Where, Updates) 被执行。
			// 3. Updates方法返回一个Error字段为nil的gorm.DB实例。
			// 4. ignoreErr(nil)返回nil。
			// 5. 函数最终返回nil，表示成功。

			// Mock最终的Updates调用
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// 调用目标函数
			err := p.ResetContractNo(ctx, nil, oldNo, newNo, contractID, checkCode, requestID, status)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("数据库更新失败，返回通用错误", func() {
			// 场景描述：
			// 数据库更新操作失败，并返回一个通用的、不可忽略的错误。
			// 构造数据：
			// Updates操作返回一个自定义的error。
			// 逻辑链路：
			// 1. 调用initDB和GORM链。
			// 2. Updates方法返回一个带有非nil Error的gorm.DB实例。
			// 3. ignoreErr函数被调用，但由于错误类型不是可忽略的，因此原样返回错误。
			// 4. logs.CtxError被调用以记录错误。
			// 5. i18nfmt.New被调用以生成一个对用户友好的错误信息。
			// 6. 函数返回i18nfmt.New生成的错误。

			// Mock Updates返回错误
			dbError := errors.New("some database error")
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbError}).Build()
			// Mock env.IsOnline以确保ignoreRaspErr逻辑可预测
			mockey.Mock(env.IsOnline).Return(false).Build()
			// Mock日志和国际化错误生成
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
			i18nError := errors.New("ResetContractNoFail")
			mockey.Mock(i18nfmt.New).Return(i18nError).Build()

			// 调用目标函数
			err := p.ResetContractNo(ctx, nil, oldNo, newNo, contractID, checkCode, requestID, status)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ResetContractNoFail")
		})

		convey.Convey("数据库更新因记录未找到而失败，但该错误被忽略", func() {
			// 场景描述：
			// 数据库更新操作因目标记录不存在而失败，返回gorm.ErrRecordNotFound。
			// 根据代码逻辑，这个特定的错误应该被忽略。
			// 构造数据：
			// Updates操作返回gorm.ErrRecordNotFound。
			// 逻辑链路：
			// 1. 调用initDB和GORM链。
			// 2. Updates方法返回一个Error为gorm.ErrRecordNotFound的gorm.DB实例。
			// 3. ignoreErr函数识别出此错误并返回nil。
			// 4. 函数最终返回nil，表现为操作成功。

			// Mock Updates返回ErrRecordNotFound
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// 调用目标函数
			err := p.ResetContractNo(ctx, nil, oldNo, newNo, contractID, checkCode, requestID, status)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("数据库更新因RASP错误在非线上环境失败，但该错误被忽略", func() {
			// 场景描述：
			// 数据库更新操作被RASP阻止，但在非线上环境中，此错误被配置为可忽略。
			// 构造数据：
			// Updates操作返回包含"API blocked by RASP"的错误，同时env.IsOnline返回false。
			// 逻辑链路：
			// 1. 调用initDB和GORM链。
			// 2. Updates方法返回一个RASP错误。
			// 3. ignoreErr函数内部的ignoreRaspErr检测到RASP错误和非线上环境，返回nil。
			// 4. 函数最终返回nil。

			// Mock Updates返回RASP错误
			raspError := errors.New("API blocked by RASP")
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			// Mock为非线上环境
			mockey.Mock(env.IsOnline).Return(false).Build()
			// ignoreRaspErr会打印一条日志，这里也mock掉
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()

			// 调用目标函数
			err := p.ResetContractNo(ctx, nil, oldNo, newNo, contractID, checkCode, requestID, status)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("数据库更新因RASP错误在线上环境失败，该错误不被忽略", func() {
			// 场景描述：
			// 数据库更新操作被RASP阻止，在线上环境中，此错误被视为真实失败。
			// 构造数据：
			// Updates操作返回包含"API blocked by RASP"的错误，同时env.IsOnline返回true。
			// 逻辑链路：
			// 1. 调用initDB和GORM链。
			// 2. Updates方法返回一个RASP错误。
			// 3. ignoreErr函数内部的ignoreRaspErr检测到线上环境，不忽略该错误。
			// 4. 错误被传播，日志被记录，并返回一个用户友好的错误信息。

			// Mock Updates返回RASP错误
			raspError := errors.New("API blocked by RASP")
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			// Mock为线上环境
			mockey.Mock(env.IsOnline).Return(true).Build()
			// Mock日志和国际化错误生成
			mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
			i18nError := errors.New("ResetContractNoFail")
			mockey.Mock(i18nfmt.New).Return(i18nError).Build()

			// 调用目标函数
			err := p.ResetContractNo(ctx, nil, oldNo, newNo, contractID, checkCode, requestID, status)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ResetContractNoFail")
		})
	})
}

func Test_volcContractMetaDaoImpl_UpdateCooperationStatus(t *testing.T) {
	ctx := context.Background()
	contractNo := "testContractNo"
	status := 1

	mockey.PatchConvey("Test UpdateCooperationStatus", t, func() {

		mockey.PatchConvey("Test db.Updates failed", func() {
			mockDB := &gorm.DB{Error: fmt.Errorf("update failed")}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			err := (&contractMetaDaoImpl{}).UpdateCooperationStatus(ctx, mockDB, contractNo, status, status)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("Test db.Updates success", func() {
			mockDB := &gorm.DB{Error: nil}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			err := (&contractMetaDaoImpl{}).UpdateCooperationStatus(ctx, mockDB, contractNo, status, status)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test ignoreErr returns error", func() {
			mockDB := &gorm.DB{Error: fmt.Errorf("update failed")}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock(ignoreErr).Return(fmt.Errorf("ignoreErr error")).Build()
			err := (&contractMetaDaoImpl{}).UpdateCooperationStatus(ctx, mockDB, contractNo, status, status)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("Test ignoreErr returns nil", func() {
			mockDB := &gorm.DB{Error: fmt.Errorf("update failed")}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()
			err := (&contractMetaDaoImpl{}).UpdateCooperationStatus(ctx, mockDB, contractNo, status, status)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ListNoReverseFinalNoExpiredContract(t *testing.T) {
	ctx := context.Background()
	accountID := "12345"
	limit := 10
	offset := 0

	mockey.PatchConvey("Test ListNoReverseFinalNoExpiredContract success", t, func() {
		// Mock the initDB function to return a mock DB instance
		mockDB := &gorm.DB{}
		mockey.Mock(initDB).Return(mockDB).Build()

		// Mock the DB operations to return a list of contracts
		expectedList := model.ContractMetaDBList{
			&model.ContractMetaDB{ContractNo: "C001"},
			&model.ContractMetaDB{ContractNo: "C002"},
		}
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Limit")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Offset")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Find")).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
			type ExampleModel struct{}
			switch dest.(type) {
			case *ExampleModel: // Here replace with your model type, like Task{}
				*(dest.(*ExampleModel)) = ExampleModel{}
			case *model.ContractMetaDBList:
				*(dest.(*model.ContractMetaDBList)) = expectedList
			}
			return &gorm.DB{}
		}).Build()

		actualList, err := (&contractMetaDaoImpl{}).ListNoReverseFinalNoExpiredContract(ctx, mockDB, accountID, limit, offset)
		convey.So(actualList, convey.ShouldResemble, expectedList)
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test ListNoReverseFinalNoExpiredContract with DB error", t, func() {
		// Mock the initDB function to return a mock DB instance
		mockDB := &gorm.DB{}
		mockey.Mock(initDB).Return(mockDB).Build()

		// Mock the DB operations to return an error
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Limit")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Offset")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Find")).Return(&gorm.DB{Error: fmt.Errorf("DB error")}).Build()

		actualList, err := (&contractMetaDaoImpl{}).ListNoReverseFinalNoExpiredContract(ctx, mockDB, accountID, limit, offset)
		convey.So(actualList, convey.ShouldBeNil)
		convey.So(err, convey.ShouldNotBeNil)
	})

	mockey.PatchConvey("Test ListNoReverseFinalNoExpiredContract with empty result", t, func() {
		// Mock the initDB function to return a mock DB instance
		mockDB := &gorm.DB{}
		mockey.Mock(initDB).Return(mockDB).Build()

		// Mock the DB operations to return an empty list
		expectedList := model.ContractMetaDBList{}
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Limit")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Offset")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Find")).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
			type ExampleModel struct{}
			switch dest.(type) {
			case *ExampleModel: // Here replace with your model type, like Task{}
				*(dest.(*ExampleModel)) = ExampleModel{}
			case *model.ContractMetaDBList:
				*(dest.(*model.ContractMetaDBList)) = expectedList
			}
			return &gorm.DB{}
		}).Build()

		actualList, err := (&contractMetaDaoImpl{}).ListNoReverseFinalNoExpiredContract(ctx, mockDB, accountID, limit, offset)
		convey.So(actualList, convey.ShouldResemble, expectedList)
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test ListNoReverseFinalNoExpiredContract with invalid accountID", t, func() {
		// Mock the initDB function to return a mock DB instance
		mockDB := &gorm.DB{}
		mockey.Mock(initDB).Return(mockDB).Build()

		// Mock the DB operations to return an error due to invalid accountID
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Limit")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Offset")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Find")).Return(&gorm.DB{Error: fmt.Errorf("invalid accountID")}).Build()

		actualList, err := (&contractMetaDaoImpl{}).ListNoReverseFinalNoExpiredContract(ctx, mockDB, "invalid", limit, offset)
		convey.So(actualList, convey.ShouldBeNil)
		convey.So(err, convey.ShouldNotBeNil)
	})

	mockey.PatchConvey("Test ListNoReverseFinalNoExpiredContract with context cancellation", t, func() {
		// Create a context that is already canceled
		canceledCtx, cancel := context.WithCancel(ctx)
		cancel()

		// Mock the initDB function to return a mock DB instance
		mockDB := &gorm.DB{}
		mockey.Mock(initDB).Return(mockDB).Build()

		// Mock the DB operations to return an error due to context cancellation
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Limit")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Offset")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Find")).Return(&gorm.DB{Error: canceledCtx.Err()}).Build()

		actualList, err := (&contractMetaDaoImpl{}).ListNoReverseFinalNoExpiredContract(canceledCtx, mockDB, accountID, limit, offset)
		convey.So(actualList, convey.ShouldBeNil)
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func Test_contractMetaDaoImpl_GetAccessibleCoopNo(t *testing.T) {
	t.Run("case 合同类型、收支类型 批量查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				CategoryNo: "1033,101",
				InOutType:  "IN,OUT,NO_IN_NO_OUT",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case 合同类型、收支类型 单个查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				CategoryNo: "1033",
				InOutType:  "IN",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case 合同类型、收支类型 批量查询,边缘测试（入参为空）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				CategoryNo: "",
				InOutType:  "",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case 合同类型、收支类型 批量查询,边缘测试（入参为 A,）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				CategoryNo: "1033,",
				InOutType:  "IN,",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})

	t.Run("case 合同号 模糊查询 PCT", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				ContractNo: "PCTXXXX",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
	t.Run("case 合同号 模糊查询 CT", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock(larkc.GetEmployeeByMail).Return([]*peopleclient.Employee{{ID: 2861866}}, nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			v.GetAccessibleCoopNo(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				ContractNo: "CTXXXX",
			})

			// Assert
			convey.So("your code", convey.ShouldEqual, "your code")
		})
	})
}

func Test_contractMetaDaoImpl_buildQuery(t *testing.T) {
	t.Run("case 合同类型、收支类型 批量查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,101",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["category_no in (?)"], convey.ShouldResemble, []string{"1033", "101"})
			convey.So(whereArg["in_out_type in (?)"], convey.ShouldResemble, []string{"IN", "OUT", "NO_IN_NO_OUT"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 合同类型、收支类型 单个查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033",
				InOutType:             "IN",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["category_no = ?"], convey.ShouldResemble, []string{"1033"})
			convey.So(whereArg["in_out_type = ?"], convey.ShouldResemble, []string{"IN"})
			convey.So(db, convey.ShouldNotBeNil)
		})
	})
	t.Run("case 合同类型、收支类型 批量查询,边缘测试（入参为空）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "",
				InOutType:             "",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["category_no = ?"], convey.ShouldBeNil)
			convey.So(whereArg["in_out_type = ?"], convey.ShouldBeNil)
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 合同类型、收支类型 批量查询,边缘测试（入参为 A,）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,",
				InOutType:             "IN,OUT,",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["category_no = ?"], convey.ShouldResemble, []string{"1033"})
			convey.So(whereArg["in_out_type in (?)"], convey.ShouldResemble, []string{"IN", "OUT"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})

	t.Run("case 补充类型 批量查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["supply_scene in (?)"], convey.ShouldResemble, []string{"20", "30"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 补充类型 单个查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033",
				SupplyScene:           "20",
				InOutType:             "IN",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["supply_scene = ?"], convey.ShouldResemble, []string{"20"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 补充类型 批量查询,边缘测试（入参为空）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "",
				SupplyScene:           "",
				InOutType:             "",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["supply_scene = ?"], convey.ShouldBeNil)
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 补充类型 批量查询,边缘测试（入参为 A,）", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,",
				SupplyScene:           "20,",
				InOutType:             "IN,OUT,",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			convey.So(whereArg["supply_scene = ?"], convey.ShouldResemble, []string{"20"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})

	t.Run("case 火山补充合同号 模糊查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				VolcContractNo:        "CTxxxxx",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["volc_contract_no like ?"], convey.ShouldResemble, []string{"CTxxxxx%"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})

	t.Run("case 合同号 模糊查询 CT", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				ContractNo:            "CTXXXXX",
				VolcContractNo:        "CTxxxxx",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["contract_no like ?"], convey.ShouldResemble, []string{"CTXXXXX%"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 合同号 模糊查询 PCT", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}
			var v1 = _const.SourceType(0)
			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            v1,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				ContractNo:            "PCTXXXXX",
				VolcContractNo:        "CTxxxxx",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             true,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["pre_contract_no like ?"], convey.ShouldResemble, []string{"PCTXXXXX%"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("非管理员1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            _const.SourceTypeOpen,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				ContractNo:            "PCTXXXXX",
				VolcContractNo:        "CTxxxxx",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             false,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["pre_contract_no like ?"], convey.ShouldResemble, []string{"PCTXXXXX%"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("非管理员2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			whereArg := map[string][]string{}
			mockey.Mock((*gorm.DB).Where).To(func(query interface{}, args ...interface{}) *gorm.DB {
				values := []string{}
				key := query.(string)
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				whereArg[key] = values
				return &gorm.DB{} // Add your code
			}).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			var v2 int = 0
			var v3 int = 0
			var v4 int = 0
			var v5 int = 0
			v6, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v7, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v8, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v9, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v10, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v11, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v12, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v13, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v14, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			v15, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			db := v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				SourceType:            _const.SourceTypeOpen,
				CategoryNo:            "1033,101",
				SupplyScene:           "20,30",
				ContractNo:            "PCTXXXXX",
				VolcContractNo:        "CTxxxxx",
				InOutType:             "IN,OUT,NO_IN_NO_OUT",
				CooperationStatus:     &v2,
				CooperationStatusList: []int{0},
				ArchivedStatus:        &v3,
				ActiveStatus:          &v4,
				ActiveStatusList:      []int{0},
				Status:                &v5,
				BeginTime:             v6,
				EndTime:               v7,
				EndTimeBegin:          v8,
				EndTimeEnd:            v9,
				CreatedTimeBegin:      v10,
				CreatedTimeEnd:        v11,
				SubmitTimeBegin:       v12,
				SubmitTimeEnd:         v13,
				FileTimeBegin:         v14,
				FileTimeEnd:           v15,
				IsManager:             false,
			})

			// Assert
			t.Log(whereArg)
			convey.So(whereArg["pre_contract_no like ?"], convey.ShouldResemble, []string{"PCTXXXXX%"})
			convey.So(db, convey.ShouldNotEqual, nil)
		})
	})
}

func Test_contractMetaDaoImpl_ListByReq_BitsUTGen(t *testing.T) {
	// Common setup for all test cases
	p := &contractMetaDaoImpl{}
	ctx := context.Background()
	mockDb := &gorm.DB{}

	mockey.PatchConvey("Test contractMetaDaoImpl.ListByReq", t, func() {

		mockey.PatchConvey("Success case: need total and pagination", func() {
			// 场景描述：
			// 构造数据：构造一个需要查询总数和分页的请求。
			// 逻辑链路：
			// 1. Mock `buildQuery` 返回一个 mock gorm.DB 实例。
			// 2. Mock `Count` 方法成功，并返回一个总数值（例如 20）。
			// 3. Mock `Limit` 和 `Offset` 方法成功。
			// 4. Mock `Find` 方法成功，并返回一个包含两条记录的列表。
			// 5. 最终函数应无错误地返回列表和总数。
			req := &model.ContractMetaReq{
				NeedTotal: true,
				Limit:     10,
				Offset:    0,
			}

			// Mock the chain of GORM calls
			mockey.Mock((*contractMetaDaoImpl).buildQuery).Return(mockDb).Build()
			mockey.Mock((*gorm.DB).Count).To(func(db *gorm.DB, count *int64) *gorm.DB {
				*count = 20
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDb).Build()
			mockey.Mock((*gorm.DB).Offset).Return(mockDb).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				list := dest.(*model.ContractMetaDBList)
				// Assuming ContractMetaDB struct exists in model package, we can create instances.
				// Since we don't have the definition, we'll create empty instances which is sufficient for this test.
				*list = model.ContractMetaDBList{{}, {}}
				return &gorm.DB{Error: nil}
			}).Build()
			// Mock `ignoreErr`'s dependency, although not strictly needed for success case.
			mockey.Mock(env.IsOnline).Return(false).Build()

			// Act
			list, total, err := p.ListByReq(ctx, nil, req)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 20)
			convey.So(len(list), convey.ShouldEqual, 2)
		})

		t.Run("case #2", func(t *testing.T) {})
	})
}

func TestContractMetaDaoImpl_Update(t *testing.T) {
	t.Run("UpdateWithNilEntity", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] entityTest == nil
			var entityTest *model.ContractMetaDB = nil
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// 运行被测函数
			err := receiver.Update(ctxTest, txTest, entityTest)
			// 当传入的entity为nil时，业务函数会进入if判断，调用i18nfmt.New返回错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当传入的entity为nil时，业务函数会返回该错误信息
			convey.So(err.Error(), convey.ShouldEqual, "updateContractMetaFail, entity is nil")
		})
	})

	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Omit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var entityTest *model.ContractMetaDB = &model.ContractMetaDB{}
			// 运行被测函数
			err := receiver.Update(ctxTest, txTest, entityTest)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_UpdateByMap(t *testing.T) {
	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var idTest int64 = 1001
			var updatesTest map[string]interface{} = map[string]interface{}{"field1": "value1"}
			// 运行被测函数
			err := receiver.UpdateByMap(ctxTest, txTest, idTest, updatesTest)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_DeleteByNo(t *testing.T) {
	t.Run("DeleteByNoWithVersionGreaterThanOneAndNoError", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			// 构造函数入参
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var contractNoTest string = "CN2024001"
			// [目标分支] versionTest > 1
			var versionTest int = 2
			// 运行被测函数
			err := receiver.DeleteByNo(ctxTest, txTest, contractNoTest, versionTest)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_UpdateActiveStatusById(t *testing.T) {
	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*contractMetaDaoImpl).addBizUpdateCondition).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var activeStatusTest int = 1
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var bizSceneTest int = 1
			var contractIdTest int64 = 100001
			// 运行被测函数
			err := receiver.UpdateActiveStatusById(ctxTest, txTest, bizSceneTest, contractIdTest, activeStatusTest)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_UpdateAttachmentFields(t *testing.T) {
	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var entityTest *model.ContractMetaDB = &model.ContractMetaDB{
				ContractAttachment: "Contract_Attachment_2024.zip",
				ContractFile:       "Contract_2024.pdf",
			}
			// 运行被测函数
			err := receiver.UpdateAttachmentFields(ctxTest, txTest, entityTest)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_ListAbnormalArchivedContract(t *testing.T) {
	t.Run("LimitNotZeroAndIgnoreErrNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] limitTest != 0
			var limitTest int = 1
			var offsetTest int = 0
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1, err := receiver.ListAbnormalArchivedContract(ctxTest, txTest, limitTest, offsetTest)
			// 虽然进行了数据库查询的mock，但没有对查询结果进行赋值，因此返回的列表长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_List(t *testing.T) {
	t.Run("ListFunctionNormalExecution", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			// [目标分支] findTabSceneAccessibleContractListRet2Mock != true
			// [目标分支] findTabSceneAccessibleContractListRet3Mock == nil
			mockey.Mock((*contractMetaDaoImpl).findTabSceneAccessibleContractList).Return(nil, false, nil).Build()
			// [目标分支] findAccessibleCooperationNoListRet2Mock == nil
			mockey.Mock((*contractMetaDaoImpl).FindAccessibleCooperationNoList).Return(nil, nil).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*contractMetaDaoImpl).buildQuery).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] paramTest.IsManager == true && paramTest.NeedTotal == true && paramTest.Limit != 0 && paramTest.StartId == 0
			var paramTest *model.ContractMetaReq = &model.ContractMetaReq{
				StartId:   0,
				NeedLimit: true,
				IsManager: false,
				NeedTotal: true,
				Limit:     1,
				Offset:    10,
			}
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			got1, got2, err := receiver.List(ctxTest, txTest, paramTest)
			// Find方法被mock，没有向list中添加元素，所以got1的长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 虽然paramTest.NeedTotal为true，但Count方法被mock，没有对total赋值，所以total默认为0，got2作为total的int类型返回值也为0
			convey.So(got2, convey.ShouldEqual, 0)
			// 所有mock函数均未返回错误，且ignoreErr函数也返回nil，因此业务函数执行过程中不会出现错误，err应为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestContractMetaDaoImpl_UpdateAfterSubmit(t *testing.T) {
	// 测试ignoreErr函数返回错误的场景
	t.Run("IgnoreErrReturnError", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock != nil
			mockey.Mock(ignoreErr).Return(errors.New("test_error")).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("UpdateAfterSubmitFail")).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{
				Error: errors.New("test_error"),
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var contractNoTest string = "CT2024001"
			var ofacURLTest string = "https://ofac.example.com"
			var statusTest int = 1
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// 运行被测函数
			err := receiver.UpdateAfterSubmit(ctxTest, txTest, contractNoTest, ofacURLTest, statusTest)
			// 在测试中，mock的ignoreErr函数返回了错误，根据业务函数逻辑，当ignoreErr返回错误时，会返回一个新的错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当ignoreErr返回错误时，业务函数会调用i18nfmt.New返回一个错误，且错误信息为UpdateAfterSubmitFail
			convey.So(err.Error(), convey.ShouldEqual, "UpdateAfterSubmitFail")
		})
	})
	// 测试ignoreErr函数返回nil的场景
	t.Run("IgnoreErrReturnNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Updates, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var contractNoTest string = "CT2024001"
			var ofacURLTest string = "https://ofac.example.com"
			var statusTest int = 1
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.UpdateAfterSubmit(ctxTest, txTest, contractNoTest, ofacURLTest, statusTest)
			// 在测试用例中，mock的ignoreErr函数返回nil，不会进入错误处理分支，因此预期返回的错误为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_contractMetaDaoImpl_Create_ByteUTGen(t *testing.T) {
	// 测试传入entity为nil的场景
	t.Run("CreateWithNilEntity", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] entityTest == nil
			var entityTest *model.ContractMetaDB = nil
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.Create(ctxTest, txTest, entityTest)
			// 当传入的entity为nil时，业务函数会执行if entity == nil分支，返回一个错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当传入的entity为nil时，业务函数会返回i18nfmt.New(ctx, \"createContractMetaFail, entity is nil\")，由于i18nfmt.New被mock返回nil，这里根据业务函数逻辑推测错误信息为createContractMetaFail, entity is nil
			convey.So(err.Error(), convey.ShouldEqual, "createContractMetaFail, entity is nil")
		})
	})
	// 测试ignoreErr函数返回错误的场景
	t.Run("IgnoreErrReturnError", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Omit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock != nil
			mockey.Mock(ignoreErr).Return(fmt.Errorf("mock an error return")).Build()
			mockey.Mock(i18nfmt.New, mockey.OptUnsafe).Return(errors.New("createContractMetaFail")).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: errors.New("TEST_ERROR")}).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var entityTest *model.ContractMetaDB = &model.ContractMetaDB{
				TradePartyInfo: "ABC Trading Company",
				BizData:        "Sales data for Q1 2024",
			}
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			var ctxTest context.Context = context.Background()
			// 运行被测函数
			err := receiver.Create(ctxTest, txTest, entityTest)
			// 在测试中，ignoreErr函数被mock为返回错误，根据业务函数逻辑，当ignoreErr返回错误时，会返回一个新的错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当ignoreErr返回错误时，业务函数会返回i18nfmt.New(ctx, \"createContractMetaFail\")生成的错误，所以错误信息为createContractMetaFail
			convey.So(err.Error(), convey.ShouldEqual, "createContractMetaFail")
		})
	})
	// 测试创建合同元数据成功的场景
	t.Run("CreateContractMetaSuccess", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Omit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			// 构造函数入参
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var entityTest *model.ContractMetaDB = &model.ContractMetaDB{
				BizData:        "Sales data for Q1 2024",
				TradePartyInfo: "ABC Trading Company",
			}
			var receiver *contractMetaDaoImpl = &contractMetaDaoImpl{}
			// 运行被测函数
			err := receiver.Create(ctxTest, txTest, entityTest)
			// 通过mock函数，ignoreErr函数返回nil，不会触发错误返回逻辑，因此Create函数应正常执行并返回nil错误
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_contractMetaDaoImpl_UpdateFieldsByContractIds_BitsUTGen(t *testing.T) {
	t.Run("合同ID为空，直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造被测对象与参数
			dao := &contractMetaDaoImpl{}
			ctx := context.Background()
			contractIds := []uint64{}                   // 合同ID为空
			updates := map[string]interface{}{"k": "v"} // 更新字段非空

			// 调用
			err := dao.UpdateFieldsByContractIds(ctx, nil, contractIds, updates)

			// 断言错误信息包含指定文案
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByContractIdsFail")
		})
	})

	t.Run("更新字段为空，直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &contractMetaDaoImpl{}
			ctx := context.Background()
			contractIds := []uint64{1, 2}       // 合同ID非空
			updates := map[string]interface{}{} // 更新字段为空

			err := dao.UpdateFieldsByContractIds(ctx, nil, contractIds, updates)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByContractIdsFail")
		})
	})

	t.Run("数据库返回RecordNotFound错误被忽略，更新成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &contractMetaDaoImpl{}
			ctx := context.Background()
			contractIds := []uint64{10, 20}
			updates := map[string]interface{}{"field": "value"}

			// mock initDB与链式调用，最终Updates返回RecordNotFound
			mockey.MockUnsafe(initDB).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.UpdateFieldsByContractIds(ctx, nil, contractIds, updates)

			// ErrRecordNotFound被ignore，返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("离线环境RASP拦截错误被忽略，更新成功返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &contractMetaDaoImpl{}
			ctx := context.Background()
			contractIds := []uint64{100, 200}
			updates := map[string]interface{}{"ok": true}

			// mock initDB与链式调用，最终Updates返回包含RASP拦截的错误
			mockey.MockUnsafe(initDB).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(&gorm.DB{Error: errors.New("xxx API blocked by RASP yyy")}).Build()

			err := dao.UpdateFieldsByContractIds(ctx, nil, contractIds, updates)

			// 离线环境下包含RASP的错误被忽略，返回nil
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("数据库返回普通错误，返回国际化错误信息", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &contractMetaDaoImpl{}
			ctx := context.Background()
			contractIds := []uint64{7, 8}
			updates := map[string]interface{}{"f": "v"}

			// mock initDB与链式调用，最终Updates返回普通错误
			mockey.MockUnsafe(initDB).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(&gorm.DB{Error: errors.New("db fail")}).Build()

			err := dao.UpdateFieldsByContractIds(ctx, nil, contractIds, updates)

			// 普通错误不会被忽略，返回国际化错误信息
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateFieldsByContractIdsFail")
		})
	})
}

func Test_contractMetaDaoImpl_ListByContractNos_BitsUTGen(t *testing.T) {
	t.Run("错误返回：Find返回不忽略的错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备上下文与dao
			ctx := context.Background()
			dao := &contractMetaDaoImpl{}
			tx := &gorm.DB{}

			// 避免日志默认logger为空导致空指针，短函数使用MockUnsafe
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// 构建链式调用：Table -> Where -> Find
			tableDB := &gorm.DB{}
			whereDB := &gorm.DB{}

			mockey.MockUnsafe((*gorm.DB).Table).Return(tableDB).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(whereDB).Build()
			mockey.MockUnsafe((*gorm.DB).Find).Return(&gorm.DB{Error: errors.New("db error")}).Build()

			// 调用待测方法
			contractNos := []string{"NO1", "NO2"}
			list, err := dao.ListByContractNos(ctx, tx, contractNos)

			// 断言命中错误分支并返回国际化错误
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListByContractIdsFail")
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("成功返回：Find返回nil错误并返回列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备上下文与dao
			ctx := context.Background()
			dao := &contractMetaDaoImpl{}
			tx := &gorm.DB{}

			// 构建链式调用：Table -> Where -> Find
			tableDB := &gorm.DB{}
			whereDB := &gorm.DB{}

			mockey.MockUnsafe((*gorm.DB).Table).Return(tableDB).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(whereDB).Build()
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				// 将查询结果设置为非空切片，元素可以为nil以避免依赖具体结构
				if d, ok := dest.(*model.ContractMetaDBList); ok {
					arr := make(model.ContractMetaDBList, 2)
					*d = arr
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// 调用待测方法
			contractNos := []string{"NO_A"}
			list, err := dao.ListByContractNos(ctx, tx, contractNos)

			// 断言成功分支
			convey.So(err, convey.ShouldBeNil)
			convey.So(list, convey.ShouldNotBeNil)
			convey.So(len(list), convey.ShouldEqual, 2)
		})
	})
}

func Test_contractMetaDaoImpl_buildExtraFilterQuery(t *testing.T) {
	// setupMock 收集 Where/Having 的 query 与字符串参数，并让链式方法返回可复用的 db。
	setupMock := func() (whereArg map[string][]string, havingArg map[string][]string) {
		whereArg = map[string][]string{}
		havingArg = map[string][]string{}
		mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
		mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
		mockey.Mock((*gorm.DB).Select).Return(&gorm.DB{}).Build()
		mockey.Mock((*gorm.DB).Group).Return(&gorm.DB{}).Build()
		collect := func(store map[string][]string) func(query interface{}, args ...interface{}) *gorm.DB {
			return func(query interface{}, args ...interface{}) *gorm.DB {
				key, _ := query.(string)
				values := []string{}
				for _, arg := range args {
					if v, ok := arg.([]string); ok {
						values = append(values, v...)
					}
					if v, ok := arg.(string); ok {
						values = append(values, v)
					}
				}
				store[key] = append(store[key], values...)
				return &gorm.DB{}
			}
		}
		mockey.Mock((*gorm.DB).Where).To(collect(whereArg)).Build()
		mockey.Mock((*gorm.DB).Having).To(collect(havingArg)).Build()
		return whereArg, havingArg
	}

	t.Run("case 主表字段直查：主合同号/补充场景/签约形式/项目编号", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				MainContractNo: "CT-MAIN-1",
				SupplySource:   "SS-1,SS-2",
				SignatureType:  "ELECTRONIC",
				ProjectCode:    "PJ-1",
			})

			convey.So(whereArg["main_contract_no like ?"], convey.ShouldResemble, []string{"CT-MAIN-1%"})
			convey.So(whereArg["(FIND_IN_SET(?, supply_source) OR FIND_IN_SET(?, supply_source))"], convey.ShouldResemble, []string{"SS-1", "SS-2"})
			// 签约形式修复：where 需真实带上 signature_type 过滤
			convey.So(whereArg["signature_type = ?"], convey.ShouldResemble, []string{"ELECTRONIC"})
			// 项目编号走生成列，并按左精准右模糊
			convey.So(whereArg["project_code_gen like ?"], convey.ShouldResemble, []string{"PJ-1%"})
		})
	})

	t.Run("case 商务模式多选：special_contract_type 用多个 FIND_IN_SET AND 命中全部选中值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				BusinessModeList: []string{"MODE_A", "MODE_B"},
			})

			// 多选语义由多个 FIND_IN_SET AND 串联实现
			convey.So(whereArg["FIND_IN_SET(?, special_contract_type)"], convey.ShouldResemble, []string{"MODE_A", "MODE_B"})
		})
	})

	t.Run("case 关联报价单号：左精准右模糊", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildQuery(context.Background(), &gorm.DB{}, &model.ContractMetaReq{
				RelateQuoteID: "RQ-1",
				IsManager:     true,
			})

			convey.So(whereArg["volc_contract_meta.relate_quote_no like ?"], convey.ShouldResemble, []string{"RQ-1%"})
		})
	})

	t.Run("case 商品多选：仅查内部商品表并聚合包含全部选中值", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, havingArg := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				TradeProductList: []string{"P1", "P2"},
			})

			// 仅按内部表 trade_product in (?) 过滤，不再查外部商品表
			convey.So(whereArg["trade_product in (?)"], convey.ShouldResemble, []string{"P1", "P2"})
			// having 需带 count(distinct trade_product) 以保证“包含全部选中值”语义
			_, ok := havingArg["count(distinct trade_product) = ?"]
			convey.So(ok, convey.ShouldBeTrue)
		})
	})

	t.Run("case 商机名称/ID：左精准右模糊(前缀匹配)", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				OpportunityName: "OPP",
				OpportunityID:   "ID9",
			})

			// 左精准右模糊 => 前缀匹配 xxx%
			convey.So(whereArg["party_name like ?"], convey.ShouldContain, "OPP%")
			convey.So(whereArg["party_name like ?"], convey.ShouldContain, "ID9%")
		})
	})

	t.Run("case 是否项目制：Y 仅命中明确项目制", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				WhetherProject: "Y",
			})

			convey.So(whereArg["whether_project_gen = ?"], convey.ShouldResemble, []string{"Y"})
		})
	})

	t.Run("case 是否项目制：N 命中所有不明确为 Y 的非项目制", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				WhetherProject: "N",
			})

			convey.So(whereArg["whether_project_gen = ?"], convey.ShouldResemble, []string{"N"})
		})
	})

	t.Run("case 归属行业多选：生成列 in 查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				DepartmentIdList: []string{"D1", "D2"},
			})

			convey.So(whereArg["department_id_gen in (?)"], convey.ShouldResemble, []string{"D1", "D2"})
		})
	})

	t.Run("case 业务类型多选：生成列 in 查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			whereArg, _ := setupMock()
			_dbClient = &gorm.DB{}
			v := &contractMetaDaoImpl{}

			v.buildExtraFilterQuery(context.Background(), &gorm.DB{}, &gorm.DB{}, &model.ContractMetaReq{
				BusinessTypeList: []string{"1", "7"},
			})

			convey.So(whereArg["business_type_gen in (?)"], convey.ShouldResemble, []string{"1", "7"})
		})
	})
}

package dal

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestBuildQuery(t *testing.T) {
	assert.True(t, buildLikeQuery("xxx") == "%xxx%")
}

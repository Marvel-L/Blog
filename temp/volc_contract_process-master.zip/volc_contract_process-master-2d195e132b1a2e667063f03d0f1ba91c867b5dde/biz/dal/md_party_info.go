package dal

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/security/dkms-gorm/kms"
	"context"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	TMdPartyInfo = "md_party_info"
)

type MdPartyInfoDao interface {
	CreateMdPartyInfo(ctx context.Context, tx *gorm.DB, mdPartyInfo *model.MdPartyInfoDB) error
	GetMdPartyInfoByAccountId(ctx context.Context, tx *gorm.DB, accountID int64) (*model.MdPartyInfoDB, error)
	GetMdPartyInfoByIdentNo(ctx context.Context, tx *gorm.DB, identNo string) (*model.MdPartyInfoDB, error)
	DeleteMdPartyInfo(ctx context.Context, tx *gorm.DB, accountID int64) error
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID uint64, offset int) (model.MdPartyInfoDBList, error)
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	GetMdPartyInfoByID(ctx context.Context, tx *gorm.DB, id uint64) (*model.MdPartyInfoDB, error)
}

var _mdPartyInfoDaoInstance = &mdPartyInfoDaoImpl{}

func NewMdPartyInfoDao() MdPartyInfoDao {
	return _mdPartyInfoDaoInstance
}

type mdPartyInfoDaoImpl struct {
}

// CreateMdPartyInfo Create
func (c *mdPartyInfoDaoImpl) CreateMdPartyInfo(ctx context.Context, tx *gorm.DB, mdPartyInfo *model.MdPartyInfoDB) error {
	// 敏感字段在create是会被gorm-dkms置空，创建业务合同的长事务中使用该明文字段，因此这里需要先保存明文，create后再赋值。
	if mdPartyInfo == nil {
		return i18nfmt.New(ctx, "CreateMdPartyInfoFail, mdPartyInfo is nil")
	}
	identNoPlaintext := mdPartyInfo.IdentNo
	err := initDB(ctx, tx).Table(TMdPartyInfo).Create(mdPartyInfo).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateMdPartyInfoFail, err:%s", err.Error())
		return err
	}
	mdPartyInfo.IdentNo = identNoPlaintext
	return nil
}

// GetMdPartyInfoByAccountId Get
func (c *mdPartyInfoDaoImpl) GetMdPartyInfoByAccountId(ctx context.Context, tx *gorm.DB, accountID int64) (*model.MdPartyInfoDB, error) {
	mdPartyInfo := model.MdPartyInfoDB{}

	db := initDB(ctx, tx).Table(TMdPartyInfo)
	db.Where("account_id = ?", accountID)

	err := db.First(&mdPartyInfo).Error
	if ignoreErr(err) != nil {
		return nil, err
	}
	if mdPartyInfo.Id > 0 {
		return &mdPartyInfo, nil
	}
	return nil, nil
}

func (c *mdPartyInfoDaoImpl) GetMdPartyInfoByID(ctx context.Context, tx *gorm.DB, id uint64) (*model.MdPartyInfoDB, error) {
	mdPartyInfo := model.MdPartyInfoDB{}
	db := initDB(ctx, tx).Table(TMdPartyInfo)
	db.Where("id = ?", id)
	err := db.First(&mdPartyInfo).Error
	if ignoreErr(err) != nil {
		return nil, err
	}
	if mdPartyInfo.Id > 0 {
		return &mdPartyInfo, nil
	}
	return nil, nil
}

func (c *mdPartyInfoDaoImpl) GetMdPartyInfoByIdentNo(ctx context.Context, tx *gorm.DB, identNo string) (*model.MdPartyInfoDB, error) {
	mdPartyInfo := model.MdPartyInfoDB{}

	db := initDB(ctx, tx).Table(TMdPartyInfo)
	db.Where(kms.Eq("encrypt_ident_no", identNo))

	err := db.Last(&mdPartyInfo).Error
	if ignoreErr(err) != nil {
		return nil, err
	}
	if mdPartyInfo.Id > 0 {
		return &mdPartyInfo, nil
	}
	return nil, nil
}

// DeleteMdPartyInfo Delete
func (c *mdPartyInfoDaoImpl) DeleteMdPartyInfo(ctx context.Context, tx *gorm.DB, accountID int64) error {
	if accountID == 0 {
		return i18nfmt.New(ctx, "NO accountID")
	}

	db := initDB(ctx, tx).Table(TMdPartyInfo).Where("account_id = ?", accountID)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *mdPartyInfoDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID uint64, offset int) (model.MdPartyInfoDBList, error) {
	db := initDB(ctx, tx).Table(TMdPartyInfo).Where("id >= ?", startID)
	var list model.MdPartyInfoDBList
	err := db.Order("id asc").Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *mdPartyInfoDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Model(&model.MdPartyInfoDB{}).Table(TMdPartyInfo)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

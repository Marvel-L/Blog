package dal

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"reflect"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_contractTradePartyDaoImpl_UpdateByMap(t *testing.T) {
	dao := &contractTradePartyDaoImpl{}
	updates := map[string]interface{}{
		"ext": "test_ext",
	}
	ctx := context.Background()

	t.Run("Success case", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when database update is successful", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			// Test with a non-nil transaction
			errWithTx := dao.UpdateByMap(ctx, mockDB, int64(1), updates)
			convey.So(errWithTx, convey.ShouldBeNil)

			// Test with a nil transaction (uses global _dbClient)
			errWithoutTx := dao.UpdateByMap(ctx, nil, int64(1), updates)
			convey.So(errWithoutTx, convey.ShouldBeNil)
		})
	})

	t.Run("Failure case - database error", func(t *testing.T) {
		mockey.PatchConvey("Should return a formatted error when database update fails", t, func() {
			dbErr := errors.New("database update failed")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: dbErr}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.UpdateByMap(ctx, nil, int64(1), updates)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "UpdateByMapFail")
		})
	})

	t.Run("Success case - ignored 'record not found' error", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when 'record not found' error is returned from DB", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.UpdateByMap(ctx, nil, int64(1), updates)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_contractTradePartyDaoImpl_ListByIdRange_BitsUTGen(t *testing.T) {
	dao := &contractTradePartyDaoImpl{}
	ctx := context.Background()
	startID := uint64(1)
	offset := 10

	t.Run("Success case", func(t *testing.T) {
		mockey.PatchConvey("Should return a list of items when DB operation is successful", t, func() {
			mockDB := &gorm.DB{}
			expectedList := model.ContractTradePartyDBList{
				{}, {},
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				// Simulate GORM populating the destination slice
				v := reflect.ValueOf(dest)
				if v.Kind() == reflect.Ptr {
					v.Elem().Set(reflect.ValueOf(expectedList))
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// Test with a non-nil transaction
			listWithTx, errWithTx := dao.ListByIdRange(ctx, mockDB, startID, offset)
			convey.So(errWithTx, convey.ShouldBeNil)
			convey.So(len(listWithTx), convey.ShouldEqual, len(expectedList))

			// Test with a nil transaction
			listWithoutTx, errWithoutTx := dao.ListByIdRange(ctx, nil, startID, offset)
			convey.So(errWithoutTx, convey.ShouldBeNil)
			convey.So(len(listWithoutTx), convey.ShouldEqual, len(expectedList))
		})
	})

	t.Run("Success case - record not found", func(t *testing.T) {
		mockey.PatchConvey("Should return empty list and nil error when gorm.ErrRecordNotFound is returned", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(finalDB).Build()

			list, err := dao.ListByIdRange(ctx, nil, startID, offset)

			convey.So(err, convey.ShouldBeNil)
			// The function returns a nil slice when no records are found, which is a valid empty slice.
			// The original assertion `ShouldNotBeNil` was incorrect. We check the length is 0, which correctly tests for emptiness.
			convey.So(len(list), convey.ShouldEqual, 0)
		})
	})

	t.Run("Failure case - database error", func(t *testing.T) {
		mockey.PatchConvey("Should return an error when the database find operation fails", t, func() {
			dbErr := errors.New("database find failed")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: dbErr}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Order).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Limit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(finalDB).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()

			list, err := dao.ListByIdRange(ctx, nil, startID, offset)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "FindByIdRangeFail")
			convey.So(list, convey.ShouldBeNil)
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_contractTradePartyDaoImpl_FindByID_BitsUTGen(t *testing.T) {
	// Initialize common variables for tests.
	dao := &contractTradePartyDaoImpl{}
	ctx := context.Background()
	testID := uint64(1)
	expectedEntity := &model.ContractTradePartyDB{
		BaseDB:         model.BaseDB{Id: testID},
		VolcContractID: 101,
		ContractNo:     "TEST-CONTRACT-001",
		PartyName:      "Test Party",
	}

	t.Run("Success case - record found", func(t *testing.T) {
		mockey.PatchConvey("Should return the entity when a record is successfully found in the database", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			// Mock the First method to populate the destination entity.
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if entityPtr, ok := dest.(*model.ContractTradePartyDB); ok {
					*entityPtr = *expectedEntity
				}
				return finalDB
			}).Build()

			// Test with a nil transaction.
			result, err := dao.FindByID(ctx, nil, testID)
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedEntity)

			// Test with a non-nil transaction.
			resultWithTx, errWithTx := dao.FindByID(ctx, &gorm.DB{}, testID)
			convey.So(errWithTx, convey.ShouldBeNil)
			convey.So(resultWithTx, convey.ShouldResemble, expectedEntity)
		})
	})

	t.Run("Failure case - database error", func(t *testing.T) {
		mockey.PatchConvey("Should return a formatted error when the database query fails", t, func() {
			dbErr := errors.New("database connection failed")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: dbErr}
			formattedErrStr := fmt.Sprintf("FindByIDFail, err:%v", dbErr)

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(finalDB).Build()

			mockey.Mock(i18nfmt.Sprintf).Return(formattedErrStr).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()
			// Mock env.IsOnline to ensure it doesn't fall into the RASP error ignore case.
			mockey.Mock(env.IsOnline).Return(true).Build()

			result, err := dao.FindByID(ctx, nil, testID)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, formattedErrStr)
		})
	})

	t.Run("Success case - record not found error is ignored", func(t *testing.T) {
		mockey.PatchConvey("Should return nil error when gorm.ErrRecordNotFound is returned", t, func() {
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(finalDB).Build()

			result, err := dao.FindByID(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			// The function returns a pointer to a zero-value struct in this case.
			convey.So(result, convey.ShouldResemble, &model.ContractTradePartyDB{})
		})
	})

	t.Run("Success case - RASP error is ignored in non-online env", func(t *testing.T) {
		mockey.PatchConvey("Should return nil error for RASP errors in a non-online environment", t, func() {
			raspErr := errors.New("API blocked by RASP")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: raspErr}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(finalDB).Build()

			// This is the key condition for this test case.
			mockey.Mock(env.IsOnline).Return(false).Build()

			result, err := dao.FindByID(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, &model.ContractTradePartyDB{})
		})
	})
}

// All comments and test scenario descriptions must be in english.
func Test_contractTradePartyDaoImpl_Update_BitsUTGen(t *testing.T) {
	// Initialize common variables for tests
	dao := &contractTradePartyDaoImpl{}
	ctx := context.Background()
	entity := &model.ContractTradePartyDB{
		BaseDB:    model.BaseDB{Id: 1},
		PartyName: "Test Party",
	}

	t.Run("Success case", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when database update is successful", t, func() {
			// Mock the GORM chain to simulate a successful update
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Select).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Omit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			// Test with a non-nil transaction
			errWithTx := dao.Update(ctx, mockDB, entity)
			convey.So(errWithTx, convey.ShouldBeNil)

			// Test with a nil transaction (uses global db client)
			errWithoutTx := dao.Update(ctx, nil, entity)
			convey.So(errWithoutTx, convey.ShouldBeNil)
		})
	})

	t.Run("fail case", func(t *testing.T) {
		mockey.PatchConvey("entity is nil", t, func() {
			// Mock the GORM chain to simulate a successful update
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: nil}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Select).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Omit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			// Test with a non-nil transaction
			errWithTx := dao.Update(ctx, mockDB, nil)
			convey.So(errWithTx, convey.ShouldNotBeNil)
			convey.So(errWithTx.Error(), convey.ShouldEqual, "updateContractTradePartyFail, entity is nil")

		})
	})

	t.Run("Failure case - database error", func(t *testing.T) {
		mockey.PatchConvey("Should return a formatted error when database update fails", t, func() {
			// Mock a generic database error
			dbErr := errors.New("database update failed")
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: dbErr}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Select).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Omit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()

			// Mock error formatting and environment check
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return errors.New(text)
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.Update(ctx, nil, entity)

			// Assert that a specific error is returned
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "updateTradePartyFail")
		})
	})

	t.Run("Success case - ignored 'record not found' error", func(t *testing.T) {
		mockey.PatchConvey("Should return nil when 'record not found' error is returned from DB", t, func() {
			// Mock the specific 'record not found' error
			mockDB := &gorm.DB{}
			finalDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Model).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Select).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Omit).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(finalDB).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := dao.Update(ctx, nil, entity)

			// Assert that the error is correctly ignored
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_contractTradePartyDaoImpl_Create_ByteUTGen(t *testing.T) {
	// 测试传入的entity为nil的场景
	t.Run("CreateWithNilEntity", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			var receiver *contractTradePartyDaoImpl = &contractTradePartyDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] entityTest == nil
			var entityTest *model.ContractTradePartyDB = nil
			// 运行被测函数
			err := receiver.Create(ctxTest, txTest, entityTest)
			// 当传入的entity为nil时，函数会进入if判断，返回一个错误，所以err不为nil
			convey.So(err, convey.ShouldNotBeNil)
			// 当传入的entity为nil时，函数会返回该错误信息
			convey.So(err.Error(), convey.ShouldEqual, "createContractTradePartyFail, entity is nil")
		})
	})

	// 测试创建合同交易方信息成功的场景
	t.Run("CreateContractTradePartySuccess", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			// 构造函数入参
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			var entityTest *model.ContractTradePartyDB = &model.ContractTradePartyDB{
				Ext: "Additional information",
			}
			var receiver *contractTradePartyDaoImpl = &contractTradePartyDaoImpl{}
			// 运行被测函数
			err := receiver.Create(ctxTest, txTest, entityTest)
			// 通过mock函数，ignoreErr返回nil，不会触发错误处理逻辑，函数正常执行并返回nil，因此err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

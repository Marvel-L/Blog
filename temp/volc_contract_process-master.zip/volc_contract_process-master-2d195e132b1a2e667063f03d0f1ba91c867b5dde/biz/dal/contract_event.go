package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tBContractEvent = "volc_contract_event"
)

type ContractEventDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractEventDB) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.ContractEventDB) error
	FindByStashKey(ctx context.Context, tx *gorm.DB, stashKey string) (*model.ContractEventDB, error)
}

func NewContractEventDao() ContractEventDao {
	return &contractEventDao{}
}

type contractEventDao struct {
}

func (c contractEventDao) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractEventDB) error {
	err := initDB(ctx, tx).Table(tBContractEvent).Select("*").Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractEventFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractEventFail")
	}
	return nil
}

func (c contractEventDao) Update(ctx context.Context, tx *gorm.DB, entity *model.ContractEventDB) error {
	err := initDB(ctx, tx).Table(tBContractEvent).Select("*").Omit("created_time").
		Where("id = ?", entity.Id).Save(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractEventFail, StashKey:%d, err:%s", entity.StashKey, err.Error())
		return i18nfmt.New(ctx, "updateContractEventFail")
	}
	return nil
}

func (c contractEventDao) FindByStashKey(ctx context.Context, tx *gorm.DB, stashKey string) (*model.ContractEventDB, error) {
	db := initDB(ctx, tx).Table(tBContractEvent).Where("stash_key = ?", stashKey)
	var ret model.ContractEventDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByStashKeyFail, stashKey=%s, err=%s", stashKey, err.Error())
		return nil, i18nfmt.New(ctx, "FindByStashKeyFail")
	}
	if ret.Id == 0 {
		return nil, nil
	}
	return &ret, nil
}

package dal

import (
	"context"
	"time"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tContractSettlement = "volc_contract_settlement"
)

type ContractSettlementDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractSettlementDB) error
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.ContractSettlementDB) error
	SoftDeleteByContractID(ctx context.Context, tx *gorm.DB, contractID int) error
	ListContractSettlementByContractID(ctx context.Context, tx *gorm.DB, contractID int) ([]*model.ContractSettlementDB, error)
	ListContractSettlementByContractIDAndVersion(ctx context.Context, tx *gorm.DB, contractID int, version string) ([]*model.ContractSettlementDB, error)
	DeleteSettlementByIds(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.ContractSettlementDB) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	MakeStartUp(ctx context.Context, tx *gorm.DB, settlementId int) error
}

func NewContractSettlementDao() ContractSettlementDao {
	return &contractSettlementDaoImpl{}
}

type contractSettlementDaoImpl struct {
}

func (c *contractSettlementDaoImpl) SoftDeleteByContractID(ctx context.Context, tx *gorm.DB, contractID int) error {
	db := initDB(ctx, tx).Table(tContractSettlement)
	err := db.Where("volc_contract_id = ? and is_deleted = 0", contractID).Updates(map[string]interface{}{"is_deleted": 1}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "SoftDeleteSettlementByContractID, err:%v", err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "SoftDeleteSettlementByContractIDFail,err:%v", err))
	}
	return nil
}

func (c *contractSettlementDaoImpl) ListContractSettlementByContractID(ctx context.Context,
	tx *gorm.DB, contractID int) ([]*model.ContractSettlementDB, error) {
	var list []*model.ContractSettlementDB
	db := initDB(ctx, tx).Table(tContractSettlement).Where("volc_contract_id = ? and is_deleted = 0", contractID)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractSettlementByContractID, contractID:%s, err:%s", contractID, err.Error())
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListContractSettlementByContractIDFail,err:%v", err))
	}
	return list, nil
}

func (c *contractSettlementDaoImpl) ListContractSettlementByContractIDAndVersion(ctx context.Context,
	tx *gorm.DB, contractID int, version string) ([]*model.ContractSettlementDB, error) {
	var list []*model.ContractSettlementDB
	db := initDB(ctx, tx).Table(tContractSettlement).Where("volc_contract_id = ? and version = ?", contractID, version)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractSettlementByContractIDAndVersion, contractID:%s, version:%v,err:%s", contractID, version, err.Error())
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListContractSettlementByContractIDAndVersionFail,err:%v", err))
	}
	return list, nil
}

// Create .暂时没有应用场景，后续使用时需要考虑version字段问题
func (c *contractSettlementDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractSettlementDB) error {
	err := initDB(ctx, tx).Table(tContractSettlement).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractSettlementFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "createContractSettlementFail,err:%v", err))
	}
	return nil
}

func (c *contractSettlementDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.ContractSettlementDB) error {
	version := time.Now().Format("20060102150405")
	for _, entity := range entities {
		if len(entity.Version) == 0 {
			entity.Version = version
		}
	}
	err := initDB(ctx, tx).Table(tContractSettlement).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreateContractSettlementFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "batchCreateContractSettlementFail,err:%v", err))
	}
	return nil
}

func (c *contractSettlementDaoImpl) DeleteSettlementByIds(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error {
	if len(ids) == 0 {
		logs.CtxWarn(ctx, "NO ids")
		return nil
	}

	db := initDB(ctx, tx).Table(tContractSettlement)
	err := db.Where("volc_contract_id = ?", contractID).Where("id in (?)", ids).
		Updates(map[string]interface{}{"is_deleted": 1}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteSettlementByIds, err:%v", err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "DeleteSettlementByIdsFail,err:%v", err))
	}
	return nil
}

func (c *contractSettlementDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.ContractSettlementDB) error {
	err := initDB(ctx, tx).Table(tContractSettlement).Select("*").Omit("created_time").Updates(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateSettlementFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "updateSettlementFail")
	}
	return nil
}

func (c *contractSettlementDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tContractSettlement)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c *contractSettlementDaoImpl) MakeStartUp(ctx context.Context, tx *gorm.DB, settlementId int) error {
	db := initDB(ctx, tx).Table(tContractSettlement)
	err := db.Where("id = ?", settlementId).Updates(map[string]interface{}{"is_start_up": 1}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteSettlementByIds, err:%v", err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "DeleteSettlementByIdsFail,err:%v", err))
	}
	return nil
}

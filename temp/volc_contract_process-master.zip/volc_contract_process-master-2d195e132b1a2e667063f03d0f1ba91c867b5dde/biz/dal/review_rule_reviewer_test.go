package dal

import (
	"code.byted.org/gopkg/context"
	context2 "context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_preContractReviewRuleReviewerDaoImpl_DeleteByRuleID_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewRuleReviewerDaoImpl_DeleteByRuleID", t, func() {
		// Common variables for all test cases
		ctx := context.Background()
		dao := &preContractReviewRuleReviewerDaoImpl{}
		ruleID := "test-rule-123"
		mockDB := &gorm.DB{}

		mockey.PatchConvey("Success case: successfully delete records by ruleID", func() {
			// 场景描述：
			// 数据库删除操作成功。
			// 构造数据：
			// 无特殊构造。
			// 逻辑链路：
			// 1. Mock initDB 返回一个有效的 gorm.DB 实例。
			// 2. Mock gorm 的 Table, Where, Delete 链式调用。
			// 3. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为 nil。
			// 4. 函数应正常执行并返回 nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: nil}).Build()

			err := dao.DeleteByRuleID(ctx, nil, ruleID)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case: database operation fails", func() {
			// 场景描述：
			// 数据库删除操作返回一个通用错误。
			// 构造数据：
			// 构造一个通用 error。
			// 逻辑链路：
			// 1. Mock initDB 返回一个有效的 gorm.DB 实例。
			// 2. Mock gorm 的 Table, Where, Delete 链式调用。
			// 3. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为一个通用错误。
			// 4. ignoreErr 函数不会忽略此错误。
			// 5. Mock i18nfmt.New 返回一个预设的错误。
			// 6. 函数应返回 i18nfmt.New 创建的错误。
			dbErr := errors.New("database connection error")
			i18nErr := errors.New("DeleteByRuleIDFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			err := dao.DeleteByRuleID(ctx, nil, ruleID)

			convey.So(err, convey.ShouldEqual, i18nErr)
		})

		mockey.PatchConvey("Ignored error case: gorm.ErrRecordNotFound", func() {
			// 场景描述：
			// 数据库删除操作返回 gorm.ErrRecordNotFound 错误，该错误应被忽略。
			// 构造数据：
			// 无。
			// 逻辑链路：
			// 1. Mock initDB 返回一个有效的 gorm.DB 实例。
			// 2. Mock gorm 的 Table, Where, Delete 链式调用。
			// 3. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为 gorm.ErrRecordNotFound。
			// 4. ignoreErr 函数会忽略此错误并返回 nil。
			// 5. 函数应正常返回 nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.DeleteByRuleID(ctx, nil, ruleID)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Ignored error case: RASP error in non-online environment", func() {
			// 场景描述：
			// 在非线上环境，数据库返回 RASP 错误，该错误应被忽略。
			// 构造数据：
			// 构造一个包含 "API blocked by RASP" 的 error。
			// 逻辑链路：
			// 1. Mock env.IsOnline 返回 false。
			// 2. Mock initDB 返回一个有效的 gorm.DB 实例。
			// 3. Mock gorm 的 Table, Where, Delete 链式调用。
			// 4. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为 RASP 错误。
			// 5. ignoreErr 函数会忽略此错误并返回 nil。
			// 6. 函数应正常返回 nil。
			raspErr := errors.New("some error: API blocked by RASP")
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: raspErr}).Build()

			err := dao.DeleteByRuleID(ctx, nil, ruleID)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case: RASP error in online environment", func() {
			// 场景描述：
			// 在线上环境，数据库返回 RASP 错误，该错误不应被忽略。
			// 构造数据：
			// 构造一个包含 "API blocked by RASP" 的 error。
			// 逻辑链路：
			// 1. Mock env.IsOnline 返回 true。
			// 2. Mock initDB 返回一个有效的 gorm.DB 实例。
			// 3. Mock gorm 的 Table, Where, Delete 链式调用。
			// 4. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为 RASP 错误。
			// 5. ignoreErr 函数不会忽略此错误。
			// 6. Mock i18nfmt.New 返回一个预设的错误。
			// 7. 函数应返回 i18nfmt.New 创建的错误。
			raspErr := errors.New("some error: API blocked by RASP")
			i18nErr := errors.New("DeleteByRuleIDFail")

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			err := dao.DeleteByRuleID(ctx, nil, ruleID)

			convey.So(err, convey.ShouldEqual, i18nErr)
		})

		mockey.PatchConvey("Success case: with transaction", func() {
			// 场景描述：
			// 使用传入的数据库事务（tx）成功删除记录。
			// 构造数据：
			// 构造一个非 nil 的 gorm.DB 实例作为事务。
			// 逻辑链路：
			// 1. 构造一个 tx *gorm.DB。
			// 2. Mock initDB 在接收到非 nil 的 tx 时，返回该 tx。
			// 3. Mock gorm 的 Table, Where, Delete 链式调用。
			// 4. Mock Delete 方法返回的 gorm.DB 实例的 Error 字段为 nil。
			// 5. 函数应正常执行并返回 nil。
			tx := &gorm.DB{}

			mockey.Mock(initDB).Return(tx).Build()
			mockey.Mock((*gorm.DB).Table).Return(tx).Build()
			mockey.Mock((*gorm.DB).Where).Return(tx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: nil}).Build()

			err := dao.DeleteByRuleID(ctx, tx, ruleID)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_preContractReviewRuleReviewerDaoImpl_List_ByteUTGen(t *testing.T) {
	// 测试输入NeedTotal为true且Limit不为0，所有函数无错误返回的场景
	t.Run("ListWithNeedTotalAndLimit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*preContractReviewRuleReviewerDaoImpl).buildQuery).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			// 构造函数入参
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] paramTest.NeedTotal == true && paramTest.Limit != 0
			var paramTest *modelreviewrule.ReviewRuleReviewerListParams = &modelreviewrule.ReviewRuleReviewerListParams{
				Offset:    10,
				NeedTotal: true,
				Limit:     1,
			}
			var receiver *preContractReviewRuleReviewerDaoImpl = &preContractReviewRuleReviewerDaoImpl{}
			var ctxTest context.Context = context2.Background()
			// 运行被测函数
			got1, got2, err := receiver.List(ctxTest, txTest, paramTest)

			// 虽然Find函数被mock，但没有对结果列表进行赋值操作，因此结果列表为空，长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 代码中total未被赋值，默认初始值为0，因此返回的总数为0
			convey.So(got2, convey.ShouldEqual, 0)
			// 所有mock函数返回值均无错误，且ignoreErr函数返回nil，不会触发错误处理逻辑，因此err为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

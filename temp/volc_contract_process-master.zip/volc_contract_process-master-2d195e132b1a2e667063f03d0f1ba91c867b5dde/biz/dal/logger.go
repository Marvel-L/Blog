package dal

import (
	"context"
	"errors"
	"fmt"
	"math/rand"
	"time"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/dkmscli"
)

type extLogger struct {
	logger.LogLevel
	*logs.Logger
}

func (l extLogger) Apply(config *gorm.Config) error {
	if l.LogLevel == 0 {
		l.LogLevel = logger.Error
	}

	if l.Logger == nil {
		l.Logger = logs.DefaultLogger()
	}

	config.Logger = l
	return nil
}

func (l extLogger) AfterInitialize(db *gorm.DB) error {
	return nil
}

func (l extLogger) LogMode(level logger.LogLevel) logger.Interface {
	l.LogLevel = level
	return l
}

func (l extLogger) Info(ctx context.Context, msg string, data ...interface{}) {
	//if l.LogLevel >= logger.Info {
	//	l.Logger.CtxInfo(ctx, "GORM LOG "+msg, data...)
	//}
}

func (l extLogger) Warn(ctx context.Context, msg string, data ...interface{}) {
	//if l.LogLevel >= logger.Warn {
	//	l.Logger.CtxWarn(ctx, "GORM LOG "+msg, data...)
	//}
}

func (l extLogger) Error(ctx context.Context, msg string, data ...interface{}) {
	//if l.LogLevel >= logger.Error {
	//	l.Logger.CtxError(ctx, "GORM LOG "+msg, data...)
	//}
}

func (l extLogger) Trace(ctx context.Context, begin time.Time, fc func() (string, int64), err error) {
	if l.LogLevel > logger.Silent {
		cost := float64(time.Since(begin).Nanoseconds()/1e4) / 100.0
		nowNano := time.Now().UnixNano()
		r := rand.Uint32()
		flag := fmt.Sprintf("%d_%d", nowNano, r)
		switch {
		case err != nil && l.LogLevel >= logger.Error && (!errors.Is(err, gorm.ErrRecordNotFound)):
			sql, _ := fc()
			l.Logger.CtxError(ctx, "[%s]GORM LOG %s, Cost:%.2fms, Error: %s", flag, sql, cost, err.Error())
			l.logEncryptData(ctx, sql, flag)
		case l.LogLevel >= logger.Info:
			sql, rows /* affected rows */ := fc()
			l.Logger.CtxInfo(ctx, "[%s]GORM LOG SQL:%s Rows: %d Cost:%.2fms", flag, sql, rows, cost)
			l.logEncryptData(ctx, sql, flag)
		}
	}
}

func (l extLogger) logEncryptData(ctx context.Context, sql string, flag string) {
	encryptData, _ := dkmscli.EncryptWithContext(ctx, sql)
	if encryptData != "" {
		l.Logger.CtxInfo(ctx, "[%s]%s Encrypt GORM LOG: %s", _const.ZenRawInfoFlag, flag, encryptData)
	}
}

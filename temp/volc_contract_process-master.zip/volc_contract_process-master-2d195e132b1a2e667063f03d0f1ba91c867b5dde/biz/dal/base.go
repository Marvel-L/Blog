package dal

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/pkg/env"
)

type readDBContextKey struct{}

// GetDB 获取数据库连接
func GetDB(ctx context.Context) *gorm.DB {
	return initDB(ctx, nil)
}

func WithReadDB(ctx context.Context) context.Context {
	return context.WithValue(ctx, readDBContextKey{}, true)
}

func useReadDB(ctx context.Context) bool {
	v, _ := ctx.Value(readDBContextKey{}).(bool)
	return v
}

func initDB(ctx context.Context, tx *gorm.DB) *gorm.DB {
	if tx != nil {
		return tx
	}
	if useReadDB(ctx) && _readDBClient != nil {
		logs.CtxInfo(ctx, "useReadDB")
		return _readDBClient.WithContext(ctx)
	}
	return _dbClient.WithContext(ctx)
}

func ignoreNotFoundErr(err error) error {
	if err == gorm.ErrRecordNotFound {
		return nil
	}
	return err
}

// 代码扫描 Mysql 更新拦截
func ignoreRaspErr(err error) error {
	// 线上环境不执行过滤逻辑
	if env.IsOnline() {
		return err
	}
	if err != nil && strings.Contains(err.Error(), "API blocked by RASP") {
		logs.CtxError(context.Background(), "ignoreRaspErr, err:%v", err)
		return nil
	}
	return err
}

func ignoreErr(err error) error {
	if ignoreNotFoundErr(err) == nil {
		return nil
	}
	if ignoreRaspErr(err) == nil {
		return nil
	}
	return err
}

func buildLikeQuery(s string) string {
	return fmt.Sprintf("%%%s%%", s)
}

func buildRightLikeQuery(s string) string {
	return fmt.Sprintf("%s%%", s)
}

func buildContractVersions(version int) []int {
	var versions []int
	if version <= 1 {
		versions = []int{0, 1}
	} else {
		versions = []int{version}
	}
	return versions
}

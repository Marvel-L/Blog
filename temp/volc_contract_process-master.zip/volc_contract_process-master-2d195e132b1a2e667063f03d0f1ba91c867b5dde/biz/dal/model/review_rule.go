package model

import "time"

type ReviewRuleDB struct {
	BaseDB
	RuleID          string                   `gorm:"column:rule_id" db:"rule_id" json:"rule_id" form:"rule_id"`                                     // 规则id
	SalesDepartment string                   `gorm:"column:sales_department" db:"sales_department" json:"sales_department" form:"sales_department"` // 销售所属行业(中文)
	Remark          string                   `gorm:"column:remark" db:"remark" json:"remark" form:"remark"`                                         // 备注说明
	CreatorEmail    string                   `gorm:"column:creator_email" db:"creator_email" json:"creator_email" form:"creator_email"`             // 创建人邮箱
	UpdaterEmail    string                   `gorm:"column:updater_email" db:"updater_email" json:"updater_email" form:"updater_email"`             // 更新人邮箱
	Reviewers       ReviewRuleReviewerDBList `gorm:"-"`                                                                                             // 联表查询的结果
}

type ReviewRule struct {
	ID              uint64                 // 自增id
	RuleID          string                 // 规则id
	SalesDepartment string                 // 销售所属行业(中文)
	Remark          string                 // 备注说明
	CreatorEmail    string                 // 创建人邮箱
	UpdaterEmail    string                 // 更新人邮箱
	CreatedTime     time.Time              // 创建时间
	UpdatedTime     time.Time              // 更新时间
	Status          int                    // 状态 1 生效中 2 已禁用
	Reviewers       ReviewRuleReviewerList `json:"-"` // 联表查询的结果
}

type ReviewRuleDBList []*ReviewRuleDB
type ReviewRuleList []*ReviewRule

func (r *ReviewRuleDB) GenResp() *ReviewRule {
	return &ReviewRule{
		ID:              r.Id,
		RuleID:          r.RuleID,
		SalesDepartment: r.SalesDepartment,
		Remark:          r.Remark,
		CreatorEmail:    r.CreatorEmail,
		UpdaterEmail:    r.UpdaterEmail,
		Reviewers:       r.Reviewers.GenResp(),
		CreatedTime:     r.CreatedTime,
		UpdatedTime:     r.UpdatedTime,
		Status:          r.Status,
	}
}

func (r ReviewRuleDBList) GenResp() ReviewRuleList {
	var list ReviewRuleList
	for _, rule := range r {
		list = append(list, rule.GenResp())
	}
	return list
}

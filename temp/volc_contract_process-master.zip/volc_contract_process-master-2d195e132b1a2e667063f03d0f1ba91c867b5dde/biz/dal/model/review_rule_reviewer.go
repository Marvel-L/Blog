package model

import "time"

type ReviewRuleReviewerDB struct {
	BaseDB
	RuleID           string `gorm:"column:rule_id" db:"rule_id" json:"rule_id" form:"rule_id"`                                         // 所属规则id
	ReviewerRole     int    `gorm:"column:reviewer_role" db:"reviewer_role" json:"reviewer_role" form:"reviewer_role"`                 // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP
	AssigneePriority int    `gorm:"column:assignee_priority" db:"assignee_priority" json:"assignee_priority" form:"assignee_priority"` // 指派人优先级 1 首选审批人 2 相关人
	EmployeeEmail    string `gorm:"column:employee_email" db:"employee_email" json:"employee_email" form:"employee_email"`             // 审批人邮箱
	EmployeeName     string `gorm:"column:employee_name" db:"employee_name" json:"employee_name" form:"employee_name"`                 // 审批人姓名(仅用于搜索)
	EmployeeNumber   string `gorm:"column:employee_number" db:"employee_number" json:"employee_number" form:"employee_number"`         // 审批人工号(仅用于搜索)
	ChatToken        string `gorm:"column:chat_token" db:"chat_token" json:"chat_token" form:"chat_token"`                             // 旧的飞书群 token (仅字节内部使用)，通过 https://open.feishu.cn/tool/token 获取
	OpenChatID       string `gorm:"column:open_chat_id" db:"open_chat_id" json:"open_chat_id" form:"open_chat_id"`                     // 飞书群ID
	ChatName         string `gorm:"column:chat_name" db:"chat_name" json:"chat_name" form:"chat_name"`                                 // 飞书群名称
	ChatAvatarURL    string `gorm:"column:chat_avatar_url" db:"chat_avatar_url" json:"chat_avatar_url" form:"chat_avatar_url"`         // 飞书群头像 URL
}

type ReviewRuleReviewer struct {
	ID               uint64    // 自增id
	RuleID           string    // 所属规则id
	ReviewerRole     int       // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP
	AssigneePriority int       // 指派人优先级 1 首选审批人 2 相关人
	EmployeeEmail    string    // 审批人邮箱
	EmployeeName     string    // 审批人姓名(仅用于搜索)
	EmployeeNumber   string    // 审批人工号(仅用于搜索)
	ChatToken        string    // 旧的飞书群 token (仅字节内部使用)，通过 https://open.feishu.cn/tool/token 获取
	OpenChatID       string    // 飞书群ID
	ChatName         string    // 飞书群名称
	ChatAvatarURL    string    // 飞书群头像 URL
	CreatedTime      time.Time // 创建时间
	UpdatedTime      time.Time // 更新时间(未使用)
	Status           int       // 状态(未使用)
}

type ReviewRuleReviewerDBList []*ReviewRuleReviewerDB
type ReviewRuleReviewerList []*ReviewRuleReviewer

func (r *ReviewRuleReviewerDB) GenResp() *ReviewRuleReviewer {
	return &ReviewRuleReviewer{
		ID:               r.Id,
		RuleID:           r.RuleID,
		ReviewerRole:     r.ReviewerRole,
		AssigneePriority: r.AssigneePriority,
		EmployeeEmail:    r.EmployeeEmail,
		EmployeeName:     r.EmployeeName,
		EmployeeNumber:   r.EmployeeNumber,
		ChatToken:        r.ChatToken,
		OpenChatID:       r.OpenChatID,
		ChatName:         r.ChatName,
		ChatAvatarURL:    r.ChatAvatarURL,
		CreatedTime:      r.CreatedTime,
		UpdatedTime:      r.UpdatedTime,
		Status:           r.Status,
	}
}

func (r ReviewRuleReviewerDBList) GenResp() ReviewRuleReviewerList {
	var list ReviewRuleReviewerList
	for _, reviewer := range r {
		list = append(list, reviewer.GenResp())
	}
	return list
}

package model

// ToolOperationLogDB 工具操作日志表，对应表 tool_operation_log
// 记录通过合同执行人/创建人变更工具产生的所有操作行为。
type ToolOperationLogDB struct {
	BaseDB
	ContractID      int64  `gorm:"column:contract_id"`
	ContractNo      string `gorm:"column:contract_no"`
	OperatorEmail   string `gorm:"column:operator_email"`
	ChangeType      string `gorm:"column:change_type"`      // 变更类型
	BeforeSnapshot  string `gorm:"column:before_snapshot"`  // 变更前快照
	AfterSnapshot   string `gorm:"column:after_snapshot"`   // 变更后快照
	ApprovalChanges string `gorm:"column:approval_changes"` // 审批人变更快照
}

package model

import (
	"context"
	"encoding/json"
	"strings"
	"volc_contract_process/biz/bizmodels"

	"code.byted.org/gopkg/logs"
)

// FreshSealApprovalDB 合同加盖鲜章申请表
type FreshSealApprovalDB struct {
	BaseDB
	ApplyId        string `gorm:"column:apply_id" db:"apply_id" json:"apply_id" form:"apply_id"`                             //  申请单号，唯一标识一次申请
	AccountId      string `gorm:"column:account_id" db:"account_id" json:"account_id" form:"account_id"`                     //  申请账号 ID
	CopyCount      int    `gorm:"column:copy_count" db:"copy_count" json:"copy_count" form:"copy_count"`                     //  邮寄份数
	ContactName    string `gorm:"column:contact_name" db:"contact_name" json:"contact_name" form:"contact_name"`             //  联系人姓名
	ContactPhone   string `gorm:"column:contact_phone" db:"contact_phone" json:"contact_phone" form:"contact_phone"`         //  联系人电话
	AddressInfo    string `gorm:"column:address_info" db:"address_info" json:"address_info" form:"address_info"`             //  联系人地址
	ExpressCompany string `gorm:"column:express_company" db:"express_company" json:"express_company" form:"express_company"` //  快递公司
	ExpressNo      string `gorm:"column:express_no" db:"express_no" json:"express_no" form:"express_no"`                     //  快递单号
	ApplyReason    string `gorm:"column:apply_reason" db:"apply_reason" json:"apply_reason" form:"apply_reason"`             //  申请原因
	ContractNo     string `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                 //  申请单关联的所有合同号
	Updater        string `gorm:"column:updater" db:"updater" json:"updater" form:"updater"`                                 //  更新人
	Status         int    `gorm:"column:status" db:"status" json:"status" form:"status"`                                     //  状态：0-草稿 1-已申请 2-已邮寄
}

// GenResp 生成业务模型响应
func (db *FreshSealApprovalDB) GenResp(ctx context.Context) *bizmodels.FreshSealApplyInfo {
	//var addressInfo bizmodels.AddressInfo
	//_ = json.Unmarshal([]byte(db.AddressInfo), &addressInfo)

	// 解析地址信息
	var addressInfo bizmodels.AddressInfo
	//_ = json.Unmarshal([]byte(db.AddressInfo), &addressInfo)
	if err := json.Unmarshal([]byte(db.AddressInfo), &addressInfo); err != nil {
		logs.CtxError(ctx, "FreshSealAddressInfoUnmarshalFail, applyId: %s, err: %s", db.ApplyId, err.Error())
	}

	// 解析申请原因
	var applyReason []bizmodels.Reason
	//_ = json.Unmarshal([]byte(db.ApplyReason), &applyReason)
	if err := json.Unmarshal([]byte(db.ApplyReason), &applyReason); err != nil {
		logs.CtxError(ctx, "FreshSealApplyReasonUnmarshalFail, applyId: %s, err: %s", db.ApplyId, err.Error())
	}

	applyReasonStrSlice := make([]string, 0)
	for _, r := range applyReason {
		applyReasonStrSlice = append(applyReasonStrSlice, r.Message)
	}

	return &bizmodels.FreshSealApplyInfo{
		ApplyId:        db.ApplyId,
		AccountId:      db.AccountId,
		CopyCount:      db.CopyCount,
		ContactName:    db.ContactName,
		ContactPhone:   db.ContactPhone,
		AddressInfo:    addressInfo,
		ExpressCompany: db.ExpressCompany,
		ExpressNo:      db.ExpressNo,
		ApplyReason:    strings.Join(applyReasonStrSlice, ","),
		ContractNo:     db.ContractNo,
		Updater:        db.Updater,
		CreatedTime:    FormatTime(db.CreatedTime),
		UpdatedTime:    FormatTime(db.UpdatedTime),
		Status:         db.Status,
	}
}

type FreshSealApprovalDBList []*FreshSealApprovalDB

// GenResp 生成业务模型列表响应
//func (db *FreshSealApprovalDBList) GenResp(ctx context.Context) []*bizmodels.FreshSealApplyInfo {
//	ret := make([]*bizmodels.FreshSealApplyInfo, len(*db))
//	for i, d := range *db {
//		ret[i] = d.GenResp(ctx)
//	}
//	return ret
//}

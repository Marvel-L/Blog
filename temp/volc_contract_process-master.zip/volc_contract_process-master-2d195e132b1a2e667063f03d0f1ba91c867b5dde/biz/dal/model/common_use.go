package model

import (
	"time"
)

type CommonUseDB struct {
	BaseDB
	CommonUseKey string
	AccountID    int
	Category     string
	Content      string
	OriginTime   time.Time
	Name         string
	Size         int
}

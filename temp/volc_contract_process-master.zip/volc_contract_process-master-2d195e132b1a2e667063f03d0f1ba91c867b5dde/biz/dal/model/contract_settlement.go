package model

import (
	"time"

	"github.com/shopspring/decimal"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

// ContractSettlementDB  火山合同结算信息表
type ContractSettlementDB struct {
	BaseDB
	VolcContractID             int             `gorm:"column:volc_contract_id" db:"volc_contract_id" json:"volc_contract_id" form:"volc_contract_id"`                                                     // 合同ID
	ContractNo                 string          `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                                                                         // 合同号
	PaymentGroup               int             `gorm:"column:payment_group" db:"payment_group" json:"payment_group" form:"payment_group"`                                                                 // 付款组别
	PaymentMethod              int             `gorm:"column:payment_method" db:"payment_method" json:"payment_method" form:"payment_method"`                                                             // 付款方式
	SettlementPeriod           int             `gorm:"column:settlement_period" db:"settlement_cycle" json:"settlement_cycle" form:"settlement_cycle"`                                                    // 结算周期
	InvoicingMilepost          int             `gorm:"column:invoicing_milepost" db:"invoicing_milepost" json:"invoicing_milepost" form:"invoicing_milepost"`                                             // 开票里程碑
	InvoicingMilepostFixedTime time.Time       `gorm:"column:invoicing_milepost_fixed_time" db:"invoicing_milepost_fixed_time" json:"invoicing_milepost_fixed_time" form:"invoicing_milepost_fixed_time"` // 开票里程碑-固定时点日期
	InvoicingPercent           decimal.Decimal `gorm:"column:invoicing_percent" db:"invoicing_percent" json:"invoicing_percent" form:"invoicing_percent"`                                                 // 开票比例
	InvoicingTotal             decimal.Decimal `gorm:"column:invoicing_total" db:"invoicing_total" json:"invoicing_total" form:"invoicing_total"`                                                         // 开票金额
	PaymentMilepost            int             `gorm:"column:payment_milepost" db:"payment_milepost" json:"payment_milepost" form:"payment_milepost"`                                                     // 付款里程碑
	PaymentMilepostFixedTime   time.Time       `gorm:"column:payment_milepost_fixed_time" db:"payment_milepost_fixed_time" json:"payment_milepost_fixed_time" form:"payment_milepost_fixed_time"`         // 付款里程碑-固定时点日期
	PaymentPercent             decimal.Decimal `gorm:"column:payment_percent" db:"payment_percent" json:"payment_percent" form:"payment_percent"`                                                         // 结算比例
	PaymentTotal               decimal.Decimal `gorm:"column:payment_total" db:"payment_total" json:"payment_total" form:"payment_total"`                                                                 // 付款金额
	PaymentPeriod              int             `gorm:"column:payment_period" db:"payment_cycle" json:"payment_cycle" form:"payment_cycle"`                                                                // 付款周期
	PaymentPeriodUnit          int             `gorm:"column:payment_period_unit" db:"payment_cycle_unit" json:"payment_cycle_unit" form:"payment_cycle_unit"`                                            // 付款周期单位
	Remark                     string          `gorm:"column:remark" db:"remark" json:"remark" form:"remark"`                                                                                             // 备注
	Version                    string          `gorm:"column:version" db:"version" json:"version" form:"version"`                                                                                         // 版本
	DeploymentType             int             `gorm:"column:deployment_type" db:"deployment_type" json:"deployment_type" form:"deployment_type"`                                                         // 部署方式
	IsDeleted                  int             `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`
	IsStartUp                  int             `gorm:"column:is_start_up" db:"is_start_up" json:"is_start_up" form:"is_start_up"`
}

func (s *ContractSettlementDB) GenResp() *bizmodels.SettlementLine {

	return &bizmodels.SettlementLine{
		Id:                         s.Id,
		PaymentGroup:               s.PaymentGroup,
		PayMethod:                  s.PaymentMethod,
		SettlementPeriod:           s.SettlementPeriod,
		InvoicingMilepost:          s.InvoicingMilepost,
		InvoicingMilepostFixedTime: s.InvoicingMilepostFixedTime.Format(util.DateFormatTpl),
		InvoicingPercent:           s.InvoicingPercent.String(),
		InvoicingTotal:             s.InvoicingTotal.String(),
		PaymentMilepost:            s.PaymentMilepost,
		PaymentMilepostFixedTime:   s.PaymentMilepostFixedTime.Format(util.DateFormatTpl),
		PaymentPercent:             s.PaymentPercent.String(),
		PaymentTotal:               s.PaymentTotal.String(),
		PaymentPeriod:              s.PaymentPeriod,
		PaymentPeriodUnit:          s.PaymentPeriodUnit,
		PaymentExplain:             s.Remark,
		DeploymentType:             s.DeploymentType,
		IsStartUp:                  s.IsStartUp,
		UpdatedTime:                s.UpdatedTime.Unix(),
	}
}

func GenSettlementDBFromSettlementInfo(contractDB *ContractMetaDB,
	settlementLine *bizmodels.SettlementLine) (*ContractSettlementDB, error) {
	invoicingPercent, err := decimal.NewFromString(settlementLine.InvoicingPercent)
	if err != nil {
		return nil, errors.ErrorCommon.WithArgs(err)
	}
	invoicingTotal, err := decimal.NewFromString(settlementLine.InvoicingTotal)
	if err != nil {
		return nil, errors.ErrorCommon.WithArgs(err)
	}
	paymentPercent, err := decimal.NewFromString(settlementLine.PaymentPercent)
	if err != nil {
		return nil, errors.ErrorCommon.WithArgs(err)
	}
	paymentTotal, err := decimal.NewFromString(settlementLine.PaymentTotal)
	if err != nil {
		return nil, errors.ErrorCommon.WithArgs(err)
	}

	var paymentMilepostFixedTime time.Time
	if len(settlementLine.PaymentMilepostFixedTime) > 0 {
		paymentMilepostFixedTime, err = time.ParseInLocation(util.DateFormatTpl, settlementLine.PaymentMilepostFixedTime, time.Local)
		if err != nil {
			return nil, errors.ErrorCommon.WithArgs(err)
		}
	}

	var invoicingMilepostFixedTime time.Time
	if len(settlementLine.InvoicingMilepostFixedTime) > 0 {
		invoicingMilepostFixedTime, err = time.ParseInLocation(util.DateFormatTpl, settlementLine.InvoicingMilepostFixedTime, time.Local)
		if err != nil {
			return nil, errors.ErrorCommon.WithArgs(err)
		}
	}

	return &ContractSettlementDB{
		VolcContractID:             int(contractDB.Id),
		ContractNo:                 contractDB.ContractNo,
		PaymentGroup:               settlementLine.PaymentGroup,
		PaymentMethod:              settlementLine.PayMethod,
		SettlementPeriod:           settlementLine.SettlementPeriod,
		InvoicingMilepost:          settlementLine.InvoicingMilepost,
		InvoicingMilepostFixedTime: invoicingMilepostFixedTime,
		InvoicingPercent:           invoicingPercent,
		InvoicingTotal:             invoicingTotal,
		PaymentMilepost:            settlementLine.PaymentMilepost,
		PaymentMilepostFixedTime:   paymentMilepostFixedTime,
		PaymentPercent:             paymentPercent,
		PaymentTotal:               paymentTotal,
		PaymentPeriod:              settlementLine.PaymentPeriod,
		PaymentPeriodUnit:          settlementLine.PaymentPeriodUnit,
		Remark:                     settlementLine.PaymentExplain,
		DeploymentType:             settlementLine.DeploymentType,
	}, nil
}

func (s *ContractSettlementDB) BuildDeleteSettlementDB() *ContractSettlementDB {
	return &ContractSettlementDB{
		VolcContractID:             s.VolcContractID,
		ContractNo:                 s.ContractNo,
		PaymentGroup:               s.PaymentGroup,
		PaymentMethod:              s.PaymentMethod,
		SettlementPeriod:           s.SettlementPeriod,
		InvoicingMilepost:          s.InvoicingMilepost,
		InvoicingMilepostFixedTime: s.InvoicingMilepostFixedTime,
		InvoicingPercent:           s.InvoicingPercent,
		InvoicingTotal:             s.InvoicingTotal,
		PaymentMilepost:            s.PaymentMilepost,
		PaymentMilepostFixedTime:   s.PaymentMilepostFixedTime,
		PaymentPercent:             s.PaymentPercent,
		PaymentTotal:               s.PaymentTotal,
		PaymentPeriod:              s.PaymentPeriod,
		PaymentPeriodUnit:          s.PaymentPeriodUnit,
		Remark:                     s.Remark,
		Version:                    s.Version,
		DeploymentType:             s.DeploymentType,
		IsDeleted:                  _const.TRUE_FLAG_INT,
		IsStartUp:                  s.IsStartUp,
	}
}

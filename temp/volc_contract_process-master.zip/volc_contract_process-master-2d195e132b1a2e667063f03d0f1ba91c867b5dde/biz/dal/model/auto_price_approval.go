package model

type AutoPriceApproval struct {
	BaseDB
	ContractId         uint64 `gorm:"column:contract_id" db:"contract_id" json:"contract_id" form:"contract_id"`                                     //  合同id
	ApprovalCode       string `gorm:"column:approval_code" db:"approval_code" json:"approval_code" form:"approval_code"`                             //  审批code
	ApprovalInstanceId string `gorm:"column:approval_instance_id" db:"approval_instance_id" json:"approval_instance_id" form:"approval_instance_id"` //  审批实例id
	ApprovalURL        string `gorm:"column:approval_url" db:"approval_url" json:"approval_url" form:"approval_url"`                                 //  审批实例地址
}

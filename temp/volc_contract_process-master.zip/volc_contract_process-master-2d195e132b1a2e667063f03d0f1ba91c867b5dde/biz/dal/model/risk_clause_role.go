package model

import (
	"code.byted.org/videoarch/cloud_gopkg/models"

	"volc_contract_process/biz/bizmodels"
)

type RiskClauseRoleDB struct {
	BaseDB
	VolcContractId            int    `gorm:"column:volc_contract_id" db:"volc_contract_id" json:"volc_contract_id" form:"volc_contract_id"`                                             // meta合同元数据ID 	// 风险条款角色类型
	RiskTemplateID            int    `gorm:"column:risk_template_id" db:"risk_template_id" json:"risk_template_id" form:"risk_template_id"`                                             // 风险条款模板ID
	ApproveId                 string `gorm:"column:approve_id" db:"approve_id" json:"approve_id" form:"approve_id"`                                                                     // 审批ID
	RiskClauseType            int    `gorm:"column:risk_clause_type" db:"risk_clause_type" json:"risk_clause_type" form:"risk_clause_type"`                                             // 风险条款类型
	ContractClauseNo          string `gorm:"column:contract_clause_no" db:"contract_clause_no" json:"contract_clause_no" form:"contract_clause_no"`                                     // 风险条款编号
	ContractClauseDescription string `gorm:"column:contract_clause_description" db:"contract_clause_description" json:"contract_clause_description" form:"contract_clause_description"` // 原合同风险条款描述
	ContractClauseAnalysis    string `gorm:"column:contract_clause_analysis" db:"contract_clause_analysis" json:"contract_clause_analysis" form:"contract_clause_analysis"`             // 原合同风险条款影响分析
	RiskLevel                 string `gorm:"column:risk_level" db:"risk_level" json:"risk_level" form:"risk_level"`                                                                     // 风险等级
	Reviewer                  string `gorm:"column:reviewer" db:"reviewer" json:"reviewer" form:"reviewer"`                                                                             // 风险审批人
	ClauseMeasure             string `gorm:"column:clause_measure" db:"clause_measure" json:"clause_measure" form:"clause_measure"`                                                     // 合同责任人评估及应对措施
	Creator                   string `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                                                                 // 创建人
	IsDeleted                 int    `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                                                                     // 是否已删除，1-是 0-否
}

type RiskClauseRoleDBList []*RiskClauseRoleDB

func (s *RiskClauseRoleDB) GenResp() *bizmodels.RiskClauseRole {
	return &bizmodels.RiskClauseRole{
		Id:                        int(s.Id),
		VolcContractId:            s.VolcContractId,
		RiskTemplateID:            s.RiskTemplateID,
		ApproveId:                 s.ApproveId,
		RiskClauseType:            s.RiskClauseType,
		ContractClauseNo:          s.ContractClauseNo,
		ContractClauseDescription: s.ContractClauseDescription,
		ContractClauseAnalysis:    s.ContractClauseAnalysis,
		RiskLevel:                 s.RiskLevel,
		Reviewer:                  s.Reviewer,
		ClauseMeasure:             s.ClauseMeasure,
		Creator:                   s.Creator,
		IsDeleted:                 s.IsDeleted,
		Status:                    s.Status,
		CreatedTime:               s.CreatedTime.Format(models.DBDateFormatTpl),
		UpdatedTime:               s.UpdatedTime.Format(models.DBDateFormatTpl),
	}
}

func (s RiskClauseRoleDBList) GenResp() []*bizmodels.RiskClauseRole {
	var roleList []*bizmodels.RiskClauseRole
	for _, role := range s {
		roleList = append(roleList, role.GenResp())
	}
	return roleList
}

func (s RiskClauseRoleDBList) FetchId() []int64 {
	var ids []int64
	for _, role := range s {
		ids = append(ids, int64(role.Id))
	}
	return ids
}

type ListRiskClauseRoleReq struct {
	VolcContractId int    // 合同元数据ID
	ApproveId      string // 审批记录唯一ID
	RiskClauseType int    // 风险条款类型
	RiskLevel      string // 风险条款等级
	Status         *int   // 风险条款状态
	NeedTotal      bool   // 是否查询总数
	Limit          int    //
	Offset         int    //
}

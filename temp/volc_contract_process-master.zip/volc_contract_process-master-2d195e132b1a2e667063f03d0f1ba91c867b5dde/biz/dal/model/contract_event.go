package model

import "time"

// ContractEventDB 合同事件变更
type ContractEventDB struct {
	BaseDB
	StashKey        string    `gorm:"column:stash_key;NOT NULL"`                   // 暂存Key
	ContractID      int64     `gorm:"column:contract_id;default:0;NOT NULL"`       // 合同ID
	ContractNo      string    `gorm:"column:contract_no;NOT NULL"`                 // 合同号
	Version         int       `gorm:"column:version;default:0;NOT NULL"`           // 合同版本
	BizScene        int       `gorm:"column:biz_scene;default:0;NOT NULL"`         // 合同业务场景
	EventTypes      string    `gorm:"column:event_types;NOT NULL"`                 // 事件类型列表
	EventTimeWindow int64     `gorm:"column:event_time_window;default:0;NOT NULL"` // 事件发生时间窗口, 23091300001
	Archived        int       `gorm:"column:archived;default:0;NOT NULL"`          // 是否已归档
	EventTimestamp  time.Time `gorm:"column:event_timestamp;NOT NULL"`             // 事件发生时间
	Extra           string    `gorm:"column:extra"`                                // 事件备注信息
}

func (m *ContractEventDB) TableName() string {
	return "volc_contract_event"
}

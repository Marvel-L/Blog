package model

import (
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_FreshSealApprovalItemDB_GenResp_BitsUTGen(t *testing.T) {
	t.Run("生成响应-字段完整映射", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造完整字段的DB数据
			var id uint64 = 8888
			created := time.Date(2023, time.June, 1, 10, 20, 30, 0, time.UTC)
			updated := time.Date(2024, time.November, 15, 22, 33, 44, 0, time.UTC)
			db := &FreshSealApprovalItemDB{
				BaseDB: BaseDB{
					Id:          id,
					CreatedTime: created,
					UpdatedTime: updated,
					Status:      1,
				},
				SubApplyId:      "sub-01",
				ApplyId:         "apply-99",
				ContractId:      "contract-7",
				ContractNo:      "NO-001",
				BizSource:       3,
				SignSubjectName: "对方公司",
				Operator:        "张三",
				Status:          1, // 结构体自身的状态字段，GenResp从此处读取
			}

			// 调用待测方法
			resp := db.GenResp()
			// 通过类型断言确保返回类型正确（使用bizmodels前缀）
			var _ *bizmodels.SubApplyInfo = resp

			// 断言所有字段映射正确
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.ID, convey.ShouldEqual, id)
			convey.So(resp.SubApplyId, convey.ShouldEqual, "sub-01")
			convey.So(resp.ApplyId, convey.ShouldEqual, "apply-99")
			convey.So(resp.ContractId, convey.ShouldEqual, "contract-7")
			convey.So(resp.ContractNo, convey.ShouldEqual, "NO-001")
			convey.So(resp.BizSource, convey.ShouldEqual, 3)
			convey.So(resp.SignSubjectName, convey.ShouldEqual, "对方公司")
			convey.So(resp.Operator, convey.ShouldEqual, "张三")
			convey.So(resp.CreatedTime, convey.ShouldEqual, FormatTime(created))
			convey.So(resp.UpdatedTime, convey.ShouldEqual, FormatTime(updated))
			convey.So(resp.Status, convey.ShouldEqual, 1)
		})
	})

	t.Run("生成响应-零值与空字符串映射", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造零值与空字符串的DB数据
			var id uint64 = 0
			var zeroTime time.Time
			db := &FreshSealApprovalItemDB{
				BaseDB: BaseDB{
					Id:          id,
					CreatedTime: zeroTime,
					UpdatedTime: zeroTime,
					Status:      0,
				},
				SubApplyId:      "",
				ApplyId:         "",
				ContractId:      "",
				ContractNo:      "",
				BizSource:       0,
				SignSubjectName: "",
				Operator:        "",
				Status:          0,
			}

			// 调用待测方法
			resp := db.GenResp()
			var _ *bizmodels.SubApplyInfo = resp

			// 断言零值映射与时间格式化结果
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.ID, convey.ShouldEqual, id)
			convey.So(resp.SubApplyId, convey.ShouldEqual, "")
			convey.So(resp.ApplyId, convey.ShouldEqual, "")
			convey.So(resp.ContractId, convey.ShouldEqual, "")
			convey.So(resp.ContractNo, convey.ShouldEqual, "")
			convey.So(resp.BizSource, convey.ShouldEqual, 0)
			convey.So(resp.SignSubjectName, convey.ShouldEqual, "")
			convey.So(resp.Operator, convey.ShouldEqual, "")
			convey.So(resp.CreatedTime, convey.ShouldEqual, FormatTime(zeroTime))
			convey.So(resp.UpdatedTime, convey.ShouldEqual, FormatTime(zeroTime))
			convey.So(resp.Status, convey.ShouldEqual, 0)
		})
	})
}

func Test_FreshSealApprovalItemDBList_GenResp_BitsUTGen(t *testing.T) {
	t.Run("列表为空时返回空切片", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 空列表场景，循环不执行
			var list FreshSealApprovalItemDBList
			ret := list.GenResp()

			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(len(ret), convey.ShouldEqual, 0)
		})
	})

	t.Run("列表有两个元素时依次调用并返回对应结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造两次不同的返回结果，验证顺序与长度
			expected1 := &bizmodels.SubApplyInfo{ID: 1, ApplyId: "A1"}
			expected2 := &bizmodels.SubApplyInfo{ID: 2, ApplyId: "A2"}

			mockey.MockUnsafe((*FreshSealApprovalItemDB).GenResp).Return(
				mockey.Sequence(expected1).Then(expected2),
			).Build()

			list := FreshSealApprovalItemDBList{
				&FreshSealApprovalItemDB{ApplyId: "A1"},
				&FreshSealApprovalItemDB{ApplyId: "A2"},
			}
			ret := list.GenResp()

			convey.So(ret, convey.ShouldNotBeNil)
			convey.So(len(ret), convey.ShouldEqual, 2)
			convey.So(ret[0], convey.ShouldEqual, expected1)
			convey.So(ret[1], convey.ShouldEqual, expected2)
		})
	})
}

package model

import (
	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
)

type PreContractReviewerDB struct {
	BaseDB
	PreContractNo    string `gorm:"column:pre_contract_no" db:"pre_contract_no" json:"pre_contract_no" form:"pre_contract_no"`
	Reviewer         string `gorm:"column:reviewer" db:"reviewer" json:"reviewer" form:"reviewer"`
	ReviewerID       string `gorm:"column:reviewer_id" db:"reviewer_id" json:"reviewer_id" form:"reviewer_id"`
	Department       string `gorm:"column:department" db:"department" json:"department" form:"department"` // 销售归属行业(中文名) 对应 volc_contract_meta.basic_info 的 Department 字段
	ReviewerType     int    `gorm:"column:reviewer_type" db:"reviewer_type" json:"reviewer_type" form:"reviewer_type"`
	ReviewerRole     int    `gorm:"column:reviewer_role" db:"reviewer_role" json:"reviewer_role" form:"reviewer_role"`                     // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP 0 其他
	ReviewerSource   int    `gorm:"column:reviewer_source" db:"reviewer_source" json:"reviewer_source" form:"reviewer_source"`             // 审核人登记：主审核人：0，加签审核人：1
	ContractStatus   int    `gorm:"column:contract_status" db:"contract_status" json:"contract_status" form:"contract_status"`             // 合同节点
	Priority         int    `gorm:"column:priority" db:"priority" json:"priority" form:"priority"`                                         // 优先级
	IsDeleted        int    `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                                 // 是否已删除，1-是 0-否
	SkipReturnReview int    `gorm:"column:skip_return_review" db:"skip_return_review" json:"skip_return_review" form:"skip_return_review"` // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重
}

type PreContractReviewerDBList []*PreContractReviewerDB

// type PreContractReviewer struct {
//	Reviewer         string // 审批人员邮箱
//	ReviewerName     string `json:"ReviewerName,omitempty"` //
//	AvatarURL        string `json:"AvatarURL,omitempty"`    //
//	ReviewerID       string // 审批人员工号
//	ReviewerType     int    // 人员类型 -1 无效角色 0 销售 1 销售运营 2 财税法审核 3 管理员 4 被艾特人员 5 有浏览权限
//	ReviewerSource   int    // 审核人登记：主审核人：0，加签审核人：1
//	ReviewerRole     int    // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP 0 其他
//	ContractStatus   int    // 合同节点
//	Priority         int    // 优先级
//	IsDeleted        int    // 是否被删除
//	Status           int    // 注意该字段展示给前端及流转过程中 可能已经过fix
//	SkipReturnReview int    // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重审
// }

// type PreContractReviewerList []*PreContractReviewer

func (db *PreContractReviewerDB) GenResp() *bizmodels.PreContractReviewer {
	status := db.fixStatus()
	return &bizmodels.PreContractReviewer{
		ID:               db.Id,
		Reviewer:         db.Reviewer,
		ReviewerType:     db.ReviewerType,
		ReviewerID:       db.ReviewerID,
		Status:           status,
		ContractStatus:   db.ContractStatus,
		ReviewerSource:   db.ReviewerSource,
		ReviewerRole:     db.ReviewerRole,
		Priority:         db.Priority,
		IsDeleted:        db.IsDeleted,
		SkipReturnReview: db.SkipReturnReview,
	}
}

func (db *PreContractReviewerDB) fixStatus() int {
	switch db.Status {
	case _const.ReviewStatusUnreviewed, //
		_const.ReviewStatusReviewPass,     // 通过
		_const.ReviewStatusReviewWithdraw, // 撤回
		_const.ReviewStatusChangeReviewer: // 转办
		return db.Status
	}
	return _const.ReviewStatusUnreviewed
}

func (db *PreContractReviewerDBList) GenResp() bizmodels.PreContractReviewerList {
	ret := make(bizmodels.PreContractReviewerList, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

func (db *PreContractReviewerDBList) GetHighestPriorityReviewers() PreContractReviewerDBList {
	// 取审核优先级最高的未审核人员
	var (
		highestPriority = 0
		priorityMapping = map[int]PreContractReviewerDBList{}
	)
	for _, reviewer := range *db {
		priority := reviewer.Priority
		if priority > highestPriority {
			highestPriority = priority
		}
		priorityMapping[priority] = append(priorityMapping[priority], reviewer)
	}

	return priorityMapping[highestPriority]
}

type Reviewer struct {
	Reviewer   string
	ReviewerID string
}

type ListPreContractReviewerReq struct {
	PreContractNo  string
	ReviewerType   int
	ContractStatus int
	Priority       int
}

type UpdateReviewerStatusReq struct {
	Reviewer         string // 审批人
	PreContractNO    string // 合同号
	ReviewerType     int    // 审批节点类型
	ContractStatus   int    // 协商状态
	Status           int    // 更新后的状态
	SkipReturnReview int    // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重审
}

type ResetReviewerStatusByReviewerTypeReq struct {
	PreContractNO                 string   // 合同号
	ReviewerType                  int      // 审批节点类型
	ContractStatus                int      // 协商状态
	SkipReturnReviewNoAuditEmails []string // 返稿场景不需要审批的人员列表
}

type ReplaceReviewerByOldInfoReq struct {
	PreContractNo    string
	OldReviewerEmail string
	OldReviewerID    string
	NewReviewerEmail string
	NewReviewerID    string
	ContractStatus   *int
}

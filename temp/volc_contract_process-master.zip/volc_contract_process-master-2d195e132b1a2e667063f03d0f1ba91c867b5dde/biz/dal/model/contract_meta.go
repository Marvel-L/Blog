package model

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"code.byted.org/security/dkms-gorm/encrypt_type"

	"volc_contract_process/pkg/proxy/accountcli"

	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/util"
)

// ContractMetaDB  火山合同元数据表
// todo: `gorm:"-"`
type ContractMetaDB struct {
	BaseDB
	BizScene                    int                         `gorm:"column:biz_scene" db:"biz_scene" json:"biz_scene" form:"biz_scene"`                                                                                     //  业务场景
	BizSource                   int                         `gorm:"column:biz_source" db:"biz_source" json:"biz_source" form:"biz_source"`                                                                                 //  合同来源
	OAAppID                     string                      `gorm:"column:oa_app_id" db:"oa_app_id" json:"oa_app_id" form:"oa_app_id"`                                                                                     //  oa_app_id
	ContractNo                  string                      `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                                                                             //  合同号
	OaContractNo                string                      `gorm:"column:oa_contract_no" db:"oa_contract_no" json:"oa_contract_no" form:"oa_contract_no"`                                                                 //  OA合同号
	VolcContractNo              string                      `gorm:"column:volc_contract_no" db:"volc_contract_no" json:"volc_contract_no" form:"volc_contract_no"`                                                         //  OA合同号
	PreContractNo               string                      `gorm:"column:pre_contract_no" db:"pre_contract_no" json:"pre_contract_no" form:"pre_contract_no"`                                                             //  临时合同号
	MainContractNo              string                      `gorm:"column:main_contract_no" db:"main_contract_no" json:"main_contract_no" form:"main_contract_no"`                                                         //  主合同号
	FromContractNo              string                      `gorm:"column:from_contract_no" db:"from_contract_no" json:"from_contract_no" form:"from_contract_no"`                                                         //  原合同号
	Version                     int                         `gorm:"column:version" db:"version" json:"version" form:"version"`                                                                                             //  合同版本
	SupplyScene                 int                         `gorm:"column:supply_scene" db:"supply_scene" json:"supply_scene" form:"supply_scene"`                                                                         //  补充协议类型
	SupplySource                string                      `gorm:"column:supply_source" db:"supply_source" json:"supply_source" form:"supply_source"`                                                                     //  补充协议场景
	ContractName                string                      `gorm:"column:contract_name" db:"contract_name" json:"contract_name" form:"contract_name"`                                                                     //  合同名称
	SubjectName                 string                      `gorm:"column:subject_name" db:"subject_name" json:"subject_name" form:"subject_name"`                                                                         //  我方名称
	SubjectNo                   string                      `gorm:"column:subject_no" db:"subject_no" json:"subject_no" form:"subject_no"`                                                                                 //  主体编码,多个逗号分隔
	OtherPartyName              string                      `gorm:"column:other_party_name" db:"other_party_name" json:"other_party_name" form:"other_party_name"`                                                         //  对方名称
	Operator                    string                      `gorm:"column:operator" db:"operator" json:"operator" form:"operator"`                                                                                         //  业务执行人工号
	OperatorNew                 string                      `gorm:"column:operator_new" db:"operator_new" json:"operator_new" form:"operator_new"`                                                                         //  业务执行人工号
	RelatedPersonnel            string                      `gorm:"column:related_personnel" db:"related_personnel" json:"related_personnel" form:"related_personnel"`                                                     //  相关人工号
	Creator                     string                      `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                                                                             //  创建人工号
	CreatorNew                  string                      `gorm:"column:creator_new" db:"creator_new" json:"creator_new" form:"creator_new"`                                                                             //  创建人工号
	PropertyCode                string                      `gorm:"column:property_code" db:"property_code" json:"property_code" form:"property_code"`                                                                     //  合同性质
	CategoryNo                  string                      `gorm:"column:category_no" db:"category_no" json:"category_no" form:"category_no"`                                                                             //  合同类型编码
	SignatureType               string                      `gorm:"column:signature_type" db:"signature_type" json:"signature_type" form:"signature_type"`                                                                 //  签约形式
	InOutType                   string                      `gorm:"column:in_out_type" db:"in_out_type" json:"in_out_type" form:"in_out_type"`                                                                             //  收支类型
	SubmitTime                  time.Time                   `gorm:"column:submit_time" db:"submit_time" json:"submit_time" form:"submit_time"`                                                                             //  提交时间
	VersionCreatedTime          time.Time                   `gorm:"column:version_created_time" db:"version_created_time" json:"version_created_time" form:"version_created_time"`                                         //  版本创建时间
	SignTime                    time.Time                   `gorm:"column:sign_time" db:"sign_time" json:"sign_time" form:"sign_time"`                                                                                     //  sign_time
	FileTime                    time.Time                   `gorm:"column:file_time" db:"file_time" json:"file_time" form:"file_time"`                                                                                     //  file_time
	FinishTime                  time.Time                   `gorm:"column:finish_time" db:"finish_time" json:"finish_time" form:"finish_time"`                                                                             //  file_time
	Initiator                   int                         `gorm:"column:initiator" db:"initiator" json:"initiator" form:"initiator"`                                                                                     //  发起端
	CooperationStatus           int                         `gorm:"column:cooperation_status" db:"cooperation_status" json:"cooperation_status" form:"cooperation_status"`                                                 //  协商状态，不同业务系统不同
	PreCooperationStatus        int                         `gorm:"column:pre_cooperation_status" db:"pre_cooperation_status" json:"pre_cooperation_status" form:"pre_cooperation_status"`                                 //  前序协商状态，不同业务系统不同
	ArchivedStatus              int                         `gorm:"column:archived_status" db:"archived_status" json:"archived_status" form:"archived_status"`                                                             //  归档状态，0-未归档  1-已归档
	ActiveStatus                int                         `gorm:"column:active_status" db:"active_status" json:"active_status" form:"active_status"`                                                                     //  生效状态，0-未生效，1-生效中，2-已过期
	BeginTime                   time.Time                   `gorm:"column:begin_time" db:"begin_time" json:"begin_time" form:"begin_time"`                                                                                 //  开始时间
	EndTime                     time.Time                   `gorm:"column:end_time" db:"end_time" json:"end_time" form:"end_time"`                                                                                         //  结束时间
	SubjectAccountIds           string                      `gorm:"column:subject_account_ids" db:"subject_account_ids" json:"subject_account_ids" form:"subject_account_ids"`                                             //  主体账号id,多个逗号分隔
	SealAccountIDs              string                      `gorm:"column:seal_account_ids" db:"seal_account_ids" json:"seal_account_ids" form:"seal_account_ids"`                                                         //  盖章账号id,多个逗号分隔
	PricingAccountIDs           string                      `gorm:"column:pricing_account_ids" db:"pricing_account_ids" json:"pricing_account_ids" form:"pricing_account_ids"`                                             //  盖章账号id,多个逗号分隔
	Product                     string                      `gorm:"column:product" db:"product" json:"product" form:"product"`                                                                                             //  product
	Finance                     string                      `gorm:"column:finance" db:"finance" json:"finance" form:"finance"`                                                                                             //  finance
	BasicInfo                   string                      `gorm:"column:basic_info" db:"basic_info" json:"basic_info" form:"basic_info"`                                                                                 //  基本信息
	ProjectInfo                 string                      `gorm:"column:project_info" db:"project_info" json:"project_info" form:"project_info"`                                                                         //  项目信息
	ManageInfo                  string                      `gorm:"-"`                                                                                                                                                     //  管理信息
	TradePartyInfo              string                      `gorm:"column:trade_party_info;type:text" db:"trade_party_info" json:"trade_party_info" form:"trade_party_info" kms:"double_write:EncryptTradePartyInfo"`      //  交易双方信息
	UrgentInfo                  string                      `gorm:"column:urgent_info" db:"urgent_info" json:"urgent_info" form:"urgent_info"`                                                                             //  紧急信息
	ExpireRemindInfo            string                      `gorm:"column:expire_remind_info" db:"expire_remind_info" json:"expire_remind_info" form:"expire_remind_info"`                                                 //  过期提醒信息
	EncryptTradePartyInfo       *encrypt_type.EncryptString `gorm:"column:encrypt_trade_party_info;type:text" dkmsId:"eps.platform.volc_contract_dkms_siv" encodeFormat:"base64"`                                          //  加密交易双方信息
	ReverseSignInfo             string                      `gorm:"column:reverse_sign_info" db:"reverse_sign_info" json:"reverse_sign_info" form:"reverse_sign_info"`                                                     //  倒签原因信息
	SettlementInfo              string                      `gorm:"-"`                                                                                                                                                     //  结算信息
	DiscountInfo                string                      `gorm:"column:discount_info" db:"discount_info" json:"discount_info" form:"discount_info"`                                                                     //  折扣信息
	ContractProductInfo         string                      `gorm:"column:contract_product_info" db:"contract_product_info" json:"contract_product_info" form:"contract_product_info"`                                     //  合同产品信息
	TemplateInfo                string                      `gorm:"column:template_info" db:"template_info" json:"template_info" form:"template_info"`                                                                     //  合同关联模板信息
	ContractAttachment          string                      `gorm:"column:contract_attachment" db:"contract_attachment" json:"contract_attachment" form:"contract_attachment"`                                             //  附件信息
	ContractFile                string                      `gorm:"column:contract_file" db:"contract_file" json:"contract_file" form:"contract_file"`                                                                     //  合同文本
	ContractTemplateVersion     string                      `gorm:"column:contract_template_version" db:"contract_template_version" json:"contract_template_version" form:"contract_template_version"`                     //  合同文本
	IsBackdating                int                         `gorm:"column:is_backdating" db:"is_backdating" json:"is_backdating" form:"is_backdating"`                                                                     //  1 主合同 0 非主合同
	IsMainContract              int                         `gorm:"column:is_main_contract" db:"is_main_contract" json:"is_main_contract" form:"is_main_contract"`                                                         //  1 主合同 0 非主合同
	Remark                      string                      `gorm:"column:remark" db:"remark" json:"remark" form:"remark"`                                                                                                 //  备注
	RequestId                   string                      `gorm:"column:request_id" db:"request_id" json:"request_id" form:"request_id"`                                                                                 //  请求id
	CheckCode                   string                      `gorm:"column:check_code" db:"check_code" json:"check_code" form:"check_code"`                                                                                 //  校验码
	ContractId                  string                      `gorm:"column:contract_id" db:"contract_id" json:"contract_id" form:"contract_id"`                                                                             //  contract id
	FileIdSigned                string                      `gorm:"column:file_id_signed" db:"file_id_signed" json:"file_id_signed" form:"file_id_signed"`                                                                 //  contract id
	FileIdUnsigned              string                      `gorm:"column:file_id_unsigned" db:"file_id_unsigned" json:"file_id_unsigned" form:"file_id_unsigned"`                                                         //  contract id
	IsNewest                    int                         `gorm:"column:is_newest" db:"is_newest" json:"is_newest" form:"is_newest"`                                                                                     //  1 最新 0 旧版, 99%为新版
	OfacUrl                     string                      `gorm:"column:ofac_url" db:"ofac_url" json:"ofac_url" form:"ofac_url"`                                                                                         //  ofac_url, 目前为空
	FinanceSubject              string                      `gorm:"column:finance_subject" db:"finance_subject" json:"finance_subject" form:"finance_subject"`                                                             //  finance_subject
	BizIdentifier               string                      `gorm:"column:biz_identifier" db:"biz_identifier" json:"biz_identifier" form:"biz_identifier"`                                                                 //  业务系统唯一标识
	CRMKey                      string                      `gorm:"column:crm_key" db:"crm_key" json:"crm_key" form:"crm_key"`                                                                                             //  业务系统唯一标识
	BizAccountID                int64                       `gorm:"column:biz_account_id" db:"biz_account_id" json:"biz_account_id" form:"biz_account_id"`                                                                 //  业务合同账号ID
	BizData                     string                      `gorm:"column:biz_data;type:text" db:"biz_data" json:"biz_data" form:"biz_data" kms:"double_write:EncryptBizData"`                                             //  业务信息 	//  业务信息
	EncryptBizData              *encrypt_type.EncryptString `gorm:"column:encrypt_biz_data;type:text" dkmsId:"eps.platform.volc_contract_dkms_siv" encodeFormat:"base64"`                                                  //  加密业务信息
	OpenChatID                  string                      `gorm:"column:open_chat_id" db:"open_chat_id" json:"open_chat_id" form:"open_chat_id"`                                                                         //  飞书群ID
	RelateQuoteNo               string                      `gorm:"column:relate_quote_no" db:"relate_quote_no" json:"relate_quote_no" form:"relate_quote_no"`                                                             //  关联报价单号
	RelateQuoteScene            int                         `gorm:"column:relate_quote_scene" db:"relate_quote_scene" json:"relate_quote_scene" form:"relate_quote_scene"`                                                 //  关联报价单号
	ContractPriceRepeatInfo     string                      `gorm:"column:contract_price_repeat_info" db:"contract_price_repeat_info" json:"contract_price_repeat_info" form:"contract_price_repeat_info"`                 //  合同价重复列表
	ContractPriceCreatedTime    time.Time                   `gorm:"column:contract_price_created_time" db:"contract_price_created_time" json:"contract_price_created_time" form:"contract_price_created_time"`             //  合同价创建时间
	FromContractTerminatedTime  time.Time                   `gorm:"column:from_contract_terminated_time" db:"from_contract_terminated_time" json:"from_contract_terminated_time" form:"from_contract_terminated_time"`     //  原合同终止日期
	CooperationStatusChangeTime time.Time                   `gorm:"column:cooperation_status_change_time" db:"cooperation_status_change_time" json:"cooperation_status_change_time" form:"cooperation_status_change_time"` //  协商状态变更时间
	IsDeleted                   int                         `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                                                                                 //  删除标记
	IsUrgent                    int                         `gorm:"column:is_urgent" db:"is_urgent" json:"is_urgent" form:"is_urgent"`                                                                                     //  是否是加急合同
	CurVersionFrom              string                      `gorm:"column:cur_version_from" db:"cur_version_from" json:"cur_version_from" form:"cur_version_from"`                                                         //  数据来源
	ValidityChangeDetail        string                      `gorm:"column:validity_change_detail" db:"validity_change_detail" json:"validity_change_detail" form:"validity_change_detail"`                                 //  结算条款信息
	SettlementClause            string                      `gorm:"column:settlement_clause" db:"settlement_clause" json:"settlement_clause" form:"settlement_clause"`                                                     //  结算条款信息
	IsContainRefundClause       int                         `gorm:"column:is_contain_refund_clause" db:"is_contain_refund_clause" json:"is_contain_refund_clause" form:"is_contain_refund_clause"`                         //  是否包含退款条款
	SpecialContractType         string                      `gorm:"column:special_contract_type" db:"special_contract_type" json:"special_contract_type" form:"special_contract_type"`                                     //  特殊合同类型
	PrincipalParty              string                      `gorm:"column:principal_party" db:"principal_party" json:"principal_party" form:"principal_party"`                                                             //  委托方
	EntrustedParty              string                      `gorm:"column:entrusted_party" db:"entrusted_party" json:"entrusted_party" form:"entrusted_party"`                                                             //  被委托方
	PerformFlag                 int                         `gorm:"column:perform_flag" db:"perform_flag" json:"perform_flag" form:"perform_flag"`                                                                         //  是否由履约调度
	ExpireRemindFlag            int                         `gorm:"column:expire_remind_flag" db:"expire_remind_flag" json:"expire_remind_flag" form:"expire_remind_flag"`                                                 //  是否需要过期提醒
	FreshSealApprovalNo         string                      `gorm:"column:fresh_seal_approval_no" db:"fresh_seal_approval_no" json:"fresh_seal_approval_no" form:"fresh_seal_approval_no"`                                 // 纸质鲜章申请单号
}

// ContractMeta  火山合同元数据表
type ContractMeta struct {
	ID                   uint64
	BizScene             int    //  业务场景
	BizSource            int    //  合同来源
	OAAppID              string //  oa_app_id
	ContractNo           string //  合同号
	OaContractNo         string //  OA合同号
	PreContractNo        string //  临时合同号
	VolcContractNo       string // 火山合同号
	MainContractNo       string //  主合同号
	FromContractNo       string //  原合同号
	Version              int    //  合同版本
	SupplyScene          int    //  补充协议类型
	SupplySource         string // 补充协议场景
	ContractName         string //  合同名称
	SubjectName          string //  我方名称
	SubjectNo            string //  主体编码,多个逗号分隔
	OtherPartyName       string //  对方名称
	Operator             string //  业务执行人工号
	OperatorNew          string //  业务执行人工号
	RelatedPersonnel     string //  相关人工号
	Creator              string //  创建人工号
	CreatorNew           string //  创建人工号
	PropertyCode         string //  合同性质
	CategoryNo           string //  合同类型编码
	SignatureType        string //  签约形式
	InOutType            string //  收支类型
	SubmitTime           string //  提交时间
	SubmitTimeWithTZ     string //  提交时间
	SignTime             string //  sign_time
	SignTimeWithTZ       string //  sign_time
	FileTime             string //  file_time
	FileTimeWithTZ       string //  file_time
	FinishTime           string //  file_time
	FinishTimeWithTZ     string //  file_time
	Initiator            int    //  发起端
	CooperationStatus    int    //  协商状态，不同业务系统不同
	PreCooperationStatus int    //  前置协商状态，不同业务系统不同
	ArchivedStatus       int    //  归档状态，0-未归档  1-已归档
	ActiveStatus         int    //  生效状态，0-未生效，1-生效中，2-已过期
	BeginTime            string //  开始时间
	BeginTimeWithTZ      string //  开始时间
	EndTime              string //  结束时间
	EndTimeWithTZ        string //  结束时间
	SubjectAccountIds    string //  主体账号id,多个逗号分隔
	SealAccountIDs       string // 签约账号
	PricingAccountIDs    string // 配价账号
	Product              string //  product
	Finance              string //  finance
	DiscountInfo         string //  折扣信息
	BasicInfo            *bizmodels.BasicInfo
	ProjectInfo          *bizmodels.ProjectInfo
	ManageInfo           *bizmodels.ManageInfo
	TradePartyInfo       *bizmodels.TradePartyInfo
	ReverseSignInfo      *bizmodels.ReverseSignInfo
	TemplateInfo         *bizmodels.TemplateInfo //  模板信息
	SettlementInfo       *bizmodels.SettlementInfo
	BusinessModeClauses  []*bizmodels.BusinessModeClause // 商务模式条款摘要
	ContractProductInfo  *bizmodels.ContractProductInfo
	UrgentInfo           *bizmodels.UrgentInfo       // 加急信息
	ExpireRemindInfo     *bizmodels.ExpireRemindInfo //  过期提醒信息
	ContractAttachment   string
	ContractFile         string //  合同文本
	IsBackdating         int    //  1 主合同 0 非主合同
	IsMainContract       bool   // 是否为主合同
	Remark               string //  备注
	RequestId            string //  请求id
	CheckCode            string //  校验码
	ContractId           string //  contract id
	FileIdSigned         string //  contract id
	FileIdUnsigned       string //  contract id
	IsNewest             int    //  1 最新 0 旧版, 99%为新版
	OfacUrl              string //  ofac_url, 目前为空
	FinanceSubject       string //  finance_subject
	BizIdentifier        string //  业务系统唯一标识
	CRMKey               string //  业务系统唯一标识
	BizAccountID         int64  //  业务合同账号ID
	BizData              string //  业务数据
	OpenChatID           string //  飞书群ID
	RelateQuoteNo        string //  关联报价单号
	RelateQuoteScene     int    // 关联报价单场景

	ContractPriceRepeatInfo     *bizmodels.ContractPriceRepeatInfo // 合同价重复信息
	ContractPriceCreatedTime    string                             //  合同价创建时间
	FromContractTerminatedTime  string                             //  原合同终止日期
	CooperationStatusChangeTime string                             // 协商状态变更时间
	IsDeleted                   int                                //  删除标记
	IsUrgent                    int                                // 是否加急
	ExpireRemindFlag            int                                // 合同到期后是否提醒
	CurVersionFrom              string                             //  数据来源
	Reviewers                   bizmodels.PreContractReviewerList  // 审批人列表
	Role                        int                                // 当前操作人角色
	CanApproval                 bool                               // 是否可以审批
	CurrentReviewSource         int
	// OnlineContract             string
	// RequestID                  string
	OnlineContract           string
	RequireQuote             bool   // 是否需要关联报价单
	RelateQuoteChangedNotify bool   // 报价单发生变更，当前用户是否需要弹窗
	RelateQuoteChanged       bool   // 报价单发生变更
	RelateQuoteChangedBefore string // 变更前报价单
	QuoteItemOfflineInfo     string // 报价单条目下架信息
	CreatedTime              string
	CreatedTimeWithTZ        string
	UpdatedTime              string
	UpdatedTimeWithTZ        string
	Status                   int
	NeedCreateGroupChat      bool
	SupplementInfoList       *bizmodels.SupplementInfoList //
	IsShowSupplyWin          bool                          // 是否展示补充协议列表
	FromContractStartTime    string                        // 原合同有效期开始时间
	FromContractEndTime      string                        // 原合同有效期结束时间
	MainContractStartTime    string                        // 主合同有效期开始时间
	MainContractEndTime      string                        // 主合同有效期结束时间
	ValidityChangeDetail     string                        // 有效期变更详情
	SettlementClause         string                        // 结算条款信息
	IsContainRefundClause    int                           // 是否包含退款条款
	Ext                      map[string]string             // 合同附加信息
	RiskClauseList           []*bizmodels.RiskClauseRole   // 合同附加信息
	CurrentFilePermission    int                           // 当前操作人访问合同文本权限
}

func (p *ContractMeta) GetProductSolutionEmails() []string {
	if p.ProjectInfo == nil {
		return nil
	}
	emails := p.ProjectInfo.GetProductSolutionEmail()
	if emails == "" {
		return nil
	}
	return strings.Split(emails, ",")
}

func (p *ContractMeta) GetDeliveryStaffEmails() []string {
	if p.ProjectInfo == nil {
		return nil
	}
	emails := p.ProjectInfo.GetDeliveryStaff()
	if emails == "" {
		return nil
	}
	return strings.Split(emails, ",")
}

// 关联报价单场景=已完成报价审批时，必须关联
func (p *ContractMeta) NeedRelateQuoteNo() bool {
	if p.RelateQuoteScene == _const.RelateQuoteSceneCompleted {
		return true
	}
	return false
}

// 关联报价单场景=已完成报价审批时，必须关联
func (p *ContractMetaDB) NeedRelateQuoteNo() bool {
	if p.RelateQuoteScene == _const.RelateQuoteSceneCompleted {
		return true
	}
	return false
}

// type SupplementInfoList struct {
//	VolcHistory []*SupplyInfo
//	OAHistory   []*SupplyInfo
// }

// type SupplyInfo struct {
//	ContractNo                 string // 火山合同号
//	VolcContractNo             string // 火山补充合同号
//	FromContractNo             string // 原合同号
//	ContractName               string // 合同名称
//	SupplyScene                int    // 补充协议类型
//	SupplySource               string // 补充协议场景
//	SubmitTime                 string // 提交日期
//	FromContractTerminatedTime string // 原协议终止日期
//	CooperationStatus          int    // 协商状态，不同业务系统不同
//	Status                     int    // 状态
//	OAContractDownloadID       string // OA扫描版合同-已盖章
//	UploadContractDownloadID   string // 用户上传原始合同
//	ArchivedStatus             int    // 归档状态，0-未归档  1-已归档
//	RelateQuoteNo              string // 关联报价单号
//	FileTime                   string // 归档日期
//	// DownloadID                 string //
// }

// GetSupplySource 获取补充场景
func (c *ContractMetaDB) GetSupplySource() []string {
	return util.SingleList(strings.Split(c.SupplySource, ","))
}

func (c *ContractMetaDB) CalcActiveStatus() int {
	if c.ArchivedStatus != _const.ContractArchived {
		return c.ActiveStatus
	}
	// 结束时间非空，且当前时间大于结束时间，则为已过期
	if !c.EndTime.IsZero() && c.EndTime.Unix() > 0 && time.Now().After(c.EndTime) {
		return _const.ActiveStatusExpired
	} else if time.Now().After(c.BeginTime) {
		return _const.ActiveStatusInForce
	}
	return c.ActiveStatus
}

func (c *ContractMetaDB) CalcFinalType() int {
	// 正向终态
	if util.IntIn(c.ArchivedStatus, _const.PositiveFinalArchivedStatus) {
		return _const.FinalTypePositive
	}
	// 逆向终态
	if util.IntIn(c.CooperationStatus, _const.ReverseFinalCooperationStatus) ||
		util.IntIn(c.Status, _const.ReverseFinalContractStatus) ||
		util.IntIn(c.ActiveStatus, _const.ReverseFinalActiveStatus) {
		return _const.FinalTypeReverse
	}
	// 非终态即在途
	return _const.FinalTypeInProcess
}

type ContractMetaDBList []*ContractMetaDB

// GenResp GenResp
func (db *ContractMetaDBList) GenResp(ctx context.Context) ContractMetaList {
	ret := make([]*ContractMeta, len(*db))
	for i, d := range *db {
		contract := d.GenResp()
		contract.ParseAccountCreateSource(ctx)
		ret[i] = contract
	}
	return ret
}

type ContractMetaList []*ContractMeta

// GenResp GenResp
func (db *ContractMetaDB) GenResp() *ContractMeta {
	basicInfo := &bizmodels.BasicInfo{}
	_ = json.Unmarshal([]byte(db.BasicInfo), &basicInfo)
	projectInfo := &bizmodels.ProjectInfo{}
	_ = json.Unmarshal([]byte(db.ProjectInfo), &projectInfo)
	manageInfo := &bizmodels.ManageInfo{}
	_ = json.Unmarshal([]byte(db.ManageInfo), &manageInfo)
	tradePartyInfo := &bizmodels.TradePartyInfo{}
	_ = json.Unmarshal([]byte(db.TradePartyInfo), &tradePartyInfo)
	reverseSignInfo := &bizmodels.ReverseSignInfo{}
	_ = json.Unmarshal([]byte(db.ReverseSignInfo), &reverseSignInfo)
	// settlementInfo := &SettlementInfo{}
	// _ = json.Unmarshal([]byte(db.SettlementInfo), &settlementInfo)
	contractProductInfo := &bizmodels.ContractProductInfo{}
	_ = json.Unmarshal([]byte(db.ContractProductInfo), &contractProductInfo)
	priceRepeatInfo := &bizmodels.ContractPriceRepeatInfo{}
	_ = json.Unmarshal([]byte(db.ContractPriceRepeatInfo), priceRepeatInfo)
	templateInfo := &bizmodels.TemplateInfo{}
	_ = json.Unmarshal([]byte(db.TemplateInfo), &templateInfo)
	urgentInfo := &bizmodels.UrgentInfo{}
	_ = json.Unmarshal([]byte(db.UrgentInfo), &urgentInfo)
	expireRemindInfo := &bizmodels.ExpireRemindInfo{}
	_ = json.Unmarshal([]byte(db.ExpireRemindInfo), &expireRemindInfo)

	if tradePartyInfo.OtherParty == nil {
		tradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{}
	}
	if tradePartyInfo.Subject == nil {
		tradePartyInfo.Subject = []*bizmodels.TradePartyInfoDetail{}
	}
	var accountIDs []string
	for _, v := range tradePartyInfo.OtherParty {
		if v.PayTypes == nil {
			v.PayTypes = []*bizmodels.PayType{}
		}
		if v.OpAddress == nil {
			v.OpAddress = []bizmodels.OpAddress{}
		}
		subAccountIds := strings.Split(v.AccountID, ",")
		accountIDs = append(accountIDs, util.SingleList(subAccountIds)...)
	}
	for _, v := range tradePartyInfo.Subject {
		if v.PayTypes == nil {
			v.PayTypes = []*bizmodels.PayType{}
		}
		if v.OpAddress == nil {
			v.OpAddress = []bizmodels.OpAddress{}
		}
	}
	if basicInfo.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		basicInfo.UsefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
		basicInfo.IndefiniteDateFlag = _const.BizNo
	}

	ret := &ContractMeta{
		ID:                   db.Id,
		BizScene:             db.BizScene,
		BizSource:            db.BizSource,
		OAAppID:              db.OAAppID,
		Initiator:            db.Initiator,
		ContractNo:           db.ContractNo,
		OaContractNo:         db.OaContractNo,
		Version:              db.Version,
		SubjectNo:            db.SubjectNo,
		CooperationStatus:    db.CooperationStatus,
		PreCooperationStatus: db.PreCooperationStatus,
		RelatedPersonnel:     db.RelatedPersonnel,
		SignatureType:        db.SignatureType,
		SignTime:             FormatTime(db.SignTime),
		SignTimeWithTZ:       FormatTime3339(db.SignTime),
		FileTime:             FormatTime(db.FileTime),
		FileTimeWithTZ:       FormatTime3339(db.FileTime),
		FinishTime:           FormatTime(db.FinishTime),
		FinishTimeWithTZ:     FormatTime3339(db.FinishTime),
		PreContractNo:        db.PreContractNo,
		VolcContractNo:       db.VolcContractNo,
		MainContractNo:       db.MainContractNo,
		FromContractNo:       db.FromContractNo,
		SupplyScene:          db.SupplyScene,
		SupplySource:         db.SupplySource,
		ContractName:         db.ContractName,
		SubjectName:          db.SubjectName,
		OtherPartyName:       db.OtherPartyName,
		SubjectAccountIds:    strings.Join(accountIDs, ","),
		Operator:             db.Operator,
		Creator:              db.Creator,
		OperatorNew:          db.OperatorNew,
		CreatorNew:           db.CreatorNew,
		PropertyCode:         db.PropertyCode,
		CategoryNo:           db.CategoryNo,
		InOutType:            db.InOutType,
		SubmitTime:           FormatTime(db.SubmitTime),
		SubmitTimeWithTZ:     FormatTime3339(db.SubmitTime),
		BeginTime:            FormatTime(db.BeginTime),
		BeginTimeWithTZ:      FormatTime3339(db.BeginTime),
		EndTime:              FormatTime(db.EndTime),
		EndTimeWithTZ:        FormatTime3339(db.EndTime),
		BasicInfo:            basicInfo,
		ProjectInfo:          projectInfo,
		ManageInfo:           manageInfo,
		TradePartyInfo:       tradePartyInfo,
		ReverseSignInfo:      reverseSignInfo,
		UrgentInfo:           urgentInfo,
		ExpireRemindInfo:     expireRemindInfo,
		// SettlementInfo:      settlementInfo,

		ValidityChangeDetail:  db.ValidityChangeDetail,
		SettlementClause:      db.SettlementClause,
		IsContainRefundClause: db.IsContainRefundClause,

		ContractProductInfo: contractProductInfo,
		ContractAttachment:  db.ContractAttachment,
		// OnlineContract:             db.ContractFile,
		CRMKey:                      db.CRMKey,
		ContractId:                  db.ContractId,
		CheckCode:                   db.CheckCode,
		RelateQuoteNo:               db.RelateQuoteNo,
		RelateQuoteScene:            db.RelateQuoteScene,
		TemplateInfo:                templateInfo,
		ContractPriceRepeatInfo:     priceRepeatInfo,
		ContractPriceCreatedTime:    db.ContractPriceCreatedTime.Format(DBDateFormatTpl),
		FromContractTerminatedTime:  db.FromContractTerminatedTime.Format(DBDateFormatTpl),
		CooperationStatusChangeTime: db.CooperationStatusChangeTime.Format(DBDateFormatTpl),
		CreatedTime:                 FormatTime(db.CreatedTime),
		CreatedTimeWithTZ:           FormatTime3339(db.CreatedTime),
		UpdatedTime:                 FormatTime(db.UpdatedTime),
		UpdatedTimeWithTZ:           FormatTime3339(db.UpdatedTime),
		Status:                      db.Status,
		NeedCreateGroupChat:         db.OpenChatID == "",
		OpenChatID:                  db.OpenChatID,
		IsMainContract:              db.MainContractNo == "" || db.MainContractNo == db.ContractNo,

		ArchivedStatus:   db.ArchivedStatus,
		ActiveStatus:     db.ActiveStatus,
		Product:          db.Product,
		Finance:          db.Finance,
		ContractFile:     db.ContractFile,
		ExpireRemindFlag: db.ExpireRemindFlag,
		IsBackdating:     db.IsBackdating,
		IsUrgent:         db.IsUrgent,
		Remark:           db.Remark,
		RequestId:        db.RequestId,
		IsNewest:         db.IsNewest,
		OfacUrl:          db.OfacUrl,
		FinanceSubject:   db.FinanceSubject,
		BizIdentifier:    db.BizIdentifier,
		BizAccountID:     db.BizAccountID,
		CurVersionFrom:   db.CurVersionFrom,
	}

	fileIds := strings.Split(db.ContractFile, ",")
	for _, fileId := range fileIds {
		if strings.Contains(fileId, "cn_file") {
			ret.OnlineContract = fileId
		}
	}

	ret.RequireQuote = ret.RelateQuoteScene == _const.RelateQuoteSceneCompleted

	return ret
}

type ContractMetaReq struct {
	SourceType            _const.SourceType
	CurrentOperator       string          // 当前操作人
	CurrentOperatorUID    int64           // 当前操作人ID，前端header传值
	BizScene              int             // 业务场景
	BizSceneList          string          // 业务场景
	BizSource             int             // 合同来源
	BizSourceList         string          // 合同来源
	SupplyScene           string          // 补充类型
	TabScene              int             // 1-待我处理  2-我已处理
	ContractNo            string          // 合同号
	VolcContractNo        string          // 火山合同号
	ContractNoList        string          // 合同号列表
	ContractName          string          // 合同名称 模糊查询
	SubjectName           string          // 我方主体名称 模糊查询
	OtherPartyName        string          // 对方主体名称 模糊查询
	PropertyCode          string          // 合同性质
	CategoryNo            string          // 合同类型
	InOutType             string          // 收支类型
	Initiator             int             // 发起端
	CooperationStatus     *int            // 协商状态
	CooperationStatusList []int           // 协商状态列表
	ArchivedStatus        *int            // 归档状态
	ActiveStatus          *int            // 生效状态
	ActiveStatusList      []int           // 生效状态列表
	Status                *int            // 合同状态
	StatusList            string          // 合同状态列表
	Operator              int64           // 业务执行人
	RelatedPersonnel      int64           // 合同相关人
	Creator               int64           // 创建人
	BizAccountID          int             //
	BeginTime             time.Time       // 有效期开始时间
	EndTime               time.Time       // 有效期结束时间
	EndTimeBegin          time.Time       // 有效期结束时间-开始
	EndTimeEnd            time.Time       // 有效期结束时间-结束
	CreatedTimeBegin      time.Time       // 创建时间开始
	CreatedTimeEnd        time.Time       // 创建时间结束
	SubmitTimeBegin       time.Time       //
	SubmitTimeEnd         time.Time       //
	FileTimeBegin         time.Time       //
	FileTimeEnd           time.Time       //
	RelateQuoteID         string          // 关联报价单号
	RelateQuote           bool            // 合同关联了报价单
	PrincipalParty        string          // 委托方-主体名称
	EntrustedParty        string          // 被委托方-主体名称
	StartId               uint64          // 开始ID，与page.offset互斥 // 由于查询是按创建时间降序，所以如果指定startID时，需要按递减逻辑
	Limit                 int             //
	Offset                int             //
	NeedTotal             bool            // 是否需要查询总量count
	IsManager             bool            // 是否为管理员
	SpecialContractType   string          // 特殊合同类型，目前只支持单值查询
	RuleIdAndRoles        [][]interface{} // 在线协同相关配置
	DepartmentAndRoles    [][]interface{} // 在线协同相关配置
	UseManageInfo         bool            // 是否需要返回管理信息
	UseProjectInfo        bool            // 是否需要返回项目信息
	UseSettlementInfo     bool            // 是否需要返回结算信息
	UseTradePartyInfo     bool            // 是否需要返回交易双方信息

	// 准备参数
	PreContractNoList   []string // 在线协同可查询合同列表
	NeedLimit           bool     // 是否限制合同号列表
	LimitContractNoList []string // 限制合同号列表

	// 在线协同
	PreContractNo string
	SignatureType string

	IsMultiApply int // 批量申请鲜章 0-否 1-是

	// 「合同查询条件&列表内容调整」新增筛选条件（已归一化）
	BusinessModeList []string // 商务模式，命中合同需包含全部选中值
	TradeProductList []string // 商品英文名唯一标识，命中合同需包含全部选中值
	MainContractNo   string   // 主合同号
	OpportunityName  string   // 商机名称，左精准右模糊
	OpportunityID    string   // 商机ID，左精准右模糊
	ProjectCode      string   // 项目编号，来源 ProjectInfo.ProjectCode
	DepartmentIdList []string // 归属行业ID，来源 BasicInfo.DepartmentId，任一选中值命中即可
	BusinessTypeList []string // 业务类型，来源 BasicInfo.BusinessType，任一选中值命中即可
	SupplySource     string   // 补充场景
	WhetherProject   string   // 是否项目制 Y:是 N:否
}

type ListInProcessMetaReq struct {
	SourceType               _const.SourceType
	CurrentOperator          string          // 当前操作人
	BizScene                 int             // 业务场景
	BizSceneList             string          // 业务场景
	BizSource                int             // 合同来源
	BizSourceList            string          // 合同来源
	ContractNo               string          // 合同号
	ContractNoList           string          // 合同号列表
	ContractName             string          // 合同名称 模糊查询
	SubjectName              string          // 我方主体名称 模糊查询
	OtherPartyName           string          // 对方主体名称 模糊查询
	PropertyCode             string          // 合同性质
	CategoryNo               string          // 合同类型
	InOutType                string          // 收支类型
	Initiator                int             // 发起端
	CooperationStatus        *int            // 协商状态
	CooperationStatusList    []int           // 协商状态列表
	ArchivedStatus           *int            // 归档状态
	ActiveStatus             *int            // 生效状态
	ActiveStatusList         []int           // 生效状态列表
	Status                   *int            // 合同状态
	StatusList               string          // 合同状态列表
	Operator                 int64           // 业务执行人
	RelatedPersonnel         int64           // 合同相关人
	Creator                  int64           // 创建人
	BizAccountID             int             //
	BeginTime                time.Time       // 有效期开始时间
	EndTime                  time.Time       // 有效期结束时间
	EndTimeBegin             time.Time       // 有效期结束时间-开始
	EndTimeEnd               time.Time       // 有效期结束时间-结束
	CreatedTimeBegin         time.Time       // 创建时间开始
	CreatedTimeEnd           time.Time       // 创建时间结束
	SubmitTimeBegin          time.Time       //
	SubmitTimeEnd            time.Time       //
	FileTimeBegin            time.Time       //
	FileTimeEnd              time.Time       //
	RelateQuoteID            string          // 关联报价单号
	StartId                  uint64          // 开始ID，与page.offset互斥 // 由于查询是按创建时间降序，所以如果指定startID时，需要按递减逻辑
	Limit                    int             //
	Offset                   int             //
	NeedTotal                bool            // 是否需要查询总量count
	IsManager                bool            // 是否为管理员
	SpecialContractType      string          // 特殊合同类型，目前只支持单值查询
	SalesDepartmentsAndRoles [][]interface{} // 在线协同相关配置
	UseManageInfo            bool            // 是否需要返回管理信息
	UseSettlementInfo        bool            // 是否需要返回结算信息
	UseTradePartyInfo        bool            // 是否需要返回交易双方信息
}

type PreContractNoVO struct {
	PreContractNo string
}

type ContractNoVO struct {
	ContractNo string
}

func (c *ContractMetaDB) BuildManageInfo(ctx context.Context) (*VolcContractManage, []*VolcContractCommodity, []*VolcContractCommodityExternal) {

	info := &VolcContractManage{
		VolcContractId: c.Id,
		ContractNo:     c.ContractNo,
		Version:        c.Version,
	}

	var manageModel bizmodels.ManageInfo
	err := json.Unmarshal([]byte(c.ManageInfo), &manageModel)
	if err != nil {
		logs.CtxWarn(ctx, "BuildManageInfo_unmarshalManageInfoFail, manageInfo=%s, err=%s", c.ManageInfo, err.Error())
		return nil, nil, nil
	}

	// 处理ProductTotalIncome
	productTotalIncome := decimal.NewFromInt(0)
	for _, list := range manageModel.ProductLevelMap {
		for _, product := range list {
			productTotalIncome = productTotalIncome.Add(product.Income)
		}
	}

	info.Remark = manageModel.Remark
	info.PaymentType = manageModel.PaymentType
	info.PaymentTypeName = manageModel.PaymentTypeName
	info.BelongingDepartment = manageModel.BelongingDepartment
	info.ProductLine = manageModel.ProductLine
	info.RelatedPersonnel = manageModel.RelatedPersonnel
	info.LegalReviewer = manageModel.LegalReviewer
	feishuApostilleInfo, _ := json.Marshal(manageModel.FeishuApostilleInfo)
	info.FeishuApostilleInfo = string(feishuApostilleInfo)
	info.ReceivingPlace = manageModel.ReceivingPlace
	info.QuoteAccountID = manageModel.QuoteAccountID
	info.SealAccountID = manageModel.SealAccountID
	info.PricingAccountID = manageModel.PricingAccountID
	info.EndUser = manageModel.EndUser
	info.EndUserAccountID = manageModel.EndUserAccountID

	info.IsSplitProduct = manageModel.IsSplitProduct

	usefulLifeType := manageModel.UsefulLifeType
	if usefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		usefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
	}
	info.UsefulLifeType = usefulLifeType
	info.IndefiniteDateFlag = manageModel.IndefiniteDateFlag
	info.UsefulLifeUnit = manageModel.UsefulLifeUnit
	info.UsefulLifeNum = manageModel.UsefulLifeNum
	info.LongLifeReason = manageModel.LongLifeReason

	info.ProductValidityBegin, _ = time.ParseInLocation(DBDateFormatTpl, manageModel.ProductValidityBegin, time.Local)
	info.ProductValidityEnd, _ = time.ParseInLocation(DBDateFormatTpl, manageModel.ProductValidityEnd, time.Local)
	info.ProductTotalIncome = productTotalIncome
	info.RelateQuoteChanged = manageModel.RelateQuoteChanged
	info.RelateQuoteChangedBefore = manageModel.RelateQuoteChangedBefore

	info.WhetherProject = manageModel.WhetherProject
	info.IsSplitProduct = manageModel.IsSplitProduct
	accountAssociationInfo, _ := json.Marshal(manageModel.AccountAssociationInfo)
	info.AccountAssociationInfo = string(accountAssociationInfo)
	info.DistributBusinessType = manageModel.DistributBusinessType

	var list []*VolcContractCommodity
	for _, v := range manageModel.ProductLevelMap {
		list = append(list, ConvertCommodityList(v, c.Id, c.ContractNo, c.Version)...)
	}

	for _, v := range manageModel.DeductProductInfoMap {
		list = append(list, ConvertCommodityList(v, c.Id, c.ContractNo, c.Version)...)
	}

	var externalList []*VolcContractCommodityExternal
	if info.IsSplitProduct {
		externalList = ConvertExternalCommodityList(manageModel.ExternalProductList, c.Id)
	}

	return info, list, externalList
}

func (c *ContractMetaDB) GetPrincipalParty() *bizmodels.TradePartyInfoDetail {
	return c.getOtherPartyByType(_const.OtherPartyTypePrincipal)
}

func (c *ContractMetaDB) GetEntrustedParty() *bizmodels.TradePartyInfoDetail {
	return c.getOtherPartyByType(_const.OtherPartyTypeEntrusted)
}

func (c *ContractMetaDB) getOtherPartyByType(otherPartyType int) *bizmodels.TradePartyInfoDetail {
	if c.BizScene != _const.BizScenePayOnBehalf {
		return nil
	}
	var info bizmodels.TradePartyInfo
	if err := json.Unmarshal([]byte(c.TradePartyInfo), &info); err != nil {
		return nil
	}
	for _, v := range info.OtherParty {
		if v.OtherPartyType == otherPartyType {
			return v
		}
	}
	return nil
}

func (c *ContractMetaDB) IsTemporaryCredit() bool {
	if c.BizScene != _const.BizSceneCreditContract {
		return false
	}
	if c.TemplateInfo == "" {
		return false
	}
	var templateInfo bizmodels.TemplateInfo
	_ = json.Unmarshal([]byte(c.TemplateInfo), &templateInfo)
	if templateInfo.Master != nil && util.StringIn(templateInfo.Master.TemplateKey,
		[]string{_const.TemplateKeyCreditTemporary, _const.TemplateKeyCreditTemporaryMultiagent}) {
		return true
	}
	return false
}

func (c *ContractMetaDB) GetBizDownloadID() string {
	if c.CooperationStatus == _const.ContractStatusSubmitOA {
		// 协商状态进入“已提交飞书”后，并不代表签章回调一定已经完成。
		// 例如代付合同在提交飞书时会先落库 FileIdUnsigned，并把 CooperationStatus 更新为 SubmitOA；
		// 只有在后续电子签已签约回调成功后，才会补写 FileIdSigned。
		// 因此这里不能仅凭状态直接取 signed 文件，而是要在 FileIdSigned 已经存在时优先返回签章文件；
		// 否则回退到 unsigned 文件，避免“已提交飞书但尚未回调”阶段出现文件不存在。
		if c.FileIdSigned != "" {
			return c.FileIdSigned
		}
	}
	return c.FileIdUnsigned
}

type ConvertContractStatusParam struct {
	ContractNo     string
	CoStatus       int
	ActiveStatus   int
	Status         int
	ArchivedStatus int
}

func ConvertContractStatus(ctx context.Context, bizScene int, param ConvertContractStatusParam) int {
	if param.CoStatus == _const.ContractStatusSubmitOA {
		if bizScene == _const.BizScenePayOnBehalf { // 代付合同
			bizStatusMap := _const.BizContractQueryStatusMappings[_const.BizScenePayOnBehalf]
			logs.CtxWarn(ctx, "[convertContractStatus]BizScenePayOnBehalfUnexpectedStatus, "+
				"bizScene=%d, contractNo=%s, coStatus=%d, activeStatus=%d, status=%d, archivedStatus=%d",
				bizScene, param.ContractNo, param.CoStatus, param.ActiveStatus, param.Status, param.ArchivedStatus)
			for showStatus, cond := range bizStatusMap {
				var hit = true
				if len(cond.CooperationStatusList) > 0 && !util.IntIn(param.CoStatus, cond.CooperationStatusList) {
					hit = false
				}
				if len(cond.ActiveStatusList) > 0 && !util.IntIn(param.ActiveStatus, cond.ActiveStatusList) {
					hit = false
				}
				if len(cond.StatusList) > 0 && !util.IntIn(param.Status, cond.StatusList) {
					hit = false
				}
				if len(cond.ArchiveStatusList) > 0 && !util.IntIn(param.ArchivedStatus, cond.ArchiveStatusList) {
					hit = false
				}
				if hit {
					return showStatus
				}
			}

			return _const.BizContractStatusInit
		}

		return _const.BizContractActiveStatus2StatusMappings[param.ActiveStatus]
	}
	return _const.BizContractCoStatus2StatusMappings[param.CoStatus]
}

func (p *ContractMeta) CalcRequireQuote() bool {

	if p.BasicInfo == nil {
		return false
	}

	if p.Initiator == _const.InitiatorSelfPurchase {
		return false
	}

	if p.BasicInfo.IsBasicRequireQuote() {
		if p.SupplyScene == _const.SupplySceneOA {
			return false
		}
		// 合同为火山补充协议 合同补充场景不包含 报价单变更 & 有效期变更时 不需要关联报价单
		if p.SupplyScene == _const.SupplySceneVolc &&
			!util.StringListIn(strings.Split(p.SupplySource, ","), _const.RelateQuoteSupplySourceList) {
			return false
		}
		return true
	}

	return false
}

// IsFinalState 是否为终态
func (db *ContractMetaDB) IsFinalState() bool {
	return db.CooperationStatus == _const.PreSalesContractSubmitOA || db.CooperationStatus == _const.PreSalesContractAbandoned
}

func (db *ContractMetaDB) CalcApprovalKey() string {
	if db == nil {
		return _const.ApprovalKeyDefault
	}
	// 自采平台目前仅有一种情况，优先级最高
	if db.Initiator == _const.InitiatorSelfPurchase {
		return _const.ApprovalKeyCooperationSelfPurchase
	}
	if len(db.TemplateInfo) > 0 {
		return _const.ApprovalKeyCooperationQuote
	}
	// 是否有产解行解
	hasProductSolution := db.hasProductSolution()
	if hasProductSolution {
		return _const.ApprovalKeyDefaultWithSolution
	}
	return _const.ApprovalKeyDefault
}

// 是否包含产解行解
func (db *ContractMetaDB) hasProductSolution() bool {
	var projectInfo bizmodels.ProjectInfo
	_ = json.Unmarshal([]byte(db.ProjectInfo), &projectInfo)
	return projectInfo.HasProductSolutionEmail()
}

func (db *ContractMetaDBList) CollectContractNoList() []string {
	ret := make([]string, len(*db))
	for idx, v := range *db {
		ret[idx] = v.ContractNo
	}
	return ret
}

// ParseAccountCreateSource 此处逻辑需要移走，models中不要引用其他外部服务
func (p *ContractMeta) ParseAccountCreateSource(ctx context.Context) {
	for _, detail := range p.TradePartyInfo.OtherParty {
		var createSources []string
		accountIds := strings.Split(detail.AccountID, ",")
		for _, accountId := range accountIds {
			createSource, err := accountcli.GetCreateSource(ctx, accountId)
			if err != nil {
				createSources = append(createSources, strconv.Itoa(_const.FailAccountCreateSource))
			} else {
				createSources = append(createSources, strconv.Itoa(createSource))
			}
		}

		detail.CreateSource = strings.Join(createSources, ",")
	}
}

func (p *ContractMeta) CalcQuoteValidity() (time.Time, time.Time) {

	begin, _ := util.GetTimeFromString(p.BeginTime)
	end, _ := util.GetTimeFromString(p.EndTime)
	// meta表中begin_time类型为datetime，零值会被读取为如下格式
	if begin.IsZero() || p.BeginTime == "0001-01-01 00:00:00" {
		// 合同有效期尚未指定 尝试取报价单合同预估有效期
		if p.ManageInfo != nil {
			begin, _ = util.GetTimeFromString(p.ManageInfo.ProductValidityBegin)
			end, _ = util.GetTimeFromString(p.ManageInfo.ProductValidityEnd)
		}
	}
	return begin, end
}

func (cl *ContractMetaList) CollectContractNoList() []string {
	ret := make([]string, len(*cl))
	for idx, v := range *cl {
		ret[idx] = v.ContractNo
	}
	return ret
}

// func (c *ContractMetaDB) GenAfterMeta(req *bizmodels.CreateOrUpdateMetaReq) *ContractMetaDB {
// 	// copy 合同
// 	newMeta := *c
// 	// 合同有效期
// 	reqBeginTime, _ := time.ParseInLocation("2006-01-02", req.BasicInfo.BeginTime, time.Local)
// 	reqEndTime, _ := time.ParseInLocation("2006-01-02", req.BasicInfo.EndTime, time.Local)
// 	// 结束时间非空要求 23：59：59
// 	if !reqEndTime.IsZero() {
// 		year, month, day := reqEndTime.Date()
// 		reqEndTime = time.Date(year, month, day, 23, 59, 59, 0, reqEndTime.Location())
// 	}
// 	// 主合同终止日期
// 	fromContractTerminatedTime, _ := time.ParseInLocation(DBDateFormatTpl, req.FromContractTerminatedTime, time.Local)
// 	basicStr, _ := json.Marshal(req.BasicInfo)
// 	reverseSignInfoStr, _ := json.Marshal(req.ReverseSignInfo)
// 	templateInfoStr, _ := json.Marshal(req.TemplateInfo)
// 	// 合同附录
// 	var attachmentKey []string
// 	for _, attachment := range req.ContractAttachment {
// 		attachmentKey = append(attachmentKey, attachment.DownloadID)
// 	}
// 	// 替换参数
// 	newMeta.BizScene = req.BizScene
// 	newMeta.BizSource = req.BizSource
// 	newMeta.SupplyScene = req.SupplyScene
// 	newMeta.Initiator = req.Initiator
// 	newMeta.ContractNo = req.ContractNo
// 	newMeta.FromContractNo = req.FromContractNo
// 	newMeta.MainContractNo = req.MainContractNo
// 	newMeta.Version = req.Version
// 	newMeta.Creator = req.Creator
// 	newMeta.Operator = req.Operator
// 	newMeta.CreatorNew = req.CreatorNew
// 	newMeta.OperatorNew = req.OperatorNew
// 	newMeta.PropertyCode = req.PropertyCode
// 	newMeta.InOutType = req.InOutType
// 	newMeta.CategoryNo = req.CategoryNo
// 	newMeta.SignatureType = req.SignatureType
// 	newMeta.SpecialContractType = req.SpecialContractType
// 	newMeta.ContractName = req.ContractName
// 	newMeta.BeginTime = reqBeginTime
// 	newMeta.EndTime = reqEndTime
// 	newMeta.ContractFile = req.ContractFile
// 	newMeta.ContractAttachment = strings.Join(attachmentKey, ",")
// 	newMeta.RelateQuoteNo = req.RelateQuoteNo
// 	newMeta.BizIdentifier = req.BizIdentifier
// 	newMeta.CRMKey = req.CRMKey
// 	newMeta.Remark = req.Remark
// 	newMeta.FromContractTerminatedTime = fromContractTerminatedTime
// 	newMeta.Product = req.ProductList
// 	newMeta.Finance = req.Finance
// 	newMeta.SubjectName = req.SubjectName
// 	newMeta.OtherPartyName = req.OtherPartyName
// 	newMeta.SubjectAccountIds = req.SubjectAccountIds
// 	newMeta.BasicInfo = string(basicStr)
// 	newMeta.ReverseSignInfo = string(reverseSignInfoStr)
// 	newMeta.TemplateInfo = string(templateInfoStr)
// 	return &newMeta
// }

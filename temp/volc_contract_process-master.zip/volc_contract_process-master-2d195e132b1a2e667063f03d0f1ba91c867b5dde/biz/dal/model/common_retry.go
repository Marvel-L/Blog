package model

// CommonRetryTaskDB 业务重试
type CommonRetryTaskDB struct {
	BaseDB
	TaskType     int    // 重试类型
	Scene        int    // 业务场景
	Identifier   string // 业务重试唯一标识，比如合同号
	Detail       string // 重试上下文信息，建议使用JSON格式化存储
	RetryCount   int    // 已重试次数
	Remark       string // 重试信息
	TriggerLogID string // 触发该任务的logID
}

type CommonRetryTaskDBList []*CommonRetryTaskDB

type CommonRetryTaskVO struct {
	ID           uint64
	Scene        int    //
	TaskType     int    // 重试类型
	Identifier   string // 业务重试唯一标识，比如合同号
	Detail       string // 重试上下文信息，建议使用JSON格式化存储
	RetryCount   int    // 已重试次数
	Remark       string // 重试信息
	CreatedTime  string //
	UpdatedTime  string //
	Status       int    //
	TriggerLogID string // 触发该任务的logID
	Force        bool   //
}

func (db *CommonRetryTaskDB) GenResp() *CommonRetryTaskVO {
	return &CommonRetryTaskVO{
		ID:           db.Id,
		Scene:        db.Scene,
		TaskType:     db.TaskType,
		Identifier:   db.Identifier,
		Detail:       db.Detail,
		RetryCount:   db.RetryCount,
		Remark:       db.Remark,
		CreatedTime:  FormatTime(db.CreatedTime),
		UpdatedTime:  FormatTime(db.UpdatedTime),
		Status:       db.Status,
		TriggerLogID: db.TriggerLogID,
	}
}

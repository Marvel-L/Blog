package model

// CreditItem 信控信息
type CreditItem struct {
	Proposer        string  `json:"Proposer"`
	Reviewer        string  `json:"Creator"`
	PaymentCycle    string  `json:"PaymentCycle"`
	CreditLimit     float64 `json:"CreditLimit"`
	SettlementCycle string  `json:"SettlementCycle"`
	CreditType      string  `json:"CreditType"`
}

package model

import "volc_contract_process/biz/bizmodels"

// CommentDB 评论表
type CommentDB struct {
	BaseDB
	RelatedID       string `gorm:"column:related_id" json:"related_id"`
	CommentScene    int    `gorm:"column:comment_scene" json:"comment_scene"`
	CommentID       string `gorm:"column:comment_id" json:"comment_id"`
	ParentCommentID string `gorm:"column:parent_comment_id" json:"parent_comment_id"`
	RichTextID      int64  `gorm:"column:rich_text_id" json:"rich_text_id"`
	Sender          string `gorm:"column:sender" json:"sender"`
}

type CommentDBList []*CommentDB

func (m *CommentDB) GenResp() *bizmodels.Comment {
	return &bizmodels.Comment{
		ID:              int64(m.Id),
		RelatedID:       m.RelatedID,
		CommentScene:    m.CommentScene,
		CommentID:       m.CommentID,
		ParentCommentID: m.ParentCommentID,
		RichTextID:      m.RichTextID,
		Sender:          m.Sender,
		CreatedTime:     m.CreatedTime.Unix(),
		UpdatedTime:     m.UpdatedTime.Unix(),
		Status:          m.Status,
	}
}

func (l CommentDBList) GenResp() []*bizmodels.Comment {
	ret := make([]*bizmodels.Comment, len(l))

	for i, d := range l {
		ret[i] = d.GenResp()
	}

	return ret
}

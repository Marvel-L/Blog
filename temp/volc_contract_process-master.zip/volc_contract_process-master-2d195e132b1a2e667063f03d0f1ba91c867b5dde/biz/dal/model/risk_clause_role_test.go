package model

import (
	"math"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_RiskClauseRoleDBList_FetchId_BitsUTGen(t *testing.T) {
	t.Run("空列表返回空ID切片", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 空列表场景
			var s RiskClauseRoleDBList
			ids := s.FetchId()
			convey.So(ids, convey.ShouldBeNil)
			convey.So(len(ids), convey.ShouldEqual, 0)
		})
	})
	t.Run("非空列表返回转换后的ID切片", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 非空列表场景，包含多个元素
			s := RiskClauseRoleDBList{
				&RiskClauseRoleDB{BaseDB: BaseDB{Id: uint64(0)}},
				&RiskClauseRoleDB{BaseDB: BaseDB{Id: uint64(123)}},
				&RiskClauseRoleDB{BaseDB: BaseDB{Id: uint64(math.MaxInt64)}},
			}
			ids := s.FetchId()
			convey.So(ids, convey.ShouldResemble, []int64{0, 123, int64(math.MaxInt64)})
		})
	})
}

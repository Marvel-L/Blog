package model

import (
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/util"
)

// BusinessModeClauseDB 商务模式条款摘要表
type BusinessModeClauseDB struct {
	BaseDB
	VolcContractID int    `gorm:"column:volc_contract_id" db:"volc_contract_id" json:"volc_contract_id" form:"volc_contract_id"` // 合同ID
	ContractNo     string `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                     // 合同号
	BusinessMode   string `gorm:"column:business_mode" db:"business_mode" json:"business_mode" form:"business_mode"`             // 商务模式
	ClauseSummary  string `gorm:"column:clause_summary" db:"clause_summary" json:"clause_summary" form:"clause_summary"`         // 条款摘要
	Creator        string `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                     // 创建人
	Updater        string `gorm:"column:updater" db:"updater" json:"updater" form:"updater"`                                     // 更新人
	IsDeleted      int    `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                         // 是否已删除，1-是 0-否
}

func (b *BusinessModeClauseDB) TableName() string {
	return "business_mode_clause"
}

func (b *BusinessModeClauseDB) GenResp() *bizmodels.BusinessModeClause {
	return &bizmodels.BusinessModeClause{
		Id:            b.Id,
		BusinessMode:  b.BusinessMode,
		ClauseSummary: b.ClauseSummary,
		Creator:       b.Creator,
		CreatedTime:   b.CreatedTime.Format(util.DBDateFormatTpl),
		Updater:       b.Updater,
		UpdatedTime:   b.UpdatedTime.Format(util.DBDateFormatTpl),
	}
}

func GenBusinessModeClauseDB(contractDB *ContractMetaDB, clause *bizmodels.BusinessModeClause, operator string) *BusinessModeClauseDB {
	return &BusinessModeClauseDB{
		VolcContractID: int(contractDB.Id),
		ContractNo:     contractDB.ContractNo,
		BusinessMode:   clause.BusinessMode,
		ClauseSummary:  clause.ClauseSummary,
		Creator:        operator,
		Updater:        operator,
	}
}

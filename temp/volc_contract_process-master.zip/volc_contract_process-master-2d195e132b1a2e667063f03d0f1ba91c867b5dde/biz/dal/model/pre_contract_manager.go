package model

// PreContractManagerDB 管理员表
type PreContractManagerDB struct {
	BaseDB
	ManagerMail string
	ManagerID   string
}

type PreContractManagerDBList []*PreContractManagerDB

package model

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestLarkMsgRecord_Main(t *testing.T) {
	e := &LarkMsgRecordDB{}
	assert.True(t, e.TableName() == "lark_msg_record")
}

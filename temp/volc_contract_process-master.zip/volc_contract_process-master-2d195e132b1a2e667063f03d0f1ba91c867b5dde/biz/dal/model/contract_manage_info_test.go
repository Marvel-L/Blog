package model

import (
	"fmt"
	"testing"
	"time"

	"code.byted.org/gopkg/context"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func TestVolcContractCommodity_OnlineStandard(t *testing.T) {
	t.Run("case 公有云标品", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &VolcContractCommodity{
				DeploymentType:  _const.SettlementDeploymentPublicCloud,
				StandardProduct: _const.STANDARD_PRODUCT_ENUM,
			}

			// Assert
			convey.So(v.OnlineStandard(), convey.ShouldEqual, true)
		})
	})
	t.Run("case 非公有云标品", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &VolcContractCommodity{
				DeploymentType:  _const.SettlementDeploymentPrivateCloud,
				StandardProduct: _const.NON_STANDARD_PRODUCT_ENUM,
			}

			// Assert
			convey.So(v.OnlineStandard(), convey.ShouldEqual, false)
		})
	})
}

func TestConvertExternalCommodity(t *testing.T) {
	// Test case when all fields have valid values
	mockey.PatchConvey("Test successful conversion with valid values", t, func() {
		volcContractId := uint64(1)
		product := &bizmodels.ExternalProductInfo{
			GroupID:           3,
			RecordType:        4,
			RelateQuoteItemID: "quote_item_id",
			TradeProductName:  "product_name",
			BuyNum:            "5",
			BuyNumUnit:        "unit",
			BuyDuration:       "duration",
			BuyDurationUnit:   "duration_unit",
			UnitPrice:         decimal.NewFromInt(10086).String(),
			IncomeNoTax:       decimal.NewFromInt(10086).String(),
			TaxRate:           decimal.NewFromInt(10086).String(),
			Remark:            "remark",
		}
		expected := &VolcContractCommodityExternal{
			VolcContractID:    volcContractId,
			GroupID:           product.GroupID,
			RecordType:        product.RecordType,
			RelateQuoteItemID: product.RelateQuoteItemID,
			TradeProductName:  product.TradeProductName,
			BuyNum:            product.BuyNum,
			BuyNumUnit:        product.BuyNumUnit,
			BuyDuration:       product.BuyDuration,
			BuyDurationUnit:   product.BuyDurationUnit,
			UnitPrice:         product.UnitPrice,
			IncomeNoTax:       product.IncomeNoTax,
			TaxRate:           product.TaxRate,
			Remark:            product.Remark,
		}
		actual := ConvertExternalCommodity(product, volcContractId)
		convey.So(actual, convey.ShouldResemble, expected)
	})
	// Test case when some fields are empty or zero values
	mockey.PatchConvey("Test conversion with some empty or zero values", t, func() {
		volcContractId := uint64(1)
		product := &bizmodels.ExternalProductInfo{
			GroupID:           0,
			RecordType:        0,
			RelateQuoteItemID: "",
			TradeProductName:  "",
			BuyNum:            "",
			BuyNumUnit:        "",
			BuyDuration:       "",
			BuyDurationUnit:   "",
			UnitPrice:         decimal.NewFromInt(10086).String(),
			IncomeNoTax:       decimal.NewFromInt(10086).String(),
			TaxRate:           decimal.NewFromInt(10086).String(),
			Remark:            "",
		}
		expected := &VolcContractCommodityExternal{
			VolcContractID:    volcContractId,
			GroupID:           product.GroupID,
			RecordType:        product.RecordType,
			RelateQuoteItemID: product.RelateQuoteItemID,
			TradeProductName:  product.TradeProductName,
			BuyNum:            product.BuyNum,
			BuyNumUnit:        product.BuyNumUnit,
			BuyDuration:       product.BuyDuration,
			BuyDurationUnit:   product.BuyDurationUnit,
			UnitPrice:         product.UnitPrice,
			IncomeNoTax:       product.IncomeNoTax,
			TaxRate:           product.TaxRate,
			Remark:            product.Remark,
		}
		actual := ConvertExternalCommodity(product, volcContractId)
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

func TestConvertExternalCommodityList(t *testing.T) {
	// 正常情况
	mockey.PatchConvey("Test normal case", t, func() {
		productList := []*bizmodels.ExternalProductInfo{
			{
				ID:                1,
				GroupID:           10,
				RecordType:        1,
				RelateQuoteItemID: "item1",
				VolcContractID:    100,
				TradeProductName:  "Product 1",
				BuyNum:            "10",
				BuyNumUnit:        "unit1",
				BuyDuration:       "1 month",
				BuyDurationUnit:   "month",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "Remark 1",
			},
			{
				ID:                2,
				GroupID:           20,
				RecordType:        2,
				RelateQuoteItemID: "item2",
				VolcContractID:    100,
				TradeProductName:  "Product 2",
				BuyNum:            "20",
				BuyNumUnit:        "unit2",
				BuyDuration:       "2 months",
				BuyDurationUnit:   "month",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "Remark 2",
			},
		}
		volcContractId := uint64(100)
		expectedResList := []*VolcContractCommodityExternal{
			{
				VolcContractID:    100,
				GroupID:           10,
				RecordType:        1,
				RelateQuoteItemID: "item1",
				TradeProductName:  "Product 1",
				BuyNum:            "10",
				BuyNumUnit:        "unit1",
				BuyDuration:       "1 month",
				BuyDurationUnit:   "month",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "Remark 1",
			},
			{
				VolcContractID:    100,
				GroupID:           20,
				RecordType:        2,
				RelateQuoteItemID: "item2",
				TradeProductName:  "Product 2",
				BuyNum:            "20",
				BuyNumUnit:        "unit2",
				BuyDuration:       "2 months",
				BuyDurationUnit:   "month",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "Remark 2",
			},
		}
		actualResList := ConvertExternalCommodityList(productList, volcContractId)
		convey.So(actualResList, convey.ShouldResemble, expectedResList)
	})

	// 空列表情况
	mockey.PatchConvey("Test empty product list", t, func() {
		productList := []*bizmodels.ExternalProductInfo{}
		volcContractId := uint64(100)
		actualResList := ConvertExternalCommodityList(productList, volcContractId)
		convey.So(len(actualResList), convey.ShouldEqual, 0)
	})

	// 边界情况，例如极端值或特殊值
	mockey.PatchConvey("Test boundary cases", t, func() {
		productList := []*bizmodels.ExternalProductInfo{
			{
				ID:                0,
				GroupID:           0,
				RecordType:        0,
				RelateQuoteItemID: "",
				VolcContractID:    0,
				TradeProductName:  "",
				BuyNum:            "",
				BuyNumUnit:        "",
				BuyDuration:       "",
				BuyDurationUnit:   "",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "",
			},
		}
		volcContractId := uint64(0)
		expectedResList := []*VolcContractCommodityExternal{
			{
				VolcContractID:    0,
				GroupID:           0,
				RecordType:        0,
				RelateQuoteItemID: "",
				TradeProductName:  "",
				BuyNum:            "",
				BuyNumUnit:        "",
				BuyDuration:       "",
				BuyDurationUnit:   "",
				UnitPrice:         decimal.NewFromInt(10086).String(),
				IncomeNoTax:       decimal.NewFromInt(10086).String(),
				TaxRate:           decimal.NewFromInt(10086).String(),
				Remark:            "",
			},
		}
		actualResList := ConvertExternalCommodityList(productList, volcContractId)
		convey.So(actualResList, convey.ShouldResemble, expectedResList)
	})
}

func Test_GenProductInfo(t *testing.T) {
	mockey.PatchConvey("Test when product is nil", t, func() {
		c := &VolcContractCommodityExternal{
			BaseDB: BaseDB{
				Id:     1,
				Status: 1,
			},
			VolcContractID:    2,
			GroupID:           4,
			RecordType:        5,
			TradeProductName:  "name",
			Remark:            "remark",
			BuyNum:            "num",
			BuyNumUnit:        "unit",
			BuyDuration:       "duration",
			BuyDurationUnit:   "durationUnit",
			IncomeNoTax:       decimal.NewFromInt(10086).String(),
			RelateQuoteItemID: "quoteItemId",
			UnitPrice:         decimal.NewFromInt(10086).String(),
			TaxRate:           decimal.NewFromInt(10086).String(),
		}
		actual := c.GenProductInfo(nil)
		convey.So(actual.ID, convey.ShouldEqual, c.Id)
		convey.So(actual.VolcContractID, convey.ShouldEqual, c.VolcContractID)
		convey.So(actual.GroupID, convey.ShouldEqual, c.GroupID)
		convey.So(actual.RecordType, convey.ShouldEqual, c.RecordType)
		convey.So(actual.TradeProductName, convey.ShouldEqual, c.TradeProductName)
		convey.So(actual.Remark, convey.ShouldEqual, c.Remark)
		convey.So(actual.BuyNum, convey.ShouldEqual, c.BuyNum)
		convey.So(actual.BuyNumUnit, convey.ShouldEqual, c.BuyNumUnit)
		convey.So(actual.BuyDuration, convey.ShouldEqual, c.BuyDuration)
		convey.So(actual.BuyDurationUnit, convey.ShouldEqual, c.BuyDurationUnit)
		convey.So(actual.IncomeNoTax, convey.ShouldEqual, c.IncomeNoTax)
		convey.So(actual.RelateQuoteItemID, convey.ShouldEqual, c.RelateQuoteItemID)
		convey.So(actual.UnitPrice, convey.ShouldEqual, c.UnitPrice)
		convey.So(actual.TaxRate, convey.ShouldEqual, c.TaxRate)
		convey.So(actual.Status, convey.ShouldEqual, c.Status)
		// And other fields as needed
	})
	mockey.PatchConvey("Test when product is not nil", t, func() {
		c := &VolcContractCommodityExternal{
			BaseDB: BaseDB{
				Id:     1,
				Status: 1,
			},
			VolcContractID:    2,
			GroupID:           4,
			RecordType:        5,
			TradeProductName:  "name",
			Remark:            "remark",
			BuyNum:            "num",
			BuyNumUnit:        "unit",
			BuyDuration:       "duration",
			BuyDurationUnit:   "durationUnit",
			IncomeNoTax:       decimal.NewFromInt(10086).String(),
			RelateQuoteItemID: "quoteItemId",
			UnitPrice:         decimal.NewFromInt(10086).String(),
			TaxRate:           decimal.NewFromInt(10086).String(),
		}
		product := &bizmodels.ProductInfo{
			TradeSolution:    "solution",
			CanPrePay:        "prePay",
			ConfigCategory:   "category",
			Configuration:    "config",
			SellingMode:      "mode",
			ChargeItemTag:    "tag",
			ChargeItemCode:   "code",
			BillingName:      "billing",
			Region:           "region",
			ChargeElement:    "element",
			PriceFactor:      "factor",
			PriceType:        "type",
			IncomeCode:       "incomeCode",
			DeploymentType:   1,
			RelatedItemID:    "relatedItemId",
			ItemBusinessRole: "itemBusinessRole",
		}
		actual := c.GenProductInfo(product)
		convey.So(actual.TradeSolution, convey.ShouldEqual, product.TradeSolution)
		convey.So(actual.CanPrePay, convey.ShouldEqual, product.CanPrePay)
		convey.So(actual.ConfigCategory, convey.ShouldEqual, product.ConfigCategory)
		convey.So(actual.Configuration, convey.ShouldEqual, product.Configuration)
		convey.So(actual.SellingMode, convey.ShouldEqual, product.SellingMode)
		convey.So(actual.ChargeItemTag, convey.ShouldEqual, product.ChargeItemTag)
		convey.So(actual.ChargeItemCode, convey.ShouldEqual, product.ChargeItemCode)
		convey.So(actual.BillingName, convey.ShouldEqual, product.BillingName)
		convey.So(actual.Region, convey.ShouldEqual, product.Region)
		convey.So(actual.ChargeElement, convey.ShouldEqual, product.ChargeElement)
		convey.So(actual.PriceFactor, convey.ShouldEqual, product.PriceFactor)
		convey.So(actual.PriceType, convey.ShouldEqual, product.PriceType)
		convey.So(actual.IncomeCode, convey.ShouldEqual, product.IncomeCode)
		convey.So(actual.DeploymentType, convey.ShouldEqual, product.DeploymentType)
		convey.So(actual.Quantity, convey.ShouldEqual, product.Quantity)
		convey.So(actual.QuantityUnit, convey.ShouldEqual, product.QuantityUnit)
		convey.So(actual.RelatedItemID, convey.ShouldEqual, product.RelatedItemID)
		convey.So(actual.ItemBusinessRole, convey.ShouldEqual, product.ItemBusinessRole)
		// And other fields from VolcContractCommodityExternal as needed
	})
}

func Test_Commodity_GenProductInfo(t *testing.T) {
	mockey.PatchConvey("Test GenProductInfo", t, func() {
		// Mock GetPricingFunction to return a specific value
		mockey.Mock(bizmodels.GetPricingFunction).Return("test_pricing_function", nil).Build()

		// Create a VolcContractCommodity instance
		volcContractCommodity := &VolcContractCommodity{
			BaseDB: BaseDB{
				Id: 1,
			},
			VolcContractID:        2,
			TradeProduct:          "Product1",
			TradeProductCode:      "Code1",
			TradeProductName:      "Name1",
			Income:                decimal.NewFromInt(100),
			InvoiceProjectCode:    "IPC1",
			TaxRatio:              decimal.NewFromInt(1),
			InvoiceProject:        "IP1",
			IncomeCode:            "IC1",
			Remark:                "Remark1",
			ChildProductCode:      "CPC1",
			StandardProductCode:   "SPC1",
			Configuration:         "Config1",
			ConfigurationName:     "ConfigName1",
			ConfigCategory:        "ConfigCategory1",
			BillingMethodCode:     "BMC1",
			BillingName:           "BN1",
			RegionCode:            "RC1",
			Region:                "Region1",
			ChargeElement:         "CE1",
			ChargeElementCode:     "CEC1",
			PriceFactor:           "PF1",
			PriceFactorCode:       "PFC1",
			Discount:              "Discount1",
			OffPeakHoursBilling:   "OPHB1",
			ChargeItemCode:        "CIC1",
			ChargeItemTag:         "CIT1",
			PricingVersion:        "PV1",
			PayType:               "PT1",
			CanPrePay:             "CP1",
			CanPrePayCode:         "CPC1",
			GuaranteedPercentage:  "GP1",
			DeploymentType:        0,
			SellingMode:           "SM1",
			ItemType:              "IT1",
			ActivationType:        "AT1",
			QuoteSolutionID:       "QSID1",
			TradeSolutionCode:     "TSC1",
			TradeSolution:         "TS1",
			TradeSolutionName:     "TSN1",
			TradeSolutionVersion:  "TSV1",
			BuyNum:                "BN1",
			BuyNumUnit:            "BNU1",
			Quantity:              "1000",
			QuantityUnit:          "次",
			BuyDuration:           "BD1",
			BuyDurationUnit:       "BDU1",
			MaintenanceService:    "MS1",
			MaintenanceNum:        "MN1",
			MaintenanceUnit:       "MU1",
			OriginalPrice:         "OP1",
			IncomeNoTax:           "INT1",
			PriceInfoSnapshot:     "PIS1",
			QuoteItemID:           "QID1",
			StandardProduct:       "SP1",
			ShowName:              "SN1",
			GiveAwayType:          "GAT1",
			PrePayRatio:           "PrePayRatio1",
			PrePayRatioCode:       "PrePayRatioCode1",
			SpBuyDuration:         "SpBuyDuration1",
			SpBuyDurationCode:     "SpBuyDurationCode1",
			CommitFeeInterval:     "CommitFeeInterval1",
			CommitFeeIntervalCode: "CommitFeeIntervalCode1",
			SalesMode:             "SalesMode1",
			ConfigIsPublic:        "ConfigIsPublic1",
			ConfigPublicDisplay:   "ConfigPublicDisplay1",
		}

		expectedProductInfo := &bizmodels.ProductInfo{
			ID:                    1,
			VolcContractID:        2,
			TradeProduct:          "Product1",
			TradeProductCode:      "Code1",
			TradeProductName:      "Name1",
			Income:                decimal.NewFromInt(100),
			InvoiceProjectCode:    "IPC1",
			TaxRatio:              decimal.NewFromInt(1),
			InvoiceProject:        "IP1",
			IncomeCode:            "IC1",
			Remark:                "Remark1",
			ChildProductCode:      "CPC1",
			StandardProductCode:   "SPC1",
			Configuration:         "Config1",
			ConfigurationName:     "ConfigName1",
			ConfigCategory:        "ConfigCategory1",
			BillingMethodCode:     "BMC1",
			BillingName:           "BN1",
			RegionCode:            "RC1",
			Region:                "Region1",
			ChargeElement:         "CE1",
			ChargeElementCode:     "CEC1",
			PriceFactor:           "PF1",
			PriceFactorCode:       "PFC1",
			PriceType:             "test_pricing_function",
			Discount:              "Discount1",
			OffPeakHoursBilling:   "OPHB1",
			ChargeItemCode:        "CIC1",
			ChargeItemTag:         "CIT1",
			PricingVersion:        "PV1",
			PayType:               "PT1",
			CanPrePay:             "CP1",
			CanPrePayCode:         "CPC1",
			GuaranteedPercentage:  "GP1",
			DeploymentType:        0,
			SellingMode:           "SM1",
			ItemType:              "IT1",
			ActivationType:        "AT1",
			QuoteSolutionID:       "QSID1",
			TradeSolutionCode:     "TSC1",
			TradeSolution:         "TS1",
			TradeSolutionName:     "TSN1",
			TradeSolutionVersion:  "TSV1",
			BuyNum:                "BN1",
			BuyNumUnit:            "BNU1",
			Quantity:              "1000",
			QuantityUnit:          "次",
			BuyDuration:           "BD1",
			BuyDurationUnit:       "BDU1",
			MaintenanceService:    "MS1",
			MaintenanceNum:        "MN1",
			MaintenanceUnit:       "MU1",
			OriginalPrice:         "OP1",
			IncomeNoTax:           "INT1",
			PriceInfoSnapshot:     "PIS1",
			QuoteItemID:           "QID1",
			StandardProduct:       "SP1",
			ShowName:              "SN1",
			GiveAwayType:          "GAT1",
			UpdatedTime:           volcContractCommodity.UpdatedTime.Unix(),
			PrePayRatio:           "PrePayRatio1",
			PrePayRatioCode:       "PrePayRatioCode1",
			SpBuyDuration:         "SpBuyDuration1",
			SpBuyDurationCode:     "SpBuyDurationCode1",
			CommitFeeInterval:     "CommitFeeInterval1",
			CommitFeeIntervalCode: "CommitFeeIntervalCode1",
			SalesMode:             "SalesMode1",
			ConfigIsPublic:        "ConfigIsPublic1",
			ConfigPublicDisplay:   "ConfigPublicDisplay1",
		}

		actualProductInfo := volcContractCommodity.GenProductInfo()

		convey.So(actualProductInfo, convey.ShouldResemble, expectedProductInfo)
	})
}

func TestConvertCommodity_Quantity(t *testing.T) {
	mockey.PatchConvey("Test ConvertCommodity quantity fields", t, func() {
		product := &bizmodels.ProductInfo{
			TradeProduct:     "Product1",
			TradeProductName: "Name1",
			InvoiceProject:   "*信息技术服务*技术服务费*6%",
			Quantity:         "1000",
			QuantityUnit:     "次",
		}

		actual := ConvertCommodity(product, 1, "contract_no", 2)

		convey.So(actual.Quantity, convey.ShouldEqual, product.Quantity)
		convey.So(actual.QuantityUnit, convey.ShouldEqual, product.QuantityUnit)
	})
}

func TestVolcContractCommodityExternalList_GenProductInfo(t *testing.T) {
	mockey.PatchConvey("Test when RecordType is ExternalCommodityRecordTypeMaster", t, func() {
		commodity := &VolcContractCommodityExternal{RecordType: _const.ExternalCommodityRecordTypeMaster}
		mockey.Mock(commodity.GenProductInfo).Return(&bizmodels.ExternalProductInfo{}).Build()
		productMap := make(map[string]*bizmodels.ProductInfo)
		c := VolcContractCommodityExternalList{commodity}
		actual := (c).GenProductInfo(productMap)
		convey.So(actual, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test when RecordType is not ExternalCommodityRecordTypeMaster and productMap exists", t, func() {
		commodity := &VolcContractCommodityExternal{RecordType: 1, RelateQuoteItemID: "1"}
		productMap := make(map[string]*bizmodels.ProductInfo)
		productMap["1"] = &bizmodels.ProductInfo{}
		mockey.Mock(commodity.GenProductInfo).Return(&bizmodels.ExternalProductInfo{}).Build()
		c := VolcContractCommodityExternalList{commodity}
		actual := (c).GenProductInfo(productMap)
		convey.So(actual, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test when RecordType is not ExternalCommodityRecordTypeMaster and productMap is nil", t, func() {
		commodity := &VolcContractCommodityExternal{RecordType: 1, RelateQuoteItemID: "1"}
		c := VolcContractCommodityExternalList{commodity}
		actual := (c).GenProductInfo(nil)
		convey.So(actual, convey.ShouldNotBeNil)
	})
}

func TestGenCommodityIdProductInfoMap(t *testing.T) {
	// 创建 VolcContractCommodityList 对象

	mockey.PatchConvey("Test when the list is empty", t, func() {
		vccl := VolcContractCommodityList{}
		actual := vccl.GenQuoteItemIDProductInfoMap()
		convey.So(len(actual), convey.ShouldEqual, 0)
	})
	mockey.PatchConvey("Test when the list has one commodity", t, func() {
		vccl := VolcContractCommodityList{}
		vccl = append(vccl, &VolcContractCommodity{QuoteItemID: "1"})
		mockey.Mock((*VolcContractCommodity).GenProductInfo).Return(&bizmodels.ProductInfo{}).Build()
		actual := vccl.GenQuoteItemIDProductInfoMap()
		convey.So(len(actual), convey.ShouldEqual, 1)
		convey.So(actual["1"], convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test when the list has multiple commodities", t, func() {
		vccl := VolcContractCommodityList{}
		vccl = append(vccl, &VolcContractCommodity{QuoteItemID: "2"}, &VolcContractCommodity{QuoteItemID: "3"})
		mockey.Mock((*VolcContractCommodity).GenProductInfo).Return(&bizmodels.ProductInfo{}).Build()
		actual := vccl.GenQuoteItemIDProductInfoMap()
		convey.So(len(actual), convey.ShouldEqual, 2)
		convey.So(actual["2"], convey.ShouldNotBeNil)
		convey.So(actual["3"], convey.ShouldNotBeNil)
	})
}

func TestVolcContractCommodityExternalList_ValidateBuyNum(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()

			// Act
			var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
				GroupID:           1,
				RecordType:        2,
				RelateQuoteItemID: "10086",
				BuyNum:            "10",
			}})
			v1 := v
			err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
				DeploymentType: 1,
				BuyNum:         "10",
			}})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case master continue", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()

			// Act
			var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
				GroupID:           1,
				RecordType:        1,
				RelateQuoteItemID: "10086",
				BuyNum:            "10",
			}})
			v1 := v
			err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
				DeploymentType: 1,
				BuyNum:         "10",
			}})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case buyNum format fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()

			// Act
			var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
				GroupID:           1,
				RecordType:        2,
				RelateQuoteItemID: "10086",
				BuyNum:            "aa",
			}})
			v1 := v
			err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
				DeploymentType: 1,
				BuyNum:         "10",
			}})

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs("分组[1]外部商品行[10086]购买数量[aa]格式异常[can't convert aa to decimal]"))
		})
	})
	t.Run("case product continue", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()

			// Act
			var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
				GroupID:           1,
				RecordType:        2,
				RelateQuoteItemID: "10086",
				BuyNum:            "10",
			}})
			v1 := v
			err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
				DeploymentType: 0,
				BuyNum:         "10",
			}})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case buyNum zero error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()

			// Act
			var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
				GroupID:           1,
				RecordType:        2,
				RelateQuoteItemID: "10086",
				BuyNum:            "0",
			}})
			v1 := v
			err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
				DeploymentType: 1,
				BuyNum:         "10",
			}})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
	// t.Run("case buyNum equal fail", func(t *testing.T) {
	//	mockey.PatchConvey("", t, func() {
	//		// Arrange
	//		mockey.Mock(i18nfmt.Errorf).To(func(ctx context.Context, format string, a ...interface{}) error { return fmt.Errorf(format, a...) }).Build()
	//		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
	//
	//		// Act
	//		var v = VolcContractCommodityExternalList([]*VolcContractCommodityExternal{&VolcContractCommodityExternal{
	//			GroupID:           1,
	//			RecordType:        2,
	//			RelateQuoteItemID: "10086",
	//			BuyNum:            "9",
	//		}})
	//		v1 := v
	//		err := v1.ValidateBuyNum(context.Background(), map[string]*bizmodels.ProductInfo{"10086": &bizmodels.ProductInfo{
	//			DeploymentType: 1,
	//			BuyNum:         "10",
	//		}})
	//
	//		// Assert
	//		convey.So(err, convey.ShouldResemble, errors.ErrInternalError.WithArgs("内部商品行[10086]内外部映射表购买数量校验失败，内部商品行购买数量[10]，外部商品行购买数量总和[9]"))
	//	})
	// })
}

func TestVolcContractCommodityExternalList_Validate(t *testing.T) {
	mockey.PatchConvey("Test with no missing params", t, func() {
		c := VolcContractCommodityExternalList{
			{
				RelateQuoteItemID: "123",
				GroupID:           1,
			},
			{
				RelateQuoteItemID: "456",
				GroupID:           2,
			},
		}
		err := c.Validate()
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test with missing RelatedQuoteItemID", t, func() {
		c := VolcContractCommodityExternalList{
			{
				RelateQuoteItemID: "",
				GroupID:           1,
			},
		}
		err := c.Validate()
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test with missing GroupID", t, func() {
		c := VolcContractCommodityExternalList{
			{
				RelateQuoteItemID: "123",
				GroupID:           0,
			},
		}
		err := c.Validate()
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func Test_AllFieldUpdate(t *testing.T) {
	mockey.PatchConvey("Test new is nil", t, func() {
		m := &VolcContractManage{}
		new := (*VolcContractManage)(nil)
		m.AllFieldUpdate(new)
		convey.So(m.ContractNo, convey.ShouldBeEmpty)
		convey.So(m.Version, convey.ShouldEqual, 0)
	})

	mockey.PatchConvey("Test m.ContractNo is empty", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{
			ContractNo: "new_contract_no",
			Version:    2,
		}
		m.AllFieldUpdate(new)
		convey.So(m.ContractNo, convey.ShouldEqual, "new_contract_no")
		convey.So(m.Version, convey.ShouldEqual, 2)
	})

	mockey.PatchConvey("Test m.ContractNo is not empty", t, func() {
		m := &VolcContractManage{
			ContractNo: "existing_contract_no",
			Version:    1,
		}
		new := &VolcContractManage{
			ContractNo: "new_contract_no",
			Version:    2,
		}
		m.AllFieldUpdate(new)
		convey.So(m.ContractNo, convey.ShouldEqual, "existing_contract_no")
		convey.So(m.Version, convey.ShouldEqual, 1)
	})

	mockey.PatchConvey("Test new.ProductLine is not empty", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{
			ProductLine: "new_product_line",
		}
		m.AllFieldUpdate(new)
		convey.So(m.ProductLine, convey.ShouldEqual, "new_product_line")
	})

	mockey.PatchConvey("Test new.ProductLine is empty", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{}
		m.AllFieldUpdate(new)
		convey.So(m.ProductLine, convey.ShouldBeEmpty)
	})

	mockey.PatchConvey("Test new.PaymentType and PaymentTypeName are not empty", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{
			PaymentType:     "new_payment_type",
			PaymentTypeName: "new_payment_type_name",
		}
		m.AllFieldUpdate(new)
		convey.So(m.PaymentType, convey.ShouldEqual, "new_payment_type")
		convey.So(m.PaymentTypeName, convey.ShouldEqual, "new_payment_type_name")
	})

	mockey.PatchConvey("Test new.PaymentType and PaymentTypeName are empty", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{}
		m.AllFieldUpdate(new)
		convey.So(m.PaymentType, convey.ShouldBeEmpty)
		convey.So(m.PaymentTypeName, convey.ShouldBeEmpty)
	})

	mockey.PatchConvey("Test all fields update", t, func() {
		m := &VolcContractManage{}
		new := &VolcContractManage{
			VolcContractId:         12345,
			RelatedPersonnel:       "new_related_personnel",
			LegalReviewer:          "new_legal_reviewer",
			FeishuApostilleInfo:    "new_feishu_apostille_info",
			ReceivingPlace:         "new_receiving_place",
			Remark:                 "new_remark",
			ProductValidityBegin:   time.Date(2023, 10, 1, 0, 0, 0, 0, time.UTC),
			ProductValidityEnd:     time.Date(2024, 10, 1, 0, 0, 0, 0, time.UTC),
			QuoteAccountID:         "new_quote_account_id",
			SealAccountID:          "new_seal_account_id",
			PricingAccountID:       "new_pricing_account_id",
			EndUser:                "new_end_user",
			EndUserAccountID:       "new_end_user_account_id",
			WhetherProject:         "Y",
			IsSplitProduct:         true,
			DistributBusinessType:  1,
			UsefulLifeType:         _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME,
			IndefiniteDateFlag:     "Y",
			UsefulLifeUnit:         "MONTH",
			UsefulLifeNum:          12,
			LongLifeReason:         "new_long_life_reason",
			AccountAssociationInfo: "new_account_association_info",
		}
		m.AllFieldUpdate(new)
		convey.So(m.VolcContractId, convey.ShouldEqual, uint64(12345))
		convey.So(m.RelatedPersonnel, convey.ShouldEqual, "new_related_personnel")
		convey.So(m.LegalReviewer, convey.ShouldEqual, "new_legal_reviewer")
		convey.So(m.FeishuApostilleInfo, convey.ShouldEqual, "new_feishu_apostille_info")
		convey.So(m.ReceivingPlace, convey.ShouldEqual, "new_receiving_place")
		convey.So(m.Remark, convey.ShouldEqual, "new_remark")
		convey.So(m.ProductValidityBegin, convey.ShouldEqual, time.Date(2023, 10, 1, 0, 0, 0, 0, time.UTC))
		convey.So(m.ProductValidityEnd, convey.ShouldEqual, time.Date(2024, 10, 1, 0, 0, 0, 0, time.UTC))
		convey.So(m.QuoteAccountID, convey.ShouldEqual, "new_quote_account_id")
		convey.So(m.SealAccountID, convey.ShouldEqual, "new_seal_account_id")
		convey.So(m.PricingAccountID, convey.ShouldEqual, "new_pricing_account_id")
		convey.So(m.EndUser, convey.ShouldEqual, "new_end_user")
		convey.So(m.EndUserAccountID, convey.ShouldEqual, "new_end_user_account_id")
		convey.So(m.WhetherProject, convey.ShouldEqual, "Y")
		convey.So(m.IsSplitProduct, convey.ShouldBeTrue)
		convey.So(m.DistributBusinessType, convey.ShouldEqual, 1)
		convey.So(m.UsefulLifeType, convey.ShouldEqual, _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME)
		convey.So(m.IndefiniteDateFlag, convey.ShouldEqual, "Y")
		convey.So(m.UsefulLifeUnit, convey.ShouldEqual, "MONTH")
		convey.So(m.UsefulLifeNum, convey.ShouldEqual, 12)
		convey.So(m.LongLifeReason, convey.ShouldEqual, "new_long_life_reason")
		convey.So(m.AccountAssociationInfo, convey.ShouldEqual, "new_account_association_info")
	})

	mockey.PatchConvey("force updates explicitly overwrite zero values without changing other fields", t, func() {
		current := &VolcContractManage{
			BaseDB:                   BaseDB{Id: 100},
			ContractNo:               "contract-no",
			Version:                  1,
			PaymentType:              "payment-type",
			PaymentTypeName:          "payment-type-name",
			BelongingDepartment:      "department",
			ProductLine:              "product-line",
			RelateQuoteChanged:       true,
			RelateQuoteChangedBefore: "old-quote",
			ProductTotalIncome:       decimal.NewFromInt(100),
			ProgressiveType:          "monthly",
			UsefulLifeType:           _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
		}
		newManage := &VolcContractManage{
			VolcContractId:        200,
			RelatedPersonnel:      "new-related-personnel",
			LegalReviewer:         "new-legal-reviewer",
			ReceivingPlace:        "new-receiving-place",
			QuoteAccountID:        "new-quote-account",
			SealAccountID:         "new-seal-account",
			WhetherProject:        "N",
			DistributBusinessType: 2,
			UsefulLifeType:        _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
			UsefulLifeUnit:        "MONTH",
			UsefulLifeNum:         12,
		}
		wantWithoutForceUpdates := *current
		wantWithoutForceUpdates.AllFieldUpdate(newManage)

		current.AllFieldUpdate(newManage, map[string]interface{}{
			"relate_quote_changed":        false,
			"relate_quote_changed_before": "",
			"product_total_income":        decimal.Zero,
			"progressive_type":            "",
			"useful_life_type":            0,
		})

		convey.So(current.RelateQuoteChanged, convey.ShouldBeFalse)
		convey.So(current.RelateQuoteChangedBefore, convey.ShouldBeEmpty)
		convey.So(current.ProductTotalIncome.IsZero(), convey.ShouldBeTrue)
		convey.So(current.ProgressiveType, convey.ShouldBeEmpty)
		convey.So(current.UsefulLifeType, convey.ShouldEqual, 0)

		current.RelateQuoteChanged = wantWithoutForceUpdates.RelateQuoteChanged
		current.RelateQuoteChangedBefore = wantWithoutForceUpdates.RelateQuoteChangedBefore
		current.ProductTotalIncome = wantWithoutForceUpdates.ProductTotalIncome
		current.ProgressiveType = wantWithoutForceUpdates.ProgressiveType
		current.UsefulLifeType = wantWithoutForceUpdates.UsefulLifeType
		convey.So(current, convey.ShouldResemble, &wantWithoutForceUpdates)
	})
}

package model

import (
	"time"

	"code.byted.org/videoarch/cloud_gopkg/models"
)

type RiskClauseTemplateDB struct {
	BaseDB
	Version        int       `gorm:"column:version" db:"version" json:"version" form:"version"`                                     // 合同版本
	RiskClauseType int       `gorm:"column:risk_clause_type" db:"risk_clause_type" json:"risk_clause_type" form:"risk_clause_type"` // 风险条款类型
	ClauseNo       string    `gorm:"column:clause_no" db:"clause_no" json:"clause_no" form:"clause_no"`                             // 风险条款编号
	Description    string    `gorm:"column:description" db:"description" json:"description" form:"description"`                     // 风险条款描述
	RiskLevel      string    `gorm:"column:risk_level" db:"risk_level" json:"risk_level" form:"risk_level"`                         // 风险等级
	Reviewer       string    `gorm:"column:reviewer" db:"reviewer" json:"reviewer" form:"reviewer"`                                 // 风险审批人
	Creator        string    `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                     // 创建人
	Updater        string    `gorm:"column:updater" db:"updater" json:"updater" form:"updater"`                                     // 更新人
	Filer          string    `gorm:"column:filer" db:"filer" json:"filer" form:"filer"`                                             // 归档人
	FileTime       time.Time `gorm:"column:file_time" db:"file_time" json:"file_time" form:"file_time"`                             // 归档时间                  // 归档人
	IsNewest       int       `gorm:"column:is_newest" db:"is_newest" json:"is_newest" form:"is_newest"`                             // 1 最新 0 旧版, 99%为新版
	IsDeleted      int       `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                         // 是否已删除，1-是 0-否
}

type RiskClauseTemplate struct {
	Id             uint64
	Version        int    // 合同版本
	RiskClauseType int    // 风险条款类型
	ClauseNo       string // 风险条款编号
	Description    string // 风险条款描述
	RiskLevel      string // 风险等级
	Reviewer       string // 风险审批人
	Creator        string // 创建人
	Updater        string // 更新人
	Filer          string // 归档人
	FileTime       string // 归档时间
	IsNewest       int    // 1 最新 0 旧版, 99%为新版
	IsDeleted      int    // 是否已删除，1-是 0-否
	Status         int
	CreatedTime    string
	UpdatedTime    string
}

func (r *RiskClauseTemplateDB) GenResp() *RiskClauseTemplate {
	return &RiskClauseTemplate{
		Id:             r.Id,
		Version:        r.Version,
		RiskClauseType: r.RiskClauseType,
		ClauseNo:       r.ClauseNo,
		Description:    r.Description,
		RiskLevel:      r.RiskLevel,
		Reviewer:       r.Reviewer,
		Creator:        r.Creator,
		Updater:        r.Updater,
		Filer:          r.Filer,
		FileTime:       r.FileTime.Format(models.DBDateFormatTpl),
		IsNewest:       r.IsNewest,
		IsDeleted:      r.IsDeleted,
		Status:         r.Status,
		CreatedTime:    r.CreatedTime.Format(models.DBDateFormatTpl),
		UpdatedTime:    r.UpdatedTime.Format(models.DBDateFormatTpl),
	}
}

type RiskClauseTemplateDBList []*RiskClauseTemplateDB

func (r RiskClauseTemplateDBList) GenResp() []*RiskClauseTemplate {
	var res []*RiskClauseTemplate
	for _, risk := range r {
		res = append(res, risk.GenResp())
	}
	return res
}

type ListRiskClauseTemplateReq struct {
	ClauseNo       string // 风险条款编号
	RiskClauseType string // 风险条款类型
	RiskLevel      string // 风险条款等级
	Status         *int   // 风险条款状态
	IsNewset       *int   // 最新版本
	NeedTotal      bool   // 是否查询总数
	Limit          int    //
	Offset         int    //
}

package model

import "time"

// LarkMsgRecordDB 飞书消息发送记录表
type LarkMsgRecordDB struct {
	BaseDB
	IdentityID   string    `json:"identity_id" gorm:"column:identity_id;NOT NULL"`     // 接收人标识，一般为邮箱
	IdentityType int32     `json:"identity_type" gorm:"column:identity_type;NOT NULL"` // 接收人类型，1-邮箱 2-OpenChatID
	MsgType      int32     `json:"msg_type" gorm:"column:msg_type;NOT NULL"`           // 消息类型：1-飞书消息
	MsgBody      string    `json:"msg_body" gorm:"column:msg_body;NOT NULL"`           // 消息体
	MessageID    string    `json:"message_id" gorm:"column:message_id;NOT NULL"`       // 消息标识,发送成功后有值
	SendTime     time.Time `json:"send_time" gorm:"column:send_time"`                  // 消息发送时间
	Extra        string    `json:"extra" gorm:"column:extra;NOT NULL"`                 // 消息备注信息
}

func (m *LarkMsgRecordDB) TableName() string {
	return "lark_msg_record"
}

package model

import (
	"code.byted.org/security/dkms-gorm/encrypt_type"
	"encoding/json"
	"strings"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/util"
)

// ContractSettlementDB  火山合同结算信息表
type ContractTradePartyDB struct {
	BaseDB
	VolcContractID int                         `gorm:"column:volc_contract_id" db:"volc_contract_id" json:"volc_contract_id" form:"volc_contract_id"`   // meta合同元数据ID
	ContractNo     string                      `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                       // 合同号
	PartyName      string                      `gorm:"column:party_name" db:"party_name" json:"party_name" form:"party_name"`                           // 主体名称
	AccountId      string                      `gorm:"column:account_id" db:"account_id" json:"account_id" form:"account_id"`                           // 账号ID
	PartyType      int                         `gorm:"column:party_type" db:"party_type" json:"party_type" form:"party_type"`                           // 类型：我方-1、对方-2、账号-3
	Ext            string                      `gorm:"column:ext" db:"ext" json:"ext" form:"ext" kms:"double_write:EncryptExt"`                         // 附加信息：类型为主体时，存储交易双方信息
	EncryptExt     *encrypt_type.EncryptString `gorm:"column:encrypt_ext;type:text" dkmsId:"eps.platform.volc_contract_dkms_siv" encodeFormat:"base64"` // 加密信息
}

type ContractTradePartyDBList []*ContractTradePartyDB

func (s ContractTradePartyDBList) GenResp() *bizmodels.TradePartyInfo {
	tradePartyInfo := bizmodels.TradePartyInfo{}
	var subject []*bizmodels.TradePartyInfoDetail
	var other []*bizmodels.TradePartyInfoDetail
	for _, party := range s {
		switch party.PartyType {
		case _const.TradePartyTypeSubject:
			{
				var detail bizmodels.TradePartyInfoDetail
				_ = json.Unmarshal([]byte(party.Ext), &detail)
				subject = append(subject, &detail)
			}
		case _const.TradePartyTypeOther:
			{
				var detail bizmodels.TradePartyInfoDetail
				_ = json.Unmarshal([]byte(party.Ext), &detail)
				other = append(other, &detail)
			}
		case _const.TradePartyTypeRelatePartner:
			{
				tradePartyInfo.RelatePartner = party.PartyName
			}
		case _const.TradePartyTypeEndUser:
			{
				tradePartyInfo.EndUser = party.PartyName
			}
		case _const.TradePartyTypeEndUserAccountID:
			{
				tradePartyInfo.EndUserAccountID = party.PartyName
			}
		case _const.TradePartyTypeOpportunityName:
			{
				tradePartyInfo.OpportunityName = party.PartyName
			}
		case _const.TradePartyTypeOpportunityID:
			{
				tradePartyInfo.OpportunityID = party.PartyName
			}
		}
	}
	tradePartyInfo.Subject = subject
	tradePartyInfo.OtherParty = other
	return &tradePartyInfo
}

func ConverTradePartyDB(meta *ContractMetaDB, info *bizmodels.TradePartyInfo) ContractTradePartyDBList {
	var res ContractTradePartyDBList
	// 我方主体拆分
	for _, party := range info.Subject {
		res = append(res, buildTradeParty(meta, party, _const.TradePartyTypeSubject)...)
	}
	// 对方主体拆分
	for _, party := range info.OtherParty {
		res = append(res, buildTradeParty(meta, party, _const.TradePartyTypeOther)...)
		res = append(res, buildTradeAccountId(meta, party)...)
	}
	if len(info.EndUser) > 0 {
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			PartyName:      info.EndUser,
			PartyType:      _const.TradePartyTypeEndUser,
		})
	}
	if len(info.EndUserAccountID) > 0 {
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			PartyName:      info.EndUserAccountID,
			PartyType:      _const.TradePartyTypeEndUserAccountID,
		})
	}
	if len(info.OpportunityName) > 0 {
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			PartyName:      info.OpportunityName,
			PartyType:      _const.TradePartyTypeOpportunityName,
		})
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			PartyName:      info.OpportunityID,
			PartyType:      _const.TradePartyTypeOpportunityID,
		})
	}
	if len(info.RelatePartner) > 0 {
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			PartyName:      info.RelatePartner,
			PartyType:      _const.TradePartyTypeRelatePartner,
		})
	}
	return res
}

func buildTradeParty(meta *ContractMetaDB, party *bizmodels.TradePartyInfoDetail, partyType int) ContractTradePartyDBList {
	var res ContractTradePartyDBList
	body, _ := json.Marshal(party)
	res = append(res, &ContractTradePartyDB{
		VolcContractID: int(meta.Id),
		ContractNo:     meta.ContractNo,
		PartyName:      party.PartyName,
		PartyType:      partyType,
		Ext:            string(body),
	})
	return res
}

func buildTradeAccountId(meta *ContractMetaDB, party *bizmodels.TradePartyInfoDetail) ContractTradePartyDBList {
	var res ContractTradePartyDBList
	accountIds := util.SingleList(strings.Split(party.AccountID, ","))
	for _, accountId := range accountIds {
		res = append(res, &ContractTradePartyDB{
			VolcContractID: int(meta.Id),
			ContractNo:     meta.ContractNo,
			AccountId:      accountId,
			PartyType:      _const.TradePartyTypeAccount,
		})
	}
	return res
}

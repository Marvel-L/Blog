package model

import "code.byted.org/security/dkms-gorm/encrypt_type"

const (
	CardNoManually = 1
)

// MdPartyInfoDB
type MdPartyInfoDB struct {
	BaseDB
	AccountID      int
	IdentityStatus int
	MdmCode        string
	SubjectType    string
	CardType       string
	IdentName      string
	IdentNo        string                      `gorm:"column:ident_no;type:varchar(45)" kms:"double_write:EncryptIdentNo"`
	Manually       int                         // 1 手动填写
	EncryptIdentNo *encrypt_type.EncryptString `gorm:"column:encrypt_ident_no;type:varchar(200)" dkmsId:"eps.platform.volc_contract_dkms_siv" encodeFormat:"base64"`
}

// MdPartyInfo
type MdPartyInfo struct {
	ID          uint64
	AccountID   int
	MdmCode     string
	SubjectType string
	CardType    string
	IdentName   string
	IdentNo     string
	CreatedTime string
	UpdatedTime string
	Status      int
}

// GenResp GenResp
func (db *MdPartyInfoDB) GenResp() *MdPartyInfo {
	return &MdPartyInfo{
		ID:          db.Id,
		AccountID:   db.AccountID,
		MdmCode:     db.MdmCode,
		SubjectType: db.SubjectType,
		CardType:    db.CardType,
		IdentName:   db.IdentName,
		IdentNo:     db.IdentNo,
		CreatedTime: FormatTime(db.CreatedTime),
		UpdatedTime: FormatTime(db.UpdatedTime),
		Status:      db.Status,
	}
}

// MdPartyInfoDBList
type MdPartyInfoDBList []*MdPartyInfoDB

// GenResp GenResp
func (db *MdPartyInfoDBList) GenResp() []*MdPartyInfo {
	ret := make([]*MdPartyInfo, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

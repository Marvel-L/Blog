package model

import (
	"time"

	"volc_contract_process/biz/bizmodels"
)

// CommonOpRecordReq 查询参数
type CommonOpRecordReq struct {
	IdentNo   string `json:"SceneNo" query:"QuoteNo, IdentNo"` // 合同号
	Limit     int    `json:"Limit" query:"Limit"`              // 分页大小 0表示不限
	Offset    int    `json:"Offset" query:"Offset"`            // 偏移
	NeedTotal bool   // 是否需要返回计数信息
}

type CommonOperationRecordCreatedTimeReq struct {
	VolcContractID int64
	Scene          int
	Operation      int
	CreatedTime    time.Time
}

type CommonOperationRecordDB struct {
	BaseDB
	VolcContractID int64  // meta表ID
	IdentNo        string // 操作对象
	Operator       string // 操作人，可能是内部人员邮箱 或者外部客户ID
	Operation      int    // 操作
	Scene          int    // 业务场景
	Remark         string // 节点描述
	Extra          string // 额外信息
}

type CommonOperationRecordDBList []*CommonOperationRecordDB

func (db *CommonOperationRecordDB) GenResp() *bizmodels.CommonOperationRecord {
	return &bizmodels.CommonOperationRecord{
		Operator:    db.Operator,
		Operation:   db.Operation,
		Remark:      db.Remark,
		Extra:       db.Extra,
		OpState:     db.Extra,
		OperateTime: FormatTime(db.CreatedTime),
	}
}

func (db *CommonOperationRecordDBList) GenResp() bizmodels.CommonOperationRecordList {
	ret := make(bizmodels.CommonOperationRecordList, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

package model

// PreContractEditorNotifyDB 编辑器通知暂存
type PreContractEditorNotifyDB struct {
	BaseDB
	NotifyType     int    //
	UniqueKey      string // 唯一键
	PreContractNo  string // 合同编号
	Author         string // 批注人邮箱
	Owner          string // 文件所有者邮箱
	MentionList    string // 被@人员列表，邮箱，多个以逗号分隔
	ContractStatus int    // 合同状态
	Content        string // 批注内容 最长1000字符
}

type PreContractEditorNotifyDBList []*PreContractEditorNotifyDB

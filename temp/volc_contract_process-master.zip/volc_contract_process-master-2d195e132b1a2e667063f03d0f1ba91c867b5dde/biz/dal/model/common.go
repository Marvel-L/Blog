package model

import (
	"time"

	"github.com/shopspring/decimal"
)

const (
	DateFormatTpl   = "20060102T150405Z"
	DBDateFormatTpl = "2006-01-02 15:04:05"
)

type Map map[string]interface{}

func FormatTime(t time.Time) string {
	return t.Format(DBDateFormatTpl)
}

func FormatTime3339(t time.Time) string {
	return t.Format(time.RFC3339)
}

// Decimal2Float
func Decimal2Float(d decimal.Decimal) float64 {
	f, _ := d.Float64()
	return f
}

package model

import (
	"time"

	"code.byted.org/gopkg/context"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv"
	_const "volc_contract_process/pkg/const"
)

// ContractOpRecordReq 查询参数
type ContractOpRecordReq struct {
	PreContractNo     string `json:"PreContractNo" query:"PreContractNo, required"` // 合同号
	PreContractNoList string `json:"PreContractNoList" query:"PreContractNoList"`   // 合同号
	Limit             int    `json:"Limit" query:"Limit"`                           // 分页大小 0表示不限
	Offset            int    `json:"Offset" query:"Offset"`                         // 偏移
	NeedTotal         bool   // 是否需要返回计数信息
}

type ContractOperationRecordCreatedTimeReq struct {
	PreContractNo  string
	Operation      int
	ContractStatus int
	CreatedTime    time.Time
}

type ContractOperationRecordDB struct {
	BaseDB
	PreContractNo          string
	Operator               string
	Operation              int
	SecondaryOperationType int
	ContractStatus         int
	Remark                 string // 审核意见/备注/撤回原因
	CommentID              int    // 审批意见唯一id
	Extra                  string // 加签人员/转办人员
	RelatedFileVersion     string // 合同关联文件版本信息
	SkipReturnReview       int    // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重审
	SendBackTargetStatus   int    `gorm:"column:send_back_target_status" json:"SendBackTargetStatus"` // 指定退回目标节点状态
}

type ContractOperationRecordDBList []*ContractOperationRecordDB

func (db ContractOperationRecordDB) GenResp() *bizmodels.CooperationRecord {
	return &bizmodels.CooperationRecord{
		NodeName:               multienv.GetAuditNodeStatusName(context.Background(), db.ContractStatus),
		ContractStatus:         db.ContractStatus,
		Operator:               db.Operator,
		Operation:              db.Operation,
		SecondaryOperationType: db.SecondaryOperationType,
		Remark:                 db.Remark,
		Extra:                  db.Extra,
		CommentID:              db.CommentID,
		Comment:                &bizmodels.RichTextInfo{RichtextPlainText: db.Remark}, // 兼容历史数据
		AuditTime:              FormatTime(db.CreatedTime),
		OperateTime:            FormatTime(db.CreatedTime),
		RelatedFileVersion:     db.RelatedFileVersion,
		SkipReturnReview:       db.SkipReturnReview,
		RecordSource:           _const.RecordSourceVolcano,
		SendBackTargetStatus:   db.SendBackTargetStatus,
	}
}

func (db ContractOperationRecordDBList) GenResp() bizmodels.CooperationRecordList {
	ret := make(bizmodels.CooperationRecordList, len(db))
	for i, d := range db {
		ret[i] = d.GenResp()
	}
	return ret
}

func (db ContractOperationRecordDBList) GetCommentIDs() []int {
	ret := []int{}
	for _, d := range db {
		ret = append(ret, d.CommentID)
	}
	return ret
}

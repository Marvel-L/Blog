package model

import (
	"encoding/json"
	"time"

	"volc_contract_process/biz/bizmodels"

	_const "volc_contract_process/pkg/const"
)

type BizContractReq struct {
	SourceType          _const.SourceType
	Scene               int
	CurrentOperator     string
	Status              string
	Identifier          string
	ContractNo          string
	ContractNoList      []string //
	CreateTimeBegin     int64
	CreateTimeEnd       int64
	UpdateTimeBegin     int64
	UpdateTimeEnd       int64
	ValidityBegin       int64
	ValidityEnd         int64
	ExcludeScreenStatus []int // 不包含的状态
	AccountID           int
	OrderBy             int
	IsManager           bool // 是否为管理员
	Limit               int
	Offset              int
	NeedTotal           bool
}

// BizContractDB 合同信息
type BizContractDB struct {
	BaseDB
	Scene          int
	Identifier     string
	ContractNo     string
	AccountID      int64
	Creator        string
	ValidityBegin  time.Time
	ValidityEnd    time.Time
	FileIdUnsigned string
	FileIdSigned   string
	BizDataInfo    string
	Remark         string
	FinishTime     time.Time
	Extra          string
	OaContractNo   string
}

type ContractNoVo struct {
	ContractNo string
}

func (q *BizContractDB) GenResp() *bizmodels.BizContract {

	var finishTime string
	if !q.FinishTime.IsZero() {
		finishTime = FormatTime(q.FinishTime)
	}
	var validityBegin string
	if !q.ValidityBegin.IsZero() {
		validityBegin = FormatTime(q.ValidityBegin)
	}
	var validityEnd string
	if !q.ValidityEnd.IsZero() {
		validityEnd = FormatTime(q.ValidityEnd)
	}
	var creditType string
	var creditLimit float64
	if q.Scene == _const.SceneCreditContract {
		var bizInfo CreditItem
		if err := json.Unmarshal([]byte(q.BizDataInfo), &bizInfo); err == nil {
			creditType = bizInfo.CreditType
			creditLimit = bizInfo.CreditLimit
		}
	}

	return &bizmodels.BizContract{
		ContractNo:     q.ContractNo,
		Scene:          q.Scene,
		Identifier:     q.Identifier,
		AccountID:      q.AccountID,
		ValidityBegin:  validityBegin,
		ValidityEnd:    validityEnd,
		Creator:        q.Creator,
		CreateTime:     FormatTime(q.CreatedTime),
		FinishTime:     finishTime,
		BizInfo:        q.BizDataInfo,
		FileIdUnsigned: q.FileIdUnsigned,
		FileIdSigned:   q.FileIdSigned,
		Remark:         q.Remark,
		Status:         q.Status,
		Extra:          q.Extra,
		OaContractNo:   q.OaContractNo,
		CreditType:     creditType,
		CreditLimit:    creditLimit,
	}
}

type BizContractDBList []*BizContractDB

// BizContractList 业务合同列表
type BizContractList []*bizmodels.BizContract

// GenResp GenResp
func (db *BizContractDBList) GenResp() BizContractList {
	ret := make([]*bizmodels.BizContract, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

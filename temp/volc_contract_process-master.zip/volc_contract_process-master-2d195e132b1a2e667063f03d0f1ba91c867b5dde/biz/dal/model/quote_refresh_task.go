package model

// QuoteRefreshTaskDB 报价刷数任务表
type QuoteRefreshTaskDB struct {
	BaseDB
	RefreshApprovalID string `json:"refresh_approval_id" gorm:"column:refresh_approval_id;NOT NULL"`
	QuoteID           string `json:"quote_id" gorm:"column:quote_id;NOT NULL"`
	ContractNo        string `json:"contract_no" gorm:"column:contract_no;NOT NULL"`
	RefreshScene      string `json:"refresh_scene" gorm:"column:refresh_scene;NOT NULL"`
}

// TableName 返回表名
func (m *QuoteRefreshTaskDB) TableName() string {
	return "quote_refresh_task"
}

type QuoteRefreshTaskDBList []*QuoteRefreshTaskDB

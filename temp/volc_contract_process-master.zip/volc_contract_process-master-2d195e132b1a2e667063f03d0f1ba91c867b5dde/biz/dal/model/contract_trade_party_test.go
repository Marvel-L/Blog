package model

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
)

func Test_GenResp(t *testing.T) {
	mockey.PatchConvey("Test GenResp", t, func() {
		sampleList := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C123",
				PartyName:      "Subject Party",
				AccountId:      "A123",
				PartyType:      _const.TradePartyTypeSubject,
				Ext:            `{"NACustomerTag":"tag1","CustomerName":"Customer1","ContractRoleCode":"CR1","PrimaryFlag":"I","AccountID":"A123","SealAccountID":"SA123","PricingAccountID":"PA123","RelateAccountInfo":{},"PartyName":"Subject Party","PartyNumber":"PN1","LegalPartyNumber":"LPN1","Sealed":1,"Pricing":1,"CpType":"CT1","OtherPartyType":0,"Signer":"Signer1","Email":"email1@example.com","ContactName":"Contact1","CreateSource":"CS1","OfficePhone":"1234567890","SignerPhone":"0987654321","DocumentType":"DT1","DocumentCode":"DC1","Country":"Country1","StateName":"State1","CityName":"City1","Address":"Address1","PayTypes":[],"OpAddress":[],"SignCrossPage":"Y","SignKeyword":"Keyword1","SealType":"ST1","SignTypeLimits":"0"}`,
			},
			{
				VolcContractID: 2,
				ContractNo:     "C456",
				PartyName:      "Other Party",
				AccountId:      "A456",
				PartyType:      _const.TradePartyTypeOther,
				Ext:            `{"NACustomerTag":"tag2","CustomerName":"Customer2","ContractRoleCode":"CR2","PrimaryFlag":"O","AccountID":"A456","SealAccountID":"SA456","PricingAccountID":"PA456","RelateAccountInfo":{},"PartyName":"Other Party","PartyNumber":"PN2","LegalPartyNumber":"LPN2","Sealed":1,"Pricing":1,"CpType":"CT2","OtherPartyType":1,"Signer":"Signer2","Email":"email2@example.com","ContactName":"Contact2","CreateSource":"CS2","OfficePhone":"2345678901","SignerPhone":"1098765432","DocumentType":"DT2","DocumentCode":"DC2","Country":"Country2","StateName":"State2","CityName":"City2","Address":"Address2","PayTypes":[],"OpAddress":[],"SignCrossPage":"N","SignKeyword":"Keyword2","SealType":"ST2","SignTypeLimits":"1"}`,
			},
			{
				VolcContractID: 3,
				ContractNo:     "C789",
				PartyName:      "Relate Partner",
				AccountId:      "A789",
				PartyType:      _const.TradePartyTypeRelatePartner,
			},
			{
				VolcContractID: 4,
				ContractNo:     "C101",
				PartyName:      "End User",
				AccountId:      "A101",
				PartyType:      _const.TradePartyTypeEndUser,
			},
			{
				VolcContractID: 5,
				ContractNo:     "C112",
				PartyName:      "End User Account ID",
				AccountId:      "A112",
				PartyType:      _const.TradePartyTypeEndUserAccountID,
			},
			{
				VolcContractID: 6,
				ContractNo:     "C134",
				PartyName:      "Opportunity Name",
				AccountId:      "A134",
				PartyType:      _const.TradePartyTypeOpportunityName,
			},
			{
				VolcContractID: 7,
				ContractNo:     "C156",
				PartyName:      "Opportunity ID",
				AccountId:      "A156",
				PartyType:      _const.TradePartyTypeOpportunityID,
			},
		}

		expectedResp := &bizmodels.TradePartyInfo{
			Subject: []*bizmodels.TradePartyInfoDetail{
				{
					NACustomerTag:     "tag1",
					CustomerName:      "Customer1",
					ContractRoleCode:  "CR1",
					PrimaryFlag:       "I",
					AccountID:         "A123",
					SealAccountID:     "SA123",
					PricingAccountID:  "PA123",
					RelateAccountInfo: map[string]map[string][]string{},
					PartyName:         "Subject Party",
					PartyNumber:       "PN1",
					LegalPartyNumber:  "LPN1",
					Sealed:            1,
					Pricing:           1,
					CpType:            "CT1",
					OtherPartyType:    0,
					Signer:            "Signer1",
					Email:             "email1@example.com",
					ContactName:       "Contact1",
					CreateSource:      "CS1",
					OfficePhone:       "1234567890",
					SignerPhone:       "0987654321",
					DocumentType:      "DT1",
					DocumentCode:      "DC1",
					Country:           "Country1",
					StateName:         "State1",
					CityName:          "City1",
					Address:           "Address1",
					PayTypes:          []*bizmodels.PayType{},
					OpAddress:         []bizmodels.OpAddress{},
					SignCrossPage:     "Y",
					SignKeyword:       "Keyword1",
					SealType:          "ST1",
					SignTypeLimits:    "0",
				},
			},
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				{
					NACustomerTag:     "tag2",
					CustomerName:      "Customer2",
					ContractRoleCode:  "CR2",
					PrimaryFlag:       "O",
					AccountID:         "A456",
					SealAccountID:     "SA456",
					PricingAccountID:  "PA456",
					RelateAccountInfo: map[string]map[string][]string{},
					PartyName:         "Other Party",
					PartyNumber:       "PN2",
					LegalPartyNumber:  "LPN2",
					Sealed:            1,
					Pricing:           1,
					CpType:            "CT2",
					OtherPartyType:    1,
					Signer:            "Signer2",
					Email:             "email2@example.com",
					ContactName:       "Contact2",
					CreateSource:      "CS2",
					OfficePhone:       "2345678901",
					SignerPhone:       "1098765432",
					DocumentType:      "DT2",
					DocumentCode:      "DC2",
					Country:           "Country2",
					StateName:         "State2",
					CityName:          "City2",
					Address:           "Address2",
					PayTypes:          []*bizmodels.PayType{},
					OpAddress:         []bizmodels.OpAddress{},
					SignCrossPage:     "N",
					SignKeyword:       "Keyword2",
					SealType:          "ST2",
					SignTypeLimits:    "1",
				},
			},
			RelatePartner:    "Relate Partner",
			EndUser:          "End User",
			EndUserAccountID: "End User Account ID",
			OpportunityName:  "Opportunity Name",
			OpportunityID:    "Opportunity ID",
		}

		actualResp := sampleList.GenResp()
		convey.So(actualResp, convey.ShouldResemble, expectedResp)
	})
}

func Test_ConverTradePartyDB(t *testing.T) {
	meta := &ContractMetaDB{
		BaseDB: BaseDB{
			Id: 1,
		},
		ContractNo: "C001",
		// Other fields can be set as needed
	}
	info := &bizmodels.TradePartyInfo{
		Subject: []*bizmodels.TradePartyInfoDetail{
			{
				CustomerName: "Subject1",
				AccountID:    "A001",
				// Other fields can be set as needed
			},
		},
		OtherParty: []*bizmodels.TradePartyInfoDetail{
			{
				CustomerName: "OtherParty1",
				AccountID:    "B001",
				// Other fields can be set as needed
			},
		},
		EndUser:          "EndUser1",
		EndUserAccountID: "EUA001",
		OpportunityName:  "Opportunity1",
		OpportunityID:    "OP001",
		RelatePartner:    "RelatePartner1",
	}

	mockey.PatchConvey("Test ConverTradePartyDB with all fields", t, func() {
		mockey.Mock(buildTradeParty).Return([]*ContractTradePartyDB{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Subject1",
				PartyType:      _const.TradePartyTypeSubject,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OtherParty1",
				PartyType:      _const.TradePartyTypeOther,
			},
		}).Build()
		mockey.Mock(buildTradeAccountId).Return([]*ContractTradePartyDB{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "B001",
				PartyType:      _const.TradePartyTypeOther,
			},
		}).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Subject1",
				PartyType:      1,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OtherParty1",
				PartyType:      2,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Subject1",
				PartyType:      1,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OtherParty1",
				PartyType:      2,
			}, {
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "B001",
				PartyType:      2,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "EndUser1",
				PartyType:      4,
			}, {
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "EUA001",
				PartyType:      7,
			}, {
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Opportunity1",
				PartyType:      5,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OP001",
				PartyType:      6,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "RelatePartner1",
				PartyType:      8,
			}}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with empty fields", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject:          []*bizmodels.TradePartyInfoDetail{},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "",
			EndUserAccountID: "",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return(nil).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only subject", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject: []*bizmodels.TradePartyInfoDetail{
				{
					CustomerName: "Subject1",
					AccountID:    "A001",
					// Other fields can be set as needed
				},
			},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "",
			EndUserAccountID: "",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return([]*ContractTradePartyDB{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Subject1",
				PartyType:      _const.TradePartyTypeSubject,
			},
		}).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Subject1",
				PartyType:      _const.TradePartyTypeSubject,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only other party", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject: []*bizmodels.TradePartyInfoDetail{},
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				{
					CustomerName: "OtherParty1",
					AccountID:    "B001",
					// Other fields can be set as needed
				},
			},
			EndUser:          "",
			EndUserAccountID: "",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return([]*ContractTradePartyDB{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OtherParty1",
				PartyType:      _const.TradePartyTypeOther,
			},
		}).Build()
		mockey.Mock(buildTradeAccountId).Return([]*ContractTradePartyDB{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "B001",
				PartyType:      _const.TradePartyTypeOther,
			},
		}).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OtherParty1",
				PartyType:      _const.TradePartyTypeOther,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "B001",
				PartyType:      _const.TradePartyTypeOther,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only end user", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject:          []*bizmodels.TradePartyInfoDetail{},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "EndUser1",
			EndUserAccountID: "",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return(nil).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "EndUser1",
				PartyType:      _const.TradePartyTypeEndUser,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only end user account ID", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject:          []*bizmodels.TradePartyInfoDetail{},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "",
			EndUserAccountID: "EUA001",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return(nil).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "EUA001",
				PartyType:      _const.TradePartyTypeEndUserAccountID,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only opportunity name and ID", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject:          []*bizmodels.TradePartyInfoDetail{},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "",
			EndUserAccountID: "",
			OpportunityName:  "Opportunity1",
			OpportunityID:    "OP001",
			RelatePartner:    "",
		}
		mockey.Mock(buildTradeParty).Return(nil).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "Opportunity1",
				PartyType:      _const.TradePartyTypeOpportunityName,
			},
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "OP001",
				PartyType:      _const.TradePartyTypeOpportunityID,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConverTradePartyDB with only relate partner", t, func() {
		info := &bizmodels.TradePartyInfo{
			Subject:          []*bizmodels.TradePartyInfoDetail{},
			OtherParty:       []*bizmodels.TradePartyInfoDetail{},
			EndUser:          "",
			EndUserAccountID: "",
			OpportunityName:  "",
			OpportunityID:    "",
			RelatePartner:    "RelatePartner1",
		}
		mockey.Mock(buildTradeParty).Return(nil).Build()
		mockey.Mock(buildTradeAccountId).Return(nil).Build()

		actual := ConverTradePartyDB(meta, info)
		expected := ContractTradePartyDBList{
			{
				VolcContractID: 1,
				ContractNo:     "C001",
				PartyName:      "RelatePartner1",
				PartyType:      _const.TradePartyTypeRelatePartner,
			},
		}
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

func Test_buildTradeAccountId(t *testing.T) {
	meta := &ContractMetaDB{
		BaseDB: BaseDB{
			Id: 123,
		},
		ContractNo: "C123456",
		// Other fields can be initialized as needed
	}
	party := &bizmodels.TradePartyInfoDetail{
		AccountID: "acc1,acc2,acc3",
		// Other fields can be initialized as needed
	}

	mockey.PatchConvey("Test with multiple account IDs", t, func() {
		expectedRes := ContractTradePartyDBList{
			&ContractTradePartyDB{
				VolcContractID: 123,
				ContractNo:     "C123456",
				AccountId:      "acc1",
				PartyType:      _const.TradePartyTypeAccount,
			},
			&ContractTradePartyDB{
				VolcContractID: 123,
				ContractNo:     "C123456",
				AccountId:      "acc2",
				PartyType:      _const.TradePartyTypeAccount,
			},
			&ContractTradePartyDB{
				VolcContractID: 123,
				ContractNo:     "C123456",
				AccountId:      "acc3",
				PartyType:      _const.TradePartyTypeAccount,
			},
		}
		actualRes := buildTradeAccountId(meta, party)
		convey.So(actualRes, convey.ShouldResemble, expectedRes)
	})

	mockey.PatchConvey("Test with single account ID", t, func() {
		party.AccountID = "acc1"
		expectedRes := ContractTradePartyDBList{
			&ContractTradePartyDB{
				VolcContractID: 123,
				ContractNo:     "C123456",
				AccountId:      "acc1",
				PartyType:      _const.TradePartyTypeAccount,
			},
		}
		actualRes := buildTradeAccountId(meta, party)
		convey.So(actualRes, convey.ShouldResemble, expectedRes)
	})

	mockey.PatchConvey("Test with empty account ID", t, func() {
		party.AccountID = ""
		actualRes := buildTradeAccountId(meta, party)
		convey.So(actualRes, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test with nil meta", t, func() {
		meta = nil
		actualRes := buildTradeAccountId(meta, party)
		convey.So(actualRes, convey.ShouldBeNil)
	})
}

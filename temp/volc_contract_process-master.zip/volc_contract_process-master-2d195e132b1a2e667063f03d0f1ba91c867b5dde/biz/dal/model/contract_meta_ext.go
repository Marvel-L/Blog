package model

// VolcContractManage 火山合同管理信息表
type ContractMetaExt struct {
	BaseDB
	ContractId uint64 `json:"contract_id" gorm:"column:contract_id;default:0;NOT NULL"` // meta表ID
	AttrKey    string `json:"attr_key" gorm:"column:attr_key;NOT NULL"`                 // 扩展信息key
	AttrValue  string `json:"attr_value" gorm:"column:attr_value"`                      // 扩展信息value
}

func (m *ContractMetaExt) TableName() string {
	return "volc_contract_meta_ext"
}

type ContractMetaExtList []*ContractMetaExt

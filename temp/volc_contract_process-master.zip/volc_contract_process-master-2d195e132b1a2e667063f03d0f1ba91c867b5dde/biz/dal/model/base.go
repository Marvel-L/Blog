package model

import (
	"time"
)

type BaseDB struct {
	Id          uint64    `json:"-" gorm:"primary_key"`
	CreatedTime time.Time `json:"-" gorm:"autoCreateTime"`
	UpdatedTime time.Time `json:"-" gorm:"autoUpdateTime"`
	Status      int       `json:"status"`
}

package model

type RiskClauseRoleReviewerDB struct {
	BaseDB
	RiskClauseRoleID int    `gorm:"column:risk_clause_role_id" db:"risk_clause_role_id" json:"risk_clause_role_id" form:"risk_clause_role_id"` // 关联风险条款条目ID
	ReviewerType     int    `gorm:"column:reviewer_type" db:"reviewer_type" json:"reviewer_type" form:"reviewer_type"`                         // 审批人类型
	Reviewer         string `gorm:"column:reviewer" db:"reviewer" json:"reviewer" form:"reviewer"`                                             // 审批人值
	IsDeleted        int    `gorm:"column:is_deleted" db:"is_deleted" json:"is_deleted" form:"is_deleted"`                                     // 是否已删除，1-是 0-否
	Creator          string `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                                 // 创建人
	Updater          string `gorm:"column:updater" db:"updater" json:"updater" form:"updater"`                                                 // 更新人
}

type RiskClauseReviewerSecData struct {
	Lable                 []string // 展示文案
	FirstLevelDepartment  string   // 一级产品线
	SecondLevelDepartment string   // 二级产品线
}

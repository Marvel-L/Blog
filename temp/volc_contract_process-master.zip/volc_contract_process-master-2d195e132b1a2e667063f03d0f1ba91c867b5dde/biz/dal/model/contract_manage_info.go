package model

import (
	"encoding/json"
	"fmt"
	"time"

	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

// VolcContractManage 火山合同管理信息表
type VolcContractManage struct {
	BaseDB
	VolcContractId           uint64          `json:"volc_contract_id" gorm:"column:volc_contract_id;default:0;NOT NULL"`       // meta表ID
	ContractNo               string          `json:"contract_no" gorm:"column:contract_no;NOT NULL"`                           // 合同ID
	Version                  int             `json:"version" gorm:"column:version;default:0;NOT NULL"`                         // 合同版本
	PaymentType              string          `json:"payment_type" gorm:"column:payment_type;NOT NULL"`                         // 预算科目
	PaymentTypeName          string          `json:"payment_type_name" gorm:"column:payment_type_name;NOT NULL"`               // 预算科目名称
	DistributBusinessType    int             `json:"distribut_business_type" gorm:"column:distribut_business_type;NOT NULL"`   // 分销业务类型
	BelongingDepartment      string          `json:"belonging_department" gorm:"column:belonging_department;NOT NULL"`         // 一级产品线
	ProductLine              string          `json:"product_line" gorm:"column:product_line;NOT NULL"`                         // 产品线
	RelatedPersonnel         string          `json:"related_personnel" gorm:"column:related_personnel;NOT NULL"`               // 相关人员
	LegalReviewer            string          `json:"legal_reviewer" gorm:"column:legal_reviewer;NOT NULL"`                     // 法务审核人
	FeishuApostilleInfo      string          `json:"feishu_apostille_info" gorm:"column:feishu_apostille_info;NOT NULL"`       // 飞书加签人信息
	ReceivingPlace           string          `json:"receiving_place" gorm:"column:receiving_place;NOT NULL"`                   // 领取地点编号
	UsefulLifeType           int             `json:"useful_life_type" gorm:"column:useful_life_type;default:1;NOT NULL"`       // 有效期类型。1：固定期限； 2：自签订生效
	IndefiniteDateFlag       string          `json:"indefinite_date_flag" gorm:"column:indefinite_date_flag;NOT NULL"`         // 有效期有无期限标识。Y:无限期 N:有限期
	UsefulLifeUnit           string          `json:"useful_life_unit" gorm:"column:useful_life_unit;NOT NULL"`                 // 有效期单位，当合同为“自签订之日起生效”时使用 DAY:日 MONTH:月 YEAR:年
	UsefulLifeNum            int             `json:"useful_life_num" gorm:"column:useful_life_num;default:0;NOT NULL"`         // 有效期数值，当合同为“自签订之日起生效”时使用
	LongLifeReason           string          `json:"long_life_reason" gorm:"column:long_life_reason;NOT NULL"`                 // 长有效期原因  最多200字符
	ProductValidityBegin     time.Time       `json:"product_validity_begin" gorm:"column:product_validity_begin;NOT NULL"`     // 产品有效期起始日期
	ProductValidityEnd       time.Time       `json:"product_validity_end" gorm:"column:product_validity_end;NOT NULL"`         // 产品有效期截止日期
	AccountAssociationInfo   string          `json:"account_association_info" gorm:"column:account_association_info;NOT NULL"` // 商品行分组信息
	QuoteAccountID           string          `json:"quote_account_id" gorm:"column:quote_account_id;NOT NULL"`                 // 报价单账号
	SealAccountID            string          `json:"seal_account_id" gorm:"seal_account_id;NOT NULL"`                          // 合同关联签约账号，报价单关联
	PricingAccountID         string          `json:"pricing_account_id" gorm:"pricing_account_id;NOT NULL"`                    // 合同关联配价账号，报价单关联
	EndUser                  string          `json:"end_user" gorm:"end_user;NOT NULL"`                                        // 合同关联最终用户，报价单关联
	EndUserAccountID         string          `json:"end_user_account_id" gorm:"end_user_account_id;NOT NULL"`                  // 合同关联最终用户账号ID，报价单关联
	WhetherProject           string          `json:"whether_project" gorm:"column:whether_project;NOT NULL"`                   // 是否项目制 Y:是；N:否
	ProgressiveType          string          `json:"progressive_type" gorm:"column:progressive_type;NOT NULL"`                 // 是否项目制 Y:是；N:否
	ProductTotalIncome       decimal.Decimal `json:"product_total_income" gorm:"column:product_total_income;default:0;NOT NULL"`
	RelateQuoteChanged       bool            `json:"relate_quote_changed" gorm:"column:relate_quote_changed;default:0;NOT NULL"`
	RelateQuoteChangedBefore string          `json:"relate_quote_changed_before" gorm:"column:relate_quote_changed_before;NOT NULL"`
	IsSplitProduct           bool            `json:"is_split_product" gorm:"column:is_split_product;default:0;NOT NULL"` // 是否拆分内外部映射表
	Remark                   string          `json:"remark" gorm:"column:remark"`                                        // 备注信息
}

func (m *VolcContractManage) TableName() string {
	return "volc_contract_manage"
}

func (m *VolcContractManage) AllFieldUpdate(new *VolcContractManage, forceUpdates ...map[string]interface{}) {
	if new == nil {
		return
	}
	if m.ContractNo == "" {
		m.ContractNo = new.ContractNo
		m.Version = new.Version
	}
	if len(new.BelongingDepartment) != 0 {
		m.BelongingDepartment = new.BelongingDepartment
	}
	if len(new.ProductLine) != 0 {
		m.ProductLine = new.ProductLine
	}
	if len(new.PaymentType) != 0 {
		m.PaymentType = new.PaymentType
		m.PaymentTypeName = new.PaymentTypeName
	}
	m.VolcContractId = new.VolcContractId
	m.RelatedPersonnel = new.RelatedPersonnel
	m.LegalReviewer = new.LegalReviewer
	m.FeishuApostilleInfo = new.FeishuApostilleInfo
	m.ReceivingPlace = new.ReceivingPlace
	m.Remark = new.Remark
	m.ProductValidityBegin = new.ProductValidityBegin
	m.ProductValidityEnd = new.ProductValidityEnd
	m.QuoteAccountID = new.QuoteAccountID
	m.SealAccountID = new.SealAccountID
	m.PricingAccountID = new.PricingAccountID
	m.EndUser = new.EndUser
	m.EndUserAccountID = new.EndUserAccountID
	m.WhetherProject = new.WhetherProject
	m.IsSplitProduct = new.IsSplitProduct
	m.DistributBusinessType = new.DistributBusinessType

	usefulLifeType := new.UsefulLifeType
	if usefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		usefulLifeType = _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
	}
	// 自合同签订日生效相关字段
	m.UsefulLifeType = usefulLifeType
	m.IndefiniteDateFlag = new.IndefiniteDateFlag
	m.UsefulLifeUnit = new.UsefulLifeUnit
	m.UsefulLifeNum = new.UsefulLifeNum
	m.LongLifeReason = new.LongLifeReason

	m.AccountAssociationInfo = new.AccountAssociationInfo

	if len(forceUpdates) == 0 || forceUpdates[0] == nil {
		return
	}
	body, _ := json.Marshal(forceUpdates[0])
	_ = json.Unmarshal(body, m)
}

type VolcContractManageList []*VolcContractManage

// VolcContractCommodityExternal 火山合同商品信息-外部映射表
type VolcContractCommodityExternal struct {
	BaseDB
	VolcContractID    uint64 `gorm:"column:volc_contract_id;NOT NULL"`     // 合同元数据表 ID
	GroupID           int    `gorm:"column:group_id;NOT NULL"`             // 组别，主条目与子条目同组
	RecordType        int    `gorm:"column:record_type;NOT NULL"`          // 类型，1：主条目、2：子条目
	RelateQuoteItemID string `gorm:"column:relate_quote_item_id;NOT NULL"` // 关联报价项 ID，主条目为多个内部报价项 ID 逗号拼接
	TradeProductName  string `gorm:"column:trade_product_name;NOT NULL"`   // 商品名称（类型为主条目时，含义为对客商品名称）
	BuyNum            string `gorm:"column:buy_num;NOT NULL"`              // 数量
	BuyNumUnit        string `gorm:"column:buy_num_unit;NOT NULL"`         // 数量单位
	BuyDuration       string `gorm:"column:buy_duration;NOT NULL"`         // 时长
	BuyDurationUnit   string `gorm:"column:buy_duration_unit;NOT NULL"`    // 时长单位
	UnitPrice         string `gorm:"column:unit_price;NOT NULL"`           // 单价
	IncomeNoTax       string `gorm:"column:income_no_tax;NOT NULL"`        // 总价
	TaxRate           string `gorm:"column:tax_rate;NOT NULL"`             // 税率
	Remark            string `gorm:"column:remark;NOT NULL"`               // 备注
}

type VolcContractCommodityExternalList []*VolcContractCommodityExternal

func (c *VolcContractCommodityExternal) GenProductInfo(product *bizmodels.ProductInfo) *bizmodels.ExternalProductInfo {
	res := &bizmodels.ExternalProductInfo{
		ID:                c.Id,
		VolcContractID:    c.VolcContractID,
		GroupID:           c.GroupID,
		RecordType:        c.RecordType,
		TradeProductName:  c.TradeProductName,
		Remark:            c.Remark,
		BuyNum:            c.BuyNum,
		BuyNumUnit:        c.BuyNumUnit,
		BuyDuration:       c.BuyDuration,
		BuyDurationUnit:   c.BuyDurationUnit,
		IncomeNoTax:       c.IncomeNoTax,
		RelateQuoteItemID: c.RelateQuoteItemID,
		UnitPrice:         c.UnitPrice,
		TaxRate:           c.TaxRate,
		Status:            c.Status,
		DeploymentType:    -1, // 主条目不展示部署方式，默认返回-1
	}
	if product != nil {
		res.TradeSolution = product.TradeSolution
		res.CanPrePay = product.CanPrePay
		res.ConfigCategory = product.ConfigCategory
		res.Configuration = product.Configuration
		res.SellingMode = product.SellingMode
		res.ChargeItemTag = product.ChargeItemTag
		res.ChargeItemCode = product.ChargeItemCode
		res.BillingName = product.BillingName
		res.TradeSolutionName = product.TradeSolutionName
		res.Region = product.Region
		res.ChargeElement = product.ChargeElement
		res.PriceFactor = product.PriceFactor
		res.PriceType = product.PriceType
		res.Income = product.Income
		res.IncomeCode = product.IncomeCode
		res.DeploymentType = product.DeploymentType
		res.QuoteItemID = product.QuoteItemID
		res.Discount = product.Discount
		res.DistributionDiscounts = product.DistributionDiscounts
		res.InvoiceProjectCode = product.InvoiceProjectCode // 开票项目业务主键,*信息技术服务*技术服务费
		res.TaxRatio = product.TaxRatio                     // 税率
		res.InvoiceProject = product.InvoiceProject         // 开票项目
		res.GuaranteedPercentage = product.GuaranteedPercentage
		res.TradeProductCode = product.TradeProductCode
		res.TradeProduct = product.TradeProduct
		res.PrePayRatio = product.PrePayRatio
		res.PrePayRatioCode = product.PrePayRatioCode
		res.SpBuyDuration = product.SpBuyDuration
		res.SpBuyDurationCode = product.SpBuyDurationCode
		res.CommitFeeInterval = product.CommitFeeInterval
		res.CommitFeeIntervalCode = product.CommitFeeIntervalCode
		res.SalesMode = product.SalesMode
		res.ConfigIsPublic = product.ConfigIsPublic
		res.ConfigPublicDisplay = product.ConfigPublicDisplay
		res.Quantity = product.Quantity
		res.QuantityUnit = product.QuantityUnit
		res.RelatedItemID = product.RelatedItemID
		res.ItemBusinessRole = product.ItemBusinessRole
	}
	return res
}

func (c VolcContractCommodityExternalList) GenProductInfo(productMap map[string]*bizmodels.ProductInfo) []*bizmodels.ExternalProductInfo {
	res := []*bizmodels.ExternalProductInfo{}
	for _, commodity := range c {
		if commodity.RecordType == _const.ExternalCommodityRecordTypeMaster {
			res = append(res, commodity.GenProductInfo(nil))
		} else {
			res = append(res, commodity.GenProductInfo(productMap[commodity.RelateQuoteItemID]))
		}
	}
	return res
}

func (c VolcContractCommodityExternalList) ValidateBuyNum(ctx context.Context, productMap map[string]*bizmodels.ProductInfo) errors.APIError {
	// buyNumSumMap := map[string]decimal.Decimal{}
	for _, commodity := range c {
		if commodity.RecordType == _const.ExternalCommodityRecordTypeMaster {
			continue
		}
		if len(commodity.BuyNum) == 0 {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为空",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum))
		}
		buyNum, err := decimal.NewFromString(commodity.BuyNum)
		if err != nil {
			logs.CtxError(ctx, "分组[%d]外部商品行[%s]购买数据[%s]格式异常[%s]",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum, err.Error())
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]格式异常[%s]",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum, err.Error()))
		}

		logs.CtxInfo(ctx, "[ValidateBuyNum]buyNum=%s", buyNum.String())
		// 新增校验 必须>=0
		if buyNum.LessThanOrEqual(decimal.Zero) {
			logs.CtxError(ctx, "分组[%d]外部商品行[%s]购买数据[%s]不允许为0",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum)
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为0",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum))
		}
	}
	return nil
}

func (c VolcContractCommodityExternalList) Validate() errors.APIError {
	for _, commodity := range c {
		if len(commodity.RelateQuoteItemID) == 0 {
			return errors.ErrMissingParam.WithArgs("ExternalCommodity.RelateQuoteItemID")
		}
		if commodity.GroupID == 0 {
			return errors.ErrMissingParam.WithArgs("ExternalCommodity.GroupID")
		}
	}
	return nil
}

// VolcContractCommodity 火山合同商品信息表
type VolcContractCommodity struct {
	BaseDB
	VolcContractID        uint64          `gorm:"column:volc_contract_id;default:0;NOT NULL"` // meta表ID
	ContractNo            string          `gorm:"column:contract_no;NOT NULL"`                // 合同号
	Version               int             `gorm:"column:version;default:0;NOT NULL"`          // 合同版本
	TradeProduct          string          `gorm:"column:trade_product;NOT NULL"`              // 商品英文名唯一标识
	TradeProductCode      string          `gorm:"column:trade_product_code;NOT NULL"`         // 商品Code
	TradeProductName      string          `gorm:"column:trade_product_name;NOT NULL"`         // 商品名称
	Income                decimal.Decimal `gorm:"column:income;default:0;NOT NULL"`           // 收入金额
	InvoiceProject        string          `gorm:"column:invoice_project;NOT NULL"`            // 开票项目信息,*信息技术服务*技术服务费*6%
	InvoiceProjectCode    string          `gorm:"column:invoice_project_code;NOT NULL"`       // 开票项目业务主键,*信息技术服务*技术服务费
	TaxRatio              decimal.Decimal `gorm:"column:tax_ratio;default:0;NOT NULL"`        // 税率
	IncomeCode            string          `gorm:"column:income_code;NOT NULL"`                // 收入性质,来自商品系统
	ChildProductCode      string          `gorm:"column:child_product_code;NOT NULL"`         // 子产品code
	StandardProductCode   string          `gorm:"column:standard_product_code;NOT NULL"`      // 单产品编码
	Configuration         string          `gorm:"column:configuration;NOT NULL"`              // 配置 ConfigCode
	ConfigurationName     string          `gorm:"column:configuration_name;NOT NULL"`         // 配置名称
	ConfigCategory        string          `gorm:"column:config_category;NOT NULL"`            // 配置分类
	BillingMethodCode     string          `gorm:"column:billing_method_code;NOT NULL"`        // 计费方式编码 ChargeMethodCode
	BillingName           string          `gorm:"column:billing_name;NOT NULL"`               // 计费方式名称 非必传 ChargeMethod
	RegionCode            string          `gorm:"column:region_code;NOT NULL"`                // 地域编码
	Region                string          `gorm:"column:region;NOT NULL"`                     // 地域
	ChargeElement         string          `gorm:"column:charge_element;NOT NULL"`             // 计费单元
	ChargeElementCode     string          `gorm:"column:charge_element_code;NOT NULL"`        // 计费单元编码	ChargeUnitCode
	PriceFactor           string          `gorm:"column:price_factor;NOT NULL"`               // 价格影响因子 PriceFactorCode
	PriceFactorCode       string          `gorm:"column:price_factor_code;NOT NULL"`          // 价格影响因子 PriceFactorCode
	PriceType             string          `gorm:"column:price_type;NOT NULL"`                 //	价格类型
	Discount              string          `gorm:"column:discount;"`                           //	折扣/价格
	DistributionDiscounts string          `gorm:"column:distribution_discounts;"`             // 分销折扣
	OffPeakHoursBilling   string          `gorm:"column:off_peak_hours_billing;"`             //	闲时折扣信息
	ChargeItemCode        string          `gorm:"column:charge_item_code;NOT NULL"`           // 计费项编码
	ChargeItemTag         string          `gorm:"column:charge_item_tag;NOT NULL"`            // 计费项标签
	PricingVersion        string          `gorm:"column:pricing_version;NOT NULL"`            // 刊例价版本
	CanPrePay             string          `gorm:"column:can_pre_pay;NOT NULL"`                // 计费方式-1
	CanPrePayCode         string          `gorm:"column:can_pre_pay_code;NOT NULL"`           // 计费方式-预付费
	GuaranteedPercentage  string          `gorm:"column:guaranteed_percentage;NOT NULL"`      // 保底比例
	PayType               string          `gorm:"column:pay_type;NOT NULL"`                   // 支付方式
	Remark                string          `gorm:"column:remark"`                              // 备注信息
	DeploymentType        int             `gorm:"column:deployment_type"`                     // 部署方式0公有云1私有云
	SellingMode           string          `gorm:"column:selling_mode"`                        // 售卖模式 1-抢占式实例
	StandardProduct       string          `gorm:"standard_product;default:0;NOT NULL"`        // 标准商品：1-标品，2-非标品
	ItemType              string          `gorm:"item_type;default:0;NOT NULL"`               // 0-线上标品，1-线下标品
	ActivationType        string          `gorm:"column:activation_type;NOT NULL"`            // 开通类型
	QuoteSolutionID       string          `gorm:"quote_solution_id;default:0;NOT NULL"`       // 解决方案ID
	TradeSolutionCode     string          `gorm:"trade_solution_code;NOT NULL"`               // 商品解决方案code
	TradeSolution         string          `gorm:"trade_solution;NOT NULL"`                    // 商品解决方案英文名
	TradeSolutionName     string          `gorm:"trade_solution_name;NOT NULL"`               // 商品解决方案中文名
	TradeSolutionVersion  string          `gorm:"trade_solution_version;NOT NULL"`            // 商品解决方案版本
	BuyNum                string          `gorm:"buy_num;NOT NULL"`                           // 购买数量
	BuyNumUnit            string          `gorm:"buy_num_unit;NOT NULL"`                      // 购买数量单位
	Quantity              string          `gorm:"column:quantity;NOT NULL"`                   // 预计用量
	QuantityUnit          string          `gorm:"column:quantity_unit;NOT NULL"`              // 预计用量单位
	BuyDuration           string          `gorm:"buy_duration;NOT NULL"`                      // 购买时长
	BuyDurationUnit       string          `gorm:"buy_duration_unit;NOT NULL"`                 // 购买时长单位
	MaintenanceService    string          `gorm:"maintenance_service;NOT NULL"`               // 赠送信息
	MaintenanceNum        string          `gorm:"maintenance_num;NOT NULL"`                   // 赠送数量
	MaintenanceUnit       string          `gorm:"maintenance_unit;NOT NULL"`                  // 赠数量单位
	OriginalPrice         string          `gorm:"original_price;NOT NULL"`                    // 刊例价售卖金额
	IncomeNoTax           string          `gorm:"income_no_tax;NOT NULL"`                     // 折后金额
	PriceInfoSnapshot     string          `gorm:"price_info_snapshot;NOT NULL"`               // 刊例价单价
	QuoteItemID           string          `gorm:"quote_item_id;NOT NULL"`                     // 报价系统数据库中的自增id
	ItemBusinessRole      string          `gorm:"column:item_business_role;NOT NULL"`         // 报价项业务角色：0-标准报价项，1-抵扣报价项
	RelatedItemID         string          `gorm:"column:related_item_id;NOT NULL"`            // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	ShowName              string          `gorm:"show_name;NOT NULL"`                         // 对客名称
	GiveAwayType          string          `gorm:"give_away_type"`                             // 赠送类型：赠送、区间赠送
	ExcludeDetail         string          `gorm:"exclude_detail"`                             // 排除项信息
	SalesMode             string          `gorm:"sales_mode;NOT NULL"`                        // SavingsPlans-节省计划 Others-其他类型商品
	ConfigIsPublic        string          `gorm:"config_is_public;NOT NULL"`                  // 是否公开售卖 0-否 1-是
	ConfigPublicDisplay   string          `gorm:"config_public_display;NOT NULL"`             // 1-非公开售卖配置报价可见 2-非公开售卖配置报价不可见
	PrePayRatio           string          `gorm:"pre_pay_ratio;NOT NULL"`                     // 预付比例
	PrePayRatioCode       string          `gorm:"pre_pay_ratio_code;NOT NULL"`                // 预付比例编码
	SpBuyDuration         string          `gorm:"sp_buy_duration;NOT NULL"`                   // 节省计划购买时长
	SpBuyDurationCode     string          `gorm:"sp_buy_duration_code;NOT NULL"`              // 节省计划购买时长编码
	CommitFeeInterval     string          `gorm:"commit_fee_interval;NOT NULL"`               // 承诺消费金额
	CommitFeeIntervalCode string          `gorm:"commit_fee_interval_code;NOT NULL"`          // 承诺消费金额编码
}

func (c *VolcContractCommodity) OnlineStandard() bool {
	return c.DeploymentType == _const.SettlementDeploymentPublicCloud && c.StandardProduct == _const.STANDARD_PRODUCT_ENUM
}

func (m *VolcContractCommodity) TableName() string {
	return "volc_contract_commodity"
}

type VolcContractCommodityList []*VolcContractCommodity

// ExportCommodityItem 导出商品数据结构，用于维护层级关系与序号
type ExportCommodityItem struct {
	Commodity *VolcContractCommodity // 底层商品数据
	SerialNum string                 // 层级序号，例如 "1", "1-1"
}

func (c *VolcContractCommodity) GenProductInfo() *bizmodels.ProductInfo {
	pricingFunction, _ := bizmodels.GetPricingFunction(context.Background(), c.Discount, c.DistributionDiscounts)
	return &bizmodels.ProductInfo{
		ID:                    c.Id,
		VolcContractID:        c.VolcContractID,
		TradeProduct:          c.TradeProduct,
		TradeProductCode:      c.TradeProductCode,
		TradeProductName:      c.TradeProductName,
		Income:                c.Income,
		InvoiceProjectCode:    c.InvoiceProjectCode,
		TaxRatio:              c.TaxRatio,
		InvoiceProject:        c.InvoiceProject,
		IncomeCode:            c.IncomeCode,
		Remark:                c.Remark,
		ChildProductCode:      c.ChildProductCode,
		StandardProductCode:   c.StandardProductCode,
		Configuration:         c.Configuration,
		ConfigurationName:     c.ConfigurationName,
		ConfigCategory:        c.ConfigCategory,
		BillingMethodCode:     c.BillingMethodCode,
		BillingName:           c.BillingName,
		RegionCode:            c.RegionCode,
		Region:                c.Region,
		ChargeElement:         c.ChargeElement,
		ChargeElementCode:     c.ChargeElementCode,
		PriceFactor:           c.PriceFactor,
		PriceFactorCode:       c.PriceFactorCode,
		PriceType:             pricingFunction,
		Discount:              c.Discount,
		DistributionDiscounts: c.DistributionDiscounts,
		OffPeakHoursBilling:   c.OffPeakHoursBilling,
		ChargeItemCode:        c.ChargeItemCode,
		ChargeItemTag:         c.ChargeItemTag,
		PricingVersion:        c.PricingVersion,
		PayType:               c.PayType,
		CanPrePay:             c.CanPrePay,
		CanPrePayCode:         c.CanPrePayCode,
		GuaranteedPercentage:  c.GuaranteedPercentage,
		DeploymentType:        c.DeploymentType,
		SellingMode:           c.SellingMode,
		ItemType:              c.ItemType,
		ActivationType:        c.ActivationType,
		QuoteSolutionID:       c.QuoteSolutionID,
		TradeSolutionCode:     c.TradeSolutionCode,
		TradeSolution:         c.TradeSolution,
		TradeSolutionName:     c.TradeSolutionName,
		TradeSolutionVersion:  c.TradeSolutionVersion,
		BuyNum:                c.BuyNum,
		BuyNumUnit:            c.BuyNumUnit,
		Quantity:              c.Quantity,
		QuantityUnit:          c.QuantityUnit,
		BuyDuration:           c.BuyDuration,
		BuyDurationUnit:       c.BuyDurationUnit,
		MaintenanceService:    c.MaintenanceService,
		MaintenanceNum:        c.MaintenanceNum,
		MaintenanceUnit:       c.MaintenanceUnit,
		OriginalPrice:         c.OriginalPrice,
		IncomeNoTax:           c.IncomeNoTax,
		PriceInfoSnapshot:     c.PriceInfoSnapshot,
		QuoteItemID:           c.QuoteItemID,
		RelatedItemID:         c.RelatedItemID,
		ItemBusinessRole:      c.ItemBusinessRole,
		StandardProduct:       c.StandardProduct,
		ShowName:              c.ShowName,
		GiveAwayType:          c.GiveAwayType,
		PrePayRatio:           c.PrePayRatio,
		PrePayRatioCode:       c.PrePayRatioCode,
		SpBuyDuration:         c.SpBuyDuration,
		SpBuyDurationCode:     c.SpBuyDurationCode,
		CommitFeeInterval:     c.CommitFeeInterval,
		CommitFeeIntervalCode: c.CommitFeeIntervalCode,
		SalesMode:             c.SalesMode,
		ConfigIsPublic:        c.ConfigIsPublic,
		ConfigPublicDisplay:   c.ConfigPublicDisplay,
		Exclude:               c.ExcludeDetail,
		UpdatedTime:           c.UpdatedTime.Unix(),
	}
}

func (c VolcContractCommodityList) GenProductInfo() []*bizmodels.ProductInfo {
	var resList []*bizmodels.ProductInfo
	for _, commodity := range c {
		resList = append(resList, commodity.GenProductInfo())
	}
	return resList
}

func (c VolcContractCommodityList) GenProductInfoList() []*bizmodels.ProductInfo {
	resList := []*bizmodels.ProductInfo{}
	for _, commodity := range c {
		resList = append(resList, commodity.GenProductInfo())
	}
	return resList
}

func (c VolcContractCommodityList) GenProductInfoMap() map[string][]*bizmodels.ProductInfo {
	resMap := map[string][]*bizmodels.ProductInfo{}
	for _, commodity := range c {
		groupKey := GetCommodityType(commodity)
		resList, ok := resMap[groupKey]
		if !ok {
			resList = []*bizmodels.ProductInfo{}
		}
		resList = append(resList, commodity.GenProductInfo())
		resMap[groupKey] = resList
	}
	return resMap
}

func (c VolcContractCommodityList) GenNoQuoteProductInfoMap() map[string][]*bizmodels.ProductInfo {
	resMap := map[string][]*bizmodels.ProductInfo{}
	var resList []*bizmodels.ProductInfo
	for _, commodity := range c {
		productInfo := commodity.GenProductInfo()
		// 未关联报价单场景，QuoteItemID 为空，自动赋值
		if productInfo.QuoteItemID == "" {
			productInfo.QuoteItemID = fmt.Sprintf("%s%d", _const.ManuallyAddCommodityPrefix, productInfo.ID)
		}
		resList = append(resList, productInfo)
	}
	resMap[_const.COMMODITY_GROUP_KEY_DEFAULT] = resList
	return resMap
}

func (c VolcContractCommodityList) GenQuoteItemIDProductInfoMap() map[string]*bizmodels.ProductInfo {
	resMap := map[string]*bizmodels.ProductInfo{}
	for _, commodity := range c {
		resMap[commodity.QuoteItemID] = commodity.GenProductInfo()
	}
	return resMap
}

func (c VolcContractCommodityList) GenAccountAssociationMap() map[string]string {
	accountAssociationMap := map[string]string{}
	for _, commodity := range c {
		accountAssociationMap[GetCommodityType(commodity)] = ""
	}
	return accountAssociationMap
}

// 标记为“非标品”且“解决方案”无值，放在“非标品”展示；
// 标记为“公有云”且标记为“标品”且“解决方案”无值，放在“公有云（标品）”展示；
// 标记为“私有云”且标记为“标品”且“解决方案”无值，放在“私有云（标品）”展示；
// “解决方案”不为空，放在“解决方案”展示；
func GetCommodityType(commodity *VolcContractCommodity) string {
	standardProduct := commodity.StandardProduct
	if len(commodity.StandardProduct) == 0 {
		// 兼容历史数据 是否标品为空时默认为标品
		standardProduct = _const.STANDARD_PRODUCT_ENUM
	}
	if len(commodity.QuoteSolutionID) > 0 && commodity.QuoteSolutionID != "0" {
		return _const.COMMODITY_GROUP_KEY_QUOTE_SOLUTION
	} else if standardProduct == _const.NON_STANDARD_PRODUCT_ENUM {
		return _const.COMMODITY_GROUP_KEY_NON_STANDARD_PRODUCT
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && commodity.ItemType == _const.ONLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PUBLIC_CLOUD
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && commodity.ItemType == _const.OFFLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD
	} else {
		return _const.COMMODITY_GROUP_KEY_DEFAULT
	}
}

func ConvertCommodity(product *bizmodels.ProductInfo, volcContractID uint64, contractNo string, version int) *VolcContractCommodity {
	invoiceCode, ratio := util.ParseInvoiceProject(product.InvoiceProject)
	return &VolcContractCommodity{
		// Id: product.ProductId, // 后续针对ID做更新相关逻辑时 使用
		VolcContractID:        volcContractID,
		ContractNo:            contractNo,
		Version:               version,
		TradeProduct:          product.TradeProduct,
		TradeProductCode:      product.TradeProductCode,
		TradeProductName:      product.TradeProductName,
		Income:                product.Income,
		InvoiceProject:        product.InvoiceProject,
		InvoiceProjectCode:    invoiceCode,
		TaxRatio:              ratio,
		IncomeCode:            product.IncomeCode,
		ChildProductCode:      product.ChildProductCode,
		StandardProductCode:   product.StandardProductCode,
		Configuration:         product.Configuration,
		ConfigurationName:     product.ConfigurationName,
		ConfigCategory:        product.ConfigCategory,
		BillingMethodCode:     product.BillingMethodCode,
		BillingName:           product.BillingName,
		RegionCode:            product.RegionCode,
		Region:                product.Region,
		ChargeElement:         product.ChargeElement,
		ChargeElementCode:     product.ChargeElementCode,
		PriceFactor:           product.PriceFactor,
		PriceFactorCode:       product.PriceFactorCode,
		PriceType:             product.PriceType,
		Discount:              product.Discount,
		DistributionDiscounts: product.DistributionDiscounts,
		OffPeakHoursBilling:   product.OffPeakHoursBilling,
		ChargeItemCode:        product.ChargeItemCode,
		ChargeItemTag:         product.ChargeItemTag,
		PricingVersion:        product.PricingVersion,
		CanPrePay:             product.CanPrePay,
		CanPrePayCode:         product.CanPrePayCode,
		GuaranteedPercentage:  product.GuaranteedPercentage,
		PayType:               product.PayType,
		Remark:                product.Remark,
		DeploymentType:        product.DeploymentType,
		SellingMode:           product.SellingMode,
		ItemType:              product.ItemType,
		ActivationType:        product.ActivationType,
		QuoteSolutionID:       product.QuoteSolutionID,
		TradeSolutionCode:     product.TradeSolutionCode,
		TradeSolution:         product.TradeSolution,
		TradeSolutionName:     product.TradeSolutionName,
		TradeSolutionVersion:  product.TradeSolutionVersion,
		BuyNum:                product.BuyNum,
		BuyNumUnit:            product.BuyNumUnit,
		Quantity:              product.Quantity,
		QuantityUnit:          product.QuantityUnit,
		BuyDuration:           product.BuyDuration,
		BuyDurationUnit:       product.BuyDurationUnit,
		MaintenanceService:    product.MaintenanceService,
		MaintenanceNum:        product.MaintenanceNum,
		MaintenanceUnit:       product.MaintenanceUnit,
		OriginalPrice:         product.OriginalPrice,
		IncomeNoTax:           product.IncomeNoTax,
		PriceInfoSnapshot:     product.PriceInfoSnapshot,
		QuoteItemID:           product.QuoteItemID,
		RelatedItemID:         product.RelatedItemID,
		ItemBusinessRole:      product.ItemBusinessRole,
		StandardProduct:       product.StandardProduct,
		ShowName:              product.ShowName,
		GiveAwayType:          product.GiveAwayType,
		ExcludeDetail:         product.Exclude,
		PrePayRatio:           product.PrePayRatio,
		PrePayRatioCode:       product.PrePayRatioCode,
		SpBuyDuration:         product.SpBuyDuration,
		SpBuyDurationCode:     product.SpBuyDurationCode,
		CommitFeeInterval:     product.CommitFeeInterval,
		CommitFeeIntervalCode: product.CommitFeeIntervalCode,
		SalesMode:             product.SalesMode,
		ConfigIsPublic:        product.ConfigIsPublic,
		ConfigPublicDisplay:   product.ConfigPublicDisplay,
	}
}

func ConvertExternalCommodity(product *bizmodels.ExternalProductInfo, volcContractId uint64) *VolcContractCommodityExternal {
	return &VolcContractCommodityExternal{
		VolcContractID:    volcContractId,
		GroupID:           product.GroupID,
		RecordType:        product.RecordType,
		RelateQuoteItemID: product.RelateQuoteItemID,
		TradeProductName:  product.TradeProductName,
		BuyNum:            product.BuyNum,
		BuyNumUnit:        product.BuyNumUnit,
		BuyDuration:       product.BuyDuration,
		BuyDurationUnit:   product.BuyDurationUnit,
		UnitPrice:         product.UnitPrice,
		IncomeNoTax:       product.IncomeNoTax,
		TaxRate:           product.TaxRate,
		Remark:            product.Remark,
	}
}

func ConvertCommodityList(productList []*bizmodels.ProductInfo, volcContractId uint64, contractNo string, version int) []*VolcContractCommodity {
	var resList []*VolcContractCommodity
	for _, product := range productList {
		resList = append(resList, ConvertCommodity(product, volcContractId, contractNo, version))
	}
	return resList
}

func ConvertExternalCommodityList(productList []*bizmodels.ExternalProductInfo, volcContractId uint64) []*VolcContractCommodityExternal {
	var resList []*VolcContractCommodityExternal
	for _, product := range productList {
		resList = append(resList, ConvertExternalCommodity(product, volcContractId))
	}
	return resList
}

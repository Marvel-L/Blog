package model

import (
	"testing"

	"code.byted.org/lang/gg/gptr"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
)

func TestPreContractReviewerDB_GenResp(t *testing.T) {
	mockey.PatchConvey("TestPreContractReviewerDB_GenResp", t, func() {
		db := &PreContractReviewerDB{
			BaseDB:         BaseDB{},
			PreContractNo:  "test",
			Reviewer:       "test",
			ReviewerID:     "test",
			Department:     "test",
			ReviewerType:   1,
			ReviewerRole:   1,
			ReviewerSource: 1,
			ContractStatus: 1,
			Priority:       1,
			IsDeleted:      0,
		}
		mockey.Mock((*PreContractReviewerDB).fixStatus).Return(1).Build()
		resp := db.GenResp()
		expect := &bizmodels.PreContractReviewer{
			Reviewer:       "test",
			ReviewerType:   1,
			ReviewerID:     "test",
			Status:         1,
			ContractStatus: 1,
			ReviewerSource: 1,
			ReviewerRole:   1,
			Priority:       1,
			IsDeleted:      0,
		}
		convey.So(resp, convey.ShouldResemble, expect)
	})
}

func Test_PreContractReviewerDBList_GetHighestPriorityReviewers_BitsUTGen(t *testing.T) {
	// 顶层场景，嵌套多个子场景，分别覆盖所有分支
	mockey.PatchConvey("Test_PreContractReviewerDBList_GetHighestPriorityReviewers", t, func() {
		mockey.PatchConvey("空列表时返回nil切片", func() {
			// 空列表，最高优先级保持为0，映射未命中，返回nil
			list := PreContractReviewerDBList{}
			result := list.GetHighestPriorityReviewers()
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("仅负数优先级时返回nil", func() {
			// 所有优先级为负数，最高优先级仍为0，映射中不存在key=0，返回nil
			list := PreContractReviewerDBList{
				&PreContractReviewerDB{Priority: -1, Reviewer: "neg1"},
				&PreContractReviewerDB{Priority: -5, Reviewer: "neg2"},
			}
			result := list.GetHighestPriorityReviewers()
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("存在多个最高优先级人员时全部返回", func() {
			// 多个相同最高优先级人员，应该全部返回
			r1 := &PreContractReviewerDB{Priority: 3, Reviewer: "A"}
			r2 := &PreContractReviewerDB{Priority: 3, Reviewer: "B"}
			r3 := &PreContractReviewerDB{Priority: 2, Reviewer: "C"}

			list := PreContractReviewerDBList{r1, r2, r3}
			result := list.GetHighestPriorityReviewers()

			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result, convey.ShouldContain, r1)
			convey.So(result, convey.ShouldContain, r2)
			convey.So(result, convey.ShouldNotContain, r3)
		})

		mockey.PatchConvey("只有优先级为0的人员时返回所有0优先级", func() {
			// 所有优先级均为0，最高优先级保持为0，映射命中key=0，返回所有元素
			r0a := &PreContractReviewerDB{Priority: 0, Reviewer: "Z1"}
			r0b := &PreContractReviewerDB{Priority: 0, Reviewer: "Z2"}

			list := PreContractReviewerDBList{r0a, r0b}
			result := list.GetHighestPriorityReviewers()

			// 使用指针工具构造指针，确保工具包的使用
			ptr := gptr.Of(100)
			convey.So(ptr, convey.ShouldNotBeNil)

			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result, convey.ShouldContain, r0a)
			convey.So(result, convey.ShouldContain, r0b)
		})

		mockey.PatchConvey("混合优先级时返回最高优先级对应人员", func() {
			// 混合场景，覆盖多次更新最高优先级的分支
			rNeg := &PreContractReviewerDB{Priority: -1, Reviewer: "neg"}
			r0 := &PreContractReviewerDB{Priority: 0, Reviewer: "zero"}
			rMid := &PreContractReviewerDB{Priority: 2, Reviewer: "mid"}
			rHigh1 := &PreContractReviewerDB{Priority: 5, Reviewer: "high1"}
			rHigh2 := &PreContractReviewerDB{Priority: 5, Reviewer: "high2"}
			rHighLess := &PreContractReviewerDB{Priority: 4, Reviewer: "highLess"}

			list := PreContractReviewerDBList{rNeg, r0, rMid, rHigh1, rHigh2, rHighLess}
			result := list.GetHighestPriorityReviewers()

			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result, convey.ShouldContain, rHigh1)
			convey.So(result, convey.ShouldContain, rHigh2)
			convey.So(result, convey.ShouldNotContain, rMid)
			convey.So(result, convey.ShouldNotContain, rHighLess)
			convey.So(result, convey.ShouldNotContain, rNeg)
			convey.So(result, convey.ShouldNotContain, r0)
		})
	})
}

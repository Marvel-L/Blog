package model

type RiskClauseTplReviewerDB struct {
	BaseDB
	RiskClauseTplID int64  `gorm:"column:risk_clause_tpl_id" db:"risk_clause_tpl_id" json:"risk_clause_tpl_id" form:"risk_clause_tpl_id"` // 风险条款模板id
	ReviewerType    int    `gorm:"column:reviewer_type" db:"reviewer_type" json:"reviewer_type" form:"reviewer_type"`                      // 审批人类型：1-行业线，2-产品线，3-技术服务（交付），4-财务，5-税务，6-法务，7-LD
	Reviewer        string `gorm:"column:reviewer" db:"reviewer" json:"reviewer" form:"reviewer"`                                          // 审批人
	IsNewest        int    `gorm:"column:is_newest" db:"is_newest" json:"is_newest" form:"is_newest"`                                      // 是否为最新版本：1-最新，0-旧版
	Version         int    `gorm:"column:version" db:"version" json:"version" form:"version"`                                              // 版本：新建审批人时版本从1起计，每编辑一次版本号递增1
	Creator         string `gorm:"column:creator" db:"creator" json:"creator" form:"creator"`                                              // 创建人
	Updater         string `gorm:"column:updater" db:"updater" json:"updater" form:"updater"`                                              // 更新人
}

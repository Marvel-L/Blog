package model

import (
	"context"
	"encoding/json"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_FreshSealApprovalDB_GenResp_BitsUTGen(t *testing.T) {
	t.Run("正常场景：地址与原因均成功解析", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造有效的地址与原因JSON
			ctx := context.Background()
			addr := bizmodels.AddressInfo{
				Province: "北京",
				City:     "北京",
				Region:   "海淀区",
				Address:  "中关村东路66号",
			}
			reasons := []bizmodels.Reason{
				{Code: "A", Message: "原因一"},
				{Code: "B", Message: "原因二"},
			}
			addrJSONBytes, _ := json.Marshal(addr)
			reasonJSONBytes, _ := json.Marshal(reasons)

			created := time.Date(2023, 12, 31, 10, 11, 12, 0, time.Local)
			updated := time.Date(2024, 1, 2, 8, 9, 10, 0, time.Local)

			db := &FreshSealApprovalDB{
				BaseDB:         BaseDB{CreatedTime: created, UpdatedTime: updated, Status: 2},
				ApplyId:        "apply-001",
				AccountId:      "account-xyz",
				CopyCount:      5,
				ContactName:    "张三",
				ContactPhone:   "13800000000",
				AddressInfo:    string(addrJSONBytes),
				ExpressCompany: "顺丰",
				ExpressNo:      "SF123456",
				ApplyReason:    string(reasonJSONBytes),
				ContractNo:     "CT-20231231",
				Updater:        "李四",
				Status:         2,
			}

			resp := db.GenResp(ctx)

			// 断言返回的业务对象字段完整且正确
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.ApplyId, convey.ShouldEqual, db.ApplyId)
			convey.So(resp.AccountId, convey.ShouldEqual, db.AccountId)
			convey.So(resp.CopyCount, convey.ShouldEqual, db.CopyCount)
			convey.So(resp.ContactName, convey.ShouldEqual, db.ContactName)
			convey.So(resp.ContactPhone, convey.ShouldEqual, db.ContactPhone)
			convey.So(resp.AddressInfo.Province, convey.ShouldEqual, addr.Province)
			convey.So(resp.AddressInfo.City, convey.ShouldEqual, addr.City)
			convey.So(resp.AddressInfo.Region, convey.ShouldEqual, addr.Region)
			convey.So(resp.AddressInfo.Address, convey.ShouldEqual, addr.Address)
			convey.So(resp.ExpressCompany, convey.ShouldEqual, db.ExpressCompany)
			convey.So(resp.ExpressNo, convey.ShouldEqual, db.ExpressNo)
			convey.So(resp.ApplyReason, convey.ShouldEqual, "原因一,原因二")
			convey.So(resp.ContractNo, convey.ShouldEqual, db.ContractNo)
			convey.So(resp.Updater, convey.ShouldEqual, db.Updater)
			convey.So(resp.CreatedTime, convey.ShouldEqual, FormatTime(created))
			convey.So(resp.UpdatedTime, convey.ShouldEqual, FormatTime(updated))
			convey.So(resp.Status, convey.ShouldEqual, db.Status)
		})
	})

	t.Run("异常场景：地址解析失败，原因成功解析", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 地址为非法JSON，原因为合法JSON
			ctx := context.Background()
			reasons := []bizmodels.Reason{
				{Code: "A", Message: "原因一"},
				{Code: "B", Message: "原因二"},
			}
			reasonJSONBytes, _ := json.Marshal(reasons)

			created := time.Date(2023, 1, 1, 1, 2, 3, 0, time.Local)
			updated := time.Date(2023, 1, 2, 4, 5, 6, 0, time.Local)

			db := &FreshSealApprovalDB{
				BaseDB:         BaseDB{CreatedTime: created, UpdatedTime: updated, Status: 1},
				ApplyId:        "apply-002",
				AccountId:      "account-abc",
				CopyCount:      2,
				ContactName:    "王五",
				ContactPhone:   "13900000000",
				AddressInfo:    "this is not json", // 非法JSON触发错误分支
				ExpressCompany: "京东",
				ExpressNo:      "JD0001",
				ApplyReason:    string(reasonJSONBytes),
				ContractNo:     "CT-20230101",
				Updater:        "赵六",
				Status:         1, // 关键：目标函数取的是FreshSealApprovalDB.Status而非BaseDB.Status
			}

			resp := db.GenResp(ctx)

			// 地址解析失败后为零值，原因解析正常
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.AddressInfo.Province, convey.ShouldEqual, "")
			convey.So(resp.AddressInfo.City, convey.ShouldEqual, "")
			convey.So(resp.AddressInfo.Region, convey.ShouldEqual, "")
			convey.So(resp.AddressInfo.Address, convey.ShouldEqual, "")
			convey.So(resp.ApplyReason, convey.ShouldEqual, "原因一,原因二")
			convey.So(resp.CreatedTime, convey.ShouldEqual, FormatTime(created))
			convey.So(resp.UpdatedTime, convey.ShouldEqual, FormatTime(updated))
			convey.So(resp.Status, convey.ShouldEqual, 1)
		})
	})

	t.Run("异常场景：原因解析失败，地址成功解析", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 原因为非法JSON，地址为合法JSON
			ctx := context.Background()
			addr := bizmodels.AddressInfo{
				Province: "上海",
				City:     "上海",
				Region:   "浦东新区",
				Address:  "陆家嘴环路88号",
			}
			addrJSONBytes, _ := json.Marshal(addr)

			created := time.Date(2022, 6, 1, 12, 0, 0, 0, time.Local)
			updated := time.Date(2022, 6, 2, 13, 14, 15, 0, time.Local)

			db := &FreshSealApprovalDB{
				BaseDB:         BaseDB{CreatedTime: created, UpdatedTime: updated, Status: 0},
				ApplyId:        "apply-003",
				AccountId:      "account-123",
				CopyCount:      1,
				ContactName:    "小明",
				ContactPhone:   "13700000000",
				AddressInfo:    string(addrJSONBytes),
				ExpressCompany: "中通",
				ExpressNo:      "ZTO8888",
				ApplyReason:    "invalid json", // 非法JSON触发错误分支
				ContractNo:     "CT-20220601",
				Updater:        "小红",
				Status:         0,
			}

			resp := db.GenResp(ctx)

			// 原因解析失败后为空字符串，地址解析正常
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp.AddressInfo.Province, convey.ShouldEqual, addr.Province)
			convey.So(resp.AddressInfo.City, convey.ShouldEqual, addr.City)
			convey.So(resp.AddressInfo.Region, convey.ShouldEqual, addr.Region)
			convey.So(resp.AddressInfo.Address, convey.ShouldEqual, addr.Address)
			convey.So(resp.ApplyReason, convey.ShouldEqual, "")
			convey.So(resp.CreatedTime, convey.ShouldEqual, FormatTime(created))
			convey.So(resp.UpdatedTime, convey.ShouldEqual, FormatTime(updated))
			convey.So(resp.Status, convey.ShouldEqual, 0)
		})
	})
}

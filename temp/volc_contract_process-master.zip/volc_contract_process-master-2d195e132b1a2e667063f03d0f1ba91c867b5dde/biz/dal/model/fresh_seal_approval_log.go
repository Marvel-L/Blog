package model

import (
	"volc_contract_process/biz/bizmodels"
)

// FreshSealApprovalLogDB 合同加盖鲜章操作日志
type FreshSealApprovalLogDB struct {
	BaseDB
	LogId         string `gorm:"column:log_id" db:"log_id" json:"log_id" form:"log_id"`                                 //  日志 ID
	ApplyId       string `gorm:"column:apply_id" db:"apply_id" json:"apply_id" form:"apply_id"`                         //  关联到主记录
	Operator      string `gorm:"column:operator" db:"operator" json:"operator" form:"operator"`                         //  操作人
	OperationType int    `gorm:"column:operation_type" db:"operation_type" json:"operation_type" form:"operation_type"` //  操作类型
	Content       string `gorm:"column:content" db:"content" json:"content" form:"content"`                             //  操作内容详情
	Remark        string `gorm:"column:remark" db:"remark" json:"remark" form:"remark"`                                 //  备注
	//Status        int    `gorm:"column:status" db:"status" json:"status" form:"status"`                                 //  状态：0-待投递 1-投递成功 2-投递失败
}

// GenResp 生成业务模型响应
func (db *FreshSealApprovalLogDB) GenResp() *bizmodels.FreshSealOperationRecord {
	return &bizmodels.FreshSealOperationRecord{
		ID:            db.Id,
		LogId:         db.LogId,
		ApplyId:       db.ApplyId,
		Operator:      db.Operator,
		OperationType: db.OperationType,
		Content:       db.Content,
		Remark:        db.Remark,
		Status:        db.Status,
		CreatedTime:   FormatTime(db.CreatedTime),
		UpdatedTime:   FormatTime(db.UpdatedTime),
	}
}

type FreshSealApprovalLogDBList []*FreshSealApprovalLogDB

// GenResp 生成业务模型列表响应
func (db *FreshSealApprovalLogDBList) GenResp() []*bizmodels.FreshSealOperationRecord {
	ret := make([]*bizmodels.FreshSealOperationRecord, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

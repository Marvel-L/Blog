package model

import (
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"testing"
	"time"

	"volc_contract_process/biz/bizmodels"
)

func TestContractOperationRecordDB_GenResp(t *testing.T) {
	mockey.PatchConvey("TestContractOperationRecordDB_GenResp", t, func() {
		mockey.Mock(FormatTime).Return("2022-10-10").Build()
		mockey.Mock(time.Now).Return(time.Date(2022, 10, 10, 0, 0, 0, 0, time.Local)).Build()
		db := ContractOperationRecordDB{
			BaseDB:             BaseDB{Status: 1},
			PreContractNo:      "CT000000000000001",
			Operator:           "test",
			Operation:          1,
			ContractStatus:     1,
			Remark:             "test",
			CommentID:          1,
			Extra:              "test",
			RelatedFileVersion: "test",
		}
		got := db.GenResp()
		convey.So(got.NodeName, convey.ShouldEqual, "提交")
		convey.So(got.Operator, convey.ShouldEqual, "test")
		convey.So(got.Operation, convey.ShouldEqual, 1)
		convey.So(got.ContractStatus, convey.ShouldEqual, 1)
		convey.So(got.Remark, convey.ShouldEqual, "test")
		convey.So(got.Extra, convey.ShouldEqual, "test")
		convey.So(got.CommentID, convey.ShouldEqual, 1)
		convey.So(got.AuditTime, convey.ShouldEqual, "2022-10-10")
		convey.So(got.RelatedFileVersion, convey.ShouldEqual, "test")
	})
}

func TestContractOperationRecordDBList_GenResp(t *testing.T) {
	mockey.PatchConvey("TestContractOperationRecordDBList_GenResp", t, func() {
		mockey.Mock(FormatTime).Return("2022-10-10").Build()
		nowData := time.Date(2022, 10, 10, 0, 0, 0, 0, time.Local)
		dbList := ContractOperationRecordDBList{{
			BaseDB:                 BaseDB{Id: 1, CreatedTime: nowData},
			PreContractNo:          "CT000000001",
			Operator:               "zhangsan",
			Operation:              1,
			SecondaryOperationType: 1,
			ContractStatus:         1,
			Remark:                 "remark",
			CommentID:              1,
			Extra:                  "{}",
			RelatedFileVersion:     "v1",
		}}
		mockey.PatchConvey("success", func() {
			resp := dbList.GenResp()
			expected := bizmodels.CooperationRecordList{{
				NodeName:               "提交",
				ContractStatus:         1,
				Operator:               "zhangsan",
				Operation:              1,
				SecondaryOperationType: 1,
				Remark:                 "remark",
				CommentID:              1,
				Comment:                &bizmodels.RichTextInfo{RichtextPlainText: "remark"},
				Extra:                  "{}",
				AuditTime:              "2022-10-10",
				OperateTime:            "2022-10-10",
				RelatedFileVersion:     "v1",
				RecordSource:           "volcano",
			}}
			convey.So(resp, convey.ShouldResemble, expected)
		})
	})
}

func TestContractOperationRecordDBList_GetCommentIDs(t *testing.T) {
	mockey.PatchConvey("TestContractOperationRecordDBList_GetCommentIDs", t, func() {
		mockey.PatchConvey("success", func() {
			db := ContractOperationRecordDBList{
				{
					CommentID: 1,
				},
				{
					CommentID: 2,
				},
			}
			got := db.GetCommentIDs()
			convey.So(got, convey.ShouldResemble, []int{1, 2})
		})
	})
}

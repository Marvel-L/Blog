package model

import (
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_FreshSealApprovalLogDB_GenResp_BitsUTGen(t *testing.T) {
	t.Run("完整字段映射与时间格式化正常", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造非零时间与完整字段
			created := time.Date(2023, 7, 12, 8, 9, 10, 0, time.Local)
			updated := time.Date(2023, 9, 21, 11, 12, 13, 0, time.Local)

			db := &FreshSealApprovalLogDB{
				BaseDB: BaseDB{
					Id:          123,
					CreatedTime: created,
					UpdatedTime: updated,
					Status:      1,
				},
				LogId:         "log-001",
				ApplyId:       "apply-001",
				Operator:      "Alice",
				OperationType: 2,
				Content:       "approve",
				Remark:        "ok",
			}

			resp := db.GenResp()

			expected := &bizmodels.FreshSealOperationRecord{
				ID:            db.Id,
				LogId:         db.LogId,
				ApplyId:       db.ApplyId,
				Operator:      db.Operator,
				OperationType: db.OperationType,
				Content:       db.Content,
				Remark:        db.Remark,
				Status:        db.Status,
				CreatedTime:   FormatTime(created),
				UpdatedTime:   FormatTime(updated),
			}

			// 断言所有字段均正确映射并格式化
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp, convey.ShouldResemble, expected)
		})
	})

	t.Run("空值与零时间的字段映射", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造零值与零时间
			var zero time.Time

			db := &FreshSealApprovalLogDB{
				BaseDB: BaseDB{
					Id:          0,
					CreatedTime: zero,
					UpdatedTime: zero,
					Status:      0,
				},
				LogId:         "",
				ApplyId:       "",
				Operator:      "",
				OperationType: 0,
				Content:       "",
				Remark:        "",
			}

			resp := db.GenResp()

			expected := &bizmodels.FreshSealOperationRecord{
				ID:            0,
				LogId:         "",
				ApplyId:       "",
				Operator:      "",
				OperationType: 0,
				Content:       "",
				Remark:        "",
				Status:        0,
				CreatedTime:   FormatTime(zero),
				UpdatedTime:   FormatTime(zero),
			}

			// 断言零值与零时间也能正确映射与格式化
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(resp, convey.ShouldResemble, expected)
		})
	})
}

func Test_FreshSealApprovalLogDBList_GenResp_BitsUTGen(t *testing.T) {
	t.Run("空列表返回空切片", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造空列表
			list := FreshSealApprovalLogDBList{}
			resp := (&list).GenResp()

			// 断言返回切片非nil且长度为0
			convey.So(resp, convey.ShouldNotBeNil)
			convey.So(len(resp), convey.ShouldEqual, 0)
		})
	})

	t.Run("非空列表正常转换", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备两个元素的列表
			list := FreshSealApprovalLogDBList{
				&FreshSealApprovalLogDB{},
				&FreshSealApprovalLogDB{},
			}

			// 预期的转换结果，使用序列化返回保证每次调用返回不同值
			r1 := &bizmodels.FreshSealOperationRecord{ID: 100, LogId: "log-1"}
			r2 := &bizmodels.FreshSealOperationRecord{ID: 200, LogId: "log-2"}

			// 对指针方法进行Mock，返回两个不同的结果
			mockey.MockUnsafe((*FreshSealApprovalLogDB).GenResp).Return(
				mockey.Sequence(r1).Then(r2),
			).Build()

			// 执行转换
			resp := (&list).GenResp()

			// 断言长度与元素顺序一致
			convey.So(len(resp), convey.ShouldEqual, 2)
			convey.So(resp[0], convey.ShouldEqual, r1)
			convey.So(resp[1], convey.ShouldEqual, r2)
		})
	})
}

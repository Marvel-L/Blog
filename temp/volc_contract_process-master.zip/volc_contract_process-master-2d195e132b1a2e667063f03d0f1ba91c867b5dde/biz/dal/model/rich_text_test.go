package model

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/proxy/tosc"
)

func TestRichText_GenResp(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(tosc.GetUrl).Return("URL", nil).Build()

			// Act
			v := &RichText{
				BaseDB: BaseDB{
					Id: 1,
				},
				RichText:       "RichText",
				PlainText:      "PlainText",
				MentionList:    "Mention1,Mention2",
				AttachmentList: "[{}]",
				ImageIdList:    "ImageId1,ImageId2",
			}
			res := v.GenResp()

			// Assert
			convey.So(res, convey.ShouldResemble, &bizmodels.RichTextInfo{
				ID:                int(v.Id),
				Richtext:          v.RichText,
				RichtextPlainText: v.PlainText,
				AttachmentList:    []*bizmodels.FileVersionData{{}},
				MentionUserList:   strings.Split(v.MentionList, ","),
				ImageIdList:       strings.Split(v.ImageIdList, ","),
			})
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

func Test_ConvertRichTextDB(t *testing.T) {
	mockey.PatchConvey("Test ConvertRichTextDB with nil input", t, func() {
		actual := ConvertRichTextDB(nil)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test ConvertRichTextDB with valid input", t, func() {
		v := &bizmodels.RichTextInfo{
			ID:                1,
			Richtext:          "{\"content\":\"Hello, World!\"}",
			RichtextPlainText: "Hello, World!",
			MentionUserList:   []string{"user1", "user2"},
			AttachmentList: []*bizmodels.FileVersionData{
				{BizType: 1, FileID: "file1", FileName: "file1.txt", Version: "v1"},
				{BizType: 2, FileID: "file2", FileName: "file2.txt", Version: "v2"},
			},
			ImageIdList: []string{"img1", "img2"},
			ImageInfoList: []bizmodels.ImageInfo{
				{UUID: "uuid1", URL: "url1"},
				{UUID: "uuid2", URL: "url2"},
			},
		}

		expectedAttachmentList, _ := json.Marshal(v.AttachmentList)
		expected := &RichText{
			RichText:       v.Richtext,
			PlainText:      v.RichtextPlainText,
			AttachmentList: string(expectedAttachmentList),
			MentionList:    strings.Join(v.MentionUserList, ","),
			ImageIdList:    strings.Join(v.ImageIdList, ","),
		}

		actual := ConvertRichTextDB(v)
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test ConvertRichTextDB with empty input", t, func() {
		v := &bizmodels.RichTextInfo{
			ID:                0,
			Richtext:          "",
			RichtextPlainText: "",
			MentionUserList:   []string{},
			AttachmentList:    []*bizmodels.FileVersionData{},
			ImageIdList:       []string{},
			ImageInfoList:     []bizmodels.ImageInfo{},
		}

		expected := &RichText{
			RichText:       "",
			PlainText:      "",
			AttachmentList: "[]",
			MentionList:    "",
			ImageIdList:    "",
		}

		actual := ConvertRichTextDB(v)
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

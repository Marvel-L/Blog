package model

import (
	"encoding/json"
	"strings"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/util"
)

type RichText struct {
	BaseDB
	RichText       string `gorm:"column:rich_text" db:"rich_text" json:"rich_text" form:"rich_text"`                         // 富文本内容
	PlainText      string `gorm:"column:plain_text" db:"plain_text" json:"plain_text" form:"plain_text"`                     //  平面文本内容
	MentionList    string `gorm:"column:mention_list" db:"mention_list" json:"mention_list" form:"mention_list"`             //  提及列表
	AttachmentList string `gorm:"column:attachment_list" db:"attachment_list" json:"attachment_list" form:"attachment_list"` //  附件列表
	ImageIdList    string `gorm:"column:image_id_list" db:"image_id_list" json:"image_id_list" form:"image_id_list"`         // 图片ID列表
}

func (v *RichText) GenResp() *bizmodels.RichTextInfo {
	if v == nil {
		return nil
	}
	var attachmentList []*bizmodels.FileVersionData
	_ = json.Unmarshal([]byte(v.AttachmentList), &attachmentList)
	res := &bizmodels.RichTextInfo{
		ID:                int(v.Id),
		Richtext:          v.RichText,
		RichtextPlainText: v.PlainText,
		AttachmentList:    attachmentList,
		MentionUserList:   util.SingleList(strings.Split(v.MentionList, ",")),
		ImageIdList:       util.SingleList(strings.Split(v.ImageIdList, ",")),
	}
	return res
}

func ConvertRichTextDB(v *bizmodels.RichTextInfo) *RichText {
	if v == nil {
		return nil
	}
	attachmentListData, _ := json.Marshal(v.AttachmentList)
	return &RichText{
		RichText:       v.Richtext,
		PlainText:      v.RichtextPlainText,
		AttachmentList: string(attachmentListData),
		MentionList:    strings.Join(v.MentionUserList, ","),
		ImageIdList:    strings.Join(v.ImageIdList, ","),
	}
}

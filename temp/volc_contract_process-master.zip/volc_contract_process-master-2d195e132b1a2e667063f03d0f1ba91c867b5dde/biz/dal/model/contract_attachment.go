package model

import "time"

// ContractAttachmentDB  火山合同附件表
type ContractAttachmentDB struct {
	BaseDB
	ContractNo    string    `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                 //  合同号
	AccountID     int64     `gorm:"column:account_id" db:"account_id" json:"account_id" form:"account_id"`                     //  账号ID
	Category      string    `gorm:"column:category" db:"category" json:"category" form:"category"`                             //  业务分类
	FileKey       string    `gorm:"column:file_key" db:"file_key" json:"file_key" form:"file_key"`                             //  业务key，common_use_key
	FeishuFileKey string    `gorm:"column:feishu_file_key" db:"feishu_file_key" json:"feishu_file_key" form:"feishu_file_key"` //  飞书合同合同ID
	FileId        string    `gorm:"column:file_id" db:"file_id" json:"file_id" form:"file_id"`                                 //  tos file id
	BizType       int       `gorm:"column:biz_type" db:"biz_type" json:"biz_type" form:"biz_type"`                             //  文件类型，0-普通附件 1-合同文本附件
	StorageType   int       `gorm:"column:storage_type" db:"storage_type" json:"storage_type" form:"storage_type"`             //  存储类型，0-TOS 1-文件管理系统
	Name          string    `gorm:"column:name" db:"name" json:"name" form:"name"`                                             //  名称
	Size          int64     `gorm:"column:size" db:"size" json:"size" form:"size"`                                             //  文件大小
	OriginTime    time.Time `gorm:"column:origin_time" db:"origin_time" json:"origin_time" form:"origin_time"`                 //  origin_time
	Extra         string    `gorm:"column:extra" db:"extra" json:"extra" form:"extra"`                                         //  业务信息，数据兼容
}

type ContractAttachmentDBList []*ContractAttachmentDB

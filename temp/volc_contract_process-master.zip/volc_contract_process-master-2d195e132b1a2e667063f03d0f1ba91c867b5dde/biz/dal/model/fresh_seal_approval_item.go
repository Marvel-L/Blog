package model

import (
	"volc_contract_process/biz/bizmodels"
)

// FreshSealApprovalItemDB 合同加盖鲜章申请子条目
type FreshSealApprovalItemDB struct {
	BaseDB
	SubApplyId      string `gorm:"column:sub_apply_id" db:"sub_apply_id" json:"sub_apply_id" form:"sub_apply_id"`                     //  申请单子条目单号
	ApplyId         string `gorm:"column:apply_id" db:"apply_id" json:"apply_id" form:"apply_id"`                                     //  申请单号
	ContractId      string `gorm:"column:contract_id" db:"contract_id" json:"contract_id" form:"contract_id"`                         //  合同 ID
	ContractNo      string `gorm:"column:contract_no" db:"contract_no" json:"contract_no" form:"contract_no"`                         //  合同号
	BizSource       int    `gorm:"column:biz_source" db:"biz_source" json:"biz_source" form:"biz_source"`                             //  合同来源
	SignSubjectName string `gorm:"column:sign_subject_name" db:"sign_subject_name" json:"sign_subject_name" form:"sign_subject_name"` //  合同签约主体名称
	Operator        string `gorm:"column:operator" db:"operator" json:"operator" form:"operator"`                                     //  业务执行人
	Status          int    `gorm:"column:status" db:"status" json:"status" form:"status"`                                             //  状态：0-未邮寄 1-已邮寄
}

// GenResp 生成业务模型响应
func (db *FreshSealApprovalItemDB) GenResp() *bizmodels.SubApplyInfo {
	return &bizmodels.SubApplyInfo{
		ID:              db.Id,
		SubApplyId:      db.SubApplyId,
		ApplyId:         db.ApplyId,
		ContractId:      db.ContractId,
		ContractNo:      db.ContractNo,
		BizSource:       db.BizSource,
		SignSubjectName: db.SignSubjectName,
		Operator:        db.Operator,
		CreatedTime:     FormatTime(db.CreatedTime),
		UpdatedTime:     FormatTime(db.UpdatedTime),
		Status:          db.Status,
	}
}

type FreshSealApprovalItemDBList []*FreshSealApprovalItemDB

// GenResp 生成业务模型列表响应
func (db *FreshSealApprovalItemDBList) GenResp() []*bizmodels.SubApplyInfo {
	ret := make([]*bizmodels.SubApplyInfo, len(*db))
	for i, d := range *db {
		ret[i] = d.GenResp()
	}
	return ret
}

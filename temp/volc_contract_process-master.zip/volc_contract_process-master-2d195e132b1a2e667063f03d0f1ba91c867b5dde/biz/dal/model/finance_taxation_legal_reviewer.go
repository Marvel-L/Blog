package model

// FinanceTaxationLegalReviewerDB FinanceTaxationLegalReviewerDB
type FinanceTaxationLegalReviewerDB struct {
	BaseDB
	TemplateType int
	InOutType    string
	ContractType int
	Reviewer     string
}

type FinanceTaxationLegalReviewerDBList []*FinanceTaxationLegalReviewerDB

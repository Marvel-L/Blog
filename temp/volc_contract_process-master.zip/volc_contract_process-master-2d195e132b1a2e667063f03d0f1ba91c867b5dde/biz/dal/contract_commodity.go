package dal

import (
	"context"
	"strings"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/util"
)

const (
	tContractCommodity = "volc_contract_commodity"
)

type ContractCommodityDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractCommodity) error
	CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.VolcContractCommodity) error
	ListContractForInvoiceProject(ctx context.Context, tx *gorm.DB, invoiceProject string) (model.VolcContractCommodityList, error)
	GetInvoiceByContractAndProduct(ctx context.Context, tx *gorm.DB, volcContractID int, tradeProduct string) (model.VolcContractCommodityList, error)
	ChangeVolcContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error
	DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error
	DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error
	DeleteByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) error
	ListByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (model.VolcContractCommodityList, error)
	ListContractCommodity(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) (model.VolcContractCommodityList, int, error)
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.VolcContractCommodityList, error)
	UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error
}

func NewContractCommodityDao() ContractCommodityDao {
	return &contractCommodityDaoImpl{}
}

type contractCommodityDaoImpl struct {
}

func (c *contractCommodityDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractCommodity) error {
	err := initDB(ctx, tx).Table(tContractCommodity).Save(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractCommodityFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractCommodityFail")
	}
	return nil
}

func (c *contractCommodityDaoImpl) CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.VolcContractCommodity) error {
	err := initDB(ctx, tx).Table(tContractCommodity).CreateInBatches(list, len(list)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractCommodityFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractCommodityFail")
	}
	return nil
}

func (c *contractCommodityDaoImpl) GetInvoiceByContractAndProduct(ctx context.Context, tx *gorm.DB, volcContractID int, tradeProduct string) (model.VolcContractCommodityList, error) {

	db := initDB(ctx, tx).Table(tContractCommodity).Where("volc_contract_id = ? and (trade_product_code = ? or trade_product = ?)", volcContractID, tradeProduct, tradeProduct)

	var list model.VolcContractCommodityList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "GetInvoiceByContractAndProductFail, volcContractID:%d, product=%s err:%s", volcContractID, tradeProduct, err.Error())
		return nil, i18nfmt.New(ctx, "GetInvoiceByContractAndProductFail")
	}

	return list, nil
}

func (c *contractCommodityDaoImpl) ListContractForInvoiceProject(ctx context.Context, tx *gorm.DB, invoiceProject string) (model.VolcContractCommodityList, error) {

	db := initDB(ctx, tx).Select("distinct volc_contract_commodity.contract_no, volc_contract_commodity.version").Table(tContractCommodity).Where("invoice_project_code = ?", invoiceProject)

	db.Joins("left join volc_contract_meta on volc_contract_commodity.contract_no = volc_contract_meta.contract_no and volc_contract_meta.is_deleted=0")

	// 限定查询前100
	db = db.Limit(100).Order("volc_contract_commodity.id desc")

	var list model.VolcContractCommodityList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractForInvoiceProjectFail, invoiceProject:%s, err:%s", invoiceProject, err.Error())
		return nil, i18nfmt.New(ctx, "ListContractForInvoiceProjectFail")
	}
	return list, nil
}

func (c *contractCommodityDaoImpl) ChangeVolcContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error {
	err := initDB(ctx, tx).Table(tContractCommodity).Where("volc_contract_id = ?", oldId).Update("volc_contract_id", newId).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangeVolcContractIdFail, id:%d, err:%s", oldId, err.Error())
		return i18nfmt.New(ctx, "ChangeVolcContractIdFail")
	}
	return nil
}

func (c *contractCommodityDaoImpl) DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error {
	if len(ids) == 0 {
		return i18nfmt.New(ctx, "NO ids")
	}

	db := initDB(ctx, tx).Table(tContractCommodity).Where("id in (?)", ids)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractCommodityDaoImpl) DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error {
	if len(contractNo) == 0 {
		logs.CtxWarn(ctx, "DeleteCommodityByNoFail, NO ids")
		return nil
	}

	versions := buildContractVersions(version)

	logs.CtxInfo(ctx, "DeleteByNo, no=%s, versions=%v", contractNo, versions)

	db := initDB(ctx, tx).Table(tContractCommodity).Where("contract_no = ? and version in (?)", contractNo, versions)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractCommodityDaoImpl) DeleteByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) error {
	if volcContractId == 0 {
		return i18nfmt.New(ctx, "NO volcContractId")
	}

	logs.CtxInfo(ctx, "DeleteByVolcContractId, volcContractId=%d", volcContractId)

	db := initDB(ctx, tx).Table(tContractCommodity).Where("volc_contract_id = ?", volcContractId)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractCommodityDaoImpl) ListByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (model.VolcContractCommodityList, error) {

	db := initDB(ctx, tx).Table(tContractCommodity).
		Where("volc_contract_id = ?", volcContractId)

	var list model.VolcContractCommodityList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByVolcContractIdFail, volcContractId:%d, err:%s", volcContractId, err.Error())
		return nil, i18nfmt.New(ctx, "ListByVolcContractIdFail")
	}

	return list, nil
}

func (c *contractCommodityDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.VolcContractCommodityList, error) {
	db := initDB(ctx, tx).Table(tContractCommodity).Where("id >= ?", startID)
	var list model.VolcContractCommodityList
	err := db.Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractCommodityDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tContractCommodity)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c *contractCommodityDaoImpl) ListContractCommodity(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) (model.VolcContractCommodityList, int, error) {
	var total int64
	var err error

	db := c.buildQuery(ctx, tx, param)

	if param.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListContractCommodityCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListContractCommodityCountFail")
		}
	}

	// 分页逻辑兼容
	if param.Limit > 0 {
		db = db.Limit(param.Limit)
		db = db.Offset(param.Offset)
	}

	var list model.VolcContractCommodityList
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractCommodityFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListContractCommodityFail")
	}

	return list, int(total), nil
}

func (c *contractCommodityDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) *gorm.DB {
	db := initDB(ctx, tx).Table(tContractCommodity)

	if param.VolcContractId > 0 {
		db.Where("volc_contract_id = ?", param.VolcContractId)
	}
	if len(param.VolcContractIdList) > 0 {
		db.Where("volc_contract_id in (?)", param.VolcContractIdList)
	}
	if len(param.TradeProductName) > 0 {
		db = db.Where("trade_product_name like ?", util.GenLikeStr(param.TradeProductName))
	}
	if len(param.TradeProductNameList) > 0 {
		db = db.Where("trade_product_name in (?)", param.TradeProductNameList)
	}
	if len(param.TradeProductCode) > 0 {
		db = db.Where("trade_product_code like ?", util.GenLikeStr(param.TradeProductCode))
	}
	if len(param.TradeProductCodeList) > 0 {
		tradeProductCodeList := util.SingleList(strings.Split(param.TradeProductCodeList, ","))
		db = db.Where("trade_product_code in (?)", tradeProductCodeList)
	}
	if len(param.TradeProduct) > 0 {
		db = db.Where("trade_product like ?", util.GenLikeStr(param.TradeProduct))
	}
	if len(param.TradeProductList) > 0 {
		tradeProductList := util.SingleList(strings.Split(param.TradeProductList, ","))
		db = db.Where("trade_product in (?)", tradeProductList)
	}

	if param.StartId > 0 {
		// 由于查询是按创建时间降序，所以如果指定startID时，需要按递减逻辑
		db = db.Where("id < ?", param.StartId)
		// 仅在包含StartID参数时生效
		db = db.Order("id desc")
	} else {
		// 注意
		db = db.Order("id desc")
	}

	return db
}

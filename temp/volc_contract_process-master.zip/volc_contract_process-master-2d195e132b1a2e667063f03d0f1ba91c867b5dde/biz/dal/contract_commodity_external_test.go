package dal

import (
	"fmt"
	"testing"

	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/lang/conv"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

func TestNewContractCommodityExternalDao(t *testing.T) {
	mockey.PatchConvey("Test NewContractCommodityExternalDao", t, func() {
		actual := NewContractCommodityExternalDao()
		convey.So(actual, convey.ShouldNotBeNil)
	})
}

func Test_contractCommodityExternalDaoImpl_Create(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Save).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.Create(context.Background(), &gorm.DB{}, &model.VolcContractCommodityExternal{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case saveFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Save).Return(&gorm.DB{
				Error: fmt.Errorf("SaveFail"),
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.Create(context.Background(), &gorm.DB{}, &model.VolcContractCommodityExternal{})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "createContractCommodityFail")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_CreateInBatches(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.CreateInBatches(context.Background(), &gorm.DB{}, []*model.VolcContractCommodityExternal{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case saveFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).Return(&gorm.DB{
				Error: fmt.Errorf("CreateInBatchesFail"),
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.CreateInBatches(context.Background(), &gorm.DB{}, []*model.VolcContractCommodityExternal{})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "createContractCommodityFail")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_DeleteByIds(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{0})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case DeleteFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{0})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "DeleteFail")
		})
	})
	t.Run("case Id is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByIds(context.Background(), &gorm.DB{}, []int64{})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "NO ids")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_DeleteByVolcContractId(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByVolcContractID(context.Background(), &gorm.DB{}, 1)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case DeleteFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByVolcContractID(context.Background(), &gorm.DB{}, 1)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "DeleteFail")
		})
	})
	t.Run("case Id is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{
				Error: fmt.Errorf("DeleteFail"),
			}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.DeleteByVolcContractID(context.Background(), &gorm.DB{}, 0)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "NO volcContractId")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_ListByVolcContractId(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			got, err := v.ListByVolcContractID(context.Background(), &gorm.DB{}, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeEmpty)
		})
	})
	t.Run("case Find fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{Error: fmt.Errorf("FindFail")}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			got, err := v.ListByVolcContractID(context.Background(), &gorm.DB{}, 0)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "ListByVolcContractIdFail")
			convey.So(got, convey.ShouldBeEmpty)
		})
	})
}

func Test_contractCommodityExternalDaoImpl_ListByIdRange(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			got, err := v.ListByIdRange(context.Background(), &gorm.DB{}, 0, 0)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(got, convey.ShouldNotBeEmpty)
		})
	})
	t.Run("case Find fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{Error: fmt.Errorf("FindFail")}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			got, err := v.ListByIdRange(context.Background(), &gorm.DB{}, 0, 0)

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "FindByIdRangeFail")
			convey.So(got, convey.ShouldBeEmpty)
		})
	})
}

func Test_contractCommodityExternalDaoImpl_UpdateByMap(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.UpdateByMap(context.Background(), &gorm.DB{}, 0, map[string]interface{}{"": nil})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case UpdateByMapFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("UpdatesFail")}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			err := v.UpdateByMap(context.Background(), &gorm.DB{}, 0, map[string]interface{}{"": nil})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "UpdateByMapFail")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_ListContractCommodity(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				count = conv.Int64Ptr(1)
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			res, count, err := v.ListContractCommodity(context.Background(), &gorm.DB{}, &modelcommodity.CommodityListParam{
				VolcContractId:       0,
				VolcContractIdList:   []int{0},
				TradeProductName:     "",
				TradeProductNameList: []string{""},
				StartId:              0,
				Limit:                0,
				Offset:               0,
				NeedTotal:            true,
			})

			// Assert
			convey.So(res, convey.ShouldNotBeEmpty)
			convey.So(count, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case CountFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				count = conv.Int64Ptr(1)
				return &gorm.DB{Error: fmt.Errorf("CountFail")}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			res, count, err := v.ListContractCommodity(context.Background(), &gorm.DB{}, &modelcommodity.CommodityListParam{
				VolcContractId:       0,
				VolcContractIdList:   []int{0},
				TradeProductName:     "",
				TradeProductNameList: []string{""},
				StartId:              0,
				Limit:                0,
				Offset:               0,
				NeedTotal:            true,
			})

			// Assert
			convey.So(res, convey.ShouldBeEmpty)
			convey.So(count, convey.ShouldEqual, 0)
			convey.So(err.Error(), convey.ShouldEqual, "ListContractCommodityCountFail")
		})
	})
	t.Run("case FindFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				count = conv.Int64Ptr(1)
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityExternalList:
					*(dest.(*model.VolcContractCommodityExternalList)) = model.VolcContractCommodityExternalList{{RelateQuoteItemID: "1"}}
				}
				return &gorm.DB{
					Error: fmt.Errorf("FindFail"),
				}
			}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			res, count, err := v.ListContractCommodity(context.Background(), &gorm.DB{}, &modelcommodity.CommodityListParam{
				VolcContractId:       0,
				VolcContractIdList:   []int{0},
				TradeProductName:     "",
				TradeProductNameList: []string{""},
				StartId:              0,
				Limit:                0,
				Offset:               0,
				NeedTotal:            false,
			})

			// Assert
			convey.So(res, convey.ShouldBeEmpty)
			convey.So(count, convey.ShouldEqual, 0)
			convey.So(err.Error(), convey.ShouldEqual, "ListContractCommodityFail")
		})
	})
}

func Test_contractCommodityExternalDaoImpl_buildQuery(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityExternalDaoImpl{}
			got := v.buildQuery(context.Background(), &gorm.DB{}, &modelcommodity.CommodityListParam{
				VolcContractId:       1,
				VolcContractIdList:   []int{1, 2, 3},
				TradeProductName:     "ECS",
				TradeProductNameList: []string{"ECS"},
				StartId:              3,
			})

			// Assert
			convey.So(got, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case #2", func(t *testing.T) {})
}

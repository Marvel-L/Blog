package dal

import (
	"context"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
)

const (
	tComment = "comment"
)

type CommentDao interface {
	CreateComment(ctx context.Context, tx *gorm.DB, Comment *model.CommentDB) error
	ListCommentByRelatedID(ctx context.Context, tx *gorm.DB, commentScene int, pageRelatedID string) (model.CommentDBList, error)
	GetCommentByCommentID(ctx context.Context, tx *gorm.DB, commentID string) (*model.CommentDB, error)
	UpdateCommentByCommentID(ctx context.Context, tx *gorm.DB, commentID string, updates map[string]interface{}) error
}

var _commentDaoInstance = &commentDaoImpl{}

func NewCommentDao() CommentDao {
	return _commentDaoInstance
}

type commentDaoImpl struct {
}

func (c *commentDaoImpl) CreateComment(ctx context.Context, tx *gorm.DB, comment *model.CommentDB) error {
	return initDB(ctx, tx).Table(tComment).Create(comment).Error
}

func (c *commentDaoImpl) ListCommentByRelatedID(ctx context.Context, tx *gorm.DB, commentScene int, relatedID string) (model.CommentDBList, error) {
	ret := model.CommentDBList{}
	if err := initDB(ctx, tx).Table(tComment).Where("comment_scene = ? and related_id = ?", commentScene, relatedID).Find(&ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

func (c *commentDaoImpl) UpdateCommentByCommentID(ctx context.Context, tx *gorm.DB, commentID string, updates map[string]interface{}) error {
	return initDB(ctx, tx).Table(tComment).Where("comment_id = ?", commentID).Updates(updates).Error
}

func (c *commentDaoImpl) GetCommentByCommentID(ctx context.Context, tx *gorm.DB, commentID string) (*model.CommentDB, error) {
	ret := &model.CommentDB{}
	if err := initDB(ctx, tx).Table(tComment).Where("comment_id = ?", commentID).First(ret).Error; err != nil {
		return nil, err
	}
	return ret, nil
}

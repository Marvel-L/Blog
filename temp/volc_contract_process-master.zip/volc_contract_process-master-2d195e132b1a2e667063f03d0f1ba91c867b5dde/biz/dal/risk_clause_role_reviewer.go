package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tRiskClauseRoleReviewer = "risk_clause_role_reviewer"
)

type RiskClauseRoleReviewerDao interface {
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseRoleReviewerDB) error
	GetByRoleIDs(ctx context.Context, tx *gorm.DB, roleIDs []int64) ([]*model.RiskClauseRoleReviewerDB, error)
	DeleteByRoleID(ctx context.Context, tx *gorm.DB, roleID int64) error
}

var _riskClauseRoleReviewerDaoInstance = &riskClauseRoleReviewerDaoImpl{}

func NewRiskClauseRoleReviewerDao() RiskClauseRoleReviewerDao {
	return _riskClauseRoleReviewerDaoInstance
}

type riskClauseRoleReviewerDaoImpl struct {
}

func (r *riskClauseRoleReviewerDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseRoleReviewerDB) error {
	if len(entities) == 0 {
		return nil
	}
	err := initDB(ctx, tx).Table(tRiskClauseRoleReviewer).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreateRiskClauseRoleReviewerFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "batchCreateRiskClauseRoleReviewerFail, err:%v", err))
	}
	return nil
}

func (r riskClauseRoleReviewerDaoImpl) GetByRoleIDs(ctx context.Context, tx *gorm.DB, roleIDs []int64) ([]*model.RiskClauseRoleReviewerDB, error) {
	if len(roleIDs) == 0 {
		return nil, nil
	}
	var list []*model.RiskClauseRoleReviewerDB
	err := initDB(ctx, tx).Table(tRiskClauseRoleReviewer).Where("risk_clause_role_id IN (?)", roleIDs).Where("is_deleted = 0").Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "GetByRoleIDsFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "GetByRoleIDsFail")
	}
	return list, nil
}

func (r riskClauseRoleReviewerDaoImpl) DeleteByRoleID(ctx context.Context, tx *gorm.DB, roleID int64) error {
	err := initDB(ctx, tx).Table(tRiskClauseRoleReviewer).Where("risk_clause_role_id = ?", roleID).Updates(map[string]interface{}{"is_deleted": 1}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteByRoleIDFail, roleID=%d, err:%v", roleID, err)
		return i18nfmt.New(ctx, "DeleteByRoleIDFail")
	}
	return nil
}

package dal

import (
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tPreContractReviewRule = "pre_contract_review_rule"
)

type PreContractReviewRuleDao interface {
	Create(ctx context.Context, tx *gorm.DB, rule *model.ReviewRuleDB) error
	Update(ctx context.Context, tx *gorm.DB, rule *model.ReviewRuleDB) error
	UpdateStatus(ctx context.Context, tx *gorm.DB, ruleID string, status int, operator string) error
	FindByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) (*model.ReviewRuleDB, error)
	FindByRuleIDs(ctx context.Context, tx *gorm.DB, ruleIDs []string) (*model.ReviewRuleDB, error)
	FindBySalesDepartment(ctx context.Context, tx *gorm.DB, salesDepartment string) (*model.ReviewRuleDB, error)
	DeleteByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) error
	List(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleListParams) (model.ReviewRuleDBList, int, error)
	ListAll(ctx context.Context, tx *gorm.DB) (model.ReviewRuleDBList, error)
	ListByEmployeeEmail(ctx context.Context, tx *gorm.DB, employeeEmail string, withReviewers bool) (reviewers []*model.ReviewRuleReviewerDB, reviewRules []*model.ReviewRuleDB, err error)
}

var _preContractReviewRuleDaoInstance = &preContractReviewRuleDaoImpl{}

func NewPreContractReviewRuleDao() PreContractReviewRuleDao {
	return _preContractReviewRuleDaoInstance
}

type preContractReviewRuleDaoImpl struct {
}

func (p *preContractReviewRuleDaoImpl) Create(ctx context.Context, tx *gorm.DB, rule *model.ReviewRuleDB) error {
	err := initDB(ctx, tx).Table(tPreContractReviewRule).Create(rule).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createPreContractReviewRuleFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractMetaFail")
	}
	return nil
}

func (p *preContractReviewRuleDaoImpl) Update(ctx context.Context, tx *gorm.DB, rule *model.ReviewRuleDB) error {
	err := initDB(ctx, tx).Table(tPreContractReviewRule).Select("*").
		Omit("id", "rule_id", "creator_email", "created_time", "status").
		Where("rule_id = ?", rule.RuleID).
		Updates(rule).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updatePreContractReviewRuleFail, RuleID:%s, err:%s", rule.RuleID, err.Error())
		return i18nfmt.New(ctx, "updatePreContractReviewRuleFail")
	}
	return nil
}

func (p *preContractReviewRuleDaoImpl) UpdateStatus(ctx context.Context, tx *gorm.DB, ruleID string, status int, operator string) error {
	err := initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id = ?", ruleID).Updates(map[string]interface{}{
		"status":        status,
		"updater_email": operator,
	}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ReviewRuleDAO.UpdateFields error: %+v", err)
		return err
	}
	return nil
}

func (p *preContractReviewRuleDaoImpl) FindByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) (*model.ReviewRuleDB, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id = ?", ruleID)
	var ret model.ReviewRuleDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByRuleIDFail, ruleID=%s err=%s", ruleID, err.Error())
		return nil, i18nfmt.New(ctx, "FindByRuleIDFail")
	}
	return &ret, nil
}

func (p *preContractReviewRuleDaoImpl) FillReviewers(ctx context.Context, tx *gorm.DB, reviewRules []*model.ReviewRuleDB) error {
	var ruleIDs []string
	ruleIDReviewRuleMap := map[string]*model.ReviewRuleDB{}
	for _, reviewRule := range reviewRules {
		if _, ok := ruleIDReviewRuleMap[reviewRule.RuleID]; ok {
			logs.CtxError(ctx, "ReviewRuleDAO.FillReviewers duplicated RuleID: %s", reviewRule.RuleID)
			return i18nfmt.Errorf(ctx, "duplicated RuleID: %s", reviewRule.RuleID)
		}
		ruleIDs = append(ruleIDs, reviewRule.RuleID)
		ruleIDReviewRuleMap[reviewRule.RuleID] = reviewRule
	}
	var reviewers []*model.ReviewRuleReviewerDB
	err := initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id IN ?", ruleIDs).Find(&reviewers).Error
	if err != nil {
		return err
	}
	for _, reviewer := range reviewers {
		if reviewRule, ok := ruleIDReviewRuleMap[reviewer.RuleID]; ok {
			reviewRule.Reviewers = append(reviewRule.Reviewers, reviewer)
		} else {
			logs.CtxError(ctx, "ReviewRuleDAO.FillReviewers unexpected RuleID reviewer not found: %s", reviewer.RuleID)
			return i18nfmt.Errorf(ctx, "unexpected RuleID reviewer not found: %s", reviewer.RuleID)
		}
	}
	return nil
}

func (p *preContractReviewRuleDaoImpl) FindByRuleIDs(ctx context.Context, tx *gorm.DB, ruleIDs []string) (*model.ReviewRuleDB, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id IN ?", ruleIDs)
	var ret model.ReviewRuleDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByRuleIDFail, ruleID=%v err=%s", ruleIDs, err.Error())
		return nil, i18nfmt.New(ctx, "FindByRuleIDFail")
	}
	return &ret, nil
}

func (p *preContractReviewRuleDaoImpl) FindBySalesDepartment(ctx context.Context, tx *gorm.DB, salesDepartment string) (*model.ReviewRuleDB, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewRule).Where("sales_department = ?", salesDepartment)
	var ret model.ReviewRuleDB
	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindBySalesDepartmentFail, salesDepartment=%s err=%s", salesDepartment, err.Error())
		return nil, i18nfmt.New(ctx, "FindBySalesDepartmentFail")
	}
	return &ret, nil
}

func (p *preContractReviewRuleDaoImpl) DeleteByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) error {
	if len(ruleID) == 0 {
		logs.CtxError(ctx, "DeleteByRuleIDFail, ruleIDEmpty")
		return nil
	}

	logs.CtxInfo(ctx, "DeleteByRuleID, ruleID=%s", ruleID)

	db := initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id = ?", ruleID)

	return ignoreErr(db.Delete(nil).Error)

}

func (p *preContractReviewRuleDaoImpl) List(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleListParams) (model.ReviewRuleDBList, int, error) {
	var total int64
	var err error

	db := p.buildQuery(ctx, tx, param)

	if param.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListPreContractReviewRuleFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListPreContractReviewRuleFail")
		}
	}

	// 分页逻辑兼容
	if param.Limit != 0 {
		db = db.Limit(param.Limit)
	}
	db = db.Offset(param.Offset)

	var list []*model.ReviewRuleDB
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListPreContractReviewRuleFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListPreContractReviewRuleFail")
	}

	return list, int(total), nil
}

func (p *preContractReviewRuleDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleListParams) *gorm.DB {
	db := initDB(ctx, tx).Table(tPreContractReviewRule)

	if param.SalesDepartment != "" {
		db = db.Where("sales_department LIKE ?", buildLikeQuery(param.SalesDepartment))
	}
	if len(param.SalesDepartmentList) > 0 {
		db = db.Where("sales_department in (?)", param.SalesDepartmentList)
	}
	if len(param.Status) != 0 {
		db = db.Where("status IN (?)", param.Status)
	}
	if len(param.RuleIds) != 0 {
		db = db.Where("rule_id IN (?)", param.RuleIds)
	}

	db = db.Order("id desc")

	return db
}

func (p *preContractReviewRuleDaoImpl) ListAll(ctx context.Context, tx *gorm.DB) (model.ReviewRuleDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewRule).Order("id desc")
	var list []*model.ReviewRuleDB
	err := db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListAllReviewRuleFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListAllReviewRuleFail")
	}
	return list, nil
}

func (d *preContractReviewRuleDaoImpl) ListByEmployeeEmail(ctx context.Context, tx *gorm.DB, employeeEmail string, withReviewers bool) (reviewers []*model.ReviewRuleReviewerDB, reviewRules []*model.ReviewRuleDB, err error) {
	err = initDB(ctx, tx).Table(tPreContractReviewRuleReviewer).Where("employee_email = ?", employeeEmail).Find(&reviewers).Error
	if err != nil {
		logs.CtxError(ctx, "[ListByEmployeeEmail] Find 1 error: err=%v employeeEmail=%s", err, employeeEmail)
		return nil, nil, err
	}

	var ruleIDs []string
	for _, reviewer := range reviewers {
		ruleIDs = append(ruleIDs, reviewer.RuleID)
	}
	err = initDB(ctx, tx).Table(tPreContractReviewRule).Where("rule_id IN ?", ruleIDs).Find(&reviewRules).Error
	if err != nil {
		logs.CtxError(ctx, "[ListByEmployeeEmail] Find 2 error: err=%v ruleIDs=%v", err, ruleIDs)
		return nil, nil, err
	}

	if withReviewers {
		err := d.FillReviewers(ctx, tx, reviewRules)
		if err != nil {
			logs.CtxError(ctx, "[ListByEmployeeEmail] FillReviewers err: %v", err)
			return nil, nil, err
		}
	}
	return
}

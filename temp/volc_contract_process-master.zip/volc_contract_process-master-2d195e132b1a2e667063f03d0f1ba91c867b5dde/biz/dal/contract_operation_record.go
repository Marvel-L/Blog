package dal

import (
	"context"
	"strings"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	TContractOperationRecord = "contract_operation_record"
)

type ContractOperationRecordDao interface {
	// ListByReq 根据请求参数查询合同操作记录列表
	ListByReq(ctx context.Context, tx *gorm.DB, req *model.ContractOpRecordReq) (model.ContractOperationRecordDBList, int, error)
	// ListLastRecordByOperation 查询指定操作的操作记录
	ListRecordByOperation(ctx context.Context, tx *gorm.DB, preContractNo string, operation []int) (model.ContractOperationRecordDBList, error)
	// 查询节点最后的处理记录
	ListLastRecordByOperationAndStatus(ctx context.Context, tx *gorm.DB, preContractNo string, operation []int, status int) (*model.ContractOperationRecordDB, error)
	GetLastRecordByOperationStatusAndCreatedTime(ctx context.Context, tx *gorm.DB, req *model.ContractOperationRecordCreatedTimeReq) (*model.ContractOperationRecordDB, error)
	BatchListRecordByOperationAndStatus(ctx context.Context, tx *gorm.DB, preContractNos []string, operation []int, status int) (model.ContractOperationRecordDBList, error)
	// 创建操作记录
	Create(ctx context.Context, tx *gorm.DB, contractOperationRecordDB *model.ContractOperationRecordDB) error
	// - 在线协同 -
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.ContractOperationRecordDB) error
	UpdateNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	// ListByReq 根据请求参数查询合同操作记录列表
	DeleteByNo(ctx context.Context, tx *gorm.DB, preContractNo string) error
}

var _contractOpRecordDaoInstance = &contractOperationRecordDaoImpl{}

func NewContractOperationRecordDao() ContractOperationRecordDao {
	return _contractOpRecordDaoInstance
}

type contractOperationRecordDaoImpl struct {
}

func (c contractOperationRecordDaoImpl) Create(ctx context.Context, tx *gorm.DB, contractOperationRecordDB *model.ContractOperationRecordDB) error {
	return ignoreErr(initDB(ctx, tx).Table(TContractOperationRecord).Create(contractOperationRecordDB).Error)
}

func (c contractOperationRecordDaoImpl) ListByReq(ctx context.Context, tx *gorm.DB, req *model.ContractOpRecordReq) (model.ContractOperationRecordDBList, int, error) {

	if req == nil {
		return nil, 0, i18nfmt.New(ctx, "req_is_nil")
	}

	var total int64
	var err error

	db := initDB(ctx, tx).Table(TContractOperationRecord).Where("operation not in (?)", []int{0, 7}) // 此处为在线协同逻辑移植 后续统一处理
	if req.PreContractNo != "" {
		db = db.Where("pre_contract_no = ?", req.PreContractNo)
	}
	if req.PreContractNoList != "" {
		db = db.Where("pre_contract_no in (?)", strings.Split(req.PreContractNoList, ","))
	}

	if req.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "opRecordDalListByReqFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "opRecordDalListByReqFail")
		}
	}

	// 以limit>0作为需要分页查询的标志
	if req.Limit > 0 {
		db = db.Limit(req.Limit).Offset(req.Offset)
	}

	var ret model.ContractOperationRecordDBList
	if err = db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "opRecordDalListByReqFail, err => %v", err)
		return nil, 0, i18nfmt.New(ctx, "opRecordDalListByReqFail")
	}

	return ret, int(total), nil
}

func (c contractOperationRecordDaoImpl) ListLastRecordByOperationAndStatus(ctx context.Context, tx *gorm.DB, preContractNo string, operation []int, status int) (*model.ContractOperationRecordDB, error) {

	if preContractNo == "" {
		return nil, i18nfmt.New(ctx, "preContractNo_is_nil")
	}

	var err error

	db := initDB(ctx, tx).Table(TContractOperationRecord).Where("operation not in (?)", []int{0, 7}) // 此处为在线协同逻辑移植 后续统一处理
	db = db.Where("pre_contract_no = ?", preContractNo).
		Where("operation in (?)", operation).
		Where("contract_status = ?", status).
		Order("id desc").Limit(1)

	var ret *model.ContractOperationRecordDB
	if err = db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "opRecordDalListByReqFail, err => %v", err)
		return nil, i18nfmt.New(ctx, "opRecordDalListByReqFail")
	}

	return ret, nil
}

func (c contractOperationRecordDaoImpl) GetLastRecordByOperationStatusAndCreatedTime(ctx context.Context, tx *gorm.DB, req *model.ContractOperationRecordCreatedTimeReq) (*model.ContractOperationRecordDB, error) {
	if req == nil {
		return nil, i18nfmt.New(ctx, "req_is_nil")
	}
	if req.PreContractNo == "" {
		return nil, i18nfmt.New(ctx, "preContractNo_is_nil")
	}

	var ret model.ContractOperationRecordDB
	db := initDB(ctx, tx).Table(TContractOperationRecord).Where("operation not in (?)", []int{0, 7})
	db = db.Where("pre_contract_no = ?", req.PreContractNo).
		Where("operation = ?", req.Operation).
		Where("contract_status = ?", req.ContractStatus).
		Where("created_time = ?", req.CreatedTime).
		Order("id desc").Limit(1)

	result := db.Find(&ret)
	if ignoreErr(result.Error) != nil {
		logs.CtxError(ctx, "opRecordDalListByReqFail, err => %v", result.Error)
		return nil, i18nfmt.New(ctx, "opRecordDalListByReqFail")
	}
	if result.RowsAffected == 0 {
		return nil, nil
	}

	return &ret, nil
}

func (c contractOperationRecordDaoImpl) ListRecordByOperation(ctx context.Context, tx *gorm.DB, preContractNo string, operation []int) (model.ContractOperationRecordDBList, error) {

	if preContractNo == "" {
		return nil, i18nfmt.New(ctx, "preContractNo_is_nil")
	}

	var err error

	db := initDB(ctx, tx).Table(TContractOperationRecord).Where("operation not in (?)", []int{0, 7}) // 此处为在线协同逻辑移植 后续统一处理
	db = db.Where("pre_contract_no = ?", preContractNo).
		Where("operation in (?)", operation).
		Order("id desc").Limit(1)

	var ret model.ContractOperationRecordDBList
	if err = db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "opRecordDalListByReqFail, err => %v", err)
		return nil, i18nfmt.New(ctx, "opRecordDalListByReqFail")
	}

	return ret, nil
}

func (c contractOperationRecordDaoImpl) BatchListRecordByOperationAndStatus(ctx context.Context, tx *gorm.DB, preContractNos []string, operation []int, status int) (model.ContractOperationRecordDBList, error) {

	if len(preContractNos) == 0 {
		return nil, i18nfmt.New(ctx, "preContractNos_is_nil")
	}

	var err error

	db := initDB(ctx, tx).Table(TContractOperationRecord).Where("operation not in (?)", []int{0, 7}) // 此处为在线协同逻辑移植 后续统一处理
	db = db.Where("pre_contract_no in (?)", preContractNos).
		Where("operation in (?)", operation).
		Where("contract_status = ?", status).
		Order("id desc")

	var ret model.ContractOperationRecordDBList
	if err = db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "opRecordDalListByReqFail, err => %v", err)
		return nil, i18nfmt.New(ctx, "opRecordDalListByReqFail")
	}

	return ret, nil
}

func (c *contractOperationRecordDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.ContractOperationRecordDB) error {
	err := initDB(ctx, tx).Table(TContractOperationRecord).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreateTradePartyFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "batchCreateTradePartyFail,err:%v", err))
	}
	return nil
}

// UpdateNo 更新pre_contract_no
func (c contractOperationRecordDaoImpl) UpdateNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error {

	err := initDB(ctx, tx).Table(TContractOperationRecord).Where("pre_contract_no = ?", oldNo).
		Updates(map[string]interface{}{"pre_contract_no": newNo}).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "RecordUpdateNoFail, err: %v", err)
		return i18nfmt.New(ctx, "RecordUpdateNoFail")
	}

	return nil
}

func (c *contractOperationRecordDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(TContractOperationRecord)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c contractOperationRecordDaoImpl) DeleteByNo(ctx context.Context, tx *gorm.DB, preContractNo string) error {
	return ignoreErr(initDB(ctx, tx).Table(TContractOperationRecord).Where("pre_contract_no = ?", preContractNo).Delete(nil).Error)
}

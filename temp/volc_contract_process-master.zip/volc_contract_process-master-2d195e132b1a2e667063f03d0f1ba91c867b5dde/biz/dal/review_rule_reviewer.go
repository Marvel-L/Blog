package dal

import (
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelreviewrule"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tPreContractReviewRuleReviewer = "pre_contract_review_rule_reviewer"
)

type PreContractReviewRuleReviewerDao interface {
	CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.ReviewRuleReviewerDB) error
	DeleteByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) error
	List(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleReviewerListParams) (model.ReviewRuleReviewerDBList, int, error)
	ListAll(ctx context.Context, tx *gorm.DB) (model.ReviewRuleReviewerDBList, error)
}

var _preContractReviewRuleReviewerDaoInstance = &preContractReviewRuleReviewerDaoImpl{}

func NewPreContractReviewRuleReviewerDao() PreContractReviewRuleReviewerDao {
	return _preContractReviewRuleReviewerDaoInstance
}

type preContractReviewRuleReviewerDaoImpl struct {
}

func (p *preContractReviewRuleReviewerDaoImpl) CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.ReviewRuleReviewerDB) error {
	err := initDB(ctx, tx).Table(tPreContractReviewRuleReviewer).CreateInBatches(list, len(list)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createReviewRuleReviewerFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createReviewRuleReviewerFail")
	}
	return nil
}

func (p *preContractReviewRuleReviewerDaoImpl) DeleteByRuleID(ctx context.Context, tx *gorm.DB, ruleID string) error {
	err := initDB(ctx, tx).Table(tPreContractReviewRuleReviewer).Where("rule_id =?", ruleID).Delete(nil).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteByRuleIDFail, ruleID=%s err=%s", ruleID, err.Error())
		return i18nfmt.New(ctx, "DeleteByRuleIDFail")
	}
	return nil
}

func (p *preContractReviewRuleReviewerDaoImpl) List(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleReviewerListParams) (model.ReviewRuleReviewerDBList, int, error) {
	var total int64
	var err error

	db := p.buildQuery(ctx, tx, param)

	if param.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListPreContractReviewRuleReviewerFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListPreContractReviewRuleReviewerFail")
		}
	}

	// 分页逻辑兼容
	if param.Limit != 0 {
		db = db.Limit(param.Limit)
	}
	db = db.Offset(param.Offset)

	var list []*model.ReviewRuleReviewerDB
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListPreContractReviewRuleReviewerFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListPreContractReviewRuleReviewerFail")
	}

	return list, int(total), nil
}

func (p *preContractReviewRuleReviewerDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, param *modelreviewrule.ReviewRuleReviewerListParams) *gorm.DB {
	db := initDB(ctx, tx).Table(tPreContractReviewRuleReviewer)

	if param.EmployeeEmail != "" {
		db = db.Where("employee_email = ?", param.EmployeeEmail)
	}
	if len(param.RuleIds) != 0 {
		db = db.Where("rule_id in (?)", param.RuleIds)
	}

	db = db.Order("id desc")

	return db
}

func (p *preContractReviewRuleReviewerDaoImpl) ListAll(ctx context.Context, tx *gorm.DB) (model.ReviewRuleReviewerDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewRuleReviewer).Order("id desc")
	var list []*model.ReviewRuleReviewerDB
	err := db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListAllReviewRuleReviewerFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListPreContractReviewRuleFail")
	}
	return list, nil
}

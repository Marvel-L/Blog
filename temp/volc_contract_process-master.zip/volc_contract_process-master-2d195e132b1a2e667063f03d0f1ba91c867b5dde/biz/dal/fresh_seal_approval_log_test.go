package dal

import (
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/env"
)

func Test_freshSealApprovalLogDaoImpl_Create_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_freshSealApprovalLogDaoImpl_Create", t, func() {
		ctx := context.Background()
		dao := &freshSealApprovalLogDaoImpl{}
		entity := &model.FreshSealApprovalLogDB{
			LogId:         "log-001",
			ApplyId:       "apply-001",
			Operator:      "tester",
			OperationType: 1,
			Content:       "content",
			Remark:        "remark",
		}
		var mockTx *gorm.DB

		mockey.PatchConvey("场景：创建日志成功，数据库返回nil错误", func() {
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				convey.So(value, convey.ShouldEqual, entity)
				return &gorm.DB{Error: nil}
			}).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：Create返回gorm.ErrRecordNotFound错误被忽略", func() {
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：非线上环境返回RASP错误被忽略", func() {
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			raspErr := errors.New("internal error: API blocked by RASP")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.MockUnsafe(env.IsOnline).Return(false).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：通用错误触发日志打印并返回国际化错误", func() {
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			dbErr := errors.New("database create error")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
			// 避免默认日志器为空导致的空指针
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createFreshSealApprovalLogFail")
		})

		mockey.PatchConvey("场景：线上环境返回RASP错误不被忽略并返回国际化错误", func() {
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.MockUnsafe(env.IsOnline).Return(true).Build()
			// 避免默认日志器为空导致的空指针
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createFreshSealApprovalLogFail")
		})
	})
}

func Test_NewFreshSealApprovalLogDao_BitsUTGen(t *testing.T) {
	t.Run("默认实例返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 通过MockValue确保全局变量实例可控
			inst := &freshSealApprovalLogDaoImpl{}
			mockey.MockValue(&_freshSealApprovalLogDaoInstance).To(inst)

			dao := NewFreshSealApprovalLogDao()
			convey.So(dao, convey.ShouldNotBeNil)

			// 断言返回的接口实际指向的实现与全局变量一致
			impl, ok := dao.(*freshSealApprovalLogDaoImpl)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(impl, convey.ShouldEqual, inst)
		})
	})

	t.Run("覆盖全局实例后返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 覆盖全局实例，验证返回值随之变化
			newInst := &freshSealApprovalLogDaoImpl{}
			mockey.MockValue(&_freshSealApprovalLogDaoInstance).To(newInst)

			dao := NewFreshSealApprovalLogDao()
			convey.So(dao, convey.ShouldNotBeNil)

			impl, ok := dao.(*freshSealApprovalLogDaoImpl)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(impl, convey.ShouldEqual, newInst)
		})
	})
}

func Test_freshSealApprovalLogDaoImpl_ListByApplyId_BitsUTGen(t *testing.T) {
	t.Run("applyId为空返回RecordNotFound", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalLogDaoImpl{}
			ctx := context.Background()

			list, total, err := receiver.ListByApplyId(ctx, nil, "", 0, 0)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldEqual, gorm.ErrRecordNotFound)
		})
	})

	t.Run("Count阶段返回非忽略错误直接失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalLogDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// 构造查询链路
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()

			// Count返回非忽略错误
			countErr := errors.New("count error")
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: countErr}).Build()

			list, total, err := receiver.ListByApplyId(ctx, tx, "apply-001", 0, 0)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldEqual, countErr)
		})
	})

	t.Run("Find阶段出错返回i18n错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalLogDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// 构造查询链路
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()

			// Count成功并写入total
			mockey.Mock((*gorm.DB).Count).To(func(db *gorm.DB, count *int64) *gorm.DB {
				*count = 10
				return &gorm.DB{Error: nil}
			}).Build()

			// 分页
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{}).Build()

			// 排序
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Find返回非忽略错误
			findErr := errors.New("find error")
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: findErr}).Build()

			list, total, err := receiver.ListByApplyId(ctx, tx, "apply-002", 5, 1)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "freshSealApprovalLogListByApplyIdFail")
		})
	})

	t.Run("查询成功limit大于0分页返回列表和总数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalLogDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// 构造查询链路
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()

			// Count成功并写入total
			mockey.Mock((*gorm.DB).Count).To(func(db *gorm.DB, count *int64) *gorm.DB {
				*count = 7
				return &gorm.DB{Error: nil}
			}).Build()

			// 分页
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{}).Build()

			// 排序
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{}).Build()

			// Find成功并填充list
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if p, ok := dest.(*model.FreshSealApprovalLogDBList); ok && p != nil {
					*p = make(model.FreshSealApprovalLogDBList, 0)
				}
				return &gorm.DB{Error: nil}
			}).Build()

			list, total, err := receiver.ListByApplyId(ctx, tx, "apply-003", 8, 1)
			convey.So(err, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 7)
			convey.So(list, convey.ShouldNotBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
		})
	})
}

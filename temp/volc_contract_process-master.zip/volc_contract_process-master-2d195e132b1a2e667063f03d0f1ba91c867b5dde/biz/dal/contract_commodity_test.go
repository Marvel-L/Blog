package dal

import (
	"fmt"
	"testing"

	"code.byted.org/gopkg/context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_contractCommodityDaoImpl_GetInvoiceByContractAndProduct(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityList:
					*(dest.(*model.VolcContractCommodityList)) = []*model.VolcContractCommodity{{}}
				}
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityDaoImpl{}
			got, err := v.GetInvoiceByContractAndProduct(context.Background(), &gorm.DB{}, 123, "ECS")

			// Assert
			convey.So(got, convey.ShouldResemble, model.VolcContractCommodityList{{}})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case FindFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			// mockey.Mock(ignoreNotFoundErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				return &gorm.DB{Error: fmt.Errorf("FindFail")}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractCommodityDaoImpl{}
			got, err := v.GetInvoiceByContractAndProduct(context.Background(), &gorm.DB{}, 123, "ECS")

			// Assert
			convey.So(got, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "GetInvoiceByContractAndProductFail")
		})
	})
}

func Test_contractCommodityDaoImpl_ListContractCommodity(t *testing.T) {
	ctx := context.Background()
	tx := &gorm.DB{} // Mock or initialize as needed
	param := &modelcommodity.CommodityListParam{
		CurrentOperator:      "testOperator",
		ContractNo:           "testContractNo",
		VolcContractId:       123,
		VolcContractIdList:   []int{123, 456},
		TradeProductName:     "testProductName",
		TradeProductNameList: []string{"testProductName1", "testProductName2"},
		TradeProductCode:     "testProductCode",
		TradeProductCodeList: "testProductCodeList",
		TradeProduct:         "testProduct",
		TradeProductList:     "testProductList",
		StartId:              uint64(1),
		Limit:                10,
		Offset:               0,
		NeedTotal:            true,
		Extra:                "testExtra",
	}
	c := &contractCommodityDaoImpl{}

	mockey.PatchConvey("Test ListContractCommodity", t, func() {
		mockey.Mock((*contractCommodityDaoImpl).buildQuery).Return(tx).Build()

		mockey.PatchConvey("Test NeedTotal true and Count fails", func() {
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: fmt.Errorf("count error")}).Build()
			list, total, err := c.ListContractCommodity(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("Test NeedTotal true and Count success", func() {
			mockey.Mock((*gorm.DB).Count).Return(tx).Build()
			mockey.Mock((*gorm.DB).Limit).Return(tx).Build()
			mockey.Mock((*gorm.DB).Offset).Return(tx).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: fmt.Errorf("find error")}).Build()
			list, total, err := c.ListContractCommodity(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("Test NeedTotal false and Find fails", func() {
			param.NeedTotal = false
			mockey.Mock((*gorm.DB).Count).Return(tx).Build()
			mockey.Mock((*gorm.DB).Limit).Return(tx).Build()
			mockey.Mock((*gorm.DB).Offset).Return(tx).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: fmt.Errorf("find error")}).Build()
			list, total, err := c.ListContractCommodity(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("Test NeedTotal false and Find success", func() {
			param.NeedTotal = false
			expectedList := model.VolcContractCommodityList{&model.VolcContractCommodity{ContractNo: "testContractNo"}}
			mockey.Mock((*gorm.DB).Count).Return(tx).Build()
			mockey.Mock((*gorm.DB).Limit).Return(tx).Build()
			mockey.Mock((*gorm.DB).Offset).Return(tx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityList:
					*(dest.(*model.VolcContractCommodityList)) = model.VolcContractCommodityList{&model.VolcContractCommodity{ContractNo: "testContractNo"}}
				}
				return &gorm.DB{}
			}).Build()
			list, total, err := c.ListContractCommodity(ctx, tx, param)
			convey.So(list, convey.ShouldResemble, expectedList)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test NeedTotal true and both Count and Find success", func() {
			param.NeedTotal = true
			expectedList := model.VolcContractCommodityList{&model.VolcContractCommodity{ContractNo: "testContractNo"}}
			mockey.Mock((*gorm.DB).Count).Return(tx).Build()
			mockey.Mock((*gorm.DB).Limit).Return(tx).Build()
			mockey.Mock((*gorm.DB).Offset).Return(tx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) (tx *gorm.DB) {
				type ExampleModel struct{}
				switch dest.(type) {
				case *ExampleModel: // Here replace with your model type, like Task{}
					*(dest.(*ExampleModel)) = ExampleModel{}
				case *model.VolcContractCommodityList:
					*(dest.(*model.VolcContractCommodityList)) = model.VolcContractCommodityList{&model.VolcContractCommodity{ContractNo: "testContractNo"}}
				}
				return &gorm.DB{}
			}).Build()
			list, total, err := c.ListContractCommodity(ctx, tx, param)
			convey.So(list, convey.ShouldResemble, expectedList)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})

	})
}

package dal

import (
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	context001 "context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/proxy/starlingcli"
)

func Test_preContractReviewerDaoImpl_FindAccessibleNoList_BitsUTGen(t *testing.T) {
	// 准备公共的模拟上下文和DAO实例
	ctx := context001.Background()
	dao := &preContractReviewerDaoImpl{}
	mockDB := &gorm.DB{}

	mockey.PatchConvey("Test preContractReviewerDaoImpl.FindAccessibleNoList", t, func() {
		// 模拟GORM链式调用的各个环节
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Select).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Or).Return(mockDB).Build()
		// 模拟日志和错误处理函数
		mockey.Mock(logs.CtxError).Return().Build()
		mockey.Mock(i18nfmt.New).To(func(ctx context001.Context, text string) error {
			return errors.New(text)
		}).Build()

		mockey.PatchConvey("成功场景: 提供了 reviewer, idRoleList 和 nameRoleList", func() {
			// 场景描述：
			// 构造数据：reviewer, idRoleList, nameRoleList 均有值。
			// 逻辑链路：
			// 1. 调用 initDB, Table, Select, Where 构建基础查询。
			// 2. idRoleList 和 nameRoleList 长度大于0，两个 Or 条件都被添加。
			// 3. Mock DB.Find 方法，模拟数据库查询成功，并返回预设的数据列表。
			// 4. 函数遍历返回的VO列表，提取 PreContractNo 字段。
			// 5. 最终返回提取出的字符串切片和 nil 错误。
			reviewer := "test_user"
			idRoleList := [][]interface{}{{"dept_id_1", "role_id_1"}}
			nameRoleList := [][]interface{}{{"dept_name_2", "role_name_2"}}
			expectedResult := []string{"PC-001", "PC-002"}

			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*[]*model.PreContractNoVO); ok {
					*list = []*model.PreContractNoVO{
						{PreContractNo: "PC-001"},
						{PreContractNo: "PC-002"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, idRoleList, nameRoleList)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("成功场景: 仅提供了 reviewer", func() {
			// 场景描述：
			// 构造数据：仅 reviewer 有值，idRoleList 和 nameRoleList 为空。
			// 逻辑链路：
			// 1. 调用 initDB, Table, Select, Where 构建基础查询。
			// 2. idRoleList 和 nameRoleList 为空，跳过添加 Or 条件的逻辑。
			// 3. Mock DB.Find 方法，模拟数据库查询成功。
			// 4. 函数成功返回结果。
			reviewer := "test_user"
			expectedResult := []string{"PC-003"}

			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*[]*model.PreContractNoVO); ok {
					*list = []*model.PreContractNoVO{
						{PreContractNo: "PC-003"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, nil, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("成功场景: 提供了 reviewer 和 idRoleList", func() {
			// 场景描述：
			// 构造数据：reviewer 和 idRoleList 有值，nameRoleList 为空。
			// 逻辑链路：
			// 1. 调用 initDB, Table, Select, Where 构建基础查询。
			// 2. idRoleList 不为空，添加第一个 Or 条件。nameRoleList 为空，跳过第二个 Or。
			// 3. Mock DB.Find 方法，模拟数据库查询成功。
			// 4. 函数成功返回结果。
			reviewer := "test_user"
			idRoleList := [][]interface{}{{"dept_id_1", "role_id_1"}}
			expectedResult := []string{"PC-004"}

			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*[]*model.PreContractNoVO); ok {
					*list = []*model.PreContractNoVO{
						{PreContractNo: "PC-004"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, idRoleList, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("成功场景: 提供了 reviewer 和 nameRoleList", func() {
			// 场景描述：
			// 构造数据：reviewer 和 nameRoleList 有值，idRoleList 为空。
			// 逻辑链路：
			// 1. 调用 initDB, Table, Select, Where 构建基础查询。
			// 2. idRoleList 为空，跳过第一个 Or。nameRoleList 不为空，添加第二个 Or 条件。
			// 3. Mock DB.Find 方法，模拟数据库查询成功。
			// 4. 函数成功返回结果。
			reviewer := "test_user"
			nameRoleList := [][]interface{}{{"dept_name_2", "role_name_2"}}
			expectedResult := []string{"PC-005"}

			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*[]*model.PreContractNoVO); ok {
					*list = []*model.PreContractNoVO{
						{PreContractNo: "PC-005"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, nil, nameRoleList)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("成功场景: 数据库未找到记录", func() {
			// 场景描述：
			// 构造数据：任意合法输入。
			// 逻辑链路：
			// 1. 查询构建同上。
			// 2. Mock DB.Find 方法，模拟数据库返回 gorm.ErrRecordNotFound 错误。
			// 3. ignoreErr 函数会忽略 gorm.ErrRecordNotFound，因此错误被处理为 nil。
			// 4. 函数返回一个空的切片和 nil 错误。
			reviewer := "non_existent_user"

			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, nil, nil)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("失败场景: 数据库查询失败", func() {
			// 场景描述：
			// 构造数据：任意合法输入。
			// 逻辑链路：
			// 1. 查询构建同上。
			// 2. Mock DB.Find 方法，模拟数据库返回一个通用错误。
			// 3. ignoreErr 函数不会忽略此错误，错误继续传递。
			// 4. 函数内部会调用 logs.CtxError 记录错误。
			// 5. 函数调用 i18nfmt.New 生成并返回一个新的错误。
			reviewer := "any_user"
			dbError := errors.New("database connection lost")

			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbError}).Build()

			result, err := dao.FindAccessibleNoList(ctx, nil, reviewer, nil, nil)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "QueryPreContractNoFail")
		})
	})
}

func Test_preContractReviewerDaoImpl_UpdateNo_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewerDaoImpl_UpdateNo", t, func() {
		// 准备通用数据
		p := &preContractReviewerDaoImpl{}
		ctx := context001.Background()
		oldNo := "old-contract-no"
		newNo := "new-contract-no"

		mockey.PatchConvey("场景：当数据库更新成功时，应返回nil", func() {
			// 场景描述：
			// GORM的Updates操作成功执行，其返回的DB实例中的Error字段为nil。
			// 构造数据：
			// - 传入一个非nil的*gorm.DB事务对象。
			// 逻辑链路：
			// 1. initDB函数返回传入的事务对象。
			// 2. GORM链式调用 Table -> Where -> Updates。
			// 3. Mock Updates 方法返回一个Error为nil的*gorm.DB。
			// 4. ignoreErr(nil)返回nil。
			// 5. 函数最终返回nil。
			mockTx := &gorm.DB{}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := p.UpdateNo(ctx, mockTx, oldNo, newNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：当数据库更新返回通用错误时，应返回包装后的错误", func() {
			// 场景描述：
			// GORM的Updates操作返回一个通用的数据库错误。
			// 构造数据：
			// - GORM Updates 返回一个自定义的error。
			// 逻辑链路：
			// 1. initDB函数返回传入的事务对象。
			// 2. GORM链式调用，Updates方法返回的DB实例中Error字段为通用错误。
			// 3. ignoreErr函数不处理该错误，将其原样返回。
			// 4. 程序记录错误日志并调用i18nfmt.New生成新的错误。
			// 5. 函数最终返回这个新生成的错误。
			mockTx := &gorm.DB{}
			dbErr := errors.New("some database error")
			i18nErr := errors.New("RecordUpdateNoFail")

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			err := p.UpdateNo(ctx, mockTx, oldNo, newNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RecordUpdateNoFail")
		})

		mockey.PatchConvey("场景：当数据库更新返回记录未找到错误时，应忽略错误并返回nil", func() {
			// 场景描述：
			// GORM的Updates操作返回gorm.ErrRecordNotFound，该错误应被忽略。
			// 构造数据：
			// - GORM Updates 返回 gorm.ErrRecordNotFound。
			// 逻辑链路：
			// 1. initDB函数返回传入的事务对象。
			// 2. GORM链式调用，Updates方法返回的DB实例中Error字段为gorm.ErrRecordNotFound。
			// 3. ignoreErr函数处理该错误，返回nil。
			// 4. 函数最终返回nil。
			mockTx := &gorm.DB{}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := p.UpdateNo(ctx, mockTx, oldNo, newNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：当数据库更新返回RASP错误且环境为非线上时，应忽略错误并返回nil", func() {
			// 场景描述：
			// GORM的Updates操作返回RASP（运行时应用自我保护）错误，在非线上环境中，此错误应被安全地忽略。
			// 构造数据：
			// - GORM Updates 返回包含 "API blocked by RASP" 的error。
			// - env.IsOnline() 返回 false。
			// 逻辑链路：
			// 1. initDB函数返回传入的事务对象。
			// 2. GORM链式调用，Updates方法返回RASP错误。
			// 3. ignoreErr调用ignoreRaspErr，由于env.IsOnline()为false，ignoreRaspErr返回nil。
			// 4. 函数最终返回nil。
			mockTx := &gorm.DB{}
			raspErr := errors.New("API blocked by RASP")

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := p.UpdateNo(ctx, mockTx, oldNo, newNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：当数据库更新返回RASP错误且环境为线上时，应返回包装后的错误", func() {
			// 场景描述：
			// GORM的Updates操作返回RASP错误，在线上环境中，此错误不应被忽略，应作为关键错误处理。
			// 构造数据：
			// - GORM Updates 返回包含 "API blocked by RASP" 的error。
			// - env.IsOnline() 返回 true。
			// 逻辑链路：
			// 1. initDB函数返回传入的事务对象。
			// 2. GORM链式调用，Updates方法返回RASP错误。
			// 3. ignoreErr调用ignoreRaspErr，由于env.IsOnline()为true，ignoreRaspErr返回原始错误。
			// 4. 程序记录错误日志并调用i18nfmt.New生成新的错误。
			// 5. 函数最终返回这个新生成的错误。
			mockTx := &gorm.DB{}
			raspErr := errors.New("API blocked by RASP")
			i18nErr := errors.New("RecordUpdateNoFail")

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			err := p.UpdateNo(ctx, mockTx, oldNo, newNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RecordUpdateNoFail")
		})

		mockey.PatchConvey("场景：当传入的事务对象为nil时，应使用全局DB客户端并成功更新", func() {
			// 场景描述：
			// 调用UpdateNo时传入的tx参数为nil，函数应回退到使用全局的_dbClient。
			// 构造数据：
			// - tx 参数为 nil。
			// 逻辑链路：
			// 1. initDB函数因tx为nil而调用_dbClient.WithContext(ctx)。
			// 2. Mock _dbClient.WithContext 返回一个可用的*gorm.DB实例。
			// 3. 后续GORM链式调用及结果处理与成功场景一致。
			// 4. 函数最终返回nil。
			_dbClient = &gorm.DB{} // 初始化全局变量
			defer func() {
				_dbClient = nil // 测试后清理
			}()
			mockGlobalDB := &gorm.DB{}

			mockey.Mock((*gorm.DB).WithContext).Return(mockGlobalDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockGlobalDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockGlobalDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := p.UpdateNo(ctx, nil, oldNo, newNo)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_preContractReviewerDaoImpl_UpdateByID_BitsUTGen(t *testing.T) {
	// 准备通用测试数据
	dao := &preContractReviewerDaoImpl{}
	ctx := context001.Background()
	testID := uint64(123)
	testUpdates := map[string]interface{}{"status": 1}

	mockey.PatchConvey("Test preContractReviewerDaoImpl.UpdateByID", t, func() {
		// mockDB 用于 GORM 链式调用
		mockDB := &gorm.DB{}

		mockey.PatchConvey("场景1: 成功更新，不使用事务 (tx is nil)", func() {
			// 场景描述：
			// GORM 操作成功，不传入事务对象 tx。
			// 构造数据：
			// tx = nil, id = 123, updates = map[string]interface{}{"status": 1}
			// 逻辑链路：
			// 1. 调用 initDB(ctx, nil)
			// 2. 在 initDB 内部, 调用 _dbClient.WithContext(ctx)，返回 mockDB。
			// 3. 链式调用 Table -> Where -> Updates 在 mockDB 上执行。
			// 4. Updates 方法返回的 gorm.DB 对象的 Error 字段为 nil。
			// 5. ignoreErr(nil) 返回 nil。
			// 6. 函数最终返回 nil。

			// Mock 数据准备
			_dbClient = &gorm.DB{} // 初始化包级变量
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, nil, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景2: 成功更新，使用事务 (tx is not nil)", func() {
			// 场景描述：
			// GORM 操作成功，传入了事务对象 tx。
			// 构造数据：
			// tx = &gorm.DB{}, id = 123, updates = map[string]interface{}{"status": 1}
			// 逻辑链路：
			// 1. 调用 initDB(ctx, tx)，直接返回传入的 tx 对象。
			// 2. 链式调用 Table -> Where -> Updates 在 tx 对象上执行。
			// 3. Updates 方法返回的 gorm.DB 对象的 Error 字段为 nil。
			// 4. ignoreErr(nil) 返回 nil。
			// 5. 函数最终返回 nil。

			// Mock 数据准备
			tx := &gorm.DB{} // 模拟事务对象
			mockey.Mock((*gorm.DB).Table).Return(tx).Build()
			mockey.Mock((*gorm.DB).Where).Return(tx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, tx, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景3: GORM 返回普通错误", func() {
			// 场景描述：
			// GORM 操作返回一个不可忽略的错误。
			// 构造数据：
			// GORM 操作链返回一个通用错误。
			// 逻辑链路：
			// 1. initDB 返回一个 mockDB。
			// 2. Updates 方法返回的 gorm.DB 对象的 Error 字段为一个普通 error。
			// 3. ignoreErr 返回该 error。
			// 4. 调用 logs.CtxError 记录日志。
			// 5. 调用 i18nfmt.New 生成并返回一个新的错误。

			// Mock 数据准备
			_dbClient = &gorm.DB{}
			dbError := errors.New("database connection lost")
			expectedErr := errors.New("UpdateByIDFail")

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbError}).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, nil, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByIDFail")
		})

		mockey.PatchConvey("场景4: GORM 返回 ErrRecordNotFound 错误", func() {
			// 场景描述：
			// GORM 操作返回 gorm.ErrRecordNotFound，该错误应被 ignoreErr 函数忽略。
			// 构造数据：
			// GORM 操作链返回 gorm.ErrRecordNotFound。
			// 逻辑链路：
			// 1. initDB 返回一个 mockDB。
			// 2. Updates 方法返回的 gorm.DB 对象的 Error 字段为 gorm.ErrRecordNotFound。
			// 3. ignoreErr(gorm.ErrRecordNotFound) 调用 ignoreNotFoundErr 返回 nil。
			// 4. 函数最终返回 nil。

			// Mock 数据准备
			_dbClient = &gorm.DB{}
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, nil, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景5: GORM 返回 RASP 错误且环境为非线上", func() {
			// 场景描述：
			// GORM 操作返回 RASP 错误，但由于环境为非线上，该错误被 ignoreErr 函数忽略。
			// 构造数据：
			// GORM 操作链返回一个包含 "API blocked by RASP" 的 error。
			// env.IsOnline 返回 false。
			// 逻辑链路：
			// 1. initDB 返回一个 mockDB。
			// 2. Updates 方法返回的 gorm.DB 对象的 Error 字段为 RASP 错误。
			// 3. ignoreErr 调用 ignoreRaspErr，内部 env.IsOnline() 返回 false。
			// 4. ignoreRaspErr 检查到 RASP 错误和非线上环境，返回 nil。
			// 5. 函数最终返回 nil。

			// Mock 数据准备
			_dbClient = &gorm.DB{}
			raspError := errors.New("API blocked by RASP")
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, nil, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景6: GORM 返回 RASP 错误且环境为线上", func() {
			// 场景描述：
			// GORM 操作返回 RASP 错误，由于环境是线上，该错误不被忽略。
			// 构造数据：
			// GORM 操作链返回一个包含 "API blocked by RASP" 的 error。
			// env.IsOnline 返回 true。
			// 逻辑链路：
			// 1. initDB 返回一个 mockDB。
			// 2. Updates 方法返回的 gorm.DB 对象的 Error 字段为 RASP 错误。
			// 3. ignoreErr 调用 ignoreRaspErr，内部 env.IsOnline() 返回 true。
			// 4. ignoreRaspErr 返回原 error。
			// 5. 调用 logs.CtxError 记录日志。
			// 6. 调用 i18nfmt.New 生成并返回一个新的错误。

			// Mock 数据准备
			_dbClient = &gorm.DB{}
			raspError := errors.New("API blocked by RASP")
			expectedErr := errors.New("UpdateByIDFail")

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			// 调用目标函数
			err := dao.UpdateByID(ctx, nil, testID, testUpdates)

			// 断言结果
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByIDFail")
		})
	})
}

func Test_preContractReviewerDaoImpl_Create_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test preContractReviewerDaoImpl.Create", t, func() {
		// Common setup for all test cases
		dao := &preContractReviewerDaoImpl{}
		ctx := context001.Background()
		reviewerDB := &model.PreContractReviewerDB{PreContractNo: "PC-TEST-001"}
		var tx *gorm.DB // Use nil tx to test the path where a new DB session is created from _dbClient

		mockey.PatchConvey("should return nil when database creation is successful", func() {
			// 场景描述：
			// 数据库Create操作成功。
			// 构造数据：
			// 无特殊构造。
			// 逻辑链路：
			// 1. Mock initDB to return a mock gorm.DB instance.
			// 2. Mock the Table method on the mock DB to return itself.
			// 3. Mock the Create method on the mock DB to return a DB instance with a nil Error field.
			// 4. The function calls ignoreErr(nil), which returns nil.
			// 5. The function successfully returns nil.

			mockDB := &gorm.DB{} // .Error is nil by default
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(mockDB).Build()

			err := dao.Create(ctx, tx, reviewerDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return an error when database creation fails with a generic error", func() {
			// 场景描述：
			// 数据库Create操作失败，返回一个通用的、不可忽略的错误。
			// 构造数据：
			// Mock DB的Create方法返回一个包含通用错误的DB实例。
			// 逻辑链路：
			// 1. Mock initDB, Table, and Create methods.
			// 2. The Create mock returns a DB instance with a non-nil Error.
			// 3. The function calls ignoreErr(err), which returns the original error.
			// 4. The error is logged via logs.CtxError.
			// 5. A new error is created via i18nfmt.New.
			// 6. The function returns the new error.

			dbErr := errors.New("a generic database error")
			mockDB := &gorm.DB{Error: dbErr}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(mockDB).Build()

			err := dao.Create(ctx, tx, reviewerDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createPreReviewerFail")
		})

		mockey.PatchConvey("should return nil when database creation fails with an ignorable RecordNotFound error", func() {
			// 场景描述：
			// 数据库Create操作失败，但返回的是gorm.ErrRecordNotFound，该错误可被忽略。
			// 构造数据：
			// Mock DB的Create方法返回一个Error为gorm.ErrRecordNotFound的DB实例。
			// 逻辑链路：
			// 1. Mock initDB, Table, and Create methods.
			// 2. The Create mock returns a DB instance with Error set to gorm.ErrRecordNotFound.
			// 3. The function calls ignoreErr(gorm.ErrRecordNotFound), which returns nil.
			// 4. The function returns nil.

			mockDB := &gorm.DB{Error: gorm.ErrRecordNotFound}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(mockDB).Build()

			err := dao.Create(ctx, tx, reviewerDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when database creation fails with an ignorable RASP error in a non-online environment", func() {
			// 场景描述：
			// 数据库Create操作失败，返回RASP错误，但由于环境为非线上环境，该错误可被忽略。
			// 构造数据：
			// Mock env.IsOnline返回false.
			// Mock DB的Create方法返回一个包含"API blocked by RASP"的错误。
			// 逻辑链路：
			// 1. Mock env.IsOnline to return false.
			// 2. Mock initDB, Table, and Create methods.
			// 3. The Create mock returns a DB instance with a RASP error.
			// 4. The function calls ignoreErr(raspErr). Inside ignoreErr, ignoreRaspErr is called, which returns nil because env.IsOnline is false.
			// 5. The function returns nil.

			mockey.Mock(env.IsOnline).Return(false).Build()

			raspErr := errors.New("API blocked by RASP")
			mockDB := &gorm.DB{Error: raspErr}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(mockDB).Build()

			err := dao.Create(ctx, tx, reviewerDB)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return an error when database creation fails with a RASP error in an online environment", func() {
			// 场景描述：
			// 数据库Create操作失败，返回RASP错误，且由于环境为线上环境，该错误不可被忽略。
			// 构造数据：
			// Mock env.IsOnline返回true.
			// Mock DB的Create方法返回一个包含"API blocked by RASP"的错误。
			// 逻辑链路：
			// 1. Mock env.IsOnline to return true.
			// 2. Mock initDB, Table, and Create methods.
			// 3. The Create mock returns a DB instance with a RASP error.
			// 4. The function calls ignoreErr(raspErr). Inside ignoreErr, ignoreRaspErr returns the original error because env.IsOnline is true.
			// 5. The error is logged and a new error is returned, similar to the generic error case.

			mockey.Mock(env.IsOnline).Return(true).Build()

			raspErr := errors.New("API blocked by RASP")
			mockDB := &gorm.DB{Error: raspErr}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(mockDB).Build()

			err := dao.Create(ctx, tx, reviewerDB)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "createPreReviewerFail")
		})
	})
}

func TestListHighPriorityReviewerTypeNoPassedReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestListHighPriorityReviewerTypeNoPassedReviewer", t, func() {
		// 准备通用变量
		ctx := context001.Background()
		req := &model.ListPreContractReviewerReq{
			PreContractNo:  "PCN-2023-001",
			ReviewerType:   1,
			ContractStatus: 1,
			Priority:       5,
		}
		mockTx := &gorm.DB{}

		mockey.PatchConvey("success case: database query returns a list of reviewers", func() {
			// 场景描述:
			// 数据库查询成功，并找到了符合条件的审阅人列表。
			// 构造数据:
			// - req: 一个正常的请求参数。
			// - mockTx: 一个gorm.DB的mock实例。
			// - expectedList: 预期的查询结果列表。
			// 逻辑链路:
			// 1. initDB(ctx, tx) 被调用并返回传入的 mockTx。
			// 2. gorm的Table和Where链式调用均被mock，并返回 mockTx。
			// 3. gorm的Find方法被mock，模拟成功查询到数据，将expectedList赋值给Find方法的第一个参数(dest)，并返回一个无错误的gorm.DB实例。
			// 4. ignoreErr(nil) 返回 nil，两个错误检查都通过。
			// 5. 函数最终返回查询到的列表和nil error。

			// 数据准备
			expectedList := model.PreContractReviewerDBList{
				{},
				{},
			}

			// Mock
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = expectedList
				}
				return &gorm.DB{}
			}).Build()

			// 调用
			result, err := ListHighPriorityReviewerTypeNoPassedReviewer(ctx, mockTx, req)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedList)
		})

		mockey.PatchConvey("failure case: database query returns a generic error", func() {
			// 场景描述:
			// 数据库执行Find操作时发生了一个通用错误。
			// 构造数据:
			// - req: 一个正常的请求参数。
			// - mockTx: 一个gorm.DB的mock实例。
			// - dbError: 模拟的数据库错误。
			// 逻辑链路:
			// 1. initDB(ctx, tx) 返回传入的 mockTx。
			// 2. gorm的Table和Where链式调用均返回 mockTx。
			// 3. gorm的Find方法被mock，模拟查询失败，返回一个包含dbError的gorm.DB实例。
			// 4. ignoreErr(dbError) 返回 dbError，因为它不是可忽略的错误。
			// 5. 函数进入第一个错误处理分支，调用i18nfmt.New生成一个特定的错误。
			// 6. 函数最终返回nil列表和i18nfmt生成的错误。

			// 数据准备
			dbError := errors.New("generic db error")
			i18nError := errors.New("ListHighPriorityReviewerTypeNoPassedReviewerFail")

			// Mock
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				return &gorm.DB{Error: dbError}
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build() // 确保ignoreRaspErr不忽略错误
			mockey.Mock(i18nfmt.New).Return(i18nError).Build()

			// 调用
			result, err := ListHighPriorityReviewerTypeNoPassedReviewer(ctx, mockTx, req)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, i18nError.Error())
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case: database returns ErrRecordNotFound", func() {
			// 场景描述:
			// 数据库查询未找到任何记录，返回gorm.ErrRecordNotFound。
			// 构造数据:
			// - req: 一个正常的请求参数。
			// - mockTx: 一个gorm.DB的mock实例。
			// 逻辑链路:
			// 1. initDB(ctx, tx) 返回传入的 mockTx。
			// 2. gorm的Table和Where链式调用均返回 mockTx。
			// 3. gorm的Find方法被mock，模拟未找到记录，返回一个包含gorm.ErrRecordNotFound的gorm.DB实例。
			// 4. ignoreErr(gorm.ErrRecordNotFound) 返回 nil，因为这是一个可忽略的错误。
			// 5. 函数的两个错误检查都通过。
			// 6. 函数最终返回一个空的列表和nil error。

			// Mock
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				return &gorm.DB{Error: gorm.ErrRecordNotFound}
			}).Build()

			// 调用
			result, err := ListHighPriorityReviewerTypeNoPassedReviewer(ctx, mockTx, req)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			// 当没有找到记录时，函数返回一个nil切片，这是一个有效的空切片。检查其长度是否为0是充分且更符合 Go 惯例的。
			convey.So(len(result), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("success case: tx is nil, use global db client", func() {
			// 场景描述:
			// 传入的tx为nil，函数将使用全局的_dbClient进行查询并成功。
			// 构造数据:
			// - req: 一个正常的请求参数。
			// - tx: nil。
			// - _dbClient: 一个gorm.DB的mock实例。
			// - expectedList: 预期的查询结果列表。
			// 逻辑链路:
			// 1. initDB(ctx, nil) 被调用。
			// 2. 由于tx为nil，initDB内部调用 _dbClient.WithContext(ctx)。
			// 3. Mock _dbClient.WithContext(ctx) 返回一个可用的mock DB实例。
			// 4. 后续的Table, Where, Find链式调用与成功案例一致。
			// 5. 函数最终返回查询到的列表和nil error。

			// 数据准备
			_dbClient = &gorm.DB{} // 初始化全局变量以避免空指针
			mockDBFromGlobal := &gorm.DB{}
			expectedList := model.PreContractReviewerDBList{
				{},
			}

			// Mock
			mockey.Mock((*gorm.DB).WithContext).Return(mockDBFromGlobal).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDBFromGlobal).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDBFromGlobal).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = expectedList
				}
				return &gorm.DB{}
			}).Build()

			// 调用
			result, err := ListHighPriorityReviewerTypeNoPassedReviewer(ctx, nil, req)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedList)
		})
	})
}

func TestIsAllNoMasterReviewerTypePassed_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestIsAllNoMasterReviewerTypePassed", t, func() {
		// Mock a gorm.DB instance that will be returned by the mocked functions.
		mockDB := &gorm.DB{}
		ctx := context001.Background()
		preContractNo := "PCN-TEST-123"
		reviewerType := 1
		contractStatus := 1

		mockey.PatchConvey("success: when there are no pending reviewers, should return true", func() {
			// 场景描述: 数据库查询成功，并且没有待处理的审核人。
			// 构造数据: 无特殊构造。
			// 逻辑链路:
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的链式调用 Table 和 Where 方法，均返回 mockDB。
			// 3. mock Count 方法，模拟查询到0条记录，并将 pendingCount 设置为0。
			// 4. 函数最终返回 (true, nil)。

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				*count = 0
				return &gorm.DB{} // Return a new DB instance with no error
			}).Build()

			passed, err := IsAllNoMasterReviewerTypePassed(ctx, nil, preContractNo, reviewerType, contractStatus)

			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("success: when there are pending reviewers, should return false", func() {
			// 场景描述: 数据库查询成功，但存在一个或多个待处理的审核人。
			// 构造数据: 无特殊构造。
			// 逻辑链路:
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的链式调用 Table 和 Where 方法，均返回 mockDB。
			// 3. mock Count 方法，模拟查询到2条记录，并将 pendingCount 设置为2。
			// 4. 函数最终返回 (false, nil)。

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				*count = 2
				return &gorm.DB{} // Return a new DB instance with no error
			}).Build()

			passed, err := IsAllNoMasterReviewerTypePassed(ctx, nil, preContractNo, reviewerType, contractStatus)

			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("failure: when database query returns an error, should return false and the error", func() {
			// 场景描述: 数据库查询过程中发生了一个通用错误。
			// 构造数据: 构造一个 error 对象。
			// 逻辑链路:
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的链式调用 Table 和 Where 方法，均返回 mockDB。
			// 3. mock Count 方法，使其返回一个包含错误的 gorm.DB 实例。
			// 4. mock env.IsOnline 返回 false，以确保 ignoreErr 函数不会忽略此错误。
			// 5. 函数捕获到错误，并返回 (false, error)。

			dbErr := errors.New("database query failed")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			passed, err := IsAllNoMasterReviewerTypePassed(ctx, nil, preContractNo, reviewerType, contractStatus)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database query failed")
			convey.So(passed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("success: when database returns ErrRecordNotFound, should be ignored and return true", func() {
			// 场景描述: 数据库查询返回 gorm.ErrRecordNotFound 错误，此错误应被忽略。
			// 构造数据: 无特殊构造。
			// 逻辑链路:
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的链式调用 Table 和 Where 方法，均返回 mockDB。
			// 3. mock Count 方法，使其返回一个 gorm.ErrRecordNotFound 错误。
			// 4. ignoreErr 函数会忽略此错误。
			// 5. 函数继续执行，pendingCount 仍为0，最终返回 (true, nil)。

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			passed, err := IsAllNoMasterReviewerTypePassed(ctx, nil, preContractNo, reviewerType, contractStatus)

			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})
	})
}

func TestCreatePreContractReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestCreatePreContractReviewer", t, func() {
		// 构造通用测试数据
		ctx := context001.Background()
		// 由于tx在initDB中被处理，这里可以传入nil
		var mockTx *gorm.DB
		preContractReviewerDB := &model.PreContractReviewerDB{
			PreContractNo: "TEST_PCN_001",
			Reviewer:      "test_user",
		}
		mockDB := &gorm.DB{}

		mockey.PatchConvey("场景：成功创建预合同审批人记录", func() {
			// 场景描述：
			// 构造数据：构造一个有效的 PreContractReviewerDB 对象。
			// 逻辑链路：
			// 1. Mock dal.initDB 函数返回一个 gorm.DB 实例。
			// 2. Mock gorm.DB 的 Table 方法返回同一个 gorm.DB 实例。
			// 3. Mock gorm.DB 的 Create 方法返回一个 Error 字段为 nil 的 gorm.DB 实例，模拟数据库创建成功。
			// 4. 调用 CreatePreContractReviewer 函数。
			// 5. dal.ignoreErr 函数接收到 nil 错误，直接返回 nil。
			// 6. 断言最终返回的 error 为 nil。

			// Arrange
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				convey.So(value, convey.ShouldEqual, preContractReviewerDB)
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			err := CreatePreContractReviewer(ctx, mockTx, preContractReviewerDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：数据库Create操作返回通用错误", func() {
			// 场景描述：
			// 构造数据：构造一个通用 error 对象。
			// 逻辑链路：
			// 1. Mock dal.initDB 函数返回一个 gorm.DB 实例。
			// 2. Mock gorm.DB 的 Table 方法返回同一个 gorm.DB 实例。
			// 3. Mock gorm.DB 的 Create 方法返回一个 Error 字段为通用错误的 gorm.DB 实例。
			// 4. 调用 CreatePreContractReviewer 函数。
			// 5. dal.ignoreErr 函数接收到该通用错误，由于不满足任何忽略条件，直接返回该错误。
			// 6. 断言最终返回的 error 不为 nil，且内容与预设错误一致。

			// Arrange
			dbErr := errors.New("database create error")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
			// 确保不进入 RASP 错误忽略逻辑
			mockey.Mock(env.IsOnline).Return(true).Build()

			// Act
			err := CreatePreContractReviewer(ctx, mockTx, preContractReviewerDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database create error")
		})

		mockey.PatchConvey("场景：数据库Create操作返回gorm.ErrRecordNotFound错误", func() {
			// 场景描述：
			// 构造数据：无特殊数据。
			// 逻辑链路：
			// 1. Mock dal.initDB, gorm.DB.Table 行为。
			// 2. Mock gorm.DB 的 Create 方法返回一个 Error 字段为 gorm.ErrRecordNotFound 的 gorm.DB 实例。
			// 3. 调用 CreatePreContractReviewer 函数。
			// 4. dal.ignoreErr 函数接收到 gorm.ErrRecordNotFound 错误，根据其内部逻辑，该错误被忽略，返回 nil。
			// 5. 断言最终返回的 error 为 nil。

			// Arrange
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			err := CreatePreContractReviewer(ctx, mockTx, preContractReviewerDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：非线上环境数据库Create操作返回RASP错误", func() {
			// 场景描述：
			// 构造数据：构造一个包含 "API blocked by RASP" 的 error 对象。
			// 逻辑链路：
			// 1. Mock dal.initDB, gorm.DB.Table 行为。
			// 2. Mock env.IsOnline 返回 false，模拟非线上环境。
			// 3. Mock gorm.DB 的 Create 方法返回一个 RASP 错误。
			// 4. 调用 CreatePreContractReviewer 函数。
			// 5. dal.ignoreErr 函数接收到 RASP 错误，根据其内部逻辑，在非线上环境该错误被忽略，返回 nil。
			// 6. 断言最终返回的 error 为 nil。

			// Arrange
			raspErr := errors.New("some internal error: API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			// Act
			err := CreatePreContractReviewer(ctx, mockTx, preContractReviewerDB)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：线上环境数据库Create操作返回RASP错误", func() {
			// 场景描述：
			// 构造数据：构造一个包含 "API blocked by RASP" 的 error 对象。
			// 逻辑链路：
			// 1. Mock dal.initDB, gorm.DB.Table 行为。
			// 2. Mock env.IsOnline 返回 true，模拟线上环境。
			// 3. Mock gorm.DB 的 Create 方法返回一个 RASP 错误。
			// 4. 调用 CreatePreContractReviewer 函数。
			// 5. dal.ignoreErr 函数接收到 RASP 错误，根据其内部逻辑，在线上环境该错误不被忽略，直接返回。
			// 6. 断言最终返回的 error 不为 nil，且包含 RASP 错误信息。

			// Arrange
			raspErr := errors.New("some internal error: API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()

			// Act
			err := CreatePreContractReviewer(ctx, mockTx, preContractReviewerDB)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
		})
	})
}

func Test_preContractReviewerDaoImpl_HaveViewPerm_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewerDaoImpl_HaveViewPerm", t, func() {
		// 准备通用变量
		ctx := context001.Background()
		preContractNo := "PCN-2023-001"
		reviewer := "zhangsan"
		dao := &preContractReviewerDaoImpl{}
		mockDB := &gorm.DB{}

		mockey.PatchConvey("Success: should return true and nil error when reviewer has permission", func() {
			// 场景描述：
			// 数据库查询成功，并找到了匹配的审阅人记录。
			// 构造数据：
			// - 无特定构造，依赖Mock返回。
			// 逻辑链路：
			// 1. 调用 HaveViewPerm, tx 为 nil, 因此 initDB 将使用全局 _dbClient。
			// 2. Mock gorm 的方法链 (*gorm.DB).WithContext -> Table -> Where -> Where，都返回 mockDB。
			// 3. Mock (*gorm.DB).Find 方法，模拟找到了数据，向传入的 list 中填充一个元素，并返回一个无错误的 gorm.DB 实例。
			// 4. 函数内部判断 list 长度大于 0，因此最终返回 true 和 nil。
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = model.PreContractReviewerDBList{&model.PreContractReviewerDB{}}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("Success: should return false and nil error when reviewer does not have permission", func() {
			// 场景描述：
			// 数据库查询成功，但未找到匹配的审阅人记录。
			// 构造数据：
			// - 无特定构造，依赖Mock返回。
			// 逻辑链路：
			// 1. 调用 HaveViewPerm, tx 为 nil。
			// 2. Mock gorm 的方法链，与成功场景类似。
			// 3. Mock (*gorm.DB).Find 方法，模拟未找到数据，保持传入的 list 为空，并返回一个无错误的 gorm.DB 实例。
			// 4. 函数内部判断 list 长度等于 0，因此最终返回 false 和 nil。
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = model.PreContractReviewerDBList{}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Success: should return false and nil error when db returns ErrRecordNotFound", func() {
			// 场景描述：
			// 数据库查询返回 gorm.ErrRecordNotFound 错误，该错误应被忽略。
			// 构造数据：
			// - 无特定构造，依赖Mock返回。
			// 逻辑链路：
			// 1. 调用 HaveViewPerm, tx 为 nil。
			// 2. Mock gorm 的方法链。
			// 3. Mock (*gorm.DB).Find 方法，返回一个带有 gorm.ErrRecordNotFound 错误的 gorm.DB 实例。
			// 4. 函数内部的 ignoreErr 函数会判断并忽略此错误，返回 nil。
			// 5. 最终函数返回 false 和 nil。
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Failure: should return false and an error when a generic db error occurs", func() {
			// 场景描述：
			// 数据库查询返回一个通用的、不可忽略的错误。
			// 构造数据：
			// - 构造一个 genericError。
			// 逻辑链路：
			// 1. 调用 HaveViewPerm, tx 为 nil。
			// 2. Mock gorm 的方法链。
			// 3. Mock (*gorm.DB).Find 方法，返回一个带有 genericError 的 gorm.DB 实例。
			// 4. 函数内部的 ignoreErr 函数不会忽略此错误。
			// 5. 函数会调用 logs.CtxError 记录日志，并调用 i18nfmt.New 返回一个新错误。
			// 6. 最终函数返回 false 和这个新创建的错误。
			dbErr := errors.New("unexpected database error")
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("HaveViewPermFail")).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "HaveViewPermFail")
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Success: should return false and nil error for RASP error in non-online env", func() {
			// 场景描述：
			// 在非线上环境，数据库返回一个 RASP 错误，该错误应被忽略。
			// 构造数据：
			// - 构造一个 RASP error。
			// 逻辑链路：
			// 1. Mock env.IsOnline() 返回 false。
			// 2. 调用 HaveViewPerm。
			// 3. Mock (*gorm.DB).Find 方法返回 RASP 错误。
			// 4. 函数内部的 ignoreRaspErr 会判断环境并忽略此错误。
			// 5. 最终函数返回 false 和 nil。
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build() // For ignoreRaspErr logging

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Failure: should return false and an error for RASP error in online env", func() {
			// 场景描述：
			// 在线上环境，数据库返回一个 RASP 错误，该错误不应被忽略。
			// 构造数据：
			// - 构造一个 RASP error。
			// 逻辑链路：
			// 1. Mock env.IsOnline() 返回 true。
			// 2. 调用 HaveViewPerm。
			// 3. Mock (*gorm.DB).Find 方法返回 RASP 错误。
			// 4. 函数内部的 ignoreRaspErr 判断环境后，不会忽略此错误。
			// 5. 函数进入错误处理分支，记录日志并返回新错误。
			// 6. 最终函数返回 false 和一个包装后的错误。
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.New).Return(errors.New("HaveViewPermFail")).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, nil, preContractNo, reviewer)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "HaveViewPermFail")
			convey.So(hasPerm, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("Success: should use provided tx when it is not nil", func() {
			// 场景描述：
			// 调用函数时传入一个非空的 gorm.DB 事务对象 (tx)，函数应使用此 tx 而不是全局的 _dbClient。
			// 构造数据：
			// - 构造一个 mockTx 作为事务对象。
			// 逻辑链路：
			// 1. 调用 HaveViewPerm, 传入 mockTx。
			// 2. 函数内部 initDB 会直接返回 mockTx。
			// 3. Mock gorm 的方法链 Table -> Where -> Where，注意这次不需要 Mock WithContext。
			// 4. Mock (*gorm.DB).Find 方法，模拟查询成功并返回数据。
			// 5. 最终函数返回 true 和 nil，验证了 tx != nil 的分支。
			mockTx := &gorm.DB{}
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = model.PreContractReviewerDBList{&model.PreContractReviewerDB{}}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			hasPerm, err := dao.HaveViewPerm(ctx, mockTx, preContractNo, reviewer)

			convey.So(err, convey.ShouldBeNil)
			convey.So(hasPerm, convey.ShouldBeTrue)
		})
	})
}

func Test_preContractReviewerDaoImpl_FindReviewersByNoAndEmail_BitsUTGen(t *testing.T) {
	p := &preContractReviewerDaoImpl{}

	mockey.PatchConvey("Test FindReviewersByNoAndEmail", t, func() {
		ctx := context001.Background()
		mockDB := &gorm.DB{}

		// Initialize the global DB client for mocking paths where tx is nil
		_dbClient = &gorm.DB{}

		mockey.PatchConvey("when transaction (tx) is not provided (is nil)", func() {
			convey.Convey("Success case: should find reviewers and return them", func() {
				// 场景描述:
				// 调用时不传入事务(tx=nil)，函数通过全局_dbClient成功查询到数据。
				// 构造数据:
				// preContractNo = "PCN-001", reviewer = "test@example.com".
				// 逻辑链路:
				// 1. tx为nil, initDB将调用_dbClient.WithContext，mock该调用以返回一个gorm.DB实例。
				// 2. GORM的Table和Where方法被mock以支持链式调用。
				// 3. GORM的Find方法被mock，模拟查询成功，并将结果填充到目标变量中。
				// 4. ignoreErr接收到nil错误，直接返回nil。
				// 5. 函数返回查询到的数据列表和nil错误。

				preContractNo := "PCN-001"
				reviewer := "test@example.com"
				expectedResult := model.PreContractReviewerDBList{
					{PreContractNo: preContractNo, Reviewer: reviewer},
				}

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
					if list, ok := dest.(*model.PreContractReviewerDBList); ok {
						*list = expectedResult
					}
					return &gorm.DB{Error: nil}
				}).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, nil, preContractNo, reviewer)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldResemble, expectedResult)
			})

			convey.Convey("Failure case: should return error when database Find fails", func() {
				// 场景描述:
				// 调用时不传入事务(tx=nil)，查询时数据库返回一个通用错误。
				// 构造数据:
				// preContractNo = "PCN-002", reviewer = "error@example.com".
				// 逻辑链路:
				// 1. tx为nil, _dbClient.WithContext和GORM链式调用被mock。
				// 2. GORM的Find方法被mock，返回一个指定的通用错误。
				// 3. ignoreErr接收到该错误，由于不是特定可忽略的错误，原样返回。
				// 4. 函数返回nil和该数据库错误。

				preContractNo := "PCN-002"
				reviewer := "error@example.com"
				dbErr := errors.New("database connection failed")

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, nil, preContractNo, reviewer)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "database connection failed")
				convey.So(result, convey.ShouldBeNil)
			})

			convey.Convey("Special case: should return nil when record not found", func() {
				// 场景描述:
				// 调用时不传入事务(tx=nil)，查询时数据库返回 "record not found" 错误。
				// 构造数据:
				// preContractNo = "PCN-003", reviewer = "notfound@example.com".
				// 逻辑链路:
				// 1. tx为nil, _dbClient.WithContext和GORM链式调用被mock。
				// 2. GORM的Find方法被mock，返回gorm.ErrRecordNotFound。
				// 3. ignoreErr接收到该错误，将其识别为可忽略错误，并返回nil。
				// 4. 函数返回nil结果和nil错误，表示未找到记录不属于程序失败。

				preContractNo := "PCN-003"
				reviewer := "notfound@example.com"

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, nil, preContractNo, reviewer)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldBeNil)
			})

			convey.Convey("Special case: should ignore RASP error in non-online environment", func() {
				// 场景描述:
				// 在非线上环境，调用时不传入事务(tx=nil)，数据库返回一个RASP错误。
				// 构造数据:
				// preContractNo = "PCN-004", reviewer = "rasp@example.com".
				// 逻辑链路:
				// 1. tx为nil, _dbClient.WithContext和GORM链式调用被mock。
				// 2. GORM的Find方法被mock，返回一个包含"API blocked by RASP"的错误。
				// 3. env.IsOnline被mock返回false。
				// 4. ignoreErr接收到RASP错误，由于是非线上环境，该错误被忽略，返回nil。
				// 5. 函数最终返回(nil, nil)。

				preContractNo := "PCN-004"
				reviewer := "rasp@example.com"
				raspErr := errors.New("API blocked by RASP")

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: raspErr}).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, nil, preContractNo, reviewer)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldBeNil)
			})

			convey.Convey("Special case: should not ignore RASP error in online environment", func() {
				// 场景描述:
				// 在线上环境，调用时不传入事务(tx=nil)，数据库返回一个RASP错误。
				// 构造数据:
				// preContractNo = "PCN-005", reviewer = "rasp-online@example.com".
				// 逻辑链路:
				// 1. tx为nil, _dbClient.WithContext和GORM链式调用被mock。
				// 2. GORM的Find方法被mock，返回一个包含"API blocked by RASP"的错误。
				// 3. env.IsOnline被mock返回true。
				// 4. ignoreErr接收到RASP错误，因为是线上环境，该错误不被忽略，原样返回。
				// 5. 函数最终返回(nil, RASP错误)。

				preContractNo := "PCN-005"
				reviewer := "rasp-online@example.com"
				raspErr := errors.New("API blocked by RASP")

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: raspErr}).Build()
				mockey.Mock(env.IsOnline).Return(true).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, nil, preContractNo, reviewer)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
				convey.So(result, convey.ShouldBeNil)
			})
		})

		mockey.PatchConvey("when transaction (tx) is provided", func() {
			convey.Convey("Success case: should use the provided transaction and find reviewers", func() {
				// 场景描述:
				// 调用时传入一个有效的数据库事务对象(tx)，并成功查询到数据。
				// 构造数据:
				// preContractNo = "PCN-006", reviewer = "tx@example.com". 传入一个非nil的*gorm.DB作为tx。
				// 逻辑链路:
				// 1. tx不为nil, initDB直接返回该tx对象，不调用_dbClient.WithContext。
				// 2. GORM的Table和Where方法在传入的tx上被调用，mock它们以支持链式调用。
				// 3. GORM的Find方法被mock，模拟查询成功，并填充结果。
				// 4. 函数返回填充后的数据列表和nil错误。

				preContractNo := "PCN-006"
				reviewer := "tx@example.com"
				tx := &gorm.DB{} // The non-nil transaction object
				expectedResult := model.PreContractReviewerDBList{
					{PreContractNo: preContractNo, Reviewer: reviewer},
				}

				mockey.Mock((*gorm.DB).Table).Return(tx).Build()
				mockey.Mock((*gorm.DB).Where).Return(tx).Build()
				mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
					if list, ok := dest.(*model.PreContractReviewerDBList); ok {
						*list = expectedResult
					}
					return &gorm.DB{Error: nil}
				}).Build()

				result, err := p.FindReviewersByNoAndEmail(ctx, tx, preContractNo, reviewer)

				convey.So(err, convey.ShouldBeNil)
				convey.So(result, convey.ShouldResemble, expectedResult)
			})
		})
	})
}

func Test_preContractReviewerDaoImpl_BatchDeleteReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewerDaoImpl_BatchDeleteReviewer", t, func() {
		// common variables for tests
		ctx := context001.Background()
		p := &preContractReviewerDaoImpl{}
		preContractNo := "PCN12345"
		ids := []uint64{1, 2, 3}

		mockey.PatchConvey("when transaction is nil", func() {
			mockey.PatchConvey("should return nil when db operation is successful", func() {
				// 场景描述：
				// 测试当数据库删除操作成功时的场景。
				// 构造数据：
				// - tx为nil
				// 逻辑链路：
				// 1. initDB被mock，返回一个无错误的gorm.DB实例。
				// 2. 链式调用Table, Where, Delete都成功，返回的*gorm.DB的Error字段为nil。
				// 3. ignoreErr(nil)返回nil。
				// 4. 函数最终返回nil。
				mockDB := &gorm.DB{}
				mockey.Mock(initDB).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockDB).Build()

				err := p.BatchDeleteReviewer(ctx, nil, preContractNo, ids)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should return error when db operation fails with a generic error", func() {
				// 场景描述：
				// 测试当数据库删除操作返回一个通用错误时的场景。
				// 构造数据：
				// - tx为nil
				// 逻辑链路：
				// 1. initDB被mock，返回一个带有错误的gorm.DB实例。
				// 2. 链式调用返回的*gorm.DB的Error字段为一个通用错误。
				// 3. ignoreErr(err)返回原始错误。
				// 4. logs.CtxError被调用。
				// 5. i18nfmt.New被调用并返回一个包装后的错误。
				// 6. 函数最终返回该包装后的错误。
				dbErr := errors.New("some db error")
				expectedErr := errors.New("BatchReplaceReviewer error")
				mockDB := &gorm.DB{Error: dbErr}

				mockey.Mock(initDB).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockDB).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
				mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

				err := p.BatchDeleteReviewer(ctx, nil, preContractNo, ids)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			})

			mockey.PatchConvey("should return nil when db returns ErrRecordNotFound", func() {
				// 场景描述：
				// 测试当数据库删除操作返回gorm.ErrRecordNotFound错误时的场景，该错误应该被忽略。
				// 构造数据：
				// - tx为nil
				// 逻辑链路：
				// 1. initDB被mock，返回一个gorm.DB实例。
				// 2. 链式调用返回的*gorm.DB的Error字段为gorm.ErrRecordNotFound。
				// 3. ignoreErr(gorm.ErrRecordNotFound)返回nil。
				// 4. 函数最终返回nil。
				mockDB := &gorm.DB{Error: gorm.ErrRecordNotFound}
				mockey.Mock(initDB).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockDB).Build()

				err := p.BatchDeleteReviewer(ctx, nil, preContractNo, ids)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should return nil when RASP error occurs in non-online env", func() {
				// 场景描述：
				// 测试在非线上环境，数据库操作返回RASP错误时的场景，该错误应该被忽略。
				// 构造数据：
				// - tx为nil
				// 逻辑链路：
				// 1. env.IsOnline被mock，返回false。
				// 2. initDB被mock，返回一个gorm.DB实例。
				// 3. 链式调用返回的*gorm.DB的Error字段为一个RASP错误。
				// 4. ignoreErr(raspErr)调用ignoreRaspErr，因环境为非线上，返回nil。
				// 5. 函数最终返回nil。
				raspErr := errors.New("something API blocked by RASP something")
				mockDB := &gorm.DB{Error: raspErr}
				mockey.Mock(env.IsOnline).Return(false).Build()
				mockey.Mock(initDB).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockDB).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()

				err := p.BatchDeleteReviewer(ctx, nil, preContractNo, ids)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should return error when RASP error occurs in online env", func() {
				// 场景描述：
				// 测试在线上环境，数据库操作返回RASP错误时的场景，该错误不应被忽略。
				// 构造数据：
				// - tx为nil
				// 逻辑链路：
				// 1. env.IsOnline被mock，返回true。
				// 2. initDB被mock，返回一个gorm.DB实例。
				// 3. 链式调用返回的*gorm.DB的Error字段为一个RASP错误。
				// 4. ignoreErr(raspErr)调用ignoreRaspErr，因环境为线上，返回原始RASP错误。
				// 5. logs.CtxError被调用。
				// 6. i18nfmt.New被调用并返回一个包装后的错误。
				// 7. 函数最终返回该包装后的错误。
				raspErr := errors.New("something API blocked by RASP something")
				expectedErr := errors.New("BatchReplaceReviewer error")
				mockDB := &gorm.DB{Error: raspErr}
				mockey.Mock(env.IsOnline).Return(true).Build()
				mockey.Mock(initDB).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockDB).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
				mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

				err := p.BatchDeleteReviewer(ctx, nil, preContractNo, ids)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			})
		})

		mockey.PatchConvey("when transaction is provided", func() {
			mockey.PatchConvey("should use the provided transaction and succeed", func() {
				// 场景描述：
				// 测试当传入一个有效的gorm事务对象(tx)时，函数能够正确使用该事务并成功执行。
				// 构造数据：
				// - tx为一个无错误的*gorm.DB mock对象。
				// 逻辑链路：
				// 1. initDB(ctx, tx)直接返回传入的tx。
				// 2. 链式调用Table, Where, Delete都在tx上执行，并成功返回。
				// 3. 函数最终返回nil。
				mockTx := &gorm.DB{}
				mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockTx).Build()

				err := p.BatchDeleteReviewer(ctx, mockTx, preContractNo, ids)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("should use the provided transaction and fail", func() {
				// 场景描述：
				// 测试当传入一个gorm事务对象(tx)时，如果数据库操作失败，函数能够正确处理错误。
				// 构造数据：
				// - tx为一个带有错误的*gorm.DB mock对象。
				// 逻辑链路：
				// 1. initDB(ctx, tx)直接返回传入的tx。
				// 2. 链式调用在tx上执行，并返回一个带有错误的*gorm.DB。
				// 3. ignoreErr(err)返回原始错误。
				// 4. logs.CtxError和i18nfmt.New被调用。
				// 5. 函数最终返回包装后的错误。
				dbErr := errors.New("transaction failed")
				expectedErr := errors.New("BatchReplaceReviewer error")
				mockTx := &gorm.DB{Error: dbErr}
				mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Delete).Return(mockTx).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
				mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

				err := p.BatchDeleteReviewer(ctx, mockTx, preContractNo, ids)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
			})
		})
	})
}

func Test_FindSoftDeleteReviewersByNoList(t *testing.T) {
	ctx := context.Background()
	preContractNoList := []string{"123", "456"}
	service := &preContractReviewerDaoImpl{}

	mockey.PatchConvey("Test empty preContractNoList", t, func() {
		tx := &gorm.DB{} // Mock this as needed
		_, err := service.FindSoftDeleteReviewersByNoList(ctx, tx, []string{})
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Find")).Return(tx).Build()
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test initDB returns error", t, func() {
		tx := &gorm.DB{Error: fmt.Errorf("initDB failed")}
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Find")).Return(tx).Build()
		_, err := service.FindSoftDeleteReviewersByNoList(ctx, tx, preContractNoList)
		convey.So(err, convey.ShouldNotBeNil)
	})

	mockey.PatchConvey("Test db.Find returns error", t, func() {
		tx := &gorm.DB{} // Mock this as needed
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Find")).Return(&gorm.DB{Error: fmt.Errorf("db.Find failed")}).Build()
		_, err := (&preContractReviewerDaoImpl{}).FindSoftDeleteReviewersByNoList(ctx, tx, preContractNoList)
		convey.So(err, convey.ShouldNotBeNil)
	})

	mockey.PatchConvey("Test db.Find success", t, func() {
		expectedList := model.PreContractReviewerDBList{
			&model.PreContractReviewerDB{PreContractNo: "123", Reviewer: "reviewer1"},
			&model.PreContractReviewerDB{PreContractNo: "123", Reviewer: "reviewer2"},
			&model.PreContractReviewerDB{PreContractNo: "456", Reviewer: "reviewer3"},
		}
		tx := &gorm.DB{} // Mock this as needed
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Find")).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
			type ExampleModel struct{}
			switch dest.(type) {
			case *ExampleModel: // Here replace with your model type, like Task{}
				*(dest.(*ExampleModel)) = ExampleModel{}
			case *model.PreContractReviewerDBList:
				*(dest.(*model.PreContractReviewerDBList)) = expectedList
			}
			return &gorm.DB{}
		}).Build()
		mockey.Mock(ignoreErr).Return(nil).Build()
		actual, err := service.FindSoftDeleteReviewersByNoList(ctx, tx, preContractNoList)
		convey.So(err, convey.ShouldBeNil)
		for k, v := range actual {
			convey.So(k, convey.ShouldBeIn, []string{"123", "456"})
			if k == "123" {
				for _, vv := range v {
					convey.So(vv.Reviewer, convey.ShouldBeIn, []string{"reviewer1", "reviewer2"})
				}
			} else if k == "456" {
				for _, vv := range v {
					convey.So(vv.Reviewer, convey.ShouldBeIn, []string{"reviewer3"})
				}
			}
		}
	})
}

func Test_IsSoftDeleteReviewerByNoAndEmail(t *testing.T) {
	ctx := context.Background()
	service := &preContractReviewerDaoImpl{}
	preContractNo, reviewer := "123", "test@example.com"
	mockey.PatchConvey("Test db.Count returns error", t, func() {
		mockDB := &gorm.DB{}
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Count")).Return(&gorm.DB{Error: fmt.Errorf("count error")}).Build()
		actual, err := service.IsSoftDeleteReviewerByNoAndEmail(ctx, mockDB, preContractNo, reviewer)
		convey.So(actual, convey.ShouldBeFalse)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test count is zero", t, func() {
		mockDB := &gorm.DB{}
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Count")).Return(mockDB).Build()
		actual, err := service.IsSoftDeleteReviewerByNoAndEmail(ctx, mockDB, preContractNo, reviewer)
		convey.So(actual, convey.ShouldBeFalse)
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test count is greater than zero", t, func() {
		mockDB := &gorm.DB{}
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(initDB).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Table")).Return(mockDB).Build()
		mockey.Mock(mockey.GetMethod(mockDB, "Where")).Return(mockDB).Build()
		mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
			*count = 1
			return &gorm.DB{} // Add your code
		}).Build()
		actual, err := service.IsSoftDeleteReviewerByNoAndEmail(ctx, mockDB, preContractNo, reviewer)
		convey.So(actual, convey.ShouldBeTrue)
		convey.So(err, convey.ShouldBeNil)
	})
}

func Test_FindReviewersByNoList(t *testing.T) {
	ctx := context.Background()
	preContractNoList := []string{"PCT20240001", "PCT20240002"}
	dao := NewPreContractReviewerDao()

	mockey.PatchConvey("TestFindReviewersByNoList", t, func() {
		tx := &gorm.DB{}
		mockey.Mock(initDB).Return(tx).Build()

		t.Run("空预合同编号列表", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				result, err := dao.FindReviewersByNoList(ctx, tx, []string{})
				convey.Convey("应返回空结果", func() {
					convey.So(result, convey.ShouldBeNil)
					convey.So(err, convey.ShouldBeNil)
				})
			})
		})

		t.Run("数据库初始化失败", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				tx1 := &gorm.DB{Error: fmt.Errorf("initDBFail")}
				mockey.Mock(initDB).Return(tx1).Build()
				mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx1).Build()
				mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx1).Build()
				mockey.Mock(mockey.GetMethod(tx, "Find")).Return(tx1).Build()
				result, err := dao.FindReviewersByNoList(ctx, tx1, preContractNoList)
				convey.Convey("应返回数据库错误", func() {
					convey.So(result, convey.ShouldBeNil)
					convey.So(err, convey.ShouldNotBeNil)
				})
			})
		})

		t.Run("数据库查询错误", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
				mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
				mockey.Mock(mockey.GetMethod(tx, "Find")).Return(&gorm.DB{Error: fmt.Errorf("query error")}).Build()
				result, err := dao.FindReviewersByNoList(ctx, tx, preContractNoList)
				convey.Convey("应返回查询错误", func() {
					convey.So(result, convey.ShouldBeNil)
					convey.So(err.Error(), convey.ShouldContainSubstring, "FindReviewersByNoListFail")
				})
			})
		})

		t.Run("正常查询流程", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				mockData := model.PreContractReviewerDBList{
					{PreContractNo: "PCT20240001", Reviewer: "user1"},
					{PreContractNo: "PCT20240002", Reviewer: "user2"},
				}
				mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
				mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
				mockey.Mock(mockey.GetMethod(tx, "Find")).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
					type ExampleModel struct{}
					switch dest.(type) {
					case *ExampleModel: // Here replace with your model type, like Task{}
						*(dest.(*ExampleModel)) = ExampleModel{}
					case *model.PreContractReviewerDBList:
						*(dest.(*model.PreContractReviewerDBList)) = mockData
					}
					return &gorm.DB{}
				}).Build()

				result, err := dao.FindReviewersByNoList(ctx, tx, preContractNoList)
				convey.Convey("应返回分组数据", func() {
					convey.So(err, convey.ShouldBeNil)
					convey.So(result, convey.ShouldHaveLength, 2)
					convey.So(result["PCT20240001"], convey.ShouldHaveLength, 1)
					convey.So(result["PCT20240002"][0].Reviewer, convey.ShouldEqual, "user2")
				})
			})
		})
	})
}

func Test_preContractReviewerDaoImpl_DeleteChangedReviewer_BitsUTGen(t *testing.T) {
	dao := &preContractReviewerDaoImpl{}

	mockey.PatchConvey("Test_preContractReviewerDaoImpl_DeleteChangedReviewer", t, func() {
		mockey.PatchConvey("should return nil when reviewer is empty", func() {
			// 场景描述：
			// reviewer参数为空字符串。
			// 构造数据：
			// reviewer = ""
			// preContractNo = "PC-123"
			// 逻辑链路：
			// 1. 函数被调用，reviewer为空。
			// 2. 函数入口的if len(reviewer) == 0为true。
			// 3. 函数直接返回nil。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := ""
			preContractNo := "PC-123"

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when preContractNo is empty", func() {
			// 场景描述：
			// preContractNo参数为空字符串。
			// 构造数据：
			// reviewer = "test.user"
			// preContractNo = ""
			// 逻辑链路：
			// 1. 函数被调用，preContractNo为空。
			// 2. 函数入口的if len(preContractNo) == 0为true。
			// 3. 函数直接返回nil。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := "test.user"
			preContractNo := ""

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil on successful deletion", func() {
			// 场景描述：
			// GORM的删除操作成功执行，没有返回错误。
			// 构造数据：
			// reviewer和preContractNo均不为空。
			// 逻辑链路：
			// 1. 函数被调用，参数有效。
			// 2. Mock initDB返回一个*gorm.DB实例。
			// 3. Mock GORM的Table, Where, Delete方法链式调用。
			// 4. Mock Delete方法返回的*gorm.DB实例的Error字段为nil。
			// 5. ignoreErr(nil)返回nil。
			// 6. 函数最终返回nil。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := "test.user"
			preContractNo := "PC-123"

			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: nil}).Build()

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when record not found", func() {
			// 场景描述：
			// GORM的删除操作返回gorm.ErrRecordNotFound错误。
			// 构造数据：
			// reviewer和preContractNo均不为空。
			// 逻辑链路：
			// 1. 函数被调用，参数有效。
			// 2. Mock initDB和GORM方法链。
			// 3. Mock Delete方法返回的*gorm.DB实例的Error字段为gorm.ErrRecordNotFound。
			// 4. ignoreErr(gorm.ErrRecordNotFound)会忽略此错误并返回nil。
			// 5. 函数最终返回nil。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := "test.user"
			preContractNo := "PC-123"

			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return error on database failure", func() {
			// 场景描述：
			// GORM的删除操作返回一个通用的数据库错误。
			// 构造数据：
			// reviewer和preContractNo均不为空。
			// 逻辑链路：
			// 1. 函数被调用，参数有效。
			// 2. Mock initDB和GORM方法链。
			// 3. Mock Delete方法返回的*gorm.DB实例的Error字段为一个通用error。
			// 4. ignoreErr(error)返回该error。
			// 5. logs.CtxError被调用记录日志。
			// 6. i18nfmt.New被调用以生成国际化错误信息。
			// 7. 函数最终返回i18nfmt.New生成的错误。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := "test.user"
			preContractNo := "PC-123"
			dbErr := errors.New("database connection failed")
			expectedErr := errors.New("DeleteChangedReviewerFail")

			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteChangedReviewerFail")
		})

		mockey.PatchConvey("should return nil on RASP error in non-online env", func() {
			// 场景描述：
			// GORM删除操作返回一个RASP错误，并且环境为非线上环境。
			// 构造数据：
			// reviewer和preContractNo均不为空。
			// 逻辑链路：
			// 1. 函数被调用，参数有效。
			// 2. Mock env.IsOnline返回false。
			// 3. Mock initDB和GORM方法链。
			// 4. Mock Delete方法返回的*gorm.DB实例的Error字段为一个包含"API blocked by RASP"的error。
			// 5. ignoreErr(raspErr)调用ignoreRaspErr，该函数会忽略此错误并返回nil。
			// 6. 函数最终返回nil。
			ctx := context001.Background()
			var tx *gorm.DB
			reviewer := "test.user"
			preContractNo := "PC-123"
			raspErr := errors.New("API blocked by RASP")

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()

			err := dao.DeleteChangedReviewer(ctx, tx, reviewer, preContractNo)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_preContractReviewerDaoImpl_BatchReplaceReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewerDaoImpl_BatchReplaceReviewer", t, func() {
		// Common test data
		p := &preContractReviewerDaoImpl{}
		ctx := context001.Background()
		newEmail := "new.reviewer@example.com"
		newID := "new_id_123"
		preContractNo := "PC-2024-001"
		ids := []uint64{1, 2, 3}
		mockDB := &gorm.DB{}

		mockey.PatchConvey("success case: database update succeeds", func() {
			// 场景描述：
			// 数据库更新操作成功执行。
			// 构造数据：
			// - GORM的Updates方法返回一个Error为nil的*gorm.DB对象。
			// 逻辑链路：
			// 1. Mock initDB返回一个可用的*gorm.DB实例。
			// 2. Mock GORM的链式调用Table, Where, Updates均成功。
			// 3. Updates方法返回的*gorm.DB实例的Error字段为nil。
			// 4. ignoreErr(nil)返回nil，不进入错误处理分支。
			// 5. 函数返回nil，表示操作成功。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := p.BatchReplaceReviewer(ctx, nil, newEmail, newID, preContractNo, ids)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case: database update returns a generic error", func() {
			// 场景描述：
			// 数据库更新操作返回一个通用的、未被忽略的错误。
			// 构造数据：
			// - GORM的Updates方法返回一个包含通用错误的*gorm.DB对象。
			// - env.IsOnline()返回false。
			// 逻辑链路：
			// 1. Mock initDB返回一个可用的*gorm.DB实例。
			// 2. Mock GORM的链式调用，但最终Updates返回一个带错误的*gorm.DB实例。
			// 3. ignoreErr函数检查该错误，由于不是可忽略类型，原样返回。
			// 4. Mock logs.CtxError被调用以记录内部错误。
			// 5. Mock i18nfmt.New被调用以生成一个面向用户的错误信息。
			// 6. 函数返回由i18nfmt.New生成的错误。
			dbErr := errors.New("some unexpected db error")
			expectedErr := errors.New("BatchReplaceReviewer error")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := p.BatchReplaceReviewer(ctx, nil, newEmail, newID, preContractNo, ids)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})

		mockey.PatchConvey("success case: database returns ErrRecordNotFound which is ignored", func() {
			// 场景描述：
			// 数据库更新操作未找到匹配记录，返回gorm.ErrRecordNotFound，该错误被逻辑忽略。
			// 构造数据：
			// - GORM的Updates方法返回一个Error为gorm.ErrRecordNotFound的*gorm.DB对象。
			// 逻辑链路：
			// 1. Mock initDB返回一个可用的*gorm.DB实例。
			// 2. Mock GORM的链式调用，最终Updates返回gorm.ErrRecordNotFound。
			// 3. ignoreErr函数内部的ignoreNotFoundErr识别并处理此错误，返回nil。
			// 4. 函数不进入错误处理分支，返回nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := p.BatchReplaceReviewer(ctx, nil, newEmail, newID, preContractNo, ids)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("success case: database returns RASP error in non-online env which is ignored", func() {
			// 场景描述：
			// 在非线上环境，数据库操作被RASP拦截，返回特定错误，该错误被逻辑忽略。
			// 构造数据：
			// - GORM的Updates方法返回一个包含"API blocked by RASP"的错误。
			// - env.IsOnline()返回false。
			// 逻辑链路：
			// 1. Mock initDB返回一个可用的*gorm.DB实例。
			// 2. Mock GORM的Updates返回RASP错误。
			// 3. ignoreErr函数内部的ignoreRaspErr在检查到env.IsOnline()为false后，识别并处理RASP错误，返回nil。
			// 4. Mock logs.CtxError被调用以记录被忽略的RASP错误。
			// 5. 函数不进入错误处理分支，返回nil。
			raspError := errors.New("API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).Return().Build()

			err := p.BatchReplaceReviewer(ctx, nil, newEmail, newID, preContractNo, ids)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case: database returns RASP error in online env which is not ignored", func() {
			// 场景描述：
			// 在线上环境，数据库操作被RASP拦截，返回特定错误，该错误不应被忽略。
			// 构造数据：
			// - GORM的Updates方法返回一个包含"API blocked by RASP"的错误。
			// - env.IsOnline()返回true。
			// 逻辑链路：
			// 1. Mock initDB返回一个可用的*gorm.DB实例。
			// 2. Mock GORM的Updates返回RASP错误。
			// 3. ignoreErr函数内部的ignoreRaspErr在检查到env.IsOnline()为true后，不处理该错误，原样返回。
			// 4. Mock logs.CtxError被调用以记录内部错误。
			// 5. Mock i18nfmt.New被调用以生成一个面向用户的错误信息。
			// 6. 函数返回由i18nfmt.New生成的错误。
			raspError := errors.New("API blocked by RASP")
			expectedErr := errors.New("BatchReplaceReviewer error")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(logs.CtxError).Return().Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := p.BatchReplaceReviewer(ctx, nil, newEmail, newID, preContractNo, ids)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, expectedErr.Error())
		})
	})
}

func Test_ListSoftDeleteReviewerByNo(t *testing.T) {
	ctx := context.Background()
	preContractNo := "12345"
	dao := &preContractReviewerDaoImpl{}
	mockey.PatchConvey("Test db.Find failed", t, func() {
		tx := &gorm.DB{}
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Find")).Return(&gorm.DB{Error: fmt.Errorf("find error")}).Build()
		actual, err := dao.ListSoftDeleteReviewerByNo(ctx, tx, preContractNo)
		convey.So(actual, convey.ShouldBeNil)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "QueryReviewerListFail")
	})

	mockey.PatchConvey("Test db.Find success", t, func() {
		tx := &gorm.DB{}
		mockey.Mock(starlingcli.GetAllCopywriting).Return(map[string]string{}).Build()
		mockey.Mock(initDB).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Table")).Return(tx).Build()
		mockey.Mock(mockey.GetMethod(tx, "Where")).Return(tx).Build()
		expectedList := model.PreContractReviewerDBList{
			&model.PreContractReviewerDB{PreContractNo: preContractNo, IsDeleted: 1},
		}
		mockey.Mock(mockey.GetMethod(tx, "Find")).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
			type ExampleModel struct{}
			switch dest.(type) {
			case *ExampleModel: // Here replace with your model type, like Task{}
				*(dest.(*ExampleModel)) = ExampleModel{}
			case *model.PreContractReviewerDBList:
				*(dest.(*model.PreContractReviewerDBList)) = expectedList
			}
			return &gorm.DB{}
		}).Build()
		actual, err := (&preContractReviewerDaoImpl{}).ListSoftDeleteReviewerByNo(ctx, tx, preContractNo)
		convey.So(actual, convey.ShouldResemble, expectedList)
		convey.So(err, convey.ShouldBeNil)
	})
}

func TestResetReviewerStatusByReviewerType_BitsUTGen(t *testing.T) {
	// 本测试中无需定义 Mock 结构体，因为所有被 mock 的都是包级函数或已存在的 gorm.DB 结构体方法。
	mockey.PatchConvey("TestResetReviewerStatusByReviewerType", t, func() {
		// 准备通用参数
		ctx := context001.Background()
		param := &model.ResetReviewerStatusByReviewerTypeReq{
			PreContractNO:  "PC-TEST-001",
			ReviewerType:   1,
			ContractStatus: 2,
		}
		mockDB := &gorm.DB{}

		mockey.PatchConvey("成功场景: 不带 SkipReturnReviewNoAuditEmails 参数", func() {
			// 场景描述:
			// 测试基础的成功路径，请求参数中不包含需要跳过审批的邮件列表。
			// 构造数据:
			// param.SkipReturnReviewNoAuditEmails 为空切片。
			// 逻辑链路:
			// 1. Mock initDB 返回一个 mockDB 实例。
			// 2. Mock gorm.DB 的链式调用 Table 和 Where，均返回 mockDB 实例。
			// 3. `if len(param.SkipReturnReviewNoAuditEmails) > 0` 条件为 false, 不会进入该分支。
			// 4. Mock gorm.DB 的 Updates 方法返回一个 Error 为 nil 的 gorm.DB 实例。
			// 5. 目标函数调用 ignoreErr，由于错误为 nil，直接返回 nil。
			// 6. 断言最终返回的 error 为 nil。
			param.SkipReturnReviewNoAuditEmails = []string{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 带 SkipReturnReviewNoAuditEmails 参数", func() {
			// 场景描述:
			// 测试带有需要跳过审批邮件列表的成功路径。
			// 构造数据:
			// param.SkipReturnReviewNoAuditEmails 包含一个或多个邮件地址。
			// 逻辑链路:
			// 1. Mock initDB 和 gorm.DB 的链式调用。
			// 2. `if len(param.SkipReturnReviewNoAuditEmails) > 0` 条件为 true, 进入分支并额外调用一次 Where。
			// 3. Mock gorm.DB 的 Updates 方法返回成功。
			// 4. 断言最终返回的 error 为 nil。
			param.SkipReturnReviewNoAuditEmails = []string{"test.user@example.com"}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: 数据库更新失败", func() {
			// 场景描述:
			// 测试数据库 Updates 操作返回一个通用错误时的失败路径。
			// 构造数据:
			// 无特殊构造。
			// 逻辑链路:
			// 1. Mock initDB 和 gorm.DB 的链式调用。
			// 2. Mock gorm.DB 的 Updates 方法返回一个自定义的 error。
			// 3. ignoreErr 函数接收到此错误，由于不是可忽略的错误类型，将其原样返回。
			// 4. 断言最终返回的 error 不为 nil，且包含预期的错误信息。
			dbErr := errors.New("database update error")
			param.SkipReturnReviewNoAuditEmails = []string{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database update error")
		})

		mockey.PatchConvey("成功场景: 数据库返回 ErrRecordNotFound 错误，应被忽略", func() {
			// 场景描述:
			// 测试数据库 Updates 操作返回 gorm.ErrRecordNotFound 错误，该错误应被 ignoreErr 函数忽略。
			// 构造数据:
			// 无特殊构造。
			// 逻辑链路:
			// 1. Mock initDB 和 gorm.DB 的链式调用。
			// 2. Mock gorm.DB 的 Updates 方法返回 gorm.ErrRecordNotFound。
			// 3. ignoreErr 函数接收到此错误，并根据逻辑返回 nil。
			// 4. 断言最终返回的 error 为 nil。
			param.SkipReturnReviewNoAuditEmails = []string{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 数据库返回 RASP 错误且环境为非线上，应被忽略", func() {
			// 场景描述:
			// 测试数据库 Updates 操作返回 RASP 错误，在非线上环境下，该错误应被 ignoreErr 函数忽略。
			// 构造数据:
			// Mock env.IsOnline() 返回 false。
			// 逻辑链路:
			// 1. Mock env.IsOnline() 返回 false。
			// 2. Mock initDB 和 gorm.DB 的链式调用。
			// 3. Mock gorm.DB 的 Updates 方法返回一个包含 "API blocked by RASP" 的错误。
			// 4. ignoreErr 函数接收到此错误，内部调用 ignoreRaspErr，由于环境非线上，返回 nil。
			// 5. 断言最终返回的 error 为 nil。
			raspErr := errors.New("API blocked by RASP")
			param.SkipReturnReviewNoAuditEmails = []string{}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build() // Mock掉日志打印，避免干扰
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景: 数据库返回 RASP 错误且环境为线上，不应被忽略", func() {
			// 场景描述:
			// 测试数据库 Updates 操作返回 RASP 错误，在线上环境下，该错误不应被忽略。
			// 构造数据:
			// Mock env.IsOnline() 返回 true。
			// 逻辑链路:
			// 1. Mock env.IsOnline() 返回 true。
			// 2. Mock initDB 和 gorm.DB 的链式调用。
			// 3. Mock gorm.DB 的 Updates 方法返回一个包含 "API blocked by RASP" 的错误。
			// 4. ignoreErr 函数接收到此错误，内部调用 ignoreRaspErr，由于环境为线上，将错误原样返回。
			// 5. 断言最终返回的 error 不为 nil。
			raspErr := errors.New("API blocked by RASP")
			param.SkipReturnReviewNoAuditEmails = []string{}

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()

			err := ResetReviewerStatusByReviewerType(ctx, nil, param)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
		})
	})
}

func Test_preContractReviewerDaoImpl_SoftDeleteCountersignReviewer_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_preContractReviewerDaoImpl_SoftDeleteCountersignReviewer", t, func() {
		// Prepare common variables
		p := &preContractReviewerDaoImpl{}
		ctx := context001.Background()
		preContractNo := "PC-12345"
		contractStatus := 1
		mockDB := &gorm.DB{}

		mockey.PatchConvey("Success case", func() {
			// 场景描述：
			// 数据库Updates操作成功，返回的error为nil。
			// 构造数据：
			// 无特殊构造。
			// 逻辑链路：
			// 1. Mock initDB返回一个*gorm.DB实例。
			// 2. Mock gorm的链式调用Table, Where, Updates。
			// 3. Mock Updates方法返回一个error为nil的*gorm.DB实例。
			// 4. 函数ignoreErr(nil)返回nil。
			// 5. 函数直接返回nil。
			resultDB := &gorm.DB{Error: nil}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(resultDB).Build()

			err := p.SoftDeleteCountersignReviewer(ctx, nil, preContractNo, contractStatus)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case - generic DB error", func() {
			// 场景描述：
			// 数据库Updates操作失败，返回一个通用DB错误。
			// 构造数据：
			// 构造一个generic error。
			// 逻辑链路：
			// 1. Mock initDB返回一个*gorm.DB实例。
			// 2. Mock gorm的链式调用Table, Where, Updates。
			// 3. Mock Updates方法返回一个包含错误的*gorm.DB实例。
			// 4. 函数ignoreErr(err)返回该错误。
			// 5. Mock i18nfmt.New返回一个封装后的错误。
			// 6. 函数返回封装后的错误。
			dbErr := errors.New("some database error")
			expectedErr := errors.New("DeleteChangedReviewerFail")
			resultDB := &gorm.DB{Error: dbErr}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(resultDB).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := p.SoftDeleteCountersignReviewer(ctx, nil, preContractNo, contractStatus)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteChangedReviewerFail")
		})

		mockey.PatchConvey("Success case - DB error is gorm.ErrRecordNotFound", func() {
			// 场景描述：
			// 数据库Updates操作返回gorm.ErrRecordNotFound，该错误被ignoreErr忽略。
			// 构造数据：
			// 无特殊构造。
			// 逻辑链路：
			// 1. Mock initDB返回一个*gorm.DB实例。
			// 2. Mock gorm的链式调用Table, Where, Updates。
			// 3. Mock Updates方法返回一个error为gorm.ErrRecordNotFound的*gorm.DB实例。
			// 4. 函数ignoreErr(gorm.ErrRecordNotFound)返回nil。
			// 5. 函数直接返回nil。
			resultDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(resultDB).Build()

			err := p.SoftDeleteCountersignReviewer(ctx, nil, preContractNo, contractStatus)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success case - DB error is RASP error in non-online env", func() {
			// 场景描述：
			// 数据库Updates操作返回RASP错误，在非线上环境，该错误被ignoreErr忽略。
			// 构造数据：
			// 构造一个包含"API blocked by RASP"的error。
			// 逻辑链路：
			// 1. Mock env.IsOnline返回false。
			// 2. Mock initDB返回一个*gorm.DB实例。
			// 3. Mock gorm的链式调用Table, Where, Updates。
			// 4. Mock Updates方法返回一个RASP错误。
			// 5. 函数ignoreErr(raspErr)返回nil。
			// 6. 函数直接返回nil。
			raspErr := errors.New("something wrong: API blocked by RASP")
			resultDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(resultDB).Build()

			err := p.SoftDeleteCountersignReviewer(ctx, nil, preContractNo, contractStatus)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure case - DB error is RASP error in online env", func() {
			// 场景描述：
			// 数据库Updates操作返回RASP错误，在线上环境，该错误不被ignoreErr忽略。
			// 构造数据：
			// 构造一个包含"API blocked by RASP"的error。
			// 逻辑链路：
			// 1. Mock env.IsOnline返回true。
			// 2. Mock initDB返回一个*gorm.DB实例。
			// 3. Mock gorm的链式调用Table, Where, Updates。
			// 4. Mock Updates方法返回一个RASP错误。
			// 5. 函数ignoreErr(raspErr)返回该RASP错误。
			// 6. Mock i18nfmt.New返回一个封装后的错误。
			// 7. 函数返回封装后的错误。
			raspErr := errors.New("something wrong: API blocked by RASP")
			expectedErr := errors.New("DeleteChangedReviewerFail")
			resultDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(resultDB).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := p.SoftDeleteCountersignReviewer(ctx, nil, preContractNo, contractStatus)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteChangedReviewerFail")
		})
	})
}

func TestIsAllReviewerTypePassed_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestIsAllReviewerTypePassed", t, func() {
		// 公共测试变量
		ctx := context001.Background()
		preContractNo := "PCN-20231225-001"
		reviewerType := 1
		contractStatus := 1
		mockDB := &gorm.DB{}

		// Mock日志函数，避免在测试中产生实际日志输出
		mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()

		mockey.PatchConvey("场景：所有相关类型的审核人均已通过", func() {
			// 场景描述：
			// GORM查询链被成功调用，最终Count方法将pendingCount设置为0，并且没有返回错误。
			// 逻辑链路：
			// 1. 调用 IsAllReviewerTypePassed, 传入一个非空的 *gorm.DB 作为 tx，以便 initDB 直接返回该实例。
			// 2. gorm 的 Table, Where 链式调用均返回 mockDB 实例。
			// 3. Count 方法被 mock，它将传入的 *int64 参数（pendingCount）设置为 0，并返回一个没有错误的 *gorm.DB 实例。
			// 4. ignoreErr(nil) 返回 nil。
			// 5. 函数最终返回 pendingCount == 0 (true) 和 nil。

			// Arrange
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				*count = 0
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			passed, err := IsAllReviewerTypePassed(ctx, mockDB, preContractNo, reviewerType, contractStatus)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：存在待处理的审核人", func() {
			// 场景描述：
			// GORM查询链被成功调用，最终Count方法将pendingCount设置为大于0的值，表示仍有待处理项。
			// 逻辑链路：
			// 1. 调用 IsAllReviewerTypePassed, 传入一个非空的 *gorm.DB 作为 tx。
			// 2. gorm 的 Table, Where 链式调用返回 mockDB 实例。
			// 3. Count 方法被 mock，将传入的 *int64 参数（pendingCount）设置为 1，并返回一个没有错误的 *gorm.DB 实例。
			// 4. ignoreErr(nil) 返回 nil。
			// 5. 函数最终返回 pendingCount == 0 (false) 和 nil。

			// Arrange
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				*count = 2 // 假设有2个待处理项
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			passed, err := IsAllReviewerTypePassed(ctx, mockDB, preContractNo, reviewerType, contractStatus)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：数据库查询出错", func() {
			// 场景描述：
			// GORM的Count方法在执行时返回一个通用的数据库错误。
			// 逻辑链路：
			// 1. 调用 IsAllReviewerTypePassed, 传入一个非空的 *gorm.DB 作为 tx。
			// 2. Count 方法被 mock，返回一个包含错误的 *gorm.DB 实例。
			// 3. ignoreErr 函数不会忽略此错误（通过 mock env.IsOnline=true 保证）。
			// 4. 函数记录错误日志，并返回 false 和该数据库错误。

			// Arrange
			dbError := errors.New("database connection failed")
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				return &gorm.DB{Error: dbError}
			}).Build()
			// Mock为线上环境，确保 ignoreErr 不会忽略普通错误
			mockey.Mock(env.IsOnline).Return(true).Build()

			// Act
			passed, err := IsAllReviewerTypePassed(ctx, mockDB, preContractNo, reviewerType, contractStatus)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database connection failed")
			convey.So(passed, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("场景：数据库返回 'record not found' 错误", func() {
			// 场景描述：
			// GORM的Count方法返回 gorm.ErrRecordNotFound 错误，该错误应被业务逻辑忽略。
			// 逻辑链路：
			// 1. 调用 IsAllReviewerTypePassed, 传入一个非空的 *gorm.DB 作为 tx。
			// 2. Count 方法被 mock，返回一个 gorm.ErrRecordNotFound 错误。
			// 3. ignoreErr 函数识别并忽略此错误，返回 nil。
			// 4. 函数继续执行，此时 pendingCount 仍为初始值 0。
			// 5. 函数返回 true 和 nil。

			// Arrange
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				return &gorm.DB{Error: gorm.ErrRecordNotFound}
			}).Build()

			// Act
			passed, err := IsAllReviewerTypePassed(ctx, mockDB, preContractNo, reviewerType, contractStatus)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景：非线上环境返回 RASP 错误", func() {
			// 场景描述：
			// GORM的Count方法返回一个 RASP 错误，在非线上环境中该错误应被业务逻辑忽略。
			// 逻辑链路：
			// 1. 调用 IsAllReviewerTypePassed, 传入一个非空的 *gorm.DB 作为 tx。
			// 2. Count 方法被 mock，返回一个包含 "API blocked by RASP" 的错误。
			// 3. env.IsOnline 被 mock 返回 false，以触发 ignoreRaspErr 的逻辑。
			// 4. ignoreErr 函数识别并忽略 RASP 错误，返回 nil。
			// 5. 函数继续执行，此时 pendingCount 仍为初始值 0。
			// 6. 函数返回 true 和 nil。

			// Arrange
			raspError := errors.New("some error: API blocked by RASP")
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Count).To(func(count *int64) *gorm.DB {
				return &gorm.DB{Error: raspError}
			}).Build()
			// Mock为非线上环境
			mockey.Mock(env.IsOnline).Return(false).Build()

			// Act
			passed, err := IsAllReviewerTypePassed(ctx, mockDB, preContractNo, reviewerType, contractStatus)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(passed, convey.ShouldBeTrue)
		})
	})
}

func TestListNotPassedReviewerByPriority_BitsUTGen(t *testing.T) {
	// Common setup for all test cases
	ctx := context001.Background()
	req := &model.ListPreContractReviewerReq{
		PreContractNo:  "PC-2023-001",
		ReviewerType:   1,
		ContractStatus: 2,
		Priority:       10,
	}
	mockDB := &gorm.DB{}

	mockey.PatchConvey("TestListNotPassedReviewerByPriority", t, func() {
		// This setup applies to tests that use the global _dbClient.
		// It initializes the package-level DB client which is used when tx is nil.
		_dbClient = &gorm.DB{}

		mockey.PatchConvey("Success case: found reviewers using global db client", func() {
			// 场景描述：
			// 测试在不提供事务对象(tx)时，函数通过全局_dbClient成功查询到符合条件的审阅人列表。
			// 构造数据：
			// req: 一个标准的查询请求。
			// tx: nil, 触发函数使用全局数据库连接。
			// 逻辑链路：
			// 1. initDB(ctx, nil)被调用，其内部调用_dbClient.WithContext(ctx)。
			// 2. gorm的Table, Where链式调用均成功，返回预设的mockDB对象。
			// 3. Find操作成功，查询到一条记录，并将其填充到list中，返回的gorm.DB.Error为nil。
			// 4. ignoreErr(nil)返回nil，不进入任何错误处理分支。
			// 5. 函数成功返回查询到的列表和nil error。

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()

			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = model.PreContractReviewerDBList{
						{PreContractNo: req.PreContractNo},
					}
				}
				return &gorm.DB{Error: nil} // Simulate a successful find
			}).Build()

			// Act
			result, err := ListNotPassedReviewerByPriority(ctx, nil, req)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result[0].PreContractNo, convey.ShouldEqual, req.PreContractNo)
		})

		mockey.PatchConvey("Success case: found reviewers using provided tx", func() {
			// 场景描述：
			// 测试在提供事务对象(tx)的情况下，函数能利用该事务对象成功查询到审阅人列表。
			// 构造数据：
			// req: 一个标准的查询请求。
			// tx: 一个非nil的*gorm.DB对象，模拟数据库事务。
			// 逻辑链路：
			// 1. initDB(ctx, tx)被调用，直接返回传入的tx对象，不使用全局_dbClient。
			// 2. gorm的Table, Where链式调用均在tx对象上执行并成功。
			// 3. Find操作在tx上成功执行，查询到两条记录。
			// 4. 函数成功返回查询到的列表和nil error。

			// Arrange
			tx := &gorm.DB{}
			mockey.Mock((*gorm.DB).Table).Return(tx).Build()
			mockey.Mock((*gorm.DB).Where).Return(tx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = model.PreContractReviewerDBList{
						{PreContractNo: req.PreContractNo},
						{PreContractNo: req.PreContractNo},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			result, err := ListNotPassedReviewerByPriority(ctx, tx, req)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(len(result), convey.ShouldEqual, 2)
		})

		mockey.PatchConvey("Error case: DB Find fails with a generic error", func() {
			// 场景描述：
			// 测试当数据库Find操作返回一个通用错误时，函数能捕获此错误并返回封装后的i18n错误信息。
			// 构造数据：
			// req: 一个标准的查询请求。
			// tx: nil。
			// 逻辑链路：
			// 1. initDB和Where链调用成功。
			// 2. Find操作失败，返回一个非gorm.ErrRecordNotFound的error。
			// 3. ignoreErr(err)不忽略该错误，返回原始error。
			// 4. 进入第一个`if ignoreErr(err) != nil`的错误处理分支。
			// 5. i18nfmt.New被调用，生成特定的错误信息。
			// 6. 函数返回nil列表和i18nfmt.New返回的错误。

			// Arrange
			dbErr := errors.New("database connection lost")
			i18nErr := errors.New("ListNotPassedReviewerByPriorityFail")

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build() // For ignoreErr -> ignoreRaspErr
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			// Act
			result, err := ListNotPassedReviewerByPriority(ctx, nil, req)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, i18nErr.Error())
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Edge case: DB returns record not found", func() {
			// 场景描述：
			// 测试当数据库查询未找到任何记录（返回gorm.ErrRecordNotFound）时，函数应将其视为正常情况，并返回一个空的列表和nil错误。
			// 构造数据：
			// req: 一个标准的查询请求。
			// tx: nil。
			// 逻辑链路：
			// 1. initDB和Where链调用成功。
			// 2. Find操作返回gorm.ErrRecordNotFound，同时模拟GORM行为将结果slice初始化为空slice。
			// 3. ignoreErr(gorm.ErrRecordNotFound)内部的ignoreNotFoundErr返回nil，因此ignoreErr返回nil。
			// 4. 不会进入任何错误处理分支。
			// 5. 函数返回一个非nil的空列表和nil error。

			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				// 模拟GORM的行为：即使没有找到记录，也会初始化slice为一个非nil的空slice。
				if list, ok := dest.(*model.PreContractReviewerDBList); ok {
					*list = make(model.PreContractReviewerDBList, 0)
				}
				return &gorm.DB{Error: gorm.ErrRecordNotFound}
			}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build() // For ignoreErr

			// Act
			result, err := ListNotPassedReviewerByPriority(ctx, nil, req)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil) // Should be an empty slice, not nil
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})
}

func TestUpdateReviewerStatus_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestUpdateReviewerStatus", t, func() {
		// 构造通用测试数据
		ctx := context001.Background()
		param := &model.UpdateReviewerStatusReq{
			PreContractNO:    "PCN-2023-001",
			Reviewer:         "test.reviewer",
			ReviewerType:     1,
			ContractStatus:   10,
			Status:           20,
			SkipReturnReview: 1,
		}
		mockDB := &gorm.DB{}

		mockey.PatchConvey("场景：成功更新审核人状态", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx为nil。
			// 逻辑链路：
			// 1. initDB返回一个mock的*gorm.DB实例。
			// 2. gorm的链式调用 Table -> Where -> Updates 均成功。
			// 3. Updates方法返回的DB实例中，Error字段为nil。
			// 4. ignoreErr接收到nil错误，直接返回nil。
			// 5. 函数最终返回nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := UpdateReviewerStatus(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：数据库更新失败，返回通用错误", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx为nil。
			// 逻辑链路：
			// 1. initDB返回一个mock的*gorm.DB实例。
			// 2. gorm的链式调用到Updates方法时，返回一个通用错误。
			// 3. ignoreErr接收到该错误，由于不满足任何忽略条件，原样返回。
			// 4. 函数最终返回该通用错误。
			dbErr := errors.New("database update error")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build() // 确保不进入RASP错误忽略逻辑

			err := UpdateReviewerStatus(ctx, nil, param)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "database update error")
		})

		mockey.PatchConvey("场景：数据库返回gorm.ErrRecordNotFound，错误被忽略", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx为nil。
			// 逻辑链路：
			// 1. initDB返回一个mock的*gorm.DB实例。
			// 2. gorm的链式调用到Updates方法时，返回gorm.ErrRecordNotFound。
			// 3. ignoreErr接收到该错误，ignoreNotFoundErr分支命中，返回nil。
			// 4. 函数最终返回nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := UpdateReviewerStatus(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：非线上环境，数据库返回RASP错误，错误被忽略", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx为nil。
			// 逻辑链路：
			// 1. initDB返回一个mock的*gorm.DB实例。
			// 2. gorm的链式调用到Updates方法时，返回一个包含"API blocked by RASP"的错误。
			// 3. Mock env.IsOnline 返回 false，表示非线上环境。
			// 4. ignoreErr接收到该错误，ignoreRaspErr分支命中，返回nil。
			// 5. 函数最终返回nil。
			raspErr := errors.New("SQL injection detected: API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(logs.CtxError).To(func(ctx context001.Context, format string, v ...interface{}) {}).Build()

			err := UpdateReviewerStatus(ctx, nil, param)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：线上环境，数据库返回RASP错误，错误不被忽略", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx为nil。
			// 逻辑链路：
			// 1. initDB返回一个mock的*gorm.DB实例。
			// 2. gorm的链式调用到Updates方法时，返回一个包含"API blocked by RASP"的错误。
			// 3. Mock env.IsOnline 返回 true，表示线上环境。
			// 4. ignoreErr接收到该错误，ignoreRaspErr分支不满足条件，原样返回错误。
			// 5. 函数最终返回该RASP错误。
			raspErr := errors.New("API blocked by RASP")
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()

			err := UpdateReviewerStatus(ctx, nil, param)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
		})

		mockey.PatchConvey("场景：使用传入的事务句柄(tx)成功更新", func() {
			// 场景描述：
			// 构造数据：一个合法的UpdateReviewerStatusReq参数，tx不为nil。
			// 逻辑链路：
			// 1. initDB接收到非nil的tx，直接返回该tx。
			// 2. gorm的链式调用在传入的tx上进行，且均成功。
			// 3. Updates方法返回的DB实例中，Error字段为nil。
			// 4. ignoreErr接收到nil错误，直接返回nil。
			// 5. 函数最终返回nil。
			tx := &gorm.DB{}
			mockey.Mock((*gorm.DB).Table).Return(tx).Build()
			mockey.Mock((*gorm.DB).Where).Return(tx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := UpdateReviewerStatus(ctx, tx, param)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_preContractReviewerDaoImpl_DeleteReviewersByType_BitsUTGen(t *testing.T) {
	p := &preContractReviewerDaoImpl{}
	ctx := context001.Background()

	mockey.PatchConvey("Test preContractReviewerDaoImpl.DeleteReviewersByType", t, func() {
		mockey.PatchConvey("should return nil when preContractNo is empty", func() {
			// 场景描述：
			// 构造数据：preContractNo为空字符串。
			// 逻辑链路：
			// 1. 函数在开头检查preContractNo长度。
			// 2. 因为preContractNo为空，直接返回nil，不执行数据库操作。

			preContractNo := ""
			reviewerType := []int{1}

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when reviewerType is empty", func() {
			// 场景描述：
			// 构造数据：reviewerType为空切片。
			// 逻辑链路：
			// 1. 函数在开头检查reviewerType长度。
			// 2. 因为reviewerType为空，直接返回nil，不执行数据库操作。

			preContractNo := "PCN-001"
			var reviewerType []int

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil on successful deletion", func() {
			// 场景描述：
			// 构造数据：有效的preContractNo和reviewerType。
			// 逻辑链路：
			// 1. Mock initDB返回一个*gorm.DB实例。
			// 2. Mock GORM的链式调用Table和Where，都返回同一个*gorm.DB实例。
			// 3. Mock Delete方法返回一个*gorm.DB实例，其Error字段为nil。
			// 4. 函数成功执行并返回nil。

			mockDB := &gorm.DB{}
			preContractNo := "PCN-001"
			reviewerType := []int{1, 2}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: nil}).Build()

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return an error when deletion fails with a database error", func() {
			// 场景描述：
			// 构造数据：有效的preContractNo和reviewerType。
			// 逻辑链路：
			// 1. Mock GORM调用链。
			// 2. Mock Delete方法返回一个通用数据库错误。
			// 3. ignoreErr函数不会忽略此错误。
			// 4. 函数会调用logs.CtxError和i18nfmt.New来构造并返回一个错误。

			mockDB := &gorm.DB{}
			dbError := errors.New("database connection lost")
			expectedError := errors.New("DeleteReviewersByTypeFail")
			preContractNo := "PCN-001"
			reviewerType := []int{1, 2}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: dbError}).Build()
			mockey.Mock(i18nfmt.New).Return(expectedError).Build()

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteReviewersByTypeFail")
		})

		mockey.PatchConvey("should return nil when deletion returns ErrRecordNotFound", func() {
			// 场景描述：
			// 构造数据：有效的preContractNo和reviewerType。
			// 逻辑链路：
			// 1. Mock GORM调用链。
			// 2. Mock Delete方法返回gorm.ErrRecordNotFound。
			// 3. ignoreErr函数会忽略此错误。
			// 4. 函数最终返回nil。

			mockDB := &gorm.DB{}
			preContractNo := "PCN-001"
			reviewerType := []int{1, 2}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return nil when deletion fails with a RASP error in non-online env", func() {
			// 场景描述：
			// 构造数据：有效的preContractNo和reviewerType。
			// 逻辑链路：
			// 1. Mock GORM调用链。
			// 2. Mock Delete方法返回一个包含 "API blocked by RASP" 的错误。
			// 3. Mock env.IsOnline()返回false，表示非线上环境。
			// 4. ignoreErr函数会忽略RASP错误。
			// 5. 函数最终返回nil。

			mockDB := &gorm.DB{}
			raspError := errors.New("some error: API blocked by RASP")
			preContractNo := "PCN-001"
			reviewerType := []int{1, 2}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("should return error when deletion fails with a RASP error in online env", func() {
			// 场景描述：
			// 构造数据：有效的preContractNo和reviewerType。
			// 逻辑链路：
			// 1. Mock GORM调用链。
			// 2. Mock Delete方法返回一个包含 "API blocked by RASP" 的错误。
			// 3. Mock env.IsOnline()返回true，表示线上环境。
			// 4. ignoreErr函数不会忽略RASP错误。
			// 5. 函数最终返回封装后的错误。

			mockDB := &gorm.DB{}
			raspError := errors.New("some error: API blocked by RASP")
			expectedError := errors.New("DeleteReviewersByTypeFail")
			preContractNo := "PCN-001"
			reviewerType := []int{1, 2}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(&gorm.DB{Error: raspError}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(i18nfmt.New).Return(expectedError).Build()

			err := p.DeleteReviewersByType(ctx, nil, preContractNo, reviewerType)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteReviewersByTypeFail")
		})
	})
}

func Test_preContractReviewerDaoImpl_BatchCreate(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).To(func(value interface{}, batchSize int) (tx *gorm.DB) {
				return &gorm.DB{}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &preContractReviewerDaoImpl{}
			err := v.BatchCreate(context.Background(), &gorm.DB{}, []*model.PreContractReviewerDB{&model.PreContractReviewerDB{}})

			// Assert
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case CreateInBatchesFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).CreateInBatches).To(func(value interface{}, batchSize int) (tx *gorm.DB) {
				return &gorm.DB{
					Error: fmt.Errorf("CreateInBatchesFail"),
				}
			}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &preContractReviewerDaoImpl{}
			err := v.BatchCreate(context.Background(), &gorm.DB{}, []*model.PreContractReviewerDB{&model.PreContractReviewerDB{}})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "batchCreatePreReviewerFail")
		})
	})
}

func Test_preContractReviewerDaoImpl_ReplaceReviewerByOldInfo_BitsUTGen(t *testing.T) {
	t.Run("Early return when any required field is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}

			// Missing PreContractNo triggers early return
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)
			convey.So(err, convey.ShouldBeNil)
			convey.So(rows, convey.ShouldEqual, 0)
		})
	})

	t.Run("Update successful returns rows affected", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Avoid any potential panic from logs
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// Chain gorm methods to return the same DB instance
			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()

			// Final Updates returns a result DB with nil error & specific RowsAffected
			updateRes := &gorm.DB{Error: nil, RowsAffected: 3}
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				return updateRes
			}).Build()

			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "PC123",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)
			convey.So(err, convey.ShouldBeNil)
			convey.So(rows, convey.ShouldEqual, 3)
		})
	})

	t.Run("Update with contract status only updates specified status", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			var capturedWheres []interface{}
			var capturedArgs [][]interface{}
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				capturedWheres = append(capturedWheres, query)
				capturedArgs = append(capturedArgs, args)
				return db
			}).Build()

			updateRes := &gorm.DB{Error: nil, RowsAffected: 1}
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				return updateRes
			}).Build()

			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}
			contractStatus := 9
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "PC123",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
				ContractStatus:   &contractStatus,
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)

			convey.So(err, convey.ShouldBeNil)
			convey.So(rows, convey.ShouldEqual, 1)
			convey.So(capturedWheres, convey.ShouldContain, "contract_status = ?")
			convey.So(capturedArgs[len(capturedArgs)-1][0], convey.ShouldEqual, contractStatus)
		})
	})

	t.Run("Error returned and not ignored triggers i18n error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Prevent logs.CtxError panic
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()

			// Updates returns an error not ignored by ignoreErr
			updateRes := &gorm.DB{Error: errors.New("update failed"), RowsAffected: 7}
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				return updateRes
			}).Build()

			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "PC123",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)
			convey.So(rows, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ReplaceReviewerByOldInfoFail")
		})
	})

	t.Run("RASP blocked error is ignored and returns rows affected", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Prevent logs inside ignoreRaspErr
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()

			// Error contains RASP keyword, should be ignored in offline env
			updateRes := &gorm.DB{Error: errors.New("API blocked by RASP: injection detected"), RowsAffected: 9}
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				return updateRes
			}).Build()

			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "PC123",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)
			convey.So(err, convey.ShouldBeNil)
			convey.So(rows, convey.ShouldEqual, 9)
		})
	})

	t.Run("Record not found error is ignored and returns zero", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Prevent logs.CtxError panic (not expected to be called here, but safe)
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return db
			}).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return db
			}).Build()

			// ErrRecordNotFound should be ignored by ignoreErr
			updateRes := &gorm.DB{Error: gorm.ErrRecordNotFound, RowsAffected: 0}
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				return updateRes
			}).Build()

			dao := &preContractReviewerDaoImpl{}
			ctx := context001.Background()
			tx := &gorm.DB{}
			params := &model.ReplaceReviewerByOldInfoReq{
				PreContractNo:    "PC123",
				OldReviewerEmail: "old@example.com",
				OldReviewerID:    "old-id",
				NewReviewerEmail: "new@example.com",
				NewReviewerID:    "new-id",
			}

			rows, err := dao.ReplaceReviewerByOldInfo(ctx, tx, params)
			convey.So(err, convey.ShouldBeNil)
			convey.So(rows, convey.ShouldEqual, 0)
		})
	})
}

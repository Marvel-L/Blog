package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tContractTradeParty = "volc_contract_trade_party"
)

type ContractTradePartyDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractTradePartyDB) error
	BatchCreate(ctx context.Context, tx *gorm.DB, entities model.ContractTradePartyDBList) error
	ListTradePartyByContractID(ctx context.Context, tx *gorm.DB, contractID int) (model.ContractTradePartyDBList, error)
	DeleteTradePartyByIds(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error
	DeleteByVolcContractId(ctx context.Context, tx *gorm.DB, contractID int) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.ContractTradePartyDB) error
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID uint64, offset int) (model.ContractTradePartyDBList, error)
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	FindByID(ctx context.Context, tx *gorm.DB, id uint64) (*model.ContractTradePartyDB, error)
}

func NewContractTradePartyDao() ContractTradePartyDao {
	return &contractTradePartyDaoImpl{}
}

type contractTradePartyDaoImpl struct {
}

func (c *contractTradePartyDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractTradePartyDB) error {
	// 敏感字段在create是会被gorm-dkms置空，创建业务合同的长事务中使用该明文字段，因此这里需要先保存明文，create后再赋值。
	if entity == nil {
		return i18nfmt.New(ctx, "createContractTradePartyFail, entity is nil")
	}
	extPlaintext := entity.Ext
	err := initDB(ctx, tx).Table(tContractTradeParty).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractTradePartyFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "createContractTradePartyFail, err:%v", err))
	}
	entity.Ext = extPlaintext
	return nil
}

func (c *contractTradePartyDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.ContractTradePartyDB) error {
	// 敏感字段在create是会被gorm-dkms置空，创建业务合同的长事务中使用该明文字段，因此这里需要先保存明文，update后再赋值。
	if entity == nil {
		return i18nfmt.New(ctx, "updateContractTradePartyFail, entity is nil")
	}
	extPlaintext := entity.Ext
	err := initDB(ctx, tx).Model(&model.ContractTradePartyDB{}).Table(tContractTradeParty).Where("id = ?", entity.Id).Select("*").Omit("created_time").Updates(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateTradePartyFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "updateTradePartyFail")
	}
	entity.Ext = extPlaintext
	return nil
}

func (c *contractTradePartyDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Model(&model.ContractTradePartyDB{}).Table(tContractTradeParty)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c *contractTradePartyDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID uint64, offset int) (model.ContractTradePartyDBList, error) {
	db := initDB(ctx, tx).Table(tContractTradeParty).Where("id >= ?", startID)
	var list model.ContractTradePartyDBList
	err := db.Order("id asc").Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractTradePartyDaoImpl) FindByID(ctx context.Context, tx *gorm.DB, id uint64) (*model.ContractTradePartyDB, error) {
	var entity model.ContractTradePartyDB
	db := initDB(ctx, tx).Table(tContractTradeParty).Where("id = ?", id)
	if err := db.First(&entity).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByID, err:%v", err)
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "FindByIDFail, err:%v", err))
	}
	return &entity, nil
}

func (c *contractTradePartyDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities model.ContractTradePartyDBList) error {
	err := initDB(ctx, tx).Table(tContractTradeParty).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreateTradePartyFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "batchCreateTradePartyFail,err:%v", err))
	}
	return nil
}

func (c *contractTradePartyDaoImpl) DeleteTradePartyByIds(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error {
	if len(ids) == 0 {
		logs.CtxWarn(ctx, "NO ids")
		return nil
	}

	db := initDB(ctx, tx).Table(tContractTradeParty)
	err := db.Where("volc_contract_id = ?", contractID).Where("id in (?)", ids).Delete(nil).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteTradePartyByIds, err:%v", err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "DeleteTradePartyByIdsFail, err:%v", err))
	}
	return nil
}

func (c *contractTradePartyDaoImpl) DeleteByVolcContractId(ctx context.Context, tx *gorm.DB, contractID int) error {
	db := initDB(ctx, tx).Table(tContractTradeParty)
	err := db.Where("volc_contract_id = ?", contractID).Delete(nil).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteTradePartyByIds, err:%v", err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "DeleteTradePartyByIdsFail, err:%v", err))
	}
	return nil
}

func (c *contractTradePartyDaoImpl) ListTradePartyByContractID(ctx context.Context, tx *gorm.DB, contractID int) (model.ContractTradePartyDBList, error) {
	var list model.ContractTradePartyDBList
	db := initDB(ctx, tx).Table(tContractTradeParty).Where("volc_contract_id = ?", contractID)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListTradePartyByContractID, contractID:%s, err:%s", contractID, err.Error())
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListTradePartyByContractIDFail,err:%v", err))
	}
	return list, nil
}

package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

const (
	tBusinessModeClause = "business_mode_clause"
)

type BusinessModeClauseDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.BusinessModeClauseDB) error
	UpdateByID(ctx context.Context, tx *gorm.DB, contractID int, id uint64, updates map[string]interface{}) error
	DeleteByIDs(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error
	ListByContractID(ctx context.Context, tx *gorm.DB, contractID int) ([]*model.BusinessModeClauseDB, error)
	ListByContractIDAndBusinessModes(ctx context.Context, tx *gorm.DB, contractID int, businessModes []string) ([]*model.BusinessModeClauseDB, error)
}

func NewBusinessModeClauseDao() BusinessModeClauseDao {
	return &businessModeClauseDaoImpl{}
}

type businessModeClauseDaoImpl struct{}

func (b *businessModeClauseDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.BusinessModeClauseDB) error {
	err := initDB(ctx, tx).Table(tBusinessModeClause).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateBusinessModeClauseFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "CreateBusinessModeClauseFail,err:%v", err))
	}
	return nil
}

func (b *businessModeClauseDaoImpl) UpdateByID(ctx context.Context, tx *gorm.DB, contractID int, id uint64, updates map[string]interface{}) error {
	if len(updates) == 0 {
		return nil
	}
	db := initDB(ctx, tx).Table(tBusinessModeClause)
	err := db.Where("id = ? and volc_contract_id = ?", id, contractID).
		Where("is_deleted = ?", _const.FALSE_FLAG_INT).
		Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateBusinessModeClauseByIDFail, contractID:%d, id:%d, err:%v", contractID, id, err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "UpdateBusinessModeClauseByIDFail,err:%v", err))
	}
	return nil
}

func (b *businessModeClauseDaoImpl) DeleteByIDs(ctx context.Context, tx *gorm.DB, contractID int, ids []uint64) error {
	if len(ids) == 0 {
		return nil
	}
	db := initDB(ctx, tx).Table(tBusinessModeClause)
	err := db.Where("volc_contract_id = ?", contractID).
		Where("id in (?)", ids).
		Where("is_deleted = ?", _const.FALSE_FLAG_INT).
		Updates(map[string]interface{}{"is_deleted": _const.TRUE_FLAG_INT}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteBusinessModeClauseByIDsFail, contractID:%d, ids:%v, err:%v", contractID, ids, err)
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "DeleteBusinessModeClauseByIDsFail,err:%v", err))
	}
	return nil
}

func (b *businessModeClauseDaoImpl) ListByContractID(ctx context.Context, tx *gorm.DB, contractID int) ([]*model.BusinessModeClauseDB, error) {
	var list []*model.BusinessModeClauseDB
	db := initDB(ctx, tx).Table(tBusinessModeClause).
		Where("volc_contract_id = ?", contractID).
		Where("is_deleted = ?", _const.FALSE_FLAG_INT)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListBusinessModeClauseByContractIDFail, contractID:%d, err:%s", contractID, err.Error())
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListBusinessModeClauseByContractIDFail,err:%v", err))
	}
	return list, nil
}

func (b *businessModeClauseDaoImpl) ListByContractIDAndBusinessModes(ctx context.Context, tx *gorm.DB,
	contractID int, businessModes []string) ([]*model.BusinessModeClauseDB, error) {
	var list []*model.BusinessModeClauseDB
	if len(businessModes) == 0 {
		return list, nil
	}
	db := initDB(ctx, tx).Table(tBusinessModeClause).
		Where("volc_contract_id = ?", contractID).
		Where("business_mode in (?)", businessModes).
		Where("is_deleted = ?", _const.FALSE_FLAG_INT)
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListBusinessModeClauseByContractIDAndBusinessModesFail, contractID:%d, businessModes:%v, err:%s",
			contractID, businessModes, err.Error())
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListBusinessModeClauseByContractIDAndBusinessModesFail,err:%v", err))
	}
	return list, nil
}

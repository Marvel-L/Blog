package dal

import (
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/pkg/env"
)

func Test_contractMetaExtDaoImpl_DeleteByAttrKey_BitsUTGen(t *testing.T) {
	d := &contractMetaExtDaoImpl{}

	mockey.PatchConvey("Test contractMetaExtDaoImpl_DeleteByAttrKey", t, func() {
		ctx := context.Background()
		var contractId uint64 = 123
		attrKey := "test_attr_key"

		mockey.PatchConvey("成功场景: 当传入事务对象时，成功删除数据", func() {
			// 场景描述：
			// 传入一个非空的gorm事务对象，数据库删除操作成功，函数返回nil。
			// 构造数据：
			// tx: 一个mock的*gorm.DB对象
			// contractId: 123
			// attrKey: "test_attr_key"
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. initDB接收到非空的tx，直接返回该tx。
			// 3. 链式调用Table, Where, Where, Delete均返回mock的*gorm.DB对象。
			// 4. Delete方法返回的*gorm.DB对象的Error字段为nil。
			// 5. ignoreErr(nil)返回nil。
			// 6. 函数最终返回nil。
			mockTx := &gorm.DB{}
			mockResultDB := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, mockTx, contractId, attrKey)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景: 当事务对象为nil时，使用全局DB客户端成功删除数据", func() {
			// 场景描述：
			// 传入的gorm事务对象为nil，函数使用全局的_dbClient执行删除操作，并成功返回nil。
			// 构造数据：
			// tx: nil
			// contractId: 123
			// attrKey: "test_attr_key"
			// _dbClient: 一个mock的*gorm.DB对象
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. initDB接收到nil的tx，调用_dbClient.WithContext。
			// 3. Mock _dbClient.WithContext返回一个mock的*gorm.DB对象。
			// 4. 链式调用Table, Where, Where, Delete均成功。
			// 5. Delete方法返回的*gorm.DB对象的Error字段为nil。
			// 6. ignoreErr(nil)返回nil。
			// 7. 函数最终返回nil。
			_dbClient = &gorm.DB{} // Initialize global var for initDB
			mockDB := &gorm.DB{}
			mockResultDB := &gorm.DB{Error: nil}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, nil, contractId, attrKey)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界场景: 删除时gorm返回ErrRecordNotFound，该错误被忽略", func() {
			// 场景描述：
			// 数据库删除操作返回gorm.ErrRecordNotFound，根据ignoreErr的逻辑，此错误被忽略，函数返回nil。
			// 构造数据：
			// tx: 一个mock的*gorm.DB对象
			// Delete方法返回的Error为gorm.ErrRecordNotFound
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. DB操作链式调用成功。
			// 3. Delete方法返回的*gorm.DB对象的Error字段为gorm.ErrRecordNotFound。
			// 4. ignoreErr(gorm.ErrRecordNotFound)返回nil。
			// 5. 函数最终返回nil。
			mockTx := &gorm.DB{}
			mockResultDB := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, mockTx, contractId, attrKey)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("边界场景: 非线上环境发生RASP错误，该错误被忽略", func() {
			// 场景描述：
			// 数据库删除操作返回包含"API blocked by RASP"的错误，同时环境为非线上环境，此错误被ignoreErr忽略，函数返回nil。
			// 构造数据：
			// tx: 一个mock的*gorm.DB对象
			// env.IsOnline()返回false
			// Delete方法返回的Error为包含RASP信息的错误
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. Mock env.IsOnline()返回false。
			// 3. DB操作链式调用成功。
			// 4. Delete方法返回的*gorm.DB对象的Error字段为RASP错误。
			// 5. ignoreErr根据环境判断，忽略该错误，返回nil。
			// 6. 函数最终返回nil。
			mockTx := &gorm.DB{}
			raspErr := errors.New("API blocked by RASP")
			mockResultDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, mockTx, contractId, attrKey)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("异常场景: attrKey为空", func() {
			// 场景描述：
			// 传入的attrKey为空字符串，函数应立即返回错误。
			// 构造数据：
			// attrKey: ""
			// 逻辑链路：
			// 1. 检查len(attrKey) == 0为true。
			// 2. 调用i18nfmt.New返回错误。
			// 3. 函数返回该错误。
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
				return v
			}).Build()
			err := d.DeleteByAttrKey(ctx, nil, contractId, "")

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "NO attrKey")
		})

		mockey.PatchConvey("异常场景: 数据库删除操作返回通用错误", func() {
			// 场景描述：
			// 数据库删除操作返回一个通用错误，该错误未被ignoreErr处理，函数应返回该错误。
			// 构造数据：
			// tx: 一个mock的*gorm.DB对象
			// Delete方法返回的Error为一个自定义的error
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. DB操作链式调用成功。
			// 3. Delete方法返回的*gorm.DB对象的Error字段为一个通用错误。
			// 4. ignoreErr不处理该错误，直接返回。
			// 5. 函数最终返回该错误。
			mockTx := &gorm.DB{}
			dbErr := errors.New("some db error")
			mockResultDB := &gorm.DB{Error: dbErr}

			mockey.Mock(env.IsOnline).Return(false).Build() // To ensure ignoreRaspErr doesn't misfire
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, mockTx, contractId, attrKey)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "some db error")
		})

		mockey.PatchConvey("异常场景: 线上环境发生RASP错误，该错误不被忽略", func() {
			// 场景描述：
			// 数据库删除操作返回包含"API blocked by RASP"的错误，但环境为线上环境，此错误不应被ignoreErr忽略，函数返回该错误。
			// 构造数据：
			// tx: 一个mock的*gorm.DB对象
			// env.IsOnline()返回true
			// Delete方法返回的Error为包含RASP信息的错误
			// 逻辑链路：
			// 1. attrKey不为空，校验通过。
			// 2. Mock env.IsOnline()返回true。
			// 3. DB操作链式调用成功。
			// 4. Delete方法返回的*gorm.DB对象的Error字段为RASP错误。
			// 5. ignoreErr根据环境判断，不忽略该错误，直接返回。
			// 6. 函数最终返回该错误。
			mockTx := &gorm.DB{}
			raspErr := errors.New("API blocked by RASP")
			mockResultDB := &gorm.DB{Error: raspErr}

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Delete).Return(mockResultDB).Build()

			err := d.DeleteByAttrKey(ctx, mockTx, contractId, attrKey)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "API blocked by RASP")
		})
	})
}

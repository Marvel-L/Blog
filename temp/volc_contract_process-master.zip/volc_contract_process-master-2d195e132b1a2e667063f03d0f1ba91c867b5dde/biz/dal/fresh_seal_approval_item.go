package dal

import (
	"context"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
)

const (
	tBFreshSealApprovalItem = "fresh_seal_approval_item"
)

type ListParams struct {
	ContractNoList []string
	ApplyIds       []string
}

// FreshSealApprovalItemDao 鲜章申请条目dao
type FreshSealApprovalItemDao interface {
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.FreshSealApprovalItemDB) error
	List(ctx context.Context, tx *gorm.DB, listParams *ListParams) (model.FreshSealApprovalItemDBList, error)
}

var _freshSealApprovalItemDaoInstance = &freshSealApprovalItemDaoImpl{}

func NewFreshSealApprovalItemDao() FreshSealApprovalItemDao {
	return _freshSealApprovalItemDaoInstance
}

type freshSealApprovalItemDaoImpl struct{}

// BatchCreate 批量创建鲜章申请子条目
func (p *freshSealApprovalItemDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.FreshSealApprovalItemDB) error {
	db := initDB(ctx, tx)
	err := db.Table(tBFreshSealApprovalItem).CreateInBatches(entities, len(entities)).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createFreshSealApprovalItemFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createFreshSealApprovalItemFail")
	}
	return nil
}

func (p *freshSealApprovalItemDaoImpl) List(ctx context.Context, tx *gorm.DB, listParams *ListParams) (model.FreshSealApprovalItemDBList, error) {
	if len(listParams.ContractNoList) == 0 && len(listParams.ApplyIds) == 0 {
		return nil, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "ListFail listParams , listParams:%+v", listParams))
	}
	db := initDB(ctx, tx)
	var list model.FreshSealApprovalItemDBList
	query := db.Table(tBFreshSealApprovalItem)
	if len(listParams.ContractNoList) > 0 {
		query = query.Where("contract_no IN ?", listParams.ContractNoList)
	}
	if len(listParams.ApplyIds) > 0 {
		query = query.Where("apply_id IN ?", listParams.ApplyIds)
	}

	err := query.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createFreshSealApprovalItemFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "freshSealApprovalItemListFail")
	}
	return list, nil
}

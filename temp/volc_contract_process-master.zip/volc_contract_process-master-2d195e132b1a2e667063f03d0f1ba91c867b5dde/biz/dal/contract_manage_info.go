package dal

import (
	"context"
	"encoding/json"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tContractManageInfo = "volc_contract_manage"
)

type ContractManageDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractManage) error
	Update(ctx context.Context, tx *gorm.DB, entity *model.VolcContractManage) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updateMap map[string]interface{}) error
	ChangeVolcContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error
	FindByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) (*model.VolcContractManage, error)
	FindByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (*model.VolcContractManage, error)
	DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error
	DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) ([]*model.VolcContractManage, error)
}

type contractManageDaoImpl struct {
}

var _contractManageDaoInstance = &contractManageDaoImpl{}

func NewContractManageDao() ContractManageDao {
	return _contractManageDaoInstance
}

func buildUpdateMap(entity *model.VolcContractManage) map[string]interface{} {
	if entity == nil {
		return nil
	}
	var resMap map[string]interface{}
	body, err := json.Marshal(entity)
	if err != nil {
		return resMap
	}
	_ = json.Unmarshal(body, &resMap)
	return resMap
}

func (c *contractManageDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractManage) error {
	err := initDB(ctx, tx).Table(tContractManageInfo).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractManageFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractManageFail")
	}
	return nil
}

func (c *contractManageDaoImpl) Update(ctx context.Context, tx *gorm.DB, entity *model.VolcContractManage) error {
	err := initDB(ctx, tx).Table(tContractManageInfo).Where("id = ?", entity.Id).Updates(buildUpdateMap(entity)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractManageFail, id:%d, err:%s", entity.Id, err.Error())
		return i18nfmt.New(ctx, "updateContractManageFail")
	}
	return nil
}

func (c *contractManageDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updateMap map[string]interface{}) error {
	err := initDB(ctx, tx).Table(tContractManageInfo).Where("id = ?", id).Updates(updateMap).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateContractManageByMapFail, id:%d, err:%s", id, err.Error())
		return i18nfmt.New(ctx, "updateContractManageByMapFail")
	}
	return nil
}

func (c *contractManageDaoImpl) ChangeVolcContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error {
	err := initDB(ctx, tx).Table(tContractManageInfo).Where("volc_contract_id = ?", oldId).Update("volc_contract_id", newId).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangeVolcContractIdFail, id:%d, err:%s", oldId, err.Error())
		return i18nfmt.New(ctx, "ChangeVolcContractIdFail")
	}
	return nil
}

func (c *contractManageDaoImpl) FindByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) (*model.VolcContractManage, error) {

	versions := buildContractVersions(version)

	logs.CtxInfo(ctx, "FindByNo, no=%s, versions=%v", contractNo, versions)

	db := initDB(ctx, tx).Table(tContractManageInfo).Where("contract_no = ? and version in (?)", contractNo, versions)

	var ret model.VolcContractManage

	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByNoFail, contract_no=%s, err=%s", contractNo, err.Error())
		return nil, i18nfmt.New(ctx, "FindByNoFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

func (c *contractManageDaoImpl) FindByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (*model.VolcContractManage, error) {
	logs.CtxInfo(ctx, "FindByVolcContractId, volcContractId=%v", volcContractId)

	db := initDB(ctx, tx).Table(tContractManageInfo).
		Where("volc_contract_id = ?", volcContractId)

	var ret model.VolcContractManage

	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByVolcContractIdFail, volcContractId=%v, err=%s", volcContractId, err.Error())
		return nil, i18nfmt.New(ctx, "FindByVolcContractIdFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

func (c *contractManageDaoImpl) DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error {

	if len(ids) == 0 {
		return i18nfmt.New(ctx, "NO ids")
	}

	db := initDB(ctx, tx).Table(tContractManageInfo).Where("id in (?)", ids)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractManageDaoImpl) DeleteByNo(ctx context.Context, tx *gorm.DB, contractNo string, version int) error {

	if len(contractNo) == 0 {
		return i18nfmt.New(ctx, "NO ids")
	}

	versions := buildContractVersions(version)

	logs.CtxInfo(ctx, "DeleteByNo, no=%s, versions=%v", contractNo, versions)

	db := initDB(ctx, tx).Table(tContractManageInfo).Where("contract_no = ? and version in (?)", contractNo, versions)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractManageDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) ([]*model.VolcContractManage, error) {
	db := initDB(ctx, tx).Table(tContractManageInfo).Where("id >= ?", startID)
	var list []*model.VolcContractManage
	err := db.Order("id asc").Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

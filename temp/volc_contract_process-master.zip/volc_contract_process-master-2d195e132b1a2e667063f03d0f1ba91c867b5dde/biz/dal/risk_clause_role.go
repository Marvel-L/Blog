package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tRiskClauseRole = "risk_clause_role"
)

type RiskClauseRoleDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.RiskClauseRoleDB) error
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseRoleDB) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	UpdateByIds(ctx context.Context, tx *gorm.DB, ids []int64, params map[string]interface{}) error
	List(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseRoleReq) (model.RiskClauseRoleDBList, int, error)
	ListByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (model.RiskClauseRoleDBList, error)
	ListByApproveId(ctx context.Context, tx *gorm.DB, approveId string) (model.RiskClauseRoleDBList, error)
	DeleteById(ctx context.Context, tx *gorm.DB, id, volcContractId int64) error
}

var _riskClauseRoleDaoInstance = &riskClauseRoleDaoImpl{}

func NewRiskClauseRoleDao() RiskClauseRoleDao {
	return _riskClauseRoleDaoInstance
}

type riskClauseRoleDaoImpl struct {
}

func (r riskClauseRoleDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.RiskClauseRoleDB) error {
	err := initDB(ctx, tx).Table(tRiskClauseRole).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createRiskClauseRoleFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createRiskClauseRoleFail")
	}
	return nil
}

func (c *riskClauseRoleDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.RiskClauseRoleDB) error {
	err := initDB(ctx, tx).Table(tRiskClauseRole).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreateRiskClauseRoleFail, err:%s", err.Error())
		return i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "batchCreateRiskClauseRoleFail, err:%v", err))
	}
	return nil
}

func (r riskClauseRoleDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tRiskClauseRole)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (r riskClauseRoleDaoImpl) UpdateByIds(ctx context.Context, tx *gorm.DB, ids []int64, params map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tRiskClauseRole)
	err := db.Where("id in (?)", ids).Updates(params).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, ids=%v, err:%v", ids, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (r riskClauseRoleDaoImpl) DeleteById(ctx context.Context, tx *gorm.DB, id, volcContractId int64) error {
	db := initDB(ctx, tx).Table(tRiskClauseRole)
	err := db.Where("id = ? and volc_contract_id = ?", id, volcContractId).Updates(map[string]interface{}{"is_deleted": 1}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteByIdFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "DeleteByIdFail")
	}
	return nil
}

func (r riskClauseRoleDaoImpl) ListByVolcContractId(ctx context.Context, tx *gorm.DB, volcContractId int64) (model.RiskClauseRoleDBList, error) {
	db := initDB(ctx, tx).Table(tRiskClauseRole).Where("volc_contract_id = ?", volcContractId).Where("is_deleted = 0")

	var list model.RiskClauseRoleDBList
	err := db.Order("risk_clause_role.id").Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListRiskClauseRoleFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListRiskClauseRoleFail")
	}

	return list, nil
}

func (r riskClauseRoleDaoImpl) ListByApproveId(ctx context.Context, tx *gorm.DB, approveId string) (model.RiskClauseRoleDBList, error) {
	db := initDB(ctx, tx).Table(tRiskClauseRole).Where("approve_id = ?", approveId).Where("is_deleted = 0")

	var list model.RiskClauseRoleDBList
	err := db.Order("risk_clause_role.id").Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListRiskClauseRoleFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListRiskClauseRoleFail")
	}

	return list, nil
}

func (r riskClauseRoleDaoImpl) List(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseRoleReq) (model.RiskClauseRoleDBList, int, error) {
	var total int64
	var err error

	db := r.buildQuery(ctx, tx, req)

	if req.NeedTotal {
		if err := db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListRiskClauseRoleCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListRiskClauseRoleCountFail")
		}
	}

	var list model.RiskClauseRoleDBList

	query := db.Order("risk_clause_role.id").Offset(req.Offset)
	// 只有当req.Limit不为0时，才添加Limit条件
	if req.Limit != 0 {
		query = query.Limit(req.Limit)
	}
	err = query.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListRiskClauseRoleFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListRiskClauseRoleFail")
	}

	return list, int(total), nil
}

func (p *riskClauseRoleDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseRoleReq) *gorm.DB {

	db := initDB(ctx, tx).Table(tRiskClauseRole).Where("volc_contract_id = ?", req.VolcContractId)

	if req.RiskClauseType > 0 {
		db = db.Where("risk_clause_type = ?", req.RiskClauseType)
	}
	if len(req.RiskLevel) > 0 {
		db = db.Where("risk_level = ?", req.RiskLevel)
	}
	if req.Status != nil {
		db = db.Where("status = ?", *req.Status)
	}
	if len(req.ApproveId) > 0 {
		db = db.Where("approve_id = ?", req.ApproveId)
	}
	db = db.Where("is_deleted = 0")

	return db
}

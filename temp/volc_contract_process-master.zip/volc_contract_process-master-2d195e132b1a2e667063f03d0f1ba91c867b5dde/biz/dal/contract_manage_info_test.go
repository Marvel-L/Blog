package dal

import (
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
)

type Mock_Dialector_Target struct {
	gorm.Dialector
}

func Test_contractManageDaoImpl_UpdateByMap_BitsUTGen(t *testing.T) {
	t.Run("Return nil on success update", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocked DB chain that leads to nil error
			startDB := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(startDB).Build()
			startDB.Error = nil

			c := &contractManageDaoImpl{}
			ctx := context.Background()
			updateMap := map[string]interface{}{"status": "ok"}
			err := c.UpdateByMap(ctx, nil, int64(123), updateMap)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return nil on record not found error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocked DB chain that returns ErrRecordNotFound which should be ignored
			startDB := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(startDB).Build()
			startDB.Error = gorm.ErrRecordNotFound

			c := &contractManageDaoImpl{}
			ctx := context.Background()
			updateMap := map[string]interface{}{"status": "missing"}
			err := c.UpdateByMap(ctx, nil, int64(456), updateMap)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Return i18n error on update failure", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocked DB chain that returns a normal error which should not be ignored
			startDB := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Where).Return(startDB).Build()
			mockey.MockUnsafe((*gorm.DB).Updates).Return(startDB).Build()
			startDB.Error = errors.New("database update failed")

			// Avoid nil-pointer in logs default logger
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			c := &contractManageDaoImpl{}
			ctx := context.Background()
			updateMap := map[string]interface{}{"status": "fail"}
			err := c.UpdateByMap(ctx, nil, int64(789), updateMap)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "updateContractManageByMapFail")
		})
	})
}

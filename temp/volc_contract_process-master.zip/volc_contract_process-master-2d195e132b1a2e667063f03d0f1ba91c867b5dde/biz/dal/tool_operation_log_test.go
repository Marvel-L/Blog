package dal

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_toolOperationLogDaoImpl_Create_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("toolOperationLogDaoImpl.Create 单元测试", t, func() {
		mockey.PatchConvey("操作日志参数为nil，返回国际化错误", func() {
			// 构造dao与上下文
			dao := &toolOperationLogDaoImpl{}
			ctx := context.Background()

			// 直接触发nil分支
			err := dao.Create(ctx, nil, nil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "tool_operation_log_is_nil")
		})

		mockey.PatchConvey("创建失败返回错误", func() {
			// 构造dao与上下文
			dao := &toolOperationLogDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// 为避免真实gorm内部逻辑，打桩Table与Create
			mockey.MockUnsafe((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Create).Return(&gorm.DB{Error: errors.New("db create failed")}).Build()

			// 避免日志默认logger为空导致的panic
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			op := &model.ToolOperationLogDB{ContractNo: "CN-FAILED"}
			err := dao.Create(ctx, tx, op)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ToolOperationLogCreateFail")
		})

		mockey.PatchConvey("创建成功（忽略RecordNotFound）返回nil", func() {
			// 构造dao与上下文
			dao := &toolOperationLogDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			// 打桩Table与Create，返回RecordNotFound以触发ignoreErr分支返回nil
			mockey.MockUnsafe((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.MockUnsafe((*gorm.DB).Create).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			op := &model.ToolOperationLogDB{ContractNo: "CN-OK"}
			err := dao.Create(ctx, tx, op)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

package dal

import (
	"context"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
)

func Test_bizContractDaoImpl_List_ByteUTGen(t *testing.T) {
	t.Run("ListWithNeedTotalAndLimit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// [目标分支] ignoreErrRet1Mock == nil
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock((*gorm.DB).Offset, mockey.OptUnsafe).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			mockey.Mock((*gorm.DB).Limit, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{}).Build()
			mockey.Mock((*bizContractDaoImpl).buildQuery).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{Dialector: nil}}).Build()
			// 构造函数入参
			var receiver *bizContractDaoImpl = &bizContractDaoImpl{}
			var ctxTest context.Context = context.Background()
			var txTest *gorm.DB = &gorm.DB{Config: &gorm.Config{Dialector: nil}}
			// [目标分支] reqTest.NeedTotal == true && reqTest.Limit != 0
			var reqTest *model.BizContractReq = &model.BizContractReq{
				Offset:    10,
				NeedTotal: true,
				Limit:     1,
			}
			// 运行被测函数
			got1, got2, err := receiver.List(ctxTest, txTest, reqTest)
			// 在调用Find方法时，只是进行了mock返回，没有实际的数据填充到list中，所以返回的列表长度为0
			convey.So(len(got1), convey.ShouldEqual, 0)
			// 虽然在代码中有统计总数的逻辑，但没有对总数进行赋值操作，所以总数total初始化为0，最终返回的总数也为0
			convey.So(got2, convey.ShouldEqual, 0)
			// 通过mock函数，ignoreErr函数返回nil，不会触发错误返回逻辑，因此预期返回的错误为nil
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

package dal

import (
	"context"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tPreContractReviewer = "pre_contract_reviewer"
)

type PreContractReviewerDao interface {
	BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error
	FindReviewersByNo(ctx context.Context, tx *gorm.DB, preContractNo string) (model.PreContractReviewerDBList, error)
	FindReviewersByNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string) (map[string]model.PreContractReviewerDBList, error)
	FindSoftDeleteReviewersByNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string) (map[string]model.PreContractReviewerDBList, error)
	FindReviewersByReviewerAndNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string, operator string) (map[string]model.PreContractReviewerDBList, error)
	FindReviewersByNoAndReviewerType(ctx context.Context, tx *gorm.DB, preContractNoList []string, reviewerType int) (model.PreContractReviewerDBList, error)
	IsSoftDeleteReviewerByNoAndEmail(ctx context.Context, tx *gorm.DB, preContractNo, reviewer string) (bool, error)
	ListSoftDeleteReviewerByNo(ctx context.Context, tx *gorm.DB, preContractNo string) (model.PreContractReviewerDBList, error)
	ResetReviewerStatus(ctx context.Context, tx *gorm.DB, preContractNo string, contractStatusList []int) error
	// 在线协同
	Create(ctx context.Context, tx *gorm.DB, entity *model.PreContractReviewerDB) error
	UpdateByID(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error
	BatchReplaceReviewer(ctx context.Context, tx *gorm.DB, newEmail string, newID string, preContractNo string, ids []uint64) error
	BatchDeleteReviewer(ctx context.Context, tx *gorm.DB, preContractNo string, ids []uint64) error
	UpdateNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error
	FindAccessibleNoList(ctx context.Context, tx *gorm.DB, reviewer string, idRoleList [][]interface{}, nameRoleList [][]interface{}) ([]string, error)
	FindReviewersByNoAndEmail(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error)
	HaveViewPerm(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (bool, error)
	SoftDeleteCountersignReviewer(ctx context.Context, tx *gorm.DB, preContractNo string, contractStatus int) error
	DeleteReviewersByType(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType []int, contractStatusList ...int) error
	DeleteChangedReviewer(ctx context.Context, tx *gorm.DB, reviewer string, preContractNo string) error
	ReplaceReviewerByOldInfo(ctx context.Context, tx *gorm.DB, params *model.ReplaceReviewerByOldInfoReq) (int64, error)
}

var _preContractReviewerDaoInstance = &preContractReviewerDaoImpl{}

func NewPreContractReviewerDao() PreContractReviewerDao {
	return _preContractReviewerDaoInstance
}

type preContractReviewerDaoImpl struct {
}

// DeleteChangedReviewer 删除转办人员审批权限
func (p *preContractReviewerDaoImpl) DeleteChangedReviewer(ctx context.Context, tx *gorm.DB, reviewer string, preContractNo string) error {
	if len(reviewer) == 0 || len(preContractNo) == 0 {
		return nil
	}
	err := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", preContractNo).
		Where("reviewer = ?", reviewer).
		Where("reviewer_type not in (?)", _const.ReviewerTypeMentioned). // 仅保留当前用户被艾特的角色,其余角色删除
		Where("is_deleted = ?", 0).
		// Where("status = ? ", _const.ReviewStatusChangeReviewer).
		Delete(nil).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteChangedReviewerFail, reviewer:%s, contractNo:%s, err:%v", reviewer, preContractNo, err)
		return i18nfmt.New(ctx, "DeleteChangedReviewerFail")
	}
	return nil
}

// ReplaceReviewerByOldInfo 按 pre_contract_no + reviewer + reviewer_id 精确替换审批人
func (p *preContractReviewerDaoImpl) ReplaceReviewerByOldInfo(ctx context.Context, tx *gorm.DB, params *model.ReplaceReviewerByOldInfoReq) (int64, error) {
	if params == nil || len(params.PreContractNo) == 0 || len(params.OldReviewerEmail) == 0 || len(params.OldReviewerID) == 0 {
		return 0, nil
	}
	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", params.PreContractNo).
		Where("reviewer = ?", params.OldReviewerEmail).
		Where("reviewer_id = ?", params.OldReviewerID).
		Where("is_deleted = ?", 0)
	if params.ContractStatus != nil {
		db = db.Where("contract_status = ?", *params.ContractStatus)
	}
	res := db.Updates(map[string]interface{}{
		"reviewer":    params.NewReviewerEmail,
		"reviewer_id": params.NewReviewerID,
	})
	if ignoreErr(res.Error) != nil {
		logs.CtxError(ctx, "ReplaceReviewerByOldInfoFail, pre_contract_no:%s, err:%v", params.PreContractNo, res.Error)
		return 0, i18nfmt.New(ctx, "ReplaceReviewerByOldInfoFail")
	}
	return res.RowsAffected, nil
}

func (p *preContractReviewerDaoImpl) DeleteReviewersByType(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType []int, contractStatusList ...int) error {

	if len(reviewerType) == 0 || len(preContractNo) == 0 {
		return nil
	}

	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no = ?", preContractNo).
		Where("reviewer_type in (?)", reviewerType).Where("is_deleted =?", 0)
	if len(contractStatusList) > 0 {
		db = db.Where("contract_status in (?)", contractStatusList)
	}

	if err := db.Delete(nil).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "DeleteReviewersByTypeFail, err:%v", err)
		return i18nfmt.New(ctx, "DeleteReviewersByTypeFail")
	}

	return nil
}

// SoftDeleteCountersignReviewer 软删除指定节点加签审核人
func (p *preContractReviewerDaoImpl) SoftDeleteCountersignReviewer(ctx context.Context, tx *gorm.DB, preContractNo string, contractStatus int) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", preContractNo).
		Where("contract_status = ?", contractStatus).
		Where("reviewer_source != ?", 0).
		Updates(map[string]interface{}{"is_deleted": _const.TRUE_FLAG_INT}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "SoftDeleteCountersignReviewerFail, preContractNo:%s, contractStatus:%d, err:%v", preContractNo, contractStatus, err)
		return i18nfmt.New(ctx, "DeleteChangedReviewerFail")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) HaveViewPerm(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (bool, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no = ?", preContractNo).Where("reviewer = ?", reviewer)
	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "HaveViewPermFail, contract_no:%s, err:%s", preContractNo, err.Error())
		return false, i18nfmt.New(ctx, "HaveViewPermFail")
	}
	return len(list) > 0, nil
}

func (p *preContractReviewerDaoImpl) FindReviewersByNoAndEmail(ctx context.Context, tx *gorm.DB, preContractNo string, reviewer string) (model.PreContractReviewerDBList, error) {
	var ret model.PreContractReviewerDBList

	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no = ?", preContractNo).
		Where("reviewer = ?", reviewer).Where("is_deleted = ?", 0)
	if err := db.Find(&ret).Error; ignoreErr(err) != nil {
		return nil, err
	}

	return ret, nil
}

func (p *preContractReviewerDaoImpl) FindAccessibleNoList(ctx context.Context, tx *gorm.DB, reviewer string, idRoleList [][]interface{}, nameRoleList [][]interface{}) ([]string, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).Select("distinct pre_contract_no").Where("reviewer = ? ", reviewer)
	if len(idRoleList) > 0 {
		db = db.Or("(department, reviewer_role) IN ?", idRoleList)
	}
	if len(nameRoleList) > 0 {
		db = db.Or("(department, reviewer_role) IN ?", nameRoleList)
	}
	var list []*model.PreContractNoVO
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "QueryPreContractNoFail, reviewer:%s, err:%s", reviewer, err.Error())
		return nil, i18nfmt.New(ctx, "QueryPreContractNoFail")
	}
	ret := make([]string, len(list))
	for idx, v := range list {
		ret[idx] = v.PreContractNo
	}
	return ret, nil
}

func (p *preContractReviewerDaoImpl) UpdateNo(ctx context.Context, tx *gorm.DB, oldNo string, newNo string) error {

	err := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no = ?", oldNo).
		Updates(map[string]interface{}{"pre_contract_no": newNo}).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "RecordUpdateNoFail, err: %v", err)
		return i18nfmt.New(ctx, "RecordUpdateNoFail")
	}

	return nil
}

func (p *preContractReviewerDaoImpl) BatchDeleteReviewer(ctx context.Context, tx *gorm.DB, preContractNo string, ids []uint64) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", preContractNo).
		Where("id IN ?", ids).
		Delete(nil).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "BatchReplaceReviewer, err:%s", err.Error())
		return i18nfmt.New(ctx, "BatchReplaceReviewer error")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) BatchReplaceReviewer(ctx context.Context, tx *gorm.DB, newEmail string, newID string, preContractNo string, ids []uint64) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", preContractNo).
		Where("id IN ?", ids).
		Where("is_deleted = ?", 0).
		Updates(map[string]interface{}{
			"reviewer":    newEmail,
			"reviewer_id": newID,
		}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "BatchReplaceReviewer, err:%s", err.Error())
		return i18nfmt.New(ctx, "BatchReplaceReviewer error")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) UpdateByID(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByIDFail, err:%s", err.Error)
		return i18nfmt.New(ctx, "UpdateByIDFail")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) Create(ctx context.Context, tx *gorm.DB, preContractReviewerDB *model.PreContractReviewerDB) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).Create(preContractReviewerDB).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createPreReviewerFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createPreReviewerFail")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) BatchCreate(ctx context.Context, tx *gorm.DB, entities []*model.PreContractReviewerDB) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).CreateInBatches(entities, len(entities)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "batchCreatePreReviewerFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "batchCreatePreReviewerFail")
	}
	return nil
}

func (p *preContractReviewerDaoImpl) FindReviewersByNo(ctx context.Context, tx *gorm.DB, preContractNo string) (model.PreContractReviewerDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", preContractNo).Where("is_deleted = ?", 0)
	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "QueryReviewerListFail, contract_no:%s, err:%s", preContractNo, err.Error())
		return nil, i18nfmt.New(ctx, "QueryReviewerListFail")
	}
	return list, nil
}

func (p *preContractReviewerDaoImpl) FindReviewersByNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string) (map[string]model.PreContractReviewerDBList, error) {

	if len(preContractNoList) == 0 {
		return nil, nil
	}

	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no in (?)", preContractNoList).Where("is_deleted = ?", 0)
	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindReviewersByNoListFail, contract_nos:%s, err:%s", preContractNoList, err.Error())
		return nil, i18nfmt.New(ctx, "FindReviewersByNoListFail")
	}

	// 按pre_contract_no分组
	ret := map[string]model.PreContractReviewerDBList{}
	for _, v := range list {
		ret[v.PreContractNo] = append(ret[v.PreContractNo], v)
	}
	return ret, nil
}

func (p *preContractReviewerDaoImpl) FindSoftDeleteReviewersByNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string) (map[string]model.PreContractReviewerDBList, error) {

	if len(preContractNoList) == 0 {
		return nil, nil
	}

	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no in (?)", preContractNoList).Where("is_deleted = ?", 1)
	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindReviewersByNoListFail, contract_nos:%s, err:%s", preContractNoList, err.Error())
		return nil, i18nfmt.New(ctx, "FindReviewersByNoListFail")
	}

	// 按pre_contract_no分组
	ret := map[string]model.PreContractReviewerDBList{}
	for _, v := range list {
		ret[v.PreContractNo] = append(ret[v.PreContractNo], v)
	}
	return ret, nil
}

func (p *preContractReviewerDaoImpl) FindReviewersByReviewerAndNoList(ctx context.Context, tx *gorm.DB, preContractNoList []string, operator string) (map[string]model.PreContractReviewerDBList, error) {

	if len(preContractNoList) == 0 {
		return nil, nil
	}

	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no in (?)", preContractNoList).
		Where("reviewer = ?", operator).Where("is_deleted = ?", 0)

	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindReviewersByNoListFail, contract_nos:%s, err:%s", preContractNoList, err.Error())
		return nil, i18nfmt.New(ctx, "FindReviewersByNoListFail")
	}

	// 按pre_contract_no分组
	ret := map[string]model.PreContractReviewerDBList{}
	for _, v := range list {
		ret[v.PreContractNo] = append(ret[v.PreContractNo], v)
	}
	return ret, nil
}

func (p *preContractReviewerDaoImpl) FindReviewersByNoAndReviewerType(ctx context.Context, tx *gorm.DB, preContractNoList []string, reviewerType int) (model.PreContractReviewerDBList, error) {

	var ret model.PreContractReviewerDBList

	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no in (?)", preContractNoList).
		Where("reviewer_type = ?", reviewerType).Where("is_deleted = ?", 0)
	if err := db.Find(&ret).Error; ignoreErr(err) != nil {
		return nil, err
	}

	return ret, nil
}

func (p *preContractReviewerDaoImpl) ListSoftDeleteReviewerByNo(ctx context.Context, tx *gorm.DB, preContractNo string) (model.PreContractReviewerDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no =?", preContractNo).
		Where("is_deleted = ?", 1)
	var list model.PreContractReviewerDBList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "QueryReviewerListFail, contract_no:%s, err:%s", preContractNo, err.Error())
		return nil, i18nfmt.New(ctx, "QueryReviewerListFail")
	}
	return list, nil
}

func (p *preContractReviewerDaoImpl) IsSoftDeleteReviewerByNoAndEmail(ctx context.Context, tx *gorm.DB, preContractNo, reviewer string) (bool, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).Where("pre_contract_no = ?", preContractNo).
		Where("is_deleted = ?", 1).Where("reviewer = ?", reviewer)
	var count int64
	if err := db.Count(&count).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "CountSoftDeleteReviewerFail, contract_no:%s, reviewer:%s, err:%s", preContractNo, reviewer, err.Error())
		return false, i18nfmt.New(ctx, "CountSoftDeleteReviewerFail")
	}
	return count > 0, nil
}

// ResetReviewerStatus 将指定协商节点的审批状态重置为：未审核
func (p *preContractReviewerDaoImpl) ResetReviewerStatus(ctx context.Context, tx *gorm.DB, preContractNo string, contractStatusList []int) error {
	err := initDB(ctx, tx).Table(tPreContractReviewer).Where(
		"pre_contract_no = ? and contract_status in (?)", preContractNo, contractStatusList).Updates(map[string]interface{}{"status": _const.ReviewStatusUnreviewed}).Error
	return err
}

// UpdateReviewerStatus /**更新操作表状态
func UpdateReviewerStatus(ctx context.Context, tx *gorm.DB, param *model.UpdateReviewerStatusReq) error {

	db := initDB(ctx, tx).Table(tPreContractReviewer)

	err := db.Where("pre_contract_no = ?", param.PreContractNO).
		Where("reviewer = ?", param.Reviewer).
		Where("contract_status in (?)", []int{param.ContractStatus, 0}). //
		Where("is_deleted = ?", 0).
		Where("reviewer_type = ?", param.ReviewerType).
		Updates(map[string]interface{}{
			"status":             param.Status,
			"skip_return_review": param.SkipReturnReview,
		}).Error

	return ignoreErr(err)
}

// IsAllReviewerTypePassed /**当前审批类型是否都已执行完毕
func IsAllReviewerTypePassed(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType int, contractStatus int) (bool, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer)

	var pendingCount int64
	err := db.Where("pre_contract_no = ?", preContractNo).
		Where("reviewer_type = ?", reviewerType).
		Where("contract_status = ?", contractStatus).
		Where("is_deleted = ?", 0).
		Where("status not in (?)", []int{
			// 此处待优化 由业务自行判断
			_const.ReviewStatusReviewPass, // 通过
			// _const.ReviewStatusAddReviewers,   // 加签
			_const.ReviewStatusChangeReviewer, // 转办
			_const.ReviewStatusSubmitChange,   // 提交修改
			_const.ReviewStatusFinalized,      // 可定稿
		}).
		Count(&pendingCount).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "queryContractReviewerListFail, err:%v", err)
		return false, err
	}

	return pendingCount == 0, nil
}

// IsAllReviewerTypePassed /**当前审批类型是否都已执行完毕
func IsAllNoMasterReviewerTypePassed(ctx context.Context, tx *gorm.DB, preContractNo string, reviewerType int, contractStatus int) (bool, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer)

	var pendingCount int64
	err := db.Where("pre_contract_no = ?", preContractNo).
		Where("reviewer_type = ?", reviewerType).
		Where("contract_status = ?", contractStatus).
		Where("reviewer_source != ?", 0).
		Where("is_deleted = ?", 0).
		Where("status not in (?)", []int{
			// 此处待优化 由业务自行判断
			_const.ReviewStatusReviewPass, // 通过
			// _const.ReviewStatusAddReviewers,   // 加签
			_const.ReviewStatusChangeReviewer, // 转办
			_const.ReviewStatusSubmitChange,   // 提交修改
			_const.ReviewStatusFinalized,      // 可定稿
		}).
		Count(&pendingCount).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "queryContractReviewerListFail, err:%v", err)
		return false, err
	}

	return pendingCount == 0, nil
}

// ListHighPriorityReviewerTypeNoPassedReviewer 获取所有未审核通过的指定审批优先级以上的审核人
func ListHighPriorityReviewerTypeNoPassedReviewer(ctx context.Context, tx *gorm.DB, req *model.ListPreContractReviewerReq) (model.PreContractReviewerDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", req.PreContractNo).
		Where("reviewer_type = ?", req.ReviewerType).
		Where("contract_status = ?", req.ContractStatus).
		Where("priority > ?", req.Priority).
		Where("is_deleted = ?", 0).
		Where("status not in (?)", []int{
			// 此处待优化 由业务自行判断
			_const.ReviewStatusReviewPass, // 通过
			// _const.ReviewStatusAddReviewers,   // 加签
			_const.ReviewStatusChangeReviewer, // 转办
			_const.ReviewStatusSubmitChange,   // 提交修改
			_const.ReviewStatusFinalized,      // 可定稿
		})

	var list model.PreContractReviewerDBList
	err := db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListHighPriorityReviewerTypeNoPassedReviewerFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListHighPriorityReviewerTypeNoPassedReviewerFail")
	}

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "queryContractReviewerListFail, err:%v", err)
		return nil, err
	}

	return list, nil
}

// ListNotPassedReviewerByPriority 获取所有未审核通过的指定审批优先级的审核人
func ListNotPassedReviewerByPriority(ctx context.Context, tx *gorm.DB, req *model.ListPreContractReviewerReq) (model.PreContractReviewerDBList, error) {
	db := initDB(ctx, tx).Table(tPreContractReviewer).
		Where("pre_contract_no = ?", req.PreContractNo).
		Where("reviewer_type = ?", req.ReviewerType).
		Where("contract_status = ?", req.ContractStatus).
		Where("priority = ?", req.Priority).
		Where("is_deleted = ?", 0).
		Where("status not in (?)", []int{
			// 此处待优化 由业务自行判断
			_const.ReviewStatusReviewPass, // 通过
			// _const.ReviewStatusAddReviewers,   // 加签
			_const.ReviewStatusChangeReviewer, // 转办
			_const.ReviewStatusSubmitChange,   // 提交修改
			_const.ReviewStatusFinalized,      // 可定稿
		})

	var list model.PreContractReviewerDBList
	err := db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListNotPassedReviewerByPriorityFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListNotPassedReviewerByPriorityFail")
	}

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "queryContractReviewerListFail, err:%v", err)
		return nil, err
	}

	return list, nil
}

// CreatePreContractReviewer Create
func CreatePreContractReviewer(ctx context.Context, tx *gorm.DB, preContractReviewerDB *model.PreContractReviewerDB) error {
	return ignoreErr(initDB(ctx, tx).Table(tPreContractReviewer).Create(preContractReviewerDB).Error)
}

func ResetReviewerStatusByReviewerType(ctx context.Context, tx *gorm.DB, param *model.ResetReviewerStatusByReviewerTypeReq) error {

	db := initDB(ctx, tx).Table(tPreContractReviewer)

	db = db.Where("pre_contract_no = ?", param.PreContractNO).
		Where("reviewer_type = ?", param.ReviewerType).
		Where("contract_status in (?)", []int{param.ContractStatus, 0}). //
		Where("is_deleted = ?", 0)
	if len(param.SkipReturnReviewNoAuditEmails) > 0 {
		db = db.Where("reviewer not in (?)", param.SkipReturnReviewNoAuditEmails)
	}

	err := db.Updates(map[string]interface{}{
		"status":             _const.ReviewStatusUnreviewed,
		"skip_return_review": _const.SkipReturnReviewTypeNone,
		"priority":           0,
	}).Error

	return ignoreErr(err)
}

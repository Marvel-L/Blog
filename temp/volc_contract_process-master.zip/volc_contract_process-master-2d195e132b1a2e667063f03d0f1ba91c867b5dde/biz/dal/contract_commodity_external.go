package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/bizmodels/modelcommodity"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/util"
)

const (
	tContractCommodityExternal = "volc_contract_commodity_external"
)

type ContractCommodityExternalDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractCommodityExternal) error
	CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.VolcContractCommodityExternal) error
	DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error
	DeleteByVolcContractID(ctx context.Context, tx *gorm.DB, volcContractID int64) error
	ListByVolcContractID(ctx context.Context, tx *gorm.DB, volcContractID int64) (model.VolcContractCommodityExternalList, error)
	ListContractCommodity(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) (model.VolcContractCommodityExternalList, int, error)
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.VolcContractCommodityExternalList, error)
	UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error
}

func NewContractCommodityExternalDao() ContractCommodityExternalDao {
	return &contractCommodityExternalDaoImpl{}
}

type contractCommodityExternalDaoImpl struct {
}

func (c *contractCommodityExternalDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.VolcContractCommodityExternal) error {
	err := initDB(ctx, tx).Table(tContractCommodityExternal).Save(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractCommodityFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractCommodityFail")
	}
	return nil
}

func (c *contractCommodityExternalDaoImpl) CreateInBatches(ctx context.Context, tx *gorm.DB, list []*model.VolcContractCommodityExternal) error {
	err := initDB(ctx, tx).Table(tContractCommodityExternal).CreateInBatches(list, len(list)).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractCommodityFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractCommodityFail")
	}
	return nil
}

func (c *contractCommodityExternalDaoImpl) DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error {
	if len(ids) == 0 {
		return i18nfmt.New(ctx, "NO ids")
	}

	db := initDB(ctx, tx).Table(tContractCommodityExternal).Where("id in (?)", ids)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractCommodityExternalDaoImpl) DeleteByVolcContractID(ctx context.Context, tx *gorm.DB, volcContractID int64) error {
	if volcContractID == 0 {
		return i18nfmt.New(ctx, "NO volcContractId")
	}

	logs.CtxInfo(ctx, "DeleteByVolcContractID, volcContractId=%d", volcContractID)

	db := initDB(ctx, tx).Table(tContractCommodityExternal).Where("volc_contract_id = ?", volcContractID)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractCommodityExternalDaoImpl) ListByVolcContractID(ctx context.Context, tx *gorm.DB, volcContractID int64) (model.VolcContractCommodityExternalList, error) {

	db := initDB(ctx, tx).Table(tContractCommodityExternal).
		Where("volc_contract_id = ?", volcContractID)

	var list model.VolcContractCommodityExternalList
	if err := db.Find(&list).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByVolcContractIdFail, volcContractId:%d, err:%s", volcContractID, err.Error())
		return nil, i18nfmt.New(ctx, "ListByVolcContractIdFail")
	}

	return list, nil
}

func (c *contractCommodityExternalDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.VolcContractCommodityExternalList, error) {
	db := initDB(ctx, tx).Table(tContractCommodityExternal).Where("id >= ?", startID)
	var list model.VolcContractCommodityExternalList
	err := db.Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractCommodityExternalDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tContractCommodityExternal)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (c *contractCommodityExternalDaoImpl) ListContractCommodity(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) (model.VolcContractCommodityExternalList, int, error) {
	var total int64
	var err error

	db := c.buildQuery(ctx, tx, param)

	if param.NeedTotal {
		if err = db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListContractCommodityCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListContractCommodityCountFail")
		}
	}

	// 分页逻辑兼容
	if param.Limit > 0 {
		db = db.Limit(param.Limit)
		db = db.Offset(param.Offset)
	}

	var list model.VolcContractCommodityExternalList
	err = db.Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListContractCommodityFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListContractCommodityFail")
	}

	return list, int(total), nil
}

func (c *contractCommodityExternalDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, param *modelcommodity.CommodityListParam) *gorm.DB {
	db := initDB(ctx, tx).Table(tContractCommodityExternal)

	if param.VolcContractId > 0 {
		db.Where("volc_contract_id = ?", param.VolcContractId)
	}
	if len(param.VolcContractIdList) > 0 {
		db.Where("volc_contract_id in (?)", param.VolcContractIdList)
	}
	if len(param.TradeProductName) > 0 {
		db = db.Where("trade_product_name like ?", util.GenLikeStr(param.TradeProductName))
	}
	if len(param.TradeProductNameList) > 0 {
		db = db.Where("trade_product_name in (?)", param.TradeProductNameList)
	}

	if param.StartId > 0 {
		// 由于查询是按创建时间降序，所以如果指定startID时，需要按递减逻辑
		db = db.Where("id < ?", param.StartId)
		// 仅在包含StartID参数时生效
		db = db.Order("id desc")
	} else {
		// 注意
		db = db.Order("id desc")
	}

	return db
}

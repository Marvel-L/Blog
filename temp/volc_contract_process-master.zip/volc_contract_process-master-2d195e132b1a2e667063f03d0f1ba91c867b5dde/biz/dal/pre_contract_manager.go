package dal

import (
	"context"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tPreContractManager = "pre_contract_manager"
)

type PreContractManagerDao interface {
	GetAllManager(ctx context.Context, tx *gorm.DB) ([]*model.PreContractManagerDB, error)
	CreateOrUpdate(ctx context.Context, tx *gorm.DB, entity *model.PreContractManagerDB) error
	FindByMail(ctx context.Context, tx *gorm.DB, email string) (*model.PreContractManagerDB, error)
	ChangePreContractNo(ctx context.Context, tx *gorm.DB, oldPreContractNo string, newPreContractNo string) error
}

var _preContractManagerDaoImplInstance = &preContractManagerDaoImpl{}

func NewPreContractManagerDao() PreContractManagerDao {
	return _preContractManagerDaoImplInstance
}

type preContractManagerDaoImpl struct {
}

func (p *preContractManagerDaoImpl) ChangePreContractNo(ctx context.Context, tx *gorm.DB, oldPreContractNo string, newPreContractNo string) error {

	err := initDB(ctx, tx).Table(tPreContractManager).Where("pre_contract_no = ?", oldPreContractNo).
		Updates(map[string]interface{}{"pre_contract_no": newPreContractNo}).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangePreContractNoFail, err: %v", err)
		return i18nfmt.New(ctx, "ChangePreContractNoFail")
	}

	return nil
}

func (p *preContractManagerDaoImpl) GetAllManager(ctx context.Context, tx *gorm.DB) ([]*model.PreContractManagerDB, error) {

	var ret model.PreContractManagerDBList

	db := initDB(ctx, tx).Table(tPreContractManager)
	if err := db.Find(&ret).Error; ignoreErr(err) != nil {
		return nil, err
	}

	return ret, nil
}

func (p *preContractManagerDaoImpl) FindByMail(ctx context.Context, tx *gorm.DB, email string) (*model.PreContractManagerDB, error) {

	var ret model.PreContractManagerDB

	db := initDB(ctx, tx).Table(tPreContractManager).Where("manager_mail", email)

	if err := db.First(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByMailFail, email:%s, err:%s", email, err.Error())
		return nil, i18nfmt.New(ctx, "FindByMailFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

func (p *preContractManagerDaoImpl) CreateOrUpdate(ctx context.Context, tx *gorm.DB, entity *model.PreContractManagerDB) error {
	old, _ := p.FindByMail(ctx, tx, entity.ManagerMail)
	if old != nil {
		entity.Id = old.Id
		return initDB(ctx, tx).Table(tPreContractManager).Updates(entity).Error
	}
	return ignoreErr(initDB(ctx, tx).Table(tPreContractManager).Create(entity).Error)
}

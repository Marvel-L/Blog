package dal

import (
	"context"
	"errors"
	"testing"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/env"
	"volc_contract_process/pkg/proxy/dkmscli"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_freshSealApprovalDaoImpl_List_BitsUTGen(t *testing.T) {
	t.Run("正常查询返回列表和总数", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造完整查询条件以走到成功路径
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-001",
					AccountID:  "acc-001",
					Status:     "1,2",
					Limit:      10,
					Offset:     5,
				},
				ApplyIds: []string{"A1", "A2"},
			}

			// 打桩gorm方法，模拟所有查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			// ignoreErr返回nil表示无错误需要处理
			mockey.Mock(ignoreErr).Return(nil).Build()

			list, total, err := receiver.List(ctx, tx, param)
			// 期望成功：err应为nil，list与total应为查询结果（本测试中均为0/空）
			convey.So(len(list), convey.ShouldEqual, 0)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("筛选条件不足返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 条件不足：既无ContractNo、Status，也无ApplyIds且Limit为0
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			var tx *gorm.DB = nil
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "",
					Status:     "",
					Limit:      0,
				},
				ApplyIds: []string{},
			}

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("Count发生错误返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					Limit:  10,
					Status: "1",
				},
				ApplyIds: []string{"A1"},
			}

			// 模拟Count返回错误
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: errors.New("db count error")}).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db count error")
		})
	})

	t.Run("查询返回非忽略错误直接失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					Limit:  10,
					Status: "1",
				},
				ApplyIds: []string{"A1"},
			}

			// 前置查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			// Find返回错误，且ignoreErr不忽略该错误
			findErr := errors.New("db find error")
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: findErr}).Build()
			mockey.Mock(ignoreErr).Return(findErr).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "db find error")
		})
	})

	t.Run("参数为nil返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()

			list, total, err := receiver.List(ctx, nil, nil)
			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ListFail, param is nil")
		})
	})

	// 新增测试用例：仅使用AccountID条件查询
	t.Run("仅使用AccountID条件查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					AccountID: "acc-001",
					Limit:     10,
					Offset:    0,
				},
			}

			// 打桩gorm方法，模拟查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
			convey.So(total, convey.ShouldEqual, 0)
		})
	})

	// 新增测试用例：仅使用Status条件查询
	t.Run("仅使用Status条件查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					Status: "1,2,3",
					Limit:  10,
					Offset: 0,
				},
			}

			// 打桩gorm方法，模拟查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
			convey.So(total, convey.ShouldEqual, 0)
		})
	})

	// 新增测试用例：Limit=0不应用分页
	t.Run("Limit=0不应用分页", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-001",
					Limit:      0, // Limit=0不应用分页
					Offset:     5,
				},
			}

			// 打桩gorm方法，模拟查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			// 注意：Limit=0时不应该调用Limit和Offset方法
			// 这里我们依然mock它们，但不验证调用次数
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
			convey.So(total, convey.ShouldEqual, 0)
		})
	})

	// 新增测试用例：各种条件组合查询
	t.Run("各种条件组合查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-001",
					AccountID:  "acc-001",
					Status:     "1",
					Limit:      20,
					Offset:     10,
				},
				ApplyIds: []string{"A1"},
			}

			// 打桩gorm方法，模拟查询成功
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()

			list, total, err := receiver.List(ctx, tx, param)
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(list), convey.ShouldEqual, 0)
			convey.So(total, convey.ShouldEqual, 0)
		})
	})

	t.Run("查询成功并解密敏感数据", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-xyz",
					Limit:      5,
					Offset:     0,
				},
				ApplyIds: []string{"AX"},
			}

			// 构造查询返回的列表，包含一个nil元素用于覆盖nil分支
			records := model.FreshSealApprovalDBList{
				&model.FreshSealApprovalDB{ContactPhone: "ENC_PHONE", AddressInfo: "ENC_ADDR"},
				nil,
			}

			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if lp, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*lp = records
				}
				return &gorm.DB{Config: &gorm.Config{}, Error: nil}
			}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock(dkmscli.DecryptWithContext).Return(
				mockey.Sequence("DEC_PHONE", nil).Then("DEC_ADDR", nil),
			).Build()

			list, total, err := receiver.List(ctx, tx, param)

			convey.So(err, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(len(list), convey.ShouldEqual, 2)
			convey.So(list[0].ContactPhone, convey.ShouldEqual, "DEC_PHONE")
			convey.So(list[0].AddressInfo, convey.ShouldEqual, "DEC_ADDR")
			convey.So(list[1], convey.ShouldBeNil)
		})
	})

	t.Run("解密联系人电话失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-abc",
					Limit:      1,
				},
				ApplyIds: []string{"A1"},
			}

			records := model.FreshSealApprovalDBList{
				&model.FreshSealApprovalDB{ContactPhone: "ENC_PHONE", AddressInfo: ""},
			}

			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if lp, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*lp = records
				}
				return &gorm.DB{Config: &gorm.Config{}, Error: nil}
			}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock(dkmscli.DecryptWithContext).Return(
				mockey.Sequence("", errors.New("decrypt phone error")),
			).Build()

			list, total, err := receiver.List(ctx, tx, param)

			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "decrypt phone error")
		})
	})

	t.Run("解密地址信息失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{Config: &gorm.Config{}}
			param := &FreshSealListParamExt{
				FreshSealListParam: bizmodels.FreshSealListParam{
					ContractNo: "contract-def",
					Limit:      1,
				},
				ApplyIds: []string{"A2"},
			}

			records := model.FreshSealApprovalDBList{
				&model.FreshSealApprovalDB{ContactPhone: "ENC_PHONE", AddressInfo: "ENC_ADDR"},
			}

			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Config: &gorm.Config{}, Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Limit).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Offset).Return(&gorm.DB{Config: &gorm.Config{}}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if lp, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*lp = records
				}
				return &gorm.DB{Config: &gorm.Config{}, Error: nil}
			}).Build()
			mockey.Mock(ignoreErr).Return(nil).Build()
			mockey.Mock(dkmscli.DecryptWithContext).Return(
				mockey.Sequence("DEC_PHONE", nil).Then("", errors.New("decrypt address error")),
			).Build()

			list, total, err := receiver.List(ctx, tx, param)

			convey.So(list, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "decrypt address error")
		})
	})
}

func Test_freshSealApprovalDaoImpl_UpdateByMap_BitsUTGen(t *testing.T) {
	t.Run("更新成功，err为nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 准备上下文与入参
			ctx := context.Background()
			id := uint64(123)
			updates := map[string]interface{}{"status": "ok"}
			tx := &gorm.DB{}

			// 打桩gorm链路方法，确保最终Error为nil
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("更新失败，忽略RecordNotFound错误返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			id := uint64(456)
			updates := map[string]interface{}{"status": "none"}
			tx := &gorm.DB{}

			// 返回ErrRecordNotFound，ignoreErr会忽略该错误
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("更新失败，RASP错误离线环境被忽略返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 离线环境默认env.Runtime=offline，RASP错误会被ignoreErr忽略
			ctx := context.Background()
			id := uint64(789)
			updates := map[string]interface{}{"status": "rasp"}
			tx := &gorm.DB{}

			raspErr := errors.New("API blocked by RASP: unsafe sql")
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("更新失败，普通错误返回i18n错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			id := uint64(1001)
			updates := map[string]interface{}{"status": "err"}
			tx := &gorm.DB{}

			dbErr := errors.New("db error")
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByMapFail")
		})
	})

	t.Run("加密成功后更新成功，contact_phone和address_info被替换", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 两个敏感字段均加密成功
			ctx := context.Background()
			id := uint64(5)
			updates := map[string]interface{}{"contact_phone": "13800000000", "address_info": "北京朝阳"}
			tx := &gorm.DB{}

			mockey.MockUnsafe(dkmscli.EncryptWithContext).Return(
				mockey.Sequence("enc_phone", nil).Then("enc_addr", nil),
			).Build()

			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("加密失败，联系手机号加密错误直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 联系方式加密错误，直接返回
			ctx := context.Background()
			id := uint64(6)
			updates := map[string]interface{}{"contact_phone": "13900000000"}
			tx := &gorm.DB{}

			mockey.MockUnsafe(dkmscli.EncryptWithContext).Return("", errors.New("dkms phone error")).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "dkms phone error")
		})
	})

	t.Run("加密失败，地址信息加密错误直接返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 地址信息加密错误，直接返回
			ctx := context.Background()
			id := uint64(7)
			updates := map[string]interface{}{"address_info": "上海浦东新区"}
			tx := &gorm.DB{}

			mockey.MockUnsafe(dkmscli.EncryptWithContext).Return("", errors.New("dkms address error")).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "dkms address error")
		})
	})

	t.Run("敏感字段为空或类型不符时不加密也能更新成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 空字符串或非字符串类型，不进行加密
			ctx := context.Background()
			id := uint64(8)
			updates := map[string]interface{}{"contact_phone": "", "address_info": 12345, "status": "ok"}
			tx := &gorm.DB{}

			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			err := receiver.UpdateByMap(ctx, tx, id, updates)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_freshSealApprovalDaoImpl_Create_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_freshSealApprovalDaoImpl_Create", t, func() {
		ctx := context.Background()
		var mockTx *gorm.DB
		dao := &freshSealApprovalDaoImpl{}
		entity := &model.FreshSealApprovalDB{
			ApplyId:      "APP001",
			AccountId:    "ACC001",
			ContactName:  "张三",
			ContactPhone: "13800000000",
			AddressInfo:  "北京市",
			CopyCount:    1,
			Status:       1,
		}

		mockey.PatchConvey("场景：成功创建鲜章申请记录", func() {
			// 模拟成功创建
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				// 断言传入的实体对象正确
				convey.So(value, convey.ShouldEqual, entity)
				return &gorm.DB{Error: nil}
			}).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：contactPhone加密失败", func() {
			// 模拟成功创建
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				// 断言传入的实体对象正确
				convey.So(value, convey.ShouldEqual, entity)
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(dkmscli.EncryptWithContext).Return("", errors.New("encrypt error")).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("场景：AddressInfo", func() {
			// 模拟成功创建
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				// 断言传入的实体对象正确
				convey.So(value, convey.ShouldEqual, entity)
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(dkmscli.EncryptWithContext).Return("", errors.New("encrypt error")).Build()

			err := dao.Create(ctx, mockTx, &model.FreshSealApprovalDB{
				ApplyId:     "APP001",
				AccountId:   "ACC001",
				ContactName: "张三",
				AddressInfo: "北京市",
				CopyCount:   1,
				Status:      1,
			})
			convey.So(err, convey.ShouldNotBeNil)
		})

		mockey.PatchConvey("场景：数据库Create返回gorm.ErrRecordNotFound错误（应忽略）", func() {
			// ErrRecordNotFound需要被忽略
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：非线上环境返回RASP错误（应忽略）", func() {
			// 非线上环境RASP错误需要被忽略
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			raspErr := errors.New("some internal error: API blocked by RASP")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			// 不Mock env.IsOnline，默认offline

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：线上环境返回RASP错误（应返回i18n错误）", func() {
			// 线上环境RASP错误不忽略，应返回i18n错误
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			raspErr := errors.New("some internal error: API blocked by RASP")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CreateFail")
		})

		mockey.PatchConvey("场景：数据库Create返回通用错误（应返回i18n错误）", func() {
			// 通用错误不被忽略，应返回i18n错误
			mockDB := &gorm.DB{}
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			dbErr := errors.New("database create error")
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()

			err := dao.Create(ctx, mockTx, entity)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CreateFail")
		})
	})
}

func Test_NewFreshSealApprovalDao_BitsUTGen(t *testing.T) {
	t.Run("返回全局单例实例", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 调用构造函数，检查返回值与全局单例一致
			got := NewFreshSealApprovalDao()
			var want FreshSealApprovalDao = _freshSealApprovalDaoInstance
			convey.So(got, convey.ShouldEqual, want)

			// 进一步检查具体类型与指针一致
			impl, ok := got.(*freshSealApprovalDaoImpl)
			convey.So(ok, convey.ShouldBeTrue)
			convey.So(impl, convey.ShouldEqual, _freshSealApprovalDaoInstance)

			// 再次调用，确保依旧返回同一实例
			got2 := NewFreshSealApprovalDao()
			convey.So(got2, convey.ShouldEqual, want)
		})
	})
}

func Test_freshSealApprovalDaoImpl_FindByApplyId_BitsUTGen(t *testing.T) {
	t.Run("入参applyId为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()

			gotEntity, err := receiver.FindByApplyId(ctx, nil, "")
			convey.So(gotEntity, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "FindByApplyIdFail, applyId is empty")
		})
	})

	t.Run("数据库普通错误返回通用失败错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟链式查询过程中产生普通错误
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: errors.New("db error")}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{} // 非空tx避免走_dbClient.WithContext

			gotEntity, err := receiver.FindByApplyId(ctx, tx, "apply_1")
			convey.So(gotEntity, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "FindByApplyIdFail")
		})
	})

	t.Run("记录未找到错误被忽略返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟记录未找到错误，ignoreErr应忽略该错误
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			gotEntity, err := receiver.FindByApplyId(ctx, tx, "apply_not_found")
			convey.So(err, convey.ShouldBeNil)
			convey.So(gotEntity, convey.ShouldNotBeNil)
			convey.So(gotEntity.ApplyId, convey.ShouldEqual, "")
		})
	})

	t.Run("查询成功返回实体", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 模拟成功查询，填充目标实体
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if po, ok := dest.(*model.FreshSealApprovalDB); ok {
					po.ApplyId = "apply_success"
					po.Status = 2
				}
				return &gorm.DB{Error: nil}
			}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			gotEntity, err := receiver.FindByApplyId(ctx, tx, "apply_success")
			convey.So(err, convey.ShouldBeNil)
			convey.So(gotEntity, convey.ShouldNotBeNil)
			convey.So(gotEntity.ApplyId, convey.ShouldEqual, "apply_success")
			convey.So(gotEntity.Status, convey.ShouldEqual, 2)
		})
	})

	t.Run("联系人电话解密失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 查询成功，联系人电话非空，解密报错
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if po, ok := dest.(*model.FreshSealApprovalDB); ok {
					po.ApplyId = "apply_phone_err"
					po.ContactPhone = "enc-phone"
				}
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(dkmscli.DecryptWithContext).Return("", errors.New("解密电话失败")).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			gotEntity, err := receiver.FindByApplyId(ctx, tx, "apply_phone_err")
			convey.So(gotEntity, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解密电话失败")
		})
	})

	t.Run("地址信息解密失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 查询成功，电话解密成功，地址解密失败
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if po, ok := dest.(*model.FreshSealApprovalDB); ok {
					po.ApplyId = "apply_addr_err"
					po.ContactPhone = "enc-phone"
					po.AddressInfo = "enc-addr"
				}
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(dkmscli.DecryptWithContext).To(func(ctx context.Context, plaintext string) (string, error) {
				if plaintext == "enc-phone" {
					return "dec-phone", nil
				}
				if plaintext == "enc-addr" {
					return "", errors.New("解密地址失败")
				}
				return plaintext, nil
			}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}

			gotEntity, err := receiver.FindByApplyId(ctx, tx, "apply_addr_err")
			convey.So(gotEntity, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "解密地址失败")
		})
	})

	t.Run("查询成功且敏感信息成功解密返回实体", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// tx为nil走initDB，模拟WithContext；电话与地址均成功解密
			mockey.MockValue(&_dbClient).To(&gorm.DB{})
			mockey.MockUnsafe((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if po, ok := dest.(*model.FreshSealApprovalDB); ok {
					po.ApplyId = "apply_success"
					po.ContactPhone = "enc-phone"
					po.AddressInfo = "enc-addr"
					po.Status = 1
				}
				return &gorm.DB{Error: nil}
			}).Build()
			mockey.Mock(dkmscli.DecryptWithContext).To(func(ctx context.Context, plaintext string) (string, error) {
				if plaintext == "enc-phone" {
					return "dec-phone", nil
				}
				if plaintext == "enc-addr" {
					return "dec-addr", nil
				}
				return plaintext, nil
			}).Build()

			receiver := &freshSealApprovalDaoImpl{}
			ctx := context.Background()

			gotEntity, err := receiver.FindByApplyId(ctx, nil, "apply_success")
			convey.So(err, convey.ShouldBeNil)
			convey.So(gotEntity, convey.ShouldNotBeNil)
			convey.So(gotEntity.ApplyId, convey.ShouldEqual, "apply_success")
			convey.So(gotEntity.ContactPhone, convey.ShouldEqual, "dec-phone")
			convey.So(gotEntity.AddressInfo, convey.ShouldEqual, "dec-addr")
			convey.So(gotEntity.Status, convey.ShouldEqual, 1)
		})
	})
}

func Test_freshSealApprovalDaoImpl_ListByStatus_BitsUTGen(t *testing.T) {
	t.Run("Count错误时返回error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化上下文和dao
			ctx := context.Background()
			dao := &freshSealApprovalDaoImpl{}
			tx := &gorm.DB{}

			// 为全局_dbClient设置一个占位，避免潜在空指针
			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			// 链路方法返回自身，便于调用链继续
			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Limit).To(func(db *gorm.DB, limit int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Offset).To(func(db *gorm.DB, offset int) *gorm.DB { return db }).Build()
			// Count返回错误，触发早返回
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: errors.New("count_err")}).Build()
			// 即使Order/Find被调用也不会影响，因为在Count后已经返回
			mockey.Mock((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB { return &gorm.DB{} }).Build()

			list, total, err := dao.ListByStatus(ctx, tx, 1, 10, 5)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "count_err")
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("Find错误时返回error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化
			ctx := context.Background()
			dao := &freshSealApprovalDaoImpl{}
			tx := &gorm.DB{}

			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB { return db }).Build()
			// 不设置limit/offset分支（均为0）
			mockey.Mock((*gorm.DB).Limit).To(func(db *gorm.DB, limit int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Offset).To(func(db *gorm.DB, offset int) *gorm.DB { return db }).Build()
			// Count成功
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: nil}).Build()
			// Order返回自身
			mockey.Mock((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB { return db }).Build()
			// Find返回错误
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				return &gorm.DB{Error: errors.New("find_err")}
			}).Build()

			list, total, err := dao.ListByStatus(ctx, tx, 2, 0, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "find_err")
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("解密手机号失败返回error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化
			ctx := context.Background()
			dao := &freshSealApprovalDaoImpl{}
			tx := &gorm.DB{}

			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB { return db }).Build()
			// limit > 0，offset == 0，走limit分支
			mockey.Mock((*gorm.DB).Limit).To(func(db *gorm.DB, limit int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Offset).To(func(db *gorm.DB, offset int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB { return db }).Build()
			// Find填充一个nil和一个仅有手机号的元素
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if l, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*l = model.FreshSealApprovalDBList{
						nil,
						&model.FreshSealApprovalDB{ContactPhone: "enc_phone"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()
			// 解密手机号失败
			mockey.Mock(dkmscli.DecryptWithContext).Return("", errors.New("decrypt phone error")).Build()

			list, total, err := dao.ListByStatus(ctx, tx, 3, 1, 0)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "decrypt phone error")
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("解密地址失败返回error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化
			ctx := context.Background()
			dao := &freshSealApprovalDaoImpl{}
			tx := &gorm.DB{}

			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB { return db }).Build()
			// offset > 0，仅走offset分支
			mockey.Mock((*gorm.DB).Limit).To(func(db *gorm.DB, limit int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Offset).To(func(db *gorm.DB, offset int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB { return db }).Build()
			// Find填充一个同时拥有手机号和地址的元素
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if l, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*l = model.FreshSealApprovalDBList{
						&model.FreshSealApprovalDB{ContactPhone: "enc_phone", AddressInfo: "enc_addr"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()
			// 首次调用（手机号）成功，第二次调用（地址）失败
			mockey.Mock(dkmscli.DecryptWithContext).Return(
				mockey.Sequence("dec_phone", nil).Then("", errors.New("decrypt address error")),
			).Build()

			list, total, err := dao.ListByStatus(ctx, tx, 4, 0, 1)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "decrypt address error")
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(list, convey.ShouldBeNil)
		})
	})

	t.Run("全部成功返回列表", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 初始化
			ctx := context.Background()
			dao := &freshSealApprovalDaoImpl{}
			tx := &gorm.DB{}

			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB { return db }).Build()
			// 不走limit/offset分支
			mockey.Mock((*gorm.DB).Limit).To(func(db *gorm.DB, limit int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Offset).To(func(db *gorm.DB, offset int) *gorm.DB { return db }).Build()
			mockey.Mock((*gorm.DB).Count).Return(&gorm.DB{Error: nil}).Build()
			mockey.Mock((*gorm.DB).Order).To(func(db *gorm.DB, value interface{}) *gorm.DB { return db }).Build()
			// Find填充：nil、仅手机号、仅地址，覆盖循环内所有分支
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if l, ok := dest.(*model.FreshSealApprovalDBList); ok {
					*l = model.FreshSealApprovalDBList{
						nil,
						&model.FreshSealApprovalDB{ContactPhone: "enc_p1"},
						&model.FreshSealApprovalDB{AddressInfo: "enc_a2"},
					}
				}
				return &gorm.DB{Error: nil}
			}).Build()
			// 两次解密均成功
			mockey.Mock(dkmscli.DecryptWithContext).Return(
				mockey.Sequence("dec_p1", nil).Then("dec_a2", nil),
			).Build()

			list, total, err := dao.ListByStatus(ctx, tx, 5, 0, 0)
			convey.So(err, convey.ShouldBeNil)
			convey.So(total, convey.ShouldEqual, 0)
			convey.So(list, convey.ShouldNotBeNil)
			convey.So(len(list), convey.ShouldEqual, 3)
			// 校验解密结果已写回
			convey.So(list[1].ContactPhone, convey.ShouldEqual, "dec_p1")
			convey.So(list[2].AddressInfo, convey.ShouldEqual, "dec_a2")
		})
	})
}

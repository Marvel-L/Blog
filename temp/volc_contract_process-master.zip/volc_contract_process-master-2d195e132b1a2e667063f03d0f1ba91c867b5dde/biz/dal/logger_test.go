package dal

import (
	"context"
	"testing"
	"time"

	"code.byted.org/gopkg/logs"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"github.com/stretchr/testify/assert"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"volc_contract_process/pkg/proxy/dkmscli"
)

/**
 * @Author: wangzhen.12@bytedance.com
 * @Date: 2024/10/24 10:48
 * @Desc:
 */

func TestLogger_Apply(t *testing.T) {
	l := &extLogger{}
	cfg := &gorm.Config{}
	err := l.Apply(cfg)
	assert.True(t, err == nil)
	err = l.AfterInitialize(nil)
	assert.True(t, err == nil)
	ret := l.LogMode(logger.Info)
	assert.True(t, ret != nil)
}

func TestLogger_log(t *testing.T) {
	v1 := extLogger{
		LogLevel: logs.LevelFatal,
		Logger:   &logs.Logger{},
	}
	ctx := context.Background()
	v1.Info(ctx, "", "")
	v1.Warn(ctx, "", "")
	v1.Error(ctx, "", "")
}

func Test_extLogger_Trace(t *testing.T) {
	// Arrange
	var v1 = logger.LogLevel(0)
	v2 := extLogger{
		LogLevel: v1,
		Logger:   &logs.Logger{},
	}
	type args struct {
		ctx   context.Context
		begin time.Time
		fc    func() (string, int64)
		err   error
	}
	tests := []struct {
		name  string
		args  args
		mocks func()
	}{
		{
			name: "case #1",
			args: args{
				ctx:   context.Background(),
				begin: time.Now(),
				fc: func() (string, int64) {
					return "", 0
				},
				err: nil,
			},
			mocks: func() {
				mockey.Mock(dkmscli.EncryptWithContext).Return("hello", nil).Build()
				methodCtxInfo := mockey.GetMethod(v2.Logger, "CtxInfo")
				mockey.Mock(methodCtxInfo).Return().Build()
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				v2.Trace(
					tt.args.ctx,
					tt.args.begin,
					tt.args.fc,
					tt.args.err,
				)

				// Assert
				convey.So("your code", convey.ShouldEqual, "your code")
			})
		})
	}
}

func Test_extLogger_logEncryptData(t *testing.T) {
	// Arrange
	v := extLogger{
		Logger: &logs.Logger{},
	}
	type args struct {
		ctx  context.Context
		sql  string
		flag string
	}
	tests := []struct {
		name  string
		args  args
		mocks func()
	}{
		{
			name: "case #1",
			args: args{
				ctx:  context.Background(),
				sql:  "",
				flag: "0",
			},
			mocks: func() {
				mockey.Mock(dkmscli.EncryptWithContext).Return("hello", nil).Build()
				methodCtxInfo := mockey.GetMethod(v.Logger, "CtxInfo")
				mockey.Mock(methodCtxInfo).Return().Build()
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				v.logEncryptData(
					tt.args.ctx,
					tt.args.sql,
					tt.args.flag,
				)

				// Assert
				convey.So("your code", convey.ShouldEqual, "your code")
			})
		})
	}
}

package dal

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"github.com/stretchr/testify/assert"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

func Test_larkMsgRecord_New(t *testing.T) {
	dao := NewLarkMsgRecordDao()
	assert.True(t, dao != nil)
}

func Test_larkMsgRecordDaoImpl_Create(t *testing.T) {
	// Arrange
	v := larkMsgRecordDaoImpl{}
	tx := &gorm.DB{}
	type args struct {
		ctx    context.Context
		entity *model.LarkMsgRecordDB
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx:    context.Background(),
				entity: &model.LarkMsgRecordDB{},
			},
			mocks: func() {

				mockey.Mock(initDB).Return(&gorm.DB{}).Build()

				methodTable := mockey.GetMethod(tx, "Table")
				mockey.Mock(methodTable).Return(tx).Build()
				methodSelect := mockey.GetMethod(tx, "Select")
				mockey.Mock(methodSelect).Return(tx).Build()

				methodCreate := mockey.GetMethod(tx, "Create")
				mockey.Mock(methodCreate).To(func(value interface{}) *gorm.DB {
					type ExampleModel struct{}
					switch value.(type) {
					case *ExampleModel: // Here replace with your model type, like Task{}
						*(value.(*ExampleModel)) = ExampleModel{}
					}
					return tx
				}).Build()

				mockey.Mock(i18nfmt.New).Return(fmt.Errorf("your error")).Build()
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				err := v.Create(
					tt.args.ctx,
					tx,
					tt.args.entity,
				)

				// Assert
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

package dal

import (
	"fmt"
	"strings"
	"time"

	"code.byted.org/security/dkms-gorm/double_write_hook"
	"code.byted.org/security/dkms-gorm/encrypt_type"

	"gorm.io/plugin/dbresolver"

	"volc_contract_process/pkg/conf"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gorm/bytedgorm"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var (
	_dbClient     *gorm.DB
	_readDBClient *gorm.DB
)

func Init(conf *conf.GlobalConf) error {

	encrypt_type.Init()

	if !conf.SwitchConfig.DisableDencryptAfterQuery {
		encrypt_type.Setting(encrypt_type.SetDecryptAfterQuery())
	}

	var err error
	_dbClient, err = newDBClient(conf.DBClient, conf.SwitchConfig.DisableStrictMode, dbresolver.Write)
	if err != nil {
		return err
	}
	_readDBClient, err = newDBClient(conf.DBClient, conf.SwitchConfig.DisableStrictMode, dbresolver.Read)
	if err != nil {
		return err
	}

	err = double_write_hook.SetDBHook(_dbClient, conf.SwitchConfig.AllowEncryptDoubleWrite)
	if err != nil {
		panic(err)
	}

	err = double_write_hook.SetDBHook(_readDBClient, conf.SwitchConfig.AllowEncryptDoubleWrite)
	if err != nil {
		panic(err)
	}

	return nil
}

func newDBClient(mc *conf.MysqlConf, disableStrictMode bool, resolverMode dbresolver.Operation) (*gorm.DB, error) {

	s := string(resolverMode)

	var psm, host string
	psmArr := strings.Split(mc.Cluster, ".")
	if len(psmArr) < 3 {
		return nil, fmt.Errorf("invalid PSM: %s", mc.Cluster)
	}

	if strings.HasSuffix(psmArr[2], s) {
		m := strings.TrimSuffix(psmArr[2], "_"+s)
		psm = strings.Join([]string{psmArr[0], psmArr[1], m}, ".")
		host = mc.Cluster
	} else {
		psm = strings.Join([]string{psmArr[0], psmArr[1], psmArr[2]}, ".")
		psmArr[2] = psmArr[2] + "_" + s
		host = strings.Join(psmArr, ".")
	}
	logs.Info("newDBClient with psm=%s, DBHostname=%s", psm, host)

	client, err := gorm.Open(
		bytedgorm.MySQL(psm, "").With(func(conf *bytedgorm.DBConfig) {
			conf.InterpolateParams = true
			conf.DBHostname = host
			conf.SetDSNParam("loc", "Asia/Shanghai")    // 客户端解释时区
			conf.DSNParams.Add("time_zone", "'+08:00'") // 服务端解释时区
			if !disableStrictMode {
				conf.SetDSNParam("sql_mode", "STRICT_TRANS_TABLES") // 开启严格模式
			}
		}),
		bytedgorm.ConnPool{
			ConnMaxIdleTime: 300 * time.Second,
			ConnMaxLifetime: 300 * time.Second,
			MaxIdleConns:    100,
			MaxOpenConns:    200,
		},
		bytedgorm.WithStressTestSupport(),
		bytedgorm.WithSecurityScanWithOption(bytedgorm.SecurityScanOption{
			DontSupportTableAliasInDeleteStatement: true, // 务必要有这个！！！ Delete sql 不会拼接别名，不加这个配置，sql 执行会报错
		}),
		// bytedgorm.WithDefaults(),
		&extLogger{},
	)
	if err != nil {
		logs.Errorf("initDBClientFail, err:%s", err.Error())
		return nil, err
	}

	// 通过配置是否开启日志
	if mc.LogMode {
		logs.Infof("initDBLoggerWithInfoLevel")
		client.Logger = client.Logger.LogMode(logger.Info)
	} else {
		logs.Infof("initDBLoggerWithErrorLevel")
		client.Logger = client.Logger.LogMode(logger.Warn)
	}

	return client, nil
}

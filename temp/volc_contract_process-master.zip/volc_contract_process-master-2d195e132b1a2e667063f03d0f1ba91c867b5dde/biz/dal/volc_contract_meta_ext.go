package dal

import (
	"context"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tContractMetaExt = "volc_contract_meta_ext"
)

type ContractMetaExtDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaExt) error
	UpdateValue(ctx context.Context, tx *gorm.DB, id uint64, attrValue string) error
	ChangeContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error
	ListByContractId(ctx context.Context, tx *gorm.DB, volcContractId int64, attrKeys []string) ([]*model.ContractMetaExt, int, error)
	ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.ContractMetaExtList, error)
	FindByAttrKey(ctx context.Context, tx *gorm.DB, volcContractId int64, attrKey string) (*model.ContractMetaExt, error)
	DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error
	DeleteByAttrKey(ctx context.Context, tx *gorm.DB, id uint64, attrValue string) error
}

type contractMetaExtDaoImpl struct {
}

var _contractMetaExtDaoInstance = &contractMetaExtDaoImpl{}

func NewContractMetaExtDao() ContractMetaExtDao {
	return _contractMetaExtDaoInstance
}

func (c *contractMetaExtDaoImpl) DeleteByAttrKey(ctx context.Context, tx *gorm.DB, contractId uint64, attrKey string) error {
	if len(attrKey) == 0 {
		return i18nfmt.New(ctx, "NO attrKey")
	}

	logs.CtxInfo(ctx, "DeleteByAttrKey, contractId=%s, attrKey=%v", contractId, attrKey)

	db := initDB(ctx, tx).Table(tContractMetaExt).Where("contract_id = ?", contractId).Where("attr_key = ?", attrKey)

	return ignoreErr(db.Delete(nil).Error)
}

func (c *contractMetaExtDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.ContractMetaExt) error {
	err := initDB(ctx, tx).Table(tContractMetaExt).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createContractMetaExtFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createContractManageFail")
	}
	return nil
}

func (c *contractMetaExtDaoImpl) UpdateValue(ctx context.Context, tx *gorm.DB, id uint64, attrValue string) error {
	err := initDB(ctx, tx).Table(tContractMetaExt).Where("id = ?", id).UpdateColumn("attr_value", attrValue).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "updateMetaExtValueFail, id:%d, err:%s", id, err.Error())
		return i18nfmt.New(ctx, "updateMetaExtValueFail")
	}
	return nil
}

func (c *contractMetaExtDaoImpl) ChangeContractId(ctx context.Context, tx *gorm.DB, oldId, newId int64) error {
	err := initDB(ctx, tx).Table(tContractMetaExt).Where("contract_id = ?", oldId).Update("contract_id", newId).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ChangeContractIdFail, id:%d, err:%s", oldId, err.Error())
		return i18nfmt.New(ctx, "ChangeContractIdFail")
	}
	return nil
}

func (c *contractMetaExtDaoImpl) ListByContractId(ctx context.Context, tx *gorm.DB, volcContractId int64, attrKeys []string) ([]*model.ContractMetaExt, int, error) {
	logs.CtxInfo(ctx, "FindByContractId, ContractId=%v", volcContractId)

	db := initDB(ctx, tx).Table(tContractMetaExt).
		Where("contract_id = ?", volcContractId)
	var total int64
	// if err := db.Count(&total).Error; ignoreErr(err) != nil {
	// 	logs.CtxError(ctx, "ListMetaExtCountFail, err:%s", err.Error())
	// 	return nil, int(total), i18nfmt.New("ListContractMetaCountFail")
	// }
	if len(attrKeys) > 0 {
		db = db.Where("attr_key in (?)", attrKeys)
	}

	var list []*model.ContractMetaExt
	err := db.Find(&list).Error
	if err == gorm.ErrRecordNotFound {
		return nil, 0, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListByContractIdFail, ContractId=%v, err=%s", volcContractId, err.Error())
		return nil, 0, i18nfmt.New(ctx, "ListByContractIdFail")
	}

	return list, int(total), nil
}

func (c *contractMetaExtDaoImpl) ListByIdRange(ctx context.Context, tx *gorm.DB, startID int64, offset int) (model.ContractMetaExtList, error) {
	db := initDB(ctx, tx).Table(tContractMetaExt).Where("id >= ?", startID)
	var list model.ContractMetaExtList
	err := db.Limit(offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdRangeFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdRangeFail")
	}
	return list, nil
}

func (c *contractMetaExtDaoImpl) FindByAttrKey(ctx context.Context, tx *gorm.DB, volcContractId int64, attrKey string) (*model.ContractMetaExt, error) {
	logs.CtxInfo(ctx, "FindByContractId, ContractId=%v", volcContractId)

	db := initDB(ctx, tx).Table(tContractMetaExt).
		Where("contract_id = ?", volcContractId).Where("attr_key = ?", attrKey)

	var ret model.ContractMetaExt

	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByContractIdFail, ContractId=%v, err=%s", volcContractId, err.Error())
		return nil, i18nfmt.New(ctx, "FindByContractIdFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

func (c *contractMetaExtDaoImpl) DeleteByIds(ctx context.Context, tx *gorm.DB, ids []int64) error {

	if len(ids) == 0 {
		logs.CtxWarn(ctx, "DeleteMetaExtByIdsFail, NO ids")
		return nil
	}

	db := initDB(ctx, tx).Table(tContractMetaExt).Where("id in (?)", ids)

	return ignoreErr(db.Delete(nil).Error)
}

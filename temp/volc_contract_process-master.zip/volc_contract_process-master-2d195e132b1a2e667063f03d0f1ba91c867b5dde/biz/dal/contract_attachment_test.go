package dal

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_contractAttachmentDaoImpl_FindByFileKey_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test contractAttachmentDaoImpl.FindByFileKey", t, func() {
		// Prepare common variables for tests
		ctx := context.Background()
		fileKey := "test-file-key-123"
		dao := &contractAttachmentDaoImpl{}
		// This mock gorm.DB instance will be used in the chain
		mockDB := &gorm.DB{}

		mockey.PatchConvey("success case: record found", func() {
			// 场景描述：
			// 构造数据：一个预期的 ContractAttachmentDB 实例。
			// 逻辑链路：
			// 1. Mock initDB 返回一个 mockDB 实例。
			// 2. Mock gorm.DB 的 Table, Where, Last 链式调用。
			// 3. Mock Last 方法成功，无错误返回，并填充结果到传入的指针。
			// 4. 函数按预期返回找到的记录和 nil 错误。
			expectedResult := &model.ContractAttachmentDB{
				FileKey: fileKey,
				Name:    "test_attachment.pdf",
				Size:    1024,
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractAttachmentDB); ok {
					*ret = *expectedResult
				}
				// Return a gorm.DB instance with no error
				return &gorm.DB{Error: nil}
			}).Build()

			// Act
			result, err := dao.FindByFileKey(ctx, nil, fileKey)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			convey.So(result.FileKey, convey.ShouldEqual, expectedResult.FileKey)
			convey.So(result.Name, convey.ShouldEqual, expectedResult.Name)
		})

		mockey.PatchConvey("not found case: gorm.ErrRecordNotFound", func() {
			// 场景描述：
			// 构造数据：无特定数据构造。
			// 逻辑链路：
			// 1. Mock initDB, Table, Where 链式调用。
			// 2. Mock Last 方法返回 gorm.ErrRecordNotFound 错误。
			// 3. 函数内部捕获到 gorm.ErrRecordNotFound，并按逻辑返回 nil, nil。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			result, err := dao.FindByFileKey(ctx, nil, fileKey)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("database error case: a generic db error occurs", func() {
			// 场景描述：
			// 构造数据：一个自定义的数据库错误和一个自定义的 i18n 错误。
			// 逻辑链路：
			// 1. Mock initDB, Table, Where 链式调用。
			// 2. Mock Last 方法返回一个通用数据库错误。
			// 3. 函数进入错误处理分支，因为错误不是 gorm.ErrRecordNotFound 且未被 ignoreErr 忽略。
			// 4. Mock i18nfmt.New 返回一个预设的错误。
			// 5. 函数返回 nil 和来自 i18nfmt.New 的错误。
			dbErr := errors.New("something went wrong with the db")
			i18nErr := errors.New("i18n: find by file key failed")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: dbErr}).Build()
			// Mock env.IsOnline to ensure ignoreErr doesn't ignore the error
			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock(i18nfmt.New).Return(i18nErr).Build()

			// Act
			result, err := dao.FindByFileKey(ctx, nil, fileKey)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, i18nErr.Error())
		})

		mockey.PatchConvey("ignored error case: a RASP error is ignored", func() {
			// 场景描述：
			// 构造数据：一个包含 RASP 信息的错误。
			// 逻辑链路：
			// 1. Mock initDB, Table, Where 链式调用。
			// 2. Mock Last 方法返回 RASP 错误。
			// 3. Mock env.IsOnline 返回 false，触发 ignoreRaspErr 的忽略逻辑。
			// 4. ignoreErr 函数返回 nil。
			// 5. 函数跳过错误处理分支，返回一个零值的结果和 nil 错误。
			raspErr := errors.New("some error: API blocked by RASP")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: raspErr}).Build()
			// Mock env.IsOnline to be false to trigger the ignore logic
			mockey.Mock(env.IsOnline).Return(false).Build()

			// Act
			result, err := dao.FindByFileKey(ctx, nil, fileKey)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldNotBeNil)
			// The returned result should be a zero-valued struct
			convey.So(*result, convey.ShouldResemble, model.ContractAttachmentDB{})
		})
	})
}

func Test_contractAttachmentDaoImpl_ListByNo(t *testing.T) {
	t.Run("成功场景", func(t *testing.T) {
		mockey.PatchConvey("当 contractNo 有效且数据库查询成功时，应返回附件列表", t, func() {
			// Arrange
			ctx := context.Background()
			contractNo := "CT-12345"
			expectedResult := model.ContractAttachmentDBList{
				{
					ContractNo: contractNo,
					Name:       "attachment1.pdf",
					FileKey:    "key1",
				},
			}
			mockDB := &gorm.DB{}

			// Mocks
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				convey.So(name, convey.ShouldEqual, tBContractAttachment)
				return db
			}).Build()

			var capturedWhereQuery string
			var capturedWhereArgs []interface{}
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				capturedWhereQuery = query.(string)
				capturedWhereArgs = args
				return db
			}).Build()

			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.ContractAttachmentDBList); ok {
					*list = expectedResult
				}
				return &gorm.DB{Error: nil}
			}).Build()

			mockey.Mock(ignoreErr).Return(nil).Build()

			_dbClient = &gorm.DB{}

			// Act
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
			convey.So(capturedWhereQuery, convey.ShouldEqual, "contract_no = ? ")
			convey.So(capturedWhereArgs[0], convey.ShouldEqual, contractNo)
		})
	})

	t.Run("失败场景 - contractNo 为空", func(t *testing.T) {
		mockey.PatchConvey("当 contractNo 为空字符串时，应返回空列表和 nil 错误", t, func() {
			// Arrange
			ctx := context.Background()

			// Act
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByNo(ctx, nil, "")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, model.ContractAttachmentDBList{})
		})
	})

	t.Run("失败场景 - 记录未找到", func(t *testing.T) {
		mockey.PatchConvey("当数据库返回 gorm.ErrRecordNotFound 时，应返回 nil, nil", t, func() {
			// Arrange
			ctx := context.Background()
			contractNo := "CT-NOT-FOUND"
			mockDB := &gorm.DB{}

			// Mocks
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			_dbClient = &gorm.DB{}

			// Act
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByNo(ctx, nil, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("失败场景 - 数据库查询失败", func(t *testing.T) {
		mockey.PatchConvey("当数据库 Find 操作返回未被忽略的错误时，应返回国际化错误", t, func() {
			// Arrange
			ctx := context.Background()
			contractNo := "CT-DB-ERROR"
			dbError := errors.New("some critical db error")
			mockDB := &gorm.DB{}

			// Mocks
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbError}).Build()

			mockey.Mock(ignoreErr).Return(dbError).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			_dbClient = &gorm.DB{}

			// Act
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByNo(ctx, nil, contractNo)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "FindByNoFail")
		})
	})

	t.Run("成功场景 - 使用传入的 tx", func(t *testing.T) {
		mockey.PatchConvey("当传入非空的 tx 时，应使用该 tx 实例进行查询", t, func() {
			// Arrange
			ctx := context.Background()
			contractNo := "CT-TX-123"
			mockTx := &gorm.DB{}

			// Mocks
			mockey.Mock((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				convey.So(db, convey.ShouldEqual, mockTx)
				return db
			}).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.ContractAttachmentDBList); ok {
					*list = model.ContractAttachmentDBList{}
				}
				return &gorm.DB{Error: nil}
			}).Build()

			mockey.Mock(ignoreErr).Return(nil).Build()

			// Act
			dao := &contractAttachmentDaoImpl{}
			_, err := dao.ListByNo(ctx, mockTx, contractNo)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_contractAttachmentDaoImpl_ListByFileKeys(t *testing.T) {
	t.Run("成功场景-查询到记录", func(t *testing.T) {
		mockey.PatchConvey("成功场景-查询到记录", t, func() {
			// 场景描述:
			// 当输入有效的fileKeys，数据库成功查询到匹配的记录并返回。
			// 逻辑链路:
			// 1. Mock initDB 返回一个gorm.DB实例。
			// 2. Mock gorm的Find方法，模拟成功查询到数据，并将数据填充到出参中。
			// 3. 调用目标函数。
			// 4. 断言返回的error为nil，并且返回的数据列表与预期一致。

			// 数据构造
			ctx := context.Background()
			tx := &gorm.DB{}
			fileKeys := []string{"key1", "key2"}
			expectedResult := model.ContractAttachmentDBList{
				{
					BaseDB:  model.BaseDB{Id: 1, CreatedTime: time.Now(), UpdatedTime: time.Now(), Status: 1},
					FileKey: "key1",
					Name:    "file1.pdf",
				},
				{
					BaseDB:  model.BaseDB{Id: 2, CreatedTime: time.Now(), UpdatedTime: time.Now(), Status: 1},
					FileKey: "key2",
					Name:    "file2.pdf",
				},
			}

			// Mock
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if list, ok := dest.(*model.ContractAttachmentDBList); ok {
					*list = expectedResult
				}
				return &gorm.DB{Error: nil}
			}).Build()

			// 调用
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByFileKeys(ctx, tx, fileKeys)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})
	})

	t.Run("成功场景-未查询到记录", func(t *testing.T) {
		mockey.PatchConvey("成功场景-未查询到记录", t, func() {
			// 场景描述:
			// 当数据库查询未找到任何记录，返回gorm.ErrRecordNotFound时，函数应处理该情况并返回nil, nil。
			// 逻辑链路:
			// 1. Mock gorm的Find方法，使其返回gorm.ErrRecordNotFound错误。
			// 2. 调用目标函数。
			// 3. 断言返回的结果和错误都为nil。

			// 数据构造
			ctx := context.Background()
			tx := &gorm.DB{}
			fileKeys := []string{"non_existent_key"}

			// Mock
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// 调用
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByFileKeys(ctx, tx, fileKeys)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("成功场景-输入fileKeys为空", func(t *testing.T) {
		mockey.PatchConvey("成功场景-输入fileKeys为空", t, func() {
			// 场景描述:
			// 当输入的fileKeys切片为空时，函数应直接返回一个空的列表和nil错误，不执行数据库查询。
			// 逻辑链路:
			// 1. 准备一个空的fileKeys切片。
			// 2. 调用目标函数。
			// 3. 断言返回一个空的、非nil的列表和nil错误。

			// 数据构造
			ctx := context.Background()
			tx := &gorm.DB{}
			fileKeys := []string{}

			// 调用
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByFileKeys(ctx, tx, fileKeys)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, model.ContractAttachmentDBList{})
		})
	})

	t.Run("失败场景-数据库查询失败", func(t *testing.T) {
		mockey.PatchConvey("失败场景-数据库查询失败", t, func() {
			// 场景描述:
			// 当数据库查询返回一个未被忽略的通用错误时，函数应捕获该错误，记录日志并返回一个国际化的错误。
			// 逻辑链路:
			// 1. Mock gorm的Find方法返回一个通用错误。
			// 2. Mock ignoreErr方法，使其不忽略该错误。
			// 3. Mock i18nfmt.New方法，以返回一个可断言的错误。
			// 4. 调用目标函数。
			// 5. 断言返回预期的错误信息，并且结果列表为nil。

			// 数据构造
			ctx := context.Background()
			tx := &gorm.DB{}
			fileKeys := []string{"key1"}
			dbErr := errors.New("database connection failed")
			expectedErrText := "ListByFileKeysFail"

			// Mock
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(ignoreErr, mockey.OptUnsafe).Return(dbErr).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// 调用
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByFileKeys(ctx, tx, fileKeys)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrText)
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("成功场景-数据库返回可忽略的错误", func(t *testing.T) {
		mockey.PatchConvey("成功场景-数据库返回可忽略的错误", t, func() {
			// 场景描述:
			// 当数据库查询返回一个错误，但该错误被ignoreErr函数判定为可忽略时，函数应返回一个空的列表和nil错误。
			// 逻辑链路:
			// 1. Mock gorm的Find方法返回一个可被忽略的错误。
			// 2. Mock ignoreErr方法，使其返回nil，表示错误被忽略。
			// 3. 调用目标函数。
			// 4. 断言返回错误为nil，并且结果列表为一个空的非nil列表。

			// 数据构造
			ctx := context.Background()
			tx := &gorm.DB{}
			fileKeys := []string{"key1"}
			ignorableErr := errors.New("API blocked by RASP")

			// Mock
			mockey.Mock(initDB, mockey.OptUnsafe).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Find).Return(&gorm.DB{Error: ignorableErr}).Build()
			mockey.Mock(ignoreErr, mockey.OptUnsafe).Return(nil).Build()

			// 调用
			dao := &contractAttachmentDaoImpl{}
			result, err := dao.ListByFileKeys(ctx, tx, fileKeys)

			// 断言
			convey.So(err, convey.ShouldBeNil)
			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})
}

func Test_contractAttachmentDaoImpl_FindByFileKey(t *testing.T) {
	mockey.PatchConvey("Test_contractAttachmentDaoImpl_FindByFileKey", t, func() {
		dao := &contractAttachmentDaoImpl{}

		mockey.PatchConvey("成功场景 - 找到记录", func() {
			// 场景描述:
			// 当传入有效的 fileKey 且数据库能找到对应记录时，函数应正确返回该记录。
			// 数据构造:
			// - fileKey: "existing_key"
			// - 数据库查询结果: 一个预设的 ContractAttachmentDB 实例
			// 逻辑链路:
			// 1. Mock initDB 返回一个有效的 *gorm.DB 实例。
			// 2. Mock gorm.DB 的链式调用 Table, Where。
			// 3. Mock gorm.DB 的 Last 方法，模拟找到数据，填充结果并返回 nil error。
			// 4. 调用目标函数 FindByFileKey。
			// 5. 断言返回的 error 为 nil，且返回的 *model.ContractAttachmentDB 与预期一致。

			// Arrange
			mockFileKey := "existing_key"
			expectedResult := &model.ContractAttachmentDB{
				ContractNo: "CT001",
				FileKey:    mockFileKey,
				Name:       "attachment.pdf",
				BaseDB: model.BaseDB{
					Id:          1,
					CreatedTime: time.Now(),
					UpdatedTime: time.Now(),
					Status:      0,
				},
			}
			mockDB := &gorm.DB{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if ret, ok := dest.(*model.ContractAttachmentDB); ok {
					*ret = *expectedResult
				}
				return &gorm.DB{Error: nil}
			}).Build()
			// 在成功路径上，ignoreErr 不会被调用

			// Act
			result, err := dao.FindByFileKey(context.Background(), nil, mockFileKey)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedResult)
		})

		mockey.PatchConvey("成功场景 - 未找到记录", func() {
			// 场景描述:
			// 当传入的 fileKey 在数据库中不存在时，GORM 返回 gorm.ErrRecordNotFound，函数应将其视为正常情况并返回 nil, nil。
			// 数据构造:
			// - fileKey: "not_found_key"
			// 逻辑链路:
			// 1. Mock initDB, Table, Where。
			// 2. Mock Last 方法返回 gorm.ErrRecordNotFound。
			// 3. 调用目标函数。
			// 4. 断言返回的 *model.ContractAttachmentDB 和 error 均为 nil。

			// Arrange
			mockFileKey := "not_found_key"
			mockDB := &gorm.DB{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			// Act
			result, err := dao.FindByFileKey(context.Background(), nil, mockFileKey)

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景 - 数据库查询失败", func() {
			// 场景描述:
			// 当数据库查询操作返回 gorm.ErrRecordNotFound 以外的错误时，函数应捕获该错误，并返回一个国际化的错误信息。
			// 数据构造:
			// - fileKey: "db_error_key"
			// - 数据库错误: 一个通用的 error 实例
			// 逻辑链路:
			// 1. Mock initDB, Table, Where。
			// 2. Mock Last 方法返回一个非 ErrRecordNotFound 的错误。
			// 3. Mock ignoreErr 确认该错误不被忽略。
			// 4. Mock i18nfmt.New 以返回预期的包装后错误。
			// 5. 调用目标函数。
			// 6. 断言返回的 *model.ContractAttachmentDB 为 nil，且 error 符合预期。

			// Arrange
			mockFileKey := "db_error_key"
			dbErr := errors.New("unexpected database error")
			mockDB := &gorm.DB{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Last).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(ignoreErr).Return(dbErr).Build() // 模拟错误未被忽略
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error {
				return fmt.Errorf(text)
			}).Build()

			// Act
			result, err := dao.FindByFileKey(context.Background(), nil, mockFileKey)

			// Assert
			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "FindByFileKeyFail")
		})

		mockey.PatchConvey("边界场景 - fileKey为空", func() {
			// 场景描述:
			// 当传入的 fileKey 为空字符串时，函数应直接返回 nil, nil，不进行任何数据库查询。
			// 数据构造:
			// - fileKey: ""
			// 逻辑链路:
			// 1. 调用目标函数，传入空字符串 fileKey。
			// 2. 验证函数是否在早期检查中退出。
			// 3. 断言返回的 *model.ContractAttachmentDB 和 error 均为 nil。

			// Arrange
			// 无需 Mock，因为函数应在调用数据库之前返回

			// Act
			result, err := dao.FindByFileKey(context.Background(), nil, "")

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

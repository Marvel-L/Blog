package dal

import (
	"context"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"

	"code.byted.org/gopkg/logs"
)

const (
	tBFreshSealApprovalLog = "fresh_seal_approval_log"
)

// FreshSealApprovalLogDao 鲜章申请操作日志dao
type FreshSealApprovalLogDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.FreshSealApprovalLogDB) error
	ListByApplyId(ctx context.Context, tx *gorm.DB, applyId string, limit, offset int) (model.FreshSealApprovalLogDBList, int, error)
}

var _freshSealApprovalLogDaoInstance = &freshSealApprovalLogDaoImpl{}

func NewFreshSealApprovalLogDao() FreshSealApprovalLogDao {
	return _freshSealApprovalLogDaoInstance
}

type freshSealApprovalLogDaoImpl struct{}

// Create 创建鲜章申请操作日志
func (p *freshSealApprovalLogDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.FreshSealApprovalLogDB) error {
	db := initDB(ctx, tx)
	err := db.Table(tBFreshSealApprovalLog).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createFreshSealApprovalLogFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createFreshSealApprovalLogFail")
	}
	return nil
}

// ListByApplyId 根据ApplyId查询鲜章申请操作日志列表（支持分页）
func (p *freshSealApprovalLogDaoImpl) ListByApplyId(ctx context.Context, tx *gorm.DB, applyId string, limit, offset int) (model.FreshSealApprovalLogDBList, int, error) {

	if applyId == "" {
		logs.CtxError(ctx, "ListByApplyIdFail, applyId is empty")
		return nil, 0, gorm.ErrRecordNotFound
	}
	db := initDB(ctx, tx)
	query := db.Table(tBFreshSealApprovalLog).Where("apply_id = ?", applyId)

	// 查询总记录数
	var total int64
	err := query.Count(&total).Error
	if ignoreErr(err) != nil {
		return nil, 0, err
	}

	// 查询分页数据
	var list model.FreshSealApprovalLogDBList
	if limit > 0 {
		query = query.Limit(limit).Offset(offset)
	}
	err = query.Order("id desc").Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "freshSealApprovalLogListByApplyIdFail, err:%s", err.Error())
		return nil, 0, i18nfmt.New(ctx, "freshSealApprovalLogListByApplyIdFail")
	}

	return list, int(total), nil
}

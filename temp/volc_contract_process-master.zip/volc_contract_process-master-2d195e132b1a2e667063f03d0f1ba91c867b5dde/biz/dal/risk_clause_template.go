package dal

import (
	"context"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tRiskClauseTemplate = "risk_clause_template"
)

type RiskClauseTemplateDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.RiskClauseTemplateDB) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error
	UpdateStatusById(ctx context.Context, tx *gorm.DB, id int64, status int) error
	FindById(ctx context.Context, tx *gorm.DB, id int) (*model.RiskClauseTemplateDB, error)
	List(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseTemplateReq) (model.RiskClauseTemplateDBList, int, error)
}

var _riskClauseTemplateDaoInstance = &riskClauseTemplateDaoImpl{}

func NewRiskClauseTemplateDao() RiskClauseTemplateDao {
	return _riskClauseTemplateDaoInstance
}

type riskClauseTemplateDaoImpl struct {
}

func (r riskClauseTemplateDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.RiskClauseTemplateDB) error {
	err := initDB(ctx, tx).Table(tRiskClauseTemplate).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "createRiskClauseTemplateFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "createRiskClauseTemplateFail")
	}
	return nil
}

func (r riskClauseTemplateDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id int64, updates map[string]interface{}) error {
	db := initDB(ctx, tx).Table(tRiskClauseTemplate)
	err := db.Where("id = ?", id).Updates(updates).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (r riskClauseTemplateDaoImpl) UpdateStatusById(ctx context.Context, tx *gorm.DB, id int64, status int) error {
	db := initDB(ctx, tx).Table(tRiskClauseTemplate)
	err := db.Where("id = ?", id).Updates(map[string]interface{}{"status": status}).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

func (r riskClauseTemplateDaoImpl) FindById(ctx context.Context, tx *gorm.DB, id int) (*model.RiskClauseTemplateDB, error) {
	logs.CtxInfo(ctx, "FindById, id=%v", id)

	db := initDB(ctx, tx).Table(tRiskClauseTemplate).Where("id = ?", id)

	var ret model.RiskClauseTemplateDB

	err := db.First(&ret).Error
	if err == gorm.ErrRecordNotFound {
		return nil, nil
	} else if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByIdFail, id=%v, err=%s", id, err.Error())
		return nil, i18nfmt.New(ctx, "FindByIdFail")
	}

	if ret.Id > 0 {
		return &ret, nil
	}

	return nil, nil
}

func (r riskClauseTemplateDaoImpl) List(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseTemplateReq) (model.RiskClauseTemplateDBList, int, error) {
	var total int64
	var err error

	db := r.buildQuery(ctx, tx, req)

	if req.NeedTotal {
		if err := db.Count(&total).Error; ignoreErr(err) != nil {
			logs.CtxError(ctx, "ListRiskClauseTemplateCountFail, err:%s", err.Error())
			return nil, int(total), i18nfmt.New(ctx, "ListRiskClauseTemplateCountFail")
		}
	}

	var list model.RiskClauseTemplateDBList
	err = db.Order("risk_clause_template.id desc").Limit(req.Limit).Offset(req.Offset).Find(&list).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListRiskClauseTemplateFail, err:%s", err.Error())
		return nil, int(total), i18nfmt.New(ctx, "ListRiskClauseTemplateFail")
	}

	return list, int(total), nil
}

func (p *riskClauseTemplateDaoImpl) buildQuery(ctx context.Context, tx *gorm.DB, req *model.ListRiskClauseTemplateReq) *gorm.DB {
	db := initDB(ctx, tx).Table(tRiskClauseTemplate)

	if len(req.ClauseNo) > 0 {
		db = db.Where("clause_no = ?", req.ClauseNo)
	}
	if len(req.RiskClauseType) > 0 {
		db = db.Where("risk_clause_type = ?", req.RiskClauseType)
	}
	if len(req.RiskLevel) > 0 {
		db = db.Where("risk_level = ?", req.RiskLevel)
	}
	if req.Status != nil {
		db = db.Where("status = ?", *req.Status)
	}
	if req.IsNewset != nil {
		db = db.Where("is_newest = ?", *req.IsNewset)
	}

	return db
}

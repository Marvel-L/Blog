package dal

import (
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
)

func Test_riskClauseRoleReviewerDaoImpl_BatchCreate_BitsUTGen(t *testing.T) {
	t.Run("BatchCreate returns nil when entities is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &riskClauseRoleReviewerDaoImpl{}

			var entities []*model.RiskClauseRoleReviewerDB
			err := r.BatchCreate(ctx, nil, entities)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("BatchCreate success when CreateInBatches returns nil error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &riskClauseRoleReviewerDaoImpl{}
			entities := []*model.RiskClauseRoleReviewerDB{
				{Reviewer: "alice"},
			}

			mockDB := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(mockDB).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(mockDB).Build()
			okDB := &gorm.DB{} // Error is nil to simulate success
			mockey.MockUnsafe((*gorm.DB).CreateInBatches).Return(okDB).Build()

			err := r.BatchCreate(ctx, nil, entities)

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("BatchCreate returns i18n error when CreateInBatches returns non-ignored error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			r := &riskClauseRoleReviewerDaoImpl{}
			entities := []*model.RiskClauseRoleReviewerDB{
				{Reviewer: "bob"},
			}

			mockDB := &gorm.DB{}
			mockey.MockUnsafe(initDB).Return(mockDB).Build()
			mockey.MockUnsafe((*gorm.DB).Table).Return(mockDB).Build()
			errDB := &gorm.DB{Error: errors.New("mock db error")}
			mockey.MockUnsafe((*gorm.DB).CreateInBatches).Return(errDB).Build()

			err := r.BatchCreate(ctx, nil, entities)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "batchCreateRiskClauseRoleReviewerFail")
			convey.So(err.Error(), convey.ShouldContainSubstring, "mock db error")
		})
	})
}

func Test_riskClauseRoleReviewerDaoImpl_DeleteByRoleID_BitsUTGen(t *testing.T) {
	t.Run("DeleteByRoleID success when Updates returns nil error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocks for gorm chain
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			roleID := int64(123)

			// Act
			err := dao.DeleteByRoleID(ctx, tx, roleID)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("DeleteByRoleID success when Updates returns ErrRecordNotFound", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange mocks for gorm chain
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			roleID := int64(456)

			// Act
			err := dao.DeleteByRoleID(ctx, tx, roleID)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("DeleteByRoleID fail when Updates returns general error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock logs to avoid nil default logger panic
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// Arrange mocks for gorm chain
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: errors.New("database error")}).Build()

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			roleID := int64(789)

			// Act
			err := dao.DeleteByRoleID(ctx, tx, roleID)

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "DeleteByRoleIDFail")
		})
	})

	t.Run("DeleteByRoleID success when error is blocked by RASP in offline env", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Mock logs used inside ignoreRaspErr to avoid nil default logger panic
			mockey.MockUnsafe(logs.CtxError).Return().Build()

			// Arrange mocks for gorm chain
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: errors.New("API blocked by RASP: injection prevented")}).Build()

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			roleID := int64(321)

			// Act
			err := dao.DeleteByRoleID(ctx, tx, roleID)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_riskClauseRoleReviewerDaoImpl_GetByRoleIDs_BitsUTGen(t *testing.T) {
	t.Run("Empty roleIDs returns nil and no error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Act
			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			res, err := dao.GetByRoleIDs(ctx, nil, []int64{})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("Query fails with DB error, returns i18n error", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Mock _dbClient to a stub, even though tx is provided, to keep globals initialized
			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			dbErr := errors.New("database broken")

			stub := &gorm.DB{Error: dbErr}

			mockey.MockUnsafe((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				// Do not modify dest, just return the error
				return stub
			}).Build()

			// Act
			res, err := dao.GetByRoleIDs(ctx, tx, []int64{1, 2})

			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "GetByRoleIDsFail")
		})
	})

	t.Run("Record not found error is ignored and returns empty list", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			stub := &gorm.DB{Error: gorm.ErrRecordNotFound}

			mockey.MockUnsafe((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				return stub
			}).Build()

			// Act
			res, err := dao.GetByRoleIDs(ctx, tx, []int64{3})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			// The function returns the list variable which remains nil when not found
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("RASP blocked error in offline env is ignored and returns empty list", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			stub := &gorm.DB{Error: errors.New("API blocked by RASP: simulated")}

			mockey.MockUnsafe((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				return stub
			}).Build()

			// Act
			res, err := dao.GetByRoleIDs(ctx, tx, []int64{5})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("Successful query returns non-empty list", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.MockValue(&_dbClient).To(&gorm.DB{})

			dao := riskClauseRoleReviewerDaoImpl{}
			ctx := context.Background()
			tx := &gorm.DB{}
			stub := &gorm.DB{Error: nil}

			mockey.MockUnsafe((*gorm.DB).Table).To(func(db *gorm.DB, name string, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				return stub
			}).Build()
			mockey.MockUnsafe((*gorm.DB).Find).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				// Populate the destination slice to simulate successful query
				if d, ok := dest.(*[]*model.RiskClauseRoleReviewerDB); ok {
					*d = []*model.RiskClauseRoleReviewerDB{
						{RiskClauseRoleID: 101, ReviewerType: 1, Reviewer: "Alice", IsDeleted: 0},
						{RiskClauseRoleID: 102, ReviewerType: 2, Reviewer: "Bob", IsDeleted: 0},
					}
				}
				return stub
			}).Build()

			// Act
			res, err := dao.GetByRoleIDs(ctx, tx, []int64{101, 102})

			// Assert
			convey.So(err, convey.ShouldBeNil)
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 2)
			convey.So(res[0].RiskClauseRoleID, convey.ShouldEqual, 101)
			convey.So(res[1].RiskClauseRoleID, convey.ShouldEqual, 102)
		})
	})
}

var entities []*model.RiskClauseRoleReviewerDB

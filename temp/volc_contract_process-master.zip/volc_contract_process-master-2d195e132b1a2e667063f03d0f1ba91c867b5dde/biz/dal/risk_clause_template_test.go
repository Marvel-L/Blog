package dal

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"context"
	"errors"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_riskClauseTemplateDaoImpl_FindById_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_riskClauseTemplateDaoImpl_FindById", t, func() {
		// Common variables for all test cases
		dao := riskClauseTemplateDaoImpl{}
		ctx := context.Background()
		mockDB := &gorm.DB{}
		testID := 123

		mockey.PatchConvey("Success: record found", func() {
			// 场景描述：
			// 模拟数据库查询成功，找到匹配的记录。
			// 构造数据：
			// 构造一个 RiskClauseTemplateDB 实例作为预期的查询结果，其 Id > 0。
			// 逻辑链路：
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的 Table 和 Where 方法，使其支持链式调用。
			// 3. mock gorm 的 First 方法，使其模拟找到数据，将预设的记录填充到输入参数中，并返回一个无错误的 *gorm.DB。
			// 4. 函数执行，进入 ret.Id > 0 的分支。
			// 5. 断言返回的记录和 error 都符合预期。
			expectedRecord := &model.RiskClauseTemplateDB{
				BaseDB:      model.BaseDB{Id: uint64(testID)},
				Description: "this is a test record",
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if r, ok := dest.(*model.RiskClauseTemplateDB); ok {
					*r = *expectedRecord
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindById(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldResemble, expectedRecord)
		})

		mockey.PatchConvey("Failure: record not found", func() {
			// 场景描述：
			// 模拟数据库查询未找到记录。
			// 构造数据：
			// 无特定数据构造。
			// 逻辑链路：
			// 1. mock initDB 返回一个 mockDB 实例。
			// 2. mock gorm 的 Table 和 Where 方法。
			// 3. mock gorm 的 First 方法，使其返回 gorm.ErrRecordNotFound 错误。
			// 4. 函数执行，进入 err == gorm.ErrRecordNotFound 的分支。
			// 5.断言返回 (nil, nil)。
			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			result, err := dao.FindById(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure: general database error", func() {
			// 场景描述：
			// 模拟数据库查询时发生通用错误（非 RecordNotFound）。
			// 构造数据：
			// 构造一个通用的 error 实例。
			// 逻辑链路：
			// 1. mock initDB, Table, Where。
			// 2. mock gorm 的 First 方法，使其返回一个通用错误。
			// 3. mock env.IsOnline 返回 true，使 ignoreErr 不会忽略该错误。
			// 4. 函数执行，进入 ignoreErr(err) != nil 的分支。
			// 5. 函数返回 i18nfmt.New 创建的错误。
			// 6. 断言返回的结果为 nil，error 不为 nil 且包含特定信息。
			dbErr := errors.New("something went wrong")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(true).Build() // Ensure ignoreErr doesn't swallow the error

			result, err := dao.FindById(ctx, nil, testID)

			convey.So(result, convey.ShouldBeNil)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "FindByIdFail")
		})

		mockey.PatchConvey("Success: found record with Id 0", func() {
			// 场景描述：
			// 模拟数据库查询成功，但返回的记录 Id 为 0。
			// 构造数据：
			// 构造一个 RiskClauseTemplateDB 实例，其 Id 字段为 0。
			// 逻辑链路：
			// 1. mock initDB, Table, Where。
			// 2. mock gorm 的 First 方法，使其模拟找到数据，并填充 Id 为 0 的记录。
			// 3. 函数执行，不满足 ret.Id > 0 的条件。
			// 4. 函数执行到最后的 return nil, nil。
			// 5. 断言返回 (nil, nil)。
			recordWithZeroID := &model.RiskClauseTemplateDB{
				BaseDB: model.BaseDB{Id: 0},
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).To(func(dest interface{}, conds ...interface{}) *gorm.DB {
				if r, ok := dest.(*model.RiskClauseTemplateDB); ok {
					*r = *recordWithZeroID
				}
				return &gorm.DB{Error: nil}
			}).Build()

			result, err := dao.FindById(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Success: RASP error is ignored in non-online env", func() {
			// 场景描述：
			// 模拟在非线上环境，数据库返回一个 RASP 错误，该错误应被忽略。
			// 构造数据：
			// 构造一个包含 "API blocked by RASP" 字符串的 error。
			// 逻辑链路：
			// 1. mock initDB, Table, Where。
			// 2. mock gorm 的 First 方法，使其返回 RASP 错误。
			// 3. mock env.IsOnline 返回 false，触发 ignoreRaspErr 的忽略逻辑。
			// 4. 函数执行，ignoreErr(err) 返回 nil。
			// 5. 由于记录未被填充，ret.Id 不大于 0。
			// 6. 函数执行到最后的 return nil, nil。
			// 7. 断言返回 (nil, nil)。
			raspErr := errors.New("some error: API blocked by RASP")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: raspErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build() // Key mock for this scenario

			result, err := dao.FindById(ctx, nil, testID)

			convey.So(err, convey.ShouldBeNil)
			convey.So(result, convey.ShouldBeNil)
		})
	})
}

func Test_riskClauseTemplateDaoImpl_buildQuery_BitsUTGen(t *testing.T) {
	p := &riskClauseTemplateDaoImpl{}
	mockDB := &gorm.DB{}

	mockey.PatchConvey("Test buildQuery", t, func() {
		mockey.PatchConvey("should build query with all conditions when request has all fields", func() {
			// 场景描述：
			// 测试当请求参数 `req` 的所有字段都被填充时，`buildQuery` 函数能否正确地为每个字段添加 WHERE 条件。
			// 构造数据：
			// 创建一个 `model.ListRiskClauseTemplateReq` 实例，并为其所有字段（ClauseNo, RiskClauseType, RiskLevel, Status, IsNewset）提供非空或非零值。
			// 逻辑链路：
			// 1. Mock `initDB` 函数，使其返回一个 mock 的 `gorm.DB` 实例。
			// 2. Mock `gorm.DB` 的 `Table` 方法，使其返回同一个 mock 的 `gorm.DB` 实例。
			// 3. Mock `gorm.DB` 的 `Where` 方法，使其在被调用时，记录下传入的查询条件字符串。
			// 4. 使用构造的完整请求数据调用 `buildQuery` 方法。
			// 5. 断言 `Where` 方法被调用了5次，并且所有预期的条件都已添加。
			var whereClauses []string
			req := &model.ListRiskClauseTemplateReq{
				ClauseNo:       "TestClauseNo-1",
				RiskClauseType: "TestType-1",
				RiskLevel:      "High",
				Status:         gptr.Of(1),
				IsNewset:       gptr.Of(1),
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				if qStr, ok := query.(string); ok {
					whereClauses = append(whereClauses, qStr)
				}
				return db
			}).Build()

			_ = p.buildQuery(context.Background(), nil, req)

			convey.So(len(whereClauses), convey.ShouldEqual, 5)
			convey.So(whereClauses, convey.ShouldContain, "clause_no = ?")
			convey.So(whereClauses, convey.ShouldContain, "risk_clause_type = ?")
			convey.So(whereClauses, convey.ShouldContain, "risk_level = ?")
			convey.So(whereClauses, convey.ShouldContain, "status = ?")
			convey.So(whereClauses, convey.ShouldContain, "is_newest = ?")
		})

		mockey.PatchConvey("should build query with no conditions when request is empty", func() {
			// 场景描述：
			// 测试当请求参数 `req` 的所有字段都为空或nil时，`buildQuery` 函数不添加任何 WHERE 条件。
			// 构造数据：
			// 创建一个空的 `model.ListRiskClauseTemplateReq` 实例。
			// 逻辑链路：
			// 1. Mock `initDB` 和 `(*gorm.DB).Table` 方法。
			// 2. Mock `(*gorm.DB).Where` 方法，记录其调用。
			// 3. 使用空的请求数据调用 `buildQuery` 方法。
			// 4. 断言 `Where` 方法从未被调用。
			var whereClauses []string
			req := &model.ListRiskClauseTemplateReq{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				if qStr, ok := query.(string); ok {
					whereClauses = append(whereClauses, qStr)
				}
				return db
			}).Build()

			_ = p.buildQuery(context.Background(), nil, req)

			convey.So(len(whereClauses), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("should build query with partial conditions when request has some fields", func() {
			// 场景描述：
			// 测试当请求参数 `req` 只有部分字段被填充时，`buildQuery` 函数只为已填充的字段添加 WHERE 条件。
			// 构造数据：
			// 创建一个 `model.ListRiskClauseTemplateReq` 实例，只填充 `RiskLevel` 和 `Status` 字段。
			// 逻辑链路：
			// 1. Mock `initDB`, `(*gorm.DB).Table`, 和 `(*gorm.DB).Where` 方法。
			// 2. 使用部分填充的请求数据调用 `buildQuery` 方法。
			// 3. 断言 `Where` 方法被调用了2次，并且添加的条件是针对 `RiskLevel` 和 `Status` 的。
			var whereClauses []string
			req := &model.ListRiskClauseTemplateReq{
				RiskLevel: "Medium",
				Status:    gptr.Of(0),
			}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				if qStr, ok := query.(string); ok {
					whereClauses = append(whereClauses, qStr)
				}
				return db
			}).Build()

			_ = p.buildQuery(context.Background(), nil, req)

			convey.So(len(whereClauses), convey.ShouldEqual, 2)
			convey.So(whereClauses, convey.ShouldContain, "risk_level = ?")
			convey.So(whereClauses, convey.ShouldContain, "status = ?")
			convey.So(whereClauses, convey.ShouldNotContain, "clause_no = ?")
		})

		mockey.PatchConvey("should use the provided transaction when tx is not nil", func() {
			// 场景描述：
			// 测试当传入一个非空的 gorm 事务对象 `tx` 时，`buildQuery` 函数会基于此事务对象构建查询。
			// 构造数据：
			// 创建一个 `model.ListRiskClauseTemplateReq` 实例和一个非空的 `gorm.DB` 事务对象 `tx`。
			// 逻辑链路：
			// 1. Mock `initDB` 函数，并验证传入的 `tx` 参数正是我们创建的事务对象。
			// 2. Mock 其他 GORM 方法如 `Table` 和 `Where`。
			// 3. 使用请求数据和事务对象调用 `buildQuery` 方法。
			// 4. 断言查询条件被正确添加，且 `initDB` 正确接收了事务对象。
			var whereClauses []string
			req := &model.ListRiskClauseTemplateReq{
				ClauseNo: "TX-C001",
			}
			tx := &gorm.DB{} // Represents the incoming transaction

			mockey.Mock(initDB).To(func(ctx context.Context, gormTx *gorm.DB) *gorm.DB {
				convey.So(gormTx, convey.ShouldEqual, tx)
				return gormTx
			}).Build()

			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				if qStr, ok := query.(string); ok {
					whereClauses = append(whereClauses, qStr)
				}
				return db
			}).Build()

			_ = p.buildQuery(context.Background(), tx, req)

			convey.So(len(whereClauses), convey.ShouldEqual, 1)
			convey.So(whereClauses[0], convey.ShouldEqual, "clause_no = ?")
		})
	})
}

func Test_riskClauseTemplateDaoImpl_UpdateStatusById_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_riskClauseTemplateDaoImpl_UpdateStatusById", t, func() {
		// 准备通用测试数据
		ctx := context.Background()
		dao := riskClauseTemplateDaoImpl{}
		id := int64(123)
		status := 1

		mockey.PatchConvey("场景：不使用事务（tx为nil）", func() {
			// 在此场景下，initDB将使用全局变量_dbClient
			_dbClient = &gorm.DB{} // 为测试初始化全局DB客户端

			mockey.PatchConvey("子场景：数据库更新成功", func() {
				// 场景描述：
				// 当不使用事务时，数据库更新操作成功。
				// 构造数据：
				// - tx *gorm.DB 设置为 nil
				// - 模拟的gorm.DB链式调用最终返回的Error为nil
				// 逻辑链路：
				// 1. initDB(ctx, nil) 被调用，返回 _dbClient.WithContext(ctx) 的结果。
				// 2. 模拟 (*gorm.DB).WithContext 返回一个mock的DB实例。
				// 3. 模拟DB实例的 Table -> Where -> Updates 链式调用。
				// 4. Updates 调用返回的DB实例的Error字段为nil。
				// 5. ignoreErr(nil) 返回 nil。
				// 6. 函数最终返回nil，表示成功。
				mockDB := &gorm.DB{Error: nil}
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()

				err := dao.UpdateStatusById(ctx, nil, id, status)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：数据库更新失败，返回通用错误", func() {
				// 场景描述：
				// 数据库更新操作失败，返回一个通用错误。
				// 构造数据：
				// - tx *gorm.DB 设置为 nil
				// - 模拟的gorm.DB链式调用最终返回的Error为一个自定义错误
				// 逻辑链路：
				// 1. initDB(ctx, nil) 被调用。
				// 2. 模拟DB链式调用，Updates方法返回的DB实例的Error字段为一个非特殊的错误。
				// 3. ignoreErr(err) 将此错误原样返回。
				// 4. 函数记录错误日志，并调用i18nfmt.New返回一个格式化的新错误。
				// 5. 函数最终返回这个新错误。
				dbErr := errors.New("some generic db error")
				mockDB := &gorm.DB{Error: dbErr}

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
				mockey.Mock(i18nfmt.New).Return(errors.New("UpdateByMapFail")).Build()

				err := dao.UpdateStatusById(ctx, nil, id, status)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByMapFail")
			})

			mockey.PatchConvey("子场景：数据库更新失败，返回ErrRecordNotFound错误", func() {
				// 场景描述：
				// 数据库更新操作未找到记录，此错误应被忽略。
				// 构造数据：
				// - tx *gorm.DB 设置为 nil
				// - 模拟的gorm.DB链式调用最终返回的Error为gorm.ErrRecordNotFound
				// 逻辑链路：
				// 1. initDB(ctx, nil) 被调用。
				// 2. 模拟DB链式调用，Updates方法返回的DB实例的Error字段为gorm.ErrRecordNotFound。
				// 3. ignoreErr(gorm.ErrRecordNotFound) 返回 nil。
				// 4. 函数最终返回nil。
				mockDB := &gorm.DB{Error: gorm.ErrRecordNotFound}
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()

				err := dao.UpdateStatusById(ctx, nil, id, status)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：数据库更新失败，返回RASP错误且在非线上环境", func() {
				// 场景描述：
				// 数据库更新操作返回RASP错误，在非线上环境下此错误应被忽略。
				// 构造数据：
				// - tx *gorm.DB 设置为 nil
				// - 模拟的gorm.DB链式调用最终返回的Error为一个RASP错误
				// - 模拟 env.IsOnline() 返回 false
				// 逻辑链路：
				// 1. 模拟DB链式调用，Updates方法返回包含"API blocked by RASP"的错误。
				// 2. ignoreErr调用env.IsOnline()，得到false。
				// 3. ignoreErr(raspErr) 返回 nil。
				// 4. 函数最终返回nil。
				raspErr := errors.New("some error: API blocked by RASP")
				mockDB := &gorm.DB{Error: raspErr}

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()

				err := dao.UpdateStatusById(ctx, nil, id, status)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("子场景：数据库更新失败，返回RASP错误且在线上环境", func() {
				// 场景描述：
				// 数据库更新操作返回RASP错误，在线上环境下此错误不应被忽略。
				// 构造数据：
				// - tx *gorm.DB 设置为 nil
				// - 模拟的gorm.DB链式调用最终返回的Error为一个RASP错误
				// - 模拟 env.IsOnline() 返回 true
				// 逻辑链路：
				// 1. 模拟DB链式调用，Updates方法返回包含"API blocked by RASP"的错误。
				// 2. ignoreErr调用env.IsOnline()，得到true。
				// 3. ignoreErr(raspErr) 将错误原样返回。
				// 4. 函数记录错误日志并返回一个格式化的新错误。
				raspErr := errors.New("some error: API blocked by RASP")
				mockDB := &gorm.DB{Error: raspErr}

				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()
				mockey.Mock(env.IsOnline).Return(true).Build()
				mockey.Mock(logs.CtxError).To(func(ctx context.Context, format string, v ...interface{}) {}).Build()
				mockey.Mock(i18nfmt.New).Return(errors.New("UpdateByMapFail")).Build()

				err := dao.UpdateStatusById(ctx, nil, id, status)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByMapFail")
			})
		})

		mockey.PatchConvey("场景：使用事务（tx不为nil）", func() {
			// 在此场景下，initDB将直接返回传入的tx对象
			tx := &gorm.DB{}

			mockey.PatchConvey("子场景：数据库更新成功", func() {
				// 场景描述：
				// 当使用传入的事务对象时，数据库更新操作成功。
				// 构造数据：
				// - tx *gorm.DB 设置为一个非nil的gorm.DB实例
				// - 模拟的gorm.DB链式调用最终返回的Error为nil
				// 逻辑链路：
				// 1. initDB(ctx, tx) 被调用，由于tx不为nil，直接返回tx。
				// 2. 模拟tx实例的 Table -> Where -> Updates 链式调用。
				// 3. Updates 调用返回的DB实例的Error字段为nil。
				// 4. ignoreErr(nil) 返回 nil。
				// 5. 函数最终返回nil，表示成功。
				mockDB := &gorm.DB{Error: nil}
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Updates).Return(mockDB).Build()

				err := dao.UpdateStatusById(ctx, tx, id, status)

				convey.So(err, convey.ShouldBeNil)
			})
		})
	})
}

func Test_riskClauseTemplateDaoImpl_UpdateByMap_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_riskClauseTemplateDaoImpl_UpdateByMap", t, func() {
		// 准备通用测试数据
		ctx := context.Background()
		dao := riskClauseTemplateDaoImpl{}
		id := int64(123)
		updates := map[string]interface{}{"status": 1}

		mockey.PatchConvey("场景：更新成功（不使用事务）", func() {
			// 场景描述：
			// 这是一个成功的更新操作，没有使用数据库事务。
			// 构造数据：
			// - tx 为 nil
			// - id 和 updates 为有效值
			// 逻辑链路：
			// 1. initDB 将使用全局 _dbClient。
			// 2. Mock GORM 的 Updates 方法返回一个 nil error。
			// 3. ignoreErr 函数将返回 nil。
			// 4. 函数最终返回 nil，表示更新成功。

			// 初始化全局 DB 客户端以供 initDB 使用
			mockDB := &gorm.DB{}
			_dbClient = &gorm.DB{}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := dao.UpdateByMap(ctx, nil, id, updates)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：更新成功（使用事务）", func() {
			// 场景描述：
			// 这是一个成功的更新操作，并且在数据库事务中执行。
			// 构造数据：
			// - tx 不为 nil
			// - id 和 updates 为有效值
			// 逻辑链路：
			// 1. initDB 将直接返回传入的 tx 对象。
			// 2. Mock GORM 在 tx 对象上的 Updates 方法返回一个 nil error。
			// 3. ignoreErr 函数将返回 nil。
			// 4. 函数最终返回 nil，表示更新成功。

			mockTx := &gorm.DB{}
			mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockTx).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: nil}).Build()

			err := dao.UpdateByMap(ctx, mockTx, id, updates)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：数据库更新失败", func() {
			// 场景描述：
			// 模拟数据库执行更新操作时发生通用错误。
			// 构造数据：
			// - tx 为 nil
			// 逻辑链路：
			// 1. Mock GORM 的 Updates 方法返回一个通用错误。
			// 2. ignoreErr 函数将透传这个错误。
			// 3. 函数将记录错误日志并返回一个国际化的错误信息 "UpdateByMapFail"。

			dbErr := errors.New("some database error")
			mockDB := &gorm.DB{}
			_dbClient = &gorm.DB{}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()

			err := dao.UpdateByMap(ctx, nil, id, updates)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByMapFail")
		})

		mockey.PatchConvey("场景：更新时记录未找到", func() {
			// 场景描述：
			// 模拟更新一个不存在的记录，GORM 返回 ErrRecordNotFound。
			// 构造数据：
			// - tx 为 nil
			// 逻辑链路：
			// 1. Mock GORM 的 Updates 方法返回 gorm.ErrRecordNotFound。
			// 2. ignoreErr 函数会忽略此特定错误并返回 nil。
			// 3. 函数最终返回 nil，表示操作被视为成功（或无害）。

			mockDB := &gorm.DB{}
			_dbClient = &gorm.DB{}

			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			err := dao.UpdateByMap(ctx, nil, id, updates)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：非线上环境遇到 RASP 错误", func() {
			// 场景描述：
			// 模拟在非线上环境（如开发、测试）中，数据库操作被 RASP 阻止。
			// 构造数据：
			// - tx 为 nil
			// 逻辑链路：
			// 1. Mock GORM 的 Updates 方法返回一个包含 "API blocked by RASP" 的错误。
			// 2. Mock env.IsOnline 返回 false。
			// 3. ignoreErr 函数会识别并忽略 RASP 错误，返回 nil。
			// 4. 函数最终返回 nil。

			raspErr := errors.New("something went wrong: API blocked by RASP")
			mockDB := &gorm.DB{}
			_dbClient = &gorm.DB{}

			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()

			err := dao.UpdateByMap(ctx, nil, id, updates)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景：线上环境遇到 RASP 错误", func() {
			// 场景描述：
			// 模拟在线上环境中，数据库操作被 RASP 阻止。
			// 构造数据：
			// - tx 为 nil
			// 逻辑链路：
			// 1. Mock GORM 的 Updates 方法返回一个包含 "API blocked by RASP" 的错误。
			// 2. Mock env.IsOnline 返回 true。
			// 3. ignoreErr 函数不会忽略此错误，会将其透传。
			// 4. 函数将记录错误日志并返回一个国际化的错误信息 "UpdateByMapFail"。

			raspErr := errors.New("something went wrong: API blocked by RASP")
			mockDB := &gorm.DB{}
			_dbClient = &gorm.DB{}

			mockey.Mock(env.IsOnline).Return(true).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: raspErr}).Build()

			err := dao.UpdateByMap(ctx, nil, id, updates)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "UpdateByMapFail")
		})
	})
}

func Test_riskClauseTemplateDaoImpl_Create_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test riskClauseTemplateDaoImpl.Create", t, func() {
		// Common test data and setup
		ctx := context.Background()
		dao := riskClauseTemplateDaoImpl{}
		entity := &model.RiskClauseTemplateDB{
			ClauseNo: "TEST-001",
		}

		// This mock is for the i18nfmt.New call, to ensure the error message is predictable
		mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string {
			return v
		}).Build()

		mockey.PatchConvey("Scenario: Using global DB client (tx is nil)", func() {
			// Initialize the global DB client for this set of tests
			_dbClient = &gorm.DB{}
			mockDB := &gorm.DB{}

			mockey.PatchConvey("Case: DB create succeeds", func() {
				// 场景描述：
				// 构造数据：tx为nil，entity为一个有效的RiskClauseTemplateDB对象。
				// 逻辑链路：
				// 1. 调用initDB(ctx, nil)，返回全局_dbClient。
				// 2. Mock _dbClient.WithContext，返回一个mockDB。
				// 3. Mock mockDB.Table，返回同一个mockDB。
				// 4. Mock mockDB.Create，返回一个无错误的gorm.DB对象。
				// 5. ignoreErr(nil)返回nil。
				// 6. 函数成功返回，结果为nil。
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: nil}).Build()

				err := dao.Create(ctx, nil, entity)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: DB create fails with a generic error", func() {
				// 场景描述：
				// 构造数据：tx为nil，entity为一个有效的RiskClauseTemplateDB对象。
				// 逻辑链路：
				// 1. 调用initDB(ctx, nil)，返回全局_dbClient。
				// 2. Mock _dbClient.WithContext，返回一个mockDB。
				// 3. Mock mockDB.Table，返回同一个mockDB。
				// 4. Mock mockDB.Create，返回一个包含通用错误的gorm.DB对象。
				// 5. ignoreErr(err)返回原始错误。
				// 6. 函数执行错误处理逻辑，打印日志并返回i18nfmt.New创建的错误。
				dbErr := errors.New("generic db error")
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()

				err := dao.Create(ctx, nil, entity)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, "createRiskClauseTemplateFail")
			})

			mockey.PatchConvey("Case: DB create fails with an ignored error (ErrRecordNotFound)", func() {
				// 场景描述：
				// 构造数据：tx为nil，entity为一个有效的RiskClauseTemplateDB对象。
				// 逻辑链路：
				// 1. 调用initDB(ctx, nil)，返回全局_dbClient。
				// 2. Mock _dbClient.WithContext，返回一个mockDB。
				// 3. Mock mockDB.Table，返回同一个mockDB。
				// 4. Mock mockDB.Create，返回一个包含gorm.ErrRecordNotFound错误的gorm.DB对象。
				// 5. ignoreErr(gorm.ErrRecordNotFound)返回nil。
				// 6. 函数成功返回，结果为nil。
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

				err := dao.Create(ctx, nil, entity)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: DB create fails with an ignored error (RASP, non-online env)", func() {
				// 场景描述：
				// 构造数据：tx为nil, 非线上环境。
				// 逻辑链路：
				// 1. Mock env.IsOnline()返回false。
				// 2. Mock DB Create操作返回RASP错误。
				// 3. ignoreErr函数会忽略此RASP错误，返回nil。
				// 4. 函数最终返回nil。
				raspErr := errors.New("API blocked by RASP")
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()

				err := dao.Create(ctx, nil, entity)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: DB create fails with a non-ignored error (RASP, online env)", func() {
				// 场景描述：
				// 构造数据：tx为nil, 线上环境。
				// 逻辑链路：
				// 1. Mock env.IsOnline()返回true。
				// 2. Mock DB Create操作返回RASP错误。
				// 3. ignoreErr函数不会忽略此RASP错误，返回原始错误。
				// 4. 函数执行错误处理逻辑，返回i18nfmt.New创建的错误。
				raspErr := errors.New("API blocked by RASP")
				mockey.Mock((*gorm.DB).WithContext).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: raspErr}).Build()
				mockey.Mock(env.IsOnline).Return(true).Build()

				err := dao.Create(ctx, nil, entity)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, "createRiskClauseTemplateFail")
			})
		})

		mockey.PatchConvey("Scenario: Using transaction (tx is not nil)", func() {
			mockTx := &gorm.DB{}

			mockey.PatchConvey("Case: DB create succeeds", func() {
				// 场景描述：
				// 构造数据：tx不为nil，为一个mock的gorm.DB对象。
				// 逻辑链路：
				// 1. 调用initDB(ctx, tx)，直接返回传入的tx。
				// 2. Mock tx.Table，返回tx。
				// 3. Mock tx.Create，返回一个无错误的gorm.DB对象。
				// 4. ignoreErr(nil)返回nil。
				// 5. 函数成功返回，结果为nil。
				mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: nil}).Build()

				err := dao.Create(ctx, mockTx, entity)

				convey.So(err, convey.ShouldBeNil)
			})

			mockey.PatchConvey("Case: DB create fails with a generic error", func() {
				// 场景描述：
				// 构造数据：tx不为nil，为一个mock的gorm.DB对象。
				// 逻辑链路：
				// 1. 调用initDB(ctx, tx)，直接返回传入的tx。
				// 2. Mock tx.Table，返回tx。
				// 3. Mock tx.Create，返回一个包含通用错误的gorm.DB对象。
				// 4. ignoreErr(err)返回原始错误。
				// 5. 函数执行错误处理逻辑，返回i18nfmt.New创建的错误。
				dbErr := errors.New("tx error")
				mockey.Mock((*gorm.DB).Table).Return(mockTx).Build()
				mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
				mockey.Mock(env.IsOnline).Return(false).Build()

				err := dao.Create(ctx, mockTx, entity)

				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldEqual, "createRiskClauseTemplateFail")
			})
		})
	})
}

func Test_NewRiskClauseTemplateDao_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test NewRiskClauseTemplateDao", t, func() {
		mockey.PatchConvey("should return the singleton instance", func() {
			// 场景描述：
			// 测试NewRiskClauseTemplateDao函数能否成功返回一个非空的单例实例。
			// 构造数据：
			// 无需构造特殊数据。
			// 逻辑链路：
			// 1. 直接调用 NewRiskClauseTemplateDao() 函数。
			// 2. 验证返回的实例不为nil。
			// 3. 验证返回的实例与包内定义的单例 _riskClauseTemplateDaoInstance 是同一个实例。

			// 调用
			dao := NewRiskClauseTemplateDao()

			// 断言
			convey.So(dao, convey.ShouldNotBeNil)
			convey.So(dao, convey.ShouldEqual, _riskClauseTemplateDaoInstance)
		})
	})
}

package dal

import (
	"context"

	"gorm.io/gorm"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

const (
	tCommonUse = "common_use"
)

type CommonUseDao interface {
	CreateCommonUse(ctx context.Context, tx *gorm.DB, commonUse *model.CommonUseDB) error
	GetCommonUseByKey(ctx context.Context, tx *gorm.DB, key string) (*model.CommonUseDB, error)
	ListCommonUseByKey(ctx context.Context, tx *gorm.DB, keys []string) ([]*model.CommonUseDB, error)
}

var _commonUseDaoInstance = &commonUseDaoImpl{}

func NewCommonUseDao() CommonUseDao {
	return _commonUseDaoInstance
}

type commonUseDaoImpl struct {
}

func (c *commonUseDaoImpl) GetCommonUseByKey(ctx context.Context, tx *gorm.DB, useKey string) (*model.CommonUseDB, error) {
	var ret model.CommonUseDB
	db := initDB(ctx, tx).Table(tCommonUse).Where("common_use_key = ?", useKey)
	if err := db.First(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "GetCommonUseByKeyFail, useKey:%s, err:%s", useKey, err.Error())
		return nil, i18nfmt.New(ctx, "GetCommonUseByKeyFail")
	}
	return &ret, nil
}

func (c *commonUseDaoImpl) CreateCommonUse(ctx context.Context, tx *gorm.DB, commonUse *model.CommonUseDB) error {
	return ignoreErr(initDB(ctx, tx).Table(tCommonUse).Create(commonUse).Error)
}

func (c *commonUseDaoImpl) ListCommonUseByKey(ctx context.Context, tx *gorm.DB, keys []string) ([]*model.CommonUseDB, error) {
	ret := make([]*model.CommonUseDB, 0)
	db := initDB(ctx, tx).Table(tCommonUse).Where("common_use_key in (?)", keys)
	if err := db.Find(&ret).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ListCommonUseByKeyFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "ListCommonUseByKeyFail")
	}
	return ret, nil
}

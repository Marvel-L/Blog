package dal

import (
	"context"
	"fmt"
	"testing"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
)

func Test_contractSettlementDaoImpl_UpdateByMap(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractSettlementDaoImpl{}
			err := v.UpdateByMap(context.Background(), &gorm.DB{}, 0, map[string]interface{}{"": nil})

			// Assert
			convey.So(err != nil, convey.ShouldEqual, false)
		})
	})
	t.Run("case updateFail ignoreErr", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(initDB).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Model).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).WithContext).Return(&gorm.DB{}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock((*gorm.DB).Table).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Where).Return(&gorm.DB{}).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: fmt.Errorf("UpdatesFail")}).Build()
			mockey.Mock(i18nfmt.New).To(func(ctx context.Context, text string) error { return fmt.Errorf(text) }).Build()

			// Act
			_dbClient = &gorm.DB{}
			v := &contractSettlementDaoImpl{}
			err := v.UpdateByMap(context.Background(), &gorm.DB{}, 0, map[string]interface{}{"": nil})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "UpdateByMapFail")
		})
	})
}

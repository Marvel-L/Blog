package dal

import (
	"context"

	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"

	"code.byted.org/gopkg/logs"
	"gorm.io/gorm"
)

const (
	tToolOperationLog = "tool_operation_log"
)

// ToolOperationLogDao 工具操作日志表 DAO
// 仅提供 Create 能力，由上层控制事务边界。
type ToolOperationLogDao interface {
	Create(ctx context.Context, tx *gorm.DB, operationLog *model.ToolOperationLogDB) error
}

var _toolOperationLogDaoInstance = &toolOperationLogDaoImpl{}

func NewToolOperationLogDao() ToolOperationLogDao {
	return _toolOperationLogDaoInstance
}

type toolOperationLogDaoImpl struct{}

func (d *toolOperationLogDaoImpl) Create(ctx context.Context, tx *gorm.DB, operationLog *model.ToolOperationLogDB) error {
	if operationLog == nil {
		return i18nfmt.New(ctx, "tool_operation_log_is_nil")
	}

	db := initDB(ctx, tx).Table(tToolOperationLog)
	if err := db.Create(operationLog).Error; ignoreErr(err) != nil {
		logs.CtxError(ctx, "ToolOperationLogCreateFail, contract_no=%s, err=%v", operationLog.ContractNo, err)
		return i18nfmt.New(ctx, "ToolOperationLogCreateFail")
	}

	return nil
}

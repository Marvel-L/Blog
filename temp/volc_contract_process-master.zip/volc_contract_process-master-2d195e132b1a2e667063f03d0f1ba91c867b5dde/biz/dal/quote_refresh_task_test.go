package dal

import (
	"context"
	"errors"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"gorm.io/gorm"
	"testing"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/env"
)

func Test_quoteRefreshTaskDaoImpl_Create(t *testing.T) {
	t.Run("创建成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			entity := &model.QuoteRefreshTaskDB{
				RefreshApprovalID: "refresh-1",
				QuoteID:           "quote-1",
				ContractNo:        "CN001",
				RefreshScene:      "manual",
				BaseDB: model.BaseDB{
					Status: 1,
				},
			}
			var gotEntity *model.QuoteRefreshTaskDB

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).To(func(db *gorm.DB, value interface{}) *gorm.DB {
				gotEntity = value.(*model.QuoteRefreshTaskDB)
				return &gorm.DB{}
			}).Build()

			err := dao.Create(ctx, nil, entity)

			convey.So(err, convey.ShouldBeNil)
			convey.So(gotEntity, convey.ShouldResemble, entity)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			entity := &model.QuoteRefreshTaskDB{RefreshApprovalID: "refresh-1"}
			dbErr := errors.New("create failed")
			expectedErr := errors.New("CreateQuoteRefreshTaskFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Create).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.Create(ctx, nil, entity)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

func Test_quoteRefreshTaskDaoImpl_FindByRefreshApprovalID(t *testing.T) {
	t.Run("查询成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			expected := &model.QuoteRefreshTaskDB{
				RefreshApprovalID: "refresh-1",
				QuoteID:           "quote-1",
				ContractNo:        "CN001",
				RefreshScene:      "manual",
				BaseDB: model.BaseDB{
					Id:     12,
					Status: 2,
				},
			}
			var whereCalls []string

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).First).To(func(db *gorm.DB, dest interface{}, conds ...interface{}) *gorm.DB {
				*(dest.(*model.QuoteRefreshTaskDB)) = *expected
				return &gorm.DB{}
			}).Build()

			ret, err := dao.FindByRefreshApprovalID(ctx, nil, "refresh-1")

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "refresh_approval_id = ?|[refresh-1]")
			convey.So(ret, convey.ShouldResemble, expected)
		})
	})

	t.Run("记录不存在时返回空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: gorm.ErrRecordNotFound}).Build()

			ret, err := dao.FindByRefreshApprovalID(ctx, nil, "refresh-1")

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("返回空主键时返回空", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{}).Build()

			ret, err := dao.FindByRefreshApprovalID(ctx, nil, "refresh-1")

			convey.So(err, convey.ShouldBeNil)
			convey.So(ret, convey.ShouldBeNil)
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("query failed")
			expectedErr := errors.New("FindQuoteRefreshTaskFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).First).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			ret, err := dao.FindByRefreshApprovalID(ctx, nil, "refresh-1")

			convey.So(err, convey.ShouldEqual, expectedErr)
			convey.So(ret, convey.ShouldBeNil)
		})
	})
}

func Test_quoteRefreshTaskDaoImpl_UpdateStatus(t *testing.T) {
	t.Run("更新成功", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			var whereCalls []string
			var gotUpdates map[string]interface{}

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).To(func(db *gorm.DB, query interface{}, args ...interface{}) *gorm.DB {
				whereCalls = append(whereCalls, fmt.Sprintf("%v|%v", query, args))
				return mockDB
			}).Build()
			mockey.Mock((*gorm.DB).Updates).To(func(db *gorm.DB, values interface{}) *gorm.DB {
				gotUpdates = values.(map[string]interface{})
				return &gorm.DB{}
			}).Build()

			err := dao.UpdateStatus(ctx, nil, 12, 3)

			convey.So(err, convey.ShouldBeNil)
			convey.So(whereCalls, convey.ShouldContain, "id = ?|[12]")
			convey.So(gotUpdates, convey.ShouldResemble, map[string]interface{}{"status": 3})
		})
	})

	t.Run("数据库返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			ctx := context.Background()
			dao := &quoteRefreshTaskDaoImpl{}
			mockDB := &gorm.DB{}
			dbErr := errors.New("update failed")
			expectedErr := errors.New("UpdateQuoteRefreshTaskStatusFail")

			mockey.Mock(initDB).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Table).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Where).Return(mockDB).Build()
			mockey.Mock((*gorm.DB).Updates).Return(&gorm.DB{Error: dbErr}).Build()
			mockey.Mock(env.IsOnline).Return(false).Build()
			mockey.Mock(i18nfmt.New).Return(expectedErr).Build()

			err := dao.UpdateStatus(ctx, nil, 12, 3)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})
	})
}

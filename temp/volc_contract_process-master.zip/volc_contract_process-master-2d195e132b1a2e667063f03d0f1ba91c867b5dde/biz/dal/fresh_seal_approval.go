package dal

import (
	"code.byted.org/gopkg/logs"
	"context"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/proxy/dkmscli"
	"volc_contract_process/pkg/util"

	"gorm.io/gorm"

	"volc_contract_process/biz/dal/model"
)

const (
	tBFreshSealApproval = "fresh_seal_approval"
)

// FreshSealListParamExt 鲜章申请表列表查询参数扩展结构体
type FreshSealListParamExt struct {
	bizmodels.FreshSealListParam
	ApplyIds []string
}

type FreshSealApprovalDao interface {
	Create(ctx context.Context, tx *gorm.DB, entity *model.FreshSealApprovalDB) error
	UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error
	FindByApplyId(ctx context.Context, tx *gorm.DB, applyId string) (*model.FreshSealApprovalDB, error)
	List(ctx context.Context, tx *gorm.DB, param *FreshSealListParamExt) (model.FreshSealApprovalDBList, int64, error)
	ListByStatus(ctx context.Context, tx *gorm.DB, status int, limit, offset int) (model.FreshSealApprovalDBList, int64, error)
}

var _freshSealApprovalDaoInstance = &freshSealApprovalDaoImpl{}

func NewFreshSealApprovalDao() FreshSealApprovalDao {
	return _freshSealApprovalDaoInstance
}

type freshSealApprovalDaoImpl struct{}

// Create 创建鲜章申请表
func (p *freshSealApprovalDaoImpl) Create(ctx context.Context, tx *gorm.DB, entity *model.FreshSealApprovalDB) error {
	if entity == nil {
		return nil
	}
	// 敏感数据加密处理，dkms密钥与合同中心相同,未使用dkms自动加解密插件
	if entity.ContactPhone != "" {
		contactPhone, err := dkmscli.EncryptWithContext(ctx, entity.ContactPhone)
		if err != nil {
			logs.CtxError(ctx, "Encrypt ContactPhone Error", err.Error())
			return err
		}
		entity.ContactPhone = contactPhone
	}
	if entity.AddressInfo != "" {
		addressInfo, err := dkmscli.EncryptWithContext(ctx, entity.AddressInfo)
		if err != nil {
			logs.CtxError(ctx, "Encrypt AddressInfo Error", err.Error())
			return err
		}
		entity.AddressInfo = addressInfo
	}

	db := initDB(ctx, tx)
	err := db.Table(tBFreshSealApproval).Create(entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "CreateFail, err:%s", err.Error())
		return i18nfmt.New(ctx, "CreateFail")
	}

	return nil
}

// UpdateByMap 根据ID更新指定字段
func (p *freshSealApprovalDaoImpl) UpdateByMap(ctx context.Context, tx *gorm.DB, id uint64, updates map[string]interface{}) error {
	// 敏感数据加密处理，dkms密钥与合同中心相同,未使用dkms自动加解密插件
	if contactPhone, ok := updates["contact_phone"]; ok {
		if contactPhoneStr, ok := contactPhone.(string); ok && contactPhoneStr != "" {
			secContactPhone, err := dkmscli.EncryptWithContext(ctx, contactPhoneStr)
			if err != nil {
				logs.CtxError(ctx, "EncryptUpdateMap EncryptWithContext ContactPhone Fail, err: %v", err)
				return err
			}
			updates["contact_phone"] = secContactPhone
		}
	}
	if addressInfo, ok := updates["address_info"]; ok {
		if addressInfoStr, ok := addressInfo.(string); ok && addressInfoStr != "" {
			secAddressInfo, err := dkmscli.EncryptWithContext(ctx, addressInfoStr)
			if err != nil {
				logs.CtxError(ctx, "EncryptUpdateMap EncryptWithContext AddressInfo Fail, err: %v", err)
				return err
			}
			updates["address_info"] = secAddressInfo
		}
	}

	db := initDB(ctx, tx)
	err := db.Table(tBFreshSealApproval).Where("id = ?", id).Updates(updates).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "UpdateByMapFail, id=%d, err:%v", id, err)
		return i18nfmt.New(ctx, "UpdateByMapFail")
	}
	return nil
}

// FindByApplyId 根据申请单号查询鲜章申请表
func (p *freshSealApprovalDaoImpl) FindByApplyId(ctx context.Context, tx *gorm.DB, applyId string) (*model.FreshSealApprovalDB, error) {

	if applyId == "" {
		logs.CtxError(ctx, "FindByApplyIdFail, applyId is empty")
		return nil, i18nfmt.New(ctx, "FindByApplyIdFail, applyId is empty")

	}
	db := initDB(ctx, tx)
	var entity model.FreshSealApprovalDB
	err := db.Table(tBFreshSealApproval).Where("apply_id = ?", applyId).First(&entity).Error
	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "FindByApplyIdFail, err:%s", err.Error())
		return nil, i18nfmt.New(ctx, "FindByApplyIdFail")
	}
	if entity.ContactPhone != "" {
		// 解密敏感数据
		contactPhone, err := dkmscli.DecryptWithContext(ctx, entity.ContactPhone)
		if err != nil {
			logs.CtxError(ctx, "Decrypt ContactPhone Error", err.Error())
			return nil, err
		}
		entity.ContactPhone = contactPhone
	}
	if entity.AddressInfo != "" {
		// 解密敏感数据
		addressInfo, err := dkmscli.DecryptWithContext(ctx, entity.AddressInfo)
		if err != nil {
			logs.CtxError(ctx, "Decrypt AddressInfo Error", err.Error())
			return nil, err
		}
		entity.AddressInfo = addressInfo
	}

	return &entity, nil
}

// List 查询鲜章申请表列表
func (p *freshSealApprovalDaoImpl) List(ctx context.Context, tx *gorm.DB, param *FreshSealListParamExt) (model.FreshSealApprovalDBList, int64, error) {

	if param == nil {
		logs.CtxError(ctx, "ListFail, param is nil")
		return nil, 0, i18nfmt.New(ctx, "ListFail, param is nil")

	}
	if param.ContractNo == "" && len(param.ApplyIds) == 0 && len(param.Status) == 0 && len(param.ApplyIds) == 0 && param.Limit == 0 {
		return nil, 0, nil

	}
	db := initDB(ctx, tx)
	query := db.Table(tBFreshSealApproval)

	// 添加查询条件
	if param.ContractNo != "" {
		query = query.Where("apply_id IN (SELECT apply_id FROM fresh_seal_approval_item WHERE contract_no = ?)", param.ContractNo)
	}

	if param.AccountID != "" {
		query = query.Where("account_id = ?", param.AccountID)
	}
	if len(param.Status) > 0 {
		statusList, _ := util.SplitInt(param.Status, ",")
		query = query.Where("status IN ?", statusList)
	}
	// 添加申请单号列表查询条件
	if len(param.ApplyIds) > 0 {
		query = query.Where("apply_id IN ?", param.ApplyIds)
	}
	// 查询列表
	var list model.FreshSealApprovalDBList
	// 统计总数
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	query = query.Order("id desc")
	if param.Limit > 0 {
		query = query.Limit(param.Limit).Offset(param.Offset)
	}

	err := query.Find(&list).Error

	if ignoreErr(err) != nil {
		logs.CtxError(ctx, "freshSealApprovalListFail, err:%s", err.Error())
		return nil, 0, err
	}

	// 解密敏感数据
	for _, item := range list {
		if item == nil {
			continue
		}
		if item.ContactPhone != "" {
			// 解密敏感数据
			contactPhone, err := dkmscli.DecryptWithContext(ctx, item.ContactPhone)
			if err != nil {
				logs.CtxError(ctx, "Decrypt ContactPhone Error", err.Error())
				return nil, 0, err
			}
			item.ContactPhone = contactPhone
		}
		if item.AddressInfo != "" {
			// 解密敏感数据
			addressInfo, err := dkmscli.DecryptWithContext(ctx, item.AddressInfo)
			if err != nil {
				logs.CtxError(ctx, "Decrypt AddressInfo Error", err.Error())
				return nil, 0, err
			}
			item.AddressInfo = addressInfo
		}
	}

	return list, total, nil
}

// ListByStatus 根据状态查询申请单列表
func (p *freshSealApprovalDaoImpl) ListByStatus(ctx context.Context, tx *gorm.DB, status int, limit, offset int) (model.FreshSealApprovalDBList, int64, error) {
	db := initDB(ctx, tx)
	query := db.Table(tBFreshSealApproval).Where("status = ?", status)

	if limit > 0 {
		query = query.Limit(limit)
	}
	if offset > 0 {
		query = query.Offset(offset)
	}
	var total int64
	if err := query.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	var list model.FreshSealApprovalDBList
	if err := query.Order("created_time DESC").Find(&list).Error; err != nil {
		return nil, 0, err
	}

	// 解密敏感数据
	for _, item := range list {
		if item == nil {
			continue
		}
		if item.ContactPhone != "" {
			// 解密敏感数据
			contactPhone, err := dkmscli.DecryptWithContext(ctx, item.ContactPhone)
			if err != nil {
				logs.CtxError(ctx, "Decrypt ContactPhone Error", err.Error())
				return nil, 0, err
			}
			item.ContactPhone = contactPhone
		}
		if item.AddressInfo != "" {
			// 解密敏感数据
			addressInfo, err := dkmscli.DecryptWithContext(ctx, item.AddressInfo)
			if err != nil {
				logs.CtxError(ctx, "Decrypt AddressInfo Error", err.Error())
				return nil, 0, err
			}
			item.AddressInfo = addressInfo
		}
	}

	return list, total, nil
}

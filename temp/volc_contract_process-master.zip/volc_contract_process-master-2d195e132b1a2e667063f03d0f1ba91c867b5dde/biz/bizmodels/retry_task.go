package bizmodels

type RetryTaskDetail interface {
	GenTaskInfo() string
}

func NewDefaultRetryTaskDetail() RetryTaskDetail {
	return &defaultRetryTaskDetail{}
}

type defaultRetryTaskDetail struct {
}

func (d *defaultRetryTaskDetail) GenTaskInfo() string {
	return ""
}

type CallRetryTaskReq struct {
	Token      string // token
	Scene      int    // 业务场景
	TaskType   int    // 重试类型
	Identifier string // 业务重试唯一标识，比如合同号
}

type QuoteRetryDetail struct {
	CustomEmail     string `json:"CustomEmail"`     //
	CustomPartyName string `json:"CustomPartyName"` //
	CustomTel       string `json:"customTel"`       //
	CardNo          string `json:"CardNo"`          //
	DocumentType    string `json:"DocumentType"`
	RegistCountry   string `json:"RegistCountry"`
	CustomNickName  string `json:"CustomNickName"` //
}

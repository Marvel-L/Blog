package bizmodels

type RichTextInfo struct {
	ID                int                `json:"id"`                // 富文本id
	Richtext          string             `json:"richtext"`          // 富文本主体内容，对后端来说是个json，不用关心内容
	RichtextPlainText string             `json:"richtextPlainText"` // 纯文字版本，前端在提交时解析出来写入（用在页面上回复引用渲染和机器人通知等场景）
	MentionUserList   []string           `json:"mentionUserList"`   // 提及到的人列表，前端在提交时解析出来写入
	AttachmentList    []*FileVersionData `json:"attachmentList"`    // 附件列表
	ImageIdList       []string           `json:"imageIdList"`       // 如果采用统一id转换的方案（待定）,需要这两个字段，前端提交时需要解析图片ids放到这个字段里
	ImageInfoList     []ImageInfo        `json:"imageInfoList"`     // 富文本关联图片链接
}

type ImageInfo struct {
	UUID string `json:"uuid"` // 图片唯一ID
	URL  string `json:"url"`  // 图片预览链接
}

func (v *RichTextInfo) IsEmpty() bool {
	if v == nil {
		return true
	}
	return len(v.Richtext) == 0 && len(v.RichtextPlainText) == 0 && len(v.MentionUserList) == 0 && len(v.AttachmentList) == 0 && len(v.ImageIdList) == 0
}

package bizmodels

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	_const "volc_contract_process/pkg/const"
)

func Test_FetchFeishuFileType(t *testing.T) {
	mockey.PatchConvey("Test FetchFeishuFileType with nil receiver", t, func() {
		actual := (*MetaAttachmentExtra)(nil).FetchFeishuFileType()
		convey.So(actual, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("Test FetchFeishuFileType with Sealed and Archived both No", t, func() {
		e := &MetaAttachmentExtra{
			Sealed:   _const.No,
			Archived: _const.No,
		}
		actual := e.FetchFeishuFileType()
		convey.So(actual, convey.ShouldEqual, _const.FILE_TYPE_ATTACHMENT)
	})

	mockey.PatchConvey("Test FetchFeishuFileType with Sealed and Archived both Yes", t, func() {
		e := &MetaAttachmentExtra{
			Sealed:   _const.Yes,
			Archived: _const.Yes,
		}
		actual := e.FetchFeishuFileType()
		convey.So(actual, convey.ShouldEqual, _const.FILE_TYPE_CAUSE)
	})

	mockey.PatchConvey("Test FetchFeishuFileType with other combinations of Sealed and Archived", t, func() {
		e := &MetaAttachmentExtra{
			Sealed:   _const.No,
			Archived: _const.Yes,
		}
		actual := e.FetchFeishuFileType()
		convey.So(actual, convey.ShouldEqual, _const.FILE_TYPE_TEXT)

		e = &MetaAttachmentExtra{
			Sealed:   _const.Yes,
			Archived: _const.No,
		}
		actual = e.FetchFeishuFileType()
		convey.So(actual, convey.ShouldEqual, _const.FILE_TYPE_CAUSE)
	})
}

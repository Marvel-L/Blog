package bizmodels

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

// BizContractDetailParam 业务合同详情
type BizContractDetailParam struct {
	SourceType      _const.SourceType //
	CurrentOperator string            //
	AccountID       int64             //
	ContractNo      string            // 合同号
}

func (p *BizContractDetailParam) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.SourceType == _const.SourceTypeOpen && p.AccountID == 0 {
		return errors.ErrMissingParam.WithArgs("AccountID")
	}
	if len(p.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

type BizContractDownloadResp struct {
	FileURL string
}

type BizContractDownloadFileParam struct {
	SourceType _const.SourceType //
	DownloadID string
}

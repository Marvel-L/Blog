package bizmodels

type GetContractRedirectInfoReq struct {
	ContractNo    string
	OperatorEmail string
}

type ContractRedirectInfo struct {
	RedirectPage string
}

type GetContractRedirectInfoResp struct {
	ContractRedirectInfo *ContractRedirectInfo
}

package bizmodels

type FeishuContractMsg struct {
	EventType  string                   `json:"eventType"`
	EventToken string                   `json:"eventToken"`
	Events     []FeishuContractMsgEvent `json:"events"`
}

type FeishuContractMsgEvent struct {
	BizEventID   string            `json:"bizEventID"`
	SubEventType string            `json:"subEventType"`
	OrderKey     string            `json:"orderKey"`
	Content      string            `json:"content"`
	Props        map[string]string `json:"props"`
	EventTime    string            `json:"eventTime"`
}

type FeishuContractMsgContent struct {
	Header FeishuHeaderData `json:"header"` //
	Event  FeishuEventData  `json:"event"`
}

type FeishuHeaderData struct {
	EventId    string `json:"event_id"`   // 事件 ID
	EventType  string `json:"event_type"` // 事件类型
	EventTime  string `json:"eventTime"`
	TenantId   string `json:"tenant_id"`   // 租户 Key
	CreateTime string `json:"create_time"` // 事件创建时间戳（单位：毫秒）
	Token      string `json:"token"`       // 事件 Token
	AppId      string `json:"app_id"`      // 应用 ID（勿用，字节租户下所有业务方合同该字段均相同）
}

type FeishuEventData struct {
	ContractStageCode      int          `json:"contract_stage_code"`      // 合同阶段编码
	ContractStageName      string       `json:"contract_stage_name"`      // 合同阶段名称
	BusinessTypeCode       int          `json:"business_type_code"`       // 合同业务类型编码
	PreviousId             string       `json:"previous_id"`              // 上一份合同id
	PreviousContractNumber string       `json:"previous_contract_number"` // 上一份合同编号
	ContractId             string       `json:"contract_id"`              // 合同id
	ContractNumber         string       `json:"contract_number"`          // 合同编号
	GroupId                string       `json:"group_id"`                 // 分组id
	AppId                  string       `json:"app_id"`                   // 业务方AppId（可使用该字段区分合同来源）
	OpenDepartmentID       string       `json:"open_department_id"`       // 业务方部门id
	InformationChangeCode  int          `json:"information_change_code"`  // 合同信息变更编码
	InformationChangeName  string       `json:"information_change_name"`  // 合同变更信息名称
	ExtraInfo              string       `json:"extra_info"`
	HandoverInfo           HandoverInfo `json:"handover_info"` // 交接信息 【仅合同信息变更编码为6（合同归属人变更）时，推送该字段】
}

type HandoverInfo struct {
	SourceUserId   string `json:"source_user_id"`   // 事件的用户id 交接人id
	TargetUserId   string `json:"target_user_id"`   // 事件的用户id 被交接人id
	OperatorUserId string `json:"operator_user_id"` // 事件的用户id 操作人id
	OperationTime  string `json:"operation_time"`   // 操作时间（时间戳，单位：秒）
}

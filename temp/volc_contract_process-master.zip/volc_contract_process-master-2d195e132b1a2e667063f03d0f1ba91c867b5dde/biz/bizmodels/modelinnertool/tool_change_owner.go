package modelinnertool

import (
	"context"
	"strings"
	_const "volc_contract_process/pkg/const"

	bytedstrings "code.byted.org/gopkg/lang/strings"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/pkg/errors"
)

// ChangeContractOwnerReq 用于合同执行人/创建人/审批人变更
type ChangeContractOwnerReq struct {
	ContractNo               string                   `json:"contract_no"`                          // 合同编号，必填
	ChangeOperator           bool                     `json:"change_operator"`                      // 是否变更业务执行人
	ChangeCreator            bool                     `json:"change_creator"`                       // 是否变更合同创建人
	ChangeContractReviewer   bool                     `json:"change_contract_reviewer"`             // 是否变更合同审批人
	NewOperator              *ChangeOwnerUserInfo     `json:"new_operator,omitempty"`               // 当 ChangeOperator=true 时必填
	NewCreator               *ChangeOwnerUserInfo     `json:"new_creator,omitempty"`                // 当 ChangeCreator=true 时必填
	ApprovalRuleReplacements *ApprovalRuleReplacement `json:"approval_rule_replacements,omitempty"` // 当 ChangeContractReviewer=true 时必填
	CurrentOperator          string                   `json:"current_operator"`                     // 当前操作人（邮箱），必填
}

// ChangeOwnerUserInfo 人员基础信息
type ChangeOwnerUserInfo struct {
	JobID  string `json:"job_id,omitempty"`  // 工号，必填
	UserID string `json:"user_id,omitempty"` // 飞书开放平台的用户ID，非必填
}

// ApprovalRuleReplacement 审批规则替换定义
type ApprovalRuleReplacement struct {
	OldReviewerEmail string `json:"old_reviewer_email,omitempty"`
	OldReviewerJobID string `json:"old_reviewer_job_id,omitempty"`
	NewReviewerEmail string `json:"new_reviewer_email,omitempty"`
	NewReviewerJobID string `json:"new_reviewer_job_id,omitempty"`
	ContractStatus   *int   `json:"contract_status,omitempty"` // 非必填；传入时仅替换指定合同状态下的审批人
}

// Validate
func (r *ChangeContractOwnerReq) Validate(ctx context.Context) errors.APIError {
	if bytedstrings.IsEmpty(r.ContractNo) {
		return errors.ErrMissingParam.WithArgs("contract_no")
	}
	if bytedstrings.IsEmpty(r.CurrentOperator) {
		return errors.ErrMissingParam.WithArgs("current_operator")
	}

	if !r.ChangeOperator && !r.ChangeCreator && !r.ChangeContractReviewer {
		msg := i18nfmt.Sprintf(ctx, "至少需要选择一种变更类型: change_operator / change_creator / change_contract_reviewer")
		return errors.ErrInvalidParam.WithArgs(msg)
	}

	if r.ChangeOperator {
		if r.NewOperator == nil {
			return errors.ErrMissingParam.WithArgs("new_operator")
		}
		if bytedstrings.IsEmpty(r.NewOperator.JobID) {
			return errors.ErrMissingParam.WithArgs("new_operator.job_id")
		}
	}

	if r.ChangeCreator {
		if r.NewCreator == nil {
			return errors.ErrMissingParam.WithArgs("new_creator")
		}
		if bytedstrings.IsEmpty(r.NewCreator.JobID) {
			return errors.ErrMissingParam.WithArgs("new_creator.job_id")
		}
	}

	if r.ChangeContractReviewer {
		if r.ApprovalRuleReplacements == nil {
			return errors.ErrMissingParam.WithArgs("approval_rule_replacements")
		}
		if bytedstrings.IsEmpty(r.ApprovalRuleReplacements.OldReviewerEmail) {
			return errors.ErrMissingParam.WithArgs("old_reviewer_email")
		}
		if bytedstrings.IsEmpty(r.ApprovalRuleReplacements.OldReviewerJobID) {
			return errors.ErrMissingParam.WithArgs("old_reviewer_job_id")
		}
		if bytedstrings.IsEmpty(r.ApprovalRuleReplacements.NewReviewerEmail) {
			return errors.ErrMissingParam.WithArgs("new_reviewer_email")
		}
		if bytedstrings.IsEmpty(r.ApprovalRuleReplacements.NewReviewerJobID) {
			return errors.ErrMissingParam.WithArgs("new_reviewer_job_id")
		}
	}

	return nil
}

func (r *ChangeContractOwnerReq) BuildChangeType() string {
	var types []string
	if r.ChangeOperator {
		types = append(types, _const.ToolOperationTypeChangeOperator)
	}
	if r.ChangeCreator {
		types = append(types, _const.ToolOperationTypeChangeCreator)
	}
	if r.ChangeContractReviewer {
		types = append(types, _const.ToolOperationTypeChangeContractReviewer)
	}
	return strings.Join(types, ",")
}

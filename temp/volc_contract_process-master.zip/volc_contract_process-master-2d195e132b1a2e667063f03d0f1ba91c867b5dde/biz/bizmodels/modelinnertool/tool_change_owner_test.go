package modelinnertool

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	_const "volc_contract_process/pkg/const"
)

func Test_ChangeContractOwnerReq_Validate_BitsUTGen(t *testing.T) {
	t.Run("合同编号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合同编号为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo: "",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			// 断言错误码与参数
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "contract_no")
		})
	})

	t.Run("当前操作人为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 没有选择任何变更开关
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo: "C-001",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			// 断言无效参数错误码与提示包含关键字
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "current_operator")
		})
	})

	t.Run("未选择任何变更类型返回无效参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 没有选择任何变更开关
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:      "C-001",
				CurrentOperator: "operator@example.com",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			// 断言无效参数错误码与提示包含关键字
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "InvalidParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "至少需要选择一种变更类型")
		})
	})

	t.Run("变更业务执行人未提供新执行人返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ChangeOperator为true，但NewOperator为nil
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:      "C-002",
				ChangeOperator:  true,
				NewOperator:     nil,
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_operator")
		})
	})

	t.Run("变更业务执行人新执行人工号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// NewOperator提供但JobID为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:      "C-003",
				ChangeOperator:  true,
				NewOperator:     &ChangeOwnerUserInfo{JobID: ""},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_operator.job_id")
		})
	})

	t.Run("变更合同创建人未提供新创建人返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ChangeCreator为true，但NewCreator为nil
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:      "C-004",
				ChangeCreator:   true,
				NewCreator:      nil,
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_creator")
		})
	})

	t.Run("变更合同创建人新创建人工号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// NewCreator提供但JobID为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:      "C-005",
				ChangeCreator:   true,
				NewCreator:      &ChangeOwnerUserInfo{JobID: ""},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_creator.job_id")
		})
	})

	t.Run("变更合同审批人未提供替换规则返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ChangeContractReviewer为true，但ApprovalRuleReplacements为nil
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:               "C-006",
				ChangeContractReviewer:   true,
				ApprovalRuleReplacements: nil,
				CurrentOperator:          "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "approval_rule_replacements")
		})
	})

	t.Run("变更合同审批人旧审批人邮箱为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 替换规则存在但OldReviewerEmail为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:             "C-007",
				ChangeContractReviewer: true,
				ApprovalRuleReplacements: &ApprovalRuleReplacement{
					OldReviewerEmail: "",
					OldReviewerJobID: "OJ1",
					NewReviewerEmail: "new@xx.com",
					NewReviewerJobID: "NJ1",
				},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "old_reviewer_email")
		})
	})

	t.Run("变更合同审批人旧审批人工号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// OldReviewerJobID为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:             "C-008",
				ChangeContractReviewer: true,
				ApprovalRuleReplacements: &ApprovalRuleReplacement{
					OldReviewerEmail: "old@xx.com",
					OldReviewerJobID: "",
					NewReviewerEmail: "new@xx.com",
					NewReviewerJobID: "NJ2",
				},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "old_reviewer_job_id")
		})
	})

	t.Run("变更合同审批人新审批人邮箱为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// NewReviewerEmail为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:             "C-009",
				ChangeContractReviewer: true,
				ApprovalRuleReplacements: &ApprovalRuleReplacement{
					OldReviewerEmail: "old@xx.com",
					OldReviewerJobID: "OJ3",
					NewReviewerEmail: "",
					NewReviewerJobID: "NJ3",
				},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_reviewer_email")
		})
	})

	t.Run("变更合同审批人新审批人工号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// NewReviewerJobID为空
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:             "C-010",
				ChangeContractReviewer: true,
				ApprovalRuleReplacements: &ApprovalRuleReplacement{
					OldReviewerEmail: "old@xx.com",
					OldReviewerJobID: "OJ4",
					NewReviewerEmail: "new@xx.com",
					NewReviewerJobID: "",
				},
				CurrentOperator: "operator",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "new_reviewer_job_id")
		})
	})

	t.Run("所有字段合法时校验通过并返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有必填字段都合法
			ctx := context.Background()
			req := &ChangeContractOwnerReq{
				ContractNo:             "C-011",
				ChangeOperator:         true,
				ChangeCreator:          true,
				ChangeContractReviewer: true,
				NewOperator:            &ChangeOwnerUserInfo{JobID: "OP1"},
				NewCreator:             &ChangeOwnerUserInfo{JobID: "CR1"},
				ApprovalRuleReplacements: &ApprovalRuleReplacement{
					OldReviewerEmail: "old@xx.com",
					OldReviewerJobID: "OJ5",
					NewReviewerEmail: "new@xx.com",
					NewReviewerJobID: "NJ5",
				},
				CurrentOperator: "cur@xx.com",
			}
			err := req.Validate(ctx)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ChangeContractOwnerReq_BuildChangeType_BitsUTGen(t *testing.T) {
	t.Run("全部开关为false返回空字符串", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有开关均为false
			req := &ChangeContractOwnerReq{
				ChangeOperator:         false,
				ChangeCreator:          false,
				ChangeContractReviewer: false,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, "")
		})
	})

	t.Run("仅变更业务执行人返回对应类型", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 仅变更业务执行人
			req := &ChangeContractOwnerReq{
				ChangeOperator:         true,
				ChangeCreator:          false,
				ChangeContractReviewer: false,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeOperator)
		})
	})

	t.Run("仅变更合同创建人返回对应类型", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 仅变更合同创建人
			req := &ChangeContractOwnerReq{
				ChangeOperator:         false,
				ChangeCreator:          true,
				ChangeContractReviewer: false,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeCreator)
		})
	})

	t.Run("仅变更合同审批人返回对应类型", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 仅变更合同审批人
			req := &ChangeContractOwnerReq{
				ChangeOperator:         false,
				ChangeCreator:          false,
				ChangeContractReviewer: true,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeContractReviewer)
		})
	})

	t.Run("变更业务执行人与合同创建人组合顺序正确", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 业务执行人+合同创建人，顺序为operator,creator
			req := &ChangeContractOwnerReq{
				ChangeOperator:         true,
				ChangeCreator:          true,
				ChangeContractReviewer: false,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeOperator+","+_const.ToolOperationTypeChangeCreator)
		})
	})

	t.Run("变更业务执行人与合同审批人组合顺序正确", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 业务执行人+合同审批人，顺序为operator,reviewer
			req := &ChangeContractOwnerReq{
				ChangeOperator:         true,
				ChangeCreator:          false,
				ChangeContractReviewer: true,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeOperator+","+_const.ToolOperationTypeChangeContractReviewer)
		})
	})

	t.Run("变更合同创建人与合同审批人组合顺序正确", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合同创建人+合同审批人，顺序为creator,reviewer
			req := &ChangeContractOwnerReq{
				ChangeOperator:         false,
				ChangeCreator:          true,
				ChangeContractReviewer: true,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeCreator+","+_const.ToolOperationTypeChangeContractReviewer)
		})
	})

	t.Run("三个开关均为true返回三个类型按固定顺序", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 三者都变更，顺序为operator,creator,reviewer
			req := &ChangeContractOwnerReq{
				ChangeOperator:         true,
				ChangeCreator:          true,
				ChangeContractReviewer: true,
			}
			ret := req.BuildChangeType()
			convey.So(ret, convey.ShouldEqual, _const.ToolOperationTypeChangeOperator+","+_const.ToolOperationTypeChangeCreator+","+_const.ToolOperationTypeChangeContractReviewer)
		})
	})
}

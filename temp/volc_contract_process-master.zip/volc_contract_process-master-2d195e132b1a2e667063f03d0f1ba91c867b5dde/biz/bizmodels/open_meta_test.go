package bizmodels

import (
	"encoding/json"
	"testing"
)

func TestMetaUnmarshal(t *testing.T) {
	s := `
		{"CurrentOperator":"","BizScene":0,"BizSource":0,"Initiator":0,"ContractNo":"","AccountID":0,"BizIdentifier":"xxxx","Creator":"","ValidityBegin":"","ValidityEnd":"","BizInfo":{"test":"demo"},"Remark":""}
`
	var req OpenBizContractMetaCreateParam
	err := json.Unmarshal([]byte(s), &req)
	t.Log(err)
	t.Log(req)
}

func TestMetaUnmarshalDemo(t *testing.T) {
	s := `
		{"Name":"xxxx"}
`
	var req Demo
	err := json.Unmarshal([]byte(s), &req)
	t.Log(err)
	t.Log(req)
}

type Demo struct {
	Name string
	Foo  Foo
}

type Foo interface {
}

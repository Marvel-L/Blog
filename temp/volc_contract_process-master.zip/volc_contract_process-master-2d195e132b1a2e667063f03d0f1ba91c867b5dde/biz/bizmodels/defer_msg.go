package bizmodels

import _const "volc_contract_process/pkg/const"

type DeferMsg struct {
	DeferType _const.DeferType `json:"defer_type"`       //
	Body      string           `json:"body,omitempty"`   //
	Detail    DeferMsgDetail   `json:"detail,omitempty"` //
}

type DeferMsgDetail interface {
	DeferMsgDetailFlag()
}

type baseDeferMsgDetail struct {
}

func (b baseDeferMsgDetail) DeferMsgDetailFlag() {
}

type DeferMsgDetailGenBizDraft struct {
	baseDeferMsgDetail
	baseEventContext
	ContractNo      string `json:"ContractNo"`      // 合同号
	ContractVersion int    `json:"ContractVersion"` // 合同版本
	BizScene        int    `json:"biz_scene"`       //
	BizSource       int    `json:"biz_source"`      //
	BizIdentifier   string `json:"biz_identifier"`  //
}

type DeferMsgDetailGenBizSubmitOaFile struct {
	baseDeferMsgDetail
	baseEventContext
	ContractNo      string `json:"ContractNo"`      // 合同号
	ContractVersion int    `json:"ContractVersion"` // 合同版本
	BizScene        int    `json:"biz_scene"`       //
	BizSource       int    `json:"biz_source"`      //
	BizIdentifier   string `json:"biz_identifier"`  //
	CardNo          string `json:"CardNo"`          // 实名认证编码
	DocumentType    string `json:"DocumentType"`    // 实名认证类型
	RegistCountry   string `json:"RegistCountry"`
	IsFeishu        bool   `json:"IsFeishu"` // 是否为提交飞书合同的流程
}

type DeferMsgSubmitOA struct {
	baseDeferMsgDetail
	baseEventContext
	ContractNo string `json:"ContractNo"` // 合同号
}

type DeferMsgDetailInvalid struct {
	baseDeferMsgDetail
	InvalidType     int    `json:"invalid_type"`
	ContractNo      string `json:"ContractNo"`      // 合同号
	ContractVersion int    `json:"ContractVersion"` // 合同版本
	BizScene        int    `json:"biz_scene"`       //
	BizIdentifier   string `json:"biz_identifier"`  //
}

type DeferMsgDetailEventBusBody struct {
	baseDeferMsgDetail
	EventType string `json:"event_type"` //
	Body      string `json:"body"`       //
}

// DeferMsgDetailAutoPriceApprovalBody 自动配价后判断新建敏捷流程
type DeferMsgDetailAutoPriceApprovalBody struct {
	baseDeferMsgDetail
	ContractNo string `json:"ContractNo"` // 合同号
}

// DeferMsgDetailLarkMsgRecordBody 飞书消息发送记录
type DeferMsgDetailLarkMsgRecordBody struct {
	baseDeferMsgDetail
	DetailRedisKey string `json:"DetailRedisKey"` // 详情缓存Key
}

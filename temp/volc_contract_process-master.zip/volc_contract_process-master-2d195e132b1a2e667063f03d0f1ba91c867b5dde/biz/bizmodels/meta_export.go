package bizmodels

import "os"

type InitMetaExportFileResp struct {
	TempFile *os.File
	TaskID   int64
	TosKey   string
}

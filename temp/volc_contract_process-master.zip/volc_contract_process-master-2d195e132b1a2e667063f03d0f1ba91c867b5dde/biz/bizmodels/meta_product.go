package bizmodels

import (
	"strings"

	"code.byted.org/gopkg/context"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type GetInProcessProductReq struct {
	SourceType             _const.SourceType
	CurrentOperator        string                   `json:"CurrentOperator" query:"CurrentOperator"`
	FetchProductConditions []*FetchProductCondition `json:"FetchProductConditions" query:"FetchProductConditions"`
	DownLoadId             string                   `json:"DownLoadId" query:"DownLoadId"`
}

func (r *GetInProcessProductReq) Validate() errors.APIError {
	if len(r.FetchProductConditions) == 0 {
		return errors.ErrMissingParam.WithArgs("FetchProductConditions")
	}
	return nil
}

type FetchProductCondition struct {
	TradeProduct      string `json:"TradeProduct"`      // 商品
	PayType           string `json:"PayType"`           // 付费方式(英文)
	CanPrePay         string `json:"CanPrePay"`         // 付费方式(中文)
	ConfigCategory    string `json:"ConfigCategory"`    // 配置分类
	Configuration     string `json:"Configuration"`     // 配置
	BillingMethodCode string `json:"BillingMethodCode"` // 计费方式编码
	BillingName       string `json:"BillingName"`       // 计费方式名称
	RegionCode        string `json:"RegionCode"`        // 地域编码
	Region            string `json:"Region"`            // 地域名称
	ChargeElement     string `json:"ChargeElement"`     // 计费单元名称
	ChargeElementCode string `json:"ChargeRlementCode"` // 计费单元编码
	ChargeItemCode    string `json:"ChargeItemCode"`    // 计费项编号/计费项编码
}

func (f FetchProductCondition) GenKey(ctx context.Context) string {
	var res []string
	if len(f.TradeProduct) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "商品:%s", f.TradeProduct))
	}
	if len(f.PayType) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "付费方式(英文):%s", f.PayType))
	}
	if len(f.CanPrePay) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "付费方式(中文):%s", f.CanPrePay))
	}
	if len(f.ConfigCategory) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "配置分类:%s", f.ConfigCategory))
	}
	if len(f.Configuration) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "配置:%s", f.Configuration))
	}
	if len(f.BillingMethodCode) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "计费方式编码:%s", f.BillingMethodCode))
	}
	if len(f.BillingName) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "计费方式名称:%s", f.BillingName))
	}
	if len(f.RegionCode) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "地域编码:%s", f.RegionCode))
	}
	if len(f.Region) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "地域名称:%s", f.Region))
	}
	if len(f.ChargeElement) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "计费单元名称:%s", f.ChargeElement))
	}
	if len(f.ChargeElementCode) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "计费单元编码:%s", f.ChargeElementCode))
	}
	if len(f.ChargeItemCode) > 0 {
		res = append(res, i18nfmt.Sprintf(ctx, "计费项编号:%s", f.ChargeItemCode))
	}
	return strings.Join(res, ", ")
}

type CommodityExportData struct {
	AccountId              string // 账号ID
	ContractNo             string // "合同编号"
	ContractName           string // "合同名称"
	OtherPartyName         string // "对方主体名称"
	Operator               string // "业务执行人"
	Creator                string // "合同创建人"
	ValidityTime           string // "合同有效期"
	CooperationStatusSec   string // "协商状态"
	SalesContractStatusSec string // "合同状态"
	ArchivedStatusSec      string // "归档状态"
	ActiveStatusSec        string // "执行状态"

	FetchTradeProduct      string // 商品
	FetchPayType           string // 付费方式(英文)
	FetchCanPrePay         string // 付费方式(中文)
	FetchConfigCategory    string // 配置分类
	FetchConfiguration     string // 配置
	FetchBillingMethodCode string // 计费方式编码
	FetchBillingName       string // 计费方式名称
	FetchRegionCode        string // 地域编码
	FetchRegion            string // 地域名称
	FetchChargeElement     string // 计费单元名称
	FetchChargeElementCode string // 计费单元编码
	FetchChargeItemCode    string // 计费项编号/计费项编码

	ErrorMsg string // 错误信息
}

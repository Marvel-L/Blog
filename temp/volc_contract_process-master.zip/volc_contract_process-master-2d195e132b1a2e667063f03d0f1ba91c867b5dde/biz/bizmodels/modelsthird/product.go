package modelsthird

type ProductLineData struct {
	ID           int64
	Name         string
	Code         string
	Level        int
	ChildProduct []ProductLineData
}

package modelsthird

type SearchAccountIndustryByCustomerNameReq struct {
	CustomerName string `json:"CustomerName" query:"CustomerName"`
}

package modelsthird

import "fmt"

// CreateVerifyAccountReq 创建计收账号
type CreateVerifyAccountReq struct {
	CurrentOperator    string
	SubjectNo          string `json:"SubjectNo" query:"SubjectNo"`                   // 我方主体编码
	OrganizationName   string `json:"OrganizationName" query:"OrganizationName"`     // 组织名称
	Country            string `json:"Country" query:"Country"`                       // 国家/地区，通过ListVerifyCountry接口获取
	Province           string `json:"Province" query:"Province"`                     // 州/省
	Address            string `json:"Address" query:"Address"`                       // 账单地址
	SettlementCurrency string `json:"SettlementCurrency" query:"SettlementCurrency"` // 结算币种
	AccountName        string `json:"AccountName" query:"AccountName"`               // 账号名称
}

func (r *CreateVerifyAccountReq) BuildCacheKey() string {
	return fmt.Sprintf("limit:create_account:%s:%s", r.CurrentOperator, r.AccountName)
}

// CreateVerifyAccountResp 创建计收账号响应
type CreateVerifyAccountResp struct {
	OrganizationName           string `json:"OrganizationName"`           // 组织名称
	AccountName                string `json:"AccountName"`                // 账号名称
	AccountID                  int64  `json:"AccountID"`                  // 账号ID
	SettlementCurrencyAssigned bool   `json:"SettlementCurrencyAssigned"` // 设置结算币种结果
}

type ListProductDepartmentReq struct {
	DepartmentName string `json:"DepartmentName" query:"DepartmentName"`
	DepartmentCode string `json:"DepartmentCode" query:"DepartmentCode"`
}

package bizmodels

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type BizContractListParam struct {
	SourceType      _const.SourceType
	CurrentOperator string `query:"CurrentOperator"`
	Status          string `query:"Status"`
	Identifier      string `query:"Identifier"`
	ContractNo      string `query:"ContractNo"`
	Scene           int    `query:"Scene"`
	CreateTimeBegin int64  `query:"CreateTimeBegin"`
	CreateTimeEnd   int64  `query:"CreateTimeEnd"`
	ValidityBegin   int64  `query:"ValidityBegin"`
	ValidityEnd     int64  `query:"ValidityEnd"`
	AccountID       int    `query:"AccountID"`
	PrincipalParty  string `query:"PrincipalParty"` // 委托方-主体名称
	EntrustedParty  string `query:"EntrustedParty"` // 被委托方-主体名称
	OrderBy         int    `query:"OrderBy"`
	Limit           int    `json:"limit" query:"Limit" default:"10"`
	Offset          int    `json:"offset" query:"Offset"`
	Extra           string `query:"Extra"`
	IsMultiApply    int    `query:"IsMultiApply"` // 批量申请鲜章 0-否 1-是
}

type BizContractListResp struct {
	List   []*BizContract
	Total  int
	Limit  int
	Offset int
}

func (p *BizContractListParam) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.SourceType == _const.SourceTypeOpen && p.AccountID == 0 {
		return errors.ErrMissingParam.WithArgs("AccountID")
	}
	if p.Scene == 0 {
		return errors.ErrMissingParam.WithArgs("Scene")
	}
	return nil
}

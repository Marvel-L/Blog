package bizmodels

type RiskClauseProductLineReviewer struct {
	ParentId   int64  `json:"parentId"`
	ChildId    int64  `json:"childId"`
	ParentName string `json:"parentName"`
	ChildName  string `json:"childName"`
}

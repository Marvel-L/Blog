package bizmodels

import (
	"time"

	"volc_contract_process/pkg/errors"
)

// OpenBizContractMetaCreateParam 业务合同元数据
type OpenBizContractMetaCreateParam struct {
	baseEventContext
	CurrentOperator            string            `json:"CurrentOperator" query:"CurrentOperator"`                       //
	FromContractNo             string            `json:"FromContractNo" query:"FromContractNo"`                         // 原合同号
	BizScene                   int               `json:"BizScene" query:"BizScene"`                                     // 业务场景
	BizSource                  int               `json:"BizSource" query:"BizSource"`                                   //
	SupplySource               string            `json:"SupplySource" query:"SupplySource"`                             // 补充场景
	Initiator                  int               `json:"Initiator" query:"Initiator"`                                   // 发起端
	ContractNo                 string            `json:"ContractNo" query:"ContractNo"`                                 // 合同号码 更新时使用
	AccountID                  int64             `json:"AccountID" query:"AccountID"`                                   // 客户ID
	SealAccountID              string            `json:"SealAccountID" query:"SealAccountID"`                           // 签约账号ID
	PricingAccountID           string            `json:"PricingAccountID" query:"PricingAccountID"`                     // 配价账号ID
	BizIdentifier              string            `json:"BizIdentifier" query:"BizIdentifier"`                           // 业务唯一标识
	Creator                    string            `json:"Creator" query:"Creator"`                                       // 创建人
	RelatedPersonnel           string            `json:"RelatedPersonnel" query:"RelatedPersonnel"`                     // 相关人员
	UsefulLifeType             int               `json:"UsefulLifeType" query:"UsefulLifeType" default:"1"`             // 有效期类型。1：固定期限； 2：自签订生效
	IndefiniteDateFlag         string            `json:"IndefiniteDateFlag" query:"IndefiniteDateFlag" default:"N"`     // 有效期有无期限标识。Y:无限期 N:有限期
	UsefulLifeUnit             string            `json:"UsefulLifeUnit" query:"UsefulLifeUnit"`                         // 有效期单位，当合同为“自签订之日起生效”时使用 DAY:日 MONTH:月 YEAR:年
	UsefulLifeNum              int               `json:"UsefulLifeNum" query:"UsefulLifeNum"`                           // 有效期数值，当合同为“自签订之日起生效”时使用
	LongLifeReason             string            `json:"LongLifeReason" query:"LongLifeReason"`                         // 长有效期原因  最多200字符
	ValidityBegin              time.Time         `json:"ValidityBegin" query:"ValidityBegin"`                           // 有效期开始，格式2006-01-02 15:04:05
	ValidityEnd                time.Time         `json:"ValidityEnd" query:"ValidityEnd"`                               // 有效期结束，格式2006-01-02 15:04:05
	ValidityBeginStr           string            `json:"ValidityBeginStr" query:"ValidityBeginStr"`                     // 有效期开始，格式2006-01-02 15:04:05
	ValidityEndStr             string            `json:"ValidityEndStr" query:"ValidityEndStr"`                         // 有效期结束，格式2006-01-02 15:04:05
	BizInfo                    interface{}       `json:"BizInfo" query:"BizInfo"`                                       //
	BizInfoStr                 string            `json:"BizInfoStr" query:"BizInfoStr"`                                 //
	BizInfoEntity              BizInfo           `json:"BizInfoEntity" query:"BizInfoEntity"`                           //
	Remark                     string            `json:"Remark" query:"Remark"`                                         // 备注信息
	RedirectUrl                string            `json:"RedirectUrl" query:"RedirectUrl"`                               // 电子签签约结束后的跳转链接
	IsUpdate                   bool              `json:"IsUpdate" query:"IsUpdate"`                                     // 是否更新
	OpportunityName            string            `json:"OpportunityName" query:"OpportunityName"`                       // 商机名称
	OpportunityID              string            `json:"OpportunityID" query:"OpportunityID"`                           // 商机ID
	BusinessType               int               `json:"BusinessType" query:"BusinessType"`                             // 业务类型
	CustomerName               string            `json:"CustomerName" query:"CustomerName"`                             // 最终用户
	CustomerAccountID          string            `json:"CustomerAccountID" query:"CustomerAccountID"`                   // 最终用户ID
	PartnerName                string            `json:"PartnerName" query:"PartnerName"`                               // 关联伙伴
	IsRejectContract           bool              `json:"IsRejectContract" query:"IsRejectContract"`                     // 是否是因为用户拒绝重提的合同 TODO：1024 后可删除
	IsUnbindQuote              bool              `json:"IsUnbindQuote" query:"IsUnbindQuote"`                           // 是否已解绑报价单
	SpecialContractType        string            `json:"SpecialContractType" query:"SpecialContractType"`               //  特殊合同类型
	GuaranteeItem              string            `json:"GuaranteeItem" query:"GuaranteeItem"`                           // 报价单保底信息
	BizInfoQuote               QuoteBizInfo      `json:"BizInfoQuote" query:"BizInfoQuote"`                             // 报价单创建合同信息
	BasicInfo                  BasicInfo         `json:"BasicInfo" query:"BasicInfo"`                                   // 合同基本信息
	SettlementInfo             SettlementInfo    `json:"SettlementInfo" query:"SettlementInfo"`                         // 结算条款信息
	TradePartyInfo             TradePartyInfo    `json:"TradePartyInfo"`                                                // 交易双方信息
	TemplateKey                string            `json:"TemplateKey" query:"TemplateKey"`                               // 模板Key
	TemplateExt                map[string]string `json:"TemplateExt"`                                                   // 合同附件的附加信息
	CouponAppendTemplateConfig map[int64]string  `json:"CouponAppendTemplateConfig" query:"CouponAppendTemplateConfig"` // 代金券ID到是否推送代金券附录配置映射
	Ext                        map[string]string
}

// OpenBizContractSubmitParam 业务合同场景-提交合同草稿
type OpenBizContractSubmitParam struct {
	baseEventContext
	BaseBizContractParam
	CurrentOperator         string `json:"CurrentOperator" query:"CurrentOperator"`                 //
	BizSource               int    `json:"BizSource" query:"BizSource"`                             // 合同来源
	AccountID               int64  `json:"AccountID" query:"AccountID"`                             // 账号
	IgnorePriceRepeatReturn bool   `json:"IgnorePriceRepeatReturn" query:"IgnorePriceRepeatReturn"` // 是否忽略报价单重复
	// ContractNo              string `json:"ContractNo" query:"ContractNo"`                           // 合同号
	// ContractVersion         int    `json:"ContractVersion" query:"ContractVersion"`                 // 合同版本
	// BizScene                int    `json:"BizScene" query:"BizScene"`                               // 业务场景
	// BizIdentifier           string `json:"BizIdentifier" query:"BizIdentifier"`                     // 业务唯一标识
}

type OpenBizContractAbandonParam struct {
	baseEventContext
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` //
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 合同版本
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
}

type OpenBizContractAbortParam struct {
	baseEventContext
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` //
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 合同版本
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
}

// OpenBizContractRevokeParam 业务合同场景-撤销合同
type OpenBizContractRevokeParam struct {
	baseEventContext
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` // 当前操作人邮箱
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
}

// OpenBizContractCustomerAuditParam 业务合同场景-客户确认
type OpenBizContractCustomerAuditParam struct {
	baseEventContext
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` // 当前操作人邮箱
	AccountID       int64  `json:"AccountID" query:"AccountID"`             // 客户ID
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizSource       int    `json:"BizSource" query:"BizSource"`             // 合同来源
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 合同版本
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
	Operation       int    `json:"Operation" query:"Operation"`             // 1-同意 2-拒绝 3-作废
	RejectType      int    `json:"RejectType" query:"RejectType"`           // 拒绝类型
	RejectReason    string `json:"RejectReason" query:"RejectReason"`       // 拒绝原因
	Remark          string `json:"Remark" query:"Remark"`                   // 备注信息
	CardNo          string `json:"CardNo" query:"CardNo"`                   //
	DocumentType    string `json:"DocumentType" query:"DocumentType"`       // 主数据注册类型
	RegistCountry   string `json:"RegistCountry" query:"RegistCountry"`     // 注册国家地区
}

func (p *OpenBizContractCustomerAuditParam) validate() errors.APIError {
	if len(p.CurrentOperator) != 0 && p.AccountID != 0 {
		return errors.ErrorCommon.WithArgs("确认信息不能同时存在邮箱与AccountId")
	}
	return nil
}

type OpenBizContractGetSignURLParam struct {
	baseEventContext
	BaseBizContractParam
	AccountID int64 `query:"AccountID"` // 客户ID
}

// BaseBizContractParam 该参数用于表示业务合同场景下，定位到一个确定的合同
type BaseBizContractParam struct {
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 合同版本
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
}

type ListCertificationTemplateReq struct {
	TemplateName string `json:"TemplateName" query:"TemplateName"`
	Limit        int    `json:"Limit" default:"10" query:"Limit"`
	Offset       int    `json:"Offset" query:"Offset"`
}

type DownLoadCertificationTemplateReq struct {
	TplKey    string `json:"TplKey" query:"TplKey"`
	AccountID uint64 `json:"AccountID" query:"AccountID"`
}

package bizmodels

import (
	"context"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

// CreateOrUpdateMetaReq 创建/更新meta
// 前期仅允许部分参数变更
type CreateOrUpdateMetaReq struct {
	ProcessType                _const.ProcessType
	SourceType                 _const.SourceType
	BizScene                   int               // 业务来源
	BizSource                  int               // 合同来源
	SupplyScene                int               // 补充协议分类
	Initiator                  int               // 发起端
	Operation                  int               // 操作值
	CurrentOperator            string            // 当前操作人
	ContractNo                 string            // 合同号
	FromContractNo             string            // 原合同号
	MainContractNo             string            // 主合同号
	Version                    int               // 版本
	Creator                    string            // 创建人
	Operator                   string            // 业务执行人工号
	CreatorNew                 string            // 创建人
	OperatorNew                string            // 业务执行人工号
	PropertyCode               string            // 合同性质
	InOutType                  string            // 收支类型
	Department                 string            // 业务执行人归属部门
	CategoryNo                 string            // 合同分类编码
	SignatureType              string            // 签约形式
	WhetherProject             string            // 是否项目制 Y:是；N:否
	SpecialContractType        string            // 特殊合同类型
	ContractName               string            // 合同名称
	BeginTime                  string            // 开始时间
	EndTime                    string            // 结束时间
	BasicInfo                  *BasicInfo        // 合同基本信息
	ManageInfo                 *ManageInfo       // 管理信息
	TradePartyInfo             *TradePartyInfo   // 交易双方信息
	SettlementInfo             *SettlementInfo   // 结算条款信息
	ReverseSignInfo            *ReverseSignInfo  // 合同倒签信息
	TemplateInfo               *TemplateInfo     // 合同模板信息
	ContractFile               string            // 合同文件 ID
	ContractAttachment         []*MetaAttachment // 合同附录
	RelateQuoteNo              string            // 关联报价单号
	RelateQuoteScene           int               // 关联报价单场景
	BizIdentifier              string            // 业务唯一标识
	CRMKey                     string            // crm唯一值
	Remark                     string            // 备注
	Ext                        map[string]string // 合同附加信息 传入则更新 不传不更新
	IgnorePriceRepeatReturn    bool              // 是否忽略报价单重复
	FromContractTerminatedTime string            // 主合同终止日期

	// 非入参 拼接参数
	ProductList       string // 合同商品列表
	Finance           string // 财务审核人
	SubjectName       string // 我方主体名称
	OtherPartyName    string // 对方主体名称
	SubjectAccountIds string // 合同关联 ID

	// 流程参数
	IsUpdate bool

	// // 非入参 预处理参数
	// TextParam        map[string]interface{}                // 模板所需参数列表
	// TableParam       map[string][]map[string][]interface{} // 模板所需参数列表
	// BizInfo          interface{}                           `json:"BizInfo" query:"BizInfo"`                   //
	// BizInfoStr       string                                `json:"BizInfoStr" query:"BizInfoStr"`             //
	// BizInfoEntity    BizInfo                               `json:"BizInfoEntity" query:"BizInfoEntity"`       //
	// BizInfoQuote     QuoteBizInfo                          `json:"BizInfoQuote" query:"BizInfoQuote"`         // 报价单创建合同信息
	// IsUpdate         bool                                  `json:"IsUpdate" query:"IsUpdate"`                 // 是否更新
	// IsRejectContract bool                                  `json:"IsRejectContract" query:"IsRejectContract"` // 是否是因为用户拒绝重提的合同
	// CustomerName     string                                `json:"CustomerName" query:"CustomerName"`         // 商机关联客户名称
	// GuaranteeItem    string                                `json:"GuaranteeItem" query:"GuaranteeItem"`       // 报价单保底信息
}

func (c *CreateOrUpdateMetaReq) Validate(ctx context.Context) error {

	if len(c.BizIdentifier) == 0 {
		return errors.ErrMissingParam.WithArgs("BizIdentifier")
	}
	if c.BizScene == 0 {
		return errors.ErrMissingParam.WithArgs("BizScene")
	}
	// if len(c.ContractNo) > 0 && !strings.HasPrefix(c.ContractNo, "PCT") {
	// 	return errors.ErrInternalError.WithArgs("合同号不合规")
	// }
	if len(c.Creator) == 0 {
		return errors.ErrMissingParam.WithArgs("Creator")
	}

	return nil
}

package bizmodels

type ListPermissionParam struct {
	UseAllData        bool // 全部展示
	UseSettlementInfo bool `json:"UseSettlementInfo"` // 结算条款信息
	UseManageInfo     bool `json:"UseManageInfo"`     // 管理信息
	UseProjectInfo    bool `json:"UseProjectInfo"`    // 管理信息
	// UseTradePartyInfo        bool `json:"useTradePartyInfo"`        // 交易双方信息
}

type BuildDetailParamV1 struct {
	CurrentOperator          string
	IsManager                bool `json:"IsManager"`
	UseAllData               bool // 全部展示
	UseBizViewURL            bool `json:"useBizViewURL"`            // 合同文本预览链接
	UseContractPriceData     bool `json:"useContractPriceData"`     // 合同价相关信息
	CheckQuoteItemOffline    bool `json:"checkQuoteItemOffline"`    // 校验报价条目是否下架
	UseAccountInfo           bool `json:"useAccountInfo"`           // 合同 passport 信息
	UseUserInfo              bool `json:"useUserInfo"`              // 合同 people 信息
	UseSupplyList            bool `json:"useSupplyList"`            // 补充协议信息
	UseCommonOpRecordList    bool `json:"useCommonOpRecordList"`    // 业务合同审批记录
	UseCooperationRecordList bool `json:"useCooperationRecordList"` // 在线协同审批记录
	UseCooperationNodeList   bool `json:"useCooperationNodeList"`   // 在线协同审批节点信息
	UseFileData              bool `json:"useFileData"`              // 文件信息
	UseParseBiz              bool `json:"useParseBiz"`              // 业务合同入参信息
	UseExt                   bool `json:"useExt"`                   // 合同补充信息
	UseBasicInfo             bool `json:"useBasicInfo"`             // 合同基本信息
	UseProjectInfo           bool `json:"useProjectInfo"`           // 项目信息
	UseSettlementInfo        bool `json:"useSettlementInfo"`        // 结算条款信息
	UseBusinessModeClauses   bool `json:"useBusinessModeClauses"`   // 商务模式条款摘要
	UseReverseSignInfo       bool `json:"useReverseSignInfo"`       // 倒签信息
	UseManageInfo            bool `json:"useManageInfo"`            // 管理信息
	UseTradePartyInfo        bool `json:"useTradePartyInfo"`        // 交易双方信息
	UseTemplateInfo          bool `json:"useTemplateInfo"`          // 合同模板信息
	UseRiskClause            bool `json:"useRiskClause"`            // 风险条款信息
	UseUrgentInfo            bool `json:"useUrgentInfo"`            // 加急信息
}

type PreContractExportData struct {
	SalesOperationReviewTime       string
	FinanceTaxationLegalReviewTime string
	FinalizedReviewTime            string
	SalesOperation                 string
}

package bizmodels

import (
	"context"
	"strings"
	"testing"
	"volc_contract_process/pkg/const"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func newValidParam() FreshSealCreateParam {
	return FreshSealCreateParam{
		AccountId:    "acc-001",
		CopyCount:    1,
		ContactName:  "张三",
		ContactPhone: "12345678901",
		AddressInfo: AddressInfo{
			Province: "北京",
			City:     "北京",
			Region:   "朝阳区",
			Address:  "望京东路88号",
		},
		ApplyReason:    []Reason{{Code: "A1", Message: "需要线下鲜章"}},
		ContractNoList: "NO1,NO2",
		BizScene:       _const.BizSceneQuoteContract,
	}
}

func makeContractNos(n int) string {
	if n <= 0 {
		return ""
	}
	items := make([]string, n)
	for i := 0; i < n; i++ {
		items[i] = "NO"
	}
	return strings.Join(items, ",")
}

func Test_FreshSealDetailParam_ValidateDetail_BitsUTGen(t *testing.T) {
	t.Run("AccountId为空时返回MissingParam错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当AccountId为空
			param := &FreshSealDetailParam{
				AccountId:  "",
				ApplyNo:    "apply-001",
				ContractNo: "contract-001",
			}
			err := param.ValidateDetail()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "MissingParam")
		})
	})

	t.Run("ApplyNo为空时返回MissingParam错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当ApplyNo为空
			param := &FreshSealDetailParam{
				AccountId:  "account-001",
				ApplyNo:    "",
				ContractNo: "contract-001",
			}
			err := param.ValidateDetail()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "MissingParam")
			convey.So(err.Error(), convey.ShouldContainSubstring, "ApplyNo")
		})
	})

	t.Run("ContractNo为空时返回MissingParam错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当ContractNo为空
			param := &FreshSealDetailParam{
				AccountId:  "account-001",
				ApplyNo:    "apply-001",
				ContractNo: "",
			}
			err := param.ValidateDetail()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "MissingParam")
		})
	})

	t.Run("全部字段非空时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 全部字段非空
			param := &FreshSealDetailParam{
				AccountId:  "account-001",
				ApplyNo:    "apply-001",
				ContractNo: "contract-001",
			}
			err := param.ValidateDetail()

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_FreshSealListParam_Validate_BitsUTGen(t *testing.T) {
	t.Run("Limit 不合法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Limit<=0直接返回错误
			param := &FreshSealListParam{
				Limit:  0,
				Offset: 0,
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Limit")
		})
	})

	t.Run("Offset 不合法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Offset<0返回错误
			param := &FreshSealListParam{
				Limit:  10,
				Offset: -1,
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Offset")
		})
	})

	t.Run("Status 解析失败返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Status包含非数字导致解析失败
			param := &FreshSealListParam{
				Limit:  10,
				Offset: 0,
				Status: "a,b",
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Status")
		})
	})

	t.Run("Status 包含非法值返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Status解析成功但包含不在映射中的值
			param := &FreshSealListParam{
				Limit:  10,
				Offset: 0,
				Status: "1,3",
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Status")
		})
	})

	t.Run("AccountID 非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// AccountID非数字触发错误
			param := &FreshSealListParam{
				Limit:     10,
				Offset:    0,
				Status:    "",
				AccountID: "abc",
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "AccountID")
		})
	})

	t.Run("全部参数合法返回 nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 所有参数合法
			param := &FreshSealListParam{
				Limit:     10,
				Offset:    0,
				Status:    "1,2",
				AccountID: "12345",
			}
			err := param.Validate(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_FreshSealBatchUpdateExpressParam_ValidateBatchUpdateExpress_BitsUTGen(t *testing.T) {
	t.Run("当前操作人为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当前操作人为空
			param := &FreshSealBatchUpdateExpressParam{
				CurrentOperator: "",
			}
			err := param.ValidateBatchUpdateExpress(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CurrentOperator")
		})
	})

	t.Run("邮寄信息列表为nil返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 邮寄信息列表为nil
			param := &FreshSealBatchUpdateExpressParam{
				CurrentOperator: "op",
				ExpressDataList: nil,
			}
			err := param.ValidateBatchUpdateExpress(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ExpressDataList")
		})
	})

	t.Run("邮寄信息列表长度为0返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 邮寄信息列表长度为0
			param := &FreshSealBatchUpdateExpressParam{
				CurrentOperator: "op",
				ExpressDataList: []*ExpressData{},
			}
			err := param.ValidateBatchUpdateExpress(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ExpressDataList")
		})
	})

	t.Run("邮寄信息列表长度超过200返回非法参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 邮寄信息列表长度超过200
			list := make([]*ExpressData, 201)
			for i := range list {
				list[i] = &ExpressData{}
			}
			param := &FreshSealBatchUpdateExpressParam{
				CurrentOperator: "op",
				ExpressDataList: list,
			}
			err := param.ValidateBatchUpdateExpress(context.Background())
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "单次最多导入200条")
		})
	})

	t.Run("参数合法返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 参数合法
			param := &FreshSealBatchUpdateExpressParam{
				CurrentOperator: "op",
				ExpressDataList: []*ExpressData{
					{ApplyNo: "A1", ExpressCompany: "C1", ExpressNo: "N1", Remark: "ok"},
				},
			}
			err := param.ValidateBatchUpdateExpress(context.Background())
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_FreshSealListOperationRecordParam_ValidateFreshSealListOperationRecordParam_BitsUTGen(t *testing.T) {
	t.Run("ApplyNo为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造参数，ApplyNo为空触发错误分支
			param := &FreshSealListOperationRecordParam{
				ApplyNo: "",
				Limit:   10,
				Offset:  0,
			}

			err := param.ValidateFreshSealListOperationRecordParam()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ApplyNo")
			convey.So(err.Error(), convey.ShouldContainSubstring, "MissingParam")
		})
	})

	t.Run("ApplyNo非空返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造参数，ApplyNo非空触发返回nil分支
			param := &FreshSealListOperationRecordParam{
				ApplyNo: "FS-001",
				Limit:   10,
				Offset:  0,
			}

			err := param.ValidateFreshSealListOperationRecordParam()

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_FreshSealCreateParam_ValidateCreate_BitsUTGen(t *testing.T) {
	t.Run("缺少AccountId返回MissingParam", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.AccountId = ""
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "AccountId")
		})
	})

	t.Run("CopyCount不在1到3之间报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.CopyCount = 0
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "盖章分数必须在1-3之间")
		})
	})

	t.Run("联系人姓名缺失报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContactName = ""
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "请填写邮寄联系人姓名")
		})
	})

	t.Run("联系人姓名超过10个字报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContactName = "一二三四五六七八九十一"
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "请填写邮寄联系人姓名，最多10个字")
		})
	})

	t.Run("联系人电话缺失报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContactPhone = ""
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContactPhone")
		})
	})

	t.Run("联系人电话长度超过11报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContactPhone = "123456789012"
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "联系人电话长度不能超过11个字符")
		})
	})

	t.Run("联系人电话包含非数字报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContactPhone = "12345abc678"
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "联系人电话必须为纯数字")
		})
	})

	t.Run("地址信息缺失报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.AddressInfo.Province = ""
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "AddressInfo")
		})
	})

	t.Run("详细地址超过200字报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			longAddr := strings.Repeat("字", 201)
			p := newValidParam()
			p.AddressInfo.Address = longAddr
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "详细地址长度不能超过200个字符")
		})
	})

	t.Run("申请原因为空报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ApplyReason = nil
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ApplyReason")
		})
	})

	t.Run("申请原因Code为空报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ApplyReason = []Reason{{Code: "", Message: "原因描述"}}
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "申请原因代码不能为空")
		})
	})

	t.Run("申请原因Message为空报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ApplyReason = []Reason{{Code: "R1", Message: ""}}
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "申请原因描述不能为空")
		})
	})

	t.Run("合同号列表为空报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContractNoList = ""
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractNoList")
		})
	})

	t.Run("合同号数量超过50报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			contractNos := makeContractNos(51)
			p := newValidParam()
			p.ContractNoList = contractNos
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同号数量不能超过50个")
		})
	})

	t.Run("业务场景不支持报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.BizScene = 999
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "不支持的业务场景")
		})
	})

	t.Run("全部参数合法返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			p := newValidParam()
			p.ContractNoList = makeContractNos(3)
			p.BizScene = _const.BizSceneTransactionContract
			err := (&p).ValidateCreate()
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

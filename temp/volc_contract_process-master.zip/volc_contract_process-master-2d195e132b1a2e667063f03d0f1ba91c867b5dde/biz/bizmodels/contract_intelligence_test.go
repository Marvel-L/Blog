package bizmodels

import (
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"strings"
	"testing"
	"volc_contract_process/pkg/errors"
)

func Test_SubmitContractIntelligenceFeedbackReq_Validate(t *testing.T) {
	t.Run("请求为空时返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var req *SubmitContractIntelligenceFeedbackReq

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrCommon.WithArgs("request is nil"))
		})
	})

	t.Run("操作人为空白时返回缺少参数", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := validSubmitContractIntelligenceFeedbackReq()
			req.CurrentOperator = "   "

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("CurrentOperator"))
		})
	})

	t.Run("反馈项为空时返回缺少参数", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := validSubmitContractIntelligenceFeedbackReq()
			req.FeedbackItems = nil

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("FeedbackItems"))
		})
	})

	t.Run("反馈项超过上限时返回校验错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := validSubmitContractIntelligenceFeedbackReq()
			req.FeedbackItems = make([]*FeedbackItemReq, 0, maxContractIntelligenceFeedbackItems+1)
			for i := 0; i < maxContractIntelligenceFeedbackItems+1; i++ {
				req.FeedbackItems = append(req.FeedbackItems, &FeedbackItemReq{FeedbackContent: "item"})
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrValidateParamErr.WithArgs("FeedbackItems数量不能超过10个"))
		})
	})

	t.Run("反馈内容为空白时返回缺少参数", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := validSubmitContractIntelligenceFeedbackReq()
			req.FeedbackItems = []*FeedbackItemReq{{FeedbackContent: "   "}}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("FeedbackContent"))
		})
	})

	t.Run("反馈项达到上限且参数完整时允许通过", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := validSubmitContractIntelligenceFeedbackReq()
			req.CurrentOperator = " operator "
			req.ContractNo = " contract-no "
			req.ContractName = " contract-name "
			req.InOutType = " OUT "
			req.ContractSubmitTime = " 2024-01-01 10:00:00 "
			req.FeedbackItems = make([]*FeedbackItemReq, 0, maxContractIntelligenceFeedbackItems)
			for i := 0; i < maxContractIntelligenceFeedbackItems; i++ {
				req.FeedbackItems = append(req.FeedbackItems, &FeedbackItemReq{
					FeedbackContent: strings.Repeat("a", i+1),
				})
			}

			err := req.Validate()

			So(err, ShouldBeNil)
		})
	})
}

func Test_GetAIAuditReportReq_Validate(t *testing.T) {
	t.Run("请求为空时返回错误", func(t *testing.T) {
		PatchConvey("", t, func() {
			var req *GetAIAuditReportReq

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrCommon.WithArgs("request is nil"))
		})
	})

	t.Run("操作人为空白时返回缺少参数", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &GetAIAuditReportReq{
				CurrentOperator: " ",
				ContractNo:      "contract-no",
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("CurrentOperator"))
		})
	})

	t.Run("合同编号为空白时返回缺少参数", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &GetAIAuditReportReq{
				CurrentOperator: "operator",
				ContractNo:      " ",
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("ContractNo"))
		})
	})

	t.Run("参数完整时允许通过", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &GetAIAuditReportReq{
				CurrentOperator: " operator ",
				ContractNo:      " contract-no ",
			}

			err := req.Validate()

			So(err, ShouldBeNil)
		})
	})
}

func validSubmitContractIntelligenceFeedbackReq() *SubmitContractIntelligenceFeedbackReq {
	return &SubmitContractIntelligenceFeedbackReq{
		CurrentOperator:    "operator",
		ContractNo:         "contract-no",
		ContractName:       "contract-name",
		InOutType:          "OUT",
		ContractSubmitTime: "2024-01-01 10:00:00",
		FeedbackItems: []*FeedbackItemReq{
			{FeedbackContent: "feedback"},
		},
	}
}

package bizmodels

import (
	"code.byted.org/gopkg/lang/strings"

	"volc_contract_process/pkg/errors"
)

// QuoteRefreshNotifyReq 报价刷数通知请求
type QuoteRefreshNotifyReq struct {
	QuoteID           string `json:"QuoteID" form:"QuoteID" query:"QuoteID"`
	RefreshApprovalID string `json:"RefreshApprovalID" form:"RefreshApprovalID" query:"RefreshApprovalID"`
	ContractNo        string `json:"ContractNo" form:"ContractNo" query:"ContractNo"`
}

// Validate 校验报价刷数通知请求
func (r *QuoteRefreshNotifyReq) Validate() errors.APIError {
	if strings.IsEmpty(r.QuoteID) {
		return errors.ErrMissingParam.WithArgs("QuoteID")
	}
	if strings.IsEmpty(r.RefreshApprovalID) {
		return errors.ErrMissingParam.WithArgs("RefreshApprovalID")
	}
	if strings.IsEmpty(r.ContractNo) {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

// QuoteRefreshNotifyResp 报价刷数通知响应
type QuoteRefreshNotifyResp struct {
	IsContractAccepted bool   `json:"IsContractAccepted"`
	Reason             string `json:"Reason"`
}

package bizmodels

import (
	"volc_contract_process/pkg/errors"
)

type BizInfoCredit struct {
	baseBizInfo
	baseBizData
	Proposer          string  `json:"Proposer"`
	Reviewer          string  `json:"Creator"`
	PaymentCycle      string  `json:"PaymentCycle"`
	CreditLimit       float64 `json:"CreditLimit"`
	SettlementCycle   string  `json:"SettlementCycle"`
	CreditType        string  `json:"CreditType"`
	RelatedContractNo string  `json:"RelatedContractNo"` // 信控申请相关合同号
}

func (b *BizInfoCredit) Validate() errors.APIError {
	return nil
}

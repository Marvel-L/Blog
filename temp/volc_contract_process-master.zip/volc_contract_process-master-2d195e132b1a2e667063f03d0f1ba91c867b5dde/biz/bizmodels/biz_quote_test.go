package bizmodels

import (
	"code.byted.org/gopkg/context"
	"encoding/json"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/biz/service/multienv"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/util"
)

func TestSplitSellingMode(t *testing.T) {
	discount := &QuoteDiscount{
		SellingMode: "1,0",
	}
	list := discount.SplitSellingMode()
	t.Log("list_size", len(list))
	for _, v := range list {
		t.Log(v.SellingMode)
	}
}

func TestQuoteBizInfoGuaranteeJudge(t *testing.T) {
	convey.Convey("quote biz info guarantee judge", t, func() {
		convey.Convey("nil quote info should not contain guarantee", func() {
			var quoteInfo *QuoteBizInfo
			convey.So(quoteInfo.ContainsGuarantee(), convey.ShouldBeFalse)
			convey.So(quoteInfo.HasValidGuarantee(), convey.ShouldBeFalse)
			convey.So(quoteInfo.ValidGuarantees(), convey.ShouldBeNil)
			convey.So(quoteInfo.ValidGuaranteeMap(), convey.ShouldBeEmpty)
		})

		convey.Convey("empty guarantee tree should still be treated as guarantee info", func() {
			quoteInfo := &QuoteBizInfo{GuaranteeItems: &ContractGuaranteeRuleTreeResp{}}
			convey.So(quoteInfo.ContainsGuarantee(), convey.ShouldBeTrue)
			convey.So(quoteInfo.HasValidGuarantee(), convey.ShouldBeFalse)
			convey.So(quoteInfo.ValidGuarantees(), convey.ShouldBeNil)
			convey.So(quoteInfo.ValidGuaranteeMap(), convey.ShouldBeEmpty)
		})

		convey.Convey("new guarantee items has higher priority", func() {
			quoteInfo := &QuoteBizInfo{
				GuaranteeItem: &GuaranteeResp{GuaranteeItemID: 1, GuaranteeType: _const.GuaranteeTypeAll},
				GuaranteeItems: &ContractGuaranteeRuleTreeResp{Groups: []*ContractGuaranteeRuleGroupResp{
					{Root: &ContractGuaranteeRuleNodeResp{Item: &GuaranteeResp{GuaranteeItemID: 2, GuaranteeType: _const.GuaranteeTypeOther}}},
				}},
			}
			convey.So(quoteInfo.ContainsGuarantee(), convey.ShouldBeTrue)
			convey.So(quoteInfo.HasValidGuarantee(), convey.ShouldBeFalse)
			convey.So(quoteInfo.ValidGuaranteeMap(), convey.ShouldBeEmpty)
		})

		convey.Convey("fallback to old guarantee item", func() {
			quoteInfo := &QuoteBizInfo{GuaranteeItem: &GuaranteeResp{GuaranteeItemID: 1, GuaranteeType: _const.GuaranteeTypeAll}}
			convey.So(quoteInfo.ContainsGuarantee(), convey.ShouldBeTrue)
			convey.So(quoteInfo.HasValidGuarantee(), convey.ShouldBeTrue)
			guaranteeMap := quoteInfo.ValidGuaranteeMap()
			convey.So(guaranteeMap, convey.ShouldHaveLength, 1)
			convey.So(guaranteeMap[1], convey.ShouldEqual, quoteInfo.GuaranteeItem)
		})

		convey.Convey("build valid guarantee map from new guarantee items", func() {
			validRoot := &GuaranteeResp{GuaranteeItemID: 2, GuaranteeType: _const.GuaranteeTypeAll}
			invalidChild := &GuaranteeResp{GuaranteeItemID: 3, GuaranteeType: _const.GuaranteeTypeOther}
			validChild := &GuaranteeResp{GuaranteeItemID: 4, GuaranteeType: _const.GuaranteeTypePart}
			quoteInfo := &QuoteBizInfo{
				GuaranteeItem: &GuaranteeResp{GuaranteeItemID: 1, GuaranteeType: _const.GuaranteeTypeAll},
				GuaranteeItems: &ContractGuaranteeRuleTreeResp{Groups: []*ContractGuaranteeRuleGroupResp{
					{Root: &ContractGuaranteeRuleNodeResp{Item: validRoot, Children: []*ContractGuaranteeRuleNodeResp{
						{Item: invalidChild},
						{Item: validChild},
					}}},
				}},
			}

			guaranteeMap := quoteInfo.ValidGuaranteeMap()
			convey.So(guaranteeMap, convey.ShouldHaveLength, 2)
			convey.So(guaranteeMap[1], convey.ShouldBeNil)
			convey.So(guaranteeMap[2], convey.ShouldEqual, validRoot)
			convey.So(guaranteeMap[3], convey.ShouldBeNil)
			convey.So(guaranteeMap[4], convey.ShouldEqual, validChild)
		})

	})
}

func TestQuoteItem_GetQuantityUnit(t *testing.T) {
	mockey.PatchConvey("Test QuoteItem GetQuantityUnit", t, func() {
		mockey.PatchConvey("should return unit from price info snapshot", func() {
			item := &QuoteItem{PriceInfoSnapshot: `{"Unit":"次","PricingGranularity":5}`}

			unit, err := item.GetQuantityUnit()
			convey.So(err, convey.ShouldBeNil)
			convey.So(unit, convey.ShouldEqual, "次")
		})

		mockey.PatchConvey("should return error when price info snapshot invalid", func() {
			item := &QuoteItem{PriceInfoSnapshot: "invalid json"}

			unit, err := item.GetQuantityUnit()
			convey.So(unit, convey.ShouldEqual, "")
			convey.So(err, convey.ShouldNotBeNil)
		})
	})
}

func TestPriceInfoSnapshot_AlignWithUpstream(t *testing.T) {
	raw := `{
		"ChargeItemID":"charge_item_id",
		"PricingFunction":"fixed_price",
		"Currency":"CNY",
		"Price":"12.34",
		"MarketPrice":"15.00",
		"SegMarketPrice":"13.00",
		"MeasureInterval":"1,2",
		"Unit":"次",
		"IsResourcePack":true,
		"PriceInterval":"10,20",
		"IsCombining":true,
		"CombiningPrice":88.8,
		"StandardPrice":"standard price",
		"Quantity":"3次",
		"UnitDisplay":"次",
		"PricingGranularity":2.5,
		"SellingMode":"0",
		"BuyNumUnit":"个",
		"BuyDurationUnit":"月",
		"IsMaintenanceService":1.5,
		"GiveMaintenanceService":2.5,
		"MaintenanceNum":3.5,
		"MaintenanceUnit":"年",
		"RatioChargeItemNum":4.5,
		"RelatedChargeItemRatio":"0.25",
		"RelatedChargeItems":[{"Product":"product_a"}],
		"DiscountLineList":[{"DiscountLineName":"common_line"}]
	}`

	var snapshot PriceInfoSnapshot
	err := json.Unmarshal([]byte(raw), &snapshot)

	if err != nil {
		t.Fatalf("unmarshal price info snapshot failed: %v", err)
	}

	if snapshot.MarketPrice != "15.00" {
		t.Fatalf("unexpected MarketPrice: %s", snapshot.MarketPrice)
	}
	if snapshot.SegMarketPrice != "13.00" {
		t.Fatalf("unexpected SegMarketPrice: %s", snapshot.SegMarketPrice)
	}
	if snapshot.PricingGranularity != 2.5 {
		t.Fatalf("unexpected PricingGranularity: %v", snapshot.PricingGranularity)
	}
	if snapshot.SellingMode != "0" {
		t.Fatalf("unexpected SellingMode: %s", snapshot.SellingMode)
	}
	if snapshot.IsMaintenanceService != 1.5 {
		t.Fatalf("unexpected IsMaintenanceService: %v", snapshot.IsMaintenanceService)
	}
	if snapshot.GiveMaintenanceService != 2.5 {
		t.Fatalf("unexpected GiveMaintenanceService: %v", snapshot.GiveMaintenanceService)
	}
	if snapshot.MaintenanceNum != 3.5 {
		t.Fatalf("unexpected MaintenanceNum: %v", snapshot.MaintenanceNum)
	}
	if snapshot.RatioChargeItemNum != 4.5 {
		t.Fatalf("unexpected RatioChargeItemNum: %v", snapshot.RatioChargeItemNum)
	}
	if snapshot.RelatedChargeItemRatio.String() != "0.25" {
		t.Fatalf("unexpected RelatedChargeItemRatio: %s", snapshot.RelatedChargeItemRatio.String())
	}
	relatedChargeItems, ok := snapshot.RelatedChargeItems.([]interface{})
	if !ok {
		t.Fatalf("unexpected RelatedChargeItems type: %T", snapshot.RelatedChargeItems)
	}
	if len(relatedChargeItems) != 1 {
		t.Fatalf("unexpected RelatedChargeItems len: %d", len(relatedChargeItems))
	}

	discountLineList, ok := snapshot.DiscountLineList.([]interface{})
	if !ok {
		t.Fatalf("unexpected DiscountLineList type: %T", snapshot.DiscountLineList)
	}
	if len(discountLineList) != 1 {
		t.Fatalf("unexpected DiscountLineList len: %d", len(discountLineList))
	}
}

func TestGuaranteeResp_IsSame_GuaranteeProductSeats(t *testing.T) {
	mockey.PatchConvey("Test GuaranteeResp IsSame GuaranteeProductSeats", t, func() {
		base := &GuaranteeResp{
			GuaranteeItemID: 1,
			QuoteID:         2,
			GuaranteeType:   3,
			GuaranteeAmount: decimal.NewFromInt(100),
			GuaranteeRule:   "rule",
			AccountID:       "account",
			AccumulateType:  "single",
			GuaranteeProductSeats: []GuaranteeProductSeat{
				{TradeProduct: "Trae", Seats: 100},
				{TradeProduct: "ArkClaw", Seats: 200},
			},
		}

		mockey.PatchConvey("same seats with different order should be same", func() {
			other := &GuaranteeResp{
				GuaranteeItemID: 1,
				QuoteID:         2,
				GuaranteeType:   3,
				GuaranteeAmount: decimal.NewFromInt(100),
				GuaranteeRule:   "rule",
				AccountID:       "account",
				AccumulateType:  "single",
				GuaranteeProductSeats: []GuaranteeProductSeat{
					{TradeProduct: "ArkClaw", Seats: 200},
					{TradeProduct: "Trae", Seats: 100},
				},
			}

			convey.So(base.IsSame(other), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("different seats should not be same", func() {
			other := &GuaranteeResp{
				GuaranteeItemID: 1,
				QuoteID:         2,
				GuaranteeType:   3,
				GuaranteeAmount: decimal.NewFromInt(100),
				GuaranteeRule:   "rule",
				AccountID:       "account",
				AccumulateType:  "single",
				GuaranteeProductSeats: []GuaranteeProductSeat{
					{TradeProduct: "Trae", Seats: 101},
					{TradeProduct: "ArkClaw", Seats: 200},
				},
			}

			convey.So(base.IsSame(other), convey.ShouldBeFalse)
		})

		mockey.PatchConvey("same zero-value seats with different order should be same", func() {
			baseWithZeroValue := &GuaranteeResp{
				GuaranteeItemID: 1,
				QuoteID:         2,
				GuaranteeType:   3,
				GuaranteeAmount: decimal.NewFromInt(100),
				GuaranteeRule:   "rule",
				AccountID:       "account",
				AccumulateType:  "single",
				GuaranteeProductSeats: []GuaranteeProductSeat{
					{},
					{TradeProduct: "Trae", Seats: 100},
				},
			}
			other := &GuaranteeResp{
				GuaranteeItemID: 1,
				QuoteID:         2,
				GuaranteeType:   3,
				GuaranteeAmount: decimal.NewFromInt(100),
				GuaranteeRule:   "rule",
				AccountID:       "account",
				AccumulateType:  "single",
				GuaranteeProductSeats: []GuaranteeProductSeat{
					{TradeProduct: "Trae", Seats: 100},
					{},
				},
			}

			convey.So(baseWithZeroValue.IsSame(other), convey.ShouldBeTrue)
		})
	})
}

func TestQuoteItem_GenProductInfo(t *testing.T) {
	t.Run("case success-common", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(decimal.NewFromString).Return(decimal.Decimal{}, nil).Build()
			mockey.Mock((BuyModule).GetNumStr).Return("12").Build()
			mockey.Mock((GiveMaintenance).GetNumStr).Return("13").Build()
			_, taxRatio := util.ParseInvoiceProject("")

			// Act
			v := &QuoteItem{
				Config:               "Config",
				ConfigCode:           "ConfigCode",
				ChargeItemCode:       "ChargeItemCode",
				ChargeItemTag:        "ChargeItemTag",
				PricingVersion:       "PricingVersion",
				ActivationType:       "ActivationType",
				Discount:             "Discount",
				OffPeakHoursBilling:  "OffPeakHoursBilling",
				ChildProductName:     "ChildProductName",
				ChildProductCode:     "ChildProductCode",
				StandardProductCode:  "StandardProductCode",
				Product:              "Product",
				ProductName:          "ProductName",
				ConfigCategoryCode:   "ConfigCategoryCode",
				ChargeMethod:         "ChargeMethod",
				ChargeMethodCode:     "ChargeMethodCode",
				Region:               "Region",
				RegionCode:           "RegionCode",
				ChargeUnit:           "ChargeUnit",
				ChargeUnitCode:       "ChargeUnitCode",
				PriceFactor:          "PriceFactor",
				PriceFactorCode:      "PriceFactorCode",
				CanPrePay:            "CanPrePay",
				CanPrePayCode:        "CanPrePayCode",
				GuaranteedPercentage: "GuaranteedPercentage",
				SellingMode:          "SellingMode",
				StandardProduct:      "StandardProduct",
				ItemType:             "ItemType",
				QuoteSolutionID:      "QuoteSolutionID",
				TradeSolutionCode:    "TradeSolutionCode",
				TradeSolution:        "TradeSolution",
				TradeSolutionName:    "TradeSolutionName",
				TradeSolutionVersion: "TradeSolutionVersion",
				BuyNum:               "BuyNum",
				BuyDuration:          "BuyDuration",
				GiveMaintenance:      "GiveMaintenance",
				OriginalPrice:        "OriginalPrice",
				IncomeNoTax:          "IncomeNoTax",
				PriceInfoSnapshot:    "PriceInfoSnapshot",
				QuoteItemID:          "QuoteItemID",
				ShowName:             "ShowName",
				GiveAwayType:         "GiveAwayType",
			}
			got := v.GenProductInfo(0, 0)

			// Assert
			convey.So(got, convey.ShouldResemble, &ProductInfo{
				TradeProduct:         "Product",
				TradeProductName:     "ProductName",
				ChildProductCode:     "ChildProductCode",
				IsBillExist:          false,
				StandardProductCode:  "StandardProductCode",
				Configuration:        "ConfigCode",
				ConfigurationName:    "Config",
				ConfigCategory:       "ConfigCategoryCode",
				BillingMethodCode:    "ChargeMethodCode",
				BillingName:          "ChargeMethod",
				RegionCode:           "RegionCode",
				Region:               "Region",
				ChargeElement:        "ChargeUnit",
				ChargeElementCode:    "ChargeUnitCode",
				PriceFactor:          "PriceFactor",
				PriceFactorCode:      "PriceFactorCode",
				Discount:             "Discount",
				OffPeakHoursBilling:  "OffPeakHoursBilling",
				ChargeItemCode:       "ChargeItemCode",
				ChargeItemTag:        "ChargeItemTag",
				PricingVersion:       "PricingVersion",
				CanPrePay:            "CanPrePay",
				CanPrePayCode:        "CanPrePayCode",
				GuaranteedPercentage: "GuaranteedPercentage",
				TaxRatio:             taxRatio,
				DeploymentType:       0,
				SellingMode:          "SellingMode",
				ItemType:             "ItemType",
				ActivationType:       "ActivationType",
				StandardProduct:      "StandardProduct",
				QuoteSolutionID:      "QuoteSolutionID",
				TradeSolutionCode:    "TradeSolutionCode",
				TradeSolution:        "TradeSolution",
				TradeSolutionName:    "TradeSolutionName",
				TradeSolutionVersion: "TradeSolutionVersion",
				BuyNum:               "12",
				BuyDuration:          "12",
				MaintenanceNum:       "13",
				OriginalPrice:        "OriginalPrice",
				IncomeNoTax:          "IncomeNoTax",
				PriceInfoSnapshot:    "PriceInfoSnapshot",
				QuoteItemID:          "QuoteItemID",
				ShowName:             "ShowName",
				Exclude:              "{}",
				GiveAwayType:         "GiveAwayType",
			})
		})
	})
	t.Run("case success-bp分销", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(decimal.NewFromString).Return(decimal.Decimal{}, nil).Build()
			mockey.Mock((BuyModule).GetNumStr).Return("12").Build()
			mockey.Mock((GiveMaintenance).GetNumStr).Return("13").Build()
			_, taxRatio := util.ParseInvoiceProject("")

			// Act
			v := &QuoteItem{
				Config:               "Config",
				ConfigCode:           "ConfigCode",
				ChargeItemCode:       "ChargeItemCode",
				ChargeItemTag:        "ChargeItemTag",
				PricingVersion:       "PricingVersion",
				ActivationType:       "ActivationType",
				Discount:             "Discount",
				OffPeakHoursBilling:  "OffPeakHoursBilling",
				ChildProductName:     "ChildProductName",
				ChildProductCode:     "ChildProductCode",
				StandardProductCode:  "StandardProductCode",
				Product:              "Product",
				ProductName:          "ProductName",
				ConfigCategoryCode:   "ConfigCategoryCode",
				ChargeMethod:         "ChargeMethod",
				ChargeMethodCode:     "ChargeMethodCode",
				Region:               "Region",
				RegionCode:           "RegionCode",
				ChargeUnit:           "ChargeUnit",
				ChargeUnitCode:       "ChargeUnitCode",
				PriceFactor:          "PriceFactor",
				PriceFactorCode:      "PriceFactorCode",
				CanPrePay:            "CanPrePay",
				CanPrePayCode:        "CanPrePayCode",
				GuaranteedPercentage: "GuaranteedPercentage",
				SellingMode:          "SellingMode",
				StandardProduct:      "StandardProduct",
				ItemType:             "ItemType",
				QuoteSolutionID:      "QuoteSolutionID",
				TradeSolutionCode:    "TradeSolutionCode",
				TradeSolution:        "TradeSolution",
				TradeSolutionName:    "TradeSolutionName",
				TradeSolutionVersion: "TradeSolutionVersion",
				BuyNum:               "BuyNum",
				BuyDuration:          "BuyDuration",
				GiveMaintenance:      "GiveMaintenance",
				OriginalPrice:        "OriginalPrice",
				IncomeNoTax:          "IncomeNoTax",
				PriceInfoSnapshot:    "PriceInfoSnapshot",
				QuoteItemID:          "QuoteItemID",
				ShowName:             "ShowName",
				GiveAwayType:         "GiveAwayType",
			}
			got := v.GenProductInfo(_const.BusinessTypeBPDistribution, _const.DistributBusinessTypeSpecial)

			// Assert
			convey.So(got, convey.ShouldResemble, &ProductInfo{
				TradeProduct:         "Product",
				TradeProductName:     "ProductName",
				ChildProductCode:     "ChildProductCode",
				IsBillExist:          false,
				StandardProductCode:  "StandardProductCode",
				Configuration:        "ConfigCode",
				ConfigurationName:    "Config",
				ConfigCategory:       "ConfigCategoryCode",
				BillingMethodCode:    "ChargeMethodCode",
				BillingName:          "ChargeMethod",
				RegionCode:           "RegionCode",
				Region:               "Region",
				ChargeElement:        "ChargeUnit",
				ChargeElementCode:    "ChargeUnitCode",
				PriceFactor:          "PriceFactor",
				PriceFactorCode:      "PriceFactorCode",
				Discount:             "Discount",
				OffPeakHoursBilling:  "OffPeakHoursBilling",
				ChargeItemCode:       "ChargeItemCode",
				ChargeItemTag:        "ChargeItemTag",
				PricingVersion:       "PricingVersion",
				CanPrePay:            "CanPrePay",
				CanPrePayCode:        "CanPrePayCode",
				GuaranteedPercentage: "GuaranteedPercentage",
				TaxRatio:             taxRatio,
				DeploymentType:       0,
				SellingMode:          "SellingMode",
				ItemType:             "ItemType",
				ActivationType:       "ActivationType",
				StandardProduct:      "StandardProduct",
				QuoteSolutionID:      "QuoteSolutionID",
				TradeSolutionCode:    "TradeSolutionCode",
				TradeSolution:        "TradeSolution",
				TradeSolutionName:    "TradeSolutionName",
				TradeSolutionVersion: "TradeSolutionVersion",
				BuyNum:               "12",
				BuyDuration:          "12",
				MaintenanceNum:       "13",
				OriginalPrice:        "OriginalPrice",
				IncomeNoTax:          "IncomeNoTax",
				PriceInfoSnapshot:    "PriceInfoSnapshot",
				QuoteItemID:          "QuoteItemID",
				ShowName:             "ShowName",
				Exclude:              "{}",
				GiveAwayType:         "GiveAwayType",
			})
		})
	})
}

func TestGuaranteeResp_IsSame_CarryForward(t *testing.T) {
	base := &GuaranteeResp{
		GuaranteeItemID: 1,
		QuoteID:         2,
		GuaranteeType:   _const.GuaranteeTypeAll,
		GuaranteeAmount: decimal.NewFromInt(100),
		AccountID:       "2100000001",
		AccumulateType:  "single",
		CarryForward:    1,
	}

	same := *base
	if !base.IsSame(&same) {
		t.Fatal("expected same guarantee info when CarryForward is equal")
	}

	different := *base
	different.CarryForward = 2
	if base.IsSame(&different) {
		t.Fatal("expected different guarantee info when CarryForward is different")
	}
}

func Test_GenQuoteDiscount(t *testing.T) {
	q := &QuoteItem{}
	beginTime := "2023-01-01"
	endTime := "2023-12-31"
	isProject := "0"

	mockey.PatchConvey("Test CanPrePayCode not found in mapping", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.CanPrePayCode = "not_found"
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, nil)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test DeploymentType not found in mapping", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.DeploymentType = -1
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, nil)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test SellingMode is empty", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.SellingMode = ""
		expected := &QuoteDiscount{
			Product:               q.Product,
			ProductName:           q.ProductName,
			ProductCode:           q.ChildProductCode,
			Configuration:         q.ConfigCode,
			ConfigurationName:     q.Config,
			ChargeItemCode:        q.ChargeItemCode,
			ChargeItemTag:         q.ChargeItemTag,
			PriceVersion:          q.PricingVersion,
			Discount:              q.Discount,
			BeginTime:             beginTime,
			EndTime:               endTime,
			BizBillingFunction:    "",
			UnitPrice:             "",
			UnitPriceInterval:     "",
			MeasureInterval:       "",
			BottomAmount:          "",
			ConfigurationCategory: q.ConfigCategoryCode,
			BillingMethodCode:     q.ChargeMethodCode,
			BillingName:           q.ChargeMethod,
			RegionCode:            q.RegionCode,
			Region:                q.Region,
			ChargeElement:         q.ChargeUnit,
			ChargeElementCode:     q.ChargeUnitCode,
			PriceFactor:           q.PriceFactorCode,
			PriceFactorName:       q.PriceFactor,
			PayType:               "",
			CanPrePay:             q.CanPrePay,
			GuaranteedPercentage:  q.GuaranteedPercentage,
			SellingMode:           "0",
			DeploymentType:        0,
			ProductCatalogue:      _const.StandProductCodeMap[q.StandardProduct],
			Solution:              q.TradeSolution,
			SolutionVersion:       q.TradeSolutionVersion,
			ExternalID:            "",
			PriceInfoSnapshot:     q.PriceInfoSnapshot,
			IsProject:             isProject,
			ReferenceID:           q.QuoteItemID,
		}
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, nil)
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("Test normal case - customerDiscount nil", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.CanPrePayCode = "valid_code"
		q.DeploymentType = 1
		q.SellingMode = "1"
		expected := &QuoteDiscount{
			Product:               q.Product,
			ProductName:           q.ProductName,
			ProductCode:           q.ChildProductCode,
			Configuration:         q.ConfigCode,
			ConfigurationName:     q.Config,
			ChargeItemCode:        q.ChargeItemCode,
			ChargeItemTag:         q.ChargeItemTag,
			PriceVersion:          q.PricingVersion,
			Discount:              q.Discount,
			BeginTime:             beginTime,
			EndTime:               endTime,
			BizBillingFunction:    "",
			UnitPrice:             "",
			UnitPriceInterval:     "",
			MeasureInterval:       "",
			BottomAmount:          "",
			ConfigurationCategory: q.ConfigCategoryCode,
			BillingMethodCode:     q.ChargeMethodCode,
			BillingName:           q.ChargeMethod,
			RegionCode:            q.RegionCode,
			Region:                q.Region,
			ChargeElement:         q.ChargeUnit,
			ChargeElementCode:     q.ChargeUnitCode,
			PriceFactor:           q.PriceFactorCode,
			PriceFactorName:       q.PriceFactor,
			PayType:               "valid_pay_type",
			CanPrePay:             q.CanPrePay,
			GuaranteedPercentage:  q.GuaranteedPercentage,
			SellingMode:           "1",
			DeploymentType:        1,
			ProductCatalogue:      _const.StandProductCodeMap[q.StandardProduct],
			Solution:              q.TradeSolution,
			SolutionVersion:       q.TradeSolutionVersion,
			ExternalID:            "",
			PriceInfoSnapshot:     q.PriceInfoSnapshot,
			IsProject:             isProject,
			ReferenceID:           q.QuoteItemID,
		}
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, nil)
		convey.So(actual, convey.ShouldResemble, expected)
	})
	mockey.PatchConvey("Test normal case - customerDiscount.Discount nil", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.CanPrePayCode = "valid_code"
		q.DeploymentType = 1
		q.SellingMode = "1"
		expected := &QuoteDiscount{
			Product:               q.Product,
			ProductName:           q.ProductName,
			ProductCode:           q.ChildProductCode,
			Configuration:         q.ConfigCode,
			ConfigurationName:     q.Config,
			ChargeItemCode:        q.ChargeItemCode,
			ChargeItemTag:         q.ChargeItemTag,
			PriceVersion:          q.PricingVersion,
			Discount:              q.Discount,
			BeginTime:             beginTime,
			EndTime:               endTime,
			BizBillingFunction:    "",
			UnitPrice:             "",
			UnitPriceInterval:     "",
			MeasureInterval:       "",
			BottomAmount:          "",
			ConfigurationCategory: q.ConfigCategoryCode,
			BillingMethodCode:     q.ChargeMethodCode,
			BillingName:           q.ChargeMethod,
			RegionCode:            q.RegionCode,
			Region:                q.Region,
			ChargeElement:         q.ChargeUnit,
			ChargeElementCode:     q.ChargeUnitCode,
			PriceFactor:           q.PriceFactorCode,
			PriceFactorName:       q.PriceFactor,
			PayType:               "valid_pay_type",
			CanPrePay:             q.CanPrePay,
			GuaranteedPercentage:  q.GuaranteedPercentage,
			SellingMode:           "1",
			DeploymentType:        1,
			ProductCatalogue:      _const.StandProductCodeMap[q.StandardProduct],
			Solution:              q.TradeSolution,
			SolutionVersion:       q.TradeSolutionVersion,
			ExternalID:            "",
			PriceInfoSnapshot:     q.PriceInfoSnapshot,
			IsProject:             isProject,
			ReferenceID:           q.QuoteItemID,
		}
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, &CustomerDiscount{})
		convey.So(actual, convey.ShouldResemble, expected)
	})

	mockey.PatchConvey("节省计划商品", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		q.SalesMode = multienv.SalesModeSavingsPlans
		expected := &QuoteDiscount{
			Product:               q.Product,
			ProductName:           q.ProductName,
			ProductCode:           q.ChildProductCode,
			Configuration:         q.ConfigCode,
			ConfigurationName:     q.Config,
			ChargeItemCode:        q.ChargeItemCode,
			ChargeItemTag:         q.ChargeItemTag,
			PriceVersion:          q.PricingVersion,
			Discount:              q.Discount,
			BeginTime:             beginTime,
			EndTime:               endTime,
			BizBillingFunction:    "",
			UnitPrice:             "",
			UnitPriceInterval:     "",
			MeasureInterval:       "",
			BottomAmount:          "",
			ConfigurationCategory: q.ConfigCategoryCode,
			BillingMethodCode:     q.ChargeMethodCode,
			BillingName:           q.ChargeMethod,
			RegionCode:            q.RegionCode,
			Region:                q.Region,
			ChargeElement:         q.ChargeUnit,
			ChargeElementCode:     q.ChargeUnitCode,
			PriceFactor:           q.PriceFactorCode,
			PriceFactorName:       q.PriceFactor,
			PayType:               "",
			CanPrePay:             q.CanPrePay,
			GuaranteedPercentage:  q.GuaranteedPercentage,
			SellingMode:           "0",
			DeploymentType:        0,
			ProductCatalogue:      _const.StandProductCodeMap[q.StandardProduct],
			Solution:              q.TradeSolution,
			SolutionVersion:       q.TradeSolutionVersion,
			ExternalID:            "",
			PriceInfoSnapshot:     q.PriceInfoSnapshot,
			IsProject:             isProject,
			ReferenceID:           q.QuoteItemID,
			Extra: &DiscountExtra{
				SavingPlan: &SavingPlanInExtra{
					PrePayRatio:           "PrePayRatio",
					PrePayRatioCode:       "PrePayRatioCode",
					SpBuyDuration:         "SpBuyDuration",
					SpBuyDurationCode:     "SpBuyDurationCode",
					CommitFeeInterval:     "CommitFeeInterval",
					CommitFeeIntervalCode: "CommitFeeIntervalCode",
				},
			},
		}
		actual := q.GenQuoteDiscount(beginTime, endTime, isProject, nil)
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

func TestGenCustomerDiscountList(t *testing.T) {
	t.Run("case DistributionDiscounts success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			res, err := GenCustomerDiscountList(context.Background(), &GenCustomerDiscountListReq{
				BusinessType:          7,
				DistributBusinessType: 1,
				AccountID:             "123123",
				Discount:              "{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":10,\"Assigned\":true}",
				DistributionDiscounts: "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"10\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"2\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"1\",\"Assigned\":false}}}",
			})

			// Assert
			convey.So(res, convey.ShouldResemble, []*CustomerDiscount{
				{
					CustomerInfo: CustomerInfo{
						CustomerType: "FirstDistributor",
						AccountID:    "3000009113",
						OwnerID:      "3000009115",
						CustomerName: "kanna_test"},
					Discount: &Discount{
						PricingFunction: "fixed_price",
						UnitPrice:       decimal.NewFromInt(10),
					},
				},
				{
					CustomerInfo: CustomerInfo{
						CustomerType: "SecondDistributor",
						AccountID:    "3000009114",
						OwnerID:      "3000009115",
						CustomerName: "kanna_test"},
					Discount: &Discount{
						PricingFunction: "fixed_price",
						UnitPrice:       decimal.NewFromInt(2),
					},
				},
				{
					CustomerInfo: CustomerInfo{
						CustomerType: "FinalCustomer",
						AccountID:    "3000009115",
						OwnerID:      "*",
						CustomerName: "kanna_test",
					},
					Discount: &Discount{
						PricingFunction: "fixed_price",
						UnitPrice:       decimal.NewFromInt(1),
					},
				},
			})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case DistributionDiscounts json.Unmarshal fail ", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(json.Unmarshal).Return(fmt.Errorf("json.Unmarshal fail")).Build()
			// Act
			res, err := GenCustomerDiscountList(context.Background(), &GenCustomerDiscountListReq{
				BusinessType:          7,
				DistributBusinessType: 1,
				AccountID:             "123123",
				Discount:              "{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":10,\"Assigned\":true}",
				DistributionDiscounts: "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"10\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"2\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"1\",\"Assigned\":false}}}",
			})
			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "json.Unmarshal fail")
		})
	})
	t.Run("case Discount success ", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			res, err := GenCustomerDiscountList(context.Background(), &GenCustomerDiscountListReq{
				BusinessType:          0,
				DistributBusinessType: 0,
				AccountID:             "123123",
				Discount:              "{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":10,\"Assigned\":true}",
				DistributionDiscounts: "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"10\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"2\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"1\",\"Assigned\":false}}}",
			})

			// Assert
			convey.So(res, convey.ShouldResemble, []*CustomerDiscount{
				{CustomerInfo: CustomerInfo{AccountID: "123123"}, Discount: &Discount{PricingFunction: "fixed_price", UnitPrice: decimal.NewFromInt(10)}}})
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case Discount json.Unmarshal fail ", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(json.Unmarshal).Return(fmt.Errorf("json.Unmarshal fail")).Build()
			// Act
			res, err := GenCustomerDiscountList(context.Background(), &GenCustomerDiscountListReq{
				BusinessType:          0,
				DistributBusinessType: 0,
				AccountID:             "123123",
				Discount:              "{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":10,\"Assigned\":true}",
				DistributionDiscounts: "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"10\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"2\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"fixed_price\",\"UnitPriceInterval\":\"\",\"MeasureInterval\":\"\",\"UnitPrice\":\"1\",\"Assigned\":false}}}",
			})
			// Assert
			convey.So(res, convey.ShouldBeNil)
			convey.So(err.Error(), convey.ShouldEqual, "json.Unmarshal fail")
		})
	})
}

func Test_GetProductSolutionEmailPtr(t *testing.T) {
	t.Run("case GetProductSolutionEmailPtr#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			info := QuoteBizInfo{ProductSolutionEmail: ""}
			// Assert
			convey.So(info.GetProductSolutionEmailPtr(), convey.ShouldBeNil)
		})
	})
	t.Run("case GetProductSolutionEmailPtr#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			info := QuoteBizInfo{
				ProductSolutionEmail: "12",
			}
			// Assert
			convey.So(info.GetProductSolutionEmailPtr(), convey.ShouldNotBeNil)
		})
	})
}

func Test_GetRelatedResDepartmentPtr(t *testing.T) {
	t.Run("case GetRelatedResDepartmentPtr#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			info := QuoteBizInfo{RelatedResDepartment: ""}
			// Assert
			convey.So(info.GetRelatedResDepartmentPtr(), convey.ShouldBeNil)
		})
	})
	t.Run("case GetRelatedResDepartmentPtr#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			info := QuoteBizInfo{
				RelatedResDepartment: "12",
			}
			// Assert
			convey.So(info.GetRelatedResDepartmentPtr(), convey.ShouldNotBeNil)
		})
	})
}

func TestQuoteCreateContractReq_IsPass_ByteUTGen(t *testing.T) {
	// 测试输入的QuoteCreateContractReq的BizInfo不为空且状态均不为通过的场景
	t.Run("BizInfoNotNullAndStatusNotPass", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.BizInfo != nil
			var receiver *QuoteCreateContractReq = &QuoteCreateContractReq{
				QuoteStatus: "Test Value",
				BizInfo: &QuoteBizInfo{
					QuoteStatus: "InProgress",
				},
			}
			// 运行被测函数
			got1 := receiver.IsPass()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 构造的receiver的BizInfo不为nil，且QuoteStatus不等于_const.StatusPass，BizInfo.QuoteStatus也不等于_const.StatusPass，根据函数逻辑，应返回false
			convey.So(got1, convey.ShouldEqual, false)
		})
	})
	// 测试BizInfo为nil且QuoteStatus不等于_const.StatusPass的场景
	t.Run("BizInfoNilAndQuoteStatusNotPass", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.BizInfo == nil
			var receiver *QuoteCreateContractReq = &QuoteCreateContractReq{
				QuoteStatus: "Test Value",
			}
			// 运行被测函数
			got1 := receiver.IsPass()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 构造的QuoteCreateContractReq对象的BizInfo为nil，且QuoteStatus为\"Test Value\"，不等于_const.StatusPass，根据函数逻辑，应返回false
			convey.So(got1, convey.ShouldEqual, false)
		})
	})
}

func Test_QuoteBizInfo_GenAllQuoteItems_BitsUTGen(t *testing.T) {
	t.Run("GenAllQuoteItems_nil_receiver_returns_nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var q *QuoteBizInfo = nil
			res := q.GenAllQuoteItems()
			convey.So(res, convey.ShouldBeNil)
		})
	})

	t.Run("GenAllQuoteItems_combines_quote_and_deduct_items", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			item1 := &QuoteItem{Config: "A", QuoteItemID: "1"}
			item2 := &QuoteItem{Config: "B", QuoteItemID: "2"}
			deduct1 := &QuoteItem{Config: "C", QuoteItemID: "3"}
			q := &QuoteBizInfo{
				QuoteItems:       QuoteItemList{item1, item2},
				DeductQuoteItems: QuoteItemList{deduct1},
			}
			res := q.GenAllQuoteItems()
			convey.So(len(res), convey.ShouldEqual, 3)
			convey.So(res, convey.ShouldResemble, []*QuoteItem{item1, item2, deduct1})
		})
	})

	t.Run("只包含报价项，无抵扣项", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			item1 := &QuoteItem{Config: "A", QuoteItemID: "1"}
			item2 := &QuoteItem{Config: "B", QuoteItemID: "2"}
			q := &QuoteBizInfo{
				QuoteItems: QuoteItemList{item1, item2},
			}
			res := q.GenAllQuoteItems()
			convey.So(len(res), convey.ShouldEqual, 2)
			convey.So(res, convey.ShouldResemble, []*QuoteItem{item1, item2})
		})
	})
}

func Test_QuoteBizInfo_GenAllProductInfoList_BitsUTGen(t *testing.T) {
	t.Run("NilReceiverReturnsNil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var info *QuoteBizInfo
			result := info.GenAllProductInfoList()
			convey.So(result, convey.ShouldBeNil)
		})
	})

	t.Run("NoDeductItemsReturnsPrimaryList", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			primary := []*ProductInfo{{QuoteItemID: "primary"}}
			mockey.Mock(QuoteItemList.GenProductInfoList).Return(primary).Build()
			info := &QuoteBizInfo{
				TradeTypeCode:           1,
				DistributionBizTypeCode: 2,
				QuoteItems:              QuoteItemList{&QuoteItem{}},
				DeductQuoteItems:        QuoteItemList{},
			}
			result := info.GenAllProductInfoList()
			convey.So(result, convey.ShouldResemble, primary)
		})
	})

	t.Run("DeductItemsAppendedToPrimaryList", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			primaryItem := &ProductInfo{QuoteItemID: "primary"}
			deductItem := &ProductInfo{QuoteItemID: "deduct"}
			primaryList := []*ProductInfo{primaryItem}
			deductList := []*ProductInfo{deductItem}
			mockey.Mock(QuoteItemList.GenProductInfoList).Return(
				mockey.Sequence(primaryList).Then(deductList),
			).Build()
			info := &QuoteBizInfo{
				TradeTypeCode:           3,
				DistributionBizTypeCode: 4,
				QuoteItems:              QuoteItemList{&QuoteItem{}},
				DeductQuoteItems:        QuoteItemList{&QuoteItem{}},
			}
			result := info.GenAllProductInfoList()
			convey.So(result, convey.ShouldHaveLength, 2)
			convey.So(result[0], convey.ShouldEqual, primaryItem)
			convey.So(result[1], convey.ShouldEqual, deductItem)
		})
	})
}

//func Test_QuoteDiscount_ConvertToSavingPlanDiscount_BitsUTGen(t *testing.T) {
//	t.Run("Nil receiver returns nil", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			var quoteDiscount *QuoteDiscount
//
//			got := quoteDiscount.ConvertToSavingPlanDiscount()
//
//			convey.So(got, convey.ShouldBeNil)
//		})
//	})
//
//	t.Run("Non nil receiver maps all supported fields", func(t *testing.T) {
//		mockey.PatchConvey("", t, func() {
//			extra := &DiscountExtra{}
//			quoteDiscount := &QuoteDiscount{
//				Product:               "product-a",
//				PayType:               "postpaid",
//				ConfigurationCategory: "category-a",
//				Configuration:         "config-a",
//				ConfigurationName:     "config-name-a",
//				ChargeItemTag:         "charge-tag-a",
//				BillingMethodCode:     "billing-method-a",
//				BillingName:           "billing-name-a",
//				RegionCode:            "region-a",
//				ChargeElementCode:     "charge-element-code-a",
//				PriceFactor:           "price-factor-a",
//				ChargeItemCode:        "charge-item-code-a",
//				BizBillingFunction:    "billing-function-a",
//				UnitPrice:             "12.34",
//				UnitPriceInterval:     "hour",
//				MeasureInterval:       "1",
//				DeploymentType:        2,
//				ProductCatalogue:      "standard_product",
//				Solution:              "solution-a",
//				SolutionVersion:       "v1.0.0",
//				ReferenceID:           "reference-id-a",
//				Extra:                 extra,
//				ProductName:           "ignored-product-name",
//				ProductCode:           "ignored-product-code",
//				PriceVersion:          "ignored-price-version",
//				Discount:              "ignored-discount",
//				BeginTime:             "ignored-begin-time",
//				EndTime:               "ignored-end-time",
//				BottomAmount:          "ignored-bottom-amount",
//				Region:                "ignored-region",
//				ChargeElement:         "ignored-charge-element",
//				PriceFactorName:       "ignored-price-factor-name",
//				CanPrePay:             "ignored-can-prepay",
//				GuaranteedPercentage:  "ignored-guaranteed-percentage",
//				SellingMode:           "ignored-selling-mode",
//				ExternalID:            "ignored-external-id",
//				PriceInfoSnapshot:     "ignored-price-info-snapshot",
//				IsProject:             "ignored-is-project",
//				AccountID:             "ignored-account-id",
//				OwnerID:               "ignored-owner-id",
//				RelatedItemID:         "ignored-related-item-id",
//				ItemBusinessRole:      "ignored-item-business-role",
//				Exclude: DiscountExclude{
//					ConfigurationCategory: "exclude-category-a",
//					Configuration:         "exclude-config-a",
//					RegionCode:            "exclude-region-a",
//					ChargeElement:         "exclude-charge-element-a",
//					ChargeItemTag:         "exclude-charge-tag-a",
//				},
//			}
//
//			got := quoteDiscount.ConvertToSavingPlanDiscount()
//
//			expected := &SavingPlanDiscount{
//				Product:                      "product-a",
//				PayType:                      "postpaid",
//				ConfigurationCategory:        "category-a",
//				Configuration:                "config-a",
//				ConfigurationName:            "config-name-a",
//				ChargeItemTag:                "charge-tag-a",
//				BillingMethodCode:            "billing-method-a",
//				BillingName:                  "billing-name-a",
//				RegionCode:                   "region-a",
//				ChargeElementCode:            "charge-element-code-a",
//				PriceFactor:                  "price-factor-a",
//				ChargeItemCode:               "charge-item-code-a",
//				BillingFunction:              "billing-function-a",
//				UnitPrice:                    "12.34",
//				UnitPriceInterval:            "hour",
//				MeasureInterval:              "1",
//				DeploymentType:               2,
//				ProductCatalogue:             "standard_product",
//				Solution:                     "solution-a",
//				SolutionVersion:              "v1.0.0",
//				ReferenceID:                  "reference-id-a",
//				Extra:                        extra,
//				ConfigurationCategoryExclude: "exclude-category-a",
//				ConfigurationExclude:         "exclude-config-a",
//				ChargeElementExclude:         "exclude-charge-element-a",
//				ChargeItemTagExclude:         "exclude-charge-tag-a",
//				RegionExclude:                "exclude-region-a",
//			}
//
//			convey.So(got, convey.ShouldResemble, expected)
//			convey.So(got.Extra, convey.ShouldEqual, extra)
//		})
//	})
//}

func Test_QuoteBizInfo_GenAllProductInfoMap_BitsUTGen(t *testing.T) {
	t.Run("Nil receiver returns nil map", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var quoteBizInfo *QuoteBizInfo

			got := quoteBizInfo.GenAllProductInfoMap()

			convey.So(got, convey.ShouldBeNil)
		})
	})

	t.Run("Non nil receiver returns quote product map when deduct map is empty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			quoteProduct := &ProductInfo{QuoteItemID: "quote-item-1"}
			mockQuoteMap := map[string][]*ProductInfo{
				"standard": []*ProductInfo{quoteProduct},
			}
			mockDeductMap := map[string][]*ProductInfo{}
			expected := map[string][]*ProductInfo{
				"standard": []*ProductInfo{quoteProduct},
			}

			mockey.Mock(QuoteItemList.GenProductInfoMap).Return(mockey.Sequence(mockQuoteMap).Then(mockDeductMap)).Build()

			quoteBizInfo := &QuoteBizInfo{
				TradeTypeCode:           1,
				DistributionBizTypeCode: 2,
				QuoteItems:              QuoteItemList{},
				DeductQuoteItems:        QuoteItemList{},
			}

			got := quoteBizInfo.GenAllProductInfoMap()

			convey.So(got, convey.ShouldResemble, expected)
		})
	})

	t.Run("Non nil receiver merges deduct product map into existing and new groups", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			quoteProduct := &ProductInfo{QuoteItemID: "quote-item-1"}
			deductProductInExistingGroup := &ProductInfo{QuoteItemID: "deduct-item-1"}
			deductProductInNewGroup := &ProductInfo{QuoteItemID: "deduct-item-2"}

			mockQuoteMap := map[string][]*ProductInfo{
				"existing": []*ProductInfo{quoteProduct},
			}
			mockDeductMap := map[string][]*ProductInfo{
				"existing": []*ProductInfo{deductProductInExistingGroup},
				"new":      []*ProductInfo{deductProductInNewGroup},
			}
			expected := map[string][]*ProductInfo{
				"existing": []*ProductInfo{quoteProduct, deductProductInExistingGroup},
				"new":      []*ProductInfo{deductProductInNewGroup},
			}

			mockey.Mock(QuoteItemList.GenProductInfoMap).Return(mockey.Sequence(mockQuoteMap).Then(mockDeductMap)).Build()

			quoteBizInfo := &QuoteBizInfo{
				TradeTypeCode:           3,
				DistributionBizTypeCode: 4,
				QuoteItems:              QuoteItemList{},
				DeductQuoteItems:        QuoteItemList{},
			}

			got := quoteBizInfo.GenAllProductInfoMap()

			convey.So(got, convey.ShouldResemble, expected)
		})
	})
}

func TestContractGuaranteeRuleNodeRespValidGuarantees(t *testing.T) {
	t.Run("空节点返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var node *ContractGuaranteeRuleNodeResp

			convey.So(node.ValidGuarantees(), convey.ShouldBeNil)
		})
	})

	t.Run("过滤无效节点并递归子节点", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			validGrandChild := &GuaranteeResp{GuaranteeItemID: 22, GuaranteeType: _const.GuaranteeTypeAll}
			node := &ContractGuaranteeRuleNodeResp{
				Item: &GuaranteeResp{GuaranteeItemID: 21, GuaranteeType: _const.GuaranteeTypeOther},
				Children: []*ContractGuaranteeRuleNodeResp{
					nil,
					{
						Children: []*ContractGuaranteeRuleNodeResp{
							{Item: validGrandChild},
						},
					},
				},
			}

			convey.So(node.ValidGuarantees(), convey.ShouldResemble, []*GuaranteeResp{validGrandChild})
		})
	})
}

func TestContractGuaranteeRuleTreeRespValidGuarantees(t *testing.T) {
	t.Run("空树返回空结果", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			var ruleTree *ContractGuaranteeRuleTreeResp

			convey.So(ruleTree.ValidGuarantees(), convey.ShouldBeNil)
			convey.So(ruleTree.HasValidGuarantee(), convey.ShouldBeFalse)
		})
	})

	t.Run("跳过空分组并汇总有效保底", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			validRoot := &GuaranteeResp{GuaranteeItemID: 11, GuaranteeType: _const.GuaranteeTypeAll}
			validChild := &GuaranteeResp{GuaranteeItemID: 12, GuaranteeType: _const.GuaranteeTypePart}
			ruleTree := &ContractGuaranteeRuleTreeResp{
				Groups: []*ContractGuaranteeRuleGroupResp{
					nil,
					{
						Root: &ContractGuaranteeRuleNodeResp{
							Item: validRoot,
							Children: []*ContractGuaranteeRuleNodeResp{
								nil,
								{Item: &GuaranteeResp{GuaranteeItemID: 13, GuaranteeType: _const.GuaranteeTypeOther}},
								{Item: validChild},
							},
						},
					},
				},
			}

			guarantees := ruleTree.ValidGuarantees()

			convey.So(guarantees, convey.ShouldResemble, []*GuaranteeResp{validRoot, validChild})
			convey.So(ruleTree.HasValidGuarantee(), convey.ShouldBeTrue)
		})
	})
}

func TestIsSameStringSlice(t *testing.T) {
	mockey.PatchConvey("Test isSameStringSlice", t, func() {
		mockey.PatchConvey("same values should be same", func() {
			convey.So(isSameStringSlice([]string{"ladder-a", "ladder-b"}, []string{"ladder-a", "ladder-b"}), convey.ShouldBeTrue)
		})

		mockey.PatchConvey("different lengths should not be same", func() {
			convey.So(isSameStringSlice([]string{"ladder-a"}, []string{"ladder-a", "ladder-b"}), convey.ShouldBeFalse)
		})

		mockey.PatchConvey("same length but different order should not be same", func() {
			convey.So(isSameStringSlice([]string{"ladder-a", "ladder-b"}, []string{"ladder-b", "ladder-a"}), convey.ShouldBeFalse)
		})
	})
}

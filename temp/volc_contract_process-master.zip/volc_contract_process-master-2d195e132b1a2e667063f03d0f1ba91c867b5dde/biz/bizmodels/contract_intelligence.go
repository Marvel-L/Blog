package bizmodels

import (
	"strings"

	"volc_contract_process/pkg/errors"
)

const maxContractIntelligenceFeedbackItems = 10

// FeedbackItemReq 单条合同智能反馈建议
type FeedbackItemReq struct {
	FeedbackContent string `json:"FeedbackContent" query:"FeedbackContent"`
	AttachmentID    string `json:"AttachmentID" query:"AttachmentID"`
}

// SubmitContractIntelligenceFeedbackReq 提交合同智能反馈请求
type SubmitContractIntelligenceFeedbackReq struct {
	CurrentOperator    string             `json:"CurrentOperator" query:"CurrentOperator"`
	ContractNo         string             `json:"ContractNo" query:"ContractNo"`
	ContractName       string             `json:"ContractName" query:"ContractName"`
	InOutType          string             `json:"InOutType" query:"InOutType"`
	ContractSubmitTime string             `json:"ContractSubmitTime" query:"ContractSubmitTime"`
	FeedbackItems      []*FeedbackItemReq `json:"FeedbackItems" query:"FeedbackItems"`
}

func (q *SubmitContractIntelligenceFeedbackReq) Validate() errors.APIError {
	if q == nil {
		return errors.ErrCommon.WithArgs("request is nil")
	}
	if strings.TrimSpace(q.CurrentOperator) == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if strings.TrimSpace(q.ContractNo) == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if strings.TrimSpace(q.ContractName) == "" {
		return errors.ErrMissingParam.WithArgs("ContractName")
	}
	if strings.TrimSpace(q.InOutType) == "" {
		return errors.ErrMissingParam.WithArgs("InOutType")
	}
	if strings.TrimSpace(q.ContractSubmitTime) == "" {
		return errors.ErrMissingParam.WithArgs("ContractSubmitTime")
	}
	if len(q.FeedbackItems) == 0 {
		return errors.ErrMissingParam.WithArgs("FeedbackItems")
	}
	if len(q.FeedbackItems) > maxContractIntelligenceFeedbackItems {
		return errors.ErrValidateParamErr.WithArgs("FeedbackItems数量不能超过10个")
	}
	for _, item := range q.FeedbackItems {
		if item == nil || strings.TrimSpace(item.FeedbackContent) == "" {
			return errors.ErrMissingParam.WithArgs("FeedbackContent")
		}
	}
	return nil
}

// GetAIAuditReportReq 获取合同智能审核报告请求。
type GetAIAuditReportReq struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"`
	ContractNo      string `json:"ContractNo" query:"ContractNo"`
}

func (q *GetAIAuditReportReq) Validate() errors.APIError {
	if q == nil {
		return errors.ErrCommon.WithArgs("request is nil")
	}
	if strings.TrimSpace(q.CurrentOperator) == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if strings.TrimSpace(q.ContractNo) == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

// GetAIAuditReportResp 获取合同智能审核报告响应。
type GetAIAuditReportResp struct {
	ContractNo     string `json:"ContractNo"`
	Visible        bool   `json:"Visible"`
	AuditTaskState string `json:"AuditTaskState"`
	ReportURL      string `json:"ReportURL"`
}

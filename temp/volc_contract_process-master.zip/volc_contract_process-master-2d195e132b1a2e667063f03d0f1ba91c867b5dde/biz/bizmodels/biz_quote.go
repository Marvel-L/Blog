package bizmodels

import (
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
	"volc_contract_process/pkg/util"

	"code.byted.org/eps-platform/volcengine-innersdk-golang/volcengine"
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/pkg/conf"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type BizInfoQuote struct {
	baseBizInfo
	baseBizData
	AccountInfo *BizInfoQuoteAccountInfo `json:"AccountInfo"` //
	QuoteInfo   QuoteBizInfo             `json:"QuoteInfo"`   //
}

// BizInfoPayOnBehalf 代付
type BizInfoPayOnBehalf struct {
	baseBizInfo
	baseBizData
}

type BizInfoPartnerQuote struct {
	baseBizInfo
	baseBizData
	PartnerInfo *BizInfoPartnerAccountInfo `json:"PartnerInfo"` //
	QuoteInfo   QuoteBizInfo               `json:"QuoteInfo"`   //
}

func (b *BizInfoQuote) Validate() errors.APIError {
	if b.AccountInfo == nil {
		return errors.ErrorCommon.WithArgs("QuoteBizInfo缺少账号相关信息")
	}
	if len(b.QuoteInfo.QuoteItems) == 0 {
		return errors.ErrorCommon.WithArgs("报价条目信息为空")
	}
	if len(b.QuoteInfo.ProductSolutionEmail) == 0 {
		return errors.ErrorCommon.WithArgs("报价产品解决方案信息为空")
	}
	return nil
}

type BizInfoQuoteAccountInfo struct {
	AccountID                       int64  `json:"AccountID"`                       //
	ContactName                     string `json:"ContactName"`                     // 联系人名称
	ContactEmail                    string `json:"ContactEmail"`                    // 联系人邮箱
	ContactTel                      string `json:"ContactTel"`                      // 联系人电话
	CompanyAddress                  string `json:"CompanyAddress"`                  // 客户注册地址
	RegistrationNumber              string `json:"RegistrationNumber"`              // 客户注册号
	VATRegistrationNumber           string `json:"VATRegistrationNumber"`           // 客户税号
	CustomContactName               string `json:"CustomContactName"`               // 客户联系人姓名
	CustomEmail                     string `json:"CustomEmail"`                     // 客户联系人邮箱
	CustomTel                       string `json:"CustomTel"`                       // 客户联系人电话
	CustomerContactMailingAddress   string `json:"CustomerContactMailingAddress"`   // 客户联系人地址
	CustomContactPosition           string `json:"CustomContactPosition"`           // 客户联系人职位
	VolcContactName                 string `json:"VolcContactName"`                 // BytePlus联系人姓名
	VolcEmail                       string `json:"VolcEmail"`                       // BytePlus联系人邮件
	VolcTel                         string `json:"VolcTel"`                         // BytePlus联系人电话
	RelatedPartnerContractNo        string `json:"RelatedPartnerContractNo"`        // 关联伙伴入驻协议编号
	RelatedPartnerContractBeginTime string `json:"RelatedPartnerContractBeginTime"` // 关联伙伴入驻协议有效期开始时间
}

type BizInfoPartnerAccountInfo struct {
	AccountID           int64  `json:"AccountID"`           // 合作伙伴AccountId
	PartnerContactName  string `json:"PartnerContactName"`  // 合作伙伴联系人：prm获取预填，可修改
	PartnerName         string `json:"PartnerName"`         // 合作伙伴名称：prm获取预填，不可修改
	PartnerContactEmail string `json:"PartnerContactEmail"` // 合作伙伴联系人邮箱：prm获取预填，不可修改
	PartnerContactTel   string `json:"PartnerContactTel"`   // 合作伙伴联系人电话：prm获取预填，不可修改
	TermContactName     string `json:"TermContactName"`     // 终端客户联系人：伙伴填写
	TermName            string `json:"TermName"`            // 终端客户名称：伙伴填写
	TermContactEmail    string `json:"TermContactEmail"`    // 终端客户联系人邮箱：伙伴填写
	TermContactTel      string `json:"TermContactTel"`      // 终端客户联系人电话：伙伴填写
	DeliverType         string `json:"DeliverType"`         // 交付方式：选择，枚举值prm维护（门到门、门到站、自提）
	DeliverPlace        string `json:"DeliverPlace"`        // 交付地点：选择，【省】-【市】

	PayType                string `json:"PayType"`                // 支付/收款类型// 对方支付/收款类型：？
	ClctName               string `json:"ClctName"`               // 账户名称// 对方账号名称：？
	AccountNumber          string `json:"AccountNumber"`          // 银行账号// 对方银行账号：？
	BranchName             string `json:"BranchName"`             // 开户行名称// 对方开户行名称：？
	BranchCode             string `json:"BranchCode"`             // 开户行Code
	MSAContractValidTime   int64  `json:"MSAContractValidTime"`   // 主协议合同生效起始时间
	MSAContractInvalidTime int64  `json:"MSAContractInvalidTime"` // 主协议合同生效失效时间
	AppendixValidTime      int64  `json:"AppendixValidTime"`      // 附录协议合同生效起始时间
	AppendixInvalidTime    int64  `json:"AppendixInvalidTime"`    // 附录协议合同生效失效时间
	MSAContractNo          string `json:"MSAContractNo"`          // 主协议编号
	AppendixNo             string `json:"AppendixNo"`             // 附录编号
}

type QuoteCreateContractReq struct {
	Scene         int       // 场景
	Identifier    string    // 业务系统唯一标识
	AccountID     int       // 客户ID
	Creator       string    // 创建人 一般是内部人员 使用邮箱
	ValidityBegin time.Time // 有效期开始时间戳 单位秒
	ValidityEnd   time.Time // 有效期结束时间戳 单位秒
	QuoteStatus   string    // 报价单状态
	BizInfo       *QuoteBizInfo
}

// GenAllProductInfoList 生成所有商品行信息（包含报价项和抵扣项）
func (q *QuoteBizInfo) GenAllProductInfoList() []*ProductInfo {
	if q == nil {
		return nil
	}
	res := q.QuoteItems.GenProductInfoList(q.TradeTypeCode, q.DistributionBizTypeCode)
	if len(q.DeductQuoteItems) > 0 {
		res = append(res, q.DeductQuoteItems.GenProductInfoList(q.TradeTypeCode, q.DistributionBizTypeCode)...)
	}
	return res
}

// GenAllQuoteItems 生成所有报价项（包含报价项和抵扣项）
func (q *QuoteBizInfo) GenAllQuoteItems() []*QuoteItem {
	if q == nil {
		return nil
	}
	res := make([]*QuoteItem, 0, len(q.QuoteItems)+len(q.DeductQuoteItems))
	res = append(res, q.QuoteItems...)
	res = append(res, q.DeductQuoteItems...)
	return res
}

// GenAllProductInfoMap 生成所有商品行信息（包含报价项和抵扣项）
func (q *QuoteBizInfo) GenAllProductInfoMap() map[string][]*ProductInfo {
	if q == nil {
		return nil
	}
	resMap := q.QuoteItems.GenProductInfoMap(q.TradeTypeCode, q.DistributionBizTypeCode)
	deductResMap := q.DeductQuoteItems.GenProductInfoMap(q.TradeTypeCode, q.DistributionBizTypeCode)
	for k, v := range deductResMap {
		resMap[k] = append(resMap[k], v...)
	}
	return resMap
}

// QuoteBizInfo 报价业务信息
type QuoteBizInfo struct {
	AccountID                      string                         `json:"AccountId"`               // 关联账号ID
	PartnerName                    string                         `json:"PartnerName"`             // 关联伙伴名称
	ContractEntity                 string                         `json:"ContractEntity"`          // 签约主体
	ContractAccount                string                         `json:"ContractAccount"`         // 签约火山账号ID
	ContractPriceEntity            string                         `json:"ContractPriceEntity"`     // 配价主体
	CustomerDetail                 string                         `json:"CustomerDetail"`          // 配价火山账号ID
	ProductSolutionEmail           string                         `json:"ProductSolutionEmail"`    // 产品解决方案邮箱
	RelatedResDepartment           string                         `json:"RelatedResDepartment"`    // 涉及资源方
	CustomerName                   string                         `json:"CustomerName"`            // 最终客户名称
	CustomerAccount                string                         `json:"CustomerAccount"`         // 最终客户火山账号ID
	MainQuoteID                    int64                          `json:"MainQuoteID"`             // 主报价单
	ParentQuoteID                  int64                          `json:"ParentQuoteID"`           // 父级报价单
	QuoteNo                        string                         `json:"QuoteNo"`                 // 报价单号，一般不使用；当前主要使用报价单ID作为identifier
	QuoteScene                     int                            `json:"QuoteScene"`              // 报价单场景值，与【补充协议场景】一致。
	SupplyScene                    string                         `json:"SupplyScene"`             // 【补充场景】一致。
	TradeTypeCode                  int                            `json:"TradeTypeCode"`           // 业务类型
	DistributionBizTypeCode        int                            `json:"DistributionBizTypeCode"` // 分销业务类型编码
	DistributorInfos               string                         `json:"DistributorInfos"`        // 多级分销关联信息
	QuoteType                      int                            `json:"QuoteType"`               // 报价类型：0-普通报价，1-项目制报价，2-阶梯报价
	ProjectAttributes              string                         `json:"ProjectAttributes"`       // 项目属性：0-普通项目，1-项目制
	QuoteStatus                    string                         `json:"QuoteStatus"`             // 报价单状态
	ProgressiveInfo                string                         `json:"ProgressiveInfo"`         // 阶梯报价必填
	CouponConfigID                 uint64                         `json:"CouponConfigID"`          // 返券配置ID
	CouponConfigIDList             []uint64                       `json:"CouponConfigIDList"`      // 返券配置ID列表
	CreditConfigID                 uint64                         `json:"CreditConfigID"`          // 信控配置
	CreditConfigIDList             []int64                        `json:"CreditConfigIDList"`      // 信控配置ID列表
	PriceValidPeriod               string                         `json:"PriceValidPeriod"`
	ProjectBased                   uint64                         `json:"ProjectBased"` // 是否项目制：0-非项目制，1-项目制
	LongLifeReason                 string                         `json:"LongLifeReason"`
	TotalSales                     string                         `json:"TotalSales"`
	CreditRiskInfo                 []*CreditRiskInfo              `json:"CreditRiskInfo"`
	QuoteItems                     QuoteItemList                  // `json:"QuoteItems"`
	DeliveryItems                  DeliveryItemList               // json:"DeliveryItemList"`
	DeductQuoteItems               QuoteItemList                  `json:"DeductQuoteItems"`    // 抵扣报价项（节省计划-计费项抵扣折扣）
	DeductDeliveryItems            DeliveryItemList               `json:"DeductDeliveryItems"` // 抵扣交付项
	GuaranteeItem                  *GuaranteeResp                 `json:"GuaranteeItem"`
	GuaranteeItems                 *ContractGuaranteeRuleTreeResp `json:"GuaranteeItems"`    // 保底规则树
	BusinessDiscounts              string                         `json:"BusinessDiscounts"` // 商务优惠: 保底、信控、赠送、返佣、代金券
	GiveAwayScene                  string                         `json:"GiveAwayScene"`     // 赠送场景: 无条件赠送
	GiveAwayReason                 string                         `json:"GiveAwayReason"`    // 赠送原因
	SupplyDiffInfo                 map[string]interface{}         `json:"SupplyDiffInfo"`
	ProjectCode                    string                         `json:"ProjectCode"`                    // 项目编号
	ProjectApprovalLink            string                         `json:"ProjectApprovalLink"`            // 项目制立项流程
	QuoteApprovalLink              string                         `json:"QuoteApprovalLink"`              // 项目制报价流程
	ConfigListApprovalSerialNumber string                         `json:"ConfigListApprovalSerialNumber"` // 项目范围确认编号
	ConfigListApprovalLink         string                         `json:"ConfigListApprovalLink"`         // 项目范围确认流程
}

func (q *QuoteCreateContractReq) IsPass() bool {
	if q.BizInfo == nil {
		return q.QuoteStatus == _const.StatusPass
	}
	// 兼容历史数据 任一字段=pass即为通过
	return q.QuoteStatus == _const.StatusPass || q.BizInfo.QuoteStatus == _const.StatusPass
}

func (q *QuoteBizInfo) GetProductSolutionEmailPtr() *string {
	if q.ProductSolutionEmail == "" {
		return nil
	}
	return &q.ProductSolutionEmail
}

func (q *QuoteBizInfo) GetRelatedResDepartmentPtr() *string {
	if q.RelatedResDepartment == "" {
		return nil
	}
	return &q.RelatedResDepartment
}

func (q *QuoteBizInfo) ParseRelateAccountInfo(ctx context.Context) (map[string]map[string][]string, error) {
	res := map[string]map[string][]string{}
	if q == nil {
		return res, nil
	}
	var distributor DistributorInfos
	if err := json.Unmarshal([]byte(q.DistributorInfos), &distributor); err != nil {
		logs.CtxError(ctx, "ParseRelateAccountInfo_distributorUnmarshalFail, distributor:%s", q.DistributorInfos)
		return res, err
	}
	// 若以及分销商名称返回为空，则直接返回
	if firstDistributor := distributor.GetFirstDistributor(); len(firstDistributor) == 0 {
		return res, nil
	}
	return distributor.GetRelateAccountInfo(), nil
}

type GenCustomerDiscountListReq struct {
	BusinessType          int
	DistributBusinessType int
	AccountID             string
	Discount              string
	DistributionDiscounts string
}

func (c *QuoteBizInfo) IsBpDistribut() bool {
	return c.DistributionBizTypeCode == _const.DistributBusinessTypeSpecial && c.TradeTypeCode == _const.BusinessTypeBPDistribution
}

func GenCustomerDiscountList(ctx context.Context, req *GenCustomerDiscountListReq) ([]*CustomerDiscount, error) {
	var res []*CustomerDiscount
	if req.DistributBusinessType == _const.DistributBusinessTypeSpecial && req.BusinessType == _const.BusinessTypeBPDistribution {
		discount := &DistributionDiscounts{}
		if err := json.Unmarshal([]byte(req.DistributionDiscounts), discount); err != nil {
			logs.CtxError(ctx, "getDiscount_DistributionDiscountsUnmarshalFail, discountInfo:%s", req.DistributionDiscounts)
			return res, err
		}
		if discount.FirstDiscount != nil {
			res = append(res, discount.FirstDiscount)
		}
		if discount.SecondDiscount != nil {
			res = append(res, discount.SecondDiscount)
		}
		if discount.FinalDiscount != nil {
			res = append(res, discount.FinalDiscount)
		}
	} else {
		discount := &Discount{}
		if err := json.Unmarshal([]byte(req.Discount), discount); err != nil {
			logs.CtxError(ctx, "getDiscount_DiscountUnmarshalFail, discountInfo:%s", req.Discount)
			return res, err
		}
		res = append(res, &CustomerDiscount{
			CustomerInfo: CustomerInfo{
				AccountID: req.AccountID,
			},
			Discount: discount})
	}
	return res, nil
}

type CreditRiskInfo struct {
	Cid          string `json:"Cid"`
	CustomerName string `json:"CustomerName"`
	IsPassed     bool   `json:"IsPassed"`
	Reason       string `json:"Reason"`
	RetryTimes   int    `json:"RetryTimes"`
	RiskStatus   string `json:"RiskStatus"`
	UID          int    `json:"Uid"`
	Version      int64  `json:"Version"`
}

type ProgressiveInfo struct {
	ProgressiveType string // 累计维度 按月累计-monthly、按合同周期累计-byContract
	MeasureInterval string // 阶梯信息
	AccumulateType  string // 累计类型
}

// GuaranteeResp 保底信息
type GuaranteeResp struct {
	GuaranteeItemID          int64                  `json:"GuaranteeItemID"`
	QuoteID                  int64                  `json:"QuoteID"`
	GuaranteeType            int                    `json:"GuaranteeType"`
	GuaranteeAmount          decimal.Decimal        `json:"GuaranteeAmount"`
	GuaranteeRule            string                 `json:"GuaranteeRule"`
	RelatedQuoteItemId       []int64                `json:"RelatedQuoteItemId"`
	AccountID                string                 `json:"AccountID"`
	AccumulateType           string                 `json:"AccumulateType"`
	TotalSeats               *int64                 `json:"TotalSeats,omitempty"`     // 总座位数
	GuaranteeProductSeats    []GuaranteeProductSeat `json:"GuaranteeProductSeats"`    // 商品维度订购数量
	GuaranteeCategory        int                    `json:"GuaranteeCategory"`        // 保底类型 0-按有效期保底 1-按周期保底
	GuaranteeInterval        int                    `json:"GuaranteeInterval"`        // 保底周期 每{X}个自然月
	GuaranteeStartTime       string                 `json:"GuaranteeStartTime"`       // 保底开始时间
	GuaranteeEndTime         string                 `json:"GuaranteeEndTime"`         // 保底结束时间
	CarryForward             int                    `json:"CarryForward"`             // 是否结转 0-不存在，不涉及；1-结转；2-不结转
	SameRuleCarryForward     int                    `json:"SameRuleCarryForward"`     // 是否同规则结转 0-不结转；1-结转
	CrossGroupCarryForwardID int64                  `json:"CrossGroupCarryForwardID"` // 跨组结转目标根保底规则ID
	GuaranteeAmountMode      int                    `json:"GuaranteeAmountMode"`      // 金额保底方式 0-等额；1-非等额
	GuaranteeAmountLadder    []string               `json:"GuaranteeAmountLadder"`    // 非等额保底金额列表
	GuaranteeTotalAmount     *string                `json:"GuaranteeTotalAmount"`     // 保底总金额
	RootGuaranteeID          int64                  `json:"RootGuaranteeID"`          // 根保底ID
	ParentGuaranteeID        int64                  `json:"ParentGuaranteeID"`        // 父保底ID
	CopyFrom                 int64                  `json:"CopyFrom"`
	ChangeFrom               int64                  `json:"ChangeFrom"`
}

type ContractGuaranteeRuleTreeResp struct {
	QuoteID int64
	Groups  []*ContractGuaranteeRuleGroupResp
}

type ContractGuaranteeRuleGroupResp struct {
	RootGuaranteeID int64
	Root            *ContractGuaranteeRuleNodeResp
}

type ContractGuaranteeRuleNodeResp struct {
	Item     *GuaranteeResp
	Children []*ContractGuaranteeRuleNodeResp
}

// ContainsGuarantee 判断报价业务信息中是否包含保底信息，兼容多保底与单保底结构。
func (q *QuoteBizInfo) ContainsGuarantee() bool {
	if q == nil {
		return false
	}
	if q.GuaranteeItems != nil {
		return true
	}
	return q.GuaranteeItem != nil
}

// HasValidGuarantee 判断报价业务信息中是否存在有效保底信息，兼容多保底与单保底结构。
func (q *QuoteBizInfo) HasValidGuarantee() bool {
	return len(q.ValidGuarantees()) > 0
}

// ValidGuarantees 获取报价业务信息中的有效保底列表，优先读取多保底结构并兼容单保底结构。
func (q *QuoteBizInfo) ValidGuarantees() []*GuaranteeResp {
	if q == nil {
		return nil
	}
	if q.GuaranteeItems != nil {
		return q.GuaranteeItems.ValidGuarantees()
	}
	if q.GuaranteeItem.HasValidGuarantee() {
		return []*GuaranteeResp{q.GuaranteeItem}
	}
	return nil
}

// ValidGuaranteeMap 构造报价业务信息中有效保底项ID到具体保底项的映射，优先读取多保底结构并兼容单保底结构。
func (q *QuoteBizInfo) ValidGuaranteeMap() map[int64]*GuaranteeResp {
	res := map[int64]*GuaranteeResp{}
	for _, guarantee := range q.ValidGuarantees() {
		res[guarantee.GuaranteeItemID] = guarantee
	}
	return res
}

// HasValidGuarantee 判断单个保底信息是否有效，排除“其他”类型的保底。
func (g *GuaranteeResp) HasValidGuarantee() bool {
	return g != nil && g.GuaranteeType != _const.GuaranteeTypeOther
}

// ValidGuarantees 遍历保底规则树的所有分组，汇总其中的有效保底信息。
func (g *ContractGuaranteeRuleTreeResp) ValidGuarantees() []*GuaranteeResp {
	if g == nil {
		return nil
	}
	var res []*GuaranteeResp
	for _, group := range g.Groups {
		if group == nil {
			continue
		}
		res = append(res, group.Root.ValidGuarantees()...)
	}
	return res
}

// HasValidGuarantee 判断保底规则树中是否存在有效保底信息。
func (g *ContractGuaranteeRuleTreeResp) HasValidGuarantee() bool {
	return len(g.ValidGuarantees()) > 0
}

// ValidGuarantees 递归遍历保底规则节点及其子节点，汇总有效保底信息。
func (n *ContractGuaranteeRuleNodeResp) ValidGuarantees() []*GuaranteeResp {
	if n == nil {
		return nil
	}
	var res []*GuaranteeResp
	if n.Item.HasValidGuarantee() {
		res = append(res, n.Item)
	}
	for _, child := range n.Children {
		res = append(res, child.ValidGuarantees()...)
	}
	return res
}

// GuaranteeProductSeat 商品维度保底订购数量
type GuaranteeProductSeat struct {
	TradeProduct string `json:"TradeProduct"`
	Seats        int64  `json:"Seats"`
}

func (g *GuaranteeResp) IsSame(v *GuaranteeResp) bool {

	if v == nil {
		return false
	}

	commonSame := g.GuaranteeItemID == v.GuaranteeItemID &&
		g.QuoteID == v.QuoteID &&
		g.GuaranteeType == v.GuaranteeType &&
		g.GuaranteeRule == v.GuaranteeRule &&
		g.AccountID == v.AccountID &&
		g.AccumulateType == v.AccumulateType &&
		g.CarryForward == v.CarryForward &&
		g.SameRuleCarryForward == v.SameRuleCarryForward &&
		g.CrossGroupCarryForwardID == v.CrossGroupCarryForwardID &&
		g.GuaranteeAmountMode == v.GuaranteeAmountMode &&
		isSameStringSlice(g.GuaranteeAmountLadder, v.GuaranteeAmountLadder) &&
		g.GuaranteeAmount.Equal(v.GuaranteeAmount) &&
		volcengine.Int64Value(g.TotalSeats) == volcengine.Int64Value(v.TotalSeats) &&
		isSameGuaranteeProductSeats(g.GuaranteeProductSeats, v.GuaranteeProductSeats)

	return commonSame
}

func isSameStringSlice(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func isSameGuaranteeProductSeats(a, b []GuaranteeProductSeat) bool {
	if len(a) != len(b) {
		return false
	}

	normalize := func(list []GuaranteeProductSeat) []GuaranteeProductSeat {
		res := make([]GuaranteeProductSeat, len(list))
		copy(res, list)
		sort.Slice(res, func(i, j int) bool {
			if res[i].TradeProduct != res[j].TradeProduct {
				return res[i].TradeProduct < res[j].TradeProduct
			}
			return res[i].Seats < res[j].Seats
		})
		return res
	}

	aList := normalize(a)
	bList := normalize(b)
	for i := range aList {
		if aList[i] != bList[i] {
			return false
		}
	}
	return true
}

// OrderedQuoteItem 用于在模板替换时维护商品的层级和序号
type OrderedQuoteItem struct {
	Item      *QuoteItem
	SerialNum string
}

// QuoteItem 报价条目
type QuoteItem struct {
	Config                   string `json:"config"`
	ConfigCode               string `json:"configCode"`
	ConfigCodeExclude        string `json:"configCodeExclude"`        // 配置编码排除项，多个逗号分割
	ConfigNameExclude        string `json:"configNameExclude"`        // 配置名称排除项，多个逗号分割
	ChargeItemCode           string `json:"chargeItemCode"`           // 计费项编码
	ChargeItemTag            string `json:"chargeItemTag"`            // 计费项标签
	ChargeItemTagCodeExclude string `json:"chargeItemTagCodeExclude"` // 计费项分类编码排除项，多个逗号分割
	ChargeItemTagNameExclude string `json:"chargeItemTagNameExclude"` // 计费项分类名称排除项，多个逗号分割
	PricingVersion           string `json:"PricingVersion"`
	PriceType                string `json:"priceType"`             // 价格类型
	ActivationType           string `json:"ActivationType"`        // 开通类型
	Discount                 string `json:"discount"`              // 折扣/价格
	DistributionDiscounts    string `json:"DistributionDiscounts"` // 分销折扣
	OffPeakHoursBilling      string `json:"offPeakHoursBilling"`   // 闲时折扣信息
	ChildProductName         string `json:"ChildProductName"`      // 产品名称
	ChildProductCode         string `json:"ChildProductCode"`      //
	Quantity                 string `json:"quantity"`
	StandardProductCode      string `json:"standardProductCode"` // 单产品编码
	Product                  string `json:"Product"`
	ProductName              string `json:"ProductName"`

	ConfigCategory            string `json:"configCategory"`     // 配置分类
	ConfigCategoryCode        string `json:"configCategoryCode"` // 配置分类
	ConfigCategoryCodeExist   string `json:"configCategoryCodeExist"`
	ConfigCategoryCodeExclude string `json:"configCategoryCodeExclude"` // 配置分类编码排除项，多个逗号分割
	ConfigCategoryNameExclude string `json:"configCategoryNameExclude"` // 配置分类名称排除项，多个逗号分割
	ChargeMethod              string `json:"chargeMethod"`              // 计费方式名称
	ChargeMethodCode          string `json:"chargeMethodCode"`          // 计费方式编码
	Region                    string `json:"region"`                    // 地域编码
	RegionCode                string `json:"regionCode"`                // 地域编码
	RegionCodeExclude         string `json:"regionCodeExclude"`         // 地域编码排除项，多个逗号分割
	RegionNameExclude         string `json:"regionNameExclude"`         // 地域名称排除项，多个逗号分割
	ChargeUnit                string `json:"chargeUnit"`                // 计费单元
	ChargeUnitCode            string `json:"chargeUnitCode"`            // 计费单元编号
	ChargeUnitCodeExclude     string `json:"chargeUnitCodeExclude"`     // 计费单元编号排除项，多个逗号分割
	ChargeUnitNameExclude     string `json:"chargeUnitNameExclude"`     // 计费单元名称排除项，多个逗号分割
	PriceFactor               string `json:"priceFactor"`               // 价格影响因子
	PriceFactorCode           string `json:"priceFactorCode"`           // 价格影响因子KeyValue
	CanPrePay                 string `json:"canPrePay"`                 // 计费方式
	CanPrePayCode             string `json:"canPrePayCode"`             // 计费方式编码
	GuaranteedPercentage      string `json:"guaranteedPercentage"`      // 保底比例
	SellingMode               string `json:"sellingMode"`               // 售卖模式
	StandardProduct           string `json:"StandardProduct"`           // 标准商品：1-标品，2-非标品
	ItemType                  string `json:"ItemType"`                  // 0-线上标品，1-线下标品
	QuoteSolutionID           string `json:"QuoteSolutionID"`           // 解决方案ID
	StandardSolutionCode      string `json:"StandardSolutionCode"`      // 产品解决方案code
	StandardSolutionName      string `json:"StandardSolutionName"`      // 产品解决方案名
	StandardDepartmentName    string `json:"StandardDepartmentName"`    // 产品解决方案所属部门
	StandardSolutionVersion   string `json:"StandardSolutionVersion"`   // 产品解决方案版本
	TradeSolutionCode         string `json:"TradeSolutionCode"`         // 商品解决方案code
	TradeSolution             string `json:"TradeSolution"`             // 商品解决方案英文名
	TradeSolutionName         string `json:"TradeSolutionName"`         // 商品解决方案中文名
	TradeSolutionVersion      string `json:"TradeSolutionVersion"`      // 商品解决方案版本
	BuyNum                    string `json:"buyNum"`                    // 购买数量 "buyNum":"{\"Num\":10,\"Unit\":\"YEAR\"}"
	BuyDuration               string `json:"buyDuration"`               // 购买时长 "buyDuration":"{\"Num\":10,\"Unit\":\"个\"}"
	GiveMaintenance           string `json:"giveMaintenance"`           // "giveMaintenance":"{\"MaintenanceService\":\"赠送维保\",\"MaintenanceNum\":\"3\",\"MaintenanceUnit\":\"年\"}"
	OriginalPrice             string `json:"OriginalPrice"`             // 刊例价售卖金额
	IncomeNoTax               string `json:"IncomeNoTax"`               // 折后金额
	PriceInfoSnapshot         string `json:"PriceInfoSnapshot"`         // 刊例价单价
	DeploymentType            int    // 部署类型 1:公有云，2:私有云
	QuoteItemID               string `json:"QuoteItemID"`           // 报价系统数据库中的自增id
	TradeProductType          string `json:"TradeProductType"`      // :"服务",//产品类型
	RealDiscount              string `json:"RealDiscount"`          // :"0.45",//实际折扣
	UnitPrice                 string `json:"UnitPrice"`             // : "2.88",//刊例价单价
	SingleCost                string `json:"SingleCost"`            // : "1.234",//单位目标成本
	TotalCost                 string `json:"TotalCost"`             // : "2.468",//总目标成本
	ProfitRate                string `json:"ProfitRate"`            // : "0.2",//利润率
	OutputTax                 string `json:"OutputTax"`             // : "1.22",//消项税
	ExceededDiscount          string `json:"ExceededDiscount"`      // : "0.5",//超额折扣
	ExceededDiscountPrice     string `json:"ExceededDiscountPrice"` // : "2.333",//超额折扣价格
	AutoGenerate              string `json:"AutoGenerate"`          // : "true"//系统自动生成
	ShowName                  string `json:"showName"`              // 对客名称
	RelatedItemID             string `json:"RelatedItemID"`         // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	ItemBusinessRole          string `json:"ItemBusinessRole"`      // 报价项业务角色：0-标准报价项，1-抵扣报价项
	SalesMode                 string `json:"SalesMode"`             // SavingsPlans-节省计划 Others-其他类型商品
	ConfigIsPublic            string `json:"ConfigIsPublic"`        // 是否公开售卖 0-非公开售卖,1-公开售卖
	ConfigPublicDisplay       string `json:"ConfigPublicDisplay"`   // 1-非公开售卖配置报价可见 2-非公开售卖配置报价不可
	PrePayRatio               string `json:"prePayRatio"`           // 预付比例
	PrePayRatioCode           string `json:"prePayRatioCode"`       // 预付比例编码
	SpBuyDuration             string `json:"spBuyDuration"`         // 节省计划购买时长
	SpBuyDurationCode         string `json:"spBuyDurationCode"`     // 节省计划购买时长编码
	CommitFeeInterval         string `json:"commitFeeInterval"`     // 承诺消费金额
	CommitFeeIntervalCode     string `json:"commitFeeIntervalCode"` // 承诺消费金额编码
	DepartmentName            string `json:"DepartmentName"`
	ItemBelong                string `json:"ItemBelong"`
	ReleaseVersion            string `json:"ReleaseVersion"`
	StandardProductName       string `json:"StandardProductName"`
	InvoiceProjectCode        string `json:"InvoiceItem"`    // 开票项
	InvoiceProject            string `json:"InvoiceProject"` //开票项&税率
	IncomeCode                string `json:"IncomeCode"`     //收入性质
	TaxRate                   string `json:"TaxRate"`        //税率 0.06

	GiveAwayType string `json:"GiveAwayType"` // 赠送类型：赠送、区间赠送
}
type QuoteItemList []*QuoteItem
type DeliveryItemList []*QuoteItem

func (q QuoteItemList) GenAccountAssociationMap() map[string]string {
	accountAssociationMap := map[string]string{}
	for _, item := range q {
		if item.IsBlockedItem(context.Background()) {
			continue
		}
		accountAssociationMap[item.GetQuoteGroupType()] = ""
	}
	return accountAssociationMap
}

// 标记为“非标品”且“解决方案”无值，放在“非标品”展示；
// 标记为“公有云”且标记为“标品”且“解决方案”无值，放在“公有云（标品）”展示；
// 标记为“私有云”且标记为“标品”且“解决方案”无值，放在“私有云（标品）”展示；
// “解决方案”不为空，放在“解决方案”展示；
func (q *QuoteItem) GetQuoteGroupType() string {
	standardProduct := q.StandardProduct
	if len(q.StandardProduct) == 0 {
		// 兼容历史数据 是否标品为空时默认为标品
		standardProduct = _const.STANDARD_PRODUCT_ENUM
	}
	if len(q.QuoteSolutionID) > 0 && q.QuoteSolutionID != "0" {
		return _const.COMMODITY_GROUP_KEY_QUOTE_SOLUTION
	} else if standardProduct == _const.NON_STANDARD_PRODUCT_ENUM {
		return _const.COMMODITY_GROUP_KEY_NON_STANDARD_PRODUCT
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && q.ItemType == _const.ONLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PUBLIC_CLOUD
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && q.ItemType == _const.OFFLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD
	} else {
		return _const.COMMODITY_GROUP_KEY_DEFAULT
	}
}

func (q *QuoteItem) IsBlockedItem(ctx context.Context) bool {
	configs := conf.GetQuoteBlockedItemConfig(ctx)
	for _, config := range configs {
		if q.AutoGenerate != _const.TRUE_FLAG_INT_STR {
			continue
		}
		if config.Product != "-" && q.Product != config.Product {
			continue
		}
		if config.ChargeItemCode != "-" && q.ChargeItemCode != config.ChargeItemCode {
			continue
		}
		return true
	}
	return false
}

func (q *QuoteItem) GenProductInfo(businessType, distributBusinessType int) *ProductInfo {

	var (
		payType         string
		pricingFunction string
	)
	payTypeIn, ok := _const.CanPrePayMapping[q.CanPrePayCode]
	if ok {
		payType = payTypeIn
	}
	configCategory := q.ConfigCategoryCode

	productName := q.ChildProductName
	if len(q.ProductName) > 0 {
		productName = q.ProductName
	}

	// 默认为标品，报价单中指定了取报价单数据
	standardProduct := _const.STANDARD_PRODUCT_ENUM
	if len(q.StandardProduct) > 0 {
		standardProduct = q.StandardProduct
	}

	if businessType == _const.BusinessTypeBPDistribution && distributBusinessType == _const.DistributBusinessTypeSpecial {
		discount := DistributionDiscounts{}
		_ = json.Unmarshal([]byte(q.DistributionDiscounts), &discount)
		if discount.FirstDiscount != nil && discount.FirstDiscount.Discount != nil {
			pricingFunction = discount.FirstDiscount.Discount.PricingFunction
		}
	} else {
		discount := Discount{}
		_ = json.Unmarshal([]byte(q.Discount), &discount)
		pricingFunction = discount.PricingFunction
	}

	buyNum := BuyModule{}
	_ = json.Unmarshal([]byte(q.BuyNum), &buyNum)

	buyDuration := BuyModule{}
	_ = json.Unmarshal([]byte(q.BuyDuration), &buyDuration)

	giveMaintenance := GiveMaintenance{}
	_ = json.Unmarshal([]byte(q.GiveMaintenance), &giveMaintenance)

	quantityUnit, err := q.GetQuantityUnit()
	if err != nil {
		logs.CtxError(context.Background(), "GetQuantityUnitFail, QuoteItemID:%s, err:%v", q.QuoteItemID, err)
	}

	exclude := &ExcludeDetail{
		ConfigurationCategory:     q.ConfigCategoryNameExclude,
		ConfigurationCategoryCode: q.ConfigCategoryCodeExclude,
		Configuration:             q.ConfigNameExclude,
		ConfigurationCode:         q.ConfigCodeExclude,
		Region:                    q.RegionNameExclude,
		RegionCode:                q.RegionCodeExclude,
		ChargeElement:             q.ChargeUnitNameExclude,
		ChargeElementCode:         q.ChargeUnitCodeExclude,
		ChargeItemTag:             q.ChargeItemTagNameExclude,
		ChargeItemTagCode:         q.ChargeItemTagCodeExclude,
	}

	productIncome, _ := decimal.NewFromString(q.IncomeNoTax)

	excludeBody, _ := json.Marshal(exclude)

	itemType, _ := strconv.Atoi(q.ItemType)
	_, taxRatio := util.ParseInvoiceProject(q.InvoiceProject)

	return &ProductInfo{
		TradeProductName:      productName,
		TradeProduct:          q.Product,
		TradeProductCode:      "", // 当前报价单中不存在该字段 后续流程补全
		InvoiceProjectCode:    q.InvoiceProjectCode,
		InvoiceProject:        q.InvoiceProject,
		IncomeCode:            q.IncomeCode,
		TaxRatio:              taxRatio,
		ChildProductCode:      q.ChildProductCode,
		StandardProductCode:   q.StandardProductCode,
		Configuration:         q.ConfigCode,
		ConfigurationName:     q.Config,
		ConfigCategory:        configCategory,
		BillingMethodCode:     q.ChargeMethodCode,
		BillingName:           q.ChargeMethod,
		Region:                q.Region,
		RegionCode:            q.RegionCode,
		ChargeElement:         q.ChargeUnit,
		ChargeElementCode:     q.ChargeUnitCode,
		PriceFactor:           q.PriceFactor,
		PriceFactorCode:       q.PriceFactorCode,
		ChargeItemCode:        q.ChargeItemCode,
		ChargeItemTag:         q.ChargeItemTag,
		PriceType:             pricingFunction,
		Discount:              q.Discount,
		DistributionDiscounts: q.DistributionDiscounts,
		OffPeakHoursBilling:   q.OffPeakHoursBilling,
		PricingVersion:        q.PricingVersion,
		CanPrePay:             q.CanPrePay,
		CanPrePayCode:         q.CanPrePayCode,
		GuaranteedPercentage:  q.GuaranteedPercentage,
		PayType:               payType,
		SellingMode:           q.SellingMode,
		StandardProduct:       standardProduct,
		ItemType:              q.ItemType,
		ActivationType:        q.ActivationType,
		QuoteSolutionID:       q.QuoteSolutionID,
		TradeSolutionCode:     q.TradeSolutionCode,
		TradeSolution:         q.TradeSolution,
		TradeSolutionName:     q.TradeSolutionName,
		TradeSolutionVersion:  q.TradeSolutionVersion,
		DeploymentType:        itemType,
		BuyNum:                buyNum.GetNumStr(),
		BuyNumUnit:            buyNum.Unit,
		BuyDuration:           buyDuration.GetNumStr(),
		BuyDurationUnit:       buyDuration.Unit,
		MaintenanceService:    giveMaintenance.MaintenanceService,
		MaintenanceNum:        giveMaintenance.GetNumStr(),
		MaintenanceUnit:       giveMaintenance.MaintenanceUnit,
		OriginalPrice:         q.OriginalPrice,
		IncomeNoTax:           q.IncomeNoTax,
		Income:                productIncome,
		PriceInfoSnapshot:     q.PriceInfoSnapshot,
		Quantity:              q.Quantity,
		QuantityUnit:          quantityUnit,
		QuoteItemID:           q.QuoteItemID,
		RelatedItemID:         q.RelatedItemID,
		ItemBusinessRole:      q.ItemBusinessRole,
		ShowName:              q.ShowName,
		Exclude:               string(excludeBody),
		GiveAwayType:          q.GiveAwayType,
		PrePayRatio:           q.PrePayRatio,
		PrePayRatioCode:       q.PrePayRatioCode,
		SpBuyDuration:         q.SpBuyDuration,
		SpBuyDurationCode:     q.SpBuyDurationCode,
		CommitFeeInterval:     q.CommitFeeInterval,
		CommitFeeIntervalCode: q.CommitFeeIntervalCode,
		SalesMode:             q.SalesMode,
		ConfigIsPublic:        q.ConfigIsPublic,
		ConfigPublicDisplay:   q.ConfigPublicDisplay,
	}
}

func (q *QuoteItem) GetQuantityUnit() (string, error) {
	if q == nil || len(q.PriceInfoSnapshot) == 0 {
		return "", nil
	}
	priceInfo := PriceInfoSnapshot{}
	if err := json.Unmarshal([]byte(q.PriceInfoSnapshot), &priceInfo); err != nil {
		logs.CtxError(context.Background(), "GetQuantityUnit_jsonUnmarshalFail, QuoteItemID:%s, PriceInfoSnapshot:%s, err:%v", q.QuoteItemID, q.PriceInfoSnapshot, err)
		return "", fmt.Errorf("unmarshal price info snapshot: %w", err)
	}
	return priceInfo.Unit, nil
}

func (q QuoteItemList) GenProductInfoList(businessType, distributBusinessType int) []*ProductInfo {
	resList := []*ProductInfo{}
	for _, item := range q {
		if item.IsBlockedItem(context.Background()) {
			continue
		}
		resList = append(resList, item.GenProductInfo(businessType, distributBusinessType))
	}
	return resList
}

func (q QuoteItemList) GenProductInfoMap(businessType, distributBusinessType int) map[string][]*ProductInfo {
	resMap := map[string][]*ProductInfo{}
	for _, item := range q {
		if item.IsBlockedItem(context.Background()) {
			continue
		}
		groupKey := GetProductGroupType(item)
		resList, ok := resMap[groupKey]
		if !ok {
			resList = []*ProductInfo{}
		}
		resList = append(resList, item.GenProductInfo(businessType, distributBusinessType))
		resMap[groupKey] = resList
	}
	return resMap
}

// 标记为“非标品”且“解决方案”无值，放在“非标品”展示；
// 标记为“公有云”且标记为“标品”且“解决方案”无值，放在“公有云（标品）”展示；
// 标记为“私有云”且标记为“标品”且“解决方案”无值，放在“私有云（标品）”展示；
// “解决方案”不为空，放在“解决方案”展示；
func GetProductGroupType(item *QuoteItem) string {
	standardProduct := item.StandardProduct
	if len(item.StandardProduct) == 0 {
		// 兼容历史数据 是否标品为空时默认为标品
		standardProduct = _const.STANDARD_PRODUCT_ENUM
	}
	if len(item.QuoteSolutionID) > 0 && item.QuoteSolutionID != "0" {
		return _const.COMMODITY_GROUP_KEY_QUOTE_SOLUTION
	} else if standardProduct == _const.NON_STANDARD_PRODUCT_ENUM {
		return _const.COMMODITY_GROUP_KEY_NON_STANDARD_PRODUCT
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && item.ItemType == _const.ONLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PUBLIC_CLOUD
	} else if standardProduct == _const.STANDARD_PRODUCT_ENUM && item.ItemType == _const.OFFLINE_STANDARD {
		return _const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD
	} else {
		return _const.COMMODITY_GROUP_KEY_DEFAULT
	}
}

type OffPeakHoursBilling struct {
	Enabled       bool            `json:"Enabled"`       // 是否启用
	Periods       string          `json:"Period"`        // 闲时时段
	DiscountRatio decimal.Decimal `json:"DiscountRatio"` // 闲时计费折扣比例
}

type BuyModule struct {
	Num  int
	Unit string
}

func (b BuyModule) GetNumStr() string {
	if b.Num == 0 {
		return ""
	}
	return strconv.Itoa(b.Num)
}

type PriceInfoSnapshot struct {
	ChargeItemID           string          `json:"ChargeItemID"`
	PricingFunction        string          `json:"PricingFunction"`
	Currency               string          `json:"Currency"`
	Price                  decimal.Decimal `json:"Price"`
	MarketPrice            string          `json:"MarketPrice"`
	SegMarketPrice         string          `json:"SegMarketPrice"`
	MeasureInterval        string          `json:"MeasureInterval"`
	Unit                   string          `json:"Unit"`
	IsResourcePack         bool            `json:"IsResourcePack"`
	PriceInterval          string          `json:"PriceInterval"`
	IsCombining            bool            `json:"IsCombining"`
	CombiningPrice         float64         `json:"CombiningPrice"`
	StandardPrice          string          `json:"StandardPrice"`
	Quantity               string          `json:"Quantity"`
	UnitDisplay            string          `json:"UnitDisplay"`
	PricingGranularity     float64         `json:"PricingGranularity"`
	SellingMode            string          `json:"SellingMode"`
	BuyNumUnit             string          `json:"BuyNumUnit"`
	BuyDurationUnit        string          `json:"BuyDurationUnit"`
	IsMaintenanceService   float64         `json:"IsMaintenanceService"`
	GiveMaintenanceService float64         `json:"GiveMaintenanceService"`
	MaintenanceNum         float64         `json:"MaintenanceNum"`
	MaintenanceUnit        string          `json:"MaintenanceUnit"`
	RatioChargeItemNum     float64         `json:"RatioChargeItemNum"`
	RelatedChargeItemRatio decimal.Decimal `json:"RelatedChargeItemRatio"`
	RelatedChargeItems     interface{}     `json:"RelatedChargeItems"`
	DiscountLineList       interface{}     `json:"DiscountLineList"`
}

type GiveMaintenance struct {
	MaintenanceService string
	MaintenanceNum     int
	MaintenanceUnit    string
}

func (b GiveMaintenance) GetNumStr() string {
	if b.MaintenanceNum == 0 {
		return ""
	}
	return strconv.Itoa(b.MaintenanceNum)
}

type PeriodModule struct {
	PeriodNum  int
	PeriodUnit string
}

type ExcludeDetail struct {
	ConfigurationCategory     string `json:"ConfigurationCategory,omitempty"`     // 配置分类，多个逗号分隔
	ConfigurationCategoryCode string `json:"ConfigurationCategoryCode,omitempty"` // 配置分类Code，多个逗号分隔
	Configuration             string `json:"Configuration,omitempty"`             // 配置，多个逗号分隔
	ConfigurationCode         string `json:"ConfigurationCode,omitempty"`         // 配置Code，多个逗号分隔
	Region                    string `json:"Region,omitempty"`                    // 地域，多个逗号分隔
	RegionCode                string `json:"RegionCode,omitempty"`                // 地域Code，多个逗号分隔
	ChargeElement             string `json:"ChargeElement,omitempty"`             // 计费单元，多个逗号分隔
	ChargeElementCode         string `json:"ChargeElementCode,omitempty"`         // 计费单元编码，多个逗号分隔
	ChargeItemTag             string `json:"ChargeItemTag,omitempty"`             // 计费项分类，多个逗号分隔
	ChargeItemTagCode         string `json:"ChargeItemTagCode,omitempty"`         // 计费项编码，多个逗号分隔
}

type QuoteDiscount struct {
	Product           string `json:"Product"`
	ProductName       string `json:"ProductName"`
	ProductCode       string `json:"ProductCode"`
	Configuration     string `json:"Configuration"`
	ConfigurationName string `json:"ConfigurationName"` // 预付费-包天
	ChargeItemCode    string `json:"ChargeItemCode"`
	ChargeItemTag     string `json:"ChargeItemTag"` // 计费项分类
	PriceVersion      string `json:"PriceVersion"`
	Discount          string `json:"Discount"`
	BeginTime         string `json:"BeginTime"`
	EndTime           string `json:"EndTime"`
	// BillingFunction    string `json:"BillingFunction"`
	BizBillingFunction string `json:"BizBillingFunction"`
	UnitPrice          string `json:"UnitPrice"`
	UnitPriceInterval  string `json:"UnitPriceInterval"`
	MeasureInterval    string `json:"MeasureInterval"`
	BottomAmount       string `json:"BottomAmount"`

	ConfigurationCategory string `json:"ConfigurationCategory"` // 配置分类
	BillingMethodCode     string `json:"BillingMethodCode"`     // 计费方式编码
	BillingName           string `json:"BillingName"`           // 计费方式名称 非必传
	RegionCode            string `json:"RegionCode"`            // 地域编码
	Region                string `json:"Region"`                // 地域(中文)
	ChargeElement         string `json:"ChargeElement"`         // 计费单元编码(中文)
	ChargeElementCode     string `json:"ChargeElementCode"`     // 计费单元编码
	PriceFactor           string `json:"PriceFactor"`           // 价格影响因子
	PriceFactorName       string `json:"PriceFactorName"`
	PayType               string `json:"PayType"`
	CanPrePay             string `json:"CanPrePay"`
	GuaranteedPercentage  string `json:"GuaranteedPercentage"` // 保底比例
	SellingMode           string `json:"SellingMode"`          // 售卖模式 1-抢占式实例

	// 线下标品&解决方案 新增字段
	DeploymentType    int              `json:"DeploymentType"`   // 部署类型 1:公有云，2:私有云
	ProductCatalogue  string           `json:"ProductCatalogue"` // “standard_product”：标品，“non_standard_product”：非标品。
	Solution          string           `json:"Solution"`         // 解决方案英文名
	SolutionVersion   string           `json:"SolutionVersion"`  // 解决方案版本号
	ExternalID        string           `json:"ExternalID"`
	PriceInfoSnapshot string           `json:"PriceInfoSnapshot"`
	Exclude           DiscountExclude  `json:"Exclude"`
	ReferenceID       string           `json:"ReferenceID"`          // 报价关联ID
	IsProject         string           `json:"IsProject"`            // 是否是项目制， 0 否， 1 是
	AccountID         string           `json:"AccountID"`            // 账号ID
	OwnerID           string           `json:"OwnerID"`              // 最终用户ID
	Extra             *DiscountExtra   `json:"Extra"`                // 折扣扩展字段
	DeductList        []*QuoteDiscount `json:"DeductList,omitempty"` // 节省计划抵扣明细（数据结构和合同价保持一致）
	RelatedItemID     string           `json:"RelatedItemID"`        // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID（不直接入参给合同价，仅用于数据构造）
	ItemBusinessRole  string           `json:"ItemBusinessRole"`     // 报价项业务角色：0-标准报价项，1-抵扣报价项（不直接入参给合同价，仅用于数据构造）

}

type DiscountExtra struct {
	SavingPlan *SavingPlanInExtra `json:"SavingPlan,omitempty"`
}

type SavingPlanInExtra struct {
	PrePayRatio           string `json:"PrepayRatioDisplay,omitempty"`       // 预付比例
	PrePayRatioCode       string `json:"PrepayRatio,omitempty"`              // 预付比例, 1- 0 预付, 2- 部分预付, 3-全预付
	SpBuyDuration         string `json:"BuyDurationDisplay,omitempty"`       // 购买时长
	SpBuyDurationCode     string `json:"BuyDuration,omitempty"`              // 购买月份, 单位月, 示例: 1,1
	CommitFeeInterval     string `json:"CommitFeeIntervalDisplay,omitempty"` // 承诺消费金额
	CommitFeeIntervalCode string `json:"CommitFeeInterval,omitempty"`        // 承诺消费金额, 单位元, 示例: 100
}

type DiscountExclude struct {
	ConfigurationCategory string // 配置分类
	Configuration         string // 配置
	RegionCode            string // 地域
	ChargeElement         string // 计费单元
	ChargeItemTag         string // 计费项分类
}

// SplitSellingMode 售卖模式拆分
func (q *QuoteDiscount) SplitSellingMode() []*QuoteDiscount {

	var sellingModeList []int
	arr := strings.Split(q.SellingMode, ",")
	for _, v := range arr {
		intVal, err := strconv.ParseInt(v, 10, 64)
		if err != nil {
			continue
		}
		sellingModeList = append(sellingModeList, int(intVal))
	}

	if len(sellingModeList) == 0 {
		return []*QuoteDiscount{q}
	}

	rawItemBody, _ := json.Marshal(q)

	var ret []*QuoteDiscount
	for _, v := range sellingModeList {
		var newItem QuoteDiscount
		_ = json.Unmarshal(rawItemBody, &newItem)
		newItem.SellingMode = strconv.Itoa(v)
		ret = append(ret, &newItem)
	}

	return ret
}

func (q *QuoteItem) GenQuoteDiscount(BeginTime string, EndTime string, isProject string, customerDiscount *CustomerDiscount) *QuoteDiscount {
	if customerDiscount == nil {
		customerDiscount = &CustomerDiscount{
			Discount: &Discount{},
		}
	} else if customerDiscount.Discount == nil {
		customerDiscount.Discount = &Discount{}
	}

	configCategory := q.ConfigCategoryCode

	var payType string
	var savingPlanExtra *SavingPlanInExtra

	payTypeIn, ok := _const.CanPrePayMapping[q.CanPrePayCode]
	if ok {
		payType = payTypeIn
	}
	deploymentType, ok := _const.ContractToProductDeploymentType[q.DeploymentType]
	if !ok {
		return nil
	}

	sellingMode := q.SellingMode
	if sellingMode == "" {
		sellingMode = "0"
	}
	if q.SalesMode == multienv.SalesModeSavingsPlans {
		savingPlanExtra = &SavingPlanInExtra{
			PrePayRatio:           q.PrePayRatio,
			PrePayRatioCode:       q.PrePayRatioCode,
			SpBuyDuration:         q.SpBuyDuration,
			SpBuyDurationCode:     q.SpBuyDurationCode,
			CommitFeeInterval:     q.CommitFeeInterval,
			CommitFeeIntervalCode: q.CommitFeeIntervalCode,
		}
	}

	return &QuoteDiscount{
		Product:               q.Product,
		ProductName:           q.ProductName,
		ProductCode:           q.ChildProductCode,
		Configuration:         q.ConfigCode,
		ConfigurationName:     q.Config,
		ChargeItemCode:        q.ChargeItemCode,
		ChargeItemTag:         q.ChargeItemTag,
		PriceVersion:          q.PricingVersion,
		Discount:              q.Discount,
		BeginTime:             BeginTime,
		EndTime:               EndTime,
		BizBillingFunction:    customerDiscount.Discount.PricingFunction,
		UnitPrice:             customerDiscount.Discount.UnitPrice.String(),
		UnitPriceInterval:     customerDiscount.Discount.UnitPriceInterval,
		MeasureInterval:       customerDiscount.Discount.MeasureInterval,
		BottomAmount:          "",
		ConfigurationCategory: configCategory,
		BillingMethodCode:     q.ChargeMethodCode,
		BillingName:           q.ChargeMethod,
		RegionCode:            q.RegionCode,
		Region:                q.Region,
		ChargeElement:         q.ChargeUnit,
		ChargeElementCode:     q.ChargeUnitCode,
		PriceFactor:           q.PriceFactorCode,
		PriceFactorName:       q.PriceFactor,
		PayType:               payType,
		CanPrePay:             q.CanPrePay,
		GuaranteedPercentage:  q.GuaranteedPercentage,
		SellingMode:           sellingMode,
		DeploymentType:        deploymentType,
		ProductCatalogue:      _const.StandProductCodeMap[q.StandardProduct],
		Solution:              q.TradeSolution,
		SolutionVersion:       q.TradeSolutionVersion,
		ExternalID:            "",
		PriceInfoSnapshot:     q.PriceInfoSnapshot,
		Exclude: DiscountExclude{
			ConfigurationCategory: q.ConfigCategoryCodeExclude,
			Configuration:         q.ConfigCodeExclude,
			RegionCode:            q.RegionCodeExclude,
			ChargeElement:         q.ChargeUnitCodeExclude,
			ChargeItemTag:         q.ChargeItemTagCodeExclude,
		},
		IsProject:   isProject,
		ReferenceID: q.QuoteItemID,
		AccountID:   customerDiscount.AccountID,
		OwnerID:     customerDiscount.OwnerID,
		Extra: &DiscountExtra{
			SavingPlan: savingPlanExtra,
		},
		RelatedItemID:    q.RelatedItemID,
		ItemBusinessRole: q.ItemBusinessRole,
	}
}

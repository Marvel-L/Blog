package metasupport

import (
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetNonFinalContractListReq_ValidateAutoGen(t *testing.T) {
	// 测试输入AccountID小于等于0的场景
	t.Run("AccountIDLessThanOrEqualToZero", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.AccountID <= 0
			var receiver *GetNonFinalContractListReq = &GetNonFinalContractListReq{
				AccountID: 0,
			}
			// 运行被测函数
			got1 := receiver.Validate()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 当receiver.AccountID <= 0时，预期执行分支if r.AccountID <= 0，返回errors.ErrInvalidParam.WithArgs(\"AccountID\")，所以got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
		})
	})

	// 测试AccountID有效但Limit无效的场景
	t.Run("AccountIDValidLimitInvalid", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.AccountID > 0 && receiver.Limit <= 0
			var receiver *GetNonFinalContractListReq = &GetNonFinalContractListReq{
				AccountID: 1,
				Limit:     -1,
			}
			// 运行被测函数
			got1 := receiver.Validate()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 根据构造的参数，AccountID为1大于0，但Limit为0小于等于0，会执行if r.Limit <= 0分支，返回非nil的错误，所以got1不为nil
			convey.So(got1 == nil, convey.ShouldBeFalse)
		})
	})

	// 测试输入AccountID和Limit都大于0的有效场景
	t.Run("ValidAccountIDAndLimit", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.AccountID > 0 && receiver.Limit > 0
			var receiver *GetNonFinalContractListReq = &GetNonFinalContractListReq{
				AccountID: 1,
				Limit:     1,
			}
			// 运行被测函数
			got1 := receiver.Validate()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 构造的GetNonFinalContractListReq对象中AccountID和Limit都大于0，不会触发返回错误的条件，因此Validate方法返回nil
			convey.So(got1 == nil, convey.ShouldBeTrue)
		})
	})
}

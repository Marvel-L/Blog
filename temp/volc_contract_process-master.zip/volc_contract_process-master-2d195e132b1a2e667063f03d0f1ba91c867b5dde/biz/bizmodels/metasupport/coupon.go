package metasupport

import (
	"volc_contract_process/pkg/errors"
)

// ExportCouponConfigReq 导出返券规则请求
// 同时支持 JSON、Form、Query 三种绑定方式
type ExportCouponConfigReq struct {
	ContractNo      string `json:"ContractNo" form:"ContractNo" query:"ContractNo"`
	CurrentOperator string `json:"CurrentOperator" form:"CurrentOperator" query:"CurrentOperator"`
	Extra           string `json:"Extra" form:"Extra" query:"Extra"`
}

// Validate 参数校验
func (r *ExportCouponConfigReq) Validate() errors.APIError {
	if r.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

package metasupport

import (
	"strings"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

// UpdateExpireRemindReq 更新合同提醒设置请求
type UpdateExpireRemindReq struct {
	CurrentOperator  string // 当前操作人ID
	ContractNo       string // 业务合同编号
	ExpireRemindFlag int    // 是否到期提醒
	NoRemindType     int    // 不再提醒类型枚举
	NoRemindTypeSec  string // 不再提醒类型枚举文字展示
	NoRemindReason   string // 不再提醒具体原因
}

func (u *UpdateExpireRemindReq) Validate() errors.APIError {
	if len(u.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if len(u.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	// 合同到期后是否发送提醒，0-发送，1-不发送，不发送时 不再提醒类型枚举和不再提醒具体原因不能为空
	if u.ExpireRemindFlag == _const.TRUE_FLAG_INT {
		if !util.IntIn(u.NoRemindType, []int{
			_const.NonExpireRemindTypeRenewed,
			_const.NonExpireRemindTypeNoCooperation,
		}) {
			return errors.ErrMissingParam.WithArgs("NoRemindType")
		}
		noRemindTypeSec := _const.NonExpireRemindTypeDescMap[u.NoRemindType]
		if len(u.NoRemindTypeSec) == 0 || !strings.EqualFold(noRemindTypeSec, u.NoRemindTypeSec) {
			return errors.ErrMissingParam.WithArgs("NoRemindTypeSec")
		}
		if len(u.NoRemindReason) > 500 {
			return errors.ErrInternalError.WithArgs("具体原因不能超过500个字符")
		}
	}
	return nil
}

type GetExpireRemindReq struct {
	CurrentOperator string // 当前操作人ID
	ContractNo      string // 合同号
}

func (u *GetExpireRemindReq) Validate() errors.APIError {
	if len(u.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if u.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

package metasupport

import (
	"net/http"
	"testing"
	pkg_errors "volc_contract_process/pkg/errors"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_ExportCouponConfigReq_Validate_BitsUTGen(t *testing.T) {
	t.Run("ContractNo为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：合同编号为空时，校验应返回缺失参数错误
			req := &ExportCouponConfigReq{
				ContractNo:      "",
				CurrentOperator: "op1",
				Extra:           "extra",
			}

			var apiErr pkg_errors.APIError
			apiErr = req.Validate()

			convey.So(apiErr, convey.ShouldNotBeNil)
			convey.So(apiErr.GetCode(), convey.ShouldEqual, "MissingParam")
			convey.So(apiErr.HttpStatus(), convey.ShouldEqual, http.StatusBadRequest)
			convey.So(apiErr.Error(), convey.ShouldContainSubstring, "ContractNo")
			convey.So(apiErr.GetArgs(), convey.ShouldNotBeNil)
			convey.So(len(apiErr.GetArgs()), convey.ShouldEqual, 1)
		})
	})

	t.Run("ContractNo非空返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 场景：合同编号非空时，校验应通过返回nil
			req := &ExportCouponConfigReq{
				ContractNo:      "C-12345",
				CurrentOperator: "op2",
				Extra:           "extra2",
			}

			var apiErr pkg_errors.APIError
			apiErr = req.Validate()

			convey.So(apiErr, convey.ShouldBeNil)
		})
	})
}

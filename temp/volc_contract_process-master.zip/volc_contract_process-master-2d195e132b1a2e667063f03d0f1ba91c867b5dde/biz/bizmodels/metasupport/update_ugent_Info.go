package metasupport

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

type UpdateUrgentInfoReq struct {
	CurrentOperator string `json:"CurrentOperator"` // 当前操作人
	ContractNo      string `json:"ContractNo"`      // 合同号
	IsUrgent        bool   `json:"IsUrgent"`        // 是否加急
	UrgentCode      string `json:"UrgentCode"`      // 加急类型
}

func (u *UpdateUrgentInfoReq) Validate() errors.APIError {
	if u.CurrentOperator == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if u.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if u.IsUrgent && !util.StringIn(u.UrgentCode, []string{
		_const.UrgentCodeMonthly,
		_const.UrgentCodeSprint,
	}) {
		return errors.ErrInvalidParam.WithArgs("UrgentCode")
	}
	return nil
}

type GetUrgentInfoReq struct {
	CurrentOperator string // 当前操作人
	ContractNo      string // 合同号
}

func (u *GetUrgentInfoReq) Validate() errors.APIError {
	if u.CurrentOperator == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if u.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

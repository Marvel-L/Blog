package metasupport

import (
	"fmt"
	"strings"
	"testing"

	_const "volc_contract_process/pkg/const"

	"code.byted.org/eps-platform/common_gopkg/v2/hertz"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_UpdateExpireRemindReq_Validate_BitsUTGen(t *testing.T) {
	t.Run("缺少当前操作人返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "",
				ContractNo:       "", // 触发缺参
				ExpireRemindFlag: 0,
			}

			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)

			// 提取错误消息用于断言包含关键字
			msg := fmt.Sprintf("%v", err)
			if ae, ok := any(err).(hertz.APIError); ok {
				msg = ae.Error()
			}
			convey.So(msg, convey.ShouldContainSubstring, "CurrentOperator")
		})
	})
	t.Run("缺少合同编号返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "", // 触发缺参
				ExpireRemindFlag: 0,
			}

			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)

			// 提取错误消息用于断言包含关键字
			msg := fmt.Sprintf("%v", err)
			if ae, ok := any(err).(hertz.APIError); ok {
				msg = ae.Error()
			}
			convey.So(msg, convey.ShouldContainSubstring, "ContractNo")
		})
	})

	t.Run("到期提醒标志为发送时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// ExpireRemindFlag != TRUE_FLAG_INT 时不校验后续字段
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "C-1001",
				ExpireRemindFlag: 0,
				NoRemindType:     999, // 虽然非法，但不会触发校验
			}

			err := req.Validate()
			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("不再提醒类型非法返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "C-1002",
				ExpireRemindFlag: _const.TRUE_FLAG_INT, // 进入不提醒分支
				NoRemindType:     999,                  // 非法类型
				NoRemindTypeSec:  "",
			}

			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)

			msg := fmt.Sprintf("%v", err)
			if ae, ok := any(err).(hertz.APIError); ok {
				msg = ae.Error()
			}
			convey.So(msg, convey.ShouldContainSubstring, "NoRemindType")
		})
	})

	t.Run("不再提醒类型描述不匹配返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 类型合法，但描述与映射不一致
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "C-1003",
				ExpireRemindFlag: _const.TRUE_FLAG_INT,
				NoRemindType:     _const.NonExpireRemindTypeRenewed,
				NoRemindTypeSec:  "描述不匹配",
			}

			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)

			msg := fmt.Sprintf("%v", err)
			if ae, ok := any(err).(hertz.APIError); ok {
				msg = ae.Error()
			}
			convey.So(msg, convey.ShouldContainSubstring, "NoRemindTypeSec")
		})
	})

	t.Run("不再提醒具体原因超过500返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合法类型与描述，但原因超过500
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "C-1004",
				ExpireRemindFlag: _const.TRUE_FLAG_INT,
				NoRemindType:     _const.NonExpireRemindTypeNoCooperation,
				NoRemindTypeSec:  _const.NonExpireRemindTypeDescMap[_const.NonExpireRemindTypeNoCooperation],
				NoRemindReason:   strings.Repeat("字", 501),
			}

			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)

			msg := fmt.Sprintf("%v", err)
			if ae, ok := any(err).(hertz.APIError); ok {
				msg = ae.Error()
			}
			convey.So(msg, convey.ShouldContainSubstring, "具体原因不能超过500个字符")
		})
	})

	t.Run("所有参数合法返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &UpdateExpireRemindReq{
				CurrentOperator:  "xxx",
				ContractNo:       "C-1005",
				ExpireRemindFlag: _const.TRUE_FLAG_INT,
				NoRemindType:     _const.NonExpireRemindTypeRenewed,
				NoRemindTypeSec:  _const.NonExpireRemindTypeDescMap[_const.NonExpireRemindTypeRenewed],
				NoRemindReason:   strings.Repeat("a", 500),
			}

			err := req.Validate()
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_GetExpireRemindReq_Validate_BitsUTGen(t *testing.T) {
	t.Run("当前操作人缺失返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 当前操作人为空，合同号非空，应返回缺失当前操作人的错误
			req := &GetExpireRemindReq{
				ContractNo: "CN-001",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "CurrentOperator")
		})
	})

	t.Run("合同号缺失返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合同号为空，当前操作人非空，应返回缺失合同号的错误
			req := &GetExpireRemindReq{
				CurrentOperator: "xxxx",
				ContractNo:      "",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ContractNo")
		})
	})

	t.Run("参数齐全返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 参数齐全，应返回nil
			req := &GetExpireRemindReq{
				CurrentOperator: "xxxx",
				ContractNo:      "CN-001",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

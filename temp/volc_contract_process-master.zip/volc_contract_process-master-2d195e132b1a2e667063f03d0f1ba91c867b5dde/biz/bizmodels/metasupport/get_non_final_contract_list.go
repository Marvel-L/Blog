package metasupport

import "volc_contract_process/pkg/errors"

type GetNonFinalContractListReq struct {
	AccountID int64 `json:"AccountID" query:"AccountID"`
	Limit     int   `json:"Limit" query:"Limit" default:"10"` //
	Offset    int   `json:"Offset" query:"Offset"`            //
}

func (r *GetNonFinalContractListReq) Validate() errors.APIError {
	if r.AccountID <= 0 {
		return errors.ErrInvalidParam.WithArgs("AccountID")
	}
	if r.Limit < 0 {
		return errors.ErrInvalidParam.WithArgs("Limit")
	}
	return nil
}

type GetNonFinalContractListResp struct {
	List   []*ContractData
	Total  int
	Limit  int
	Offset int
}

type ContractData struct {
	ContractNo     string `json:"ContractNo"`
	ContractSource int    `json:"ContractSource"`
	Status         int    `json:"Status"`
	SealAccountIDs string `json:"SealAccountIDs"`
	CreateTime     string `json:"CreateTime"`
	Identifier     string `json:"Identifier"`
	ValidityBegin  string `json:"ValidityBegin"`
	ValidityEnd    string `json:"ValidityEnd"`
	FileInfo       string `json:"FileInfo"`
}

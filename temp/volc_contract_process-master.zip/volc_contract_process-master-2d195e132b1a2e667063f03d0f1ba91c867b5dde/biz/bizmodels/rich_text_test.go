package bizmodels

import (
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func Test_RichTextInfo_IsEmpty_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_RichTextInfo_IsEmpty", t, func() {
		mockey.PatchConvey("当RichTextInfo指针为nil时，应返回true", func() {
			// 场景描述：
			// 构造数据：将RichTextInfo指针v设置为nil。
			// 逻辑链路：函数首先检查v是否为nil，条件成立，直接返回true。
			var v *RichTextInfo = nil
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("当RichTextInfo不为nil但所有被检查的字段都为空时，应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo的实例，所有被IsEmpty方法检查的字段都保持零值（空字符串或nil/空切片）。
			// 逻辑链路：函数检查v不为nil，然后依次检查Richtext、RichtextPlainText、MentionUserList、AttachmentList和ImageIdList的长度，所有长度均为0，因此返回true。
			v := &RichTextInfo{}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("当Richtext字段不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，并将其Richtext字段设置为一个非空字符串。
			// 逻辑链路：函数检查len(v.Richtext)不等于0，导致整个布尔与表达式的结果为false，因此函数返回false。
			v := &RichTextInfo{
				Richtext: "some richtext content",
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当RichtextPlainText字段不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，并将其RichtextPlainText字段设置为一个非空字符串。
			// 逻辑链路：函数检查len(v.RichtextPlainText)不等于0，导致整个布尔与表达式的结果为false，因此函数返回false。
			v := &RichTextInfo{
				RichtextPlainText: "some plain text",
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当MentionUserList字段不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，并将其MentionUserList字段设置为一个包含元素的切片。
			// 逻辑链路：函数检查len(v.MentionUserList)不等于0，导致整个布尔与表达式的结果为false，因此函数返回false。
			v := &RichTextInfo{
				MentionUserList: []string{"user1"},
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当AttachmentList字段不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，并将其AttachmentList字段设置为一个包含元素的切片。
			// 逻辑链路：函数检查len(v.AttachmentList)不等于0，导致整个布尔与表达式的结果为false，因此函数返回false。
			v := &RichTextInfo{
				AttachmentList: []*FileVersionData{{FileID: "file-id-1"}},
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当ImageIdList字段不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，并将其ImageIdList字段设置为一个包含元素的切片。
			// 逻辑链路：函数检查len(v.ImageIdList)不等于0，导致整个布尔与表达式的结果为false，因此函数返回false。
			v := &RichTextInfo{
				ImageIdList: []string{"image-id-1"},
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当多个被检查的字段都不为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，将其Richtext和ImageIdList字段都设置为非空。
			// 逻辑链路：函数在检查第一个非空字段len(v.Richtext)时，整个布尔与表达式即为false，函数返回false。
			v := &RichTextInfo{
				Richtext:    "some content",
				ImageIdList: []string{"image-id-1"},
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当未被检查的字段不为空（如ImageInfoList），但所有被检查字段都为空时，应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个RichTextInfo实例，所有被IsEmpty检查的字段都为空，但未被检查的ImageInfoList字段不为空。
			// 逻辑链路：函数不检查ImageInfoList字段。由于所有被检查字段的长度都为0，整个布尔与表达式的结果为true，因此函数返回true。
			v := &RichTextInfo{
				ImageInfoList: []ImageInfo{{}}, // 假设ImageInfo是一个已定义的结构体
			}
			result := v.IsEmpty()
			convey.So(result, convey.ShouldBeTrue)
		})
	})
}

package bizmodels

import (
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"

	"volc_contract_process/pkg/errors"
)

type TemplateReplaceReq struct {
	CurrentOperator string
	ContractNo      string
	TemplateData    []*templateclient.GetTplParamData `json:"TemplateData"` // 模板详情
	FullData        *ContractFullData
	TextParam       map[string]interface{}
	TableParam      map[string]*TableReplaceData
}

func (r *TemplateReplaceReq) Validate() errors.APIError {
	if len(r.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if r.TemplateData == nil {
		return errors.ErrMissingParam.WithArgs("TemplateData")
	}
	if r.FullData == nil {
		return errors.ErrMissingParam.WithArgs("FullData")
	}
	// if len(r.TextParam) == 0 {
	//	return errors.ErrMissingParam.WithArgs("TextParam")
	// }
	return nil
}

type TableReplaceData struct {
	TableData   []map[string][]interface{}
	MergeConfig []*templateclient.TableMergeConfig
}

type BuildReplaceMapResp struct {
	TemplateTextParams        map[string]interface{}
	TemplateTableParams       map[string][]map[string][]interface{}
	TemplateTableMergeConfigs map[string][]*templateclient.TableMergeConfig
}

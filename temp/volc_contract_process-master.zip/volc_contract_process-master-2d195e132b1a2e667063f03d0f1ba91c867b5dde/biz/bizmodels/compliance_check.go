package bizmodels

import (
	"strings"

	"volc_contract_process/pkg/errors"
)

type ComplianceCheckResult struct {
	AutoCheckResult   string `json:"autoCheckResult"`   // 机审结果
	ManualCheckResult string `json:"manualCheckResult"` // 人审结果
}

type SubmitComplianceCheckReq struct {
	ContractNo string `json:"ContractNo"`
}

func (s *SubmitComplianceCheckReq) Validate() errors.APIError {
	if len(s.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if !strings.HasPrefix(s.ContractNo, "CT") && !strings.HasPrefix(s.ContractNo, "PCT") {
		return errors.ErrInvalidParam.WithArgs("ContractNo")
	}
	return nil
}

package bizmodels

import (
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"testing"
	"volc_contract_process/pkg/errors"
)

func TestQuoteRefreshNotifyReqValidate(t *testing.T) {
	t.Run("缺少QuoteID", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &QuoteRefreshNotifyReq{
				RefreshApprovalID: "refresh-1",
				ContractNo:        "contract-1",
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("QuoteID"))
		})
	})

	t.Run("缺少RefreshApprovalID", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &QuoteRefreshNotifyReq{
				QuoteID:    "quote-1",
				ContractNo: "contract-1",
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("RefreshApprovalID"))
		})
	})

	t.Run("缺少ContractNo", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &QuoteRefreshNotifyReq{
				QuoteID:           "quote-1",
				RefreshApprovalID: "refresh-1",
			}

			err := req.Validate()

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("ContractNo"))
		})
	})

	t.Run("参数完整", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &QuoteRefreshNotifyReq{
				QuoteID:           "quote-1",
				RefreshApprovalID: "refresh-1",
				ContractNo:        "contract-1",
			}

			err := req.Validate()

			So(err, ShouldBeNil)
		})
	})
}

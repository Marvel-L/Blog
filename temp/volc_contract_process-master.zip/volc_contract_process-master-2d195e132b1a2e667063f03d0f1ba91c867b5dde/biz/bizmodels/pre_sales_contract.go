package bizmodels

type PreSalesContract struct {
	ID                         string                   // 合同meta表主键ID
	BizScene                   int                      //  业务场景
	BizSource                  int                      //  合同来源
	PreContractNo              string                   // 合同号
	Version                    int                      // 合同版本
	VolcContractNo             string                   // 火山合同号
	MainContractNo             string                   // 主合同号
	FromContractNo             string                   // 原合同号
	SupplyScene                int                      // 补充协议类型 https://bytedance.feishu.cn/wiki/wikcnL1u2xtx5sRujyVtMpmRQ3c
	SupplySource               string                   // 补充协议场景
	ContractName               string                   // 合同名称
	SubjectName                string                   // 我方名称
	OtherPartyName             string                   // 对方名称
	Operator                   string                   // 业务执行人工号（即销售人员工号）
	Creator                    string                   // 创建人工号
	PropertyCode               string                   // 合同性质
	CategoryNo                 string                   // 合同类型编码
	InOutType                  string                   // 收支类型
	SubmitTime                 string                   // 提交时间
	BeginTime                  string                   // 开始时间
	EndTime                    string                   // 结束时间
	SubmitTimeWithTZ           string                   // 提交时间
	BeginTimeWithTZ            string                   // 开始时间
	EndTimeWithTZ              string                   // 结束时间
	Reviewers                  PreContractReviewerList  // 审核人
	CurrentReviewSource        int                      // 当前操作人审核来源
	CurrentFilePermission      int                      // 当前操作人访问合同文本权限
	Role                       int                      // 当前操作人角色
	CanApproval                bool                     // 是否可以审批
	BasicInfo                  *BasicInfo               // 基本信息
	ProjectInfo                *ProjectInfo             // 项目信息
	ManageInfo                 *ManageInfo              // 管理信息
	TradePartyInfo             *TradePartyInfo          // 交易方信息
	ReverseSignInfo            *ReverseSignInfo         // 倒签信息
	SettlementInfo             *SettlementInfo          // 结算条款信息
	BusinessModeClauses        []*BusinessModeClause    // 商务模式条款摘要
	ContractProductInfo        *ContractProductInfo     // 合同产品信息
	ContractAttachment         []*ContractAttachment    // 合同附件
	OnlineContractFile         []*ContractAttachment    // 合同文本
	RiskClauseList             []*RiskClauseRole        // 风险条款
	OnlineContract             string                   // 合同文本
	CRMKey                     string                   // CRM 唯一 Key
	ContractID                 string                   // 飞书合同唯一ID
	CheckCode                  string                   // 校验码
	RequestID                  string                   // 请求ID
	RelateQuoteNo              string                   // 关联报价单号
	RelateQuoteScene           int                      // 关联报价场景
	TemplateKey                string                   // 模板key
	TemplateVersion            int                      // 模板版本
	TemplateInfo               *TemplateInfo            // 模板配置信息
	ContractPriceRepeatInfo    *ContractPriceRepeatInfo // 合同价重复信息
	UrgentInfo                 *UrgentInfo              // 加急信息
	ExpireRemindInfo           *ExpireRemindInfo        // 到期提醒信息
	ContractPriceCreatedTime   string                   // 合同价创建时间
	RequireQuote               bool                     // 是否需要关联报价单
	RelateQuoteChangedNotify   bool                     // 报价单发生变更，当前用户是否需要弹窗
	RelateQuoteChanged         bool                     // 报价单发生变更
	RelateQuoteChangedBefore   string                   // 变更前报价单
	QuoteItemOfflineInfo       string                   // 报价单条目下架信息
	CreatedTime                string                   // 创建时间
	CreatedTimeWithTZ          string                   // 创建时间-带时区
	UpdatedTime                string                   // 更新时间
	UpdatedTimeWithTZ          string                   // 更新时间-带时区
	Status                     int                      // 状态
	PreCooperationStatus       int                      // 前序协商状态
	NeedCreateGroupChat        bool                     // 是否需要创建群聊
	OpenChatID                 string                   // 飞书群ID
	FromContractTerminatedTime string                   // 原合同终止日期
	IsMainContract             bool                     // 是否为主合同
	SupplementInfoList         *SupplementInfoList      // 补充协议信息
	IsShowSupplyWin            bool                     // 是否展示补充协议列表
	IsUrgent                   int                      // 是否加急
	ExpireRemindFlag           int                      // 合同到期是否提醒
	FromContractStartTime      string                   // 原合同有效期开始时间
	FromContractEndTime        string                   // 原合同有效期结束时间
	MainContractStartTime      string                   // 主合同有效期开始时间
	MainContractEndTime        string                   // 主合同有效期结束时间
	ValidityChangeDetail       string                   // 有效期变更详情
	CanAcquireReviewer         bool                     // 是否显示“分配给我”（通过代码填入的字段）
	WillReplaceReviewers       []string                 // “分配给我”会抢的审核人员（通过代码填入的字段）
	Ext                        map[string]string        // 合同附加信息
}

type ContractProductInfo struct {
	// 合同产品信息 本期不做
}

type ContractAttachment struct {
	Type        string // 附件类型
	FileName    string // 名称
	CreatorName string // 创建人
	ModifiedAt  string // 修改时间
	Sealed      string // 用章情况
	Archived    string // 存档情况
	Remark      string // 说明
	DownloadID  string // 下载id
	StorageType int    // 存储类型，0-TOS 1-文件管理系统
}

package modelsettlement

import "volc_contract_process/biz/bizmodels"

type SubmitSettlementReq struct {
	ContractNo      string
	SettlementLines bizmodels.SettlementLines
}

type SubmitSettlementResp struct {
	ContractNo      string
	SettlementLines bizmodels.SettlementLines
}

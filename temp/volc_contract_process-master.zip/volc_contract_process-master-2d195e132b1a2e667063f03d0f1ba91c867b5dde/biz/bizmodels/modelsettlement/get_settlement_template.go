package modelsettlement

import (
	"volc_contract_process/biz/bizmodels"
)

type GetSettlementTemplateReq struct {
	AccountIds string `json:"AccountIds" query:"AccountIds"`
	SubjectNo  string `json:"SubjectNo" query:"SubjectNo"`
	QuoteNo    string `json:"QuoteNo" query:"QuoteNo"`
}

type GetSettlementTemplateResp struct {
	AccountDatas       []*CreditAccountData
	Settlementtemplate []*bizmodels.SettlementLine
}

type CreditAccountData struct {
	AccountId    string
	CreditSource int
}

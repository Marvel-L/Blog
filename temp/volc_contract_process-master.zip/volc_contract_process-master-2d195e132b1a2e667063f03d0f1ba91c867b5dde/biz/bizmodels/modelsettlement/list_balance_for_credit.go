package modelsettlement

type ListBalanceForCreditReq struct {
	AccountIDList string
	ContractNo    string
	SubjectNo     string
}

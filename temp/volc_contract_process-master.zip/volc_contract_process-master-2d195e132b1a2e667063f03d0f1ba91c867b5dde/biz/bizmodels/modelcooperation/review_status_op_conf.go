package modelcooperation

type ReviewerStatusOpConf struct {
	AllowSystemCalls                bool           // 是否允许系统调用
	IgnoreRolePermCheck             bool           // 忽略角色权限检查
	ReviewerType                    int            // 执行角色
	IgnoreUpdateReviewerStatus      bool           // 是否忽略更新审批操作表状态
	NewStatusOnSuccess              int            // 审批操作表状态
	IgnoreUpdatePreContractStatus   bool           // 是否忽略更新合同协表状态
	ContractNewStatusOnSuccess      int            // 合同协作表状态
	ContractNewStatusMapOnSuccess   map[string]int // 合同协作表状态
	DynamicNodeRuleKey              string         // 动态节点匹配规则
	SpecifiedSendBackTargetStatuses []int          // 指定退回时允许用户选择的目标节点
}

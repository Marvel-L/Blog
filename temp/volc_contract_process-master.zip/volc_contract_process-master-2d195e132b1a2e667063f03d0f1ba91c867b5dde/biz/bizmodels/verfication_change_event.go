package bizmodels

import "time"

type AccountChangeMsg struct {
	MessageType string    `json:"messageType"`
	MessageID   string    `json:"messageId"`
	Timestamp   time.Time `json:"timestamp"`
	Detail      struct {
		AccountID int `json:"accountID"`
	} `json:"detail"`
}

type AccountChangeInnerEBMsg struct {
	MessageID string                        `json:"MessageId"`
	Timestamp time.Time                     `json:"Timestamp"`
	IsTools   bool                          `json:"IsTools"`
	Detail    AccountChangeInnerEBMsgDetail `json:"Detail"`
}
type AccountChangeInnerEBMsgDetail struct {
	AccountID int64  `json:"AccountId"`
	ProcessID string `json:"ProcessId"`
}

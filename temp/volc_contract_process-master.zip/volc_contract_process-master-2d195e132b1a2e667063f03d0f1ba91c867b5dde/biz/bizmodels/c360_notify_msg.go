package bizmodels

type C360NotifyMsg struct {
	EventType    string             `json:"event_type"`
	Operator     []string           `json:"operator"`
	ContractList []C360NotifyRecord `json:"contract_list"`
}

type C360NotifyRecord struct {
	ContractNumber     string `json:"contract_number"`
	ContractName       string `json:"contract_name"`
	NextAuditNode      string `json:"next_audit_node"`
	StatusReturnReason string `json:"status_return_reason"`
	CustomerName       string `json:"customer_name"`
	CommentCreator     string `json:"comment_creator"`
	CommentContent     string `json:"comment_content"`
	LegalAuditRes      string `json:"legal_audit_res"` // 合规审查结果
	ContractStatus     string `json:"contract_status"` // 合同状态
}

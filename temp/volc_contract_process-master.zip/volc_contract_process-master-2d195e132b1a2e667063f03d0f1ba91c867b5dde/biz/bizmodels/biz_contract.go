package bizmodels

type BizContract struct {
	ContractNo          string
	Scene               int
	Identifier          string
	AccountID           int64
	SealAccountIDs      string
	ValidityBegin       string
	ValidityEnd         string
	Creator             string
	CreateTime          string
	FinishTime          string
	OpRecordList        CommonOperationRecordList `json:"OpRecordList,omitempty"`
	AccountInfoList     []*AccountInfo            `json:"AccountInfoList"`
	BizInfo             string
	Remark              string
	Identity            string `json:"identity,omitempty"`
	CustomerName        string `json:"CustomerName,omitempty"`
	FileIdUnsigned      string
	FileIdSigned        string
	Extra               string
	Status              int
	FileURL             string `json:"file_url,omitempty"`
	StatusDesc          string
	OaContractNo        string
	CreditType          string
	CreditLimit         float64
	CreateSource        int
	PrincipalParty      string `json:"PrincipalParty"`      // 委托方
	EntrustedParty      string `json:"EntrustedParty"`      // 被委托方
	CanApplyPaper       bool   `json:"CanApplyPaper"`       // 是否允许加盖鲜章
	FreshSealApprovalNo string `json:"FreshSealApprovalNo"` // 申请单号

}

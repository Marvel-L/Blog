package bizmodels

type PerformEvent struct {
	Action     string `json:"Action"`
	BizNO      string `json:"BizNO"`
	ContractNo string `json:"ContractNo"`
}

package bizmodels

import (
	"time"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type QueryLadderQuotationContractReq struct {
	CurrentOperator string
	SourceType      _const.SourceType //
	ContractNoList  string
	AccountIds      string
	ProductList     string
	ValidityBegin   time.Time
	ValidityEnd     time.Time
	SkipContractNo  string
}

func (r *QueryLadderQuotationContractReq) Validate() errors.APIError {
	if len(r.ContractNoList) == 0 && len(r.AccountIds) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNoList & AccountIds")
	}
	if len(r.ProductList) == 0 {
		return errors.ErrMissingParam.WithArgs("ProductList")
	}
	if r.ValidityBegin.IsZero() {
		return errors.ErrMissingParam.WithArgs("ValidityBegin")
	}
	if r.ValidityEnd.IsZero() {
		return errors.ErrMissingParam.WithArgs("ValidityEnd")
	}
	return nil
}

type QueryLadderQuotationContractResp struct {
	IsRepeat   bool
	RepeatList []*RepeatContractExportData
}

func (q *QueryLadderQuotationContractResp) GetProductNameList() []string {
	productMap := map[string]string{}
	for _, repeatData := range q.RepeatList {
		for _, data := range repeatData.RepeatDataList {
			for _, product := range data.RepeatProducts {
				productMap[product.Product] = product.ProductName
				if len(product.ProductName) == 0 {
					productMap[product.Product] = product.Product
				}
			}
		}
	}
	var nameList []string
	for _, productName := range productMap {
		nameList = append(nameList, productName)
	}
	return nameList
}

func (q *QueryLadderQuotationContractResp) GetProductList() []string {
	productMap := map[string]struct{}{}
	for _, repeatData := range q.RepeatList {
		for _, data := range repeatData.RepeatDataList {
			for _, product := range data.RepeatProducts {
				productMap[product.Product] = struct{}{}
			}
		}
	}
	var productList []string
	for product := range productMap {
		productList = append(productList, product)
	}
	return productList
}

type RepeatContractExportData struct {
	AccountId      int
	RepeatDataList []*RepeatData
}

type RepeatData struct {
	ContractNo     string
	RepeatProducts []*RepeatProductsData
}

type RepeatProductsData struct {
	Product     string
	ProductName string
}

type CheckLadderQuoteContractClashReq struct {
	CurrentOperator   string            // 当前操作人
	SourceType        _const.SourceType //
	AccountIds        string            // 报价单关联账号ID
	ContractNo        string            // 当前合同合同好
	CheckContractNos  string            // 当前用户历史创建合同，有accountID 可不填
	ProductList       string            // 报价单包含的商品列表
	ValidityBegin     string            // 合同预估有效期
	ValidityEnd       string            // 合同预估有效期
	ValidityBeginDate time.Time         // 合同预估有效期
	ValidityEndDate   time.Time         // 合同预估有效期
}

func (r *CheckLadderQuoteContractClashReq) Validate() errors.APIError {
	if len(r.CheckContractNos) == 0 && len(r.AccountIds) == 0 {
		return errors.ErrMissingParam.WithArgs("CheckContractNos & AccountIds 为空")
	}
	if len(r.ProductList) == 0 {
		return errors.ErrMissingParam.WithArgs("ProductList 为空")
	}
	if len(r.ValidityBegin) == 0 {
		return errors.ErrMissingParam.WithArgs("ValidityBegin 为空")
	}
	if len(r.ValidityEnd) == 0 {
		return errors.ErrMissingParam.WithArgs("ValidityEnd 为空")
	}

	var err error
	r.ValidityBeginDate, err = time.ParseInLocation(DBDateFormatTpl, r.ValidityBegin, time.Local)
	if err != nil {
		return errors.ErrInternalError.WithArgs("ValidityBegin")
	}
	r.ValidityEndDate, err = time.ParseInLocation(DBDateFormatTpl, r.ValidityEnd, time.Local)
	if err != nil {
		return errors.ErrInternalError.WithArgs("ValidityEnd")
	}
	return nil
}

type CheckLadderQuoteContractClashResp struct {
	Repeat  bool
	Message string
}

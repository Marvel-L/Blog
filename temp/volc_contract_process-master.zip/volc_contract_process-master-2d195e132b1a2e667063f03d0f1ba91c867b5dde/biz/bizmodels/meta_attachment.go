package bizmodels

import (
	_const "volc_contract_process/pkg/const"
)

// MetaAttachment 元数据附件
type MetaAttachment struct {
	Type        string `json:"Type"`
	FileName    string `json:"FileName"`
	CreatorName string // 创建人
	ModifiedAt  string // 修改时间
	Sealed      string `json:"Sealed,omitempty"`
	Archived    string `json:"Archived,omitempty"`
	Remark      string `json:"Remark,omitempty"`
	DownloadID  string `json:"DownloadID"`
	StorageType int    `json:"StorageType"`
}

type MetaAttachmentExtra struct {
	Type     string `json:"Type"`
	Sealed   string `json:"Sealed,omitempty"`
	Archived string `json:"Archived,omitempty"`
	Remark   string `json:"Remark,omitempty"`
}

func (e *MetaAttachmentExtra) FetchFeishuFileType() string {
	if e == nil {
		return ""
	}
	if e.Sealed == _const.No && e.Archived == _const.No {
		return _const.FILE_TYPE_ATTACHMENT
	} else if e.Sealed == _const.Yes && e.Archived == _const.Yes {
		return _const.FILE_TYPE_CAUSE
	} else if e.Sealed == _const.Yes {
		return _const.FILE_TYPE_CAUSE
	}
	return _const.FILE_TYPE_TEXT
}

type MetaAttachmentDownloadParam struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"`
	DownloadID      string `json:"DownloadID" query:"DownloadID"`
	Version         string `json:"DocVersion" query:"DocVersion"`
	StorageType     int    `json:"StorageType" query:"StorageType"`
}

type MetaBizAttachmentDownloadParam struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` //
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 合同号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 合同版本
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
}

// MetaBatchAttachmentDownloadParam 批量下载合同参数（逗号分隔的DownloadID列表）
// swagger:model MetaBatchAttachmentDownloadParam
type MetaBatchAttachmentDownloadParam struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator" binding:"required"` // 当前操作人
	DownloadIDs     string `json:"DownloadIDs" query:"DownloadIDs" binding:"required"`         // 下载ID列表，逗号分隔
	ContractNo      string `json:"ContractNo" query:"ContractNo"`                              // 合同号（用于打包文件命名，可选）
}

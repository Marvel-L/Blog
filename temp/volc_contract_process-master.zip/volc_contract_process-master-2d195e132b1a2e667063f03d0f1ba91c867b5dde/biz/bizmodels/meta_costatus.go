package bizmodels

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"strings"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
)

// MetaCoStatusParam 合同状态信息
type MetaCoStatusParam struct {
	ContractNo      string `json:"ContractNo" query:"ContractNo"`
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"`
	BizScene        int    `json:"BizScene" query:"BizScene"`
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"`
}

// MetaCoStatusInfo 合同协同状态信息
type MetaCoStatusInfo struct {
	ContractNo        string `json:"ContractNo" query:"ContractNo"`               //
	CooperationStatus int    `json:"CooperationStatus" query:"CooperationStatus"` //
	Extra             string `json:"Extra" query:"Extra"`                         //
}

type ContractDiscountGroup struct {
	Current      *ContractDiscount   // 当前合同中的条目（排在第一条）
	PreviousList []*ContractDiscount // 与之前重复的条目（按 CreatedTime 从最新到最老排序）
}

type ContractDiscount struct {
	ID                               int    `json:"Id"`
	Key                              string // 由 Product ConfigurationCategory Configuration BillingMethodCode RegionCode ChargeElementCode PriceFactor ChargeItemCode 拼出来的
	Product                          string // 商品 ECS
	ProductName                      string // 商品中文名
	ProductValidityBegin             int64  // 产品有效期起始日期
	ProductValidityEnd               int64  // 产品有效期截止日期
	CreatedTime                      int64  // 合同价创建时间
	ContractNo                       string // 合同号 CN202206229231158
	ChargeItemCode                   string // 计费项名称
	ChargeItemTag                    string // 计费项标签
	PayType                          string // 付费方式(英文)
	CanPrePay                        string // 付费方式(中文)
	GuaranteedPercentage             string // 保底比例
	ConfigurationCategory            string // 配置分类
	Configuration                    string // 配置(英文)
	ConfigurationName                string // 配置(中文)
	BillingFunction                  string // 计费方式(英文)
	BillingName                      string // 计费方式(中文)
	BillingMethodCode                string // 计费方式编码 ChargeMethodCode
	RegionCode                       string // 地域编码
	Region                           string // 地域(中文)
	ChargeElement                    string // 计费单元
	ChargeElementCode                string // 计费单元编码
	UnitPrice                        string // 计费单元
	UnitPriceInterval                string //
	MeasureInterval                  string //
	PriceFactor                      string // 价格影响因子(JSON)
	PriceFactorName                  string // 价格影响因子(中文)
	RelateQuoteNo                    string // 关联报价单
	PriceInfoSnapshot                string // 刊例价快照
	ExternalID                       string
	BeginTime                        int
	EndTime                          int
	Solution                         string
	SolutionVersion                  string
	SellingMode                      string
	ConfigurationCategoryExclude     string // 配置分类 排除项
	ConfigurationCategoryExcludeName string // 配置分类名称 排除项
	ConfigurationExclude             string // 配置 排除项
	ConfigurationExcludeName         string // 配置名称 排除项
	ChargeItemTagExcludeCode         string // 计费项分类 排除项
	ChargeItemTagExcludeName         string // 计费项分类名称 排除项
	ChargeElementExcludeCode         string // 计费单元 排除项
	ChargeElementExcludeName         string // 计费单元名称 排除项
	RegionExcludeCode                string // 地域 排除项
	RegionExcludeName                string // 地域名称 排除项
	Sequence                         int64
	ReferenceID                      string
	RelatedItemID                    string // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	ItemBusinessRole                 string // 报价项业务角色：0-标准报价项，1-抵扣报价项
	IsProject                        string
	BizBillingFunction               string
	Extra                            *DiscountExtra
	Status                           int
	DeductList                       []*ContractDiscount // 子抵扣项列表
}

type ContractDiscountList []*ContractDiscount

func BuildConfigurationSummaryDesc(ctx context.Context, title, value, exclude string) string {
	title = multienv.I18nFormat(ctx, title)
	value = ReplaceQuoteOptionDesc(ctx, value)
	var res = value
	// 默认格式
	if len(title) > 0 {
		res = fmt.Sprintf("%s: %s", title, value)
	}
	// 若排除项不为空，需拼接排除信息
	if len(exclude) > 0 {
		exclude = strings.ReplaceAll(exclude, ",", "、")
		res = i18nfmt.Sprintf(ctx, "%s（不包含 %s）", res, exclude)
	}
	return res
}

func ReplaceQuoteOptionDesc(ctx context.Context, option string) string {
	switch option {
	case "*":
		return multienv.I18nFormat(ctx, "所有选项")
	default:
		return option
	}
}

func (c ContractDiscountList) GenRepeatProductMsg(ctx context.Context, quoteID string) string {
	var buf bytes.Buffer
	buf.WriteString(multienv.I18nFormat(ctx, "报价单["))
	buf.WriteString(quoteID)
	buf.WriteString(multienv.I18nFormat(ctx, "]存在如下重复报价项："))
	for idx, v := range c {
		buf.WriteString(fmt.Sprintf("%d: ", idx+1))
		buf.WriteString(multienv.I18nFormat(ctx, "合同["))
		buf.WriteString(v.ContractNo)
		buf.WriteString("],")
		if len(v.DeductList) > 0 {
			// 主子层级展示
			buf.WriteString(multienv.I18nFormat(ctx, "报价项"))
			buf.WriteString(v.formatDiscount(ctx))
			buf.WriteString(multienv.I18nFormat(ctx, "，包含重复节省计划抵扣项："))
			for subIdx, subV := range v.DeductList {
				buf.WriteString(fmt.Sprintf("(%d.%d) ", idx+1, subIdx+1))
				buf.WriteString(subV.formatDiscount(ctx))
				if subIdx < len(v.DeductList)-1 {
					buf.WriteString("； ")
				}
			}
		} else {
			// 普通平铺展示
			buf.WriteString(v.formatDiscount(ctx))
		}
		buf.WriteString("； ")
	}
	if buf.Len() == 0 {
		return ""
	}
	duplicatedInfo := buf.String()
	duplicatedInfo = strings.ReplaceAll(duplicatedInfo, "\\", "\\\\")
	duplicatedInfo = strings.ReplaceAll(duplicatedInfo, "\"", "\\\"")
	return duplicatedInfo
}

func (v *ContractDiscount) formatDiscount(ctx context.Context) string {
	var prePayRatio, commitFeeInterval, spBuyDuration string
	if v.Extra != nil && v.Extra.SavingPlan != nil {
		prePayRatio = v.Extra.SavingPlan.PrePayRatio
		commitFeeInterval = v.Extra.SavingPlan.CommitFeeInterval
		spBuyDuration = v.Extra.SavingPlan.SpBuyDuration
	}

	var buf bytes.Buffer
	buf.WriteString(multienv.I18nFormat(ctx, "商品["))
	buf.WriteString(v.ProductName)
	buf.WriteString(multienv.I18nFormat(ctx, "],付费方式为["))
	buf.WriteString(v.CanPrePay)
	buf.WriteString(multienv.I18nFormat(ctx, "],配置分类为["))
	buf.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ConfigurationCategory, v.ConfigurationCategoryExcludeName))
	buf.WriteString(multienv.I18nFormat(ctx, "],配置["))
	buf.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ConfigurationName, v.ConfigurationExcludeName))
	buf.WriteString(multienv.I18nFormat(ctx, "],计费项分类["))
	buf.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ChargeItemTag, v.ChargeItemTagExcludeName))
	buf.WriteString(multienv.I18nFormat(ctx, "],计费方式["))
	buf.WriteString(v.BillingName)
	buf.WriteString(multienv.I18nFormat(ctx, "],地域["))
	buf.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.Region, v.RegionExcludeName))
	buf.WriteString(multienv.I18nFormat(ctx, "],计费单元["))
	buf.WriteString(BuildConfigurationSummaryDesc(ctx, "", v.ChargeElement, v.ChargeElementExcludeName))
	buf.WriteString(multienv.I18nFormat(ctx, "],价格影响因子["))
	buf.WriteString(v.PriceFactor)
	buf.WriteString(multienv.I18nFormat(ctx, "],售卖模式["))
	buf.WriteString(v.SellingMode)
	buf.WriteString(multienv.I18nFormat(ctx, "],预付比例["))
	buf.WriteString(prePayRatio)
	buf.WriteString(multienv.I18nFormat(ctx, "],承诺消费金额["))
	buf.WriteString(commitFeeInterval)
	buf.WriteString(multienv.I18nFormat(ctx, "],购买时长["))
	buf.WriteString(spBuyDuration)
	buf.WriteString("]")
	return buf.String()
}

func (m *MetaCoStatusParam) Validate() error {
	if len(m.ContractNo) > 0 {
		return nil
	}
	if m.BizScene == 0 || len(m.BizIdentifier) == 0 {
		return errors.New(i18nfmt.Sprintf(context.Background(), "%s为空", "biz_scene|biz_identifier"))
	}
	return nil
}

package bizmodels

import (
	"code.byted.org/gopkg/context"
	context001 "context"
	"fmt"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"strings"
	"testing"
	"volc_contract_process/biz/service/multienv"
)

func Test_BuildConfigurationSummaryDesc(t *testing.T) {
	ctx := context.Background()

	PatchConvey("Test BuildConfigurationSummaryDesc", t, func() {
		PatchConvey("场景一：提供标题和值，不提供排除项", func() {
			// 场景描述:
			// 当 title 和 value 不为空，而 exclude 为空时，函数应返回 "title: value" 格式的字符串，并对 title 和 value 进行国际化/替换处理。
			// 数据构造:
			// - title: "Test Title"
			// - value: "Test Value"
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 对 title 进行国际化处理。
			// 2. Mock ReplaceQuoteOptionDesc 对 value 进行替换处理。
			// 3. 函数拼接 title 和 value。
			// 4. 由于 exclude 为空，不进入排除项拼接逻辑。
			// 5. 返回最终结果。

			// 数据构造
			title := "Test Title"
			value := "Test Value"
			exclude := ""

			// Mock
			Mock(multienv.I18nFormat).Return("Test Title_i18n").Build()
			Mock(ReplaceQuoteOptionDesc).Return("Test Value_replaced").Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			expected := "Test Title_i18n: Test Value_replaced"
			So(result, ShouldEqual, expected)
		})

		PatchConvey("场景二：仅提供值，不提供标题和排除项", func() {
			// 场景描述:
			// 当仅 value 不为空时，函数应只返回经过处理的 value 字符串。
			// 数据构造:
			// - title: ""
			// - value: "Test Value"
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock ReplaceQuoteOptionDesc 对 value 进行处理。
			// 2. 由于 title 为空，不进行 title 拼接。
			// 3. 由于 exclude 为空，不进行排除项拼接。
			// 4. 返回处理后的 value。

			// 数据构造
			title := ""
			value := "Test Value"
			exclude := ""

			// Mock
			Mock(multienv.I18nFormat).Return("").Build()
			Mock(ReplaceQuoteOptionDesc).Return("Test Value_replaced").Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			So(result, ShouldEqual, "Test Value_replaced")
		})

		PatchConvey("场景三：提供所有参数（标题、值、排除项）", func() {
			// 场景描述:
			// 当 title, value, exclude 均不为空时，函数应返回包含排除信息的完整描述。
			// 数据构造:
			// - title: "Test Title"
			// - value: "Test Value"
			// - exclude: "item1,item2"
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 对 title 和排除项格式字符串进行国际化。
			// 2. Mock ReplaceQuoteOptionDesc 对 value 进行处理。
			// 3. 函数拼接 "title: value"。
			// 4. 函数处理 exclude 字符串，将逗号替换为顿号。
			// 5. 函数使用 i18nfmt.Sprintf 拼接排除信息。
			// 6. 返回最终结果。

			// 数据构造
			title := "Test Title"
			value := "Test Value"
			exclude := "item1,item2"

			// Mock
			Mock(multienv.I18nFormat).
				When(func(_ context.Context, v string) bool { return v == title }).
				Return("Test Title_i18n").
				When(func(_ context.Context, v string) bool { return v == "%s（不包含 %s）" }).
				Return("%s (excludes %s)").
				Build()
			Mock(ReplaceQuoteOptionDesc).Return("Test Value_replaced").Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			expected := fmt.Sprintf("%s (excludes %s)", "Test Title_i18n: Test Value_replaced", "item1、item2")
			So(result, ShouldEqual, expected)
		})

		PatchConvey("场景四：提供值和排除项，不提供标题", func() {
			// 场景描述:
			// 当 value 和 exclude 不为空，而 title 为空时，函数应返回 value 及排除信息。
			// 数据构造:
			// - title: ""
			// - value: "Test Value"
			// - exclude: "item1"
			// 逻辑链路:
			// 1. Mock ReplaceQuoteOptionDesc 对 value 进行处理。
			// 2. 由于 title 为空，不拼接 title。
			// 3. Mock multienv.I18nFormat 对排除项格式字符串进行国际化。
			// 4. 拼接排除信息。
			// 5. 返回最终结果。

			// 数据构造
			title := ""
			value := "Test Value"
			exclude := "item1"

			// Mock
			Mock(multienv.I18nFormat).
				When(func(_ context.Context, v string) bool { return v == "" }).
				Return("").
				When(func(_ context.Context, v string) bool { return v == "%s（不包含 %s）" }).
				Return("%s (excludes %s)").
				Build()
			Mock(ReplaceQuoteOptionDesc).Return("Test Value_replaced").Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			expected := fmt.Sprintf("%s (excludes %s)", "Test Value_replaced", "item1")
			So(result, ShouldEqual, expected)
		})

		PatchConvey("场景五：所有输入均为空", func() {
			// 场景描述:
			// 当所有输入参数都为空字符串时，函数应返回空字符串。
			// 数据构造:
			// - title: ""
			// - value: ""
			// - exclude: ""
			// 逻辑链路:
			// 1. 各 Mock 均返回空字符串。
			// 2. 函数不进入任何拼接逻辑。
			// 3. 返回空字符串。

			// 数据构造
			title := ""
			value := ""
			exclude := ""

			// Mock
			Mock(multienv.I18nFormat).Return("").Build()
			Mock(ReplaceQuoteOptionDesc).Return("").Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			So(result, ShouldBeEmpty)
		})

		PatchConvey("场景六：当值为特殊字符'*'时", func() {
			// 场景描述:
			// 当 value 为 "*" 时，应由 ReplaceQuoteOptionDesc 处理为特定描述，如 "所有选项"。
			// 数据构造:
			// - title: "选项"
			// - value: "*"
			// - exclude: ""
			// 逻辑链路:
			// 1. Mock multienv.I18nFormat 对 title 进行国际化。
			// 2. Mock ReplaceQuoteOptionDesc 将 "*" 替换为 "所有选项"。
			// 3. 函数拼接 title 和处理后的 value。
			// 4. 返回最终结果。

			// 数据构造
			title := "选项"
			value := "*"
			exclude := ""

			// Mock
			Mock(multienv.I18nFormat).Return("选项_i18n").Build()
			Mock(ReplaceQuoteOptionDesc).
				When(func(_ context.Context, v string) bool { return v == "*" }).
				Return("所有选项").
				Build()

			// 调用
			result := BuildConfigurationSummaryDesc(ctx, title, value, exclude)

			// 断言
			expected := "选项_i18n: 所有选项"
			So(result, ShouldEqual, expected)
		})
	})
}

func Test_ReplaceQuoteOptionDesc(t *testing.T) {
	ctx := context.Background()
	PatchConvey("Test ReplaceQuoteOptionDesc with '*' option", t, func() {
		// Mock the multienv.I18nFormat function to return a specific string
		Mock(multienv.I18nFormat).Return("所有选项").Build()
		actual := ReplaceQuoteOptionDesc(ctx, "*")
		So(actual, ShouldEqual, "所有选项")
	})
	PatchConvey("Test ReplaceQuoteOptionDesc with default option", t, func() {
		// No need to mock multienv.I18nFormat as it won't be called
		option := "default_option"
		actual := ReplaceQuoteOptionDesc(ctx, option)
		So(actual, ShouldEqual, option)
	})
	PatchConvey("Test ReplaceQuoteOptionDesc with empty option", t, func() {
		// No need to mock multienv.I18nFormat as it won't be called
		option := ""
		actual := ReplaceQuoteOptionDesc(ctx, option)
		So(actual, ShouldEqual, option)
	})
}

func Test_GenRepeatProductMsg(t *testing.T) {
	ctx := context.Background()
	quoteID := "QUOTE123"

	PatchConvey("Test GenRepeatProductMsg with empty ContractDiscountList", t, func() {
		c := ContractDiscountList{}
		actual := c.GenRepeatProductMsg(ctx, quoteID)
		So(actual, ShouldEqual, "报价单[QUOTE123]存在如下重复报价项：")
	})

	PatchConvey("Test GenRepeatProductMsg with single ContractDiscount", t, func() {
		c := ContractDiscountList{
			&ContractDiscount{
				ContractNo:                       "CN202206229231158",
				ProductName:                      "ECS",
				CanPrePay:                        "PrePay",
				ConfigurationCategory:            "CategoryA",
				ConfigurationName:                "ConfigA",
				ChargeItemTag:                    "TagA",
				BillingName:                      "BillingA",
				Region:                           "RegionA",
				ChargeElement:                    "ElementA",
				PriceFactor:                      "FactorA",
				SellingMode:                      "ModeA",
				ConfigurationCategoryExcludeName: "ExcludeCategoryA",
				ConfigurationExcludeName:         "ExcludeConfigA",
				ChargeItemTagExcludeName:         "ExcludeTagA",
				RegionExcludeName:                "ExcludeRegionA",
				ChargeElementExcludeName:         "ExcludeElementA",
				Extra: &DiscountExtra{
					SavingPlan: &SavingPlanInExtra{
						PrePayRatio:       "PrePayRatioA",
						SpBuyDuration:     "SpBuyDurationA",
						CommitFeeInterval: "CommitFeeIntervalA",
					},
				},
			},
		}

		// Mocking I18nFormat and BuildConfigurationSummaryDesc functions
		Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		Mock(BuildConfigurationSummaryDesc).Return("summary description").Build()

		expected := `报价单[QUOTE123]存在如下重复报价项：1: 合同[CN202206229231158],商品[ECS],付费方式为[PrePay],配置分类为[summary description],配置[summary description],计费项分类[summary description],计费方式[BillingA],地域[summary description],计费单元[summary description],价格影响因子[FactorA],售卖模式[ModeA],预付比例[PrePayRatioA],承诺消费金额[CommitFeeIntervalA],购买时长[SpBuyDurationA]； `
		actual := c.GenRepeatProductMsg(ctx, quoteID)
		So(actual, ShouldEqual, expected)
	})

	PatchConvey("Test GenRepeatProductMsg with multiple ContractDiscounts", t, func() {
		c := ContractDiscountList{
			&ContractDiscount{
				ContractNo:                       "CN202206229231158",
				ProductName:                      "ECS",
				CanPrePay:                        "PrePay",
				ConfigurationCategory:            "CategoryA",
				ConfigurationName:                "ConfigA",
				ChargeItemTag:                    "TagA",
				BillingName:                      "BillingA",
				Region:                           "RegionA",
				ChargeElement:                    "ElementA",
				PriceFactor:                      "FactorA",
				SellingMode:                      "ModeA",
				ConfigurationCategoryExcludeName: "ExcludeCategoryA",
				ConfigurationExcludeName:         "ExcludeConfigA",
				ChargeItemTagExcludeName:         "ExcludeTagA",
				RegionExcludeName:                "ExcludeRegionA",
				ChargeElementExcludeName:         "ExcludeElementA",
				Extra: &DiscountExtra{
					SavingPlan: &SavingPlanInExtra{
						PrePayRatio:       "PrePayRatioA",
						SpBuyDuration:     "SpBuyDurationA",
						CommitFeeInterval: "CommitFeeIntervalA",
					},
				},
			},
			&ContractDiscount{
				ContractNo:                       "CN202206229231159",
				ProductName:                      "RDS",
				CanPrePay:                        "PostPay",
				ConfigurationCategory:            "CategoryB",
				ConfigurationName:                "ConfigB",
				ChargeItemTag:                    "TagB",
				BillingName:                      "BillingB",
				Region:                           "RegionB",
				ChargeElement:                    "ElementB",
				PriceFactor:                      "FactorB",
				SellingMode:                      "ModeB",
				ConfigurationCategoryExcludeName: "ExcludeCategoryB",
				ConfigurationExcludeName:         "ExcludeConfigB",
				ChargeItemTagExcludeName:         "ExcludeTagB",
				RegionExcludeName:                "ExcludeRegionB",
				ChargeElementExcludeName:         "ExcludeElementB",
				Extra: &DiscountExtra{
					SavingPlan: &SavingPlanInExtra{
						PrePayRatio:       "PrePayRatioB",
						SpBuyDuration:     "SpBuyDurationB",
						CommitFeeInterval: "CommitFeeIntervalB",
					},
				},
			},
		}

		// Mocking I18nFormat and BuildConfigurationSummaryDesc functions
		Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
		Mock(BuildConfigurationSummaryDesc).Return("summary description").Build()

		expected := `报价单[QUOTE123]存在如下重复报价项：1: 合同[CN202206229231158],商品[ECS],付费方式为[PrePay],配置分类为[summary description],配置[summary description],计费项分类[summary description],计费方式[BillingA],地域[summary description],计费单元[summary description],价格影响因子[FactorA],售卖模式[ModeA],预付比例[PrePayRatioA],承诺消费金额[CommitFeeIntervalA],购买时长[SpBuyDurationA]； 2: 合同[CN202206229231159],商品[RDS],付费方式为[PostPay],配置分类为[summary description],配置[summary description],计费项分类[summary description],计费方式[BillingB],地域[summary description],计费单元[summary description],价格影响因子[FactorB],售卖模式[ModeB],预付比例[PrePayRatioB],承诺消费金额[CommitFeeIntervalB],购买时长[SpBuyDurationB]； `
		actual := c.GenRepeatProductMsg(ctx, quoteID)
		So(actual, ShouldEqual, expected)
	})

	PatchConvey("Test GenRepeatProductMsg with special characters in fields", t, func() {
		c := ContractDiscountList{
			&ContractDiscount{
				ContractNo:                       "CN202206229231158",
				ProductName:                      "ECS",
				CanPrePay:                        "PrePay",
				ConfigurationCategory:            "CategoryA",
				ConfigurationName:                "ConfigA",
				ChargeItemTag:                    "TagA",
				BillingName:                      "BillingA",
				Region:                           "RegionA",
				ChargeElement:                    "ElementA",
				PriceFactor:                      `FactorA"`,
				SellingMode:                      `ModeA\`,
				ConfigurationCategoryExcludeName: "ExcludeCategoryA",
				ConfigurationExcludeName:         "ExcludeConfigA",
				ChargeItemTagExcludeName:         "ExcludeTagA",
				RegionExcludeName:                "ExcludeRegionA",
				ChargeElementExcludeName:         "ExcludeElementA",
				Extra: &DiscountExtra{
					SavingPlan: &SavingPlanInExtra{
						PrePayRatio:       "PrePayRatioA",
						SpBuyDuration:     "SpBuyDurationA",
						CommitFeeInterval: "CommitFeeIntervalA",
					},
				},
			},
		}

		// Mocking I18nFormat and BuildConfigurationSummaryDesc functions
		Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()

		expected := `报价单[QUOTE123]存在如下重复报价项：1: 合同[CN202206229231158],商品[ECS],付费方式为[PrePay],配置分类为[CategoryA（不包含 ExcludeCategoryA）],配置[ConfigA（不包含 ExcludeConfigA）],计费项分类[TagA（不包含 ExcludeTagA）],计费方式[BillingA],地域[RegionA（不包含 ExcludeRegionA）],计费单元[ElementA（不包含 ExcludeElementA）],价格影响因子[FactorA\"],售卖模式[ModeA\\],预付比例[PrePayRatioA],承诺消费金额[CommitFeeIntervalA],购买时长[SpBuyDurationA]； `
		actual := c.GenRepeatProductMsg(ctx, quoteID)
		So(actual, ShouldEqual, expected)
	})
}

func escapeRepeatMsg(raw string) string {
	raw = strings.ReplaceAll(raw, "\\", "\\\\")
	raw = strings.ReplaceAll(raw, "\"", "\\\"")
	return raw
}

func newTestDiscount(contractNo string) *ContractDiscount {
	return &ContractDiscount{
		ContractNo:            contractNo,
		ProductName:           "ECS",
		CanPrePay:             "PrePay",
		ConfigurationCategory: "Compute",
		ConfigurationName:     "General",
		ChargeItemTag:         "Usage",
		BillingName:           "Monthly",
		Region:                "cn-beijing",
		ChargeElement:         "Hour",
		PriceFactor:           "standard",
		SellingMode:           "Normal",
		Extra: &DiscountExtra{
			SavingPlan: &SavingPlanInExtra{
				PrePayRatio:       "50%",
				CommitFeeInterval: "100",
				SpBuyDuration:     "12M",
			},
		},
	}
}

func Test_ContractDiscountList_GenRepeatProductMsg_BitsUTGen(t *testing.T) {
	ctx := context001.Background()

	PatchConvey("Test_ContractDiscountList_GenRepeatProductMsg", t, func() {
		PatchConvey("Return empty string when all initial writes are empty", func() {
			MockUnsafe(multienv.I18nFormat).To(func(mockCtx context001.Context, v string) string {
				return ""
			}).Build()

			actual := (ContractDiscountList{}).GenRepeatProductMsg(ctx, "")

			So(actual, ShouldEqual, "")
		})

		PatchConvey("Return header only for empty list without mocks", func() {
			quoteID := "QUOTE-EMPTY"

			actual := (ContractDiscountList{}).GenRepeatProductMsg(ctx, quoteID)

			So(actual, ShouldEqual, "报价单[QUOTE-EMPTY]存在如下重复报价项：")
		})

		PatchConvey("Format flat duplicate items and escape special characters", func() {
			quoteID := `Q"01\X`
			item := newTestDiscount(`CN"01\A`)
			item.ProductName = `ECS"X\Y`
			item.PriceFactor = `factor"\path`
			item.SellingMode = `mode"\tier`

			list := ContractDiscountList{item}
			rawExpected := "报价单[" + quoteID + "]存在如下重复报价项：" +
				"1: 合同[" + item.ContractNo + "]," +
				item.formatDiscount(ctx) +
				"； "
			expected := escapeRepeatMsg(rawExpected)

			actual := list.GenRepeatProductMsg(ctx, quoteID)

			So(actual, ShouldEqual, expected)
		})

		PatchConvey("Format hierarchical duplicate items with child separators", func() {
			quoteID := "QUOTE-H"

			parent := newTestDiscount("CN-PARENT")
			parent.ProductName = "ParentProduct"
			parent.PriceFactor = "parent-factor"
			parent.SellingMode = "parent-mode"

			childOne := newTestDiscount("CN-CHILD-1")
			childOne.ProductName = "ChildOne"
			childOne.PriceFactor = "child-factor-1"
			childOne.SellingMode = "child-mode-1"

			childTwo := newTestDiscount("CN-CHILD-2")
			childTwo.ProductName = "ChildTwo"
			childTwo.PriceFactor = "child-factor-2"
			childTwo.SellingMode = "child-mode-2"

			parent.DeductList = []*ContractDiscount{childOne, childTwo}
			list := ContractDiscountList{parent}

			rawExpected := "报价单[" + quoteID + "]存在如下重复报价项：" +
				"1: 合同[" + parent.ContractNo + "],报价项" +
				parent.formatDiscount(ctx) +
				"，包含重复节省计划抵扣项：" +
				"(1.1) " + childOne.formatDiscount(ctx) + "； " +
				"(1.2) " + childTwo.formatDiscount(ctx) +
				"； "
			expected := escapeRepeatMsg(rawExpected)

			actual := list.GenRepeatProductMsg(ctx, quoteID)

			So(actual, ShouldEqual, expected)
		})
	})
}

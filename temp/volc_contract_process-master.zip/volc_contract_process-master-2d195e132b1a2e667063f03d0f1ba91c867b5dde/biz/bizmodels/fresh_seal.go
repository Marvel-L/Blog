package bizmodels

import (
	"context"
	"net/http"
	"strings"
	"unicode/utf8"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"

	"code.byted.org/gopkg/logs"
)

// FreshSealCreateParam 鲜章申请创建请求参数
type FreshSealCreateParam struct {
	AccountId      string      `json:"AccountId" query:"AccountId" binding:"required"` // 当前操作人账号，控制台请求默认从 header 取
	CopyCount      int         `json:"CopyCount" binding:"required"`                   // 盖章分数   0<邮寄分数<=3
	ContactName    string      `json:"ContactName" binding:"required"`                 // 联系人名称 字段长度小于<=10
	ContactPhone   string      `json:"ContactPhone" binding:"required"`                // 联系人电话 字段长度小于等于11，且为纯数字
	AddressInfo    AddressInfo `json:"AddressInfo" binding:"required"`                 // 地址信息
	ApplyReason    []Reason    `json:"ApplyReason" binding:"required"`                 // 申请原因
	ContractNoList string      `json:"ContractNoList" binding:"required"`              // 申请合同号列表，逗号分隔 最多50个
	BizScene       int         `json:"BizScene" binding:"required"`                    // 场景： 2-订单合同,3-产品报价合同, 4-信控合同, 7-代付合同

}

// ValidateCreate 验证创建请求参数
func (p *FreshSealCreateParam) ValidateCreate() errors.APIError {
	if p.AccountId == "" {
		return errors.ErrMissingParam.WithArgs("AccountId")
	}
	// 验证盖章分数：0 < 邮寄分数 <= 3
	if p.CopyCount <= 0 || p.CopyCount > 3 {
		return errors.ErrValidateParamErr.WithArgs("盖章分数必须在1-3之间")
	}
	// 验证联系人名称：字段长度小于等于10
	if p.ContactName == "" {
		return errors.ErrMissingParam.WithArgs("请填写邮寄联系人姓名")
	}
	if utf8.RuneCountInString(p.ContactName) > 10 {
		return errors.ErrValidateParamErr.WithArgs("请填写邮寄联系人姓名，最多10个字")
	}
	// 验证联系人电话：字段长度小于等于11，且为纯数字
	if p.ContactPhone == "" {
		return errors.ErrMissingParam.WithArgs("ContactPhone")
	}
	if len(p.ContactPhone) > 11 {
		return errors.ErrValidateParamErr.WithArgs("联系人电话长度不能超过11个字符")
	}
	for _, c := range p.ContactPhone {
		if c < '0' || c > '9' {
			return errors.ErrValidateParamErr.WithArgs("联系人电话必须为纯数字")
		}
	}
	// 验证地址信息
	if p.AddressInfo.Province == "" || p.AddressInfo.City == "" || p.AddressInfo.Region == "" || p.AddressInfo.Address == "" {
		return errors.ErrMissingParam.WithArgs("AddressInfo")
	}
	// 验证详细地址：最大长度200
	if utf8.RuneCountInString(p.AddressInfo.Address) > 200 {
		return errors.ErrValidateParamErr.WithArgs("详细地址长度不能超过200个字符")
	}
	// 验证申请原因
	if len(p.ApplyReason) == 0 {
		return errors.ErrMissingParam.WithArgs("ApplyReason")
	}
	// 验证每个申请原因的Code和Message不能为空
	for _, reason := range p.ApplyReason {
		if reason.Code == "" {
			return errors.ErrValidateParamErr.WithArgs("申请原因代码不能为空")
		}
		if reason.Message == "" {
			return errors.ErrValidateParamErr.WithArgs("申请原因描述不能为空")
		}
	}
	// 验证合同号列表：最多50个
	if p.ContractNoList == "" {
		return errors.ErrMissingParam.WithArgs("ContractNoList")
	}
	contractNoList := strings.Split(p.ContractNoList, ",")
	if len(contractNoList) > 50 {
		return errors.ErrValidateParamErr.WithArgs("合同号数量不能超过50个")
	}
	// 验证场景：只能是2-订单合同,3-产品报价合同,4-信控合同,7-代付合同
	validBizScenes := map[int]bool{
		_const.BizSceneTransactionContract: true,
		_const.BizSceneQuoteContract:       true,
		_const.BizSceneCreditContract:      true,
		_const.BizScenePayOnBehalf:         true,
	}
	if !validBizScenes[p.BizScene] {
		return errors.ErrValidateParamErr.WithArgs("不支持的业务场景")
	}
	return nil
}

// AddressInfo 地址信息
type AddressInfo struct {
	Province string `json:"Province" binding:"required"` // 省
	City     string `json:"City" binding:"required"`     // 市
	Region   string `json:"Region" binding:"required"`   // 区
	Address  string `json:"Address" binding:"required"`  // 详细地址 最大长度200
}

// Reason 申请原因
type Reason struct {
	Code    string `json:"Code" binding:"required"`    // 原因代码
	Message string `json:"Message" binding:"required"` // 原因描述
}

// FreshSealCreateResp 鲜章申请创建响应
type FreshSealCreateResp struct {
	ApplyNo string `json:"ApplyNo"` // 申请单号
}

// FreshSealDetailParam 鲜章申请详情查询请求参数
type FreshSealDetailParam struct {
	AccountId  string `json:"AccountId" query:"AccountId" binding:"required"` // 当前操作人账号，控制台请求默认从 header 取
	ApplyNo    string `json:"ApplyNo"  binding:"required"`                    // 申请单号
	ContractNo string `json:"ContractNo"  binding:"required"`                 // 合同号列表，逗号分隔
}

// ValidateDetail 验证查询请求参数
func (p *FreshSealDetailParam) ValidateDetail() errors.APIError {
	if p.AccountId == "" {
		return errors.ErrMissingParam.WithArgs("AccountId")
	}
	if p.ApplyNo == "" {
		return errors.ErrMissingParam.WithArgs("ApplyNo")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

// FreshSealApplyInfo 鲜章申请信息（通用结构体）
type FreshSealApplyInfo struct {
	ApplyId        string          `json:"ApplyId"`        // 申请ID
	AccountId      string          `json:"AccountId"`      // 当前操作人账号
	CopyCount      int             `json:"CopyCount"`      // 盖章分数
	ContactName    string          `json:"ContactName"`    // 联系人姓名
	ContactPhone   string          `json:"ContactPhone"`   // 联系人电话
	AddressInfo    AddressInfo     `json:"AddressInfo"`    // 地址信息
	ExpressCompany string          `json:"ExpressCompany"` // 快递公司
	ExpressNo      string          `json:"ExpressNo"`      // 快递单号
	ApplyReason    string          `json:"ApplyReason"`    // 申请原因
	ContractNo     string          `json:"ContractNo"`     // 申请单关联的所有合同号
	SubApplyList   []*SubApplyInfo `json:"SubApplyList"`   // 子申请列表
	Updater        string          `json:"Updater"`        // 更新人
	CreatedTime    string          `json:"CreatedTime"`    // 创建时间
	UpdatedTime    string          `json:"UpdatedTime"`    // 更新时间
	Status         int             `json:"Status"`         // 状态
}

// FreshSealDetailResp 鲜章申请详情查询响应
type FreshSealDetailResp *FreshSealApplyInfo

// SubApplyInfo 子申请信息
type SubApplyInfo struct {
	ID              uint64 `json:"ID"`              // ID
	SubApplyId      string `json:"SubApplyId"`      // 子申请ID
	ApplyId         string `json:"ApplyId"`         // 申请ID
	ContractId      string `json:"ContractId"`      // 合同ID
	ContractNo      string `json:"ContractNo"`      // 合同号
	BizSource       int    `json:"BizSource"`       // 业务来源
	SignSubjectName string `json:"SignSubjectName"` // 交易对方名称
	Operator        string `json:"Operator"`        // 操作人email
	CreatedTime     string `json:"CreatedTime"`     // 创建时间
	UpdatedTime     string `json:"UpdatedTime"`     // 更新时间
	Status          int    `json:"Status"`          // 状态
	OperatorName    string `json:"OperatorName"`    //  操作人姓名
}

// FreshSealBatchUpdateExpressParam 鲜章申请单批量更新邮寄信息请求参数
type FreshSealBatchUpdateExpressParam struct {
	CurrentOperator string         `json:"CurrentOperator" query:"CurrentOperator"` //当前操作人
	ExpressDataList []*ExpressData `json:"ExpressDataList" binding:"required"`      // 邮寄信息列表
}

// ValidateBatchUpdateExpress 验证批量更新邮寄信息参数
func (p *FreshSealBatchUpdateExpressParam) ValidateBatchUpdateExpress(ctx context.Context) errors.APIError {
	// 验证当前操作人不能为空
	if p.CurrentOperator == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	// 验证邮寄信息列表不能为空
	length := len(p.ExpressDataList)
	if p.ExpressDataList == nil || length == 0 {
		return errors.ErrMissingParam.WithArgs("ExpressDataList")
	}
	if length > 200 {
		return errors.NewErr("InvalidParam", "单次最多导入200条", http.StatusBadRequest)
	}
	return nil
}

// ExpressData 邮寄信息结构
type ExpressData struct {
	ApplyNo        string `json:"ApplyNo" binding:"required"`        // 申请单号
	ExpressCompany string `json:"ExpressCompany" binding:"required"` // 邮寄公司code- 快递公司code 验证是数字
	ExpressNo      string `json:"ExpressNo" binding:"required"`      // 邮寄单号
	Remark         string `json:"Remark" binding:"omitempty"`        // 备注信息，用于传入变更原因(变更时必填)
}

// FreshSealListOperationRecordParam 鲜章申请单操作记录查询请求参数
type FreshSealListOperationRecordParam struct {
	ApplyNo string `json:"ApplyNo" binding:"required"`             // 申请单编号，可选 （应该是必填项）
	Limit   int    `json:"Limit" binding:"omitempty" default:"10"` // 分页大小，可选，
	Offset  int    `json:"Offset" binding:"omitempty" default:"0"` // 分页偏移量，可选
}

func (p *FreshSealListOperationRecordParam) ValidateFreshSealListOperationRecordParam() errors.APIError {
	if p.ApplyNo == "" {
		return errors.ErrMissingParam.WithArgs("ApplyNo")
	}
	// 验证分页大小和偏移量是否为非负数
	if p.Limit <= 0 || p.Offset < 0 {
		return errors.ErrValidateParamErr.WithArgs("Limit and Offset must be non-negative integers")
	}
	return nil
}

// FreshSealOperationRecord 鲜章申请单操作记录
type FreshSealOperationRecord struct {
	ID            uint64 `json:"ID"`            // 记录ID
	LogId         string `json:"LogId"`         // 日志ID
	ApplyId       string `json:"ApplyId"`       // 申请单ID
	Operator      string `json:"Operator"`      // 操作人
	OperationType int    `json:"OperationType"` // 操作类型
	Content       string `json:"Content"`       // 操作内容
	Remark        string `json:"Remark"`        // 备注
	Status        int    `json:"Status"`        // 状态
	CreatedTime   string `json:"CreatedTime"`   // 创建时间
	UpdatedTime   string `json:"UpdatedTime"`   // 更新时间
}

// FreshSealListOperationRecordResp 鲜章申请单操作记录查询响应
type FreshSealListOperationRecordResp struct {
	List   []*FreshSealOperationRecord `json:"List"`   // 操作记录列表
	Total  int                         `json:"Total"`  // 总记录数
	Limit  int                         `json:"Limit"`  // 分页大小
	Offset int                         `json:"Offset"` // 分页偏移量
}

// FreshSealListParam 鲜章申请单列表查询请求参数
type FreshSealListParam struct {
	ContractNo      string `json:"ContractNo" query:"ContractNo" form:"ContractNo"` // 合同编号(单个)
	AccountID       string `json:"AccountID" form:"AccountID"`                      // 客户账号ID
	Status          string `json:"Status" form:"Status"`                            // 申请单状态，多个参数逗号分割 1已申请, 2已邮寄
	Limit           int    `json:"Limit" form:"Limit" default:"10"`                 // 每页数量，默认10
	Offset          int    `json:"Offset" form:"Offset" default:"0"`                // 偏移量
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"`         //当前操作人
	ApplyNos        string `json:"ApplyNos" form:"ApplyNos"`                        // 申请单编号(多个逗号分隔)
	Extra           string `json:"Extra" form:"Extra"`                              // 扩展参数，用于传入额外的查询条件
}

// Validate 参数验证
func (p *FreshSealListParam) Validate(ctx context.Context) errors.APIError {
	// Limit参数验证：必须大于0，且有合理上限
	if p.Limit <= 0 { //todo 上线限制？
		return errors.ErrInvalidParam.WithArgs("Limit")
	}

	// Offset参数验证：必须大于等于0
	if p.Offset < 0 {
		return errors.ErrInvalidParam.WithArgs("Offset")
	}

	// Status参数验证：如果提供，必须是1或2，多个用逗号分割
	if len(p.Status) > 0 {
		statusList, err := util.SplitInt(p.Status, ",")
		if err != nil {
			logs.CtxError(ctx, "FreshSealListParamFail, err: %s", err.Error())
			return errors.ErrInvalidParam.WithArgs("Status")
		}
		for _, status := range statusList {
			if _, ok := _const.FreshSealApprovalStatusMap[status]; !ok {
				return errors.ErrInvalidParam.WithArgs("Status")
			}
		}
	}

	// AccountID参数验证：如果提供，必须大于0
	if p.AccountID != "" {
		if _, err := util.StringToInt64(p.AccountID); err != nil {
			logs.CtxError(ctx, "FreshSealListParamFail, AccountID, err: %s", p.AccountID, err.Error())
			return errors.ErrInvalidParam.WithArgs("AccountID")
		}

	}

	return nil
}

// FreshSealListResp 鲜章申请单列表查询响应
type FreshSealListResp struct {
	List   []*FreshSealApplyInfo `json:"List"`   // 申请单列表
	Total  int64                 `json:"Total"`  // 总数
	Limit  int                   `json:"Limit"`  // 每页数量
	Offset int                   `json:"Offset"` // 偏移量
}

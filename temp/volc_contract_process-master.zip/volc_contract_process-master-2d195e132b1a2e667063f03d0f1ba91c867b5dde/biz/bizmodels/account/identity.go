package account

type IdentityInfo struct {
	IdentityType   int
	DocumentCode   string
	CountryCodeTwo string // 国家地区二字码
	Country        string // 国家地区
	CustomerName   string // 昵称
}

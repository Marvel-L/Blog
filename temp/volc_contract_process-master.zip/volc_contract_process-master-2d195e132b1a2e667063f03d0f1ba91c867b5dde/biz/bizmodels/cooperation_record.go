package bizmodels

type ContractOperationRecord struct {
	Operator               string        //
	OperatorName           string        `json:"OperatorName,omitempty"` //
	Operation              int           //
	SecondaryOperationType int           //
	ContractStatus         int           //
	Remark                 string        //
	CommentID              int           //
	Comment                *RichTextInfo //
	Extra                  string        //
	OperateTime            string        //
	RelatedFileVersion     string        // 合同关联文件版本信息
	SendBackTargetStatus   int           // 指定退回目标节点状态
}

type ContractOperationRecordList []*ContractOperationRecord

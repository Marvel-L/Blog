package bizmodels

// ChangeQuoteExtra 修改报价单扩展信息
type ChangeQuoteExtra struct {
	QuoteID                 string `json:"QuoteID"`                 //
	IgnorePriceRepeatReturn bool   `json:"IgnorePriceRepeatReturn"` //
}

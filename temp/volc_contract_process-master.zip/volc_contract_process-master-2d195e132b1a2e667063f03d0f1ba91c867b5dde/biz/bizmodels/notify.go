package bizmodels

type NotifyParam struct {
	AccountID    int64  `json:"AccountID"`
	ContractNo   string `json:"ContractNo"`
	CustomerName string `json:"CustomerName"`
	Identifier   string `json:"Identifier"`
	AbortTime    string `json:"AbortTime"`
	ProductLine  string `json:"ProductLine"`
}

// NotifyContext 通知上下文
type NotifyContext struct {
	ProductLine string `json:"ProductLine"`
}

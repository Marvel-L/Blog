package bizmodels

import (
	"context"
	"encoding/json"
	"strings"

	_const "volc_contract_process/pkg/const"

	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"
)

type BizData interface {
	IsBizIdentifier()
}

type baseBizData struct {
}

func (b baseBizData) IsBizIdentifier() {
}

// BizDataCreditApply 信控业务信息
type BizDataCreditApply struct {
	baseBizData
	Creator     string          `json:"Creator"`
	CreditType  string          `json:"CreditType"`
	CreditLimit decimal.Decimal `json:"CreditLimit"`
}

type BizDataQuoteV1 map[string]interface{}

func (b BizDataQuoteV1) IsBizIdentifier() {
}

func ParseBizData(ctx context.Context, bizScene int, bizSource int, data string) BizData {
	if bizScene == _const.BizSceneCreditContract && bizSource == _const.BizSourceCredit {
		var ret BizDataCreditApply
		if err := json.Unmarshal([]byte(data), &ret); err != nil {
			logs.CtxError(ctx, "parse_credit_biz_data_fail, data=%s, err=%s", data, err.Error())
			return nil
		}
		return &ret
	} else if bizScene == _const.BizSceneQuoteContract && bizSource == _const.BizSourceQuote {
		// 首先尝试解析为新数据格式 兼容逻辑
		if strings.Contains(data, "ProductSolutionEmail") {
			var ret BizInfoQuote
			if err := json.Unmarshal([]byte(data), &ret); err != nil {
				logs.CtxError(ctx, "parse_quote_biz_data_fail, data=%s, err=%s", data, err.Error())
				return nil
			}
			return ret
		} else {
			var ret BizDataQuoteV1
			if err := json.Unmarshal([]byte(data), &ret); err != nil {
				logs.CtxError(ctx, "parse_quote_biz_data_fail, data=%s, err=%s", data, err.Error())
				return nil
			}
			return ret
		}
	} else if bizScene == _const.BizScenePartnerContract /*&& bizSource == _const.BizSourcePartner*/ {
		// 首先尝试解析为新数据格式 兼容逻辑 // 伙伴合同新增bizSource 没有基于此字段做特殊处理 暂时跳过
		var ret BizInfoPartner
		if err := json.Unmarshal([]byte(data), &ret); err != nil {
			logs.CtxError(ctx, "parse_partner_biz_data_fail, data=%s, err=%s", data, err.Error())
			return nil
		}
		return ret

	}
	return nil
}

package bizmodels

import (
	"code.byted.org/videoarch/cloud_gopkg/peopleclient"

	_const "volc_contract_process/pkg/const"
)

type InnerPageParam struct {
	Limit  int `json:"limit" query:"Limit"`   //
	Offset int `json:"offset" query:"Offset"` //
}

// MetaListParam 合同列表查询
type MetaListParam struct {
	SourceType              _const.SourceType
	IsManager               bool   `json:"IsManager" query:"IsManager"`
	CurrentOperator         string `json:"CurrentOperator" query:"CurrentOperator"`             //
	BizSceneList            string `json:"BizSceneList" query:"BizSceneList"`                   //
	BizSourceList           string `json:"BizSourceList" query:"BizSourceList"`                 //
	SupplyScene             string `json:"SupplyScene" query:"SupplyScene"`                     //
	CooperationStatusList   []int  `json:"CooperationStatusList" query:"CooperationStatusList"` //
	ActiveStatusList        []int  `json:"ActiveStatusList" query:"ActiveStatusList"`           //
	StatusList              string `json:"StatusList" query:"StatusList"`                       // 合同状态列表
	BizAccountID            int    `query:"BizAccountID"`                                       //
	BizScene                int    `json:"BizScene" query:"BizScene"`                           //
	TabScene                int    `json:"TabScene" query:"TabScene"`                           // 1-待我处理  2-我已处理
	BizSource               int    `json:"BizSource" query:"BizSource"`                         //
	InProcess               int    `json:"InProcess" query:"InProcess"`                         //
	VolcContractNo          string `json:"VolcContractNo" query:"VolcContractNo"`               // 火山合同号
	ContractNo              string `json:"ContractNo" query:"ContractNo"`                       //
	ContractNoList          string `json:"ContractNoList" query:"ContractNoList"`               //
	ContractName            string `json:"ContractName" query:"ContractName"`                   //
	SubjectName             string `json:"SubjectName" query:"SubjectName"`                     //
	OtherPartyName          string `json:"OtherPartyName" query:"OtherPartyName"`               //
	PropertyCode            string `json:"PropertyCode" query:"PropertyCode"`                   // 合同性质
	CategoryNo              string `json:"CategoryNo" query:"CategoryNo"`                       // 合同类型
	InOutType               string `json:"InOutType" query:"InOutType"`                         // 收支类型
	Initiator               int    `json:"Initiator" query:"Initiator"`                         // 发起端
	CooperationStatus       *int   `json:"CooperationStatus" query:"CooperationStatus"`         // 协商状态
	ArchivedStatus          *int   `json:"ArchivedStatus" query:"ArchivedStatus"`               // 归档状态
	ActiveStatus            *int   `json:"ActiveStatus" query:"ActiveStatus"`                   // 生效状态
	Status                  *int   `json:"Status" query:"Status"`                               // 合同状态
	Operator                int64  `json:"Operator" query:"Operator"`                           //
	RelatedPersonnel        int64  `json:"RelatedPersonnel" query:"RelatedPersonnel"`           // 合同相关人
	Creator                 int64  `json:"Creator" query:"Creator"`                             //
	CreatedTimeBegin        string `json:"CreatedTimeBegin" query:"CreatedTimeBegin"`           //
	CreatedTimeEnd          string `json:"CreatedTimeEnd" query:"CreatedTimeEnd"`               //
	ValidityBegin           string `json:"ValidityBegin" query:"ValidityBegin"`                 //
	ValidityEnd             string `json:"ValidityEnd" query:"ValidityEnd"`                     //
	SubmitTimeBegin         string `json:"SubmitTimeBegin" query:"SubmitTimeBegin"`             //
	SubmitTimeEnd           string `json:"SubmitTimeEnd" query:"SubmitTimeEnd"`                 //
	FileTimeBegin           string `json:"FileTimeBegin" query:"FileTimeBegin"`                 //
	FileTimeEnd             string `json:"FileTimeEnd" query:"FileTimeEnd"`                     //
	PrincipalParty          string `json:"PrincipalParty" query:"PrincipalParty"`               // 委托方-主体名称
	EntrustedParty          string `json:"EntrustedParty" query:"EntrustedParty"`               // 被委托方-主体名称
	OrderBy                 int    `json:"OrderBy" query:"OrderBy"`                             //
	Limit                   int    `json:"limit" query:"Limit" default:"10"`                    //
	Offset                  int    `json:"offset" query:"Offset"`                               //
	StartId                 uint64 // 起始ID
	NeedCalcCooperationRole bool   //
	CurrentOperatorUID      int64  // 当前操作人对应的工号
	// NeedQueryManageInfo     bool   //
	Extra               string `json:"Extra" query:"Extra"`
	SpecialContractType string `json:"SpecialContractType" query:"SpecialContractType"` // 特殊合同类型，目前只支持单值查询
	UseManageInfo       bool   `json:"UseManageInfo" query:"UseManageInfo"`             // 是否需要返回管理信息
	UseSettlementInfo   bool   `json:"UseSettlementInfo" query:"UseSettlementInfo"`     // 是否需要返回结算信息
	UseTradePartyInfo   bool   `json:"UseTradePartyInfo" query:"UseTradePartyInfo"`     // 是否需要返回交易双方信息
	UseProjectInfo      bool   `json:"UseProjectInfo" query:"UseProjectInfo"`           // 是否需要返回项目信息
	IsMultiApply        int    `query:"IsMultiApply"`                                   // 批量申请鲜章 0-否 1-是

	// 「合同查询条件&列表内容调整」新增筛选条件
	BusinessMode    string `json:"BusinessMode" query:"BusinessMode"`       // 商务模式，多选逗号分隔，命中合同需包含全部选中值
	TradeProduct    string `json:"TradeProduct" query:"TradeProduct"`       // 商品英文名唯一标识，多选逗号分隔，命中合同需包含全部选中值
	MainContractNo  string `json:"MainContractNo" query:"MainContractNo"`   // 主合同号
	OpportunityName string `json:"OpportunityName" query:"OpportunityName"` // 商机名称，左精准右模糊
	OpportunityID   string `json:"OpportunityID" query:"OpportunityID"`     // 商机ID，左精准右模糊
	ProjectCode     string `json:"ProjectCode" query:"ProjectCode"`         // 项目编号，来源 ProjectInfo.ProjectCode
	DepartmentId    string `json:"DepartmentId" query:"DepartmentId"`       // 归属行业ID，来源 BasicInfo.DepartmentId，多选逗号分隔，任一选中值命中即可
	BusinessType    string `json:"BusinessType" query:"BusinessType"`       // 业务类型，多选逗号分隔，来源 BasicInfo.BusinessType，任一选中值命中即可
	SupplySource    string `json:"SupplySource" query:"SupplySource"`       // 补充场景
	WhetherProject  string `json:"WhetherProject" query:"WhetherProject"`   // 是否项目制 Y:是 N:否
	SignatureType   string `json:"SignatureType" query:"SignatureType"`     // 签约形式
	RelateQuoteNo   string `json:"RelateQuoteNo" query:"RelateQuoteNo"`     // 关联报价单号，左精准右模糊

}

type ContractMetaItem struct {
	ID                   uint64                   // 主键 ID
	ContractNo           string                   `json:"ContractNo"`           // 合同号
	VolcContractNo       string                   `json:"VolcContractNo"`       // 火山合同号
	Version              int                      `json:"Version"`              // 合同版本
	BizScene             int                      `json:"BizScene"`             // 业务场景
	SupplyScene          int                      `json:"SupplyScene"`          // 补充协议类型
	SupplySource         string                   `json:"SupplySource"`         // 补充协议场景
	BizIdentifier        string                   `json:"BizIdentifier"`        // 业务唯一标识
	ContractName         string                   `json:"ContractName"`         // 合同名称
	SubjectName          string                   `json:"SubjectName"`          // 我方主体名称
	OtherPartyName       string                   `json:"OtherPartyName"`       // 对方主体名称
	PropertyCode         string                   `json:"PropertyCode"`         // 合同性质
	CategoryNo           string                   `json:"CategoryNo"`           // 合同类型
	InOutType            string                   `json:"InOutType"`            // 收支类型
	BizSource            int                      `json:"BizSource"`            // 合同来源
	Initiator            int                      `json:"Initiator"`            // 发起端
	CooperationStatus    int                      `json:"CooperationStatus"`    // 协商状态
	PreCooperationStatus int                      `json:"PreCooperationStatus"` // 前序协商状态
	Status               int                      `json:"Status"`               // 合同状态
	ArchivedStatus       int                      `json:"ArchivedStatus"`       // 归档状态
	ActiveStatus         int                      `json:"ActiveStatus"`         // 生效状态
	Operator             int64                    `json:"Operator"`             // 业务执行人
	Creator              int64                    `json:"Creator"`              // 创建人
	BeginTime            string                   `json:"BeginTime"`            // 有效期开始时间
	EndTime              string                   `json:"EndTime"`              // 有效期结束时间
	FinishTime           string                   `json:"FinishTime"`           // 归档时间
	SignTime             string                   `json:"SignTime"`             // 签订时间
	FileTime             string                   `json:"FileTime"`             // 归档时间
	BasicInfo            *BasicInfo               `json:"BasicInfo"`            // 基本信息
	ContractID           string                   `json:"ContractId"`           // 飞书合同ID
	CreatedTime          string                   `json:"CreatedTime"`          // 创建时间
	SubmitTime           string                   `json:"SubmitTime"`           // 提交时间
	BizData              string                   `json:"BizData"`              // 业务数据
	AccountID            string                   `json:"AccountID"`            // 账号ID
	BizAccountID         int64                    `json:"BizAccountID"`         // 业务账号ID
	SubjectAccountIDs    string                   `json:"SubjectAccountIDs"`    // 合同关联账号ID 列表
	SealAccountIDs       string                   `json:"SealAccountIDs"`       // 签约账号列表
	PricingAccountIDs    string                   `json:"PricingAccountIDs"`    // 配价账号列表
	TradePartyInfo       *TradePartyInfo          `json:"TradePartyInfo"`       // 交易双方信息
	ManageInfo           *ManageInfo              `json:"ManageInfo"`           // 管理信息
	ProjectInfo          *ProjectInfo             `json:"ProjectInfo"`          // 项目信息
	UrgentInfo           *UrgentInfo              `json:"UrgentInfo"`           // 加急信息
	ExpireRemindInfo     *ExpireRemindInfo        `json:"ExpireRemindInfo"`     // 到期提醒信息
	SettlementInfo       *SettlementInfo          `json:"SettlementInfo"`       // 结算信息
	Remark               string                   `json:"Remark"`               // 备注
	Product              string                   `json:"Product"`              // 商品
	AccountInfoList      []*AccountInfo           `json:"AccountInfoList"`      // 账号信息
	EmployeeList         []*peopleclient.Employee `json:"EmployeeList"`         // 关联用户 people 信息
	ReviewerRole         int                      `json:"ReviewerRole"`         // 审批角色
	CanApproval          bool                     `json:"CanApproval"`          // 是否可以审批
	Reviewers            PreContractReviewerList  `json:"Reviewers"`            // 审批人列表
	CurrentReviewSource  int                      `json:"CurrentReviewSource"`  // 当前操作人审核来源
	ReviewStatus         int                      `json:"ReviewStatus"`         // 审批状态
	RelateQuoteNo        string                   `json:"RelateQuoteNo"`        // 关联报价单号
	RelateQuoteScene     int                      `json:"RelateQuoteScene"`     // 关联报价单场景
	PrincipalParty       string                   `json:"PrincipalParty"`       // 委托方
	EntrustedParty       string                   `json:"EntrustedParty"`       // 被委托方
	IsUrgent             int                      `json:"IsUrgent"`             // 是否加急
	ExpireRemindFlag     int                      `json:"ExpireRemindFlag"`
	FreshSealApprovalNo  string                   `json:"FreshSealApprovalNo"` // 申请单号
	TemplateInfo         *TemplateInfo            `json:"TemplateInfo"`        // 模板信息

	// 「合同查询条件&列表内容调整」列表新增展示字段
	MainContractNo string `json:"MainContractNo"` // 主合同号
	ContractIncome string `json:"ContractIncome"` // 合同收入金额展示值
}

type AccountInfo struct {
	AccountID    int64  `json:"AccountID"`    // 账号ID
	CustomerName string `json:"CustomerName"` // 客户名称
	Identity     string `json:"Identity"`     // 认证名称
	CreateSource int    `json:"CreateSource"` // 账号创建来源
}

type MetaListResp struct {
	List   []*ContractMetaItem
	Total  int
	Limit  int
	Offset int
}

type SupplyContractListResp struct {
	FromContractHasSupply bool              `json:"FromContractHasSupply"`  // 原合同是否已发起过补充协议
	ParentContractList    []string          `json:"ParentContractList"`     // 父级补充协议链合同号
	FromContract          *ContractMetaInfo `json:"FromContract,omitempty"` // 原合同信息
	MainContract          *ContractMetaInfo `json:"MainContract,omitempty"` // 主合同信息
	LastContract          *ContractMetaInfo `json:"LastContract,omitempty"` // 最新版本补充协议合同信息
	EffectiveQuoteNo      string            `json:"EffectiveQuoteNo"`       // 当前生效报价单号
	VolcHistory           []*SupplyInfo     `json:"VolcHistory"`            // 火山合同中心补充协议列表
	OAHistory             []*SupplyInfo     `json:"OAHistory"`              // OA补充协议
}

type HistorySupplyContractListResp struct {
	IsShowSupplyWin bool
	VolcHistory     []*SupplyInfo `json:"VolcHistory"` // 火山合同中心补充协议列表
	OAHistory       []*SupplyInfo `json:"OAHistory"`   // OA补充协议
}

type SupplyInfo struct {
	ContractNo                 string //
	VolcContractNo             string // 火山补充合同号
	FromContractNo             string
	ContractName               string //
	SupplyScene                int    //
	SupplySource               string //
	SubmitTime                 string // 提交日期
	FromContractTerminatedTime string // 原协议终止日期
	CooperationStatus          int    //
	PreCooperationStatus       int    // 前序协商状态
	Status                     int    //
	OAContractDownloadID       string // OA扫描版合同-已盖章
	UploadContractDownloadID   string // 用户上传原始合同
	ArchivedStatus             int    //
	RelateQuoteNo              string
	RelateQuoteScene           int    // 关联报价单场景
	FileTime                   string // 归档日期
	SupplyEstablish            bool   // 补充关系建立
	BeginTime                  string // 有效期开始时间 2006-01-02 15:04:05
	EndTime                    string // 有效期结束时间 2006-01-02 15:04:05
	// DownloadID                 string //
}

type ContractListResp struct {
	List   []*ContractMetaItem
	Total  int
	Limit  int
	Offset int
}

package modelmetaext

import "volc_contract_process/pkg/errors"

type GetMetaExtReq struct {
	ContractNo string   `json:"ContractNo"`
	AttrKeys   []string `json:"AttrKeys"`
}

func (r *GetMetaExtReq) Validate() errors.APIError {
	if len(r.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

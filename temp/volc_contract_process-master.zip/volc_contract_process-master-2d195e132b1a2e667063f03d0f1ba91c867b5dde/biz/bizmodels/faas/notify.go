package faas

// 请求入参
type NotifyParam struct {
	ContractNos string `json:"ContractNos" form:"ContractNos" query:"ContractNos"`
	CreatorID   int64  `json:"CreatorID" form:"CreatorID" query:"CreatorID"`
	PDate       string `json:"PDate" form:"PDate" query:"PDate"`
}

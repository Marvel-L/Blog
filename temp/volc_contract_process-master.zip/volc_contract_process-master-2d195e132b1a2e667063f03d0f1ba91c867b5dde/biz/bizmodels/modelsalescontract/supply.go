package modelsalescontract

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type SupplyReq struct {
	ContractNo      string
	Creator         string
	SourceType      _const.SourceType
	CurrentOperator string
}

type SupplyResp struct {
	Url string
}

func (p *SupplyReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if p.Creator == "" {
		return errors.ErrMissingParam.WithArgs("Creator")
	}
	return nil
}

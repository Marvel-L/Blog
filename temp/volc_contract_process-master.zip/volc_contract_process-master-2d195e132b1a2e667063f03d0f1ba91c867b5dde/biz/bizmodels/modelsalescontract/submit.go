package modelsalescontract

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/riskenginecli"
)

type SubmitReq struct {
	ContractNo      string
	ReSubmit        string
	CurrentOperator string
	SourceType      _const.SourceType
}

type SubmitResp struct {
	ContractNo     string
	ComplianceInfo *riskenginecli.ComplianceCheckInfo
}

func (p *SubmitReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

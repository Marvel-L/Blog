package modelsalescontract

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type ListProductOfContractReq struct {
	ContractNo string
	//Version         int `default:"-1"`
	AccountID       string
	SourceType      _const.SourceType
	CurrentOperator string
}

func (p *ListProductOfContractReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

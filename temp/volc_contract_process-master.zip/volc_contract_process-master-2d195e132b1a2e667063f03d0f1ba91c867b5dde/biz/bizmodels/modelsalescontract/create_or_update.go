package modelsalescontract

import (
	"context"
	"strconv"
	"strings"

	"code.byted.org/gopkg/logs"

	"volc_contract_process/biz/service/basicinfo"
	"volc_contract_process/biz/service/support/metacommodity"
	"volc_contract_process/pkg/proxy/accountcli"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/larkc"
	"volc_contract_process/pkg/util"
)

type CreateOrUpdateReq struct {
	SourceType          _const.SourceType               // 请求方式
	CurrentOperator     string                          // 当前操作人
	ContractNo          string                          // 合同编号
	SupplyScene         int                             // 补充协议分类
	SupplySource        string                          // 补充场景
	Creator             string                          // 合同创建人
	TemplateKey         string                          // 模板key
	TemplateVersion     int                             // 模板版本
	ContractFile        string                          // 合同文件
	ContractAttachment  []bizmodels.MetaAttachment      // 合同附件
	BasicInfo           *bizmodels.BasicInfo            // 基本信息
	ProjectInfo         bizmodels.ProjectInfo           // 项目信息
	ManageInfo          bizmodels.ManageInfo            // 管理信息
	TradePartyInfo      bizmodels.TradePartyInfo        // 交易方信息
	SettlementInfo      bizmodels.SettlementInfo        // 结算信息
	BusinessModeClauses []*bizmodels.BusinessModeClause // 商务模式条款摘要
	DiscountInfo        []bizmodels.DiscountInfo        // 优惠信息
	ReverseSignInfo     bizmodels.ReverseSignInfo       // 倒签信息
	Ext                 map[string]string               // 扩展信息
}

type CreateOrUpdateResp struct {
	ContractNo string
}

func (p *CreateOrUpdateReq) BaseValidate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.BasicInfo == nil {
		return errors.ErrMissingParam.WithArgs("BasicInfo")
	}
	return nil
}

// 前置校验
func (p *CreateOrUpdateReq) PreValidate(ctx context.Context, meta *model.ContractMetaDB) error {
	if err := p.BaseValidate(); err != nil {
		logs.CtxError(ctx, "BaseValidateFail, err:%v", err)
		return err
	}
	//  校验一个合同中，同一个商品的开票项目一致
	if err := p.ManageInfo.ValidateProductHasSameInvoice(ctx); err != nil {
		return err
	}
	// 税率的验证
	if err := metacommodity.ValidateInvoiceTaxRateForManageInfo(ctx, &p.ManageInfo, meta.RelateQuoteNo); err != nil {
		return err
	}

	//  校验同一组别下，开票比例和付款比例之和是否等于100
	if err := p.SettlementInfo.SettlementLines.Validate(ctx); err != nil {
		return err
	}

	// 合同有效期基本校验
	if err := p.BasicInfo.ValidateContractPeriod(ctx, meta.Status); err != nil {
		return err
	}

	if err := contractmeta.NewMetaServiceV2().AccountNameAndPartyNameCheck(ctx, meta); err != nil {
		return err
	}

	// 校验交易双方信息
	if meta.Status == _const.SalesContractUnSubmit || meta.Status == _const.SalesContractRejected {
		// todo:兼容逻辑，OA合同详情接口查询不到签约关键字，已提交合同可能存在签约关键字为空的场景。非提交场景不校验签约关键字。
		if err := p.validateTradePartyInfo(ctx); err != nil {
			return err
		}

		// 选择电子签的场景，印章类型强制匹配必须为12
		signType, ok := _const.EleSignatureTypeMap[p.BasicInfo.SignatureType]
		if ok {
			if p.BasicInfo.SealType != signType {
				errStr := i18nfmt.Sprintf(ctx, "req.SealType:%s, fetch.SealType:%s", p.BasicInfo.SealType, signType)
				larkc.Warning("销售合同-印章类型异常", errStr)
				p.BasicInfo.SealType = signType
			}
		}

		// 是否项目制字段必填
		if len(p.BasicInfo.WhetherProject) == 0 {
			logs.CtxInfo(ctx, "是否项目制字段必填，WhetherProject：%s", p.BasicInfo.WhetherProject)
			return errors.ErrMissingParam.WithArgs("WhetherProject")
		}
		// 签约方式校验
		if err := p.validateSignatureType(ctx); err != nil {
			logs.CtxInfo(ctx, "validateSignatureTypeFail, err:%s", err.Error())
			return errors.ErrMissingParam.WithArgs(multienv.I18nFormat(ctx, err.Error()))
		}

		// 关联报价单的校验逻辑
		if len(p.ContractNo) > 0 && len(meta.RelateQuoteNo) > 0 {
			// 关联报价单 是否项目制需与报价单一致
			if len(p.ManageInfo.WhetherProject) > 0 && p.BasicInfo.WhetherProject != p.ManageInfo.WhetherProject {
				return errors.ErrorCommon.WithArgs("关联报价单合同，合同是否项目制字段需与报价单保持一致")
			}
		}
	}

	// 关联报价单的校验逻辑
	if len(p.ContractNo) > 0 && len(meta.RelateQuoteNo) > 0 {
		// 特殊合同类型处理，关联报价单合同，报价单解析出的特殊合同类型不允许删除
		p.BasicInfo.SpecialContractType = basicinfo.ClacQuoteSpecialContractType(ctx,
			meta.RelateQuoteNo,
			meta.RelateQuoteNo,
			meta.SpecialContractType,
			p.BasicInfo.SpecialContractType)
		// 校验合同关联账号
		// 合同创建草稿时：不校验
		// 合同正常更新时：校验账号
		// 合同更换报价单时：会命中校验，需明确是否存在账号更新，当前交易双方信息中的账号信息还是源报价单的配置
		if meta.BizScene == _const.BizSceneSalesContract && meta.BizSource == _const.BizSourceCooperation {
			if err := p.validateQuoteRelateAccountId(ctx, meta); err != nil {
				logs.CtxError(ctx, "报价单关联账号校验失败，err:%v", err)
				return errors.ErrorCommon.WithArgs(err.Error())
			}
			// 需校验账号分组信息
			if err := p.validateProductGroup(ctx); err != nil {
				logs.CtxError(ctx, "validateProductGroupFail, err:%v", err)
				return err
			}
		}
	}
	// 补充协议
	if p.SupplyScene == _const.SupplySceneVolc {
		if err := p.validateSupplySource(ctx, meta); err != nil {
			return err
		}
		if err := p.validateTermChangeDetail(ctx, meta); err != nil {
			return err
		}
	}

	return nil
}

func (p *CreateOrUpdateReq) validateSupplySource(ctx context.Context, meta *model.ContractMetaDB) (err error) {
	// 补充场景为空时
	if meta.SupplyScene != _const.SupplySceneVolc {
		logs.CtxInfo(ctx, "合同非补充协议")
		return nil
	}
	for _, source := range meta.GetSupplySource() {
		// 补充场景只允许在原有基础上新增或删除条款变更 除条款变更外其他补充场景不允许删除
		if source != _const.SupplySourceTermChange && !util.StringIn(source, strings.Split(p.SupplySource, ",")) {
			return errors.ErrInternalError.WithArgs("补充场景只允许在原有基础上新增或删除条款变更")
		}
	}
	return nil
}

// validateTermChangeDetail 条款变更字段校验
func (p *CreateOrUpdateReq) validateTermChangeDetail(ctx context.Context, meta *model.ContractMetaDB) error {
	// 补充场景为空时
	if meta.SupplyScene != _const.SupplySceneVolc {
		logs.CtxInfo(ctx, "合同非补充协议")
		return nil
	}
	// 补充场景不包含条款变更
	if !util.StringIn(_const.SupplySourceTermChange, strings.Split(p.SupplySource, ",")) {
		logs.CtxInfo(ctx, "合同补充场景不包含条款变更")
		return nil
	}
	if termChangeDetail, ok := p.Ext[_const.ExtKeyTermChangeDetail]; !ok || len(termChangeDetail) == 0 {
		logs.CtxError(ctx, "合同补充场景包含条款变更，条款变更详情必填。")
		return errors.ErrInternalError.WithArgs("合同补充场景包含条款变更，条款变更详情必填。")
	}
	return nil
}

func (p *CreateOrUpdateReq) validateQuoteRelateAccountId(ctx context.Context, entity *model.ContractMetaDB) error {
	logs.CtxInfo(ctx, "validateQuoteRelateAccountId, volcContractId:%d", entity.Id)
	// 未创建状态、已退回 跳过账号校验
	// if utils.IntIn(entity.Status, []int{_const.PreSalesContractNotCreated, _const.PreSalesContractSendBack}) {
	// 	logs.CtxInfo(ctx, "HitContractStatus, continue.")
	// 	return nil
	// }
	// 获取合同对方信息关联账号列表
	var partyAccountIdList []string
	var pricingAccountIDList []string
	for _, other := range p.TradePartyInfo.OtherParty {
		if other.IsDeputyParty() {
			continue
		}
		pricingAccountIDList = util.SingleList(append(pricingAccountIDList, strings.Split(other.PricingAccountID, ",")...))
		partyAccountIdList = util.SingleList(append(partyAccountIdList, strings.Split(other.AccountID, ",")...))
	}
	// 合同限制关联配价账号 ID 最大数量为 10
	if len(pricingAccountIDList) > 10 {
		logs.CtxError(ctx, "otherPartyRelateAccountOverNum")
		return errors.ErrInternalError.WithArgs("合同关联签约账号 Id 超过最大限制。")
	}
	// 获取报价单关联账号
	manage, err := dal.NewContractManageDao().FindByVolcContractId(ctx, nil, int64(entity.Id))
	if err != nil {
		logs.CtxError(ctx, "FindManageDBByVolcContractIdFail, volcContractId:%d, err:%v", entity.Id, err)
		return err
	}
	if manage == nil {
		logs.CtxWarn(ctx, "manageDB is nil, continue.")
		return nil
	}
	if len(manage.QuoteAccountID) == 0 {
		logs.CtxWarn(ctx, "manageDB.QuoteAccountID is nil, continue.")
		return nil
	}
	quoteRelateAccountIds := strings.Split(manage.QuoteAccountID, ",")

	// 报价单关联的账号不允许删除 && 只允许在原有基础上关联一个账号
	if len(quoteRelateAccountIds) != len(partyAccountIdList) && len(quoteRelateAccountIds) != len(partyAccountIdList)-1 {
		return errors.ErrInternalError.WithArgs("报价单关联账号ID不可删除，且仅可在此基础上新增一个“线下代客创建”的账号ID")
	}
	// 构建报价单关联账号 map
	quoteRelateAccountIdMap := map[string]struct{}{}
	for _, accountId := range quoteRelateAccountIds {
		quoteRelateAccountIdMap[accountId] = struct{}{}
	}
	// 只允许在原有基础上关联一个账号
	// 若关联账号列表中无此账号 视为线下代客户创建账号
	// 若存在多个未命中账号 则关联账号数据异常
	var valetCreateAccount string
	for _, accountId := range partyAccountIdList {
		if _, ok := quoteRelateAccountIdMap[accountId]; !ok {
			if len(valetCreateAccount) != 0 {
				logs.CtxError(ctx, "合同关联账号异常，valetCreateAccount：%s, accountId:%s", valetCreateAccount, accountId)
				return errors.ErrInternalError.WithArgs("报价单关联账号ID不可删除，且仅可在此基础上新增一个“线下代客创建”的账号ID")
			}
			valetCreateAccount = accountId
		}
	}
	if len(valetCreateAccount) == 0 {
		logs.CtxInfo(ctx, "valetCreateAccount is empty, continue.")
		return nil
	}
	// 验证下新增账号是否为现在待客户创建账号
	checkId, err := strconv.Atoi(valetCreateAccount)
	if err != nil {
		logs.CtxError(ctx, "valet create account id format fail.")
		return errors.ErrInternalError.WithArgs("合同关联账号格式异常")
	}
	accountInfo, err := accountcli.GetAccountAndVerifyFromCache(ctx, int64(checkId))
	if err != nil {
		logs.CtxError(ctx, "GetAccountInfoFromCacheFail, err:%v", err)
		return err
	}
	if accountInfo.CreateSource != _const.PassportCreateSourceSale {
		logs.CtxError(ctx, "accountInfo_createSource err, accountId:%d, CreateSource:%d", checkId, accountInfo.CreateSource)
		return errors.ErrInternalError.WithArgs("报价单关联账号ID不可删除，且仅可在此基础上新增一个“线下代客创建”的账号ID")
	}

	return nil
}

func (p *CreateOrUpdateReq) validateProductGroup(ctx context.Context) error {
	manageAccountMap := map[string]struct{}{}
	priceAccountMap := map[string]struct{}{}
	tradeAccountMap := map[string]struct{}{}

	// 合并商品行分组和抵扣项分组的 Key
	allProductGroupKeys := map[string]struct{}{}
	for k := range p.ManageInfo.ProductLevelMap {
		allProductGroupKeys[k] = struct{}{}
	}
	for k := range p.ManageInfo.DeductProductInfoMap {
		allProductGroupKeys[k] = struct{}{}
	}

	// 商品行分组数 与 账号ID分组信息数量不匹配
	if len(allProductGroupKeys) != len(p.ManageInfo.AccountAssociationInfo) {
		logs.CtxError(ctx, "商品行分组信息商品行信息分组数量不匹配, allProductGroupKeys:%d, AccountAssociationInfo:%d", len(allProductGroupKeys), len(p.ManageInfo.AccountAssociationInfo))
		return errors.ErrorCommon.WithArgs("商品行分组信息异常")
	}

	// 商品行分组信息 与 账号分组信息 需一致
	for key, accountIds := range p.ManageInfo.AccountAssociationInfo {
		if _, ok := allProductGroupKeys[key]; !ok {
			logs.CtxError(ctx, "商品行分组信息商品行信息分组标识不匹配, key:%s", key)
			return errors.ErrorCommon.WithArgs("商品行分组信息异常")
		}

		if len(accountIds) == 0 {
			return errors.ErrorCommon.WithArgs("每个商品行类别必须关联账号ID")
		}
		for _, accountID := range strings.Split(accountIds, ",") {
			if len(accountID) == 0 {
				continue
			}
			manageAccountMap[accountID] = struct{}{}
		}
	}

	for _, party := range p.TradePartyInfo.OtherParty {
		for _, accountID := range strings.Split(party.PricingAccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			priceAccountMap[accountID] = struct{}{}
			tradeAccountMap[accountID] = struct{}{}
		}
		for _, accountID := range strings.Split(party.SealAccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			tradeAccountMap[accountID] = struct{}{}
		}
		// 兜底逻辑，保证能拿到所有账号
		for _, accountID := range strings.Split(party.AccountID, ",") {
			if len(accountID) == 0 {
				continue
			}
			tradeAccountMap[accountID] = struct{}{}
		}
	}

	for accountID := range priceAccountMap {
		if _, ok := manageAccountMap[accountID]; !ok {
			return errors.ErrorCommon.WithArgs("配价主体中的账号ID必须全部关联分组")
		}
	}

	for accountID := range manageAccountMap {
		if _, ok := tradeAccountMap[accountID]; !ok {
			return errors.ErrorCommon.WithArgs("商品行分组信息中存在异常账号ID")
		}
	}

	return nil
}

// validateCurrencyIn 签约方式校验
func (p *CreateOrUpdateReq) validateSignatureType(ctx context.Context) error {
	logs.CtxInfo(ctx, "validateSignatureType, ContractNo:%s", p.ContractNo)
	// 国际电子签
	if p.BasicInfo.SignatureType == _const.InternationalEleSignatureType {
		for _, party := range p.TradePartyInfo.Subject {
			if party.Country == "CN" || party.Country == "MDCT00000040" {
				return errors.ErrorCommon.WithArgs("存在我方为中国大陆主体，不可选择国际电子签")
			}
		}
		for _, party := range p.TradePartyInfo.OtherParty {
			if party.Country == "CN" || party.Country == "MDCT00000040" {
				return errors.ErrorCommon.WithArgs("存在对方为中国大陆主体，不可选择国际电子签")
			}
		}
	}
	return nil
}

func (p *CreateOrUpdateReq) validateTradePartyInfo(ctx context.Context) error {
	// 交易双方信息参数校验
	if err := p.TradePartyInfo.Validate(ctx, p.BasicInfo.InOutType); err != nil {
		logs.CtxError(ctx, "TradePartyInfoValidateFail, err:%v", err)
		return err
	}
	// 先盖章方-是否盖章校验
	if err := p.TradePartyInfo.SealOrderCheck(p.BasicInfo.SealOrder); err != nil {
		logs.CtxError(ctx, "TradePartyInfoSealOrderCheckFail, err:%v", err)
		return err
	}
	// 银行账号信息校验，直连飞书的合同，强制要求入参主数据唯一ID（OpInfoId）
	if p.BasicInfo.IsFeishu {
		if err := p.TradePartyInfo.CheckPayTypes(); err != nil {
			logs.CtxError(ctx, "TradePartyInfoSealOrderCheckFail, err:%v", err)
			return err
		}
	}
	if err := p.TradePartyInfo.CheckSignData(p.BasicInfo.SignatureType); err != nil {
		logs.CtxError(ctx, "TradePartyInfoCheckSignDataFail, err:%v", err)
		return err
	}
	return nil
}

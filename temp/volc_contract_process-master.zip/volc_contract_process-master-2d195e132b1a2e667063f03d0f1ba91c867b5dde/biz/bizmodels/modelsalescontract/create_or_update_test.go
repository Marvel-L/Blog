package modelsalescontract

import (
	"context"
	"fmt"
	"testing"
	"time"
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/biz/service/contractmeta"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/accountcli"
	"volc_contract_process/pkg/proxy/larkc"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func newValidCreateOrUpdateReq() *CreateOrUpdateReq {
	return &CreateOrUpdateReq{
		ManageInfo: bizmodels.ManageInfo{
			ProductLevelMap: map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			},
			DeductProductInfoMap: map[string][]*bizmodels.ProductInfo{
				"group-deduct": nil,
			},
			AccountAssociationInfo: map[string]string{
				"group-standard": "acc-1,,acc-2",
				"group-deduct":   "acc-3",
			},
		},
		TradePartyInfo: bizmodels.TradePartyInfo{
			OtherParty: []*bizmodels.TradePartyInfoDetail{
				&bizmodels.TradePartyInfoDetail{
					PricingAccountID: "acc-1,,acc-3",
					SealAccountID:    "acc-2,,",
					AccountID:        "acc-2,acc-3,,",
				},
			},
		},
	}
}

//go:noinline
func errorText(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

func TestCreateOrUpdateReq_validateProductGroup(t *testing.T) {
	ctx := context.Background()
	t.Run("case #1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {

			// Act
			v := &CreateOrUpdateReq{
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap:        map[string][]*bizmodels.ProductInfo{"StandardPublicCloud": {&bizmodels.ProductInfo{}}},
					AccountAssociationInfo: map[string]string{"StandardPublicCloud": "2100260896"},
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					OtherParty: []*bizmodels.TradePartyInfoDetail{{
						AccountID:        "2100260896",
						Pricing:          _const.TRUE_FLAG_INT,
						PricingAccountID: "2100260896",
					}},
				},
			}
			err := v.validateProductGroup(ctx)

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("Returns error when merged product group count does not match account association count", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()
			req.ManageInfo.ProductLevelMap = map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			}
			req.ManageInfo.DeductProductInfoMap = map[string][]*bizmodels.ProductInfo{
				"group-deduct": nil,
			}
			req.ManageInfo.AccountAssociationInfo = map[string]string{
				"group-standard": "acc-1",
			}

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorText(err), convey.ShouldContainSubstring, "商品行分组信息异常")
		})
	})

	t.Run("Returns error when account association contains unknown product group key", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()
			req.ManageInfo.ProductLevelMap = map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			}
			req.ManageInfo.DeductProductInfoMap = nil
			req.ManageInfo.AccountAssociationInfo = map[string]string{
				"group-unknown": "acc-1",
			}

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorText(err), convey.ShouldContainSubstring, "商品行分组信息异常")
		})
	})

	t.Run("Returns error when a product group has empty associated account ids", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()
			req.ManageInfo.ProductLevelMap = map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			}
			req.ManageInfo.DeductProductInfoMap = nil
			req.ManageInfo.AccountAssociationInfo = map[string]string{
				"group-standard": "",
			}

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorText(err), convey.ShouldContainSubstring, "每个商品行类别必须关联账号ID")
		})
	})

	t.Run("Returns error when pricing account ids are not fully associated to product groups", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()
			req.ManageInfo.ProductLevelMap = map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			}
			req.ManageInfo.DeductProductInfoMap = nil
			req.ManageInfo.AccountAssociationInfo = map[string]string{
				"group-standard": "manage-1,,manage-2",
			}
			req.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
				&bizmodels.TradePartyInfoDetail{
					PricingAccountID: "priced-1,,",
					SealAccountID:    "manage-1,,",
					AccountID:        "manage-2,,",
				},
			}

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorText(err), convey.ShouldContainSubstring, "配价主体中的账号ID必须全部关联分组")
		})
	})

	t.Run("Returns error when managed account ids are missing from trade party accounts", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()
			req.ManageInfo.ProductLevelMap = map[string][]*bizmodels.ProductInfo{
				"group-standard": nil,
			}
			req.ManageInfo.DeductProductInfoMap = nil
			req.ManageInfo.AccountAssociationInfo = map[string]string{
				"group-standard": "manage-1,,manage-2",
			}
			req.TradePartyInfo.OtherParty = []*bizmodels.TradePartyInfoDetail{
				&bizmodels.TradePartyInfoDetail{
					PricingAccountID: ",",
					SealAccountID:    "manage-1,,",
					AccountID:        ",",
				},
			}

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(errorText(err), convey.ShouldContainSubstring, "商品行分组信息中存在异常账号ID")
		})
	})

	t.Run("Returns nil when product groups and trade party accounts are fully aligned", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := newValidCreateOrUpdateReq()

			err := req.validateProductGroup(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_BaseValidate(t *testing.T) {
	mockey.PatchConvey("Test SourceTypeInner and CurrentOperator is empty", t, func() {
		req := &CreateOrUpdateReq{
			SourceType: _const.SourceTypeInner,
			BasicInfo:  &bizmodels.BasicInfo{},
		}
		actual := req.BaseValidate()
		convey.So(actual, convey.ShouldNotBeNil)
		convey.So(actual, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("CurrentOperator"))
	})
	mockey.PatchConvey("Test BasicInfo is nil", t, func() {
		req := &CreateOrUpdateReq{
			CurrentOperator: "CurrentOperator",
			SourceType:      _const.SourceTypeInner,
		}
		actual := req.BaseValidate()
		convey.So(actual, convey.ShouldNotBeNil)
		convey.So(actual, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("BasicInfo"))
	})
	mockey.PatchConvey("Test valid case", t, func() {
		req := &CreateOrUpdateReq{
			SourceType:      _const.SourceTypeInner,
			CurrentOperator: "operator123",
			BasicInfo: &bizmodels.BasicInfo{
				ContractName: "Test Contract",
			},
		}
		actual := req.BaseValidate()
		convey.So(actual, convey.ShouldBeNil)
	})
}

func TestCreateOrUpdateReq_PreValidate(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": "2100001"},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:      _const.TRUE_FLAG_INT,
						PartyNumber: "123",
						Country:     "CN",
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:        _const.TRUE_FLAG_INT,
						PartyNumber:   "123",
						AccountID:     "2100001",
						SealAccountID: "2100001",
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("ValidateProductHasSameInvoice err", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(errors.ErrorCommon.WithArgs("product has same invoice")).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": "2100001"},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:      _const.TRUE_FLAG_INT,
						PartyNumber: "123",
						Country:     "CN",
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:        _const.TRUE_FLAG_INT,
						PartyNumber:   "123",
						AccountID:     "2100001",
						SealAccountID: "2100001",
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("product has same invoice"))
		})
	})

	t.Run("ValidateContractPeriod err", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(errors.ErrorCommon.WithArgs("contract period is invalid")).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": "2100001"},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:      _const.TRUE_FLAG_INT,
						PartyNumber: "123",
						Country:     "CN",
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:        _const.TRUE_FLAG_INT,
						PartyNumber:   "123",
						AccountID:     "2100001",
						SealAccountID: "2100001",
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("contract period is invalid"))
		})
	})

	t.Run("case BaseValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "",
				BasicInfo:       nil,
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": ""},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:  _const.TRUE_FLAG_INT,
						Country: "CN",
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Sealed:        _const.TRUE_FLAG_INT,
						AccountID:     "2100001",
						SealAccountID: "2100001",
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("BasicInfo"))
		})
	})
	t.Run("case validateSupplySourceFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "1",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": ""},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Country: "CN",
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						AccountID: "2100001",
						Country:   "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				SupplySource:        "1,2",
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case validateTermChangeDetailFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockey.Mock((*bizmodels.BasicInfo).RequireQuote).Return(false).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()
			mockey.Mock((*CreateOrUpdateReq).validateTermChangeDetail).Return(fmt.Errorf("validateTermChangeDetailFail")).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "3",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"": "2100001"},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Country:     "CN",
						PartyNumber: "123",
						Sealed:      _const.TRUE_FLAG_INT,
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						AccountID:     "2100001",
						SealAccountID: "2100001",
						PartyNumber:   "123",
						Sealed:        _const.TRUE_FLAG_INT,
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err.Error(), convey.ShouldEqual, "validateTermChangeDetailFail")
		})
	})
	t.Run("case validateProductGroupFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			metaServiceV2 := contractmeta.NewMetaServiceV2()
			manageDao := dal.NewContractManageDao()
			// Arrange
			mockey.Mock((*bizmodels.ManageInfo).ValidateProductHasSameInvoice).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).ValidateContractPeriod).Return(nil).Build()
			mockey.Mock((bizmodels.SettlementLines).Validate).Return(nil).Build()
			mockey.Mock(contractmeta.NewMetaServiceV2).Return(metaServiceV2).Build()
			mockAccountNameAndPartyNameCheck := mockey.GetMethod(metaServiceV2, "AccountNameAndPartyNameCheck")
			mockey.Mock(mockAccountNameAndPartyNameCheck).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string { return fmt.Sprintf(format, a...) }).Build()
			mockey.Mock(larkc.Warning).Return().Build()
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()
			mockFindByVolcContractId := mockey.GetMethod(manageDao, "FindByVolcContractId")
			mockey.Mock(mockFindByVolcContractId).Return(&model.VolcContractManage{QuoteAccountID: "2100001"}, nil).Build()
			mockey.Mock(dal.NewContractManageDao).Return(manageDao).Build()
			mockey.Mock(accountcli.GetAccountAndVerifyFromCache).Return(&accountcli.AccountAndVerifyInfo{CreateSource: 1}, nil).Build()
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			v1, _ := time.Parse("2006-01-02 15:04:05", "2023-07-01 00:00:00")
			mockey.Mock(time.ParseInLocation).Return(v1, nil).Build()
			var v = time.Duration(0)
			mockey.Mock((time.Time).Sub).Return(v).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

			// Act
			time.Local = &time.Location{}
			var v2 = _const.SourceType(0)
			var v3 = bizmodels.SettlementLines([]*bizmodels.SettlementLine{&bizmodels.SettlementLine{}})
			v4 := &CreateOrUpdateReq{
				SourceType:      v2,
				CurrentOperator: "liufenglin.234@bytedance.com",
				ContractNo:      "CTXXXXX01",
				SupplyScene:     30,
				SupplySource:    "1,2",
				BasicInfo: &bizmodels.BasicInfo{
					WhetherProject:      "Y",
					UsefulLifeType:      1,
					IndefiniteDateFlag:  "N",
					UsefulLifeUnit:      "YEAR",
					UsefulLifeNum:       5,
					LongLifeReason:      "xxxxxx",
					BeginTime:           "2024-06-14",
					EndTime:             "2024-06-14",
					CurrencyIn:          "CNY",
					SignatureType:       "12",
					SealType:            "4",
					SpecialContractType: "1",
					InOutType:           _const.IN,
				},
				ManageInfo: bizmodels.ManageInfo{
					ProductLevelMap: map[string][]*bizmodels.ProductInfo{"Default": []*bizmodels.ProductInfo{&bizmodels.ProductInfo{
						DeploymentType: 1,
					}}},
					AccountAssociationInfo: map[string]string{"Default1": "2100001"},
					WhetherProject:         "Y",
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						Country:     "CN",
						PartyNumber: "123",
						Sealed:      _const.TRUE_FLAG_INT,
					}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{&bizmodels.TradePartyInfoDetail{
						AccountID:     "2100001",
						SealAccountID: "2100001",
						PartyNumber:   "123",
						Sealed:        _const.TRUE_FLAG_INT,
						Country:       "CN",
					}},
				},
				SettlementInfo: bizmodels.SettlementInfo{
					SettlementLines: v3,
				},
				Ext: map[string]string{"": ""},
			}
			err := v4.PreValidate(context.Background(), &model.ContractMetaDB{
				BaseDB: model.BaseDB{
					Status: 0,
				},
				BizScene:            1,
				BizSource:           2,
				SupplyScene:         30,
				SupplySource:        "1,2",
				RelateQuoteNo:       "10086",
				SpecialContractType: "1",
			})

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品行分组信息异常"))
		})
	})
}

func TestCreateOrUpdateReq_validateSupplySource(t *testing.T) {
	t.Run("case 补充协议 success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &CreateOrUpdateReq{
				SupplySource: "1,2",
			}
			err := v.validateSupplySource(context.Background(), &model.ContractMetaDB{
				SupplyScene:  30,
				SupplySource: "1,2,3",
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case 补充协议 fail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &CreateOrUpdateReq{
				SupplySource: "1",
			}
			err := v.validateSupplySource(context.Background(), &model.ContractMetaDB{
				SupplyScene:  30,
				SupplySource: "1,2,3",
			})

			// Assert
			convey.So(err, convey.ShouldNotEqual, nil)
		})
	})
	t.Run("case 非补充协议", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &CreateOrUpdateReq{
				SupplySource: "1,2",
			}
			err := v.validateSupplySource(context.Background(), &model.ContractMetaDB{
				SupplyScene:  0,
				SupplySource: "1,2,3",
			})

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_validateTermChangeDetail(t *testing.T) {
	mockey.PatchConvey("Test_validateTermChangeDetail", t, func() {
		mockey.PatchConvey("补充协议-非补充协议", func() {
			req := CreateOrUpdateReq{SupplyScene: 0, SupplySource: "", Ext: map[string]string{}}
			meta := &model.ContractMetaDB{SupplyScene: 0}
			err := req.validateTermChangeDetail(context.Background(), meta)
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("补充协议-补充场景不包含条款变更", func() {
			req := CreateOrUpdateReq{SupplyScene: _const.SupplySceneVolc, SupplySource: "", Ext: map[string]string{}}
			meta := &model.ContractMetaDB{SupplyScene: _const.SupplySceneVolc}
			err := req.validateTermChangeDetail(context.Background(), meta)
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("补充协议-补充场景包含条款变更，条款变更详情为空", func() {
			req := CreateOrUpdateReq{SupplyScene: _const.SupplySceneVolc, SupplySource: _const.SupplySourceTermChange, Ext: map[string]string{}}
			meta := &model.ContractMetaDB{SupplyScene: _const.SupplySceneVolc}
			err := req.validateTermChangeDetail(context.Background(), meta)
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("补充协议-补充场景包含条款变更，条款变更详情不为空", func() {
			req := CreateOrUpdateReq{SupplyScene: _const.SupplySceneVolc, SupplySource: _const.SupplySourceTermChange, Ext: map[string]string{_const.ExtKeyTermChangeDetail: "123"}}
			meta := &model.ContractMetaDB{SupplyScene: _const.SupplySceneVolc}
			err := req.validateTermChangeDetail(context.Background(), meta)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func TestCreateOrUpdateReq_validateTradePartyInfo(t *testing.T) {
	t.Run("case success", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).FetchSignDataCheckType).Return(_const.NoneCheckPartyDetail).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()

			// Act
			v := &CreateOrUpdateReq{
				BasicInfo: &bizmodels.BasicInfo{
					InOutType:     "IN",
					SignatureType: "12",
					SealOrder:     "I",
					IsFeishu:      true,
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{{}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{{}},
				},
			}
			err := v.validateTradePartyInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldBeNil)
		})
	})
	t.Run("case TradePartyInfo ValidateFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(errors.ErrorCommon).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).FetchSignDataCheckType).Return(_const.NoneCheckPartyDetail).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()

			// Act
			v := &CreateOrUpdateReq{
				BasicInfo: &bizmodels.BasicInfo{
					InOutType:     "IN",
					SignatureType: "12",
					SealOrder:     "I",
					IsFeishu:      true,
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{{}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{{}},
				},
			}
			err := v.validateTradePartyInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon)
		})
	})
	t.Run("case TradePartyInfo SealOrderCheckFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(errors.ErrorCommon).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(nil).Build()
			mockey.Mock((*bizmodels.BasicInfo).FetchSignDataCheckType).Return(_const.NoneCheckPartyDetail).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()

			// Act
			v := &CreateOrUpdateReq{
				BasicInfo: &bizmodels.BasicInfo{
					InOutType:     "IN",
					SignatureType: "12",
					SealOrder:     "I",
					IsFeishu:      true,
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{{}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{{}},
				},
			}
			err := v.validateTradePartyInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon)
		})
	})
	t.Run("case TradePartyInfo CheckPayTypesFail", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock((*bizmodels.TradePartyInfo).Validate).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).SealOrderCheck).Return(nil).Build()
			mockey.Mock((*bizmodels.TradePartyInfo).CheckPayTypes).Return(errors.ErrorCommon).Build()
			mockey.Mock((*bizmodels.BasicInfo).FetchSignDataCheckType).Return(_const.NoneCheckPartyDetail).Build()
			mockey.Mock((*bizmodels.TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()

			// Act
			v := &CreateOrUpdateReq{
				BasicInfo: &bizmodels.BasicInfo{
					InOutType:     "IN",
					SignatureType: "12",
					SealOrder:     "I",
					IsFeishu:      true,
				},
				TradePartyInfo: bizmodels.TradePartyInfo{
					Subject:    []*bizmodels.TradePartyInfoDetail{{}},
					OtherParty: []*bizmodels.TradePartyInfoDetail{{}},
				},
			}
			err := v.validateTradePartyInfo(context.Background())

			// Assert
			convey.So(err, convey.ShouldResemble, errors.ErrorCommon)
		})
	})
}

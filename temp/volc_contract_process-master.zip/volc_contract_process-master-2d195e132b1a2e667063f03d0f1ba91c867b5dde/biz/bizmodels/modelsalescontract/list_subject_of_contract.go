package modelsalescontract

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type ListSubjectOfContractReq struct {
	ContractNo string
	AccountID  int
	//Version         int `default:"-1"`
	SourceType      _const.SourceType
	CurrentOperator string
}

func (p *ListSubjectOfContractReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

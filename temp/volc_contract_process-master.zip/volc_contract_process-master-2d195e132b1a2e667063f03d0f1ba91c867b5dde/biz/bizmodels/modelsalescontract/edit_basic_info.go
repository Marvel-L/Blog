package modelsalescontract

type EditBasicInfoReq struct {
	ContractNo    string
	UpdateBodyMap map[string]interface{}
}

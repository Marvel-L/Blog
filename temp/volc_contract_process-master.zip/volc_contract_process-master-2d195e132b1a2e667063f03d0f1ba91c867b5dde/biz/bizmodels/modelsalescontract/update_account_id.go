package modelsalescontract

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type UpdateAccountIDReq struct {
	ContractNo      string
	AccountID       int
	SubjectNo       string
	SourceType      _const.SourceType
	CurrentOperator string
}

func (p *UpdateAccountIDReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if p.AccountID == 0 {
		return errors.ErrMissingParam.WithArgs("AccountID")
	}
	if p.SubjectNo == "" {
		return errors.ErrMissingParam.WithArgs("SubjectNo")
	}
	return nil
}

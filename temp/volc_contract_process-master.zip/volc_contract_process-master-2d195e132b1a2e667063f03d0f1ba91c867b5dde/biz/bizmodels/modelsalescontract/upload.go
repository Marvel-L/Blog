package modelsalescontract

import (
	"mime/multipart"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type UploadReq struct {
	File            *multipart.FileHeader `json:"File" form:"File" formfile:"File"`
	AccountId       int                   `json:"AccountId" form:"AccountID"`
	BizType         int                   `json:"BizType" form:"BizType"`
	ContractNo      string                `json:"ContractNo" form:"ContractNo"`
	Sealed          string                `json:"Sealed,omitempty" form:"Sealed"`
	Archived        string                `json:"Archived,omitempty" form:"Archived"`
	Remark          string                `json:"Remark,omitempty" form:"Remark"`
	SourceType      _const.SourceType
	CurrentOperator string
}

func (p *UploadReq) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	if p.BizType == _const.ContractAttachmentTypeCommon && len(p.Sealed) == 0 {
		return errors.ErrMissingParam.WithArgs("Sealed")
	}
	if p.BizType == _const.ContractAttachmentTypeCommon && len(p.Archived) == 0 {
		return errors.ErrMissingParam.WithArgs("Archived")
	}
	// if len(p.ContractNo) == 0 {
	// 	return errors.ErrMissingParam.WithArgs("ContractNo")
	// }
	if p.File == nil {
		return errors.ErrMissingParam.WithArgs("File")
	}
	return nil
}

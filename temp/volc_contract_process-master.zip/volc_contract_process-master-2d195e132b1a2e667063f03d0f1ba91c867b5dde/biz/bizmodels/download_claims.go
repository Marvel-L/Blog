package bizmodels

import (
	"fmt"
	"time"
)

// Claims  .
type DownloadClaims struct {
	DownloadId string `json:"DownloadId"`
	Version    string `json:"Version"`
	ExpiresAt  int64  `json:"exp,omitempty"`
	IssuedAt   int64  `json:"iat,omitempty"`
	IsView     bool   `json:"extra_info"`
}

// VerifyExpiresAt Compares the exp claim against cmp.
// If required is false, this method will return true if the value matches or is unset
func (c *DownloadClaims) VerifyExpiresAt(cmp int64) bool {
	return c.ExpiresAt <= cmp
}

// VerifyIssuedAt Compares the iat claim against cmp.
// If required is false, this method will return true if the value matches or is unset
func (c *DownloadClaims) VerifyIssuedAt(cmp int64) bool {
	return c.IssuedAt > cmp
}

// Valid Valid Claim
func (c *DownloadClaims) Valid() error {
	now := time.Now().Unix()
	if c.VerifyExpiresAt(now) {
		return fmt.Errorf("token is expired")
	}
	if c.VerifyIssuedAt(now) {
		return fmt.Errorf("token used before issued")
	}
	return nil
}

package bizmodels

import (
	context001 "context"
	"encoding/json"
	errors001 "errors"
	"fmt"
	"strings"
	"testing"
	"time"
	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/salescontract/productkey"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/invoicesdkcli"
	"volc_contract_process/pkg/util"

	sdkinvoiceclient "code.byted.org/eps-platform/invoice_sdk/invoiceclient"
	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/lang/conv"
	"github.com/bytedance/mockey"
	"github.com/shopspring/decimal"
	"github.com/smartystreets/goconvey/convey"
)

func TestBasicInfo_RequireQuote(t *testing.T) {
	t.Run("case 收入类新签合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}
			flag := v.RequireQuote(_const.SupplySceneNew, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
		})
	})
	t.Run("case 收入类火山补充合同，补充场景不包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 收入类火山补充合同，补充场景包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "1,2,3")

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
		})
	})
	t.Run("case 收入类OA补充合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}
			flag := v.RequireQuote(_const.SupplySceneOA, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})

	t.Run("case 支出类新签合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.OUT,
			}
			flag := v.RequireQuote(_const.SupplySceneNew, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 支出类火山补充合同，补充场景不包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.OUT,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 支出类火山补充合同，补充场景包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.OUT,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "1,2,3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 支出类OA补充合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.OUT,
			}
			flag := v.RequireQuote(_const.SupplySceneOA, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})

	t.Run("case 即收又支类新签合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.InAndOut,
			}
			flag := v.RequireQuote(_const.SupplySceneNew, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
		})
	})
	t.Run("case 即收又支类火山补充合同，补充场景不包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.InAndOut,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 即收又支类火山补充合同，补充场景包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.InAndOut,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "1,2,3")

			// Assert
			convey.So(flag, convey.ShouldEqual, true)
		})
	})
	t.Run("case 即收又支类OA补充合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.InAndOut,
			}
			flag := v.RequireQuote(_const.SupplySceneOA, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})

	t.Run("case 无收无支类新签合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.NoInNoOut,
			}
			flag := v.RequireQuote(_const.SupplySceneNew, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 无收无支类火山补充合同，补充场景不包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.NoInNoOut,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 无收无支类火山补充合同，补充场景包含报价单相关", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.NoInNoOut,
			}
			flag := v.RequireQuote(_const.SupplySceneVolc, "1,2,3")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})
	t.Run("case 无收无支类OA补充合同", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.NoInNoOut,
			}
			flag := v.RequireQuote(_const.SupplySceneOA, "")

			// Assert
			convey.So(flag, convey.ShouldEqual, false)
		})
	})

	t.Run("case 收支类型不符合条件", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.OUT,
			}

			// Assert
			convey.So(v.RequireQuote(30, "1,2"), convey.ShouldEqual, false)
		})
	})
	t.Run("case 收支类型符合条件，OA 补充协议", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(20, "1,2"), convey.ShouldEqual, false)
		})
	})
	t.Run("case 收支类型符合条件，新签", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(0, ""), convey.ShouldEqual, true)
		})
	})
	t.Run("case 收支类型符合条件，火山补充协议，仅条款变更", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(30, "3"), convey.ShouldEqual, false)
		})
	})
	t.Run("case 收支类型符合条件，火山补充协议，包含报价单变更", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(30, "1,3"), convey.ShouldEqual, true)
		})
	})
	t.Run("case 收支类型符合条件，火山补充协议，包含有效期变更，报价单变更", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(30, "1,2,3"), convey.ShouldEqual, true)
		})
	})
	t.Run("case 收支类型符合条件，火山补充协议，包含增购", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(30, "4"), convey.ShouldEqual, true)
		})
	})
	t.Run("case 收支类型符合条件，火山补充协议，包含续约", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange

			// Act
			v := &BasicInfo{
				InOutType: _const.IN,
			}

			// Assert
			convey.So(v.RequireQuote(30, "5"), convey.ShouldEqual, true)
		})
	})
}

func TestManageInfo_ValidateInvoiceProjectBySnapshot(t *testing.T) {
	t.Run("case 海外环境跳过校验", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:         "product_skip",
						TradeProductName:     "商品跳过",
						InvoiceProject:       "*信息技术服务*新开票项*13%",
						TaxRatio:             decimal.NewFromInt(13),
						InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
						OriginInvoiceProject: "*信息技术服务*原开票项*6%",
						OriginTaxRatio:       decimal.NewFromInt(6),
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("case 关联报价单税率一致放行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:         "product_a",
						TradeProductName:     "商品A",
						InvoiceProject:       "*信息技术服务*新开票项*6%",
						TaxRatio:             decimal.NewFromInt(6),
						InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
						OriginInvoiceProject: "*信息技术服务*原开票项*6%",
						OriginTaxRatio:       decimal.NewFromInt(6),
					}},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("case 关联报价单未补到原始快照时放行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:         "product_no_snapshot",
						TradeProductName:     "商品无快照",
						InvoiceProject:       "*信息技术服务*新开票项*13%",
						TaxRatio:             decimal.NewFromInt(13),
						InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
						OriginInvoiceProject: "",
						OriginTaxRatio:       decimal.Zero,
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("case 未关联报价单组合售卖不一致报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					_const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD: {{
						TradeProduct:                     "product_b",
						TradeProductName:                 "商品B",
						IncomeCode:                       "income_new",
						InvoiceProject:                   "*信息技术服务*技术服务费*6%",
						InvoiceValidateScene:             _const.InvoiceValidateSceneNoQuote,
						OriginSellingRule:                _const.InvoiceSellingRuleCombined,
						OriginCombinedSaleIncomeCode:     "income_origin",
						OriginCombinedSaleInvoiceProject: "*信息技术服务*组合售卖*13%",
					}},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品B仅可选择13%的开票项，请重新选择"))
		})
	})

	t.Run("case 未关联报价单组合售卖税率一致且收入性质一致时放行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					_const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD: {{
						TradeProduct:                     "product_combined_pass",
						TradeProductName:                 "商品组合售卖",
						IncomeCode:                       "income_origin",
						InvoiceProject:                   "*信息技术服务*技术服务费*13%",
						TaxRatio:                         decimal.NewFromInt(13),
						InvoiceValidateScene:             _const.InvoiceValidateSceneNoQuote,
						OriginSellingRule:                _const.InvoiceSellingRuleCombined,
						OriginCombinedSaleIncomeCode:     "income_origin",
						OriginCombinedSaleInvoiceProject: "*信息技术服务*组合售卖*13%",
						OriginCombinedSaleTaxRatio:       decimal.NewFromInt(13),
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("case 未关联报价单单独售卖匹配原始规则时放行", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					_const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD: {{
						TradeProduct:         "product_single_pass",
						TradeProductName:     "商品C",
						IncomeCode:           "income_origin",
						InvoiceProject:       "*信息技术服务*技术服务费*6%",
						InvoiceValidateScene: _const.InvoiceValidateSceneNoQuote,
						OriginSellingRule:    _const.InvoiceSellingRuleSingle,
						OriginIncomeCode:     "income_origin",
						OriginInvoiceProject: "*信息技术服务*技术服务费*6%",
					}},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})

	t.Run("case 未关联报价单单独售卖不一致报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					_const.COMMODITY_GROUP_KEY_STANDARD_PRIVATE_CLOUD: {{
						TradeProduct:         "product_single_fail",
						TradeProductName:     "商品D",
						IncomeCode:           "income_new",
						InvoiceProject:       "*信息技术服务*技术服务费*13%",
						InvoiceValidateScene: _const.InvoiceValidateSceneNoQuote,
						OriginSellingRule:    _const.InvoiceSellingRuleSingle,
						OriginIncomeCode:     "income_origin",
						OriginInvoiceProject: "*信息技术服务*技术服务费*6%",
					}},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品D仅可选择6%的开票项，请重新选择"))
		})
	})

	t.Run("case 主商品和抵扣商品同名报错时仅聚合一次", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:         "product_a",
						TradeProductName:     "商品A",
						InvoiceProject:       "*信息技术服务*新开票项*6%",
						TaxRatio:             decimal.NewFromInt(6),
						InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
						OriginInvoiceProject: "*信息技术服务*原开票项*13%",
						OriginTaxRatio:       decimal.NewFromInt(13),
					}},
				},
				DeductProductInfoMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:         "product_a_deduct",
						TradeProductName:     "商品A",
						InvoiceProject:       "*信息技术服务*新开票项*6%",
						TaxRatio:             decimal.NewFromInt(6),
						InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
						OriginInvoiceProject: "*信息技术服务*原开票项*13%",
						OriginTaxRatio:       decimal.NewFromInt(13),
					}},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品A仅可选择13%的开票项，请重新选择"))
			convey.So(strings.Count(err.Error(), "商品A"), convey.ShouldEqual, 1)
		})
	})

	t.Run("case 多商品报错按商品名排序后返回", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{
							TradeProduct:         "product_b",
							TradeProductName:     "商品B",
							InvoiceProject:       "*信息技术服务*新开票项*6%",
							TaxRatio:             decimal.NewFromInt(6),
							InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
							OriginInvoiceProject: "*信息技术服务*原开票项*13%",
							OriginTaxRatio:       decimal.NewFromInt(13),
						},
						{
							TradeProduct:         "product_a",
							TradeProductName:     "商品A",
							InvoiceProject:       "*信息技术服务*新开票项*13%",
							TaxRatio:             decimal.NewFromInt(13),
							InvoiceValidateScene: _const.InvoiceValidateSceneRelateQuote,
							OriginInvoiceProject: "*信息技术服务*原开票项*6%",
							OriginTaxRatio:       decimal.NewFromInt(6),
						},
					},
				},
			}

			err := manageInfo.ValidateInvoiceProjectBySnapshot(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品A仅可选择6%的开票项，商品B仅可选择13%的开票项，请重新选择"))
		})
	})
}

func TestManageInfo_ValidateProductInvoiceProjectByInvoiceSDK(t *testing.T) {
	t.Run("case 校验成功并按 TradeProduct 去重", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{
							TradeProduct:     "product_a",
							TradeProductName: "商品A",
							InvoiceProject:   "开票项A",
							TaxRatio:         decimal.NewFromInt(6),
						},
						{
							TradeProduct:     "product_a",
							TradeProductName: "商品A",
							InvoiceProject:   "开票项A",
							TaxRatio:         decimal.NewFromInt(6),
						},
						{
							TradeProduct:     "product_b",
							TradeProductName: "商品B",
							InvoiceProject:   "开票项B",
							TaxRatio:         decimal.NewFromInt(13),
						},
					},
				},
			}
			queryCount := 0
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).To(func(ctx context001.Context, queries []invoicesdkcli.ProductInvoiceProjectQuery) (map[string]*sdkinvoiceclient.ListProductInvoiceProject, error) {
				queryCount = len(queries)
				return map[string]*sdkinvoiceclient.ListProductInvoiceProject{
					invoicesdkcli.BuildProductInvoiceProjectMapKey("product_a", decimal.Zero): {
						InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
							{
								InvoiceProject: "开票项A",
								TaxRate:        6,
							},
						},
					},
					invoicesdkcli.BuildProductInvoiceProjectMapKey("product_b", decimal.Zero): {
						InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
							{
								InvoiceProject: "开票项B",
								TaxRate:        13,
							},
						},
					},
				}, nil
			}).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(queryCount, convey.ShouldEqual, 2)
		})
	})

	t.Run("case 任意商品查询失败直接报错", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:     "product_a",
						TradeProductName: "商品A",
						InvoiceProject:   "开票项A",
						TaxRatio:         decimal.NewFromInt(6),
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).Return(nil, &invoicesdkcli.BatchGetProductInvoiceProjectError{
				ProductCode: "product_a",
				TaxRate:     decimal.NewFromInt(6),
				Err:         fmt.Errorf("query fail"),
			}).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品A开票项信息查询失败"))
		})
	})

	t.Run("case TaxRatio 为 0 时从 InvoiceProject 解析税率", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:       "product_a",
						TradeProductName:   "商品A",
						InvoiceProjectCode: "*信息技术服务*开票项A",
						InvoiceProject:     "*信息技术服务*开票项A*6%",
						TaxRatio:           decimal.Zero,
					}},
				},
			}
			var (
				gotProductCode string
				gotTaxRate     decimal.Decimal
			)
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).To(func(ctx context001.Context, queries []invoicesdkcli.ProductInvoiceProjectQuery) (map[string]*sdkinvoiceclient.ListProductInvoiceProject, error) {
				gotProductCode = queries[0].ProductCode
				gotTaxRate = queries[0].TaxRate
				return map[string]*sdkinvoiceclient.ListProductInvoiceProject{
					invoicesdkcli.BuildProductInvoiceProjectMapKey("product_a", decimal.NewFromInt(6)): {
						InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
							{
								InvoiceProject: "*信息技术服务*开票项A",
								TaxRate:        6,
							},
						},
					},
				}, nil
			}).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(gotProductCode, convey.ShouldEqual, "product_a")
			convey.So(gotTaxRate.Equal(decimal.NewFromInt(6)), convey.ShouldBeTrue)
		})
	})

	t.Run("case 开票项不匹配返回统一错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:     "product_a",
						TradeProductName: "商品A",
						InvoiceProject:   "开票项A",
						TaxRatio:         decimal.NewFromInt(6),
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).Return(map[string]*sdkinvoiceclient.ListProductInvoiceProject{
				invoicesdkcli.BuildProductInvoiceProjectMapKey("product_a", decimal.Zero): {
					InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
						{
							InvoiceProject: "开票项B",
							TaxRate:        6,
						},
					},
				},
			}, nil).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品A开票项不符合商品规则，请重新选择"))
		})
	})

	t.Run("case 查询结果缺少商品税率键时返回查询失败", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:     "product_a",
						TradeProductName: "商品A",
						InvoiceProject:   "开票项A",
						TaxRatio:         decimal.NewFromInt(6),
					}},
				},
			}
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).Return(map[string]*sdkinvoiceclient.ListProductInvoiceProject{
				invoicesdkcli.BuildProductInvoiceProjectMapKey("product_a", decimal.NewFromInt(13)): {
					InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
						{
							InvoiceProject: "开票项A",
							TaxRate:        13,
						},
					},
				},
			}, nil).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("商品A开票项信息查询失败"))
		})
	})

	t.Run("case 商品列表为空时跳过查询", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			manageInfo := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {{
						TradeProduct:     "",
						TradeProductName: "商品空",
						InvoiceProject:   "",
					}},
				},
			}
			queryCalled := false
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).To(func(ctx context001.Context, queries []invoicesdkcli.ProductInvoiceProjectQuery) (map[string]*sdkinvoiceclient.ListProductInvoiceProject, error) {
				queryCalled = true
				return nil, nil
			}).Build()

			err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

			convey.So(err, convey.ShouldBeNil)
			convey.So(queryCalled, convey.ShouldBeFalse)
		})
	})
}

func TestManageInfo_ValidateProductInvoiceProjectByInvoiceSDK_ParseTaxRatioFromInvoiceProject(t *testing.T) {
	mockey.PatchConvey("", t, func() {
		manageInfo := &ManageInfo{
			ProductLevelMap: map[string][]*ProductInfo{
				"group1": {{
					TradeProduct:       "product_a",
					TradeProductName:   "商品A",
					InvoiceProjectCode: "*信息技术服务*开票项A",
					InvoiceProject:     "*信息技术服务*开票项A*6%",
					TaxRatio:           decimal.Zero,
				}},
			},
		}
		var (
			gotProductCode string
			gotTaxRate     decimal.Decimal
		)
		mockey.Mock(multienv.IsBytePlus).Return(false).Build()
		mockey.Mock(invoicesdkcli.BatchGetProductInvoiceProject).To(func(ctx context001.Context, queries []invoicesdkcli.ProductInvoiceProjectQuery) (map[string]*sdkinvoiceclient.ListProductInvoiceProject, error) {
			gotProductCode = queries[0].ProductCode
			gotTaxRate = queries[0].TaxRate
			return map[string]*sdkinvoiceclient.ListProductInvoiceProject{
				invoicesdkcli.BuildProductInvoiceProjectMapKey("product_a", decimal.NewFromInt(6)): {
					InvoiceProject: []*sdkinvoiceclient.ProductInvoiceProject{
						{
							InvoiceProject: "*信息技术服务*开票项A",
							TaxRate:        6,
						},
					},
				},
			}, nil
		}).Build()

		err := manageInfo.ValidateProductInvoiceProjectByInvoiceSDK(context001.Background())

		convey.So(err, convey.ShouldBeNil)
		convey.So(gotProductCode, convey.ShouldEqual, "product_a")
		convey.So(gotTaxRate.Equal(decimal.NewFromInt(6)), convey.ShouldBeTrue)
	})
}

func Test_TradePartyInfoDetail_Behalf(t *testing.T) {
	t.Run("case TradePartyInfoDetail behalf#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			d := &TradePartyInfoDetail{}
			// Assert
			convey.So(d.IsEntrustedParty(), convey.ShouldBeFalse)
		})
	})
	t.Run("case TradePartyInfoDetail behalf#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			d := &TradePartyInfoDetail{
				OtherPartyType: _const.OtherPartyTypePrincipal,
			}
			// Assert
			convey.So(d.IsPrincipalParty(), convey.ShouldBeTrue)
			convey.So(d.IsEntrustedParty(), convey.ShouldBeFalse)
		})
	})
	t.Run("case TradePartyInfoDetail behalf#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			d := &TradePartyInfoDetail{
				OtherPartyType: _const.OtherPartyTypeEntrusted,
			}
			// Assert
			convey.So(d.IsPrincipalParty(), convey.ShouldBeFalse)
			convey.So(d.IsEntrustedParty(), convey.ShouldBeTrue)
		})
	})
}

func Test_productList_GenQuoteDiscount(t *testing.T) {
	mockey.PatchConvey("Test when ProductInfoList is empty", t, func() {
		productInfoList := ProductInfoList{}
		mockey.Mock((*ProductInfo).GenQuoteDiscount).Return([]*QuoteDiscount{}).Build()
		actual := productInfoList.GenQuoteDiscount("isProject", "beginTime", "endTime")
		convey.So(len(actual), convey.ShouldEqual, 0)
	})
	mockey.PatchConvey("Test normal case", t, func() {
		productInfoList := ProductInfoList{
			&ProductInfo{},
		}
		expected := []*QuoteDiscount{{}}
		mockey.Mock((*ProductInfo).GenQuoteDiscount).Return(expected).Build()
		actual := productInfoList.GenQuoteDiscount("isProject", "beginTime", "endTime")
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

func Test_ProductInfo_GenQuoteDiscount(t *testing.T) {
	mockey.PatchConvey("TestProductInfoGenQuoteDiscount", t, func() {
		testProduct := &ProductInfo{
			CanPrePayCode:         "prepay",
			DeploymentType:        0,
			Discount:              `{"UnitPrice":100}`,
			DistributionDiscounts: `{"FirstDiscount":{"Discount":{"UnitPrice":90}}}`,
			TradeProduct:          "cloud_server",
			TradeProductCode:      "CS001",
			Configuration:         "1C2G",
		}

		t.Run("正常流程-分销折扣", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				mockey.Mock(json.Unmarshal).Return(nil).Build()

				result := testProduct.GenQuoteDiscount("0", "2023-01-01", "2023-12-31")

				convey.Convey("应返回分销折扣数据", func() {
					convey.So(result, convey.ShouldHaveLength, 1)
					convey.So(result[0].UnitPrice, convey.ShouldEqual, "90")
					convey.So(result[0].DeploymentType, convey.ShouldEqual, "public")
				})
			})
		})

		t.Run("普通折扣流程", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				testCopy := *testProduct
				testCopy.DistributionDiscounts = ""

				result := testCopy.GenQuoteDiscount("0", "2023-01-01", "2023-12-31")

				convey.Convey("应返回基础折扣数据", func() {
					convey.So(result, convey.ShouldHaveLength, 1)
					convey.So(result[0].UnitPrice, convey.ShouldEqual, "100")
				})
			})
		})

		t.Run("JSON解析失败", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				testCopy := *testProduct
				testCopy.Discount = "{invalid_json"

				result := testCopy.GenQuoteDiscount("0", "2023-01-01", "2023-12-31")

				convey.Convey("应返回空折扣数据", func() {
					convey.So(result, convey.ShouldHaveLength, 1)
					convey.So(result[0].UnitPrice, convey.ShouldEqual, "90")
				})
			})
		})

		t.Run("支付类型映射失败", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				testCopy := *testProduct
				testCopy.CanPrePayCode = "invalid_code"

				result := testCopy.GenQuoteDiscount("0", "2023-01-01", "2023-12-31")

				convey.Convey("应返回默认支付类型", func() {
					convey.So(result[0].PayType, convey.ShouldBeEmpty)
				})
			})
		})

		t.Run("节省计划", func(t *testing.T) {
			mockey.PatchConvey("", t, func() {
				testProduct.SalesMode = multienv.SalesModeSavingsPlans
				testProduct.PrePayRatio = "PrePayRatio"
				testProduct.PrePayRatioCode = "PrePayRatioCode"
				testProduct.SpBuyDuration = "SpBuyDuration"
				testProduct.SpBuyDurationCode = "SpBuyDurationCode"
				testProduct.CommitFeeInterval = "CommitFeeInterval"
				testProduct.CommitFeeIntervalCode = "CommitFeeIntervalCode"

				excepted := &DiscountExtra{
					SavingPlan: &SavingPlanInExtra{
						PrePayRatio:           "PrePayRatio",
						PrePayRatioCode:       "PrePayRatioCode",
						SpBuyDuration:         "SpBuyDuration",
						SpBuyDurationCode:     "SpBuyDurationCode",
						CommitFeeInterval:     "CommitFeeInterval",
						CommitFeeIntervalCode: "CommitFeeIntervalCode",
					},
				}

				mockey.Mock(json.Unmarshal).Return(nil).Build()

				result := testProduct.GenQuoteDiscount("0", "2023-01-01", "2023-12-31")

				convey.Convey("返回节省计划数据", func() {
					convey.So(result, convey.ShouldHaveLength, 1)
					convey.So(result[0].Extra, convey.ShouldResemble, excepted)
				})
			})
		})
	})
}

func Test_ProductInfo_ConvertContractDiscount(t *testing.T) {
	ctx := context.Background()
	validityBegin := time.Now()
	validityEnd := time.Now()
	quoteNo := "quote123"
	contractNo := "contract456"

	mockey.PatchConvey("Test when distributionDiscounts.FirstDiscount is not nil", t, func() {
		p := &ProductInfo{}
		distributionDiscounts := DistributionDiscounts{FirstDiscount: &CustomerDiscount{Discount: &Discount{PricingFunction: "func1"}}}
		body, _ := json.Marshal(distributionDiscounts)
		p.DistributionDiscounts = string(body)
		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.BillingFunction, convey.ShouldEqual, "func1")
		convey.So(actual.ProductValidityBegin, convey.ShouldEqual, validityBegin.Unix())
		convey.So(actual.ProductValidityEnd, convey.ShouldEqual, validityEnd.Unix())
		// ...
	})

	mockey.PatchConvey("Test when distributionDiscounts.FirstDiscount is nil and discount.PricingFunction is not empty", t, func() {
		p := &ProductInfo{}
		p.Discount = `{"PricingFunction": "func"}`
		distributionDiscounts := DistributionDiscounts{}
		body, _ := json.Marshal(distributionDiscounts)
		p.DistributionDiscounts = string(body)
		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.BillingFunction, convey.ShouldEqual, "func")
		convey.So(actual.ProductValidityBegin, convey.ShouldEqual, validityBegin.Unix())
		convey.So(actual.ProductValidityEnd, convey.ShouldEqual, validityEnd.Unix())
		// ...
	})

	mockey.PatchConvey("Test when distributionDiscounts.FirstDiscount is nil and discount.PricingFunction is empty", t, func() {
		p := &ProductInfo{}
		distributionDiscounts := DistributionDiscounts{}
		body, _ := json.Marshal(distributionDiscounts)
		p.DistributionDiscounts = string(body)
		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.BillingFunction, convey.ShouldEqual, "")
		convey.So(actual.ProductValidityBegin, convey.ShouldEqual, validityBegin.Unix())
		convey.So(actual.ProductValidityEnd, convey.ShouldEqual, validityEnd.Unix())
		// ...
	})

	mockey.PatchConvey("Test when validityBegin is zero", t, func() {
		p := &ProductInfo{}
		validityBegin = time.Time{}
		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.ProductValidityBegin, convey.ShouldEqual, 0)
		// ...
	})

	mockey.PatchConvey("Test when validityEnd is zero", t, func() {
		p := &ProductInfo{}
		validityEnd = time.Time{}
		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.ProductValidityEnd, convey.ShouldEqual, 0)
		// ...
	})

	mockey.PatchConvey("Test when distributionDiscounts.FirstDiscount is not nil", t, func() {
		p := &ProductInfo{}
		distributionDiscounts := DistributionDiscounts{FirstDiscount: &CustomerDiscount{Discount: &Discount{PricingFunction: "func1"}}}
		body, _ := json.Marshal(distributionDiscounts)
		p.DistributionDiscounts = string(body)
		p.SalesMode = multienv.SalesModeSavingsPlans
		p.PrePayRatio = "PrePayRatio"
		p.PrePayRatioCode = "PrePayRatioCode"
		p.SpBuyDuration = "SpBuyDuration"
		p.SpBuyDurationCode = "SpBuyDurationCode"
		p.CommitFeeInterval = "CommitFeeInterval"
		p.CommitFeeIntervalCode = "CommitFeeIntervalCode"

		actual := p.ConvertContractDiscount(ctx, validityBegin, validityEnd, quoteNo, contractNo)
		// Add assertions for the expected values of ContractDiscount fields
		convey.So(actual.Extra.SavingPlan.PrePayRatio, convey.ShouldEqual, "PrePayRatio")
		convey.So(actual.Extra.SavingPlan.PrePayRatioCode, convey.ShouldEqual, "PrePayRatioCode")
		convey.So(actual.Extra.SavingPlan.SpBuyDuration, convey.ShouldEqual, "SpBuyDuration")
		convey.So(actual.Extra.SavingPlan.SpBuyDurationCode, convey.ShouldEqual, "SpBuyDurationCode")
		convey.So(actual.Extra.SavingPlan.CommitFeeInterval, convey.ShouldEqual, "CommitFeeInterval")
		convey.So(actual.Extra.SavingPlan.CommitFeeIntervalCode, convey.ShouldEqual, "CommitFeeIntervalCode")
		// ...
	})
}

func Test_GetPricingFunction(t *testing.T) {
	ctx := context.Background()
	discountInfo, distributionDiscounts := "{}", "{}"
	mockey.PatchConvey("Test json.Unmarshal for discountInfo fails", t, func() {
		mockey.Mock(json.Unmarshal).To(func(data []byte, v any) error {
			if string(data) == "{}" {
				return fmt.Errorf("unmarshal discountInfo error")
			}
			return nil
		}).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test json.Unmarshal for distributionDiscounts fails", t, func() {
		discountInfo = `{"PricingFunction": "func"}`
		mockey.Mock(json.Unmarshal).To(func(data []byte, v any) error {
			if string(data) == "{}" {
				return fmt.Errorf("unmarshal distributionDiscounts error")
			}
			return nil
		}).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test both unmarshal success but discount is nil", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test discount has non-empty PricingFunction", t, func() {
		expectedPricingFunction := "function1"
		discount := &Discount{PricingFunction: expectedPricingFunction}
		discountBody, _ := json.Marshal(discount)
		discountInfo = string(discountBody)
		mockey.Mock(getPricingFunctionDesc).To(func(ctx context.Context, pricingFunction string) string { return pricingFunction }).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldEqual, expectedPricingFunction)
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test distributionDiscount has valid PricingFunction", t, func() {
		discountInfo = "{}"
		expectedPricingFunction := "function2"
		distributDiscount := &DistributionDiscounts{
			FirstDiscount: &CustomerDiscount{
				Discount: &Discount{
					PricingFunction: expectedPricingFunction,
				},
			},
		}
		distributDiscountBod, _ := json.Marshal(distributDiscount)
		distributionDiscounts = string(distributDiscountBod)
		mockey.Mock(getPricingFunctionDesc).To(func(ctx context.Context, pricingFunction string) string { return pricingFunction }).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldEqual, expectedPricingFunction)
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test no valid PricingFunction found", t, func() {
		discountInfo, distributionDiscounts = "{}", "{}"
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test found PricingFunction but it's empty", t, func() {
		discountInfo, distributionDiscounts = "{}", "{}"
		actual, err := GetPricingFunction(ctx, discountInfo, distributionDiscounts)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func Test_ParseSimplePriceInfo(t *testing.T) {
	ctx := context.Background()
	priceInfoSnapshot := "{}"
	mockey.PatchConvey("Test json.Unmarshal failed", t, func() {
		mockey.Mock(json.Unmarshal).Return(fmt.Errorf("unmarshal error")).Build()
		actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
		convey.So(actual, convey.ShouldBeEmpty)
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test json.Unmarshal success", t, func() {
		mockey.PatchConvey("Test IsCombining true", func() {
			priceInfo := PriceInfoSnapshot{IsCombining: true, CombiningPrice: 10.5}
			body, _ := json.Marshal(priceInfo)
			priceInfoSnapshot = string(body)
			actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
			convey.So(actual, convey.ShouldEqual, i18nfmt.Sprintf(ctx, "%f%s", 10.5, "元"))
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test IsCombining false and FixedPrice", func() {
			priceInfo := PriceInfoSnapshot{PricingFunction: _const.FixedPrice, Price: decimal.NewFromInt(5)}
			body, _ := json.Marshal(priceInfo)
			priceInfoSnapshot = string(body)
			actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
			convey.So(actual, convey.ShouldEqual, i18nfmt.Sprintf(ctx, "%v 元", 5))
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test IsCombining false and SimpleDiscount", func() {
			priceInfo := PriceInfoSnapshot{PricingFunction: _const.SimpleDiscount, Price: decimal.NewFromInt(7)}
			body, _ := json.Marshal(priceInfo)
			priceInfoSnapshot = string(body)
			actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
			convey.So(actual, convey.ShouldEqual, i18nfmt.Sprintf(ctx, " %v 折", multienv.GetDiscountOffNum(decimal.NewFromInt(7))))
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test IsCombining false and OverProgressive/FullProgressive/FullProgressiveTotal/GuaranteedOverProgressive", func() {
			priceInfo := PriceInfoSnapshot{
				PricingFunction: _const.OverProgressive,
				MeasureInterval: "1,2",
				PriceInterval:   "3,4",
			}
			body, _ := json.Marshal(priceInfo)
			priceInfoSnapshot = string(body)
			actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
			// Add assertion based on expected result
			convey.So(actual, convey.ShouldEqual, i18nfmt.Sprintf(ctx, strings.Join([]string{"[0, 2], 3 元", "(2, +∞), 4 元"}, ";\n")))
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test IsCombining false and RelatedChargeItemRatio", func() {
			priceInfo := PriceInfoSnapshot{
				PricingFunction:        _const.RelatedChargeItemRatio,
				RelatedChargeItemRatio: decimal.NewFromFloat(0.2),
				Price:                  decimal.NewFromInt(8),
			}
			body, _ := json.Marshal(priceInfo)
			priceInfoSnapshot = string(body)
			actual, err := ParseSimplePriceInfo(ctx, priceInfoSnapshot)
			convey.So(actual, convey.ShouldEqual, i18nfmt.Sprintf(ctx, " 固定比例:%v %%, 人民币: %v元", priceInfo.RelatedChargeItemRatio.Mul(decimal.NewFromInt(100)), priceInfo.Price.Mul(decimal.NewFromInt(10))))
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_GetDiscountArrCommon(t *testing.T) {
	ctx := context.Background()
	discount, distributionDiscounts := "discount_value", "distribution_discounts_value"
	mockey.PatchConvey("Test GetDiscount success", t, func() {
		mockey.Mock(GetDistributionDiscounts).Return([]string{"discount_res"}, "discount_pricing_function", nil).Build()
		actualRes, actualPricingFunction, actualErr := GetDiscountArrCommon(ctx, discount, distributionDiscounts)
		convey.So(actualRes, convey.ShouldResemble, []string{"discount_res"})
		convey.So(actualPricingFunction, convey.ShouldEqual, "discount_pricing_function")
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test GetDiscount fail", t, func() {
		mockey.Mock(GetDistributionDiscounts).Return([]string{}, "", fmt.Errorf("get_discount_fail")).Build()
		mockey.PatchConvey("Test GetDistributionDiscounts success", func() {
			mockey.Mock(GetDiscount).Return([]string{"distribution_res"}, "distribution_pricing_function", nil).Build()
			actualRes, actualPricingFunction, actualErr := GetDiscountArrCommon(ctx, discount, distributionDiscounts)
			convey.So(actualRes, convey.ShouldResemble, []string{"distribution_res"})
			convey.So(actualPricingFunction, convey.ShouldEqual, "distribution_pricing_function")
			convey.So(actualErr, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test GetDistributionDiscounts fail", func() {
			mockey.Mock(GetDiscount).Return([]string{}, "", fmt.Errorf("get_distribution_discounts_fail")).Build()
			actualRes, actualPricingFunction, actualErr := GetDiscountArrCommon(ctx, discount, distributionDiscounts)
			convey.So(actualRes, convey.ShouldBeEmpty)
			convey.So(actualPricingFunction, convey.ShouldBeEmpty)
			convey.So(actualErr, convey.ShouldNotBeNil)
		})
	})
}

func Test_GetDiscount(t *testing.T) {
	ctx := context.Background()
	discountInfo := "{\"name\":\"example\"}"
	mockey.PatchConvey("Test discountInfo Unmarshal failed", t, func() {
		mockey.Mock(json.Unmarshal).Return(fmt.Errorf("unmarshal error")).Build()
		actualList, actualStr, err := GetDiscount(ctx, discountInfo)
		convey.So(actualList, convey.ShouldResemble, []string{})
		convey.So(actualStr, convey.ShouldEqual, "")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test discountInfo Unmarshal success", t, func() {
		mockey.Mock(json.Unmarshal).Return(nil).Build()
		mockey.PatchConvey("Test BuildDiscountStr failed", func() {
			mockey.Mock(BuildDiscountStr).Return([]string{}, "", fmt.Errorf("build discount str failed")).Build()
			actualList, actualStr, err := GetDiscount(ctx, discountInfo)
			convey.So(actualList, convey.ShouldResemble, []string{})
			convey.So(actualStr, convey.ShouldEqual, "")
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("Test BuildDiscountStr success", func() {
			expectedList := []string{"item1", "item2"}
			expectedStr := "discount string"
			mockey.Mock(BuildDiscountStr).Return(expectedList, expectedStr, nil).Build()
			actualList, actualStr, err := GetDiscount(ctx, discountInfo)
			convey.So(actualList, convey.ShouldResemble, expectedList)
			convey.So(actualStr, convey.ShouldEqual, expectedStr)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_GetDistributionDiscounts(t *testing.T) {
	ctx := context.Background()
	discountInfo := "{}"
	mockey.PatchConvey("Test discountInfo unmarshal fail", t, func() {
		mockey.Mock(json.Unmarshal).Return(fmt.Errorf("unmarshal error")).Build()
		actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
		convey.So(actualRes, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test discountInfo unmarshal success", t, func() {
		mockey.PatchConvey("Test buildDistributionDiscountsStr for FirstDiscount fail", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"xxx\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{})
			convey.So(actualPricingFunction, convey.ShouldEqual, "")
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("Test buildDistributionDiscountsStr for FirstDiscount success", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{
				"3000009113", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009114", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009115", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
			})
			convey.So(actualPricingFunction, convey.ShouldEqual, "全额累进单价")
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test buildDistributionDiscountsStr for SecondDiscount fail", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"xxxx\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{})
			convey.So(actualPricingFunction, convey.ShouldEqual, "")
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("Test buildDistributionDiscountsStr for SecondDiscount success", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{
				"3000009113", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009114", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009115", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
			})
			convey.So(actualPricingFunction, convey.ShouldEqual, "全额累进单价")
			convey.So(err, convey.ShouldBeNil)
		})
		mockey.PatchConvey("Test buildDistributionDiscountsStr for FinalDiscount fail", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"xxxxx\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{})
			convey.So(actualPricingFunction, convey.ShouldEqual, "")
			convey.So(err, convey.ShouldNotBeNil)
		})
		mockey.PatchConvey("Test buildDistributionDiscountsStr for FinalDiscount success", func() {
			discountInfo = "{\"FirstDiscount\":{\"CustomerType\":\"FirstDistributor\",\"AccountID\":\"3000009113\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":true}},\"SecondDiscount\":{\"CustomerType\":\"SecondDistributor\",\"AccountID\":\"3000009114\",\"OwnerID\":\"3000009115\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}},\"FinalDiscount\":{\"CustomerType\":\"FinalCustomer\",\"AccountID\":\"3000009115\",\"OwnerID\":\"*\",\"CustomerName\":\"kanna_test\",\"Discount\":{\"PricingFunction\":\"full_progressive\",\"UnitPriceInterval\":\"1,2,2\",\"MeasureInterval\":\"0,1,3\",\"UnitPrice\":\"0\",\"Assigned\":false}}}"
			actualRes, actualPricingFunction, err := GetDistributionDiscounts(ctx, discountInfo)
			convey.So(actualRes, convey.ShouldResemble, []string{
				"3000009113", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009114", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
				"3000009115", "[0, 1], 1元", "(1, 3], 2元", "(3, +∞), 2元",
			})
			convey.So(actualPricingFunction, convey.ShouldEqual, "全额累进单价")
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_buildDistributionDiscountsStr(t *testing.T) {
	ctx := context.Background()
	discount := &CustomerDiscount{
		CustomerInfo: CustomerInfo{
			CustomerType: "FirstDistributor",
			AccountID:    "123",
			OwnerID:      "456",
			CustomerName: "John Doe",
		},
		Discount: &Discount{
			PricingFunction:   "Fixed",
			UnitPriceInterval: "Monthly",
			MeasureInterval:   "PerUnit",
			UnitPrice:         decimal.NewFromFloat(10.5),
		},
	}
	mockey.PatchConvey("Test BuildDiscountStr failed", t, func() {
		mockey.Mock(BuildDiscountStr).Return([]string{}, "", fmt.Errorf("BuildDiscountStr error")).Build()
		actualRes, actualPricingFunction, err := buildDistributionDiscountsStr(ctx, discount)
		convey.So(actualRes, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test BuildDiscountStr success", t, func() {
		expectedFirstDiscount := []string{"Discount1", "Discount2"}
		expectedFirstPricingFunction := "Variable"
		mockey.Mock(BuildDiscountStr).Return(expectedFirstDiscount, expectedFirstPricingFunction, nil).Build()
		mockey.PatchConvey("Test append loop", func() {
			actualRes, actualPricingFunction, err := buildDistributionDiscountsStr(ctx, discount)
			expectedRes := []string{
				discount.CustomerInfo.AccountID,
				"Discount1",
				"Discount2",
			}
			convey.So(actualRes, convey.ShouldResemble, expectedRes)
			convey.So(actualPricingFunction, convey.ShouldEqual, expectedFirstPricingFunction)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_BuildDiscountStr(t *testing.T) {
	ctx := context.Background()
	mockey.PatchConvey("Test getPricingFunctionDesc failed", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("").Build()
		discount := &Discount{}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test FixedPrice case", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("fixed").Build()
		discount := &Discount{PricingFunction: _const.FixedPrice, UnitPrice: decimal.NewFromFloat(10)}
		expected := []string{i18nfmt.Sprintf(ctx, "%s元", discount.UnitPrice.String())}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "fixed")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test FullProgressive, OverProgressive, FullProgressiveTotal cases with correct measure and unit price intervals", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("progressive").Build()
		discount := &Discount{
			PricingFunction:   _const.FullProgressive,
			MeasureInterval:   "1,2,3",
			UnitPriceInterval: "10,20,30",
		}
		expected := []string{
			i18nfmt.Sprintf(ctx, "[1, 2], 10元"),
			i18nfmt.Sprintf(ctx, "(2, 3], 20元"),
			i18nfmt.Sprintf(ctx, "(3, +∞), 30元"),
		}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "progressive")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test FullProgressive, OverProgressive, FullProgressiveTotal cases with incorrect measure and unit price intervals", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("progressive").Build()
		discount := &Discount{
			PricingFunction:   _const.FullProgressive,
			MeasureInterval:   "1,2",
			UnitPriceInterval: "10,20,30",
		}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "progressive")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test SimpleDiscount case", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("simple").Build()
		discount := &Discount{PricingFunction: _const.SimpleDiscount, UnitPrice: decimal.NewFromFloat(0.8)}
		expected := []string{i18nfmt.Sprintf(ctx, "%s折", multienv.GetDiscountOffNum(discount.UnitPrice))}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "simple")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test TimeDiscount case with supported type", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("time").Build()
		discount := &Discount{
			PricingFunction:   _const.TimeDiscount,
			MeasureInterval:   `{"key1": "1,2"}`,
			UnitPriceInterval: `{"key1": "0.1,0.2"}`,
		}
		expected := []string{"key1", "满1key1，1折", "满2key1，2折"}
		mockey.Mock(multienv.GetTimeDiscountUnitMapping).To(func() map[string]string {
			return map[string]string{"key1": "key1"}
		}).Build()
		mockey.Mock(multienv.GetTimeDiscountMapping).To(func() map[string]interface{} {
			return map[string]interface{}{"key1": "key1"}
		}).Build()
		mockey.Mock(multienv.GetTimeDiscountNameByCodeMapping).To(func() map[string]string {
			return map[string]string{"key1": "key1"}
		}).Build()
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "time")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test TimeDiscount case with unsupported type", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("time").Build()
		discount := &Discount{
			PricingFunction:   _const.TimeDiscount,
			MeasureInterval:   `{"key2": "1,2"}`,
			UnitPriceInterval: `{"key2": "10,20"}`,
		}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "time")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test QuantityDiscount case", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("quantity").Build()
		discount := &Discount{
			PricingFunction:   _const.QuantityDiscount,
			MeasureInterval:   "10",
			UnitPriceInterval: "0.5",
		}
		expected := []string{i18nfmt.Sprintf(ctx, "买满10个，打%s折", multienv.GetDiscountOffNum(decimal.NewFromFloat(0.5)))}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "quantity")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test TotalOverAmountDiscount case", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("total_over_amount").Build()
		discount := &Discount{
			PricingFunction:   _const.TotalOverAmountDiscount,
			MeasureInterval:   "100,200",
			UnitPriceInterval: "0.8,0.6",
		}
		expected := []string{
			i18nfmt.Sprintf(ctx, "满100元, %s折", multienv.GetDiscountOffNum(decimal.RequireFromString("0.8"))),
			i18nfmt.Sprintf(ctx, "满200元, %s折", multienv.GetDiscountOffNum(decimal.RequireFromString("0.6"))),
		}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, expected)
		convey.So(actualPricingFunction, convey.ShouldEqual, "total_over_amount")
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test TotalOverAmountDiscount case with incorrect measure and unit price intervals", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("total_over_amount").Build()
		discount := &Discount{
			PricingFunction:   _const.TotalOverAmountDiscount,
			MeasureInterval:   "100",
			UnitPriceInterval: "0.8,0.6",
		}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "total_over_amount")
		convey.So(err, convey.ShouldNotBeNil)
	})
	mockey.PatchConvey("Test unrecognized pricing function", t, func() {
		mockey.Mock(getPricingFunctionDesc).Return("unknown").Build()
		discount := &Discount{PricingFunction: "unknown"}
		actual, actualPricingFunction, err := BuildDiscountStr(ctx, discount)
		convey.So(actual, convey.ShouldResemble, []string{})
		convey.So(actualPricingFunction, convey.ShouldEqual, "unknown")
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func Test_getPricingFunctionDesc(t *testing.T) {
	t.Run("case hitMap", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()

			// Act
			got := getPricingFunctionDesc(context.Background(), _const.FixedPrice)

			// Assert
			convey.So(got, convey.ShouldEqual, _const.FixedPriceDesc)
		})
	})
	t.Run("case UnSupport", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			mockey.Mock(multienv.I18nFormat).To(func(ctx context.Context, v string) string { return v }).Build()

			// Act
			got := getPricingFunctionDesc(context.Background(), "UnSupport")

			// Assert
			convey.So(got, convey.ShouldEqual, "")
		})
	})
}

func TestGetDiscount(t *testing.T) {
	// Arrange
	type args struct {
		ctx          context.Context
		discountInfo string
	}
	tests := []struct {
		name    string
		args    args
		mocks   func()
		want    []string
		want1   string
		wantErr bool
	}{
		{
			name: "case #1",
			args: args{
				ctx:          context.Background(),
				discountInfo: "",
			},
			mocks: func() {
			},
			want:    nil,
			want1:   "",
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockey.PatchConvey(tt.name, t, func() {
				// Prepares-mock
				tt.mocks()

				// Act
				_, _, err := GetDiscount(
					tt.args.ctx,
					tt.args.discountInfo,
				)

				// Assert
				convey.So(err != nil, convey.ShouldEqual, tt.wantErr)
			})
		})
	}
}

func Test_GetDefaultSubjectSealEnable(t *testing.T) {
	ctx := context.Background()
	relateQuoteNo := ""
	bizScene := _const.BizSceneSalesContract

	p := &TradePartyInfoDetail{
		Sealed: 1,
	}

	mockey.PatchConvey("Test relateQuoteNo is empty and bizScene is BizSceneSalesContract", t, func() {
		actual := p.GetDefaultSubjectSealEnable(ctx, relateQuoteNo, bizScene)
		convey.So(actual, convey.ShouldEqual, p.Sealed)
	})

	mockey.PatchConvey("Test relateQuoteNo is not empty and bizScene is BizSceneSalesContract", t, func() {
		relateQuoteNo = "12345"
		actual := p.GetDefaultSubjectSealEnable(ctx, relateQuoteNo, bizScene)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test relateQuoteNo is empty and bizScene is not BizSceneSalesContract", t, func() {
		bizScene = _const.BizSceneCreditContract
		actual := p.GetDefaultSubjectSealEnable(ctx, relateQuoteNo, bizScene)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test relateQuoteNo is not empty and bizScene is not BizSceneSalesContract", t, func() {
		relateQuoteNo = "12345"
		bizScene = _const.BizSceneCreditContract
		actual := p.GetDefaultSubjectSealEnable(ctx, relateQuoteNo, bizScene)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})
}

func Test_GetDefaultOtherPartySealEnable(t *testing.T) {
	ctx := context.Background()
	relateQuoteNo := "12345"
	bizScene := 1
	bizSource := 1
	p := &TradePartyInfoDetail{
		Sealed: 0,
	}

	mockey.PatchConvey("Test bizScene is BizScenePayOnBehalf", t, func() {
		bizScene = _const.BizScenePayOnBehalf
		actual := p.GetDefaultOtherPartySealEnable(ctx, relateQuoteNo, bizScene, bizSource)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test bizScene is BizSceneQuoteContract", t, func() {
		bizScene = _const.BizSceneQuoteContract
		mockey.Mock(util.IntIn).Return(true).Build()
		actual := p.GetDefaultOtherPartySealEnable(ctx, relateQuoteNo, bizScene, bizSource)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test bizScene is BizSceneCreditContract", t, func() {
		bizScene = _const.BizSceneCreditContract
		mockey.Mock(util.IntIn).Return(true).Build()
		actual := p.GetDefaultOtherPartySealEnable(ctx, relateQuoteNo, bizScene, bizSource)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test bizScene is BizScenePartnerContract", t, func() {
		bizScene = _const.BizScenePartnerContract
		mockey.Mock(util.IntIn).Return(true).Build()
		actual := p.GetDefaultOtherPartySealEnable(ctx, relateQuoteNo, bizScene, bizSource)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test bizScene is not in the list and relateQuoteNo is not empty and bizSource is BizSourceCooperation", t, func() {
		bizSource = _const.BizSourceCooperation
		mockey.Mock(util.IntIn).Return(false).Build()
		actual := p.GetDefaultOtherPartySealEnable(ctx, relateQuoteNo, bizScene, bizSource)
		convey.So(actual, convey.ShouldEqual, _const.TRUE_FLAG_INT)
	})

	mockey.PatchConvey("Test default case", t, func() {
		mockey.Mock(util.IntIn).Return(false).Build()
		bizSource = _const.BizSourceQuote
		actual := p.GetDefaultOtherPartySealEnable(ctx, "", _const.BizSourceFee, bizSource)
		convey.So(actual, convey.ShouldEqual, p.Sealed)
	})
}

func Test_NeedRefreshSealedAndPricing(t *testing.T) {
	mockey.PatchConvey("Test NeedRefreshSealedAndPricing", t, func() {
		tPartyInfo := &TradePartyInfo{
			Subject: []*TradePartyInfoDetail{
				{Sealed: _const.FALSE_FLAG_INT},
				{Sealed: _const.FALSE_FLAG_INT},
			},
			OtherParty: []*TradePartyInfoDetail{
				{Sealed: _const.FALSE_FLAG_INT},
				{Sealed: _const.FALSE_FLAG_INT},
			},
		}
		mockey.PatchConvey("Test all Sealed are false", func() {
			actual := tPartyInfo.NeedRefreshSealedAndPricing()
			convey.So(actual, convey.ShouldBeTrue)
		})
		mockey.PatchConvey("Test one Sealed is true in Subject", func() {
			tPartyInfo.Subject[0].Sealed = _const.TRUE_FLAG_INT
			actual := tPartyInfo.NeedRefreshSealedAndPricing()
			convey.So(actual, convey.ShouldBeFalse)
		})
		mockey.PatchConvey("Test one Sealed is true in OtherParty", func() {
			tPartyInfo.OtherParty[0].Sealed = _const.TRUE_FLAG_INT
			actual := tPartyInfo.NeedRefreshSealedAndPricing()
			convey.So(actual, convey.ShouldBeFalse)
		})
		mockey.PatchConvey("Test one Sealed is true in both Subject and OtherParty", func() {
			tPartyInfo.Subject[0].Sealed = _const.TRUE_FLAG_INT
			tPartyInfo.OtherParty[0].Sealed = _const.TRUE_FLAG_INT
			actual := tPartyInfo.NeedRefreshSealedAndPricing()
			convey.So(actual, convey.ShouldBeFalse)
		})
	})
}

func Test_SealOrderCheck(t *testing.T) {
	sealOrderOurSide := _const.OurSide
	sealOrderOtherSide := _const.OtherSide

	tPartyInfo := &TradePartyInfo{
		Subject: []*TradePartyInfoDetail{
			{Sealed: _const.TRUE_FLAG_INT},
			{Sealed: _const.FALSE_FLAG_INT},
		},
		OtherParty: []*TradePartyInfoDetail{
			{Sealed: _const.TRUE_FLAG_INT},
			{Sealed: _const.FALSE_FLAG_INT},
		},
	}

	mockey.PatchConvey("Test SealOrderCheck with sealOrder = OurSide and Subject has sealed party", t, func() {
		actual := tPartyInfo.SealOrderCheck(sealOrderOurSide)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test SealOrderCheck with sealOrder = OurSide and Subject has no sealed party", t, func() {
		tPartyInfo.Subject[0].Sealed = _const.FALSE_FLAG_INT
		actual := tPartyInfo.SealOrderCheck(sealOrderOurSide)
		expectedError := errors.ErrorCommon.WithArgs("先盖章方=我方先签约：我方必须存在需要签约的对象")
		convey.So(actual, convey.ShouldResemble, expectedError)
	})

	mockey.PatchConvey("Test SealOrderCheck with sealOrder = OtherSide and OtherParty has sealed party", t, func() {
		actual := tPartyInfo.SealOrderCheck(sealOrderOtherSide)
		convey.So(actual, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test SealOrderCheck with sealOrder = OtherSide and OtherParty has no sealed party", t, func() {
		tPartyInfo.OtherParty[0].Sealed = _const.FALSE_FLAG_INT
		actual := tPartyInfo.SealOrderCheck(sealOrderOtherSide)
		expectedError := errors.ErrorCommon.WithArgs("先盖章方=对方先签约：对方必须存在需要签约的对象")
		convey.So(actual, convey.ShouldResemble, expectedError)
	})

	mockey.PatchConvey("Test SealOrderCheck with invalid sealOrder", t, func() {
		actual := tPartyInfo.SealOrderCheck("invalid_seal_order")
		convey.So(actual, convey.ShouldBeNil)
	})
}

func Test_CheckPayTypes(t *testing.T) {

	mockey.PatchConvey("Test CheckPayTypes with valid OpInfoId in Subject", t, func() {
		subjectParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "123", OpInfoId: "123"},
				{AccountNumber: "456", OpInfoId: "456"},
			},
		}
		otherParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "789", OpInfoId: "789"},
				{AccountNumber: "123", OpInfoId: "123"},
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subjectParty},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.CheckPayTypes()
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test CheckPayTypes with invalid OpInfoId in Subject", t, func() {
		subjectParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "123", OpInfoId: ""},
				{AccountNumber: "456", OpInfoId: "456"},
			},
		}
		otherParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "789", OpInfoId: "789"},
				{AccountNumber: "123", OpInfoId: "123"},
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subjectParty},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.CheckPayTypes()
		expectedErr := errors.ErrorCommon.WithArgs("银行账号ID-主数据唯一编码为空")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})

	mockey.PatchConvey("Test CheckPayTypes with valid OpInfoId in OtherParty", t, func() {
		subjectParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "123", OpInfoId: "123"},
				{AccountNumber: "456", OpInfoId: "456"},
			},
		}
		otherParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "789", OpInfoId: "789"},
				{AccountNumber: "123", OpInfoId: "123"},
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subjectParty},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.CheckPayTypes()
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test CheckPayTypes with invalid OpInfoId in OtherParty", t, func() {
		subjectParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "123", OpInfoId: "123"},
				{AccountNumber: "456", OpInfoId: "456"},
			},
		}
		otherParty := &TradePartyInfoDetail{
			PayTypes: []*PayType{
				{AccountNumber: "789", OpInfoId: ""},
				{AccountNumber: "123", OpInfoId: "123"},
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subjectParty},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.CheckPayTypes()
		expectedErr := errors.ErrorCommon.WithArgs("银行账号ID-主数据唯一编码为空")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})
}

func Test_Validate(t *testing.T) {
	ctx := context.Background()
	inOutType := "IN"
	mockey.PatchConvey("Test Validate with invalid inOutType", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.FALSE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, "INVALID")
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("【Party1】是否需要签约、是否需要配价不允许同时选择否"))
	})

	mockey.PatchConvey("Test Validate with valid inOutType and no signed party", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.FALSE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("【Party1】是否需要签约、是否需要配价不允许同时选择否"))
	})

	mockey.PatchConvey("Test Validate with valid inOutType and signed party with seal account ID", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test Validate with valid inOutType and pricing party with pricing account ID", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.TRUE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "123456",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test Validate with valid inOutType and no signed party in other party", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.FALSE_FLAG_INT,
				Pricing:          _const.TRUE_FLAG_INT,
				SealAccountID:    "",
				PricingAccountID: "123456",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("至少要有一个对方主体需要签约"))
	})

	mockey.PatchConvey("Test Validate with valid inOutType and signed party in both subject and other party", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test Validate with valid inOutType and no signed party in subject", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.FALSE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("收入类 / 支出类 / 既收又支，需存在是否需要签约为“是”的我方主体"))
	})

	mockey.PatchConvey("Test Validate with OUT inOutType and no pricing party in other party", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.FALSE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test subject partyNumber is nil", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:    _const.TRUE_FLAG_INT,
				PartyName: "subject",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				PartyNumber:      "123",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.TRUE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "123456",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("【subject】PartyNumber is nil"))
	})

	mockey.PatchConvey("Test otherParty partyNumber is nil", t, func() {
		subject := []*TradePartyInfoDetail{
			{
				Sealed:      _const.TRUE_FLAG_INT,
				PartyNumber: "123",
			},
		}
		otherParty := []*TradePartyInfoDetail{
			{
				PartyName:        "Party1",
				Sealed:           _const.TRUE_FLAG_INT,
				Pricing:          _const.TRUE_FLAG_INT,
				SealAccountID:    "123456",
				PricingAccountID: "123456",
			},
		}
		tradePartyInfo := &TradePartyInfo{
			Subject:    subject,
			OtherParty: otherParty,
		}
		actualErr := tradePartyInfo.Validate(ctx, inOutType)
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("【Party1】PartyNumber is nil"))
	})
}

func Test_ManageInfo_validateBuyNum_BitsUTGen(t *testing.T) {
	ctx := context001.Background()
	const nonMasterRecordType = 2
	const privateDeploymentType = 1

	mockey.PatchConvey("Test ManageInfo.validateBuyNum", t, func() {
		mockey.PatchConvey("Return nil when product maps are built and skipped records are ignored", func() {
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group-a": {
						&ProductInfo{QuoteItemID: "inner-1", BuyNum: "5"},
					},
				},
				DeductProductInfoMap: map[string][]*ProductInfo{
					"group-b": {
						&ProductInfo{QuoteItemID: "deduct-1", BuyNum: "2"},
					},
				},
				ExternalProductList: ExternalProductInfoList{
					{
						GroupID:           1,
						RelateQuoteItemID: "skip-master",
						RecordType:        _const.ExternalCommodityRecordTypeMaster,
						DeploymentType:    privateDeploymentType,
						BuyNum:            "",
					},
					{
						GroupID:           2,
						RelateQuoteItemID: "skip-public",
						RecordType:        nonMasterRecordType,
						DeploymentType:    _const.SettlementDeploymentPublicCloud,
						BuyNum:            "",
					},
					{
						GroupID:           3,
						RelateQuoteItemID: "inner-1",
						RecordType:        nonMasterRecordType,
						DeploymentType:    privateDeploymentType,
						BuyNum:            "10.5",
					},
				},
			}

			err := m.validateBuyNum(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Return internal error when buy number is empty", func() {
			commodity := &ExternalProductInfo{
				GroupID:           11,
				RelateQuoteItemID: "item-empty",
				RecordType:        nonMasterRecordType,
				DeploymentType:    privateDeploymentType,
				BuyNum:            "",
			}
			m := &ManageInfo{
				ExternalProductList: ExternalProductInfoList{commodity},
			}

			expectedMessage := i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为空",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum)

			err := m.validateBuyNum(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(err.GetArgs(), convey.ShouldHaveLength, 1)
			convey.So(err.GetArgs()[0], convey.ShouldEqual, expectedMessage)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedMessage)
		})

		mockey.PatchConvey("Return internal error when buy number format is invalid", func() {
			commodity := &ExternalProductInfo{
				GroupID:           12,
				RelateQuoteItemID: "item-invalid",
				RecordType:        nonMasterRecordType,
				DeploymentType:    privateDeploymentType,
				BuyNum:            "abc",
			}
			m := &ManageInfo{
				ExternalProductList: ExternalProductInfoList{commodity},
			}

			_, parseErr := decimal.NewFromString(commodity.BuyNum)
			convey.So(parseErr, convey.ShouldNotBeNil)

			expectedMessage := i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]格式异常[%s]",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum, parseErr.Error())

			err := m.validateBuyNum(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(err.GetArgs(), convey.ShouldHaveLength, 1)
			convey.So(err.GetArgs()[0], convey.ShouldEqual, expectedMessage)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedMessage)
		})

		mockey.PatchConvey("Return internal error when buy number is not greater than zero", func() {
			commodity := &ExternalProductInfo{
				GroupID:           13,
				RelateQuoteItemID: "item-non-positive",
				RecordType:        nonMasterRecordType,
				DeploymentType:    privateDeploymentType,
				BuyNum:            "-1",
			}
			m := &ManageInfo{
				ExternalProductList: ExternalProductInfoList{commodity},
			}

			expectedMessage := i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为0",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum)

			err := m.validateBuyNum(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.GetCode(), convey.ShouldEqual, errors.ErrInternalError.GetCode())
			convey.So(err.GetArgs(), convey.ShouldHaveLength, 1)
			convey.So(err.GetArgs()[0], convey.ShouldEqual, expectedMessage)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedMessage)
		})
	})
}

func Test_FillSealType(t *testing.T) {
	sealType := "TestSealType"

	mockey.PatchConvey("Test FillSealType with empty Subject", t, func() {
		tpi := &TradePartyInfo{
			Subject: []*TradePartyInfoDetail{},
		}
		tpi.FillSealType(sealType)
		convey.So(tpi.Subject, convey.ShouldBeEmpty)
	})

	mockey.PatchConvey("Test FillSealType with non-empty Subject", t, func() {
		subject1 := &TradePartyInfoDetail{
			NACustomerTag: "NA1",
			CustomerName:  "Customer1",
			SealType:      "",
		}
		subject2 := &TradePartyInfoDetail{
			NACustomerTag: "NA2",
			CustomerName:  "Customer2",
			SealType:      "",
		}
		tpi := &TradePartyInfo{
			Subject: []*TradePartyInfoDetail{subject1, subject2},
		}
		tpi.FillSealType(sealType)
		convey.So(subject1.SealType, convey.ShouldEqual, sealType)
		convey.So(subject2.SealType, convey.ShouldEqual, sealType)
	})
}

func Test_FillAccountID(t *testing.T) {
	mockey.PatchConvey("Test no OtherParty", t, func() {
		tradePartyInfo := &TradePartyInfo{
			OtherParty: nil,
		}
		tradePartyInfo.FillAccountID()
		convey.So(tradePartyInfo.OtherParty, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test OtherParty with Sealed and Pricing true", t, func() {
		tradePartyInfo := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Sealed:           _const.TRUE_FLAG_INT,
					Pricing:          _const.TRUE_FLAG_INT,
					AccountID:        "12345",
					SealAccountID:    "",
					PricingAccountID: "",
				},
			},
		}
		tradePartyInfo.FillAccountID()
		convey.So(tradePartyInfo.OtherParty[0].SealAccountID, convey.ShouldEqual, "12345")
		convey.So(tradePartyInfo.OtherParty[0].PricingAccountID, convey.ShouldEqual, "12345")
	})

	mockey.PatchConvey("Test OtherParty with Sealed true and Pricing false", t, func() {
		tradePartyInfo := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Sealed:           _const.TRUE_FLAG_INT,
					Pricing:          0,
					AccountID:        "12345",
					SealAccountID:    "",
					PricingAccountID: "",
				},
			},
		}
		tradePartyInfo.FillAccountID()
		convey.So(tradePartyInfo.OtherParty[0].SealAccountID, convey.ShouldEqual, "12345")
		convey.So(tradePartyInfo.OtherParty[0].PricingAccountID, convey.ShouldEqual, "")
	})

	mockey.PatchConvey("Test OtherParty with Sealed false and Pricing true", t, func() {
		tradePartyInfo := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Sealed:           0,
					Pricing:          _const.TRUE_FLAG_INT,
					AccountID:        "12345",
					SealAccountID:    "",
					PricingAccountID: "",
				},
			},
		}
		tradePartyInfo.FillAccountID()
		convey.So(tradePartyInfo.OtherParty[0].SealAccountID, convey.ShouldEqual, "")
		convey.So(tradePartyInfo.OtherParty[0].PricingAccountID, convey.ShouldEqual, "12345")
	})

	mockey.PatchConvey("Test OtherParty with Sealed and Pricing false", t, func() {
		tradePartyInfo := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Sealed:           0,
					Pricing:          0,
					AccountID:        "12345",
					SealAccountID:    "",
					PricingAccountID: "",
				},
			},
		}
		tradePartyInfo.FillAccountID()
		convey.So(tradePartyInfo.OtherParty[0].SealAccountID, convey.ShouldEqual, "")
		convey.So(tradePartyInfo.OtherParty[0].PricingAccountID, convey.ShouldEqual, "")
	})
}

func Test_SettlementInfo_Validate_BitsUTGen(t *testing.T) {
	ctx := context001.Background()

	mockey.PatchConvey("Test SettlementInfo.Validate", t, func() {
		mockey.PatchConvey("正常场景-结算条款为空", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{},
			}

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("正常场景-校验成功", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "60",
						InvoicingTotal:   "6000",
						PaymentPercent:   "40",
						PaymentTotal:     "4000",
					},
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "40",
						InvoicingTotal:   "4000",
						PaymentPercent:   "60",
						PaymentTotal:     "6000",
					},
					{
						PaymentGroup: 0, // 该行应被忽略
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("异常场景-子结算条款校验失败", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{{}},
			}
			expectedErr := errors001.New("sub-validation failed")
			mockey.Mock(SettlementLine.Validate).Return(expectedErr).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldEqual, expectedErr)
		})

		mockey.PatchConvey("异常场景-公有云部署下付款方式不合法", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						DeploymentType: _const.SettlementDeploymentPublicCloud,
						PaymentGroup:   1,
						PayMethod:      _const.SettlementPaymentMethodProgressPay,
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "公有云部署方式下，付款方式只能是预付费或者后付费")
		})

		mockey.PatchConvey("异常场景-公有云部署下付款方式重复", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						DeploymentType:   _const.SettlementDeploymentPublicCloud,
						PaymentGroup:     1,
						PayMethod:        _const.SettlementPaymentMethodPrePay,
						InvoicingPercent: "50",
						InvoicingTotal:   "500",
						PaymentPercent:   "50",
						PaymentTotal:     "500",
					},
					{
						DeploymentType:   _const.SettlementDeploymentPublicCloud,
						PaymentGroup:     1,
						PayMethod:        _const.SettlementPaymentMethodPrePay,
						InvoicingPercent: "50",
						InvoicingTotal:   "500",
						PaymentPercent:   "50",
						PaymentTotal:     "500",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context001.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "公有云部署方式下，同一付款方式只能存在一行 付款方式：预付费重复")
		})

		mockey.PatchConvey("异常场景-开票比例小于0", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						PaymentGroup:     1,
						InvoicingPercent: "-10",
						InvoicingTotal:   "100",
						PaymentPercent:   "100",
						PaymentTotal:     "100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context001.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[1]开票比例参数不正确")
		})

		mockey.PatchConvey("异常场景-开票金额为负数", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						PaymentGroup:     1,
						InvoicingPercent: "100",
						InvoicingTotal:   "-100",
						PaymentPercent:   "100",
						PaymentTotal:     "100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context001.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[1]开票金额参数不正确")
		})

		mockey.PatchConvey("异常场景-付款比例大于100", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						PaymentGroup:     2,
						InvoicingPercent: "100",
						InvoicingTotal:   "100",
						PaymentPercent:   "101",
						PaymentTotal:     "100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[2]付款比例参数不正确")
		})

		mockey.PatchConvey("异常场景-付款金额为负数", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						PaymentGroup:     3,
						InvoicingPercent: "100",
						InvoicingTotal:   "100",
						PaymentPercent:   "100",
						PaymentTotal:     "-100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[3]付款金额参数不正确")
		})

		mockey.PatchConvey("异常场景-开票比例之和不为100", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "50",
						InvoicingTotal:   "100",
						PaymentPercent:   "100",
						PaymentTotal:     "100",
					},
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "40",
						InvoicingTotal:   "100",
						PaymentPercent:   "0",
						PaymentTotal:     "100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[1]开票比例之和不为100")
		})

		mockey.PatchConvey("异常场景-付款比例之和不为100", func() {

			s := &SettlementInfo{
				SettlementLines: []*SettlementLine{
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "100",
						InvoicingTotal:   "100",
						PaymentPercent:   "50",
						PaymentTotal:     "100",
					},
					{
						DeploymentType:   _const.SettlementDeploymentPrivateCloud,
						PaymentGroup:     1,
						InvoicingPercent: "0",
						InvoicingTotal:   "100",
						PaymentPercent:   "60",
						PaymentTotal:     "100",
					},
				},
			}
			mockey.Mock(SettlementLine.Validate).Return(nil).Build()

			err := s.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "结算条款中付款组别[1]付款比例之和不为100")
		})

		mockey.PatchConvey("异常场景-金额或比例字符串解析失败", func() {

			testCases := []struct {
				name        string
				settlements []*SettlementLine
			}{
				{
					name: "InvoicingPercent_ParseFail",
					settlements: []*SettlementLine{
						{PaymentGroup: 1, InvoicingPercent: "fail", InvoicingTotal: "0", PaymentPercent: "0", PaymentTotal: "0"},
					},
				},
				{
					name: "InvoicingTotal_ParseFail",
					settlements: []*SettlementLine{
						{PaymentGroup: 1, InvoicingPercent: "10", InvoicingTotal: "fail", PaymentPercent: "0", PaymentTotal: "0"},
					},
				},
				{
					name: "PaymentPercent_ParseFail",
					settlements: []*SettlementLine{
						{PaymentGroup: 1, InvoicingPercent: "10", InvoicingTotal: "10", PaymentPercent: "fail", PaymentTotal: "0"},
					},
				},
				{
					name: "PaymentTotal_ParseFail",
					settlements: []*SettlementLine{
						{PaymentGroup: 1, InvoicingPercent: "10", InvoicingTotal: "10", PaymentPercent: "10", PaymentTotal: "fail"},
					},
				},
			}

			for _, tc := range testCases {
				convey.Convey(fmt.Sprintf("When %s", tc.name), func() {
					s := &SettlementInfo{SettlementLines: tc.settlements}
					mockey.Mock(SettlementLine.Validate).Return(nil).Build()

					resultErr := s.Validate(ctx)

					convey.So(resultErr, convey.ShouldNotBeNil)
					convey.So(resultErr, convey.ShouldHaveSameTypeAs, errors.ErrInternalError.WithArgs(""))
				})
			}
		})
	})
}

func Test_ExternalProductInfoList_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_ExternalProductInfoList_Validate", t, func() {
		mockey.PatchConvey("成功场景：所有商品信息均有效", func() {
			// 场景描述：
			// 构造数据：构造一个包含多个有效ExternalProductInfo的列表，每个商品都具有非空的RelateQuoteItemID和非零的GroupID。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 循环遍历所有商品，每个商品的校验都通过。
			// 3. 函数最终返回nil。
			c := ExternalProductInfoList{
				{
					RelateQuoteItemID: "item-1",
					GroupID:           1,
				},
				{
					RelateQuoteItemID: "item-2",
					GroupID:           2,
				},
			}

			err := c.Validate()

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景：列表为空", func() {
			// 场景描述：
			// 构造数据：构造一个空的ExternalProductInfoList。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. for循环不执行。
			// 3. 函数直接返回nil。
			c := ExternalProductInfoList{}

			err := c.Validate()

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景：存在商品缺少RelateQuoteItemID", func() {
			// 场景描述：
			// 构造数据：构造一个ExternalProductInfoList，其中一个商品的RelateQuoteItemID为空字符串。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 循环遍历到RelateQuoteItemID为空的商品。
			// 3. if len(commodity.RelateQuoteItemID) == 0 条件成立，函数返回错误。
			c := ExternalProductInfoList{
				{
					RelateQuoteItemID: "item-1",
					GroupID:           1,
				},
				{
					RelateQuoteItemID: "", // 无效
					GroupID:           2,
				},
			}

			err := c.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("ExternalCommodity.RelateQuoteItemID").Error())
		})

		mockey.PatchConvey("失败场景：存在商品缺少GroupID", func() {
			// 场景描述：
			// 构造数据：构造一个ExternalProductInfoList，其中一个商品的GroupID为0。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 循环遍历到GroupID为0的商品。
			// 3. 第一个if条件不满足，进入第二个if条件 if commodity.GroupID == 0，条件成立，函数返回错误。
			c := ExternalProductInfoList{
				{
					RelateQuoteItemID: "item-1",
					GroupID:           1,
				},
				{
					RelateQuoteItemID: "item-2",
					GroupID:           0, // 无效
				},
			}

			err := c.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("ExternalCommodity.GroupID").Error())
		})

		mockey.PatchConvey("失败场景：第一个商品就无效", func() {
			// 场景描述：
			// 构造数据：构造一个ExternalProductInfoList，其中第一个商品的RelateQuoteItemID就为空。
			// 逻辑链路：
			// 1. 调用Validate方法。
			// 2. 循环遍历到第一个商品。
			// 3. if len(commodity.RelateQuoteItemID) == 0 条件成立，函数立即返回错误，不再检查后续商品。
			c := ExternalProductInfoList{
				{
					RelateQuoteItemID: "", // 无效
					GroupID:           1,
				},
				{
					RelateQuoteItemID: "item-2",
					GroupID:           0, // 也无效，但不应该检查到这里
				},
			}

			err := c.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("ExternalCommodity.RelateQuoteItemID").Error())
		})
	})
}

func Test_GetAllAccountID(t *testing.T) {
	// Helper function to create a TradePartyInfoDetail with specific flags
	createParty := func(sealed, pricing int, sealAccountID, pricingAccountID string) *TradePartyInfoDetail {
		return &TradePartyInfoDetail{
			Sealed:           sealed,
			Pricing:          pricing,
			SealAccountID:    sealAccountID,
			PricingAccountID: pricingAccountID,
		}
	}

	mockey.PatchConvey("Test GetAllAccountID with no parties", t, func() {
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldBeEmpty)
	})

	mockey.PatchConvey("Test GetAllAccountID with sealed party", t, func() {
		party1 := createParty(_const.TRUE_FLAG_INT, _const.FALSE_FLAG_INT, "123,456", "")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldResemble, []string{"123", "456"})
	})

	mockey.PatchConvey("Test GetAllAccountID with pricing party", t, func() {
		party1 := createParty(_const.FALSE_FLAG_INT, _const.TRUE_FLAG_INT, "", "789,1011")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldResemble, []string{"789", "1011"})
	})

	mockey.PatchConvey("Test GetAllAccountID with both sealed and pricing party", t, func() {
		party1 := createParty(_const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT, "123,456", "789,1011")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldResemble, []string{"123", "456", "789", "1011"})
	})

	mockey.PatchConvey("Test GetAllAccountID with multiple parties", t, func() {
		party1 := createParty(_const.TRUE_FLAG_INT, _const.FALSE_FLAG_INT, "123,456", "")
		party2 := createParty(_const.FALSE_FLAG_INT, _const.TRUE_FLAG_INT, "", "789,1011")
		party3 := createParty(_const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT, "1112,1314", "1516,1718")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1, party2, party3}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldResemble, []string{"123", "456", "789", "1011", "1112", "1314", "1516", "1718"})
	})

	mockey.PatchConvey("Test GetAllAccountID with empty account IDs", t, func() {
		party1 := createParty(_const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT, "", "")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldBeEmpty)
	})

	mockey.PatchConvey("Test GetAllAccountID with duplicate account IDs", t, func() {
		party1 := createParty(_const.TRUE_FLAG_INT, _const.TRUE_FLAG_INT, "123,456", "123,456")
		tpi := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{party1}}
		actual := tpi.GetAllAccountID()
		convey.So(actual, convey.ShouldResemble, []string{"123", "456"})
	})
}

func Test_GetAllPricingAccountID(t *testing.T) {
	// Test case: No OtherParty
	mockey.PatchConvey("Test no OtherParty", t, func() {
		tpi := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{},
		}
		actual := tpi.GetAllPricingAccountID()
		convey.So(actual, convey.ShouldBeEmpty)
	})

	// Test case: OtherParty with no PricingAccountID
	mockey.PatchConvey("Test OtherParty with no PricingAccountID", t, func() {
		tpi := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "",
				},
			},
		}
		actual := tpi.GetAllPricingAccountID()
		convey.So(actual, convey.ShouldBeEmpty)
	})

	// Test case: OtherParty with valid PricingAccountID
	mockey.PatchConvey("Test OtherParty with valid PricingAccountID", t, func() {
		tpi := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "123,456",
				},
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "789,101112",
				},
			},
		}
		expected := []string{"123", "456", "789", "101112"}
		actual := tpi.GetAllPricingAccountID()
		convey.So(actual, convey.ShouldResemble, expected)
	})

	// Test case: OtherParty with mixed Pricing flags
	mockey.PatchConvey("Test OtherParty with mixed Pricing flags", t, func() {
		tpi := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "123,456",
				},
				{
					Pricing:          0,
					PricingAccountID: "789,101112",
				},
			},
		}
		expected := []string{"123", "456"}
		actual := tpi.GetAllPricingAccountID()
		convey.So(actual, convey.ShouldResemble, expected)
	})

	// Test case: OtherParty with duplicate PricingAccountID
	mockey.PatchConvey("Test OtherParty with duplicate PricingAccountID", t, func() {
		tpi := &TradePartyInfo{
			OtherParty: []*TradePartyInfoDetail{
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "123,456",
				},
				{
					Pricing:          _const.TRUE_FLAG_INT,
					PricingAccountID: "456,789",
				},
			},
		}
		expected := []string{"123", "456", "789"}
		actual := tpi.GetAllPricingAccountID()
		convey.So(actual, convey.ShouldResemble, expected)
	})
}

func Test_BaseValidate(t *testing.T) {
	mockey.PatchConvey("Test BaseValidate for Subject PartyNumber is nil", t, func() {
		subject := &TradePartyInfoDetail{PartyName: "Subject1", PartyNumber: ""}
		otherParty := &TradePartyInfoDetail{PartyName: "Other1", PartyNumber: "OP123"}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subject},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.BaseValidate()
		expectedErr := errors.ErrorCommon.WithArgs("【Subject1】PartyNumber is nil")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})

	mockey.PatchConvey("Test BaseValidate for OtherParty PartyNumber is nil", t, func() {
		subject := &TradePartyInfoDetail{PartyName: "Subject1", PartyNumber: "SP123"}
		otherParty := &TradePartyInfoDetail{PartyName: "Other1", PartyNumber: ""}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subject},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.BaseValidate()
		expectedErr := errors.ErrorCommon.WithArgs("【Other1】PartyNumber is nil")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})

	mockey.PatchConvey("Test BaseValidate for both Subject and OtherParty PartyNumber are valid", t, func() {
		subject := &TradePartyInfoDetail{PartyName: "Subject1", PartyNumber: "SP123"}
		otherParty := &TradePartyInfoDetail{PartyName: "Other1", PartyNumber: "OP123"}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subject},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.BaseValidate()
		convey.So(actualErr, convey.ShouldBeNil)
	})
	mockey.PatchConvey("副签约主体不是签约主体", t, func() {
		subject := &TradePartyInfoDetail{PartyName: "Subject1", PartyNumber: "SP123"}
		otherParty := &TradePartyInfoDetail{PartyName: "Other1", PartyNumber: "OP123", DeputyParty: 1, Sealed: 0}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subject},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.BaseValidate()
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("副签约主体是否需要签约必须为是"))
	})
	mockey.PatchConvey("副签约主体是配价主体", t, func() {
		subject := &TradePartyInfoDetail{PartyName: "Subject1", PartyNumber: "SP123"}
		otherParty := &TradePartyInfoDetail{PartyName: "Other1", PartyNumber: "OP123", DeputyParty: 1, Sealed: 1, Pricing: 1}
		tradePartyInfo := &TradePartyInfo{
			Subject:    []*TradePartyInfoDetail{subject},
			OtherParty: []*TradePartyInfoDetail{otherParty},
		}
		actualErr := tradePartyInfo.BaseValidate()
		convey.So(actualErr, convey.ShouldResemble, errors.ErrorCommon.WithArgs("副签约主体是否需要配价必须为否"))
	})
}

func Test_ManageInfo_ValidateExternalCommodity_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ManageInfo.ValidateExternalCommodity", t, func() {
		ctx := context001.Background()

		mockey.PatchConvey("当m为nil时，应返回内部错误", func() {
			// 场景描述：
			// 构造数据：ManageInfo指针为nil
			// 逻辑链路：
			// 1. 函数入口检查m是否为nil。
			// 2. m为nil，返回errors.ErrInternalError。
			var m *ManageInfo
			err := m.ValidateExternalCommodity(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "metaDB is nil")
		})

		mockey.PatchConvey("当IsSplitProduct为false时，应直接返回nil", func() {
			// 场景描述：
			// 构造数据：ManageInfo的IsSplitProduct字段为false。
			// 逻辑链路：
			// 1. 函数检查IsSplitProduct字段。
			// 2. 字段为false，直接返回nil，不进行后续校验。
			m := &ManageInfo{
				IsSplitProduct: false,
			}
			err := m.ValidateExternalCommodity(ctx)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("当IsSplitProduct为true但ExternalProductList为空时，应返回错误", func() {
			// 场景描述：
			// 构造数据：IsSplitProduct为true，但ExternalProductList为空列表。
			// 逻辑链路：
			// 1. IsSplitProduct为true，继续执行。
			// 2. 检查ExternalProductList长度，发现为0。
			// 3. 返回错误，提示外部报价信息不可为空。
			m := &ManageInfo{
				IsSplitProduct:      true,
				ExternalProductList: ExternalProductInfoList{},
			}
			err := m.ValidateExternalCommodity(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "内外部映射表不可为空")
		})

		mockey.PatchConvey("当ExternalProductList校验失败时（Validate方法）", func() {
			mockey.PatchConvey("缺少RelateQuoteItemID", func() {
				// 场景描述：
				// 构造数据：ExternalProductList中有一个元素的RelateQuoteItemID为空字符串。
				// 逻辑链路：
				// 1. IsSplitProduct为true，ExternalProductList不为空。
				// 2. 调用ExternalProductList.Validate()方法。
				// 3. Validate方法检测到RelateQuoteItemID为空，返回参数缺失错误。
				// 4. ValidateExternalCommodity将此错误返回。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "", // 缺少关联报价项ID
							GroupID:           1,
						},
					},
				}
				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "ExternalCommodity.RelateQuoteItemID")
			})

			mockey.PatchConvey("GroupID为0", func() {
				// 场景描述：
				// 构造数据：ExternalProductList中有一个元素的GroupID为0。
				// 逻辑链路：
				// 1. IsSplitProduct为true，ExternalProductList不为空。
				// 2. 调用ExternalProductList.Validate()方法。
				// 3. Validate方法检测到GroupID为0，返回参数缺失错误。
				// 4. ValidateExternalCommodity将此错误返回。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "item-123",
							GroupID:           0, // GroupID为0
						},
					},
				}
				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "ExternalCommodity.GroupID")
			})
		})

		mockey.PatchConvey("当validateBuyNum校验失败时", func() {
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context001.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			mockey.PatchConvey("BuyNum为空", func() {
				// 场景描述：
				// 构造数据：一个私有云的外部商品行BuyNum为空。
				// 逻辑链路：
				// 1. ExternalProductList.Validate()成功。
				// 2. 调用validateBuyNum。
				// 3. 在validateBuyNum中，遍历到一个私有云商品行，其BuyNum为空。
				// 4. 返回错误，提示购买数量不允许为空。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "item-1",
							GroupID:           1,
							BuyNum:            "", // BuyNum为空
							DeploymentType:    _const.SettlementDeploymentPrivateCloud,
							RecordType:        _const.ExternalCommodityRecordTypeSub,
						},
					},
				}
				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "不允许为空")
			})

			mockey.PatchConvey("BuyNum格式异常", func() {
				// 场景描述：
				// 构造数据：一个私有云的外部商品行BuyNum为无效字符串。
				// 逻辑链路：
				// 1. ExternalProductList.Validate()成功。
				// 2. 调用validateBuyNum。
				// 3. decimal.NewFromString解析BuyNum失败，返回错误。
				// 4. validateBuyNum捕获此错误并返回，提示购买数量格式异常。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "item-1",
							GroupID:           1,
							BuyNum:            "invalid-number",
							DeploymentType:    _const.SettlementDeploymentPrivateCloud,
							RecordType:        _const.ExternalCommodityRecordTypeSub,
						},
					},
				}
				mockey.Mock(decimal.NewFromString).Return(decimal.Decimal{}, errors001.New("parse error")).Build()

				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "格式异常")
			})

			mockey.PatchConvey("BuyNum为0", func() {
				// 场景描述：
				// 构造数据：一个私有云的外部商品行BuyNum为"0"。
				// 逻辑链路：
				// 1. ExternalProductList.Validate()成功。
				// 2. 调用validateBuyNum。
				// 3. decimal.NewFromString解析成功，得到0。
				// 4. buyNum.LessThanOrEqual(decimal.Zero)检查为true。
				// 5. 返回错误，提示购买数量不允许为0。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "item-1",
							GroupID:           1,
							BuyNum:            "0",
							DeploymentType:    _const.SettlementDeploymentPrivateCloud,
							RecordType:        _const.ExternalCommodityRecordTypeSub,
						},
					},
				}
				mockey.Mock(decimal.NewFromString).Return(decimal.Zero, nil).Build()
				mockey.Mock(decimal.Decimal.LessThanOrEqual).Return(true).Build()

				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "不允许为0")
			})

			mockey.PatchConvey("BuyNum为负数", func() {
				// 场景描述：
				// 构造数据：一个私有云的外部商品行BuyNum为"-1"。
				// 逻辑链路：
				// 1. ExternalProductList.Validate()成功。
				// 2. 调用validateBuyNum。
				// 3. decimal.NewFromString解析成功，得到-1。
				// 4. buyNum.LessThanOrEqual(decimal.Zero)检查为true。
				// 5. 返回错误，提示购买数量不允许为0。
				m := &ManageInfo{
					IsSplitProduct: true,
					ExternalProductList: ExternalProductInfoList{
						{
							RelateQuoteItemID: "item-1",
							GroupID:           1,
							BuyNum:            "-1",
							DeploymentType:    _const.SettlementDeploymentPrivateCloud,
							RecordType:        _const.ExternalCommodityRecordTypeSub,
						},
					},
				}
				negOne, _ := decimal.NewFromString("-1")
				mockey.Mock(decimal.NewFromString).Return(negOne, nil).Build()
				mockey.Mock(decimal.Decimal.LessThanOrEqual).Return(true).Build()

				err := m.ValidateExternalCommodity(ctx)
				convey.So(err, convey.ShouldNotBeNil)
				convey.So(err.Error(), convey.ShouldContainSubstring, "不允许为0")
			})
		})

		mockey.PatchConvey("成功通过所有校验", func() {
			// 场景描述：
			// 构造数据：包含主记录、公有云记录和有效的私有云记录。
			// 逻辑链路：
			// 1. IsSplitProduct为true, ExternalProductList不为空。
			// 2. ExternalProductList.Validate()成功。
			// 3. 调用validateBuyNum。
			// 4. validateBuyNum遍历列表：
			//    - 跳过主记录 (RecordTypeMaster)。
			//    - 跳过公有云记录 (DeploymentPublicCloud)。
			//    - 校验私有云记录，其BuyNum > 0，校验通过。
			// 5. 所有校验均通过，函数返回nil。
			m := &ManageInfo{
				IsSplitProduct: true,
				ExternalProductList: ExternalProductInfoList{
					{ // 主记录，应跳过
						RelateQuoteItemID: "item-master",
						GroupID:           1,
						BuyNum:            "10",
						RecordType:        _const.ExternalCommodityRecordTypeMaster,
						DeploymentType:    _const.SettlementDeploymentPrivateCloud,
					},
					{ // 公有云，应跳过
						RelateQuoteItemID: "item-public",
						GroupID:           2,
						BuyNum:            "20",
						RecordType:        _const.ExternalCommodityRecordTypeSub,
						DeploymentType:    _const.SettlementDeploymentPublicCloud,
					},
					{ // 私有云，有效，应校验通过
						RelateQuoteItemID: "item-private",
						GroupID:           3,
						BuyNum:            "30",
						RecordType:        _const.ExternalCommodityRecordTypeSub,
						DeploymentType:    _const.SettlementDeploymentPrivateCloud,
					},
				},
			}
			posNum, _ := decimal.NewFromString("30")
			mockey.Mock(decimal.NewFromString).Return(posNum, nil).Build()
			mockey.Mock(decimal.Decimal.LessThanOrEqual).Return(false).Build()
			err := m.ValidateExternalCommodity(ctx)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_CheckSubjectSignData(t *testing.T) {
	ctx := context.Background()
	signatureType := _const.SignatureDomesticElectronicSignature
	mockey.PatchConvey("Test sealed is false", t, func() {
		p := &TradePartyInfoDetail{Sealed: _const.FALSE_FLAG_INT}
		err := p.CheckSubjectSignData(signatureType)
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test signatureType is domestic electronic signature and sign keyword is empty", t, func() {
		p := &TradePartyInfoDetail{Sealed: _const.TRUE_FLAG_INT, SignKeyword: ""}
		err := p.CheckSubjectSignData(signatureType)
		expectedErr := i18nfmt.Errorf(ctx, "交易我方信息，签约关键字不能为空")
		convey.So(err, convey.ShouldResemble, expectedErr)
	})
	mockey.PatchConvey("Test signatureType is domestic electronic signature and sign keyword is not empty", t, func() {
		p := &TradePartyInfoDetail{Sealed: _const.TRUE_FLAG_INT, SignKeyword: "test_keyword"}
		err := p.CheckSubjectSignData(signatureType)
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test signatureType is not domestic electronic signature", t, func() {
		p := &TradePartyInfoDetail{Sealed: _const.TRUE_FLAG_INT, SignKeyword: ""}
		nonDomesticSignatureType := "other_signature_type"
		err := p.CheckSubjectSignData(nonDomesticSignatureType)
		convey.So(err, convey.ShouldBeNil)
	})
}

func Test_CheckOtherSignData(t *testing.T) {
	p := &TradePartyInfoDetail{
		Sealed:      _const.TRUE_FLAG_INT,
		Signer:      "John Doe",
		Email:       "john.doe@example.com",
		SignerPhone: "1234567890",
		SignKeyword: "keyword",
	}

	mockey.PatchConvey("Test CheckOtherSignData with Sealed false", t, func() {
		p.Sealed = _const.FALSE_FLAG_INT
		err := p.CheckOtherSignData(_const.SignatureInternationalElectronicSignature)
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test CheckOtherSignData with International Electronic Signature and valid data", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		err := p.CheckOtherSignData(_const.SignatureInternationalElectronicSignature)
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test CheckOtherSignData with International Electronic Signature and empty Signer", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.Signer = ""
		err := p.CheckOtherSignData(_const.SignatureInternationalElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约人不能为空")
	})

	mockey.PatchConvey("Test CheckOtherSignData with International Electronic Signature and empty Email", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.Signer = "John Doe"
		p.Email = ""
		err := p.CheckOtherSignData(_const.SignatureInternationalElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约人邮箱不能为空")
	})

	mockey.PatchConvey("Test CheckOtherSignData with Domestic Electronic Signature and valid data", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.SignKeyword = "keyword"
		p.SignerPhone = "SignerPhone"
		p.Email = "Email"
		err := p.CheckOtherSignData(_const.SignatureDomesticElectronicSignature)
		convey.So(err, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test CheckOtherSignData with Domestic Electronic Signature and empty SignKeyword", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.SignKeyword = ""
		err := p.CheckOtherSignData(_const.SignatureDomesticElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约关键字不能为空")
	})

	mockey.PatchConvey("Test CheckOtherSignData with Domestic Electronic Signature and empty Signer", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.SignKeyword = "keyword"
		p.Signer = ""
		err := p.CheckOtherSignData(_const.SignatureDomesticElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约人不能为空")
	})

	mockey.PatchConvey("Test CheckOtherSignData with Domestic Electronic Signature and empty SignerPhone", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.SignKeyword = "keyword"
		p.Signer = "John Doe"
		p.SignerPhone = ""
		err := p.CheckOtherSignData(_const.SignatureDomesticElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约人实名认证手机号码不能为空")
	})

	mockey.PatchConvey("Test CheckOtherSignData with Domestic Electronic Signature and empty Email", t, func() {
		p.Sealed = _const.TRUE_FLAG_INT
		p.SignKeyword = "keyword"
		p.Signer = "John Doe"
		p.SignerPhone = "1234567890"
		p.Email = ""
		err := p.CheckOtherSignData(_const.SignatureDomesticElectronicSignature)
		convey.So(err, convey.ShouldNotBeNil)
		convey.So(err.Error(), convey.ShouldEqual, "交易对方信息，签约人邮箱不能为空")
	})
}

func Test_TradePartyInfo_FillCooperationSealPriceTag_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_TradePartyInfo_FillCooperationSealPriceTag", t, func() {
		mockey.PatchConvey("should do nothing when not in BytePlus environment", func() {
			// 场景描述：
			// 当前环境不是海外环境(BytePlus)。
			// 构造数据：
			// 构造一个TradePartyInfo实例，其中Subject和OtherParty有数据，但相关标签字段为空或0。
			// 逻辑链路：
			// 1. Mock multienv.IsBytePlus() 返回 false。
			// 2. 调用 FillCooperationSealPriceTag 方法。
			// 3. 函数在第一个if判断后直接返回，不执行任何修改。
			// 4. 断言TradePartyInfo中的字段值没有被改变。
			tradeInfo := &TradePartyInfo{
				Subject: []*TradePartyInfoDetail{
					{AccountID: "subject_acc_1"},
				},
				OtherParty: []*TradePartyInfoDetail{
					{AccountID: "other_acc_1"},
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			tradeInfo.FillCooperationSealPriceTag("some-quote-no")

			convey.So(tradeInfo.Subject[0].Sealed, convey.ShouldEqual, 0)
			convey.So(tradeInfo.Subject[0].SealAccountID, convey.ShouldBeEmpty)
			convey.So(tradeInfo.OtherParty[0].Sealed, convey.ShouldEqual, 0)
			convey.So(tradeInfo.OtherParty[0].SealAccountID, convey.ShouldBeEmpty)
			convey.So(tradeInfo.OtherParty[0].Pricing, convey.ShouldEqual, 0)
			convey.So(tradeInfo.OtherParty[0].PricingAccountID, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("should do nothing when relateQuoteNo is empty in BytePlus environment", func() {
			// 场景描述：
			// 当前环境是海外环境(BytePlus)，但关联报价单号为空。
			// 构造数据：
			// 构造一个TradePartyInfo实例，其中Subject和OtherParty有数据，但相关标签字段为空或0。
			// 逻辑链路：
			// 1. Mock multienv.IsBytePlus() 返回 true。
			// 2. 使用空字符串作为relateQuoteNo参数调用 FillCooperationSealPriceTag 方法。
			// 3. 函数在第二个if判断后直接返回，不执行任何修改。
			// 4. 断言TradePartyInfo中的字段值没有被改变。
			tradeInfo := &TradePartyInfo{
				Subject: []*TradePartyInfoDetail{
					{AccountID: "subject_acc_1"},
				},
				OtherParty: []*TradePartyInfoDetail{
					{AccountID: "other_acc_1"},
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			tradeInfo.FillCooperationSealPriceTag("")

			convey.So(tradeInfo.Subject[0].Sealed, convey.ShouldEqual, 0)
			convey.So(tradeInfo.Subject[0].SealAccountID, convey.ShouldBeEmpty)
			convey.So(tradeInfo.OtherParty[0].Sealed, convey.ShouldEqual, 0)
			convey.So(tradeInfo.OtherParty[0].SealAccountID, convey.ShouldBeEmpty)
			convey.So(tradeInfo.OtherParty[0].Pricing, convey.ShouldEqual, 0)
			convey.So(tradeInfo.OtherParty[0].PricingAccountID, convey.ShouldBeEmpty)
		})

		mockey.PatchConvey("should fill tags when in BytePlus environment and relateQuoteNo is not empty", func() {
			// 场景描述：
			// 当前环境是海外环境(BytePlus)，且关联报价单号不为空。
			// 构造数据：
			// 构造一个TradePartyInfo实例，其中Subject和OtherParty均有数据，相关标签字段为空或0。
			// 逻辑链路：
			// 1. Mock multienv.IsBytePlus() 返回 true。
			// 2. 使用非空字符串作为relateQuoteNo参数调用 FillCooperationSealPriceTag 方法。
			// 3. 函数进入循环体，为Subject和OtherParty中的所有元素设置签约和配价标签。
			// 4. 断言TradePartyInfo中的相关字段被正确赋值。
			tradeInfo := &TradePartyInfo{
				Subject: []*TradePartyInfoDetail{
					{AccountID: "subject_acc_1"},
					{AccountID: "subject_acc_2"},
				},
				OtherParty: []*TradePartyInfoDetail{
					{AccountID: "other_acc_1"},
					{AccountID: "other_acc_2"},
				},
			}

			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			tradeInfo.FillCooperationSealPriceTag("some-quote-no")

			for _, v := range tradeInfo.Subject {
				convey.So(v.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(v.SealAccountID, convey.ShouldEqual, v.AccountID)
			}
			for _, v := range tradeInfo.OtherParty {
				convey.So(v.Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(v.SealAccountID, convey.ShouldEqual, v.AccountID)
				convey.So(v.Pricing, convey.ShouldEqual, _const.TRUE_FLAG_INT)
				convey.So(v.PricingAccountID, convey.ShouldEqual, v.AccountID)
			}
		})

		mockey.PatchConvey("should handle nil or empty slices gracefully", func() {
			// 场景描述：
			// 当前环境是海外环境(BytePlus)，关联报价单号不为空，但Subject或OtherParty切片为空或nil。
			// 构造数据：
			// 构造一个TradePartyInfo实例，其中Subject切片有数据，但OtherParty切片为nil。
			// 逻辑链路：
			// 1. Mock multienv.IsBytePlus() 返回 true。
			// 2. 调用 FillCooperationSealPriceTag 方法。
			// 3. 函数会正常遍历非空的Subject切片并修改其值，跳过为空的OtherParty切片，不应产生panic。
			// 4. 断言Subject中的字段被正确更新。
			tradeInfo := &TradePartyInfo{
				Subject: []*TradePartyInfoDetail{
					{AccountID: "subject_acc_1"},
				},
				OtherParty: nil, // OtherParty is nil
			}

			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			tradeInfo.FillCooperationSealPriceTag("some-quote-no")

			convey.So(tradeInfo.Subject[0].Sealed, convey.ShouldEqual, _const.TRUE_FLAG_INT)
			convey.So(tradeInfo.Subject[0].SealAccountID, convey.ShouldEqual, tradeInfo.Subject[0].AccountID)
			convey.So(tradeInfo.OtherParty, convey.ShouldBeNil)
		})
	})
}

func Test_CheckSignData(t *testing.T) {
	signatureTypeDomestic := _const.SignatureDomesticElectronicSignature
	signatureTypeInvalid := "invalid_signature_type"

	subjectParty := &TradePartyInfoDetail{
		PartyName: "Subject Party",
	}
	otherParty := &TradePartyInfoDetail{
		PartyName: "Other Party",
	}

	tradePartyInfo := &TradePartyInfo{
		Subject:    []*TradePartyInfoDetail{subjectParty},
		OtherParty: []*TradePartyInfoDetail{otherParty},
	}

	mockey.PatchConvey("Test invalid signature type", t, func() {
		actualErr := tradePartyInfo.CheckSignData(signatureTypeInvalid)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test valid signature type with no errors", t, func() {
		mockey.Mock((*TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
		mockey.Mock((*TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

		actualErr := tradePartyInfo.CheckSignData(signatureTypeDomestic)
		convey.So(actualErr, convey.ShouldBeNil)
	})

	mockey.PatchConvey("Test valid signature type with subject party errors", t, func() {
		mockey.Mock((*TradePartyInfoDetail).CheckSubjectSignData).Return(fmt.Errorf("subject party error")).Build()
		mockey.Mock((*TradePartyInfoDetail).CheckOtherSignData).Return(nil).Build()

		actualErr := tradePartyInfo.CheckSignData(signatureTypeDomestic)
		expectedErr := fmt.Errorf("【Subject Party】 subject party error")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})

	mockey.PatchConvey("Test valid signature type with other party errors", t, func() {
		mockey.Mock((*TradePartyInfoDetail).CheckSubjectSignData).Return(nil).Build()
		mockey.Mock((*TradePartyInfoDetail).CheckOtherSignData).Return(fmt.Errorf("other party error")).Build()

		actualErr := tradePartyInfo.CheckSignData(signatureTypeDomestic)
		expectedErr := fmt.Errorf("【Other Party】 other party error")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})

	mockey.PatchConvey("Test valid signature type with both subject and other party errors", t, func() {
		mockey.Mock((*TradePartyInfoDetail).CheckSubjectSignData).Return(fmt.Errorf("subject party error")).Build()
		mockey.Mock((*TradePartyInfoDetail).CheckOtherSignData).Return(fmt.Errorf("other party error")).Build()

		actualErr := tradePartyInfo.CheckSignData(signatureTypeDomestic)
		expectedErr := fmt.Errorf("【Subject Party】 subject party error、【Other Party】 other party error")
		convey.So(actualErr, convey.ShouldResemble, expectedErr)
	})
}

func Test_IsSameContractTemplateType(t *testing.T) {
	t.Run("case IsSameContractTemplateType#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			basicInfo := &BasicInfo{}
			// Assert
			convey.So(basicInfo.IsSameContractTemplateType(1), convey.ShouldBeFalse)
		})
	})
	t.Run("case IsSameContractTemplateType#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			var v = 1
			basicInfo := &BasicInfo{ContractTemplateType: &v}
			// Assert
			convey.So(basicInfo.IsSameContractTemplateType(1), convey.ShouldBeTrue)
			convey.So(basicInfo.IsSameContractTemplateType(2), convey.ShouldBeFalse)
		})
	})
}

func Test_GetHistoryContractNo(t *testing.T) {
	t.Run("case GetHistoryContractNo#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			basicInfo := &BasicInfo{}
			// Assert
			convey.So(basicInfo.GetHistoryContractNo(), convey.ShouldEqual, "")
		})
	})
	t.Run("case GetHistoryContractNo#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// Act
			v := "test"
			basicInfo := &BasicInfo{HistoryContractNo: &v}
			// Assert
			convey.So(basicInfo.GetHistoryContractNo(), convey.ShouldEqual, "test")
		})
	})
}

func Test_BasicInfo_IsBasicRequireQuote_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_BasicInfo_IsBasicRequireQuote", t, func() {
		mockey.PatchConvey("当收支类型为收入类时，应返回true", func() {
			// 场景描述：
			// 构造数据：BasicInfo 的 InOutType 字段为 _const.IN ("IN")
			// 逻辑链路：
			// 1. 调用 IsBasicRequireQuote 方法
			// 2. 方法内部判断 b.InOutType == _const.IN 为 true
			// 3. 返回 true

			// 数据准备
			b := &BasicInfo{
				InOutType: _const.IN,
			}

			// 调用
			result := b.IsBasicRequireQuote()

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("当收支类型为既收又支时，应返回true", func() {
			// 场景描述：
			// 构造数据：BasicInfo 的 InOutType 字段为 _const.InAndOut ("IN_AND_OUT")
			// 逻辑链路：
			// 1. 调用 IsBasicRequireQuote 方法
			// 2. 方法内部判断 b.InOutType == _const.IN 为 false
			// 3. 方法内部判断 b.InOutType == _const.InAndOut 为 true
			// 4. or 条件成立，返回 true

			// 数据准备
			b := &BasicInfo{
				InOutType: _const.InAndOut,
			}

			// 调用
			result := b.IsBasicRequireQuote()

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("当收支类型为支出类时，应返回false", func() {
			// 场景描述：
			// 构造数据：BasicInfo 的 InOutType 字段为 _const.OUT ("OUT")
			// 逻辑链路：
			// 1. 调用 IsBasicRequireQuote 方法
			// 2. 方法内部判断 b.InOutType == _const.IN 为 false
			// 3. 方法内部判断 b.InOutType == _const.InAndOut 为 false
			// 4. if 条件不满足，返回 false

			// 数据准备
			b := &BasicInfo{
				InOutType: _const.OUT,
			}

			// 调用
			result := b.IsBasicRequireQuote()

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当收支类型为无收无支时，应返回false", func() {
			// 场景描述：
			// 构造数据：BasicInfo 的 InOutType 字段为 _const.NoInNoOut ("NO_IN_NO_OUT")
			// 逻辑链路：
			// 1. 调用 IsBasicRequireQuote 方法
			// 2. 方法内部判断 b.InOutType == _const.IN 为 false
			// 3. 方法内部判断 b.InOutType == _const.InAndOut 为 false
			// 4. if 条件不满足，返回 false

			// 数据准备
			b := &BasicInfo{
				InOutType: _const.NoInNoOut,
			}

			// 调用
			result := b.IsBasicRequireQuote()

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})

		mockey.PatchConvey("当收支类型为其他任意字符串时，应返回false", func() {
			// 场景描述：
			// 构造数据：BasicInfo 的 InOutType 字段为一个非预期的字符串 "OTHER"
			// 逻辑链路：
			// 1. 调用 IsBasicRequireQuote 方法
			// 2. 方法内部判断 b.InOutType == _const.IN 为 false
			// 3. 方法内部判断 b.InOutType == _const.InAndOut 为 false
			// 4. if 条件不满足，返回 false

			// 数据准备
			b := &BasicInfo{
				InOutType: "OTHER",
			}

			// 调用
			result := b.IsBasicRequireQuote()

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})
	})
}

func Test_ProjectInfo_Method(t *testing.T) {
	t.Run("case ProjectInfo#1", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// mockey.Mock(retry.Do).Return("", nil).Build()
			// Act
			info := &ProjectInfo{}
			// Assert
			convey.So(info.HasRelatedResDepartment(), convey.ShouldBeFalse)
			convey.So(info.GetRelatedResDepartment(), convey.ShouldEqual, "")
			convey.So(info.HasDeliveryStaff(), convey.ShouldBeFalse)
			convey.So(info.GetDeliveryStaff(), convey.ShouldEqual, "")
			convey.So(info.HasProductSolutionEmail(), convey.ShouldBeFalse)
			convey.So(info.GetProductSolutionEmail(), convey.ShouldEqual, "")
			convey.So(info.EqualsRelatedResDepartment(nil), convey.ShouldBeTrue)
			convey.So(info.EqualsProductSolutionEmail(nil), convey.ShouldBeTrue)
			convey.So(info.EqualsDeliveryStaff(nil), convey.ShouldBeTrue)
		})
	})
	t.Run("case ProjectInfo#2", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// Arrange
			// mockey.Mock(retry.Do).Return("", nil).Build()
			// Act
			solutionEmail := "a"
			stuff := "b"
			resDepartment := "c"
			info := &ProjectInfo{
				ProductSolutionEmail: &solutionEmail,
				DeliveryStaff:        &stuff,
				RelatedResDepartment: &resDepartment,
			}
			// Assert
			convey.So(info.HasRelatedResDepartment(), convey.ShouldBeTrue)
			convey.So(info.GetRelatedResDepartment(), convey.ShouldEqual, "c")
			convey.So(info.HasDeliveryStaff(), convey.ShouldBeTrue)
			convey.So(info.GetDeliveryStaff(), convey.ShouldEqual, "b")
			convey.So(info.HasProductSolutionEmail(), convey.ShouldBeTrue)
			convey.So(info.GetProductSolutionEmail(), convey.ShouldEqual, "a")
			convey.So(info.EqualsRelatedResDepartment(nil), convey.ShouldBeFalse)
			convey.So(info.EqualsProductSolutionEmail(nil), convey.ShouldBeFalse)
			convey.So(info.EqualsDeliveryStaff(nil), convey.ShouldBeFalse)
		})
	})
}

func TestAuditorInfo_IsAudited(t *testing.T) {
	mockey.PatchConvey("TestAuditorInfo_IsAudited", t, func() {
		mockey.PatchConvey("success", func() {
			info := &AuditorInfo{
				Status: _const.ReviewStatusSubmitOA,
			}
			convey.So(info.IsAudited(), convey.ShouldBeTrue)
		})
		mockey.PatchConvey("failed", func() {
			info := &AuditorInfo{
				Status: _const.ReviewStatusUnreviewed,
			}
			convey.So(info.IsAudited(), convey.ShouldBeFalse)
		})
	})
}

func Test_CheckExchangeRate(t *testing.T) {
	mockey.PatchConvey("Test CheckExchangeRate", t, func() {
		b := &BasicInfo{}

		mockey.PatchConvey("Test multienv.IsBytePlus returns false", func() {
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test CurrencyIn is empty", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = ""
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test CurrencyIn is USD", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = "USD"
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test ExchangeRateType is less than or equal to 0", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = "EUR"
			b.ExchangeRateType = 0
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ExchangeRateType")
		})

		mockey.PatchConvey("Test ExchangeRateType is Fixed and ExchangeRate is empty", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = "EUR"
			b.ExchangeRateType = _const.ExchangeRateTypeFixed
			b.ExchangeRate = ""
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ExchangeRate")
		})

		mockey.PatchConvey("Test ExchangeRateType is Fixed and ExchangeRate is not empty", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = "EUR"
			b.ExchangeRateType = _const.ExchangeRateTypeFixed
			b.ExchangeRate = "1.2"
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Test ExchangeRateType is not Fixed", func() {
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()
			b.CurrencyIn = "EUR"
			b.ExchangeRateType = _const.ExchangeRateTypeFloat
			err := b.CheckExchangeRate()
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_BasicInfo_Validate(t *testing.T) {
	mockey.PatchConvey("Test Validate function", t, func() {
		basicInfo := &BasicInfo{}

		mockey.PatchConvey("Test CheckExchangeRate returns error", func() {
			mockey.Mock(mockey.GetMethod(basicInfo, "CheckExchangeRate")).Return(errors.ErrorCommon.WithArgs("exchange rate error")).Build()
			err := basicInfo.Validate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "exchange rate error")
		})

		mockey.PatchConvey("Test CheckExchangeRate returns nil", func() {
			mockey.Mock(mockey.GetMethod(basicInfo, "CheckExchangeRate")).Return(nil).Build()
			err := basicInfo.Validate()
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_BasicInfo_ValidateRedirectURL(t *testing.T) {
	t.Run("empty redirect url", func(t *testing.T) {
		basicInfo := &BasicInfo{}
		err := basicInfo.ValidateRedirectURL()
		if err != nil {
			t.Fatalf("expected nil error, got %v", err)
		}
	})

	t.Run("valid https redirect url", func(t *testing.T) {
		basicInfo := &BasicInfo{RedirectURL: "https://redirect.example.com/callback?contract_no=PCT123"}
		err := basicInfo.ValidateRedirectURL()
		if err != nil {
			t.Fatalf("expected nil error, got %v", err)
		}
	})

	t.Run("invalid redirect url scheme", func(t *testing.T) {
		basicInfo := &BasicInfo{RedirectURL: "javascript:alert(1)"}
		err := basicInfo.ValidateRedirectURL()
		if err == nil || !strings.Contains(err.Error(), "电子签跳转链接仅支持HTTP或HTTPS协议") {
			t.Fatalf("expected invalid scheme error, got %v", err)
		}
	})

	t.Run("redirect url missing host", func(t *testing.T) {
		basicInfo := &BasicInfo{RedirectURL: "https:///callback"}
		err := basicInfo.ValidateRedirectURL()
		if err == nil || !strings.Contains(err.Error(), "电子签跳转链接缺少域名") {
			t.Fatalf("expected missing host error, got %v", err)
		}
	})

	t.Run("redirect url contains user info", func(t *testing.T) {
		basicInfo := &BasicInfo{RedirectURL: "https://user:pass@redirect.example.com/callback"}
		err := basicInfo.ValidateRedirectURL()
		if err == nil || !strings.Contains(err.Error(), "电子签跳转链接不支持用户信息") {
			t.Fatalf("expected userinfo error, got %v", err)
		}
	})

	t.Run("redirect url too long", func(t *testing.T) {
		basicInfo := &BasicInfo{RedirectURL: "https://redirect.example.com/" + strings.Repeat("a", 2050)}
		err := basicInfo.ValidateRedirectURL()
		if err == nil || !strings.Contains(err.Error(), "电子签跳转链接长度超限") {
			t.Fatalf("expected too long error, got %v", err)
		}
	})
}

func TestProjectInfo_HasProductSolutionEmail(t *testing.T) {
	// 测试ProductSolutionEmail不为nil且指向的字符串不为空的场景
	t.Run("ProductSolutionEmailIsNotNullAndNotEmpty", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 构造函数入参
			// [目标分支] receiver.ProductSolutionEmail != nil
			var receiver *ProjectInfo = &ProjectInfo{
				ProductSolutionEmail: conv.StringPtr("Default Value"),
			}
			// 运行被测函数
			got1 := receiver.HasProductSolutionEmail()
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 在测试用例中，ProjectInfo结构体的ProductSolutionEmail字段被赋值为指向非空字符串的指针，根据业务函数的逻辑，当ProductSolutionEmail不为nil且指向的字符串不为空时，函数返回true
			convey.So(got1, convey.ShouldEqual, true)
		})
	})
}

func TestProjectInfo_EqualsDeliveryStaff(t *testing.T) {
	// 测试genCompareString方法返回相同模拟结果的场景
	t.Run("GenCompareStringMockSameResult", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*ProjectInfo).genCompareString, mockey.OptUnsafe).Return("Mock comparison result 1").Build()
			// 构造函数入参
			var receiver *ProjectInfo = &ProjectInfo{}
			var vTest *string = conv.StringPtr("Test Value")
			// 运行被测函数
			got1 := receiver.EqualsDeliveryStaff(vTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 通过mockey.Mock将genCompareString方法的返回值固定为\"Mock comparison result 1\"，在EqualsDeliveryStaff函数中，调用genCompareString方法比较两个值时，由于返回值相同，所以比较结果为true
			convey.So(got1, convey.ShouldEqual, true)
		})
	})
}

func TestProjectInfo_EqualsProductSolutionEmailAutoGen(t *testing.T) {
	// 测试genCompareString函数返回相同模拟值的场景
	t.Run("GenCompareStringMockSameValue", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*ProjectInfo).genCompareString, mockey.OptUnsafe).Return("This is a comparison string result mock").Build()
			// 构造函数入参
			var receiver *ProjectInfo = &ProjectInfo{}
			var vTest *string = conv.StringPtr("Test Value")
			// 运行被测函数
			got1 := receiver.EqualsProductSolutionEmail(vTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 通过mockey.Mock将genCompareString函数的返回值固定为\"This is a comparison string result mock\"，那么receiver.genCompareString(p.ProductSolutionEmail)和receiver.genCompareString(v)的返回值相同，所以EqualsProductSolutionEmail函数返回true
			convey.So(got1, convey.ShouldEqual, true)
		})
	})
}

func TestProjectInfo_EqualsRelatedResDepartment(t *testing.T) {
	// 测试genCompareString函数被mock为返回相同结果的场景
	t.Run("GenCompareStringMockedSame", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			mockey.Mock((*ProjectInfo).genCompareString, mockey.OptUnsafe).Return("Mock comparison string result 1").Build()
			// 构造函数入参
			var receiver *ProjectInfo = &ProjectInfo{}
			var vTest *string = conv.StringPtr("Test Value")
			// 运行被测函数
			got1 := receiver.EqualsRelatedResDepartment(vTest)
			// 断言值由大模型生成，需要评估是否符合预期值!
			// 在测试用例中，genCompareString函数被mock为总是返回\"Mock comparison string result 1\"，因此p.genCompareString(p.RelatedResDepartment)和p.genCompareString(v)的返回值相同，EqualsRelatedResDepartment函数会返回true
			convey.So(got1, convey.ShouldEqual, true)
		})
	})
}

func TestParseDecimal(t *testing.T) {
	del, _ := decimal.NewFromString("1e-10")
	t.Log(del.String())
}

func Test_TradePartyInfo_ValidateMainDeputyPartyDuplication_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("ValidateMainDeputyPartyDuplication 单元测试", t, func() {
		mockey.PatchConvey("入参t为nil时返回nil", func() {
			// 构造nil接收者场景
			var tpi *TradePartyInfo
			ctx := context001.Background()

			err := tpi.ValidateMainDeputyPartyDuplication(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("无副签约主体时直接返回nil", func() {
			// 仅存在主签约主体，不存在副签约主体
			tpi := &TradePartyInfo{
				OtherParty: []*TradePartyInfoDetail{
					{DeputyParty: 0, PartyNumber: "MAIN-001"},
					{DeputyParty: 0, PartyNumber: "MAIN-002"},
				},
			}
			ctx := context001.Background()

			err := tpi.ValidateMainDeputyPartyDuplication(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("存在重复副签约主体时返回错误", func() {
			// 构造副签约主体重复的场景
			tpi := &TradePartyInfo{
				OtherParty: []*TradePartyInfoDetail{
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "DEPUTY-001"},
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "DEPUTY-001"},
					{DeputyParty: 0, PartyNumber: "MAIN-001"},
				},
			}
			ctx := context001.Background()

			err := tpi.ValidateMainDeputyPartyDuplication(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "副签约主体重复")
		})

		mockey.PatchConvey("存在与主签约主体重复的副签约主体时返回错误", func() {
			// 构造与主签约主体重复的副签约主体
			tpi := &TradePartyInfo{
				OtherParty: []*TradePartyInfoDetail{
					{DeputyParty: 0, PartyNumber: "COMMON-001"},
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "COMMON-001"},
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "DEPUTY-002"},
				},
			}
			ctx := context001.Background()

			err := tpi.ValidateMainDeputyPartyDuplication(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "副签约主体与主签约主体重复")
		})

		mockey.PatchConvey("存在副签约主体且无重复且不与主签约主体重复时返回nil", func() {
			// 有副签约主体但不重复且与主签约主体不重复
			tpi := &TradePartyInfo{
				OtherParty: []*TradePartyInfoDetail{
					{DeputyParty: 0, PartyNumber: "MAIN-001"},
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "DEPUTY-001"},
					{DeputyParty: _const.TRUE_FLAG_INT, PartyNumber: "DEPUTY-002"},
				},
			}
			ctx := context001.Background()

			err := tpi.ValidateMainDeputyPartyDuplication(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_TradePartyInfo_GetMainOtherParty_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("GetMainOtherParty 方法测试集", t, func() {

		mockey.PatchConvey("OtherParty 为 nil", func() {
			// 构造输入为nil，覆盖循环不进入的分支
			trade := &TradePartyInfo{OtherParty: nil}
			res := trade.GetMainOtherParty()

			// 返回的切片应非nil但长度为0
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("仅包含副签约主体", func() {
			// 所有元素均为副签约主体，覆盖continue分支
			other1 := &TradePartyInfoDetail{DeputyParty: _const.TRUE_FLAG_INT}
			other2 := &TradePartyInfoDetail{DeputyParty: _const.TRUE_FLAG_INT}
			trade := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{other1, other2}}

			res := trade.GetMainOtherParty()
			convey.So(res, convey.ShouldNotBeNil)
			convey.So(len(res), convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("混合包含主签约与副签约主体", func() {
			// 混合场景，既走continue分支也走append分支
			dep := &TradePartyInfoDetail{DeputyParty: _const.TRUE_FLAG_INT}
			main := &TradePartyInfoDetail{DeputyParty: 0}
			trade := &TradePartyInfo{OtherParty: []*TradePartyInfoDetail{dep, main, dep}}

			res := trade.GetMainOtherParty()
			convey.So(len(res), convey.ShouldEqual, 1)
			// 验证返回的即为主签约主体
			convey.So(res[0], convey.ShouldEqual, main)
		})

		mockey.PatchConvey("全部为主签约主体且保持顺序", func() {
			// 全部主签约主体，覆盖append分支并验证顺序保持
			main1 := &TradePartyInfoDetail{DeputyParty: 0}
			main2 := &TradePartyInfoDetail{DeputyParty: 0}
			main3 := &TradePartyInfoDetail{DeputyParty: 0}
			others := []*TradePartyInfoDetail{main1, main2, main3}
			trade := &TradePartyInfo{OtherParty: others}

			res := trade.GetMainOtherParty()
			convey.So(len(res), convey.ShouldEqual, 3)
			// 返回顺序应与输入一致
			convey.So(res, convey.ShouldResemble, others)
		})
	})
}

func Test_BasicInfo_ValidateContractPeriod(t *testing.T) {

	mockey.PatchConvey("TestFunc", t, func() {
		mockey.PatchConvey("失败场景-有效期类型为默认值", func() {
			// 场景描述: 当有效期类型为默认值时，函数应返回参数缺失错误。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME
			// 逻辑链路:
			// 1. 函数执行到第一个if判断
			// 2. 返回 errors.ErrMissingParam.WithArgs("UsefulLifeType")
			b := &BasicInfo{
				UsefulLifeType: _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME,
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("UsefulLifeType").Error())
		})

		mockey.PatchConvey("失败场景-有效期有无期限标识为空", func() {
			// 场景描述: 当有效期有无期限标识为空时，函数应返回参数缺失错误。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - IndefiniteDateFlag 设置为空字符串
			// 逻辑链路:
			// 1. 函数通过第一个if判断
			// 2. 执行到第二个if判断，len(b.IndefiniteDateFlag) == 0
			// 3. 返回 errors.ErrMissingParam.WithArgs("IndefiniteDateFlag")
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("IndefiniteDateFlag").Error())
		})

		mockey.PatchConvey("失败场景-指定有效期但开始时间为空", func() {
			// 场景描述: 当有效期类型为指定期限，但开始时间为空时，函数应返回参数缺失错误。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - IndefiniteDateFlag 设置为 _const.No
			// - BeginTime 设置为空字符串
			// 逻辑链路:
			// 1. 函数进入 b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME 分支
			// 2. 检查到 len(b.BeginTime) == 0
			// 3. 返回 errors.ErrMissingParam.WithArgs("BeginTime")
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("BeginTime").Error())
		})

		mockey.PatchConvey("失败场景-指定有效期，结束时间为空但不是无期限合同", func() {
			// 场景描述: 指定有效期类型，结束时间为空，但IndefiniteDateFlag不为Y，表示逻辑冲突。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - IndefiniteDateFlag 设置为 _const.No
			// - EndTime 设置为空字符串
			// 逻辑链路:
			// 1. 函数进入 b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME 分支
			// 2. 检查到 len(b.EndTime) == 0 && b.IndefiniteDateFlag != _const.Yes
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "2023-01-01",
				EndTime:            "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "固定期限，结束时间无值时为无期限合同")
		})

		mockey.PatchConvey("失败场景-指定有效期，结束时间有值但不是有期限合同", func() {
			// 场景描述: 指定有效期类型，结束时间有值，但IndefiniteDateFlag不为N，表示逻辑冲突。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - IndefiniteDateFlag 设置为 _const.Yes
			// - EndTime 设置为非空
			// 逻辑链路:
			// 1. 函数进入 b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME 分支
			// 2. 检查到 len(b.EndTime) != 0 && b.IndefiniteDateFlag != _const.No
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.Yes,
				BeginTime:          "2023-01-01",
				EndTime:            "2024-01-01",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "固定期限，结束时间有值时为有期限合同")
		})

		mockey.PatchConvey("失败场景-自签订生效但为无期限合同", func() {
			// 场景描述: 自签订生效类型只支持有期限合同，如果设置为无期限则应报错。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			// - IndefiniteDateFlag 设置为 _const.Yes
			// 逻辑链路:
			// 1. 函数进入 else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME 分支
			// 2. 检查到 b.IndefiniteDateFlag != _const.No
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
				IndefiniteDateFlag: _const.Yes,
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "自签订生效只支持有期限合同")
		})

		mockey.PatchConvey("失败场景-自签订生效但有效期单位为空", func() {
			// 场景描述: 自签订生效类型，必须提供有效期单位。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			// - UsefulLifeUnit 设置为空字符串
			// 逻辑链路:
			// 1. 函数进入 else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME 分支
			// 2. 检查到 len(b.UsefulLifeUnit) == 0
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
				IndefiniteDateFlag: _const.No,
				UsefulLifeUnit:     "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("UsefulLifeUnit").Error())
		})

		mockey.PatchConvey("失败场景-自签订生效但有效期数值为0", func() {
			// 场景描述: 自签订生效类型，必须提供有效期数值。
			// 数据构造:
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			// - UsefulLifeNum 设置为 0
			// 逻辑链路:
			// 1. 函数进入 else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME 分支
			// 2. 检查到 b.UsefulLifeNum == 0
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
				IndefiniteDateFlag: _const.No,
				UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
				UsefulLifeNum:      0,
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, errors.ErrMissingParam.WithArgs("UsefulLifeNum").Error())
		})

		mockey.PatchConvey("失败场景-未知有效期类型", func() {
			// 场景描述: 提供了未知的有效期类型。
			// 数据构造:
			// - UsefulLifeType 设置为 99 (未知值)
			// 逻辑链路:
			// 1. 函数进入最外层 else 分支
			// 2. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     99,
				IndefiniteDateFlag: _const.No,
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "未知有效期类型")
		})

		mockey.PatchConvey("失败场景-自签订生效超5年且无长有效期原因", func() {
			// 场景描述: 状态为待提交，自签订生效类型，有效期超过5年，但未提供长有效期原因。
			// 数据构造:
			// - status 设置为 _const.SalesContractUnSubmit
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			// - UsefulLifeUnit 设置为 YEAR, UsefulLifeNum 设置为 6
			// - LongLifeReason 设置为空
			// 逻辑链路:
			// 1. 函数进入长有效期原因校验逻辑
			// 2. 进入 b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME 分支
			// 3. 条件 b.UsefulLifeUnit == _const.USEFUL_LIFE_UNIT_YEAR && b.UsefulLifeNum > 5 成立
			// 4. 条件 len(b.LongLifeReason) == 0 成立，返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
				IndefiniteDateFlag: _const.No,
				UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
				UsefulLifeNum:      6,
				LongLifeReason:     "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期超过五年，长有效期原因不允许为空")
		})

		mockey.PatchConvey("失败场景-指定有效期超5年且无长有效期原因", func() {
			// 场景描述: 状态为已驳回，指定有效期类型，时间跨度超过5年，但未提供长有效期原因。
			// 数据构造:
			// - status 设置为 _const.SalesContractRejected
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - BeginTime 和 EndTime 跨度大于5年
			// - LongLifeReason 设置为空
			// 逻辑链路:
			// 1. 函数进入长有效期原因校验逻辑
			// 2. 进入 else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME 分支
			// 3. 时间差 subTime > fiveYear 成立
			// 4. 条件 len(b.LongLifeReason) == 0 成立，返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "2020-01-01",
				EndTime:            "2026-01-02",
				LongLifeReason:     "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractRejected)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期超过五年，长有效期原因不允许为空")
		})

		mockey.PatchConvey("失败场景-指定有效期为无期限且无长有效期原因", func() {
			// 场景描述: 状态为待提交，指定有效期类型，无期限合同，但未提供长有效期原因。
			// 数据构造:
			// - status 设置为 _const.SalesContractUnSubmit
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - EndTime 为空
			// - LongLifeReason 设置为空
			// 逻辑链路:
			// 1. 函数进入长有效期原因校验逻辑
			// 2. 进入 else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME 分支
			// 3. 条件 len(b.EndTime) == 0 成立
			// 4. 条件 len(b.LongLifeReason) == 0 成立，返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.Yes,
				BeginTime:          "2020-01-01",
				EndTime:            "",
				LongLifeReason:     "",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "合同有效期超过五年，长有效期原因不允许为空")
		})

		mockey.PatchConvey("失败场景-指定有效期开始时间格式错误", func() {
			// 场景描述: 在校验长有效期时，指定的开始时间格式不正确，导致 time.ParseInLocation 失败。
			// 数据构造:
			// - status 设置为 _const.SalesContractUnSubmit
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - BeginTime 设置为 "invalid-date"
			// 逻辑链路:
			// 1. 函数进入长有效期原因校验逻辑
			// 2. time.ParseInLocation(util.DateFormatTpl, b.BeginTime, time.Local) 失败
			// 3. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "invalid-date",
				EndTime:            "2022-01-01",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "固定合同有效期，合同开始时间异常")
		})

		mockey.PatchConvey("失败场景-指定有效期结束时间格式错误", func() {
			// 场景描述: 在校验长有效期时，指定的结束时间格式不正确，导致 time.ParseInLocation 失败。
			// 数据构造:
			// - status 设置为 _const.SalesContractUnSubmit
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - EndTime 设置为 "invalid-date"
			// 逻辑链路:
			// 1. 函数进入长有效期原因校验逻辑
			// 2. time.ParseInLocation 对 BeginTime 成功
			// 3. time.ParseInLocation 对 EndTime 失败
			// 4. 返回错误
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "2020-01-01",
				EndTime:            "invalid-date",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "固定合同有效期，合同开始时间异常")
		})

		mockey.PatchConvey("成功场景-指定有效期类型", func() {
			// 场景描述: 提供合法的指定有效期信息，且状态不触发长有效期校验，应成功通过。
			// 数据构造:
			// - status 设置为 999 (非待提交或已驳回)
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - BeginTime 和 EndTime 均合法
			// 逻辑链路:
			// 1. 通过所有前期校验
			// 2. status 条件不满足，跳过长有效期校验
			// 3. 返回 nil
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          time.Now().Format(util.DateFormatTpl),
				EndTime:            time.Now().AddDate(1, 0, 0).Format(util.DateFormatTpl),
			}
			err := b.ValidateContractPeriod(context.Background(), 999)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景-自签订生效类型", func() {
			// 场景描述: 提供合法的自签订生效信息，且状态不触发长有效期校验，应成功通过。
			// 数据构造:
			// - status 设置为 999 (非待提交或已驳回)
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SIGN_TIME
			// - UsefulLifeUnit 和 UsefulLifeNum 均合法
			// 逻辑链路:
			// 1. 通过所有前期校验
			// 2. status 条件不满足，跳过长有效期校验
			// 3. 返回 nil
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SIGN_TIME,
				IndefiniteDateFlag: _const.No,
				UsefulLifeUnit:     _const.USEFUL_LIFE_UNIT_YEAR,
				UsefulLifeNum:      1,
			}
			err := b.ValidateContractPeriod(context.Background(), 999)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景-指定有效期超5年但有长有效期原因", func() {
			// 场景描述: 状态为待提交，指定有效期超过5年，但提供了长有效期原因，应成功通过。
			// 数据构造:
			// - status 设置为 _const.SalesContractUnSubmit
			// - UsefulLifeType 设置为 _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME
			// - BeginTime 和 EndTime 跨度大于5年
			// - LongLifeReason 设置为非空
			// 逻辑链路:
			// 1. 进入长有效期原因校验逻辑
			// 2. 时间差 subTime > fiveYear 成立
			// 3. 条件 len(b.LongLifeReason) == 0 不成立
			// 4. 校验通过，返回 nil
			b := &BasicInfo{
				UsefulLifeType:     _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME,
				IndefiniteDateFlag: _const.No,
				BeginTime:          "2020-01-01",
				EndTime:            "2026-01-01",
				LongLifeReason:     "长期合作",
			}
			err := b.ValidateContractPeriod(context.Background(), _const.SalesContractUnSubmit)
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ManageInfo_ValidateProductHasSameInvoice_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	mockey.PatchConvey("Test_ManageInfo_ValidateProductHasSameInvoice", t, func() {
		mockey.PatchConvey("海外环境场景-跳过校验", func() {
			// 场景描述:
			// 当环境为海外环境(IsBytePlus返回true)时，即使商品信息中存在同一商品开票项目不一致的情况，也应该跳过校验，直接返回成功(nil)。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 包含一个分组，其中 "商品A" 有两个不同的 "InvoiceProject"。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 true。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数返回 nil，因为海外环境会跳过检查。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{TradeProduct: "商品A", InvoiceProject: "开票项目1"},
						{TradeProduct: "商品A", InvoiceProject: "开票项目2"},
					},
				},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(true).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("国内环境-成功场景-开票项目一致", func() {
			// 场景描述:
			// 当环境为国内环境(IsBytePlus返回false)，且所有商品行中，同一商品的开票项目都保持一致时，校验应通过。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 包含一个分组。
			// - "商品A" 出现多次，但 "InvoiceProject" 均为 "开票项目1"。
			// - "商品B" 只出现一次。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 false。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数返回 nil。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{TradeProduct: "商品A", InvoiceProject: "开票项目1"},
						{TradeProduct: "商品B", InvoiceProject: "开票项目2"},
						{TradeProduct: "商品A", InvoiceProject: "开票项目1"},
					},
				},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("国内环境-成功场景-存在空开票项目", func() {
			// 场景描述:
			// 当环境为国内环境，商品行中存在开票项目为空字符串的情况，这些商品行应被忽略，不参与一致性校验。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 包含一个分组。
			// - "商品A" 同时存在 "开票项目1" 和空字符串 "" 两种情况。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 false。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数返回 nil，因为空开票项目被忽略。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{TradeProduct: "商品A", InvoiceProject: "开票项目1"},
						{TradeProduct: "商品A", InvoiceProject: ""},
					},
				},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("国内环境-成功场景-商品信息为空", func() {
			// 场景描述:
			// 当环境为国内环境，但 ManageInfo 中的 ProductLevelMap 为空时，函数应直接返回成功。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 为空 map。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 false。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数返回 nil。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("国内环境-失败场景-同一分组内开票项目不一致", func() {
			// 场景描述:
			// 当环境为国内环境，且在同一个商品分组中，同一商品存在不同的开票项目时，校验应失败并返回错误信息。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 包含一个分组。
			// - "商品A" 存在 "开票项目1" 和 "开票项目2" 两个不同的 InvoiceProject。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 false。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数返回一个非 nil 的 APIError。
			// 4. 验证错误信息包含 "同一商品[商品A]开票项目不一致"。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{TradeProduct: "商品A", InvoiceProject: "开票项目1"},
						{TradeProduct: "商品B", InvoiceProject: "开票项目3"},
						{TradeProduct: "商品A", InvoiceProject: "开票项目2"},
					},
				},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "同一商品[商品A]开票项目不一致, [开票项目1], [开票项目2]")
		})

		mockey.PatchConvey("国内环境-失败场景-不同分组中存在不一致", func() {
			// 场景描述:
			// 当环境为国内环境，且在不同的商品分组中，同一商品的开票项目不一致时，校验同样应失败。
			// 数据构造:
			// - ManageInfo.ProductLevelMap 包含两个分组 "group1" 和 "group2"。
			// - "group1" 中的商品开票项目一致。
			// - "group2" 中的 "商品X" 存在 "开票项目A" 和 "开票项目B" 两个不同的 InvoiceProject。
			// 逻辑链路:
			// 1. Mock multienv.IsBytePlus 返回 false。
			// 2. 调用 ValidateProductHasSameInvoice 方法。
			// 3. 验证函数在处理 "group2" 时返回一个非 nil 的 APIError。
			// 4. 验证错误信息包含 "同一商品[商品X]开票项目不一致"。

			// 数据构造
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"group1": {
						{TradeProduct: "商品Y", InvoiceProject: "开票项目Z"},
						{TradeProduct: "商品Y", InvoiceProject: "开票项目Z"},
					},
					"group2": {
						{TradeProduct: "商品X", InvoiceProject: "开票项目A"},
						{TradeProduct: "商品X", InvoiceProject: "开票项目B"},
					},
				},
			}

			// Mock
			mockey.Mock(multienv.IsBytePlus).Return(false).Build()

			// 调用
			err := m.ValidateProductHasSameInvoice(ctx)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "同一商品[商品X]开票项目不一致, [开票项目A], [开票项目B]")
		})
	})
}

func TestManageInfo_ValidateProductConfigurationChargeCodeUnique(t *testing.T) {
	ctx := context001.Background()

	mockey.PatchConvey("TestManageInfo_ValidateProductConfigurationChargeCodeUnique", t, func() {
		convey.Convey("成功场景 - 商品配置和计费项唯一", func() {
			// 场景描述:
			// 当ProductLevelMap中的每个商品列表里的商品都具有唯一的配置+计费项组合时，校验通过。
			// 数据构造:
			// - ManageInfo 包含一个商品列表，列表中有两个不同的商品。
			// 逻辑链路:
			// 1. Mock (*ProductInfo).ConvertProductKeyInfo 返回一个虚拟的 ProductInfo。
			// 2. Mock productkey.GenKey 依次返回 "key1" 和 "key2"，表示唯一。
			// 3. 调用 ValidateProductConfigurationChargeCodeUnique。
			// 4. 断言返回的 error 为 nil。
			p1 := &ProductInfo{Configuration: "config1", ChargeItemCode: "item1"}
			p2 := &ProductInfo{Configuration: "config2", ChargeItemCode: "item2"}
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"level1": {p1, p2},
				},
			}

			mockey.Mock((*ProductInfo).ConvertProductKeyInfo).Return(&productkey.ProductInfo{}).Build()
			mockey.Mock(productkey.GenKey).Return(
				mockey.Sequence("key1", nil).Then("key2", nil),
			).Build()

			err := m.ValidateProductConfigurationChargeCodeUnique(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("成功场景 - ProductLevelMap为空", func() {
			// 场景描述:
			// 当ManageInfo的ProductLevelMap为nil或空时，函数应直接返回nil，不进行任何校验。
			// 数据构造:
			// - ManageInfo 的 ProductLevelMap 字段为 nil。
			// 逻辑链路:
			// 1. 调用 ValidateProductConfigurationChargeCodeUnique。
			// 2. 断言返回的 error 为 nil。
			m := &ManageInfo{
				ProductLevelMap: nil,
			}

			err := m.ValidateProductConfigurationChargeCodeUnique(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("成功场景 - 跳过旧数据(Configuration和ChargeItemCode为空)", func() {
			// 场景描述:
			// 商品列表中的商品如果 Configuration 和 ChargeItemCode 均为空，则应跳过校验。
			// 数据构造:
			// - ManageInfo 包含一个商品列表，其中一个商品是旧数据格式，另一个是新数据格式。
			// 逻辑链路:
			// 1. Mock (*ProductInfo).ConvertProductKeyInfo 返回一个虚拟的 ProductInfo。
			// 2. Mock productkey.GenKey 仅为新数据生成 key。
			// 3. 调用 ValidateProductConfigurationChargeCodeUnique。
			// 4. 断言返回的 error 为 nil，表示旧数据被成功跳过。
			pOld := &ProductInfo{Configuration: "", ChargeItemCode: ""}
			pNew := &ProductInfo{Configuration: "config1", ChargeItemCode: "item1"}
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"level1": {pOld, pNew},
				},
			}

			mockey.Mock((*ProductInfo).ConvertProductKeyInfo).Return(&productkey.ProductInfo{}).Build()
			mockey.Mock(productkey.GenKey).Return("key_new", nil).Build()

			err := m.ValidateProductConfigurationChargeCodeUnique(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		convey.Convey("失败场景 - 商品编码_配置_计费项重复", func() {
			// 场景描述:
			// 当同一商品列表里存在配置+计费项重复的商品时，校验应失败并返回错误。
			// 数据构造:
			// - ManageInfo 包含一个商品列表，其中两个商品会生成相同的 key。
			// 逻辑链路:
			// 1. Mock (*ProductInfo).ConvertProductKeyInfo。
			// 2. Mock productkey.GenKey 两次都返回 "duplicate_key"。
			// 3. 调用 ValidateProductConfigurationChargeCodeUnique。
			// 4. 断言返回非 nil 的 error，且错误信息包含“重复”。
			p1 := &ProductInfo{TradeProductCode: "TPC1", Configuration: "config1", ChargeItemCode: "item1"}
			p2 := &ProductInfo{TradeProductCode: "TPC1", Configuration: "config1", ChargeItemCode: "item1"}
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"level1": {p1, p2},
				},
			}

			mockey.Mock((*ProductInfo).ConvertProductKeyInfo).Return(&productkey.ProductInfo{}).Build()
			mockey.Mock(productkey.GenKey).Return("duplicate_key", nil).Build()

			err := m.ValidateProductConfigurationChargeCodeUnique(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "商品编码_配置_计费项 重复")
		})

		convey.Convey("失败场景 - productkey.GenKey生成失败", func() {
			// 场景描述:
			// 当依赖的 productkey.GenKey 函数返回错误时，校验应失败并返回相应的错误信息。
			// 数据构造:
			// - ManageInfo 包含一个商品。
			// 逻辑链路:
			// 1. Mock (*ProductInfo).ConvertProductKeyInfo。
			// 2. Mock productkey.GenKey 返回一个非 nil 的 error。
			// 3. 调用 ValidateProductConfigurationChargeCodeUnique。
			// 4. 断言返回非 nil 的 error，且错误信息包含 "ProductkeyGenKeyFail_new"。
			p1 := &ProductInfo{Configuration: "config1", ChargeItemCode: "item1"}
			m := &ManageInfo{
				ProductLevelMap: map[string][]*ProductInfo{
					"level1": {p1},
				},
			}

			mockey.Mock((*ProductInfo).ConvertProductKeyInfo).Return(&productkey.ProductInfo{}).Build()
			mockey.Mock(productkey.GenKey).Return("", errors001.New("genkey error")).Build()

			err := m.ValidateProductConfigurationChargeCodeUnique(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ProductkeyGenKeyFail_new")
		})
	})
}

func TestGroupQuoteDiscounts_ByteUT(t *testing.T) {
	t.Run("正常场景：包含主折扣项和对应的抵扣项", func(t *testing.T) {
		mockey.PatchConvey("正常场景：包含主折扣项和对应的抵扣项", t, func() {
			// 该子场景测试用例用于验证当输入包含主折扣项和与之关联的抵扣项时，函数能正确地将抵扣项归类到对应的主折扣项下。
			// 调用链路为：GroupQuoteDiscounts -> 内部循环处理 -> 返回聚合后的折扣列表。
			// 预期结果为：返回的主折扣项列表中，其 DeductList 字段应包含所有相关的抵扣项。
			qds := []*QuoteDiscount{
				{
					ReferenceID:      "main_item_1",
					ItemBusinessRole: _const.ItemBusinessRoleStandard,
				},
				{
					RelatedItemID:    "main_item_1",
					ItemBusinessRole: _const.ItemBusinessRoleDeduct,
					ProductName:      "deduct_item_1",
				},
				{
					ReferenceID:      "main_item_2",
					ItemBusinessRole: _const.ItemBusinessRoleStandard,
				},
			}

			result := GroupQuoteDiscounts(qds)

			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(result[0].ReferenceID, convey.ShouldEqual, "main_item_1")
			convey.So(len(result[0].DeductList), convey.ShouldEqual, 1)
			convey.So(result[0].DeductList[0].ProductName, convey.ShouldEqual, "deduct_item_1")
			convey.So(result[1].ReferenceID, convey.ShouldEqual, "main_item_2")
			convey.So(len(result[1].DeductList), convey.ShouldEqual, 0)
		})
	})

	t.Run("边界场景：输入为空列表", func(t *testing.T) {
		mockey.PatchConvey("边界场景：输入为空列表", t, func() {
			// 该子场景测试用例用于验证当输入折扣列表为空时，函数的健壮性。
			// 调用链路为：GroupQuoteDiscounts -> 直接返回。
			// 预期结果为：返回一个空的折扣列表。
			var qds []*QuoteDiscount

			result := GroupQuoteDiscounts(qds)

			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("场景：只包含主折扣项，无抵扣项", func(t *testing.T) {
		mockey.PatchConvey("场景：只包含主折扣项，无抵扣项", t, func() {
			// 该子场景测试用例用于验证当输入只包含主折扣项时，函数能正确处理。
			// 调用链路为：GroupQuoteDiscounts -> 循环处理主折扣项 -> 未找到匹配的抵扣项。
			// 预期结果为：返回所有主折扣项，且它们的 DeductList 字段均为空。
			qds := []*QuoteDiscount{
				{
					ReferenceID:      "main_item_1",
					ItemBusinessRole: _const.ItemBusinessRoleStandard,
				},
				{
					ReferenceID:      "main_item_2",
					ItemBusinessRole: _const.ItemBusinessRoleStandard,
				},
			}

			result := GroupQuoteDiscounts(qds)

			convey.So(len(result), convey.ShouldEqual, 2)
			convey.So(len(result[0].DeductList), convey.ShouldEqual, 0)
			convey.So(len(result[1].DeductList), convey.ShouldEqual, 0)
		})
	})

	t.Run("场景：只包含抵扣项，无主折扣项", func(t *testing.T) {
		mockey.PatchConvey("场景：只包含抵扣项，无主折扣项", t, func() {
			// 该子场景测试用例用于验证当输入只包含抵扣项时，函数的处理情况。
			// 调用链路为：GroupQuoteDiscounts -> 抵扣项被存入map，但主折扣项列表为空。
			// 预期结果为：返回一个空的折扣列表。
			qds := []*QuoteDiscount{
				{
					RelatedItemID:    "main_item_1",
					ItemBusinessRole: _const.ItemBusinessRoleDeduct,
				},
			}

			result := GroupQuoteDiscounts(qds)

			convey.So(len(result), convey.ShouldEqual, 0)
		})
	})

	t.Run("场景：主折扣项与抵扣项ID不匹配", func(t *testing.T) {
		mockey.PatchConvey("场景：主折扣项与抵扣项ID不匹配", t, func() {
			// 该子场景测试用例用于验证当主折扣项的ReferenceID与抵扣项的RelatedItemID不匹配时，不会发生错误关联。
			// 调用链路为：GroupQuoteDiscounts -> 循环处理主折扣项 -> 在抵扣map中未找到匹配项。
			// 预期结果为：返回主折扣项，但其 DeductList 字段为空。
			qds := []*QuoteDiscount{
				{
					ReferenceID:      "main_item_1",
					ItemBusinessRole: _const.ItemBusinessRoleStandard,
				},
				{
					RelatedItemID:    "some_other_id",
					ItemBusinessRole: _const.ItemBusinessRoleDeduct,
				},
			}

			result := GroupQuoteDiscounts(qds)

			convey.So(len(result), convey.ShouldEqual, 1)
			convey.So(result[0].ReferenceID, convey.ShouldEqual, "main_item_1")
			convey.So(len(result[0].DeductList), convey.ShouldEqual, 0)
		})
	})
}

type args struct {
	ctx          context.Context
	discountInfo string
}

var qds []*QuoteDiscount

var receiver *ProjectInfo = &ProjectInfo{}

var v = 1

var tpi *TradePartyInfo

var m *ManageInfo

var vTest *string = conv.StringPtr("Test Value")

const privateDeploymentType = 1

const nonMasterRecordType = 2

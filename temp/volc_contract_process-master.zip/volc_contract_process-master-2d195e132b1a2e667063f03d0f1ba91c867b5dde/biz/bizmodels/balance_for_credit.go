package bizmodels

import "github.com/shopspring/decimal"

type BalanceForCreditData struct {
	AccountID    int64
	SubjectNo    string
	Balance      decimal.Decimal
	CreditLimit  decimal.Decimal
	CreditUsed   decimal.Decimal
	Freeze       decimal.Decimal
	TotalBalance decimal.Decimal
	PayPeriod    int64
	CreditSource int64
}

package bizmodels

import (
	_const "volc_contract_process/pkg/const"
)

// SalesMetaListParam 合同列表查询
type SalesMetaListParam struct {
	SourceType              _const.SourceType
	IsManager               bool   `json:"IsManager" query:"IsManager"`
	CurrentOperator         string `json:"CurrentOperator" query:"CurrentOperator"`             //
	BizSourceList           string `json:"BizSourceList" query:"BizSourceList"`                 //
	CooperationStatusList   []int  `json:"CooperationStatusList" query:"CooperationStatusList"` //
	ActiveStatusList        []int  `json:"ActiveStatusList" query:"ActiveStatusList"`           //
	BizAccountID            int    `query:"BizAccountID"`                                       //
	BizSource               int    `json:"BizSource" query:"BizSource"`                         //
	InProcess               int    `json:"InProcess" query:"InProcess"`                         //
	SupplyScene             string `json:"SupplyScene" query:"SupplyScene"`                     //
	VolcContractNo          string `json:"VolcContractNo" query:"VolcContractNo"`               //
	ContractNo              string `json:"ContractNo" query:"ContractNo"`                       //
	ContractNoList          string `json:"ContractNoList" query:"ContractNoList"`               //
	ContractName            string `json:"ContractName" query:"ContractName"`                   //
	SubjectName             string `json:"SubjectName" query:"SubjectName"`                     //
	OtherPartyName          string `json:"OtherPartyName" query:"OtherPartyName"`               //
	PropertyCode            string `json:"PropertyCode" query:"PropertyCode"`                   // 合同性质
	CategoryNo              string `json:"CategoryNo" query:"CategoryNo"`                       // 合同类型
	InOutType               string `json:"InOutType" query:"InOutType"`                         // 收支类型
	Initiator               int    `json:"Initiator" query:"Initiator"`                         // 发起端
	CooperationStatus       *int   `json:"CooperationStatus" query:"CooperationStatus"`         // 协商状态
	ArchivedStatus          *int   `json:"ArchivedStatus" query:"ArchivedStatus"`               // 归档状态
	ActiveStatus            *int   `json:"ActiveStatus" query:"ActiveStatus"`                   // 生效状态
	Status                  *int   `json:"Status" query:"Status"`                               // 合同状态
	StatusList              string `json:"StatusList" query:"StatusList"`                       // 合同状态列表
	Operator                int64  `json:"Operator" query:"Operator"`                           //
	Creator                 int64  `json:"Creator" query:"Creator"`                             //
	CreatedTimeBegin        string `json:"CreatedTimeBegin" query:"CreatedTimeBegin"`           //
	CreatedTimeEnd          string `json:"CreatedTimeEnd" query:"CreatedTimeEnd"`               //
	ValidityBegin           string `json:"ValidityBegin" query:"ValidityBegin"`                 //
	ValidityEnd             string `json:"ValidityEnd" query:"ValidityEnd"`                     //
	SubmitTimeBegin         string `json:"SubmitTimeBegin" query:"SubmitTimeBegin"`             //
	SubmitTimeEnd           string `json:"SubmitTimeEnd" query:"SubmitTimeEnd"`                 //
	FileTimeBegin           string `json:"FileTimeBegin" query:"FileTimeBegin"`                 //
	FileTimeEnd             string `json:"FileTimeEnd" query:"FileTimeEnd"`                     //
	OrderBy                 int    `json:"OrderBy" query:"OrderBy"`                             //
	Limit                   int    `json:"limit" query:"Limit" default:"10"`                    //
	Offset                  int    `json:"offset" query:"Offset"`                               //
	NeedCalcCooperationRole bool   //
}

func (s SalesMetaListParam) ConvertMetaListParam() *MetaListParam {
	return &MetaListParam{
		SourceType:              s.SourceType,
		IsManager:               s.IsManager,
		CurrentOperator:         s.CurrentOperator,
		BizSceneList:            "1,2,3",
		BizSourceList:           s.BizSourceList,
		CooperationStatusList:   s.CooperationStatusList,
		ActiveStatusList:        s.ActiveStatusList,
		BizAccountID:            s.BizAccountID,
		BizSource:               s.BizSource,
		InProcess:               s.InProcess,
		SupplyScene:             s.SupplyScene,
		VolcContractNo:          s.VolcContractNo,
		ContractNo:              s.ContractNo,
		ContractNoList:          s.ContractNoList,
		ContractName:            s.ContractName,
		SubjectName:             s.SubjectName,
		OtherPartyName:          s.OtherPartyName,
		PropertyCode:            s.PropertyCode,
		CategoryNo:              s.CategoryNo,
		InOutType:               s.InOutType,
		Initiator:               s.Initiator,
		CooperationStatus:       s.CooperationStatus,
		ArchivedStatus:          s.ArchivedStatus,
		ActiveStatus:            s.ActiveStatus,
		Status:                  s.Status,
		StatusList:              s.StatusList,
		Operator:                s.Operator,
		Creator:                 s.Creator,
		CreatedTimeBegin:        s.CreatedTimeBegin,
		CreatedTimeEnd:          s.CreatedTimeEnd,
		ValidityBegin:           s.ValidityBegin,
		ValidityEnd:             s.ValidityEnd,
		SubmitTimeBegin:         s.SubmitTimeBegin,
		SubmitTimeEnd:           s.SubmitTimeEnd,
		FileTimeBegin:           s.FileTimeBegin,
		FileTimeEnd:             s.FileTimeEnd,
		OrderBy:                 s.OrderBy,
		Limit:                   s.Limit,
		Offset:                  s.Offset,
		NeedCalcCooperationRole: s.NeedCalcCooperationRole,
	}
}

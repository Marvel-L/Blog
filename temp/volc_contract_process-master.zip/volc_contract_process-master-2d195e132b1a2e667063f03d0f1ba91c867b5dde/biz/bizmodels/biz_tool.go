package bizmodels

import (
	"code.byted.org/gopkg/context"
	bytedstrings "code.byted.org/gopkg/lang/strings"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type MetaCreateReq struct {
	AccountID    int64 // passport账号
	CardNo       string
	DocumentType string
	Country      string
	Token        string //
}

func (m *MetaCreateReq) Validate(ctx context.Context) error {
	if m.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	if m.AccountID == 0 {
		return i18nfmt.New(ctx, "AccountID异常")
	}
	return nil
}

type ToolQueryContractByIdentReq struct {
	ContractNo      string
	ContractVersion int
	Scene           int
	Identifier      string
}

type ToolHttpMqMsgReq struct {
	Token      string //
	EventType  string //
	BizKey     string //
	StatusCode int    //
	EventTime  string //
}

func (r *ToolHttpMqMsgReq) Validate(ctx context.Context) error {
	if r.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	return nil
}

type ToolHttpMqDeferMsgReq struct {
	Token     string //
	DeferType string //
	Body      string //
}

func (r *ToolHttpMqDeferMsgReq) Validate(ctx context.Context) error {
	if r.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	return nil
}

type ToolHttpVolcContractEventMsgReq struct {
	Token string //
	Body  string // 合同事件 MQ 消息体，对应 contractevent.Event JSON
}

func (r *ToolHttpVolcContractEventMsgReq) Validate(ctx context.Context) error {
	if r.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	if r.Body == "" {
		return i18nfmt.New(ctx, "Body异常")
	}
	return nil
}

type ToolHttpFeishuMqMsgReq struct {
	Token      string //
	EventType  string //
	EventToken string
	Events     []FeishuContractMsgEvent
}

func (r *ToolHttpFeishuMqMsgReq) Validate(ctx context.Context) error {
	if r.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	return nil
}

type ToolHttpAccountChangInnerEBHttpMsgReq struct {
	Token     string //
	AccountID int64
}

func (r *ToolHttpAccountChangInnerEBHttpMsgReq) Validate(ctx context.Context) error {
	if r.Token != _const.MetaToolToken {
		return i18nfmt.New(ctx, "token异常")
	}
	if r.AccountID <= 0 {
		return i18nfmt.New(ctx, "AccountID异常")
	}
	return nil
}

type DateMergeCall struct {
	Type int
	Body string
}

// ToolAddOtherPartyAccountReq 用于工具接口补充对方主体账号信息
type ToolAddOtherPartyAccountReq struct {
	ContractNo        string `json:"ContractNo" form:"ContractNo" query:"ContractNo"`                      // 合同编号，必填
	PartyNumber       string `json:"PartyNumber" form:"PartyNumber" query:"PartyNumber"`                   // 对方主体编码，必填
	AccountID         string `json:"AccountID" form:"AccountID" query:"AccountID"`                         // 账号
	SealAccountID     string `json:"SealAccountID" form:"SealAccountID" query:"SealAccountID"`             // 签约账号
	PricingAccountID  string `json:"PricingAccountID" form:"PricingAccountID" query:"PricingAccountID"`    // 配价账号
	IsSealed          *int   `json:"IsSealed" form:"IsSealed" query:"IsSealed"`                            // 是否为签约主体，0/1
	IsPricing         *int   `json:"IsPricing" form:"IsPricing" query:"IsPricing"`                         // 是否为配价主体，0/1
	IsDeputyParty     bool   `json:"IsDeputyParty" form:"IsDeputyParty" query:"IsDeputyParty"`             // 是否为副签约主体
	DeputyPartySource int    `json:"DeputyPartySource" form:"DeputyPartySource" query:"DeputyPartySource"` // 副签约主体来源，1-销售运营手动添加，2-飞书同步
}

func (r *ToolAddOtherPartyAccountReq) Validate(ctx context.Context) errors.APIError {
	if bytedstrings.IsEmpty(r.ContractNo) {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if bytedstrings.IsEmpty(r.PartyNumber) {
		return errors.ErrMissingParam.WithArgs("PartyNumber")
	}
	if r.IsSealed == nil {
		return errors.ErrMissingParam.WithArgs("IsSealed")
	}
	if r.IsPricing == nil {
		return errors.ErrMissingParam.WithArgs("IsPricing")
	}
	if r.IsDeputyParty {
		if r.DeputyPartySource == 0 {
			return errors.ErrMissingParam.WithArgs("DeputyPartySource")
		}
	}
	if r.DeputyPartySource != 0 && r.DeputyPartySource != _const.SubPartySourceManualAdd && r.DeputyPartySource != _const.SubPartySourceLarkSync {
		return errors.ErrInvalidParam.WithArgs("DeputyPartySource")
	}
	return nil
}

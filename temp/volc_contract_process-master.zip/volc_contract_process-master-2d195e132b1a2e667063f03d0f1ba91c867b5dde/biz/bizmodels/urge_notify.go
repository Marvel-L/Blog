package bizmodels

// 催办相关

type UrgeNotifyInfo struct {
	Email string `json:"Email"`
	Name  string `json:"Name"`
	//AvatarURL          string `json:"AvatarURL"`
	LastUrgeNotifyInfo string `json:"LastUrgeNotifyInfo"`
}

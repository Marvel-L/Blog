package bizmodels

type CommonOperationRecord struct {
	Operator    string // 操作人，可能是内部人员邮箱 或者外部客户ID
	Operation   int    // 操作
	Remark      string // 节点描述
	OpState     string // 操作状态
	Extra       string // 额外信息
	OperateTime string // 操作时间
}

type CommonOperationRecordList []*CommonOperationRecord

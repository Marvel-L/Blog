package bizmodels

type GetAttachmentPreviewInfoReq struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` // 当前操作人
	DownloadID      string `json:"DownloadID" query:"DownloadID"`
	DocVersion      string `json:"DocVersion" query:"DocVersion"`
}

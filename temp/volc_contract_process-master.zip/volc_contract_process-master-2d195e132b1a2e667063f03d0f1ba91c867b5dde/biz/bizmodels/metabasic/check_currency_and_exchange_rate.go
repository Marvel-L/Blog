package metabasic

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/util"
)

type CheckCurrencyAndExchangeRateReq struct {
	AccountIDs       []string
	CurrencyCode     string
	ExchangeRateType int
	ExchangeRate     string
}

func (r *CheckCurrencyAndExchangeRateReq) Validate() errors.APIError {
	isUsd := util.StringIn(r.CurrencyCode, []string{_const.CurrencyUSD, _const.CurrencyUSDMdCode})
	if len(r.AccountIDs) == 0 {
		return errors.ErrMissingParam.WithArgs("AccountIDs")
	}
	if len(r.CurrencyCode) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrencyCode")
	}
	if !isUsd && r.ExchangeRateType <= 0 {
		return errors.ErrMissingParam.WithArgs("ExchangeRateType")
	}
	if !isUsd && r.ExchangeRateType == _const.ExchangeRateTypeFixed && len(r.ExchangeRate) == 0 {
		return errors.ErrMissingParam.WithArgs("ExchangeRate")
	}
	return nil
}

type CheckCurrencyAndExchangeRateResp struct {
	Agree       bool
	CurrentData CurrencyAndExchangeRateData
	List        []*CurrencyAndExchangeRateData
}

// 币种、汇率信息
type CurrencyAndExchangeRateData struct {
	AccountID        string
	CurrencyCode     string
	ExchangeRateType int
	ExchangeRate     string
}

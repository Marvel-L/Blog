package metabasic

import (
	"testing"

	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func Test_Validate(t *testing.T) {
	PatchConvey("Test Validate with empty AccountIDs", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{},
			CurrencyCode:     "USD",
			ExchangeRateType: 1,
			ExchangeRate:     "1.0",
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("AccountIDs"))
	})

	PatchConvey("Test Validate with empty CurrencyCode", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "",
			ExchangeRateType: 1,
			ExchangeRate:     "1.0",
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("CurrencyCode"))
	})

	PatchConvey("Test Validate with non-USD currency and missing ExchangeRateType", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "EUR",
			ExchangeRateType: 0,
			ExchangeRate:     "1.0",
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("ExchangeRateType"))
	})

	PatchConvey("Test Validate with non-USD currency and ExchangeRateTypeFixed but empty ExchangeRate", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "",
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("ExchangeRate"))
	})

	PatchConvey("Test Validate with valid USD currency", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "USD",
			ExchangeRateType: 0,
			ExchangeRate:     "",
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with valid non-USD currency and ExchangeRateTypeFixed", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "EUR",
			ExchangeRateType: _const.ExchangeRateTypeFixed,
			ExchangeRate:     "1.0",
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with valid non-USD currency and non-ExchangeRateTypeFixed", t, func() {
		req := &CheckCurrencyAndExchangeRateReq{
			AccountIDs:       []string{"123"},
			CurrencyCode:     "EUR",
			ExchangeRateType: 1,
			ExchangeRate:     "",
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})
}

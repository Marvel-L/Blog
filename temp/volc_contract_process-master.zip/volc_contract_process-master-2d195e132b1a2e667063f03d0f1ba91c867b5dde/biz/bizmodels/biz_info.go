package bizmodels

type BizInfo interface {
	IsBizInfoFlag()
}

type baseBizInfo struct {
}

func (b baseBizInfo) IsBizInfoFlag() {
}

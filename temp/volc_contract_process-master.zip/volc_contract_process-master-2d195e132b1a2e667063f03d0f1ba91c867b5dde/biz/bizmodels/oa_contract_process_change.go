package bizmodels

type OAContractMsg struct {
	MessageID      string `json:"message_id"`      // 消息ID
	EventType      string `json:"event_type"`      // 事件类型
	UnitCode       string `json:"unit_code"`       // 部门Code
	ContractNumber string `json:"contract_number"` // 合同编号
	BizKey         string `json:"biz_key"`         // 合同编号
	EventTime      string `json:"event_time"`      // 事件发生时间
	SendTime       string `json:"send_time"`       // mq消息发送时间
	CategoryNumber string `json:"category_number"` // 合同类型
	PrevNodeCode   string `json:"prev_node_code"`  // 上一审批节点
}

package bizmodels

import (
	"volc_contract_process/pkg/errors"
)

type GetSupplyContractListReq struct {
	FromContractNo    string `json:"FromContractNo" query:"FromContractNo"`
	NeedSupplyRelease bool   `json:"NeedSupplyRelease" query:"NeedSupplyRelease"`
}

type IsMeetSupplyConditionReq struct {
	ContractNo     string `json:"ContractNo" query:"ContractNo"`
	OperatorID     string `json:"OperatorID" query:"OperatorID"`
	WhetherProject string `json:"WhetherProject" query:"WhetherProject"`
	SupplySource   string `json:"SupplySource" query:"SupplySource"`
}

func (r *IsMeetSupplyConditionReq) Validate() errors.APIError {
	if r.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if r.OperatorID == "" {
		return errors.ErrMissingParam.WithArgs("OperatorID")
	}
	if r.WhetherProject == "" {
		return errors.ErrMissingParam.WithArgs("WhetherProject")
	}
	return nil
}

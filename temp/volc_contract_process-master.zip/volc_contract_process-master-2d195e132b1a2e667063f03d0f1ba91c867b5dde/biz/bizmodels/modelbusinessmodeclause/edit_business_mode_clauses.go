package modelbusinessmodeclause

import (
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/errors"
)

// EditBusinessModeClausesReq 编辑商务模式条款摘要请求
type EditBusinessModeClausesReq struct {
	ContractNo          string                          `json:"ContractNo" form:"ContractNo" query:"ContractNo"`
	CurrentOperator     string                          `json:"CurrentOperator" form:"CurrentOperator" query:"CurrentOperator"`
	BusinessModeClauses []*bizmodels.BusinessModeClause `json:"BusinessModeClauses"`
}

func (e *EditBusinessModeClausesReq) Validate() errors.APIError {
	if e.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if e.CurrentOperator == "" {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	return nil
}

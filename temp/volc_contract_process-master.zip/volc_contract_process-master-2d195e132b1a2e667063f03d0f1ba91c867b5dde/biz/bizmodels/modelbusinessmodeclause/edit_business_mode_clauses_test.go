package modelbusinessmodeclause

import (
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestEditBusinessModeClausesReqValidate(t *testing.T) {
	t.Run("合同编号为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &EditBusinessModeClausesReq{
				CurrentOperator: "tester",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "ContractNo")
		})
	})

	t.Run("当前操作人为空返回错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &EditBusinessModeClausesReq{
				ContractNo: "CN-001",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "CurrentOperator")
		})
	})

	t.Run("参数齐全返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			req := &EditBusinessModeClausesReq{
				ContractNo:      "CN-001",
				CurrentOperator: "tester",
			}

			err := req.Validate()

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

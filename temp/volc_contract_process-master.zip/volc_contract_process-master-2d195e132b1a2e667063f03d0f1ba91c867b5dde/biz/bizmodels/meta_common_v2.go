package bizmodels

import (
	"time"

	_const "volc_contract_process/pkg/const"
)

type ContractProcessContext struct {
	CurrentOperator      string             // 当前操作人
	ProcessKey           _const.ProcessType // 变更流程，创建、更新、提交、作废
	BizScene             int                // 业务来源
	BizSource            int                // 合同来源
	SupplyScene          int                // 补充协议分类
	Initiator            int                // 发起端
	Operation            int                // 操作值
	ContractNo           string             // 合同号
	Version              int                // 版本
	InOutType            string             // 收支类型
	Status               int                // 合同状态
	CooperationStatus    int                // 协商状态
	PreCooperationStatus int                // 前序协商状态
	TemplateMaster       *TemplateDetail

	// 合同参数
	CreateOrUpdateReq *CreateOrUpdateMetaReq // 请求参数
	// BeforeMeta        *model.ContractMetaDB  // 变更前合同元数据
	// AfterMeta         *model.ContractMetaDB  // 变更后合同元数据
	BeforeData *ContractFullData // 变更前合同全量数据
	AfterData  *ContractFullData // 变更后合同全量数据

	// 非入参 预处理参数 基于入参计算
	IsRejectContract bool `json:"IsRejectContract" query:"IsRejectContract"` // 是否是因为用户拒绝重提的合同
	IsQuoteNoChange  bool // 报价单号是否变更
	IsQuoteNoClear   bool // 报价单被清空
	UseTemplate      bool // 是否关联了模板
}

// 合同全量数据结构体
type ContractFullData struct {
	BizScene                   int               // 业务来源
	BizSource                  int               // 合同来源
	SupplyScene                int               // 补充协议分类
	SupplySource               string            // 补充场景
	Initiator                  int               // 发起端
	ContractNo                 string            // 合同号
	Version                    int               `json:"ContractVersion"` // 版本
	OaContractNo               string            // 提交签章生成的合同号
	PreContractNo              string            // 临时合同号
	FromContractNo             string            // 原合同号
	MainContractNo             string            // 主合同号
	VolcContractNo             string            // 火山补充合同号
	OaAppId                    string            // 提交签章的 AppID，历史对接的 OA 系统签约
	SubjectNo                  string            // 合同主体编号-交易侧维护的
	Creator                    string            // 创建人
	Operator                   string            // 业务执行人工号
	CreatorNew                 string            // 创建人
	OperatorNew                string            // 业务执行人工号
	PropertyCode               string            // 合同性质
	InOutType                  string            // 收支类型
	CategoryNo                 string            // 合同分类编码
	SignatureType              string            // 签约形式
	SpecialContractType        string            // 特殊合同类型
	ContractName               string            // 合同名称
	BeginTime                  time.Time         // 开始时间
	EndTime                    time.Time         // 结束时间
	SubmitTime                 time.Time         // 合同提交时间
	VersionCreatedTime         time.Time         // 合同版本创建时间
	SignTime                   time.Time         // 合同签订时间
	FileTime                   time.Time         // 合同归档时间
	FinishTime                 time.Time         // 合同流程结束时间
	ContractPriceCreatedTime   time.Time         // 合同价创建时间
	FromContractTerminatedTime time.Time         // 原合同终止日期
	BasicInfo                  *BasicInfo        // 合同基本信息
	ManageInfo                 *ManageInfo       // 管理信息
	TradePartyInfo             *TradePartyInfo   // 交易双方信息
	SettlementInfo             *SettlementInfo   // 结算条款信息
	ReverseSignInfo            *ReverseSignInfo  // 合同倒签信息
	TemplateInfo               *TemplateInfo     // 模板信息
	RelateQuoteNo              string            // 关联报价单号
	RelateQuoteScene           int               // 关联报价单场景
	ContractTemplateVersion    string            // 合同模板版本
	ContractFile               string            // 合同文件 ID
	ContractAttachment         string            // 合同附件 ID
	BizIdentifier              string            // 业务唯一标识
	CooperationStatus          int               // 协商状态
	PreCooperationStatus       int               // 前序协商状态
	ArchivedStatus             int               // 归档状态
	ActiveStatus               int               // 生效状态
	IsBackdating               int               // 是否倒签
	IsMainContract             int               // 是否主合同
	IsNewest                   int               // 是否为最新版本
	IsDeleted                  int               // 是否被删除
	Status                     int               // 合同状态
	CurVersionFrom             string            // cur_version_from
	ValidityChangeDetail       string            // 有效期变更详情
	Remark                     string            // 备注
	Ext                        map[string]string // 合同附加信息 传入则更新 不传不更新
	RealTimeExt                map[string]string // 基于合同入参拆分的合同附加信息，需要处理历史信息，若变更后某一信息变更时，需要删除对应参数

	// 后续移动到 BasicInfo 内的参数
	CrmKey                string // crm_key
	RelatedPersonnel      string // related_personnel
	OfacUrl               string // ofac_url
	OpenChatId            string // open_chat_id
	BizData               string // biz_data
	SettlementClause      string // settlement_clause
	IsContainRefundClause string // is_contain_refund_clause

	// 后续会删除的字段
	RequestId      string // request_id
	CheckCode      string // check_code
	ContractId     string // contract_id
	FileIdSigned   string // file_id_signed
	FileIdUnsigned string // file_id_unsigned
	BizAccountId   int    // biz_account_id
	FinanceSubject string // finance_subject

	// 非入参 拼接参数
	ProductList       string // 合同商品列表
	Finance           string // 财务审核人
	SubjectName       string // 我方主体名称
	OtherPartyName    string // 对方主体名称
	SubjectAccountIds string // 合同关联 ID
	SealAccountIDs    string // 签约账号
	PricingAccountIDs string // 配价账号

	ExclusiveAccountInfo *ExclusiveAccountDisplayInfo `json:"-"` // 专属收款账号运行期缓存，仅用于模板替换链路
}

func (f *ContractFullData) GetDiffParam(p *ContractFullData) {

}

type ExclusiveAccountDisplayInfo struct {
	Valid         bool
	AccountNumber string
	BranchName    string
	ClctName      string
	SwiftCode     string
	BankAddress   string
}

type ConverFullContractPrepareParam struct {
	ManageInfo      *ManageInfo
	TradePartyInfo  *TradePartyInfo
	BasicInfo       *BasicInfo
	ReverseSignInfo *ReverseSignInfo
	TemplateInfo    *TemplateInfo
	ExtMap          map[string]string
	DelKeys         []string
	// MetaDB          *model.ContractMetaDB
}

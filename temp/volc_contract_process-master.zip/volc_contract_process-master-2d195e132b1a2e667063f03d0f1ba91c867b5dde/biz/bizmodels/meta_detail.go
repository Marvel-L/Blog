package bizmodels

import (
	"errors"
	"time"

	"code.byted.org/gopkg/context"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
)

// MetaDetailParam 合同详情查询
type MetaDetailParam struct {
	SourceType      _const.SourceType
	IsManager       bool   `json:"IsManager" query:"IsManager"`
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"`
	ContractNo      string `json:"ContractNo" query:"ContractNo"`
	Version         int    `json:"ContractVersion" query:"ContractVersion" default:"-1"`
}

type ContractMetaInfo struct {
	ContractName               string                    `json:"ContractName"`         // 火山合同名称
	ContractNo                 string                    `json:"ContractNo"`           // 火山合同号
	Version                    int                       `json:"Version"`              // 合同版本
	MainContractNo             string                    `json:"MainContractNo"`       // 主合同号
	FromContractNo             string                    `json:"FromContractNo"`       // 原合同号
	VolcContractNo             string                    `json:"VolcContractNo"`       // 火山补充合同号
	SupplyScene                int                       `json:"SupplyScene"`          // 补充协议类型
	SupplySource               string                    `json:"SupplySource"`         // 补充协议场景
	BizScene                   int                       `json:"BizScene"`             // 业务场景
	CooperationStatus          int                       `json:"CooperationStatus"`    // 协作状态
	PreCooperationStatus       int                       `json:"PreCooperationStatus"` // 前序协商状态
	Status                     int                       `json:"Status"`               // 合同状态
	ArchivedStatus             int                       `json:"ArchivedStatus"`       // 归档状态
	ActiveStatus               int                       `json:"ActiveStatus"`         // 生效状态
	BizSource                  int                       `json:"BizSource"`            // 业务来源
	Initiator                  int                       `json:"Initiator"`            // 发起端
	CategoryNo                 string                    `json:"CategoryNo"`           // 合同类型
	TemplateType               *int                      `json:"TemplateType"`         // 合同类型
	PropertyCode               string                    `json:"PropertyCode"`         // 合同性质
	InOutType                  string                    `json:"InOutType"`            // 收支类型
	IsBackdating               int                       `json:"IsBackdating"`         // 是否为补充协议
	IsUrgent                   int                       `json:"IsUrgent"`             // 是否加急
	OtherPartyName             string                    `json:"OtherPartyName"`       // 交易对方名称
	Product                    string                    `json:"Product"`              // 合同关联产品列表
	Finance                    string                    `json:"Finance"`              // 财务
	SubjectName                string                    `json:"SubjectName"`          // 我方主体名称
	SubjectNo                  string                    `json:"SubjectNo"`            // 我方主体编码
	FinanceSubject             string                    `json:"FinanceSubject"`       // 财务主体
	MetaCommonInfo             *MetaCommonInfo           `json:"MetaCommonInfo"`       // 通用信息
	BasicInfo                  *BasicInfo                `json:"BasicInfo"`            // 基本信息
	ProjectInfo                *ProjectInfo              `json:"ProjectInfo"`          // 项目信息
	ManageInfo                 *ManageInfo               `json:"ManageInfo"`           // 管理信息
	TradePartyInfo             *TradePartyInfo           `json:"TradePartyInfo"`       // 交易方信息
	ReverseSignInfo            *ReverseSignInfo          `json:"ReverseSignInfo"`      // 倒签信息
	SettlementInfo             *SettlementInfo           `json:"SettlementInfo"`       // 结算信息
	BusinessModeClauses        []*BusinessModeClause     `json:"BusinessModeClauses"`  // 商务模式条款摘要
	TemplateInfo               *TemplateInfo             `json:"TemplateInfo"`         // 模板信息
	UrgentInfo                 *UrgentInfo               `json:"UrgentInfo"`           // 加急信息
	ExpireRemindInfo           *ExpireRemindInfo         `json:"ExpireRemindInfo"`
	ContractAttachments        []*MetaAttachment         `json:"ContractAttachments"`             // 合同附件
	ContractFiles              []*MetaAttachment         `json:"ContractFiles"`                   // 合同文件
	ContractID                 string                    `json:"ContractID"`                      // 集团合同ID
	CooperationNodeList        []*CooperationNode        `json:"CooperationNodeList,omitempty"`   // 协商节点信息
	CooperationInfo            *CooperationInfo          `json:"CooperationInfo"`                 // 协商信息
	CooperationRecordList      []*CooperationRecord      `json:"CooperationRecordList,omitempty"` // 协商记录
	CommonOpRecordList         CommonOperationRecordList `json:"CommonOpRecordList,omitempty"`    // 操作记录
	RiskClauseList             []*RiskClauseRole         `json:"RiskClauseList,omitempty"`        // 风险条款
	ListRiskClauseRole         []*RiskClauseRoleVO       `json:"ListRiskClauseRole,omitempty"`    // 风险条款(新)
	UserInfoList               *UserInfoList             `json:"UserInfoList,omitempty"`          // 关联用户people信息
	BizIdentifier              string                    `json:"BizIdentifier"`                   // 业务唯一标识
	TemplateKey                string                    `json:"TemplateKey"`                     // 模板key
	TemplateVersion            int                       `json:"TemplateVersion"`                 // 模板版本
	BizData                    BizData                   `json:"BizData,omitempty"`               // 业务数据
	ViewURL                    string                    `json:"ViewURL,omitempty"`               // 合同详情链接
	AccountID                  string                    `json:"AccountID"`                       // 合同关联账号列表
	SealAccountIDs             string                    `json:"SealAccountIDs"`                  // 合同签约账号列表
	PricingAccountIDs          string                    `json:"PricingAccountIDs"`               // 合同配价账号列表
	CRMKey                     string                    `json:"CRMKey"`                          // CRM 唯一Key
	AccountInfoList            []*AccountInfo            `json:"AccountInfoList"`                 // 账号信息
	ValidityBegin              time.Time                 `json:"ValidityBegin"`                   // 合同有效期开始时间
	ValidityEnd                time.Time                 `json:"ValidityEnd"`                     // 合同有效期结束时间
	FileTime                   time.Time                 `json:"FileTime"`                        // 归档时间
	ValidityBeginStr           string                    `json:"ValidityBeginStr"`                // 合同有效期开始时间
	ValidityEndStr             string                    `json:"ValidityEndStr"`                  // 合同有效期结束时间
	OpenChatID                 string                    `json:"OpenChatID"`                      // 群聊ID
	RelateQuoteNo              string                    `json:"RelateQuoteNo"`                   // 关联报价单
	RelateQuoteScene           int                       `json:"RelateQuoteScene"`                // 关联报价单场景
	ValidityChangeDetail       string                    `json:"ValidityChangeDetail"`            // 有效期变更详情
	ContractPriceRepeatInfo    string                    `json:"ContractPriceRepeatInfo"`         // 合同价格重复信息
	ContractPriceCreatedTime   time.Time                 `json:"ContractPriceCreatedTime"`        // 合同价格创建时间
	FromContractTerminatedTime time.Time                 `json:"FromContractTerminatedTime"`      // 原合同终止日期
	QuoteItemOfflineInfo       string                    `json:"QuoteItemOfflineInfo"`            // 报价条目下架信息
	SupplementInfoList         *SupplementInfoList       `json:"SupplementInfoList"`              // 补充协议
	IsMainContract             bool                      `json:"IsMainContract"`                  // 是否为主合同
	IsShowSupplyWin            bool                      `json:"IsShowSupplyWin"`                 // 是否展示补充协议列表
	FromContractStartTime      string                    `json:"FromContractStartTime"`           // 原合同有效期开始时间
	FromContractEndTime        string                    `json:"FromContractEndTime"`             // 原合同有效期结束时间
	MainContractStartTime      string                    `json:"MainContractStartTime"`           // 主合同有效期开始时间
	MainContractEndTime        string                    `json:"MainContractEndTime"`             // 主合同有效期结束时间
	Ext                        map[string]string         `json:"Ext"`                             // 合同附加信息字段
	PerformFlag                int                       `json:"PerformFlag"`                     // 是否同步履约
	ExpireRemindFlag           int                       `json:"ExpireRemindFlag"`                // 是否到期提醒
	SpecialContractType        string                    `json:"SpecialContractType"`             // 特殊合同类型
	Operator                   string                    `json:"Operator"`                        // 操作人
	BizAccountID               int64                     `json:"BizAccountID"`                    // 业务账号ID
	ID                         string                    `json:"ID"`                              // 合同meta表主键ID
}

type ContractMetaSimpleInfo struct {
	ID                   string          `json:"ID"`                        // 合同meta表主键ID
	ContractName         string          `json:"ContractName"`              // 火山合同名称
	ContractNo           string          `json:"ContractNo"`                // 火山合同号
	Version              int             `json:"Version"`                   // 合同版本
	MainContractNo       string          `json:"MainContractNo"`            // 主合同号
	FromContractNo       string          `json:"FromContractNo"`            // 原合同号
	VolcContractNo       string          `json:"VolcContractNo"`            // 火山补充
	Initiator            int             `json:"Initiator"`                 // 发起端
	Creator              *UserInfo       `json:"Creator"`                   // 创建人
	Operator             *UserInfo       `json:"Operator"`                  // 操作人
	SupplyScene          int             `json:"SupplyScene"`               // 补充协议类型
	SupplySource         string          `json:"SupplySource"`              // 补充协议场景
	BizScene             int             `json:"BizScene"`                  // 业务场景
	BizSource            int             `json:"BizSource"`                 // 业务来源
	BizIdentifier        string          `json:"BizIdentifier"`             // 业务唯一标识
	CooperationStatus    int             `json:"CooperationStatus"`         // 协作状态
	PreCooperationStatus int             `json:"PreCooperationStatus"`      // 前序协商状态
	ActiveStatus         int             `json:"ActiveStatus"`              // 生效状态
	ArchivedStatus       int             `json:"ArchivedStatus"`            // 归档状态
	Status               int             `json:"Status"`                    // 合同状态
	CategoryNo           string          `json:"CategoryNo"`                // 合同类型
	TemplateType         *int            `json:"TemplateType"`              // 模板类型
	PropertyCode         string          `json:"PropertyCode"`              // 合同性质
	InOutType            string          `json:"InOutType"`                 // 收支类型
	SubjectNo            string          `json:"SubjectNo"`                 // 我方主体编码
	SubjectName          string          `json:"SubjectName"`               // 我方主体名称
	OtherPartyName       string          `json:"OtherPartyName"`            // 交易对方名称
	Product              string          `json:"Product"`                   // 合同关联产品列表
	Finance              string          `json:"Finance"`                   // 财务
	FinanceSubject       string          `json:"FinanceSubject"`            // 财务主体
	AccountID            string          `json:"AccountID"`                 // 合同关联账号列表
	SealAccountIDs       string          `json:"SealAccountIDs"`            // 合同签约账号列表
	PricingAccountIDs    string          `json:"PricingAccountIDs"`         // 合同配价账号列表
	ContractAttachment   string          `json:"ContractAttachment"`        // 合同附件
	ContractFile         string          `json:"ContractFile"`              // 合同文本、扫描件
	SpecialContractType  string          `json:"SpecialContractType"`       // 特殊合同类型
	RelateQuoteNo        string          `json:"RelateQuoteNo"`             // 关联报价单
	ValidityBegin        time.Time       `json:"ValidityBegin"`             // 合同有效期开始时间
	ValidityEnd          time.Time       `json:"ValidityEnd"`               // 合同有效期结束时间
	SubmitTime           string          `json:"SubmitTime"`                // 提交时间
	VersionCreatedTime   string          `json:"VersionCreatedTime"`        // 版本创建时间
	SignTime             string          `json:"SignTime"`                  // 签约时间
	FileTime             string          `json:"FileTime"`                  // 归档时间
	FinishTime           string          `json:"FinishTime"`                // 截止日期
	FinalStateType       int             `json:"FinalStateType"`            // 终态类型
	CreditApplyType      string          `json:"CreditApplyType,omitempty"` // 信控类型
	CreditApplyLine      string          `json:"CreditApplyLine,omitempty"` // 信控额度
	BasicInfo            *BasicInfo      `json:"BasicInfo"`                 // 基本信息
	TradePartyInfo       *TradePartyInfo `json:"TradePartyInfo"`            // 交易方信息
	CreatedTime          string          `json:"CreatedTime"`               // 创建时间
}

type CooperationInfo struct {
	Role                int               // 合同详情接口无此字段
	CanApproval         bool              // 是否允许审批
	CurrentReviewSource int               // 是否主审核人 迁移逻辑
	OnlineContract      string            // cn开头的文本ID
	NeedCreateGroupChat bool              // db.OpenChatID == ""
	ApprovalInfo        *ApprovalInfo     // 审批相关
	RequireQuoteInfo    *RequireQuoteInfo // 报价单相关 变更&弹窗
}

type ApprovalInfo struct {
	Reviewer             []*AuditorInfo // 审批人员列表
	CanAcquireReviewer   bool           // 是否显示“分配给我”（通过代码填入的字段）
	WillReplaceReviewers []string       // “分配给我”会抢的审核人员（通过代码填入的字段）
}

type RequireQuoteInfo struct {
	RequireQuote             bool   // 是否需要关联报价单 ret.CalcRequireQuote()
	RelateQuoteChangedNotify bool   // 报价单发生变更，当前用户是否需要弹窗 迁移逻辑
	RelateQuoteChanged       bool   // 报价单发生变更 迁移逻辑
	RelateQuoteChangedBefore string // 变更前报价单 迁移逻辑
}

type SupplementInfoList struct {
	VolcHistory []*SupplyInfo
	OAHistory   []*SupplyInfo
}

type MetaCommonInfo struct {
	Creator            int64  `json:"Creator"`                   // 创建人 工号
	Operator           int64  `json:"Operator"`                  // 操作人
	CreatedTime        string `json:"CreatedTime"`               // 创建时间
	SubmitTime         string `json:"SubmitTime"`                // 提交时间
	VersionCreatedTime string `json:"VersionCreatedTime"`        // 版本创建时间
	SignTime           string `json:"SignTime"`                  // 签约时间
	FileTime           string `json:"FileTime"`                  // 归档时间
	FinishTime         string `json:"FinishTime"`                // 截止日期
	CheckCode          string `json:"CheckCode"`                 // 校验码
	BizIdentifier      string `json:"BizIdentifier"`             // 业务唯一标识
	CreditApplyType    string `json:"CreditApplyType,omitempty"` // 信控类型
	CreditApplyLine    string `json:"CreditApplyLine,omitempty"` // 信控额度
	FinalStateType     int    `json:"FinalStateType"`            // 终态类型
}

type UserInfoList struct {
	Employees []*UserInfo `json:"Employees,omitempty"`
}

type UserInfo struct {
	ID        int    `json:"id"`         // 工号
	Name      string `json:"name"`       // 姓名
	Email     string `json:"email"`      // 邮箱
	AvatarURL string `json:"avatar_url"` // 头像
}

// MetaBizDetailParam 业务合同场景查询详情
type MetaBizDetailParam struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` //
	IsManager       bool   `json:"IsManager" query:"IsManager"`
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 业务合同编号
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` // 业务合同版本，前期忽略
	AccountID       int64  `json:"AccountID" query:"AccountID"`             // 账号ID
}

// MetaDetailReq 业务合同场景查询详情
type MetaDetailReq struct {
	CurrentOperator string `json:"CurrentOperator" query:"CurrentOperator"` //
	IsManager       bool   `json:"IsManager" query:"IsManager"`
	BizScene        int    `json:"BizScene" query:"BizScene"`               // 业务场景
	BizIdentifier   string `json:"BizIdentifier" query:"BizIdentifier"`     // 业务唯一标识
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           // 业务合同编号
	ContractVersion *int   `json:"ContractVersion" query:"ContractVersion"` // 业务合同版本，前期忽略
	AccountID       int64  `json:"AccountID" query:"AccountID"`             // 账号ID
}

func (m *MetaDetailReq) Validate() error {
	if m.BizScene == _const.ScenePayOnBehalf {
		// 代付场景，必须指定账号和合同号
		if m.ContractNo == "" || m.AccountID == 0 {
			return i18nfmt.New(context.Background(), "参数缺失[ContractNo/AccountID]")
		}
		return nil
	}
	if len(m.ContractNo) > 0 {
		return nil
	}
	if m.BizScene == 0 || len(m.BizIdentifier) == 0 {
		return errors.New(i18nfmt.Sprintf(context.Background(), "%s为空", "biz_scene|biz_identifier"))
	}
	return nil
}

func (m *MetaBizDetailParam) Validate() error {
	if m.BizScene == _const.ScenePayOnBehalf {
		// 代付场景，必须指定账号和合同号
		if m.ContractNo == "" || m.AccountID == 0 {
			return i18nfmt.New(context.Background(), "参数缺失[ContractNo/AccountID]")
		}
		return nil
	}
	if len(m.ContractNo) > 0 {
		return nil
	}
	if m.BizScene == 0 || len(m.BizIdentifier) == 0 {
		return errors.New(i18nfmt.Sprintf(context.Background(), "%s为空", "biz_scene|biz_identifier"))
	}
	return nil
}

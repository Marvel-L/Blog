package bizmodels

type SubjectMetaMQData struct {
	SubjectCode  string `json:"SubjectCode"`  // 变更的主体编码 "3423"
	BusinessType string `json:"businessType"` // 变更类型"insert/update/delete"
	UpdatedTime  string `json:"UpdatedTime"`  // 变更时间 rtf3339时间格式 "2025-03-05T12:12:12"
}

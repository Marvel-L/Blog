package modelsupply

type IsMeetSupplyConditionResp struct {
	SupportSupply    bool
	SupplyConditions []string
}

package modelcommodity

import (
	"time"

	"volc_contract_process/biz/bizmodels"
	_const "volc_contract_process/pkg/const"
)

type CheckInProcessCommodityRepeatReq struct {
	SourceType      _const.SourceType
	ContractNo      string
	CurrentOperator string
	AccountID       string
	BizSource       int
	ProductList     []*bizmodels.ProductInfo
	ValidityBegin   time.Time
	ValidityEnd     time.Time
	QuoteNo         string
}

type RepeatCommodityListData struct {
	RepeatList bizmodels.ContractDiscountList
	Err        error
}

type CheckCommodityListData struct {
	AccountID string
	Resp      *CheckQuoteItemRepeatResp
	Err       error
}

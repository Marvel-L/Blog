package modelcommodity

import (
	"errors"
)

type GetManageReq struct {
	CurrentOperator string `query:"CurrentOperator"` // 当前操作人
	ContractNo      string `query:"ContractNo"`      // 合同号
	NeedCommodity   bool   `query:"NeedCommodity"`   // 是否需要返回商品行信息
}

func (q *GetManageReq) Validate() error {
	if len(q.ContractNo) == 0 {
		return errors.New("ContractNo is empty.")
	}

	return nil
}

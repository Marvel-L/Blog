package modelcommodity

type HasQuoteRelateContractResp struct {
	Related             bool                  `json:"Related"`
	RelatedContractList []*RelateContractInfo `json:"RelatedContractList"`
}

type RelateContractInfo struct {
	ContractNo   string `json:"ContractNo"`
	Version      int    `json:"Version"`
	ContractName string `json:"ContractName"`
}

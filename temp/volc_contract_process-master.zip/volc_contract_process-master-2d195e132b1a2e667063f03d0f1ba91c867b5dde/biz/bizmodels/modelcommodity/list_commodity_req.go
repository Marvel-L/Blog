package modelcommodity

import (
	"errors"

	"volc_contract_process/biz/bizmodels"
)

type ListCommodityReq struct {
	CurrentOperator             string   `query:"CurrentOperator"`                                                // 当前操作人
	ContractNo                  string   `query:"ContractNo"`                                                     // 合同号
	TradeProductName            string   `query:"TradeProductName"`                                               // 商品名称
	TradeProductNameList        []string `query:"TradeProductNameList"`                                           // 商品名称多选
	TradeProductCode            string   `query:"TradeProductCode"`                                               // 商品Code
	TradeProductCodeList        string   `query:"TradeProductCodeList"`                                           // 商品Code
	TradeProduct                string   `query:"TradeProduct"`                                                   // 商品英文名
	TradeProductList            string   `query:"TradeProductList"`                                               // 商品英文名list
	Limit                       int      `json:"Limit" query:"Limit" default:"10"`                                //
	Offset                      int      `json:"Offset" query:"Offset"`                                           //
	NeedTotal                   bool     `json:"NeedTotal"`                                                       // 是否需要查询总量count
	NeedDeduplicateProduct      bool     `json:"NeedDeduplicateProduct" query:"NeedDeduplicateProduct"`           // 是否按商品去重
	NeedInvoiceValidateSnapshot bool     `json:"NeedInvoiceValidateSnapshot" query:"NeedInvoiceValidateSnapshot"` // 是否补充开票项校验快照
	Extra                       string   `json:"Extra" query:"Extra"`
}

type CommodityListParam struct {
	CurrentOperator      string   `json:"CurrentOperator"` // 当前操作人
	ContractNo           string   `json:"ContractNo"`      // 合同号
	VolcContractId       int      `json:"VolcContractId" query:"VolcContractId"`
	VolcContractIdList   []int    `json:"VolcContractIdList" query:"VolcContractIdList"`
	TradeProductName     string   `json:"TradeProductName"`                 // 商品名称
	TradeProductNameList []string `json:"TradeProductNameList"`             // 商品名称多选
	TradeProductCode     string   `query:"TradeProductCode"`                // 商品Code
	TradeProductCodeList string   `query:"TradeProductCodeList"`            // 商品Code
	TradeProduct         string   `query:"TradeProduct"`                    // 商品英文名
	TradeProductList     string   `query:"TradeProductList"`                // 商品英文名list
	StartId              uint64   `json:"StartId"`                          // 记录起始ID
	Limit                int      `json:"Limit" query:"Limit" default:"10"` //
	Offset               int      `json:"Offset" query:"Offset"`            //
	NeedTotal            bool     `json:"NeedTotal"`                        // 是否需要查询总量count
	Extra                string   `json:"Extra" query:"Extra"`
}

type CommodityListResp struct {
	Map    map[string][]*bizmodels.ProductInfo `json:"List"`
	Total  int                                 `json:"Total"`
	Limit  int                                 `json:"Limit"`
	Offset int                                 `json:"Offset"`
}

func (q *ListCommodityReq) Validate() error {
	if len(q.ContractNo) == 0 {
		return errors.New("ContractNo is empty.")
	}

	return nil
}

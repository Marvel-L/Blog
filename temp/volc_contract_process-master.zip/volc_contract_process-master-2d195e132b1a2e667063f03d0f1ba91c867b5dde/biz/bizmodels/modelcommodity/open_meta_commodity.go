package modelcommodity

import "volc_contract_process/biz/bizmodels"

type OpenMetaListForInvoiceProjectResp struct {
	List []*MetaContractInfo //
}

type MetaContractInfo struct {
	ContractNo  string //
	Version     int    //
	ContractURL string //
}

type GetInvoiceByContractAndProductReq struct {
	ContractNo      string `json:"ContractNo" query:"ContractNo"`           //
	ContractVersion int    `json:"ContractVersion" query:"ContractVersion"` //
	Product         string `json:"Product" query:"Product"`                 // 商品code
}

type GetInvoiceByContractAndProductResp struct {
	IncomeCode         string
	InvoiceProjectCode string //
	TradeProduct       string //
	TaxRatio           string //
}

type GetInvoiceByContractReq struct {
	ContractNo string `json:"ContractNo" query:"ContractNo"` //
}

type GetInvoiceByContractResp map[string]*GetInvoiceByContractAndProductResp

type UpdateManageInfoReq struct {
	ContractNo string                `json:"ContractNo" query:"ContractNo"` //
	ManageInfo *bizmodels.ManageInfo `json:"ManageInfo" query:"ManageInfo"`
}

type GetManageInfoReq struct {
	ContractNo    string `json:"ContractNo" query:"ContractNo"`       //
	NeedCommodity bool   `json:"NeedCommodity" query:"NeedCommodity"` //
}

package modelcommodity

import (
	"strings"
	"time"

	"code.byted.org/gopkg/context"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type CheckContractQuoteItemRepeatReq struct {
	SourceType      _const.SourceType
	CurrentOperator string
	ContractNo      string
	QuoteNo         string
}

func (r *CheckContractQuoteItemRepeatReq) Validate() errors.APIError {
	if len(r.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	return nil
}

type PreCheckCreateContractPriceReq struct {
	CurrentOperator    string
	ContractNo         string
	FromContractNo     string
	ContractName       string
	Operator           string
	SubjectName        string
	ParentContractNo   string
	QuoteScene         int
	SupplyScene        int
	QuoteNo            string
	AccountIDs         []string
	BizSource          int
	ValidityBegin      time.Time
	ValidityEnd        time.Time
	ProductList        []*bizmodels.ProductInfo
	SkipContractNoList []string
	IsProject          string
	ManageInfo         *bizmodels.ManageInfo
	BasicInfo          *bizmodels.BasicInfo
	TradePartyInfo     *bizmodels.TradePartyInfo
}

type PreCheckCreateContractPriceReqResp struct {
	Success bool
	Msg     string
}

type CheckQuoteItemRepeatReq struct {
	SourceType         _const.SourceType
	CurrentOperator    string
	ContractNo         string
	AccountIDs         []string
	OwnerID            string
	BizSource          int
	QuoteNo            string
	ProductList        []*bizmodels.ProductInfo
	SkipContractNoList []string
	ValidityBegin      time.Time
	ValidityEnd        time.Time
	IsProject          string
}

func (r *CheckQuoteItemRepeatReq) Validate() errors.APIError {
	if len(r.ContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	if len(r.AccountIDs) == 0 {
		return errors.ErrMissingParam.WithArgs("AccountIDs")
	}
	if r.BizSource == 0 {
		return errors.ErrMissingParam.WithArgs("BizSource")
	}
	if len(r.QuoteNo) == 0 {
		return errors.ErrMissingParam.WithArgs("QuoteNo")
	}
	if len(r.ProductList) == 0 {
		return errors.ErrMissingParam.WithArgs("ProductList")
	}
	if r.ValidityBegin.IsZero() {
		return errors.ErrMissingParam.WithArgs("ValidityBegin")
	}
	if r.ValidityEnd.IsZero() {
		return errors.ErrMissingParam.WithArgs("ValidityEnd")
	}
	if len(r.IsProject) == 0 {
		return errors.ErrMissingParam.WithArgs("IsProject")
	}

	return nil
}

func (r *CheckQuoteItemRepeatReq) GenCheckInProcessCommodityRepeatReq() *CheckInProcessCommodityRepeatReq {
	return &CheckInProcessCommodityRepeatReq{
		ContractNo:      r.ContractNo,
		SourceType:      r.SourceType,
		CurrentOperator: r.CurrentOperator,
		BizSource:       r.BizSource,
		ProductList:     r.ProductList,
		ValidityBegin:   r.ValidityBegin,
		ValidityEnd:     r.ValidityEnd,
		QuoteNo:         r.QuoteNo,
	}
}

type CheckQuoteItemRepeatResp struct {
	Repeat     bool
	Msg        string
	RepeatInfo []*bizmodels.ContractDiscountGroup
}

type CheckQuoteItemRepeatData struct {
	Repeat                  bool
	ContractPriceRepeatMsg  map[string]string
	CommodityRepeatMsg      map[string]string
	ContractPriceRepeatInfo map[string][]*bizmodels.ContractDiscountGroup
	CommodityRepeatInfo     map[string][]*bizmodels.ContractDiscountGroup
}

func (c *CheckQuoteItemRepeatData) GenFailStr(ctx context.Context) string {
	var contractPriceRepeat []string
	for _, msg := range c.ContractPriceRepeatMsg {
		contractPriceRepeat = append(contractPriceRepeat, msg)
	}
	var commodityRepeat []string
	for _, msg := range c.CommodityRepeatMsg {
		commodityRepeat = append(commodityRepeat, msg)
	}
	return i18nfmt.Sprintf(ctx, "存在如下合同价重复信息：\n %s 存在如下报价项重复信息：\n %s",
		strings.Join(contractPriceRepeat, "\n"), strings.Join(commodityRepeat, "\n"))
}

func (c *CheckQuoteItemRepeatData) GetCommodityRepeatContractNo() []string {
	contractNoMap := map[string]struct{}{}
	for _, commodityMap := range c.CommodityRepeatInfo {
		for _, commodityData := range commodityMap {
			for _, previous := range commodityData.PreviousList {
				contractNoMap[previous.ContractNo] = struct{}{}
			}
		}
	}
	var res []string
	for contractNo := range contractNoMap {
		res = append(res, contractNo)
	}
	return res
}

func (c *CheckQuoteItemRepeatData) GetCommodityRepeatMsgMap(ctx context.Context, quoteNo string) map[string]map[string]string {
	// 合同号-账号-重复项
	resMap := map[string]map[string]bizmodels.ContractDiscountList{}
	for accountId, commodityMap := range c.CommodityRepeatInfo {
		for _, commodityData := range commodityMap {
			for _, previous := range commodityData.PreviousList {
				// 是否存在
				repeatMap, ok := resMap[previous.ContractNo]
				if !ok {
					repeatMap = map[string]bizmodels.ContractDiscountList{}
					resMap[previous.ContractNo] = repeatMap
				}
				repeatList, ok := repeatMap[accountId]
				if !ok {
					repeatList = make([]*bizmodels.ContractDiscount, 0)
				}
				repeatList = append(repeatList, previous)
				repeatMap[accountId] = repeatList
			}
		}
	}
	res := map[string]map[string]string{}
	for contractNo, repeatMap := range resMap {
		repeat := map[string]string{}
		for accountId, repeatList := range repeatMap {
			repeat[accountId] = repeatList.GenRepeatProductMsg(ctx, quoteNo)
		}
		res[contractNo] = repeat
	}
	return res
}

package modelcommodity

import (
	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/pkg/errors"
)

type EditExternalCommodityListReq struct {
	ContractNo     string                            `json:"ContractNo" vd:"$!='';msg:'ContractNo is required'"`
	CommodityList  bizmodels.ExternalProductInfoList `json:"CommodityList"`
	IsSplitProduct bool                              `json:"IsSplitProduct"`
}

func (r *EditExternalCommodityListReq) Validate() errors.APIError {
	if r.ContractNo == "" {
		return errors.ErrMissingParam.WithArgs("ContractNo")
	}
	// if r.IsSplitProduct {
	// 	if len(r.CommodityList) == 0 {
	// 		return errors.ErrMissingParam.WithArgs("CommodityList")
	// 	}
	// 	return r.CommodityList.Validate()
	// }
	return nil
}

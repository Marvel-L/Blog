package modelcommodity

import (
	"fmt"
	"testing"

	"volc_contract_process/biz/bizmodels"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
)

func Test_EditExternalCommodityListReq_Validate_BitsUTGen(t *testing.T) {
	t.Run("合同号为空返回缺失参数错误", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 合同号为空，期望返回缺失参数错误
			req := &EditExternalCommodityListReq{
				ContractNo:    "",
				CommodityList: bizmodels.ExternalProductInfoList{&bizmodels.ExternalProductInfo{RelateQuoteItemID: "ID1", GroupID: 1}},
			}
			err := req.Validate()
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "ContractNo")
		})
	})

	// t.Run("仅当IsSplitProduct为true且商品列表为空时返回缺失参数错误", func(t *testing.T) {
	// 	mockey.PatchConvey("", t, func() {
	// 		// Case 1: IsSplitProduct = true, CommodityList = nil -> Expect Error
	// 		req1 := &EditExternalCommodityListReq{
	// 			ContractNo:     "C001",
	// 			CommodityList:  nil,
	// 			IsSplitProduct: true,
	// 		}
	// 		err1 := req1.Validate()
	// 		convey.So(err1, convey.ShouldNotBeNil)
	// 		convey.So(fmt.Sprintf("%v", err1.GetArgs()), convey.ShouldContainSubstring, "CommodityList")
	//
	// 		// Case 2: IsSplitProduct = false, CommodityList = nil -> Expect Nil
	// 		req2 := &EditExternalCommodityListReq{
	// 			ContractNo:     "C001",
	// 			CommodityList:  nil,
	// 			IsSplitProduct: false,
	// 		}
	// 		err2 := req2.Validate()
	// 		convey.So(err2, convey.ShouldBeNil)
	// 	})
	// })
	//
	// t.Run("当IsSplitProduct为true时校验商品列表内条目", func(t *testing.T) {
	// 	mockey.PatchConvey("", t, func() {
	// 		// Case 1: IsSplitProduct = true, Invalid Commodity -> Expect Error
	// 		req := &EditExternalCommodityListReq{
	// 			ContractNo: "C002",
	// 			CommodityList: bizmodels.ExternalProductInfoList{
	// 				&bizmodels.ExternalProductInfo{RelateQuoteItemID: "", GroupID: 1},
	// 			},
	// 			IsSplitProduct: true,
	// 		}
	// 		err := req.Validate()
	// 		convey.So(err, convey.ShouldNotBeNil)
	// 		convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "ExternalCommodity.RelateQuoteItemID")
	// 	})
	// })
	//
	// t.Run("商品列表内条目GroupID为0返回错误", func(t *testing.T) {
	// 	mockey.PatchConvey("", t, func() {
	// 		// 商品条目GroupID为0，期望返回对应缺失参数错误
	// 		req := &EditExternalCommodityListReq{
	// 			ContractNo: "C003",
	// 			CommodityList: bizmodels.ExternalProductInfoList{
	// 				&bizmodels.ExternalProductInfo{RelateQuoteItemID: "ID2", GroupID: 0},
	// 			},
	// 			IsSplitProduct: true,
	// 		}
	// 		err := req.Validate()
	// 		convey.So(err, convey.ShouldNotBeNil)
	// 		convey.So(fmt.Sprintf("%v", err.GetArgs()), convey.ShouldContainSubstring, "ExternalCommodity.GroupID")
	// 	})
	// })

	t.Run("商品列表合法时返回nil", func(t *testing.T) {
		mockey.PatchConvey("", t, func() {
			// 商品列表合法，期望返回nil
			req := &EditExternalCommodityListReq{
				ContractNo: "C004",
				CommodityList: bizmodels.ExternalProductInfoList{
					&bizmodels.ExternalProductInfo{RelateQuoteItemID: "ID3", GroupID: 1},
					&bizmodels.ExternalProductInfo{RelateQuoteItemID: "ID4", GroupID: 2},
				},
				IsSplitProduct: true,
			}
			err := req.Validate()
			convey.So(err, convey.ShouldBeNil)
		})
	})
}

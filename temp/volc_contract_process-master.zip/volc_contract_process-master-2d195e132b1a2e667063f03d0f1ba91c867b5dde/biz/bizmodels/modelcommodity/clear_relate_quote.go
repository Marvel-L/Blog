package modelcommodity

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type ClearRelateQuoteReq struct {
	SourceType       _const.SourceType
	CurrentOperator  string
	OriginContractNo string
	OperatorEmail    string
	RepeatMsgMap     map[string]map[string]string // 合同号-账号-重复信息
}

func (r *ClearRelateQuoteReq) Validate() errors.APIError {
	if len(r.OperatorEmail) == 0 {
		return errors.ErrMissingParam.WithArgs("OperatorEmail")
	}
	if len(r.OriginContractNo) == 0 {
		return errors.ErrMissingParam.WithArgs("OriginContractNo")
	}
	if len(r.RepeatMsgMap) == 0 {
		return errors.ErrMissingParam.WithArgs("RepeatMsgMap")
	}
	return nil
}

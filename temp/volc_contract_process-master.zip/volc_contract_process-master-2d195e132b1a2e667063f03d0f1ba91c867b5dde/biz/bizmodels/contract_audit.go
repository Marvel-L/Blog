package bizmodels

import (
	_const "volc_contract_process/pkg/const"
)

// BizContractAuditParam 业务合同审批
type BizContractAuditParam struct {
	SourceType      _const.SourceType //
	CurrentOperator string            //
	ContractNo      string            // 合同号
	ContractVersion int               // 合同版本
	AccountID       int64             //
	Scene           int               // 场景
	Identifier      string            // 业务系统唯一标识
	Operation       int               // 操作
	CardNo          string            // 主数据认证使用
	DocumentType    string            // 主数据认证使用
	RegistCountry   string            // 注册国家地区 主数据认证使用
	RejectType      int               // 拒绝类型
	RejectReason    string            // 拒绝原因
	Remark          string            // 备注信息
}

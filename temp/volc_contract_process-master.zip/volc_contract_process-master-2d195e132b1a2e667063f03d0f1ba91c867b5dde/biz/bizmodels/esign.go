package bizmodels

import (
	"code.byted.org/gopkg/context"

	"volc_contract_process/biz/service/multienv/i18nfmt"
)

// ESignCallbackReq 参见文档 https://bytedance.feishu.cn/docs/doccnPnIE5OKavFWb4n2UMj6x3w
type ESignCallbackReq struct {
	EventType  string `json:"event_type"`  // 事件类型
	BizKey     string `json:"biz_key"`     // 业务编号 对应合同号
	StatusCode int    `json:"status_code"` // 6审批通过 5审批中 4新建 8已签订 9已取消
	EventTime  string `json:"event_time"`  // 事件发生时间 格式 2021-03-02 22:11:08
}

// ESignCallbackMsg 参见文档 https://bytedance.feishu.cn/docs/doccnPnIE5OKavFWb4n2UMj6x3w
type ESignCallbackMsg struct {
	EventType  string `json:"event_type"`  // 事件类型
	BizKey     string `json:"biz_key"`     // 业务编号 对应合同号
	CheckCode  string `json:"check_code"`  // 校验码
	Version    int    `json:"version"`     // 版本
	StatusCode int    `json:"status_code"` // 6审批通过 5审批中 4新建 8已签订 9已取消
	EventTime  string `json:"event_time"`  // 事件发生时间 格式 2021-03-02 22:11:08
}

func (m *ESignCallbackMsg) Convert() *ESignCallbackReq {
	return &ESignCallbackReq{
		EventType:  m.EventType,
		BizKey:     m.BizKey,
		EventTime:  m.EventTime,
		StatusCode: m.StatusCode,
	}
}

func (r *ESignCallbackReq) Validate(ctx context.Context) error {
	if len(r.BizKey) == 0 {
		return i18nfmt.New(ctx, "biz_key参数为空")
	}
	return nil
}

func (r *ESignCallbackReq) Convert() *ESignCallbackEvent {
	return &ESignCallbackEvent{
		EventType:  r.EventType,
		ContractNo: r.BizKey,
		StatusCode: r.StatusCode,
		EventTime:  r.EventTime,
	}
}

type ESignCallbackEvent struct {
	baseEventContext
	EventType  string `json:"event_type"`  // 事件类型
	ContractNo string `json:"contract_no"` // 业务编号 对应合同号
	StatusCode int    `json:"status_code"` // 6审批通过 5审批中 4新建 8已签订 9已取消
	EventTime  string `json:"event_time"`  // 事件发生时间 格式 2021-03-02 22:11:08
}

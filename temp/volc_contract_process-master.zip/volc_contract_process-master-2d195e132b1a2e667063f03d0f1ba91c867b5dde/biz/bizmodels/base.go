package bizmodels

const DBDateFormatTpl = "2006-01-02 15:04:05"

type baseEventContext struct {
}

func (b baseEventContext) EventExtInfoDummyFlag() {
}

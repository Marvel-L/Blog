package bizmodels

import (
	"testing"

	"volc_contract_process/pkg/errors"

	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
)

func Test_PublishCommentReq_Validate(t *testing.T) {
	PatchConvey("Test Validate with empty RelatedID", t, func() {
		req := &PublishCommentReq{
			RelatedID: "",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123"}},
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("RelatedID"))
	})

	PatchConvey("Test Validate with empty Sender", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123"}},
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("Sender"))
	})

	PatchConvey("Test Validate with valid RelatedID and Sender", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123"}},
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with invalid fileID", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"invalid_file_id"}},
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrInvalidParam.WithArgs("invalid fileID"))
	})

	PatchConvey("Test Validate with valid fileID starting with 'cn_file'", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123"}},
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with valid fileID starting with 'FID'", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"FID123"}},
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with multiple valid fileIDs", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123", "FID456"}},
		}
		err := req.Validate()
		So(err, ShouldBeNil)
	})

	PatchConvey("Test Validate with multiple fileIDs including invalid one", t, func() {
		req := &PublishCommentReq{
			RelatedID: "related123",
			Sender:    "user123",
			Content:   &RichTextInfo{ImageIdList: []string{"cn_file123", "invalid_file_id"}},
		}
		err := req.Validate()
		So(err, ShouldNotBeNil)
		So(err, ShouldResemble, errors.ErrInvalidParam.WithArgs("invalid fileID"))
	})
}

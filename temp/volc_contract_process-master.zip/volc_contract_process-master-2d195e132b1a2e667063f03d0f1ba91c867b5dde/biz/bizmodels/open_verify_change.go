package bizmodels

// AccountVerifyChangeCheck 账号实名认证变更响应
type AccountVerifyChangeCheck struct {
	Allow   bool                              `json:"Allow"`             // 是否允许变更
	Reasons []*AccountVerifyChangeCheckReason `json:"Reasons,omitempty"` // 不允许变更的原因列表
}

type AccountVerifyChangeCheckReason struct {
	Rule         string `json:"Rule"`         // 规则标识
	RuleDesc     string `json:"RuleDesc"`     // 规则描述
	Tips         string `json:"Tips"`         // 提示文案
	OperationURL string `json:"OperationURL"` // 恢复操作URL
}

// GetContractNoList 账号实名认证变更查询合同号列表响应
type GetContractNoList struct {
	SignedContractNoListTotal        int      // 已签约、且未过期合同号列表总数
	NonFinalStateContractNoListTotal int      // 非终态的合同号列表总数
	SignedContractNoList             []string // 已签约、且未过期合同号列表
	NonFinalStateContractNoList      []string // 非终态的合同号列表
}

package bizmodels

import (
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

type MdPartyExistParam struct {
	SourceType _const.SourceType //
	AccountID  int64             //
}

func (p *MdPartyExistParam) Validate() errors.APIError {
	if p.SourceType == _const.SourceTypeOpen && p.AccountID == 0 {
		return errors.ErrMissingParam.WithArgs("AccountID")
	}
	return nil
}

package bizmodels

type BizInfoMarket struct {
	baseBizInfo
	baseBizData
	HasMarketFee     bool   // 是否有市场费支持
	PayType          string // 对方支付/收款类型
	ClctName         string // 对方账户名称
	ApInfoId         string // 银行账号ID-主数据唯一编码
	AccountNumber    string // 对方银行账号
	BranchCode       string // 对方开户行编码
	BranchName       string // 对方开户行名称
	RelatedPersonnel string // 相关人员
	ContactName      string // 乙方联系人
	ContactEmail     string // 乙方邮箱
	ContactTel       string // 乙方电话
	ContactAddress   string // 乙方通信地址
	MarketFee        string // 市场推广费
	SignerName       string // 签约人姓名
	SignerPhone      string // 签约人手机号
	SignerEmail      string // 签约人邮箱
}

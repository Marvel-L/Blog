package bizmodels

// AuthInfo 授权信息 用于标识当前请求用户
type AuthInfo struct {
	CurrentOperator string // 当前操作人邮箱，内部系统使用
	AccountID       int64  // 客户ID，外部系统使用
}

type AuthInnerUserInfo struct {
	EmployeeID    int64  // 工号
	EmployeeName  string // 姓名
	EmployeeEmail string // 邮箱
}

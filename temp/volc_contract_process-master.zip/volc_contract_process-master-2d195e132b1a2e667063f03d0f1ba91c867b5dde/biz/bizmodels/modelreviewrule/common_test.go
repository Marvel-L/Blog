package modelreviewrule

import (
	"context"
	"fmt"
	"testing"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	errorsV2 "volc_contract_process/pkg/errors"
)

func TestAssigneePriorityItem_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestAssigneePriorityItem_Validate", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("场景1: 无效的分配优先级导致验证失败", func() {
			// 场景描述:
			// 构造数据: AssigneePriorityItem 的 AssigneePriority 设置为一个无效值 (e.g., 99).
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority(99) 返回 false.
			// 2. 逻辑进入第一个 if 分支, 准备返回错误.
			// 3. Mock i18nfmt.Sprintf 以格式化错误信息.
			// 4. 函数返回包含 "Unknown AssigneePriority" 的错误.
			v := &AssigneePriorityItem{
				AssigneePriority: 99,
			}

			mockey.Mock(_const.IsValidAssigneePriority).When(func(value int) bool {
				return value != 99
			}).Return(true).Build()

			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Unknown AssigneePriority: 99")
		})

		mockey.PatchConvey("场景2: 优先级为Primary但审批人列表为空导致验证失败", func() {
			// 场景描述:
			// 构造数据: AssigneePriorityItem 的 AssigneePriority 设置为 Primary, 但 Reviewers 列表为空.
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 检查到 v.AssigneePriority == _const.AssigneePriorityPrimary.
			// 3. 检查到 len(v.Reviewers) == 0.
			// 4. 函数返回 "Reviewers 审批人列表不能为空" 错误.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePriorityPrimary,
				Reviewers:        []*ReviewerRolesReviewer{},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Reviewers 审批人列表不能为空")
		})

		mockey.PatchConvey("场景3: 审批人列表中包含nil元素导致验证失败", func() {
			// 场景描述:
			// 构造数据: AssigneePriorityItem 的 Reviewers 列表中包含一个 nil 元素.
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 循环遍历 Reviewers 列表.
			// 3. 在索引为0处发现 reviewer == nil.
			// 4. Mock i18nfmt.Sprintf 以格式化错误信息.
			// 5. 函数返回 "Reviewers[0] Can not be empty" 错误.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePrioritySecondary,
				Reviewers:        []*ReviewerRolesReviewer{nil},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Reviewers[0] Can not be empty")
		})

		mockey.PatchConvey("场景4: 审批人自身验证失败导致整体验证失败", func() {
			// 场景描述:
			// 构造数据: Reviewers 列表中的一个 Reviewer 自身的 Validate 方法返回错误.
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 循环遍历 Reviewers 列表.
			// 3. 调用 reviewer.Validate(ctx) 返回一个错误.
			// 4. Mock i18nfmt.Sprintf 以格式化错误信息.
			// 5. 函数返回包含 reviewer 错误信息的错误.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePrioritySecondary,
				Reviewers: []*ReviewerRolesReviewer{
					{},
				},
			}
			mockErr := errorsV2.ErrorCommon
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()
			mockey.Mock((*ReviewerRolesReviewer).Validate).Return(mockErr).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ErrorCommon, message:")
		})

		mockey.PatchConvey("场景5: 优先级为Primary但审批人不是员工导致验证失败", func() {
			// 场景描述:
			// 构造数据: AssigneePriority 为 Primary, 但 Reviewer 不是一个员工 (IsEmployee 返回 false).
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 循环遍历 Reviewers 列表, reviewer.Validate(ctx) 返回 nil.
			// 3. 检查到 v.AssigneePriority == _const.AssigneePriorityPrimary.
			// 4. 调用 reviewer.IsEmployee() 返回 false.
			// 5. Mock i18nfmt.Sprintf 以格式化错误信息.
			// 6. 函数返回 "审批人必须指定 EmployeeEmail 或 EmployeeNumber" 错误.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePriorityPrimary,
				Reviewers: []*ReviewerRolesReviewer{
					{ChatToken: "some-token"},
				},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()
			mockey.Mock((*ReviewerRolesReviewer).Validate).Return(nil).Build()
			mockey.Mock((*ReviewerRolesReviewer).IsEmployee).Return(false).Build()
			mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
				return fmt.Sprintf(format, a...)
			}).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "审批人必须指定 EmployeeEmail 或 EmployeeNumber")
		})

		mockey.PatchConvey("场景6: 验证成功 - 优先级为Primary且所有审批人都是有效员工", func() {
			// 场景描述:
			// 构造数据: AssigneePriority 为 Primary, 所有 Reviewer 都是员工且自身验证通过.
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 循环遍历 Reviewers 列表.
			// 3. reviewer.Validate(ctx) 返回 nil.
			// 4. reviewer.IsEmployee() 返回 true.
			// 5. 循环正常结束, 函数返回 nil.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePriorityPrimary,
				Reviewers: []*ReviewerRolesReviewer{
					{EmployeeEmail: "test@example.com"},
				},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()
			mockey.Mock((*ReviewerRolesReviewer).Validate).Return(nil).Build()
			mockey.Mock((*ReviewerRolesReviewer).IsEmployee).Return(true).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景7: 验证成功 - 优先级为Secondary且审批人列表为空", func() {
			// 场景描述:
			// 构造数据: AssigneePriority 为 Secondary, Reviewers 列表为空.
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. len(v.Reviewers) == 0 的检查被跳过.
			// 3. for 循环不会执行.
			// 4. 函数返回 nil.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePrioritySecondary,
				Reviewers:        []*ReviewerRolesReviewer{},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景8: 验证成功 - 优先级为Secondary且相关人有效", func() {
			// 场景描述:
			// 构造数据: AssigneePriority 为 Secondary, Reviewer 是一个有效的非员工实体 (如飞书群).
			// 逻辑链路:
			// 1. 调用 _const.IsValidAssigneePriority 返回 true.
			// 2. 循环遍历 Reviewers 列表.
			// 3. reviewer.Validate(ctx) 返回 nil.
			// 4. IsEmployee() 的检查被跳过.
			// 5. 循环正常结束, 函数返回 nil.
			v := &AssigneePriorityItem{
				AssigneePriority: _const.AssigneePrioritySecondary,
				Reviewers: []*ReviewerRolesReviewer{
					{ChatToken: "some-token"},
				},
			}
			mockey.Mock(_const.IsValidAssigneePriority).Return(true).Build()
			mockey.Mock((*ReviewerRolesReviewer).Validate).Return(nil).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_ReviewerRolesItem_Validate_BitsUTGen(t *testing.T) {
	ctx := context.Background()

	mockey.PatchConvey("Test ReviewerRolesItem.Validate", t, func() {
		mockey.PatchConvey("成功场景-校验通过", func() {
			// 场景描述：
			// 构造数据：构造一个完整的、合法的 ReviewerRolesItem，包含一个主审批人和一个相关人。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 true。
			// 2. 构造 AssigneePriorities 列表，包含主审批人和相关人。
			// 3. Mock (*AssigneePriorityItem).Validate 对两个子项都返回 nil。
			// 4. 函数执行所有检查，均通过。
			// 5. 函数返回 nil。
			v := &ReviewerRolesItem{
				ReviewerRole: _const.ReviewerRoleSalesOp,
				AssigneePriorities: []*AssigneePriorityItem{
					{
						AssigneePriority: _const.AssigneePriorityPrimary,
						Reviewers: []*ReviewerRolesReviewer{
							{EmployeeEmail: "test1@example.com"},
						},
					},
					{
						AssigneePriority: _const.AssigneePrioritySecondary,
						Reviewers: []*ReviewerRolesReviewer{
							{EmployeeEmail: "test2@example.com"},
						},
					},
				},
			}

			mockey.Mock(_const.IsValidReviewerRole).Return(true).Build()
			mockey.Mock((*AssigneePriorityItem).Validate).Return(nil).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景-ReviewerRole无效", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRole 为无效值的 ReviewerRolesItem。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 false。
			// 2. 函数在第一个 if 判断处失败。
			// 3. Mock i18nfmt.Sprintf 返回指定的错误信息。
			// 4. 函数返回包含 "未知的 ReviewerRole" 的错误。
			v := &ReviewerRolesItem{
				ReviewerRole: 999, // Invalid role
			}
			expectedErrMsg := fmt.Sprintf("未知的 ReviewerRole: %d", v.ReviewerRole)

			mockey.Mock(_const.IsValidReviewerRole).Return(false).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
		})

		mockey.PatchConvey("失败场景-AssigneePriorities包含nil元素", func() {
			// 场景描述：
			// 构造数据：构造一个 AssigneePriorities 数组，其中第二个元素为 nil。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 true。
			// 2. 第一次循环，AssigneePriorityItem 有效，Mock (*AssigneePriorityItem).Validate 返回 nil。
			// 3. 第二次循环，发现元素为 nil，进入 if 分支。
			// 4. Mock i18nfmt.Sprintf 返回指定的错误信息。
			// 5. 函数返回包含 "Can not be empty" 的错误。
			v := &ReviewerRolesItem{
				ReviewerRole: _const.ReviewerRoleSalesOp,
				AssigneePriorities: []*AssigneePriorityItem{
					{AssigneePriority: _const.AssigneePriorityPrimary},
					nil, // Nil item
				},
			}
			expectedErrMsg := fmt.Sprintf("AssigneePriorities[%d] Can not be empty", 1)

			mockey.Mock(_const.IsValidReviewerRole).Return(true).Build()
			mockey.Mock((*AssigneePriorityItem).Validate).Return(nil).Build() // For the first valid item
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Can not be empty")
		})

		mockey.PatchConvey("失败场景-AssigneePriorities中存在重复的优先级", func() {
			// 场景描述：
			// 构造数据：构造一个 AssigneePriorities 数组，其中包含两个主审批人，导致优先级重复。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 true。
			// 2. 第一次循环，主审批人被记录到 set 中。Mock (*AssigneePriorityItem).Validate 返回 nil。
			// 3. 第二次循环，检测到优先级重复，进入 if 分支。
			// 4. Mock i18nfmt.Sprintf 返回指定的错误信息。
			// 5. 函数返回包含 "AssigneePriority Repeat" 的错误。
			v := &ReviewerRolesItem{
				ReviewerRole: _const.ReviewerRoleSalesOp,
				AssigneePriorities: []*AssigneePriorityItem{
					{AssigneePriority: _const.AssigneePriorityPrimary},
					{AssigneePriority: _const.AssigneePriorityPrimary}, // Duplicate
				},
			}
			expectedErrMsg := fmt.Sprintf("AssigneePriorities[1] AssigneePriority Repeat: %d", _const.AssigneePriorityPrimary)

			mockey.Mock(_const.IsValidReviewerRole).Return(true).Build()
			mockey.Mock((*AssigneePriorityItem).Validate).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "AssigneePriority Repeat")
		})

		mockey.PatchConvey("失败场景-子项AssigneePriorityItem校验失败", func() {
			// 场景描述：
			// 构造数据：构造一个合法的 ReviewerRolesItem 结构。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 true。
			// 2. Mock (*AssigneePriorityItem).Validate 返回一个自定义错误。
			// 3. for 循环中调用子项的 Validate 方法，捕获到错误。
			// 4. Mock i18nfmt.Sprintf 返回指定的错误信息。
			// 5. 函数返回包含子项错误信息的包装错误。
			v := &ReviewerRolesItem{
				ReviewerRole: _const.ReviewerRoleSalesOp,
				AssigneePriorities: []*AssigneePriorityItem{
					{AssigneePriority: _const.AssigneePriorityPrimary},
				},
			}
			childErr := errorsV2.ErrorCommon.WithArgs("child validation failed")
			expectedErrMsg := fmt.Sprintf("AssigneePriorities[0] %s", childErr.Error())

			mockey.Mock(_const.IsValidReviewerRole).Return(true).Build()
			mockey.Mock((*AssigneePriorityItem).Validate).Return(childErr).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "child validation failed")
		})

		mockey.PatchConvey("失败场景-缺少主审批人", func() {
			// 场景描述：
			// 构造数据：构造的 AssigneePriorities 中只包含相关人，没有主审批人。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewerRole 返回 true。
			// 2. Mock (*AssigneePriorityItem).Validate 返回 nil。
			// 3. for 循环正常完成。
			// 4. 循环结束后的 if 判断 `assigneePrioritySet` 中没有主审批人，条件成立。
			// 5. Mock i18nfmt.Sprintf 返回指定的错误信息。
			// 6. 函数返回包含 "Must Contain AssigneePriority" 的错误。
			v := &ReviewerRolesItem{
				ReviewerRole: _const.ReviewerRoleSalesOp,
				AssigneePriorities: []*AssigneePriorityItem{
					{AssigneePriority: _const.AssigneePrioritySecondary},
				},
			}
			expectedErrMsg := fmt.Sprintf("AssigneePriorities Must Contain AssigneePriority = %d", _const.AssigneePriorityPrimary)

			mockey.Mock(_const.IsValidReviewerRole).Return(true).Build()
			mockey.Mock((*AssigneePriorityItem).Validate).Return(nil).Build()
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Must Contain AssigneePriority")
		})
	})
}

func Test_ValidateRequestReviewerRoles_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("TestValidateRequestReviewerRoles", t, func() {
		ctx := context.Background()

		// Mock i18nfmt.Sprintf to make error messages predictable and verifiable
		mockey.Mock(i18nfmt.Sprintf).To(func(ctx context.Context, format string, a ...interface{}) string {
			return fmt.Sprintf(format, a...)
		}).Build()

		mockey.PatchConvey("Success Case: All roles are valid and present", func() {
			// 场景描述：
			// 传入的roles列表包含了所有必须的角色，没有重复，并且每个role自身的校验都通过。
			// 构造数据：
			// roles 包含所有_const.MustReviewerRoleList中定义的角色。
			// 逻辑链路：
			// 1. 遍历roles，每个role不为nil。
			// 2. Mock (*ReviewerRolesItem).Validate 返回 nil，表示校验通过。
			// 3. 检查重复，没有重复的角色。
			// 4. 所有roles都添加到roleSet中。
			// 5. 遍历_const.MustReviewerRoleList，所有角色都在roleSet中找到。
			// 6. 函数最终返回nil，表示校验成功。
			roles := []*ReviewerRolesItem{
				{ReviewerRole: _const.ReviewerRoleSalesOp},
				{ReviewerRole: _const.ReviewerRoleFinanceAR},
				{ReviewerRole: _const.ReviewerRoleFinanceBP},
				{ReviewerRole: _const.ReviewerRoleTaxBP},
				{ReviewerRole: _const.ReviewerRoleLegalBP},
			}
			mockey.Mock((*ReviewerRolesItem).Validate).Return(nil).Build()

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("Failure Case: roles list contains a nil item", func() {
			// 场景描述：
			// 传入的roles列表中包含一个nil元素。
			// 构造数据：
			// roles 列表中的一个元素为 nil。
			// 逻辑链路：
			// 1. 遍历roles，当遇到nil元素时。
			// 2. `if role == nil` 条件成立。
			// 3. 函数返回 "ReviewerRoles[%d] Can not be empty" 错误。
			roles := []*ReviewerRolesItem{
				{ReviewerRole: _const.ReviewerRoleSalesOp},
				nil,
			}
			mockey.Mock((*ReviewerRolesItem).Validate).Return(nil).Build()

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ReviewerRoles[1] Can not be empty")
		})

		mockey.PatchConvey("Failure Case: an item in roles fails validation", func() {
			// 场景描述：
			// roles列表中的某个元素的Validate方法校验失败。
			// 构造数据：
			// roles 列表包含一个元素。
			// 逻辑链路：
			// 1. 遍历roles，第一个元素不为nil。
			// 2. Mock (*ReviewerRolesItem).Validate 返回一个自定义错误 "internal validation failed"。
			// 3. `if err1 != nil` 条件成立。
			// 4. 函数返回 "ReviewerRoles[0] internal validation failed" 错误。
			roles := []*ReviewerRolesItem{
				{ReviewerRole: _const.ReviewerRoleSalesOp},
			}
			validationErr := errorsV2.ErrorCommon.WithArgs("internal validation failed")
			mockey.Mock((*ReviewerRolesItem).Validate).Return(validationErr).Build()

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "ReviewerRoles[0] code: ErrorCommon, message: internal validation failed")
		})

		mockey.PatchConvey("Failure Case: duplicate reviewer role in roles list", func() {
			// 场景描述：
			// roles列表中存在重复的ReviewerRole。
			// 构造数据：
			// roles 包含两个ReviewerRolesItem，它们的ReviewerRole都是相同的。
			// 逻辑链路：
			// 1. 遍历roles，第一个元素校验通过，并被加入roleSet。
			// 2. 遍历到第二个元素，其ReviewerRole在roleSet中已存在。
			// 3. `if _, ok := roleSet[role.ReviewerRole]; ok` 条件成立。
			// 4. 函数返回 "ReviewerRole Repeat" 错误。
			roles := []*ReviewerRolesItem{
				{ReviewerRole: _const.ReviewerRoleSalesOp},
				{ReviewerRole: _const.ReviewerRoleFinanceAR},
				{ReviewerRole: _const.ReviewerRoleSalesOp},
			}
			mockey.Mock((*ReviewerRolesItem).Validate).Return(nil).Build()

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("ReviewerRoles[2] ReviewerRole Repeat: %d", _const.ReviewerRoleSalesOp))
		})

		mockey.PatchConvey("Failure Case: a mandatory reviewer role is missing", func() {
			// 场景描述：
			// roles列表中缺少了某个必须的角色。
			// 构造数据：
			// roles 列表缺少了_const.MustReviewerRoleList中的一个角色。
			// 逻辑链路：
			// 1. 第一个for循环正常结束，roleSet中缺少一个必须的角色。
			// 2. 第二个for循环遍历_const.MustReviewerRoleList。
			// 3. 当遍历到缺失的角色时，`if _, ok := roleSet[role]; !ok` 条件成立。
			// 4. 函数返回 "ReviewerRoles Lack ReviewerRole" 错误。
			roles := []*ReviewerRolesItem{
				{ReviewerRole: _const.ReviewerRoleSalesOp},
				{ReviewerRole: _const.ReviewerRoleFinanceAR},
				{ReviewerRole: _const.ReviewerRoleFinanceBP},
				{ReviewerRole: _const.ReviewerRoleTaxBP},
				// Missing ReviewerRoleLegalBP
			}
			mockey.Mock((*ReviewerRolesItem).Validate).Return(nil).Build()

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("ReviewerRoles Lack ReviewerRole: %d", _const.ReviewerRoleLegalBP))
		})

		mockey.PatchConvey("Edge Case: empty roles list", func() {
			// 场景描述：
			// 传入一个空的roles列表。
			// 构造数据：
			// roles 为一个空slice。
			// 逻辑链路：
			// 1. 第一个for循环直接跳过。
			// 2. 第二个for循环遍历_const.MustReviewerRoleList，第一个元素就不在roleSet中。
			// 3. 函数返回 "ReviewerRoles Lack ReviewerRole" 错误。
			roles := []*ReviewerRolesItem{}

			err := ValidateRequestReviewerRoles(ctx, roles)
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, fmt.Sprintf("ReviewerRoles Lack ReviewerRole: %d", _const.MustReviewerRoleList[0]))
		})
	})
}

func Test_ReviewerRolesReviewer_NotEmptyCount_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ReviewerRolesReviewer.NotEmptyCount", t, func() {
		mockey.PatchConvey("场景：所有计数字段均为空", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRolesReviewer 实例，其 ChatToken, OpenChatID, EmployeeEmail, EmployeeNumber 字段均为空字符串。其他无关字段有值。
			// 逻辑链路：调用 NotEmptyCount 方法，预期返回 0。
			v := &ReviewerRolesReviewer{
				EmployeeName:   "test_user", // 该字段不应计入
				ChatName:       "test_chat", // 该字段不应计入
				ChatToken:      "",
				OpenChatID:     "",
				EmployeeEmail:  "",
				EmployeeNumber: "",
			}

			result := v.NotEmptyCount()
			convey.So(result, convey.ShouldEqual, 0)
		})

		mockey.PatchConvey("场景：只有一个计数字段不为空 (ChatToken)", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRolesReviewer 实例，其 ChatToken 字段不为空，其他计数字段为空。
			// 逻辑链路：调用 NotEmptyCount 方法，预期返回 1。
			v := &ReviewerRolesReviewer{
				ChatToken: "some_token",
			}

			result := v.NotEmptyCount()
			convey.So(result, convey.ShouldEqual, 1)
		})

		mockey.PatchConvey("场景：有两个计数字段不为空 (OpenChatID, EmployeeEmail)", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRolesReviewer 实例，其 OpenChatID 和 EmployeeEmail 字段不为空，其他计数字段为空。
			// 逻辑链路：调用 NotEmptyCount 方法，预期返回 2。
			v := &ReviewerRolesReviewer{
				OpenChatID:    "some_id",
				EmployeeEmail: "test@example.com",
			}

			result := v.NotEmptyCount()
			convey.So(result, convey.ShouldEqual, 2)
		})

		mockey.PatchConvey("场景：有三个计数字段不为空 (ChatToken, OpenChatID, EmployeeNumber)", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRolesReviewer 实例，其 ChatToken, OpenChatID, EmployeeNumber 字段不为空，其他计数字段为空。
			// 逻辑链路：调用 NotEmptyCount 方法，预期返回 3。
			v := &ReviewerRolesReviewer{
				ChatToken:      "some_token",
				OpenChatID:     "some_id",
				EmployeeNumber: "123456",
			}

			result := v.NotEmptyCount()
			convey.So(result, convey.ShouldEqual, 3)
		})

		mockey.PatchConvey("场景：所有四个计数字段都不为空", func() {
			// 场景描述：
			// 构造数据：构造一个 ReviewerRolesReviewer 实例，其 ChatToken, OpenChatID, EmployeeEmail, EmployeeNumber 字段均不为空。
			// 逻辑链路：调用 NotEmptyCount 方法，预期返回 4。
			v := &ReviewerRolesReviewer{
				ChatToken:      "some_token",
				OpenChatID:     "some_id",
				EmployeeEmail:  "test@example.com",
				EmployeeNumber: "123456",
			}

			result := v.NotEmptyCount()
			convey.So(result, convey.ShouldEqual, 4)
		})
	})
}

func Test_ListReviewRuleReq_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_ListReviewRuleReq_Validate", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("成功场景 - Status为空字符串", func() {
			// 场景描述：
			// 构造数据：ListReviewRuleReq 的 Status 字段为空字符串。
			// 逻辑链路：
			// 1. utils.SplitInt 将空字符串分割为空的整数切片，不返回错误。
			// 2. for 循环不会执行。
			// 3. 函数返回 nil，表示验证通过。
			v := &ListReviewRuleReq{
				Status: "",
			}

			// 调用目标函数
			err := v.Validate(ctx)

			// 断言结果为 nil
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("成功场景 - Status为合法的逗号分隔数字", func() {
			// 场景描述：
			// 构造数据：ListReviewRuleReq 的 Status 字段为 "1,2"，所有状态码都是有效的。
			// 逻辑链路：
			// 1. utils.SplitInt 将字符串 "1,2" 分割为整数切片 []int{1, 2}。
			// 2. 循环遍历切片中的每个状态码。
			// 3. 所有状态码都在 _const.ReviewRuleStatusNameMap 中存在。
			// 4. 函数返回 nil，表示验证通过。
			v := &ListReviewRuleReq{
				Status: "1,2",
			}

			// 调用目标函数
			err := v.Validate(ctx)

			// 断言结果为 nil
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("失败场景 - Status包含非数字字符", func() {
			// 场景描述：
			// 构造数据：ListReviewRuleReq 的 Status 字段为 "1,a"，包含非数字字符。
			// 逻辑链路：
			// 1. utils.SplitInt 尝试转换 "a" 为整数时失败，返回错误。
			// 2. 函数捕获到错误，并返回一个带有特定消息 "Status 必须为英文逗号分隔的数字" 的 APIError。
			v := &ListReviewRuleReq{
				Status: "1,a",
			}

			// 调用目标函数
			err := v.Validate(ctx)

			// 断言返回了错误，并且错误信息符合预期
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Status 必须为英文逗号分隔的数字")
		})

		mockey.PatchConvey("失败场景 - Status包含未知的状态码", func() {
			// 场景描述：
			// 构造数据：ListReviewRuleReq 的 Status 字段为 "1,99"，其中 99 是一个未定义的状态码。
			// 逻辑链路：
			// 1. utils.SplitInt 成功将字符串分割为整数切片 []int{1, 99}。
			// 2. 循环检查状态码，当检查到 99 时，在 _const.ReviewRuleStatusNameMap 中找不到。
			// 3. 调用 i18nfmt.Sprintf 生成国际化错误信息。
			// 4. 函数返回一个包含该错误信息的 APIError。
			v := &ListReviewRuleReq{
				Status: "1,99",
			}
			// Mock i18nfmt.Sprintf 以返回一个固定的错误信息，便于断言
			mockey.Mock(i18nfmt.Sprintf).Return("Status[1] 未知的 Status: 99").Build()

			// 调用目标函数
			err := v.Validate(ctx)

			// 断言返回了错误，并且错误信息符合预期
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "Status[1] 未知的 Status: 99")
		})
	})
}

func Test_ReviewerRolesReviewer_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ReviewerRolesReviewer.Validate", t, func() {
		// 构造通用测试数据
		ctx := context.Background()
		v := &ReviewerRolesReviewer{}

		mockey.PatchConvey("场景一: 当 NotEmptyCount 返回 0 时，应返回'所有字段都为空'错误", func() {
			// 场景描述：
			// 模拟一个空的 ReviewerRolesReviewer 实例进行校验。
			// 逻辑链路：
			// 1. Mock (*ReviewerRolesReviewer).NotEmptyCount 方法，使其返回 0。
			// 2. 调用 Validate 方法。
			// 3. 预期进入 notEmptyCount == 0 的分支，返回包含 "所有字段都为空" 的错误信息。
			mockey.Mock((*ReviewerRolesReviewer).NotEmptyCount).Return(0).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "所有字段都为空")
		})

		mockey.PatchConvey("场景二: 当 NotEmptyCount 返回大于 1 的值时，应返回'只能提供最多 1 个字段'错误", func() {
			// 场景描述：
			// 模拟一个包含多个非空字段的 ReviewerRolesReviewer 实例进行校验。
			// 逻辑链路：
			// 1. Mock (*ReviewerRolesReviewer).NotEmptyCount 方法，使其返回一个大于1的数字，例如2。
			// 2. 调用 Validate 方法。
			// 3. 预期进入 notEmptyCount != 1 的分支，返回包含 "只能提供最多 1 个字段" 的错误信息。
			mockey.Mock((*ReviewerRolesReviewer).NotEmptyCount).Return(2).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "只能提供最多 1 个字段")
		})

		mockey.PatchConvey("场景三: 当 NotEmptyCount 返回 1 时，校验通过，应返回 nil", func() {
			// 场景描述：
			// 模拟一个只包含一个非空字段的 ReviewerRolesReviewer 实例进行校验。
			// 逻辑链路：
			// 1. Mock (*ReviewerRolesReviewer).NotEmptyCount 方法，使其返回 1。
			// 2. 调用 Validate 方法。
			// 3. 预期跳过所有错误检查分支，函数正常返回。
			mockey.Mock((*ReviewerRolesReviewer).NotEmptyCount).Return(1).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_CreateOrUpdateReviewRuleReq_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_CreateOrUpdateReviewRuleReq_Validate", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("success", func() {
			// 场景描述：
			// 构造数据：请求体v的SalesDepartment字段不为空，ReviewerRoles字段不为nil。
			// 逻辑链路：
			// 1. SalesDepartment字段校验通过。
			// 2. Mock ValidateRequestReviewerRoles函数返回nil。
			// 3. 目标函数Validate返回nil。

			// 准备数据
			v := &CreateOrUpdateReviewRuleReq{
				SalesDepartment: "Valid Sales Department",
				ReviewerRoles:   []*ReviewerRolesItem{},
			}

			// Mock
			mockey.Mock(ValidateRequestReviewerRoles).Return(nil).Build()

			// 调用
			err := v.Validate(ctx)

			// 断言
			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("fail - SalesDepartment is empty", func() {
			// 场景描述：
			// 构造数据：请求体v的SalesDepartment字段为空字符串。
			// 逻辑链路：
			// 1. SalesDepartment字段校验失败，函数直接返回错误。
			// 2. 目标函数Validate返回包含"SalesDepartment 不能为空"信息的错误。

			// 准备数据
			v := &CreateOrUpdateReviewRuleReq{
				SalesDepartment: "",
			}

			// 调用
			err := v.Validate(ctx)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "SalesDepartment 不能为空")
		})

		mockey.PatchConvey("fail - ValidateRequestReviewerRoles returns error", func() {
			// 场景描述：
			// 构造数据：请求体v的SalesDepartment字段不为空。
			// 逻辑链路：
			// 1. SalesDepartment字段校验通过。
			// 2. Mock ValidateRequestReviewerRoles函数返回一个自定义错误。
			// 3. 目标函数Validate返回该自定义错误。

			// 准备数据
			v := &CreateOrUpdateReviewRuleReq{
				SalesDepartment: "Valid Sales Department",
				ReviewerRoles:   []*ReviewerRolesItem{},
			}
			mockErr := errorsV2.ErrorCommon.WithArgs("mock ValidateRequestReviewerRoles error")

			// Mock
			mockey.Mock(ValidateRequestReviewerRoles).Return(mockErr).Build()

			// 调用
			err := v.Validate(ctx)

			// 断言
			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err, convey.ShouldEqual, mockErr)
		})
	})
}

func Test_GetReviewRuleDetailReq_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test GetReviewRuleDetailReq.Validate", t, func() {
		mockey.PatchConvey("场景: RuleID和SalesDepartment都为空，应返回错误", func() {
			// 场景描述:
			// 构造数据: 创建一个 GetReviewRuleDetailReq 实例，其中 RuleID 和 SalesDepartment 字段都为空字符串。
			// 逻辑链路:
			// 1. 调用 Validate 方法。
			// 2. 进入第一个 if 分支 (v.RuleID == "" && v.SalesDepartment == "")。
			// 3. 返回 "RuleID SalesDepartment 不能同时为空" 的错误。
			v := &GetReviewRuleDetailReq{
				RuleID:          "",
				SalesDepartment: "",
			}

			err := v.Validate(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RuleID SalesDepartment 不能同时为空")
		})

		mockey.PatchConvey("场景: RuleID和SalesDepartment都不为空，应返回错误", func() {
			// 场景描述:
			// 构造数据: 创建一个 GetReviewRuleDetailReq 实例，其中 RuleID 和 SalesDepartment 字段都不为空。
			// 逻辑链路:
			// 1. 调用 Validate 方法。
			// 2. 跳过第一个 if 分支。
			// 3. 进入第二个 if 分支 (v.RuleID != "" && v.SalesDepartment != "")。
			// 4. 返回 "RuleID SalesDepartment 只能填写其中 1 个" 的错误。
			v := &GetReviewRuleDetailReq{
				RuleID:          "test-rule-id",
				SalesDepartment: "test-department",
			}

			err := v.Validate(context.Background())

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, "RuleID SalesDepartment 只能填写其中 1 个")
		})

		mockey.PatchConvey("场景: 只提供RuleID，验证通过", func() {
			// 场景描述:
			// 构造数据: 创建一个 GetReviewRuleDetailReq 实例，其中 RuleID 字段有值，SalesDepartment 字段为空。
			// 逻辑链路:
			// 1. 调用 Validate 方法。
			// 2. 跳过第一个 if 分支。
			// 3. 跳过第二个 if 分支。
			// 4. 返回 nil，表示验证通过。
			v := &GetReviewRuleDetailReq{
				RuleID:          "test-rule-id",
				SalesDepartment: "",
			}

			err := v.Validate(context.Background())

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("场景: 只提供SalesDepartment，验证通过", func() {
			// 场景描述:
			// 构造数据: 创建一个 GetReviewRuleDetailReq 实例，其中 RuleID 字段为空，SalesDepartment 字段有值。
			// 逻辑链路:
			// 1. 调用 Validate 方法。
			// 2. 跳过第一个 if 分支。
			// 3. 跳过第二个 if 分支。
			// 4. 返回 nil，表示验证通过。
			v := &GetReviewRuleDetailReq{
				RuleID:          "",
				SalesDepartment: "test-department",
			}

			err := v.Validate(context.Background())

			convey.So(err, convey.ShouldBeNil)
		})
	})
}

func Test_UpdateReviewRuleStatusReq_Validate_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_UpdateReviewRuleStatusReq_Validate", t, func() {
		ctx := context.Background()

		mockey.PatchConvey("success case: status is valid", func() {
			// 场景描述：
			// 测试当传入的 Status 是有效状态时，校验应该通过。
			// 构造数据：
			// - v.Status 设置为有效的 _const.ReviewRuleStatusEnabled
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewRuleStatus 函数返回 true。
			// 2. 调用 v.Validate(ctx)。
			// 3. 函数应直接返回 nil，表示校验成功。
			v := &UpdateReviewRuleStatusReq{
				Status: _const.ReviewRuleStatusEnabled,
			}

			mockey.Mock(_const.IsValidReviewRuleStatus).When(func(status int) bool {
				return status == _const.ReviewRuleStatusEnabled
			}).Return(true).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldBeNil)
		})

		mockey.PatchConvey("failure case: status is invalid", func() {
			// 场景描述：
			// 测试当传入的 Status 是无效状态时，校验应该失败并返回错误。
			// 构造数据：
			// - v.Status 设置为一个无效值（例如 99）。
			// 逻辑链路：
			// 1. Mock _const.IsValidReviewRuleStatus 函数返回 false。
			// 2. 函数进入 if 分支，准备返回错误。
			// 3. Mock i18nfmt.Sprintf 函数，使其返回一个预期的错误信息字符串。
			// 4. 调用 v.Validate(ctx)。
			// 5. 函数应返回一个包含特定错误信息的 error。
			invalidStatus := 99
			v := &UpdateReviewRuleStatusReq{
				Status: invalidStatus,
			}

			mockey.Mock(_const.IsValidReviewRuleStatus).When(func(status int) bool {
				return status == invalidStatus
			}).Return(false).Build()

			expectedErrMsg := fmt.Sprintf("Unknown Status: %d", invalidStatus)
			mockey.Mock(i18nfmt.Sprintf).Return(expectedErrMsg).Build()

			err := v.Validate(ctx)

			convey.So(err, convey.ShouldNotBeNil)
			convey.So(err.Error(), convey.ShouldContainSubstring, expectedErrMsg)
		})
	})
}

func Test_ReviewerRolesReviewer_IsChat_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test ReviewerRolesReviewer.IsChat", t, func() {
		mockey.PatchConvey("should return true when ChatToken is not empty", func() {
			// 场景描述:
			// 构造数据: 创建一个ReviewerRolesReviewer实例，其中ChatToken字段为非空字符串，OpenChatID为空字符串。
			// 逻辑链路: 调用IsChat方法，方法内部检查 `v.ChatToken != ""` 为true，因此整个或表达式的结果为true。
			v := &ReviewerRolesReviewer{
				ChatToken:  "test_chat_token",
				OpenChatID: "",
			}

			// 调用
			isChat := v.IsChat()

			// 断言
			convey.So(isChat, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return true when OpenChatID is not empty", func() {
			// 场景描述:
			// 构造数据: 创建一个ReviewerRolesReviewer实例，其中ChatToken字段为空字符串，OpenChatID为非空字符串。
			// 逻辑链路: 调用IsChat方法，方法内部检查 `v.ChatToken != ""` 为false, 接着检查 `v.OpenChatID != ""` 为true，因此整个或表达式的结果为true。
			v := &ReviewerRolesReviewer{
				ChatToken:  "",
				OpenChatID: "test_open_chat_id",
			}

			// 调用
			isChat := v.IsChat()

			// 断言
			convey.So(isChat, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return true when both ChatToken and OpenChatID are not empty", func() {
			// 场景描述:
			// 构造数据: 创建一个ReviewerRolesReviewer实例，其中ChatToken和OpenChatID字段都为非空字符串。
			// 逻辑链路: 调用IsChat方法，方法内部检查 `v.ChatToken != ""` 为true，触发或表达式的短路逻辑，直接返回true。
			v := &ReviewerRolesReviewer{
				ChatToken:  "test_chat_token",
				OpenChatID: "test_open_chat_id",
			}

			// 调用
			isChat := v.IsChat()

			// 断言
			convey.So(isChat, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("should return false when both ChatToken and OpenChatID are empty", func() {
			// 场景描述:
			// 构造数据: 创建一个ReviewerRolesReviewer实例，其中ChatToken和OpenChatID字段都为空字符串。
			// 逻辑链路: 调用IsChat方法，方法内部检查 `v.ChatToken != ""` 为false, 接着检查 `v.OpenChatID != ""` 也为false，因此整个或表达式的结果为false。
			v := &ReviewerRolesReviewer{
				ChatToken:  "",
				OpenChatID: "",
			}

			// 调用
			isChat := v.IsChat()

			// 断言
			convey.So(isChat, convey.ShouldBeFalse)
		})
	})
}

func Test_ReviewerRolesReviewer_IsEmployee_BitsUTGen(t *testing.T) {
	mockey.PatchConvey("Test_ReviewerRolesReviewer_IsEmployee", t, func() {
		mockey.PatchConvey("场景1: 当EmployeeEmail和EmployeeNumber都非空时，应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个ReviewerRolesReviewer实例，其中EmployeeEmail和EmployeeNumber都有值。
			// 逻辑链路：函数判断 v.EmployeeEmail != "" (true) || v.EmployeeNumber != "" (true)，返回true。
			v := &ReviewerRolesReviewer{
				EmployeeEmail:  "test@example.com",
				EmployeeNumber: "12345",
			}

			// 调用
			result := v.IsEmployee()

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景2: 当只有EmployeeEmail非空时，应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个ReviewerRolesReviewer实例，其中只有EmployeeEmail有值。
			// 逻辑链路：函数判断 v.EmployeeEmail != "" (true) || v.EmployeeNumber != "" (false)，返回true。
			v := &ReviewerRolesReviewer{
				EmployeeEmail:  "test@example.com",
				EmployeeNumber: "",
			}

			// 调用
			result := v.IsEmployee()

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景3: 当只有EmployeeNumber非空时，应返回true", func() {
			// 场景描述：
			// 构造数据：创建一个ReviewerRolesReviewer实例，其中只有EmployeeNumber有值。
			// 逻辑链路：函数判断 v.EmployeeEmail != "" (false) || v.EmployeeNumber != "" (true)，返回true。
			v := &ReviewerRolesReviewer{
				EmployeeEmail:  "",
				EmployeeNumber: "12345",
			}

			// 调用
			result := v.IsEmployee()

			// 断言
			convey.So(result, convey.ShouldBeTrue)
		})

		mockey.PatchConvey("场景4: 当EmployeeEmail和EmployeeNumber都为空时，应返回false", func() {
			// 场景描述：
			// 构造数据：创建一个ReviewerRolesReviewer实例，其中EmployeeEmail和EmployeeNumber都为空字符串。
			// 逻辑链路：函数判断 v.EmployeeEmail != "" (false) || v.EmployeeNumber != "" (false)，返回false。
			v := &ReviewerRolesReviewer{
				EmployeeEmail:  "",
				EmployeeNumber: "",
			}

			// 调用
			result := v.IsEmployee()

			// 断言
			convey.So(result, convey.ShouldBeFalse)
		})
	})
}

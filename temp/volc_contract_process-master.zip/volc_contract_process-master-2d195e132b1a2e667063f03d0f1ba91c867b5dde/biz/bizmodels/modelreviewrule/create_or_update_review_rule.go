package modelreviewrule

type CreateOrUpdateReviewRuleReq struct {
	RuleID          string // 规则id
	SalesDepartment string // 销售归属行业(中文)(这个字段只能创建，不能更新)
	Remark          string // 备注说明
	ReviewerRoles   []*ReviewerRolesItem
	OperatorEmail   string `header:"X-Ee-Email"`
}

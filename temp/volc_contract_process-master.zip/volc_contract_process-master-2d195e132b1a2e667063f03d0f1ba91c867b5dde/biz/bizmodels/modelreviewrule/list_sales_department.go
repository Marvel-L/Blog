package modelreviewrule

type ListSalesDepartmentReq struct {
	ShowDisabled    bool
	SalesDepartment string // 模糊搜索
}

type ListSalesDepartmentResponse struct {
	List []string
}

type ListSalesDepartmentInfoResponse struct {
	List []*ReviewRuleInfo
}

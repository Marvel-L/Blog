package modelreviewrule

type GetReviewRuleDetailReq struct {
	RuleID          string // [2 选 1]规则 ID（优先使用 RuleID）
	SalesDepartment string // [2 选 1]销售所属行业(中文)（RuleID 为空字符串的话会使用 SalesDepartment 进行查找）
}

type GetReviewRuleDetailResponse struct {
	RuleID          string
	SalesDepartment string
	Remark          string
	ReviewerRoles   []*ReviewerRolesItem
	CreatorEmail    string
	UpdaterEmail    string
	CreatedTime     string
	UpdatedTime     string
	Status          int
}

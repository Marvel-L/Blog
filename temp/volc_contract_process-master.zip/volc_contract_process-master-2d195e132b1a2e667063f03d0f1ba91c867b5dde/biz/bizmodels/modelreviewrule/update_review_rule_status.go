package modelreviewrule

type UpdateReviewRuleStatusReq struct {
	RuleID        string
	Status        int
	OperatorEmail string `header:"X-Ee-Email"`
}

package modelreviewrule

type GetLarkChatInfoReq struct {
	LarkChatID string
}
type GetLarkChatInfoResponse struct {
	LarkChatID string
	OpenChatID string
	Name       string
	AvatarURL  string
}

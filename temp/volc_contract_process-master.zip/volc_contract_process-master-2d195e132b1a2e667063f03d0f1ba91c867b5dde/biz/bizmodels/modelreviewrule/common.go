package modelreviewrule

import (
	"context"

	"volc_contract_process/biz/service/multienv/i18nfmt"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	utils "volc_contract_process/pkg/util"
)

type ReviewRuleInfo struct {
	RuleID          string // 规则id
	SalesDepartment string // 销售所属行业(中文)
}

type ReviewerRolesItem struct {
	ReviewerRole       int // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP
	AssigneePriorities []*AssigneePriorityItem
}
type AssigneePriorityItem struct {
	AssigneePriority int                      // 分配优先级 1 审批人 2 相关人
	Reviewers        []*ReviewerRolesReviewer // 审批人或相关人
}
type ReviewerRolesReviewer struct {
	EmployeeEmail     string `json:",omitempty"`
	EmployeeName      string `json:",omitempty"`
	EmployeeNumber    string `json:",omitempty"`
	EmployeeAvatarURL string `json:",omitempty"` // 用户头像（10 分钟缓存）
	ChatToken         string `json:",omitempty"` // 飞书群 Token（如果用户输入的是 ChatToken，则 ChatToken 和 OpenChatID 都会有值。如果用户输入的是 OpenChatID 则 ChatToken 为空）
	OpenChatID        string `json:",omitempty"`
	ChatName          string `json:",omitempty"`
	ChatAvatarURL     string `json:",omitempty"` // 飞书群头像（永久缓存）
}

type CommonEnumItem struct {
	Key  int
	Name string
}

// region Validator

func (v *ListReviewRuleReq) Validate(ctx context.Context) errors.APIError {
	statusList, err := utils.SplitInt(v.Status, ",")
	if err != nil {
		return errors.ErrInternalError.WithArgs("Status 必须为英文逗号分隔的数字")
	}
	for i, status := range statusList {
		if _, ok := _const.ReviewRuleStatusNameMap[status]; !ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Status[%d] 未知的 Status: %d", i, status))
		}
	}
	return nil
}

func (v *ReviewerRolesReviewer) NotEmptyCount() int {
	notEmptyCount := 0
	if v.ChatToken != "" {
		notEmptyCount++
	}
	if v.OpenChatID != "" {
		notEmptyCount++
	}
	if v.EmployeeEmail != "" {
		notEmptyCount++
	}
	if v.EmployeeNumber != "" {
		notEmptyCount++
	}
	return notEmptyCount
}

func (v *ReviewerRolesReviewer) IsEmployee() bool {
	return v.EmployeeEmail != "" || v.EmployeeNumber != ""
}

func (v *ReviewerRolesReviewer) IsChat() bool {
	return v.ChatToken != "" || v.OpenChatID != ""
}

func (v *ReviewerRolesReviewer) Validate(ctx context.Context) errors.APIError {
	notEmptyCount := v.NotEmptyCount()
	if notEmptyCount == 0 {
		return errors.ErrInternalError.WithArgs("所有字段都为空")
	}
	if notEmptyCount != 1 {
		return errors.ErrInternalError.WithArgs("只能提供最多 1 个字段")
	}
	return nil
}

func (v *ReviewerRolesItem) Validate(ctx context.Context) errors.APIError {
	if !_const.IsValidReviewerRole(v.ReviewerRole) {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "未知的 ReviewerRole: %d", v.ReviewerRole))
	}
	assigneePrioritySet := map[int]struct{}{}
	for i, assigneePriority := range v.AssigneePriorities {
		if assigneePriority == nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "AssigneePriorities[%d] Can not be empty", i))
		}
		if _, ok := assigneePrioritySet[assigneePriority.AssigneePriority]; ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "AssigneePriorities[%d] AssigneePriority Repeat: %d", i, assigneePriority.AssigneePriority))
		}
		assigneePrioritySet[assigneePriority.AssigneePriority] = struct{}{}
		err1 := assigneePriority.Validate(ctx)
		if err1 != nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "AssigneePriorities[%d] %s", i, err1.Error()))
		}
	}
	if _, ok := assigneePrioritySet[_const.AssigneePriorityPrimary]; !ok {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "AssigneePriorities Must Contain AssigneePriority = %d", _const.AssigneePriorityPrimary))
	}
	return nil
}

func (v *AssigneePriorityItem) Validate(ctx context.Context) errors.APIError {
	if !_const.IsValidAssigneePriority(v.AssigneePriority) {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Unknown AssigneePriority: %d", v.AssigneePriority))
	}
	if v.AssigneePriority == _const.AssigneePriorityPrimary {
		if len(v.Reviewers) == 0 {
			return errors.ErrInternalError.WithArgs("Reviewers 审批人列表不能为空")
		}
	}
	for i, reviewer := range v.Reviewers {
		if reviewer == nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Reviewers[%d] Can not be empty", i))
		}
		err1 := reviewer.Validate(ctx)
		if err1 != nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Reviewers[%d] %v", i, err1.Error()))
		}
		if v.AssigneePriority == _const.AssigneePriorityPrimary {
			if !reviewer.IsEmployee() {
				return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Reviewers[%d] 审批人必须指定 EmployeeEmail 或 EmployeeNumber", i))
			}
		}
	}
	return nil
}

func ValidateRequestReviewerRoles(ctx context.Context, roles []*ReviewerRolesItem) errors.APIError {
	roleSet := map[int]struct{}{}
	for i, role := range roles {
		if role == nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "ReviewerRoles[%d] Can not be empty", i))
		}
		err1 := role.Validate(ctx)
		if err1 != nil {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "ReviewerRoles[%d] %v", i, err1.Error()))
		}
		if _, ok := roleSet[role.ReviewerRole]; ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "ReviewerRoles[%d] ReviewerRole Repeat: %d", i, role.ReviewerRole))
		}
		roleSet[role.ReviewerRole] = struct{}{}
	}
	for _, role := range _const.MustReviewerRoleList {
		if _, ok := roleSet[role]; !ok {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "ReviewerRoles Lack ReviewerRole: %d", role))
		}
	}
	return nil
}

func (v *CreateOrUpdateReviewRuleReq) Validate(ctx context.Context) errors.APIError {
	if v.SalesDepartment == "" {
		return errors.ErrInternalError.WithArgs("SalesDepartment 不能为空")
	}
	err1 := ValidateRequestReviewerRoles(ctx, v.ReviewerRoles)
	if err1 != nil {
		return err1
	}
	return nil
}

func (v *UpdateReviewRuleStatusReq) Validate(ctx context.Context) errors.APIError {
	if !_const.IsValidReviewRuleStatus(v.Status) {
		return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "Unknown Status: %d", v.Status))
	}
	return nil
}

func (v *GetReviewRuleDetailReq) Validate(ctx context.Context) errors.APIError {
	if v.RuleID == "" && v.SalesDepartment == "" {
		return errors.ErrInternalError.WithArgs("RuleID SalesDepartment 不能同时为空")
	}
	if v.RuleID != "" && v.SalesDepartment != "" {
		return errors.ErrInternalError.WithArgs("RuleID SalesDepartment 只能填写其中 1 个")
	}
	return nil
}

// endregion Validator

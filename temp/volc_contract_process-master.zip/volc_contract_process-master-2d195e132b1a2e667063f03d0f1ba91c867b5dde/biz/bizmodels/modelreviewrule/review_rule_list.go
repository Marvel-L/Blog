package modelreviewrule

type ReviewRuleListParams struct {
	SalesDepartment     string   `json:"SalesDepartment" query:"SalesDepartment"`
	SalesDepartmentList []string `json:"SalesDepartmentList" query:"SalesDepartmentList"`
	RuleIds             []string `json:"RuleIds" query:"RuleIds"`
	Status              []int    `json:"Status" query:"Status"`
	Limit               int      `json:"Limit" query:"Limit" default:"10"` //
	Offset              int      `json:"Offset" query:"Offset"`            //
	NeedTotal           bool     `json:"NeedTotal"`                        // 是否需要查询总量count
	Extra               string   `json:"Extra" query:"Extra"`
}

type ReviewRuleReviewerListParams struct {
	RuleIds       []string `json:"RuleIds" query:"RuleIds"`
	EmployeeEmail string   `json:"EmployeeEmail" query:"EmployeeEmail"`
	Limit         int      `json:"Limit" query:"Limit" default:"10"` //
	Offset        int      `json:"Offset" query:"Offset"`            //
	NeedTotal     bool     `json:"NeedTotal"`                        // 是否需要查询总量count
	Extra         string   `json:"Extra" query:"Extra"`
}

type ReviewRuleDAOListParams struct {
	SalesDepartment string
	Status          []int
	WithReviewers   bool
	NeedTotal       bool
	Limit           int
	Offset          int
}

type ListReviewRuleReq struct {
	SalesDepartment string // 销售归属行业(中文)(模糊搜索)(空字符串表示此项不过滤)
	Status          string // 状态(英文逗号分隔的数字)(空字符串表示此项不过滤) 1 启用 2 禁用
	Limit           int
	Offset          int
}

type ListReviewRuleResponse struct {
	List   []*ListReviewRuleListItem
	Total  int
	Offset int
}

type ListReviewRuleListItem struct {
	RuleID          string
	SalesDepartment string
	Remark          string
	CreatorEmail    string
	UpdaterEmail    string
	CreatedTime     string
	UpdatedTime     string
	Status          int
}

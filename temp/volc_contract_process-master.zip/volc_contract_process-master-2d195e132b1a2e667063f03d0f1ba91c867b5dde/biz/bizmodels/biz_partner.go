package bizmodels

import (
	"volc_contract_process/pkg/errors"
)

type BizInfoPartner struct {
	baseBizInfo
	baseBizData
	CompanyName              string                 `json:"CompanyName"`              // 伙伴公司名
	GrantType                string                 `json:"GrantType"`                // 授权类型：代理、经销、代理&经销
	GradingRegion            string                 `json:"GradingRegion"`            // 拓渠区域
	GrantTimeLimit           string                 `json:"GrantTimeLimit"`           // 授权期限
	RegistrationNumber       string                 `json:"RegistrationNumber"`       // 注册号
	BillingCountry           string                 `json:"BillingCountry"`           // Billing Country
	ContractTerm             string                 `json:"ContractTerm"`             // 合同期限
	Territory                string                 `json:"Territory"`                // Territory
	PartnerCreditList        []*PartnerCreditData   `json:"PartnerCreditList"`        // 授权信息
	DistributorGrantArea     string                 `json:"DistributorGrantArea"`     // 分销模式授权地区(分销类型必填)
	DistributorGrantProduct  string                 `json:"DistributorGrantProduct"`  // 分销模式授权产品(分销类型必填)
	DistributorGrantBusiness string                 `json:"DistributorGrantBusiness"` // 分销模式授权行业(分销类型必填)
	DistributorGrantLevel    string                 `json:"DistributorGrantLevel"`    // 分销模式授权等级(分销类型必填)
	DistributorGrantUnique   string                 `json:"DistributorGrantUnique"`   // 分销模式独家授权(分销类型必填)
	AgencyGrantArea          string                 `json:"AgencyGrantArea"`          // 代理模式授权地区(代理类型必填)
	AgencyGrantProduct       string                 `json:"AgencyGrantProduct"`       // 代理模式授权产品(代理类型必填)
	AgencyGrantBusiness      string                 `json:"AgencyGrantBusiness"`      // 代理模式授权行业(代理类型必填)
	AgencyGrantLevel         string                 `json:"AgencyGrantLevel"`         // 代理模式授权等级(代理类型必填)
	AgencyGrantUnique        string                 `json:"AgencyGrantUnique"`        // 代理模式独家授权(代理类型必填)
	BankName                 string                 `json:"BankName"`                 // 开户行名称L3
	BankNo                   string                 `json:"BankNo"`                   // 银行卡号L4数据，加密传输，存储
	BankCode                 string                 `json:"BankCode"`                 // 开户行编码L3
	SwiftCode                string                 `json:"SwiftCode"`                // Swift Code
	AnnualCommitment         string                 `json:"AnnualCommitment"`         // 年度保底消费
	PartnerTier              string                 `json:"PartnerTier"`              // 等级
	PartnerAddress           string                 `json:"PartnerAddress"`           // 伙伴注册地址(服务类型必填)
	ContactName              string                 `json:"ContactName"`              // 联系人(服务类型必填)
	ContactPhone             string                 `json:"ContactPhone"`             // 联系电话(服务类型必填)
	ContactEmail             string                 `json:"ContactEmail"`             // 电子邮箱(服务类型必填)
	ContactAddress           string                 `json:"ContactAddress"`           // 联系地址(服务类型必填)
	VolcContactName          string                 `json:"VolcContactName"`          // 火山联系人(服务类型必填)
	VolcContactPhone         string                 `json:"VolcContactPhone"`         // 火山联系电话(服务类型必填)
	VolcContactEmail         string                 `json:"VolcContactEmail"`         // 火山电子邮箱(服务类型必填)
	VolcContactAddress       string                 `json:"VolcContactAddress"`       // 火山联系地址(服务类型必填)
	VolcSolutionProductList  []*VolcSolutionProduct `json:"VolcSolutionProductList"`  // 解决方案产品列表(解决方案类型)。可以为空数组
}

type PartnerCreditData struct {
	GrantType             string // 授权类型：代理、经销、代理&经销
	GrantArea             string // 授权地区
	GrantProduct          string // 授权产品
	GrantBusiness         string // 授权行业
	GrantLevel            string // 授权等级
	GrantUnique           string // 独家授权
	GrantTimeLimit        string // 授权期限
	GrantTerminalCustomer string // 授权终端客户
	GrantTerminalProject  string // 授权项目
}

type VolcSolutionProduct struct {
	Order int
	Name  string
}

func (b *BizInfoPartner) Validate() errors.APIError {
	return nil
}

package bizmodels

import (
	"code.byted.org/gopkg/context"
	. "github.com/bytedance/mockey"
	. "github.com/smartystreets/goconvey/convey"
	"testing"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
)

func TestToolAddOtherPartyAccountReqValidate(t *testing.T) {
	t.Run("缺少ContractNo", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
				IsPricing:        intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("ContractNo"))
		})
	})

	t.Run("缺少PartyNumber", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
				IsPricing:        intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("PartyNumber"))
		})
	})

	t.Run("允许AccountID为空", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
				IsPricing:        intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})

	t.Run("允许SealAccountID为空", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
				IsPricing:        intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})

	t.Run("配价主体允许PricingAccountID为空", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:    "contract-1",
				PartyNumber:   "party-1",
				AccountID:     "account-1",
				SealAccountID: "seal-account-1",
				IsSealed:      intPtr(1),
				IsPricing:     intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})

	t.Run("缺少IsSealed", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsPricing:        intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("IsSealed"))
		})
	})

	t.Run("缺少IsPricing", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("IsPricing"))
		})
	})

	t.Run("标记副签约主体时缺少DeputyPartySource", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(1),
				IsPricing:        intPtr(0),
				IsDeputyParty:    true,
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrMissingParam.WithArgs("DeputyPartySource"))
		})
	})

	t.Run("标记副签约主体时DeputyPartySource枚举非法", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:        "contract-1",
				PartyNumber:       "party-1",
				AccountID:         "account-1",
				SealAccountID:     "seal-account-1",
				PricingAccountID:  "pricing-account-1",
				IsSealed:          intPtr(1),
				IsPricing:         intPtr(0),
				DeputyPartySource: 3,
				IsDeputyParty:     true,
			}

			err := req.Validate(context.Background())

			So(err, ShouldResemble, errors.ErrInvalidParam.WithArgs("DeputyPartySource"))
		})
	})

	t.Run("参数完整时允许通过", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:       "contract-1",
				PartyNumber:      "party-1",
				AccountID:        "account-1",
				SealAccountID:    "seal-account-1",
				PricingAccountID: "pricing-account-1",
				IsSealed:         intPtr(0),
				IsPricing:        intPtr(0),
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})

	t.Run("非配价主体允许PricingAccountID为空", func(t *testing.T) {
		PatchConvey("非配价主体允许PricingAccountID为空", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:    "contract-1",
				PartyNumber:   "party-1",
				AccountID:     "account-1",
				SealAccountID: "seal-account-1",
				IsSealed:      intPtr(0),
				IsPricing:     intPtr(0),
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})

	t.Run("标记副签约主体且来源合法时允许通过", func(t *testing.T) {
		PatchConvey("", t, func() {
			req := &ToolAddOtherPartyAccountReq{
				ContractNo:        "contract-1",
				PartyNumber:       "party-1",
				AccountID:         "account-1",
				SealAccountID:     "seal-account-1",
				PricingAccountID:  "pricing-account-1",
				IsSealed:          intPtr(1),
				IsPricing:         intPtr(0),
				DeputyPartySource: _const.SubPartySourceLarkSync,
				IsDeputyParty:     true,
			}

			err := req.Validate(context.Background())

			So(err, ShouldBeNil)
		})
	})
}

func intPtr(v int) *int {
	return &v
}

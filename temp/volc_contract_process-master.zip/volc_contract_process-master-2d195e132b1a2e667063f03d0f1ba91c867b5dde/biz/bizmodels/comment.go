package bizmodels

import (
	"strings"

	stringsV1 "code.byted.org/gopkg/lang/strings"

	"volc_contract_process/pkg/errors"
)

type Comment struct {
	ID              int64
	RelatedID       string
	CommentScene    int
	CommentID       string
	ParentCommentID string
	RichTextID      int64
	Content         *RichTextInfo
	Sender          string
	CreatedTime     int64
	UpdatedTime     int64
	Status          int
	SubCommentList  []*Comment
}

type ListCommentReq struct {
	CommentScene int
	RelatedID    string
	CommentID    string
}

type ListCommentResp struct {
	CommentList []*Comment
}

type PublishCommentReq struct {
	RelatedID       string
	CommentScene    int
	ParentCommentID string
	Content         *RichTextInfo
	Sender          string
}

func (p *PublishCommentReq) Validate() errors.APIError {
	if stringsV1.IsEmpty(p.RelatedID) {
		return errors.ErrMissingParam.WithArgs("RelatedID")
	}
	if stringsV1.IsEmpty(p.Sender) {
		return errors.ErrMissingParam.WithArgs("Sender")
	}
	for _, fileID := range p.Content.ImageIdList {
		if strings.HasPrefix(fileID, "cn_file") {
			continue
		} else if strings.HasPrefix(fileID, "FID") {
			continue
		} else {
			return errors.ErrInvalidParam.WithArgs("invalid fileID")
		}
	}
	return nil
}

type PublishCommentResp struct {
	CommentID string
}

type DeleteCommentReq struct {
	CommentID string
	Operator  string
}

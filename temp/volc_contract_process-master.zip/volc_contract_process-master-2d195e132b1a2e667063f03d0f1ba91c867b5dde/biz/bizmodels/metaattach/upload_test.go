package metaattach

import (
	"code.byted.org/gopkg/context"
	"fmt"
	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"
	"mime/multipart"
	"strings"
	"testing"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/tosc"
	"volc_contract_process/pkg/util"
)

func Test_Validate(t *testing.T) {
	mockey.PatchConvey("Test when FileName is missing", t, func() {
		p := &UploadReq{SourceType: _const.SourceTypeInner}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("FileName"))
	})
	mockey.PatchConvey("Test when CurrentOperator is missing for ContractAttachmentTypeFile", t, func() {
		p := &UploadReq{
			SourceType: _const.SourceTypeInner,
			BizType:    _const.ContractAttachmentTypeFile,
			FileName:   "valid.pdf",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("CurrentOperator"))
	})
	mockey.PatchConvey("Test when File is missing for ContractAttachmentTypeFile", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeFile,
			CurrentOperator: "operator",
			FileName:        "valid.pdf",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("File"))
	})
	mockey.PatchConvey("Test when FileExtension not support for ContractAttachmentTypeFile", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeFile,
			CurrentOperator: "operator",
			TosKey:          "bucket/valid.pdf",
			FileName:        "valid.xx",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrFileExtensionNotSupport.WithArgs(".xx"))
	})
	mockey.PatchConvey("Test success for ContractAttachmentTypeFile", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(true, nil).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeFile,
			CurrentOperator: "operator",
			TosKey:          "bucket/valid.pdf",
			FileName:        "valid.pdf",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test when TosKey file not exist for ContractAttachmentTypeFile", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(false, nil).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeFile,
			CurrentOperator: "operator",
			TosKey:          "bucket/missing.pdf",
			FileName:        "missing.pdf",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrFileNotExistFail.WithArgs("bucket/missing.pdf"))
	})
	mockey.PatchConvey("Test when checking TosKey fails for ContractAttachmentTypeFile", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(false, fmt.Errorf("head object failed")).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeFile,
			CurrentOperator: "operator",
			TosKey:          "bucket/valid.pdf",
			FileName:        "valid.pdf",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("head object failed"))
	})
	mockey.PatchConvey("Test when Sealed missing for ContractAttachmentTypeCommon", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeCommon,
			CurrentOperator: "operator",
			FileName:        "valid.pdf",
		}
		mockey.Mock(util.GetFileExtension).Return("txt").Build()
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("Sealed"))
	})
	mockey.PatchConvey("Test when Archived missing for ContractAttachmentTypeCommon", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeCommon,
			CurrentOperator: "operator",
			FileName:        "valid.pdf",
			Sealed:          "N",
		}
		mockey.Mock(util.GetFileExtension).Return("txt").Build()
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("Archived"))
	})
	mockey.PatchConvey("Test when File missing for ContractAttachmentTypeCommon", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeCommon,
			CurrentOperator: "operator",
			FileName:        "valid.pdf",
			Sealed:          "N",
			Archived:        "N",
		}
		mockey.Mock(util.GetFileExtension).Return("txt").Build()
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("File"))
	})
	mockey.PatchConvey("Test success for ContractAttachmentTypeCommon", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(true, nil).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeCommon,
			CurrentOperator: "operator",
			FileName:        "valid.pdf",
			Sealed:          "N",
			Archived:        "N",
			TosKey:          "bucket/valid.pdf",
		}
		mockey.Mock(util.GetFileExtension).Return("txt").Build()
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test when File is missing for ContractAttachmentTypeAIAuditFeedback", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeAIAuditFeedback,
			CurrentOperator: "operator",
			FileName:        "feedback.png",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("File"))
	})
	mockey.PatchConvey("Test when FileExtension not support for ContractAttachmentTypeAIAuditFeedback", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeAIAuditFeedback,
			CurrentOperator: "operator",
			FileName:        "feedback.txt",
			FileData:        []byte("feedback"),
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrFileExtensionNotSupport.WithArgs(".txt"))
	})
	mockey.PatchConvey("Test success for ContractAttachmentTypeAIAuditFeedback", t, func() {
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeAIAuditFeedback,
			CurrentOperator: "operator",
			FileName:        "feedback.png",
			FileData:        []byte("feedback"),
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test success with TosKey for ContractAttachmentTypeAIAuditFeedback", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(true, nil).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeAIAuditFeedback,
			CurrentOperator: "operator",
			FileName:        "feedback.png",
			TosKey:          "bucket/feedback.png",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test when TosKey file not exist for ContractAttachmentTypeAIAuditFeedback", t, func() {
		mockey.Mock(tosc.CheckObjectExistsWithError).Return(false, nil).Build()
		p := &UploadReq{
			SourceType:      _const.SourceTypeInner,
			BizType:         _const.ContractAttachmentTypeAIAuditFeedback,
			CurrentOperator: "operator",
			FileName:        "feedback.png",
			TosKey:          "bucket/missing-feedback.png",
		}
		err := p.Validate(context.Background())
		convey.So(err, convey.ShouldResemble, errors.ErrFileNotExistFail.WithArgs("bucket/missing-feedback.png"))
	})
}

func Test_ApplyUploadInfoReq_Validate(t *testing.T) {
	mockey.PatchConvey("Test when FileName is missing", t, func() {
		p := &ApplyUploadInfoReq{}
		err := p.Validate()
		convey.So(err, convey.ShouldResemble, errors.ErrMissingParam.WithArgs("FileName"))
	})
	mockey.PatchConvey("Test success", t, func() {
		p := &ApplyUploadInfoReq{FileName: "valid.docx"}
		err := p.Validate()
		convey.So(err, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test when FileName is too long", t, func() {
		p := &ApplyUploadInfoReq{FileName: strings.Repeat("a", 965)}
		err := p.Validate()
		convey.So(err, convey.ShouldResemble, errors.ErrorCommon.WithArgs("req FileName is too long LengthRange [0, 964]"))
	})
}

func Test_InitMultipartUploadReq_Validate(t *testing.T) {
	mockey.PatchConvey("Test InitMultipartUploadReq Validate", t, func() {
		convey.So((&InitMultipartUploadReq{}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("FileName"))
		convey.So((&InitMultipartUploadReq{FileName: "valid.pdf"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("FileSize"))
		convey.So((&InitMultipartUploadReq{
			FileName: "valid.pdf",
			FileSize: DefaultMultipartPartSize*MaxMultipartPartCount + 1,
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("multipart upload exceeds 10000 parts"))
		convey.So((&InitMultipartUploadReq{FileName: "valid.pdf", FileSize: 1}).Validate(), convey.ShouldBeNil)
	})
}

func Test_UploadMultipartPartReq_Validate(t *testing.T) {
	mockey.PatchConvey("Test UploadMultipartPartReq Validate", t, func() {
		convey.So((&UploadMultipartPartReq{}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("TosKey"))
		convey.So((&UploadMultipartPartReq{TosKey: "contract/file.pdf"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("UploadID"))
		convey.So((&UploadMultipartPartReq{TosKey: "contract/file.pdf", UploadID: "upload-id"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("PartNumber"))
		convey.So((&UploadMultipartPartReq{
			TosKey:     "contract/file.pdf",
			UploadID:   "upload-id",
			PartNumber: 1,
		}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("File"))
		convey.So((&UploadMultipartPartReq{
			TosKey:     "contract/file.pdf",
			UploadID:   "upload-id",
			PartNumber: 2,
			File:       &multipart.FileHeader{},
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("part file size must be greater than 0"))
		convey.So((&UploadMultipartPartReq{
			TosKey:     "contract/file.pdf",
			UploadID:   "upload-id",
			PartNumber: 1,
			File:       &multipart.FileHeader{Size: 1},
		}).Validate(), convey.ShouldBeNil)
		convey.So((&UploadMultipartPartReq{
			TosKey:     "contract/file.pdf",
			UploadID:   "upload-id",
			PartNumber: 2,
			File:       &multipart.FileHeader{Size: DefaultMultipartPartSize + 1},
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("part file size exceeds 7MB"))
		convey.So((&UploadMultipartPartReq{
			TosKey:     "contract/file.pdf",
			UploadID:   "upload-id",
			PartNumber: 1,
			File:       &multipart.FileHeader{Size: DefaultMultipartPartSize},
		}).Validate(), convey.ShouldBeNil)
	})
}

func Test_CompleteMultipartUploadReq_Validate(t *testing.T) {
	mockey.PatchConvey("Test CompleteMultipartUploadReq Validate", t, func() {
		convey.So((&CompleteMultipartUploadReq{}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("TosKey"))
		convey.So((&CompleteMultipartUploadReq{TosKey: "contract/file.pdf"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("UploadID"))
		convey.So((&CompleteMultipartUploadReq{TosKey: "contract/file.pdf", UploadID: "upload-id"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("Parts"))
		convey.So((&CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    []MultipartUploadPart{{PartNumber: 0, ETag: "etag"}},
		}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("PartNumber"))
		convey.So((&CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    []MultipartUploadPart{{PartNumber: 1}},
		}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("ETag"))
		convey.So((&CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    []MultipartUploadPart{{PartNumber: 1, ETag: "etag-1"}, {PartNumber: 1, ETag: "etag-2"}},
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("duplicate PartNumber"))
		convey.So((&CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    make([]MultipartUploadPart, MaxMultipartPartCount+1),
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("multipart upload exceeds 10000 parts"))
		convey.So((&CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    []MultipartUploadPart{{PartNumber: MaxMultipartPartCount + 1, ETag: "etag"}},
		}).Validate(), convey.ShouldResemble, errors.ErrorCommon.WithArgs("PartNumber exceeds 10000"))
		req := &CompleteMultipartUploadReq{
			TosKey:   "contract/file.pdf",
			UploadID: "upload-id",
			Parts:    []MultipartUploadPart{{PartNumber: 2, ETag: "etag-2"}, {PartNumber: 1, ETag: "etag-1"}},
		}
		convey.So(req.Validate(), convey.ShouldBeNil)
		convey.So(req.Parts[0].PartNumber, convey.ShouldEqual, 1)
	})
}

func Test_AbortMultipartUploadReq_Validate(t *testing.T) {
	mockey.PatchConvey("Test AbortMultipartUploadReq Validate", t, func() {
		convey.So((&AbortMultipartUploadReq{}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("TosKey"))
		convey.So((&AbortMultipartUploadReq{TosKey: "contract/file.pdf"}).Validate(), convey.ShouldResemble, errors.ErrMissingParam.WithArgs("UploadID"))
		convey.So((&AbortMultipartUploadReq{TosKey: "contract/file.pdf", UploadID: "upload-id"}).Validate(), convey.ShouldBeNil)
	})
}

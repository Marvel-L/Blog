package metaattach

import (
	"testing"
	"time"

	"github.com/bytedance/mockey"
	"github.com/smartystreets/goconvey/convey"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	"volc_contract_process/pkg/proxy/filecli"
)

func Test_ConvertProcessFileInfo(t *testing.T) {
	mockey.PatchConvey("Test when file is nil", t, func() {
		actual := ConvertProcessFileInfo(nil, 1, bizmodels.MetaAttachmentExtra{})
		convey.So(actual, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test when file is not nil", t, func() {
		file := &filecli.FileInfo{
			FileID:       "123",
			FileName:     "test.txt",
			Version:      "1.0",
			CreatorID:    "456",
			CreaterEmail: "test@example.com",
			CreatorName:  "John Doe",
			ModifyAt:     time.Now(),
			Ext:          "txt",
		}
		mockey.PatchConvey("Test with fileType 1", func() {
			expected := &ProcessFileInfo{
				FileType:     1,
				FileID:       file.FileID,
				FileName:     file.FileName,
				Version:      file.Version,
				CreatorID:    file.CreatorID,
				CreaterEmail: file.CreaterEmail,
				CreatorName:  file.CreatorName,
				ModifyAt:     file.ModifyAt,
				ModifiedAt:   file.ModifyAt.Format(time.RFC3339),
				Ext:          file.Ext,
			}
			actual := ConvertProcessFileInfo(file, 1, bizmodels.MetaAttachmentExtra{})
			convey.So(actual, convey.ShouldResemble, expected)
		})
		mockey.PatchConvey("Test with fileType 2", func() {
			expected := &ProcessFileInfo{
				FileType:     2,
				FileID:       file.FileID,
				FileName:     file.FileName,
				Version:      file.Version,
				CreatorID:    file.CreatorID,
				CreaterEmail: file.CreaterEmail,
				CreatorName:  file.CreatorName,
				ModifyAt:     file.ModifyAt,
				ModifiedAt:   file.ModifyAt.Format(time.RFC3339),
				Ext:          file.Ext,
			}
			actual := ConvertProcessFileInfo(file, 2, bizmodels.MetaAttachmentExtra{})
			convey.So(actual, convey.ShouldResemble, expected)
		})
	})
}

func Test_ConvertProcessFileInfoByAttachment(t *testing.T) {
	attachment := &model.ContractAttachmentDB{
		FileKey:    "file123",
		FileId:     "file123",
		Name:       "test_file.txt",
		OriginTime: time.Now(),
	}
	mockey.PatchConvey("Test successful conversion", t, func() {
		actual := ConvertProcessFileInfoByAttachment(attachment, bizmodels.MetaAttachmentExtra{})
		convey.So(len(actual), convey.ShouldEqual, 1)
		convey.So(actual[0].FileID, convey.ShouldEqual, attachment.FileKey)
		convey.So(actual[0].FileName, convey.ShouldEqual, attachment.Name)
		convey.So(actual[0].ModifyAt, convey.ShouldEqual, attachment.OriginTime)
	})
	mockey.PatchConvey("Test with empty attachment", t, func() {
		attachment = nil
		actual := ConvertProcessFileInfoByAttachment(attachment, bizmodels.MetaAttachmentExtra{})
		convey.So(actual, convey.ShouldBeNil)
	})
	mockey.PatchConvey("Test with empty fields in attachment", t, func() {
		attachment = &model.ContractAttachmentDB{}
		actual := ConvertProcessFileInfoByAttachment(attachment, bizmodels.MetaAttachmentExtra{})
		convey.So(len(actual), convey.ShouldEqual, 1)
		convey.So(actual[0].FileID, convey.ShouldBeEmpty)
		convey.So(actual[0].FileName, convey.ShouldBeEmpty)
		convey.So(actual[0].ModifyAt, convey.ShouldEqual, time.Time{})
	})
}

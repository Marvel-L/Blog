package metaattach

import (
	"mime/multipart"
	"sort"

	"volc_contract_process/pkg/errors"
)

const (
	DefaultMultipartPartSize int64 = 7 * 1024 * 1024
	MaxMultipartPartCount          = 10000
)

type InitMultipartUploadReq struct {
	FileName string `json:"FileName" form:"FileName" query:"FileName"`
	FileSize int64  `json:"FileSize" form:"FileSize" query:"FileSize"`
}

type InitMultipartUploadResp struct {
	TosKey    string `json:"TosKey"`
	UploadID  string `json:"UploadID"`
	PartSize  int64  `json:"PartSize"`
	PartCount int64  `json:"PartCount"`
}

func (p *InitMultipartUploadReq) Validate() errors.APIError {
	if len(p.FileName) == 0 {
		return errors.ErrMissingParam.WithArgs("FileName")
	}
	if p.FileSize <= 0 {
		return errors.ErrMissingParam.WithArgs("FileSize")
	}
	if p.FileSize > DefaultMultipartPartSize*MaxMultipartPartCount {
		return errors.ErrorCommon.WithArgs("multipart upload exceeds 10000 parts")
	}
	return nil
}

type UploadMultipartPartReq struct {
	TosKey     string                `json:"TosKey" form:"TosKey" query:"TosKey"`
	UploadID   string                `json:"UploadID" form:"UploadID" query:"UploadID"`
	PartNumber int                   `json:"PartNumber" form:"PartNumber" query:"PartNumber"`
	File       *multipart.FileHeader `json:"File" form:"File" formfile:"File"`
}

type UploadMultipartPartResp struct {
	TosKey     string `json:"TosKey"`
	UploadID   string `json:"UploadID"`
	PartNumber int    `json:"PartNumber"`
	ETag       string `json:"ETag"`
}

func (p *UploadMultipartPartReq) Validate() errors.APIError {
	if len(p.TosKey) == 0 {
		return errors.ErrMissingParam.WithArgs("TosKey")
	}
	if len(p.UploadID) == 0 {
		return errors.ErrMissingParam.WithArgs("UploadID")
	}
	if p.PartNumber <= 0 {
		return errors.ErrMissingParam.WithArgs("PartNumber")
	}
	if p.File == nil {
		return errors.ErrMissingParam.WithArgs("File")
	}
	if p.File.Size <= 0 {
		return errors.ErrorCommon.WithArgs("part file size must be greater than 0")
	}
	if p.File.Size > DefaultMultipartPartSize {
		return errors.ErrorCommon.WithArgs("part file size exceeds 7MB")
	}
	return nil
}

type CompleteMultipartUploadReq struct {
	TosKey   string                `json:"TosKey" form:"TosKey" query:"TosKey"`
	UploadID string                `json:"UploadID" form:"UploadID" query:"UploadID"`
	Parts    []MultipartUploadPart `json:"Parts" form:"Parts"`
}

type MultipartUploadPart struct {
	PartNumber int    `json:"PartNumber" form:"PartNumber"`
	ETag       string `json:"ETag" form:"ETag"`
}

type CompleteMultipartUploadResp struct {
	TosKey string `json:"TosKey"`
}

func (p *CompleteMultipartUploadReq) Validate() errors.APIError {
	if len(p.TosKey) == 0 {
		return errors.ErrMissingParam.WithArgs("TosKey")
	}
	if len(p.UploadID) == 0 {
		return errors.ErrMissingParam.WithArgs("UploadID")
	}
	if len(p.Parts) == 0 {
		return errors.ErrMissingParam.WithArgs("Parts")
	}
	if len(p.Parts) > MaxMultipartPartCount {
		return errors.ErrorCommon.WithArgs("multipart upload exceeds 10000 parts")
	}
	seen := make(map[int]struct{}, len(p.Parts))
	for _, part := range p.Parts {
		if part.PartNumber <= 0 {
			return errors.ErrMissingParam.WithArgs("PartNumber")
		}
		if part.PartNumber > MaxMultipartPartCount {
			return errors.ErrorCommon.WithArgs("PartNumber exceeds 10000")
		}
		if len(part.ETag) == 0 {
			return errors.ErrMissingParam.WithArgs("ETag")
		}
		if _, ok := seen[part.PartNumber]; ok {
			return errors.ErrorCommon.WithArgs("duplicate PartNumber")
		}
		seen[part.PartNumber] = struct{}{}
	}
	sort.Slice(p.Parts, func(i, j int) bool {
		return p.Parts[i].PartNumber < p.Parts[j].PartNumber
	})
	return nil
}

type AbortMultipartUploadReq struct {
	TosKey   string `json:"TosKey" form:"TosKey" query:"TosKey"`
	UploadID string `json:"UploadID" form:"UploadID" query:"UploadID"`
}

func (p *AbortMultipartUploadReq) Validate() errors.APIError {
	if len(p.TosKey) == 0 {
		return errors.ErrMissingParam.WithArgs("TosKey")
	}
	if len(p.UploadID) == 0 {
		return errors.ErrMissingParam.WithArgs("UploadID")
	}
	return nil
}

package metaattach

type AttachmentDataInfo struct {
	CanView     bool   `json:"CanView"`     // 是否可预览
	ContentType string `json:"ContentType"` // 响应给前端的内容类型
	FileName    string `json:"FileName"`    // 文件名称
	Data        []byte `json:"Data"`        // 数据
	ModifiedAt  int64  `json:"ModifiedAt"`  // 最后修改时间，单位：秒
}

type AttachmentURL struct {
	URL      string `json:"URL"`      // URL
	FileName string `json:"FileName"` // 名称
}

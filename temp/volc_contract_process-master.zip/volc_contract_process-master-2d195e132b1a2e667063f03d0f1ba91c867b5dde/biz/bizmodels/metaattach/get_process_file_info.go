package metaattach

import (
	"time"

	"volc_contract_process/biz/bizmodels"
	"volc_contract_process/biz/dal/model"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/proxy/filecli"
)

type GetProcessFileInfoResp struct {
	ContractFile       [][]*ProcessFileInfo `json:"ContractFile"`
	ContractAttachment [][]*ProcessFileInfo `json:"ContractAttachment"`
}

type ProcessFileInfo struct {
	FileType     int       `json:"FileType"` // 文件类型 1 为上一节点最新版本文件
	FileID       string    `json:"FileId"`
	FileName     string    `json:"FileName"`
	Version      string    `json:"Version"`
	CreatorID    string    `json:"CreatorId"`
	CreaterEmail string    `json:"CreaterEmail"`
	CreatorName  string    `json:"CreatorName"`
	Sealed       string    `json:"Sealed"`   // 用章情况
	Archived     string    `json:"Archived"` // 存档情况
	Remark       string    `json:"Remark"`   // 说明
	ModifiedAt   string    `json:"ModifiedAt"`
	ModifyAt     time.Time `json:"ModifyAt"`
	Ext          string    `json:"Ext"`
}

func ConvertProcessFileInfo(file *filecli.FileInfo, fileType int, extra bizmodels.MetaAttachmentExtra) *ProcessFileInfo {
	if file == nil {
		return nil
	}
	return &ProcessFileInfo{
		FileType:     fileType,
		FileID:       file.FileID,
		FileName:     file.FileName,
		Version:      file.Version,
		CreatorID:    file.CreatorID,
		CreaterEmail: file.CreaterEmail,
		CreatorName:  file.CreatorName,
		Sealed:       extra.Sealed,
		Archived:     extra.Archived,
		Remark:       extra.Remark,
		ModifiedAt:   file.ModifyAt.Format(time.RFC3339),
		ModifyAt:     file.ModifyAt,
		Ext:          file.Ext,
	}
}

func ConvertProcessFileInfoByAttachment(attachment *model.ContractAttachmentDB, extra bizmodels.MetaAttachmentExtra) []*ProcessFileInfo {
	if attachment == nil {
		return nil
	}
	return []*ProcessFileInfo{
		{
			FileType:   _const.ProcessFileTypeApprove,
			FileID:     attachment.FileKey,
			FileName:   attachment.Name,
			ModifyAt:   attachment.OriginTime,
			Sealed:     extra.Sealed,
			Archived:   extra.Archived,
			Remark:     extra.Remark,
			ModifiedAt: attachment.OriginTime.Format(time.RFC3339),
		},
	}
}

package metaattach

import (
	"io/ioutil"
	"mime/multipart"

	"code.byted.org/gopkg/context"
	"code.byted.org/gopkg/logs"

	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/tosc"
	"volc_contract_process/pkg/util"
)

type UploadReq struct {
	SourceType      _const.SourceType
	CurrentOperator string                `json:"CurrentOperator" form:"CurrentOperator" query:"CurrentOperator"`
	FileKey         string                `json:"FileKey" form:"FileKey" query:"FileKey"`
	File            *multipart.FileHeader `json:"File" form:"File" formfile:"File"`
	AccountID       int                   `json:"AccountId" form:"AccountID" query:"AccountId"`
	BizType         int                   `json:"BizType" form:"BizType" query:"BizType"`
	ContractNo      string                `json:"ContractNo" form:"ContractNo" query:"ContractNo"`
	Sealed          string                `json:"Sealed,omitempty" form:"Sealed" query:"Sealed"`
	Archived        string                `json:"Archived,omitempty" form:"Archived" query:"Archived"`
	Remark          string                `json:"Remark,omitempty" form:"Remark" query:"Remark"`
	Ext             string                `json:"Ext" form:"Ext" query:"Ext"`
	// 目前仅业务流程存在，外部入参文件时，从文件获取
	FileData []byte `json:"FileData" form:"FileData"`
	FileName string `json:"FileName" form:"FileName"`
	// 目前仅业务流程存在
	TosKey string `json:"TosKey" form:"TosKey"`
	// 非外部入参
	FeishuFileKey string `json:"FeishuFileKey" form:"FeishuFileKey"`
}

type UploadResp struct {
	FileID      string `json:"FileID"`
	URL         string `json:"URL"`
	FileName    string `json:"FileName"`    // 文件名
	FileKey     string `json:"FileKey"`     // 文件key
	StorageType int    `json:"StorageType"` // 文件存储类型
	CreatorName string `json:"CreatorName"` // 上传人名称
	ModifiedAt  string `json:"ModifiedAt"`
	Version     string `json:"Version"`
}

func (p *UploadReq) Validate(ctx context.Context) errors.APIError {
	if len(p.FileName) == 0 {
		return errors.ErrMissingParam.WithArgs("FileName")
	}

	if p.SourceType == _const.SourceTypeInner && len(p.CurrentOperator) == 0 {
		return errors.ErrMissingParam.WithArgs("CurrentOperator")
	}
	// 合同文本参数校验
	if p.BizType == _const.ContractAttachmentTypeFile {
		if len(p.CurrentOperator) == 0 {
			return errors.ErrMissingParam.WithArgs("CurrentOperator")
		}
		// 合同主文本：入参文件、文件tos存储路径、文件数据三者均未传入时报错，传入任意一个均可视为传入文件数据
		if p.File == nil && len(p.TosKey) == 0 && p.FileData == nil {
			return errors.ErrMissingParam.WithArgs("File")
		}
		// 合同文本：文件扩展名校验，只支持 PDF、DOC、DOCX
		ext := util.GetFileExtension(p.FileName)
		if len(ext) == 0 || !util.StringIn(ext, _const.SupportUploadExtensionList) {
			return errors.ErrFileExtensionNotSupport.WithArgs(ext)
		}
	}
	// 合同附件：参数校验
	if p.BizType == _const.ContractAttachmentTypeCommon {
		if len(p.Sealed) == 0 {
			return errors.ErrMissingParam.WithArgs("Sealed")
		}
		if len(p.Archived) == 0 {
			return errors.ErrMissingParam.WithArgs("Archived")
		}
		// 通用文本：文件、文件数据二者均为传入时报错，传入任意一个均可视为传入文件数据
		if p.File == nil && len(p.TosKey) == 0 && p.FileData == nil {
			return errors.ErrMissingParam.WithArgs("File")
		}
	}
	// 智能审核报告反馈附件：参数校验
	if p.BizType == _const.ContractAttachmentTypeAIAuditFeedback {
		// 智能审核反馈附件：入参文件、文件 tos 存储路径、文件数据三者均未传入时报错，传入任意一个均可视为传入文件数据
		if p.File == nil && len(p.TosKey) == 0 && p.FileData == nil {
			return errors.ErrMissingParam.WithArgs("File")
		}
		ext := util.GetFileExtension(p.FileName)
		if len(ext) == 0 || !util.StringIn(ext, _const.SupportUploadExtensionList) {
			return errors.ErrFileExtensionNotSupport.WithArgs(ext)
		}
	}
	if err := p.validateTosKey(ctx); err != nil {
		return err
	}

	return nil
}

func (p *UploadReq) validateTosKey(ctx context.Context) errors.APIError {
	if len(p.TosKey) == 0 {
		return nil
	}
	exists, err := tosc.CheckObjectExistsWithError(ctx, p.TosKey)
	if err != nil {
		logs.CtxError(ctx, "validateTosKeyCheckObjectFail, tosKey:%s, err:%v", p.TosKey, err)
		return errors.ErrorCommon.WithArgs(err.Error())
	}
	if !exists {
		return errors.ErrFileNotExistFail.WithArgs(p.TosKey)
	}
	return nil
}

func (p *UploadReq) FileTransform(ctx context.Context) errors.APIError {
	if p.File != nil {
		// 获取文件数据
		contractFile, err := p.File.Open()
		if err != nil {
			logs.CtxError(ctx, "formFileOpenFail, name:%s, err:%s", p.File.Filename, err.Error())
			return errors.ErrFile.WithArgs(err.Error())
		}
		defer contractFile.Close()

		fileData, err := ioutil.ReadAll(contractFile)
		if err != nil {
			logs.CtxError(ctx, "ReadFileFail, error: %v", err)
			return errors.ErrFile.WithArgs(err.Error())
		}
		p.FileData = fileData
		p.FileName = p.File.Filename
	}
	return nil
}

type PreSingedPostFormData struct {
	Policy        string `json:"Policy"`
	Algorithm     string `json:"Algorithm"`
	Credential    string `json:"Credential"`
	Date          string `json:"Date"`
	Signature     string `json:"Signature"`
	SecurityToken string `json:"SecurityToken"`
	Key           string `json:"Key"`
	Addr          string `json:"Addr"`
}

type ApplyUploadInfoReq struct {
	FileName string `json:"FileName" form:"FileName" query:"FileName"`
}

func (p *ApplyUploadInfoReq) Validate() errors.APIError {
	if len(p.FileName) == 0 {
		return errors.ErrMissingParam.WithArgs("FileName")
	}
	if len([]byte(p.FileName)) > 964 {
		return errors.ErrorCommon.WithArgs("req FileName is too long LengthRange [0, 964]")
	}
	return nil
}

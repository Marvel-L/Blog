package metaattach

// GetAttachmentPreviewInfoResp 获取附件预览信息
type GetAttachmentPreviewInfoResp struct {
	AttachName string `json:"AttachName"`
	CanPreview bool   `json:"CanPreview"`
	PreviewURL string `json:"PreviewURL"`
}

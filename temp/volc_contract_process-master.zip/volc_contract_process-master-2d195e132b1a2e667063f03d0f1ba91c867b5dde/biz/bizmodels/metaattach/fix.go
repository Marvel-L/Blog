package metaattach

type ContractFileMigrateReq struct {
	ContractNoList string `json:"ContractNoList" query:"ContractNoList"`
	BizScene       int    `json:"BizScene" query:"BizScene"`
	BeginTime      string `json:"BeginTime" query:"BeginTime"`
	EndTime        string `json:"EndTime" query:"EndTime"`
	Limit          int    `json:"Limit" query:"Limit" default:"100"`
	StartID        int    `json:"StartID" query:"StartID"`
	Offset         int    `json:"Offset" query:"Offset"`
}

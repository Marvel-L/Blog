package bizmodels

type ReviewerInfo struct {
	ReviewerRole     int
	AssigneePriority int
	EmployeeEmail    string
	EmployeeName     string
	EmployeeNumber   string
}

type DepartmentInfo struct {
	DepartmentID string
	Department   string
	ReviewerList []*ReviewerInfo
}

type GetDepartmentInfoReq struct {
	ContractNo string
}

type GetDepartmentInfoResp struct {
	DepartmentInfo *DepartmentInfo
}

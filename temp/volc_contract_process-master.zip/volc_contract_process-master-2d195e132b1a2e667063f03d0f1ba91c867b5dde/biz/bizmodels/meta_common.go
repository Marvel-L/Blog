package bizmodels

import (
	"context"
	"encoding/json"
	goerrors "errors"
	"fmt"
	"net/url"
	"sort"
	"strings"
	"time"

	sdkinvoiceclient "code.byted.org/eps-platform/invoice_sdk/invoiceclient"
	templateclient "code.byted.org/eps-platform/vcp_clients/filetemplateclient"
	"code.byted.org/gopkg/logs"
	"github.com/shopspring/decimal"

	"volc_contract_process/biz/service/multienv"
	"volc_contract_process/biz/service/multienv/i18nfmt"
	"volc_contract_process/biz/service/salescontract/productkey"
	_const "volc_contract_process/pkg/const"
	"volc_contract_process/pkg/errors"
	"volc_contract_process/pkg/proxy/invoicesdkcli"
	"volc_contract_process/pkg/util"
)

// BasicInfo 基本信息
type BasicInfo struct {
	ContractName              string  `json:"ContractName"`                                              // 合同名称
	HistoryContractNo         *string `json:"HistoryContractNo,omitempty"`                               // 历史合同号
	Operator                  string  `json:"Operator"`                                                  // 业务执行人工号
	CreatorUserId             string  `json:"CreatorUserId"`                                             // 创建人 UserID
	OperatorUserId            string  `json:"OperatorUserId"`                                            // 业务执行人 UserID
	OperatorNew               string  `json:"OperatorNew"`                                               // 业务执行人工号,people新ID
	CreatorNew                string  `json:"CreatorNew"`                                                // 创建人工号,people新ID
	Department                string  `json:"Department"`                                                // 业务执行人归属部门
	DepartmentId              string  `json:"DepartmentId"`                                              // 业务执行人归属部门id 对应review_rule表rule_id
	CategoryNo                string  `json:"CategoryNo"`                                                // 合同分类编码
	ContractTemplateType      *int    `json:"ContractTemplateType"`                                      // 0 我方模板无修改 1 我方模板有修改 2 对方模板 3 无模板
	WhetherProject            string  `json:"WhetherProject"`                                            // 是否项目制 Y:是；N:否
	OAApprovalURL             string  `json:"OAApprovalURL"`                                             // 项目敏捷OA审批链接
	WhetherReveal             string  `json:"WhetherReveal"`                                             // 是否可作为投标案例披露
	InOutType                 string  `json:"InOutType"`                                                 // 收支类型
	UsefulLifeType            int     `json:"UsefulLifeType" query:"UsefulLifeType" default:"1"`         // 有效期类型。1：固定期限； 2：自签订生效
	IndefiniteDateFlag        string  `json:"IndefiniteDateFlag" query:"IndefiniteDateFlag" default:"N"` // 有效期有无期限标识。Y:无限期 N:有限期
	UsefulLifeUnit            string  `json:"UsefulLifeUnit"`                                            // 有效期单位，当合同为“自签订之日起生效”时使用 DAY:日 MONTH:月 YEAR:年
	UsefulLifeNum             int     `json:"UsefulLifeNum"`                                             // 有效期数值，当合同为“自签订之日起生效”时使用
	LongLifeReason            string  `json:"LongLifeReason"`                                            // 长有效期原因  最多200字符
	FixedValidityCode         int     `json:"fixedValidityCode"`                                         // 期限类型编码
	FixedValidityDetailCode   int     `json:"fixedValidityDetailCode"`                                   // 期限类型详情编码
	BeginTime                 string  `json:"BeginTime"`                                                 // 开始时间
	EndTime                   string  `json:"EndTime"`                                                   // 结束时间
	Country                   string  `json:"Country"`                                                   // 国家
	PropertyCode              string  `json:"PropertyCode"`                                              // 合同性质
	EstimateTotal             string  `json:"EstimateTotal"`                                             // 预估支出金额，已废弃
	Discount                  string  `json:"Discount"`                                                  // 折扣
	BeforeDiscountAmount      string  `json:"BeforeDiscountAmount"`                                      // 折前金额
	AfterDiscountAmount       string  `json:"AfterDiscountAmount"`                                       // 折后金额
	FrameWorkContractPrice    string  `json:"FrameWorkContractPrice"`                                    // 框架合同价
	ExchangeRateType          int     `json:"ExchangeRateType"`                                          // 汇率类型
	ExchangeRate              string  `json:"ExchangeRate"`                                              // 汇率
	TotalIn                   string  `json:"TotalIn"`                                                   // 收入金额
	EstimateTotalIn           string  `json:"EstimateTotalIn"`                                           // 预估收入金额
	CurrencyIn                string  `json:"CurrencyIn"`                                                // 收入币种
	WhetherContainTaxIn       string  `json:"WhetherContainTaxIn"`                                       // 收入金额是否含税
	BearPartyIn               string  `json:"BearPartyIn"`                                               // 收入税务部分是否我方承担
	Total                     string  `json:"Total"`
	EstimatedAmount           string  `json:"EstimatedAmount"`           // 预估支出金额
	EstimatedCurrencyCode     string  `json:"EstimatedCurrencyCode"`     // 预估支出币种
	Currency                  string  `json:"Currency"`                  // 支出币种
	WhetherContainTax         string  `json:"WhetherContainTax"`         // 支出金额是否含税
	BearParty                 string  `json:"BearParty"`                 // 支出税务部分是否我方承担
	SignatureType             string  `json:"SignatureType"`             // 签约形式
	SealType                  string  `json:"SealType"`                  // 印章类型
	WhetherSingleSeal         string  `json:"WhetherSingleSeal"`         // 盖章方数量
	SealOrder                 string  `json:"SealOrder"`                 // 先盖章方
	PrintNum                  int     `json:"PrintNum"`                  // 盖章份数
	CooperationScene          string  `json:"CooperationScene"`          // 合作场景
	BusinessCondition         string  `json:"BusinessCondition"`         // 商务条件
	Remark                    string  `json:"Remark"`                    // 备注
	SourceSystem              string  `json:"SourceSystem"`              // 调用系统
	OpportunityName           string  `json:"OpportunityName"`           // 商机名称
	OpportunityID             string  `json:"OpportunityID"`             // 商机ID
	ProjectSetupApprovalURL   string  `json:"ProjectSetupApprovalURL"`   // 项目制立项流程
	ProjectSetupID            string  `json:"ProjectSetupID"`            // 项目制立项编号
	ProjectQuoteApprovalURL   string  `json:"ProjectQuoteApprovalURL"`   // 项目制报价流程
	ProjectQuoteNo            string  `json:"ProjectQuoteNo"`            // 项目制报价编号
	IsSkipFTL                 bool    `json:"IsSkipFTL"`                 // 是否跳过财税法审批
	IsCompletedFTLReview      bool    `json:"IsCompletedFTLReview"`      // 是否已完成财税法审批
	IsFeishu                  bool    `json:"IsFeishu"`                  // 是否为提交到飞书的合同，过渡阶段使用的临时字段，全量切换至飞书时，此字段可废弃
	BusinessType              int     `json:"BusinessType"`              // 业务类型
	SpecialContractType       string  `json:"SpecialContractType"`       // 特殊合同类型
	SpecialContractTypeRemark string  `json:"SpecialContractTypeRemark"` // 特殊合同类型描述
	WhetherSignNoCert         string  `json:"WhetherSignNoCert"`         // 签约认证一体化 "N" : 关闭签约认证一体化，签约不会自动发短信  "Y": 开启签约认证一体化，签约会自动发短信
	RedirectURL               string  `json:"RedirectURL"`               // 电子签签约结束后的跳转链接
	OriginBeginTime           *string `json:"OriginBeginTime,omitempty"` // 原始开始时间，使用指针，避免同步定时任务触发批量更新
}

func (b *BasicInfo) IsBasicRequireQuote() bool {
	// 「收支类型 = 收入类」 / 「收支类型 = 既收又支」
	if b.InOutType == _const.IN || b.InOutType == _const.InAndOut {
		return true
	}
	return false
}

func (b *BasicInfo) Validate() errors.APIError {
	if err := b.CheckExchangeRate(); err != nil {
		return err
	}
	if err := b.ValidateRedirectURL(); err != nil {
		return err
	}
	return nil
}

func (b *BasicInfo) ValidateRedirectURL() errors.APIError {
	if b == nil || b.RedirectURL == "" {
		return nil
	}
	if strings.TrimSpace(b.RedirectURL) != b.RedirectURL {
		return errors.ErrorCommon.WithArgs("电子签跳转链接格式错误")
	}
	if len(b.RedirectURL) > 2048 {
		return errors.ErrorCommon.WithArgs("电子签跳转链接长度超限")
	}
	parsedURL, err := url.ParseRequestURI(b.RedirectURL)
	if err != nil {
		return errors.ErrorCommon.WithArgs("电子签跳转链接格式错误")
	}
	if !strings.EqualFold(parsedURL.Scheme, "http") && !strings.EqualFold(parsedURL.Scheme, "https") {
		return errors.ErrorCommon.WithArgs("电子签跳转链接仅支持HTTP或HTTPS协议")
	}
	if parsedURL.Host == "" {
		return errors.ErrorCommon.WithArgs("电子签跳转链接缺少域名")
	}
	if parsedURL.User != nil {
		return errors.ErrorCommon.WithArgs("电子签跳转链接不支持用户信息")
	}
	return nil
}

func (b *BasicInfo) CheckExchangeRate() errors.APIError {
	// 国内环境不校验
	if !multienv.IsBytePlus() {
		return nil
	}
	// 收入币种为空不校验
	if len(b.CurrencyIn) == 0 {
		return nil
	}
	// 美元不校验
	if util.StringIn(b.CurrencyIn, []string{_const.CurrencyUSD, _const.CurrencyUSDMdCode}) {
		return nil
	}
	// 汇率类型为空或参数异常时，返回参数缺失 error
	if b.ExchangeRateType <= 0 {
		return errors.ErrMissingParam.WithArgs("ExchangeRateType")
	}

	if b.ExchangeRateType == _const.ExchangeRateTypeFixed && len(b.ExchangeRate) == 0 {
		return errors.ErrMissingParam.WithArgs("ExchangeRate")
	}
	return nil
}

func (b *BasicInfo) IsSameContractTemplateType(t int) bool {
	if b.ContractTemplateType == nil {
		return false
	}
	return *b.ContractTemplateType == t
}

func (b *BasicInfo) GetHistoryContractNo() string {
	if b.HistoryContractNo == nil {
		return ""
	}
	return *b.HistoryContractNo
}

func (b *BasicInfo) RequireQuote(supplyScene int, supplySource string) bool {

	// 「收支类型 = 收入类」 / 「收支类型 = 既收又支」
	if b.InOutType == _const.IN || b.InOutType == _const.InAndOut {
		if supplyScene == _const.SupplySceneOA {
			return false
		}
		// 合同为火山补充协议 合同补充场景不包含 报价单变更 & 有效期变更时 不需要关联报价单
		if supplyScene == _const.SupplySceneVolc &&
			!util.StringListIn(strings.Split(supplySource, ","), _const.RelateQuoteSupplySourceList) {
			return false
		}
		return true
	}

	return false
}

// validateContractPeriod 合同有效期参数合理性校验
func (b *BasicInfo) ValidateContractPeriod(ctx context.Context, status int) error {
	// 有效期校验
	if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_DEFAULT_TIME {
		return errors.ErrMissingParam.WithArgs("UsefulLifeType")
	}
	if len(b.IndefiniteDateFlag) == 0 {
		return errors.ErrMissingParam.WithArgs("IndefiniteDateFlag")
	}
	if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME {
		logs.CtxInfo(ctx, "指定合同有效期，beginTime:%s, endTime:%s", b.BeginTime, b.EndTime)
		if len(b.BeginTime) == 0 {
			return errors.ErrMissingParam.WithArgs("BeginTime")
		}
		if len(b.EndTime) == 0 && b.IndefiniteDateFlag != _const.Yes {
			return errors.ErrMissingParam.WithArgs("固定期限，结束时间无值时为无期限合同")
		}
		if len(b.EndTime) != 0 && b.IndefiniteDateFlag != _const.No {
			return errors.ErrMissingParam.WithArgs("固定期限，结束时间有值时为有期限合同")
		}
	} else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
		logs.CtxInfo(ctx, "自签订生效，UsefulLifeNum:%s, UsefulLifeUnit:%s, LongLifeReason:%s", b.UsefulLifeNum, b.UsefulLifeUnit, b.LongLifeReason)
		if b.IndefiniteDateFlag != _const.No {
			return errors.ErrMissingParam.WithArgs("自签订生效只支持有期限合同")
		}
		if len(b.UsefulLifeUnit) == 0 {
			return errors.ErrMissingParam.WithArgs("UsefulLifeUnit")
		}
		if b.UsefulLifeNum == 0 {
			return errors.ErrMissingParam.WithArgs("UsefulLifeNum")
		}
	} else {
		return errors.ErrMissingParam.WithArgs("未知有效期类型")
	}

	// 兼容历史数据 非提交场景 不校验长有效期原因
	if status == _const.SalesContractUnSubmit || status == _const.SalesContractRejected {
		// 长有效期原因必填校验
		if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SIGN_TIME {
			if b.UsefulLifeUnit == _const.USEFUL_LIFE_UNIT_YEAR && b.UsefulLifeNum > 5 {
				if len(b.LongLifeReason) == 0 {
					return errors.ErrMissingParam.WithArgs("合同有效期超过五年，长有效期原因不允许为空")
				}
			}
		} else if b.UsefulLifeType == _const.CONTRACT_LIFE_TYPE_SPECIFY_TIME {
			beginTime, err := time.ParseInLocation(util.DateFormatTpl, b.BeginTime, time.Local)
			if err != nil {
				return errors.ErrMissingParam.WithArgs("固定合同有效期，合同开始时间异常")
			}
			if len(b.EndTime) == 0 {
				if len(b.LongLifeReason) == 0 {
					return errors.ErrMissingParam.WithArgs("合同有效期超过五年，长有效期原因不允许为空")
				}
			} else {
				endTime, err := time.ParseInLocation(util.DateFormatTpl, b.EndTime, time.Local)
				if err != nil {
					return errors.ErrMissingParam.WithArgs("固定合同有效期，合同开始时间异常")
				}
				subTime := endTime.Sub(beginTime)
				fiveYear := 5 * 365 * 24 * time.Hour
				if subTime > fiveYear {
					if len(b.LongLifeReason) == 0 {
						return errors.ErrMissingParam.WithArgs("合同有效期超过五年，长有效期原因不允许为空")
					}
				}
			}
		}
	}

	return nil
}

type ContractPriceRepeatInfo struct {
	QuoteNo  string
	Repeated bool
	Msg      string
}

type ContractPriceRepeatInfoV1 struct {
	QuoteNo  string            `json:"QuoteNo"`
	Repeated bool              `json:"Repeated"`
	Msg      map[string]string `json:"Msg"`
	// 在线协同
	CommodityMsg map[string]string `json:"CommodityMsg"`
}

// ManageInfo 管理信息
type ManageInfo struct {
	PaymentType            string                    `json:"PaymentType"`            // 预算科目
	PaymentTypeName        string                    `json:"PaymentTypeName"`        // 预算科目
	BelongingDepartment    string                    `json:"BelongingDepartment"`    // 一级产品线
	ProductLine            string                    `json:"ProductLine"`            // 产品线
	DistributBusinessType  int                       `json:"DistributBusinessType"`  // BP分销业务类型
	RelatedPersonnel       string                    `json:"RelatedPersonnel"`       // 相关人员
	LegalReviewer          string                    `json:"LegalReviewer"`          // 法务审核人工号
	FeishuApostilleInfo    FeishuApostilleInfo       `json:"FeishuApostilleInfo"`    // 飞书加签人信息
	ReceivingPlace         string                    `json:"ReceivingPlace"`         // 合同领取地点
	QuoteType              int                       `json:"QuoteType"`              // 报价类型：0-普通报价，1-项目制报价，2-阶梯报价
	ProductLevelMap        map[string][]*ProductInfo `json:"ProductLevelMap"`        // 商品行信息-分组
	DeductProductInfoMap   map[string][]*ProductInfo `json:"DeductProductInfoMap"`   // 抵扣商品行（只包含节省计划抵扣项）
	ExternalProductList    ExternalProductInfoList   `json:"ExternalProductList"`    // 外部产品列表
	Remark                 string                    `json:"Remark"`                 // 备注
	AccountAssociationInfo map[string]string         `json:"AccountAssociationInfo"` // 商品行账号关联信息

	// 自签订日起生效新增字段
	UsefulLifeType     int    `json:"UsefulLifeType"`     // 有效期类型。1：固定期限； 2：自签订生效
	IndefiniteDateFlag string `json:"IndefiniteDateFlag"` // 有效期有无期限标识。Y:无限期 N:有限期
	UsefulLifeUnit     string `json:"UsefulLifeUnit"`     // 有效期单位，当合同为“自签订之日起生效”时使用 DAY:日 MONTH:月 YEAR:年
	UsefulLifeNum      int    `json:"UsefulLifeNum"`      // 有效期数值，当合同为“自签订之日起生效”时使用
	LongLifeReason     string `json:"LongLifeReason"`     // 长有效期原因  最多200字符

	ProductTotalIncome       float64 `json:"ProductTotalIncome"`       // 产品总计收入
	ProductValidityBegin     string  `json:"ProductValidityBegin"`     // 产品有效期起始日期
	ProductValidityEnd       string  `json:"ProductValidityEnd"`       // 产品有效期截止日期
	QuoteAccountID           string  `json:"QuoteAccountID"`           // 报价单账号ID 后期有可能变为多个，这里使用字符串存储
	SealAccountID            string  `json:"SealAccountID"`            // 签约账号ID 后期有可能变为多个，这里使用字符串存储
	PricingAccountID         string  `json:"PricingAccountID"`         // 配价账号ID 后期有可能变为多个，这里使用字符串存储
	EndUser                  string  `json:"EndUser"`                  // 最终用户
	EndUserAccountID         string  `json:"EndUserAccountID"`         // 最终用户账号ID 后期有可能变为多个，这里使用字符串存储
	RelateQuoteChanged       bool    `json:"RelateQuoteChanged"`       // 报价单发生变更
	RelateQuoteChangedBefore string  `json:"RelateQuoteChangedBefore"` // 变更前报价单
	WhetherProject           string  `json:"WhetherProject"`           // 是否项目制
	IsSplitProduct           bool    `json:"IsSplitProduct"`           // 是否拆分商品
	// ProgressiveType          string  `json:"ProgressiveType"`       // 累计纬度
	// 在线协同
	ProductValidityBeginWithTZ string `json:"ProductValidityBeginWithTZ"` // 产品有效期起始日期
	ProductValidityEndWithTZ   string `json:"ProductValidityEndWithTZ"`   // 产品有效期截止日期
}

func (m *ManageInfo) ValidateExternalCommodity(ctx context.Context) errors.APIError {
	if m == nil {
		logs.CtxError(ctx, "ValidateExternalCommodityFail, metaDB is nil")
		return errors.ErrInternalError.WithArgs("metaDB is nil")
	}
	if !m.IsSplitProduct {
		logs.CtxInfo(ctx, "IsSplitProduct[false], continue.")
		return nil
	}
	// 查询合同全量外部报价项信息
	if len(m.ExternalProductList) == 0 {
		logs.CtxError(ctx, "需要拆分内外部映射表，外部报价信息不可为空")
		return errors.ErrCommon.WithArgs("内外部映射表不可为空")
	}

	// 内部报价项基于 ID 构建 Map
	// 外部报价项基于关联内部报价项 ID 计算数量加和
	if err := m.ExternalProductList.Validate(); err != nil {
		logs.CtxError(ctx, "ValidateExternalCommodityFail_Validate, err:%v", err)
		return err
	}
	if err := m.validateBuyNum(ctx); err != nil {
		logs.CtxError(ctx, "ValidateExternalCommodityFail_ValidateBuyNum, err:%v", err)
		return err
	}
	return nil
}

func (m *ManageInfo) validateBuyNum(ctx context.Context) errors.APIError {
	// 构建商品行Id Map
	productMap := map[string]*ProductInfo{}
	productMaps := []map[string][]*ProductInfo{m.ProductLevelMap, m.DeductProductInfoMap}
	for _, pMap := range productMaps {
		for _, items := range pMap {
			for _, item := range items {
				productMap[item.QuoteItemID] = item
			}
		}
	}
	// buyNumSumMap := map[string]decimal.Decimal{}
	for _, commodity := range m.ExternalProductList {
		if commodity.RecordType == _const.ExternalCommodityRecordTypeMaster {
			continue
		}
		// 公有云不做校验
		if commodity.DeploymentType == _const.SettlementDeploymentPublicCloud {
			continue
		}
		if len(commodity.BuyNum) == 0 {
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为空",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum))
		}
		buyNum, err := decimal.NewFromString(commodity.BuyNum)
		if err != nil {
			logs.CtxError(ctx, "分组[%d]外部商品行[%s]购买数据[%s]格式异常[%s]",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum, err.Error())
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]格式异常[%s]",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum, err.Error()))
		}

		logs.CtxInfo(ctx, "[validateBuyNum]buyNum=%s", buyNum.String())
		// 新增校验 必须>=0
		if buyNum.LessThanOrEqual(decimal.Zero) {
			logs.CtxError(ctx, "分组[%d]外部商品行[%s]购买数据[%s]不允许为0",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum)
			return errors.ErrInternalError.WithArgs(i18nfmt.Sprintf(ctx, "分组[%d]外部商品行[%s]购买数量[%s]不允许为0",
				commodity.GroupID, commodity.RelateQuoteItemID, commodity.BuyNum))
		}

		// buyNumSumMap[commodity.RelateQuoteItemID] = buyNumSumMap[commodity.RelateQuoteItemID].Add(buyNum)
	}
	// 校验外部报价项数量加和与内部报价项是否相等
	// var errMsgs []string
	// for relateQuoteItemID, buyNumSum := range buyNumSumMap {
	//	product, ok := productMap[relateQuoteItemID]
	//	if !ok {
	//		logs.CtxError(ctx, "外部报价项关联内部报价项不存在, commodityId:%d", relateQuoteItemID)
	//		errMsgs = append(errMsgs, i18nfmt.Sprintf(ctx, "外部报价项关联内部报价项[%s]不存在", relateQuoteItemID))
	//		continue
	//	}
	//	if !strings.EqualFold(buyNumSum.String(), product.BuyNum) {
	//		logs.CtxError(ctx, "外部报价项数量加和与关联内部报价项数量不一致，commodityId:%d", relateQuoteItemID)
	//		errmsg := i18nfmt.Sprintf(ctx, "内部商品行[%s]内外部映射表购买数量校验失败，内部商品行购买数量[%s]，外部商品行购买数量总和[%s]", relateQuoteItemID, product.BuyNum, buyNumSum.String())
	//		errMsgs = append(errMsgs, errmsg)
	//	}
	// }
	// if len(errMsgs) > 0 {
	//	return errors.ErrInternalError.WithArgs(strings.Join(errMsgs, "\n"))
	// }
	return nil
}

func (m *ManageInfo) ValidateProductHasSameInvoice(ctx context.Context) errors.APIError {

	logs.CtxInfo(ctx, "validateProductHasSameInvoiceBefore")
	productMaps := []map[string][]*ProductInfo{m.ProductLevelMap, m.DeductProductInfoMap}
	for _, pMap := range productMaps {
		for _, v := range pMap {
			err := checkProductHasSameInvoice(ctx, v)
			if err != nil {
				return err
			}
		}
	}
	logs.CtxInfo(ctx, "validateProductHasSameInvoiceSuccess")
	return nil
}

// ValidateProductInvoiceProjectByInvoiceSDK 通过发票校验前端传入的商品与开票项是否匹配。
func (m *ManageInfo) ValidateProductInvoiceProjectByInvoiceSDK(ctx context.Context) errors.APIError {
	if multienv.IsBytePlus() {
		logs.CtxInfo(ctx, "海外环境不执行商品开票项匹配校验")
		return nil
	}

	productMap := m.buildUniqueTradeProductForInvoiceProjectValidate()
	if len(productMap) == 0 {
		logs.CtxInfo(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_skip_empty_products")
		return nil
	}

	logs.CtxInfo(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_before, productCount:%d", len(productMap))
	queries := make([]invoicesdkcli.ProductInvoiceProjectQuery, 0, len(productMap))
	for _, product := range productMap {
		// 兼容前端未单独传税率、仅在开票项文案中带税率的场景。
		if product.TaxRatio.IsZero() || product.InvoiceProjectCode == "" {
			product.InvoiceProjectCode, product.TaxRatio = util.ParseInvoiceProject(product.InvoiceProject)
		}
		queries = append(queries, invoicesdkcli.ProductInvoiceProjectQuery{
			ProductCode: product.TradeProduct,
			TaxRate:     product.TaxRatio,
		})
	}
	// 获取商品的开票项
	respMap, err := invoicesdkcli.BatchGetProductInvoiceProject(ctx, queries)
	if err != nil {
		logs.CtxError(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_batch_query_fail, err:%v", err)
		var batchErr *invoicesdkcli.BatchGetProductInvoiceProjectError
		if goerrors.As(err, &batchErr) {
			if product := productMap[batchErr.ProductCode]; product != nil {
				return errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "%s开票项信息查询失败", product.getInvoiceValidateProductName()))
			}
			return errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "%s开票项信息查询失败", batchErr.ProductCode))
		}
		return errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "商品开票项信息查询失败"))
	}
	logs.CtxInfo(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_batch_query_success, queries:%v, respMap:%v", util.GetJsonStr(queries), util.GetJsonStr(respMap))

	productErrMap := make(map[string]string)
	for _, product := range productMap {
		resp, exist := respMap[invoicesdkcli.BuildProductInvoiceProjectMapKey(product.TradeProduct, product.TaxRatio)]
		if !exist {
			logs.CtxError(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_query_result_missing, product:%s, taxRate:%s", product.TradeProduct, product.TaxRatio.String())
			return errors.ErrorCommon.WithArgs(i18nfmt.Sprintf(ctx, "%s开票项信息查询失败", product.getInvoiceValidateProductName()))
		}
		// 校验商品和开票项是否一致
		if product.matchInvoiceProjectByInvoiceSDK(resp) {
			continue
		}

		errMsg := i18nfmt.Sprintf(ctx, "%s开票项不符合商品规则", product.getInvoiceValidateProductName())
		logs.CtxWarn(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_mismatch, product:%s, invoiceProject:%s, taxRate:%s", product.TradeProduct, product.InvoiceProjectCode, product.TaxRatio.String())
		productErrMap[product.getInvoiceValidateProductName()] = errMsg
	}

	if len(productErrMap) == 0 {
		logs.CtxInfo(ctx, "ValidateProductInvoiceProjectByInvoiceSDK_success")
		return nil
	}

	errList := make([]string, 0, len(productErrMap))
	for _, msg := range productErrMap {
		errList = append(errList, msg)
	}
	sort.Strings(errList)
	return errors.ErrorCommon.WithArgs(strings.Join(errList, "，") + "，请重新选择")
}

func checkProductHasSameInvoice(ctx context.Context, productList []*ProductInfo) errors.APIError {
	if multienv.IsBytePlus() {
		logs.CtxInfo(ctx, "海外环境不执行开票项相关校验")
		return nil
	}
	m := map[string]string{}
	for _, v := range productList {
		if len(v.InvoiceProject) == 0 {
			continue
		}
		product := v.TradeProduct
		if old, exist := m[product]; exist && old != v.InvoiceProject {
			logs.CtxError(ctx, "validateProductHasSameInvoiceFail, 同一商品[%s]开票项目不一致, [%s], [%s]", product, old, v.InvoiceProject)
			errMsg := i18nfmt.Sprintf(ctx, "同一商品[%s]开票项目不一致, [%s], [%s]", product, old, v.InvoiceProject)
			return errors.ErrorCommon.WithArgs(errMsg)
		}
		m[product] = v.InvoiceProject
	}
	return nil
}

// buildUniqueTradeProductForInvoiceProjectValidate 按 TradeProduct 去重，
func (m *ManageInfo) buildUniqueTradeProductForInvoiceProjectValidate() map[string]*ProductInfo {
	productMap := make(map[string]*ProductInfo)
	productMaps := []map[string][]*ProductInfo{m.ProductLevelMap, m.DeductProductInfoMap}
	for _, pMap := range productMaps {
		for _, productList := range pMap {
			for _, product := range productList {
				if product == nil || product.TradeProduct == "" || product.InvoiceProject == "" {
					continue
				}
				_, ok := productMap[product.TradeProduct]
				if !ok {
					productMap[product.TradeProduct] = product
					continue
				}

			}
		}
	}
	return productMap
}

// matchInvoiceProjectByInvoiceSDK 校验商品开票项是否一致。
func (p *ProductInfo) matchInvoiceProjectByInvoiceSDK(resp *sdkinvoiceclient.ListProductInvoiceProject) bool {
	if p == nil || resp == nil {
		return false
	}
	// 校验默认开票项
	if resp.DefaultInvoiceProject != nil && resp.DefaultInvoiceProject.InvoiceProject == p.InvoiceProjectCode {
		return true
	}
	// 组合开票项
	if resp.CombineInvoiceProject != nil && resp.CombineInvoiceProject.InvoiceProject == p.InvoiceProjectCode {
		return true
	}
	// 单独开票项
	for _, item := range resp.InvoiceProject {
		if item == nil {
			continue
		}
		if item.InvoiceProject == p.InvoiceProjectCode {
			return true
		}
	}
	return false
}

func (p *ProductInfo) getInvoiceValidateProductName() string {
	if p == nil {
		return ""
	}
	if p.TradeProductName != "" {
		return p.TradeProductName
	}
	return p.TradeProduct
}

// ValidateInvoiceProjectBySnapshot 基于实时补充的快照信息校验商品开票项是否合法。
func (m *ManageInfo) ValidateInvoiceProjectBySnapshot(ctx context.Context) errors.APIError {
	if multienv.IsBytePlus() {
		logs.CtxInfo(ctx, "海外环境不执行开票项快照校验")
		return nil
	}

	logs.CtxInfo(ctx, "validateInvoiceProjectBySnapshotBefore")
	// 按商品名聚合错误信息
	productErrMap := map[string]string{}
	productMaps := []map[string][]*ProductInfo{m.ProductLevelMap, m.DeductProductInfoMap}
	for _, pMap := range productMaps {
		for _, productList := range pMap {
			for _, product := range productList {
				if product == nil {
					continue
				}
				//  校验单个商品开票项是否合法
				if errMsg := product.validateInvoiceProjectBySnapshot(); errMsg != "" {
					productName := product.TradeProductName
					logs.CtxWarn(ctx, "validateInvoiceProjectBySnapshotFail, product=%s, scene=%s, err=%s", productName, product.InvoiceValidateScene, errMsg)
					productErrMap[productName] = errMsg
				}
			}
		}
	}

	if len(productErrMap) == 0 {
		logs.CtxInfo(ctx, "validateInvoiceProjectBySnapshotSuccess")
		return nil
	}

	errList := make([]string, 0, len(productErrMap))
	for _, msg := range productErrMap {
		errList = append(errList, msg)
	}
	// 排序后返回，保证相同入参下错误提示顺序稳定。
	sort.Strings(errList)
	logs.CtxWarn(ctx, "validateInvoiceProjectBySnapshotAggregateFail, errs=%v", errList)
	return errors.ErrorCommon.WithArgs(strings.Join(errList, "，") + "，请重新选择")
}

// validateInvoiceProjectBySnapshot 按快照场景分发到对应的开票项校验逻辑。
func (p *ProductInfo) validateInvoiceProjectBySnapshot() string {
	switch p.InvoiceValidateScene {
	// 关联报价单场景校验。
	case _const.InvoiceValidateSceneRelateQuote:
		return p.validateRelateQuoteInvoiceProject()
	// 未关联报价单场景校验。
	case _const.InvoiceValidateSceneNoQuote:
		return p.validateNoQuoteInvoiceProject()
	default:
		logs.CtxWarn(context.Background(), "validateInvoiceProjectBySnapshotIgnore_unknown_scene, product=%s, scene=%s", p.TradeProduct, p.InvoiceValidateScene)
		return ""
	}
}

// validateRelateQuoteInvoiceProject 校验关联报价单场景下的开票项是否与报价侧基准一致。
func (p *ProductInfo) validateRelateQuoteInvoiceProject() string {
	if p == nil {
		return "关联报价单场景校验开票项：商品信息不存在"
	}
	// 历史合同若未补到报价基准快照，则放行该部分校验。
	if p.OriginInvoiceProject == "" && p.OriginTaxRatio.IsZero() {
		return ""
	}
	// 关联报价单场景按开票项对比。 //todo zhangyujie 是否包括税率
	if p.InvoiceProject == p.OriginInvoiceProject {
		return ""
	}
	// 关联报价单场景允许开票项不一致但税率一致的情况通过。
	if !p.TaxRatio.IsZero() && !p.OriginTaxRatio.IsZero() && p.TaxRatio.Equal(p.OriginTaxRatio) {
		return ""
	}

	return p.buildInvoiceProjectRuleErrMsg(p.OriginInvoiceProject, p.OriginTaxRatio)
}

// validateNoQuoteInvoiceProject 校验未关联报价单场景下的开票项是否符合商品侧基准规则。
func (p *ProductInfo) validateNoQuoteInvoiceProject() string {
	if p == nil {
		return "未关联报价单场景校验开票项：商品信息不存在"
	}

	switch p.OriginSellingRule {
	case _const.InvoiceSellingRuleSingle:
		// 单独售卖场景按收入性质和开票项 // 已确定相同性质，相同开票项， 相同税率
		if p.IncomeCode == p.OriginIncomeCode && p.InvoiceProject == p.OriginInvoiceProject {
			return ""
		}
		if !p.TaxRatio.IsZero() && !p.OriginTaxRatio.IsZero() && p.TaxRatio.Equal(p.OriginTaxRatio) && p.IncomeCode == p.OriginIncomeCode {
			return ""
		}

		return p.buildInvoiceProjectRuleErrMsg(p.OriginInvoiceProject, p.OriginTaxRatio)
	case _const.InvoiceSellingRuleCombined:
		// 组合售卖场景按组合售卖对应的收入性质和开票项双字段对比。  // 已确定相同性质，相同开票项， 相同税率
		if p.IncomeCode == p.OriginCombinedSaleIncomeCode && p.InvoiceProject == p.OriginCombinedSaleInvoiceProject {
			return ""
		}

		if !p.TaxRatio.IsZero() && !p.OriginCombinedSaleTaxRatio.IsZero() && p.TaxRatio.Equal(p.OriginCombinedSaleTaxRatio) && p.IncomeCode == p.OriginCombinedSaleIncomeCode {
			return ""
		}

		return p.buildInvoiceProjectRuleErrMsg(p.OriginCombinedSaleInvoiceProject, p.OriginCombinedSaleTaxRatio)
	default:
		logs.CtxWarn(context.Background(), "validateNoQuoteInvoiceProjectIgnore_unknown_rule, product=%s, rule=%s", p.TradeProduct, p.OriginSellingRule)
		return ""
	}
}

// buildInvoiceProjectRuleErrMsg 生成商品维度的开票项错误提示。
func (p *ProductInfo) buildInvoiceProjectRuleErrMsg(originInvoiceProject string, originTaxRatio decimal.Decimal) string {
	productName := p.TradeProductName
	if productName == "" {
		productName = p.TradeProduct
	}

	taxRatio := originTaxRatio
	// 调用方未直接传入税率时，兜底从开票项文案中解析税率用于提示。
	if taxRatio.IsZero() && originInvoiceProject != "" {
		_, taxRatio = util.ParseInvoiceProject(originInvoiceProject)
	}
	if !taxRatio.IsZero() {
		return i18nfmt.Sprintf(context.Background(), "%s仅可选择%s的开票项", productName, taxRatio.String()+"%")
	}
	return i18nfmt.Sprintf(context.Background(), "%s开票项不符合原始规则", productName)

}

// ValidateProductConfigurationChargeCodeUnique 校验商品配置_计费项是否唯一
func (m *ManageInfo) ValidateProductConfigurationChargeCodeUnique(ctx context.Context) error {
	productMaps := []map[string][]*ProductInfo{m.ProductLevelMap, m.DeductProductInfoMap}
	for _, pMap := range productMaps {
		for _, productList := range pMap {
			err := m.checkProductConfigurationChargeCodeUnique(ctx, productList)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func (m *ManageInfo) checkProductConfigurationChargeCodeUnique(ctx context.Context, productList []*ProductInfo) errors.APIError {
	uniqueKeySet := map[string]bool{}
	for _, product := range productList {
		// 旧的数据跳过,旧有的在线协同/后台发起的商品数据 没有配置等多个字段，合同2.8为新增配置、计费项字段，与数据库兼容
		if product.Configuration == "" && product.ChargeItemCode == "" {
			continue
		}
		infos := product.ConvertProductKeyInfo()

		productKey, err := productkey.GenKey(ctx, infos, productkey.AlgorithmVersion3)
		if err != nil {
			logs.CtxError(ctx, "ProductkeyGenKeyFail_new, ZhName:%s", product.TradeProductName)
			return errors.ErrCommon.WithArgs("ProductkeyGenKeyFail_new")
		}
		if _, ok := uniqueKeySet[productKey]; ok {
			logs.CtxError(ctx, "product_configuration_chargeItemCode repeated, key:%s",
				i18nfmt.Sprintf(ctx, "%v-%v-%v", product.TradeProductCode, product.Configuration, product.ChargeItemCode))
			errStr := i18nfmt.Sprintf(ctx, "商品编码_配置_计费项 重复, key: %s",
				i18nfmt.Sprintf(ctx, "%v-%v-%v", product.TradeProductCode, product.Configuration, product.ChargeItemCode))
			return errors.ErrCommon.WithArgs(errStr)
		}
		uniqueKeySet[productKey] = true
	}
	return nil
}

// FeishuApostilleInfo 飞书加签人信息
type FeishuApostilleInfo struct {
	DirectSupervisor string `json:"DirectSupervisor"` // 直属上级
}

type ExternalProductInfo struct {
	ID                    uint64          `json:"ID"`
	GroupID               int             `json:"GroupID"`
	RecordType            int             `json:"RecordType"`            // 外部报价项条目类型 1：主条目、2：子条目
	RelateQuoteItemID     string          `json:"RelateQuoteItemID"`     // 关联报价单条目ID
	VolcContractID        uint64          `json:"VolcContractID"`        // 关联合同ID
	TradeProductName      string          `json:"TradeProductName"`      // 商品名称
	TradeProductCode      string          `json:"TradeProductCode"`      // 商品Code
	TradeProduct          string          `json:"TradeProduct"`          // 商品英文名唯一标识
	BuyNum                string          `json:"BuyNum"`                // 购买数量
	BuyNumUnit            string          `json:"BuyNumUnit"`            // 购买数量单位
	Quantity              string          `json:"Quantity"`              // 预计用量
	QuantityUnit          string          `json:"QuantityUnit"`          // 预计用量单位
	BuyDuration           string          `json:"BuyDuration"`           // 购买时长
	BuyDurationUnit       string          `json:"BuyDurationUnit"`       // 购买时长单位
	UnitPrice             string          `json:"UnitPrice"`             // 单价
	Discount              string          `json:"Discount"`              // 折扣
	DistributionDiscounts string          `json:"DistributionDiscounts"` // 多级分销，折扣/价格
	IncomeNoTax           string          `json:"IncomeNoTax"`           // 收入金额
	TaxRate               string          `json:"TaxRate"`               // 税率
	TradeSolution         string          `json:"TradeSolution"`         // 技术解决方案
	CanPrePay             string          `json:"CanPrePay"`             // 付费方式
	GuaranteedPercentage  string          `json:"GuaranteedPercentage"`  // 保底比例
	ConfigCategory        string          `json:"ConfigCategory"`        // 配置分类
	Configuration         string          `json:"Configuration"`         // 配置
	SellingMode           string          `json:"SellingMode"`           // 售卖模式
	ChargeItemTag         string          `json:"ChargeItemTag"`         // 计费项分类
	ChargeItemCode        string          `json:"ChargeItemCode"`        // 计费项编码
	BillingName           string          `json:"BillingName"`           // 计费方式名称
	TradeSolutionName     string          `json:"TradeSolutionName"`     // 技术解决方案名称
	Region                string          `json:"Region"`                // 地域
	ChargeElement         string          `json:"ChargeElement"`         // 计费单元
	PriceFactor           string          `json:"PriceFactor"`           // 价格影响因子
	PriceType             string          `json:"PriceType"`             // 价格类型
	Income                decimal.Decimal `json:"Income"`                // 收入金额
	IncomeCode            string          `json:"IncomeCode"`            // 收入性质
	DeploymentType        int             `json:"DeploymentType"`        // 部署方式
	Remark                string          `json:"Remark"`                // 备注
	QuoteItemID           string          `json:"QuoteItemID"`           // 报价单条目ID
	InvoiceProjectCode    string          `json:"InvoiceProjectCode"`    // 开票项目业务主键,*信息技术服务*技术服务费
	TaxRatio              decimal.Decimal `json:"TaxRatio"`              // 税率
	InvoiceProject        string          `json:"InvoiceProject"`        // 开票项目
	Status                int             `json:"Status"`                // 状态
	PrePayRatio           string          `json:"PrePayRatio"`           // 预付比例
	PrePayRatioCode       string          `json:"PrePayRatioCode"`       // 预付比例编码
	SpBuyDuration         string          `json:"SpBuyDuration"`         // 购买时长
	SpBuyDurationCode     string          `json:"SpBuyDurationCode"`     // 购买时长编码
	CommitFeeInterval     string          `json:"CommitFeeInterval"`     // 承诺消费金额
	CommitFeeIntervalCode string          `json:"CommitFeeIntervalCode"` // 承诺消费金额编码
	SalesMode             string          `json:"SalesMode"`             // SavingsPlans-节省计划 Others-其他类型商品
	ConfigIsPublic        string          `json:"ConfigIsPublic"`        // 是否公开售卖 0-非公开售卖,1-公开售卖
	ConfigPublicDisplay   string          `json:"ConfigPublicDisplay"`   // 1-非公开售卖配置报价可见 2-非公开售卖配置报价不可
	RelatedItemID         string          `json:"RelatedItemID"`         // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	ItemBusinessRole      string          `json:"ItemBusinessRole"`      // 报价项业务角色：0-标准报价项，1-抵扣报价项
}

type ExternalProductInfoList []*ExternalProductInfo

func (c ExternalProductInfoList) Validate() errors.APIError {
	for _, commodity := range c {
		if len(commodity.RelateQuoteItemID) == 0 {
			return errors.ErrMissingParam.WithArgs("ExternalCommodity.RelateQuoteItemID")
		}
		if commodity.GroupID == 0 {
			return errors.ErrMissingParam.WithArgs("ExternalCommodity.GroupID")
		}
	}
	return nil
}

type ProductInfo struct {
	ID                    uint64          // 商品行唯一ID
	VolcContractID        uint64          `json:"VolcContractId"` // 关联合同ID
	TradeProduct          string          // 商品英文名唯一标识
	TradeProductCode      string          // 商品Code
	TradeProductName      string          // 商品名称
	Income                decimal.Decimal // 收入金额
	InvoiceProjectCode    string          // 开票项目业务主键,*信息技术服务*技术服务费
	TaxRatio              decimal.Decimal // 税率
	InvoiceProject        string          // 开票项目
	IncomeCode            string          // 收入性质
	Remark                string          // 备注
	ChildProductCode      string          // 子产品code
	ProductKind           string          // 商品类型
	DeliveryMethodID      int             // 一级交付方式ID 自研软件：3；技术授权：10
	IsBillExist           bool            // 是否已关联账单
	UniqueKey             string          //
	StandardProductCode   string          // 单产品编码
	Configuration         string          // 配置 ConfigCode
	ConfigurationName     string          // 预付费-包天
	ConfigCategory        string          // 配置分类（存储配置分类编码）
	BillingMethodCode     string          // 计费方式编码 ChargeMethodCode
	BillingName           string          // 计费方式名称 非必传 ChargeMethod
	RegionCode            string          // 地域编码
	Region                string          // 地域
	ChargeElement         string          // 计费单元
	ChargeElementCode     string          // 计费单元编码	ChargeUnitCode
	PriceFactor           string          // 价格影响因子 PriceFactorCode
	PriceFactorCode       string          // 价格影响因子 PriceFactorCode
	PriceType             string          // 价格类型
	Discount              string          // 折扣/价格
	DistributionDiscounts string          // 多级分销，折扣/价格
	OffPeakHoursBilling   string          // 闲时折扣信息
	ChargeItemCode        string          // 计费项编码
	ChargeItemTag         string          // 计费项分类
	PricingVersion        string          // 刊例价版本
	PayType               string          // 付费方式(英文)
	CanPrePay             string          // 付费方式(中文)
	CanPrePayCode         string          // 付费方式(枚举)
	GuaranteedPercentage  string          // 保底比例
	DeploymentType        int             // 部署方式0公有云1私有云
	SellingMode           string          // 售卖模式 1-抢占式实例
	ItemType              string          // 0-线上标品，1-线下标品
	ActivationType        string          // 开通类型
	StandardProduct       string          // 标准商品：1-标品，2-非标品
	QuoteSolutionID       string          // 解决方案ID
	TradeSolutionCode     string          // 商品解决方案code
	TradeSolution         string          // 商品解决方案英文名
	TradeSolutionName     string          // 商品解决方案中文名
	TradeSolutionVersion  string          // 商品解决方案版本
	BuyNum                string          // 购买数量
	BuyNumUnit            string          // 购买数量单位
	Quantity              string          // 预计用量
	QuantityUnit          string          // 预计用量单位
	BuyDuration           string          // 购买时长
	BuyDurationUnit       string          // 购买市场单位
	MaintenanceService    string          // 赠送信息
	MaintenanceNum        string          // 赠送数量
	MaintenanceUnit       string          // 赠送数量单位
	OriginalPrice         string          // 刊例价售卖金额
	IncomeNoTax           string          // 折后金额
	PriceInfoSnapshot     string          // 刊例价单价
	QuoteItemID           string          // 报价系统数据库中的自增id
	RelatedItemID         string          // 关联报价项ID：抵扣报价项时表示关联的SP包报价项ID
	ItemBusinessRole      string          // 报价项业务角色：0-标准报价项，1-抵扣报价项
	ShowName              string          // 对客名称
	GiveAwayType          string          // 赠送类型：赠送、区间赠送
	Exclude               string          // 排除信息
	PrePayRatio           string          // 预付比例
	PrePayRatioCode       string          // 预付比例编码
	SpBuyDuration         string          // 节省计划购买时长
	SpBuyDurationCode     string          // 节省计划购买时长编码
	CommitFeeInterval     string          // 承诺消费金额
	CommitFeeIntervalCode string          // 承诺消费金额编码
	SalesMode             string          // SavingsPlans-节省计划 Others-其他类型商品
	ConfigIsPublic        string          // 是否公开售卖 0-非公开售卖,1-公开售卖
	ConfigPublicDisplay   string          // 1-非公开售卖配置报价可见 2-非公开售卖配置报价不可
	UpdatedTime           int64           // 更新时间戳
	ProductSource         string          // 商品来源  outsourced:外采  self_owned:自有

	// 运行时快照字段，用于前后端共用开票项校验
	InvoiceValidateScene             string
	OriginSellingRule                string
	OriginInvoiceProject             string          // 售卖开票项（开票项+税率）
	OriginInvoiceProjectCode         string          // 开票项
	OriginTaxRatio                   decimal.Decimal // 税率
	OriginIncomeCode                 string          // 售卖性质
	OriginCombinedSaleInvoiceProject string          // 组合售卖开票项
	OriginCombinedSaleIncomeCode     string          // 组合售卖性质 （开票项+税率）
	OriginCombinedSaleTaxRatio       decimal.Decimal // 组合售卖税率
}

type ProductInfoList []*ProductInfo

type ConvertContractDiscount struct {
	ValidityBegin         time.Time
	ValidityEnd           time.Time
	QuoteNo               string
	ContractNo            string
	BusinessType          int
	DistributBusinessType int
}

func (p *ProductInfo) GenQuoteDiscount(isProject, beginTime, endTime string) []*QuoteDiscount {
	var ret []*QuoteDiscount
	var payType string
	var savingPlanExtra *SavingPlanInExtra

	payTypeIn, ok := _const.CanPrePayMapping[p.CanPrePayCode]
	if ok {
		payType = payTypeIn
	}
	deploymentType := _const.ContractToProductDeploymentType[p.DeploymentType]

	discount := &Discount{}
	distributDiscounts := DistributionDiscounts{}
	_ = json.Unmarshal([]byte(p.Discount), &discount)
	_ = json.Unmarshal([]byte(p.DistributionDiscounts), &distributDiscounts)
	if distributDiscounts.FirstDiscount != nil && distributDiscounts.FirstDiscount.Discount != nil {
		discount = distributDiscounts.FirstDiscount.Discount
	} else if discount == nil {
		discount = &Discount{}
	}

	exclude := &ExcludeDetail{}
	_ = json.Unmarshal([]byte(p.Exclude), &exclude)

	if p.SalesMode == multienv.SalesModeSavingsPlans {
		savingPlanExtra = &SavingPlanInExtra{
			PrePayRatio:           p.PrePayRatio,
			PrePayRatioCode:       p.PrePayRatioCode,
			SpBuyDuration:         p.SpBuyDuration,
			SpBuyDurationCode:     p.SpBuyDurationCode,
			CommitFeeInterval:     p.CommitFeeInterval,
			CommitFeeIntervalCode: p.CommitFeeIntervalCode,
		}
	}

	qd := &QuoteDiscount{
		Product:               p.TradeProduct,
		ProductName:           p.TradeProductName,
		ProductCode:           p.TradeProductCode,
		Configuration:         p.Configuration,
		ConfigurationName:     p.ConfigurationName,
		ChargeItemCode:        p.ChargeItemCode,
		ChargeItemTag:         p.ChargeItemTag,
		PriceVersion:          p.PricingVersion,
		Discount:              p.Discount,
		BeginTime:             beginTime,
		EndTime:               endTime,
		BottomAmount:          "",
		ConfigurationCategory: p.ConfigCategory,
		BillingMethodCode:     p.BillingMethodCode,
		BillingName:           p.BillingName,
		RegionCode:            p.RegionCode,
		Region:                p.Region,
		ChargeElement:         p.ChargeElement,
		ChargeElementCode:     p.ChargeElementCode,
		PriceFactor:           p.PriceFactorCode,
		PriceFactorName:       p.PriceFactor,
		PayType:               payType,
		CanPrePay:             p.CanPrePay,
		GuaranteedPercentage:  p.GuaranteedPercentage,
		SellingMode:           p.SellingMode,
		DeploymentType:        deploymentType,
		BizBillingFunction:    discount.PricingFunction,
		UnitPrice:             discount.UnitPrice.String(),
		UnitPriceInterval:     discount.UnitPriceInterval,
		MeasureInterval:       discount.MeasureInterval,
		ProductCatalogue:      _const.StandProductCodeMap[p.StandardProduct],
		Solution:              p.TradeSolution,
		SolutionVersion:       p.TradeSolutionVersion,
		ExternalID:            "",
		PriceInfoSnapshot:     p.PriceInfoSnapshot,
		Exclude: DiscountExclude{
			ConfigurationCategory: exclude.ConfigurationCategoryCode,
			Configuration:         exclude.ConfigurationCode,
			RegionCode:            exclude.RegionCode,
			ChargeElement:         exclude.ChargeElementCode,
			ChargeItemTag:         exclude.ChargeItemTagCode,
		},
		ReferenceID:      p.QuoteItemID,
		RelatedItemID:    p.RelatedItemID,
		ItemBusinessRole: p.ItemBusinessRole,
		IsProject:        isProject,
		Extra: &DiscountExtra{
			SavingPlan: savingPlanExtra,
		},
	}
	list := qd.SplitSellingMode()
	for _, val := range list {
		if val.SellingMode == "" {
			val.SellingMode = "0"
		}
		ret = append(ret, val)
	}
	return ret
}

func GroupQuoteDiscounts(qds []*QuoteDiscount) []*QuoteDiscount {
	var ret []*QuoteDiscount
	var mainDiscounts []*QuoteDiscount
	deductMap := make(map[string][]*QuoteDiscount)

	for _, qd := range qds {
		if qd.ItemBusinessRole == _const.ItemBusinessRoleDeduct {
			deductMap[qd.RelatedItemID] = append(deductMap[qd.RelatedItemID], qd)
		} else {
			mainDiscounts = append(mainDiscounts, qd)
		}
	}

	for _, main := range mainDiscounts {
		if deducts, ok := deductMap[main.ReferenceID]; ok {
			main.DeductList = deducts
		}
		ret = append(ret, main)
	}

	return ret
}

func (p ProductInfoList) GenQuoteDiscount(isProject, beginTime, endTime string) []*QuoteDiscount {
	var ret []*QuoteDiscount
	for _, val := range p {
		ret = append(ret, val.GenQuoteDiscount(isProject, beginTime, endTime)...)
	}

	return GroupQuoteDiscounts(ret)
}

func (p *ProductInfo) ConvertContractDiscount(ctx context.Context, validityBegin, validityEnd time.Time, quoteNo, contractNo string) *ContractDiscount {
	var (
		customerDiscount      *CustomerDiscount
		discount              = Discount{}
		distributionDiscounts = DistributionDiscounts{}
		savingPlanExtra       *SavingPlanInExtra
	)
	// 拆分 BP分销特殊报价 主体账号ID
	_ = json.Unmarshal([]byte(p.Discount), &discount)
	_ = json.Unmarshal([]byte(p.DistributionDiscounts), &distributionDiscounts)
	if distributionDiscounts.FirstDiscount != nil {
		customerDiscount = distributionDiscounts.FirstDiscount
	} else if len(discount.PricingFunction) > 0 {
		customerDiscount = &CustomerDiscount{Discount: &discount}
	} else {
		customerDiscount = &CustomerDiscount{Discount: &Discount{}}
	}

	exclude := &ExcludeDetail{}
	_ = json.Unmarshal([]byte(p.Exclude), &exclude)

	// 参数映射
	payTypeIn := _const.CanPrePayMapping[p.CanPrePayCode]
	canPrePay := multienv.GetCanPrePaySec(ctx, payTypeIn)
	discountKey := fmt.Sprintf("%v%v%v%v%v%v%v%v%v%v%v%v",
		p.TradeProduct,
		p.ConfigCategory,
		p.Configuration,
		p.BillingMethodCode,
		p.RegionCode,
		p.ChargeElementCode,
		p.PriceFactorCode,
		p.ChargeItemCode,
		p.ChargeItemTag,
		p.PrePayRatioCode,
		p.SpBuyDurationCode,
		p.CommitFeeIntervalCode,
	)
	var beginUnit, endUnit int64
	if !validityBegin.IsZero() {
		beginUnit = validityBegin.Unix()
	}
	if !validityEnd.IsZero() {
		endUnit = validityEnd.Unix()
	}
	if p.SalesMode == multienv.SalesModeSavingsPlans {
		savingPlanExtra = &SavingPlanInExtra{
			PrePayRatio:           p.PrePayRatio,           // 预付比例
			PrePayRatioCode:       p.PrePayRatioCode,       // 预付比例, 1- 0 预付, 2- 部分预付, 3-全预付
			SpBuyDuration:         p.SpBuyDuration,         // 购买时长
			SpBuyDurationCode:     p.SpBuyDurationCode,     // 购买月份, 单位月, 示例: 1,1
			CommitFeeInterval:     p.CommitFeeInterval,     // 承诺消费金额
			CommitFeeIntervalCode: p.CommitFeeIntervalCode, // 承诺消费金额, 单位元, 示例: 100
		}
	}

	return &ContractDiscount{
		Key:                              discountKey,
		Product:                          p.TradeProduct,
		ProductName:                      p.TradeProductName,
		ProductValidityBegin:             beginUnit,
		ProductValidityEnd:               endUnit,
		ContractNo:                       contractNo,
		ChargeItemCode:                   p.ChargeItemCode,
		ChargeItemTag:                    p.ChargeItemTag,
		PayType:                          payTypeIn,
		CanPrePay:                        canPrePay,
		ConfigurationCategory:            p.ConfigCategory,
		Configuration:                    p.Configuration,
		ConfigurationName:                p.ConfigurationName,
		BillingFunction:                  customerDiscount.Discount.PricingFunction,
		BillingName:                      p.BillingName,
		BillingMethodCode:                p.BillingMethodCode,
		RegionCode:                       p.RegionCode,
		Region:                           p.Region,
		ChargeElement:                    p.ChargeElement,
		ChargeElementCode:                p.ChargeElementCode,
		UnitPrice:                        customerDiscount.Discount.UnitPrice.String(),
		UnitPriceInterval:                customerDiscount.Discount.UnitPriceInterval,
		MeasureInterval:                  customerDiscount.Discount.MeasureInterval,
		PriceFactor:                      p.PriceFactorCode,
		PriceFactorName:                  p.PriceFactor,
		RelateQuoteNo:                    quoteNo,
		PriceInfoSnapshot:                p.PriceInfoSnapshot,
		ExternalID:                       "",
		BeginTime:                        int(validityBegin.Unix()),
		EndTime:                          int(validityEnd.Unix()),
		Solution:                         p.TradeSolution,
		SolutionVersion:                  p.TradeSolutionVersion,
		SellingMode:                      multienv.FormatSellingMode(ctx, p.SalesMode, p.CanPrePayCode, p.SellingMode),
		ReferenceID:                      p.QuoteItemID,
		RelatedItemID:                    p.RelatedItemID,
		ItemBusinessRole:                 p.ItemBusinessRole,
		BizBillingFunction:               customerDiscount.Discount.PricingFunction,
		ConfigurationCategoryExclude:     exclude.ConfigurationCategoryCode, // 配置分类 排除项
		ConfigurationCategoryExcludeName: exclude.ConfigurationCategory,     // 配置分类名称 排除项
		ConfigurationExclude:             exclude.ConfigurationCode,         // 配置 排除项
		ConfigurationExcludeName:         exclude.Configuration,             // 配置名称 排除项
		ChargeItemTagExcludeCode:         exclude.ChargeItemTagCode,         // 计费项分类 排除项
		ChargeItemTagExcludeName:         exclude.ChargeItemTag,             // 计费项分类名称 排除项
		ChargeElementExcludeCode:         exclude.ChargeElementCode,         // 计费单元 排除项
		ChargeElementExcludeName:         exclude.ChargeElement,             // 计费单元名称 排除项
		RegionExcludeCode:                exclude.RegionCode,                // 地域 排除项
		RegionExcludeName:                exclude.Region,                    // 地域名称 排除项
		Extra: &DiscountExtra{
			SavingPlan: savingPlanExtra,
		},
	}
}

func (p *ProductInfo) ConvertProductKeyInfo() *productkey.ProductInfo {
	if p == nil {
		return nil
	}
	income, _ := p.Income.Float64()
	return &productkey.ProductInfo{
		SubProduct:            p.TradeProduct,
		ConfigCategory:        p.ConfigCategory,
		Configuration:         p.Configuration,
		BillingMethodCode:     p.BillingMethodCode,
		Region:                p.Region,
		ChargeItemCode:        p.ChargeItemCode,
		ChargeItemTag:         p.ChargeItemTag,
		ChargeElementCode:     p.ChargeElementCode,
		PriceFactor:           p.PriceFactor,
		PriceType:             p.PriceType,
		Discount:              p.Discount,
		DeploymentType:        p.DeploymentType,
		BuyNum:                p.BuyNum,
		BuyNumUnit:            p.BuyNumUnit,
		BuyDuration:           p.BuyDuration,
		BuyDurationUnit:       p.BuyDurationUnit,
		SellingMode:           p.SellingMode,
		PrePayRatio:           p.PrePayRatio,
		PrePayRatioCode:       p.PrePayRatioCode,
		SpBuyDuration:         p.SpBuyDuration,
		SpBuyDurationCode:     p.SpBuyDurationCode,
		CommitFeeInterval:     p.CommitFeeInterval,
		CommitFeeIntervalCode: p.CommitFeeIntervalCode,
		InvoiceProject:        p.InvoiceProject,
		IncomeCode:            p.IncomeCode,
		ProductIncome:         income,
		ConfigurationName:     p.ConfigurationName,
		BillingName:           p.BillingName,
		RegionCode:            p.RegionCode,
		PriceFactorCode:       p.PriceFactorCode,
		DistributionDiscounts: p.DistributionDiscounts,
		PricingVersion:        p.PricingVersion,
		PayType:               p.PayType,
		// AccountID:             p.AccountID,
		// OwnerID:               p.OwnerID,
		Exclude:          p.Exclude,
		RelatedItemID:    p.RelatedItemID,
		ItemBusinessRole: p.ItemBusinessRole,
	}
}

// CustomerInfo 客户信息
type CustomerInfo struct {
	CustomerType string // 客户类型，FirstDistributor=一级分销商，SecondDistributor=二级分销商，FinalCustomer=最终客户
	AccountID    string
	OwnerID      string
	CustomerName string
}

func (c *CustomerInfo) GenRelateAccountInfo() map[string][]string {
	if c == nil {
		return nil
	}
	return map[string][]string{
		c.CustomerName: strings.Split(c.AccountID, ","),
	}
}

type DistributorInfos struct {
	FirstDistributor  *CustomerInfo `json:"FirstDistributor"`
	SecondDistributor *CustomerInfo `json:"SecondDistributor"`
	FinalCustomer     *CustomerInfo `json:"FinalCustomer"`
}

func (d *DistributorInfos) GetFirstDistributor() string {
	if d == nil || d.FirstDistributor == nil {
		return ""
	}
	return d.FirstDistributor.AccountID
}

func (d *DistributorInfos) GetRelateAccountInfo() map[string]map[string][]string {
	if d == nil || d.FirstDistributor == nil {
		return nil
	}
	res := make(map[string]map[string][]string)
	if d.FirstDistributor != nil {
		res[_const.RelateAccountTypeFirstTierDistributor] = d.FirstDistributor.GenRelateAccountInfo()
	}
	if d.SecondDistributor != nil {
		res[_const.RelateAccountTypeSecondaryDistributor] = d.SecondDistributor.GenRelateAccountInfo()
	}
	if d.FinalCustomer != nil {
		res[_const.RelateAccountTypeEndUser] = d.FinalCustomer.GenRelateAccountInfo()
	}
	return res
}

// DistributionDiscounts 分销折扣
type DistributionDiscounts struct {
	FirstDiscount  *CustomerDiscount // 一级分销商折扣
	SecondDiscount *CustomerDiscount // 二级分销商折扣
	FinalDiscount  *CustomerDiscount // 最终客户折扣
}

// CustomerDiscount 客户折扣
type CustomerDiscount struct {
	CustomerInfo
	Discount *Discount
}

type Discount struct {
	PricingFunction   string          `json:"PricingFunction"`
	UnitPriceInterval string          `json:"UnitPriceInterval"`
	MeasureInterval   string          `json:"MeasureInterval"`
	UnitPrice         decimal.Decimal `json:"UnitPrice"`
}

func GetPricingFunction(ctx context.Context, discountInfo, distributionDiscounts string) (string, error) {
	var (
		discount          = &Discount{}
		distributDiscount = &DistributionDiscounts{}
		pricingFunction   string
	)
	if err := json.Unmarshal([]byte(discountInfo), discount); err != nil {
		logs.CtxWarn(ctx, "GetPricingFunction, discountInfo: %s, err: %v", discountInfo, err)
	}
	if err := json.Unmarshal([]byte(distributionDiscounts), distributDiscount); err != nil {
		logs.CtxWarn(ctx, "GetPricingFunction, distributionDiscounts: %s, err: %v", distributionDiscounts, err)
	}
	logs.CtxInfo(ctx, "获取折扣信息 discount：%v, distributDiscount:%v", discount, distributDiscount)
	if discount != nil && len(discount.PricingFunction) > 0 {
		pricingFunction = discount.PricingFunction
	} else if distributDiscount != nil && distributDiscount.FirstDiscount != nil && distributDiscount.FirstDiscount.Discount != nil {
		pricingFunction = distributDiscount.FirstDiscount.Discount.PricingFunction
	} else {
		return "", fmt.Errorf("GetPricingFunction fail")
	}
	if len(pricingFunction) == 0 {
		return "", fmt.Errorf("GetPricingFunctionFail, pricingFunction is empty")
	}
	return getPricingFunctionDesc(ctx, pricingFunction), nil
}

func ParseSimplePriceInfo(ctx context.Context, priceInfoSnapshot string) (string, error) {
	priceInfo := PriceInfoSnapshot{}
	err := json.Unmarshal([]byte(priceInfoSnapshot), &priceInfo)
	if err != nil {
		return "", err
	}
	if priceInfo.IsCombining {
		return i18nfmt.Sprintf(ctx, "%f%s", priceInfo.CombiningPrice, "元"), nil
	}
	price := "-"
	switch priceInfo.PricingFunction {
	case _const.FixedPrice:
		price = i18nfmt.Sprintf(ctx, "%v 元", priceInfo.Price)
	case _const.SimpleDiscount:
		price = i18nfmt.Sprintf(ctx, " %v 折", multienv.GetDiscountOffNum(priceInfo.Price))
	case _const.OverProgressive,
		_const.FullProgressive,
		_const.FullProgressiveTotal,
		_const.GuaranteedOverProgressive:
		measures := strings.Split(priceInfo.MeasureInterval, ",")
		units := strings.Split(priceInfo.PriceInterval, ",")
		var prices []string
		previous := "0"
		bracket := "["
		for i := 1; i < len(measures); i++ {
			current := measures[i]
			price := units[i-1]
			if i > 1 {
				bracket = "("
			}
			interval := i18nfmt.Sprintf(ctx, "%s%v, %v], %v 元", bracket, previous, current, price)
			prices = append(prices, interval)
			previous = current
		}
		prices = append(prices, i18nfmt.Sprintf(ctx, "(%v, +∞), %v 元", previous, units[len(units)-1]))
		price = strings.Join(prices, ";\n")

	case _const.RelatedChargeItemRatio:
		price = i18nfmt.Sprintf(ctx, " 固定比例:%v %%, 人民币: %v元", priceInfo.RelatedChargeItemRatio.Mul(decimal.NewFromInt(100)), priceInfo.Price.Mul(decimal.NewFromInt(10)))
	}
	return price, nil
}

func GetDiscountArrCommon(ctx context.Context, discount, distributionDiscounts string) ([]string, string, error) {
	// 通过 DistributionDiscount 获取折扣信息
	res, pricingFunction, err := GetDistributionDiscounts(ctx, distributionDiscounts)
	if err == nil {
		logs.CtxInfo(ctx, "GetDiscountArrCommon_GetDistributionDiscountsSuccess")
		return res, pricingFunction, nil
	}
	logs.CtxWarn(ctx, "GetDiscountArrCommon_GetDiscountFail, err:%s", err.Error())
	// 通过 DistributionDiscount 获取折扣信息失败，尝试通过 Discount 获取折扣信息
	res, pricingFunction, err = GetDiscount(ctx, discount)
	if err != nil {
		logs.CtxError(ctx, "GetDiscountArrCommon_GetDiscountFail, err:%s", err.Error())
		return res, pricingFunction, err
	}
	return res, pricingFunction, nil
}

func GetDiscount(ctx context.Context, discountInfo string) ([]string, string, error) {
	discount := &Discount{}
	if err := json.Unmarshal([]byte(discountInfo), discount); err != nil {
		logs.CtxWarn(ctx, "getDiscount_discountInfoUnmarshalFail, discountInfo:%s", discountInfo)
		return []string{}, "", err
	}
	logs.CtxInfo(ctx, "获取折扣信息 discount：%v", discount)
	return BuildDiscountStr(ctx, discount)
}

func GetDistributionDiscounts(ctx context.Context, discountInfo string) ([]string, string, error) {
	var (
		res             []string
		pricingFunction string
	)
	discount := &DistributionDiscounts{}
	if err := json.Unmarshal([]byte(discountInfo), discount); err != nil {
		logs.CtxWarn(ctx, "getDiscount_discountInfoUnmarshalFail, discountInfo:%s", discountInfo)
		return []string{}, "", err
	}
	logs.CtxInfo(ctx, "获取折扣信息 discount：%v", discount)
	if discount.FirstDiscount != nil {
		discountArr, function, err := buildDistributionDiscountsStr(ctx, discount.FirstDiscount)
		if err != nil {
			return []string{}, "", err
		}
		res = append(res, discountArr...)
		pricingFunction = function
	}
	if discount.SecondDiscount != nil {
		discountArr, function, err := buildDistributionDiscountsStr(ctx, discount.SecondDiscount)
		if err != nil {
			return []string{}, "", err
		}
		res = append(res, discountArr...)
		pricingFunction = function
	}
	if discount.FinalDiscount != nil {
		discountArr, function, err := buildDistributionDiscountsStr(ctx, discount.FinalDiscount)
		if err != nil {
			return []string{}, "", err
		}
		res = append(res, discountArr...)
		pricingFunction = function
	}
	return res, pricingFunction, nil
}

func buildDistributionDiscountsStr(ctx context.Context, discount *CustomerDiscount) ([]string, string, error) {
	var res []string
	firstDiscount, firstPricingFunction, err := BuildDiscountStr(ctx, discount.Discount)
	if err != nil {
		return []string{}, "", err
	}
	res = append(res, discount.CustomerInfo.AccountID)
	res = append(res, firstDiscount...)
	return res, firstPricingFunction, nil
}

func BuildDiscountStr(ctx context.Context, discount *Discount) ([]string, string, error) {
	pricingFunction := getPricingFunctionDesc(ctx, discount.PricingFunction)
	switch discount.PricingFunction {
	case _const.FixedPrice:
		return []string{i18nfmt.Sprintf(ctx, "%s元", discount.UnitPrice.String())}, pricingFunction, nil
	case _const.FullProgressive, _const.OverProgressive, _const.FullProgressiveTotal:

		measure := strings.Split(discount.MeasureInterval, ",")
		unitPrice := strings.Split(discount.UnitPriceInterval, ",")

		if len(measure) != len(unitPrice) {
			logs.CtxError(ctx, "折扣/价格 报价信息错误 discount：%v", discount)
			return []string{}, pricingFunction, i18nfmt.New(ctx, "折扣/价格 报价信息错误")
		}

		var res []string
		for index := 0; index < len(measure); index++ {
			start := measure[index]
			end := "+∞"
			if index < len(measure)-1 {
				end = measure[index+1]
			}
			price := unitPrice[index]
			if index == 0 {
				res = append(res, i18nfmt.Sprintf(ctx, "[%s, %s], %s元", start, end, price))
			} else {
				res = append(res, i18nfmt.Sprintf(ctx, "(%s, %s], %s元", start, end, price))
			}
			if index == len(measure)-1 {
				res[len(measure)-1] = i18nfmt.Sprintf(ctx, "(%s, %s), %s元", start, end, price)
			}
		}
		return res, pricingFunction, nil
	case _const.SimpleDiscount:
		// 国内展示为 8 折
		return []string{i18nfmt.Sprintf(ctx, "%s折", multienv.GetDiscountOffNum(discount.UnitPrice))}, pricingFunction, nil

	case _const.TimeDiscount:
		var res []string
		unitPriceMap := map[string]string{}
		measureMap := map[string]string{}
		_ = json.Unmarshal([]byte(discount.UnitPriceInterval), &unitPriceMap)
		_ = json.Unmarshal([]byte(discount.MeasureInterval), &measureMap)
		for timeDiscountKey, measureValue := range measureMap {
			_, ok := multienv.GetTimeDiscountMapping()[timeDiscountKey]
			if !ok {
				logs.CtxError(ctx, "暂不支持的时间满折类型，ChargeMethodCode：%s", timeDiscountKey)
				return []string{}, pricingFunction, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "暂不支持的时间满折类型: %s", timeDiscountKey))
			}
			priceValue := unitPriceMap[timeDiscountKey]
			measures := strings.Split(measureValue, ",")
			unitPrices := strings.Split(priceValue, ",")
			unit := multienv.I18nFormat(ctx, multienv.GetTimeDiscountUnitMapping()[timeDiscountKey])
			if len(unitPrices) != len(measures) {
				logs.CtxError(ctx, "%s，折扣/价格 报价信息错误", pricingFunction)
				return []string{}, pricingFunction, i18nfmt.New(ctx, i18nfmt.Sprintf(ctx, "折扣/价格 报价信息错误: %s", pricingFunction))
			}
			chargeMethodName := multienv.I18nFormat(ctx, multienv.GetTimeDiscountNameByCodeMapping()[timeDiscountKey])
			res = append(res, chargeMethodName)
			for index, measureInterval := range measures {
				priceDiscount, _ := decimal.NewFromString(unitPrices[index])
				content := i18nfmt.Sprintf(ctx, "满%s%s，%s折", measureInterval, unit, multienv.GetDiscountOffNum(priceDiscount))
				res = append(res, content)
			}
		}
		return res, pricingFunction, nil
	case _const.QuantityDiscount:
		priceDiscount, _ := decimal.NewFromString(discount.UnitPriceInterval)
		return []string{i18nfmt.Sprintf(ctx, "买满%s个，打%s折", discount.MeasureInterval, multienv.GetDiscountOffNum(priceDiscount))}, pricingFunction, nil
	case _const.TotalOverAmountDiscount:
		measure := strings.Split(discount.MeasureInterval, ",")
		unitPrice := strings.Split(discount.UnitPriceInterval, ",")

		if len(measure) != len(unitPrice) {
			logs.CtxError(ctx, "折扣/价格 报价信息错误 discount：%v", discount)
			return []string{}, pricingFunction, i18nfmt.New(ctx, "折扣/价格 报价信息错误")
		}

		var res []string
		for index := 0; index < len(measure); index++ {
			amount := measure[index]
			priceDiscount, _ := decimal.NewFromString(unitPrice[index])
			res = append(res, i18nfmt.Sprintf(ctx, "满%s元, %s折", amount, multienv.GetDiscountOffNum(priceDiscount)))
		}
		return res, pricingFunction, nil
	}
	return []string{}, pricingFunction, i18nfmt.New(ctx, "未匹配到对应价格类型")
}

func getPricingFunctionDesc(ctx context.Context, pricingFunction string) string {
	pricingFunctionDesc, ok := _const.PricingFunctionMap[pricingFunction]
	if !ok {
		logs.CtxWarn(ctx, "getPricingFunctionDesc, pricingFunction: %s", pricingFunction)
		return ""
	}
	return multienv.I18nFormat(ctx, pricingFunctionDesc)
}

type TradePartyInfoDetail struct {
	NACustomerTag     string                         `json:"NACustomerTag"`     // NA客户标签
	CustomerName      string                         `json:"CustomerName"`      // 客户名称
	IndustryCKey      string                         `json:"IndustryCKey"`      // 客户一级行业key
	IndustryCDec      string                         `json:"IndustryCDec"`      // 客户一级行业名称
	ContractRoleCode  string                         `json:"ContractRoleCode"`  // 交易方角色
	PrimaryFlag       string                         `json:"PrimaryFlag"`       // 我方，对方标识，必填，I代表我方，O代表对方
	SubjectNo         string                         `json:"SubjectNo"`         // 主体编码
	AccountID         string                         `json:"AccountID"`         // 账号
	SealAccountID     string                         `json:"SealAccountID"`     // 签约账号
	PricingAccountID  string                         `json:"PricingAccountID"`  // 配价账号
	RelateAccountInfo map[string]map[string][]string `json:"RelateAccountInfo"` // 关联账号
	PartyName         string                         `json:"PartyName"`         // 交易方名称
	PartyNumber       string                         `json:"PartyNumber"`       // 交易方编码
	LegalPartyNumber  string                         `json:"LegalPartyNumber"`  // 法人主体编码
	Sealed            int                            `json:"Sealed"`            // 是否签约
	Pricing           int                            `json:"Pricing"`           // 是否配价
	DeputyParty       int                            `json:"DeputyParty"`       // 是否为副签约主体 0-主签约主体，1-副签约主体
	DeputyPartySource int                            `json:"DeputyPartySource"` // 副签约主体来源 0-无，1-销售运营手动添加，2-飞书同步
	CpType            string                         `json:"CpType"`            // 交易方类型 subjectType
	OtherPartyType    int                            `json:"OtherPartyType"`    // 对方主体类型：0-通用 1-委托方 2-被委托方
	Signer            string                         `json:"Signer"`            // 签约人
	Email             string                         `json:"Email"`             // 签约人邮箱
	ContactName       string                         `json:"ContactName"`       // 联系人
	CreateSource      string                         `json:"CreateSource"`      // 账号创建类型
	OfficePhone       string                         `json:"OfficePhone"`       // 联系电话
	SignerPhone       string                         `json:"SignerPhone"`       // 签约人实名认证手机号码
	DocumentType      string                         `json:"DocumentType"`      // 证件类型 cardType
	DocumentCode      string                         `json:"DocumentCode"`      // 证件编码
	Country           string                         `json:"Country"`           // 国家
	StateName         string                         `json:"StateName"`         // 注册省份
	CityName          string                         `json:"CityName"`          // 注册城市
	Address           string                         `json:"Address"`           // 注册详细地址
	PayTypes          []*PayType                     `json:"PayTypes"`          // 支付收款方式
	OpAddress         []OpAddress                    `json:"OpAddress"`         // 交易方经营地信息
	SignCrossPage     string                         `json:"SignCrossPage"`     // 是否加盖骑缝章，Y N
	SignKeyword       string                         `json:"SignKeyword"`       // 盖章关键字
	SealType          string                         `json:"SealType"`          // 印章类型
	SignTypeLimits    string                         `json:"SignTypeLimits"`    // 非必填， 国内电子牵个人签约才会用到， 0:系统默认章(默认是0)， 1:手写签名章
}

type TradePartyInfoDetailList []*TradePartyInfoDetail

func (b *BasicInfo) FetchSignDataCheckType() int {
	if !util.StringIn(b.SignatureType, []string{_const.SignatureDomesticElectronicSignature,
		_const.SignatureInternationalElectronicSignature}) {
		return _const.NoneCheckPartyDetail
	}
	if b.WhetherSingleSeal == _const.No {
		return _const.CheckAllTradePartyDetail
	} else if b.WhetherSingleSeal == _const.Yes {
		if b.SealOrder == _const.OurSide {
			return _const.CheckSubjectTradePartyDetail
		} else if b.SealOrder == _const.OtherSide {
			return _const.CheckOtherTradePartyDetail
		}
	}
	return _const.TradePartyDetailCheckTypeMissMatch
}

func (p TradePartyInfoDetailList) GetPartyName() []string {
	var res []string
	for _, partyInfo := range p {
		res = append(res, partyInfo.PartyName)
	}
	return util.SingleList(res)
}

func (p *TradePartyInfoDetail) CheckSubjectSignData(signatureType string) error {
	if p.Sealed == _const.FALSE_FLAG_INT {
		return nil
	}
	if signatureType == _const.SignatureDomesticElectronicSignature {
		if len(p.SignKeyword) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易我方信息，签约关键字不能为空")
		}
	}
	return nil
}

// GetDefaultSubjectSealEnable 获取默认的我方主体是否需要盖章字段
func (p *TradePartyInfoDetail) GetDefaultSubjectSealEnable(ctx context.Context, relateQuoteNo string, bizScene int) int {
	if len(relateQuoteNo) == 0 && bizScene == _const.BizSceneSalesContract {
		logs.CtxInfo(ctx, "getDefaultSubjectSealEnable, salesContract no quote, use partyInfo.Sealed:%d", p.Sealed)
		return p.Sealed
	}
	return _const.TRUE_FLAG_INT
}

// GetDefaultOtherPartySealEnable 获取默认的对方主体是否需要盖章字段
func (p *TradePartyInfoDetail) GetDefaultOtherPartySealEnable(ctx context.Context, relateQuoteNo string, bizScene, bizSource int) int {
	// 代付合同 默认需要盖章
	if bizScene == _const.BizScenePayOnBehalf {
		logs.CtxInfo(ctx, "getDefaultOtherPartySealEnable, payOnBehalf, use true")
		return _const.TRUE_FLAG_INT
	}
	// 非代付的业务合同默认不需要盖章
	if util.IntIn(bizScene, []int{
		_const.BizSceneQuoteContract,
		_const.BizSceneCreditContract,
		_const.BizScenePartnerContract,
	}) {
		logs.CtxInfo(ctx, "getDefaultOtherPartySealEnable, otherBizContract, use false")
		return _const.TRUE_FLAG_INT
	}
	// 关联报价单的在线协同合同，默认需要对方签约
	if len(relateQuoteNo) > 0 && bizSource == _const.BizSourceCooperation {
		logs.CtxInfo(ctx, "getDefaultOtherPartySealEnable, salesContract with quote, use true")
		return _const.TRUE_FLAG_INT
	}
	// 其他默认返回对方主体上的是否签约标识
	return p.Sealed
}

// NeedRefreshSealedAndPricing 校验交易方信息是否需要更新是否签约和是否配价字段
// 当 我方主体或对方主体 的是否签约标识均为否时，返回true
// 默认我方主体 与 对方主体 都至少有一个需要签约
func (t *TradePartyInfo) NeedRefreshSealedAndPricing() bool {
	for _, partyInfo := range t.Subject {
		if partyInfo.Sealed == _const.TRUE_FLAG_INT {
			return false
		}
	}
	for _, partyInfo := range t.OtherParty {
		if partyInfo.Sealed == _const.TRUE_FLAG_INT {
			return false
		}
	}
	return true
}

func (p *TradePartyInfoDetail) CheckOtherSignData(signatureType string) error {
	if p.Sealed == _const.FALSE_FLAG_INT {
		return nil
	}
	if signatureType == _const.SignatureInternationalElectronicSignature {
		// 签约人姓名、签约人邮箱、抄送邮箱
		if len(p.Signer) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约人不能为空")
		}
		if len(p.Email) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约人邮箱不能为空")
		}
		// todo: 抄送邮箱待补充
	} else if signatureType == _const.SignatureDomesticElectronicSignature {
		if len(p.SignKeyword) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约关键字不能为空")
		}
		if len(p.Signer) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约人不能为空")
		}
		if len(p.SignerPhone) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约人实名认证手机号码不能为空")
		}
		if len(p.Email) == 0 {
			return i18nfmt.Errorf(context.Background(), "交易对方信息，签约人邮箱不能为空")
		}
	}
	return nil
}

// CheckOtherData 校验交易对方信息数据格式合理性
func (p *TradePartyInfoDetail) CheckOtherData() errors.APIError {

	if p.CpType != "" && p.CpType != _const.SubjectTypeEnterprise && p.CpType != _const.SubjectTypePersonal {
		return errors.ErrorCommon.WithArgs("认证类型异常")
	}

	// 通用校验
	if len([]rune(p.Signer)) > 50 {
		return errors.ErrorCommon.WithArgs("签约人姓名过长")
	}

	if p.SignerPhone != "" {
		if !util.IsValidPhoneNumber(p.SignerPhone) {
			return errors.ErrorCommon.WithArgs("签约人手机号格式错误")
		}
	}
	if p.Email != "" {
		if !util.IsValidateEmail(p.Email) {
			return errors.ErrorCommon.WithArgs("签约人邮箱格式错误")
		}
	}

	// 认证类型为企业
	if p.CpType == _const.SubjectTypeEnterprise {
		if len([]rune(p.PartyName)) > 256 {
			return errors.ErrorCommon.WithArgs("企业名称过长")
		}
		if p.DocumentType == "" {
			return errors.ErrorCommon.WithArgs("证件类型DocumentType缺失")
		}
		if p.DocumentType == _const.BusinessLicenseMdmCode {
			if len([]rune(p.DocumentCode)) > 18 {
				return errors.ErrorCommon.WithArgs("社会统一信用代码过长")
			}
		}
	}

	// 认证类型为个人
	if p.CpType == _const.SubjectTypePersonal {
		if len([]rune(p.PartyName)) > 256 {
			return errors.ErrorCommon.WithArgs("签约人姓名过长")
		}
		if p.DocumentType == "" {
			return errors.ErrorCommon.WithArgs("证件类型DocumentType缺失")
		}
		if p.DocumentType == _const.CNIdentityCardMdmCode {
			if !util.IsValidateIDCard(p.DocumentCode) {
				return errors.ErrorCommon.WithArgs("身份证号码格式错误")
			}
		}
	}

	return nil
}

// IsEntrustedParty 是否被委托方
func (p *TradePartyInfoDetail) IsEntrustedParty() bool {
	return p.OtherPartyType == _const.OtherPartyTypeEntrusted
}

// IsPrincipalParty 是否委托方
func (p *TradePartyInfoDetail) IsPrincipalParty() bool {
	return p.OtherPartyType == _const.OtherPartyTypePrincipal
}

// FillAccountID 填充交易账号
func (p *TradePartyInfoDetail) FillAccountID() {
	accountIDs := strings.Split(p.SealAccountID, ",")
	accountIDs = append(accountIDs, strings.Split(p.PricingAccountID, ",")...)
	p.AccountID = strings.Join(util.SingleList(accountIDs), ",")
}

// IsDeputyParty 判断是否为副签约主体
func (p *TradePartyInfoDetail) IsDeputyParty() bool {
	return p.DeputyParty == _const.TRUE_FLAG_INT
}

func (p TradePartyInfoDetailList) FillAccountID() {
	for _, party := range p {
		party.FillAccountID()
	}
}

type DiscountInfo struct {
	Product           string // 产品
	BillingFunction   string // 计费方式
	ObjectType        string // 折扣对象
	ObjectID          string // 折扣对象ID
	ObjectValue       string // 折扣对象值
	UnitValue         string // 单一值
	UnitValueInterval string // 值梯度
	MeasureInterval   string // 计量梯度
	Remark            string // 说明
}

type OpAddress struct {
	CountryCode string `json:"CountryCode"` // 经营地所在国家/地区
	StateName   string `json:"StateName"`   // 经营地所在省
	CityName    string `json:"CityName"`    // 经营地所在城市
	Address     string `json:"Address"`     // 经营地详细地址
}

type PayType struct {
	PayType       string `json:"PayType"`       // 支付/收款类型
	OpInfoId      string `json:"OpInfoId"`      // 银行账号ID-主数据唯一编码
	AccountNumber string `json:"AccountNumber"` // 银行账号
	SwiftCode     string `json:"SwiftCode"`     // SWIFT代码
	BranchCode    string `json:"BranchCode"`    // 开户行Code
	BranchName    string `json:"BranchName"`    // 开户行名称
	BankAddress   string `json:"BankAddress"`   // 开户行地址
	ClctName      string `json:"ClctName"`      // 账户名称
}

// TradePartyInfo 交易双方信息
type TradePartyInfo struct {
	Subject          []*TradePartyInfoDetail `json:"Subject"`
	OtherParty       []*TradePartyInfoDetail `json:"OtherParty"`
	RelatePartner    string                  `json:"RelatePartner"`
	EndUser          string                  `json:"EndUser"`
	EndUserAccountID string                  `json:"EndUserAccountID"`
	OpportunityName  string                  `json:"OpportunityName"`
	OpportunityID    string                  `json:"OpportunityID"`
}

func (t *TradePartyInfo) GetMainOtherParty() []*TradePartyInfoDetail {
	mainOtherParty := make([]*TradePartyInfoDetail, 0)
	for _, other := range t.OtherParty {
		if other.IsDeputyParty() {
			continue
		}
		mainOtherParty = append(mainOtherParty, other)

	}
	return mainOtherParty
}

func (t *TradePartyInfo) FillCooperationSealPriceTag(relateQuoteNo string) {
	// TODO:兼容逻辑，关联报价单合同，海外环境默认为即签约又配价
	if !multienv.IsBytePlus() {
		return
	}
	if len(relateQuoteNo) == 0 {
		return
	}
	for _, v := range t.Subject {
		v.Sealed = _const.TRUE_FLAG_INT
		v.SealAccountID = v.AccountID
	}
	for _, v := range t.OtherParty {
		// 仅签约主主体默认为既签约又配价
		if v.IsDeputyParty() {
			continue
		}
		v.Sealed = _const.TRUE_FLAG_INT
		v.SealAccountID = v.AccountID
		v.Pricing = _const.TRUE_FLAG_INT
		v.PricingAccountID = v.AccountID
	}
}

// getSealPartyAccounts 获取需要签约的OtherParty账号（复用现有字段处理逻辑）
func (t *TradePartyInfo) GetSealPartyAccounts() map[string]struct{} {
	accounts := make(map[string]struct{})
	if t == nil {
		return accounts
	}
	for _, p := range t.OtherParty {
		if p.Sealed == _const.TRUE_FLAG_INT {
			// 处理逗号分隔的账号（与现有账号处理逻辑一致）
			for _, id := range strings.Split(p.AccountID, ",") {
				if id != "" {
					accounts[id] = struct{}{}
				}
			}
		}
	}
	return accounts
}

// 获取主体编号集合（与现有主体处理逻辑一致）
func (t *TradePartyInfo) GetSubjectPartyNumber() map[string]struct{} {
	partyNumbers := make(map[string]struct{})
	if t == nil {
		return partyNumbers
	}
	for _, s := range t.Subject {
		// 使用工程标准空值处理方式
		if s.PartyNumber != "" {
			partyNumbers[s.PartyNumber] = struct{}{}
		}
	}
	return partyNumbers
}

func (t *TradePartyInfo) FillSealType(sealType string) {
	for _, party := range t.Subject {
		party.SealType = sealType
	}
}

// FillAccountID 填充账号ID
func (t *TradePartyInfo) FillAccountID() {
	for _, party := range t.OtherParty {
		if party.Sealed == _const.TRUE_FLAG_INT {
			party.SealAccountID = party.AccountID
		}
		if party.Pricing == _const.TRUE_FLAG_INT {
			party.PricingAccountID = party.AccountID
		}
	}
}

// 参数合理性校验
// 每份合同至少要有一个主体需要签约。
// 每份合同至少要有一个“对方主体”需要签约。
// 每个主体的“是否需要签约”、“是否需要配价”不允许同时选择“否”
func (t *TradePartyInfo) Validate(ctx context.Context, inOutType string) errors.APIError {
	var (
		isNoSignParty        = true
		isSubjectNoSignParty = true
	)
	if t == nil {
		return errors.ErrorCommon.WithArgs("TradePartyInfo is nil")
	}
	if err := t.BaseValidate(); err != nil {
		logs.CtxError(ctx, "TradePartyInfo.BaseValidate fail, err:%v", err)
		return err
	}
	// 我方
	for _, subject := range t.Subject {
		// 收入类 / 支出类 / 既收又支，强制赋值为“是”（是否签约）（任一主体为是）
		if util.StringIn(inOutType, []string{_const.IN, _const.OUT, _const.InAndOut}) &&
			subject.Sealed == _const.TRUE_FLAG_INT {
			isSubjectNoSignParty = false
		}
	}
	// 校验对方主体信息
	for _, otherParty := range t.OtherParty {
		// 合同类型非支出类、无收无支时，每个主体的“是否需要签约”、“是否需要配价”不允许同时选择“否”
		if !util.StringIn(inOutType, []string{_const.OUT, _const.NoInNoOut}) &&
			otherParty.Sealed == _const.FALSE_FLAG_INT && otherParty.Pricing == _const.FALSE_FLAG_INT {
			content := fmt.Sprintf("【%s】是否需要签约、是否需要配价不允许同时选择否", otherParty.PartyName)
			return errors.ErrorCommon.WithArgs(content)
		}
		// 合同类型非支出类、无收无支时，至少要有一个“对方主体”需要签约。
		if util.StringIn(inOutType, []string{_const.OUT, _const.NoInNoOut}) || otherParty.Sealed == _const.TRUE_FLAG_INT {
			isNoSignParty = false
		}
		// 支出类 / 无收无支，强制赋值为“否”（是否配价）（全部主体均为否）
		if util.StringIn(inOutType, []string{_const.OUT, _const.NoInNoOut}) && otherParty.Pricing == _const.TRUE_FLAG_INT {
			return errors.ErrorCommon.WithArgs("支出类 / 无收无支，对方主体是否配价需全部赋值为“否”")
		}
	}
	// 每份合同至少要有一个“对方主体”需要签约。
	if isNoSignParty {
		return errors.ErrorCommon.WithArgs("至少要有一个对方主体需要签约")
	}
	// 收入类 / 支出类 / 既收又支，是否签约强制赋值为“是”，任一主体为是即可。
	if util.StringIn(inOutType, []string{_const.IN, _const.OUT, _const.InAndOut}) && isSubjectNoSignParty {
		return errors.ErrorCommon.WithArgs("收入类 / 支出类 / 既收又支，需存在是否需要签约为“是”的我方主体")
	}
	return nil
}

// BaseValidate 基本校验，字段必填等
func (t *TradePartyInfo) BaseValidate() errors.APIError {
	if t == nil {
		return nil
	}
	// 我方
	for _, party := range t.Subject {
		// 交易双方信息，主数据编码必填
		if len(party.PartyNumber) == 0 {
			content := fmt.Sprintf("【%s】PartyNumber is nil", party.PartyName)
			return errors.ErrorCommon.WithArgs(content)
		}
	}
	for _, party := range t.OtherParty {
		// 交易双方信息，主数据编码必填
		if len(party.PartyNumber) == 0 {
			content := fmt.Sprintf("【%s】PartyNumber is nil", party.PartyName)
			return errors.ErrorCommon.WithArgs(content)
		}
		// 副签约主体“是否需要签约必须为是”且“是否需要配价必须为否”
		if party.IsDeputyParty() {
			if party.Sealed != _const.TRUE_FLAG_INT {
				return errors.ErrorCommon.WithArgs("副签约主体是否需要签约必须为是")
			}
			if party.Pricing != _const.FALSE_FLAG_INT {
				return errors.ErrorCommon.WithArgs("副签约主体是否需要配价必须为否")
			}
		}
	}
	return nil
}

// ValidateMainDeputyPartyDuplication 外部入参主副签约主体重复性校验
func (t *TradePartyInfo) ValidateMainDeputyPartyDuplication(ctx context.Context) errors.APIError {
	if t == nil {
		return nil
	}

	deputyPartyNum := make([]string, 0)
	mainPartyNum := make([]string, 0)
	for _, party := range t.OtherParty {
		if party.IsDeputyParty() {
			deputyPartyNum = append(deputyPartyNum, party.PartyNumber)
		} else {
			mainPartyNum = append(mainPartyNum, party.PartyNumber)
		}
	}
	if len(deputyPartyNum) == 0 {
		logs.CtxInfo(ctx, "无副签约主体,不进行主副签约主体重复性校验")
		return nil
	}

	// 判断副签约主体是否有重复元素
	duplicateDeputyPartyNum := util.StringListFindDuplicate(deputyPartyNum)
	if len(duplicateDeputyPartyNum) > 0 {
		logs.CtxError(ctx, "副签约主体中存在重复元素，重复元素为：%v", duplicateDeputyPartyNum)
		return errors.ErrorCommon.WithArgs("副签约主体重复")
	}

	// 判断是否有和主签约主体重复的副签约主体
	duplicateMainPartyNum := util.StringListSame(mainPartyNum, deputyPartyNum)
	if len(duplicateMainPartyNum) > 0 {
		logs.CtxError(ctx, "副签约主体中存在和主签约主体重复的元素，重复元素为：%v", duplicateMainPartyNum)
		return errors.ErrorCommon.WithArgs("副签约主体与主签约主体重复")
	}

	return nil
}

// SealOrderCheck 校验我方主体/对方主体是否需要盖章
// 先盖章方=我方先签约：我方必须存在需要签约的对象
// 先盖章方=对方先签约：对方必须存在需要签约的对象
func (t *TradePartyInfo) SealOrderCheck(sealOrder string) errors.APIError {
	if t == nil {
		return nil
	}
	if sealOrder == _const.OurSide {
		for _, party := range t.Subject {
			if party.Sealed == _const.TRUE_FLAG_INT {
				return nil
			}
		}
		return errors.ErrorCommon.WithArgs("先盖章方=我方先签约：我方必须存在需要签约的对象")
	} else if sealOrder == _const.OtherSide {
		for _, party := range t.OtherParty {
			if party.Sealed == _const.TRUE_FLAG_INT {
				return nil
			}
		}
		return errors.ErrorCommon.WithArgs("先盖章方=对方先签约：对方必须存在需要签约的对象")
	}
	return nil
}

// CheckPayTypes 银行账号信息校验
func (t *TradePartyInfo) CheckPayTypes() errors.APIError {
	if t == nil {
		return nil
	}
	for _, party := range t.Subject {
		for _, payType := range party.PayTypes {
			if len(payType.AccountNumber) == 0 {
				continue
			}
			if len(payType.OpInfoId) == 0 {
				return errors.ErrorCommon.WithArgs("银行账号ID-主数据唯一编码为空")
			}
		}
	}
	for _, party := range t.OtherParty {
		for _, payType := range party.PayTypes {
			if len(payType.AccountNumber) == 0 {
				continue
			}
			if len(payType.OpInfoId) == 0 {
				return errors.ErrorCommon.WithArgs("银行账号ID-主数据唯一编码为空")
			}
		}
	}
	return nil
}

func (t *TradePartyInfo) CheckSignData(signatureType string) error {
	if !util.StringIn(signatureType, []string{_const.SignatureDomesticElectronicSignature,
		_const.SignatureInternationalElectronicSignature}) {
		return nil
	}
	if t == nil {
		return nil
	}
	var errMsg []string
	for _, party := range t.Subject {
		if err := party.CheckSubjectSignData(signatureType); err != nil {
			errMsg = append(errMsg, fmt.Sprintf("【%s】 %s", party.PartyName, err.Error()))
		}
	}
	for _, party := range t.OtherParty {
		if err := party.CheckOtherSignData(signatureType); err != nil {
			errMsg = append(errMsg, fmt.Sprintf("【%s】 %s", party.PartyName, err.Error()))
		}
	}
	if len(errMsg) > 0 {
		return fmt.Errorf(strings.Join(errMsg, "、"))
	}
	return nil
}

func (t *TradePartyInfo) GetAllAccountID() []string {
	var res []string
	for _, party := range t.OtherParty {
		if party.Sealed == _const.TRUE_FLAG_INT {
			res = append(res, strings.Split(party.SealAccountID, ",")...)
		}
		if party.Pricing == _const.TRUE_FLAG_INT {
			res = append(res, strings.Split(party.PricingAccountID, ",")...)
		}
		res = append(res, strings.Split(party.AccountID, ",")...)
	}
	return util.SingleList(res)
}

func (t *TradePartyInfo) GetAllSealAccountID() []string {
	var res []string
	for _, party := range t.OtherParty {
		if party.Sealed == _const.TRUE_FLAG_INT {
			res = append(res, strings.Split(party.SealAccountID, ",")...)
		}
	}
	return util.SingleList(res)
}

func (t *TradePartyInfo) GetAllPricingAccountID() []string {
	var res []string
	for _, party := range t.OtherParty {
		if party.Pricing == _const.TRUE_FLAG_INT {
			res = append(res, strings.Split(party.PricingAccountID, ",")...)
		}
	}
	return util.SingleList(res)
}

func (t *TradePartyInfo) GetSealPartyName() []string {
	var res []string
	for _, party := range t.OtherParty {
		if party.Sealed == _const.TRUE_FLAG_INT {
			res = append(res, party.PartyName)
		}
	}
	return util.SingleList(res)
}

func (t *TradePartyInfo) GetPricingPartyName() []string {
	var res []string
	for _, party := range t.OtherParty {
		if party.Pricing == _const.TRUE_FLAG_INT {
			res = append(res, party.PartyName)
		}
	}
	return util.SingleList(res)
}

type DetailedInformation struct {
	AccountTimeStartPoint   string `json:"AccountTimeStartPoint"`   // 账期起算节点
	AccountTime             string `json:"AccountTime"`             // 账期
	CollectionOfPaymentTime string `json:"CollectionOfPaymentTime"` // 应回款时间
	Remark                  string `json:"Remark"`                  // 备注
}

type ReverseSignInfo struct {
	ReverseSignCode         string // 类型
	ReverseSignReason       string // 名称
	AccessKey               string // 下载id
	Bucket                  string
	TosKeys                 []ReverseSignTosData
	ActualScenarioCode      string
	RelationContractNumbers []string
}

type ReverseSignTosData struct {
	DownloadId string `json:"downloadId"`
	FileName   string `json:"fileName"`
}

type TemplateInfo struct {
	Master   *TemplateDetail    // 主模板
	Appendix TemplateDetailList // 附录模板
	Ext      map[string]string  // 模板附加信息，外部传入的一些代金券判定逻辑
}

type TemplateDetail struct {
	TemplateKey string
	Version     int `json:"TemplateVersion"`
}

type TemplateDetailList []*TemplateDetail

func (t *TemplateDetail) GenResp() *templateclient.AppendTplData {
	return &templateclient.AppendTplData{
		TemplateKey: t.TemplateKey,
		Version:     t.Version,
	}
}

func (t TemplateDetailList) GenTemplateResp() []*templateclient.AppendTplData {
	var res []*templateclient.AppendTplData
	for _, detail := range t {
		res = append(res, detail.GenResp())
	}
	return res
}

type SettlementLine struct {
	Id                         uint64 `json:"Id"`                         // 结算条款 唯一ID
	PaymentGroup               int    `json:"PaymentGroup"`               // 付款组别  合同2.8新增
	PaymentItemType            string `json:"PaymentItemType"`            // 结算类型  合同2.8废弃
	PayMethod                  int    `json:"PayMethod"`                  // 付款方式  合同2.8新增
	PaymentMethod              string `json:"PaymentMethod"`              // 结算方式  合同2.8废弃
	SettlementPeriod           int    `json:"SettlementPeriod"`           // 结算周期   合同2.8新增
	InvoicingMilepost          int    `json:"InvoicingMilepost"`          // 开票里程碑 合同2.8新增
	InvoicingMilepostFixedTime string `json:"InvoicingMilepostFixedTime"` // 开票里程碑-固定时点日期 合同2.8新增
	InvoicingPercent           string `json:"InvoicingPercent"`           // 开票比例   合同2.8新增
	InvoicingTotal             string `json:"InvoicingTotal"`             // 开票金额   合同2.8新增
	PaymentMilepost            int    `json:"PaymentMilepost"`            // 付款里程碑 合同2.8新增
	PaymentMilepostFixedTime   string `json:"PaymentMilepostFixedTime"`   // 付款里程碑-固定时点日期 合同2.8新增
	PaymentTotal               string `json:"PaymentTotal"`               // 结算金额
	PaymentPercent             string `json:"PaymentPercent"`             // 结算比例
	PaymentPeriod              int    `json:"PaymentPeriod"`              // 付款周期    合同2.8新增
	PaymentPeriodUnit          int    `json:"PaymentPeriodUnit"`          // 付款周期单位 合同2.8新增
	PaymentExplain             string `json:"PaymentExplain"`             // 结算说明     合同2.8映射为remark
	DeploymentType             int    `json:"DeploymentType"`             // 部署方式    合同2.8新增
	IsStartUp                  int    `json:"IsStartUp"`                  // 是否启动调度 线下标品&解决方案新增 已启动结算条款不允许修改
	IsUpdate                   int    `json:"IsUpdate"`                   // 是否有变更 前端标注下这条记录是否有变更
	UpdatedTime                int64  `json:"UpdatedTime"`                // 更新时间戳
}

type SettlementLines []*SettlementLine

// BusinessModeClause 商务模式条款摘要
type BusinessModeClause struct {
	Id            uint64 `json:"Id"`            // 商务模式条款摘要唯一ID
	BusinessMode  string `json:"BusinessMode"`  // 商务模式
	ClauseSummary string `json:"ClauseSummary"` // 条款摘要
	Creator       string `json:"Creator"`       // 创建人
	CreatedTime   string `json:"CreatedTime"`   // 创建时间
	Updater       string `json:"Updater"`       // 更新人
	UpdatedTime   string `json:"UpdatedTime"`   // 更新时间
}

// 风险条款条目审批人明细
type RiskClauseReviewerItem struct {
	ReviewerType int    `json:"ReviewerType"`
	Reviewer     string `json:"Reviewer"`
}

// 风险条款
type RiskClauseRole struct {
	Id                        int    // 结算条款 唯一ID
	VolcContractId            int    // meta合同元数据ID
	RiskTemplateID            int    // 风险条款模板ID
	ApproveId                 string // 审批ID
	RiskClauseType            int    // 风险条款类型
	ContractClauseNo          string // 风险条款编号
	ContractClauseDescription string // 原合同风险条款描述
	ContractClauseAnalysis    string // 原合同风险条款影响分析
	RiskLevel                 string // 风险等级
	Reviewer                  string // 风险审批人
	ClauseMeasure             string // 合同责任人评估及应对措施
	Creator                   string // 创建人
	IsDeleted                 int    // 是否已删除，1-是 0-否
	Status                    int    // 状态
	CreatedTime               string
	UpdatedTime               string
}

type RiskClauseRoleVO struct {
	Id                        int                       `json:"Id"`
	VolcContractId            int                       `json:"VolcContractId"`
	RiskTemplateID            int                       `json:"RiskTemplateID"`
	ApproveId                 string                    `json:"ApproveId"`
	RiskClauseType            int                       `json:"RiskClauseType"`
	ContractClauseNo          string                    `json:"ContractClauseNo"`
	ContractClauseDescription string                    `json:"ContractClauseDescription"`
	ContractClauseAnalysis    string                    `json:"ContractClauseAnalysis"`
	RiskLevel                 string                    `json:"RiskLevel"`
	Reviewer                  string                    `json:"Reviewer"`
	ClauseMeasure             string                    `json:"ClauseMeasure"`
	Creator                   string                    `json:"Creator"`
	IsDeleted                 int                       `json:"IsDeleted"`
	Status                    int                       `json:"Status"`
	CreatedTime               string                    `json:"CreatedTime"`
	UpdatedTime               string                    `json:"UpdatedTime"`
	Reviewers                 []*RiskClauseReviewerItem `json:"Reviewers"` // 结构化审批人列表
}

type RiskClauseRoleList []*RiskClauseRole

// SettlementInfo 结算信息
type SettlementInfo struct {
	SettlementClause        string                 `json:"SettlementClause"`
	SettlementLines         SettlementLines        `json:"SettlementLines"`
	IsContainRefundClause   string                 `json:"IsContainRefundClause"`
	DetailedInformationList []*DetailedInformation `json:"DetailedInformationList"` // 合同2.8舍弃
	IssueType               int                    `json:"IssueType"`               // 合同2.8舍弃
	IssueTime               string                 `json:"IssueTime"`               // 合同2.8舍弃
	AccountingStandard      string                 `json:"AccountingStandard"`      // 合同2.8舍弃
}

func (s *SettlementInfo) Validate(ctx context.Context) error {
	var invoicingPercentTotalInGroups = map[int]decimal.Decimal{}
	var paymentPercentTotalInGroups = map[int]decimal.Decimal{}
	var publicCloudPaymentSet = map[int]bool{}
	for _, settlement := range s.SettlementLines {
		if err := settlement.Validate(ctx); err != nil {
			logs.CtxError(ctx, "settlement_validate_fail, err:%v", err)
			return err
		}

		if settlement.DeploymentType == _const.SettlementDeploymentPublicCloud && settlement.PaymentGroup > 0 {

			if settlement.PayMethod != _const.SettlementPaymentMethodPostPay && settlement.PayMethod != _const.SettlementPaymentMethodPrePay {
				return errors.ErrRequestInvalid.WithArgs("公有云部署方式下，付款方式只能是预付费或者后付费")
			}

			key := settlement.PayMethod
			if _, ok := publicCloudPaymentSet[key]; ok {
				return errors.ErrRequestInvalid.WithArgs(i18nfmt.
					Sprintf(ctx, "公有云部署方式下，同一付款方式只能存在一行 付款方式：%v重复",
						_const.IntToPaymentMethodMap[key]))
			}
			publicCloudPaymentSet[key] = true
		}
		key := settlement.PaymentGroup
		if key == 0 {
			continue
		}
		invoicingPercentTotal, ok := invoicingPercentTotalInGroups[key]
		if !ok {
			invoicingPercentTotal = decimal.NewFromFloat(0)
		}
		paymentPercentTotal, ok := paymentPercentTotalInGroups[key]
		if !ok {
			paymentPercentTotal = decimal.NewFromFloat(0)
		}

		invoicingPercent, err := decimal.NewFromString(settlement.InvoicingPercent)
		if err != nil {
			return errors.ErrInternalError.WithArgs(err)
		}
		invoicingTotal, err := decimal.NewFromString(settlement.InvoicingTotal)
		if err != nil {
			return errors.ErrInternalError.WithArgs(err)
		}
		paymentPercent, err := decimal.NewFromString(settlement.PaymentPercent)
		if err != nil {
			return errors.ErrInternalError.WithArgs(err)
		}
		paymentTotal, err := decimal.NewFromString(settlement.PaymentTotal)
		if err != nil {
			return errors.ErrInternalError.WithArgs(err)
		}

		if invoicingPercent.LessThan(decimal.NewFromFloat(0)) || invoicingPercent.GreaterThan(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.Sprintf(ctx, "结算条款中付款组别[%v]开票比例参数不正确", key))
		}

		if invoicingTotal.IsNegative() {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]开票金额参数不正确", key))
		}

		if paymentPercent.LessThan(decimal.NewFromFloat(0)) || paymentPercent.GreaterThan(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(fmt.
				Sprintf("结算条款中付款组别[%v]付款比例参数不正确 ", key))
		}

		if paymentTotal.IsNegative() {
			return errors.ErrRequestInvalid.WithArgs(fmt.
				Sprintf("结算条款中付款组别[%v]付款金额参数不正确 ", key))
		}

		invoicingPercentTotalInGroups[key] = invoicingPercentTotal.Add(invoicingPercent)
		paymentPercentTotalInGroups[key] = paymentPercentTotal.Add(paymentPercent)

	}

	for key, total := range invoicingPercentTotalInGroups {
		if !total.Equal(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(fmt.
				Sprintf("结算条款中付款组别[%v]开票比例之和不为100 ", key))
		}
	}

	for key, total := range paymentPercentTotalInGroups {
		if !total.Equal(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(fmt.
				Sprintf("结算条款中付款组别[%v]付款比例之和不为100 ", key))
		}
	}
	return nil
}

// ProjectInfo 项目信息
type ProjectInfo struct {
	QuoteID                        string  `json:"QuoteID"`                        // 项目制报价单编号
	QuoteApprovalLink              string  `json:"QuoteApprovalLink"`              // 项目制报价流程
	ProjectCode                    string  `json:"ProjectCode"`                    // 项目编号
	ProjectApprovalLink            string  `json:"ProjectApprovalLink"`            // 项目制立项流程
	ConfigListApprovalSerialNumber string  `json:"ConfigListApprovalSerialNumber"` // 项目范围确认编号
	ConfigListApprovalLink         string  `json:"ConfigListApprovalLink"`         // 项目范围确认流程
	ProductSolutionEmail           *string `json:"ProductSolutionEmail,omitempty"` // 产解行解
	RelatedResDepartment           *string `json:"RelatedResDepartment,omitempty"` // 涉及资源方
	DeliveryStaff                  *string `json:"DeliveryStaff,omitempty"`        // 交付人员
}

func (p *ProjectInfo) genCompareString(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func (p *ProjectInfo) HasProductSolutionEmail() bool {
	return p.ProductSolutionEmail != nil && *p.ProductSolutionEmail != ""
}

func (p *ProjectInfo) GetProductSolutionEmail() string {
	if p.ProductSolutionEmail == nil {
		return ""
	}
	return *p.ProductSolutionEmail
}

func (p *ProjectInfo) HasRelatedResDepartment() bool {
	return p.RelatedResDepartment != nil && *p.RelatedResDepartment != ""
}

func (p *ProjectInfo) GetRelatedResDepartment() string {
	if p.RelatedResDepartment == nil {
		return ""
	}
	return *p.RelatedResDepartment
}

func (p *ProjectInfo) HasDeliveryStaff() bool {
	return p.DeliveryStaff != nil && *p.DeliveryStaff != ""
}

func (p *ProjectInfo) GetDeliveryStaff() string {
	if p.DeliveryStaff == nil {
		return ""
	}
	return *p.DeliveryStaff
}

func (p *ProjectInfo) EqualsDeliveryStaff(v *string) bool {
	return p.genCompareString(p.DeliveryStaff) == p.genCompareString(v)
}

func (p *ProjectInfo) EqualsProductSolutionEmail(v *string) bool {
	return p.genCompareString(p.ProductSolutionEmail) == p.genCompareString(v)
}

func (p *ProjectInfo) EqualsRelatedResDepartment(v *string) bool {
	return p.genCompareString(p.RelatedResDepartment) == p.genCompareString(v)
}

type CooperationNode struct {
	NodeName      string         `json:"NodeName"`      // 协同节点名称
	IsCurrentNode bool           `json:"IsCurrentNode"` // 是否为当前节点
	Auditors      []*AuditorInfo `json:"Auditors"`      // 审批人员列表
}

type AuditorInfo struct {
	Email          string `json:"Email"` // 审批人邮箱
	Reviewer       string // 审批人有效
	ReviewerName   string `json:"ReviewerName,omitempty"` // 审批人名称
	ReviewerID     string // 审批人ID
	ReviewerRole   int    // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP 0 其他
	ReviewerType   int    // 审批人类型
	ReviewerSource int    // 审核人登记：主审核人：0，加签审核人：1
	ContractStatus int    // 合同节点
	Priority       int    // 优先级
	Status         int    // 注意该字段展示给前端及流转过程中 可能已经过fix
}

func (a *AuditorInfo) IsAudited() bool {
	return util.IntIn(a.Status, []int{
		_const.ReviewStatusSubmitOA,     // 提交飞书合同(13)
		_const.ReviewStatusSubmitCancel, // 取消修改(12)
		_const.ReviewStatusSubmitChange, // 提交修改(11)
		_const.ReviewStatusHaveChange,   // 有修改(10)
		_const.ReviewStatusFinalized,    // 可定稿(9)
		_const.ReviewStatusReviewPass,   // 审核通过(1)
	})
}

// CooperationRecord 协同记录
type CooperationRecord struct {
	NodeName               string        `json:"NodeName"`               // 节点名称
	ContractStatus         int           `json:"ContractStatus"`         // 合同状态
	Operator               string        `json:"Operator"`               // 操作人
	OperatorName           string        `json:"OperatorName"`           // 操作人名称
	Operation              int           `json:"Operation"`              // 操作
	SecondaryOperationType int           `json:"SecondaryOperationType"` // 操作类型
	Remark                 string        `json:"Remark"`                 // 备注
	CommentID              int           `json:"CommentID"`              // 审批意见ID
	Comment                *RichTextInfo `json:"Comment"`                // 审批意见
	Extra                  string        `json:"Extra"`                  // 加签人员/转办人员
	Consignor              string        `json:"Consignor"`              // 代理人（仅飞书审批记录由此参数）
	AuditTime              string        `json:"AuditTime"`              // 操作时间
	OperateTime            string        `json:"OperateTime"`            // 操作时间
	RelatedFileVersion     string        `json:"RelatedFileVersion"`     // 合同关联文件版本信息
	SkipReturnReview       int           `json:"SkipReturnReview"`       // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重
	RecordSource           string        `json:"RecordSource"`           // 记录来源: volcano-火山协作记录, feishu-飞书审批记录
	SendBackTargetStatus   int           `json:"SendBackTargetStatus"`   // 指定退回目标节点状态
}

type FileVersionData struct {
	BizType  int    // 文件类型，0-普通附件 1-合同文本附件
	FileID   string // 文件ID
	FileName string // 文件名称
	Version  string // 文件版本
}

type CooperationRecordList []*CooperationRecord

type PreContractReviewer struct {
	ID               uint64
	Reviewer         string //
	ReviewerName     string `json:"ReviewerName,omitempty"` //
	AvatarURL        string `json:"AvatarURL,omitempty"`    //
	ReviewerID       string //
	ReviewerType     int    //
	ReviewerSource   int    // 审核人登记：主审核人：0，加签审核人：1
	ReviewerRole     int    // 审批人角色 1 销售运营 2 财务AR 3 财务BP 4 税务BP 5 法务BP 0 其他
	ContractStatus   int    // 合同节点
	Priority         int    // 优先级
	IsDeleted        int    // 是否被删除
	Status           int    // 注意该字段展示给前端及流转过程中 可能已经过fix
	SkipReturnReview int    // 是否跳过返稿重审, 0-忽略, 1-审核通过无异议, 2-修改/确认后重审
}

type PreContractReviewerList []*PreContractReviewer

// ChangeLog 变更日志
type ChangeLog struct {
}

type ContractFile struct {
	Type       string // 类型
	FileName   string // 名称
	DownloadID string // 下载id
}

type ProductInformation struct {
	Product    string // 英文名
	ZhName     string // 中文名
	IncomeCode string // 收入类型
}

type QuoteChangeInfo struct {
	RelateQuoteNo            string `json:"RelateQuoteNo"`
	RelateQuoteChanged       bool   `json:"RelateQuoteChanged"`
	RelateQuoteChangedBefore string `json:"RelateQuoteChangedBefore"`
	RelateQuoteChangedNotify bool   `json:"RelateQuoteChangedNotify"`
}

func (s SettlementLines) Validate(ctx context.Context) errors.APIError {
	var invoicingPercentTotalInGroups = map[int]decimal.Decimal{}
	var paymentPercentTotalInGroups = map[int]decimal.Decimal{}
	var publicCloudPaymentSet = map[int]bool{}
	for _, settlement := range s {
		// 已启动调度的结算条款，不允许修改
		if settlement.IsStartUp == _const.TRUE_FLAG_INT && settlement.IsUpdate == _const.TRUE_FLAG_INT {
			return errors.ErrRequestInvalid.WithArgs("结算条款已启动履约调度，不允许修改")
		}
		if err := settlement.Validate(ctx); err != nil {
			return errors.ErrorCommon.WithArgs(err.Error())
		}
		if settlement.DeploymentType == _const.SettlementDeploymentPublicCloud && settlement.PaymentGroup > 0 {

			if settlement.PayMethod != _const.SettlementPaymentMethodPostPay && settlement.PayMethod != _const.SettlementPaymentMethodPrePay {
				return errors.ErrRequestInvalid.WithArgs(i18nfmt.
					Sprintf(ctx, "公有云部署方式下，付款方式只能是预付费或者后付费"))
			}

			key := settlement.PayMethod
			if _, ok := publicCloudPaymentSet[key]; ok {
				return errors.ErrRequestInvalid.WithArgs(i18nfmt.
					Sprintf(ctx, "公有云部署方式下，同一付款方式只能存在一行 付款方式：%v重复",
						multienv.GetPaymentMethodSec(ctx, key)))
			}
			publicCloudPaymentSet[key] = true
		}
		key := settlement.PaymentGroup
		if key == 0 {
			continue
		}
		invoicingPercentTotal, ok := invoicingPercentTotalInGroups[key]
		if !ok {
			invoicingPercentTotal = decimal.NewFromFloat(0)
		}
		paymentPercentTotal, ok := paymentPercentTotalInGroups[key]
		if !ok {
			paymentPercentTotal = decimal.NewFromFloat(0)
		}

		invoicingPercent, err := decimal.NewFromString(settlement.InvoicingPercent)
		if err != nil {
			return errors.ErrorCommon.WithArgs(err)
		}
		invoicingTotal, err := decimal.NewFromString(settlement.InvoicingTotal)
		if err != nil {
			return errors.ErrorCommon.WithArgs(err)
		}
		paymentPercent, err := decimal.NewFromString(settlement.PaymentPercent)
		if err != nil {
			return errors.ErrorCommon.WithArgs(err)
		}
		paymentTotal, err := decimal.NewFromString(settlement.PaymentTotal)
		if err != nil {
			return errors.ErrorCommon.WithArgs(err)
		}

		if invoicingPercent.LessThan(decimal.NewFromFloat(0)) || invoicingPercent.GreaterThan(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]开票比例参数不正确", key))
		}

		if invoicingTotal.IsNegative() {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]开票金额参数不正确", key))
		}

		if paymentPercent.LessThan(decimal.NewFromFloat(0)) || paymentPercent.GreaterThan(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]付款比例参数不正确", key))
		}

		if paymentTotal.IsNegative() {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]付款金额参数不正确", key))
		}

		invoicingPercentTotalInGroups[key] = invoicingPercentTotal.Add(invoicingPercent)
		paymentPercentTotalInGroups[key] = paymentPercentTotal.Add(paymentPercent)

	}

	for key, total := range invoicingPercentTotalInGroups {
		if !total.Equal(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]开票比例之和不为100", key))
		}
	}

	for key, total := range paymentPercentTotalInGroups {
		if !total.Equal(decimal.NewFromFloat(100)) {
			return errors.ErrRequestInvalid.WithArgs(i18nfmt.
				Sprintf(ctx, "结算条款中付款组别[%v]付款比例之和不为100", key))
		}
	}
	return nil
}

func (s SettlementLine) Validate(ctx context.Context) error {
	if s.PaymentMilepost == _const.SettlementPaymentMilepostFixedTime {
		logs.CtxInfo(ctx, "付款里程碑为固定时点的结算条款，固定时间为：%s", s.PaymentMilepostFixedTime)
		if err := validateFixTime(ctx, s.PaymentMilepostFixedTime); err != nil {
			logs.CtxError(ctx, "固定时间校验失败， err:%v", err)
			return err
		}
	}
	if s.InvoicingMilepost == _const.SettlementInvoicingMilepostFixedTime {
		logs.CtxInfo(ctx, "开票里程碑为固定时点的结算条款，固定时间为：%s", s.InvoicingMilepostFixedTime)
		if err := validateFixTime(ctx, s.InvoicingMilepostFixedTime); err != nil {
			logs.CtxError(ctx, "固定时间校验失败， err:%v", err)
			return err
		}
	}
	return nil
}

func validateFixTime(ctx context.Context, fixTime string) errors.APIError {
	if len(fixTime) == 0 {
		logs.CtxError(ctx, "固定时间入参为空")
		return errors.ErrMissingParam.WithArgs("固定时间")
	}
	invoicingMilepostFixedTime, err := time.ParseInLocation(util.DateFormatTpl, fixTime, time.Local)
	if err != nil {
		logs.CtxError(ctx, "固定时间解析失败")
		return errors.ErrInvalidParam.WithArgs("PaymentMilepostFixedTime")
	}
	if invoicingMilepostFixedTime.IsZero() {
		logs.CtxError(ctx, "固定时间为空")
		return errors.ErrInvalidParam.WithArgs("PaymentMilepostFixedTime")
	}
	// 小于1970年的时间为异常时间
	if invoicingMilepostFixedTime.Year() < 1970 {
		logs.CtxError(ctx, "固定时间信息异常")
		return errors.ErrInvalidParam.WithArgs("PaymentMilepostFixedTime")
	}
	return nil
}

func ParseProjectInfo(s string) *ProjectInfo {
	var ret ProjectInfo
	_ = json.Unmarshal([]byte(s), &ret)
	return &ret
}

type UrgentInfo struct {
	Operator    string // 操作人
	OperateTime string // 操作时间
	UrgentCode  string // 加急类型编码
	UrgentName  string // 加急类型名称
}

type ExpireRemindInfo struct {
	ExpireRemindFlag int    // 合同到期后是否发送提醒，0-发送，1-不发送
	NoRemindType     int    // 不再提醒类型枚举
	NoRemindTypeSec  string // 不再提醒类型枚举文字展示
	NoRemindReason   string // 不再提醒具体原因
}

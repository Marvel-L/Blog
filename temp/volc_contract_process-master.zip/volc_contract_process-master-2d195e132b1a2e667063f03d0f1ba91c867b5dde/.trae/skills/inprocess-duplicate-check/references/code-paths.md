
### 在途合同判重 (`productKey`)

- **判重模型定义**:
    - `biz/service/salescontract/productkey/models.go`: `ProductInfo`

- **模型转换函数**:
    - `biz/bizmodels/meta_common.go`: `func ConvertProductKeyInfo(...)`
    - **调用点检查**:
        - `biz/service/contractmeta/check_inprocess_commodity_repeat.go`
        - `biz/service/salescontract/create_or_update.go`

- **Key 生成函数**:
    - `biz/service/salescontract/productkey/api.go`: `func genKeyVersionX(...)` (找到版本号最大的函数进行修改)

### 合同价系统判重 (`discountKey`)

- **Key 生成函数**:
    - `biz/bizmodels/meta_common.go`: `func (p *ProductInfo) ConvertContractDiscount(...) *ContractDiscount`

- **与合同价交互点 (辅助排查)**:
    - `pkg/proxy/pricecli/api.go`: `getRepeatInfo` 等函数中对 `discountKey` 的使用。

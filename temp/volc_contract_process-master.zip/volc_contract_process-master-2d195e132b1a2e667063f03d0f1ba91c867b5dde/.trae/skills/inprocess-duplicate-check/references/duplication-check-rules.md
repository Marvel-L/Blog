
## 参与判重的字段规则

判重操作必须使用**稳定且唯一**的编码类字段 (`Code`)。

| 字段 Code (`ProductInfo`) | 是否参与 `productKey` | 是否参与 `discountKey` | 备注                                 |
| ------------------------- | --------------------- | ---------------------- | ------------------------------------ |
| `TradeProduct`            | 是                    | 是                     |                                      |
| `ConfigCategory`          | 是                    | 是                     |                                      |
| `Configuration`           | 是                    | 是                     |                                      |
| `BillingMethodCode`       | 是                    | 是                     |                                      |
| `RegionCode`              | 是                    | 是                     |                                      |
| `ChargeElementCode`       | 是                    | 是                     |                                      |
| `PriceFactorCode`         | 是                    | 是                     |                                      |
| `ChargeItemCode`          | 是                    | 是                     |                                      |
| `ChargeItemTag`           | 是                    | 是                     |                                      |
| `PrePayRatioCode`         | **是 (新增)**         | **是 (新增)**          | 使用 `PrePayRatioCode` 而非 `PrePayRatio`。 |
| `SpBuyDurationCode`       | **是 (新增)**         | **是 (新增)**          | 使用 `SpBuyDurationCode`。             |
| `CommitFeeIntervalCode`   | **是 (新增)**         | **是 (新增)**          | 使用 `CommitFeeIntervalCode`。         |
| ...                       | ...                   | ...                    |                                      |

**关键原则**：任何影响商品最终价格或履约方式的业务维度，都应被纳入判重范围。

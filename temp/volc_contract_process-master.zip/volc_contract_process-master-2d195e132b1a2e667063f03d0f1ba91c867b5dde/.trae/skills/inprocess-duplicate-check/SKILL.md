---
name: inprocess-duplicate-check
description: 当新增的报价项字段需要作为区分不同商品/优惠的唯一标识，并参与在线协同流程中的“在途合同商品行判重”时，使用本技能。
---

# 技能：在途合同判重 (inprocess-duplicate-check)

## 1. 场景与目标

**何时使用**：当新增的报价项字段需要作为区分不同商品/优惠的唯一标识，并参与在线协同流程中的“在途合同商品行判重”时，使用本技能。

**核心目标**：将新增字段安全地整合到判重 key (`discountKey`, `productKey`) 的生成逻辑中，确保具有不同核心属性（如不同预付比例、不同购买时长）的相同商品被视为独立的报价项，避免误判为重复。

## 2. 准入与准出标准

### 准入标准
- [ ] 已完成 `quote-field-onboarding` 技能，新增字段已在 `ProductInfo` (`biz/bizmodels/meta_common.go`) 模型中可用。
- [ ] 已明确哪些新增字段需要参与判重（通常是 Code 结尾的编码字段）。

### 准出标准
- [ ] `biz/service/salescontract/productkey/models.go` 中的 `ProductInfo` 结构体已添加用于判重的新字段。
- [ ] `biz/bizmodels/meta_common.go` 中的 `ConvertProductKeyInfo` 函数已更新，完成从 `bizmodels.ProductInfo` 到 `productkey.ProductInfo` 的字段映射。
- [ ] `biz/service/salescontract/productkey/api.go` 中的 `genKeyVersionX` (X为当前最新版本) 函数已更新，将新字段的 Code 值拼接进最终的 `productKey`。
- [ ] `biz/bizmodels/meta_common.go` 中的 `ConvertContractDiscount` 函数已更新，将新字段的 Code 值拼接进 `discountKey`。

## 3. 操作指南

### 步骤 1：扩展判重专用模型
- **文件路径**：`biz/service/salescontract/productkey/models.go`
- **目标**：在判重逻辑专用的 `ProductInfo` 结构体中，加入新增字段。
- **示例**:
    ```go
    type ProductInfo struct {
        // ... (原有字段)
        PriceFactorCode       string
        ChargeItemTag         string
        PrePayRatioCode       string // [新增]
        SpBuyDurationCode     string // [新增]
        CommitFeeIntervalCode string // [新增]
    }
    ```

### 步骤 2：更新模型转换函数
- **文件路径**：``biz/bizmodels/meta_common.go`
- **目标**：在 `ConvertProductKeyInfo` 函数中，将主业务模型 `bizmodels.ProductInfo` 的新增字段值，赋给判重专用模型 `productkey.ProductInfo`。
- **示例**:
    ```go
    // biz/service/salescontract/productkey/api.go
    func ConvertProductInfo(bizProductInfo *bizmodels.ProductInfo) *ProductInfo {
        // ...
        return &ProductInfo{
            // ... (原有映射)
            PriceFactorCode:       bizProductInfo.PriceFactorCode,
            ChargeItemTag:         bizProductInfo.ChargeItemTag,
            PrePayRatioCode:       bizProductInfo.PrePayRatioCode,       // [新增]
            SpBuyDurationCode:     bizProductInfo.SpBuyDurationCode,     // [新增]
            CommitFeeIntervalCode: bizProductInfo.CommitFeeIntervalCode, // [新增]
        }
    }
    ```
- **注意**：检查调用 `ConvertProductKeyInfo` 的所有地方，如 `biz/service/contractmeta/check_inprocess_commodity_repeat.go` 和 `biz/service/salescontract/create_or_update.go`，确保新字段能够正确传递。

### 步骤 3：更新 ProductKey 生成逻辑
- **文件路径**：`biz/service/salescontract/productkey/api.go`
- **目标**：在最新的 `genKeyVersionX` 函数中，将新增字段（通常是 `Code` 值）拼接到生成的 `productKey` 字符串中。
- **示例**:
    ```go
    // biz/service/salescontract/productkey/api.go
    func genKeyVersion4(info *ProductInfo) string { // 假设当前最新是 v4
        // ...
        key := fmt.Sprintf("%s_%s_%s_%s_%s_%s",
            // ... (原有字段)
            info.ChargeItemTag,
            info.PrePayRatioCode,       // [新增]
            info.SpBuyDurationCode,     // [新增]
            info.CommitFeeIntervalCode, // [新增]
        )
        return key
    }
    ```

### 步骤 4：更新 DiscountKey 生成逻辑
- **文件路径**：`biz/bizmodels/meta_common.go`
- **目标**：在 `ProductInfo.ConvertContractDiscount` 函数中，将新增字段（通常是 `Code` 值）拼接到 `discountKey` 中。此 Key 主要用于与合同价系统交互时的判重。
- **示例**:
    ```go
    // biz/bizmodels/meta_common.go
    func (p *ProductInfo) ConvertContractDiscount(...) *ContractDiscount {
        // ...
        discountKey := fmt.Sprintf("%v%v%v%v%v%v%v%v%v%v%v%v", 
            p.TradeProduct, p.ConfigCategory, p.Configuration, 
            p.BillingMethodCode, p.RegionCode, p.ChargeElementCode, 
            p.PriceFactorCode, p.ChargeItemCode, p.ChargeItemTag,
            p.PrePayRatioCode,       // [新增]
            p.SpBuyDurationCode,     // [新增]
            p.CommitFeeIntervalCode, // [新增]
        )
        // ...
    }
    ```

## 4. 常见差错与护栏

- **错误：使用了展示值 (`Name`) 而不是编码值 (`Code`) 进行判重**
    - **护栏**：判重 Key 必须使用稳定、唯一的编码字段（如 `PrePayRatioCode`），绝不能使用可能会变更或被翻译的展示值（如 `PrePayRatio`）。

- **错误：Key 拼接顺序不一致**
    - **护栏**：`productKey` 和 `discountKey` 的字段拼接顺序必须严格固定。新增字段应追加在末尾，避免影响历史数据的判重逻辑。

- **错误：只修改了 `productKey` 而遗漏了 `discountKey`（或反之）**
    - **护栏**：在途合同判重 (`productKey`) 和合同价系统判重 (`discountKey`) 是两个独立的逻辑，但通常依赖同一组字段。必须确保两处的 Key 生成逻辑同步修改。使用 `references/code-paths.md` 进行核对。

- **错误：判重 Key 版本未升级**
    - **护栏**：如果判重逻辑发生重大变更（例如，改变了字段顺序或格式），应考虑创建新的 `genKeyVersionX+1` 函数，并逐步迁移，以保证向后兼容。对于仅在末尾追加字段的场景，通常无需升级版本号。
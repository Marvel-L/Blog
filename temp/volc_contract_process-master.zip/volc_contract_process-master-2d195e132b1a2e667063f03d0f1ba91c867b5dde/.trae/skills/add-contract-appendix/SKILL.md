---
name: add-contract-appendix
description: 用于新增合同附录场景，包含新增合同附录流程以及根据业务条件判断主模板是否关联本次新增的附录。
---

# 新增合同附录标准化开发指南

## 1. 目的与适用范围

本文档旨在为火山合同系统（`volc_contract_process`）的“新增合同附录”类需求提供一套标准化的开发流程和最佳实践。目标是将该重复性需求抽象为清晰、可执行的步骤，指导 `coding agent` 高效、准确地完成开发、测试和上线工作。

本指南适用于以下场景：
*   根据新的业务规则，需要向现有合同主模板动态添加新的附录模板。
*   修改已有附录的挂载逻辑，例如变更触发条件。

## 2. 触发词与使用场景

- 典型触发词（用户话术示例）
  - “新增一个合同附录”/“为主模板新增附录”/“主模板后拼接某附录”
  - “当满足某条件时，关联某合同附录”
  - “修改已有合同附录判断是否拼接的逻辑”
  - “新增某合同附录（新增附录）”

- 适用场景
  - 新增一个合同模板，需要根据业务条件判断是否拼接该模板的附录。
  - 依据 PRD 的业务触发条件，决定是否在合同主模板后动态挂载附录模板（判定由 `AppendHandler` 完成）。

- 不适用场景（边界）
  - 纯模板文案/版式修改，不涉及判定逻辑与附录挂载（应走模板管理流程）。
  - 新建一个“主模板系列”或调整主模板整体生成流程（非“附录”范畴）。
  - 仅针对海外 BytePlus 的差异化需求：若未在模板后台为海外主模板配置该附录的 `AppendTpl`，不应通过代码强行区分，保持“同代码、配置隔离”的原则。

## 3. 核心概念解析

在深入流程之前，理解以下几个核心概念至关重要：

*   **`AppendHandler`**：附录处理器的接口。每个需要动态挂载的附录都应实现此接口。它定义了附录的模板唯一标识（`TemplateKey`）、依赖的合同附加信息Key（`ExtKey`）以及是否拼接的判定逻辑（`IsAppendTemplate`）。
*   **附录判定引擎**：位于 `biz/service/template/engine.go`，是合同生成时决定加载哪些附录的核心服务。它会遍历主模板在“模板管理后台”配置的所有附录 `AppendTpl` 列表，并调用每个附录 `TemplateKey` 对应的 `AppendHandler` 来判断是否满足挂载条件。
*   **`extMap`** (`map[string]string`)：合同元数据扩展信息。它存储了从上游（如报价系统）传递来的、经过加工的业务数据，以 `JSON` 字符串的形式保存在数据库 `volc_contract_meta_ext` 表中。`AppendHandler` 的判定逻辑主要依赖此 `map` 中的数据。
*   **`templateExt`** (`map[string]string`)：合同模板的瞬时扩展信息。它主要用于在创建或更新合同时，由外部调用方（如 CRM）临时传入一些用于判定或替换的参数，这些参数通常不落库。例如，是否勾选了某个附录的场景。
*   **模板变量替换 (`templatereplace`)**：当附录模板中包含需要动态填充的变量（如业务联系人、邮箱地址等）时，需要实现 `biz/service/templatereplace/handler` 下的 `ReplaceHandler` 接口。该机制会在模板渲染前，根据变量名（`FieldCode`）调用对应的处理器，获取并填充实际数据。当新增模板中不涉及新参数时，不涉及此操作。

## 4. 标准化开发流程

新增一个合同附录的开发工作应遵循以下si个阶段。

### 阶段一：前置分析与校验

1.  **需求解读**：仔细阅读 `PRD` 文档，明确新增/变更的附录，以及附录的触发条件。
    *   **示例（聚合平台特别条款）**：新增“聚合平台优惠补充附录”，当报价单的“项目属性”(`ProjectAttributes`) 包含“大模型聚合平台”时，需要挂载该附录。
2.  **模板系统确认**：根据对新附录的作用的理解，为新附录设置唯一标识（`TemplateKey`）。
    *   **示例**：“聚合平台优惠补充附录”的 `TemplateKey` 为 `tpl_aggregation`。
3.  **扩展键（`ExtKey`）选择**：分析触发条件所需的数据来源，从 `pkg/const/meta_ext_key.go` 中选择一个最合适的 `ExtKey`。该 `ExtKey` 对应的数据（来自 `extMap`）应包含判定所需的所有字段。
    *   **原则**：优先复用已有的 `ExtKey`。如果现有 `ExtKey` 均不满足，才考虑与上游系统（如报价）协作新增。
    *   **示例**：“项目属性”(`ProjectAttributes`) 字段包含在 `QuoteBizInfoBase` 这个扩展信息中，因此选择 `ExtKeyQuoteBizinfoBase` 作为判定的数据源。

### 阶段二：代码实现

1.  **定义模板常量**
    *   在 `pkg/const/template.go` 文件中，于 `TemplateKey` 常量组中添加新的附录模板 `Key`。

    ```go
    // pkg/const/template.go

    const (
    	// ... 其他模板 Key
    	TemplateKeyAggregation = "tpl_aggregation" // 新增大模型聚合平台特别条款
    )
    ```

2.  **创建附录处理器 (`AppendHandler`)**
    *   在 `biz/service/template/handler/` 目录下，创建一个新的 Go 文件，命名规范为 `Append<业务名>Handler.go`。例如：`AppendAggregationHandler.go`。
    *   在该文件中，定义一个新的结构体，并实现 `handler.AppendHandler` 接口。

    **代码示例：`AppendAggregationHandler.go`**
    ```go
    package handler

    import (
    	"encoding/json"
    	"strings"

    	"code.byted.org/gopkg/context"
    	"code.byted.org/gopkg/logs"
    	"volc_contract_process/biz/bizmodels"
    	_const "volc_contract_process/pkg/const"
    	"volc_contract_process/pkg/util"
    )

    func NewAppendAggregationHandler() AppendHandler {
    	return &appendAggregationHandler{}
    }

    type appendAggregationHandler struct {
    	HandlerCommon
    }

    // TemplateKey 返回此 Handler 负责处理的附录模板 Key
    func (h *appendAggregationHandler) TemplateKey() []string {
    	return []string{_const.TemplateKeyAggregation}
    }

    // ExtKey 返回判定逻辑所依赖的数据在 extMap 中的 Key
    func (h *appendAggregationHandler) ExtKey() string {
    	return _const.ExtKeyQuoteBizinfoBase
    }

    // IsAppendTemplate 核心判定逻辑
    func (h *appendAggregationHandler) IsAppendTemplate(ctx context.Context, extMap, templateExt map[string]string) (bool, error) {
    	// 1. 从 extMap 中获取依赖的数据
    	value, ok := extMap[h.ExtKey()]
    	if !ok {
    		logs.CtxWarn(ctx, "IsAppendTemplate(Aggregation): extMap does not contain key %s", h.ExtKey())
    		return false, nil // 数据不存在，不挂载
    	}

    	// 2. 反序列化 JSON 数据到结构体
    	var quoteBizInfo bizmodels.QuoteBizInfo
    	if err := json.Unmarshal([]byte(value), &quoteBizInfo); err != nil {
    		logs.CtxError(ctx, "IsAppendTemplate(Aggregation): failed to unmarshal QuoteBizInfo, err: %v", err)
    		return false, err // 数据格式错误，返回错误
    	}

    	// 3. 执行业务逻辑判断
    	attributes := strings.Split(quoteBizInfo.ProjectAttributes, ",")
    	if util.StringIn(_const.ProjectAttributesAggregationPlatform, attributes) {
    		return true, nil // 条件满足，挂载附录
    	}

    	return false, nil // 条件不满足，不挂载
    }
    ```

3.  **注册附录处理器**
    *   打开 `biz/service/template/handler/init.go` 文件。
    *   在 `AllHandler()` 函数返回的切片中，添加新创建的 `Handler` 实例。

    ```go
    // biz/service/template/handler/init.go

    func AllHandler() []AppendHandler {
    	return []AppendHandler{
    		// ... 已有处理器
    		NewAppendCouponConfigHandler(),
    		NewAppendCreditConfigHandler(),
    		NewAppendGuaranteeHandler(),
    		// 在末尾添加新的处理器
    		NewAppendAggregationHandler(),
    	}
    }
    ```

### 阶段三：模板变量替换（如需）

如果附录模板中包含需动态填充的变量，例如 `{{.OperatorEmail}}`，则需要实现变量替换处理器。

1.  **分析变量**：根据 PRD 确定变量的含义和数据来源。
    *   **示例**：附录需要填充“业务执行人邮箱”。
2.  **查找或创建 `ReplaceHandler`**：
    *   首先在 `biz/service/templatereplace/handler/` 目录下查找是否已存在能满足需求的 `ReplaceHandler`。
    *   **示例**：查找发现 `operator_email.go` 中已实现 `NewReplaceOperatorEmailHandler`，其 `FieldCode()` 为 `OperatorEmail`，可以直接获取当前合同的业务执行人邮箱。
    *   如果不存在，则参考 `operator.go` 或 `operator_email.go` 的实现，创建一个新的 `ReplaceHandler`，并在 `biz/service/templatereplace/handler/init.go` 中注册。

### 阶段四：本地测试与验收

1.  **编写单元测试**：
    *   为新增的 `AppendHandler` 编写单元测试是**强制要求**。
    *   在 `biz/service/template/handler/` 目录下创建 `Append<业务名>Handler_test.go` 文件。
    *   测试用例应覆盖所有分支：
        *   `extMap` 不包含 `ExtKey` 的场景。
        *   `extMap` 中数据 `JSON` 格式错误的场景。
        *   业务条件满足（应返回 `true`）的场景。
        *   业务条件不满足（应返回 `false`）的场景。
    *   使用 `mockey` 框架模拟依赖。

    **UT 示例要点：`AppendAggregationHandler_test.go`**
    ```go
    func Test_appendAggregationHandler_IsAppendTemplate(t *testing.T) {
        // ... (上下文与 mock 定义)

        // Case 1: extMap 中缺少 ExtKey
        Convey("When extMap does not contain the required key", func() {
            extMap := make(map[string]string)
            result, err := handler.IsAppendTemplate(ctx, extMap, nil)
            So(err, ShouldBeNil)
            So(result, ShouldBeFalse)
        })

        // Case 2: 满足挂载条件
        Convey("When ProjectAttributes contains AggregationPlatform", func() {
            bizInfo := bizmodels.QuoteBizInfo{ProjectAttributes: "7"} // "7" 是 ProjectAttributesAggregationPlatform
            bizInfoJSON, _ := json.Marshal(bizInfo)
            extMap := map[string]string{
                _const.ExtKeyQuoteBizinfoBase: string(bizInfoJSON),
            }
            result, err := handler.IsAppendTemplate(ctx, extMap, nil)
            So(err, ShouldBeNil)
            So(result, ShouldBeTrue)
        })

        // Case 3: 不满足挂载条件
        Convey("When ProjectAttributes does not contain AggregationPlatform", func() {
            bizInfo := bizmodels.QuoteBizInfo{ProjectAttributes: "1"} // "1" 是其他属性
            // ... (省略)
            result, err := handler.IsAppendTemplate(ctx, extMap, nil)
            So(err, ShouldBeNil)
            So(result, ShouldBeFalse)
        })
    }
    ```
2.  **本地联调**：如有条件，可本地启动服务，通过 `Swagger` 或 `cURL` 调用相关接口，构造包含 `extMap` 和 `templateExt` 的请求，验证附录是否按预期挂载。

## 5. 标准化开发流程
- 附录顺序以模板后台的 AppendTpl 列表顺序为准；handler 注册顺序不影响拼接顺序。判定引擎会按主模板配置的附录键逐一调用对应 AppendHandler。
- 新增附录必须在 biz/service/template/handler/init.go 注册；否则主模板已配置该 TemplateKey 时，引擎会报错（缺少该附录的判定配置）。
- 每个 TemplateKey 仅注册一个 AppendHandler：同一 TemplateKey 下以 ExtKey 作为键保存处理器，重复会报错；且引擎对该 TemplateKey 只取一个 AppendHandler 并直接返回，注册多个会产生不可预期行为。复杂条件请在单个 Handler 内部判断。
- extMap 数据必须为合法 JSON；反序列化失败将导致整体模板构建失败。对“可选字段”的场景应优先采用“缺失→返回 false, nil”的降级策略；对“必要字段”严格校验并返回 error。
- 谨慎使用 templateExt：它是合同生成过程的瞬时入参，不建议入库。某些附录（如代金券）需要依赖 templateExt 中的标志位（例如 _const.CouponAppendFlag），缺少或为空会判定失败。
- 站点差异：遵循“同代码、配置隔离”的原则。BytePlus 等站点如不需挂载某附录，只需不在该站点的主模板 AppendTpl 中配置该 TemplateKey，无需在代码中硬编码站点分支。
- 命名与常量：TemplateKey 建议使用 tpl_xxx 小写风格；ExtKey 使用语义清晰的驼峰命名，并统一在 pkg/const 下维护，避免与现有常量冲突。
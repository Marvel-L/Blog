---
name: add-template-replace
description: "为合同模板新增一个自定义的可替换参数"
---

## 简介

本 Skill 用于在火山引擎合同流程服务（`volc_contract_process`）中，新增一个合同模板的动态替换参数。

合同模板中常包含如 `{{.Operator}}` 或 `{{.CommodityList}}` 等占位符，这些占位符在合同生成时，会由后端服务动态查询并替换为实际值。每一个占位符都对应一个 `ReplaceHandler` 实现。

本指南将覆盖从参数设计、代码实现、单元测试到最终注册的全过程。

### 适用场景

- 需要在火山引擎的电子合同模板中增加新的动态字段（例如：新的业务负责人信息、特定的产品条款、动态计算的日期等）。
- 新增的字段值需要通过查询数据库、调用 RPC 服务或基于现有合同数据计算得出。

### 触发时机

- 当需要在合同模板中添加一个新的占位符 `{{.NewParameter}}` 并实现其取值逻辑时。

## 输入与输出说明

- **输入**:
    - `FieldCode (string)`: 新参数的唯一标识符，必须与合同模板中的占位符名称（`{{.FieldName}}` 中的 `FieldName`）完全一致，遵循大驼峰命名法。
    - `FieldType (string)`: 参数的渲染类型，决定了该参数在合同文本上的展示方式。
- **输出**:
    - 实现 `ReplaceHandler` 接口的 Go 源文件。
    - 更新后的 `init.go` 注册文件。
    - 对应的单元测试文件。

## 执行步骤与校验

### 步骤 1：设计参数

在开始编码前，首先明确新参数的 `FieldCode` 和 `FieldType`。

1.  **确定 `FieldCode`**:
    - 这是参数的唯一标识，与合同模板中的占位符 `{{.YourFieldCode}}` 对应。
    - 必须使用**大驼峰命名法** (Upper Camel Case)，例如 `MyNewParam`。

2.  **选择 `FieldType`**:
    - `FieldType` 决定了参数值的渲染形式。根据需求从 `volc_contract_process/pkg/const/template.go` 文件中选择一个合适的类型常量。
    - **文本型 (`_const.TEMPLATE_REPLACE_TYPE_TEXT`)**:
        - 用于返回单个字符串、数字或日期等简单文本。
        - 适用于如“经办人姓名”、“合同编号”、“生效日期”等场景。
    - **表格型 (`_const.TEMPLATE_REPLACE_TYPE_TABLE`)**:
        - 用于返回结构化的二维数据，如产品列表、费用明细等。
        - 返回值需要是 `*bizmodels.TableReplaceData` 类型。
    - 其他类型如 `datePicker`, `inputNumber` 等，遵循 `const` 包中的定义。

### 步骤 2：新增 Handler 实现文件

1.  **创建文件**:
    - 在 `biz/service/templatereplace/handler/` 目录下创建一个新的 Go 文件。
    - 文件名应为 `FieldCode` 的**下划线小写**形式。例如，`FieldCode` 为 `MyNewParam`，则文件名为 `my_new_param.go`。

2.  **编写代码骨架**:
    - 新文件需要实现 `ReplaceHandler` 接口，包含 `FieldCode()`, `FieldType()`, `Process()` 三个方法。
    - 提供一个公开的构造函数，例如 `NewReplaceMyNewParamHandler()`。

#### 代码骨架：文本型 (Text)

以下是一个返回文本类型参数的最小可用示例。它模拟了从 `data` 中获取某个 ID，然后调用外部服务获取名称的过程。

```go
// biz/service/templatereplace/handler/my_new_param.go

package handler

import (
    "code.byted.org/gopkg/context"
    "code.byted.org/gopkg/logs"

    "volc_contract_process/biz/bizmodels"
    _const "volc_contract_process/pkg/const"
    "volc_contract_process/pkg/errors"
    "volc_contract_process/pkg/proxy/larkc" // 示例：假设需要调用 Lark 服务
)

// NewReplaceMyNewParamHandler 创建一个新的 MyNewParam 处理器
func NewReplaceMyNewParamHandler() ReplaceHandler {
    return &replaceMyNewParamHandler{}
}

type replaceMyNewParamHandler struct {
    HandlerCommon
}

// FieldCode 返回参数的唯一标识符
func (h *replaceMyNewParamHandler) FieldCode() string {
    return "MyNewParam" // 必须与模板占位符 {{.MyNewParam}} 一致
}

// FieldType 返回参数的渲染类型
func (h *replaceMyNewParamHandler) FieldType() string {
    return _const.TEMPLATE_REPLACE_TYPE_TEXT
}

// Process 是核心处理逻辑，用于获取参数的实际值
func (h *replaceMyNewParamHandler) Process(ctx context.Context, data *bizmodels.ContractFullData) (interface{}, errors.APIError) {
    // 1. 从 data 中获取必要的输入信息，例如某个关联ID
    if data.Operator == "" {
        return nil, errors.ErrorCommon.WithArgs("缺少必要信息，例如业务经办人ID")
    }

    // 2. 调用下游服务或执行业务逻辑
    // 示例：根据经办人ID获取其部门信息
    employee, err := larkc.GetEmployeeByIDWithCache(ctx, data.Operator)
    if err != nil {
        logs.CtxError(ctx, "获取员工信息失败, employee_id: %s, err: %v", data.Operator, err)
        // 注意：不要将内部错误信息直接暴露给用户
        return nil, errors.ErrorCommon.WithArgs("查询经办人信息失败")
    }
    if employee == nil {
        return nil, errors.ErrorCommon.WithArgs("未找到经办人信息")
    }

    // 3. 返回最终的字符串结果
    return employee.DepartmentPath, nil
}
```

#### 代码骨架：表格型 (Table)

以下是一个返回表格类型参数的最小可用示例。它构造了一个包含多行多列数据的表格。

```go
// biz/service/templatereplace/handler/my_product_list.go

package handler

import (
    "code.byted.org/gopkg/context"
    "code.byted.org/gopkg/logs"

    "volc_contract_process/biz/bizmodels"
    _const "volc_contract_process/pkg/const"
    "volc_contract_process/pkg/errors"
    "volc_contract_process/pkg/proxy/quotecli" // 示例：假设需要调用报价服务
)

// NewReplaceMyProductListHandler 创建一个新的 MyProductList 处理器
func NewReplaceMyProductListHandler() ReplaceHandler {
    return &replaceMyProductListHandler{}
}

type replaceMyProductListHandler struct {
    HandlerCommon
}

func (h *replaceMyProductListHandler) FieldCode() string {
    return "MyProductList"
}

func (h *replaceMyProductListHandler) FieldType() string {
    return _const.TEMPLATE_REPLACE_TYPE_TABLE
}

func (h *replaceMyProductListHandler) Process(ctx context.Context, data *bizmodels.ContractFullData) (interface{}, errors.APIError) {
    if data.RelateQuoteNo == "" {
        return nil, errors.ErrorCommon.WithArgs("合同未关联报价单")
    }

    bizInfo, err := quotecli.GetQuoteBizInfoByQuoteNo(ctx, data.RelateQuoteNo)
    if err != nil {
        logs.CtxError(ctx, "获取报价信息失败, quote_no: %s, err: %v", data.RelateQuoteNo, err)
        return nil, errors.ErrInvalidParam.WithArgs("获取报价信息失败")
    }
    if bizInfo == nil || len(bizInfo.QuoteItems) == 0 {
        return nil, errors.ErrorCommon.WithArgs("报价单中无产品信息")
    }

    // headerMapList 是最终要渲染的表格数据
    var headerMapList []map[string][]interface{}

    for _, item := range bizInfo.QuoteItems {
        // headerMap 对应表格的一行数据
        headerMap := make(map[string][]interface{})

        // 模板中的列名 (如 {{range .MyProductList}}{{.ProductName}}{{end}} )
        // 对应这里的 map key ("ProductName")
        headerMap["ProductName"] = []interface{}{item.ProductName}
        headerMap["Config"] = []interface{}{item.Config}
        headerMap["Discount"] = []interface{}{item.Discount}

        // 一个单元格内可以有多行文本，通过 `[]interface{}` 实现
        headerMap["Description"] = []interface{}{
            "规格: " + item.Config,
            "地域: " + item.Region,
        }

        headerMapList = append(headerMapList, headerMap)
    }

    return &bizmodels.TableReplaceData{
        TableData: headerMapList,
    }, nil
}
```

### 步骤 3：注册 Handler

打开 `biz/service/templatereplace/handler/init.go` 文件，在 `AllHandler()` 函数返回的切片中，找到合适的分组，添加新的 Handler 构造函数。

```go
// biz/service/templatereplace/handler/init.go

func AllHandler() []ReplaceHandler {
    return []ReplaceHandler{
        // text
        NewReplaceBankNoHandler(),
        NewReplaceBranchNameHandler(),
        // ... 其他 text 类型的 handler

        // people 信息
        NewReplaceOperatorHandler(),
        NewReplaceOperatorEmailHandler(),
        NewReplaceMyNewParamHandler(), // <--- 在此添加新的文本型 Handler

        // ...

        // table
        NewReplaceCommodityListHandler(),
        NewReplaceCouponListHandler(),
        NewReplaceMyProductListHandler(), // <--- 在此添加新的表格型 Handler
    }
}
```

> **注意**: 请将你的 Handler 放入最符合其业务含义的分组中。如果无特定分组，文本型可放入 `// text`，表格型放入 `// table`。

## 质量规范与注意事项

- **错误处理**: `Process` 方法中遇到的所有错误都应通过 `logs.CtxError` 详细记录，但返回给上层的 `errors.APIError` 不应泄露底层实现细节和敏感信息。统一使用 `errors.ErrorCommon.WithArgs("对用户友好的错误提示")`。
- **日志**: 关键步骤和错误场景必须有日志。日志信息应包含关键上下文，如 `contract_no`, `quote_no` 等，便于问题排查。
- **缓存使用**: 对于会被频繁调用且数据短时间内不变的外部依赖（如查询用户信息），应考虑使用 `handler` 包中提供的 `_cache` 实例进行缓存。参考 `handler/api.go` 中的 `GetCreditConfigFromCache` 实现。
- **兼容老版本模板**: 如果新参数的逻辑与旧版模板不兼容，可以使用 `handler.IsOldVersion(ctx, tplKey, version, fieldCode)` 函数进行判断，并为新旧版本提供不同的实现。具体可参考 `commodity_list.go` 中的 `Process` 方法。
- **国际化/多语言**: 如果返回的文本需要支持多语言，请使用 `multienv.I18nFormat(ctx, "key")` 进行处理，而不是硬编码中文字符串。
- **命名约定**: 严格遵守 `FieldCode` (大驼峰) 和 `handler` 文件名 (小写下划线) 的命名约定。
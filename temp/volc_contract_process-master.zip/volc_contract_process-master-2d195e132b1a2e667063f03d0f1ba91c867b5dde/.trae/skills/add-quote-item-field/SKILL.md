---
name: add-quote-item-field
description: "当上游报价系统报价项中增加了新的字段，且该字段需要在合同系统内进行**模型承接**并**持久化到数据库**时，使用本统一技能。"
---

# 技能：承接报价字段并完成数据库持久化 (add-quote-item-field)

## 1. 场景与目标

**何时使用**：当上游报价系统（Quote）的核心接口（如 `GetQuoteContractReq`）新增了报价项（`QuoteItem`）字段，且该字段需要在合同系统内进行**模型承接**并**持久化到数据库**时，使用本统一技能。

**核心目标**：在一个流程中，以“配置驱动”的方式，完成从上游字段的**模型映射**到**数据库和 DAL 层的扩展**，确保数据能够被合同系统正确地接收、解析、存储和读取，为后续的判重、展示等流程打下坚实基础。

## 2. 准入与准出标准

### 准入标准

- [ ] 已明确上游报价接口（`GetQuoteContractReq`）的新增字段定义，包括**确切名称、数据类型、枚举值**等。
- [ ] 已根据 `references/config-template.md` 模板，填写了新增字段的完整配置。
- [ ] 已明确数据库持久化需求，包括目标表（通常是 `volc_contract_commodity`）和列的命名规范。

### 准出标准

- [ ] **模型与映射**：
    - [ ] `biz/bizmodels/biz_quote.go` 中的 `QuoteItem` 结构体已添加新字段。
    - [ ] `biz/bizmodels/meta_common.go` 中的 `ProductInfo` 结构体已添加新字段。
    - [ ] 映射函数 `QuoteItem.GenProductInfo` 和 `ProductInfo.GenQuoteDiscount` 已更新，确保字段在模型间正确传递。
- [ ] **数据库与 DAL**：
    - [ ] `references/schema-changes.sql` 中已包含完整的 `ALTER TABLE` 语句。
    - [ ] `biz/dal/model/contract_manage_info.go` 中的 `VolcContractCommodity` GORM 模型已扩展。
    - [ ] DAL 层的双向转换函数 `ConvertCommodity`（写）和 `GenProductInfo`（读）已同步更新。
- [ ] **编译与测试**：
    - [ ] 所有相关改动均已通过编译 (`go build ./...`)。


## 3. 操作指南

### 步骤 0：定义字段配置

在开始编码前，务必基于 `references/config-template.md` 模板，填写所有新增字段的配置。这份配置是后续所有改造的“单一事实来源”，确保了命名、类型和行为的一致性。

### 步骤 1：扩展业务模型 (Model)

此步骤在内存中扩展数据结构，以承接上游字段。

1.  **扩展上游承接模型 `QuoteItem`**
    *   **路径**：例如 `biz/bizmodels/biz_quote.go`
    *   **操作**：在 `QuoteItem` 结构体中，根据字段配置添加新字段。`json` 标签必须与上游（报价系统）接口的字段名完全一致。

    *   **代码示例**：
        ```go
        // biz/bizmodels/biz_quote.go
        type QuoteItem struct {
            // ... (原有字段)
            ShowName                  string `json:"showName"`
            SalesMode                 string `json:"SalesMode"`               // [新增]
            ConfigIsPublic            string `json:"ConfigIsPublic"`          // [新增]
            ConfigPublicDisplay       string `json:"ConfigPublicDisplay"`     // [新增]
            PrePayRatio               string `json:"prePayRatio"`             // [新增]
            PrePayRatioCode           string `json:"prePayRatioCode"`         // [新增]
            SpBuyDuration             string `json:"spBuyDuration"`           // [新增]
            SpBuyDurationCode         string `json:"spBuyDurationCode"`       // [新增]
            CommitFeeInterval         string `json:"commitFeeInterval"`       // [新增]
            CommitFeeIntervalCode     string `json:"commitFeeIntervalCode"`   // [新增]
            // ... (原有字段)
        }
        ```

2.  **扩展内部核心模型 `ProductInfo`**
    *   **路径**：例如 `biz/bizmodels/meta_common.go`
    *   **操作**：在 `ProductInfo` 结构体中添加对应的 Go 风格字段，用于系统内部流转。此处的字段名建议使用 Go 的驼峰式命名。

    *   **代码示例**：
        ```go
        // biz/bizmodels/meta_common.go
        type ProductInfo struct {
            // ... (原有字段)
            Exclude               string
            PrePayRatio           string // [新增]
            PrePayRatioCode       string // [新增]
            SpBuyDuration         string // [新增]
            SpBuyDurationCode     string // [新增]
            CommitFeeInterval     string // [新增]
            CommitFeeIntervalCode string // [新增]
            SalesMode             string // [新增]
            ConfigIsPublic        string // [新增]
            ConfigPublicDisplay   string // [新增]
            UpdatedTime           int64
        }
        ```

3.  **扩展透传模型 `QuoteDiscount` (如果需要，当且仅当新增字段需要参与合同价判重/预校验的时候才需要赋值。)**
    *   **文件路径**：`biz/bizmodels/biz_quote.go`
    *   **场景**：当新增字段需要透传给合同价系统时，通常需要扩展 `QuoteDiscount`结构，具体结构根据合同价系统要求而定。
    *   **操作**：根据字段配置，在 `QuoteDiscount`（或其他合适的 `Extra` 等内嵌结构体）中添加新字段，并确保 `json:"..."` 标签与合同价系统要求一致。
    *   **示例**：
        ```go
        // biz/bizmodels/biz_quote.go

        type QuoteDiscount struct {
            Product           string `json:"Product"`       // [修改/新增]
            ProductName       string `json:"ProductName"`              // [修改/新增]
            // ...
        }
        ```

### 步骤 2：更新字段映射 (Mapping)

此步骤打通数据在不同模型间的流转链路。

1.  **更新 `QuoteItem.GenProductInfo` (上游 -> 内部)**
    *   **路径**：例如 `biz/bizmodels/biz_quote.go`
    *   **操作**：将 `QuoteItem` 的新字段值，赋给 `ProductInfo` 实例。

    *   **代码示例**：
        ```go
        // biz/bizmodels/biz_quote.go
        func (q *QuoteItem) GenProductInfo(...) *ProductInfo {
            // ...
            return &ProductInfo{
                // ... (原有映射)
                PrePayRatio:           q.PrePayRatio,
                PrePayRatioCode:       q.PrePayRatioCode,
                SpBuyDuration:         q.SpBuyDuration,
                SpBuyDurationCode:     q.SpBuyDurationCode,
                CommitFeeInterval:     q.CommitFeeInterval,
                CommitFeeIntervalCode: q.CommitFeeIntervalCode,
                SalesMode:             q.SalesMode,
                ConfigIsPublic:        q.ConfigIsPublic,
                ConfigPublicDisplay:   q.ConfigPublicDisplay,
            }
        }
        ```

2.  **更新 `ProductInfo.GenQuoteDiscount` (内部 -> 下游)**
    *   **路径**：例如 `biz/bizmodels/meta_common.go`
    *   **操作**：当从 `ProductInfo` 构造 `QuoteDiscount` 时，将新字段填充到 `QuoteDiscount` 中。

    *   **代码示例**：
        ```go
        // biz/bizmodels/meta_common.go
        func (p *ProductInfo) GenQuoteDiscount(...) []*QuoteDiscount {
            var savingPlanExtra *SavingPlanInExtra
            // ...
            if p.SalesMode == multienv.SalesModeSavingsPlans {
                savingPlanExtra = &SavingPlanInExtra{
                    PrePayRatio:           p.PrePayRatio,
                    PrePayRatioCode:       p.PrePayRatioCode,
                    SpBuyDuration:         p.SpBuyDuration,
                    SpBuyDurationCode:     p.SpBuyDurationCode,
                    CommitFeeInterval:     p.CommitFeeInterval,
                    CommitFeeIntervalCode: p.CommitFeeIntervalCode,
                }
            }
            // ...
            qd := &QuoteDiscount{
                // ...
                Extra: &DiscountExtra{
                    SavingPlan: savingPlanExtra,
                },
            }
            // ...
            return ...
        }
        ```

3.  **更新 `ConvertContractDiscount` (如果需要参与在途合同判重)**
    *   **路径**: 例如 `biz/bizmodels/meta_common.go`
    *   **操作**: 如果字段需要参与在途合同判重（`IsForDupCheck=true`），需将其 `Code` 值追加到 `discountKey` 的拼接逻辑中，确保顺序一致。
    *   **代码示例**:
        ```go
        // biz/bizmodels/meta_common.go
        func (p *ProductInfo) ConvertContractDiscount(...) *ContractDiscount {
            // ...
            discountKey := fmt.Sprintf("%v%v%v%v%v%v%v%v%v%v%v%v", 
                p.TradeProduct, p.ConfigCategory, p.Configuration, 
                p.BillingMethodCode, p.RegionCode, p.ChargeElementCode, 
                p.PriceFactorCode, p.ChargeItemCode, p.ChargeItemTag, 
                p.PrePayRatioCode, p.SpBuyDurationCode, p.CommitFeeIntervalCode) // [注意] 按顺序追加判重字段
            // ...
        }
        ```

### 步骤 3：扩展数据库与 DAL (Database & DAL)

此步骤将内存中的数据持久化到数据库。

1.  **编写数据库变更脚本 (DB Schema)**
    *   **文件**：`references/schema-changes.sql`
    *   **操作**：参考该文件中的示例，为 `volc_contract_commodity` 表编写 `ALTER TABLE` 语句。
    *   **核心规则**：所有新增列必须包含 `NOT NULL` 和 `DEFAULT ''`（或 `0`）约束。

    *   **SQL 示例**：
        ```sql
        -- references/schema-changes.sql
        ALTER TABLE `volc_contract_commodity`
        ADD COLUMN `sales_mode` varchar(64) NOT NULL DEFAULT '' COMMENT '售卖模式...',
        ADD COLUMN `pre_pay_ratio` varchar(64) NOT NULL DEFAULT '' COMMENT '预付比例 (展示值)',
        ADD COLUMN `pre_pay_ratio_code` varchar(64) NOT NULL DEFAULT '' COMMENT '预付比例 (编码)',
        ADD COLUMN `sp_buy_duration` varchar(64) NOT NULL DEFAULT '' COMMENT '节省计划购买时长 (展示值)',
        ADD COLUMN `sp_buy_duration_code` varchar(64) NOT NULL DEFAULT '' COMMENT '节省计划购买时长 (编码)',
        ADD COLUMN `commit_fee_interval` varchar(64) NOT NULL DEFAULT '' COMMENT '承诺消费金额 (展示值)',
        ADD COLUMN `commit_fee_interval_code` varchar(64) NOT NULL DEFAULT '' COMMENT '承诺消费金额 (编码)';
        ```

2.  **扩展 GORM 模型 `VolcContractCommodity`**
    *   **路径**：例如 `biz/dal/model/contract_manage_info.go`
    *   **操作**：在 `VolcContractCommodity` 结构体中添加与新数据库列对应的字段，并使用 `gorm:"column:..."` 标签进行精确映射。

    *   **代码示例**：
        ```go
        // biz/dal/model/contract_manage_info.go
        type VolcContractCommodity struct {
            // ... (原有字段)
            SalesMode             string `gorm:"column:sales_mode;NOT NULL"`
            ConfigIsPublic        string `gorm:"column:config_is_public;NOT NULL"`
            ConfigPublicDisplay   string `gorm:"column:config_public_display;NOT NULL"`
            PrePayRatio           string `gorm:"column:pre_pay_ratio;NOT NULL"`
            PrePayRatioCode       string `gorm:"column:pre_pay_ratio_code;NOT NULL"`
            SpBuyDuration         string `gorm:"column:sp_buy_duration;NOT NULL"`
            SpBuyDurationCode     string `gorm:"column:sp_buy_duration_code;NOT NULL"`
            CommitFeeInterval     string `gorm:"column:commit_fee_interval;NOT NULL"`
            CommitFeeIntervalCode string `gorm:"column:commit_fee_interval_code;NOT NULL"`
        }
        ```

3.  **更新 DAL 双向转换函数**
    *   **目标**：确保数据能够正确地写入数据库和从数据库读出。**这是最容易出错的环节，必须成对修改**。
    *   **写操作 (内部 -> DB)**：更新 `ConvertCommodity` 函数。
        *   **路径**：例如 `biz/dal/model/contract_manage_info.go`
        *   **代码示例**:
            ```go
            // biz/dal/model/contract_manage_info.go
            func ConvertCommodity(product *bizmodels.ProductInfo, ...) *VolcContractCommodity {
                return &VolcContractCommodity{
                    // ... (原有映射)
                    PrePayRatio:           product.PrePayRatio,
                    PrePayRatioCode:       product.PrePayRatioCode,
                    SpBuyDuration:         product.SpBuyDuration,
                    SpBuyDurationCode:     product.SpBuyDurationCode,
                    CommitFeeInterval:     product.CommitFeeInterval,
                    CommitFeeIntervalCode: product.CommitFeeIntervalCode,
                    SalesMode:             product.SalesMode,
                    ConfigIsPublic:        product.ConfigIsPublic,
                    ConfigPublicDisplay:   product.ConfigPublicDisplay,
                }
            }
            ```
    *   **读操作 (DB -> 内部)**：更新 `VolcContractCommodity.GenProductInfo` 函数。
        *   **路径**：例如 `biz/dal/model/contract_manage_info.go`
        *   **代码示例**:
            ```go
            // biz/dal/model/contract_manage_info.go
            func (v *VolcContractCommodity) GenProductInfo() *bizmodels.ProductInfo {
                return &bizmodels.ProductInfo{
                    // ... (原有映射)
                    PrePayRatio:           v.PrePayRatio,
                    PrePayRatioCode:       v.PrePayRatioCode,
                    SpBuyDuration:         v.SpBuyDuration,
                    SpBuyDurationCode:     v.SpBuyDurationCode,
                    CommitFeeInterval:     v.CommitFeeInterval,
                    CommitFeeIntervalCode: v.CommitFeeIntervalCode,
                    SalesMode:             v.SalesMode,
                    ConfigIsPublic:        v.ConfigIsPublic,
                    ConfigPublicDisplay:   v.ConfigPublicDisplay,
                }
            }
            ```

## 3. 自检清单

完成编码后，请逐一核对以下事项：

- [ ] **模型层**：`QuoteItem`、`ProductInfo`、`QuoteDiscount`、`VolcContractCommodity` 的字段是否已添加齐全？`json` 和 `gorm` 标签是否正确？
- [ ] **映射层**：`QuoteItem.GenProductInfo`、`ProductInfo.GenQuoteDiscount` 的映射是否已更新？
- [ ] **判重层**：若字段参与判重，`ConvertContractDiscount` 中的 `discountKey` 是否已追加新字段的 `Code` 值？
- [ ] **数据库层**：`references/schema-changes.sql` 中的 `ALTER TABLE` 语句是否完整，且遵循 `NOT NULL` + `DEFAULT` 规则？
- [ ] **DAL 层**：`ConvertCommodity` (写) 和 `GenProductInfo` (读) 是否**均已更新**，实现了正确的双向映射？
- [ ] **编译检查**：在项目根目录执行 `go build ./...` 是否能成功通过？

## 4. 常见差错与护栏

- **护栏：字段名符合规范**
    - **护栏**：严格遵守 `references/config-template.md` 中定义的字段名。在 `QuoteItem` 中，`json` 标签必须与上游接口保持一致；在 `ProductInfo` 和其他内部模型中，保持项目内部命名风格统一。
    - **措施**：在 Code Review 中，检查每一个字段的 `json` 标签是否与 `references/config-template.md` 中定义的一致。

- **护栏：双向映射必须成对更新**
    - **描述**：最常见的错误是只更新了 `ConvertCommodity`（写），而忘记更新 `GenProductInfo`（读），导致数据能存进去但读不出来。
    - **措施**：务必将这两个函数的修改视为一个原子操作，同时进行。

- **护栏：数据库新增列必须有默认值**
    - **描述**：对已有数据的表添加新列，若没有默认值且为 `NOT NULL`，会导致数据库操作失败或锁表。
    - **措施**：所有 `ALTER TABLE ... ADD COLUMN` 语句必须包含 `NOT NULL DEFAULT ''`（或 `0` 等）。

- **护栏：GORM `column` 标签必须显式指定**
    - **描述**：依赖 GORM 的自动命名映射（如 `PrePayRatioCode` -> `pre_pay_ratio_code`）存在风险，一旦规则变化或有特殊命名，将导致映射失败。
    - **措施**：所有数据库模型字段必须显式使用 `gorm:"column:column_name"` 标签。

- **护栏：避免只改模型未改映射**
    - **描述**：仅在 `QuoteItem`、`ProductInfo`、`VolcContractCommodity` 中添加了字段，但忘记在 `GenProductInfo`、`ConvertCommodity` 等函数中进行赋值。
    - **措施**：Code Review 时，将模型修改和其对应的转换函数视为一个整体进行检查。
- 
- **护栏：`QuoteDiscount` 结构与合同价保持一致**
    - **描述**：与合同价系统（`pricecli`）的 `QuoteDiscount` 字段定义强依赖。在修改 `QuoteDiscount` 前，必须先确认合同价系统侧的接收模型，确保 `json` 标签和层级结构完全对齐。
    - **措施**：与合同价系统侧的 `QuoteDiscount` 模型保持一致，避免字段定义不一致导致的映射错误。

- **护栏：全链路书库传递正确**
    - **描述**：完成代码修改后，务必进行交叉比对（Code Review），检查 `QuoteItem` -> `ProductInfo` -> `QuoteDiscount` 的整条链路，确保新增字段在每一步都得到正确传递。
    - **措施**：在 Code Review 中，检查每一步的映射函数，确认新增字段是否在所有函数中都被正确赋值。
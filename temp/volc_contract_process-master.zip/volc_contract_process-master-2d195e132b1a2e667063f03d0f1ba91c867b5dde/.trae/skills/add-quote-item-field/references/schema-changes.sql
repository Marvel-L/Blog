
-- DDL for volc_contract_commodity table extension
-- NOTE: Always add NOT NULL and a DEFAULT value for new columns to ensure backward compatibility.

ALTER TABLE `volc_contract_commodity`
    ADD COLUMN `sales_mode` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '售卖模式 (e.g., SavingsPlans, Others)',
ADD COLUMN `config_is_public` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '是否公开售卖 (0-否, 1-是)',
ADD COLUMN `config_public_display` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '非公开售卖时配置是否可见 (1-可见, 2-不可见)',
ADD COLUMN `pre_pay_ratio` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '预付比例 (展示值)',
ADD COLUMN `pre_pay_ratio_code` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '预付比例 (编码)',
ADD COLUMN `sp_buy_duration` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '节省计划购买时长 (展示值)',
ADD COLUMN `sp_buy_duration_code` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '节省计划购买时长 (编码)',
ADD COLUMN `commit_fee_interval` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '承诺消费金额 (展示值)',
ADD COLUMN `commit_fee_interval_code` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '承诺消费金额 (编码)';

## 新增字段配置模板

请复制并为每个新增字段填写以下表格，作为代码改造的唯一事实来源。

### 字段核心属性

| 配置项 | 示例值 (`SalesMode`) | 示例值 (`PrePayRatioCode`) | 描述 |
| --- | --- | --- | --- |
| **DisplayName** | 售卖模式 | 预付比例编码 | 对客或对内展示的名称，用于 UI、导出标题、日志等。 |
| **Code** | `SalesMode` | `PrePayRatioCode` | 在 Go 代码和 JSON 传输中使用的字段名，遵循驼峰命名法。 |
| **UpstreamCode** | `SalesMode` | `prePayRatioCode` | 上游报价系统接口 (`GetQuoteContract`) 中的原始 JSON 字段名。 |
| **ValueType** | `string` | `string` | 字段的数据类型 (e.g., `string`, `int`, `decimal.Decimal`)。 |
| **EnumMap** | `{\"SavingsPlans\": \"节省计划\", \"Others\": \"其他\"}` | `{\"1\": \"0预付\", \"2\": \"部分预付\", \"3\": \"全预付\"}` | 如果字段是枚举类型，提供 code 到 display name 的映射关系。 |
| **Description** | 区分商品是否为节省计划。 | 定义不同的预付比例选项，用于计算和判重。 | 字段的详细业务含义说明。 |

### 字段行为矩阵

通过此矩阵，明确每个字段在系统中的具体行为。

| 配置项 | 示例 (`SalesMode`) | 示例 (`PrePayRatioCode`) | 描述 |
| --- | --- | --- | --- |
| **IsForDisplay** | `true` | `false` | **是否对客展示**：决定字段是否出现在合同文本、导出文件的“配置规格”中。`true` 表示展示，`false` 表示仅为内部逻辑字段。 |
| **IsForDupCheck** | `true` | `true` | **是否参与判重**：决定字段的 `Code` 值是否应被包含在 `productKey` 和 `discountKey` 的拼接中，用于在途合同和合同价系统的判重。 |
| **Persistence** | `required` | `required` | **是否需要持久化**：`required` 表示必须存入数据库；`optional` 表示可选；`none` 表示无需持久化。 |
| **TargetDBColumn**| `sales_mode` | `pre_pay_ratio_code` | 若 `Persistence` 不为 `none`，则定义其在数据库中的列名，遵循下划线命名法。 |


---

### 待处理字段清单（示例）

请根据本次需求，填充以下表格：

| DisplayName | Code | UpstreamCode | ValueType | IsForDisplay | IsForDupCheck | Persistence | TargetDBColumn | Description |
|---|---|---|---|---|---|---|---|---|
| 售卖模式 | `SalesMode` | `SalesMode` | `string` | `true` | `true` | `required` | `sales_mode` | `SavingsPlans-节省计划` |
| 公开售卖 | `ConfigIsPublic` | `ConfigIsPublic` | `string` | `false` | `false` | `required` | `config_is_public` | `0-非公开,1-公开` |
| 公开配置展示 | `ConfigPublicDisplay` | `ConfigPublicDisplay` | `string` | `false` | `false` | `required` | `config_public_display` | `1-可见,2-不可见` |
| 预付比例 | `PrePayRatio` | `prePayRatio` | `string` | `true` | `false`| `required` | `pre_pay_ratio` | 展示值，如 `0预付` |
| 预付比例编码 | `PrePayRatioCode` | `prePayRatioCode` | `string` | `false` | `true` | `required` | `pre_pay_ratio_code`| 编码值，如 `1` |
| 购买时长 | `SpBuyDuration` | `spBuyDuration` | `string` | `true` | `false`| `required` | `sp_buy_duration` | 展示值，如 `1个月` |
| 购买时长编码 | `SpBuyDurationCode` | `spBuyDurationCode` | `string` | `false` | `true` | `required` | `sp_buy_duration_code`| 编码值，如 `1,1` |
| 承诺消费 | `CommitFeeInterval`| `commitFeeInterval` | `string` | `true` | `false`| `required` | `commit_fee_interval`| 展示值，如 `10000元`|
| 承诺消费编码|`CommitFeeIntervalCode`|`commitFeeIntervalCode`|`string`| `false` | `true` | `required` | `commit_fee_interval_code`| 编码值，如 `10000` |

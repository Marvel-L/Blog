### 核心模型与双向映射路径

数据在本系统的主要流转路径为：
**`QuoteItem` (承接上游) -> `ProductInfo` (内部业务模型) -> `VolcContractCommodity` (数据库持久化)**

#### 1. 上游字段承接与模型扩展 (内存操作)

- **上游数据承接模型**:
  - **路径**: 例如 `biz/bizmodels/biz_quote.go`
  - **结构体**: `QuoteItem`
  - **职责**: 定义与上游报价系统 `GetQuoteContractReq` 接口完全一致的结构，`json` 标签必须对齐。

- **内部核心商品模型**:
  - **路径**: 例如 `biz/bizmodels/meta_common.go`
  - **结构体**: `ProductInfo`
  - **职责**: 作为合同系统内部流转的核心业务模型，聚合了所有报价项信息。字段名采用 Go 风格。

- **向合同价系统透传的模型**:
  - **路径**: 例如 `biz/bizmodels/biz_quote.go`
  - **结构体**: `QuoteDiscount`, `DiscountExtra`, `SavingPlanInExtra`
  - **职责**: 构造用于调用合同价系统接口的 `QuoteDiscount` 数据，`json` 标签需要与合同价系统约定一致，当且仅当新增字段需要参与合同价判重/预校验的时候才需要赋值。

#### 2. 数据库持久化与 DAL 扩展 (持久化操作)

- **GORM 模型定义**:
  - **路径**: 例如 `biz/dal/model/contract_manage_info.go`
  - **结构体**: `VolcContractCommodity`
  - **职责**: 定义与数据库表 `volc_contract_commodity` 列完全对应的 GORM 模型，`gorm:"column:..."` 标签必须显式指定。

- **数据库变更脚本**:
  - **路径**: `references/schema-changes.sql` (在本技能目录中)
  - **职责**: 提供标准的 `ALTER TABLE` 语句。**易错点**：新增列必须包含 `NOT NULL` 和 `DEFAULT` 值，防止对存量数据造成影响。

#### 3. 核心双向转换逻辑 (数据流转)

- **从上游 `QuoteItem` 到内部 `ProductInfo` (内存)**:
  - **路径**: 例如 `biz/bizmodels/biz_quote.go`
  - **函数**: `func (q *QuoteItem) GenProductInfo(...) *ProductInfo`
  - **职责**: 数据流入的第一站，将上游模型转换为内部业务模型。

- **从 `ProductInfo` 到 `VolcContractCommodity` (写入数据库)**:
  - **路径**: 例如 `biz/dal/model/contract_manage_info.go`
  - **函数**: `func ConvertCommodity(...) *model.VolcContractCommodity`
  - **职责**: 数据写入数据库前的最后一步转换。**易错点**: 此处遗漏新字段映射，会导致数据无法存入数据库。

- **从 `VolcContractCommodity` 到 `ProductInfo` (从数据库读取)**:
  - **路径**: 例如 `biz/dal/model/contract_manage_info.go`
  - **函数**: `func (v *VolcContractCommodity) GenProductInfo(...) *bizmodels.ProductInfo`
  - **职责**: 从数据库读取数据后，转换为内部业务模型供业务逻辑使用。**易错点**: 此处遗漏新字段映射，会导致从数据库读取的数据在业务逻辑中丢失。

- **从 `ProductInfo` 到 `QuoteDiscount` (用于合同价等下游交互，当且仅当新增字段需要参与合同价判重/预校验的时候才需要赋值。)**:
  - **路径**: 例如 `biz/bizmodels/meta_common.go`
  - **函数**: `func (p *ProductInfo) GenQuoteDiscount(...) []*QuoteDiscount`
  - **职责**: 构造调用合同价系统所需的数据结构。

**核心原则**: 以上四个转换函数是数据流转的关键节点，任何新增字段都必须确保在这条链路中完整、正确地传递。**双向映射（写入和读取）必须成对修改**。
